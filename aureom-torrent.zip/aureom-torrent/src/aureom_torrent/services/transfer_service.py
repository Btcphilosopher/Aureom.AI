"""Transfer orchestration: the application's single authority over transfers.

Responsibilities
* add torrents / magnets (validation, duplicate and destination-conflict detection);
* persist user intent (destination, selection, manual pause, limits) and restore it at start-up;
* translate engine events into persisted facts and an immutable read model for the UI;
* enforce seeding limits and bandwidth schedules without overriding manual pauses;
* keep removal and data deletion separate, deleting only validated, owned paths.

All public methods are thread-safe and are called from worker threads or the
event pump – never from the GUI thread.
"""

from __future__ import annotations

import datetime as _dt
import logging
import os
import threading
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from ..diagnostics.redaction import redact
from ..domain.identity import TorrentIdentity
from ..domain.magnet import MagnetError, parse_magnet
from ..domain.schedule import BandwidthPlan, bandwidth_plan, seeding_limit_reached
from ..domain.state import derive_state, eta_seconds, ratio_permille
from ..domain.transfers import (TorrentMetadata, TorrentStatus, TransferDetails, TransferRecord, TransferState,
                                TransferView)
from ..engine import commands as c
from ..engine import events as e
from ..engine.interface import TorrentCodec, TorrentEngine, TorrentFormatError
from ..filesystem.paths import UnsafePathError, atomic_write, check_destination, owned_paths
from ..persistence.database import Database
from ..persistence.transfers import ResumeStore, TransferRepository
from ..settings.models import AppSettings
from ..settings.paths import AppPaths
from ..util.clock import Clock, SystemClock
from .engine_config import engine_settings
from .interfaces import AddOutcome, AddRejected

log = logging.getLogger(__name__)

PERSIST_INTERVAL_S = 30.0
Listener = Callable[[str, dict[str, Any]], None]


class OperationRejected(Exception):
    """A user operation that was refused. ``str(exc)`` is safe to show."""


@dataclass(frozen=True, slots=True)
class SessionView:
    download_rate: int = 0
    upload_rate: int = 0
    active: int = 0
    downloading: int = 0
    seeding: int = 0
    queued: int = 0
    total: int = 0
    dht_enabled: bool = False
    dht_nodes: int = 0
    listening: bool = False
    listen_port: int = 0
    has_incoming: bool = False
    peers: int = 0
    paused: bool = False
    schedule: str = ""
    engine_running: bool = False
    fault: str = ""
    port_mapping: str = ""


class TransferService:
    def __init__(self, db: Database, engine: TorrentEngine, codec: TorrentCodec, paths: AppPaths,
                 settings: Callable[[], AppSettings], clock: Clock | None = None, *, secrets=None,
                 isolated: bool = False):
        self._engine = engine
        self._codec = codec
        self._paths = paths
        self._settings = settings
        self._clock = clock or SystemClock()
        self._secrets = secrets
        self._isolated = isolated
        self._repo = TransferRepository(db)
        self._db = db
        self._store = ResumeStore(paths.resume_dir, paths.torrents_dir)
        self._lock = threading.RLock()
        self._records: dict[str, TransferRecord] = {}
        self._status: dict[str, TorrentStatus] = {}
        self._metadata: dict[str, TorrentMetadata] = {}
        self._details: dict[str, TransferDetails] = {}
        self._pending_moves: dict[str, str] = {}
        self._pending_confirms: dict[str, dict[str, Any]] = {}
        self._pending_exports: dict[str, str] = {}
        self._removing: dict[str, dict[str, Any]] = {}
        self._dirty: set[str] = set()
        self._listeners: list[Listener] = []
        self._session = e.SessionStats()
        self._engine_running = False
        self._fault = ""
        self._port_mapping = ""
        self._plan: BandwidthPlan | None = None
        self._version = 0
        self._last_persist = 0.0
        self.startup_notes: list[str] = []
        self.shutdown_report: e.ShutdownReport | None = None

    # ------------------------------------------------------------- plumbing
    def subscribe(self, listener: Listener) -> None:
        self._listeners.append(listener)

    def _notify(self, kind: str, **payload: Any) -> None:
        for listener in list(self._listeners):
            try:
                listener(kind, payload)
            except Exception:
                log.exception("transfer listener failed")

    def _bump(self) -> None:
        self._version += 1

    def _activity(self, transfer_id: str, level: str, kind: str, message: str) -> None:
        message = redact(message)
        try:
            self._repo.add_event(transfer_id, int(self._clock.now()), level, kind, message)
        except Exception:
            log.exception("could not record activity")
        getattr(log, "warning" if level == "warning" else "error" if level == "error" else "info")(
            "transfer %s: %s", transfer_id[:8], message)

    def _save(self, record: TransferRecord) -> None:
        self._repo.save(record)
        self._dirty.discard(record.id)

    def _require(self, transfer_id: str) -> TransferRecord:
        record = self._records.get(transfer_id)
        if record is None:
            raise OperationRejected("That transfer no longer exists.")
        return record

    # -------------------------------------------------------------- startup
    def current_engine_settings(self) -> c.EngineSettings:
        app = self._settings()
        self._plan = bandwidth_plan(app.queue, _dt.datetime.fromtimestamp(self._clock.now()))
        return engine_settings(app, self._secrets, plan=self._plan, isolated=self._isolated)

    def restore(self) -> int:
        """Load persisted transfers and hand them to the engine. Returns the number restored."""
        engine_version = self._engine.capabilities().version
        previous = self._db.get_meta("engine_version")
        if previous and previous != engine_version:
            note = (f"The transfer engine changed from {previous} to {engine_version}; saved resume data will be "
                    "validated by the engine and files re-checked where it is rejected.")
            self.startup_notes.append(note)
            log.warning(note)
        self._db.set_meta("engine_version", engine_version)
        self._db.set_meta("engine_name", self._engine.capabilities().engine)

        restored = 0
        with self._lock:
            for record in self._repo.list():
                self._records[record.id] = record
                torrent_data = self._store.load_torrent(record.id)
                resume = None if record.preview else self._store.load_resume(record.id)
                if torrent_data is not None:
                    try:
                        self._metadata[record.id] = self._codec.inspect(torrent_data)
                    except TorrentFormatError as exc:
                        self._activity(record.id, "warning", "restore", f"Stored torrent file is unreadable: {exc}")
                        torrent_data = None
                if resume is None and not record.preview:
                    if torrent_data is not None or record.has_metadata:
                        self._activity(record.id, "warning", "restore",
                                       "No saved resume data was found; existing files will be re-checked.")
                if resume is None and torrent_data is None and not record.magnet_uri:
                    record.last_error = ("This transfer's saved state is missing and it has no magnet link to "
                                         "recover from. Remove it and add the torrent again.")
                    record.last_state = TransferState.ERROR
                    self._save(record)
                    continue
                if _had_data(record) and not record.preview and not os.path.isdir(record.save_path):
                    # A removed destination must not be silently re-created and re-downloaded.
                    record.manual_paused = True
                    record.last_error = (f"The destination folder “{record.save_path}” is missing. "
                                         "Reconnect the drive or choose “Move storage…”, then start the transfer.")
                    self._activity(record.id, "error", "restore", record.last_error)
                    self._save(record)
                elif record.last_error and record.last_state is not TransferState.ERROR:
                    record.last_error = ""
                self._engine.submit(c.AddTorrent(
                    transfer_id=record.id,
                    save_path=str(self._paths.staging_dir) if record.preview else record.save_path,
                    torrent_data=torrent_data, magnet_uri=record.magnet_uri, resume_data=resume,
                    file_priorities=tuple(record.file_priorities) if record.file_priorities else None,
                    paused=record.manual_paused or record.stopped_by_limit,
                    metadata_only=record.preview,
                    download_limit=record.download_limit, upload_limit=record.upload_limit))
                restored += 1
            self._bump()
        return restored

    # ---------------------------------------------------- TransferGateway
    def default_save_path(self) -> str:
        from ..settings.paths import default_download_dir

        return self._settings().general.default_save_path or str(default_download_dir())

    def inspect_torrent(self, torrent_data: bytes) -> TorrentMetadata:
        return self._codec.inspect(torrent_data)

    def find_duplicate(self, identity: TorrentIdentity) -> TransferRecord | None:
        with self._lock:
            for record in self._records.values():
                if record.id not in self._removing and record.identity.matches(identity):
                    return record.copy()
        return None

    def _conflict(self, save_path: str, name: str, exclude_id: str | None = None) -> TransferRecord | None:
        """Another transfer that already writes ``save_path/name``."""
        if not name:
            return None
        target = os.path.normcase(os.path.realpath(os.path.join(save_path, name))).casefold()
        for other in self._records.values():
            if other.id == exclude_id or other.preview or not other.has_metadata or other.id in self._removing:
                continue
            theirs = os.path.normcase(os.path.realpath(os.path.join(other.save_path, other.name))).casefold()
            if theirs == target:
                return other
        return None

    def _check_destination(self, save_path: str, required: int) -> None:
        report = check_destination(save_path, required)
        if not report.ok:
            raise AddRejected(" ".join(report.problems), reason="destination")

    def add_torrent_data(self, torrent_data: bytes, *, save_path: str, category: str = "", paused: bool = False,
                         file_priorities: list[int] | None = None, source: str = "file",
                         feed_entry_id: int | None = None, manifest_id: str | None = None) -> AddOutcome:
        try:
            metadata = self._codec.inspect(torrent_data)
        except TorrentFormatError as exc:
            raise AddRejected(str(exc), reason="invalid") from exc
        if metadata.path_problems:
            raise AddRejected("This torrent was refused because its file list is unsafe: "
                              + "; ".join(metadata.path_problems[:3]), reason="unsafe_paths")
        if file_priorities is not None and len(file_priorities) != len(metadata.files):
            raise AddRejected("The file selection does not match this torrent's file list.", reason="invalid")
        with self._lock:
            existing = self.find_duplicate(metadata.identity)
            if existing is not None:
                return AddOutcome(existing.id, created=False, duplicate_of=existing.id,
                                  message=f"“{existing.name}” is already in your transfers.")
            wanted = metadata.total_size if file_priorities is None else sum(
                f.size for f, p in zip(metadata.files, file_priorities) if p > 0 and not f.pad)
            # A torrent created from local files (or re-added over existing data) needs no new space.
            already = os.path.exists(os.path.join(save_path, metadata.name))
            self._check_destination(save_path, 0 if already else wanted)
            other = self._conflict(save_path, metadata.name)
            if other is not None:
                raise AddRejected(
                    f"“{metadata.name}” in this folder is already used by the transfer “{other.name}”. "
                    "Two transfers must not write the same files; choose another destination.", reason="conflict")
            record = TransferRecord(
                id=uuid.uuid4().hex, identity=metadata.identity, name=metadata.name, save_path=save_path,
                category=category, added_at=int(self._clock.now()), source=source, has_metadata=True,
                manual_paused=paused, file_priorities=list(file_priorities or []),
                total_size=metadata.total_size, private=metadata.private,
                last_state=TransferState.PAUSED if paused else TransferState.ADDED,
                manifest_id=manifest_id, feed_entry_id=feed_entry_id)
            self._store.save_torrent(record.id, torrent_data)
            self._save(record)
            self._records[record.id] = record
            self._metadata[record.id] = metadata
            self._activity(record.id, "info", "added",
                           f"Added from {source} ({metadata.identity.kind}, {len(metadata.real_files)} file(s)).")
            self._engine.submit(c.AddTorrent(
                transfer_id=record.id, save_path=save_path, torrent_data=torrent_data,
                file_priorities=tuple(file_priorities) if file_priorities else None, paused=paused))
            self._bump()
            return AddOutcome(record.id, created=True)

    def add_magnet(self, uri: str, *, save_path: str, category: str = "", paused: bool = False,
                   preview: bool = False, source: str = "magnet", feed_entry_id: int | None = None) -> AddOutcome:
        try:
            link = parse_magnet(uri)
        except MagnetError as exc:
            raise AddRejected(str(exc), reason="invalid") from exc
        with self._lock:
            existing = self.find_duplicate(link.identity)
            if existing is not None:
                return AddOutcome(existing.id, created=False, duplicate_of=existing.id,
                                  message=f"“{existing.name}” is already in your transfers.")
            if not preview:
                self._check_destination(save_path, 0)
            record = TransferRecord(
                id=uuid.uuid4().hex, identity=link.identity,
                name=link.display_name or f"Magnet {link.identity.short()}", save_path=save_path,
                category=category, added_at=int(self._clock.now()), source=source,
                magnet_uri=link.canonical_uri(), has_metadata=False, preview=preview,
                manual_paused=paused and not preview,
                last_state=TransferState.RETRIEVING_METADATA, feed_entry_id=feed_entry_id)
            self._save(record)
            self._records[record.id] = record
            self._activity(record.id, "info", "added",
                           "Magnet added; retrieving metadata from peers"
                           + (" for preview (no payload is requested)." if preview else "."))
            self._engine.submit(c.AddTorrent(
                transfer_id=record.id,
                save_path=str(self._paths.staging_dir) if preview else save_path,
                magnet_uri=record.magnet_uri, paused=record.manual_paused, metadata_only=preview,
                peers=link.peers))
            self._bump()
            return AddOutcome(record.id, created=True)

    # -------------------------------------------------------------- preview
    def confirm_preview(self, transfer_id: str, *, save_path: str, file_priorities: list[int] | None = None,
                        category: str | None = None, paused: bool = False) -> None:
        """Accept a metadata preview: choose files and destination, then start (or add paused)."""
        with self._lock:
            record = self._require(transfer_id)
            if not record.preview:
                raise OperationRejected("This transfer is not waiting for review.")
            metadata = self._metadata.get(transfer_id)
            wanted = 0
            if metadata is not None:
                if file_priorities is not None and len(file_priorities) != len(metadata.files):
                    raise OperationRejected("The file selection does not match this torrent's file list.")
                wanted = metadata.total_size if file_priorities is None else sum(
                    f.size for f, p in zip(metadata.files, file_priorities) if p > 0 and not f.pad)
                other = self._conflict(save_path, metadata.name, exclude_id=transfer_id)
                if other is not None:
                    raise OperationRejected(
                        f"“{metadata.name}” in this folder is already used by the transfer “{other.name}”. "
                        "Choose another destination.")
            elif file_priorities is not None:
                raise OperationRejected("Files cannot be selected before the metadata has been retrieved.")
            report = check_destination(save_path, wanted)
            if not report.ok:
                raise OperationRejected(" ".join(report.problems))
            try:
                os.makedirs(save_path, exist_ok=True)
            except OSError as exc:
                raise OperationRejected(f"The destination could not be created: {exc.strerror}.") from exc
            self._pending_confirms[transfer_id] = {
                "save_path": save_path, "priorities": list(file_priorities or []), "paused": paused,
                "category": category}
            self._engine.submit(c.ConfirmPreview(
                transfer_id, save_path, tuple(file_priorities) if file_priorities is not None else None, paused))

    # ------------------------------------------------------------- controls
    def pause(self, transfer_ids: list[str]) -> None:
        with self._lock:
            for tid in transfer_ids:
                record = self._records.get(tid)
                if record is None or record.preview:
                    continue
                record.manual_paused = True
                record.stopped_by_limit = False
                self._save(record)
                self._engine.submit(c.PauseTorrent(tid))
                self._activity(tid, "info", "control", "Paused by you.")
            self._bump()

    def resume(self, transfer_ids: list[str]) -> None:
        with self._lock:
            for tid in transfer_ids:
                record = self._records.get(tid)
                if record is None or record.preview:
                    continue
                if _had_data(record) and not os.path.isdir(record.save_path):
                    # Do not silently re-create (and re-download into) a destination that vanished,
                    # e.g. an unplugged drive.
                    record.manual_paused = True
                    record.last_error = (f"The destination folder “{record.save_path}” is missing. "
                                         "Reconnect it or use “Move storage…”.")
                    self._save(record)
                    self._activity(tid, "error", "control", record.last_error)
                    self._notify("error", transfer_id=tid, message=record.last_error)
                    continue
                if record.stopped_by_limit:
                    record.ratio_limit_permille = -1
                    record.seed_time_limit_s = -1
                    self._activity(tid, "info", "control",
                                   "Seeding limits were lifted for this transfer because you started it manually.")
                record.manual_paused = False
                record.stopped_by_limit = False
                record.last_error = ""
                self._save(record)
                self._engine.submit(c.ResumeTorrent(tid))
                self._activity(tid, "info", "control", "Started by you.")
            self._bump()

    def recheck(self, transfer_ids: list[str]) -> None:
        with self._lock:
            for tid in transfer_ids:
                record = self._records.get(tid)
                if record is None or record.preview or not record.has_metadata:
                    continue
                self._engine.submit(c.ForceRecheck(tid))
                self._activity(tid, "info", "control", "Re-check of existing data requested.")

    def set_file_priorities(self, transfer_id: str, priorities: list[int]) -> None:
        with self._lock:
            record = self._require(transfer_id)
            metadata = self._metadata.get(transfer_id)
            if metadata is None or len(priorities) != len(metadata.files):
                raise OperationRejected("The file selection does not match this torrent's file list.")
            priorities = [max(0, min(7, int(p))) for p in priorities]
            record.file_priorities = priorities
            self._save(record)
            self._engine.submit(c.SetFilePriorities(transfer_id, tuple(priorities)))
            self._engine.submit(c.RequestDetails(transfer_id, files=True))
            self._activity(transfer_id, "info", "control", "File selection changed.")

    def move_storage(self, transfer_id: str, new_path: str) -> None:
        with self._lock:
            record = self._require(transfer_id)
            if record.preview or not record.has_metadata:
                raise OperationRejected("This transfer has no files to move yet.")
            if transfer_id in self._pending_moves:
                raise OperationRejected("A move is already in progress for this transfer.")
            if os.path.realpath(new_path) == os.path.realpath(record.save_path):
                raise OperationRejected("The transfer is already stored in that folder.")
            status = self._status.get(transfer_id)
            done = status.total_done if status else 0
            report = check_destination(new_path, done)
            if not report.ok:
                raise OperationRejected(" ".join(report.problems))
            other = self._conflict(new_path, record.name, exclude_id=transfer_id)
            if other is not None:
                raise OperationRejected(f"“{record.name}” in that folder is already used by “{other.name}”.")
            self._pending_moves[transfer_id] = new_path
            self._engine.submit(c.MoveStorage(transfer_id, new_path))
            self._activity(transfer_id, "info", "move", f"Moving storage to {new_path}")

    def set_limits(self, transfer_id: str, *, download_limit: int | None = None, upload_limit: int | None = None,
                   ratio_limit_permille: int | None | str = "keep",
                   seed_time_limit_s: int | None | str = "keep") -> None:
        with self._lock:
            record = self._require(transfer_id)
            if download_limit is not None:
                record.download_limit = max(0, int(download_limit))
            if upload_limit is not None:
                record.upload_limit = max(0, int(upload_limit))
            if ratio_limit_permille != "keep":
                record.ratio_limit_permille = ratio_limit_permille  # type: ignore[assignment]
            if seed_time_limit_s != "keep":
                record.seed_time_limit_s = seed_time_limit_s  # type: ignore[assignment]
            self._save(record)
            self._engine.submit(c.SetTorrentLimits(transfer_id, record.download_limit, record.upload_limit))

    def set_category(self, transfer_ids: list[str], category: str) -> None:
        with self._lock:
            for tid in transfer_ids:
                record = self._records.get(tid)
                if record is not None:
                    record.category = category[:64]
                    self._save(record)
            self._bump()

    def replace_trackers(self, transfer_id: str, trackers: list[tuple[str, int]]) -> None:
        from urllib.parse import urlsplit

        with self._lock:
            self._require(transfer_id)
            cleaned: list[tuple[str, int]] = []
            for url, tier in trackers[:128]:
                url = url.strip()
                try:
                    parts = urlsplit(url)
                except ValueError:
                    parts = None
                if parts is None or parts.scheme.lower() not in ("http", "https", "udp") or not parts.hostname:
                    raise OperationRejected(f"“{redact(url)}” is not a supported tracker address "
                                            "(http, https or udp).")
                cleaned.append((url, max(0, int(tier))))
            self._engine.submit(c.ReplaceTrackers(transfer_id, tuple(cleaned)))
            self._engine.submit(c.RequestDetails(transfer_id, trackers=True))
            self._activity(transfer_id, "info", "trackers", f"Tracker list replaced ({len(cleaned)} tracker(s)).")

    def reannounce(self, transfer_ids: list[str]) -> None:
        for tid in transfer_ids:
            self._engine.submit(c.Reannounce(tid))

    def connect_peer(self, transfer_id: str, host: str, port: int) -> None:
        self._engine.submit(c.ConnectPeer(transfer_id, host, port))

    def request_details(self, transfer_id: str, *, peers: bool = False, trackers: bool = False,
                        files: bool = False, pieces: bool = False) -> None:
        self._engine.submit(c.RequestDetails(transfer_id, peers, trackers, files, pieces))

    # ------------------------------------------------------ remove / delete
    def remove(self, transfer_ids: list[str], *, delete_data: bool = False) -> None:
        """Remove transfers from the application; optionally also delete their downloaded data.

        Deletion is validated first: every file must resolve inside the
        transfer's own destination.  If validation fails nothing is removed.
        """
        with self._lock:
            plans: list[tuple[TransferRecord, bool]] = []
            for tid in transfer_ids:
                record = self._records.get(tid)
                if record is None or tid in self._removing:
                    continue
                delete = bool(delete_data and record.has_metadata and not record.preview)
                if delete:
                    metadata = self._metadata.get(tid)
                    if metadata is None:
                        raise OperationRejected(
                            f"The file list of “{record.name}” is not available, so its data cannot be deleted safely. "
                            "Remove it without deleting data, then delete the files yourself.")
                    try:
                        owned_paths(record.save_path, [f.path for f in metadata.real_files])
                    except UnsafePathError as exc:
                        raise OperationRejected(f"Data of “{record.name}” was not deleted: {exc}") from exc
                plans.append((record, delete))
            for record, delete in plans:
                self._removing[record.id] = {"name": record.name, "delete": delete}
                self._activity(record.id, "info", "remove",
                               "Removed with its downloaded data." if delete else "Removed (data kept on disk).")
                self._engine.submit(c.RemoveTorrent(record.id, delete_files=delete))
            self._bump()

    def _finish_removal(self, transfer_id: str) -> None:
        info = self._removing.pop(transfer_id, None)
        record = self._records.pop(transfer_id, None)
        self._status.pop(transfer_id, None)
        self._metadata.pop(transfer_id, None)
        self._details.pop(transfer_id, None)
        self._pending_moves.pop(transfer_id, None)
        self._pending_confirms.pop(transfer_id, None)
        self._dirty.discard(transfer_id)
        self._repo.delete(transfer_id)
        self._store.delete(transfer_id)
        self._bump()
        if record is not None:
            self._notify("removed", transfer_id=transfer_id, name=record.name,
                         deleted=bool(info and info.get("delete")))

    # --------------------------------------------------------------- sharing
    def magnet_uri(self, transfer_id: str) -> str:
        with self._lock:
            record = self._require(transfer_id)
            data = self._store.load_torrent(transfer_id)
            if data is not None:
                try:
                    return self._codec.make_magnet(data)
                except TorrentFormatError:
                    pass
            trackers: tuple[str, ...] = ()
            if record.magnet_uri:
                try:
                    trackers = parse_magnet(record.magnet_uri).trackers
                except MagnetError:
                    trackers = ()
            return self._codec.magnet_for(record.identity, record.name if record.has_metadata else "", trackers)

    def export_torrent(self, transfer_id: str, destination: str) -> str | None:
        """Write the .torrent to ``destination``.

        Returns the path when the stored file could be written immediately;
        returns None when the engine has to produce it (the result then arrives
        as an ``export_done`` / ``error`` notification).
        """
        with self._lock:
            record = self._require(transfer_id)
            if not record.has_metadata:
                raise OperationRejected("The metadata has not been retrieved yet.")
            data = self._store.load_torrent(transfer_id)
            if data is not None:
                atomic_write(destination, data)
                return destination
            self._pending_exports[transfer_id] = destination
            self._engine.submit(c.ExportTorrent(transfer_id))
            return None

    # ------------------------------------------------------------ read model
    def version(self) -> int:
        return self._version

    def record(self, transfer_id: str) -> TransferRecord | None:
        with self._lock:
            record = self._records.get(transfer_id)
            return record.copy() if record else None

    def metadata(self, transfer_id: str) -> TorrentMetadata | None:
        with self._lock:
            return self._metadata.get(transfer_id)

    def details(self, transfer_id: str) -> TransferDetails | None:
        with self._lock:
            return self._details.get(transfer_id)

    def activity(self, transfer_id: str, limit: int = 200) -> list[tuple[int, str, str, str]]:
        return self._repo.events(transfer_id, limit)

    def _view(self, record: TransferRecord) -> TransferView:
        status = self._status.get(record.id)
        if record.id in self._removing:
            state, detail = TransferState.QUEUED, "Removing…"
        elif status is None:
            state = TransferState.ERROR if record.last_error else record.last_state
            detail = record.last_error or ("Waiting for the engine" if self._engine_running else "Engine starting")
            if not record.last_error and state in (TransferState.DOWNLOADING, TransferState.SEEDING,
                                                    TransferState.CHECKING, TransferState.MOVING):
                state = TransferState.QUEUED
        else:
            state, detail = derive_state(status, manual_paused=record.manual_paused,
                                         stopped_by_limit=record.stopped_by_limit, preview=record.preview)
            if record.last_error and state is not TransferState.ERROR and (
                    state in (TransferState.PAUSED, TransferState.COMPLETED)):
                state, detail = TransferState.ERROR, record.last_error
        if status is not None and status.has_metadata:
            size = status.total_wanted if status.total_wanted > 0 else record.total_size
            progress = status.progress_ppm
            down, up = status.all_time_download, status.all_time_upload
            selected_complete = status.is_finished and status.total_wanted > 0
            torrent_complete = status.is_seeding
            if record.preview:
                progress, selected_complete, torrent_complete, size = 0, False, False, record.total_size
        else:
            size, progress = record.total_size, record.last_progress_ppm if status is None else 0
            down, up = record.downloaded_total, record.uploaded_total
            selected_complete = torrent_complete = False
        return TransferView(
            id=record.id, name=record.name, identity=record.identity, state=state, state_detail=detail,
            size=size, total_size=record.total_size, progress_ppm=progress,
            selected_complete=selected_complete, torrent_complete=torrent_complete,
            download_rate=status.download_rate if status else 0, upload_rate=status.upload_rate if status else 0,
            peers=status.num_peers if status else 0, seeds=status.num_seeds if status else 0,
            ratio_permille=ratio_permille(up, down, size) if record.has_metadata else None,
            eta_seconds=eta_seconds(status, state) if status else None,
            category=record.category, save_path=record.save_path, added_at=record.added_at,
            has_metadata=record.has_metadata, private=record.private, preview=record.preview,
            manual_paused=record.manual_paused, error=record.last_error or (status.error if status else ""),
            downloaded=down, uploaded=up,
            pieces_have=status.pieces_have if status else 0,
            pieces_total=self._metadata[record.id].num_pieces if record.id in self._metadata else 0,
            seeding_seconds=status.seeding_seconds if status else record.seeding_seconds,
            last_announce=dict(record.last_announce), source=record.source, live=status is not None)

    def snapshot(self) -> tuple[int, list[TransferView], SessionView]:
        with self._lock:
            views = [self._view(r) for r in self._records.values()]
            down = sum(v.download_rate for v in views)
            up = sum(v.upload_rate for v in views)
            session = SessionView(
                download_rate=down, upload_rate=up,
                active=sum(1 for v in views if v.state in (TransferState.DOWNLOADING, TransferState.SEEDING,
                                                           TransferState.CHECKING, TransferState.RETRIEVING_METADATA)),
                downloading=sum(1 for v in views if v.state is TransferState.DOWNLOADING),
                seeding=sum(1 for v in views if v.state is TransferState.SEEDING),
                queued=sum(1 for v in views if v.state is TransferState.QUEUED),
                total=len(views), dht_enabled=self._session.dht_enabled, dht_nodes=self._session.dht_nodes,
                listening=self._session.listening, listen_port=self._session.listen_port,
                has_incoming=self._session.has_incoming, peers=self._session.num_peers,
                paused=self._session.paused, schedule=self._plan.schedule_name if self._plan else "",
                engine_running=self._engine_running, fault=self._fault, port_mapping=self._port_mapping)
            return self._version, views, session

    # --------------------------------------------------------------- events
    def handle_event(self, event: Any) -> None:  # noqa: C901
        with self._lock:
            if isinstance(event, e.StatusBatch):
                self._on_status(event)
            elif isinstance(event, e.EngineStarted):
                self._engine_running = True
                log.info("engine started: %s %s", event.engine, event.version)
                self._bump()
            elif isinstance(event, e.EngineStopped):
                self._engine_running = False
                self.shutdown_report = event.report
                self._bump()
            elif isinstance(event, e.EngineFault):
                self._fault = event.message if event.networking_stopped else ""
                (log.error if event.networking_stopped else log.info)("engine: %s", event.message)
                self._notify("engine_fault", message=event.message, stopped=event.networking_stopped)
                self._bump()
            elif isinstance(event, e.ListenResult):
                if event.ok:
                    log.info("listening on %s:%s (%s)", event.address, event.port, event.transport)
                else:
                    log.error("could not listen on %s:%s (%s): %s", event.address, event.port, event.transport,
                              event.message)
                    self._notify("error", transfer_id=None,
                                 message=f"Could not listen on {event.address}:{event.port} — {event.message}")
            elif isinstance(event, e.PortMapped):
                self._port_mapping = (f"{event.protocol} port {event.external_port} mapped" if event.ok
                                      else f"port mapping failed: {event.message}")
                log.info("port mapping: %s", self._port_mapping)
            elif isinstance(event, e.TorrentAdded):
                self._on_added(event)
            elif isinstance(event, e.TorrentAddFailed):
                self._on_add_failed(event)
            elif isinstance(event, e.MetadataReceived):
                self._on_metadata(event)
            elif isinstance(event, e.TorrentFinished):
                record = self._records.get(event.transfer_id)
                if record and not record.preview and record.completed_at is None:
                    record.completed_at = int(self._clock.now())
                    self._save(record)
                    self._activity(record.id, "info", "complete", "Selected files are complete and verified.")
                    self._notify("finished", transfer_id=record.id, name=record.name)
            elif isinstance(event, e.TorrentChecked):
                if event.transfer_id in self._records:
                    self._activity(event.transfer_id, "info", "check", "Existing data verified.")
            elif isinstance(event, e.TorrentErrored):
                self._on_error(event)
            elif isinstance(event, e.PieceHashFailed):
                if event.transfer_id in self._records:
                    self._activity(event.transfer_id, "warning", "integrity",
                                   f"Piece {event.piece} failed verification and will be downloaded again.")
            elif isinstance(event, e.StorageMoved):
                self._on_moved(event)
            elif isinstance(event, e.StorageMoveFailed):
                self._on_move_failed(event)
            elif isinstance(event, e.TorrentRemoved):
                self._finish_removal(event.transfer_id)
            elif isinstance(event, e.FilesDeleted):
                log.info("data deleted for transfer %s", event.transfer_id[:8])
            elif isinstance(event, e.FilesDeleteFailed):
                message = event.message
                if "not empty" in message.lower():
                    message = ("The transfer's files were deleted; its folder was kept because it contains "
                               "other files that do not belong to the transfer.")
                    self._notify("info", transfer_id=event.transfer_id, message=message)
                else:
                    self._notify("error", transfer_id=event.transfer_id,
                                 message=f"Some files could not be deleted: {message}")
                log.warning("delete for %s: %s", event.transfer_id[:8], message)
            elif isinstance(event, e.TrackerAnnounced):
                self._on_tracker(event)
            elif isinstance(event, e.ResumeDataReady):
                if event.transfer_id in self._records and event.transfer_id not in self._removing:
                    try:
                        self._store.save_resume(event.transfer_id, event.data)
                    except OSError as exc:
                        self._activity(event.transfer_id, "error", "resume", f"Resume data could not be written: {exc}")
            elif isinstance(event, e.ResumeDataFailed):
                if event.transfer_id in self._records:
                    self._activity(event.transfer_id, "warning", "resume",
                                   f"Resume data could not be generated: {event.message}")
            elif isinstance(event, e.DetailsReady):
                if event.details.transfer_id in self._records:
                    previous = self._details.get(event.details.transfer_id)
                    self._details[event.details.transfer_id] = _merge_details(previous, event.details)
            elif isinstance(event, e.TorrentConflict):
                self._on_conflict(event.transfer_id, event.other_transfer_id)
            elif isinstance(event, e.TorrentExported):
                self._on_exported(event)
            elif isinstance(event, e.TransferNotice):
                if event.transfer_id in self._records:
                    self._activity(event.transfer_id, event.level, event.kind, event.message)

    def _on_status(self, batch: e.StatusBatch) -> None:
        self._session = batch.session
        queue = self._settings().queue
        for status in batch.statuses:
            record = self._records.get(status.transfer_id)
            if record is None:
                continue
            self._status[status.transfer_id] = status
            if record.preview or record.id in self._removing:
                continue
            state, _ = derive_state(status, manual_paused=record.manual_paused,
                                    stopped_by_limit=record.stopped_by_limit)
            changed = (state is not record.last_state or status.progress_ppm != record.last_progress_ppm
                       or status.all_time_upload != record.uploaded_total)
            record.last_state = state
            record.last_progress_ppm = status.progress_ppm
            # Totals are kept monotonic so that "this transfer has written data" survives a
            # rejected resume file.
            record.downloaded_total = max(record.downloaded_total, status.all_time_download)
            record.uploaded_total = max(record.uploaded_total, status.all_time_upload)
            record.seeding_seconds = status.seeding_seconds
            if status.error and not record.last_error:
                record.last_error = status.error
            if changed:
                self._dirty.add(record.id)
            if state is TransferState.SEEDING and not record.manual_paused:
                reason = seeding_limit_reached(record, status, queue)
                if reason:
                    record.stopped_by_limit = True
                    self._save(record)
                    self._engine.submit(c.PauseTorrent(record.id))
                    self._activity(record.id, "info", "queue", f"Seeding stopped: {reason}.")
        self._bump()

    def _on_added(self, event: e.TorrentAdded) -> None:
        record = self._records.get(event.transfer_id)
        if record is None:
            return
        try:
            if not record.identity.conflicts(event.identity):
                merged = record.identity.merged(event.identity) if record.identity.matches(event.identity) else None
                if merged and merged != record.identity:
                    record.identity = merged
                    self._save(record)
        except Exception:
            pass
        self._bump()

    def _on_add_failed(self, event: e.TorrentAddFailed) -> None:
        record = self._records.get(event.transfer_id)
        if record is None:
            return
        record.last_error = event.message
        record.last_state = TransferState.ERROR
        self._save(record)
        self._activity(record.id, "error", "added", event.message)
        self._notify("error", transfer_id=record.id, message=f"“{record.name}”: {event.message}")
        self._bump()

    def _on_metadata(self, event: e.MetadataReceived) -> None:
        record = self._records.get(event.transfer_id)
        if record is None:
            return
        metadata = event.metadata
        if metadata.path_problems:
            record.last_error = ("The metadata received for this magnet was refused because its file list is "
                                 "unsafe: " + "; ".join(metadata.path_problems[:3]))
            record.last_state = TransferState.ERROR
            record.manual_paused = True
            self._save(record)
            self._engine.submit(c.PauseTorrent(record.id))
            self._activity(record.id, "error", "metadata", record.last_error)
            self._notify("error", transfer_id=record.id, message=record.last_error)
            return
        # Metadata can reveal that a v1-only magnet and a v2-only magnet are the same hybrid torrent.
        for other in list(self._records.values()):
            if other.id != record.id and other.id not in self._removing and other.identity.matches(metadata.identity):
                self._on_conflict(record.id, other.id)
                return
        record.identity = metadata.identity
        record.name = metadata.name
        record.total_size = metadata.total_size
        record.private = metadata.private
        record.has_metadata = True
        self._metadata[record.id] = metadata
        if event.torrent_data:
            try:
                self._store.save_torrent(record.id, event.torrent_data)
            except OSError as exc:
                self._activity(record.id, "warning", "metadata", f"Could not store the torrent file: {exc}")
        if not record.preview:
            other = self._conflict(record.save_path, metadata.name, exclude_id=record.id)
            if other is not None:
                record.manual_paused = True
                record.last_error = (f"Stopped: “{metadata.name}” in the destination folder is already used by the "
                                     f"transfer “{other.name}”. Move this transfer to another folder to continue.")
                self._engine.submit(c.PauseTorrent(record.id))
                self._activity(record.id, "error", "metadata", record.last_error)
                self._notify("error", transfer_id=record.id, message=record.last_error)
        self._save(record)
        self._activity(record.id, "info", "metadata",
                       f"Metadata retrieved: {len(metadata.real_files)} file(s), {metadata.total_size:,} bytes, "
                       f"{metadata.identity.kind}{', private' if metadata.private else ''}.")
        self._bump()
        if record.preview:
            self._notify("preview_ready", transfer_id=record.id, name=record.name)

    def _on_conflict(self, transfer_id: str, other_id: str) -> None:
        """Two transfers turned out to be the same torrent: keep the older, drop the newer."""
        a, b = self._records.get(transfer_id), self._records.get(other_id)
        if a is None or b is None:
            return
        newer, older = (a, b) if (a.added_at, a.id) >= (b.added_at, b.id) else (b, a)
        if newer.id in self._removing:
            return
        self._activity(older.id, "info", "duplicate",
                       f"A second transfer for the same torrent (“{newer.name}”) was detected and removed.")
        self._removing[newer.id] = {"name": newer.name, "delete": False}
        self._engine.submit(c.RemoveTorrent(newer.id, delete_files=False))
        self._notify("info", transfer_id=older.id,
                     message=f"“{newer.name}” is the same torrent as “{older.name}”; the duplicate was removed.")

    def _on_error(self, event: e.TorrentErrored) -> None:
        record = self._records.get(event.transfer_id)
        if record is None or record.preview:
            return
        message = event.message
        low = message.lower()
        if "no space" in low:
            message = "The disk is full. Free some space, then start the transfer again."
        elif "permission" in low or "access" in low:
            message = f"Permission denied while writing {event.file or 'to the destination'}."
        elif "no such file" in low and event.file:
            message = f"A file or folder is missing: {event.file}"
        elif event.file:
            message = f"{message} ({event.file})"
        if record.last_error == message:
            return
        record.last_error = message
        self._save(record)
        self._activity(record.id, "error", event.kind, message)
        self._notify("error", transfer_id=record.id, message=f"“{record.name}”: {message}")
        self._bump()

    def _on_moved(self, event: e.StorageMoved) -> None:
        record = self._records.get(event.transfer_id)
        if record is None:
            return
        confirm = self._pending_confirms.pop(record.id, None)
        if confirm is not None:
            record.preview = False
            record.save_path = confirm["save_path"]
            record.file_priorities = confirm["priorities"]
            record.manual_paused = bool(confirm["paused"])
            if confirm.get("category") is not None:
                record.category = confirm["category"]
            # The cached status predates the selection: wait for a fresh one before showing progress.
            self._status.pop(record.id, None)
            record.last_state = TransferState.PAUSED if record.manual_paused else TransferState.QUEUED
            record.last_progress_ppm = 0
            self._save(record)
            self._activity(record.id, "info", "preview", f"Review accepted; destination {record.save_path}")
            self._bump()
            return
        target = self._pending_moves.pop(record.id, None)
        # Persist the destination only now that the engine has confirmed the move.
        record.save_path = event.new_path or target or record.save_path
        if record.last_error and "destination" in record.last_error.lower():
            record.last_error = ""
        self._save(record)
        self._activity(record.id, "info", "move", f"Storage moved to {record.save_path}")
        self._notify("info", transfer_id=record.id, message=f"“{record.name}” was moved to {record.save_path}")
        self._bump()

    def _on_move_failed(self, event: e.StorageMoveFailed) -> None:
        record = self._records.get(event.transfer_id)
        if record is None:
            return
        self._pending_moves.pop(record.id, None)
        was_confirm = self._pending_confirms.pop(record.id, None) is not None
        message = event.message
        if "exist" in message.lower():
            message = f"The destination already contains files with the same names ({message})."
        self._activity(record.id, "error", "move", f"Move failed; files stay in {record.save_path}: {message}")
        self._notify("error", transfer_id=record.id,
                     message=(f"“{record.name}” could not be {'started at' if was_confirm else 'moved to'} the "
                              f"chosen folder: {message}"))
        self._bump()

    def _on_tracker(self, event: e.TrackerAnnounced) -> None:
        record = self._records.get(event.transfer_id)
        if record is None:
            return
        previous_ok = record.last_announce.get("ok")
        record.last_announce = {"url": redact(event.url), "ok": event.ok, "message": event.message[:200],
                                "peers": event.peers, "ts": int(self._clock.now())}
        self._dirty.add(record.id)
        if previous_ok is None or previous_ok != event.ok:
            if event.ok:
                self._activity(record.id, "info", "tracker", f"Announce succeeded: {event.url} ({event.peers} peer(s)).")
            else:
                self._activity(record.id, "warning", "tracker", f"Announce failed: {event.url} — {event.message}")

    def _on_exported(self, event: e.TorrentExported) -> None:
        destination = self._pending_exports.pop(event.transfer_id, None)
        if event.torrent_data and event.transfer_id in self._records:
            try:
                self._store.save_torrent(event.transfer_id, event.torrent_data)
            except OSError:
                pass
        if destination is None:
            return
        if event.torrent_data:
            try:
                atomic_write(destination, event.torrent_data)
                self._notify("export_done", transfer_id=event.transfer_id, path=destination)
            except OSError as exc:
                self._notify("error", transfer_id=event.transfer_id,
                             message=f"The torrent file could not be written: {exc.strerror}")
        else:
            self._notify("error", transfer_id=event.transfer_id, message=event.message)

    # ----------------------------------------------------------- housekeeping
    def tick(self) -> None:
        """Periodic work (call about once a second from a worker thread)."""
        now = self._clock.monotonic()
        with self._lock:
            app = self._settings()
            plan = bandwidth_plan(app.queue, _dt.datetime.fromtimestamp(self._clock.now()))
            if self._plan is None or plan != self._plan:
                previous = self._plan
                self._plan = plan
                self._engine.submit(c.ApplySettings(engine_settings(app, self._secrets, plan=plan,
                                                                    isolated=self._isolated)))
                if previous is None or previous.pause_all != plan.pause_all:
                    self._engine.submit(c.SetSessionPaused(plan.pause_all, plan.schedule_name))
                if previous is not None:
                    log.info("queue: bandwidth plan now %s (down %s, up %s, pause_all=%s)",
                             plan.schedule_name or "default", plan.download_limit, plan.upload_limit, plan.pause_all)
                self._bump()
            if now - self._last_persist >= PERSIST_INTERVAL_S:
                self._last_persist = now
                self._persist_dirty()

    def apply_settings(self) -> None:
        """Push changed application settings to the engine."""
        with self._lock:
            self._plan = None
        self.tick()

    def _persist_dirty(self) -> None:
        for tid in list(self._dirty):
            record = self._records.get(tid)
            if record is not None:
                self._repo.save(record)
        self._dirty.clear()

    def prepare_shutdown(self) -> None:
        with self._lock:
            self._persist_dirty()

    def diagnostics(self) -> dict[str, Any]:
        with self._lock:
            _, views, session = self.snapshot()
            by_state: dict[str, int] = {}
            for v in views:
                by_state[v.state.value] = by_state.get(v.state.value, 0) + 1
            return {
                "engine_running": session.engine_running,
                "listening": session.listening, "listen_port": session.listen_port,
                "dht_enabled": session.dht_enabled, "dht_nodes": session.dht_nodes,
                "incoming_connections_seen": session.has_incoming,
                "session_paused": session.paused, "schedule": session.schedule,
                "fault": session.fault, "port_mapping": session.port_mapping,
                "transfers_by_state": by_state,
                "transfers": [{"id": v.id[:8], "state": v.state.value, "detail": v.state_detail,
                               "kind": v.identity.kind, "private": v.private, "progress_ppm": v.progress_ppm,
                               "peers": v.peers, "error": v.error,
                               "last_announce": v.last_announce} for v in views[:200]],
                "startup_notes": list(self.startup_notes),
                "shutdown_report": (None if self.shutdown_report is None else
                                    {"clean": self.shutdown_report.clean, "saved": self.shutdown_report.resume_saved,
                                     "unsaved": len(self.shutdown_report.resume_unsaved),
                                     "message": self.shutdown_report.message}),
            }


def _had_data(record: TransferRecord) -> bool:
    """True when this transfer has (had) payload on disk at its destination."""
    return record.has_metadata and (record.downloaded_total > 0 or record.completed_at is not None
                                    or record.last_progress_ppm > 0)


def _merge_details(previous: TransferDetails | None, new: TransferDetails) -> TransferDetails:
    """Keep the parts of the previous snapshot that the new one did not refresh."""
    if previous is None:
        return new
    return TransferDetails(
        transfer_id=new.transfer_id,
        peers=new.peers if new.peers or not previous.peers else new.peers,
        trackers=new.trackers or previous.trackers,
        files=new.files or previous.files,
        pieces=new.pieces or previous.pieces,
        web_seeds=new.web_seeds or previous.web_seeds,
    )
