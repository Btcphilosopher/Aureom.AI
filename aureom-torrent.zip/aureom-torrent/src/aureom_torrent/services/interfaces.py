"""Narrow protocols that subsystems use to talk to each other.

The RSS and publishing services depend on :class:`TransferGateway` rather than
on the concrete transfer service, so they can be tested against a fake – and so
it is structurally impossible for a feed rule to reach the payment service
(nothing in ``feeds`` imports ``payments``; a unit test enforces this).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from ..domain.identity import TorrentIdentity
from ..domain.transfers import TorrentMetadata, TransferRecord


class AddRejected(Exception):
    """An add request that was refused. ``str(exc)`` is safe to show to the user."""

    def __init__(self, message: str, *, reason: str = "invalid"):
        super().__init__(message)
        self.reason = reason  # invalid | duplicate | conflict | destination | unsafe_paths


@dataclass(frozen=True, slots=True)
class AddOutcome:
    transfer_id: str
    created: bool  # False when an existing transfer was reused (duplicate)
    duplicate_of: str | None = None
    message: str = ""


class TransferGateway(Protocol):
    def inspect_torrent(self, torrent_data: bytes) -> TorrentMetadata:
        """Parse .torrent bytes (raises ``engine.interface.TorrentFormatError``)."""

    def find_duplicate(self, identity: TorrentIdentity) -> TransferRecord | None: ...

    def add_torrent_data(self, torrent_data: bytes, *, save_path: str, category: str = "",
                         paused: bool = False, file_priorities: list[int] | None = None,
                         source: str = "file", feed_entry_id: int | None = None,
                         manifest_id: str | None = None) -> AddOutcome:
        """Add a transfer from .torrent bytes.

        Returns an outcome with ``created=False`` when an equivalent transfer
        already exists (the existing transfer is left untouched: its pause
        state, priorities and destination are *not* modified).  Raises
        :class:`AddRejected` for invalid data, unsafe paths, an unusable
        destination, or a destination conflict with a different transfer.
        """

    def add_magnet(self, uri: str, *, save_path: str, category: str = "", paused: bool = False,
                   preview: bool = False, source: str = "magnet",
                   feed_entry_id: int | None = None) -> AddOutcome:
        """Add a transfer from a magnet link (same duplicate/rejection rules).

        With ``preview=True`` only metadata is retrieved; the user confirms
        files and destination later.
        """

    def default_save_path(self) -> str: ...
