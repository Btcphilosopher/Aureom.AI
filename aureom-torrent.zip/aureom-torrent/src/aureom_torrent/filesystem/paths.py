"""Path validation, safe resolution, atomic writes and publish-folder scanning.

Nothing here ever opens or executes downloaded content.
"""

from __future__ import annotations

import os
import shutil
import stat
import tempfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

MAX_COMPONENT_BYTES = 255
MAX_PATH_BYTES = 4096

_RESERVED = {"CON", "PRN", "AUX", "NUL", "CLOCK$", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}
_ILLEGAL_WINDOWS = set('<>:"|?*')
JUNK_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini", ".Spotlight-V100", ".Trashes", "ehthumbs.db"}


class UnsafePathError(ValueError):
    """A path that must not be used. The message is safe to show to the user."""


def relative_path_problems(path: str) -> list[str]:
    """Explain why a torrent-relative path is unsafe on at least one supported platform.

    An empty list means the path is acceptable everywhere.
    """
    problems: list[str] = []
    if not path:
        return ["empty path"]
    if "\x00" in path or any(ord(c) < 32 for c in path):
        problems.append("contains control characters")
    if len(path.encode("utf-8", "surrogatepass")) > MAX_PATH_BYTES:
        problems.append("path is too long")
    normalised = path.replace("\\", "/")
    if normalised.startswith("/") or (len(path) > 1 and path[1] == ":"):
        problems.append("absolute path")
    for part in normalised.split("/"):
        if part == "":
            problems.append("empty path component")
        elif part == "..":
            problems.append("parent-directory traversal")
        elif part == ".":
            problems.append("current-directory component")
        else:
            if len(part.encode("utf-8", "surrogatepass")) > MAX_COMPONENT_BYTES:
                problems.append("name is too long")
            stem = part.split(".")[0].strip().upper()
            if stem in _RESERVED:
                problems.append(f"reserved name “{part}” (Windows)")
            if part.endswith((" ", ".")):
                problems.append(f"name “{part}” ends with a dot or space (Windows)")
            if _ILLEGAL_WINDOWS.intersection(part):
                problems.append(f"name “{part}” has characters Windows forbids")
    # de-duplicate, keep order
    return list(dict.fromkeys(problems))


def is_fatal_problem(problem: str) -> bool:
    """Traversal/absolute/control problems are never acceptable; Windows-only naming problems
    are fatal only on Windows (the engine sanitises names there)."""
    if "(Windows)" in problem or "Windows forbids" in problem:
        return os.name == "nt"
    return True


def resolve_inside(root: str | os.PathLike[str], relative: str) -> Path:
    """Join ``relative`` under ``root`` and prove the result stays inside ``root``.

    Existing symlinks on the way are resolved, so a link that points out of the
    root is rejected.
    """
    fatal = [p for p in relative_path_problems(relative) if is_fatal_problem(p)]
    if fatal:
        raise UnsafePathError(f"Unsafe path “{relative}”: {', '.join(fatal)}")
    root_real = Path(os.path.realpath(root))
    candidate = Path(os.path.realpath(root_real.joinpath(*PurePosixPath(relative.replace("\\", "/")).parts)))
    if candidate != root_real and root_real not in candidate.parents:
        raise UnsafePathError(f"“{relative}” resolves outside “{root_real}”")
    return candidate


def owned_paths(save_path: str, files: list[str]) -> list[Path]:
    """Validate every torrent file path for a delete operation.

    Raises :class:`UnsafePathError` if any file would resolve outside the
    transfer's save path, so a deletion is refused as a whole rather than
    partially applied to paths the transfer does not own.
    """
    if not save_path or not os.path.isabs(save_path):
        raise UnsafePathError("The transfer has no absolute destination; nothing will be deleted.")
    root = Path(os.path.realpath(save_path))
    if root == Path(root.anchor):
        raise UnsafePathError("Refusing to delete from a filesystem root.")
    return [resolve_inside(root, f) for f in files]


@dataclass(frozen=True, slots=True)
class DestinationReport:
    path: str
    exists: bool
    writable: bool
    free_bytes: int | None
    problems: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.problems


def check_destination(path: str, required_bytes: int = 0) -> DestinationReport:
    """Check that ``path`` can receive ``required_bytes`` of new data.

    The directory is not created here; the nearest existing ancestor is checked
    for write permission and free space.
    """
    problems: list[str] = []
    if not path or not os.path.isabs(path):
        return DestinationReport(path, False, False, None, ("Choose an absolute destination folder.",))
    p = Path(path)
    exists = p.exists()
    if exists and not p.is_dir():
        return DestinationReport(path, True, False, None, ("The destination is a file, not a folder.",))
    probe = p
    while not probe.exists() and probe != probe.parent:
        probe = probe.parent
    writable = os.access(probe, os.W_OK | os.X_OK)
    if not writable:
        problems.append(f"No permission to write to “{probe}”.")
    free: int | None
    try:
        free = shutil.disk_usage(probe).free
    except OSError:
        free = None
    if free is not None and required_bytes > free:
        problems.append(
            f"Not enough free space: {required_bytes:,} bytes needed, {free:,} bytes available."
        )
    return DestinationReport(path, exists, writable, free, tuple(problems))


def atomic_write(path: str | os.PathLike[str], data: bytes) -> None:
    """Write ``data`` so that readers see either the old or the new file, never a torn one."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


@dataclass(frozen=True, slots=True)
class ScannedFile:
    relative: str  # forward slashes, relative to the scan root's parent-less base
    size: int
    mtime: int


@dataclass(slots=True)
class ScanResult:
    root: str
    is_single_file: bool
    files: list[ScannedFile] = field(default_factory=list)
    skipped: list[tuple[str, str]] = field(default_factory=list)  # (relative, reason)
    truncated: bool = False

    @property
    def total_size(self) -> int:
        return sum(f.size for f in self.files)


def scan_for_publish(root: str, *, max_files: int = 200_000, skip_junk: bool = True,
                     cancelled=lambda: False) -> ScanResult:
    """List the regular files under ``root`` for torrent creation.

    * Symbolic links are never followed. Links are reported as skipped, with a
      distinct reason when they point outside the selected root.
    * Special files (sockets, devices, FIFOs) and unreadable entries are skipped
      and reported.
    * OS junk files are skipped (and reported) unless ``skip_junk`` is False.
    """
    root_path = Path(root)
    if root_path.is_symlink():
        raise UnsafePathError("The selected item is a symbolic link; choose the real file or folder.")
    if not root_path.exists():
        raise UnsafePathError("The selected file or folder does not exist.")
    result = ScanResult(root=str(root_path), is_single_file=root_path.is_file())
    if root_path.is_file():
        st = root_path.stat()
        result.files.append(ScannedFile(root_path.name, st.st_size, int(st.st_mtime)))
        return result
    root_real = Path(os.path.realpath(root_path))

    stack = [root_path]
    while stack:
        if cancelled():
            result.truncated = True
            break
        current = stack.pop()
        try:
            entries = sorted(os.scandir(current), key=lambda e: e.name)
        except OSError as exc:
            result.skipped.append((_rel(current, root_path), f"cannot read folder: {exc.strerror}"))
            continue
        for entry in entries:
            rel = _rel(Path(entry.path), root_path)
            try:
                if entry.is_symlink():
                    target = Path(os.path.realpath(entry.path))
                    outside = target != root_real and root_real not in target.parents
                    result.skipped.append(
                        (rel, "symbolic link pointing outside the selected folder" if outside
                         else "symbolic link (links are not followed)"))
                    continue
                st = entry.stat(follow_symlinks=False)
            except OSError as exc:
                result.skipped.append((rel, f"cannot read: {exc.strerror}"))
                continue
            if stat.S_ISDIR(st.st_mode):
                stack.append(Path(entry.path))
            elif stat.S_ISREG(st.st_mode):
                if skip_junk and entry.name in JUNK_NAMES:
                    result.skipped.append((rel, "operating-system metadata file"))
                    continue
                if not os.access(entry.path, os.R_OK):
                    result.skipped.append((rel, "no permission to read"))
                    continue
                problems = [p for p in relative_path_problems(rel) if is_fatal_problem(p)]
                if problems:
                    result.skipped.append((rel, "unsafe name: " + ", ".join(problems)))
                    continue
                if len(result.files) >= max_files:
                    result.truncated = True
                    return result
                result.files.append(ScannedFile(rel, st.st_size, int(st.st_mtime)))
            else:
                result.skipped.append((rel, "not a regular file"))
    result.files.sort(key=lambda f: f.relative)
    return result


def _rel(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix() if path != root else "."
