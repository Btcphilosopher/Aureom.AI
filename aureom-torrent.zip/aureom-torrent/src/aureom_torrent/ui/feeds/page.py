"""RSS / Atom reader: subscriptions, entry browser, sanitised content and opt-in automation."""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QSplitter,
                               QTextBrowser, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from ...feeds.models import FeedRule
from ..format import format_size, format_time
from ..models.rows import ROW_ROLE, Column, RowsModel
from ..transfers.dialogs import DestinationRow, category_combo, muted, note
from ..transfers.page import _SortProxy, make_table

STATUS_LABELS = {"new": "New", "baseline": "Earlier item", "added": "Added", "duplicate": "Already in transfers",
                 "review": "Needs review", "dismissed": "Dismissed"}
LINK_LABELS = {"torrent": ".torrent", "magnet": "Magnet", "none": "—"}


class SafeTextBrowser(QTextBrowser):
    """Renders already-sanitised entry markup. Never loads remote resources, never follows links."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setAccessibleName("Entry content")

    def loadResource(self, kind, name):  # noqa: N802 - Qt override
        return None  # no images, style sheets or other resources – local or remote


class AddFeedDialog(QDialog):
    def __init__(self, folders: list[str], categories: list[str], default_interval: int, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Subscribe to a feed")
        self.resize(560, 320)
        form = QFormLayout(self)
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://example.org/releases.xml")
        form.addRow("Feed &address:", self.url)
        self.title = QLineEdit()
        self.title.setPlaceholderText("(taken from the feed)")
        form.addRow("&Title:", self.title)
        self.folder = QComboBox()
        self.folder.setEditable(True)
        self.folder.addItem("")
        self.folder.addItems(folders)
        form.addRow("&Folder:", self.folder)
        self.category = category_combo(categories)
        form.addRow("&Category for transfers:", self.category)
        self.interval = QSpinBox()
        self.interval.setRange(5, 10_080)
        self.interval.setSuffix(" min")
        self.interval.setValue(default_interval)
        form.addRow("&Refresh every:", self.interval)
        form.addRow(note("Entries that already exist when you subscribe are recorded as a baseline and are never "
                         "downloaded automatically. A feed served over HTTPS is not thereby trustworthy: review "
                         "what a feed offers before adding transfers from it."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Subscribe")
        buttons.button(QDialogButtonBox.StandardButton.Ok).setProperty("role", "primary")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def values(self) -> dict:
        return {"url": self.url.text().strip(), "title": self.title.text().strip(),
                "folder": self.folder.currentText().strip(), "category": self.category.currentText().strip(),
                "interval_minutes": self.interval.value()}


class RuleEditor(QDialog):
    def __init__(self, rule: FeedRule, categories: list[str], default_destination: str, parent=None):
        super().__init__(parent)
        self.rule = rule
        self.setWindowTitle("Automatic download rule")
        self.resize(560, 520)
        form = QFormLayout(self)
        self.name = QLineEdit(rule.name)
        form.addRow("&Name:", self.name)
        self.enabled = QCheckBox("Rule is enabled")
        self.enabled.setChecked(rule.enabled)
        form.addRow("", self.enabled)
        self.include = QLineEdit(", ".join(rule.include))
        self.include.setPlaceholderText("all of these words must appear in the title (comma separated)")
        form.addRow("&Include:", self.include)
        self.exclude = QLineEdit(", ".join(rule.exclude))
        self.exclude.setPlaceholderText("none of these words may appear")
        form.addRow("&Exclude:", self.exclude)
        self.regex = QLineEdit(rule.regex)
        self.regex.setPlaceholderText("optional regular expression (evaluated with a time limit)")
        form.addRow("&Pattern:", self.regex)
        self.category = category_combo(categories, rule.category)
        form.addRow("&Category:", self.category)
        self.destination = DestinationRow(rule.destination or default_destination)
        form.addRow("&Destination:", self.destination)
        self.min_size = QSpinBox()
        self.max_size = QSpinBox()
        for box, value in ((self.min_size, rule.min_size), (self.max_size, rule.max_size)):
            box.setRange(0, 10_000_000)
            box.setSuffix(" MiB")
            box.setSpecialValueText("No limit")
            box.setValue((value or 0) // (1024 * 1024))
        form.addRow("M&inimum size:", self.min_size)
        form.addRow("Ma&ximum size:", self.max_size)
        self.per_refresh = QSpinBox()
        self.per_refresh.setRange(0, 100)
        self.per_refresh.setSpecialValueText("No limit")
        self.per_refresh.setValue(rule.max_per_refresh)
        form.addRow("Additions per &refresh:", self.per_refresh)
        self.daily = QSpinBox()
        self.daily.setRange(0, 1000)
        self.daily.setSpecialValueText("No limit")
        self.daily.setValue(rule.daily_count_budget)
        form.addRow("Additions per da&y:", self.daily)
        self.daily_bytes = QSpinBox()
        self.daily_bytes.setRange(0, 10_000_000)
        self.daily_bytes.setSuffix(" MiB")
        self.daily_bytes.setSpecialValueText("No limit")
        self.daily_bytes.setValue(rule.daily_bytes_budget // (1024 * 1024))
        form.addRow("Download &budget per day:", self.daily_bytes)
        self.paused = QCheckBox("Add matching transfers paused")
        self.paused.setChecked(rule.add_paused)
        form.addRow("", self.paused)
        form.addRow(muted("Sizes reported by a feed are not trusted. When a size limit applies, the torrent's own "
                          "metadata is checked; if the size cannot be established the item is queued for your "
                          "review instead of being added. Rules never make payments."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def result_rule(self) -> FeedRule:
        split = lambda text: [t.strip() for t in text.split(",") if t.strip()]  # noqa: E731
        mib = 1024 * 1024
        r = self.rule
        return FeedRule(id=r.id, feed_id=r.feed_id, name=self.name.text().strip() or "Rule",
                        enabled=self.enabled.isChecked(), include=split(self.include.text()),
                        exclude=split(self.exclude.text()), regex=self.regex.text().strip(),
                        category=self.category.currentText().strip(), destination=self.destination.path(),
                        min_size=self.min_size.value() * mib or None, max_size=self.max_size.value() * mib or None,
                        max_per_refresh=self.per_refresh.value(), daily_count_budget=self.daily.value(),
                        daily_bytes_budget=self.daily_bytes.value() * mib, add_paused=self.paused.isChecked(),
                        created_at=r.created_at)


class RulesDialog(QDialog):
    """Per-feed automation: explicit opt-in, rule list, and a dry run that changes nothing."""

    def __init__(self, ctx, bridge, feed, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge, self.feed = ctx, bridge, feed
        self.setWindowTitle(f"Automatic downloads — {feed.display_title}")
        self.resize(760, 560)
        layout = QVBoxLayout(self)
        self.opt_in = QCheckBox("&Allow this feed to add transfers automatically using the rules below")
        self.opt_in.setChecked(feed.auto_download)
        self.opt_in.toggled.connect(self._toggle)
        layout.addWidget(self.opt_in)
        layout.addWidget(note("Automatic downloading is off unless you enable it here, for this feed. Only entries "
                              "that appear after you enable it are considered; anything a rule cannot evaluate "
                              "safely is placed in “Needs review”. Rules can add transfers only — they can never "
                              "send a payment."))
        self.rules = QListWidget()
        self.rules.setAccessibleName("Rules")
        layout.addWidget(self.rules, 1)
        row = QHBoxLayout()
        for text, slot in (("&New rule…", self._new), ("&Edit…", self._edit), ("&Delete", self._delete),
                           ("Dry &run", self._dry_run)):
            button = QPushButton(text)
            button.clicked.connect(slot)
            row.addWidget(button)
        row.addStretch(1)
        layout.addLayout(row)
        self.preview_model = RowsModel([
            Column("Entry", lambda r: r.entry.title),
            Column("Decision", lambda r: {"add": "Would add", "skip": "Skip", "review": "Needs review",
                                           "duplicate": "Already known"}.get(r.decision, r.decision)),
            Column("Reason", lambda r: r.reason),
        ], key=lambda r: r.entry.id, parent=self)
        self.preview = make_table(self.preview_model, sortable=False)
        self.preview.setAccessibleName("Dry run result")
        self.preview.setColumnWidth(0, 300)
        self.preview.setColumnWidth(1, 120)
        layout.addWidget(muted("Dry run: what the selected rule would decide for the entries currently in this "
                               "feed. Nothing is fetched or added."))
        layout.addWidget(self.preview, 1)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(self.reject)
        close.accepted.connect(self.accept)
        layout.addWidget(close)
        self._rules: list[FeedRule] = []
        self._load()

    def _error(self, exc) -> None:
        QMessageBox.warning(self, self.windowTitle(), str(exc))

    def _toggle(self, on: bool) -> None:
        self.bridge.run(lambda: self.ctx.feeds.set_auto_download(self.feed.id, on), None, self._error)

    def _load(self) -> None:
        def done(rules) -> None:
            self._rules = rules
            self.rules.clear()
            for rule in rules:
                parts = []
                if rule.include:
                    parts.append("include: " + ", ".join(rule.include))
                if rule.exclude:
                    parts.append("exclude: " + ", ".join(rule.exclude))
                if rule.regex:
                    parts.append("pattern")
                text = f"{rule.name}{'' if rule.enabled else ' (disabled)'} — {'; '.join(parts) or 'matches every entry'}"
                self.rules.addItem(QListWidgetItem(text))
            if rules:
                self.rules.setCurrentRow(0)

        self.bridge.run(lambda: self.ctx.feeds.list_rules(self.feed.id), done, self._error)

    def _current(self) -> FeedRule | None:
        row = self.rules.currentRow()
        return self._rules[row] if 0 <= row < len(self._rules) else None

    def _edit_rule(self, rule: FeedRule) -> None:
        general = self.ctx.settings.get().general
        editor = RuleEditor(rule, list(general.categories), self.ctx.transfers.default_save_path(), self)
        if editor.exec():
            new_rule = editor.result_rule()
            self.bridge.run(lambda: self.ctx.feeds.save_rule(new_rule), lambda _: self._load(), self._error)

    def _new(self) -> None:
        self._edit_rule(FeedRule(feed_id=self.feed.id, name="New rule", category=self.feed.category))

    def _edit(self) -> None:
        rule = self._current()
        if rule:
            self._edit_rule(rule)

    def _delete(self) -> None:
        rule = self._current()
        if rule and rule.id is not None:
            self.bridge.run(lambda: self.ctx.feeds.delete_rule(rule.id), lambda _: self._load(), self._error)

    def _dry_run(self) -> None:
        rule = self._current()
        if rule:
            self.bridge.run(lambda: self.ctx.feeds.preview_rule(rule), self.preview_model.set_rows, self._error)


class FeedsPage(QWidget):
    message = Signal(str, str)
    add_magnet_requested = Signal(str)

    def __init__(self, ctx, bridge, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge = ctx, bridge
        self._feeds = []
        self._busy = False
        self._selection: tuple[str, object] = ("all", None)

        # subscriptions
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setAccessibleName("Subscriptions")
        self.tree.setIndentation(14)
        self.tree.currentItemChanged.connect(self._on_tree)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        heading = QLabel("Subscriptions")
        heading.setProperty("role", "subheading")
        left_layout.addWidget(heading)
        left_layout.addWidget(self.tree, 1)
        row1 = QHBoxLayout()
        row2 = QHBoxLayout()
        for layout, items in ((row1, (("&Subscribe…", self.add_feed), ("&Refresh", self.refresh_selected),
                                      ("Re&move", self.remove_feed))),
                              (row2, (("R&ules…", self.edit_rules), ("&Import OPML…", self.import_opml),
                                      ("E&xport OPML…", self.export_opml)))):
            for text, slot in items:
                button = QPushButton(text)
                button.clicked.connect(slot)
                layout.addWidget(button)
        left_layout.addLayout(row1)
        left_layout.addLayout(row2)
        self.feed_status = muted("")
        left_layout.addWidget(self.feed_status)

        # entries
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search entries")
        self.search.setClearButtonEnabled(True)
        self.search.setAccessibleName("Search entries")
        self.unread_only = QCheckBox("&Unread only")
        self.link_filter = QComboBox()
        self.link_filter.addItem("All link types", None)
        self.link_filter.addItem(".torrent enclosures", "torrent")
        self.link_filter.addItem("Magnet links", "magnet")
        self.link_filter.setAccessibleName("Link type filter")
        self.status_filter = QComboBox()
        self.status_filter.addItem("All entries", None)
        self.status_filter.addItem("Needs review", "review")
        self.status_filter.addItem("Added", "added")
        self.status_filter.setAccessibleName("Status filter")
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(250)
        self._search_timer.timeout.connect(self.reload_entries)
        self.search.textChanged.connect(lambda _: self._search_timer.start())
        self.unread_only.toggled.connect(lambda _: self.reload_entries())
        self.link_filter.currentIndexChanged.connect(lambda _: self.reload_entries())
        self.status_filter.currentIndexChanged.connect(lambda _: self.reload_entries())
        filters = QHBoxLayout()
        filters.addWidget(self.search, 1)
        filters.addWidget(self.unread_only)
        filters.addWidget(self.link_filter)
        filters.addWidget(self.status_filter)

        self.entries_model = RowsModel([
            Column("Title", lambda e: ("● " if not e.read else "") + e.title, lambda e: e.title.casefold(),
                   tooltip=lambda e: e.title),
            Column("Publisher", lambda e: e.publisher or e.feed_title),
            Column("Published", lambda e: format_time(e.published), lambda e: e.published or 0),
            Column("Size", lambda e: "—" if e.size is None else
                   f"{format_size(e.size)}{'' if e.size_trusted else ' *'}", lambda e: e.size or 0, True,
                   tooltip=lambda e: f"Size {e.size_label}" + ("" if e.size_trusted or e.size is None else
                                                               " — not verified; a feed can state any size")),
            Column("Link", lambda e: LINK_LABELS.get(e.link_type, e.link_type)),
            Column("State", lambda e: ("Unread · " if not e.read else "") + STATUS_LABELS.get(e.status, e.status),
                   tooltip=lambda e: e.status_reason or STATUS_LABELS.get(e.status, e.status)),
        ], key=lambda e: e.id, parent=self)
        proxy = _SortProxy(self)
        proxy.setSourceModel(self.entries_model)
        self.entries = make_table(proxy)
        self.entries.setAccessibleName("Feed entries")
        self.entries.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.entries.sortByColumn(2, Qt.SortOrder.DescendingOrder)
        for column, width in enumerate((300, 150, 126, 96, 74, 150)):
            self.entries.setColumnWidth(column, width)
        self.entries.selectionModel().selectionChanged.connect(lambda *_: self._show_entry())
        self.entries.doubleClicked.connect(lambda _: self.add_transfer())

        self.content = SafeTextBrowser()
        self.entry_meta = muted("")
        actions = QHBoxLayout()
        self.add_button = QPushButton("&Add Transfer…")
        self.add_button.setProperty("role", "primary")
        self.add_button.clicked.connect(self.add_transfer)
        self.read_button = QPushButton("Mark &read")
        self.read_button.clicked.connect(lambda: self._mark(True))
        self.unread_button = QPushButton("Mark u&nread")
        self.unread_button.clicked.connect(lambda: self._mark(False))
        self.copy_button = QPushButton("&Copy link")
        self.copy_button.clicked.connect(self._copy_link)
        self.approve_button = QPushButton("A&pprove (add)")
        self.approve_button.clicked.connect(self._approve)
        self.dismiss_button = QPushButton("&Dismiss")
        self.dismiss_button.clicked.connect(self._dismiss)
        for button in (self.add_button, self.approve_button, self.dismiss_button, self.read_button,
                       self.unread_button, self.copy_button):
            actions.addWidget(button)
        actions.addStretch(1)
        self.size_note = muted("* size as stated by the feed (not verified)")
        actions.addWidget(self.size_note)

        lower = QWidget()
        lower_layout = QVBoxLayout(lower)
        lower_layout.setContentsMargins(0, 0, 0, 0)
        lower_layout.addWidget(self.entry_meta)
        lower_layout.addWidget(self.content, 1)
        lower_layout.addLayout(actions)
        right_split = QSplitter(Qt.Orientation.Vertical)
        right_split.addWidget(self.entries)
        right_split.addWidget(lower)
        right_split.setStretchFactor(0, 3)
        right_split.setStretchFactor(1, 2)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.addLayout(filters)
        right_layout.addWidget(right_split, 1)

        split = QSplitter(Qt.Orientation.Horizontal)
        split.addWidget(left)
        split.addWidget(right)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([290, 830])
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 8)
        layout.addWidget(split)

        self._timer = QTimer(self)
        self._timer.setInterval(15_000)
        self._timer.timeout.connect(self.reload)
        self._show_entry()

    # ------------------------------------------------------------- loading
    def activate(self) -> None:
        self.reload()
        self._timer.start()

    def hideEvent(self, event) -> None:
        self._timer.stop()
        super().hideEvent(event)

    def _error(self, exc) -> None:
        self._busy = False
        self.message.emit("error", str(exc))

    def reload(self) -> None:
        self.bridge.run(self.ctx.feeds.list_feeds, self._apply_feeds, self._error)

    def _apply_feeds(self, feeds) -> None:
        self._feeds = feeds
        selection = self._selection
        self.tree.blockSignals(True)
        self.tree.clear()
        total_unread = sum(f.unread_count for f in feeds)
        review = sum(f.review_count for f in feeds)
        all_item = QTreeWidgetItem([f"All feeds   {total_unread}" if total_unread else "All feeds"])
        all_item.setData(0, Qt.ItemDataRole.UserRole, ("all", None))
        self.tree.addTopLevelItem(all_item)
        review_item = QTreeWidgetItem([f"Needs review   {review}" if review else "Needs review"])
        review_item.setData(0, Qt.ItemDataRole.UserRole, ("review", None))
        self.tree.addTopLevelItem(review_item)
        folders: dict[str, QTreeWidgetItem] = {}
        to_select = all_item
        for feed in sorted(feeds, key=lambda f: (f.folder.casefold(), f.display_title.casefold())):
            parent = None
            if feed.folder:
                parent = folders.get(feed.folder)
                if parent is None:
                    parent = QTreeWidgetItem([feed.folder])
                    parent.setData(0, Qt.ItemDataRole.UserRole, ("folder", feed.folder))
                    self.tree.addTopLevelItem(parent)
                    parent.setExpanded(True)
                    folders[feed.folder] = parent
            label = feed.display_title + (f"   {feed.unread_count}" if feed.unread_count else "")
            if feed.last_status == "error":
                label += "   (error)"
            item = QTreeWidgetItem([label])
            item.setData(0, Qt.ItemDataRole.UserRole, ("feed", feed.id))
            item.setToolTip(0, feed.last_error or feed.display_title)
            (parent.addChild(item) if parent else self.tree.addTopLevelItem(item))
            if selection == ("feed", feed.id):
                to_select = item
        if selection[0] == "review":
            to_select = review_item
        elif selection[0] == "folder" and selection[1] in folders:
            to_select = folders[selection[1]]
        self.tree.setCurrentItem(to_select)
        self.tree.blockSignals(False)
        self._update_feed_status()
        self.reload_entries()

    def _on_tree(self, item, _previous=None) -> None:
        if item is None:
            return
        self._selection = item.data(0, Qt.ItemDataRole.UserRole) or ("all", None)
        self._update_feed_status()
        self.reload_entries()

    def current_feed(self):
        kind, value = self._selection
        if kind != "feed":
            return None
        return next((f for f in self._feeds if f.id == value), None)

    def _update_feed_status(self) -> None:
        feed = self.current_feed()
        if feed is None:
            self.feed_status.setText(f"{len(self._feeds)} subscription(s)")
            return
        lines = [f"Last checked: {format_time(feed.last_checked)} ({feed.last_status.replace('_', ' ')})",
                 f"Next check: {format_time(feed.next_check)}",
                 "Automatic downloads: " + ("on" if feed.auto_download else "off")]
        if feed.last_error:
            lines.append(f"Error: {feed.last_error}")
        self.feed_status.setText("\n".join(lines))

    def reload_entries(self) -> None:
        kind, value = self._selection
        kwargs = dict(unread_only=self.unread_only.isChecked(), search=self.search.text().strip(),
                      link_type=self.link_filter.currentData(), status=self.status_filter.currentData(), limit=500)
        if kind == "feed":
            kwargs["feed_id"] = value
        elif kind == "folder":
            kwargs["folder"] = value
        elif kind == "review":
            kwargs["status"] = "review"
        self.bridge.run(lambda: self.ctx.feeds.list_entries(**kwargs), self._apply_entries, self._error)

    def _apply_entries(self, entries) -> None:
        self.entries_model.set_rows(entries)
        self._show_entry()

    def selected_entries(self) -> list:
        return [index.data(ROW_ROLE) for index in self.entries.selectionModel().selectedRows()]

    def _show_entry(self) -> None:
        entries = self.selected_entries()
        entry = entries[0] if entries else None
        has = entry is not None
        self.add_button.setEnabled(has and entry.can_add and entry.status not in ("added", "duplicate"))
        review = has and entry.status == "review"
        self.approve_button.setVisible(review)
        self.dismiss_button.setVisible(review)
        for button in (self.read_button, self.unread_button, self.copy_button):
            button.setEnabled(has)
        if not has:
            self.entry_meta.setText("Select an entry to read it.")
            self.content.setHtml("")
            return
        meta = [entry.feed_title, format_time(entry.published), LINK_LABELS.get(entry.link_type, "")]
        if entry.size is not None:
            meta.append(f"{format_size(entry.size)} ({entry.size_label})")
        if entry.status_reason:
            meta.append(entry.status_reason)
        self.entry_meta.setText(" · ".join(m for m in meta if m and m != "—"))
        # summary_html was sanitised when the feed was parsed (small tag allow-list, no images/scripts).
        self.content.setHtml(f"<h3>{_escape(entry.title)}</h3>{entry.summary_html}")

    # --------------------------------------------------------------- actions
    def add_feed(self) -> None:
        settings = self.ctx.settings.get()
        dialog = AddFeedDialog(sorted({f.folder for f in self._feeds if f.folder}),
                               list(settings.general.categories), settings.feeds.default_interval_minutes, self)
        if not dialog.exec():
            return
        values = dialog.values()
        url = values.pop("url")
        if not url:
            return

        def work():
            feed = self.ctx.feeds.add_feed(url, **values)
            return feed, self.ctx.feeds.refresh_feed(feed.id, manual=True)

        def done(result) -> None:
            feed, refresh = result
            self._selection = ("feed", feed.id)
            if refresh.ok:
                self.message.emit("info", f"Subscribed. {refresh.new_entries} existing entr"
                                          f"{'y was' if refresh.new_entries == 1 else 'ies were'} recorded as the "
                                          "baseline (not downloaded).")
            else:
                self.message.emit("error", f"Subscribed, but the first refresh failed: {refresh.error}")
            self.reload()

        self.bridge.run(work, done, self._error)

    def refresh_selected(self) -> None:
        if not self.isVisible():
            return
        feed = self.current_feed()
        targets = [feed] if feed else list(self._feeds)
        if not targets:
            return

        def work():
            return [self.ctx.feeds.refresh_feed(f.id, manual=True) for f in targets[:25]]

        def done(results) -> None:
            failed = [r for r in results if not r.ok]
            new = sum(r.new_entries for r in results)
            added = sum(r.auto_added for r in results)
            review = sum(r.queued_for_review for r in results)
            text = f"Refreshed {len(results)} feed(s): {new} new entr{'y' if new == 1 else 'ies'}"
            if added:
                text += f", {added} added by rules"
            if review:
                text += f", {review} queued for review"
            if failed:
                text += f". {len(failed)} failed: {failed[0].error}"
            self.message.emit("error" if failed else "info", text + ".")
            self.reload()

        self.message.emit("info", "Refreshing…")
        self.bridge.run(work, done, self._error)

    def remove_feed(self) -> None:
        feed = self.current_feed()
        if feed is None:
            return
        if QMessageBox.question(self, "Remove subscription",
                                f"Remove “{feed.display_title}” and its entries? Transfers already added from it "
                                "are not affected.") == QMessageBox.StandardButton.Yes:
            self._selection = ("all", None)
            self.bridge.run(lambda: self.ctx.feeds.remove_feed(feed.id), lambda _: self.reload(), self._error)

    def edit_rules(self) -> None:
        feed = self.current_feed()
        if feed is None:
            self.message.emit("info", "Select a single feed to edit its automatic download rules.")
            return
        RulesDialog(self.ctx, self.bridge, feed, self).exec()
        self.reload()

    def import_opml(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import OPML", "", "OPML files (*.opml *.xml);;All files (*)")
        if not path:
            return

        def work():
            with open(path, "rb") as fh:
                data = fh.read(2 * 1024 * 1024 + 1)
            return self.ctx.feeds.import_opml(data)

        def done(result) -> None:
            self.message.emit("info", f"Imported {result.added} subscription(s); {result.skipped_existing} already "
                                      f"present, {result.invalid} not usable. Their existing entries are treated "
                                      "as a baseline.")
            self.reload()

        self.bridge.run(work, done, self._error)

    def export_opml(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export OPML", "aureom-feeds.opml", "OPML files (*.opml)")
        if not path:
            return

        def work():
            text = self.ctx.feeds.export_opml()
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text)
            return path

        self.bridge.run(work, lambda p: self.message.emit("info", f"Subscriptions exported to {p}"), self._error)

    def add_transfer(self) -> None:
        entries = [e for e in self.selected_entries() if e.can_add]
        if not entries:
            return
        entry = entries[0]
        general = self.ctx.settings.get().general
        dialog = QDialog(self)
        dialog.setWindowTitle("Add transfer from feed entry")
        form = QFormLayout(dialog)
        title = QLabel(entry.title)
        title.setWordWrap(True)
        title.setProperty("role", "subheading")
        form.addRow(title)
        destination = DestinationRow(self.ctx.transfers.default_save_path())
        form.addRow("&Destination:", destination)
        feed = next((f for f in self._feeds if f.id == entry.feed_id), None)
        category = category_combo(list(general.categories), feed.category if feed else "")
        form.addRow("&Category:", category)
        paused = QCheckBox("Add &paused")
        paused.setChecked(general.add_paused)
        form.addRow("", paused)
        preview = QCheckBox("Pre&view files first (magnet: retrieves metadata only)")
        preview.setChecked(entry.link_type == "magnet" and general.preview_magnets)
        preview.setEnabled(entry.link_type == "magnet")
        form.addRow("", preview)
        form.addRow(muted("The item comes from a feed. Its title, size and description are the feed's own claims."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Add transfer")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if not dialog.exec():
            return
        kwargs = dict(save_path=destination.path(), category=category.currentText().strip(),
                      paused=paused.isChecked() and not preview.isChecked(), preview=preview.isChecked())

        def done(outcome) -> None:
            self.message.emit("info", "Transfer added." if outcome.created else
                              (outcome.message or "This item is already in your transfers; it was not changed."))
            self.reload()

        self.bridge.run(lambda: self.ctx.feeds.add_entry_as_transfer(entry.id, **kwargs), done, self._error)

    def _mark(self, read: bool) -> None:
        ids = [e.id for e in self.selected_entries()]
        if ids:
            self.bridge.run(lambda: self.ctx.feeds.mark_read(ids, read), lambda _: self.reload(), self._error)

    def _copy_link(self) -> None:
        entries = self.selected_entries()
        if entries:
            entry = entries[0]
            QGuiApplication.clipboard().setText(entry.magnet or entry.torrent_url or entry.link or "")
            self.message.emit("info", "Link copied.")

    def _approve(self) -> None:
        entries = [e for e in self.selected_entries() if e.status == "review"]
        if not entries:
            return

        def work():
            return [self.ctx.feeds.approve_review(e.id) for e in entries]

        self.bridge.run(work, lambda r: (self.message.emit("info", f"{len(r)} item(s) added."), self.reload()),
                        self._error)

    def _dismiss(self) -> None:
        entries = [e for e in self.selected_entries() if e.status == "review"]
        if entries:
            self.bridge.run(lambda: [self.ctx.feeds.dismiss_review(e.id) for e in entries],
                            lambda _: self.reload(), self._error)


def _escape(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
