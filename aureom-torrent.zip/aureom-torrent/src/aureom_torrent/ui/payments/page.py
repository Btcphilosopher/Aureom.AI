"""Payments: optional publisher support. Every outgoing payment needs an explicit approval."""

from __future__ import annotations

import io
import time

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QGuiApplication, QPixmap
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QSplitter, QVBoxLayout,
                               QWidget)

from ...payments.amounts import format_msat, format_sats, msat_to_sat_ceil, sat_to_msat
from ...payments.models import (PaymentDirection, PaymentKind, PaymentState, PublisherRef, PublisherTrust)
from ...payments.service import PAYMENT_DISCLOSURES
from ..format import format_time
from ..models.rows import ROW_ROLE, Column, RowsModel
from ..transfers.dialogs import muted, note
from ..transfers.page import _SortProxy, make_table


def qr_pixmap(text: str, size: int = 240) -> QPixmap | None:
    """QR code for an invoice or payment URI, or None when it would be too dense to scan."""
    try:
        import segno

        code = segno.make(text, error="m", micro=False)
        if code.version > 25:
            return None
        buffer = io.BytesIO()
        code.save(buffer, kind="png", scale=4, border=3)
        pixmap = QPixmap()
        pixmap.loadFromData(buffer.getvalue())
        return pixmap.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.FastTransformation)
    except Exception:
        return None


def _selectable(text: str) -> QLabel:
    label = QLabel(text)
    label.setWordWrap(True)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    return label


class ApprovalDialog(QDialog):
    """Shows everything known about an outgoing Lightning payment and asks for explicit approval."""

    def __init__(self, summary, parent=None):
        super().__init__(parent)
        self.summary = summary
        self.setWindowTitle("Approve payment")
        self.resize(560, 520)
        form = QFormLayout(self)
        heading = QLabel(f"Pay {summary.amount_text}?")
        heading.setProperty("role", "heading")
        form.addRow(heading)
        form.addRow("Amount:", _selectable(summary.amount_text))
        form.addRow("Network:", _selectable(f"Lightning · {summary.network}"))
        form.addRow("Destination:", _selectable(f"{summary.destination}\n({summary.destination_source})"))
        form.addRow("Publisher:", _selectable(summary.publisher_name or "Not associated with a publisher"))
        form.addRow("Publisher identity:", _selectable(summary.trust_label))
        form.addRow("Invoice description:", _selectable(summary.description or "(none)"))
        self.expiry = _selectable("")
        form.addRow("Expires:", self.expiry)
        self.fee = QSpinBox()
        suggested = msat_to_sat_ceil(summary.suggested_fee_limit_msat or 0)
        maximum = max(suggested, msat_to_sat_ceil(summary.max_fee_limit_msat or 0))
        self.fee.setRange(0, max(1, maximum))
        self.fee.setValue(suggested)
        self.fee.setSuffix(" sat")
        self.fee.setAccessibleName("Maximum routing fee in satoshis")
        form.addRow("&Maximum routing fee:", self.fee)
        form.addRow("", muted("The payment fails rather than pay more than this in routing fees. The actual fee is "
                              "shown afterwards; it is usually lower."))
        form.addRow("Paid from:", _selectable(f"{summary.backend_name} {summary.backend_alias}".strip()))
        form.addRow("Payment hash:", _selectable(summary.payment_hash_short))
        if summary.warnings:
            warning = note("\n".join(f"• {w}" for w in summary.warnings))
            form.addRow(warning)
        form.addRow(note("\n".join(PAYMENT_DISCLOSURES)))
        buttons = QDialogButtonBox()
        self.approve = buttons.addButton("&Approve and pay", QDialogButtonBox.ButtonRole.AcceptRole)
        self.approve.setProperty("role", "primary")
        cancel = buttons.addButton("&Do not pay", QDialogButtonBox.ButtonRole.RejectRole)
        cancel.setDefault(True)
        cancel.setAutoDefault(True)
        self.approve.setAutoDefault(False)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        self._timer.start()
        self._tick()

    def _tick(self) -> None:
        if self.summary.expires_at is None:
            self.expiry.setText("No expiry stated")
            return
        left = int(self.summary.expires_at - time.time())
        if left <= 0:
            self.expiry.setText("Expired — this invoice can no longer be paid")
            self.approve.setEnabled(False)
        else:
            self.expiry.setText(f"in {left // 60} min {left % 60:02d} s ({format_time(self.summary.expires_at)})")

    def fee_limit_msat(self) -> int:
        return sat_to_msat(self.fee.value())


class InvoiceDialog(QDialog):
    """An incoming invoice: QR code, expiry countdown and live settlement status."""

    def __init__(self, ctx, bridge, intent, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge, self.intent = ctx, bridge, intent
        self.setWindowTitle("Receive a tip")
        layout = QVBoxLayout(self)
        heading = QLabel(f"Invoice for {format_msat(intent.amount_msat)}")
        heading.setProperty("role", "heading")
        layout.addWidget(heading)
        self.qr = QLabel()
        self.qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.qr.setMinimumSize(250, 250)
        self.qr.setAccessibleName("QR code of the invoice")
        pixmap = qr_pixmap((intent.invoice or "").upper())
        if pixmap:
            self.qr.setPixmap(pixmap)
        else:
            self.qr.setText("This invoice is too long for a reliable QR code.\nCopy the text instead.")
        layout.addWidget(self.qr)
        self.text = QPlainTextEdit(intent.invoice or "")
        self.text.setReadOnly(True)
        self.text.setMaximumHeight(90)
        self.text.setAccessibleName("Invoice text")
        layout.addWidget(self.text)
        self.status = QLabel("")
        self.status.setProperty("role", "subheading")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.countdown = muted("")
        layout.addWidget(self.countdown)
        layout.addWidget(muted("The invoice is marked settled only when your Lightning backend confirms it. "
                               "Settlement is usually quick but is not guaranteed to be instant."))
        row = QHBoxLayout()
        copy = QPushButton("&Copy invoice")
        copy.clicked.connect(lambda: QGuiApplication.clipboard().setText(intent.invoice or ""))
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row.addWidget(copy)
        row.addStretch(1)
        row.addWidget(close)
        layout.addLayout(row)
        self._busy = False
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        self._timer.start()
        self._ticks = 0
        self._show(intent)

    def _show(self, intent) -> None:
        self.intent = intent
        self._busy = False
        text = {PaymentState.PENDING: "Waiting for payment…", PaymentState.SUCCEEDED: "Settled — payment received.",
                PaymentState.EXPIRED: "Expired without being paid.",
                PaymentState.FAILED: "Cancelled by the backend."}.get(intent.state, intent.state_label)
        if intent.error and intent.state is not PaymentState.SUCCEEDED:
            text += f" ({intent.error})"
        self.status.setText(text)
        if intent.state.terminal:
            self._timer.stop()
            self.countdown.setText("")

    def _tick(self) -> None:
        self._ticks += 1
        if self.intent.expires_at:
            left = int(self.intent.expires_at - time.time())
            self.countdown.setText(f"Expires in {max(0, left) // 60} min {max(0, left) % 60:02d} s")
        if self._ticks % 3 == 0 and not self._busy:
            self._busy = True
            self.bridge.run(lambda: self.ctx.payments.refresh(self.intent.id), self._show,
                            lambda exc: setattr(self, "_busy", False))


class PaymentsPage(QWidget):
    message = Signal(str, str)

    def __init__(self, ctx, bridge, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge = ctx, bridge
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 8)
        heading = QLabel("Payments")
        heading.setProperty("role", "heading")
        layout.addWidget(heading)
        self.status = QLabel("Checking the payment backend…")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        layout.addWidget(note("Supporting a publisher is optional. " + " ".join(PAYMENT_DISCLOSURES)
                              + " Transfers work the same with or without a wallet."))
        row = QHBoxLayout()
        self.pay_button = QPushButton("Pay a Lightning &invoice…")
        self.tip_button = QPushButton("&Tip a publisher…")
        self.receive_button = QPushButton("&Receive a tip…")
        self.bitcoin_button = QPushButton("&Bitcoin payment request…")
        self.pay_button.clicked.connect(lambda: self.pay_invoice())
        self.tip_button.clicked.connect(lambda: self.tip())
        self.receive_button.clicked.connect(self.receive)
        self.bitcoin_button.clicked.connect(lambda: self.bitcoin_request())
        for button in (self.pay_button, self.tip_button, self.receive_button, self.bitcoin_button):
            row.addWidget(button)
        row.addStretch(1)
        layout.addLayout(row)

        self.model = RowsModel([
            Column("When", lambda p: format_time(p.created_at), lambda p: p.created_at),
            Column("Direction", lambda p: "Outgoing" if p.direction is PaymentDirection.OUTGOING else "Incoming"),
            Column("Type", lambda p: p.kind.label),
            Column("Amount", lambda p: self.ctx.payments.describe_amount_paid(p), lambda p: p.amount_msat or 0, True),
            Column("State", lambda p: self._state_text(p), tooltip=lambda p: p.error or self._state_text(p)),
            Column("Publisher", lambda p: p.publisher_name or "—"),
            Column("Description", lambda p: p.description or p.note or ""),
        ], key=lambda p: p.id, parent=self)
        proxy = _SortProxy(self)
        proxy.setSourceModel(self.model)
        self.table = make_table(proxy)
        self.table.setAccessibleName("Payment history")
        self.table.sortByColumn(0, Qt.SortOrder.DescendingOrder)
        for column, width in enumerate((130, 90, 190, 170, 240, 150)):
            self.table.setColumnWidth(column, width)
        self.table.selectionModel().selectionChanged.connect(lambda *_: self._show_details())
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setAccessibleName("Payment details")
        actions = QHBoxLayout()
        self.check_button = QPushButton("&Check status")
        self.check_button.setToolTip("Asks the backend for the status. This never sends the payment again.")
        self.check_button.clicked.connect(self._check)
        self.cancel_button = QPushButton("Cancel (&not sent)")
        self.cancel_button.clicked.connect(self._cancel)
        self.show_invoice_button = QPushButton("&Show invoice")
        self.show_invoice_button.clicked.connect(self._show_invoice)
        for button in (self.check_button, self.cancel_button, self.show_invoice_button):
            actions.addWidget(button)
        actions.addStretch(1)
        lower = QWidget()
        lower_layout = QVBoxLayout(lower)
        lower_layout.setContentsMargins(0, 0, 0, 0)
        lower_layout.addWidget(self.details, 1)
        lower_layout.addLayout(actions)
        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self.table)
        split.addWidget(lower)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        layout.addWidget(split, 1)
        self._timer = QTimer(self)
        self._timer.setInterval(10_000)
        self._timer.timeout.connect(self.reload)
        self._backend_ok = False
        self._show_details()

    @staticmethod
    def _state_text(p) -> str:
        if p.kind is PaymentKind.BITCOIN_EXTERNAL and p.state is PaymentState.UNKNOWN:
            return "Handed to external wallet — outcome not tracked"
        return p.state_label

    # ---------------------------------------------------------------- loading
    def activate(self) -> None:
        self.reload()
        self._timer.start()

    def hideEvent(self, event) -> None:
        self._timer.stop()
        super().hideEvent(event)

    def _error(self, exc) -> None:
        self.message.emit("error", str(exc))

    def reload(self) -> None:
        def load():
            return self.ctx.payments.backend_status(), self.ctx.payments.list_payments(limit=300)

        def done(result) -> None:
            status, payments = result
            self._backend_ok = status.connected and status.network_matches
            if not status.configured:
                text = ("No Lightning backend is configured. You can still open Bitcoin payment requests in an "
                        "external wallet. To pay or create Lightning invoices, connect an LND node in Settings → "
                        "Payments.")
            elif status.connected:
                text = (f"Connected to {status.name} “{status.alias}” on {status.network}"
                        f"{'' if status.synced else ' (node is still synchronising)'}. {self.ctx.payments.limits_text()}")
                if not status.network_matches:
                    text += " The node's network does not match the network selected in Settings; payments are blocked."
            else:
                text = f"The Lightning backend cannot be reached: {status.message}"
            self.status.setText(text)
            for button in (self.pay_button, self.tip_button, self.receive_button):
                button.setEnabled(self._backend_ok)
            self.model.set_rows(payments)
            self._show_details()

        self.bridge.run(load, done, self._error)

    def current(self):
        rows = self.table.selectionModel().selectedRows()
        return rows[0].data(ROW_ROLE) if rows else None

    def _show_details(self) -> None:
        p = self.current()
        self.check_button.setEnabled(bool(p and p.is_lightning and p.state in (
            PaymentState.SUBMITTED, PaymentState.PENDING, PaymentState.UNKNOWN)))
        self.cancel_button.setEnabled(bool(p and p.state in (PaymentState.DRAFT, PaymentState.AWAITING_APPROVAL)))
        self.show_invoice_button.setEnabled(bool(p and p.kind is PaymentKind.LIGHTNING_RECEIVE and p.invoice))
        if p is None:
            self.details.setPlainText("Select a payment to see its history.")
            return

        def done(events) -> None:
            lines = [f"{p.kind.label} · {self._state_text(p)}",
                     f"Amount: {self.ctx.payments.describe_amount_paid(p)}",
                     f"Network: {p.network}"]
            if p.fee_limit_msat is not None and p.direction is PaymentDirection.OUTGOING and p.is_lightning:
                lines.append(f"Fee limit approved: {format_sats(msat_to_sat_ceil(p.fee_limit_msat))}")
            if p.destination:
                lines.append(f"Destination: {p.destination}")
            if p.publisher_name:
                lines.append(f"Publisher: {p.publisher_name} — {p.publisher_trust.label}")
            if p.payment_hash:
                lines.append(f"Payment hash: {p.payment_hash}")
            if p.note:
                lines.append(f"Note: {p.note}")
            if p.error:
                lines.append(f"Detail: {p.error}")
            if p.state is PaymentState.UNKNOWN and p.is_lightning:
                lines.append("The outcome is not known (for example the connection dropped after the request was "
                             "sent). It is NOT assumed to have failed and will not be sent again automatically. "
                             "Use “Check status”.")
            lines.append("")
            lines.append("History")
            for ev in events:
                lines.append(f"  {format_time(ev.ts)}  {ev.from_state or '—'} → {ev.to_state}  {ev.detail}")
            self.details.setPlainText("\n".join(lines))

        self.bridge.run(lambda: self.ctx.payments.events(p.id), done, self._error)

    # ---------------------------------------------------------------- actions
    def _approve(self, intent, summary) -> None:
        """The single path to an outgoing Lightning payment: the user must press “Approve and pay”."""
        dialog = ApprovalDialog(summary, self)
        if dialog.exec():
            fee_limit = dialog.fee_limit_msat()
            self.message.emit("info", "Payment submitted; waiting for the backend…")

            def done(result) -> None:
                level = "info" if result.state in (PaymentState.SUCCEEDED, PaymentState.PENDING) else "error"
                text = {PaymentState.SUCCEEDED: f"Payment succeeded: {self.ctx.payments.describe_amount_paid(result)}.",
                        PaymentState.PENDING: "The payment is in flight. Its status will update here.",
                        PaymentState.UNKNOWN: "The outcome of the payment is unknown. It has NOT been retried. "
                                              "Use “Check status” to ask the backend.",
                        PaymentState.FAILED: f"The payment failed: {result.error}. No funds were sent.",
                        PaymentState.EXPIRED: "The invoice expired before it could be paid."}.get(
                    result.state, result.state_label)
                self.message.emit(level, text)
                self.reload()

            self.bridge.run(lambda: self.ctx.payments.approve_and_send(intent.id, fee_limit_msat=fee_limit), done,
                            lambda exc: (self._error(exc), self.reload()))
        else:
            self.bridge.run(lambda: self.ctx.payments.cancel(intent.id), lambda _: self.reload(), self._error)

    def pay_invoice(self, publisher: PublisherRef | None = None, transfer_id: str | None = None) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Pay a Lightning invoice")
        dialog.resize(560, 320)
        form = QFormLayout(dialog)
        text = QPlainTextEdit()
        text.setPlaceholderText("lnbc…")
        text.setAccessibleName("Lightning invoice")
        text.setTabChangesFocus(True)
        form.addRow("&Invoice:", text)
        amount = QSpinBox()
        amount.setRange(0, 2_100_000_000)
        amount.setSuffix(" sat")
        amount.setSpecialValueText("Use the invoice amount")
        form.addRow("&Amount (only for invoices without one):", amount)
        memo = QLineEdit()
        form.addRow("&Note for your records:", memo)
        form.addRow(muted("Nothing is paid at this step. You will see the decoded invoice and must approve it."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Review…")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if not dialog.exec():
            return
        invoice = text.toPlainText().strip()
        amount_msat = sat_to_msat(amount.value()) if amount.value() else None
        self.bridge.run(lambda: self.ctx.payments.prepare_invoice_payment(
            invoice, amount_msat=amount_msat, publisher=publisher, transfer_id=transfer_id, note=memo.text().strip()),
            lambda result: self._approve(*result), self._error)

    def tip(self, address: str = "", publisher: PublisherRef | None = None, transfer_id: str | None = None) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Tip a publisher")
        dialog.resize(520, 320)
        form = QFormLayout(dialog)
        target = QLineEdit(address)
        target.setPlaceholderText("name@example.org")
        form.addRow("Lightning &address:", target)
        if publisher is not None:
            form.addRow("Publisher:", _selectable(f"{publisher.name} — {publisher.trust.label}"))
        amount = QSpinBox()
        pay = self.ctx.settings.get().payments
        amount.setRange(pay.min_payment_sat, min(pay.max_payment_sat, 2_000_000_000))
        amount.setSuffix(" sat")
        amount.setAccessibleName("Tip amount in satoshis")
        presets = QHBoxLayout()
        preset_values = [msat // 1000 for msat in self.ctx.payments.tip_presets_msat()]
        for value in preset_values:
            button = QPushButton(format_sats(value))
            button.clicked.connect(lambda _=False, v=value: amount.setValue(v))
            presets.addWidget(button)
        presets.addStretch(1)
        if preset_values:
            amount.setValue(preset_values[0])
        form.addRow("Presets:", presets)
        form.addRow("&Amount:", amount)
        form.addRow("", muted(self.ctx.payments.limits_text()))
        memo = QLineEdit()
        form.addRow("&Note for your records:", memo)
        form.addRow(note("Requesting a tip invoice contacts the publisher's payment server, which will see your IP "
                         "address (or your payment proxy's). Nothing is paid until you approve the invoice it returns."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Request invoice…")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if not dialog.exec():
            return
        where = target.text().strip()
        msat = sat_to_msat(amount.value())
        self.message.emit("info", "Requesting an invoice from the publisher's payment server…")
        self.bridge.run(lambda: self.ctx.payments.prepare_tip(where, msat, publisher=publisher,
                                                              transfer_id=transfer_id, note=memo.text().strip()),
                        lambda result: self._approve(*result), self._error)

    def receive(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Receive a tip")
        form = QFormLayout(dialog)
        pay = self.ctx.settings.get().payments
        amount = QSpinBox()
        amount.setRange(1, min(pay.max_payment_sat, 2_000_000_000))
        amount.setValue(1000)
        amount.setSuffix(" sat")
        form.addRow("&Amount:", amount)
        memo = QLineEdit()
        memo.setMaxLength(200)
        form.addRow("&Description shown to the payer:", memo)
        expiry = QSpinBox()
        expiry.setRange(1, 7 * 24 * 60)
        expiry.setValue(max(1, pay.invoice_expiry_s // 60))
        expiry.setSuffix(" min")
        form.addRow("&Expires after:", expiry)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Create invoice")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if not dialog.exec():
            return
        msat, text, seconds = sat_to_msat(amount.value()), memo.text().strip(), expiry.value() * 60

        def done(intent) -> None:
            self.reload()
            InvoiceDialog(self.ctx, self.bridge, intent, self).exec()
            self.reload()

        self.bridge.run(lambda: self.ctx.payments.create_incoming_invoice(msat, memo=text, expiry_s=seconds),
                        done, self._error)

    def bitcoin_request(self, address: str = "", publisher: PublisherRef | None = None,
                        transfer_id: str | None = None) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Bitcoin payment request")
        dialog.resize(540, 300)
        form = QFormLayout(dialog)
        target = QLineEdit(address)
        form.addRow("Bitcoin &address:", target)
        if publisher is not None:
            form.addRow("Publisher:", _selectable(f"{publisher.name} — {publisher.trust.label}"))
        amount = QSpinBox()
        amount.setRange(0, 2_100_000_000)
        amount.setSuffix(" sat")
        amount.setSpecialValueText("Choose in the wallet")
        form.addRow("A&mount:", amount)
        label = QLineEdit(publisher.name if publisher else "")
        form.addRow("&Label:", label)
        form.addRow(note("This creates a standard bitcoin: payment link (BIP21) and hands it to the wallet "
                         "application installed on your computer. AUREOM TORRENT does not hold keys, sign or "
                         "broadcast, and cannot see whether you pay: the record stays “outcome not tracked”. "
                         "On-chain payments are public and permanently visible."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Create request…")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if not dialog.exec():
            return
        addr, sats, text = target.text().strip(), amount.value() or None, label.text().strip()

        def done(result) -> None:
            intent, uri = result
            self.reload()
            self._show_bitcoin_request(intent, uri)

        self.bridge.run(lambda: self.ctx.payments.create_bitcoin_request(
            addr, amount_sat=sats, label=text, publisher=publisher, transfer_id=transfer_id), done, self._error)

    def _show_bitcoin_request(self, intent, uri: str) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Bitcoin payment request")
        layout = QVBoxLayout(dialog)
        heading = QLabel("Open this request in your wallet?")
        heading.setProperty("role", "heading")
        layout.addWidget(heading)
        form = QFormLayout()
        form.addRow("Address:", _selectable(intent.destination))
        form.addRow("Network:", _selectable(f"Bitcoin · {intent.network}"))
        form.addRow("Amount:", _selectable(self.ctx.payments.describe_amount_paid(intent)))
        form.addRow("Publisher:", _selectable(f"{intent.publisher_name or 'Not associated'} — {intent.publisher_trust.label}"))
        layout.addLayout(form)
        qr = QLabel()
        qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pixmap = qr_pixmap(uri, 220)
        if pixmap:
            qr.setPixmap(pixmap)
        layout.addWidget(qr)
        text = QLineEdit(uri)
        text.setReadOnly(True)
        text.setAccessibleName("Payment link")
        layout.addWidget(text)
        layout.addWidget(muted("Fees, confirmation and the final amount are decided in your wallet. Opening the "
                               "wallet does not mean a payment was made."))
        row = QHBoxLayout()
        open_button = QPushButton("&Open in wallet application")
        open_button.setProperty("role", "primary")
        copy = QPushButton("&Copy link")
        close = QPushButton("Close")
        row.addWidget(open_button)
        row.addWidget(copy)
        row.addStretch(1)
        row.addWidget(close)
        layout.addLayout(row)
        copy.clicked.connect(lambda: QGuiApplication.clipboard().setText(uri))
        close.clicked.connect(dialog.accept)

        def open_wallet() -> None:
            opened = QDesktopServices.openUrl(QUrl(uri))
            if opened:
                self.bridge.run(lambda: self.ctx.payments.mark_wallet_opened(intent.id), lambda _: self.reload(),
                                self._error)
                dialog.accept()
            else:
                QMessageBox.information(dialog, dialog.windowTitle(),
                                        "No application on this computer is registered for bitcoin: links. "
                                        "Copy the link or scan the code with your wallet instead.")

        open_button.clicked.connect(open_wallet)
        dialog.exec()
        self.reload()

    def support_publisher(self, transfer_id: str, kind: str) -> None:
        """Entry point from a transfer's Publisher tab. Only opens a dialog – never pays by itself."""
        def done(summary) -> None:
            if not summary:
                self.message.emit("info", "This transfer has no publisher payment information.")
                return
            trust = PublisherTrust.VERIFIED if summary.get("verified") else PublisherTrust.SELF_ASSERTED
            ref = PublisherRef(name=summary.get("name", ""), trust=trust, manifest_id=summary.get("manifest_id"))
            if kind == "lightning":
                if not self._backend_ok:
                    self.message.emit("info", "Connect a Lightning backend in Settings → Payments to send tips.")
                    return
                self.tip(summary.get("lightning_address", ""), ref, transfer_id)
            else:
                self.bitcoin_request(summary.get("bitcoin_address", ""), ref, transfer_id)

        self.reload()
        self.bridge.run(lambda: self.ctx.manifest_summary(transfer_id), lambda s: QTimer.singleShot(300, lambda: done(s)),
                        self._error)

    def _check(self) -> None:
        p = self.current()
        if p is not None:
            self.bridge.run(lambda: self.ctx.payments.refresh(p.id), lambda _: self.reload(), self._error)

    def _cancel(self) -> None:
        p = self.current()
        if p is not None:
            self.bridge.run(lambda: self.ctx.payments.cancel(p.id), lambda _: self.reload(), self._error)

    def _show_invoice(self) -> None:
        p = self.current()
        if p is not None and p.invoice:
            InvoiceDialog(self.ctx, self.bridge, p, self).exec()
            self.reload()
