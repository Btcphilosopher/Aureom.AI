"""A small generic table model for immutable row objects (peers, trackers, feed entries, payments…).

Rows are replaced wholesale but the model diffs by a key function, so that
unchanged rows are not repainted and the selection survives refreshes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Sequence

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt

SORT_ROLE = Qt.ItemDataRole.UserRole + 1
ROW_ROLE = Qt.ItemDataRole.UserRole + 2


@dataclass(frozen=True, slots=True)
class Column:
    title: str
    text: Callable[[Any], str]
    sort: Callable[[Any], Any] | None = None
    align_right: bool = False
    tooltip: Callable[[Any], str] | None = None
    colour: Callable[[Any], Any] | None = None


class RowsModel(QAbstractTableModel):
    def __init__(self, columns: Sequence[Column], key: Callable[[Any], Any], parent=None):
        super().__init__(parent)
        self._columns = list(columns)
        self._key = key
        self._rows: list[Any] = []

    # -- Qt model API ----------------------------------------------------
    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._columns)

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self._columns[section].title
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.TextAlignmentRole:
            col = self._columns[section]
            return int((Qt.AlignmentFlag.AlignRight if col.align_right else Qt.AlignmentFlag.AlignLeft)
                       | Qt.AlignmentFlag.AlignVCenter)
        return None

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._rows)):
            return None
        row = self._rows[index.row()]
        col = self._columns[index.column()]
        if role == Qt.ItemDataRole.DisplayRole:
            return col.text(row)
        if role == SORT_ROLE:
            return col.sort(row) if col.sort else col.text(row).casefold()
        if role == ROW_ROLE:
            return row
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return int((Qt.AlignmentFlag.AlignRight if col.align_right else Qt.AlignmentFlag.AlignLeft)
                       | Qt.AlignmentFlag.AlignVCenter)
        if role == Qt.ItemDataRole.ToolTipRole:
            return col.tooltip(row) if col.tooltip else col.text(row)
        if role == Qt.ItemDataRole.ForegroundRole and col.colour:
            return col.colour(row)
        return None

    # -- updates -----------------------------------------------------------
    def rows(self) -> list[Any]:
        return list(self._rows)

    def row_at(self, row: int) -> Any | None:
        return self._rows[row] if 0 <= row < len(self._rows) else None

    def set_rows(self, new_rows: Sequence[Any]) -> None:
        """Replace the contents, emitting the narrowest change signals that are cheap to compute."""
        new_rows = list(new_rows)
        old_keys = [self._key(r) for r in self._rows]
        new_keys = [self._key(r) for r in new_rows]
        if old_keys == new_keys:
            last = len(self._columns) - 1
            first_changed = last_changed = -1
            for i, (old, new) in enumerate(zip(self._rows, new_rows)):
                if old != new:
                    self._rows[i] = new
                    if first_changed < 0:
                        first_changed = i
                    last_changed = i
            if first_changed >= 0:
                self.dataChanged.emit(self.index(first_changed, 0), self.index(last_changed, last))
            return
        new_set = set(new_keys)
        # removals (from the end so indices stay valid)
        for i in range(len(self._rows) - 1, -1, -1):
            if old_keys[i] not in new_set:
                self.beginRemoveRows(QModelIndex(), i, i)
                del self._rows[i]
                del old_keys[i]
                self.endRemoveRows()
        if old_keys == [k for k in new_keys if k in set(old_keys)]:
            # same relative order: update survivors in place and insert the new rows
            by_key = dict(zip(new_keys, new_rows))
            for i, key in enumerate(old_keys):
                if self._rows[i] != by_key[key]:
                    self._rows[i] = by_key[key]
                    self.dataChanged.emit(self.index(i, 0), self.index(i, len(self._columns) - 1))
            existing = set(old_keys)
            for i, key in enumerate(new_keys):
                if key not in existing:
                    self.beginInsertRows(QModelIndex(), i, i)
                    self._rows.insert(i, new_rows[i])
                    self.endInsertRows()
                    existing.add(key)
            return
        self.beginResetModel()
        self._rows = new_rows
        self.endResetModel()
