"""Model/view pieces for the main transfer table."""

from __future__ import annotations

from PySide6.QtCore import QModelIndex, QRect, QSortFilterProxyModel, Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QStyle, QStyledItemDelegate, QStyleOptionViewItem

from ...domain.transfers import TransferState, TransferView
from ..format import (format_eta, format_progress, format_rate, format_ratio, format_size)
from ..themes.theme import Palette
from .rows import ROW_ROLE, SORT_ROLE, Column, RowsModel

PROGRESS_COLUMN = 2

FILTERS = {
    "all": lambda v: True,
    "downloading": lambda v: v.state in (TransferState.DOWNLOADING, TransferState.RETRIEVING_METADATA,
                                         TransferState.ADDED) or (v.state is TransferState.QUEUED
                                                                  and not v.selected_complete),
    "seeding": lambda v: v.state is TransferState.SEEDING or (v.state is TransferState.QUEUED
                                                              and v.selected_complete),
    "completed": lambda v: v.selected_complete,
    "paused": lambda v: v.state in (TransferState.PAUSED, TransferState.COMPLETED),
    "checking": lambda v: v.state in (TransferState.CHECKING, TransferState.MOVING),
    "errors": lambda v: v.state is TransferState.ERROR or bool(v.error),
}


def state_text(v: TransferView) -> str:
    if v.preview:
        return "Awaiting your review" if v.has_metadata else "Retrieving metadata"
    if v.state is TransferState.DOWNLOADING and v.state_detail.startswith("Stalled"):
        return "Downloading (stalled)"
    if v.state is TransferState.SEEDING and not v.torrent_complete:
        return "Seeding (selected files)"
    return v.state.label


def transfer_columns() -> list[Column]:
    return [
        Column("Name", lambda v: v.name, tooltip=lambda v: f"{v.name}\n{v.identity.kind} · {v.identity.primary}"),
        Column("Size", lambda v: format_size(v.size) if v.has_metadata else "—", lambda v: v.size, True),
        Column("Verified", lambda v: format_progress(v.progress_ppm) if v.has_metadata and not v.preview else "—",
               lambda v: v.progress_ppm, True,
               tooltip=lambda v: "Verified progress of the selected files (pieces that passed their hash check)"),
        Column("State", state_text, lambda v: (v.state.value, v.name.casefold()),
               tooltip=lambda v: v.state_detail or v.state.label),
        Column("Down", lambda v: format_rate(v.download_rate), lambda v: v.download_rate, True),
        Column("Up", lambda v: format_rate(v.upload_rate), lambda v: v.upload_rate, True),
        Column("Peers", lambda v: f"{v.peers} ({v.seeds})" if v.live and (v.peers or v.seeds) else "",
               lambda v: v.peers, True, tooltip=lambda v: f"{v.peers} connected peers, {v.seeds} of them seeds"),
        Column("Ratio", lambda v: format_ratio(v.ratio_permille), lambda v: v.ratio_permille or -1, True),
        Column("ETA", lambda v: format_eta(v.eta_seconds), lambda v: v.eta_seconds if v.eta_seconds is not None else 1 << 40, True),
        Column("Category", lambda v: v.category),
        Column("Destination", lambda v: v.save_path if not v.preview else "(not chosen yet)"),
    ]


class TransferTableModel(RowsModel):
    def __init__(self, parent=None):
        super().__init__(transfer_columns(), key=lambda v: v.id, parent=parent)

    def view_for(self, transfer_id: str) -> TransferView | None:
        for row in self._rows:
            if row.id == transfer_id:
                return row
        return None


class TransferFilterProxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._filter = "all"
        self._needle = ""
        self.setSortRole(SORT_ROLE)
        self.setDynamicSortFilter(True)

    def _change(self, apply) -> None:
        # Qt 6.10 replaced invalidateFilter() with begin/endFilterChange(); support both.
        if hasattr(self, "beginFilterChange"):
            self.beginFilterChange()
            apply()
            self.endFilterChange()
        else:  # pragma: no cover - older Qt
            apply()
            self.invalidateFilter()

    def set_filter(self, name: str) -> None:
        if name != self._filter:
            self._change(lambda: setattr(self, "_filter", name))

    def set_search(self, text: str) -> None:
        needle = text.strip().casefold()
        if needle != self._needle:
            self._change(lambda: setattr(self, "_needle", needle))

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        view = self.sourceModel().row_at(source_row)
        if view is None:
            return False
        if not FILTERS.get(self._filter, FILTERS["all"])(view):
            return False
        if self._needle:
            haystack = f"{view.name}\n{view.category}\n{view.save_path}\n{view.identity.v1 or ''}\n{view.identity.v2 or ''}"
            return self._needle in haystack.casefold()
        return True


def filter_counts(views: list[TransferView]) -> dict[str, int]:
    return {name: sum(1 for v in views if test(v)) for name, test in FILTERS.items()}


class ProgressDelegate(QStyledItemDelegate):
    """Paints the verified-progress cell as a slim bar with the percentage."""

    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.palette = palette

    def set_palette(self, palette: Palette) -> None:
        self.palette = palette

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index: QModelIndex) -> None:
        view: TransferView | None = index.data(ROW_ROLE)
        p = self.palette
        painter.save()
        if option.state & QStyle.StateFlag.State_Selected:
            painter.fillRect(option.rect, QColor(p.selection_bg))
        if view is None or not view.has_metadata or view.preview:
            painter.setPen(QColor(p.muted))
            painter.drawText(option.rect.adjusted(6, 0, -8, 0),
                             int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), "—")
            painter.restore()
            return
        if view.state is TransferState.ERROR:
            colour = p.error
        elif view.state in (TransferState.DOWNLOADING, TransferState.CHECKING, TransferState.MOVING):
            colour = p.active
        elif view.selected_complete:
            colour = p.complete
        else:
            colour = p.paused
        rect: QRect = option.rect.adjusted(6, 0, -6, 0)
        text_width = 46
        bar = QRect(rect.left(), rect.center().y() - 3, max(10, rect.width() - text_width - 6), 6)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(p.track))
        painter.drawRoundedRect(bar, 3, 3)
        fraction = max(0.0, min(1.0, view.progress_ppm / 1_000_000))
        if fraction > 0:
            filled = QRect(bar.left(), bar.top(), max(3, int(bar.width() * fraction)), bar.height())
            painter.setBrush(QColor(colour))
            painter.drawRoundedRect(filled, 3, 3)
        painter.setPen(QColor(p.selection_text if option.state & QStyle.StateFlag.State_Selected else p.text))
        painter.drawText(QRect(rect.right() - text_width, rect.top(), text_width, rect.height()),
                         int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter),
                         format_progress(view.progress_ppm))
        painter.restore()
