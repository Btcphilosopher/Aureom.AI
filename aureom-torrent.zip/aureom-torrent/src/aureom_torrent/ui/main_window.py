"""Main window: navigation, persistent toolbar, workspace pages and status bar."""

from __future__ import annotations

import os

from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QAction, QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMainWindow, QMessageBox, QPushButton, QSizePolicy,
                               QStackedWidget, QToolBar, QVBoxLayout, QWidget)

from ..domain.magnet import looks_like_magnet
from ..services.interfaces import AddRejected
from .bridge import Bridge
from .format import format_rate_always
from .models.transfers import filter_counts
from .themes.theme import palette_for, stylesheet
from .transfers.dialogs import AddMagnetDialog, TorrentReviewDialog
from .transfers.page import TransfersPage

MAX_TORRENT_FILE = 32 * 1024 * 1024

NAV = [
    ("all", "All Transfers"), ("downloading", "Downloading"), ("seeding", "Seeding"),
    ("completed", "Completed"), ("paused", "Paused"), ("checking", "Checking"), ("errors", "Errors"),
    (None, ""),
    ("feeds", "RSS Feeds"), ("publish", "Publish && Share"), ("payments", "Payments"), ("settings", "Settings"),
]
TRANSFER_FILTERS = {"all", "downloading", "seeding", "completed", "paused", "checking", "errors"}

SHORTCUTS = [
    ("Ctrl+O", "Add torrent file(s)"), ("Ctrl+Shift+O", "Add magnet link"), ("Ctrl+V", "Paste a magnet link (transfer table focused)"),
    ("Ctrl+N", "Create torrent (Publish & Share)"), ("Ctrl+S", "Start selected transfers"),
    ("Ctrl+P", "Pause selected transfers"), ("Delete", "Remove selected transfers…"),
    ("Ctrl+F", "Search transfers"), ("Ctrl+1 … Ctrl+7", "Transfer filters (All … Errors)"),
    ("Ctrl+8 / 9 / 0", "RSS Feeds / Publish & Share / Payments"), ("Ctrl+,", "Settings"),
    ("F6 / Shift+F6", "Move focus between navigation, table and details"),
    ("Alt+Left / Alt+Right", "Previous / next details tab"), ("F5", "Refresh the selected feed"),
    ("Ctrl+Q", "Quit"),
]


class Banner(QFrame):
    """A non-modal message strip. Errors stay until dismissed; information fades after a few seconds."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("banner")
        self.label = QLabel()
        self.label.setWordWrap(True)
        self.label.setTextFormat(Qt.TextFormat.PlainText)
        self.label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        close = QPushButton("Dismiss")
        close.clicked.connect(self.hide)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 8, 6)
        layout.addWidget(self.label, 1)
        layout.addWidget(close)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)
        self.setAccessibleName("Notification")
        self.hide()

    def show_message(self, level: str, text: str) -> None:
        self.label.setText(text)
        self.setProperty("level", level)
        self.style().unpolish(self)
        self.style().polish(self)
        self.setAccessibleDescription(text)
        self.show()
        if level == "error":
            self._timer.stop()
        else:
            self._timer.start(9000)


class MainWindow(QMainWindow):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.bridge = Bridge(parent=self)
        self.setWindowTitle("AUREOM TORRENT")
        self.resize(1320, 840)
        self.setAcceptDrops(True)
        ui = ctx.settings.get().ui
        self.palette_ = palette_for(ui.theme, self._system_dark())
        self._snapshot_busy = False
        self._closing = False
        self._shutdown_done = False
        self._pending_files: list[str] = []
        self._review_open: set[str] = set()

        # ---- navigation
        nav = QWidget()
        nav.setObjectName("nav")
        nav.setFixedWidth(212)
        nav_layout = QVBoxLayout(nav)
        nav_layout.setContentsMargins(0, 16, 0, 10)
        nav_layout.setSpacing(0)
        title = QLabel("AUREOM TORRENT")
        title.setObjectName("brandTitle")
        title.setContentsMargins(16, 0, 8, 0)
        self.brand_line = QLabel("Code at the speed of civilisation.")
        self.brand_line.setObjectName("brandLine")
        self.brand_line.setContentsMargins(16, 3, 8, 0)
        self.brand_line.setVisible(ui.show_brand_line)
        rule = QFrame()
        rule.setObjectName("brandRule")
        rule_box = QHBoxLayout()
        rule_box.setContentsMargins(16, 10, 150, 12)
        rule_box.addWidget(rule)
        nav_layout.addWidget(title)
        nav_layout.addWidget(self.brand_line)
        nav_layout.addLayout(rule_box)
        self.nav = QListWidget()
        self.nav.setObjectName("navList")
        self.nav.setAccessibleName("Main navigation")
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._nav_items: dict[str, QListWidgetItem] = {}
        for key, label in NAV:
            item = QListWidgetItem(label.replace("&&", "&"))
            if key is None:
                item.setFlags(Qt.ItemFlag.NoItemFlags)
                item.setSizeHint(QSize(10, 14))
            else:
                item.setData(Qt.ItemDataRole.UserRole, key)
                self._nav_items[key] = item
            self.nav.addItem(item)
        self.nav.currentItemChanged.connect(self._on_nav)
        nav_layout.addWidget(self.nav, 1)

        # ---- pages
        from .feeds.page import FeedsPage
        from .payments.page import PaymentsPage
        from .publishing.page import PublishPage
        from .settings_page import SettingsPage

        self.transfers_page = TransfersPage(ctx, self.bridge, self.palette_, ui.density)
        self.feeds_page = FeedsPage(ctx, self.bridge, self)
        self.publish_page = PublishPage(ctx, self.bridge, self)
        self.payments_page = PaymentsPage(ctx, self.bridge, self)
        self.settings_page = SettingsPage(ctx, self.bridge, self)
        self.stack = QStackedWidget()
        for page in (self.transfers_page, self.feeds_page, self.publish_page, self.payments_page,
                     self.settings_page):
            self.stack.addWidget(page)
        self.banner = Banner()
        workspace = QWidget()
        workspace.setObjectName("workspace")
        ws_layout = QVBoxLayout(workspace)
        ws_layout.setContentsMargins(0, 0, 0, 0)
        ws_layout.setSpacing(0)
        self.toolbar = QToolBar("Main toolbar")
        ws_layout.addWidget(self.toolbar)
        banner_box = QVBoxLayout()
        banner_box.setContentsMargins(12, 8, 12, 0)
        banner_box.addWidget(self.banner)
        ws_layout.addLayout(banner_box)
        ws_layout.addWidget(self.stack, 1)

        central = QWidget()
        central_layout = QHBoxLayout(central)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)
        central_layout.addWidget(nav)
        central_layout.addWidget(workspace, 1)
        self.setCentralWidget(central)

        self._build_toolbar()
        self._build_statusbar()
        self._build_shortcuts()

        # ---- signals
        for page in (self.transfers_page, self.feeds_page, self.publish_page, self.payments_page,
                     self.settings_page):
            page.message.connect(self.show_message)
        self.transfers_page.selection_changed.connect(self._update_actions)
        self.transfers_page.review_requested.connect(self.review_preview)
        self.transfers_page.request_publisher_support.connect(self._support_publisher)
        self.settings_page.appearance_changed.connect(self.apply_theme)
        self.publish_page.go_to_transfer.connect(self._show_transfer)
        self.feeds_page.add_magnet_requested.connect(lambda text: self.add_magnet(text))
        self.bridge.failed.connect(lambda text: self.show_message("error", text))
        self.bridge.notified.connect(self._on_notification)
        ctx.transfers.subscribe(self.bridge.notify_from_worker)

        self.apply_theme()
        self.nav.setCurrentItem(self._nav_items["all"])
        self._timer = QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._poll)
        self._timer.start()
        self._wallet_timer = QTimer(self)
        self._wallet_timer.setInterval(30_000)
        self._wallet_timer.timeout.connect(self._poll_wallet)
        self._wallet_timer.start()
        QTimer.singleShot(1500, self._poll_wallet)
        QTimer.singleShot(400, self._show_startup_notes)
        self._update_actions()
        self.transfers_page.table.setFocus()

    # ---------------------------------------------------------------- chrome
    def _system_dark(self) -> bool:
        try:
            return QGuiApplication.styleHints().colorScheme() == Qt.ColorScheme.Dark
        except Exception:
            return False

    def _build_toolbar(self) -> None:
        bar = self.toolbar
        bar.setMovable(False)
        bar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        bar.setAccessibleName("Main toolbar")

        def action(text: str, shortcut: str, slot, tip: str) -> QAction:
            act = QAction(text, self)
            if shortcut:
                act.setShortcut(QKeySequence(shortcut))
            act.setToolTip(f"{tip} ({shortcut})" if shortcut else tip)
            act.setStatusTip(tip)
            act.triggered.connect(slot)
            bar.addAction(act)
            return act

        self.act_add = action("Add Torrent", "Ctrl+O", self.add_torrent_files, "Open one or more .torrent files")
        self.act_magnet = action("Add Magnet", "Ctrl+Shift+O", lambda: self.add_magnet(), "Paste magnet links")
        self.act_create = action("Create Torrent", "Ctrl+N", self.create_torrent, "Publish a file or folder")
        bar.addSeparator()
        self.act_start = action("Start", "Ctrl+S", self.transfers_page.start_selected, "Start the selected transfers")
        self.act_pause = action("Pause", "Ctrl+P", self.transfers_page.pause_selected, "Pause the selected transfers")
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        bar.addWidget(spacer)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search transfers")
        self.search.setClearButtonEnabled(True)
        self.search.setFixedWidth(260)
        self.search.setAccessibleName("Search transfers")
        self.search.textChanged.connect(self.transfers_page.set_search)
        bar.addWidget(self.search)

    def _build_statusbar(self) -> None:
        status = self.statusBar()
        status.setSizeGripEnabled(False)
        self.st_speed = QLabel()
        self.st_active = QLabel()
        self.st_network = QLabel()
        self.st_queue = QLabel()
        self.st_wallet = QLabel("Wallet: not configured")
        self.st_event = QLabel("")
        self.st_event.setAccessibleName("Latest event")
        self._event_timer = QTimer(self)
        self._event_timer.setSingleShot(True)
        self._event_timer.timeout.connect(lambda: self.st_event.setText(""))
        for label, name in ((self.st_speed, "Transfer speeds"), (self.st_active, "Active transfers"),
                            (self.st_network, "Connectivity"), (self.st_queue, "Queue"),
                            (self.st_wallet, "Wallet connection")):
            label.setAccessibleName(name)
        status.addWidget(self.st_speed)
        status.addWidget(self.st_active)
        status.addWidget(self.st_network, 1)
        status.addPermanentWidget(self.st_event)
        status.addPermanentWidget(self.st_queue)
        status.addPermanentWidget(self.st_wallet)

    def _build_shortcuts(self) -> None:
        keys = ["all", "downloading", "seeding", "completed", "paused", "checking", "errors", "feeds", "publish"]
        for number, key in enumerate(keys, start=1):
            QShortcut(QKeySequence(f"Ctrl+{number}"), self, activated=lambda k=key: self.navigate(k))
        QShortcut(QKeySequence("Ctrl+0"), self, activated=lambda: self.navigate("payments"))
        QShortcut(QKeySequence("Ctrl+,"), self, activated=lambda: self.navigate("settings"))
        QShortcut(QKeySequence("Ctrl+F"), self, activated=self._focus_search)
        QShortcut(QKeySequence("Ctrl+Q"), self, activated=self.close)
        QShortcut(QKeySequence("F6"), self, activated=lambda: self._cycle_focus(1))
        QShortcut(QKeySequence("Shift+F6"), self, activated=lambda: self._cycle_focus(-1))
        QShortcut(QKeySequence("Alt+Right"), self, activated=lambda: self._step_tab(1))
        QShortcut(QKeySequence("Alt+Left"), self, activated=lambda: self._step_tab(-1))
        QShortcut(QKeySequence("F5"), self, activated=self.feeds_page.refresh_selected)
        QShortcut(QKeySequence("Ctrl+V"), self.transfers_page.table, activated=self._paste)

    def _focus_search(self) -> None:
        self.navigate("all") if self.stack.currentWidget() is not self.transfers_page else None
        self.search.setFocus()
        self.search.selectAll()

    def _cycle_focus(self, step: int) -> None:
        targets = [self.nav]
        if self.stack.currentWidget() is self.transfers_page:
            targets += [self.transfers_page.table, self.transfers_page.tabs]
        else:
            targets.append(self.stack.currentWidget())
        focused = QApplication.focusWidget()
        index = 0
        for i, widget in enumerate(targets):
            if focused is widget or (focused is not None and widget.isAncestorOf(focused)):
                index = (i + step) % len(targets)
                break
        target = targets[index]
        target.setFocus(Qt.FocusReason.ShortcutFocusReason)
        if target is self.stack.currentWidget():
            target.focusNextChild()

    def _step_tab(self, step: int) -> None:
        tabs = self.transfers_page.tabs
        tabs.setCurrentIndex((tabs.currentIndex() + step) % tabs.count())

    def apply_theme(self) -> None:
        ui = self.ctx.settings.get().ui
        self.palette_ = palette_for(ui.theme, self._system_dark())
        from .themes.theme import arrow_icons

        try:
            arrows = arrow_icons(self.ctx.paths.data_dir / "cache" / "theme", self.palette_)
        except Exception:
            arrows = None
        QApplication.instance().setStyleSheet(stylesheet(self.palette_, ui.density, arrows))
        self.transfers_page.set_palette(self.palette_)
        self.transfers_page.set_density(ui.density)
        self.brand_line.setVisible(ui.show_brand_line)
        reduce = ui.reduced_motion == "on" or (ui.reduced_motion == "system" and _system_reduced_motion())
        # Subtle motion only: Qt's animated widget effects are switched off entirely when reduced.
        from PySide6.QtCore import Qt as _Qt

        for effect in (_Qt.UIEffect.UI_AnimateMenu, _Qt.UIEffect.UI_AnimateCombo, _Qt.UIEffect.UI_AnimateTooltip,
                       _Qt.UIEffect.UI_FadeMenu, _Qt.UIEffect.UI_FadeTooltip, _Qt.UIEffect.UI_AnimateToolBox):
            QApplication.setEffectEnabled(effect, not reduce)
        for page in (self.feeds_page, self.publish_page, self.payments_page):
            if hasattr(page, "set_palette"):
                page.set_palette(self.palette_)

    # ------------------------------------------------------------ navigation
    def navigate(self, key: str) -> None:
        item = self._nav_items.get(key)
        if item is not None:
            self.nav.setCurrentItem(item)

    def _on_nav(self, item: QListWidgetItem | None, _previous=None) -> None:
        if item is None:
            return
        key = item.data(Qt.ItemDataRole.UserRole)
        if key in TRANSFER_FILTERS:
            self.transfers_page.set_filter(key)
            self.stack.setCurrentWidget(self.transfers_page)
        elif key == "feeds":
            self.stack.setCurrentWidget(self.feeds_page)
            self.feeds_page.activate()
        elif key == "publish":
            self.stack.setCurrentWidget(self.publish_page)
            self.publish_page.activate()
        elif key == "payments":
            self.stack.setCurrentWidget(self.payments_page)
            self.payments_page.activate()
        elif key == "settings":
            self.stack.setCurrentWidget(self.settings_page)
            self.settings_page.activate()
        self.search.setEnabled(key in TRANSFER_FILTERS)
        self._update_actions()

    def _show_transfer(self, transfer_id: str) -> None:
        self.navigate("all")
        QTimer.singleShot(700, lambda: self.transfers_page.select(transfer_id))

    def _update_actions(self) -> None:
        on_transfers = self.stack.currentWidget() is self.transfers_page
        has = on_transfers and bool(self.transfers_page.selected_ids())
        self.act_start.setEnabled(has)
        self.act_pause.setEnabled(has)

    def show_message(self, level: str, text: str) -> None:
        self.banner.show_message(level, text)

    def _show_startup_notes(self) -> None:
        notes = list(dict.fromkeys(self.ctx.startup_notes))
        if not self.ctx.secrets.persistent:
            notes.append("No operating-system credential store is available: backend credentials entered in "
                         "Settings are kept for this session only and are never written to disk.")
        if notes:
            self.show_message("error" if any("unreadable" in n or "missing" in n for n in notes) else "info",
                              "\n".join(notes[:6]))

    # --------------------------------------------------------------- polling
    def _poll(self) -> None:
        if self._snapshot_busy or self._closing:
            return
        self._snapshot_busy = True
        self.bridge.run(self.ctx.transfers.snapshot, self._apply_snapshot,
                        lambda exc: setattr(self, "_snapshot_busy", False))

    def _apply_snapshot(self, result) -> None:
        self._snapshot_busy = False
        _version, views, session = result
        self.transfers_page.apply_views(views)
        counts = filter_counts(views)
        for key, label in NAV:
            if key in TRANSFER_FILTERS:
                count = counts.get(key, 0)
                self._nav_items[key].setText(f"{label}   {count}" if count else label)
        self.st_speed.setText(f"↓ {format_rate_always(session.download_rate)}   ↑ {format_rate_always(session.upload_rate)}")
        self.st_active.setText(f"{session.active} active of {session.total}")
        if not session.engine_running:
            network = "Engine starting…"
        elif session.fault:
            network = "Networking stopped — bound interface unavailable"
        else:
            parts = [f"Listening on port {session.listen_port}" if session.listening else "Not listening"]
            parts.append(f"DHT: {session.dht_nodes} nodes" if session.dht_enabled else "DHT off")
            parts.append("incoming connections seen" if session.has_incoming else "no incoming connections yet")
            if session.port_mapping:
                parts.append(session.port_mapping)
            network = " · ".join(parts)
        self.st_network.setText(network)
        queue = f"Queue: {session.queued} waiting"
        if session.paused:
            queue += " · all paused" + (f" by schedule “{session.schedule}”" if session.schedule else "")
        elif session.schedule:
            queue += f" · schedule “{session.schedule}” active"
        self.st_queue.setText(queue)
        self._update_actions()

    def _poll_wallet(self) -> None:
        if self._closing:
            return

        def done(status) -> None:
            if not status.configured:
                text = "Wallet: not configured"
            elif status.connected:
                text = f"Wallet: connected ({status.alias or status.name}, {status.network})"
                if not status.network_matches:
                    text += " — network mismatch"
            else:
                text = "Wallet: backend unreachable"
            self.st_wallet.setText(text)
            self.st_wallet.setToolTip(status.message or text)

        self.bridge.run(self.ctx.payments.backend_status, done, lambda exc: None)

    def _on_notification(self, kind: str, payload) -> None:
        if kind == "preview_ready":
            self.review_preview(payload["transfer_id"])
        elif kind == "error":
            self.show_message("error", payload.get("message", "An error occurred."))
        elif kind == "info":
            self.show_message("info", payload.get("message", ""))
        elif kind == "export_done":
            self.show_message("info", f"Torrent file saved to {payload.get('path')}")
        elif kind == "engine_fault":
            self.show_message("error" if payload.get("stopped") else "info", payload.get("message", ""))
        elif kind == "finished":
            self.st_event.setText(f"Completed and verified: {payload.get('name', '')}")
            self._event_timer.start(10_000)

    # --------------------------------------------------------- add transfers
    def _defaults(self) -> dict:
        general = self.ctx.settings.get().general
        return {"save_path": self.ctx.transfers.default_save_path(), "categories": list(general.categories),
                "add_paused": general.add_paused}

    def add_torrent_files(self, paths: list[str] | None = None) -> None:
        if not paths:
            paths, _ = QFileDialog.getOpenFileNames(self, "Add torrent files", "", "Torrent files (*.torrent);;All files (*)")
        if not paths:
            return
        self._pending_files.extend(paths)
        if len(self._pending_files) == len(paths):
            self._next_file()

    def _next_file(self) -> None:
        if not self._pending_files:
            return
        path = self._pending_files[0]

        def load():
            if os.path.getsize(path) > MAX_TORRENT_FILE:
                raise AddRejected("This file is too large to be a torrent file.")
            with open(path, "rb") as fh:
                data = fh.read()
            metadata = self.ctx.transfers.inspect_torrent(data)
            return data, metadata, self.ctx.transfers.find_duplicate(metadata.identity)

        def loaded(result) -> None:
            data, metadata, duplicate = result
            if duplicate is not None:
                self.show_message("info", f"“{duplicate.name}” is already in your transfers; nothing was added.")
                self._show_transfer(duplicate.id)
                return self._file_done()
            if metadata.path_problems:
                self.show_message("error", f"“{metadata.name}” was refused because its file list is unsafe: "
                                           + "; ".join(metadata.path_problems[:3]))
                return self._file_done()
            dialog = TorrentReviewDialog(metadata, parent=self, **self._defaults())
            if dialog.exec():
                values = dialog.values()

                def add():
                    outcome = self.ctx.transfers.add_torrent_data(data, source="file", **values)
                    self.ctx.note_added_torrent(outcome.transfer_id)
                    return outcome

                self.bridge.run(add, lambda outcome: self._show_transfer(outcome.transfer_id),
                                lambda exc: self.show_message("error", str(exc)))
            self._file_done()

        def failed(exc) -> None:
            self.show_message("error", f"{os.path.basename(path)}: {exc}")
            self._file_done()

        self.bridge.run(load, loaded, failed)

    def _file_done(self) -> None:
        if self._pending_files:
            self._pending_files.pop(0)
        if self._pending_files:
            QTimer.singleShot(0, self._next_file)

    def add_magnet(self, initial: str = "") -> None:
        general = self.ctx.settings.get().general
        if not initial:
            clip = QGuiApplication.clipboard().text().strip()
            if looks_like_magnet(clip) and len(clip) < 8192:
                initial = clip
        dialog = AddMagnetDialog(initial=initial, preview_default=general.preview_magnets, parent=self,
                                 **self._defaults())
        if not dialog.exec():
            return
        values = dialog.values()
        links = values.pop("links")
        if not links:
            return

        def add():
            results = []
            for link in links:
                try:
                    results.append((link, self.ctx.transfers.add_magnet(link, source="magnet", **values), None))
                except AddRejected as exc:
                    results.append((link, None, str(exc)))
            return results

        def done(results) -> None:
            errors = [err for _, _, err in results if err]
            dups = [o for _, o, _ in results if o and not o.created]
            added = [o for _, o, _ in results if o and o.created]
            lines = []
            if added:
                lines.append(f"{len(added)} magnet link(s) added"
                             + (" — retrieving metadata for review." if values["preview"] else "."))
            if dups:
                lines.append(f"{len(dups)} already in your transfers.")
            lines.extend(errors[:4])
            self.show_message("error" if errors else "info", "\n".join(lines))
            if added:
                self._show_transfer(added[0].transfer_id)

        self.bridge.run(add, done)

    def _paste(self) -> None:
        text = QGuiApplication.clipboard().text().strip()
        if looks_like_magnet(text):
            self.add_magnet(text)

    def review_preview(self, transfer_id: str) -> None:
        if transfer_id in self._review_open:
            return

        def loaded(result) -> None:
            record, metadata = result
            if record is None or metadata is None or not record.preview or transfer_id in self._review_open:
                return
            self._review_open.add(transfer_id)
            defaults = self._defaults()
            defaults["save_path"] = record.save_path or defaults["save_path"]
            dialog = TorrentReviewDialog(metadata, title="Review magnet contents", parent=self, **defaults)
            dialog.category.setCurrentText(record.category)
            accepted = dialog.exec()
            self._review_open.discard(transfer_id)
            if accepted:
                values = dialog.values()
                self.bridge.run(lambda: self.ctx.transfers.confirm_preview(transfer_id, **values), None,
                                lambda exc: self.show_message("error", str(exc)))
            else:
                self.show_message("info", "The magnet stays in your list without downloading. Double-click it to "
                                          "review again, or remove it.")

        self.bridge.run(lambda: (self.ctx.transfers.record(transfer_id), self.ctx.transfers.metadata(transfer_id)),
                        loaded)

    def create_torrent(self) -> None:
        self.navigate("publish")
        self.publish_page.new_publication()

    def _support_publisher(self, transfer_id: str, kind: str) -> None:
        self.navigate("payments")
        self.payments_page.support_publisher(transfer_id, kind)

    def open_arguments(self, arguments: list[str]) -> None:
        """Handle .torrent paths and magnet URIs passed by the OS (file / URI association)."""
        files = [a for a in arguments if not looks_like_magnet(a) and os.path.isfile(a)]
        magnets = [a for a in arguments if looks_like_magnet(a)]
        if files:
            self.add_torrent_files(files)
        if magnets:
            self.add_magnet("\n".join(magnets[:20]))

    # ----------------------------------------------------------- drag & drop
    def dragEnterEvent(self, event) -> None:
        mime = event.mimeData()
        if mime.hasUrls() or (mime.hasText() and looks_like_magnet(mime.text())):
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:
        mime = event.mimeData()
        files, magnets = [], []
        for url in mime.urls():
            if url.isLocalFile() and url.toLocalFile().lower().endswith(".torrent"):
                files.append(url.toLocalFile())
            elif url.scheme() == "magnet":
                magnets.append(url.toString())
        if mime.hasText() and looks_like_magnet(mime.text()):
            magnets.append(mime.text().strip())
        event.acceptProposedAction()
        if files:
            self.add_torrent_files(files)
        if magnets:
            self.add_magnet("\n".join(dict.fromkeys(magnets)))

    # -------------------------------------------------------------- shutdown
    def closeEvent(self, event) -> None:
        if self._shutdown_done:
            event.accept()
            return
        event.ignore()
        if self._closing:
            return
        self._closing = True
        self._timer.stop()
        self._wallet_timer.stop()
        self.setEnabled(False)
        self.st_event.setText("Saving transfer state…")

        def finished(report) -> None:
            self._shutdown_done = True
            if report is not None and not report.clean:
                QMessageBox.warning(self, "AUREOM TORRENT",
                                    report.message or "Some transfer state could not be saved before closing.")
            self.bridge.close()
            self.close()

        import threading

        holder: dict = {}

        def work() -> None:
            try:
                holder["report"] = self.ctx.shutdown()
            except Exception as exc:  # still close, but say so
                from ..engine.events import ShutdownReport

                holder["report"] = ShutdownReport(clean=False, message=f"Shutdown error: {exc}")

        thread = threading.Thread(target=work, name="aureom-shutdown", daemon=True)
        thread.start()

        def check() -> None:
            if thread.is_alive():
                QTimer.singleShot(100, check)
            else:
                finished(holder.get("report"))

        QTimer.singleShot(100, check)


def _system_reduced_motion() -> bool:
    """Best-effort detection of the platform's reduced-motion preference.

    Windows exposes it through SystemParametersInfo; elsewhere Qt has no portable
    query, so the explicit setting (or ``AUREOM_REDUCED_MOTION=1``) is used.
    """
    if os.environ.get("AUREOM_REDUCED_MOTION") == "1":
        return True
    if os.name == "nt":
        try:
            import ctypes

            enabled = ctypes.c_int(1)
            if ctypes.windll.user32.SystemParametersInfoW(0x1042, 0, ctypes.byref(enabled), 0):  # CLIENTAREAANIMATION
                return not bool(enabled.value)
        except Exception:
            return False
    return False
