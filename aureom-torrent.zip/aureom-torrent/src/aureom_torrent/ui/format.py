"""Display formatting helpers (pure functions; unit-tested)."""

from __future__ import annotations

import time

_UNITS = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")


def format_size(value: int | None) -> str:
    if value is None or value < 0:
        return "—"
    size = float(value)
    for unit in _UNITS:
        if size < 1024 or unit == _UNITS[-1]:
            if unit == "B":
                return f"{int(size)} B"
            return f"{size:.1f} {unit}" if size < 100 else f"{size:.0f} {unit}"
        size /= 1024
    return "—"


def format_rate(value: int) -> str:
    return "" if value <= 0 else format_size(value) + "/s"


def format_rate_always(value: int) -> str:
    return format_size(max(0, value)) + "/s"


def format_progress(ppm: int) -> str:
    """Never rounds an unfinished transfer up to 100 %."""
    if ppm >= 1_000_000:
        return "100%"
    return f"{min(ppm, 999_999) / 10_000:.1f}%".replace("100.0%", "99.9%")


def format_eta(seconds: int | None) -> str:
    if seconds is None:
        return ""
    if seconds < 60:
        return f"{seconds}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {sec:02d}s"
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours}h {minutes:02d}m"
    days, hours = divmod(hours, 24)
    return f"{days}d {hours}h"


def format_ratio(permille: int | None) -> str:
    if permille is None:
        return "—"
    return f"{permille // 1000}.{permille % 1000 // 10:02d}"


def format_time(ts: int | float | None) -> str:
    if not ts:
        return "—"
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))


def format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "—"
    return format_eta(seconds)


def parse_rate_kib(text: str) -> int:
    """KiB/s text → bytes/s (0 = unlimited)."""
    try:
        return max(0, int(float(text.strip() or "0") * 1024))
    except ValueError:
        return 0
