"""Settings, privacy explanations, diagnostics and keyboard shortcuts."""

from __future__ import annotations

import time

from PySide6.QtCore import Qt, QTime, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget, QPlainTextEdit, QPushButton,
                               QScrollArea, QSpinBox, QTabWidget, QTimeEdit, QVBoxLayout, QWidget)

from ..settings.models import BandwidthSchedule
from ..settings.secrets import SECRET_BT_PROXY_PASSWORD, SECRET_LND_MACAROON
from .transfers.dialogs import DestinationRow, muted, note

DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

PRIVACY_TEXT = """\
What other parties can see

• Peers. Every peer you exchange data with, and every tracker or DHT node you contact, can ordinarily see your \
IP address and which torrent you are participating in. This is how BitTorrent works.
• Protocol encryption obscures the traffic between two peers. It does not hide your IP address and does not \
provide anonymity.
• Magnet links. Retrieving a magnet's metadata (including the metadata-only preview) contacts peers, so they \
learn your address before you have decided to download anything.
• Private torrents. For a torrent marked private, the engine does not use DHT, peer exchange or local discovery; \
this application never overrides that.

Proxies are configured per service

• The BitTorrent proxy applies to peer and tracker connections made by the transfer engine only. When a proxy is \
set, local peer discovery and port mapping are switched off; with an HTTP proxy, DHT and uTP are switched off too, \
because they cannot be carried by it. A proxy failure is an error – there is no silent direct fallback.
• RSS, publishing and payment traffic do NOT use the BitTorrent proxy. Each has its own setting on the \
“Service networks” tab; left empty, that service connects directly.
• Host names are resolved before the destination check for RSS/publishing requests; when a proxy is configured \
the proxy resolves them.

Binding to a network interface

• When a network interface is selected, the engine listens on it and makes its outgoing connections from the \
same sockets. If the interface disappears (for example a VPN drops), BitTorrent networking is stopped until it \
returns. This is a safeguard, not a guarantee: name resolution, RSS, publishing and payment traffic are not \
bound to the interface, and operating-system routing rules ultimately decide where packets go.

Payments

• On-chain Bitcoin transactions are public and permanent: amounts, addresses and timing are visible to everyone.
• Requesting a Lightning tip invoice contacts the publisher's payment server.
• Backend credentials are stored in the operating system's credential store, never in the database, logs, \
diagnostics or exported pages.

Remote control of this application is not available in this release.
"""


def _scroll(widget: QWidget) -> QScrollArea:
    """Scrollable page whose content keeps its natural height (extra space stays empty below)."""
    area = QScrollArea()
    area.setWidgetResizable(True)
    body = QWidget()
    body.setObjectName("scrollBody")
    box = QVBoxLayout(body)
    box.setContentsMargins(0, 0, 0, 0)
    box.addWidget(widget)
    box.addStretch(1)
    area.setWidget(body)
    return area


def _rate_box(value: int) -> QSpinBox:
    box = QSpinBox()
    box.setRange(0, 10_000_000)
    box.setSuffix(" KiB/s")
    box.setSpecialValueText("Unlimited")
    box.setValue(value // 1024)
    return box


class ScheduleDialog(QDialog):
    def __init__(self, schedule: BandwidthSchedule, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Bandwidth schedule")
        form = QFormLayout(self)
        self.name = QLineEdit(schedule.name)
        form.addRow("&Name:", self.name)
        self.enabled = QCheckBox("Enabled")
        self.enabled.setChecked(schedule.enabled)
        form.addRow("", self.enabled)
        days = QHBoxLayout()
        self.days = []
        for i, label in enumerate(DAYS):
            box = QCheckBox(label)
            box.setChecked(i in schedule.days)
            self.days.append(box)
            days.addWidget(box)
        form.addRow("Days:", days)
        self.start = QTimeEdit(QTime(schedule.start_minute // 60, schedule.start_minute % 60))
        self.end = QTimeEdit(QTime(schedule.end_minute // 60, schedule.end_minute % 60))
        for edit in (self.start, self.end):
            edit.setDisplayFormat("HH:mm")
        form.addRow("&From:", self.start)
        form.addRow("&Until:", self.end)
        self.down = _rate_box(schedule.download_limit)
        self.up = _rate_box(schedule.upload_limit)
        form.addRow("&Download limit:", self.down)
        form.addRow("&Upload limit:", self.up)
        self.pause = QCheckBox("Pause all transfers during this period")
        self.pause.setChecked(schedule.pause_all)
        form.addRow("", self.pause)
        form.addRow(muted("The same start and end time means the whole day. A period may run past midnight. "
                          "Transfers you paused yourself stay paused when the period ends."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def schedule(self) -> BandwidthSchedule:
        return BandwidthSchedule(
            name=self.name.text().strip() or "Schedule", enabled=self.enabled.isChecked(),
            days=[i for i, box in enumerate(self.days) if box.isChecked()],
            start_minute=self.start.time().hour() * 60 + self.start.time().minute(),
            end_minute=self.end.time().hour() * 60 + self.end.time().minute(),
            download_limit=self.down.value() * 1024, upload_limit=self.up.value() * 1024,
            pause_all=self.pause.isChecked())


class NetworkBox(QWidget):
    """Editor for one HttpServiceNetwork section."""

    def __init__(self, title: str, explanation: str, parent=None):
        super().__init__(parent)
        form = QFormLayout(self)
        heading = QLabel(title)
        heading.setProperty("role", "subheading")
        form.addRow(heading)
        form.addRow(muted(explanation))
        self.proxy = QLineEdit()
        self.proxy.setPlaceholderText("direct connection — or socks5://127.0.0.1:9050, http://proxy:3128")
        self.proxy.setAccessibleName(f"{title} proxy address")
        form.addRow("Proxy:", self.proxy)
        self.timeout = QSpinBox()
        self.timeout.setRange(2, 300)
        self.timeout.setSuffix(" s")
        form.addRow("Timeout:", self.timeout)
        self.max_kib = QSpinBox()
        self.max_kib.setRange(1, 65_536)
        self.max_kib.setSuffix(" KiB")
        form.addRow("Largest response accepted:", self.max_kib)
        self.loopback = QCheckBox("Allow addresses on this computer (loopback)")
        self.private = QCheckBox("Allow private-network addresses")
        self.http = QCheckBox("Allow unencrypted http")
        form.addRow("", self.loopback)
        form.addRow("", self.private)
        form.addRow("", self.http)

    def load(self, net) -> None:
        self.proxy.setText(net.proxy_url)
        self.timeout.setValue(net.timeout_s)
        self.max_kib.setValue(max(1, net.max_response_bytes // 1024))
        self.loopback.setChecked(net.allow_loopback)
        self.private.setChecked(net.allow_private)
        self.http.setChecked(net.allow_http)

    def store(self, net) -> None:
        net.proxy_url = self.proxy.text().strip()
        net.timeout_s = self.timeout.value()
        net.max_response_bytes = self.max_kib.value() * 1024
        net.allow_loopback = self.loopback.isChecked()
        net.allow_private = self.private.isChecked()
        net.allow_http = self.http.isChecked()


class SettingsPage(QWidget):
    message = Signal(str, str)
    appearance_changed = Signal()

    def __init__(self, ctx, bridge, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge = ctx, bridge
        self._schedules: list[BandwidthSchedule] = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 8)
        heading = QLabel("Settings")
        heading.setProperty("role", "heading")
        layout.addWidget(heading)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        layout.addWidget(self.tabs, 1)
        self._general()
        self._queue()
        self._bittorrent()
        self._services()
        self._payments()
        self._appearance()
        self._privacy()
        self._diagnostics()
        self._shortcuts()
        row = QHBoxLayout()
        self.saved_label = muted("")
        save = QPushButton("&Save settings")
        save.setProperty("role", "primary")
        save.clicked.connect(self.save)
        revert = QPushButton("&Revert")
        revert.clicked.connect(self.load)
        row.addWidget(self.saved_label, 1)
        row.addWidget(revert)
        row.addWidget(save)
        layout.addLayout(row)
        self.load()

    # ------------------------------------------------------------------ tabs
    def _general(self) -> None:
        w = QWidget()
        form = QFormLayout(w)
        self.default_path = DestinationRow("")
        form.addRow("Default &destination:", self.default_path)
        self.categories = QLineEdit()
        self.categories.setPlaceholderText("comma-separated, e.g. Software, Documents")
        form.addRow("&Categories:", self.categories)
        self.add_paused = QCheckBox("Add new transfers &paused")
        self.preview_magnets = QCheckBox("Preview &magnet links before downloading (metadata only)")
        form.addRow("", self.add_paused)
        form.addRow("", self.preview_magnets)
        self.resume_interval = QSpinBox()
        self.resume_interval.setRange(10, 3600)
        self.resume_interval.setSuffix(" s")
        form.addRow("Save &resume data every:", self.resume_interval)
        self.shutdown_timeout = QSpinBox()
        self.shutdown_timeout.setRange(2, 120)
        self.shutdown_timeout.setSuffix(" s")
        form.addRow("Wait at most this long when &closing:", self.shutdown_timeout)
        form.addRow(muted("If resume data cannot be written within the closing time limit you are told which "
                          "transfers are affected; they are re-checked at the next start."))
        self.tabs.addTab(_scroll(w), "General")

    def _queue(self) -> None:
        w = QWidget()
        form = QFormLayout(w)
        self.max_down = QSpinBox()
        self.max_seed = QSpinBox()
        self.max_total = QSpinBox()
        for box in (self.max_down, self.max_seed, self.max_total):
            box.setRange(-1, 2000)
            box.setSpecialValueText("Unlimited")
        form.addRow("Active &downloads:", self.max_down)
        form.addRow("Active &seeds:", self.max_seed)
        form.addRow("Active transfers in &total:", self.max_total)
        self.global_down = _rate_box(0)
        self.global_up = _rate_box(0)
        form.addRow("Global d&ownload limit:", self.global_down)
        form.addRow("Global &upload limit:", self.global_up)
        self.ratio = QSpinBox()
        self.ratio.setRange(-1, 100_000)
        self.ratio.setSuffix(" %")
        self.ratio.setSpecialValueText("No ratio limit")
        form.addRow("Stop seeding at share &ratio:", self.ratio)
        self.seed_minutes = QSpinBox()
        self.seed_minutes.setRange(-1, 1_000_000)
        self.seed_minutes.setSuffix(" min")
        self.seed_minutes.setSpecialValueText("No time limit")
        form.addRow("Stop seeding &after:", self.seed_minutes)
        self.schedule_list = QListWidget()
        self.schedule_list.setMaximumHeight(120)
        self.schedule_list.setAccessibleName("Bandwidth schedules")
        form.addRow("Bandwidth schedules:", self.schedule_list)
        row = QHBoxLayout()
        for text, slot in (("&Add…", self._add_schedule), ("&Edit…", self._edit_schedule), ("Re&move", self._remove_schedule)):
            button = QPushButton(text)
            button.clicked.connect(slot)
            row.addWidget(button)
        row.addStretch(1)
        form.addRow("", row)
        form.addRow(note("Queueing is done by the transfer engine. A transfer you pause yourself is never started "
                         "by the queue or by a schedule, and that choice is remembered across restarts. Per-transfer "
                         "limits (right-click a transfer → Limits…) override these."))
        self.tabs.addTab(_scroll(w), "Queue && limits")

    def _bittorrent(self) -> None:
        w = QWidget()
        form = QFormLayout(w)
        self.port = QSpinBox()
        self.port.setRange(0, 65535)
        self.port.setSpecialValueText("Chosen by the system")
        form.addRow("Listening &port:", self.port)
        self.listen_address = QLineEdit()
        self.listen_address.setPlaceholderText("all IPv4 and IPv6 addresses")
        form.addRow("Listening &address:", self.listen_address)
        self.bind_interface = QLineEdit()
        self.bind_interface.setPlaceholderText("none — e.g. tun0, wg0 or an IP address")
        form.addRow("&Bind to network interface:", self.bind_interface)
        self.dht = QCheckBox("&DHT (find peers without a tracker)")
        self.pex = QCheckBox("Peer e&xchange (takes effect at the next start)")
        self.lsd = QCheckBox("&Local peer discovery (announces on your local network)")
        self.upnp = QCheckBox("&UPnP port mapping")
        self.natpmp = QCheckBox("&NAT-PMP port mapping")
        for box in (self.dht, self.pex, self.lsd, self.upnp, self.natpmp):
            form.addRow("", box)
        self.encryption = QComboBox()
        self.encryption.addItem("Allow encrypted and unencrypted connections", "enabled")
        self.encryption.addItem("Require encrypted connections", "forced")
        self.encryption.addItem("Disable protocol encryption", "disabled")
        form.addRow("Protocol &encryption:", self.encryption)
        self.max_connections = QSpinBox()
        self.max_connections.setRange(2, 10_000)
        form.addRow("Maximum &connections:", self.max_connections)
        self.proxy_kind = QComboBox()
        for label, value in (("No proxy", "none"), ("SOCKS5", "socks5"), ("SOCKS5 with password", "socks5_pw"),
                             ("HTTP", "http"), ("HTTP with password", "http_pw")):
            self.proxy_kind.addItem(label, value)
        form.addRow("BitTorrent pro&xy:", self.proxy_kind)
        self.proxy_host = QLineEdit()
        self.proxy_port = QSpinBox()
        self.proxy_port.setRange(0, 65535)
        host_row = QHBoxLayout()
        host_row.addWidget(self.proxy_host, 1)
        host_row.addWidget(self.proxy_port)
        form.addRow("Proxy host and port:", host_row)
        self.proxy_user = QLineEdit()
        form.addRow("Proxy user name:", self.proxy_user)
        self.proxy_password = QLineEdit()
        self.proxy_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.proxy_password.setPlaceholderText("leave empty to keep the stored password")
        form.addRow("Proxy password:", self.proxy_password)
        self.proxy_peers = QCheckBox("Use the proxy for peer connections")
        self.proxy_trackers = QCheckBox("Use the proxy for tracker connections")
        self.proxy_hostnames = QCheckBox("Let the proxy resolve host names")
        for box in (self.proxy_peers, self.proxy_trackers, self.proxy_hostnames):
            form.addRow("", box)
        form.addRow(note("Private torrents never use DHT, peer exchange or local discovery, whatever is selected "
                         "here. The proxy on this page covers BitTorrent traffic only — see “Service networks” "
                         "and “Privacy”. With a proxy, local discovery and port mapping are switched off; with an "
                         "HTTP proxy, DHT and uTP as well."))
        self.tabs.addTab(_scroll(w), "BitTorrent network")

    def _services(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(note("Each service has its own network settings. A proxy set for BitTorrent is not used "
                              "here, and a proxy set here is not used for BitTorrent. If a proxy is configured "
                              "and fails, the request fails; it is never retried directly."))
        self.net_feeds = NetworkBox("RSS / Atom feeds", "Feed refreshes and .torrent files fetched from feed entries.")
        self.net_publish = NetworkBox("Publishing", "Uploads to a publishing destination you configured and "
                                                     "downloads of external publisher manifests.")
        self.net_payments = NetworkBox("Payment backend", "Connections to the Lightning node you configured. "
                                                          "Loopback/private addresses are allowed here because a "
                                                          "node usually runs on this computer or network; requests "
                                                          "to a publisher's tip server never use that allowance.")
        for box in (self.net_feeds, self.net_publish, self.net_payments):
            layout.addWidget(box)
        layout.addStretch(1)
        self.tabs.addTab(_scroll(w), "Service networks")

    def _payments(self) -> None:
        w = QWidget()
        form = QFormLayout(w)
        self.backend = QComboBox()
        self.backend.addItem("None — payments off (transfers are unaffected)", "none")
        self.backend.addItem("LND (REST API)", "lnd_rest")
        form.addRow("Lightning &backend:", self.backend)
        self.lnd_url = QLineEdit()
        self.lnd_url.setPlaceholderText("https://127.0.0.1:8080")
        form.addRow("LND REST &address:", self.lnd_url)
        cert_row = QHBoxLayout()
        self.lnd_cert = QLineEdit()
        self.lnd_cert.setPlaceholderText("path to the node's tls.cert (PEM)")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._pick_cert)
        cert_row.addWidget(self.lnd_cert, 1)
        cert_row.addWidget(browse)
        form.addRow("TLS certificate:", cert_row)
        mac_row = QHBoxLayout()
        self.macaroon = QLineEdit()
        self.macaroon.setEchoMode(QLineEdit.EchoMode.Password)
        self.macaroon.setPlaceholderText("hex macaroon — leave empty to keep the stored one")
        self.macaroon.setAccessibleName("LND macaroon in hexadecimal")
        forget = QPushButton("Forget stored macaroon")
        forget.clicked.connect(self._forget_macaroon)
        mac_row.addWidget(self.macaroon, 1)
        mac_row.addWidget(forget)
        form.addRow("Macaroon:", mac_row)
        self.macaroon_state = muted("")
        form.addRow("", self.macaroon_state)
        self.network = QComboBox()
        self.network.addItems(["mainnet", "testnet", "signet", "regtest"])
        form.addRow("Expected &network:", self.network)
        self.presets = QLineEdit()
        form.addRow("Tip &presets (sat):", self.presets)
        self.min_pay = QSpinBox()
        self.max_pay = QSpinBox()
        for box in (self.min_pay, self.max_pay):
            box.setRange(1, 2_000_000_000)
            box.setSuffix(" sat")
        form.addRow("Smallest payment:", self.min_pay)
        form.addRow("Largest payment:", self.max_pay)
        self.fee_ppm = QSpinBox()
        self.fee_ppm.setRange(0, 100_000)
        self.fee_ppm.setSuffix(" ppm of the amount")
        form.addRow("Default fee limit:", self.fee_ppm)
        self.fee_floor = QSpinBox()
        self.fee_floor.setRange(0, 100_000)
        self.fee_floor.setSuffix(" sat minimum")
        form.addRow("", self.fee_floor)
        test = QPushButton("&Test connection")
        test.clicked.connect(self._test_backend)
        self.test_result = muted("")
        test_row = QHBoxLayout()
        test_row.addWidget(test)
        test_row.addWidget(self.test_result, 1)
        form.addRow("", test_row)
        form.addRow(note(
            "Use a macaroon limited to what is needed (for example: lncli bakemacaroon info:read invoices:read "
            "invoices:write offchain:read offchain:write) rather than the admin macaroon. The macaroon is stored in "
            f"{self.ctx.secrets.description}. This application never asks for a seed phrase or private key, does "
            "not implement a wallet, and never spends in the background: each payment needs your approval. "
            "Recurring support is not available in this release."))
        self.tabs.addTab(_scroll(w), "Payments")

    def _appearance(self) -> None:
        w = QWidget()
        form = QFormLayout(w)
        self.theme = QComboBox()
        for label, value in (("Light — warm ivory", "light"), ("Dark — midnight", "dark"), ("Follow the system", "system")):
            self.theme.addItem(label, value)
        form.addRow("&Theme:", self.theme)
        self.density = QComboBox()
        self.density.addItem("Compact tables", "compact")
        self.density.addItem("Comfortable spacing", "comfortable")
        form.addRow("Table &density:", self.density)
        self.motion = QComboBox()
        for label, value in (("Follow the system", "system"), ("Reduce motion", "on"), ("Allow subtle motion", "off")):
            self.motion.addItem(label, value)
        form.addRow("&Motion:", self.motion)
        self.brand = QCheckBox("Show the brand line under the application title")
        form.addRow("", self.brand)
        form.addRow(muted("Motion is limited to short menu and tooltip fades; with reduced motion they are turned "
                          "off entirely. Progress bars update in place and do not animate."))
        self.tabs.addTab(_scroll(w), "Appearance")

    def _privacy(self) -> None:
        text = QPlainTextEdit(PRIVACY_TEXT)
        text.setReadOnly(True)
        text.setAccessibleName("Privacy explanations")
        self.tabs.addTab(text, "Privacy")

    def _diagnostics(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)
        caps = self.ctx.engine.capabilities()
        layout.addWidget(muted(f"Transfer engine: {caps.engine} {caps.version}. " + " ".join(caps.notes)))
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(600)
        self.log_view.setAccessibleName("Application log")
        layout.addWidget(self.log_view, 1)
        row = QHBoxLayout()
        refresh = QPushButton("&Refresh log")
        refresh.clicked.connect(self._load_log)
        export = QPushButton("&Export redacted diagnostics…")
        export.clicked.connect(self._export_diagnostics)
        row.addWidget(refresh)
        row.addWidget(export)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addWidget(muted("Logs are bounded in memory and on disk. The log and the diagnostic export are "
                               "redacted: tracker passkeys, URL query strings, credentials, invoices and payment "
                               "secrets are removed."))
        self.tabs.addTab(w, "Diagnostics")

    def _shortcuts(self) -> None:
        from .main_window import SHORTCUTS

        text = QPlainTextEdit("\n".join(f"{keys:<24}{what}" for keys, what in SHORTCUTS)
                              + "\n\nTab and Shift+Tab move between controls; arrow keys move inside tables and "
                                "lists; Space toggles check boxes; the context-menu key opens a row's actions.")
        text.setReadOnly(True)
        font = text.font()
        font.setFamily("monospace")
        text.setFont(font)
        text.setAccessibleName("Keyboard shortcuts")
        self.tabs.addTab(text, "Keyboard shortcuts")

    # -------------------------------------------------------------- load/save
    def activate(self) -> None:
        self._load_log()
        self._refresh_secret_state()

    def load(self) -> None:
        s = self.ctx.settings.snapshot()
        g, q, n, p, ui = s.general, s.queue, s.bittorrent, s.payments, s.ui
        self.default_path.edit.setText(g.default_save_path or self.ctx.transfers.default_save_path())
        self.categories.setText(", ".join(g.categories))
        self.add_paused.setChecked(g.add_paused)
        self.preview_magnets.setChecked(g.preview_magnets)
        self.resume_interval.setValue(g.resume_save_interval_s)
        self.shutdown_timeout.setValue(g.shutdown_timeout_s)
        self.max_down.setValue(q.max_active_downloads)
        self.max_seed.setValue(q.max_active_seeds)
        self.max_total.setValue(q.max_active_total)
        self.global_down.setValue(q.download_limit // 1024)
        self.global_up.setValue(q.upload_limit // 1024)
        self.ratio.setValue(-1 if q.ratio_limit_permille < 0 else q.ratio_limit_permille // 10)
        self.seed_minutes.setValue(q.seed_time_limit_minutes)
        self._schedules = list(q.schedules)
        self._show_schedules()
        self.port.setValue(n.listen_port)
        self.listen_address.setText(n.listen_address)
        self.bind_interface.setText(n.bind_interface)
        self.dht.setChecked(n.enable_dht)
        self.pex.setChecked(n.enable_pex)
        self.lsd.setChecked(n.enable_lsd)
        self.upnp.setChecked(n.enable_upnp)
        self.natpmp.setChecked(n.enable_natpmp)
        self.encryption.setCurrentIndex(max(0, self.encryption.findData(n.encryption)))
        self.max_connections.setValue(n.max_connections)
        self.proxy_kind.setCurrentIndex(max(0, self.proxy_kind.findData(n.proxy.kind)))
        self.proxy_host.setText(n.proxy.host)
        self.proxy_port.setValue(n.proxy.port)
        self.proxy_user.setText(n.proxy.username)
        self.proxy_password.clear()
        self.proxy_peers.setChecked(n.proxy.proxy_peers)
        self.proxy_trackers.setChecked(n.proxy.proxy_trackers)
        self.proxy_hostnames.setChecked(n.proxy.proxy_hostnames)
        self.net_feeds.load(s.feeds_network)
        self.net_publish.load(s.publishing_network)
        self.net_payments.load(s.payments_network)
        self.backend.setCurrentIndex(max(0, self.backend.findData(p.backend)))
        self.lnd_url.setText(p.lnd_url)
        self.lnd_cert.setText(p.lnd_tls_cert_path)
        self.macaroon.clear()
        self.network.setCurrentText(p.expected_network)
        self.presets.setText(", ".join(str(v) for v in p.tip_presets_sat))
        self.min_pay.setValue(p.min_payment_sat)
        self.max_pay.setValue(min(p.max_payment_sat, 2_000_000_000))
        self.fee_ppm.setValue(p.max_fee_ppm)
        self.fee_floor.setValue(p.min_fee_limit_sat)
        self.theme.setCurrentIndex(max(0, self.theme.findData(ui.theme)))
        self.density.setCurrentIndex(max(0, self.density.findData(ui.density)))
        self.motion.setCurrentIndex(max(0, self.motion.findData(ui.reduced_motion)))
        self.brand.setChecked(ui.show_brand_line)
        self.saved_label.setText("")

    def save(self) -> None:
        s = self.ctx.settings.snapshot()
        g, q, n, p, ui = s.general, s.queue, s.bittorrent, s.payments, s.ui
        g.default_save_path = self.default_path.path()
        g.categories = [c.strip() for c in self.categories.text().split(",") if c.strip()]
        g.add_paused = self.add_paused.isChecked()
        g.preview_magnets = self.preview_magnets.isChecked()
        g.resume_save_interval_s = self.resume_interval.value()
        g.shutdown_timeout_s = self.shutdown_timeout.value()
        q.max_active_downloads = self.max_down.value()
        q.max_active_seeds = self.max_seed.value()
        q.max_active_total = self.max_total.value()
        q.download_limit = self.global_down.value() * 1024
        q.upload_limit = self.global_up.value() * 1024
        q.ratio_limit_permille = -1 if self.ratio.value() < 0 else self.ratio.value() * 10
        q.seed_time_limit_minutes = self.seed_minutes.value()
        q.schedules = list(self._schedules)
        n.listen_port = self.port.value()
        n.listen_address = self.listen_address.text().strip()
        n.bind_interface = self.bind_interface.text().strip()
        n.enable_dht = self.dht.isChecked()
        n.enable_pex = self.pex.isChecked()
        n.enable_lsd = self.lsd.isChecked()
        n.enable_upnp = self.upnp.isChecked()
        n.enable_natpmp = self.natpmp.isChecked()
        n.encryption = self.encryption.currentData()
        n.max_connections = self.max_connections.value()
        n.proxy.kind = self.proxy_kind.currentData()
        n.proxy.host = self.proxy_host.text().strip()
        n.proxy.port = self.proxy_port.value()
        n.proxy.username = self.proxy_user.text().strip()
        n.proxy.proxy_peers = self.proxy_peers.isChecked()
        n.proxy.proxy_trackers = self.proxy_trackers.isChecked()
        n.proxy.proxy_hostnames = self.proxy_hostnames.isChecked()
        self.net_feeds.store(s.feeds_network)
        self.net_publish.store(s.publishing_network)
        self.net_payments.store(s.payments_network)
        p.backend = self.backend.currentData()
        p.lnd_url = self.lnd_url.text().strip()
        p.lnd_tls_cert_path = self.lnd_cert.text().strip()
        p.expected_network = self.network.currentText()
        presets = []
        for part in self.presets.text().replace(";", ",").split(","):
            if part.strip().isdigit():
                presets.append(int(part.strip()))
        p.tip_presets_sat = presets
        p.min_payment_sat = self.min_pay.value()
        p.max_payment_sat = self.max_pay.value()
        p.max_fee_ppm = self.fee_ppm.value()
        p.min_fee_limit_sat = self.fee_floor.value()
        ui.theme = self.theme.currentData()
        ui.density = self.density.currentData()
        ui.reduced_motion = self.motion.currentData()
        ui.show_brand_line = self.brand.isChecked()
        macaroon = self.macaroon.text().strip()
        proxy_password = self.proxy_password.text()
        if macaroon and (len(macaroon) % 2 or any(c not in "0123456789abcdefABCDEF" for c in macaroon)):
            self.message.emit("error", "The macaroon must be given as hexadecimal text (for example: "
                                       "xxd -ps -u -c 1000 invoice.macaroon).")
            return

        def work():
            if macaroon:
                self.ctx.secrets.set(SECRET_LND_MACAROON, macaroon.lower())
            if proxy_password:
                self.ctx.secrets.set(SECRET_BT_PROXY_PASSWORD, proxy_password)
            self.ctx.settings.save(s)

        def done(_):
            self.load()  # shows the validated values and clears the secret fields
            self.saved_label.setText(f"Saved at {time.strftime('%H:%M:%S')}.")
            self.appearance_changed.emit()
            self._refresh_secret_state()

        self.bridge.run(work, done, lambda exc: self.message.emit("error", f"Settings could not be saved: {exc}"))

    # --------------------------------------------------------------- helpers
    def _show_schedules(self) -> None:
        self.schedule_list.clear()
        for s in self._schedules:
            days = ", ".join(DAYS[d] for d in s.days) or "no days"
            period = "all day" if s.start_minute == s.end_minute else (
                f"{s.start_minute // 60:02d}:{s.start_minute % 60:02d}–{s.end_minute // 60:02d}:{s.end_minute % 60:02d}")
            effect = "pause all" if s.pause_all else (
                f"↓ {s.download_limit // 1024 or '∞'} / ↑ {s.upload_limit // 1024 or '∞'} KiB/s")
            self.schedule_list.addItem(f"{s.name}{'' if s.enabled else ' (off)'} — {days}, {period}: {effect}")

    def _add_schedule(self) -> None:
        dialog = ScheduleDialog(BandwidthSchedule(name="Evenings", start_minute=18 * 60, end_minute=23 * 60), self)
        if dialog.exec():
            self._schedules.append(dialog.schedule())
            self._show_schedules()

    def _edit_schedule(self) -> None:
        row = self.schedule_list.currentRow()
        if 0 <= row < len(self._schedules):
            dialog = ScheduleDialog(self._schedules[row], self)
            if dialog.exec():
                self._schedules[row] = dialog.schedule()
                self._show_schedules()

    def _remove_schedule(self) -> None:
        row = self.schedule_list.currentRow()
        if 0 <= row < len(self._schedules):
            del self._schedules[row]
            self._show_schedules()

    def _pick_cert(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose the node's TLS certificate", "", "Certificates (*.cert *.pem *.crt);;All files (*)")
        if path:
            self.lnd_cert.setText(path)

    def _refresh_secret_state(self) -> None:
        def done(has: bool) -> None:
            self.macaroon_state.setText(("A macaroon is stored" if has else "No macaroon is stored")
                                        + f" ({self.ctx.secrets.description}).")

        self.bridge.run(lambda: bool(self.ctx.secrets.get(SECRET_LND_MACAROON)), done, lambda exc: None)

    def _forget_macaroon(self) -> None:
        self.bridge.run(lambda: self.ctx.secrets.delete(SECRET_LND_MACAROON), lambda _: self._refresh_secret_state(),
                        lambda exc: self.message.emit("error", str(exc)))

    def _test_backend(self) -> None:
        self.test_result.setText("Save your settings first, then testing uses the saved configuration…")

        def done(status) -> None:
            if not status.configured:
                self.test_result.setText("No backend is configured (save the settings first).")
            elif status.connected:
                self.test_result.setText(f"Connected: “{status.alias}”, {status.network}, LND {status.version}"
                                         + ("" if status.network_matches else " — NETWORK MISMATCH"))
            else:
                self.test_result.setText(f"Not connected: {status.message}")

        self.bridge.run(self.ctx.payments.backend_status, done, lambda exc: self.test_result.setText(str(exc)))

    def _load_log(self) -> None:
        from ..diagnostics.logs import ring_buffer

        entries = ring_buffer().entries(500)
        self.log_view.setPlainText("\n".join(
            f"{time.strftime('%H:%M:%S', time.localtime(e.ts))} {e.level:<7} {e.area}: {e.message}" for e in entries))
        self.log_view.verticalScrollBar().setValue(self.log_view.verticalScrollBar().maximum())

    def _export_diagnostics(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export diagnostics", "aureom-torrent-diagnostics.json", "JSON (*.json)")
        if not path:
            return

        def work():
            text = self.ctx.diagnostics.export_json()
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text)
            return path

        self.bridge.run(work, lambda p: self.message.emit("info", f"Redacted diagnostics written to {p}"),
                        lambda exc: self.message.emit("error", f"Diagnostics could not be exported: {exc}"))
