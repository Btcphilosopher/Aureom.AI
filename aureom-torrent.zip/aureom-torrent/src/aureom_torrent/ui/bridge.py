"""GUI ↔ worker bridge.

The GUI thread never performs disk, database, network or engine work.  It calls
``Bridge.run(fn, on_done)``; ``fn`` runs on a small worker pool and its result
is delivered back on the GUI thread through a queued Qt signal.  Service
notifications raised on worker threads are re-emitted on the GUI thread as
``notified(kind, payload)``.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable

from PySide6.QtCore import QObject, Qt, Signal

log = logging.getLogger(__name__)


class Bridge(QObject):
    _finished = Signal(object, object, object)  # callback, result, error
    notified = Signal(str, object)
    failed = Signal(str)  # an unhandled, user-presentable error message
    progress = Signal(object, object)  # callback, args

    def __init__(self, workers: int = 4, parent: QObject | None = None):
        super().__init__(parent)
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="aureom-worker")
        self._finished.connect(self._deliver, Qt.ConnectionType.QueuedConnection)
        self.progress.connect(lambda cb, args: cb(*args), Qt.ConnectionType.QueuedConnection)
        self._closed = False

    def run(self, fn: Callable[[], Any], on_done: Callable[[Any], None] | None = None,
            on_error: Callable[[Exception], None] | None = None) -> None:
        """Run ``fn`` off the GUI thread; deliver the outcome on the GUI thread."""
        if self._closed:
            return

        def task() -> None:
            try:
                result = fn()
            except Exception as exc:  # delivered to the GUI thread
                if on_error is None:
                    log.info("operation failed: %s: %s", type(exc).__name__, exc)
                self._emit(on_error, None, exc)
            else:
                self._emit(on_done, result, None)

        self._pool.submit(task)

    def _emit(self, callback: Any, result: Any, error: Any) -> None:
        if not self._closed:
            try:
                self._finished.emit(callback, result, error)
            except RuntimeError:
                pass  # the QObject is gone during shutdown

    def _deliver(self, callback: Any, result: Any, error: Any) -> None:
        if error is not None:
            if callback is not None:
                callback(error)
            else:
                self.failed.emit(str(error) or type(error).__name__)
        elif callback is not None:
            callback(result)

    def gui(self, callback: Callable[..., None]) -> Callable[..., None]:
        """Wrap ``callback`` so that it can be called from any thread and runs on the GUI thread."""
        def call(*args: Any) -> None:
            if not self._closed:
                try:
                    self.progress.emit(callback, args)
                except RuntimeError:
                    pass
        return call

    def notify_from_worker(self, kind: str, payload: dict) -> None:
        if not self._closed:
            try:
                self.notified.emit(kind, payload)
            except RuntimeError:
                pass

    def close(self) -> None:
        self._closed = True
        self._pool.shutdown(wait=False, cancel_futures=True)
