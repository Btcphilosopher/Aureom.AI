"""Publish & Share: a step-by-step wizard for creating a torrent, then a sharing screen."""

from __future__ import annotations

import os
import threading

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, QTimer, Signal
from PySide6.QtGui import QGuiApplication, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
                               QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
                               QRadioButton, QScrollArea, QStackedWidget, QTableView, QVBoxLayout, QWidget)

from ...domain.transfers import TransferState
from ...publishing import sharing
from ...publishing.models import PublishDestination, PublishDraft, PublisherInfo
from ..format import format_size, format_time
from ..models.rows import Column, RowsModel
from ..transfers.dialogs import category_combo, muted, note
from ..transfers.page import make_table

STEPS = ["1  Select & review files", "2  Format & piece size", "3  Trackers, web seeds & visibility",
         "4  Publisher details (optional)", "5  Create & save", "6  Share"]


class ScanModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._files: list = []
        self._checked: list[bool] = []

    def set_files(self, files: list) -> None:
        self.beginResetModel()
        self._files = list(files)
        self._checked = [True] * len(files)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._files)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else 2

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return ("Included file", "Size")[section]
        return None

    def flags(self, index):
        flags = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
        return flags | Qt.ItemFlag.ItemIsUserCheckable if index.column() == 0 else flags

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        f = self._files[index.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            return f.relative if index.column() == 0 else format_size(f.size)
        if role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            return Qt.CheckState.Checked if self._checked[index.row()] else Qt.CheckState.Unchecked
        if role == Qt.ItemDataRole.TextAlignmentRole and index.column() == 1:
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        return None

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if index.isValid() and role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            self._checked[index.row()] = value in (Qt.CheckState.Checked, Qt.CheckState.Checked.value, 2)
            self.dataChanged.emit(index, index)
            return True
        return False

    def included(self) -> list:
        return [f for f, on in zip(self._files, self._checked) if on]


class DestinationsDialog(QDialog):
    """Configure where exported artifacts can be published. Tokens go to the credential store only."""

    def __init__(self, ctx, bridge, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge = ctx, bridge
        self.setWindowTitle("Publishing destinations")
        self.resize(620, 420)
        layout = QVBoxLayout(self)
        self.listing = QListWidget()
        layout.addWidget(self.listing, 1)
        form = QFormLayout()
        self.kind = QComboBox()
        self.kind.addItem("Local export folder", "local_dir")
        self.kind.addItem("HTTPS upload endpoint (PUT)", "https_upload")
        self.name = QLineEdit()
        self.target = QLineEdit()
        self.token = QLineEdit()
        self.token.setEchoMode(QLineEdit.EchoMode.Password)
        self.token.setPlaceholderText("bearer token (stored in the credential store, never in the database)")
        form.addRow("&Type:", self.kind)
        form.addRow("&Name:", self.name)
        form.addRow("&Folder or https address:", self.target)
        form.addRow("&Upload token:", self.token)
        layout.addLayout(form)
        layout.addWidget(note(
            "A destination is somewhere *you* control. This application does not provide hosting. An upload that "
            "the server accepts does not prove the page is publicly reachable. An S3-compatible adapter is not "
            f"implemented. Credentials are kept in: {ctx.secrets.description}."))
        row = QHBoxLayout()
        add = QPushButton("&Add destination")
        add.clicked.connect(self._add)
        remove = QPushButton("&Remove selected")
        remove.clicked.connect(self._remove)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row.addWidget(add)
        row.addWidget(remove)
        row.addStretch(1)
        row.addWidget(close)
        layout.addLayout(row)
        self.kind.currentIndexChanged.connect(lambda _: self.token.setEnabled(self.kind.currentData() == "https_upload"))
        self.token.setEnabled(False)
        self._items: list[PublishDestination] = []
        self._load()

    def _error(self, exc) -> None:
        QMessageBox.warning(self, self.windowTitle(), str(exc))

    def _load(self) -> None:
        def done(items) -> None:
            self._items = items
            self.listing.clear()
            for d in items:
                where = d.config.get("directory") or d.config.get("base_url") or ""
                self.listing.addItem(f"{d.name} — {'folder' if d.kind == 'local_dir' else 'HTTPS upload'}: {where}")

        self.bridge.run(self.ctx.publishing.list_destinations, done, self._error)

    def _add(self) -> None:
        kind = self.kind.currentData()
        target = self.target.text().strip()
        config = {"directory": target} if kind == "local_dir" else {"base_url": target}
        name = self.name.text().strip() or ("Export folder" if kind == "local_dir" else "Upload endpoint")
        token = self.token.text() if kind == "https_upload" and self.token.text() else None

        def work():
            problems = self.ctx.publishing.destination_problems(kind, name, config)
            if problems:
                raise ValueError(" ".join(problems))
            return self.ctx.publishing.save_destination(PublishDestination(id="", kind=kind, name=name, config=config),
                                                        token=token)

        def done(_):
            self.token.clear()
            self.target.clear()
            self.name.clear()
            self._load()

        self.bridge.run(work, done, self._error)

    def _remove(self) -> None:
        row = self.listing.currentRow()
        if 0 <= row < len(self._items):
            dest = self._items[row]
            self.bridge.run(lambda: self.ctx.publishing.delete_destination(dest.id), lambda _: self._load(), self._error)


class PublishPage(QWidget):
    message = Signal(str, str)
    go_to_transfer = Signal(str)

    def __init__(self, ctx, bridge, parent=None):
        super().__init__(parent)
        self.ctx, self.bridge = ctx, bridge
        self._scan = None
        self._cancel = threading.Event()
        self._job_id: str | None = None
        self._share = None
        self._hashing = False

        self.steps = QListWidget()
        self.steps.setAccessibleName("Wizard steps")
        self.steps.setFixedWidth(250)
        self.steps.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        for title in STEPS:
            self.steps.addItem(QListWidgetItem(title))
        self.steps.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        self.recent = QListWidget()
        self.recent.setAccessibleName("Recent publications")
        self.recent.itemActivated.connect(self._open_recent)
        self.recent.itemClicked.connect(self._open_recent)
        left = QVBoxLayout()
        heading = QLabel("Publish & Share")
        heading.setProperty("role", "heading")
        left.addWidget(heading)
        left.addWidget(self.steps)
        recent_label = QLabel("Recent publications")
        recent_label.setProperty("role", "subheading")
        left.addWidget(recent_label)
        left.addWidget(self.recent, 1)
        new_button = QPushButton("&New publication")
        new_button.clicked.connect(self.new_publication)
        left.addWidget(new_button)

        self.stack = QStackedWidget()
        for builder in (self._step_select, self._step_format, self._step_trackers, self._step_publisher,
                        self._step_create, self._step_share):
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            body = builder()
            if isinstance(body.layout(), QFormLayout):
                # keep form rows at their natural height; spare space stays below
                holder = QWidget()
                box = QVBoxLayout(holder)
                box.setContentsMargins(0, 0, 0, 0)
                box.addWidget(body)
                box.addStretch(1)
                body = holder
            body.setObjectName("scrollBody")
            scroll.setWidget(body)
            self.stack.addWidget(scroll)
        self.problems = QLabel("")
        self.problems.setWordWrap(True)
        self.problems.setProperty("role", "error")
        self.back = QPushButton("< &Back")
        self.next = QPushButton("Ne&xt >")
        self.next.setProperty("role", "primary")
        self.back.clicked.connect(lambda: self._go(self.stack.currentIndex() - 1))
        self.next.clicked.connect(self._next)
        nav = QHBoxLayout()
        nav.addWidget(self.problems, 1)
        nav.addWidget(self.back)
        nav.addWidget(self.next)
        right = QVBoxLayout()
        right.addWidget(self.stack, 1)
        right.addLayout(nav)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 8)
        layout.addLayout(left)
        layout.addLayout(right, 1)
        self._status_timer = QTimer(self)
        self._status_timer.setInterval(1500)
        self._status_timer.timeout.connect(self._refresh_share_status)
        self._go(0)

    # ---------------------------------------------------------------- steps
    def _step_select(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(_heading("Select a file or folder"))
        row = QHBoxLayout()
        self.source = QLineEdit()
        self.source.setReadOnly(True)
        self.source.setPlaceholderText("Nothing selected")
        self.source.setAccessibleName("Selected file or folder")
        pick_file = QPushButton("Choose &file…")
        pick_folder = QPushButton("Choose f&older…")
        pick_file.clicked.connect(lambda: self._pick(False))
        pick_folder.clicked.connect(lambda: self._pick(True))
        row.addWidget(self.source, 1)
        row.addWidget(pick_file)
        row.addWidget(pick_folder)
        layout.addLayout(row)
        self.scan_summary = muted("Choose what you want to share. Only the files listed below will be included.")
        layout.addWidget(self.scan_summary)
        self.scan_model = ScanModel(self)
        self.scan_table = QTableView()
        self.scan_table.setModel(self.scan_model)
        self.scan_table.verticalHeader().hide()
        self.scan_table.verticalHeader().setDefaultSectionSize(24)
        self.scan_table.setShowGrid(False)
        self.scan_table.setAlternatingRowColors(True)
        self.scan_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.scan_table.setAccessibleName("Files to include")
        self.scan_model.dataChanged.connect(lambda *_: self._update_scan_summary())
        layout.addWidget(self.scan_table, 3)
        self.skipped_label = QLabel("Not included")
        self.skipped_label.setProperty("role", "subheading")
        self.skipped = QPlainTextEdit()
        self.skipped.setReadOnly(True)
        self.skipped.setMaximumHeight(110)
        self.skipped.setAccessibleName("Items that were not included, with reasons")
        layout.addWidget(self.skipped_label)
        layout.addWidget(self.skipped, 1)
        layout.addWidget(muted("Symbolic links are never followed, so nothing outside the selected folder can be "
                               "pulled in. Operating-system metadata files are left out."))
        return w

    def _step_format(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.addRow(_heading("Torrent format and piece size"))
        self.fmt_hybrid = QRadioButton("&Hybrid (v1 + v2) — works with the widest range of clients")
        self.fmt_v2 = QRadioButton("BitTorrent v&2 only — per-file hashes; needs a v2-capable client")
        self.fmt_v1 = QRadioButton("BitTorrent v&1 only — the classic format")
        self.fmt_hybrid.setChecked(True)
        box = QVBoxLayout()
        for radio in (self.fmt_hybrid, self.fmt_v2, self.fmt_v1):
            box.addWidget(radio)
        form.addRow("Format:", box)
        self.piece = QComboBox()
        for label, value in self.ctx.publishing.piece_length_choices():
            self.piece.addItem(label, value)
        self.piece.setAccessibleName("Piece size")
        form.addRow("&Piece size:", self.piece)
        self.piece_info = muted("")
        form.addRow("", self.piece_info)
        self.name = QLineEdit()
        self.name.setPlaceholderText("(use the file or folder name)")
        form.addRow("Torrent &name:", self.name)
        self.comment = QLineEdit()
        self.comment.setMaxLength(500)
        form.addRow("&Comment:", self.comment)
        form.addRow(muted("A folder torrent can only be renamed if you do not start seeding from the original "
                          "folder (the name on disk must match). Hybrid and v2 torrents align files to piece "
                          "boundaries, which lets identical files be recognised across torrents."))
        self.piece.currentIndexChanged.connect(lambda _: self._validate())
        return w

    def _step_trackers(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(_heading("Trackers, web seeds and visibility"))
        layout.addWidget(QLabel("&Trackers — one address per line (http, https or udp); an empty line starts a new tier:"))
        self.trackers = QPlainTextEdit()
        self.trackers.setAccessibleName("Tracker addresses")
        self.trackers.setTabChangesFocus(True)
        self.trackers.setMaximumHeight(130)
        layout.addWidget(self.trackers)
        layout.addWidget(QLabel("&Web seeds (optional) — http(s) addresses that serve the same files (BEP 19):"))
        self.web_seeds = QPlainTextEdit()
        self.web_seeds.setAccessibleName("Web seed addresses")
        self.web_seeds.setTabChangesFocus(True)
        self.web_seeds.setMaximumHeight(80)
        layout.addWidget(self.web_seeds)
        self.public = QRadioButton("P&ublic — peers may also be found through DHT, peer exchange and local discovery")
        self.private = QRadioButton("P&rivate — peers are found through the trackers above only")
        self.public.setChecked(True)
        layout.addWidget(self.public)
        layout.addWidget(self.private)
        layout.addWidget(note("For a private torrent the engine keeps DHT, peer exchange and local discovery off, "
                              "and this application never overrides that. A private torrent without a working "
                              "tracker cannot find any peers. “Private” restricts peer discovery; it does not "
                              "encrypt or restrict who can download once they have the torrent."))
        layout.addStretch(1)
        for widget in (self.trackers, self.web_seeds):
            widget.textChanged.connect(self._validate)
        self.private.toggled.connect(lambda _: self._validate())
        return w

    def _step_publisher(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.addRow(_heading("Publisher details (optional)"))
        self.pub_name = QLineEdit()
        self.pub_description = QLineEdit()
        self.pub_website = QLineEdit()
        self.pub_feed = QLineEdit()
        self.pub_licence = QLineEdit()
        self.pub_licence.setPlaceholderText("e.g. CC-BY-4.0, CC0-1.0 or a licence URL")
        self.pub_lightning = QLineEdit()
        self.pub_lightning.setPlaceholderText("name@example.org (a reusable Lightning address — never an invoice)")
        self.pub_bitcoin = QLineEdit()
        self.pub_network = QComboBox()
        self.pub_network.addItems(["mainnet", "testnet", "signet", "regtest"])
        form.addRow("Display &name:", self.pub_name)
        form.addRow("&Description:", self.pub_description)
        form.addRow("&Website:", self.pub_website)
        form.addRow("&Feed address:", self.pub_feed)
        form.addRow("&Licence:", self.pub_licence)
        form.addRow("Lightning &address:", self.pub_lightning)
        btc = QHBoxLayout()
        btc.addWidget(self.pub_bitcoin, 1)
        btc.addWidget(self.pub_network)
        form.addRow("Bitcoin address:", btc)
        self.embed = QCheckBox("&Embed these details in the torrent (bound to its info-hash)")
        self.embed.setChecked(True)
        self.sign = QCheckBox("&Sign the details with this device's publisher key (Ed25519)")
        form.addRow("", self.embed)
        form.addRow("", self.sign)
        form.addRow(note(
            "These details are your own statement. Recipients see them labelled “self-asserted” unless they have "
            "pinned your signing key themselves — a valid signature shows who signed, not that the signer deserves "
            "trust. Payment addresses are plain information: nothing is ever paid without the other person's "
            "explicit approval. Expiring invoices cannot be stored here. A Bitcoin address published this way is "
            "public and links every payment made to it."))
        for widget in (self.pub_name, self.pub_description, self.pub_website, self.pub_feed, self.pub_licence,
                       self.pub_lightning, self.pub_bitcoin):
            widget.textChanged.connect(self._validate)
        return w

    def _step_create(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.addRow(_heading("Create and save the torrent"))
        row = QHBoxLayout()
        self.output = QLineEdit()
        self.output.setAccessibleName("Torrent file to save")
        browse = QPushButton("&Browse…")
        browse.clicked.connect(self._pick_output)
        row.addWidget(self.output, 1)
        row.addWidget(browse)
        form.addRow("Save torrent as:", row)
        self.overwrite = QCheckBox("&Replace the file if it already exists")
        form.addRow("", self.overwrite)
        self.seed = QCheckBox("Start see&ding from the original location when done")
        self.seed.setChecked(True)
        form.addRow("", self.seed)
        self.category = category_combo(list(self.ctx.settings.get().general.categories))
        form.addRow("&Category:", self.category)
        self.summary = muted("")
        form.addRow("Summary:", self.summary)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1000)
        self.progress.setTextVisible(False)
        self.progress.setAccessibleName("Hashing progress")
        self.progress_label = muted("Hashing has not started.")
        form.addRow("Hashing:", self.progress)
        form.addRow("", self.progress_label)
        buttons = QHBoxLayout()
        self.create = QPushButton("&Create torrent")
        self.create.setProperty("role", "primary")
        self.create.clicked.connect(self._create)
        self.cancel = QPushButton("Canc&el hashing")
        self.cancel.clicked.connect(self._cancel.set)
        self.cancel.setEnabled(False)
        buttons.addWidget(self.create)
        buttons.addWidget(self.cancel)
        buttons.addStretch(1)
        form.addRow("", buttons)
        form.addRow(muted("Files are read and hashed in the background; the window stays responsive. The files "
                          "themselves are not changed, moved or uploaded anywhere by this step."))
        self.seed.toggled.connect(lambda _: self._validate())
        return w

    def _step_share(self) -> QWidget:
        w = QWidget()
        grid = QGridLayout(w)
        self.share_title = _heading("Share")
        grid.addWidget(self.share_title, 0, 0, 1, 2)
        self.share_facts = muted("")
        grid.addWidget(self.share_facts, 1, 0, 1, 2)

        left = QVBoxLayout()
        self.magnet = QPlainTextEdit()
        self.magnet.setReadOnly(True)
        self.magnet.setMaximumHeight(84)
        self.magnet.setAccessibleName("Magnet link")
        left.addWidget(QLabel("Magnet link"))
        left.addWidget(self.magnet)
        row = QHBoxLayout()
        for text, slot in (("Copy &magnet", self._copy_magnet), ("Copy &description", self._copy_text),
                           ("Save .&torrent as…", self._save_torrent)):
            button = QPushButton(text)
            button.clicked.connect(slot)
            row.addWidget(button)
        row.addStretch(1)
        left.addLayout(row)
        row2 = QHBoxLayout()
        for text, kinds in (("Export publisher &page…", ["page"]), ("Export &Atom entry…", ["atom"]),
                            ("Export &QR image…", ["qr_png", "qr_svg"]), ("Export e&verything…", None)):
            button = QPushButton(text)
            button.clicked.connect(lambda _=False, k=kinds: self._export(k))
            row2.addWidget(button)
        row2.addStretch(1)
        left.addLayout(row2)
        row3 = QHBoxLayout()
        self.destinations = QComboBox()
        self.destinations.setAccessibleName("Publishing destination")
        publish = QPushButton("P&ublish to destination")
        publish.clicked.connect(self._publish)
        manage = QPushButton("Destinations…")
        manage.clicked.connect(self._manage_destinations)
        row3.addWidget(self.destinations, 1)
        row3.addWidget(publish)
        row3.addWidget(manage)
        left.addLayout(row3)
        self.seeding_status = QLabel("")
        self.seeding_status.setWordWrap(True)
        self.seeding_status.setProperty("role", "subheading")
        left.addWidget(self.seeding_status)
        self.announce_status = muted("")
        left.addWidget(self.announce_status)
        show = QPushButton("Show the &transfer")
        show.clicked.connect(lambda: self._share and self._share.transfer_id and self.go_to_transfer.emit(self._share.transfer_id))
        show_row = QHBoxLayout()
        show_row.addWidget(show)
        show_row.addStretch(1)
        left.addLayout(show_row)
        self.share_notes = note("")
        left.addWidget(self.share_notes)
        self.ops_model = RowsModel([
            Column("Operation", lambda o: o.operation),
            Column("Destination", lambda o: o.destination),
            Column("Result", lambda o: "Succeeded" if o.ok else "FAILED"),
            Column("Details", lambda o: o.message),
            Column("When", lambda o: format_time(o.ts)),
        ], key=lambda o: (o.operation, o.destination, o.ts), parent=self)
        self.ops = make_table(self.ops_model, sortable=False)
        self.ops.setAccessibleName("Publishing operations and their results")
        self.ops.setMinimumHeight(110)
        for column, width in enumerate((140, 220, 90, 260)):
            self.ops.setColumnWidth(column, width)
        left.addWidget(QLabel("What has been done"))
        left.addWidget(self.ops, 1)
        grid.addLayout(left, 2, 0)

        right = QVBoxLayout()
        self.qr = QLabel()
        self.qr.setFixedSize(260, 260)
        self.qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.qr.setAccessibleName("QR code of the magnet link")
        self.qr_note = muted("")
        self.qr_note.setFixedWidth(260)
        right.addWidget(self.qr)
        right.addWidget(self.qr_note)
        right.addStretch(1)
        grid.addLayout(right, 2, 1)
        grid.setColumnStretch(0, 1)
        return w

    # ------------------------------------------------------------ navigation
    def activate(self) -> None:
        self._load_recent()

    def new_publication(self) -> None:
        if self._hashing:
            return
        self._scan = None
        self._job_id = None
        self._share = None
        self.source.clear()
        self.scan_model.set_files([])
        self.skipped.setPlainText("")
        self.progress.setValue(0)
        self.progress_label.setText("Hashing has not started.")
        self.output.clear()
        self._go(0)

    def _go(self, index: int) -> None:
        index = max(0, min(self.stack.count() - 1, index))
        self.stack.setCurrentIndex(index)
        for i in range(self.steps.count()):
            item = self.steps.item(i)
            font = item.font()
            font.setBold(i == index)
            item.setFont(font)
        self.back.setVisible(0 < index < 5)
        self.next.setVisible(index < 4)
        self.back.setEnabled(not self._hashing)
        if index == 4:
            self._prepare_create()
        self._status_timer.start() if index == 5 else self._status_timer.stop()
        self._validate()

    def _next(self) -> None:
        index = self.stack.currentIndex()
        if index == 0 and (self._scan is None or not self.scan_model.included()):
            self.problems.setText("Select a file or folder and include at least one file.")
            return
        check = self._check()
        if index >= 1 and check is not None and check.errors:
            self.problems.setText(" ".join(check.errors))
            return
        self._go(index + 1)

    # --------------------------------------------------------------- step 1
    def _pick(self, folder: bool) -> None:
        if folder:
            path = QFileDialog.getExistingDirectory(self, "Choose the folder to share")
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Choose the file to share")
        if path:
            self.set_source(path)

    def set_source(self, path: str) -> None:
        self.source.setText(path)
        self.scan_summary.setText("Reading the file list…")
        self._scan = None

        def done(scan) -> None:
            self._scan = scan
            self.scan_model.set_files(scan.files)
            self.skipped.setPlainText("\n".join(f"{rel} — {reason}" for rel, reason in scan.skipped) or
                                      "Nothing was left out.")
            self.skipped_label.setText(f"Not included ({len(scan.skipped)})")
            self.output.setText(self.ctx.publishing.suggest_torrent_path(path))
            self._update_scan_summary()
            self._validate()

        def failed(exc) -> None:
            self.scan_summary.setText(str(exc))
            self.message.emit("error", str(exc))

        self.bridge.run(lambda: self.ctx.publishing.scan(path), done, failed)

    def _update_scan_summary(self) -> None:
        if self._scan is None:
            return
        included = self.scan_model.included()
        text = (f"{len(included)} of {len(self._scan.files)} file(s) included · "
                f"{format_size(sum(f.size for f in included))}")
        if self._scan.truncated:
            text += " · the folder has more files than can be listed; only those shown are included"
        self.scan_summary.setText(text)

    # ----------------------------------------------------------- validation
    def _draft(self) -> PublishDraft:
        publisher = PublisherInfo(
            name=self.pub_name.text().strip(), description=self.pub_description.text().strip(),
            website=self.pub_website.text().strip(), feed_url=self.pub_feed.text().strip(),
            bitcoin_address=self.pub_bitcoin.text().strip(), bitcoin_network=self.pub_network.currentText(),
            lightning_address=self.pub_lightning.text().strip(), licence=self.pub_licence.text().strip())
        fmt = "hybrid" if self.fmt_hybrid.isChecked() else ("v2" if self.fmt_v2.isChecked() else "v1")
        return PublishDraft(
            source_path=self.source.text(), included_files=[f.relative for f in self.scan_model.included()],
            name=self.name.text().strip(), format=fmt, piece_length=int(self.piece.currentData() or 0),
            trackers_text=self.trackers.toPlainText(),
            web_seeds=[line.strip() for line in self.web_seeds.toPlainText().splitlines() if line.strip()],
            private=self.private.isChecked(), comment=self.comment.text().strip(),
            publisher=None if publisher.is_empty() else publisher, embed_manifest=self.embed.isChecked(),
            sign_manifest=self.sign.isChecked(), output_torrent_path=self.output.text().strip(),
            overwrite=self.overwrite.isChecked(), start_seeding=self.seed.isChecked(),
            category=self.category.currentText().strip())

    def _check(self):
        if self._scan is None:
            return None
        total = sum(f.size for f in self.scan_model.included())
        try:
            # pure, in-memory validation (no disk or network access)
            return self.ctx.publishing.check_options(self._draft(), total_size=total)
        except Exception as exc:
            self.problems.setText(str(exc))
            return None

    def _validate(self) -> None:
        if not hasattr(self, "problems"):
            return
        index = self.stack.currentIndex()
        check = self._check() if index in (1, 2, 3, 4) else None
        if check is None:
            self.problems.setText("")
            return
        self.problems.setProperty("role", "error" if check.errors else "warning")
        self.problems.style().unpolish(self.problems)
        self.problems.style().polish(self.problems)
        self.problems.setText(" ".join(check.errors or check.warnings[:2]))
        if check.piece_length:
            self.piece_info.setText(f"{format_size(check.piece_length)} pieces → about {check.estimated_pieces:,} pieces")

    # --------------------------------------------------------------- step 5
    def _prepare_create(self) -> None:
        draft = self._draft()
        included = self.scan_model.included()
        check = self._check()
        tiers = len(check.tiers) if check else 0
        self.summary.setText(
            f"{len(included)} file(s), {format_size(sum(f.size for f in included))} · {draft.format} · "
            f"{'private' if draft.private else 'public'} · {tiers} tracker tier(s) · {len(draft.web_seeds)} web seed(s)"
            + (f" · publisher “{draft.publisher.name}”" if draft.publisher and draft.publisher.name else ""))

    def _pick_output(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save torrent as", self.output.text(), "Torrent files (*.torrent)")
        if path:
            self.output.setText(path if path.lower().endswith(".torrent") else path + ".torrent")

    def _create(self) -> None:
        check = self._check()
        if check is None or check.errors:
            self.problems.setText(" ".join(check.errors) if check else "Select the files first.")
            return
        draft = self._draft()
        self._cancel.clear()
        self._hashing = True
        self.create.setEnabled(False)
        self.cancel.setEnabled(True)
        self.back.setEnabled(False)
        self.progress.setValue(0)
        self.progress_label.setText("Hashing…")
        progress = self.bridge.gui(self._on_progress)

        def done(job) -> None:
            self._finish_hashing()
            self._load_recent()
            if job.state.value == "completed":
                self._job_id = job.id
                self.progress.setValue(1000)
                self.progress_label.setText("Done.")
                self._open_share(job.id)
            elif job.state.value == "cancelled":
                self.progress_label.setText("Cancelled. No torrent file was written.")
            else:
                self.progress_label.setText(f"Failed: {job.error}")
                self.message.emit("error", f"The torrent could not be created: {job.error}")

        def failed(exc) -> None:
            self._finish_hashing()
            self.progress_label.setText(str(exc))
            self.message.emit("error", str(exc))

        self.bridge.run(lambda: self.ctx.publishing.start_job(draft, on_progress=progress,
                                                              cancelled=self._cancel.is_set), done, failed)

    def _on_progress(self, done: int, total: int) -> None:
        if total > 0:
            self.progress.setValue(done * 1000 // total)
            self.progress_label.setText(f"Hashing piece {done:,} of {total:,}")

    def _finish_hashing(self) -> None:
        self._hashing = False
        self.create.setEnabled(True)
        self.cancel.setEnabled(False)
        self.back.setEnabled(True)

    # ---------------------------------------------------------------- share
    def _load_recent(self) -> None:
        def done(jobs) -> None:
            self.recent.clear()
            for job in jobs[:30]:
                item = QListWidgetItem(f"{job.name} — {job.state.label} · {format_time(job.created_at)}")
                item.setData(Qt.ItemDataRole.UserRole, (job.id, job.state.value))
                item.setToolTip(job.error or job.torrent_path)
                self.recent.addItem(item)

        self.bridge.run(lambda: self.ctx.publishing.list_jobs(50), done, lambda exc: None)

    def _open_recent(self, item: QListWidgetItem) -> None:
        job_id, state = item.data(Qt.ItemDataRole.UserRole)
        if self._hashing:
            return
        if state == "completed":
            self._open_share(job_id)
        else:
            self.message.emit("info", "That publication did not complete, so there is nothing to share. "
                                      "Start a new publication to create the torrent again.")

    def _open_share(self, job_id: str) -> None:
        def done(result) -> None:
            info, destinations = result
            self._job_id = job_id
            self._share = info
            self.share_title.setText(f"Share “{info.name}”")
            self.share_facts.setText(
                f"{format_size(info.total_size)} · {info.file_count} file(s) · {sharing.format_label(info.format)} · "
                f"{'private' if info.private else 'public'} · publisher: {info.publisher_label}\n"
                f"Torrent file: {info.torrent_path}" + ("" if info.torrent_file_exists else " (no longer at this path)"))
            self.magnet.setPlainText(info.magnet)
            if info.qr.ok and info.qr.png:
                pixmap = QPixmap()
                pixmap.loadFromData(info.qr.png)
                self.qr.setPixmap(pixmap.scaled(250, 250, Qt.AspectRatioMode.KeepAspectRatio,
                                                Qt.TransformationMode.FastTransformation))
                self.qr_note.setText(("This code holds a shortened magnet link: " + info.qr.reason)
                                     if info.qr.trimmed else "Scan to open the magnet link.")
            else:
                self.qr.setPixmap(QPixmap())
                self.qr.setText("No QR code")
                self.qr_note.setText(f"{info.qr.reason} {info.qr.alternative}".strip())
            self.share_notes.setText("\n".join(info.notes))
            self.ops_model.set_rows(list(info.operations))
            self.destinations.clear()
            for d in destinations:
                self.destinations.addItem(d.name, d.id)
            self._go(5)
            self._refresh_share_status()

        self.bridge.run(lambda: (self.ctx.publishing.share_info(job_id), self.ctx.publishing.list_destinations()),
                        done, lambda exc: self.message.emit("error", str(exc)))

    def _refresh_share_status(self) -> None:
        info = self._share
        if info is None or not self.isVisible():
            return

        def load():
            if not info.transfer_id:
                return None
            return next((v for v in self.ctx.transfers.snapshot()[1] if v.id == info.transfer_id), None)

        def done(view) -> None:
            notes = sharing.SeedingStatusNote
            if not info.seeding_requested:
                text = notes.NOT_REQUESTED
            elif info.seeding_started is False:
                op = next((o for o in info.operations if o.operation == "start_seeding"), None)
                text = notes.ADD_FAILED.format(message=op.message if op else "see the operations list")
            elif view is None:
                text = "The transfer is no longer in this application, so this client is not seeding it."
            elif view.state is TransferState.SEEDING:
                text = notes.SEEDING
            elif view.state is TransferState.CHECKING:
                text = notes.CHECKING
            elif view.state in (TransferState.PAUSED, TransferState.COMPLETED, TransferState.ERROR):
                text = notes.STOPPED + (f" ({view.state_detail})" if view.state_detail else "")
            else:
                text = f"{view.state.label}. {view.state_detail}".strip()
            self.seeding_status.setText(text)
            if view is not None and view.last_announce:
                a = view.last_announce
                self.announce_status.setText(
                    "Last announce: " + (f"succeeded at {a.get('url', '')} ({a.get('peers', 0)} peer(s))"
                                         if a.get("ok") else f"FAILED at {a.get('url', '')} — {a.get('message', '')}")
                    + f" · {format_time(a.get('ts'))}")
            elif view is not None:
                self.announce_status.setText("No tracker announce result yet" + (
                    " (this torrent has no trackers; peers can only find it through DHT/local discovery)."
                    if not view.private else "."))
            else:
                self.announce_status.setText("")

        self.bridge.run(load, done, lambda exc: None)

    def _copy_magnet(self) -> None:
        if self._share:
            QGuiApplication.clipboard().setText(self._share.magnet)
            self.message.emit("info", "Magnet link copied. " + sharing.NOTE_MAGNET_IS_NOT_HOSTING)

    def _copy_text(self) -> None:
        if self._share:
            QGuiApplication.clipboard().setText(self._share.share_text)
            self.message.emit("info", "Sharing description copied.")

    def _save_torrent(self) -> None:
        if not self._share:
            return
        source = self._share.torrent_path
        path, _ = QFileDialog.getSaveFileName(self, "Save .torrent as", os.path.basename(source), "Torrent files (*.torrent)")
        if not path:
            return

        def work():
            from ...filesystem.paths import atomic_write

            with open(source, "rb") as fh:
                atomic_write(path, fh.read())
            return path

        self.bridge.run(work, lambda p: self.message.emit("info", f"Torrent file saved to {p}"),
                        lambda exc: self.message.emit("error", f"Could not save the torrent file: {exc}"))

    def _export(self, kinds) -> None:
        if not self._job_id:
            return
        directory = QFileDialog.getExistingDirectory(self, "Export to folder", str(self.ctx.paths.exports_dir))
        if not directory:
            return
        job_id = self._job_id

        def done(results) -> None:
            failed = [r for r in results if not r.ok]
            self.message.emit("error" if failed else "info",
                              (f"{len(results) - len(failed)} file(s) written to {directory}. "
                               + (f"{len(failed)} failed: {failed[0].message} " if failed else "")
                               + sharing.NOTE_EXPORT_IS_NOT_PUBLISHING))
            self._open_share(job_id)

        self.bridge.run(lambda: self.ctx.publishing.export_to_directory(job_id, directory, kinds), done,
                        lambda exc: self.message.emit("error", str(exc)))

    def _publish(self) -> None:
        destination = self.destinations.currentData()
        if not self._job_id or not destination:
            self.message.emit("info", "Configure a publishing destination first (Destinations…).")
            return
        job_id = self._job_id

        def done(results) -> None:
            failed = [r for r in results if not r.ok]
            self.message.emit("error" if failed else "info",
                              f"Publishing finished: {len(results) - len(failed)} succeeded, {len(failed)} failed. "
                              + sharing.NOTE_UPLOAD_IS_NOT_PROOF)
            self._open_share(job_id)

        self.message.emit("info", "Publishing…")
        self.bridge.run(lambda: self.ctx.publishing.publish(job_id, destination), done,
                        lambda exc: self.message.emit("error", str(exc)))

    def _manage_destinations(self) -> None:
        DestinationsDialog(self.ctx, self.bridge, self).exec()
        if self._job_id:
            self._open_share(self._job_id)


def _heading(text: str) -> QLabel:
    label = QLabel(text)
    label.setProperty("role", "heading")
    return label
