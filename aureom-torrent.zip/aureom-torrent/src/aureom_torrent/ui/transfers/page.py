"""The transfers workspace: main table plus the details tabs."""

from __future__ import annotations

from PySide6.QtCore import QModelIndex, QRect, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QGuiApplication, QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
                               QMenu, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QSplitter,
                               QTableView, QTabWidget, QVBoxLayout, QWidget)

from ...domain.transfers import TransferDetails, TransferState, TransferView
from ..format import (format_duration, format_progress, format_rate_always, format_ratio, format_size,
                      format_time)
from ..models.rows import ROW_ROLE, SORT_ROLE, Column, RowsModel
from ..models.transfers import PROGRESS_COLUMN, ProgressDelegate, TransferFilterProxy, TransferTableModel
from ..themes.theme import ROW_HEIGHT, Palette
from .dialogs import LimitsDialog, RemoveDialog, TrackersDialog, muted, note, priority_name

DETAIL_TABS = ("Overview", "Files", "Peers", "Trackers", "Pieces", "Activity", "Publisher")


def make_table(model, *, sortable: bool = True, density: str = "compact") -> QTableView:
    table = QTableView()
    table.setModel(model)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setAlternatingRowColors(True)
    table.setShowGrid(False)
    table.setWordWrap(False)
    table.setSortingEnabled(sortable)
    table.verticalHeader().hide()
    table.verticalHeader().setDefaultSectionSize(ROW_HEIGHT.get(density, 24))
    table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
    table.horizontalHeader().setHighlightSections(False)
    table.horizontalHeader().setStretchLastSection(True)
    table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    table.setTabKeyNavigation(False)  # Tab moves between panes; arrows move inside the table
    return table


class PiecesWidget(QWidget):
    """Piece map. Pieces are down-sampled to the available cells, so painting cost is bounded
    by the widget size, not by the number of pieces."""

    def __init__(self, palette: Palette, parent=None):
        super().__init__(parent)
        self.palette = palette
        self._pieces = b""
        self.setMinimumHeight(120)
        self.setAccessibleName("Piece map")

    def set_pieces(self, pieces: bytes) -> None:
        if pieces != self._pieces:
            self._pieces = pieces
            have = pieces.count(1)
            self.setAccessibleDescription(f"{have} of {len(pieces)} pieces verified")
            self.update()

    def sizeHint(self) -> QSize:
        return QSize(400, 160)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        p = self.palette
        painter.fillRect(self.rect(), QColor(p.surface))
        n = len(self._pieces)
        if n == 0:
            painter.setPen(QColor(p.muted))
            painter.drawText(self.rect(), int(Qt.AlignmentFlag.AlignCenter), "Piece information is not available yet")
            return
        cell, gap = 9, 2
        cols = max(1, (self.width() - 12) // (cell + gap))
        rows = max(1, (self.height() - 12) // (cell + gap))
        cells = min(n, cols * rows)
        have, partial, missing = QColor(p.active), QColor(p.complete), QColor(p.track)
        for i in range(cells):
            start = i * n // cells
            end = max(start + 1, (i + 1) * n // cells)
            count = self._pieces.count(1, start, end)
            colour = have if count == end - start else (partial if count else missing)
            x = 6 + (i % cols) * (cell + gap)
            y = 6 + (i // cols) * (cell + gap)
            painter.fillRect(QRect(x, y, cell, cell), colour)


class TransfersPage(QWidget):
    selection_changed = Signal()
    request_publisher_support = Signal(str, str)  # transfer_id, kind ("lightning" | "bitcoin")
    message = Signal(str, str)  # level, text
    review_requested = Signal(str)  # transfer_id of a metadata preview to review

    def __init__(self, ctx, bridge, palette: Palette, density: str, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.bridge = bridge
        self.palette = palette
        self._views: dict[str, TransferView] = {}
        self._details_busy = False
        self._details_for: str | None = None

        self.model = TransferTableModel(self)
        self.proxy = TransferFilterProxy(self)
        self.proxy.setSourceModel(self.model)
        self.table = make_table(self.proxy, density=density)
        self.table.setAccessibleName("Transfers")
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.delegate = ProgressDelegate(palette, self.table)
        self.table.setItemDelegateForColumn(PROGRESS_COLUMN, self.delegate)
        self.table.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        for column, width in enumerate((222, 72, 124, 164, 88, 84, 60, 50, 62, 92, 160)):
            self.table.setColumnWidth(column, width)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.table.selectionModel().selectionChanged.connect(self._on_selection)
        self.table.doubleClicked.connect(self._activated)

        self.empty = QLabel("No transfers here yet.\nUse “Add Torrent”, “Add Magnet” or drop a .torrent file or "
                            "magnet link onto this window.")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setProperty("role", "muted")

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self._build_tabs()
        self.tabs.currentChanged.connect(lambda _: self._poll_details(force=True))

        top = QWidget()
        top_layout = QVBoxLayout(top)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.addWidget(self.table)
        top_layout.addWidget(self.empty)
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.addWidget(top)
        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setChildrenCollapsible(False)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 8)
        layout.addWidget(splitter)

        self._details_timer = QTimer(self)
        self._details_timer.setInterval(1000)
        self._details_timer.timeout.connect(self._poll_details)
        self._details_timer.start()

        QShortcut(QKeySequence(Qt.Key.Key_Delete), self.table, activated=self.remove_selected)
        QShortcut(QKeySequence("Ctrl+A"), self.table, activated=self.table.selectAll)

    # ------------------------------------------------------------------ tabs
    def _build_tabs(self) -> None:
        # Overview
        self.overview = QWidget()
        form = QFormLayout(self.overview)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form.setContentsMargins(14, 12, 14, 12)
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(5)
        self.ov: dict[str, QLabel] = {}
        for key, title in (("name", "Name"), ("state", "State"), ("progress", "Verified progress"),
                           ("complete", "Completion"), ("size", "Size"), ("transfer", "Transferred"),
                           ("speed", "Speed"), ("peers", "Connections"), ("identity", "Info-hash"),
                           ("destination", "Destination"), ("added", "Added"), ("announce", "Last announce"),
                           ("discovery", "Discovery")):
            label = QLabel("—")
            label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            label.setWordWrap(True)
            self.ov[key] = label
            title_label = QLabel(title + ":")
            title_label.setProperty("role", "muted")
            form.addRow(title_label, label)
        form.addRow(muted("Verification proves that the data matches the torrent's metadata. It says nothing about "
                          "whether the content is safe or the publisher trustworthy."))
        self.overview.setObjectName("panel")
        scroll = QScrollArea()
        scroll.setObjectName("panelScroll")
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.overview)
        self.tabs.addTab(scroll, "Overview")

        # Files
        self.files_model = RowsModel([
            Column("File", lambda f: f.path),
            Column("Size", lambda f: format_size(f.size), lambda f: f.size, True),
            Column("Verified", lambda f: format_progress(f.done * 1_000_000 // f.size if f.size else 1_000_000),
                   lambda f: f.done / f.size if f.size else 1, True),
            Column("Priority", lambda f: priority_name(f.priority), lambda f: f.priority),
        ], key=lambda f: f.index, parent=self)
        self.files_table = self._detail_table(self.files_model, "Files", (460, 90, 90, 90))
        self.files_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.files_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.files_table.customContextMenuRequested.connect(self._files_menu)
        self.tabs.addTab(self.files_table, "Files")

        # Peers
        self.peers_model = RowsModel([
            Column("Address", lambda p: p.address),
            Column("Client", lambda p: p.client),
            Column("Progress", lambda p: format_progress(p.progress_ppm), lambda p: p.progress_ppm, True),
            Column("Down", lambda p: format_rate_always(p.download_rate), lambda p: p.download_rate, True),
            Column("Up", lambda p: format_rate_always(p.upload_rate), lambda p: p.upload_rate, True),
            Column("Flags", lambda p: p.flags,
                   tooltip=lambda p: "I interested · C choked · i peer interested · c peer choked · S seed · "
                                     "E/e encrypted (RC4/plaintext handshake) · U upload only"),
            Column("Source", lambda p: p.source),
            Column("Connection", lambda p: p.connection),
        ], key=lambda p: p.address, parent=self)
        peers = QWidget()
        peers_layout = QVBoxLayout(peers)
        peers_layout.setContentsMargins(0, 0, 0, 0)
        peers_layout.addWidget(self._detail_table(self.peers_model, "Peers", (190, 170, 80, 90, 90, 70, 90, 90)))
        peers_layout.addWidget(muted("  Peers you exchange data with can see your IP address. Protocol encryption "
                                     "obscures traffic; it does not make you anonymous."))
        self.tabs.addTab(peers, "Peers")

        # Trackers
        self.trackers_model = RowsModel([
            Column("Tracker", lambda t: t.url),
            Column("Tier", lambda t: str(t.tier), lambda t: t.tier, True),
            Column("Status", lambda t: t.status),
            Column("Seeds", lambda t: str(t.seeds) if t.seeds >= 0 else "—", lambda t: t.seeds, True),
            Column("Leeches", lambda t: str(t.leeches) if t.leeches >= 0 else "—", lambda t: t.leeches, True),
            Column("Next announce", lambda t: format_duration(t.next_announce_s), lambda t: t.next_announce_s, True),
            Column("Message", lambda t: t.message),
        ], key=lambda t: (t.url, t.tier), parent=self)
        trackers = QWidget()
        trackers_layout = QVBoxLayout(trackers)
        trackers_layout.setContentsMargins(0, 0, 0, 0)
        trackers_layout.addWidget(self._detail_table(self.trackers_model, "Trackers", (330, 50, 100, 60, 70, 110, 200)))
        row = QHBoxLayout()
        row.setContentsMargins(8, 4, 8, 6)
        self.web_seeds_label = muted("")
        row.addWidget(self.web_seeds_label, 1)
        edit = QPushButton("Edit &trackers…")
        edit.clicked.connect(self.edit_trackers)
        announce = QPushButton("&Announce now")
        announce.clicked.connect(lambda: self._act(lambda ids: self.ctx.transfers.reannounce(ids)))
        row.addWidget(announce)
        row.addWidget(edit)
        trackers_layout.addLayout(row)
        self.tabs.addTab(trackers, "Trackers")

        # Pieces
        pieces = QWidget()
        pieces.setObjectName("panel")
        pieces_layout = QVBoxLayout(pieces)
        self.pieces_summary = muted("")
        self.pieces = PiecesWidget(self.palette)
        pieces_layout.addWidget(self.pieces_summary)
        pieces_layout.addWidget(self.pieces, 1)
        self.tabs.addTab(pieces, "Pieces")

        # Activity
        self.activity = QPlainTextEdit()
        self.activity.setReadOnly(True)
        self.activity.setMaximumBlockCount(400)
        self.activity.setAccessibleName("Transfer activity log")
        self.tabs.addTab(self.activity, "Activity")

        # Publisher
        publisher = QWidget()
        publisher.setObjectName("panel")
        pub_layout = QVBoxLayout(publisher)
        pub_layout.setContentsMargins(14, 12, 14, 12)
        self.publisher_text = QLabel("No publisher information is attached to this transfer.")
        self.publisher_text.setWordWrap(True)
        self.publisher_text.setTextFormat(Qt.TextFormat.PlainText)
        self.publisher_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.publisher_text.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        pub_layout.addWidget(self.publisher_text)
        buttons = QHBoxLayout()
        self.tip_button = QPushButton("Send a Lightning &tip…")
        self.btc_button = QPushButton("Open a &Bitcoin payment request…")
        self.tip_button.clicked.connect(lambda: self._support("lightning"))
        self.btc_button.clicked.connect(lambda: self._support("bitcoin"))
        buttons.addWidget(self.tip_button)
        buttons.addWidget(self.btc_button)
        buttons.addStretch(1)
        pub_layout.addLayout(buttons)
        pub_layout.addWidget(note(
            "Supporting a publisher is optional and separate from the transfer. A payment does not unlock, "
            "speed up or guarantee anything, cannot be refunded by this application, and is only ever sent "
            "after you approve it."))
        pub_layout.addStretch(1)
        self.tabs.addTab(publisher, "Publisher")

    def _detail_table(self, model, name: str, widths) -> QTableView:
        proxy = _SortProxy(self)
        proxy.setSourceModel(model)
        table = make_table(proxy)
        table.setAccessibleName(name)
        for column, width in enumerate(widths):
            table.setColumnWidth(column, width)
        return table

    # --------------------------------------------------------------- refresh
    def apply_views(self, views: list[TransferView]) -> None:
        self._views = {v.id: v for v in views}
        self.model.set_rows(views)
        has_rows = self.proxy.rowCount() > 0
        self.table.setVisible(has_rows or bool(views))
        self.empty.setVisible(not views)
        self._update_overview()

    def set_filter(self, name: str) -> None:
        self.proxy.set_filter(name)

    def set_search(self, text: str) -> None:
        self.proxy.set_search(text)

    def set_density(self, density: str) -> None:
        self.table.verticalHeader().setDefaultSectionSize(ROW_HEIGHT.get(density, 24))

    def set_palette(self, palette: Palette) -> None:
        self.palette = palette
        self.delegate.set_palette(palette)
        self.pieces.palette = palette
        self.table.viewport().update()
        self.pieces.update()

    def selected_ids(self) -> list[str]:
        ids = []
        for index in self.table.selectionModel().selectedRows():
            view = index.data(ROW_ROLE)
            if view is not None:
                ids.append(view.id)
        return ids

    def current_view(self) -> TransferView | None:
        ids = self.selected_ids()
        return self._views.get(ids[0]) if ids else None

    def select(self, transfer_id: str) -> None:
        for row in range(self.proxy.rowCount()):
            index = self.proxy.index(row, 0)
            view = index.data(ROW_ROLE)
            if view is not None and view.id == transfer_id:
                self.table.selectRow(row)
                self.table.scrollTo(index)
                return

    def _on_selection(self, *_):
        self.selection_changed.emit()
        self._update_overview()
        self._poll_details(force=True)

    def _update_overview(self) -> None:
        v = self.current_view()
        if v is None:
            for label in self.ov.values():
                label.setText("—")
            return
        self.ov["name"].setText(v.name)
        self.ov["state"].setText(v.state.label + (f" — {v.state_detail}" if v.state_detail else ""))
        self.ov["state"].setProperty("role", "error" if v.state is TransferState.ERROR else "")
        self.ov["state"].style().unpolish(self.ov["state"])
        self.ov["state"].style().polish(self.ov["state"])
        if v.has_metadata and not v.preview:
            self.ov["progress"].setText(f"{format_progress(v.progress_ppm)} of the selected files "
                                        f"({v.pieces_have:,} of {v.pieces_total:,} pieces verified)")
            if v.torrent_complete:
                done = "Entire torrent complete"
            elif v.selected_complete:
                done = "Selected files complete (other files in the torrent were not selected)"
            else:
                done = "Not complete"
            self.ov["complete"].setText(done)
        else:
            self.ov["progress"].setText("—")
            self.ov["complete"].setText("Metadata not yet retrieved" if not v.has_metadata else "Waiting for your review")
        self.ov["size"].setText(f"{format_size(v.size)} selected of {format_size(v.total_size)}"
                                if v.has_metadata else "Unknown until metadata arrives")
        self.ov["transfer"].setText(f"{format_size(v.downloaded)} downloaded · {format_size(v.uploaded)} uploaded · "
                                    f"ratio {format_ratio(v.ratio_permille)} · seeding time "
                                    f"{format_duration(v.seeding_seconds)}")
        self.ov["speed"].setText(f"↓ {format_rate_always(v.download_rate)}   ↑ {format_rate_always(v.upload_rate)}")
        self.ov["peers"].setText(f"{v.peers} peers connected ({v.seeds} seeds)")
        ident = []
        if v.identity.v1:
            ident.append(f"v1  {v.identity.v1}")
        if v.identity.v2:
            ident.append(f"v2  {v.identity.v2}")
        self.ov["identity"].setText("\n".join(ident))
        self.ov["destination"].setText(v.save_path if not v.preview else "Not chosen yet (metadata preview)")
        self.ov["added"].setText(f"{format_time(v.added_at)} · from {v.source}")
        a = v.last_announce
        if a:
            outcome = f"succeeded, {a.get('peers', 0)} peer(s)" if a.get("ok") else f"failed — {a.get('message', '')}"
            self.ov["announce"].setText(f"{a.get('url', '')}: {outcome} ({format_time(a.get('ts'))})")
        else:
            self.ov["announce"].setText("No tracker announce result yet")
        self.ov["discovery"].setText("Private torrent — trackers only (DHT, peer exchange and local discovery "
                                     "are disabled by the engine)" if v.private else
                                     "Public torrent — trackers, DHT, peer exchange and local discovery as "
                                     "enabled in Settings")

    def _poll_details(self, force: bool = False) -> None:
        v = self.current_view()
        if v is None:
            self._details_for = None
            for model in (self.files_model, self.peers_model, self.trackers_model):
                model.set_rows([])
            self.pieces.set_pieces(b"")
            self.activity.setPlainText("")
            self._show_publisher(None, None)
            return
        if not self.isVisible() or (self._details_busy and not force):
            return
        tab = DETAIL_TABS[self.tabs.currentIndex()]
        tid = v.id
        svc = self.ctx.transfers
        svc.request_details(tid, peers=tab == "Peers", trackers=tab == "Trackers", files=tab == "Files",
                            pieces=tab == "Pieces")

        def load():
            manifest = self.ctx.manifest_summary(tid) if tab == "Publisher" else None
            return (tid, tab, svc.details(tid), svc.activity(tid, 300) if tab == "Activity" else None, manifest)

        self._details_busy = True
        self.bridge.run(load, self._apply_details, lambda exc: setattr(self, "_details_busy", False))

    def _apply_details(self, result) -> None:
        self._details_busy = False
        tid, tab, details, activity, manifest = result
        current = self.current_view()
        if current is None or current.id != tid:
            return
        details = details or TransferDetails(tid)
        if tab == "Files":
            self.files_model.set_rows([f for f in details.files if not f.pad])
        elif tab == "Peers":
            self.peers_model.set_rows(list(details.peers))
        elif tab == "Trackers":
            self.trackers_model.set_rows(list(details.trackers))
            seeds = ", ".join(details.web_seeds[:3])
            self.web_seeds_label.setText(f"Web seeds: {seeds}" if seeds else "No web seeds")
        elif tab == "Pieces":
            self.pieces.set_pieces(details.pieces)
            if details.pieces:
                self.pieces_summary.setText(f"{details.pieces.count(1):,} of {len(details.pieces):,} pieces "
                                            "verified. Each cell may stand for several pieces.")
        elif tab == "Activity" and activity is not None:
            text = "\n".join(f"{format_time(ts)}  {level.upper():7s} {message}" for ts, level, _, message in reversed(activity))
            if text != self.activity.toPlainText():
                self.activity.setPlainText(text)
                self.activity.verticalScrollBar().setValue(self.activity.verticalScrollBar().maximum())
        elif tab == "Publisher":
            self._show_publisher(current, manifest)

    def _show_publisher(self, view, manifest) -> None:
        if view is None or not manifest:
            self.publisher_text.setText("No publisher information is attached to this transfer.")
            self.tip_button.setEnabled(False)
            self.btc_button.setEnabled(False)
            return
        self.publisher_text.setText(manifest["text"])
        self.tip_button.setEnabled(bool(manifest.get("lightning_address")))
        self.btc_button.setEnabled(bool(manifest.get("bitcoin_address")))

    def _support(self, kind: str) -> None:
        v = self.current_view()
        if v is not None:
            self.request_publisher_support.emit(v.id, kind)

    # --------------------------------------------------------------- actions
    def _act(self, fn, ids: list[str] | None = None) -> None:
        ids = ids if ids is not None else self.selected_ids()
        if ids:
            self.bridge.run(lambda: fn(ids), None, lambda exc: self.message.emit("error", str(exc)))

    def start_selected(self) -> None:
        self._act(self.ctx.transfers.resume)

    def pause_selected(self) -> None:
        self._act(self.ctx.transfers.pause)

    def recheck_selected(self) -> None:
        self._act(self.ctx.transfers.recheck)

    def remove_selected(self) -> None:
        ids = self.selected_ids()
        if not ids:
            return
        views = [self._views[i] for i in ids if i in self._views]
        can_delete = any(v.has_metadata and not v.preview for v in views)
        dialog = RemoveDialog([v.name for v in views], [v.save_path for v in views if not v.preview], can_delete, self)
        if dialog.exec():
            delete = dialog.delete_data()
            self.bridge.run(lambda: self.ctx.transfers.remove(ids, delete_data=delete), None,
                            lambda exc: self.message.emit("error", str(exc)))

    def open_destination(self) -> None:
        v = self.current_view()
        if v is not None and not v.preview and v.save_path:
            # Opens the folder in the file manager; downloaded files themselves are never opened.
            QDesktopServices.openUrl(QUrl.fromLocalFile(v.save_path))

    def copy_magnet(self) -> None:
        v = self.current_view()
        if v is None:
            return

        def done(uri: str) -> None:
            QGuiApplication.clipboard().setText(uri)
            self.message.emit("info", "Magnet link copied. Sharing a magnet does not host the files: others can "
                                      "download only while someone with the data is seeding.")

        self.bridge.run(lambda: self.ctx.transfers.magnet_uri(v.id), done,
                        lambda exc: self.message.emit("error", str(exc)))

    def export_torrent(self) -> None:
        v = self.current_view()
        if v is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export .torrent", f"{v.name}.torrent", "Torrent files (*.torrent)")
        if not path:
            return

        def done(result) -> None:
            if result:
                self.message.emit("info", f"Torrent file saved to {result}")

        self.bridge.run(lambda: self.ctx.transfers.export_torrent(v.id, path), done,
                        lambda exc: self.message.emit("error", str(exc)))

    def move_storage(self) -> None:
        v = self.current_view()
        if v is None or v.preview:
            return
        target = QFileDialog.getExistingDirectory(self, "Move storage to…", v.save_path)
        if target:
            self.bridge.run(lambda: self.ctx.transfers.move_storage(v.id, target), None,
                            lambda exc: self.message.emit("error", str(exc)))

    def edit_limits(self) -> None:
        v = self.current_view()
        if v is None:
            return

        def show(record) -> None:
            if record is None:
                return
            dialog = LimitsDialog(record, self)
            if dialog.exec():
                values = dialog.values()
                self.bridge.run(lambda: self.ctx.transfers.set_limits(v.id, **values), None,
                                lambda exc: self.message.emit("error", str(exc)))

        self.bridge.run(lambda: self.ctx.transfers.record(v.id), show)

    def edit_trackers(self) -> None:
        v = self.current_view()
        if v is None:
            return
        current = [(t.url, t.tier) for t in self.trackers_model.rows()]

        def show(details) -> None:
            trackers = current or ([(t.url, t.tier) for t in details.trackers] if details else [])
            dialog = TrackersDialog(trackers, v.private, self)
            if dialog.exec():
                new = dialog.trackers()
                self.bridge.run(lambda: self.ctx.transfers.replace_trackers(v.id, new), None,
                                lambda exc: self.message.emit("error", str(exc)))

        self.ctx.transfers.request_details(v.id, trackers=True)
        QTimer.singleShot(350, lambda: self.bridge.run(lambda: self.ctx.transfers.details(v.id), show))

    def set_category(self, category: str) -> None:
        self._act(lambda ids: self.ctx.transfers.set_category(ids, category))

    def _activated(self, *_):
        v = self.current_view()
        if v is not None and v.preview:
            if v.has_metadata:
                self.review_requested.emit(v.id)
        else:
            self.open_destination()

    def start_without_preview(self) -> None:
        v = self.current_view()
        if v is None or not v.preview:
            return
        self.bridge.run(lambda: self.ctx.transfers.confirm_preview(v.id, save_path=v.save_path), None,
                        lambda exc: self.message.emit("error", str(exc)))

    def _context_menu(self, pos) -> None:
        if not self.selected_ids():
            return
        menu = QMenu(self)
        current = self.current_view()
        if current is not None and current.preview:
            review = menu.addAction("Review files and destination…", lambda: self.review_requested.emit(current.id))
            review.setEnabled(current.has_metadata)
            menu.addAction("Start without preview (all files, default destination)", self.start_without_preview)
            menu.addSeparator()
        menu.addAction("Start", self.start_selected)
        menu.addAction("Pause", self.pause_selected)
        menu.addAction("Re-check existing data", self.recheck_selected)
        menu.addSeparator()
        menu.addAction("Open destination folder", self.open_destination)
        menu.addAction("Move storage…", self.move_storage)
        menu.addAction("Limits…", self.edit_limits)
        menu.addAction("Edit trackers…", self.edit_trackers)
        categories = menu.addMenu("Category")
        categories.addAction("(none)", lambda: self.set_category(""))
        for name in self.ctx.settings.get().general.categories:
            categories.addAction(name, lambda n=name: self.set_category(n))
        menu.addSeparator()
        menu.addAction("Copy magnet link", self.copy_magnet)
        menu.addAction("Export .torrent…", self.export_torrent)
        menu.addSeparator()
        menu.addAction("Remove…", self.remove_selected)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def _files_menu(self, pos) -> None:
        v = self.current_view()
        rows = sorted({i.row() for i in self.files_table.selectionModel().selectedRows()})
        if v is None or not rows:
            return
        proxy = self.files_table.model()
        chosen = [proxy.index(r, 0).data(ROW_ROLE).index for r in rows]

        def apply(priority: int) -> None:
            def work():
                details = self.ctx.transfers.details(v.id)
                if details is None or not details.files:
                    raise RuntimeError("The file list is not available yet.")
                priorities = [f.priority for f in details.files]
                for index in chosen:
                    priorities[index] = priority
                self.ctx.transfers.set_file_priorities(v.id, priorities)

            self.bridge.run(work, lambda _: self._poll_details(force=True),
                            lambda exc: self.message.emit("error", str(exc)))

        menu = QMenu(self)
        for value, label in ((7, "High priority"), (4, "Normal priority"), (1, "Low priority"), (0, "Skip (do not download)")):
            menu.addAction(label, lambda p=value: apply(p))
        menu.exec(self.files_table.viewport().mapToGlobal(pos))


class _SortProxy(TransferFilterProxy.__mro__[1]):  # QSortFilterProxyModel without the transfer filter
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSortRole(SORT_ROLE)
