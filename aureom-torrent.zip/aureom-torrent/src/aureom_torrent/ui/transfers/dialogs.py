"""Dialogs for adding, reviewing, limiting and removing transfers."""

from __future__ import annotations

import os
import shutil

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMenu, QMessageBox,
                               QPlainTextEdit, QPushButton, QRadioButton, QSpinBox, QTableView, QVBoxLayout,
                               QWidget)

from ...domain.transfers import FilePriority, TorrentMetadata
from ..format import format_size

PRIORITY_NAMES = {0: "Skip", 1: "Low", 4: "Normal", 7: "High"}


def priority_name(value: int) -> str:
    if value in PRIORITY_NAMES:
        return PRIORITY_NAMES[value]
    return "Low" if value < 4 else ("Normal" if value < 6 else "High")


def note(text: str, role: str = "note") -> QLabel:
    label = QLabel(text)
    label.setWordWrap(True)
    label.setProperty("role", role)
    label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    return label


def muted(text: str) -> QLabel:
    label = QLabel(text)
    label.setWordWrap(True)
    label.setProperty("role", "muted")
    return label


class FileSelectionModel(QAbstractTableModel):
    """Flat, lazily painted file list with a check box per file (scales to very large torrents)."""

    HEADERS = ("File", "Size", "Priority")

    def __init__(self, metadata: TorrentMetadata, priorities: list[int] | None = None, parent=None):
        super().__init__(parent)
        self._files = list(metadata.files)
        self._visible = [i for i, f in enumerate(self._files) if not f.pad]
        if priorities and len(priorities) == len(self._files):
            self._priorities = list(priorities)
        else:
            self._priorities = [0 if f.pad else int(FilePriority.NORMAL) for f in self._files]
        self._prefix = metadata.name + "/" if len(self._visible) > 1 or (
            self._visible and "/" in self._files[self._visible[0]].path) else ""

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._visible)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else 3

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self.HEADERS[section]
        return None

    def flags(self, index):
        flags = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
        if index.column() == 0:
            flags |= Qt.ItemFlag.ItemIsUserCheckable
        return flags

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        i = self._visible[index.row()]
        f = self._files[i]
        if role == Qt.ItemDataRole.DisplayRole:
            if index.column() == 0:
                return f.path[len(self._prefix):] if self._prefix and f.path.startswith(self._prefix) else f.path
            if index.column() == 1:
                return format_size(f.size)
            return priority_name(self._priorities[i])
        if role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            return Qt.CheckState.Checked if self._priorities[i] > 0 else Qt.CheckState.Unchecked
        if role == Qt.ItemDataRole.TextAlignmentRole and index.column() == 1:
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        if role == Qt.ItemDataRole.ToolTipRole:
            return f.path
        return None

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if index.isValid() and role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            checked = value in (Qt.CheckState.Checked, Qt.CheckState.Checked.value, 2)
            self.set_priority([index.row()], int(FilePriority.NORMAL) if checked else 0)
            return True
        return False

    def set_priority(self, rows: list[int], priority: int) -> None:
        for row in rows:
            self._priorities[self._visible[row]] = priority
        if rows:
            self.dataChanged.emit(self.index(min(rows), 0), self.index(max(rows), 2))

    def set_all(self, priority: int) -> None:
        self.set_priority(list(range(len(self._visible))), priority)

    def priorities(self) -> list[int]:
        return list(self._priorities)

    def selected_size(self) -> int:
        return sum(self._files[i].size for i in self._visible if self._priorities[i] > 0)

    def selected_count(self) -> int:
        return sum(1 for i in self._visible if self._priorities[i] > 0)


class FileSelectionView(QWidget):
    def __init__(self, metadata: TorrentMetadata, priorities: list[int] | None = None, parent=None):
        super().__init__(parent)
        self.model = FileSelectionModel(metadata, priorities, self)
        self.table = QTableView()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(24)
        self.table.setShowGrid(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._menu)
        self.table.setAccessibleName("Files in this torrent")
        self.summary = muted("")
        all_btn = QPushButton("Select &all")
        none_btn = QPushButton("Select &none")
        all_btn.clicked.connect(lambda: self.model.set_all(int(FilePriority.NORMAL)))
        none_btn.clicked.connect(lambda: self.model.set_all(0))
        row = QHBoxLayout()
        row.addWidget(self.summary, 1)
        row.addWidget(all_btn)
        row.addWidget(none_btn)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.table, 1)
        layout.addLayout(row)
        self.model.dataChanged.connect(lambda *_: self._update_summary())
        self._update_summary()

    def _update_summary(self) -> None:
        self.summary.setText(f"{self.model.selected_count()} of {self.model.rowCount()} files selected · "
                             f"{format_size(self.model.selected_size())}  (right-click to set priority)")

    def _menu(self, pos) -> None:
        rows = sorted({i.row() for i in self.table.selectionModel().selectedRows()})
        if not rows:
            return
        menu = QMenu(self)
        for value, label in ((7, "High priority"), (4, "Normal priority"), (1, "Low priority"), (0, "Skip (do not download)")):
            menu.addAction(label, lambda v=value: self.model.set_priority(rows, v))
        menu.exec(self.table.viewport().mapToGlobal(pos))


class DestinationRow(QWidget):
    def __init__(self, path: str, parent=None):
        super().__init__(parent)
        self.edit = QLineEdit(path)
        self.edit.setAccessibleName("Destination folder")
        self.setFocusProxy(self.edit)
        browse = QPushButton("&Browse…")
        browse.clicked.connect(self._browse)
        self.free = muted("")
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self.edit, 1)
        row.addWidget(browse)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addLayout(row)
        layout.addWidget(self.free)
        self.edit.textChanged.connect(self._update_free)
        self._update_free()

    def _browse(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, "Choose destination folder", self.edit.text())
        if chosen:
            self.edit.setText(chosen)

    def _update_free(self) -> None:
        # disk_usage on a local path is a single cheap statvfs call
        probe = self.edit.text().strip()
        while probe and not os.path.exists(probe) and os.path.dirname(probe) != probe:
            probe = os.path.dirname(probe)
        try:
            self.free.setText(f"{format_size(shutil.disk_usage(probe).free)} free at this location" if probe else "")
        except OSError:
            self.free.setText("")

    def path(self) -> str:
        return os.path.abspath(os.path.expanduser(self.edit.text().strip())) if self.edit.text().strip() else ""


def category_combo(categories: list[str], current: str = "") -> QComboBox:
    combo = QComboBox()
    combo.setEditable(True)
    combo.addItem("")
    combo.addItems(categories)
    combo.setCurrentText(current)
    combo.setAccessibleName("Category")
    return combo


class TorrentReviewDialog(QDialog):
    """Preview a torrent's files, choose what to download and where, then start or add paused.

    Used both for .torrent files and for a magnet link whose metadata has been retrieved.
    """

    def __init__(self, metadata: TorrentMetadata, *, save_path: str, categories: list[str], add_paused: bool,
                 title: str = "Add torrent", duplicate_note: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(720, 560)
        layout = QVBoxLayout(self)
        heading = QLabel(metadata.name)
        heading.setProperty("role", "heading")
        heading.setWordWrap(True)
        layout.addWidget(heading)
        facts = [f"{format_size(metadata.total_size)} in {len(metadata.real_files)} file(s)",
                 {"v1": "BitTorrent v1", "v2": "BitTorrent v2", "hybrid": "Hybrid (v1 + v2)"}[metadata.identity.kind],
                 f"{metadata.num_pieces:,} pieces of {format_size(metadata.piece_length)}"]
        if metadata.private:
            facts.append("private (DHT, peer exchange and local discovery stay off for this torrent)")
        layout.addWidget(muted(" · ".join(facts)))
        if metadata.comment:
            layout.addWidget(muted(f"Comment: {metadata.comment[:300]}"))
        if duplicate_note:
            layout.addWidget(note(duplicate_note))
        self.files = FileSelectionView(metadata)
        layout.addWidget(self.files, 1)

        form = QFormLayout()
        self.destination = DestinationRow(save_path)
        form.addRow("&Destination:", self.destination)
        self.category = category_combo(categories)
        form.addRow("&Category:", self.category)
        self.start_now = QRadioButton("&Start immediately")
        self.paused = QRadioButton("Add &paused")
        (self.paused if add_paused else self.start_now).setChecked(True)
        row = QHBoxLayout()
        row.addWidget(self.start_now)
        row.addWidget(self.paused)
        row.addStretch(1)
        form.addRow("When added:", row)
        layout.addLayout(form)
        layout.addWidget(muted("Piece verification confirms that data matches this torrent's metadata. It does not "
                               "show that the files are safe or that the publisher is trustworthy. Downloaded files "
                               "are never opened automatically."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Add transfer")
        buttons.button(QDialogButtonBox.StandardButton.Ok).setProperty("role", "primary")
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self) -> None:
        if not self.destination.path():
            QMessageBox.warning(self, self.windowTitle(), "Choose a destination folder.")
            return
        if self.files.model.selected_count() == 0:
            QMessageBox.warning(self, self.windowTitle(), "Select at least one file to download.")
            return
        self.accept()

    def values(self) -> dict:
        return {"save_path": self.destination.path(), "category": self.category.currentText().strip(),
                "paused": self.paused.isChecked(), "file_priorities": self.files.model.priorities()}


class AddMagnetDialog(QDialog):
    def __init__(self, *, save_path: str, categories: list[str], add_paused: bool, preview_default: bool,
                 initial: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add magnet link")
        self.resize(640, 420)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Paste one or more magnet links (one per line):"))
        self.text = QPlainTextEdit(initial)
        self.text.setPlaceholderText("magnet:?xt=urn:btih:…")
        self.text.setAccessibleName("Magnet links")
        self.text.setTabChangesFocus(True)
        layout.addWidget(self.text, 1)
        form = QFormLayout()
        self.preview = QCheckBox("&Preview files before downloading (retrieves metadata only)")
        self.preview.setChecked(preview_default)
        form.addRow("", self.preview)
        self.destination = DestinationRow(save_path)
        form.addRow("&Destination:", self.destination)
        self.category = category_combo(categories)
        form.addRow("&Category:", self.category)
        self.paused = QCheckBox("Add p&aused")
        self.paused.setChecked(add_paused)
        form.addRow("", self.paused)
        layout.addLayout(form)
        layout.addWidget(note(
            "A magnet link carries no file list. To show one, the application asks peers for the torrent's "
            "metadata; those peers (and any tracker or DHT node contacted) can see your IP address. With preview "
            "enabled no file data is requested until you have reviewed the files and destination."))
        self.preview.toggled.connect(self._sync)
        self._sync()
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Add")
        buttons.button(QDialogButtonBox.StandardButton.Ok).setProperty("role", "primary")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _sync(self) -> None:
        self.paused.setEnabled(not self.preview.isChecked())

    def values(self) -> dict:
        links = [line.strip() for line in self.text.toPlainText().splitlines() if line.strip()]
        return {"links": links[:100], "save_path": self.destination.path(),
                "category": self.category.currentText().strip(),
                "paused": self.paused.isChecked() and not self.preview.isChecked(),
                "preview": self.preview.isChecked()}


class RemoveDialog(QDialog):
    """Removal and deletion are separate, explicit choices."""

    def __init__(self, names: list[str], destinations: list[str], can_delete: bool, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Remove transfers")
        layout = QVBoxLayout(self)
        shown = "\n".join(f"• {n}" for n in names[:8]) + (f"\n… and {len(names) - 8} more" if len(names) > 8 else "")
        layout.addWidget(QLabel(f"Remove {len(names)} transfer(s)?\n\n{shown}"))
        self.keep = QRadioButton("&Remove from AUREOM TORRENT only — downloaded files stay on disk")
        self.delete = QRadioButton("Remove and &delete the downloaded data")
        self.keep.setChecked(True)
        self.delete.setEnabled(can_delete)
        group = QButtonGroup(self)
        group.addButton(self.keep)
        group.addButton(self.delete)
        layout.addWidget(self.keep)
        layout.addWidget(self.delete)
        self.warning = note("Deleting removes only the files that belong to these torrents, inside their own "
                            "destination folders:\n" + "\n".join(sorted(set(destinations))[:6])
                            + "\nOther files in those folders are left alone. This cannot be undone.")
        self.warning.setVisible(False)
        layout.addWidget(self.warning)
        self.delete.toggled.connect(self.warning.setVisible)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.ok = buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.ok.setText("Remove")
        self.delete.toggled.connect(lambda on: (self.ok.setText("Delete data and remove" if on else "Remove"),
                                                self.ok.setProperty("role", "danger" if on else ""),
                                                self.ok.style().unpolish(self.ok), self.ok.style().polish(self.ok)))
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._count = len(names)

    def _accept(self) -> None:
        if self.delete.isChecked():
            answer = QMessageBox.warning(
                self, "Delete downloaded data",
                f"Permanently delete the downloaded data of {self._count} transfer(s)?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel, QMessageBox.StandardButton.Cancel)
            if answer != QMessageBox.StandardButton.Yes:
                return
        self.accept()

    def delete_data(self) -> bool:
        return self.delete.isChecked()


class LimitsDialog(QDialog):
    def __init__(self, record, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Transfer limits")
        form = QFormLayout(self)
        self.down = QSpinBox()
        self.up = QSpinBox()
        for box, value in ((self.down, record.download_limit), (self.up, record.upload_limit)):
            box.setRange(0, 10_000_000)
            box.setSuffix(" KiB/s")
            box.setSpecialValueText("Unlimited")
            box.setValue(value // 1024)
        form.addRow("&Download limit:", self.down)
        form.addRow("&Upload limit:", self.up)
        self.ratio_mode = QComboBox()
        self.ratio_mode.addItems(["Use the global setting", "No ratio limit", "Stop seeding at ratio:"])
        self.ratio = QSpinBox()
        self.ratio.setRange(0, 100_000)
        self.ratio.setSuffix(" %")
        self.ratio.setValue(200)
        if record.ratio_limit_permille is None:
            self.ratio_mode.setCurrentIndex(0)
        elif record.ratio_limit_permille < 0:
            self.ratio_mode.setCurrentIndex(1)
        else:
            self.ratio_mode.setCurrentIndex(2)
            self.ratio.setValue(record.ratio_limit_permille // 10)
        row = QHBoxLayout()
        row.addWidget(self.ratio_mode)
        row.addWidget(self.ratio)
        form.addRow("Share ratio:", row)
        self.time_mode = QComboBox()
        self.time_mode.addItems(["Use the global setting", "No time limit", "Stop seeding after:"])
        self.minutes = QSpinBox()
        self.minutes.setRange(0, 1_000_000)
        self.minutes.setSuffix(" min")
        self.minutes.setValue(60)
        if record.seed_time_limit_s is None:
            self.time_mode.setCurrentIndex(0)
        elif record.seed_time_limit_s < 0:
            self.time_mode.setCurrentIndex(1)
        else:
            self.time_mode.setCurrentIndex(2)
            self.minutes.setValue(record.seed_time_limit_s // 60)
        row2 = QHBoxLayout()
        row2.addWidget(self.time_mode)
        row2.addWidget(self.minutes)
        form.addRow("Seeding time:", row2)
        self.ratio_mode.currentIndexChanged.connect(lambda i: self.ratio.setEnabled(i == 2))
        self.time_mode.currentIndexChanged.connect(lambda i: self.minutes.setEnabled(i == 2))
        self.ratio.setEnabled(self.ratio_mode.currentIndex() == 2)
        self.minutes.setEnabled(self.time_mode.currentIndex() == 2)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def values(self) -> dict:
        ratio = (None, -1, self.ratio.value() * 10)[self.ratio_mode.currentIndex()]
        seconds = (None, -1, self.minutes.value() * 60)[self.time_mode.currentIndex()]
        return {"download_limit": self.down.value() * 1024, "upload_limit": self.up.value() * 1024,
                "ratio_limit_permille": ratio, "seed_time_limit_s": seconds}


class TrackersDialog(QDialog):
    def __init__(self, trackers: list[tuple[str, int]], private: bool, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit trackers")
        self.resize(560, 380)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("One tracker address per line (http, https or udp). "
                                "Leave an empty line to start a new tier."))
        self.text = QPlainTextEdit()
        self.text.setAccessibleName("Tracker addresses")
        lines: list[str] = []
        last_tier = None
        for url, tier in sorted(trackers, key=lambda t: t[1]):
            if last_tier is not None and tier != last_tier:
                lines.append("")
            lines.append(url)
            last_tier = tier
        self.text.setPlainText("\n".join(lines))
        layout.addWidget(self.text, 1)
        if private:
            layout.addWidget(note("This torrent is private: peers are found through its trackers only. DHT, peer "
                                  "exchange and local discovery remain disabled for it by the engine."))
        layout.addWidget(muted("Tracker addresses can contain personal passkeys. They are redacted in logs and "
                               "diagnostic exports."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def trackers(self) -> list[tuple[str, int]]:
        out: list[tuple[str, int]] = []
        tier = 0
        pending_gap = False
        for line in self.text.toPlainText().splitlines():
            line = line.strip()
            if not line:
                pending_gap = bool(out)
                continue
            if pending_gap:
                tier += 1
                pending_gap = False
            out.append((line, tier))
        return out
