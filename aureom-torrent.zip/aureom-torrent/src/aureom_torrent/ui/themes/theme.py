"""Visual identity: midnight-blue navigation, warm ivory workspaces, restrained copper accents,
cyan for active transfers.  Light and dark variants share one style sheet template.

Every text/background pair used for body text meets WCAG AA (4.5:1); a unit test
(`tests/unit/test_theme_contrast.py`) checks the pairs listed in ``CONTRAST_PAIRS``.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Palette:
    name: str
    nav_bg: str
    nav_text: str
    nav_muted: str
    nav_selected_bg: str
    nav_selected_text: str
    workspace: str
    surface: str
    surface_alt: str
    border: str
    text: str
    muted: str
    accent: str  # copper: primary buttons, selected nav marker, links
    accent_hover: str
    accent_text: str  # text on accent
    active: str  # cyan: active transfers
    complete: str
    paused: str
    error: str
    warning: str
    selection_bg: str
    selection_text: str
    track: str  # progress-bar track


LIGHT = Palette(
    name="light",
    nav_bg="#0F1B33", nav_text="#C9D3E6", nav_muted="#8D9BB8", nav_selected_bg="#1C2E52",
    nav_selected_text="#FFFFFF",
    workspace="#FAF6EE", surface="#FFFDF8", surface_alt="#F3EDE0", border="#DDD3BF",
    text="#1E2430", muted="#5A6070",
    accent="#A4551F", accent_hover="#8B4617", accent_text="#FFFFFF",
    active="#0A7F99", complete="#4B6B8A", paused="#6F7480", error="#A8261C", warning="#8A5A00",
    selection_bg="#E6DCC6", selection_text="#1E2430", track="#E9E1D0",
)

DARK = Palette(
    name="dark",
    nav_bg="#0A1224", nav_text="#C3CDE2", nav_muted="#8391AF", nav_selected_bg="#1A2A4C",
    nav_selected_text="#FFFFFF",
    workspace="#141B29", surface="#1A2231", surface_alt="#202A3C", border="#313D55",
    text="#EDE7DA", muted="#A3ABBB",
    accent="#D9935A", accent_hover="#E6A672", accent_text="#1A1206",
    active="#3CC6E0", complete="#8FB0D0", paused="#9AA1AE", error="#F0857B", warning="#E0B35A",
    selection_bg="#2B3A57", selection_text="#F5F0E4", track="#2A3447",
)

# (foreground attribute, background attribute) pairs that carry text.
CONTRAST_PAIRS = (
    ("text", "workspace"), ("text", "surface"), ("text", "surface_alt"), ("muted", "workspace"),
    ("muted", "surface"), ("nav_text", "nav_bg"), ("nav_muted", "nav_bg"),
    ("nav_selected_text", "nav_selected_bg"), ("accent_text", "accent"), ("accent", "workspace"),
    ("accent", "surface"), ("error", "surface"), ("error", "workspace"), ("warning", "surface"),
    ("active", "surface"), ("complete", "surface"), ("paused", "surface"), ("selection_text", "selection_bg"),
)


def _luminance(hex_colour: str) -> float:
    r, g, b = (int(hex_colour[i:i + 2], 16) / 255 for i in (1, 3, 5))

    def channel(c: float) -> float:
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)


def contrast_ratio(a: str, b: str) -> float:
    la, lb = sorted((_luminance(a), _luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def palette_for(theme: str, system_dark: bool = False) -> Palette:
    if theme == "dark" or (theme == "system" and system_dark):
        return DARK
    return LIGHT


ROW_HEIGHT = {"compact": 24, "comfortable": 34}

FONT_STACK = '"Inter", "Segoe UI", "SF Pro Text", "Noto Sans", "DejaVu Sans", sans-serif'


def arrow_icons(directory, p: Palette) -> dict[str, str]:
    """Paint the small up/down arrows used by spin boxes and combo boxes in the theme's colours.

    Returns ``{"up": path, "down": path}`` with forward slashes (as Qt style sheets require).
    Must be called on the GUI thread after the QApplication exists.
    """
    from pathlib import Path

    from PySide6.QtCore import QPointF, Qt
    from PySide6.QtGui import QColor, QImage, QPainter, QPolygonF

    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    out: dict[str, str] = {}
    for name, points in (("up", [(1, 6), (5, 1), (9, 6)]), ("down", [(1, 1), (5, 6), (9, 1)])):
        path = directory / f"arrow-{name}-{p.name}.png"
        image = QImage(10, 7, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(p.muted))
        painter.drawPolygon(QPolygonF([QPointF(x, y) for x, y in points]))
        painter.end()
        image.save(str(path))
        out[name] = path.as_posix()
    return out


def stylesheet(p: Palette, density: str = "compact", arrows: dict[str, str] | None = None) -> str:
    pad = "3px 8px" if density == "compact" else "7px 10px"
    up = f'image: url("{arrows["up"]}");' if arrows else "image: none;"
    down = f'image: url("{arrows["down"]}");' if arrows else "image: none;"
    return f"""
* {{ font-family: {FONT_STACK}; font-size: 13px; }}
QMainWindow, QDialog, QWidget#workspace {{ background: {p.workspace}; color: {p.text}; }}
QWidget {{ color: {p.text}; }}
QLabel[role="muted"], QLabel#muted {{ color: {p.muted}; }}
QLabel[role="heading"] {{ font-size: 18px; font-weight: 600; color: {p.text}; }}
QLabel[role="subheading"] {{ font-size: 13px; font-weight: 600; color: {p.text}; }}
QLabel[role="error"] {{ color: {p.error}; }}
QLabel[role="warning"] {{ color: {p.warning}; }}
QLabel[role="note"] {{ color: {p.muted}; background: {p.surface_alt}; border: 1px solid {p.border};
    border-radius: 4px; padding: 8px 10px; }}

/* navigation */
QWidget#nav {{ background: {p.nav_bg}; }}
QLabel#brandTitle {{ color: #FFFFFF; font-size: 14px; font-weight: 700; letter-spacing: 3px; }}
QLabel#brandLine {{ color: {p.nav_muted}; font-size: 11px; }}
QFrame#brandRule {{ background: {p.accent}; max-height: 2px; min-height: 2px; border: none; }}
QListWidget#navList {{ background: {p.nav_bg}; color: {p.nav_text}; border: none; outline: none; }}
QListWidget#navList::item {{ padding: 7px 14px; border-left: 3px solid transparent; }}
QListWidget#navList::item:hover {{ background: {p.nav_selected_bg}; }}
QListWidget#navList::item:selected {{ background: {p.nav_selected_bg}; color: {p.nav_selected_text};
    border-left: 3px solid {p.accent}; }}
QListWidget#navList::item:disabled {{ color: {p.nav_muted}; padding: 10px 14px 3px 14px; font-size: 11px; }}
QListWidget#navList::item:selected:focus {{ border-left: 3px solid #FFFFFF; }}

/* toolbar + status bar */
QToolBar {{ background: {p.surface}; border: none; border-bottom: 1px solid {p.border}; padding: 5px 10px; spacing: 4px; }}
QToolButton {{ padding: 5px 10px; border: 1px solid transparent; border-radius: 4px; color: {p.text}; }}
QToolButton:hover {{ background: {p.surface_alt}; border-color: {p.border}; }}
QToolButton:pressed {{ background: {p.selection_bg}; }}
QToolButton:focus {{ border-color: {p.accent}; }}
QToolButton:disabled {{ color: {p.muted}; }}
QStatusBar {{ background: {p.surface}; border-top: 1px solid {p.border}; color: {p.muted}; }}
QStatusBar QLabel {{ color: {p.muted}; padding: 2px 8px; }}
QStatusBar::item {{ border: none; }}

/* inputs */
QLineEdit, QPlainTextEdit, QTextEdit, QTextBrowser, QSpinBox, QComboBox, QDateTimeEdit, QTimeEdit {{
    background: {p.surface}; border: 1px solid {p.border}; border-radius: 4px; padding: 4px 6px;
    selection-background-color: {p.accent}; selection-color: {p.accent_text}; color: {p.text}; }}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {{ border: 1px solid {p.accent}; }}
QComboBox QAbstractItemView {{ background: {p.surface}; color: {p.text}; selection-background-color: {p.selection_bg};
    selection-color: {p.selection_text}; border: 1px solid {p.border}; }}
QSpinBox, QTimeEdit {{ max-width: 230px; padding-right: 18px; }}
QSpinBox::up-button, QSpinBox::down-button, QTimeEdit::up-button, QTimeEdit::down-button {{
    subcontrol-origin: border; width: 18px; border: none; background: transparent; }}
QSpinBox::up-button, QTimeEdit::up-button {{ subcontrol-position: top right; }}
QSpinBox::down-button, QTimeEdit::down-button {{ subcontrol-position: bottom right; }}
QSpinBox::up-arrow, QTimeEdit::up-arrow {{ {up} width: 10px; height: 7px; }}
QSpinBox::down-arrow, QTimeEdit::down-arrow {{ {down} width: 10px; height: 7px; }}
QComboBox {{ padding-right: 22px; }}
QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: center right; width: 20px; border: none; }}
QComboBox::down-arrow {{ {down} width: 10px; height: 7px; }}
QCheckBox, QRadioButton {{ spacing: 6px; color: {p.text}; }}
QCheckBox:focus, QRadioButton:focus {{ color: {p.accent}; }}
QPushButton {{ background: {p.surface}; border: 1px solid {p.border}; border-radius: 4px; padding: 5px 12px; color: {p.text}; }}
QPushButton:hover {{ background: {p.surface_alt}; }}
QPushButton:focus {{ border: 1px solid {p.accent}; }}
QPushButton:disabled {{ color: {p.muted}; background: {p.surface_alt}; }}
QPushButton[role="primary"] {{ background: {p.accent}; color: {p.accent_text}; border: 1px solid {p.accent}; font-weight: 600; }}
QPushButton[role="primary"]:hover {{ background: {p.accent_hover}; border-color: {p.accent_hover}; }}
QPushButton[role="primary"]:focus {{ border: 2px solid {p.text}; }}
QPushButton[role="primary"]:disabled {{ background: {p.surface_alt}; color: {p.muted}; border-color: {p.border}; }}
QPushButton[role="danger"] {{ color: {p.error}; border-color: {p.error}; }}

/* tables */
QTableView, QTreeView, QListView, QTreeWidget, QListWidget, QTableWidget {{
    background: {p.surface}; alternate-background-color: {p.surface_alt}; border: 1px solid {p.border};
    gridline-color: transparent; selection-background-color: {p.selection_bg}; selection-color: {p.selection_text};
    color: {p.text}; outline: none; }}
QTableView::item, QTreeView::item, QListView::item, QTreeWidget::item, QTableWidget::item {{ padding: {pad}; border: none; }}
QTableView::item:selected, QTreeView::item:selected, QListView::item:selected, QTreeWidget::item:selected,
QTableWidget::item:selected {{ background: {p.selection_bg}; color: {p.selection_text}; }}
QTableView:focus, QTreeView:focus, QListView:focus, QTreeWidget:focus, QTableWidget:focus {{ border: 1px solid {p.accent}; }}
QHeaderView::section {{ background: {p.surface_alt}; color: {p.muted}; border: none; border-bottom: 1px solid {p.border};
    border-right: 1px solid {p.border}; padding: 4px 8px; font-weight: 600; font-size: 12px; }}
QTableCornerButton::section {{ background: {p.surface_alt}; border: none; }}

/* tabs */
QTabWidget::pane {{ border: 1px solid {p.border}; background: {p.surface}; top: -1px; }}
QTabBar::tab {{ background: transparent; color: {p.muted}; padding: 6px 14px; border: none; border-bottom: 2px solid transparent; }}
QTabBar::tab:selected {{ color: {p.text}; border-bottom: 2px solid {p.accent}; font-weight: 600; }}
QTabBar::tab:hover {{ color: {p.text}; }}
QTabBar::tab:focus {{ color: {p.accent}; }}

QSplitter::handle {{ background: {p.border}; }}
QSplitter::handle:vertical {{ height: 1px; }}
QSplitter::handle:horizontal {{ width: 1px; }}
QScrollBar:vertical {{ background: {p.workspace}; width: 11px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {p.border}; border-radius: 4px; min-height: 28px; margin: 2px; }}
QScrollBar:horizontal {{ background: {p.workspace}; height: 11px; margin: 0; }}
QScrollBar::handle:horizontal {{ background: {p.border}; border-radius: 4px; min-width: 28px; margin: 2px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QProgressBar {{ background: {p.track}; border: none; border-radius: 3px; text-align: center; color: {p.text}; max-height: 14px; }}
QProgressBar::chunk {{ background: {p.active}; border-radius: 3px; }}
QGroupBox {{ border: 1px solid {p.border}; border-radius: 4px; margin-top: 14px; padding: 10px 10px 8px 10px; background: {p.surface}; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 8px; padding: 0 4px; color: {p.muted}; font-weight: 600; }}
QMenu {{ background: {p.surface}; border: 1px solid {p.border}; color: {p.text}; padding: 4px; }}
QMenu::item {{ padding: 5px 22px 5px 12px; border-radius: 3px; }}
QMenu::item:selected {{ background: {p.selection_bg}; color: {p.selection_text}; }}
QMenu::item:disabled {{ color: {p.muted}; }}
QMenu::separator {{ height: 1px; background: {p.border}; margin: 4px 6px; }}
QToolTip {{ background: {p.nav_bg}; color: #FFFFFF; border: none; padding: 4px 6px; }}
QFrame#banner {{ background: {p.surface_alt}; border: 1px solid {p.border}; border-left: 3px solid {p.accent}; border-radius: 3px; }}
QFrame#banner[level="error"] {{ border-left: 3px solid {p.error}; }}
QScrollArea {{ border: none; background: transparent; }}
QWidget#scrollBody {{ background: {p.workspace}; }}
QWidget#panel {{ background: {p.surface}; }}
QScrollArea#panelScroll {{ background: {p.surface}; border: none; }}
"""
