"""Application composition root.

``AppContext`` builds every service with explicit dependencies (dependency
injection), so tests can substitute a fake engine, fetcher, secret store or
Lightning backend.  It contains no Qt code; ``ui.main_window`` receives a
context and a ``Bridge``.
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any, Callable, Mapping

from .diagnostics.export import DiagnosticsCollector
from .diagnostics.logs import configure_logging
from .engine.events import ShutdownReport
from .engine.interface import TorrentCodec, TorrentCreator, TorrentEngine
from .net.http import HttpFetcher, HttpPolicy, HttpResult
from .persistence.database import Database
from .services.event_pump import EventPump
from .services.transfer_service import TransferService
from .settings.models import AppSettings
from .settings.paths import AppPaths, default_data_dir
from .settings.secrets import SecretStore, open_secret_store
from .settings.store import SettingsStore
from .util.clock import Clock, SystemClock

log = logging.getLogger(__name__)

TRANSFER_TICK_S = 1.0
FEED_TICK_S = 30.0
PAYMENT_TICK_S = 20.0


class PolicyFetcher:
    """A Fetcher whose policy is read from the current settings at every call.

    Each service (RSS, publishing, payments/LNURL) gets its own instance bound
    to its own network section, so one service's proxy is never applied to –
    or bypassed by – another.
    """

    def __init__(self, policy: Callable[[], HttpPolicy]):
        self._policy = policy

    def fetch(self, url: str, *, method: str = "GET", headers: Mapping[str, str] | None = None,
              body: bytes | None = None, policy: HttpPolicy | None = None) -> HttpResult:
        effective = policy or self._policy()
        return HttpFetcher(effective).fetch(url, method=method, headers=headers, body=body, policy=effective)


class AppContext:
    def __init__(self, data_dir: Path | None = None, *, engine: TorrentEngine | None = None,
                 codec: TorrentCodec | None = None, creator: TorrentCreator | None = None,
                 secrets: SecretStore | None = None, clock: Clock | None = None, isolated: bool = False,
                 lightning_backend: Callable[[], Any] | None = None, console_log: bool = False):
        self.paths = AppPaths(Path(data_dir) if data_dir else default_data_dir())
        self.paths.ensure()
        configure_logging(self.paths.logs_dir, console=console_log)
        self.clock = clock or SystemClock()
        self.isolated = isolated
        self.db = Database(self.paths.database)
        self.settings = SettingsStore(self.db)
        self.secrets = secrets or open_secret_store()
        self.startup_notes: list[str] = list(self.settings.warnings)
        if self.db.recovered_from:
            self.startup_notes.append(
                "The application database was unreadable and has been set aside as "
                f"{self.db.recovered_from}. A new, empty database was created; files on disk were not touched.")

        if engine is None or codec is None or creator is None:
            from .engine.libtorrent_adapter import LibtorrentEngine
            from .engine.libtorrent_codec import LibtorrentCodec, LibtorrentCreator

            engine = engine or LibtorrentEngine()
            codec = codec or LibtorrentCodec()
            creator = creator or LibtorrentCreator()
        self.engine, self.codec, self.creator = engine, codec, creator

        get = self.settings.get
        self.transfers = TransferService(self.db, engine, codec, self.paths, get, self.clock,
                                         secrets=self.secrets, isolated=isolated)
        self.pump = EventPump(self._on_engine_event)

        from .feeds.service import FeedService
        from .payments.service import PaymentService
        from .publishing.service import PublishService

        self.feed_fetcher = PolicyFetcher(lambda: HttpPolicy.from_settings(get().feeds_network))
        self.publish_fetcher = PolicyFetcher(lambda: HttpPolicy.from_settings(get().publishing_network))
        # LNURL requests go to a publisher's public server: they use the payment network's proxy
        # and limits but never the loopback/private allowance granted to the configured node.
        self.lnurl_fetcher = PolicyFetcher(lambda: _lnurl_policy(get()))
        self.feeds = FeedService(self.db, self.feed_fetcher, self.transfers, get, self.clock)
        self.publishing = PublishService(self.db, creator, codec, self.transfers, self.secrets,
                                         self.publish_fetcher, get, self.clock, self.paths.exports_dir)
        self._lightning_override = lightning_backend
        self._backend_cache: tuple[tuple, Any] | None = None
        self.payments = PaymentService(self.db, self._lightning_backend, get, self.clock, self.lnurl_fetcher)

        self.diagnostics = DiagnosticsCollector()
        self.diagnostics.register("settings", lambda: self.settings.get().to_dict())
        self.diagnostics.register("credential_store", lambda: {"description": self.secrets.description,
                                                               "persistent": self.secrets.persistent})
        self.diagnostics.register("engine", lambda: {
            "capabilities": {"engine": engine.capabilities().engine, "version": engine.capabilities().version,
                             "notes": list(engine.capabilities().notes)},
            "events_delivered": self.pump.delivered, "status_snapshots_coalesced": self.pump.coalesced})
        self.diagnostics.register("transfers", self.transfers.diagnostics)
        self.diagnostics.register("feeds", self.feeds.diagnostics)
        self.diagnostics.register("publishing", self.publishing.diagnostics)
        self.diagnostics.register("payments", self.payments.diagnostics)
        self.diagnostics.register("startup_notes", lambda: list(self.startup_notes))

        self.settings.subscribe(lambda _settings: self.transfers.apply_settings())
        self._scheduler: threading.Thread | None = None
        self._stop = threading.Event()
        self._started = False
        self.reconciliation_summary = ""

    # ------------------------------------------------------------- backends
    def _lightning_backend(self):
        if self._lightning_override is not None:
            return self._lightning_override()
        settings = self.settings.get()
        pay = settings.payments
        if pay.backend != "lnd_rest" or not pay.lnd_url.strip():
            return None
        key = (pay.lnd_url, pay.lnd_tls_cert_path, repr(settings.payments_network))
        if self._backend_cache is None or self._backend_cache[0] != key:
            from .payments.adapters.lnd_rest import LndRestBackend

            backend = LndRestBackend(pay.lnd_url.strip(), secrets=self.secrets,
                                     policy=HttpPolicy.from_settings(settings.payments_network),
                                     tls_cert_path=pay.lnd_tls_cert_path.strip())
            self._backend_cache = (key, backend)
        return self._backend_cache[1]

    # ---------------------------------------------------------------- events
    def _on_engine_event(self, event: Any) -> None:
        self.transfers.handle_event(event)
        # Record a publisher manifest that is embedded in (and bound to) the torrent's metadata.
        from .engine.events import MetadataReceived

        if isinstance(event, MetadataReceived) and event.metadata.embedded_manifest:
            try:
                self.publishing.record_embedded_manifest(event.metadata, event.transfer_id)
            except Exception as exc:
                log.warning("embedded publisher manifest ignored: %s", exc)

    def note_added_torrent(self, transfer_id: str) -> None:
        """Record an embedded manifest for a transfer added from a .torrent file."""
        metadata = self.transfers.metadata(transfer_id)
        if metadata is not None and metadata.embedded_manifest:
            try:
                self.publishing.record_embedded_manifest(metadata, transfer_id)
            except Exception as exc:
                log.warning("embedded publisher manifest ignored: %s", exc)

    def manifest_summary(self, transfer_id: str) -> dict[str, Any] | None:
        """Publisher information for the details pane (plain data; never triggers a payment)."""
        record = self.transfers.record(transfer_id)
        if record is None:
            return None
        records = self.publishing.manifests_for_transfer(transfer_id)
        if not records:
            records = self.publishing.manifests_for_identity(record.identity)
        if not records:
            return None
        chosen = next((r for r in records if r.provenance.value == "embedded"), records[0])
        manifest = chosen.manifest
        trust = self.publishing.assess(chosen)
        provenance = {
            "embedded": "embedded in the torrent metadata (bound to its info-hash)",
            "external": "imported from outside the torrent (untrusted)",
            "local": "written on this device",
        }.get(chosen.provenance.value, chosen.provenance.value)
        lines = [f"Publisher: {manifest.publisher}", f"Identity: {trust.label}", f"Source: {provenance}"]
        if manifest.description:
            lines.append(f"Description: {manifest.description}")
        for title, value in (("Website", manifest.website), ("Feed", manifest.feed_url),
                             ("Licence", manifest.licence), ("Lightning address", manifest.lightning_address),
                             ("Bitcoin address", manifest.bitcoin_address
                              and f"{manifest.bitcoin_address} ({manifest.bitcoin_network})")):
            if value:
                lines.append(f"{title}: {value}")
        lines.append("")
        lines.append(trust.explanation)
        return {"text": "\n".join(lines), "name": manifest.publisher, "manifest_id": chosen.id,
                "verified": trust.verified, "trust_label": trust.label,
                "lightning_address": manifest.lightning_address, "bitcoin_address": manifest.bitcoin_address,
                "bitcoin_network": manifest.bitcoin_network}

    # -------------------------------------------------------------- lifecycle
    def start(self) -> None:
        if self._started:
            return
        self._started = True
        self.pump.start()
        self.engine.start(self.transfers.current_engine_settings(), self.pump.post)
        restored = self.transfers.restore()
        self.startup_notes.extend(self.transfers.startup_notes)
        log.info("startup: %d transfer(s) restored", restored)
        try:
            interrupted = self.publishing.recover_interrupted()
            if interrupted:
                self.startup_notes.append(
                    f"{interrupted} torrent creation job(s) were interrupted by the last shutdown and must be "
                    "started again from Publish & Share.")
        except Exception:
            log.exception("publishing recovery failed")
        self._scheduler = threading.Thread(target=self._schedule, name="aureom-scheduler", daemon=True)
        self._scheduler.start()

    def _schedule(self) -> None:
        # Pending payments are reconciled once at start-up; nothing is ever re-submitted.
        try:
            report = self.payments.reconcile_on_startup()
            self.reconciliation_summary = report.summary()
            if report.changed or report.notes:
                log.info("payments: %s", self.reconciliation_summary)
        except Exception:
            log.exception("payment reconciliation failed")
        next_feed = time.monotonic() + 5.0
        next_payment = time.monotonic() + PAYMENT_TICK_S
        while not self._stop.wait(TRANSFER_TICK_S):
            try:
                self.transfers.tick()
            except Exception:
                log.exception("transfer tick failed")
            now = time.monotonic()
            if now >= next_feed:
                next_feed = now + FEED_TICK_S
                try:
                    self.feeds.refresh_due()
                except Exception:
                    log.exception("scheduled feed refresh failed")
            if now >= next_payment:
                next_payment = now + PAYMENT_TICK_S
                try:
                    self.payments.poll_open()
                except Exception:
                    log.exception("payment status poll failed")

    def shutdown(self, timeout: float | None = None) -> ShutdownReport:
        """Stop background work and the engine within a bounded time; report unsaved resume state."""
        if not self._started:
            self.db.close()
            return ShutdownReport(clean=True, message="not started")
        self._started = False
        timeout = timeout if timeout is not None else float(self.settings.get().general.shutdown_timeout_s)
        self._stop.set()
        if self._scheduler is not None:
            self._scheduler.join(3.0)
        self.transfers.prepare_shutdown()
        report = self.engine.shutdown(timeout)
        self.pump.stop()
        if report.clean:
            log.info("shutdown: resume data saved for %d transfer(s)", report.resume_saved)
        else:
            log.error("shutdown: %s", report.message)
        self.db.close()
        return report


def _lnurl_policy(settings: AppSettings) -> HttpPolicy:
    net = settings.payments_network
    return HttpPolicy(timeout_s=float(net.timeout_s), max_bytes=min(int(net.max_response_bytes), 256 * 1024),
                      max_redirects=2, allow_http=False, allow_loopback=False, allow_private=False,
                      proxy_url=str(net.proxy_url or ""))
