"""SQLite persistence for publishing jobs, destinations, manifests and pinned keys."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from typing import Any

from ..domain.identity import TorrentIdentity
from ..persistence.database import Database
from .manifests import ManifestError, Provenance, PublisherManifest, SignatureStatus, parse_manifest
from .models import JobState, PublishDestination, PublishJob, PublishOperationResult

log = logging.getLogger(__name__)

MAX_OPERATIONS_PER_JOB = 100
MAX_MANIFESTS_LISTED = 500


@dataclass(frozen=True, slots=True)
class ManifestRecord:
    id: str
    manifest: PublisherManifest
    provenance: Provenance
    signature_status: SignatureStatus  # as verified when the record was stored
    transfer_id: str | None = None
    v1: str | None = None  # the torrent this record is associated with (may differ from manifest.identity
    v2: str | None = None  # for embedded manifests, which carry no identity of their own)
    created_at: int = 0

    @property
    def identity(self) -> TorrentIdentity | None:
        return TorrentIdentity(self.v1, self.v2) if (self.v1 or self.v2) else None


def new_id() -> str:
    return uuid.uuid4().hex


class PublishingRepository:
    def __init__(self, db: Database):
        self._db = db

    # -- jobs ---------------------------------------------------------------
    def insert_job(self, job: PublishJob) -> None:
        self._db.execute(
            "INSERT INTO publish_jobs(id, created_at, updated_at, state, source_path, torrent_path, name, format,"
            " total_size, file_count, piece_length, private, v1, v2, magnet, transfer_id, manifest_id, error,"
            " options, operations) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            self._job_values(job),
        )

    def update_job(self, job: PublishJob) -> None:
        values = self._job_values(job)
        self._db.execute(
            "UPDATE publish_jobs SET created_at=?, updated_at=?, state=?, source_path=?, torrent_path=?, name=?,"
            " format=?, total_size=?, file_count=?, piece_length=?, private=?, v1=?, v2=?, magnet=?,"
            " transfer_id=?, manifest_id=?, error=?, options=?, operations=? WHERE id=?",
            values[1:] + values[:1],
        )

    @staticmethod
    def _job_values(job: PublishJob) -> tuple[Any, ...]:
        ops = [op.to_dict() for op in job.operations[-MAX_OPERATIONS_PER_JOB:]]
        return (job.id, job.created_at, job.updated_at, job.state.value, job.source_path, job.torrent_path,
                job.name, job.format, job.total_size, job.file_count, job.piece_length, int(job.private),
                job.v1, job.v2, job.magnet, job.transfer_id, job.manifest_id, job.error,
                json.dumps(job.options, sort_keys=True), json.dumps(ops))

    @staticmethod
    def _job_from_row(row) -> PublishJob:
        try:
            options = json.loads(row["options"])
            if not isinstance(options, dict):
                options = {}
        except ValueError:
            options = {}
        try:
            raw_ops = json.loads(row["operations"])
            operations = [PublishOperationResult.from_dict(o) for o in raw_ops if isinstance(o, dict)]
        except ValueError:
            operations = []
        try:
            state = JobState(row["state"])
        except ValueError:
            state = JobState.FAILED
        return PublishJob(
            id=row["id"], state=state, created_at=row["created_at"], updated_at=row["updated_at"],
            source_path=row["source_path"], torrent_path=row["torrent_path"], name=row["name"],
            format=row["format"], total_size=row["total_size"], file_count=row["file_count"],
            piece_length=row["piece_length"], private=bool(row["private"]), v1=row["v1"], v2=row["v2"],
            magnet=row["magnet"], transfer_id=row["transfer_id"], manifest_id=row["manifest_id"],
            error=row["error"], options=options, operations=operations)

    def get_job(self, job_id: str) -> PublishJob | None:
        row = self._db.query_one("SELECT * FROM publish_jobs WHERE id = ?", (job_id,))
        return self._job_from_row(row) if row else None

    def list_jobs(self, limit: int = 100) -> list[PublishJob]:
        rows = self._db.query("SELECT * FROM publish_jobs ORDER BY created_at DESC, rowid DESC LIMIT ?",
                              (max(1, min(limit, 1000)),))
        return [self._job_from_row(r) for r in rows]

    def jobs_in_states(self, states: tuple[JobState, ...]) -> list[PublishJob]:
        marks = ",".join("?" for _ in states)
        rows = self._db.query(f"SELECT * FROM publish_jobs WHERE state IN ({marks})", [s.value for s in states])
        return [self._job_from_row(r) for r in rows]

    def delete_job(self, job_id: str) -> None:
        self._db.execute("DELETE FROM publish_jobs WHERE id = ?", (job_id,))

    def job_state_counts(self) -> dict[str, int]:
        return {r["state"]: r["n"] for r in
                self._db.query("SELECT state, COUNT(*) AS n FROM publish_jobs GROUP BY state")}

    # -- destinations -------------------------------------------------------
    def save_destination(self, dest: PublishDestination, now: int) -> None:
        self._db.execute(
            "INSERT INTO publish_destinations(id, kind, name, config, created_at) VALUES (?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET kind=excluded.kind, name=excluded.name, config=excluded.config",
            (dest.id, dest.kind, dest.name, json.dumps(dest.config, sort_keys=True), now),
        )

    def get_destination(self, dest_id: str) -> PublishDestination | None:
        row = self._db.query_one("SELECT * FROM publish_destinations WHERE id = ?", (dest_id,))
        return self._dest_from_row(row) if row else None

    def list_destinations(self) -> list[PublishDestination]:
        return [self._dest_from_row(r) for r in
                self._db.query("SELECT * FROM publish_destinations ORDER BY name COLLATE NOCASE, id")]

    def delete_destination(self, dest_id: str) -> None:
        self._db.execute("DELETE FROM publish_destinations WHERE id = ?", (dest_id,))

    @staticmethod
    def _dest_from_row(row) -> PublishDestination:
        try:
            config = json.loads(row["config"])
            if not isinstance(config, dict):
                config = {}
        except ValueError:
            config = {}
        return PublishDestination(id=row["id"], kind=row["kind"], name=row["name"], config=config)

    # -- manifests ----------------------------------------------------------
    def save_manifest(self, manifest: PublisherManifest, *, provenance: Provenance,
                      signature_status: SignatureStatus, now: int, transfer_id: str | None = None,
                      identity: TorrentIdentity | None = None, manifest_id: str | None = None) -> ManifestRecord:
        bound = identity or manifest.identity
        record = ManifestRecord(id=manifest_id or new_id(), manifest=manifest, provenance=provenance,
                                signature_status=signature_status, transfer_id=transfer_id,
                                v1=bound.v1 if bound else None, v2=bound.v2 if bound else None, created_at=now)
        self._db.execute(
            "INSERT INTO manifests(id, transfer_id, v1, v2, provenance, signature_status, json, created_at)"
            " VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET transfer_id=excluded.transfer_id,"
            " v1=excluded.v1, v2=excluded.v2, provenance=excluded.provenance,"
            " signature_status=excluded.signature_status, json=excluded.json",
            (record.id, transfer_id, record.v1, record.v2, provenance.value, signature_status.value,
             manifest.canonical_bytes().decode("utf-8"), now),
        )
        return record

    def _manifest_from_row(self, row) -> ManifestRecord | None:
        try:
            manifest = parse_manifest(row["json"])
            return ManifestRecord(id=row["id"], manifest=manifest, provenance=Provenance(row["provenance"]),
                                  signature_status=SignatureStatus(row["signature_status"]),
                                  transfer_id=row["transfer_id"], v1=row["v1"], v2=row["v2"],
                                  created_at=row["created_at"])
        except (ManifestError, ValueError) as exc:
            log.warning("stored manifest %s is unreadable and was ignored: %s", row["id"], type(exc).__name__)
            return None

    def get_manifest(self, manifest_id: str) -> ManifestRecord | None:
        row = self._db.query_one("SELECT * FROM manifests WHERE id = ?", (manifest_id,))
        return self._manifest_from_row(row) if row else None

    def manifests_for_identity(self, identity: TorrentIdentity) -> list[ManifestRecord]:
        """Records for the same torrent (matching either hash), embedded first, newest first."""
        rows = self._db.query(
            "SELECT * FROM manifests WHERE (v1 IS NOT NULL AND v1 = ?) OR (v2 IS NOT NULL AND v2 = ?)"
            " ORDER BY CASE provenance WHEN 'embedded' THEN 0 WHEN 'local' THEN 1 ELSE 2 END, created_at DESC",
            (identity.v1, identity.v2))
        return [r for r in (self._manifest_from_row(row) for row in rows) if r is not None]

    def manifests_for_transfer(self, transfer_id: str) -> list[ManifestRecord]:
        rows = self._db.query(
            "SELECT * FROM manifests WHERE transfer_id = ?"
            " ORDER BY CASE provenance WHEN 'embedded' THEN 0 WHEN 'local' THEN 1 ELSE 2 END, created_at DESC",
            (transfer_id,))
        return [r for r in (self._manifest_from_row(row) for row in rows) if r is not None]

    def list_manifests(self, limit: int = 100) -> list[ManifestRecord]:
        rows = self._db.query("SELECT * FROM manifests ORDER BY created_at DESC, rowid DESC LIMIT ?",
                              (max(1, min(limit, MAX_MANIFESTS_LISTED)),))
        return [r for r in (self._manifest_from_row(row) for row in rows) if r is not None]

    def set_manifest_transfer(self, manifest_id: str, transfer_id: str | None) -> None:
        self._db.execute("UPDATE manifests SET transfer_id = ? WHERE id = ?", (transfer_id, manifest_id))

    def delete_manifest(self, manifest_id: str) -> None:
        self._db.execute("DELETE FROM manifests WHERE id = ?", (manifest_id,))

    def manifest_counts(self) -> dict[str, int]:
        return {r["provenance"]: r["n"] for r in
                self._db.query("SELECT provenance, COUNT(*) AS n FROM manifests GROUP BY provenance")}

    # -- pinned publisher keys ----------------------------------------------
    def pin_key(self, public_key: str, label: str, now: int) -> None:
        self._db.execute(
            "INSERT INTO pinned_publisher_keys(public_key, label, added_at) VALUES (?,?,?) "
            "ON CONFLICT(public_key) DO UPDATE SET label = excluded.label",
            (public_key.lower(), label[:120], now))

    def unpin_key(self, public_key: str) -> None:
        self._db.execute("DELETE FROM pinned_publisher_keys WHERE public_key = ?", (public_key.lower(),))

    def pinned_keys(self) -> dict[str, str]:
        return {r["public_key"]: r["label"] for r in
                self._db.query("SELECT public_key, label FROM pinned_publisher_keys ORDER BY added_at")}
