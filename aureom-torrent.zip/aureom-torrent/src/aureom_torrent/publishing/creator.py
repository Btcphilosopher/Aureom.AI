"""Wizard-side torrent creation logic: option validation, request building, safe file output.

The engine-specific hashing lives behind ``engine.interface.TorrentCreator``;
this module turns a :class:`PublishDraft` into a ``CreateRequest`` and decides
whether the draft may be built at all.
"""

from __future__ import annotations

import glob
import os
import re
import tempfile
from pathlib import Path
from urllib.parse import urlsplit

from ..engine.commands import CreateRequest
from ..filesystem.paths import atomic_write, check_destination, is_fatal_problem, relative_path_problems
from .manifests import ManifestError, PublisherManifest, build_manifest
from .models import OptionsCheck, PublishDraft

FORMATS = ("v1", "v2", "hybrid")
MIN_PIECE_LENGTH = 16 * 1024
MAX_PIECE_LENGTH = 64 * 1024 * 1024
MAX_TRACKERS = 64
MAX_TIERS = 20
MAX_WEB_SEEDS = 16
MAX_URL_LENGTH = 2048
MAX_COMMENT = 1024
MANY_PIECES = 100_000

TRACKER_SCHEMES = ("http", "https", "udp")
WEB_SEED_SCHEMES = ("http", "https")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")

PRIVATE_NOTE = ("Private torrent: the engine disables DHT, peer exchange and local peer discovery for it, "
                "so peers can only be found through its trackers.")
PRIVATE_NO_TRACKER = "A private torrent without a tracker cannot find any peers."
PUBLIC_NO_TRACKER = ("No trackers: peers can only find this torrent through DHT, peer exchange or local "
                     "discovery, which can be slow for a new torrent.")


def valid_piece_length(value: int) -> bool:
    return value == 0 or (MIN_PIECE_LENGTH <= value <= MAX_PIECE_LENGTH and value & (value - 1) == 0)


def automatic_piece_length(total_size: int) -> int:
    """Mirror of the engine helper: about 1 000–2 000 pieces, 16 KiB … 16 MiB."""
    length = MIN_PIECE_LENGTH
    while length < 16 * 1024 * 1024 and total_size / length > 2000:
        length *= 2
    return length


def piece_length_choices() -> list[tuple[str, int]]:
    """Labels and values for the wizard's piece-size selector."""
    out = [("Automatic", 0)]
    value = MIN_PIECE_LENGTH
    while value <= MAX_PIECE_LENGTH:
        label = f"{value // 1024} KiB" if value < 1024 * 1024 else f"{value // (1024 * 1024)} MiB"
        out.append((label, value))
        value *= 2
    return out


def url_problem(url: str, schemes: tuple[str, ...]) -> str | None:
    if not url or len(url) > MAX_URL_LENGTH:
        return "is empty or too long"
    if _CONTROL.search(url) or any(c.isspace() for c in url):
        return "contains spaces or control characters"
    try:
        parts = urlsplit(url)
        _ = parts.port
    except ValueError:
        return "is not a valid URL"
    if parts.scheme.lower() not in schemes:
        return "must start with " + ", ".join(s + "://" for s in schemes)
    if not parts.hostname:
        return "has no host name"
    return None


def _shown(url: str) -> str:
    """Tracker URLs can carry passkeys: show only scheme and host in messages."""
    try:
        parts = urlsplit(url)
        return f"{parts.scheme}://{parts.hostname or '?'}/…" if parts.scheme else url[:40]
    except ValueError:
        return url[:40]


def parse_tracker_text(text: str) -> tuple[list[list[str]], list[str]]:
    """Parse the wizard's tracker box: one URL per line, a blank line starts the next tier."""
    tiers: list[list[str]] = []
    current: list[str] = []
    for raw in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw.strip()
        if not line:
            if current:
                tiers.append(current)
                current = []
            continue
        current.append(line)
    if current:
        tiers.append(current)
    return normalise_tiers(tiers)


def normalise_tiers(tiers: list[list[str]]) -> tuple[list[list[str]], list[str]]:
    """Validate tracker tiers; duplicates are dropped, problems are returned."""
    problems: list[str] = []
    seen: set[str] = set()
    out: list[list[str]] = []
    count = 0
    for tier in tiers:
        clean: list[str] = []
        for url in tier:
            url = (url or "").strip()
            if not url or url in seen:
                continue
            problem = url_problem(url, TRACKER_SCHEMES)
            if problem:
                problems.append(f"Tracker “{_shown(url)}” {problem}.")
                continue
            seen.add(url)
            clean.append(url)
            count += 1
        if clean:
            out.append(clean)
    if count > MAX_TRACKERS:
        problems.append(f"Too many trackers ({count}; the limit is {MAX_TRACKERS}).")
    if len(out) > MAX_TIERS:
        problems.append(f"Too many tracker tiers ({len(out)}; the limit is {MAX_TIERS}).")
    return out, problems


def draft_tiers(draft: PublishDraft) -> tuple[list[list[str]], list[str]]:
    if draft.tracker_tiers:
        return normalise_tiers([list(t) for t in draft.tracker_tiers])
    return parse_tracker_text(draft.trackers_text)


def web_seed_problems(web_seeds: list[str]) -> tuple[list[str], list[str]]:
    problems: list[str] = []
    clean: list[str] = []
    for url in web_seeds:
        url = (url or "").strip()
        if not url or url in clean:
            continue
        problem = url_problem(url, WEB_SEED_SCHEMES)
        if problem:
            problems.append(f"Web seed “{_shown(url)}” {problem} (BEP 19 web seeds are http/https URLs).")
        else:
            clean.append(url)
    if len(clean) > MAX_WEB_SEEDS:
        problems.append(f"Too many web seeds ({len(clean)}; the limit is {MAX_WEB_SEEDS}).")
    return clean, problems


def effective_name(draft: PublishDraft) -> str:
    if draft.name.strip():
        return draft.name.strip()
    return os.path.basename(os.path.abspath(draft.source_path)) if draft.source_path else ""


def suggest_torrent_path(source_path: str, name: str = "") -> str:
    """Default output path: next to the selected item, never inside it."""
    root = os.path.abspath(source_path)
    stem = name.strip() or os.path.basename(root)
    return os.path.join(os.path.dirname(root), stem + ".torrent")


def build_publisher_manifest(draft: PublishDraft, created: int) -> PublisherManifest | None:
    """The (identity-less) manifest described by the draft, or None. Raises ManifestError."""
    info = draft.publisher
    if info is None or info.is_empty():
        return None
    return build_manifest(publisher=info.name, description=info.description, website=info.website,
                          feed_url=info.feed_url, bitcoin_address=info.bitcoin_address,
                          bitcoin_network=info.bitcoin_network, lightning_address=info.lightning_address,
                          licence=info.licence, created=created)


def check_options(draft: PublishDraft, *, total_size: int | None = None, can_seed: bool = True,
                  now: int = 0) -> OptionsCheck:
    """Validate a draft without touching the engine.

    ``total_size`` is the size of the included files when the caller already
    knows it (from the scan); otherwise piece-count warnings are skipped.
    The file list itself is re-verified against a fresh scan when the job
    starts, so nothing outside the selected root can be included.
    """
    errors: list[str] = []
    warnings: list[str] = []

    source = draft.source_path
    single = False
    base = ""
    if not source or not os.path.isabs(source):
        errors.append("Select a file or folder to publish.")
    elif os.path.islink(source):
        errors.append("The selected item is a symbolic link; choose the real file or folder.")
    elif not os.path.exists(source):
        errors.append("The selected file or folder no longer exists.")
    else:
        single = os.path.isfile(source)
        base = os.path.basename(os.path.abspath(source))

    if not draft.included_files:
        errors.append("No files are selected for the torrent.")
    else:
        if len(set(draft.included_files)) != len(draft.included_files):
            errors.append("The file list contains duplicates.")
        bad = 0
        for rel in draft.included_files:
            if [p for p in relative_path_problems(rel) if is_fatal_problem(p)]:
                bad += 1
        if bad:
            errors.append(f"{bad} selected file path(s) are unsafe (absolute, traversal or control characters).")
        if single and base and list(draft.included_files) != [base]:
            errors.append("A single-file torrent must contain exactly the selected file.")

    name = draft.name.strip()
    if name:
        if "/" in name or "\\" in name or [p for p in relative_path_problems(name) if is_fatal_problem(p)]:
            errors.append("The torrent name must be a plain name without path separators.")
        elif base and name != base:
            if single:
                errors.append("A single-file torrent takes its name from the file; rename the file instead.")
            elif draft.start_seeding:
                errors.append("To seed in place the torrent must keep the folder's name. Rename the folder, "
                              "or turn off “start seeding”.")

    if draft.format not in FORMATS:
        errors.append("Choose a torrent format: v1, v2 or hybrid.")
    elif draft.format == "v1":
        warnings.append("v1-only torrents use SHA-1 piece hashes. Hybrid torrents work with the same "
                        "clients and add SHA-256 (v2) verification.")
    elif draft.format == "v2":
        warnings.append("v2-only torrents cannot be opened by clients that only support BitTorrent v1.")

    piece_length = draft.piece_length
    pieces = 0
    if isinstance(piece_length, bool) or not isinstance(piece_length, int) or not valid_piece_length(piece_length):
        errors.append("The piece size must be automatic or a power of two between 16 KiB and 64 MiB.")
        piece_length = 0
    elif total_size is not None and total_size > 0:
        effective = piece_length or automatic_piece_length(total_size)
        pieces = -(-total_size // effective)
        if pieces > MANY_PIECES:
            warnings.append(f"This piece size gives {pieces:,} pieces, which makes a large .torrent file and "
                            "uses more memory in clients. Consider a larger piece size.")
        if piece_length and total_size < piece_length:
            warnings.append("The piece size is larger than the content, so the torrent has a single piece; "
                            "any corruption means re-downloading everything.")
        piece_length = effective
    if total_size is not None and total_size <= 0 and draft.included_files:
        errors.append("The selected files are empty.")

    tiers, tracker_problems = draft_tiers(draft)
    errors.extend(tracker_problems)
    _seeds, seed_problems = web_seed_problems(list(draft.web_seeds))
    errors.extend(seed_problems)

    if draft.private:
        warnings.append(PRIVATE_NOTE)
        if not tiers:
            warnings.append(PRIVATE_NO_TRACKER)
    elif not tiers:
        warnings.append(PUBLIC_NO_TRACKER)

    if len(draft.comment) > MAX_COMMENT or _CONTROL.search(draft.comment.replace("\n", " ")):
        errors.append(f"The comment must be plain text of at most {MAX_COMMENT} characters.")

    manifest = None
    try:
        manifest = build_publisher_manifest(draft, created=now or 1)
    except ManifestError as exc:
        errors.extend(f"Publisher details: {p}" for p in exc.problems)
    if manifest is None and draft.sign_manifest and not errors:
        if draft.publisher is None or draft.publisher.is_empty():
            errors.append("There are no publisher details to sign.")
    if manifest is not None:
        warnings.append("Publisher details are self-asserted: anyone can type any name."
                        + (" A signature shows they were not altered, not who you are."
                           if draft.sign_manifest else ""))
        if not draft.embed_manifest:
            warnings.append("The publisher details will not be stored in the torrent, so downloaders only "
                            "see them if you share the manifest file separately.")

    out = draft.output_torrent_path
    if not out or not os.path.isabs(out):
        errors.append("Choose where to save the .torrent file.")
    else:
        if not out.lower().endswith(".torrent"):
            errors.append("The output file name must end with .torrent.")
        if os.path.isdir(out):
            errors.append("The output path is a folder.")
        elif os.path.lexists(out) and not draft.overwrite:
            errors.append("A file already exists at the output path. Choose another name or confirm overwriting.")
        report = check_destination(os.path.dirname(out) or out)
        errors.extend(report.problems)
        if source and os.path.isabs(source):
            src = os.path.abspath(source)
            if os.path.abspath(out) == src:
                errors.append("The .torrent file cannot replace the file being published.")
            elif not single and draft.included_files:
                try:
                    rel = Path(os.path.abspath(out)).relative_to(src).as_posix()
                except ValueError:
                    rel = None
                if rel is not None and rel in set(draft.included_files):
                    errors.append("The .torrent file would overwrite one of the files being published.")

    if draft.start_seeding and not can_seed:
        errors.append("Seeding cannot be started because the transfer engine is not available.")

    return OptionsCheck(errors=tuple(dict.fromkeys(errors)), warnings=tuple(dict.fromkeys(warnings)),
                        tiers=tuple(tuple(t) for t in tiers), piece_length=piece_length, estimated_pieces=pieces)


def build_create_request(draft: PublishDraft, tiers: tuple[tuple[str, ...], ...],
                         embedded_manifest: bytes = b"") -> CreateRequest:
    seeds, _ = web_seed_problems(list(draft.web_seeds))
    return CreateRequest(
        root_path=os.path.abspath(draft.source_path),
        files=tuple(draft.included_files),
        name=draft.name.strip(),
        format=draft.format,
        piece_length=draft.piece_length,
        trackers=tiers,
        web_seeds=tuple(seeds),
        private=bool(draft.private),
        comment=draft.comment.strip(),
        creator="AUREOM TORRENT",
        embedded_manifest=embedded_manifest,
    )


def write_torrent_file(path: str, data: bytes, *, overwrite: bool) -> None:
    """Write the .torrent so that a reader never sees a partial file.

    Without ``overwrite`` the write is *exclusive*: the data is written to a
    temporary file in the same folder and hard-linked into place, which fails
    if anything already exists at ``path`` (no check-then-write race).  On
    filesystems without hard links an exclusive create is used instead.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if overwrite:
        atomic_write(target, data)
        return
    fd, tmp = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        try:
            os.link(tmp, target)
        except FileExistsError:
            raise
        except OSError:
            with open(target, "xb") as fh:  # raises FileExistsError when something is there
                fh.write(data)
                fh.flush()
                os.fsync(fh.fileno())
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def leftover_temp_files(torrent_path: str) -> list[str]:
    """Temporary files an interrupted :func:`write_torrent_file` may have left behind."""
    if not torrent_path:
        return []
    target = Path(torrent_path)
    pattern = os.path.join(glob.escape(str(target.parent)), glob.escape(target.name) + ".*.tmp")
    return sorted(p for p in glob.glob(pattern) if os.path.isfile(p) and not os.path.islink(p))
