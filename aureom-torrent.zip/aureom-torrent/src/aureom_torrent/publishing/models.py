"""Plain data shapes for the Publish & Share workflow (no Qt, no engine types)."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any

from ..domain.identity import TorrentIdentity


class PublishError(Exception):
    """A publishing request that cannot be carried out. ``str(exc)`` is safe to show."""

    def __init__(self, message: str, problems: list[str] | None = None):
        super().__init__(message)
        self.problems = list(problems or [message])


class JobState(str, enum.Enum):
    DRAFT = "draft"
    HASHING = "hashing"
    SAVING = "saving"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    INTERRUPTED = "interrupted"

    @property
    def label(self) -> str:
        return {
            "draft": "Draft",
            "hashing": "Generating hashes",
            "saving": "Saving the torrent file",
            "completed": "Completed",
            "failed": "Failed",
            "cancelled": "Cancelled",
            "interrupted": "Interrupted (the application closed before it finished)",
        }[self.value]

    @property
    def finished(self) -> bool:
        return self in (JobState.COMPLETED, JobState.FAILED, JobState.CANCELLED, JobState.INTERRUPTED)


@dataclass(slots=True)
class PublisherInfo:
    """Optional, self-asserted publisher metadata entered in the wizard."""

    name: str = ""
    description: str = ""
    website: str = ""
    feed_url: str = ""
    bitcoin_address: str = ""
    bitcoin_network: str = "mainnet"
    lightning_address: str = ""
    licence: str = ""

    def is_empty(self) -> bool:
        return not any((self.name, self.description, self.website, self.feed_url,
                        self.bitcoin_address, self.lightning_address, self.licence))


@dataclass(slots=True)
class PublishDraft:
    """Everything the wizard collects before hashing starts."""

    source_path: str = ""  # the selected file or folder
    included_files: list[str] = field(default_factory=list)  # relative paths from the scan
    name: str = ""  # "" = the base name of ``source_path``
    format: str = "hybrid"  # v1 | v2 | hybrid
    piece_length: int = 0  # 0 = automatic
    trackers_text: str = ""  # one URL per line; a blank line starts the next tier
    tracker_tiers: list[list[str]] = field(default_factory=list)  # takes precedence over trackers_text
    web_seeds: list[str] = field(default_factory=list)
    private: bool = False
    comment: str = ""
    publisher: PublisherInfo | None = None
    embed_manifest: bool = True  # store the publisher manifest inside the info dictionary
    sign_manifest: bool = False  # sign with the local Ed25519 key (created on first use)
    output_torrent_path: str = ""
    overwrite: bool = False
    start_seeding: bool = True
    category: str = ""


@dataclass(frozen=True, slots=True)
class OptionsCheck:
    errors: tuple[str, ...] = ()  # block creation
    warnings: tuple[str, ...] = ()  # shown, do not block
    tiers: tuple[tuple[str, ...], ...] = ()  # the normalised tracker tiers
    piece_length: int = 0  # the effective piece length (automatic resolved when the size is known)
    estimated_pieces: int = 0

    @property
    def ok(self) -> bool:
        return not self.errors


@dataclass(frozen=True, slots=True)
class PublishOperationResult:
    operation: str  # save_torrent | start_seeding | publish:<artifact kind>
    destination: str  # display-safe description (never a signed URL or token)
    ok: bool
    message: str
    ts: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {"operation": self.operation, "destination": self.destination, "ok": self.ok,
                "message": self.message, "ts": self.ts}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PublishOperationResult":
        return cls(str(d.get("operation", "")), str(d.get("destination", "")), bool(d.get("ok")),
                   str(d.get("message", "")), int(d.get("ts") or 0))


@dataclass(slots=True)
class PublishJob:
    id: str
    state: JobState
    created_at: int
    updated_at: int
    source_path: str
    torrent_path: str = ""
    name: str = ""
    format: str = "hybrid"
    total_size: int = 0
    file_count: int = 0
    piece_length: int = 0
    private: bool = False
    v1: str | None = None
    v2: str | None = None
    magnet: str = ""
    transfer_id: str | None = None
    manifest_id: str | None = None
    error: str = ""
    options: dict[str, Any] = field(default_factory=dict)
    operations: list[PublishOperationResult] = field(default_factory=list)

    @property
    def identity(self) -> TorrentIdentity | None:
        if self.v1 or self.v2:
            return TorrentIdentity(self.v1, self.v2)
        return None

    def operation(self, name: str) -> PublishOperationResult | None:
        """The most recent result of the named operation."""
        for op in reversed(self.operations):
            if op.operation == name:
                return op
        return None


@dataclass(frozen=True, slots=True)
class PublishDestination:
    id: str
    kind: str  # local_dir | https_upload
    name: str
    config: dict[str, Any] = field(default_factory=dict)  # never contains credentials


@dataclass(frozen=True, slots=True)
class QrResult:
    ok: bool
    payload: str = ""  # the text actually encoded
    trimmed: bool = False  # True when ``payload`` is a shortened magnet
    reason: str = ""  # why the code is trimmed or unavailable
    alternative: str = ""  # what to do instead when ok is False
    svg: str = ""  # stand-alone SVG document
    svg_inline: str = ""  # <svg> element for embedding in HTML
    png: bytes = b""
    version: int = 0  # QR symbol version (1..40)
    modules: int = 0  # modules per side, without the quiet zone


@dataclass(frozen=True, slots=True)
class Artifact:
    kind: str  # torrent | page | atom | qr_svg | qr_png | manifest | share_text
    name: str  # a safe single-component file name
    content: bytes
    content_type: str


ARTIFACT_KINDS = ("torrent", "page", "atom", "qr_svg", "qr_png", "manifest", "share_text")


@dataclass(frozen=True, slots=True)
class ShareInfo:
    job_id: str
    name: str
    magnet: str
    torrent_path: str
    torrent_file_exists: bool
    identity: TorrentIdentity | None
    format: str
    total_size: int
    file_count: int
    private: bool
    qr: QrResult
    share_text: str
    transfer_id: str | None  # join with the transfer service for live seeding state / last announce
    seeding_requested: bool
    seeding_started: bool | None  # None = not requested; False = requested but the add failed
    publisher_label: str  # e.g. "Example Press — self-asserted (unsigned)"
    operations: tuple[PublishOperationResult, ...] = ()
    notes: tuple[str, ...] = ()
