"""Upload artifacts with HTTP PUT to an explicitly configured HTTPS endpoint.

* The destination is ``<base_url>/<artifact name>``.  ``base_url`` is stored
  in SQLite and therefore must not carry credentials or a query string; the
  bearer token lives in the OS credential store.
* Requests go through the shared policy-checked fetcher using the
  *publishing* network settings: https only, no loopback/private addresses
  unless the user enabled them, the configured proxy or none, and redirects
  are never followed for uploads.
* A 2xx response is reported as "uploaded".  That means the endpoint accepted
  the bytes; it does **not** prove the file is publicly reachable.
"""

from __future__ import annotations

import logging
from urllib.parse import quote, urlsplit

from ...net.http import Fetcher, HttpFetchError, HttpPolicy, safe_url_for_display
from ..models import PublishOperationResult
from .base import MAX_ARTIFACT_BYTES, UnsafeArtifactName, check_artifact_name, result

log = logging.getLogger(__name__)

MAX_RESPONSE_BYTES = 64 * 1024


def base_url_problems(base_url: object, *, allow_http: bool = False) -> list[str]:
    if not isinstance(base_url, str) or not base_url.strip():
        return ["Enter the upload address (for example https://example.org/files)."]
    if len(base_url) > 2048:
        return ["The upload address is too long."]
    try:
        parts = urlsplit(base_url)
        _ = parts.port
    except ValueError:
        return ["The upload address is not a valid URL."]
    problems = []
    if parts.scheme.lower() not in (("http", "https") if allow_http else ("https",)):
        problems.append("The upload address must start with https://.")
    if not parts.hostname:
        problems.append("The upload address has no host name.")
    if parts.username or parts.password:
        problems.append("Do not put a user name or password in the upload address; use the token field.")
    if parts.query or parts.fragment:
        problems.append("The upload address must not contain a query string or fragment. Signed URLs "
                        "are secrets and are not stored; use a bearer token instead.")
    return problems


class HttpsUploadAdapter:
    kind = "https_upload"

    def __init__(self, base_url: str, *, fetcher: Fetcher, policy: HttpPolicy, token: str | None = None):
        self.base_url = base_url.rstrip("/")
        self._fetcher = fetcher
        self._policy = policy
        self._token = token or ""

    def describe(self) -> str:
        return "upload to " + safe_url_for_display(self.base_url)

    def publish(self, artifact_name: str, content: bytes, content_type: str) -> PublishOperationResult:
        op = f"publish:{artifact_name}"
        try:
            name = check_artifact_name(artifact_name)
        except UnsafeArtifactName as exc:
            return result(op, self.describe(), False, str(exc))
        if len(content) > MAX_ARTIFACT_BYTES:
            return result(op, self.describe(), False, "The artifact is larger than the 32 MiB upload limit.")
        problems = base_url_problems(self.base_url, allow_http=self._policy.allow_http)
        if problems:
            return result(op, self.describe(), False, problems[0])
        url = f"{self.base_url}/{quote(name)}"
        shown = safe_url_for_display(url)
        headers = {"Content-Type": content_type or "application/octet-stream"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        policy = HttpPolicy(timeout_s=self._policy.timeout_s,
                            max_bytes=min(self._policy.max_bytes, MAX_RESPONSE_BYTES), max_redirects=0,
                            allow_http=self._policy.allow_http, allow_loopback=self._policy.allow_loopback,
                            allow_private=self._policy.allow_private, proxy_url=self._policy.proxy_url)
        try:
            response = self._fetcher.fetch(url, method="PUT", headers=headers, body=content, policy=policy)
        except HttpFetchError as exc:
            log.warning("upload to %s failed: %s", shown, type(exc).__name__)
            return result(op, self.describe(), False, f"Upload of “{name}” failed: {exc}")
        except Exception as exc:  # an adapter must never take the application down
            log.warning("upload to %s failed unexpectedly: %s", shown, type(exc).__name__)
            return result(op, self.describe(), False, f"Upload of “{name}” failed ({type(exc).__name__}).")
        status = response.status
        if 200 <= status < 300:
            return result(op, self.describe(), True,
                          f"Uploaded “{name}” to {shown} (HTTP {status}). The endpoint accepted the file; "
                          "this does not prove it is publicly reachable.")
        if status in (401, 403):
            hint = "the endpoint rejected the credentials"
        elif status == 404:
            hint = "the upload address was not found"
        elif status == 413:
            hint = "the endpoint says the file is too large"
        elif 300 <= status < 400:
            hint = "the endpoint answered with a redirect, which is not followed for uploads"
        else:
            hint = "the endpoint refused the upload"
        log.warning("upload to %s refused with HTTP %s", shown, status)
        return result(op, self.describe(), False, f"Upload of “{name}” to {shown} failed: {hint} (HTTP {status}).")
