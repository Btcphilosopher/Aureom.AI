"""Publishing adapters: where exported artifacts can be sent.

An adapter moves bytes to one explicitly configured destination and reports
what happened.  It never invents hosting: a result of ``ok=True`` means the
destination accepted the bytes, nothing more.
"""

from __future__ import annotations

import re
import time
from typing import Protocol

from ..models import PublishOperationResult

MAX_ARTIFACT_BYTES = 32 * 1024 * 1024
_ARTIFACT_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$")


class UnsafeArtifactName(ValueError):
    pass


def check_artifact_name(name: str) -> str:
    """Artifact names are single path components made of conservative characters."""
    if not isinstance(name, str) or not _ARTIFACT_NAME.match(name) or name.endswith(".") or ".." in name:
        raise UnsafeArtifactName(f"“{str(name)[:60]}” is not a safe file name for publishing.")
    return name


def result(operation: str, destination: str, ok: bool, message: str) -> PublishOperationResult:
    return PublishOperationResult(operation=operation, destination=destination, ok=ok, message=message,
                                  ts=int(time.time()))


class PublishAdapter(Protocol):
    def describe(self) -> str:
        """A display-safe description of the destination (no credentials, no query strings)."""

    def publish(self, artifact_name: str, content: bytes, content_type: str) -> PublishOperationResult:
        """Send one artifact. Must not raise for expected failures; report them in the result."""
