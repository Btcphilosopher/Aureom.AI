"""Write artifacts into an explicitly chosen local folder.

A local folder is not public hosting; the result message says so.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from ...filesystem.paths import atomic_write
from ..models import PublishOperationResult
from .base import MAX_ARTIFACT_BYTES, UnsafeArtifactName, check_artifact_name, result

log = logging.getLogger(__name__)


class LocalDirAdapter:
    kind = "local_dir"

    def __init__(self, directory: str, *, overwrite: bool = True):
        self.directory = directory
        self.overwrite = overwrite

    @staticmethod
    def config_problems(config: dict) -> list[str]:
        directory = config.get("directory")
        if not isinstance(directory, str) or not directory or not os.path.isabs(directory):
            return ["Choose an absolute folder for the local export destination."]
        if os.path.exists(directory) and not os.path.isdir(directory):
            return ["The local export destination is a file, not a folder."]
        return []

    def describe(self) -> str:
        return f"local folder {self.directory}"

    def publish(self, artifact_name: str, content: bytes, content_type: str) -> PublishOperationResult:
        op = f"publish:{artifact_name}"
        try:
            name = check_artifact_name(artifact_name)
        except UnsafeArtifactName as exc:
            return result(op, self.describe(), False, str(exc))
        if len(content) > MAX_ARTIFACT_BYTES:
            return result(op, self.describe(), False, "The artifact is larger than the 32 MiB limit.")
        root = Path(self.directory)
        target = root / name
        try:
            root.mkdir(parents=True, exist_ok=True)
            # The name is a single safe component, so the target cannot leave the folder; a symlink
            # planted at the target is replaced by os.replace rather than followed.
            if target.exists() and not self.overwrite:
                return result(op, self.describe(), False, f"“{name}” already exists and was not overwritten.")
            if target.is_dir():
                return result(op, self.describe(), False, f"“{name}” is a folder in the destination.")
            atomic_write(target, content)
        except OSError as exc:
            log.warning("local export of %s failed: %s", name, exc.strerror or type(exc).__name__)
            return result(op, self.describe(), False, f"Could not write “{name}”: {exc.strerror or exc}.")
        return result(op, self.describe(), True,
                      f"Saved “{name}” ({len(content):,} bytes). A local folder is not public hosting.")
