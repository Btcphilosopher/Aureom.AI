"""Sharing helpers: magnet QR codes, share text, a static publisher page and an Atom catalogue entry.

Nothing in this module contacts the network or makes anything public.  The
static page is a local file; the Atom entry is text to add to a feed the
publisher hosts themselves.

QR capacity
-----------
A QR code can hold up to 2 331 bytes at error-correction level M (version 40),
but dense symbols are hard to scan from a screen with a phone camera.  We cap
the symbol at **version 25 (117×117 modules), level M, byte mode: 997 bytes**.
A magnet that does not fit is *not* encoded as an unreadable code.  Instead,
in order:

1. a trimmed magnet is tried – info-hash(es) and name with as many of the
   first trackers as fit (web seeds, peer hints and remaining trackers are
   dropped) – and the result is flagged ``trimmed`` with an explanation;
2. if trimming is not acceptable (a private torrent whose trackers cannot be
   kept, or ``allow_trim=False``) no code is produced and the caller is told to
   copy the magnet text or share the .torrent file.
"""

from __future__ import annotations

import html
import io
import re
import time
import xml.etree.ElementTree as ET
from urllib.parse import quote

import segno
from segno import DataOverflowError

from ..domain.identity import TorrentIdentity
from ..domain.magnet import MagnetError, parse_magnet
from ..domain.transfers import TorrentMetadata
from .manifests import PublisherManifest, TrustAssessment, url_problem
from .models import QrResult

QR_MAX_VERSION = 25
QR_ERROR_LEVEL = "m"
QR_MAX_BYTES = 997  # byte-mode capacity of a version-25 symbol at level M
QR_ALTERNATIVE = "Copy the magnet text or share the .torrent file instead."

MAX_PAGE_FILES = 200
TORRENT_NS = "http://xmlns.ezrss.it/0.1/"
ATOM_NS = "http://www.w3.org/2005/Atom"

NOTE_MAGNET_IS_NOT_HOSTING = (
    "A magnet link only identifies the content. Sharing it does not host the files or guarantee that "
    "anyone can download them."
)
NOTE_STAY_ONLINE = (
    "Until other people hold complete copies, this device must stay online with the transfer seeding. "
    "If it goes offline before then, downloads will stall."
)
NOTE_EXPORT_IS_NOT_PUBLISHING = (
    "This page is a local file. Exporting it does not publish it or host the files."
)
NOTE_UPLOAD_IS_NOT_PROOF = (
    "A successful upload means the destination accepted the file. It does not prove the file is "
    "publicly reachable; check the public address yourself."
)
NOTE_VERIFICATION_IS_NOT_SAFETY = (
    "Piece verification shows the data matches the torrent metadata. It does not show the files are "
    "safe or that the publisher is who they claim to be."
)


class SeedingStatusNote:
    """User-facing wording for the sharing screen's seeding line."""

    NOT_REQUESTED = "This client is not seeding this torrent. Nobody can download it from this device."
    ADD_FAILED = "Seeding could not be started: {message}"
    CHECKING = "Verifying the files before seeding starts."
    SEEDING = "This client is seeding. " + NOTE_STAY_ONLINE
    STOPPED = "The transfer exists but is stopped, so this client is not seeding."
    UNKNOWN = "The transfer's state is not known yet."


# ---------------------------------------------------------------------------
# QR codes
# ---------------------------------------------------------------------------

def _fits(payload: str) -> segno.QRCode | None:
    if len(payload.encode("utf-8")) > QR_MAX_BYTES:
        return None
    try:
        qr = segno.make(payload, error=QR_ERROR_LEVEL, boost_error=False, micro=False)
    except DataOverflowError:
        return None
    return qr if int(qr.version) <= QR_MAX_VERSION else None


def _magnet_from_parts(identity: TorrentIdentity, name: str | None, trackers: tuple[str, ...]) -> str:
    parts = []
    if identity.v1:
        parts.append(f"xt=urn:btih:{identity.v1}")
    if identity.v2:
        parts.append(f"xt=urn:btmh:1220{identity.v2}")
    if name:
        parts.append("dn=" + quote(name, safe=""))
    parts += ["tr=" + quote(t, safe="") for t in trackers]
    return "magnet:?" + "&".join(parts)


def trimmed_magnet_candidates(magnet: str, *, require_tracker: bool = False) -> list[str]:
    """Shorter equivalents of ``magnet``, longest first. Raises MagnetError for an unusable link."""
    link = parse_magnet(magnet)
    out: list[str] = []
    for count in range(min(len(link.trackers), 3), 0, -1):
        out.append(_magnet_from_parts(link.identity, link.display_name, link.trackers[:count]))
    if link.trackers:
        out.append(_magnet_from_parts(link.identity, None, link.trackers[:1]))
    if not require_tracker:
        out.append(_magnet_from_parts(link.identity, link.display_name, ()))
        out.append(_magnet_from_parts(link.identity, None, ()))
    seen: list[str] = []
    for candidate in out:
        if candidate not in seen and len(candidate) < len(magnet):
            seen.append(candidate)
    return seen


def make_magnet_qr(magnet: str, *, allow_trim: bool = True, require_tracker: bool = False,
                   scale: int = 6, border: int = 4) -> QrResult:
    """Build a scannable QR code for ``magnet`` or explain why there is none.

    ``require_tracker`` should be true for private torrents: a magnet without
    its tracker would be useless there, so trackers are never trimmed away.
    """
    magnet = (magnet or "").strip()
    if not magnet:
        return QrResult(ok=False, reason="There is no magnet link to encode.", alternative=QR_ALTERNATIVE)
    qr = _fits(magnet)
    payload, trimmed, reason = magnet, False, ""
    if qr is None:
        size = len(magnet.encode("utf-8"))
        too_long = (f"The magnet link is {size:,} bytes; a reliably scannable QR code holds at most "
                    f"{QR_MAX_BYTES} bytes.")
        if not allow_trim:
            return QrResult(ok=False, reason=too_long, alternative=QR_ALTERNATIVE)
        try:
            candidates = trimmed_magnet_candidates(magnet, require_tracker=require_tracker)
        except MagnetError as exc:
            return QrResult(ok=False, reason=f"{too_long} It also could not be shortened: {exc}",
                            alternative=QR_ALTERNATIVE)
        for candidate in candidates:
            qr = _fits(candidate)
            if qr is not None:
                payload, trimmed = candidate, True
                reason = (f"{too_long} This code carries a shortened link: the info-hash"
                          f"{', the name' if '&dn=' in candidate else ''}"
                          f"{' and the first tracker(s)' if '&tr=' in candidate else ''}. "
                          "Web seeds and the remaining trackers are only in the full magnet text and the "
                          ".torrent file.")
                break
        if qr is None:
            extra = " Its trackers cannot be left out because the torrent is private." if require_tracker else ""
            return QrResult(ok=False, reason=too_long + extra, alternative=QR_ALTERNATIVE)

    svg_buf = io.BytesIO()
    qr.save(svg_buf, kind="svg", scale=scale, border=border, dark="#000", light="#fff")
    png_buf = io.BytesIO()
    qr.save(png_buf, kind="png", scale=scale, border=border, dark="#000", light="#fff")
    inline = qr.svg_inline(scale=4, border=border, dark="#000", light="#fff")
    modules = qr.symbol_size(scale=1, border=0)[0]
    return QrResult(ok=True, payload=payload, trimmed=trimmed, reason=reason, svg=svg_buf.getvalue().decode("utf-8"),
                    svg_inline=inline, png=png_buf.getvalue(), version=int(qr.version), modules=modules)


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

def format_size(size: int) -> str:
    units = ("bytes", "KiB", "MiB", "GiB", "TiB", "PiB")
    value = float(max(0, size))
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{int(value)} {unit}" if unit == "bytes" else f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} bytes"  # pragma: no cover


def format_label(fmt: str) -> str:
    return {"v1": "BitTorrent v1", "v2": "BitTorrent v2", "hybrid": "BitTorrent v1 + v2 (hybrid)"}.get(fmt, fmt)


_SAFE_NAME = re.compile(r"[^A-Za-z0-9._-]+")


def safe_file_stem(name: str, fallback: str = "torrent") -> str:
    """A conservative single-component file-name stem derived from a torrent name."""
    stem = _SAFE_NAME.sub("-", name).strip("-.")[:80].strip("-.")
    return stem or fallback


def publisher_label(manifest: PublisherManifest | None, trust: TrustAssessment | None) -> str:
    if manifest is None:
        return "No publisher details"
    label = trust.label if trust is not None else "self-asserted"
    return f"{manifest.publisher} — {label}"


def build_share_text(*, name: str, total_size: int, file_count: int, fmt: str,
                     identity: TorrentIdentity | None, magnet: str, private: bool = False,
                     manifest: PublisherManifest | None = None, trust: TrustAssessment | None = None) -> str:
    """A short plain-text description suitable for a message or forum post."""
    files = "1 file" if file_count == 1 else f"{file_count:,} files"
    lines = [name, f"Size: {format_size(total_size)} in {files} · {format_label(fmt)}"
             + (" · private" if private else "")]
    if identity is not None:
        if identity.v1:
            lines.append(f"Info-hash (v1): {identity.v1}")
        if identity.v2:
            lines.append(f"Info-hash (v2): {identity.v2}")
    if manifest is not None:
        lines.append(f"Publisher: {publisher_label(manifest, trust)}")
        if manifest.licence:
            lines.append(f"Licence: {manifest.licence}")
    lines.append(f"Magnet: {magnet}")
    lines.append("")
    lines.append("Note: a magnet link only identifies the files. They can be downloaded only while at "
                 "least one seeder is online.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Static publisher page
# ---------------------------------------------------------------------------

_PAGE_CSS = """
:root{color-scheme:light dark;--bg:#f8f4ea;--ink:#16213a;--muted:#5b6478;--line:#d9d2c2;--accent:#a65f2b;--panel:#fffdf7}
@media (prefers-color-scheme:dark){:root{--bg:#0f1729;--ink:#ece6d8;--muted:#a3aabb;--line:#2b3654;--accent:#d08a52;--panel:#162038}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:46rem;margin:0 auto;padding:2rem 1rem 3rem}
h1{font-size:1.6rem;line-height:1.25;margin:0 0 .25rem;overflow-wrap:anywhere}
h2{font-size:1rem;margin:2rem 0 .5rem;color:var(--accent);letter-spacing:.04em;text-transform:uppercase}
p{margin:.5rem 0}
.muted{color:var(--muted)}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:1rem}
.notice{border-left:4px solid var(--accent)}
code,.mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.85rem;overflow-wrap:anywhere}
table{border-collapse:collapse;width:100%}
td,th{text-align:left;padding:.3rem .5rem;border-bottom:1px solid var(--line);vertical-align:top;overflow-wrap:anywhere}
td.num{text-align:right;white-space:nowrap}
a{color:var(--accent)}
.qr{background:#fff;display:inline-block;padding:.5rem;border-radius:6px;line-height:0}
.qr svg{max-width:100%;height:auto}
dl{display:grid;grid-template-columns:max-content 1fr;gap:.25rem 1rem;margin:0}
dt{color:var(--muted)}
dd{margin:0;overflow-wrap:anywhere}
""".strip()


def _e(text: object) -> str:
    return html.escape(str(text), quote=True)


def build_static_page(*, name: str, magnet: str, identity: TorrentIdentity | None, total_size: int,
                      file_count: int, fmt: str, private: bool = False,
                      metadata: TorrentMetadata | None = None, manifest: PublisherManifest | None = None,
                      trust: TrustAssessment | None = None, qr: QrResult | None = None,
                      public_torrent_url: str = "", generated_at: int | None = None) -> str:
    """One self-contained HTML document: inline CSS, no scripts, no remote resources.

    Every piece of text is HTML-escaped.  Publisher details are labelled with
    their trust level.  Payment destinations are shown as text (plus a plain
    ``bitcoin:`` link); invoices are never included.
    """
    generated = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(generated_at or time.time()))
    files = "1 file" if file_count == 1 else f"{file_count:,} files"
    parts: list[str] = [
        "<!doctype html>",
        '<html lang="en"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        # Defence in depth: even if markup slipped through, nothing may load or run.
        "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; style-src 'unsafe-inline'\">",
        '<meta name="referrer" content="no-referrer">',
        f"<title>{_e(name)}</title>",
        f"<style>{_PAGE_CSS}</style></head><body><main>",
        f"<h1>{_e(name)}</h1>",
        f'<p class="muted">{_e(format_size(total_size))} in {_e(files)} · {_e(format_label(fmt))}'
        f'{" · private torrent" if private else ""}</p>',
    ]

    parts.append("<h2>Download</h2><div class=\"panel\">")
    if magnet.lower().startswith("magnet:?"):  # never emit any other scheme as a link
        parts.append(f'<p><a href="{_e(magnet)}">Open the magnet link in a BitTorrent client</a></p>')
    parts.append(f'<p class="mono">{_e(magnet)}</p>')
    if public_torrent_url and url_problem(public_torrent_url) is None:
        parts.append(f'<p><a rel="noopener noreferrer nofollow" href="{_e(public_torrent_url)}">'
                     f"Download the .torrent file</a></p>")
    if qr is not None and qr.ok and qr.svg_inline:
        parts.append(f'<p class="qr">{qr.svg_inline}</p>')
        if qr.trimmed:
            parts.append('<p class="muted">The QR code carries a shortened magnet link (info-hash, name and '
                         "first tracker). Use the text above for the full link.</p>")
    elif qr is not None and not qr.ok:
        parts.append(f'<p class="muted">No QR code: {_e(qr.reason)}</p>')
    parts.append("</div>")

    parts.append("<h2>Identity</h2><div class=\"panel\"><dl>")
    if identity is not None:
        if identity.v1:
            parts.append(f'<dt>Info-hash (v1)</dt><dd class="mono">{_e(identity.v1)}</dd>')
        if identity.v2:
            parts.append(f'<dt>Info-hash (v2)</dt><dd class="mono">{_e(identity.v2)}</dd>')
    if metadata is not None:
        parts.append(f"<dt>Piece size</dt><dd>{_e(format_size(metadata.piece_length))}</dd>")
        parts.append(f"<dt>Pieces</dt><dd>{metadata.num_pieces:,}</dd>")
    parts.append("</dl></div>")

    if manifest is not None:
        label = trust.label if trust is not None else "self-asserted"
        explanation = trust.explanation if trust is not None else ""
        parts.append("<h2>Publisher</h2><div class=\"panel\"><dl>")
        parts.append(f"<dt>Name</dt><dd>{_e(manifest.publisher)} <span class=\"muted\">({_e(label)})</span></dd>")
        if manifest.description:
            parts.append(f"<dt>About</dt><dd>{_e(manifest.description).replace(chr(10), '<br>')}</dd>")
        if manifest.website:
            parts.append(f'<dt>Website</dt><dd><a rel="noopener noreferrer nofollow" href="{_e(manifest.website)}">'
                         f"{_e(manifest.website)}</a></dd>")
        if manifest.feed_url:
            parts.append(f'<dt>Feed</dt><dd><a rel="noopener noreferrer nofollow" href="{_e(manifest.feed_url)}">'
                         f"{_e(manifest.feed_url)}</a></dd>")
        if manifest.licence:
            parts.append(f"<dt>Licence</dt><dd>{_e(manifest.licence)}</dd>")
        if trust is not None and trust.fingerprint:
            parts.append(f'<dt>Signing key</dt><dd class="mono">{_e(trust.fingerprint)}</dd>')
        parts.append("</dl>")
        if explanation:
            parts.append(f'<p class="muted">{_e(explanation)}</p>')
        parts.append("</div>")
        if manifest.has_payment_endpoint:
            parts.append("<h2>Support the publisher</h2><div class=\"panel\"><dl>")
            if manifest.bitcoin_address:
                net = "" if manifest.bitcoin_network == "mainnet" else f" ({manifest.bitcoin_network})"
                parts.append(f'<dt>Bitcoin{_e(net)}</dt><dd><span class="mono">{_e(manifest.bitcoin_address)}</span> · '
                             f'<a href="bitcoin:{_e(manifest.bitcoin_address)}">open in a wallet</a></dd>')
            if manifest.lightning_address:
                parts.append(f'<dt>Lightning</dt><dd class="mono">{_e(manifest.lightning_address)}</dd>')
            parts.append("</dl>")
            parts.append('<p class="muted">These destinations are '
                         f"{_e(label)}. Payments are voluntary tips: they do not buy access, a download, "
                         "seeding or a refund. On-chain Bitcoin payments are public.</p></div>")

    if metadata is not None:
        real = metadata.real_files
        parts.append(f"<h2>Files</h2><div class=\"panel\"><table><thead><tr><th>Path</th>"
                     f"<th>Size</th></tr></thead><tbody>")
        for f in real[:MAX_PAGE_FILES]:
            parts.append(f'<tr><td>{_e(f.path)}</td><td class="num">{_e(format_size(f.size))}</td></tr>')
        parts.append("</tbody></table>")
        if len(real) > MAX_PAGE_FILES:
            parts.append(f'<p class="muted">… and {len(real) - MAX_PAGE_FILES:,} more files.</p>')
        parts.append("</div>")

    parts.append('<h2>Please note</h2><div class="panel notice">')
    for note in (NOTE_EXPORT_IS_NOT_PUBLISHING, NOTE_MAGNET_IS_NOT_HOSTING, NOTE_VERIFICATION_IS_NOT_SAFETY):
        parts.append(f"<p>{_e(note)}</p>")
    parts.append("</div>")
    parts.append(f'<p class="muted">Generated by AUREOM TORRENT on {_e(generated)}.</p>')
    parts.append("</main></body></html>")
    return "\n".join(parts) + "\n"


# ---------------------------------------------------------------------------
# Atom catalogue entry
# ---------------------------------------------------------------------------

def _rfc3339(ts: int) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def identity_urn(identity: TorrentIdentity) -> str:
    return f"urn:btih:{identity.v1}" if identity.v1 else f"urn:btmh:1220{identity.v2}"


_XML_ILLEGAL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")


def _x(text: str) -> str:
    """Remove characters that XML 1.0 cannot represent (ElementTree escapes the rest)."""
    return _XML_ILLEGAL.sub("", text)


def build_atom_entry(*, name: str, magnet: str, identity: TorrentIdentity, total_size: int, file_count: int,
                     fmt: str, updated: int, publisher: str = "", summary: str = "", category: str = "",
                     public_torrent_url: str = "", torrent_file_size: int = 0, feed_title: str = "",
                     entry_only: bool = False) -> str:
    """An Atom document for a publisher's catalogue.

    By default the result is a complete single-entry ``<feed>``; with
    ``entry_only`` it is just the ``<entry>`` element, to paste into an existing
    feed.  The magnet is the entry's alternate link; the .torrent enclosure is
    added only when the publisher supplies the public URL where they host it.
    ezRSS-style ``torrent:`` elements carry the info-hash and content size.
    """
    ET.register_namespace("", ATOM_NS)
    ET.register_namespace("torrent", TORRENT_NS)

    def a(tag: str) -> str:
        return f"{{{ATOM_NS}}}{tag}"

    def t(tag: str) -> str:
        return f"{{{TORRENT_NS}}}{tag}"

    stamp = _rfc3339(updated)
    urn = identity_urn(identity)
    entry = ET.Element(a("entry"))
    ET.SubElement(entry, a("title")).text = _x(name)
    ET.SubElement(entry, a("id")).text = urn
    ET.SubElement(entry, a("updated")).text = stamp
    ET.SubElement(entry, a("published")).text = stamp
    if publisher:
        ET.SubElement(ET.SubElement(entry, a("author")), a("name")).text = _x(publisher)
    ET.SubElement(entry, a("link"), {"rel": "alternate", "href": magnet})
    if public_torrent_url and url_problem(public_torrent_url) is None:
        attrs = {"rel": "enclosure", "type": "application/x-bittorrent", "href": public_torrent_url}
        if torrent_file_size > 0:
            attrs["length"] = str(torrent_file_size)
        ET.SubElement(entry, a("link"), attrs)
    if category:
        ET.SubElement(entry, a("category"), {"term": _x(category)})
    files = "1 file" if file_count == 1 else f"{file_count:,} files"
    text = summary or f"{format_size(total_size)} in {files} · {format_label(fmt)}"
    ET.SubElement(entry, a("summary"), {"type": "text"}).text = _x(text)
    ET.SubElement(entry, t("infoHash")).text = identity.v1 or identity.v2
    if identity.v1 and identity.v2:
        ET.SubElement(entry, t("infoHashV2")).text = identity.v2
    ET.SubElement(entry, t("contentLength")).text = str(int(total_size))
    ET.SubElement(entry, t("magnetURI")).text = magnet

    if entry_only:
        root = entry
    else:
        root = ET.Element(a("feed"))
        ET.SubElement(root, a("title")).text = _x(feed_title or (f"{publisher} — torrents" if publisher else name))
        ET.SubElement(root, a("id")).text = urn + ":catalogue"
        ET.SubElement(root, a("updated")).text = stamp
        if publisher:
            ET.SubElement(ET.SubElement(root, a("author")), a("name")).text = _x(publisher)
        ET.SubElement(root, a("generator")).text = "AUREOM TORRENT"
        root.append(entry)
    ET.indent(root)
    return '<?xml version="1.0" encoding="utf-8"?>\n' + ET.tostring(root, encoding="unicode") + "\n"
