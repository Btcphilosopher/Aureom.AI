"""Publisher manifests: a small, versioned, size-limited description of who published a torrent.

Schema (version 1)
------------------
A manifest is a JSON object with these members (all optional except the first two)::

    {
      "schema_version": 1,
      "publisher": "Display name",                     1..120 characters
      "description": "Free text",                      0..2000 characters, "\n" allowed
      "torrent": {"v1": "<40 hex>", "v2": "<64 hex>"}, at least one member
      "website": "https://…",                          http/https, <= 512 characters, no credentials
      "feed_url": "https://…",
      "bitcoin": {"address": "…", "network": "mainnet|testnet|signet|regtest"},
      "lightning_address": "name@domain" | "lnurl1…",  never a BOLT11 invoice
      "licence": "CC-BY-4.0" | "https://…",            SPDX-like identifier or a URL
      "created": 1795596682,                           Unix seconds (integer)
      "signature": {"alg": "ed25519", "public_key": "<64 hex>", "value": "<128 hex>"}
    }

*Unknown members are rejected* (at every level): a manifest is either fully
understood or not used.  A manifest with a different ``schema_version`` is
rejected with a message saying so.  The serialised form may not exceed
``MAX_MANIFEST_BYTES`` (16 KiB).

Embedded form
-------------
When provenance matters the manifest is stored *inside the torrent's info
dictionary* (key ``x-aureom-publisher``), so that it is covered by the
info-hash.  That copy necessarily omits the ``torrent`` member: the info-hash
is computed over the dictionary containing the manifest, so it cannot be known
when the manifest is written.  The binding is positional instead – whoever
holds the torrent metadata holds exactly the manifest its creator put there.

Canonical form (used for signing and for storage)
-------------------------------------------------
* UTF-8 encoded JSON with no insignificant whitespace (separators ``,`` and ``:``);
* object members sorted by key (all keys are ASCII, so this is byte order);
* absent/empty optional members are omitted – there is no ``null``;
* numbers are integers only (no fractions, exponents, booleans or floats);
* strings must already be Unicode NFC and contain no control characters
  (only ``description`` may contain ``\\n``); non-ASCII characters are written
  literally, and only ``"``, ``\\`` and the newline are escaped (``\\"``, ``\\\\``, ``\\n``);
* hexadecimal values are lowercase.

Signatures and trust
--------------------
A signature is Ed25519 (via ``cryptography``) over the canonical bytes of the
manifest *without* its ``signature`` member.  Verifying a signature answers one
question only: "were these exact bytes signed by the holder of this key?"  It
says nothing about who that is.  :func:`assess_trust` therefore keeps two
things apart:

* ``SignatureStatus`` – UNSIGNED / VALID / INVALID (pure cryptography);
* ``TrustLevel`` – SELF_ASSERTED, SIGNED_UNRECOGNISED (valid signature, key not
  pinned by the user: still self-asserted), PINNED_KEY (valid signature by a
  key the user pinned on this device), INVALID_SIGNATURE.

There is no key directory or web of trust: a key becomes "pinned" only because
the user chose to pin it locally, having obtained it through a channel they
trust.

Payment endpoints are carried as plain data.  This module never contacts them,
never validates Bitcoin addresses cryptographically (only character set,
length and prefix-versus-network sanity), and does not import the payments
package.
"""

from __future__ import annotations

import enum
import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, replace
from typing import Any, Iterable
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from ..domain.identity import IdentityError, TorrentIdentity

SCHEMA_VERSION = 1
MAX_MANIFEST_BYTES = 16 * 1024
MAX_PUBLISHER = 120
MAX_DESCRIPTION = 2000
MAX_URL = 512
MAX_LICENCE_ID = 64
MAX_LNURL = 1024
MAX_CREATED = 32_503_680_000  # year 3000; anything later is a mistake

NETWORKS = ("mainnet", "testnet", "signet", "regtest")

_TOP_KEYS = {"schema_version", "publisher", "description", "torrent", "website", "feed_url", "bitcoin",
             "lightning_address", "licence", "created", "signature"}
_HEX40 = re.compile(r"^[0-9a-f]{40}$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_HEX128 = re.compile(r"^[0-9a-f]{128}$")
_CONTROL = re.compile(r"[\x00-\x1f\x7f-\x9f  ]")
_CONTROL_EXCEPT_NL = re.compile(r"[\x00-\x09\x0b-\x1f\x7f-\x9f  ]")
_LICENCE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.+-]{0,%d}$" % (MAX_LICENCE_ID - 1))
_BASE58 = re.compile(r"^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]{26,35}$")
_BECH32_DATA = re.compile(r"^[02-9ac-hj-np-z]{6,87}$")
_LUD16 = re.compile(r"^[a-z0-9._+-]{1,64}@(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
_LNURL = re.compile(r"^lnurl1[02-9ac-hj-np-z]{20,%d}$" % (MAX_LNURL - 6))
_INVOICE_LIKE = re.compile(r"^(lightning:)?ln(bc|tb|tbs|bcrt)[0-9]*[munp]?1[02-9ac-hj-np-z]+$", re.IGNORECASE)
_OFFER_LIKE = re.compile(r"^(lightning:)?ln[oir]1", re.IGNORECASE)

# (base58 leading characters, bech32 human-readable part) per network
_BTC_RULES = {
    "mainnet": ("13", "bc"),
    "testnet": ("mn2", "tb"),
    "signet": ("mn2", "tb"),
    "regtest": ("mn2", "bcrt"),
}


class ManifestError(ValueError):
    """A manifest that cannot be used. ``problems`` are safe to show to the user."""

    def __init__(self, problems: list[str]):
        self.problems = list(problems)
        super().__init__("; ".join(self.problems) if self.problems else "invalid manifest")


class Provenance(str, enum.Enum):
    EMBEDDED = "embedded"  # found inside the info dictionary: bound to the info-hash
    EXTERNAL = "external"  # fetched or imported separately: untrusted
    LOCAL = "local"  # written on this device

    @property
    def label(self) -> str:
        return {
            "embedded": "Embedded in the torrent metadata (covered by the info-hash)",
            "external": "Supplied separately from the torrent (untrusted)",
            "local": "Written on this device",
        }[self.value]


class SignatureStatus(str, enum.Enum):
    UNSIGNED = "unsigned"
    VALID = "valid"
    INVALID = "invalid"


class TrustLevel(str, enum.Enum):
    SELF_ASSERTED = "self_asserted"
    SIGNED_UNRECOGNISED = "signed_unrecognised"
    PINNED_KEY = "pinned_key"
    INVALID_SIGNATURE = "invalid_signature"


TRUST_LABELS = {
    TrustLevel.SELF_ASSERTED: "self-asserted",
    TrustLevel.SIGNED_UNRECOGNISED: "signed by unrecognised key (self-asserted)",
    TrustLevel.PINNED_KEY: "verified against a key you pinned",
    TrustLevel.INVALID_SIGNATURE: "signature invalid — treat as untrusted",
}

TRUST_EXPLANATIONS = {
    TrustLevel.SELF_ASSERTED:
        "These publisher details are unsigned. Anyone who creates a torrent can write anything here.",
    TrustLevel.SIGNED_UNRECOGNISED:
        "The signature is valid, which shows the details were not altered after signing. It does not "
        "show who holds the key: you have not pinned this key, so the identity is still self-asserted.",
    TrustLevel.PINNED_KEY:
        "The signature is valid and was made with a key you pinned on this device. This is only as "
        "trustworthy as the way you obtained that key.",
    TrustLevel.INVALID_SIGNATURE:
        "The signature does not match the manifest. The details may have been altered; do not rely on them.",
}


@dataclass(frozen=True, slots=True)
class ManifestSignature:
    public_key: str  # 64 lowercase hex characters (raw Ed25519 public key)
    value: str  # 128 lowercase hex characters
    alg: str = "ed25519"


@dataclass(frozen=True, slots=True)
class PublisherManifest:
    publisher: str
    description: str = ""
    identity: TorrentIdentity | None = None
    website: str = ""
    feed_url: str = ""
    bitcoin_address: str = ""
    bitcoin_network: str = ""  # set exactly when ``bitcoin_address`` is
    lightning_address: str = ""
    licence: str = ""
    created: int = 0
    signature: ManifestSignature | None = None
    schema_version: int = SCHEMA_VERSION

    # -- serialisation ------------------------------------------------------
    def to_dict(self, *, include_signature: bool = True) -> dict[str, Any]:
        out: dict[str, Any] = {"schema_version": self.schema_version, "publisher": self.publisher}
        if self.description:
            out["description"] = self.description
        if self.identity is not None:
            torrent: dict[str, str] = {}
            if self.identity.v1:
                torrent["v1"] = self.identity.v1
            if self.identity.v2:
                torrent["v2"] = self.identity.v2
            out["torrent"] = torrent
        if self.website:
            out["website"] = self.website
        if self.feed_url:
            out["feed_url"] = self.feed_url
        if self.bitcoin_address:
            out["bitcoin"] = {"address": self.bitcoin_address, "network": self.bitcoin_network}
        if self.lightning_address:
            out["lightning_address"] = self.lightning_address
        if self.licence:
            out["licence"] = self.licence
        if self.created:
            out["created"] = self.created
        if include_signature and self.signature is not None:
            out["signature"] = {"alg": self.signature.alg, "public_key": self.signature.public_key,
                                "value": self.signature.value}
        return out

    def canonical_bytes(self, *, include_signature: bool = True) -> bytes:
        return canonical_json(self.to_dict(include_signature=include_signature))

    def signing_bytes(self) -> bytes:
        """The exact bytes a signature covers: the canonical form without ``signature``."""
        return self.canonical_bytes(include_signature=False)

    # -- derived forms ------------------------------------------------------
    def embedded_form(self) -> "PublisherManifest":
        """The copy stored inside the info dictionary: no torrent identity, signature dropped
        (sign the returned manifest again if a signature is wanted)."""
        return replace(self, identity=None, signature=None)

    def with_identity(self, identity: TorrentIdentity | None) -> "PublisherManifest":
        """The same statements bound to ``identity``; any signature is dropped because it no longer applies."""
        return replace(self, identity=identity, signature=None)

    @property
    def has_payment_endpoint(self) -> bool:
        return bool(self.bitcoin_address or self.lightning_address)


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


# ---------------------------------------------------------------------------
# Parsing and validation
# ---------------------------------------------------------------------------

def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate member “{key[:40]}”")
        out[key] = value
    return out


def _reject_number(text: str) -> Any:
    raise ValueError("only whole numbers are allowed")


def parse_manifest(data: bytes | str | dict[str, Any]) -> PublisherManifest:
    """Validate untrusted manifest data. Raises :class:`ManifestError` listing every problem."""
    if isinstance(data, (bytes, bytearray, str)):
        raw = data.encode("utf-8", "surrogatepass") if isinstance(data, str) else bytes(data)
        if len(raw) > MAX_MANIFEST_BYTES:
            raise ManifestError([f"The manifest is larger than the {MAX_MANIFEST_BYTES // 1024} KiB limit."])
        try:
            text = raw.decode("utf-8", "strict")
            obj = json.loads(text, object_pairs_hook=_no_duplicates, parse_float=_reject_number,
                             parse_constant=_reject_number)
        except (UnicodeDecodeError, ValueError, RecursionError) as exc:
            raise ManifestError([f"The manifest is not valid JSON ({str(exc)[:120]})."]) from exc
    elif isinstance(data, dict):
        obj = data
        try:
            size = len(canonical_json(obj))
        except (TypeError, ValueError) as exc:
            raise ManifestError(["The manifest contains values that cannot be represented."]) from exc
        if size > MAX_MANIFEST_BYTES:
            raise ManifestError([f"The manifest is larger than the {MAX_MANIFEST_BYTES // 1024} KiB limit."])
    else:
        raise ManifestError(["A manifest must be a JSON object."])
    if not isinstance(obj, dict):
        raise ManifestError(["A manifest must be a JSON object."])

    problems: list[str] = []
    version = obj.get("schema_version")
    if isinstance(version, bool) or not isinstance(version, int):
        raise ManifestError(["The manifest has no schema_version number."])
    if version != SCHEMA_VERSION:
        raise ManifestError([f"Manifest schema version {version} is not supported (this build reads version "
                             f"{SCHEMA_VERSION})."])
    unknown = sorted(str(k)[:40] for k in obj if k not in _TOP_KEYS)
    if unknown:
        problems.append("Unknown manifest members: " + ", ".join(unknown[:8]) + ".")

    publisher = _text(obj, "publisher", MAX_PUBLISHER, problems, required=True)
    description = _text(obj, "description", MAX_DESCRIPTION, problems, multiline=True)
    website = _url(obj, "website", problems)
    feed_url = _url(obj, "feed_url", problems)
    identity = _identity(obj, problems)
    address, network = _bitcoin(obj, problems)
    lightning = _lightning(obj, problems)
    licence = _licence(obj, problems)
    created = _created(obj, problems)
    signature = _signature(obj, problems)

    if problems:
        raise ManifestError(problems)
    return PublisherManifest(publisher=publisher, description=description, identity=identity, website=website,
                             feed_url=feed_url, bitcoin_address=address, bitcoin_network=network,
                             lightning_address=lightning, licence=licence, created=created,
                             signature=signature)


def _text(obj: dict, key: str, limit: int, problems: list[str], *, required: bool = False,
          multiline: bool = False) -> str:
    if key not in obj:
        if required:
            problems.append(f"“{key}” is required.")
        return ""
    value = obj[key]
    if not isinstance(value, str):
        problems.append(f"“{key}” must be text.")
        return ""
    if not value.strip():
        problems.append(f"“{key}” must not be empty (omit it instead).")
        return ""
    if value != value.strip():
        problems.append(f"“{key}” must not start or end with spaces.")
    if len(value) > limit:
        problems.append(f"“{key}” is longer than {limit} characters.")
    if (_CONTROL_EXCEPT_NL if multiline else _CONTROL).search(value):
        problems.append(f"“{key}” contains control characters.")
    if unicodedata.normalize("NFC", value) != value:
        problems.append(f"“{key}” is not in Unicode NFC form.")
    try:
        value.encode("utf-8", "strict")
    except UnicodeEncodeError:
        problems.append(f"“{key}” contains invalid Unicode.")
    return value


def url_problem(value: str) -> str | None:
    """Why ``value`` is not an acceptable manifest URL, or None."""
    if len(value) > MAX_URL:
        return f"is longer than {MAX_URL} characters"
    if _CONTROL.search(value) or any(c.isspace() for c in value):
        return "contains spaces or control characters"
    try:
        parts = urlsplit(value)
        _ = parts.port
    except ValueError:
        return "is not a valid URL"
    if value.split(":", 1)[0] not in ("http", "https") or not value.split(":", 1)[-1].startswith("//"):
        return "must be an http:// or https:// URL (lowercase scheme)"
    if parts.username is not None or parts.password is not None:
        return "must not contain a user name or password"
    if not parts.hostname:
        return "has no host name"
    return None


def _url(obj: dict, key: str, problems: list[str]) -> str:
    if key not in obj:
        return ""
    value = obj[key]
    if not isinstance(value, str) or not value:
        problems.append(f"“{key}” must be a non-empty URL.")
        return ""
    problem = url_problem(value)
    if problem:
        problems.append(f"“{key}” {problem}.")
    return value


def _identity(obj: dict, problems: list[str]) -> TorrentIdentity | None:
    if "torrent" not in obj:
        return None
    t = obj["torrent"]
    if not isinstance(t, dict) or not t:
        problems.append("“torrent” must be an object with a v1 and/or v2 info-hash.")
        return None
    extra = sorted(str(k)[:20] for k in t if k not in ("v1", "v2"))
    if extra:
        problems.append("Unknown members in “torrent”: " + ", ".join(extra[:4]) + ".")
    v1, v2 = t.get("v1"), t.get("v2")
    ok = True
    if v1 is not None and not (isinstance(v1, str) and _HEX40.match(v1)):
        problems.append("“torrent.v1” must be 40 lowercase hexadecimal characters.")
        ok = False
    if v2 is not None and not (isinstance(v2, str) and _HEX64.match(v2)):
        problems.append("“torrent.v2” must be 64 lowercase hexadecimal characters.")
        ok = False
    if not ok or (v1 is None and v2 is None):
        return None
    try:
        return TorrentIdentity(v1, v2)
    except IdentityError as exc:  # pragma: no cover - guarded above
        problems.append(str(exc))
        return None


def bitcoin_address_problem(address: str, network: str) -> str | None:
    """Sanity check only (character set, length, prefix versus network) – *no checksum*."""
    if network not in NETWORKS:
        return "names an unknown network"
    if not isinstance(address, str) or not address or len(address) > 90:
        return "is empty or too long"
    base58_first, hrp = _BTC_RULES[network]
    lower = address.lower()
    for other in ("bc", "tb", "bcrt"):
        if lower.startswith(other + "1") and address == lower:
            if other != hrp:
                return f"is not a {network} address"
            if not _BECH32_DATA.match(address[len(hrp) + 1:]):
                return "is not a well-formed bech32 address"
            return None
    if _BASE58.match(address):
        if address[0] not in base58_first:
            return f"is not a {network} address"
        return None
    return "is not a recognisable Bitcoin address (expected base58 or lowercase bech32)"


def _bitcoin(obj: dict, problems: list[str]) -> tuple[str, str]:
    if "bitcoin" not in obj:
        return "", ""
    b = obj["bitcoin"]
    if not isinstance(b, dict):
        problems.append("“bitcoin” must be an object with “address” and “network”.")
        return "", ""
    extra = sorted(str(k)[:20] for k in b if k not in ("address", "network"))
    if extra:
        problems.append("Unknown members in “bitcoin”: " + ", ".join(extra[:4]) + ".")
    address, network = b.get("address"), b.get("network")
    if not isinstance(network, str) or network not in NETWORKS:
        problems.append("“bitcoin.network” must be one of " + ", ".join(NETWORKS) + ".")
        return "", ""
    if not isinstance(address, str):
        problems.append("“bitcoin.address” must be text.")
        return "", ""
    problem = bitcoin_address_problem(address, network)
    if problem:
        problems.append(f"“bitcoin.address” {problem}.")
        return "", ""
    return address, network


def lightning_address_problem(value: str) -> str | None:
    if not isinstance(value, str) or not value:
        return "must be text"
    if _INVOICE_LIKE.match(value):
        return ("is a Lightning invoice. Invoices expire and can be paid only once, so they cannot be a "
                "permanent payment destination; use a Lightning address (name@domain) or an LNURL")
    if _OFFER_LIKE.match(value):
        return "is a BOLT12 string, which manifest schema 1 does not support"
    if len(value) > MAX_LNURL:
        return "is too long"
    if _LUD16.match(value) or _LNURL.match(value):
        return None
    return "must be a lowercase Lightning address (name@domain) or an lnurl1… string"


def _lightning(obj: dict, problems: list[str]) -> str:
    if "lightning_address" not in obj:
        return ""
    value = obj["lightning_address"]
    problem = lightning_address_problem(value)
    if problem:
        problems.append(f"“lightning_address” {problem}.")
        return ""
    return value


def licence_problem(value: str) -> str | None:
    if not isinstance(value, str) or not value:
        return "must be text"
    if _LICENCE_ID.match(value):
        return None
    if "://" in value:
        return url_problem(value)
    return f"must be an identifier such as CC-BY-4.0 (letters, digits, . + -, at most {MAX_LICENCE_ID}) or a URL"


def _licence(obj: dict, problems: list[str]) -> str:
    if "licence" not in obj:
        return ""
    value = obj["licence"]
    problem = licence_problem(value)
    if problem:
        problems.append(f"“licence” {problem}.")
        return ""
    return value


def _created(obj: dict, problems: list[str]) -> int:
    if "created" not in obj:
        return 0
    value = obj["created"]
    if isinstance(value, bool) or not isinstance(value, int) or not (0 < value < MAX_CREATED):
        problems.append("“created” must be a Unix timestamp in whole seconds.")
        return 0
    return value


def _signature(obj: dict, problems: list[str]) -> ManifestSignature | None:
    if "signature" not in obj:
        return None
    s = obj["signature"]
    if not isinstance(s, dict) or set(s) != {"alg", "public_key", "value"}:
        problems.append("“signature” must have exactly the members alg, public_key and value.")
        return None
    if s["alg"] != "ed25519":
        problems.append("Only “ed25519” signatures are supported.")
        return None
    if not (isinstance(s["public_key"], str) and _HEX64.match(s["public_key"])):
        problems.append("“signature.public_key” must be 64 lowercase hexadecimal characters.")
        return None
    if not (isinstance(s["value"], str) and _HEX128.match(s["value"])):
        problems.append("“signature.value” must be 128 lowercase hexadecimal characters.")
        return None
    return ManifestSignature(public_key=s["public_key"], value=s["value"])


def build_manifest(*, publisher: str, description: str = "", website: str = "", feed_url: str = "",
                   bitcoin_address: str = "", bitcoin_network: str = "mainnet", lightning_address: str = "",
                   licence: str = "", created: int = 0,
                   identity: TorrentIdentity | None = None) -> PublisherManifest:
    """Build a manifest from user input: trims, NFC-normalises, then validates strictly."""

    def norm(text: str) -> str:
        return unicodedata.normalize("NFC", (text or "").strip())

    data: dict[str, Any] = {"schema_version": SCHEMA_VERSION, "publisher": norm(publisher)}
    if norm(description):
        data["description"] = norm(description).replace("\r\n", "\n").replace("\r", "\n")
    if norm(website):
        data["website"] = norm(website)
    if norm(feed_url):
        data["feed_url"] = norm(feed_url)
    if norm(bitcoin_address):
        data["bitcoin"] = {"address": norm(bitcoin_address), "network": bitcoin_network or "mainnet"}
    if norm(lightning_address):
        value = norm(lightning_address)
        # Addresses and LNURLs are case-insensitive; invoices are left as typed so they are reported clearly.
        data["lightning_address"] = value if _INVOICE_LIKE.match(value) else value.lower()
    if norm(licence):
        data["licence"] = norm(licence)
    if created:
        data["created"] = int(created)
    if identity is not None:
        data["torrent"] = {k: v for k, v in (("v1", identity.v1), ("v2", identity.v2)) if v}
    if not data["publisher"]:
        raise ManifestError(["Enter a publisher name, or leave all publisher fields empty."])
    return parse_manifest(data)


# ---------------------------------------------------------------------------
# Signatures and trust
# ---------------------------------------------------------------------------

def generate_signing_key() -> str:
    """A new Ed25519 private key as 64 hex characters. Store it only in the credential store."""
    key = Ed25519PrivateKey.generate()
    return key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                             serialization.NoEncryption()).hex()


def public_key_of(private_key_hex: str) -> str:
    key = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(private_key_hex))
    return key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()


def key_fingerprint(public_key_hex: str) -> str:
    """A short, readable fingerprint: the first 16 hex digits of SHA-256(public key), in groups of four."""
    digest = hashlib.sha256(bytes.fromhex(public_key_hex)).hexdigest()[:16]
    return " ".join(digest[i:i + 4] for i in range(0, 16, 4))


def sign_manifest(manifest: PublisherManifest, private_key_hex: str) -> PublisherManifest:
    key = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(private_key_hex))
    unsigned = replace(manifest, signature=None)
    value = key.sign(unsigned.signing_bytes()).hex()
    return replace(unsigned, signature=ManifestSignature(public_key=public_key_of(private_key_hex), value=value))


def verify_signature(manifest: PublisherManifest) -> SignatureStatus:
    """Cryptographic validity only – see :func:`assess_trust` for what it does and does not mean."""
    sig = manifest.signature
    if sig is None:
        return SignatureStatus.UNSIGNED
    try:
        key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(sig.public_key))
        key.verify(bytes.fromhex(sig.value), manifest.signing_bytes())
    except (InvalidSignature, ValueError):
        return SignatureStatus.INVALID
    return SignatureStatus.VALID


@dataclass(frozen=True, slots=True)
class TrustAssessment:
    signature_status: SignatureStatus
    level: TrustLevel
    label: str
    explanation: str
    public_key: str = ""
    fingerprint: str = ""

    @property
    def verified(self) -> bool:
        """True only for a valid signature by a key the user pinned."""
        return self.level is TrustLevel.PINNED_KEY


def assess_trust(manifest: PublisherManifest, pinned_keys: Iterable[str] = ()) -> TrustAssessment:
    status = verify_signature(manifest)
    key = manifest.signature.public_key if manifest.signature else ""
    if status is SignatureStatus.UNSIGNED:
        level = TrustLevel.SELF_ASSERTED
    elif status is SignatureStatus.INVALID:
        level = TrustLevel.INVALID_SIGNATURE
    elif key in {k.lower() for k in pinned_keys}:
        level = TrustLevel.PINNED_KEY
    else:
        level = TrustLevel.SIGNED_UNRECOGNISED
    return TrustAssessment(signature_status=status, level=level, label=TRUST_LABELS[level],
                           explanation=TRUST_EXPLANATIONS[level], public_key=key,
                           fingerprint=key_fingerprint(key) if key else "")


def ensure_signing_key(secrets, *, create: bool = True) -> tuple[str, str, bool] | None:
    """Return ``(private_hex, public_hex, created_now)`` from the credential store.

    The key is generated only when ``create`` is true (i.e. the user asked to sign).
    Returns None when there is no key and ``create`` is false.
    """
    from ..settings.secrets import SECRET_MANIFEST_SIGNING_KEY

    stored = secrets.get(SECRET_MANIFEST_SIGNING_KEY)
    if stored:
        try:
            return stored, public_key_of(stored), False
        except ValueError:
            if not create:
                return None
    if not create:
        return None
    private = generate_signing_key()
    secrets.set(SECRET_MANIFEST_SIGNING_KEY, private)
    return private, public_key_of(private), True
