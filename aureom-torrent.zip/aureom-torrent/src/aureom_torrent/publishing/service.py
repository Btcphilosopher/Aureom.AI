"""Publish & Share application service (the wizard's backend).

Threading: every method may be called from a worker thread; none may be
called from the GUI thread (they touch disk, SQLite and possibly the network).
``start_job`` blocks for the duration of hashing and reports progress through
a callback.

What this service never does: invent hosting, contact a payment endpoint,
follow symbolic links out of the selected root, or overwrite a file without
being told to.
"""

from __future__ import annotations

import dataclasses
import logging
import os
import threading
from typing import Any, Callable, Iterable

from ..diagnostics.redaction import redact
from ..domain.identity import TorrentIdentity
from ..domain.transfers import TorrentMetadata
from ..engine.interface import CreationCancelled, TorrentCodec, TorrentCreator, TorrentFormatError
from ..filesystem.paths import ScanResult, UnsafePathError, scan_for_publish
from ..net.http import Fetcher, HttpFetchError, HttpPolicy, safe_url_for_display
from ..persistence.database import Database
from ..services.interfaces import AddRejected, TransferGateway
from ..settings.secrets import SecretStore, upload_secret_name
from ..util.clock import Clock, SystemClock
from . import creator as creator_logic
from . import sharing
from .adapters.base import PublishAdapter
from .adapters.https_upload import HttpsUploadAdapter, base_url_problems
from .adapters.local_dir import LocalDirAdapter
from .manifests import (MAX_MANIFEST_BYTES, ManifestError, Provenance, PublisherManifest, SignatureStatus,
                        TrustAssessment, assess_trust, ensure_signing_key, parse_manifest, sign_manifest,
                        verify_signature)
from .models import (ARTIFACT_KINDS, Artifact, JobState, OptionsCheck, PublishDestination, PublishDraft,
                     PublishError, PublishJob, PublishOperationResult, ShareInfo)
from .repository import ManifestRecord, PublishingRepository, new_id

log = logging.getLogger(__name__)

MAX_TORRENT_READ = 32 * 1024 * 1024
DESTINATION_KINDS = ("local_dir", "https_upload")
INTERRUPTED_MESSAGE = ("The application closed before this torrent was finished. Nothing was published; "
                       "start the wizard again to recreate it.")

AdapterFactory = Callable[[PublishDestination], PublishAdapter]


class PublishService:
    def __init__(self, db: Database, creator: TorrentCreator, codec: TorrentCodec,
                 gateway: TransferGateway | None, secrets: SecretStore, fetcher: Fetcher | None,
                 settings: Any, clock: Clock | None = None, exports_dir: str | os.PathLike[str] | None = None,
                 *, adapter_factory: AdapterFactory | None = None):
        """``settings`` may be an ``AppSettings``, a ``SettingsStore`` (anything with ``get()``),
        or a zero-argument callable returning ``AppSettings``."""
        self._repo = PublishingRepository(db)
        self._creator = creator
        self._codec = codec
        self._gateway = gateway
        self._secrets = secrets
        self._fetcher = fetcher
        self._settings_source = settings
        self._clock = clock or SystemClock()
        self._exports_dir = str(exports_dir) if exports_dir else ""
        self._adapter_factory = adapter_factory
        self._lock = threading.RLock()

    # -- helpers ------------------------------------------------------------
    def _now(self) -> int:
        return int(self._clock.now())

    def _settings(self):
        src = self._settings_source
        if callable(src):
            return src()
        getter = getattr(src, "get", None)
        return getter() if callable(getter) else src

    def _policy(self) -> HttpPolicy:
        return HttpPolicy.from_settings(self._settings().publishing_network)

    def _op(self, operation: str, destination: str, ok: bool, message: str) -> PublishOperationResult:
        return PublishOperationResult(operation=operation, destination=destination, ok=ok, message=message,
                                      ts=self._now())

    def _save(self, job: PublishJob) -> None:
        job.updated_at = self._now()
        self._repo.update_job(job)

    def _record(self, job: PublishJob, op: PublishOperationResult) -> None:
        with self._lock:
            job.operations.append(op)
            self._save(job)

    # -- step 1-2: select and review -----------------------------------------
    def scan(self, path: str, *, cancelled: Callable[[], bool] = lambda: False,
             skip_junk: bool = True) -> ScanResult:
        """List the files that can be published from ``path``.

        Symbolic links are never followed; links, special files, unreadable
        entries and OS junk files are returned in ``ScanResult.skipped`` with a
        reason so the review step can show them.  Raises ``PublishError`` when
        the selection itself is unusable.
        """
        try:
            return scan_for_publish(path, skip_junk=skip_junk, cancelled=cancelled)
        except UnsafePathError as exc:
            raise PublishError(str(exc)) from exc
        except OSError as exc:
            raise PublishError(f"Could not read the selection: {exc.strerror or exc}.") from exc

    # -- steps 3-7: options ---------------------------------------------------
    def check_options(self, draft: PublishDraft, *, total_size: int | None = None) -> OptionsCheck:
        return creator_logic.check_options(draft, total_size=total_size, can_seed=self._gateway is not None,
                                           now=self._now())

    def validate_options(self, draft: PublishDraft, *, total_size: int | None = None) -> list[str]:
        """Blocking problems only (see :meth:`option_warnings` for advice that does not block)."""
        return list(self.check_options(draft, total_size=total_size).errors)

    def option_warnings(self, draft: PublishDraft, *, total_size: int | None = None) -> list[str]:
        return list(self.check_options(draft, total_size=total_size).warnings)

    def suggest_torrent_path(self, source_path: str, name: str = "") -> str:
        return creator_logic.suggest_torrent_path(source_path, name)

    @staticmethod
    def piece_length_choices() -> list[tuple[str, int]]:
        return creator_logic.piece_length_choices()

    # -- steps 8-10: hash, save, seed -----------------------------------------
    def start_job(self, draft: PublishDraft, *, on_progress: Callable[[int, int], None] | None = None,
                  cancelled: Callable[[], bool] | None = None) -> PublishJob:
        """Create the torrent described by ``draft``. Blocking; call from a worker thread.

        Raises :class:`PublishError` if the draft is invalid (no job is recorded).
        Otherwise returns the job in its final state: ``completed``,
        ``cancelled`` (no .torrent is left behind) or ``failed`` (``job.error``).
        A failure to start seeding does not fail the job; it is recorded as the
        ``start_seeding`` operation.
        """
        on_progress = on_progress or (lambda done, total: None)
        cancelled = cancelled or (lambda: False)

        # Re-scan now: the included files must be regular files reachable without following any link.
        scan = None
        if draft.source_path and os.path.isabs(draft.source_path) and os.path.lexists(draft.source_path):
            scan = self.scan(draft.source_path, cancelled=cancelled)
            if scan.truncated and cancelled():
                now = self._now()
                job = PublishJob(
                    id=new_id(), state=JobState.CANCELLED, created_at=now, updated_at=now,
                    source_path=os.path.abspath(draft.source_path),
                    torrent_path=os.path.abspath(draft.output_torrent_path) if draft.output_torrent_path else "",
                    name=creator_logic.effective_name(draft), format=draft.format, private=bool(draft.private),
                    error="Cancelled before the torrent was created.")
                self._repo.insert_job(job)
                return job
        sizes = {f.relative: f.size for f in scan.files} if scan else {}
        total = sum(sizes.get(rel, 0) for rel in draft.included_files)
        check = self.check_options(draft, total_size=total if scan else None)
        problems = list(check.errors)
        if scan is not None and scan.truncated:
            problems.append("The selection contains too many files to publish as one torrent.")
        elif scan is not None:
            missing = [rel for rel in draft.included_files if rel not in sizes]
            if missing:
                problems.append(f"{len(missing)} selected file(s) are no longer regular files inside the "
                                f"selection (first: “{missing[0][:80]}”). Review the file list again.")
        if problems:
            raise PublishError("The torrent cannot be created: " + problems[0], problems)

        now = self._now()
        name = draft.name.strip() or os.path.basename(os.path.abspath(draft.source_path))
        job = PublishJob(
            id=new_id(), state=JobState.HASHING, created_at=now, updated_at=now,
            source_path=os.path.abspath(draft.source_path), torrent_path=os.path.abspath(draft.output_torrent_path),
            name=name, format=draft.format, total_size=total, file_count=len(draft.included_files),
            piece_length=check.piece_length, private=bool(draft.private), options=self._options_summary(draft, check))
        self._repo.insert_job(job)  # persisted before any work so an interruption is detectable
        log.info("publish job %s: hashing %d file(s), %d bytes, format %s", job.id, job.file_count,
                 job.total_size, job.format)

        try:
            manifest = creator_logic.build_publisher_manifest(draft, created=now)
            signing_key: str | None = None
            if manifest is not None and draft.sign_manifest:
                key = ensure_signing_key(self._secrets, create=True)
                assert key is not None
                signing_key = key[0]
                if key[2]:
                    log.info("created a manifest signing key in the %s", self._secrets.description)
            embedded = b""
            if manifest is not None and draft.embed_manifest:
                inner = manifest.embedded_form()
                if signing_key:
                    inner = sign_manifest(inner, signing_key)
                embedded = inner.canonical_bytes()

            request = creator_logic.build_create_request(draft, check.tiers, embedded)
            created = self._creator.create(request, on_progress, cancelled)
            if cancelled():
                raise CreationCancelled()

            meta = created.metadata
            job.state = JobState.SAVING
            job.v1, job.v2 = meta.identity.v1, meta.identity.v2
            job.name = meta.name
            job.total_size = meta.total_size
            job.file_count = len(meta.real_files)
            job.piece_length = meta.piece_length
            self._save(job)

            creator_logic.write_torrent_file(job.torrent_path, created.torrent_data, overwrite=draft.overwrite)
            job.magnet = self._codec.make_magnet(created.torrent_data)
            job.operations.append(self._op("save_torrent", job.torrent_path, True,
                                         f"Saved the torrent file ({len(created.torrent_data):,} bytes)."))

            if manifest is not None:
                full = manifest.with_identity(meta.identity)
                if signing_key:
                    full = sign_manifest(full, signing_key)
                record = self._repo.save_manifest(full, provenance=Provenance.LOCAL,
                                                  signature_status=verify_signature(full), now=self._now())
                job.manifest_id = record.id
            self._save(job)
        except CreationCancelled:
            job.state = JobState.CANCELLED
            job.error = "Cancelled before the torrent was created."
            self._cleanup_temp(job)
            self._save(job)
            log.info("publish job %s cancelled", job.id)
            return job
        except FileExistsError:
            return self._fail(job, "A file already exists at the output path; it was not overwritten.")
        except (OSError, ValueError, ManifestError, TorrentFormatError) as exc:
            detail = exc.strerror if isinstance(exc, OSError) and exc.strerror else str(exc)
            return self._fail(job, redact(detail) or type(exc).__name__)
        except Exception as exc:  # the wizard must always get a job back
            log.exception("publish job %s failed unexpectedly", job.id)
            return self._fail(job, f"Unexpected error ({type(exc).__name__}).")

        if draft.start_seeding:
            self._start_seeding(job, created.torrent_data, draft)
        job.state = JobState.COMPLETED
        self._save(job)
        log.info("publish job %s completed (%s)", job.id, meta.identity.kind)
        return job

    def _fail(self, job: PublishJob, message: str) -> PublishJob:
        job.state = JobState.FAILED
        job.error = message
        self._cleanup_temp(job)
        self._save(job)
        log.warning("publish job %s failed: %s", job.id, message)
        return job

    @staticmethod
    def _cleanup_temp(job: PublishJob) -> int:
        removed = 0
        for path in creator_logic.leftover_temp_files(job.torrent_path):
            try:
                os.unlink(path)
                removed += 1
            except OSError:
                pass
        return removed

    @staticmethod
    def _options_summary(draft: PublishDraft, check: OptionsCheck) -> dict[str, Any]:
        """What is kept with the job. The (possibly huge) file list is not stored, only its size."""
        publisher = dataclasses.asdict(draft.publisher) if draft.publisher and not draft.publisher.is_empty() else None
        return {
            "format": draft.format, "piece_length": draft.piece_length, "private": bool(draft.private),
            "trackers": [list(t) for t in check.tiers], "web_seeds": list(draft.web_seeds),
            "comment": draft.comment, "start_seeding": bool(draft.start_seeding),
            "embed_manifest": bool(draft.embed_manifest), "sign_manifest": bool(draft.sign_manifest),
            "overwrite": bool(draft.overwrite), "category": draft.category, "publisher": publisher,
            "included_files": len(draft.included_files),
        }

    def _start_seeding(self, job: PublishJob, torrent_data: bytes, draft: PublishDraft) -> None:
        save_path = os.path.dirname(job.source_path)
        if self._gateway is None:
            job.operations.append(self._op("start_seeding", save_path, False,
                                         "The transfer engine is not available, so seeding was not started."))
            return
        try:
            outcome = self._gateway.add_torrent_data(
                torrent_data, save_path=save_path, category=draft.category, paused=False, source="created",
                manifest_id=job.manifest_id)
        except AddRejected as exc:
            job.operations.append(self._op("start_seeding", save_path, False, str(exc)))
            return
        except Exception as exc:
            log.exception("publish job %s: adding the transfer failed", job.id)
            job.operations.append(self._op("start_seeding", save_path, False,
                                         f"The transfer could not be added ({type(exc).__name__})."))
            return
        job.transfer_id = outcome.transfer_id
        if job.manifest_id and outcome.transfer_id:
            self._repo.set_manifest_transfer(job.manifest_id, outcome.transfer_id)
        if outcome.created:
            message = ("Added to transfers. The files are verified first; seeding begins when the check "
                       "completes.")
        else:
            message = "This torrent is already in your transfers; the existing transfer was left unchanged."
        job.operations.append(self._op("start_seeding", save_path, True, message))

    def recover_interrupted(self) -> int:
        """Mark jobs that were mid-flight when the application last stopped. Call once at start-up."""
        jobs = self._repo.jobs_in_states((JobState.HASHING, JobState.SAVING))
        for job in jobs:
            removed = self._cleanup_temp(job)
            job.state = JobState.INTERRUPTED
            job.error = INTERRUPTED_MESSAGE
            if os.path.isfile(job.torrent_path):
                job.error += " A file exists at the output path, but it may not belong to this job."
            self._save(job)
            log.warning("publish job %s was interrupted (%d temporary file(s) removed)", job.id, removed)
        return len(jobs)

    # -- jobs -----------------------------------------------------------------
    def list_jobs(self, limit: int = 100) -> list[PublishJob]:
        return self._repo.list_jobs(limit)

    def get_job(self, job_id: str) -> PublishJob | None:
        return self._repo.get_job(job_id)

    def delete_job(self, job_id: str) -> None:
        """Forget a job record. No file on disk is touched."""
        self._repo.delete_job(job_id)

    def _require_job(self, job_id: str, *, completed: bool = True) -> PublishJob:
        job = self._repo.get_job(job_id)
        if job is None:
            raise PublishError("That publishing job no longer exists.")
        if completed and job.state is not JobState.COMPLETED:
            raise PublishError(f"This job did not complete ({job.state.label}); there is nothing to share.")
        return job

    # -- step 11: sharing -------------------------------------------------------
    def _job_metadata(self, job: PublishJob) -> tuple[TorrentMetadata | None, bytes]:
        """Read the saved .torrent back, if it is still there and still this torrent."""
        try:
            if os.path.getsize(job.torrent_path) > MAX_TORRENT_READ:
                return None, b""
            with open(job.torrent_path, "rb") as fh:
                data = fh.read(MAX_TORRENT_READ + 1)
            meta = self._codec.inspect(data)
        except (OSError, TorrentFormatError):
            return None, b""
        identity = job.identity
        if identity is None or not meta.identity.matches(identity):
            return None, b""
        return meta, data

    def _job_manifest(self, job: PublishJob) -> tuple[PublisherManifest | None, TrustAssessment | None]:
        record = self._repo.get_manifest(job.manifest_id) if job.manifest_id else None
        if record is None:
            return None, None
        return record.manifest, self.assess(record)

    def share_info(self, job_id: str) -> ShareInfo:
        job = self._require_job(job_id)
        manifest, trust = self._job_manifest(job)
        qr = sharing.make_magnet_qr(job.magnet, require_tracker=job.private)
        text = sharing.build_share_text(name=job.name, total_size=job.total_size, file_count=job.file_count,
                                        fmt=job.format, identity=job.identity, magnet=job.magnet,
                                        private=job.private, manifest=manifest, trust=trust)
        requested = bool(job.options.get("start_seeding"))
        seed_op = job.operation("start_seeding")
        return ShareInfo(
            job_id=job.id, name=job.name, magnet=job.magnet, torrent_path=job.torrent_path,
            torrent_file_exists=os.path.isfile(job.torrent_path), identity=job.identity, format=job.format,
            total_size=job.total_size, file_count=job.file_count, private=job.private, qr=qr, share_text=text,
            transfer_id=job.transfer_id, seeding_requested=requested,
            seeding_started=(seed_op.ok if seed_op else False) if requested else None,
            publisher_label=sharing.publisher_label(manifest, trust), operations=tuple(job.operations),
            notes=(sharing.NOTE_MAGNET_IS_NOT_HOSTING, sharing.NOTE_STAY_ONLINE,
                   sharing.NOTE_EXPORT_IS_NOT_PUBLISHING))

    def _build(self, job: PublishJob, kinds: Iterable[str] | None,
               public_torrent_url: str) -> tuple[list[Artifact], list[PublishOperationResult]]:
        wanted = list(dict.fromkeys(kinds if kinds is not None else ARTIFACT_KINDS))
        unknown = [k for k in wanted if k not in ARTIFACT_KINDS]
        if unknown:
            raise PublishError(f"Unknown artifact kind: {unknown[0]}.")
        if public_torrent_url:
            problem = creator_logic.url_problem(public_torrent_url, ("http", "https"))
            if problem:
                raise PublishError(f"The public .torrent address {problem}.")
        stem = sharing.safe_file_stem(job.name)
        meta, torrent_data = self._job_metadata(job)
        manifest, trust = self._job_manifest(job)
        qr = sharing.make_magnet_qr(job.magnet, require_tracker=job.private)
        identity = job.identity
        artifacts: list[Artifact] = []
        skipped: list[PublishOperationResult] = []

        def skip(kind: str, why: str) -> None:
            skipped.append(self._op(f"publish:{kind}", "", False, f"Not produced: {why}"))

        for kind in wanted:
            if kind == "torrent":
                if torrent_data:
                    artifacts.append(Artifact(kind, f"{stem}.torrent", torrent_data, "application/x-bittorrent"))
                else:
                    skip(kind, "the saved .torrent file is missing or has changed.")
            elif kind == "page":
                page = sharing.build_static_page(
                    name=job.name, magnet=job.magnet, identity=identity, total_size=job.total_size,
                    file_count=job.file_count, fmt=job.format, private=job.private, metadata=meta,
                    manifest=manifest, trust=trust, qr=qr, public_torrent_url=public_torrent_url,
                    generated_at=self._now())
                artifacts.append(Artifact(kind, f"{stem}.html", page.encode("utf-8"), "text/html; charset=utf-8"))
            elif kind == "atom":
                if identity is None:
                    skip(kind, "the job has no torrent identity.")
                    continue
                atom = sharing.build_atom_entry(
                    name=job.name, magnet=job.magnet, identity=identity, total_size=job.total_size,
                    file_count=job.file_count, fmt=job.format, updated=job.created_at,
                    publisher=manifest.publisher if manifest else "", category=str(job.options.get("category") or ""),
                    public_torrent_url=public_torrent_url, torrent_file_size=len(torrent_data))
                artifacts.append(Artifact(kind, f"{stem}.atom.xml", atom.encode("utf-8"),
                                          "application/atom+xml; charset=utf-8"))
            elif kind in ("qr_svg", "qr_png"):
                if not qr.ok:
                    skip(kind, f"{qr.reason} {qr.alternative}".strip())
                elif kind == "qr_svg":
                    artifacts.append(Artifact(kind, f"{stem}.qr.svg", qr.svg.encode("utf-8"), "image/svg+xml"))
                else:
                    artifacts.append(Artifact(kind, f"{stem}.qr.png", qr.png, "image/png"))
            elif kind == "manifest":
                if manifest is None:
                    skip(kind, "no publisher details were entered for this torrent.")
                else:
                    artifacts.append(Artifact(kind, f"{stem}.manifest.json", manifest.canonical_bytes(),
                                              "application/json"))
            elif kind == "share_text":
                text = sharing.build_share_text(name=job.name, total_size=job.total_size,
                                                file_count=job.file_count, fmt=job.format, identity=identity,
                                                magnet=job.magnet, private=job.private, manifest=manifest,
                                                trust=trust)
                artifacts.append(Artifact(kind, f"{stem}.txt", text.encode("utf-8"), "text/plain; charset=utf-8"))
        return artifacts, skipped

    def build_artifacts(self, job_id: str, kinds: Iterable[str] | None = None, *,
                        public_torrent_url: str = "") -> list[Artifact]:
        """Produce export artifacts in memory (nothing is written or sent)."""
        return self._build(self._require_job(job_id), kinds, public_torrent_url)[0]

    def _run_adapter(self, job: PublishJob, adapter: PublishAdapter, kinds: Iterable[str] | None,
                     public_torrent_url: str, cancelled: Callable[[], bool]) -> list[PublishOperationResult]:
        artifacts, skipped = self._build(job, kinds, public_torrent_url)
        try:
            where = adapter.describe()
        except Exception:
            where = "destination"
        results: list[PublishOperationResult] = []
        for note in skipped:
            op = dataclasses.replace(note, destination=where)
            results.append(op)
            self._record(job, op)
        for artifact in artifacts:
            name = f"publish:{artifact.kind}"
            if cancelled():
                op = self._op(name, where, False, "Not attempted: publishing was stopped.")
            else:
                try:
                    got = adapter.publish(artifact.name, artifact.content, artifact.content_type)
                    op = dataclasses.replace(got, operation=name, ts=got.ts or self._now(),
                                             message=redact(got.message))
                except Exception as exc:  # one failing artifact must not hide the others' outcomes
                    log.warning("publishing %s for job %s failed: %s", artifact.kind, job.id, type(exc).__name__)
                    op = self._op(name, where, False, f"Failed ({type(exc).__name__}).")
            results.append(op)
            self._record(job, op)  # persisted one by one: an interruption leaves an accurate record
        return results

    def export_to_directory(self, job_id: str, directory: str | None = None,
                            kinds: Iterable[str] | None = None, *,
                            public_torrent_url: str = "") -> list[PublishOperationResult]:
        """Write artifacts to a local folder (default: ``<exports_dir>/<torrent name>``)."""
        job = self._require_job(job_id)
        if not directory:
            if not self._exports_dir:
                raise PublishError("Choose a folder to export to.")
            directory = os.path.join(self._exports_dir, sharing.safe_file_stem(job.name))
        problems = LocalDirAdapter.config_problems({"directory": directory})
        if problems:
            raise PublishError(problems[0], problems)
        return self._run_adapter(job, LocalDirAdapter(directory), kinds, public_torrent_url, lambda: False)

    # -- destinations -----------------------------------------------------------
    def list_destinations(self) -> list[PublishDestination]:
        return self._repo.list_destinations()

    def destination_problems(self, kind: str, name: str, config: dict[str, Any]) -> list[str]:
        problems: list[str] = []
        if kind not in DESTINATION_KINDS:
            return ["Unknown destination type. Supported: a local folder or an HTTPS upload endpoint."]
        if not name.strip() or len(name) > 80:
            problems.append("Give the destination a name of at most 80 characters.")
        if kind == "local_dir":
            problems += LocalDirAdapter.config_problems(config)
            extra = set(config) - {"directory"}
        else:
            problems += base_url_problems(config.get("base_url"), allow_http=self._policy().allow_http)
            extra = set(config) - {"base_url"}
        if extra:
            # Refuse rather than silently persist something that might be a credential.
            problems.append("Unexpected destination settings: " + ", ".join(sorted(str(k)[:20] for k in extra)) + ".")
        return problems

    def save_destination(self, dest: PublishDestination, *, token: str | None = None) -> PublishDestination:
        """Create or update a destination. ``token`` (bearer token) goes to the credential store only;
        pass ``""`` to remove a stored token and ``None`` to leave it unchanged."""
        config = dict(dest.config)
        if dest.kind == "https_upload" and isinstance(config.get("base_url"), str):
            config["base_url"] = config["base_url"].strip().rstrip("/")
        problems = self.destination_problems(dest.kind, dest.name, config)
        if problems:
            raise PublishError(problems[0], problems)
        saved = PublishDestination(id=dest.id or new_id(), kind=dest.kind, name=dest.name.strip(), config=config)
        self._repo.save_destination(saved, self._now())
        if token is not None:
            secret = upload_secret_name(saved.id)
            if token:
                self._secrets.set(secret, token)
            else:
                self._secrets.delete(secret)
        return saved

    def delete_destination(self, destination_id: str) -> None:
        self._repo.delete_destination(destination_id)
        self._secrets.delete(upload_secret_name(destination_id))

    def destination_has_token(self, destination_id: str) -> bool:
        return bool(self._secrets.get(upload_secret_name(destination_id)))

    def _adapter_for(self, dest: PublishDestination) -> PublishAdapter:
        if self._adapter_factory is not None:
            return self._adapter_factory(dest)
        if dest.kind == "local_dir":
            return LocalDirAdapter(str(dest.config.get("directory", "")))
        if dest.kind == "https_upload":
            if self._fetcher is None:
                raise PublishError("Uploading is not available in this session.")
            return HttpsUploadAdapter(str(dest.config.get("base_url", "")), fetcher=self._fetcher,
                                      policy=self._policy(), token=self._secrets.get(upload_secret_name(dest.id)))
        raise PublishError("Unknown destination type.")

    def publish(self, job_id: str, destination_id: str, artifacts: Iterable[str] | None = None, *,
                public_torrent_url: str = "",
                cancelled: Callable[[], bool] | None = None) -> list[PublishOperationResult]:
        """Send the chosen artifact kinds to a configured destination.

        Every attempt is recorded on the job (``job.operations``) as it happens,
        including artifacts that could not be produced and ones not attempted
        after a stop.  A successful result means the destination accepted the
        bytes; it never means the content is publicly reachable.
        """
        job = self._require_job(job_id)
        dest = self._repo.get_destination(destination_id)
        if dest is None:
            raise PublishError("That publishing destination no longer exists.")
        adapter = self._adapter_for(dest)
        return self._run_adapter(job, adapter, artifacts, public_torrent_url, cancelled or (lambda: False))

    # -- manifests ----------------------------------------------------------------
    def pinned_keys(self) -> dict[str, str]:
        return self._repo.pinned_keys()

    def pin_key(self, public_key: str, label: str = "") -> None:
        key = public_key.strip().lower()
        if len(key) != 64 or any(c not in "0123456789abcdef" for c in key):
            raise PublishError("A publisher key is 64 hexadecimal characters.")
        self._repo.pin_key(key, label.strip(), self._now())

    def unpin_key(self, public_key: str) -> None:
        self._repo.unpin_key(public_key.strip())

    def assess(self, record: ManifestRecord | PublisherManifest) -> TrustAssessment:
        """Signature status and trust level for a manifest, against the locally pinned keys."""
        manifest = record.manifest if isinstance(record, ManifestRecord) else record
        return assess_trust(manifest, self._repo.pinned_keys().keys())

    def signing_public_key(self) -> str | None:
        key = ensure_signing_key(self._secrets, create=False)
        return key[1] if key else None

    def create_signing_key(self) -> str:
        """Create the local signing key if there is none; returns the public key."""
        key = ensure_signing_key(self._secrets, create=True)
        assert key is not None
        return key[1]

    def get_manifest(self, manifest_id: str) -> ManifestRecord | None:
        return self._repo.get_manifest(manifest_id)

    def list_manifests(self, limit: int = 100) -> list[ManifestRecord]:
        return self._repo.list_manifests(limit)

    def manifests_for_identity(self, identity: TorrentIdentity) -> list[ManifestRecord]:
        return self._repo.manifests_for_identity(identity)

    def manifests_for_transfer(self, transfer_id: str) -> list[ManifestRecord]:
        return self._repo.manifests_for_transfer(transfer_id)

    def manifest_for_job(self, job_id: str) -> ManifestRecord | None:
        job = self._repo.get_job(job_id)
        return self._repo.get_manifest(job.manifest_id) if job and job.manifest_id else None

    def record_embedded_manifest(self, metadata: TorrentMetadata,
                                 transfer_id: str | None = None) -> ManifestRecord | None:
        """Store the manifest found inside a torrent's info dictionary, if it is valid.

        An embedded manifest is bound to the info-hash, which establishes that it
        came with this torrent – not that its statements are true.  Invalid
        manifests are ignored (and logged without their content).
        """
        if not metadata.embedded_manifest:
            return None
        try:
            manifest = parse_manifest(metadata.embedded_manifest)
        except ManifestError as exc:
            log.info("ignoring an invalid embedded publisher manifest (%d problem(s))", len(exc.problems))
            return None
        if manifest.identity is not None and not manifest.identity.matches(metadata.identity):
            log.info("ignoring an embedded manifest that names a different torrent")
            return None
        for existing in self._repo.manifests_for_identity(metadata.identity):
            if existing.provenance is Provenance.EMBEDDED and existing.manifest == manifest:
                if transfer_id and existing.transfer_id != transfer_id:
                    self._repo.set_manifest_transfer(existing.id, transfer_id)
                    return self._repo.get_manifest(existing.id)
                return existing
        return self._repo.save_manifest(manifest, provenance=Provenance.EMBEDDED,
                                        signature_status=verify_signature(manifest), now=self._now(),
                                        transfer_id=transfer_id, identity=metadata.identity)

    def import_manifest(self, data: bytes | str, *, identity: TorrentIdentity | None = None,
                        transfer_id: str | None = None) -> ManifestRecord:
        """Store a manifest obtained outside the torrent (a file, a web page). Always ``external``.

        If the manifest names a torrent and ``identity`` is given, they must match.
        Raises :class:`ManifestError`.
        """
        manifest = parse_manifest(data)
        if identity is not None and manifest.identity is not None and not manifest.identity.matches(identity):
            raise ManifestError(["This manifest describes a different torrent."])
        return self._repo.save_manifest(manifest, provenance=Provenance.EXTERNAL,
                                        signature_status=verify_signature(manifest), now=self._now(),
                                        transfer_id=transfer_id, identity=identity or manifest.identity)

    def fetch_manifest(self, url: str, *, identity: TorrentIdentity | None = None,
                       transfer_id: str | None = None) -> ManifestRecord:
        """Download an external manifest (explicit user action only) and store it as untrusted.

        Uses the publishing network settings; the response is capped at the
        manifest size limit.  Raises :class:`PublishError` or :class:`ManifestError`.
        """
        if self._fetcher is None:
            raise PublishError("Downloading is not available in this session.")
        policy = dataclasses.replace(self._policy(), max_bytes=MAX_MANIFEST_BYTES)
        try:
            response = self._fetcher.fetch(url, policy=policy)
        except HttpFetchError as exc:
            raise PublishError(f"Could not download the manifest: {exc}") from exc
        if response.status != 200:
            raise PublishError(f"Could not download the manifest from {safe_url_for_display(url)} "
                               f"(HTTP {response.status}).")
        return self.import_manifest(response.body, identity=identity, transfer_id=transfer_id)

    def delete_manifest(self, manifest_id: str) -> None:
        self._repo.delete_manifest(manifest_id)

    # -- diagnostics ----------------------------------------------------------------
    def diagnostics(self) -> dict[str, Any]:
        """A summary for the diagnostic export. Contains no magnets, tracker URLs, tokens or paths
        beyond the destination folder; upload endpoints are reduced to scheme, host and path."""
        destinations = []
        for dest in self._repo.list_destinations():
            if dest.kind == "https_upload":
                target = safe_url_for_display(str(dest.config.get("base_url", "")))
            else:
                target = str(dest.config.get("directory", ""))
            destinations.append({"id": dest.id, "kind": dest.kind, "name": dest.name, "target": target,
                                 "has_token": self.destination_has_token(dest.id)})
        recent = []
        for job in self._repo.list_jobs(20):
            failed = [op.operation for op in job.operations if not op.ok]
            recent.append({"id": job.id, "state": job.state.value, "format": job.format,
                           "files": job.file_count, "bytes": job.total_size, "private": job.private,
                           "seeding_requested": bool(job.options.get("start_seeding")),
                           "has_transfer": bool(job.transfer_id), "error": redact(job.error),
                           "operations": len(job.operations), "failed_operations": failed[-10:]})
        return {
            "jobs_by_state": self._repo.job_state_counts(),
            "recent_jobs": recent,
            "destinations": destinations,
            "manifests_by_provenance": self._repo.manifest_counts(),
            "pinned_keys": len(self._repo.pinned_keys()),
            "signing_key_present": self.signing_public_key() is not None,
            "credential_store": self._secrets.description,
            "s3_adapter": "not implemented",
        }
