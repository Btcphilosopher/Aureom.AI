"""Redaction of secrets from log lines and diagnostic exports.

Applied to *every* log record before it reaches a handler, and again to the
diagnostic bundle as a whole.  Redacted classes:

* URL user-info and all query-string values of URLs (tracker passkeys, signed
  upload URLs, API tokens);
* tracker passkeys embedded in the path (``/announce/<key>``, ``/<key>/announce``);
* Lightning invoices (BOLT11) and LNURL strings;
* payment preimages / secrets / macaroons and other long hex or base64 blobs
  that follow a sensitive key name;
* ``Authorization`` / macaroon headers;
* key=value pairs whose key name is sensitive.
"""

from __future__ import annotations

import logging
import re
from typing import Any

REDACTED = "[redacted]"

_SENSITIVE_KEYS = (
    "passkey|pass_key|password|passwd|pwd|secret|token|api_?key|apikey|access_?key|auth|authorization|"
    "macaroon|preimage|payment_preimage|r_preimage|payment_secret|payment_addr|signature|sig|"
    "x-amz-signature|x-amz-credential|x-amz-security-token|credential|private_?key|seed|mnemonic|key"
)

_URL = re.compile(r"""\b(?P<scheme>https?|udp|wss?|socks5h?)://(?P<rest>(?:\[redacted\]|[^\s"'<>\]\)])+)""",
                  re.IGNORECASE)
_PASSKEY_PATH = re.compile(r"/(?:[0-9a-zA-Z]{16,64})(?=/announce|/scrape)|(?<=/announce/)[0-9a-zA-Z]{16,64}")
_BOLT11 = re.compile(r"\b(ln(?:bc|tb|tbs|bcrt)[0-9]*[munp]?1)[02-9ac-hj-np-z]{20,}\b", re.IGNORECASE)
_LNURL = re.compile(r"\b(lnurl1)[02-9ac-hj-np-z]{20,}\b", re.IGNORECASE)
_KEY_VALUE = re.compile(
    r"""(?P<key>["']?\b(?:%s)\b["']?)(?P<sep>\s*[:=]\s*)(?P<quote>["']?)(?P<value>[^\s"',;&}]{4,})(?P=quote)"""
    % _SENSITIVE_KEYS,
    re.IGNORECASE,
)
_HEADER = re.compile(r"(?i)\b(authorization|grpc-metadata-macaroon|x-api-key)\b(\s*[:=]\s*)(\S+(?:\s+\S+)?)")
_LONG_HEX = re.compile(r"\b[0-9a-fA-F]{96,}\b")  # macaroons and similar blobs; info-hashes (40/64) are kept
_MAGNET_TRACKER = re.compile(r"(?i)([?&]tr=)([^&\s]+)")


def _redact_url(match: re.Match[str]) -> str:
    scheme = match.group("scheme")
    rest = match.group("rest")
    # strip user-info
    authority, slash, tail = rest.partition("/")
    if "@" in authority:
        authority = REDACTED + "@" + authority.rsplit("@", 1)[1]
    tail = slash + tail
    path, q, _query = tail.partition("?")
    path = _PASSKEY_PATH.sub(lambda m: ("/" if m.group(0).startswith("/") else "") + REDACTED, path)
    return f"{scheme}://{authority}{path}" + (f"?{REDACTED}" if q else "")


def redact(text: str) -> str:
    """Return ``text`` with secrets removed. Idempotent."""
    if not text:
        return text
    text = _MAGNET_TRACKER.sub(lambda m: m.group(1) + REDACTED, text)
    text = _URL.sub(_redact_url, text)
    text = _BOLT11.sub(lambda m: m.group(1) + "…" + REDACTED, text)
    text = _LNURL.sub(lambda m: m.group(1) + "…" + REDACTED, text)
    text = _HEADER.sub(lambda m: m.group(1) + m.group(2) + REDACTED, text)
    text = _KEY_VALUE.sub(lambda m: m.group("key") + m.group("sep") + REDACTED, text)
    text = _LONG_HEX.sub(REDACTED, text)
    return text


def redact_obj(value: Any, _key: str = "") -> Any:
    """Recursively redact a JSON-like structure; values under sensitive keys are dropped entirely."""
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if re.fullmatch(_SENSITIVE_KEYS + "|invoice|payment_request|bolt11|proxy_url", str(k), re.IGNORECASE):
                out[k] = REDACTED if v not in ("", None, [], {}) else v
            else:
                out[k] = redact_obj(v, str(k))
        return out
    if isinstance(value, (list, tuple)):
        return [redact_obj(v, _key) for v in value]
    if isinstance(value, str):
        return redact(value)
    return value


class RedactingFilter(logging.Filter):
    """Formats the record eagerly and replaces its message with the redacted text."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
        except Exception:
            message = str(record.msg)
        record.msg = redact(message)
        record.args = None
        if record.exc_info and record.exc_info[1] is not None:
            # Keep the exception type; the text may embed URLs or credentials.
            record.exc_text = redact(logging.Formatter().formatException(record.exc_info))
            record.exc_info = None
        return True
