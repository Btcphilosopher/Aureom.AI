"""Redacted diagnostic bundle.

The bundle is a single JSON document assembled from *providers* – callables
registered by each subsystem that return JSON-like summaries.  The whole
document is passed through :func:`redact_obj` before it is written, so a
provider that forgets to redact something is still covered by the pattern
rules in ``diagnostics.redaction``.
"""

from __future__ import annotations

import json
import logging
import platform
import sys
import time
from typing import Any, Callable

from .logs import ring_buffer
from .redaction import redact_obj

log = logging.getLogger(__name__)

Provider = Callable[[], Any]


class DiagnosticsCollector:
    def __init__(self) -> None:
        self._providers: dict[str, Provider] = {}

    def register(self, section: str, provider: Provider) -> None:
        self._providers[section] = provider

    def build(self, *, log_limit: int = 1000) -> dict[str, Any]:
        bundle: dict[str, Any] = {
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "application": {"name": "AUREOM TORRENT", "version": _app_version()},
            "platform": {
                "python": sys.version.split()[0],
                "implementation": platform.python_implementation(),
                "system": platform.system(),
                "release": platform.release(),
                "machine": platform.machine(),
            },
            "libraries": _library_versions(),
        }
        for section, provider in self._providers.items():
            try:
                bundle[section] = provider()
            except Exception as exc:  # a broken provider must not block the export
                bundle[section] = {"error": f"{type(exc).__name__}: {exc}"}
        bundle["log"] = [
            {"ts": round(e.ts, 3), "level": e.level, "area": e.area, "message": e.message}
            for e in ring_buffer().entries(log_limit)
        ]
        return redact_obj(bundle)

    def export_json(self, **kwargs: Any) -> str:
        return json.dumps(self.build(**kwargs), indent=2, sort_keys=True, default=str)


def _app_version() -> str:
    try:
        from importlib.metadata import version

        return version("aureom-torrent")
    except Exception:
        return "0.1.0 (source tree)"


def _library_versions() -> dict[str, str]:
    from importlib.metadata import PackageNotFoundError, version

    out: dict[str, str] = {}
    for name in ("libtorrent", "PySide6-Essentials", "feedparser", "httpx", "keyring", "bolt11",
                 "segno", "nh3", "cryptography", "regex", "defusedxml"):
        try:
            out[name] = version(name)
        except PackageNotFoundError:
            out[name] = "not installed"
    return out
