"""Bounded structured logging: an in-memory ring buffer plus a size-rotated file."""

from __future__ import annotations

import collections
import logging
import logging.handlers
import threading
from dataclasses import dataclass
from pathlib import Path

from .redaction import RedactingFilter

RING_CAPACITY = 2000
FILE_BYTES = 1_000_000
FILE_BACKUPS = 3


@dataclass(frozen=True, slots=True)
class LogEntry:
    ts: float
    level: str
    area: str  # logger name without the package prefix, e.g. "engine", "feeds.client"
    message: str


class RingBufferHandler(logging.Handler):
    def __init__(self, capacity: int = RING_CAPACITY):
        super().__init__()
        self._entries: collections.deque[LogEntry] = collections.deque(maxlen=capacity)
        self._guard = threading.Lock()

    def emit(self, record: logging.LogRecord) -> None:
        message = record.getMessage()
        if record.exc_text:
            message = f"{message}\n{record.exc_text}"
        area = record.name.removeprefix("aureom_torrent.") or "app"
        with self._guard:
            self._entries.append(LogEntry(record.created, record.levelname, area, message))

    def entries(self, limit: int | None = None) -> list[LogEntry]:
        with self._guard:
            data = list(self._entries)
        return data[-limit:] if limit else data


_ring: RingBufferHandler | None = None


def ring_buffer() -> RingBufferHandler:
    global _ring
    if _ring is None:
        _ring = RingBufferHandler()
        _ring.addFilter(RedactingFilter())
    return _ring


def configure_logging(logs_dir: Path | None, *, level: int = logging.INFO, console: bool = False) -> RingBufferHandler:
    """Install the redacting ring buffer (and optional rotating file) on the package logger."""
    root = logging.getLogger("aureom_torrent")
    root.setLevel(level)
    root.propagate = False
    ring = ring_buffer()
    for h in list(root.handlers):
        root.removeHandler(h)
    root.addHandler(ring)
    formatter = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    if logs_dir is not None:
        logs_dir.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            logs_dir / "aureom-torrent.log", maxBytes=FILE_BYTES, backupCount=FILE_BACKUPS, encoding="utf-8")
        fh.addFilter(RedactingFilter())
        fh.setFormatter(formatter)
        root.addHandler(fh)
    if console:
        sh = logging.StreamHandler()
        sh.addFilter(RedactingFilter())
        sh.setFormatter(formatter)
        root.addHandler(sh)
    return ring
