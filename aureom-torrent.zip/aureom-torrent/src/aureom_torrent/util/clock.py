"""Clock abstraction so services can be tested with a controllable clock."""

from __future__ import annotations

import time
from typing import Protocol


class Clock(Protocol):
    def now(self) -> float:
        """Wall-clock seconds since the Unix epoch."""

    def monotonic(self) -> float:
        """Monotonic seconds, for intervals and timeouts."""


class SystemClock:
    def now(self) -> float:
        return time.time()

    def monotonic(self) -> float:
        return time.monotonic()
