"""SQLite access with ordered migrations.

One connection is shared between worker threads behind a re-entrant lock; all
statements are short.  The GUI thread never touches the database.
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import threading
import time
from contextlib import contextmanager
from importlib import resources
from pathlib import Path
from typing import Any, Iterable, Iterator

log = logging.getLogger(__name__)

_MIGRATION_NAME = re.compile(r"^(\d{4})_([a-z0-9_]+)\.sql$")


class DatabaseError(RuntimeError):
    pass


def discover_migrations() -> list[tuple[int, str, str]]:
    """Return ``(version, name, sql)`` for every packaged migration, ordered."""
    found: list[tuple[int, str, str]] = []
    pkg = resources.files("aureom_torrent.persistence").joinpath("migrations")
    for item in pkg.iterdir():
        m = _MIGRATION_NAME.match(item.name)
        if m:
            found.append((int(m.group(1)), m.group(2), item.read_text(encoding="utf-8")))
    found.sort()
    versions = [v for v, _, _ in found]
    if len(set(versions)) != len(versions):
        raise DatabaseError("duplicate migration version numbers")
    return found


class Database:
    def __init__(self, path: str | os.PathLike[str] | None):
        """Open (and migrate) the database. ``None`` opens a private in-memory database."""
        self.path = str(path) if path is not None else ":memory:"
        self.recovered_from: str | None = None
        self._lock = threading.RLock()
        self._conn = self._open()
        self.migrate()

    # -- opening / recovery -------------------------------------------------
    def _connect(self) -> sqlite3.Connection:
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _open(self) -> sqlite3.Connection:
        try:
            conn = self._connect()
            row = conn.execute("PRAGMA quick_check").fetchone()
            if row is None or row[0] != "ok":
                raise sqlite3.DatabaseError(f"integrity check failed: {row[0] if row else 'no result'}")
        except sqlite3.DatabaseError as exc:
            if self.path == ":memory:":
                raise
            # Keep the damaged file for inspection and start clean rather than refusing to launch.
            aside = f"{self.path}.corrupt-{int(time.time())}"
            try:
                conn.close()  # type: ignore[possibly-undefined]
            except Exception:
                pass
            for suffix in ("", "-wal", "-shm"):
                if os.path.exists(self.path + suffix):
                    os.replace(self.path + suffix, aside + suffix)
            log.error("database %s is unreadable (%s); moved aside to %s", self.path, exc, aside)
            self.recovered_from = aside
            conn = self._connect()
        conn.execute("PRAGMA foreign_keys = ON")
        if self.path != ":memory:":
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
        return conn

    # -- migrations ---------------------------------------------------------
    def migrate(self) -> list[int]:
        applied_now: list[int] = []
        with self._lock:
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations ("
                " version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at INTEGER NOT NULL)"
            )
            done = {r[0] for r in self._conn.execute("SELECT version FROM schema_migrations")}
            known = discover_migrations()
            newest_known = max((v for v, _, _ in known), default=0)
            if done and max(done) > newest_known:
                raise DatabaseError(
                    f"The database was written by a newer version of the application "
                    f"(schema {max(done)}, this build knows {newest_known})."
                )
            for version, name, sql in known:
                if version in done:
                    continue
                try:
                    self._conn.execute("BEGIN IMMEDIATE")
                    for statement in _split_sql(sql):
                        self._conn.execute(statement)
                    self._conn.execute(
                        "INSERT INTO schema_migrations(version, name, applied_at) VALUES (?,?,?)",
                        (version, name, int(time.time())),
                    )
                    self._conn.execute("COMMIT")
                except Exception as exc:
                    self._conn.execute("ROLLBACK")
                    raise DatabaseError(f"migration {version:04d}_{name} failed: {exc}") from exc
                applied_now.append(version)
        return applied_now

    def schema_version(self) -> int:
        row = self.query_one("SELECT MAX(version) AS v FROM schema_migrations")
        return int(row["v"] or 0) if row else 0

    # -- access -------------------------------------------------------------
    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        """A write transaction. Nested use joins the outer transaction."""
        with self._lock:
            if self._conn.in_transaction:
                yield self._conn
                return
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
            else:
                self._conn.execute("COMMIT")

    def execute(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self._lock:
            return self._conn.execute(sql, tuple(params))

    def executemany(self, sql: str, rows: Iterable[Iterable[Any]]) -> None:
        with self.tx() as conn:
            conn.executemany(sql, [tuple(r) for r in rows])

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, tuple(params)).fetchall()

    def query_one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        with self._lock:
            return self._conn.execute(sql, tuple(params)).fetchone()

    def get_meta(self, key: str) -> str | None:
        row = self.query_one("SELECT value FROM meta WHERE key = ?", (key,))
        return row["value"] if row else None

    def set_meta(self, key: str, value: str) -> None:
        self.execute(
            "INSERT INTO meta(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )

    def close(self) -> None:
        with self._lock:
            try:
                if self.path != ":memory:":
                    self._conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except sqlite3.Error:
                pass
            self._conn.close()


def _split_sql(script: str) -> list[str]:
    """Split a migration into statements (no triggers with embedded semicolons are used)."""
    statements: list[str] = []
    current: list[str] = []
    for line in script.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("--"):
            continue
        current.append(line)
        if stripped.endswith(";"):
            statements.append("\n".join(current))
            current = []
    if current:
        statements.append("\n".join(current))
    return statements
