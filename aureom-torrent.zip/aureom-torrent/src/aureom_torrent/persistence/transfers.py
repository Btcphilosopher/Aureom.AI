"""Persistence for transfer records, their activity log, resume data and stored .torrent files."""

from __future__ import annotations

import json
import logging
import os
import re
import sqlite3
from pathlib import Path

from ..domain.identity import TorrentIdentity
from ..domain.transfers import TransferRecord, TransferState
from ..filesystem.paths import atomic_write
from .database import Database

log = logging.getLogger(__name__)

MAX_EVENTS_PER_TRANSFER = 300
_ID = re.compile(r"^[0-9a-f]{32}$")

_COLUMNS = ("id, v1, v2, name, save_path, category, added_at, completed_at, source, magnet_uri, has_metadata, "
            "preview, manual_paused, stopped_by_limit, download_limit, upload_limit, ratio_limit_permille, "
            "seed_time_limit_s, file_priorities, total_size, private, last_state, last_progress_ppm, "
            "downloaded_total, uploaded_total, seeding_seconds, last_error, last_announce, manifest_id, feed_entry_id")


def _row_to_record(row: sqlite3.Row) -> TransferRecord:
    try:
        priorities = [int(p) for p in json.loads(row["file_priorities"] or "[]")]
    except (ValueError, TypeError):
        priorities = []
    try:
        announce = json.loads(row["last_announce"] or "{}")
        if not isinstance(announce, dict):
            announce = {}
    except ValueError:
        announce = {}
    try:
        state = TransferState(row["last_state"])
    except ValueError:
        state = TransferState.ADDED
    return TransferRecord(
        id=row["id"], identity=TorrentIdentity(row["v1"], row["v2"]), name=row["name"],
        save_path=row["save_path"], category=row["category"], added_at=row["added_at"],
        completed_at=row["completed_at"], source=row["source"], magnet_uri=row["magnet_uri"],
        has_metadata=bool(row["has_metadata"]), preview=bool(row["preview"]),
        manual_paused=bool(row["manual_paused"]), stopped_by_limit=bool(row["stopped_by_limit"]),
        download_limit=row["download_limit"], upload_limit=row["upload_limit"],
        ratio_limit_permille=row["ratio_limit_permille"], seed_time_limit_s=row["seed_time_limit_s"],
        file_priorities=priorities, total_size=row["total_size"], private=bool(row["private"]),
        last_state=state, last_progress_ppm=row["last_progress_ppm"],
        downloaded_total=row["downloaded_total"], uploaded_total=row["uploaded_total"],
        seeding_seconds=row["seeding_seconds"], last_error=row["last_error"], last_announce=announce,
        manifest_id=row["manifest_id"], feed_entry_id=row["feed_entry_id"],
    )


def _record_values(r: TransferRecord) -> tuple:
    return (r.id, r.identity.v1, r.identity.v2, r.name, r.save_path, r.category, r.added_at, r.completed_at,
            r.source, r.magnet_uri, int(r.has_metadata), int(r.preview), int(r.manual_paused),
            int(r.stopped_by_limit), r.download_limit, r.upload_limit, r.ratio_limit_permille,
            r.seed_time_limit_s, json.dumps(r.file_priorities), r.total_size, int(r.private),
            r.last_state.value, r.last_progress_ppm, r.downloaded_total, r.uploaded_total, r.seeding_seconds,
            r.last_error, json.dumps(r.last_announce), r.manifest_id, r.feed_entry_id)


class TransferRepository:
    def __init__(self, db: Database):
        self._db = db

    def list(self) -> list[TransferRecord]:
        records = []
        for row in self._db.query(f"SELECT {_COLUMNS} FROM transfers ORDER BY added_at, id"):
            try:
                records.append(_row_to_record(row))
            except Exception as exc:  # one damaged row must not hide the others
                log.error("skipping unreadable transfer row %s: %s", row["id"], exc)
        return records

    def save(self, record: TransferRecord) -> None:
        placeholders = ",".join("?" * 30)
        self._db.execute(f"INSERT OR REPLACE INTO transfers ({_COLUMNS}) VALUES ({placeholders})",
                         _record_values(record))

    def delete(self, transfer_id: str) -> None:
        with self._db.tx() as conn:
            conn.execute("DELETE FROM transfers WHERE id = ?", (transfer_id,))
            conn.execute("DELETE FROM transfer_events WHERE transfer_id = ?", (transfer_id,))

    def add_event(self, transfer_id: str, ts: int, level: str, kind: str, message: str) -> None:
        with self._db.tx() as conn:
            conn.execute("INSERT INTO transfer_events(transfer_id, ts, level, kind, message) VALUES (?,?,?,?,?)",
                         (transfer_id, ts, level, kind, message[:1000]))
            conn.execute(
                "DELETE FROM transfer_events WHERE transfer_id = ? AND id <= ("
                " SELECT id FROM transfer_events WHERE transfer_id = ? ORDER BY id DESC LIMIT 1 OFFSET ?)",
                (transfer_id, transfer_id, MAX_EVENTS_PER_TRANSFER))

    def events(self, transfer_id: str, limit: int = 200) -> list[tuple[int, str, str, str]]:
        rows = self._db.query(
            "SELECT ts, level, kind, message FROM transfer_events WHERE transfer_id = ? ORDER BY id DESC LIMIT ?",
            (transfer_id, limit))
        return [(r["ts"], r["level"], r["kind"], r["message"]) for r in rows]


class ResumeStore:
    """Files owned by the application: ``<id>.fastresume`` and ``<id>.torrent``.

    Writes are atomic (temp file + fsync + rename), so an interrupted write
    leaves the previous version intact.
    """

    def __init__(self, resume_dir: Path, torrents_dir: Path):
        self.resume_dir = resume_dir
        self.torrents_dir = torrents_dir
        resume_dir.mkdir(parents=True, exist_ok=True)
        torrents_dir.mkdir(parents=True, exist_ok=True)
        self._sweep_temp_files()

    def _sweep_temp_files(self) -> None:
        for directory in (self.resume_dir, self.torrents_dir):
            for leftover in directory.glob("*.tmp"):
                try:
                    leftover.unlink()
                except OSError:
                    pass

    @staticmethod
    def _check(transfer_id: str) -> str:
        if not _ID.match(transfer_id):
            raise ValueError("invalid transfer id")
        return transfer_id

    def resume_path(self, transfer_id: str) -> Path:
        return self.resume_dir / f"{self._check(transfer_id)}.fastresume"

    def torrent_path(self, transfer_id: str) -> Path:
        return self.torrents_dir / f"{self._check(transfer_id)}.torrent"

    def save_resume(self, transfer_id: str, data: bytes) -> None:
        atomic_write(self.resume_path(transfer_id), data)

    def load_resume(self, transfer_id: str) -> bytes | None:
        return self._read(self.resume_path(transfer_id))

    def save_torrent(self, transfer_id: str, data: bytes) -> None:
        atomic_write(self.torrent_path(transfer_id), data)

    def load_torrent(self, transfer_id: str) -> bytes | None:
        return self._read(self.torrent_path(transfer_id))

    def delete(self, transfer_id: str) -> None:
        for path in (self.resume_path(transfer_id), self.torrent_path(transfer_id)):
            try:
                os.unlink(path)
            except FileNotFoundError:
                pass
            except OSError as exc:
                log.warning("could not remove %s: %s", path.name, exc)

    @staticmethod
    def _read(path: Path) -> bytes | None:
        try:
            data = path.read_bytes()
        except FileNotFoundError:
            return None
        except OSError as exc:
            log.warning("could not read %s: %s", path.name, exc)
            return None
        return data or None
