-- Publishing: torrent-creation jobs, publishing destinations, publisher manifests, pinned keys.
-- Destination credentials (upload tokens) and the manifest signing key are never stored here.

CREATE TABLE publish_jobs (
    id           TEXT PRIMARY KEY,
    created_at   INTEGER NOT NULL,
    updated_at   INTEGER NOT NULL,
    state        TEXT NOT NULL,
    source_path  TEXT NOT NULL,
    torrent_path TEXT NOT NULL DEFAULT '',
    name         TEXT NOT NULL DEFAULT '',
    format       TEXT NOT NULL DEFAULT 'hybrid',
    total_size   INTEGER NOT NULL DEFAULT 0,
    file_count   INTEGER NOT NULL DEFAULT 0,
    piece_length INTEGER NOT NULL DEFAULT 0,
    private      INTEGER NOT NULL DEFAULT 0,
    v1           TEXT,
    v2           TEXT,
    magnet       TEXT NOT NULL DEFAULT '',
    transfer_id  TEXT,
    manifest_id  TEXT,
    error        TEXT NOT NULL DEFAULT '',
    options      TEXT NOT NULL DEFAULT '{}',
    operations   TEXT NOT NULL DEFAULT '[]'
);

CREATE INDEX idx_publish_jobs_created ON publish_jobs(created_at);

CREATE TABLE publish_destinations (
    id         TEXT PRIMARY KEY,
    kind       TEXT NOT NULL,
    name       TEXT NOT NULL,
    config     TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL
);

CREATE TABLE manifests (
    id               TEXT PRIMARY KEY,
    transfer_id      TEXT,
    v1               TEXT,
    v2               TEXT,
    provenance       TEXT NOT NULL,
    signature_status TEXT NOT NULL,
    json             TEXT NOT NULL,
    created_at       INTEGER NOT NULL
);

CREATE INDEX idx_manifests_v1 ON manifests(v1);
CREATE INDEX idx_manifests_v2 ON manifests(v2);
CREATE INDEX idx_manifests_transfer ON manifests(transfer_id);

CREATE TABLE pinned_publisher_keys (
    public_key TEXT PRIMARY KEY,
    label      TEXT NOT NULL DEFAULT '',
    added_at   INTEGER NOT NULL
);
