-- RSS/Atom subscriptions, entries, de-duplication history, automation rules and their logs.

CREATE TABLE feeds (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    url               TEXT NOT NULL UNIQUE,
    title             TEXT NOT NULL DEFAULT '',
    site_url          TEXT NOT NULL DEFAULT '',
    folder            TEXT NOT NULL DEFAULT '',
    category          TEXT NOT NULL DEFAULT '',
    interval_minutes  INTEGER NOT NULL DEFAULT 60,
    auto_download     INTEGER NOT NULL DEFAULT 0,
    download_existing INTEGER NOT NULL DEFAULT 0,
    baseline_done     INTEGER NOT NULL DEFAULT 0,
    etag              TEXT NOT NULL DEFAULT '',
    last_modified     TEXT NOT NULL DEFAULT '',
    created_at        INTEGER NOT NULL,
    last_checked      INTEGER,
    last_success      INTEGER,
    next_check        INTEGER NOT NULL DEFAULT 0,
    fail_count        INTEGER NOT NULL DEFAULT 0,
    last_status       TEXT NOT NULL DEFAULT 'never',
    last_error        TEXT NOT NULL DEFAULT ''
);

CREATE INDEX idx_feeds_next_check ON feeds(next_check);

CREATE TABLE feed_entries (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    feed_id       INTEGER NOT NULL REFERENCES feeds(id) ON DELETE CASCADE,
    guid          TEXT NOT NULL DEFAULT '',
    link          TEXT NOT NULL DEFAULT '',
    title         TEXT NOT NULL DEFAULT '',
    publisher     TEXT NOT NULL DEFAULT '',
    published     INTEGER,
    summary_html  TEXT NOT NULL DEFAULT '',
    summary_text  TEXT NOT NULL DEFAULT '',
    link_type     TEXT NOT NULL DEFAULT 'none',
    torrent_url   TEXT NOT NULL DEFAULT '',
    magnet        TEXT NOT NULL DEFAULT '',
    v1            TEXT,
    v2            TEXT,
    size          INTEGER,
    size_trusted  INTEGER NOT NULL DEFAULT 0,
    is_read       INTEGER NOT NULL DEFAULT 0,
    status        TEXT NOT NULL DEFAULT 'new',
    status_reason TEXT NOT NULL DEFAULT '',
    transfer_id   TEXT,
    rule_id       INTEGER,
    first_seen    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL
);

CREATE INDEX idx_feed_entries_feed ON feed_entries(feed_id, published);
CREATE INDEX idx_feed_entries_status ON feed_entries(status);

-- De-duplication history. Rows outlive the entries they describe (entries are pruned,
-- history is not), so an item that was already handled is never treated as new again.
-- Feed-scoped keys (GUID, link, title hash) carry feed_id; global keys (enclosure URL,
-- torrent identity) have feed_id NULL.
CREATE TABLE feed_seen (
    key         TEXT PRIMARY KEY,
    feed_id     INTEGER,
    entry_id    INTEGER,
    first_seen  INTEGER NOT NULL,
    last_seen   INTEGER NOT NULL,
    outcome     TEXT NOT NULL DEFAULT 'seen',
    transfer_id TEXT
);

CREATE INDEX idx_feed_seen_feed ON feed_seen(feed_id);
CREATE INDEX idx_feed_seen_entry ON feed_seen(entry_id);

CREATE TABLE feed_rules (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    feed_id            INTEGER NOT NULL REFERENCES feeds(id) ON DELETE CASCADE,
    name               TEXT NOT NULL DEFAULT '',
    enabled            INTEGER NOT NULL DEFAULT 1,
    include_terms      TEXT NOT NULL DEFAULT '[]',
    exclude_terms      TEXT NOT NULL DEFAULT '[]',
    regex              TEXT NOT NULL DEFAULT '',
    category           TEXT NOT NULL DEFAULT '',
    destination        TEXT NOT NULL DEFAULT '',
    min_size           INTEGER,
    max_size           INTEGER,
    max_per_refresh    INTEGER NOT NULL DEFAULT 3,
    daily_count_budget INTEGER NOT NULL DEFAULT 10,
    daily_bytes_budget INTEGER NOT NULL DEFAULT 0,
    add_paused         INTEGER NOT NULL DEFAULT 0,
    created_at         INTEGER NOT NULL
);

CREATE INDEX idx_feed_rules_feed ON feed_rules(feed_id);

CREATE TABLE feed_rule_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          INTEGER NOT NULL,
    feed_id     INTEGER NOT NULL,
    rule_id     INTEGER,
    entry_id    INTEGER,
    entry_title TEXT NOT NULL DEFAULT '',
    action      TEXT NOT NULL,
    reason      TEXT NOT NULL DEFAULT ''
);

CREATE TABLE feed_budget (
    day         TEXT NOT NULL,
    rule_id     INTEGER NOT NULL,
    added_count INTEGER NOT NULL DEFAULT 0,
    added_bytes INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (day, rule_id)
);
