-- Payment intents and their state-change history.
-- Never stored here: backend credentials, payment preimages, seed phrases or private keys.
-- The BOLT11 string of an outgoing payment is cleared once the payment reaches a terminal state.

CREATE TABLE payments (
    id              TEXT PRIMARY KEY,
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL,
    direction       TEXT NOT NULL,
    kind            TEXT NOT NULL,
    state           TEXT NOT NULL,
    network         TEXT NOT NULL,
    amount_msat     INTEGER,
    fee_limit_msat  INTEGER,
    fee_paid_msat   INTEGER,
    backend         TEXT NOT NULL DEFAULT '',
    payment_hash    TEXT,
    destination     TEXT NOT NULL DEFAULT '',
    description     TEXT NOT NULL DEFAULT '',
    invoice         TEXT,
    expires_at      INTEGER,
    publisher_name  TEXT NOT NULL DEFAULT '',
    publisher_trust TEXT NOT NULL DEFAULT 'unknown',
    transfer_id     TEXT,
    manifest_id     TEXT,
    note            TEXT NOT NULL DEFAULT '',
    error           TEXT NOT NULL DEFAULT '',
    submitted_at    INTEGER,
    settled_at      INTEGER
);

CREATE INDEX idx_payments_hash ON payments(payment_hash);
CREATE INDEX idx_payments_state ON payments(state);
CREATE INDEX idx_payments_transfer ON payments(transfer_id);
CREATE INDEX idx_payments_created ON payments(created_at);

CREATE TABLE payment_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    payment_id TEXT NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
    ts         INTEGER NOT NULL,
    from_state TEXT,
    to_state   TEXT NOT NULL,
    detail     TEXT NOT NULL DEFAULT ''
);

CREATE INDEX idx_payment_events_payment ON payment_events(payment_id, id);
