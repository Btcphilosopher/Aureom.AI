-- Core schema: settings, application metadata, transfers and their activity log.
-- Secrets (proxy passwords, backend credentials) are never stored here.

CREATE TABLE settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE TABLE meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE transfers (
    id                   TEXT PRIMARY KEY,
    v1                   TEXT,
    v2                   TEXT,
    name                 TEXT NOT NULL,
    save_path            TEXT NOT NULL,
    category             TEXT NOT NULL DEFAULT '',
    added_at             INTEGER NOT NULL,
    completed_at         INTEGER,
    source               TEXT NOT NULL DEFAULT 'file',
    magnet_uri           TEXT,
    has_metadata         INTEGER NOT NULL DEFAULT 0,
    preview              INTEGER NOT NULL DEFAULT 0,
    manual_paused        INTEGER NOT NULL DEFAULT 0,
    stopped_by_limit     INTEGER NOT NULL DEFAULT 0,
    download_limit       INTEGER NOT NULL DEFAULT 0,
    upload_limit         INTEGER NOT NULL DEFAULT 0,
    ratio_limit_permille INTEGER,
    seed_time_limit_s    INTEGER,
    file_priorities      TEXT NOT NULL DEFAULT '[]',
    total_size           INTEGER NOT NULL DEFAULT 0,
    private              INTEGER NOT NULL DEFAULT 0,
    last_state           TEXT NOT NULL DEFAULT 'added',
    last_progress_ppm    INTEGER NOT NULL DEFAULT 0,
    downloaded_total     INTEGER NOT NULL DEFAULT 0,
    uploaded_total       INTEGER NOT NULL DEFAULT 0,
    seeding_seconds      INTEGER NOT NULL DEFAULT 0,
    last_error           TEXT NOT NULL DEFAULT '',
    last_announce        TEXT NOT NULL DEFAULT '{}',
    manifest_id          TEXT,
    feed_entry_id        INTEGER
);

CREATE INDEX idx_transfers_v1 ON transfers(v1);
CREATE INDEX idx_transfers_v2 ON transfers(v2);

CREATE TABLE transfer_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    transfer_id TEXT NOT NULL,
    ts          INTEGER NOT NULL,
    level       TEXT NOT NULL,
    kind        TEXT NOT NULL,
    message     TEXT NOT NULL
);

CREATE INDEX idx_transfer_events_transfer ON transfer_events(transfer_id, id);
