"""Bounded, policy-checked HTTP fetching shared by RSS, publishing and LNURL code.

Every request goes through :func:`fetch` (or :class:`HttpFetcher`), which enforces:

* allowed schemes (https, and http only when the policy permits it);
* destination checks: loopback / private / link-local addresses are refused
  unless the policy explicitly allows them;
* manual redirect handling with the same checks applied to every hop and a hop limit;
* a hard response-size cap, enforced while streaming (Content-Length is not trusted);
* connect/read timeouts;
* an explicit proxy: when a proxy is configured every request uses it, and a
  proxy failure is an error – there is no silent direct fallback.

Limitation (documented in docs/privacy.md): destination checks resolve the host
name before connecting, so they do not defend against a DNS answer that changes
between the check and the connection; and when a proxy is configured the proxy
resolves names, so only literal IP addresses can be checked locally.
"""

from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass, field
from typing import Mapping, Protocol
from urllib.parse import urljoin, urlsplit

import httpx

USER_AGENT = "AureomTorrent/0.1"


class HttpFetchError(Exception):
    """Base class; ``str(exc)`` is safe to show to the user and never contains the query string."""


class BlockedDestination(HttpFetchError):
    pass


class ResponseTooLarge(HttpFetchError):
    pass


class FetchTimeout(HttpFetchError):
    pass


class TooManyRedirects(HttpFetchError):
    pass


class TransportFailure(HttpFetchError):
    pass


@dataclass(frozen=True, slots=True)
class HttpPolicy:
    timeout_s: float = 20.0
    max_bytes: int = 4 * 1024 * 1024
    max_redirects: int = 5
    allow_http: bool = True
    allow_loopback: bool = False
    allow_private: bool = False
    proxy_url: str = ""

    @classmethod
    def from_settings(cls, net) -> "HttpPolicy":
        """Build from a ``settings.models.HttpServiceNetwork``."""
        return cls(timeout_s=float(net.timeout_s), max_bytes=int(net.max_response_bytes),
                   max_redirects=int(net.max_redirects), allow_http=bool(net.allow_http),
                   allow_loopback=bool(net.allow_loopback), allow_private=bool(net.allow_private),
                   proxy_url=str(net.proxy_url or ""))


@dataclass(frozen=True, slots=True)
class HttpResult:
    status: int
    headers: Mapping[str, str]  # lower-cased names
    body: bytes
    url: str  # final URL after redirects
    redirects: tuple[str, ...] = field(default=())
    redirect_statuses: tuple[int, ...] = field(default=())  # status code of each hop, same order

    def header(self, name: str) -> str | None:
        return self.headers.get(name.lower())


class Fetcher(Protocol):
    def fetch(self, url: str, *, method: str = "GET", headers: Mapping[str, str] | None = None,
              body: bytes | None = None, policy: HttpPolicy | None = None) -> HttpResult: ...


def safe_url_for_display(url: str) -> str:
    """Scheme, host and path only: queries and credentials can carry secrets."""
    try:
        p = urlsplit(url)
        host = p.hostname or ""
        if p.port:
            host = f"{host}:{p.port}"
        return f"{p.scheme}://{host}{p.path}"
    except ValueError:
        return "<invalid url>"


def check_url(url: str, policy: HttpPolicy, *, resolver=socket.getaddrinfo) -> None:
    """Raise :class:`BlockedDestination` when the URL may not be contacted under ``policy``."""
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError as exc:
        raise BlockedDestination("The address is not a valid URL.") from exc
    scheme = parts.scheme.lower()
    if scheme not in ("http", "https"):
        raise BlockedDestination(f"Only http and https addresses are supported (got “{scheme or 'none'}”).")
    if scheme == "http" and not policy.allow_http:
        raise BlockedDestination("This service requires an https address.")
    if parts.username or parts.password:
        raise BlockedDestination("Addresses with embedded user names or passwords are not accepted.")
    host = parts.hostname
    if not host:
        raise BlockedDestination("The address has no host name.")
    literal: ipaddress._BaseAddress | None
    try:
        literal = ipaddress.ip_address(host)
    except ValueError:
        literal = None
    if literal is not None:
        _check_ip(literal, policy, host)
        return
    if host.lower() in ("localhost",) or host.lower().endswith(".localhost"):
        if not policy.allow_loopback:
            raise BlockedDestination("Connections to this computer (localhost) are not allowed for this service.")
        return
    if policy.proxy_url:
        return  # the proxy resolves the name; see module docstring
    try:
        infos = resolver(host, port or (443 if scheme == "https" else 80), type=socket.SOCK_STREAM)
    except OSError as exc:
        raise TransportFailure(f"Could not resolve “{host}”.") from exc
    for info in infos:
        _check_ip(ipaddress.ip_address(info[4][0].split("%")[0]), policy, host)


def _check_ip(ip, policy: HttpPolicy, host: str) -> None:
    if getattr(ip, "ipv4_mapped", None):
        ip = ip.ipv4_mapped
    if ip.is_loopback:
        if not policy.allow_loopback:
            raise BlockedDestination(f"“{host}” is a loopback address, which is not allowed for this service.")
        return
    if ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved:
        raise BlockedDestination(f"“{host}” is not a routable address.")
    if ip.is_private and not policy.allow_private:
        raise BlockedDestination(f"“{host}” is a private-network address, which is not allowed for this service.")


class HttpFetcher:
    """httpx-based implementation. One instance may be shared between threads."""

    def __init__(self, policy: HttpPolicy, *, resolver=socket.getaddrinfo,
                 transport: httpx.BaseTransport | None = None):
        self.policy = policy
        self._resolver = resolver
        self._transport = transport

    def _client(self, policy: HttpPolicy) -> httpx.Client:
        kwargs: dict = dict(
            timeout=httpx.Timeout(policy.timeout_s, connect=min(policy.timeout_s, 15.0)),
            follow_redirects=False,
            trust_env=False,  # never pick up proxies from the environment behind the user's back
            headers={"User-Agent": USER_AGENT, "Accept-Encoding": "gzip, deflate"},
        )
        if self._transport is not None:
            kwargs["transport"] = self._transport
        elif policy.proxy_url:
            kwargs["proxy"] = policy.proxy_url
        return httpx.Client(**kwargs)

    def fetch(self, url: str, *, method: str = "GET", headers: Mapping[str, str] | None = None,
              body: bytes | None = None, policy: HttpPolicy | None = None) -> HttpResult:
        policy = policy or self.policy
        hops: list[str] = []
        hop_statuses: list[int] = []
        current = url
        with self._client(policy) as client:
            while True:
                check_url(current, policy, resolver=self._resolver)
                try:
                    with client.stream(method, current, headers=dict(headers or {}), content=body) as resp:
                        if resp.status_code in (301, 302, 303, 307, 308) and "location" in resp.headers:
                            if method not in ("GET", "HEAD"):
                                raise TooManyRedirects("The server redirected an upload; redirects are not followed for uploads.")
                            if len(hops) >= policy.max_redirects:
                                raise TooManyRedirects(f"Too many redirects (limit {policy.max_redirects}).")
                            nxt = urljoin(current, resp.headers["location"])
                            if urlsplit(current).scheme == "https" and urlsplit(nxt).scheme == "http":
                                raise BlockedDestination("Refusing a redirect from https to http.")
                            hops.append(current)
                            hop_statuses.append(resp.status_code)
                            current = nxt
                            continue
                        declared = resp.headers.get("content-length")
                        if declared and declared.isdigit() and int(declared) > policy.max_bytes:
                            raise ResponseTooLarge(
                                f"The response is larger than the {policy.max_bytes:,}-byte limit.")
                        chunks: list[bytes] = []
                        size = 0
                        for chunk in resp.iter_bytes():
                            size += len(chunk)
                            if size > policy.max_bytes:
                                raise ResponseTooLarge(
                                    f"The response is larger than the {policy.max_bytes:,}-byte limit.")
                            chunks.append(chunk)
                        return HttpResult(
                            status=resp.status_code,
                            headers={k.lower(): v for k, v in resp.headers.items()},
                            body=b"".join(chunks),
                            url=current,
                            redirects=tuple(hops),
                            redirect_statuses=tuple(hop_statuses),
                        )
                except httpx.TimeoutException as exc:
                    raise FetchTimeout(f"Timed out contacting {safe_url_for_display(current)}.") from exc
                except httpx.ProxyError as exc:
                    raise TransportFailure("The configured proxy refused or failed the connection "
                                           "(no direct connection was attempted).") from exc
                except httpx.HTTPError as exc:
                    raise TransportFailure(
                        f"Could not contact {safe_url_for_display(current)}: {type(exc).__name__}.") from exc
