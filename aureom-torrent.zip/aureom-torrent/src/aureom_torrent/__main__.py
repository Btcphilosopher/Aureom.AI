"""Entry point: ``python -m aureom_torrent [--data-dir DIR] [file.torrent | magnet:?… …]``."""

from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="aureom-torrent", description="AUREOM TORRENT desktop client")
    parser.add_argument("items", nargs="*", help=".torrent files or magnet links to add")
    parser.add_argument("--data-dir", help="application data directory (default: per-user location)")
    parser.add_argument("--local-demo", action="store_true",
                        help="DEMO MODE: loopback-only networking (no DHT, trackers still work); "
                             "for the local demonstrations in README.md")
    parser.add_argument("--log-to-console", action="store_true")
    parser.add_argument("--self-check", action="store_true",
                        help="start the engine and the window, run for two seconds, shut down and print a "
                             "JSON report (used to verify an installation or a packaged build)")
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)

    from PySide6.QtWidgets import QApplication

    from .app import AppContext
    from .ui.main_window import MainWindow

    app = QApplication(sys.argv[:1])
    app.setApplicationName("AUREOM TORRENT")
    app.setOrganizationName("Aureom")
    ctx = AppContext(args.data_dir, isolated=args.local_demo, console_log=args.log_to_console)
    ctx.start()
    window = MainWindow(ctx)
    if args.local_demo:
        window.setWindowTitle("AUREOM TORRENT — local demo mode (loopback only)")
    window.show()
    if args.self_check:
        return _self_check(app, ctx, window)
    if args.items:
        window.open_arguments(args.items)
    return app.exec()


def _self_check(app, ctx, window) -> int:
    """Exercise start-up and shutdown of the real application and report what was found."""
    import json
    import time

    from PySide6.QtCore import QTimer

    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.02)
    _, views, session = ctx.transfers.snapshot()
    capabilities = ctx.engine.capabilities()
    report = {
        "engine": f"{capabilities.engine} {capabilities.version}",
        "engine_running": session.engine_running, "listening": session.listening,
        "schema_version": ctx.db.schema_version(), "transfers": len(views),
        "pages": window.stack.count(), "credential_store": ctx.secrets.description,
        "payment_backend": ctx.payments.backend_status().message,
    }
    window.close()
    QTimer.singleShot(8000, app.quit)
    end = time.monotonic() + 10.0
    while not window._shutdown_done and time.monotonic() < end:
        app.processEvents()
        time.sleep(0.02)
    shutdown = ctx.transfers.shutdown_report
    report["clean_shutdown"] = bool(shutdown and shutdown.clean)
    ok = report["engine_running"] and report["listening"] and report["clean_shutdown"] and report["pages"] == 5
    report["ok"] = bool(ok)
    print(json.dumps(report, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
