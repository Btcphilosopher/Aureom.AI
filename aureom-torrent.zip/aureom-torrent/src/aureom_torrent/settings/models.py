"""Typed application settings.

Network configuration is represented separately for BitTorrent, RSS, publishing
and payment backends: a proxy configured for one is never silently applied to,
or bypassed by, another.  Secrets (proxy passwords, LND macaroon) are *not*
part of these models; they live in the OS credential store (``settings.secrets``).
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, get_args, get_origin, get_type_hints

MAX_SCHEDULES = 16


@dataclass(slots=True)
class TorrentProxy:
    kind: str = "none"  # none | socks5 | socks5_pw | http | http_pw
    host: str = ""
    port: int = 0
    username: str = ""  # password: secret "bt-proxy-password"
    proxy_peers: bool = True
    proxy_trackers: bool = True
    proxy_hostnames: bool = True

    def validate(self) -> None:
        if self.kind not in ("none", "socks5", "socks5_pw", "http", "http_pw"):
            self.kind = "none"
        self.port = _clamp(self.port, 0, 65535)


@dataclass(slots=True)
class BitTorrentNetwork:
    listen_port: int = 6881
    listen_address: str = ""  # empty = all IPv4 + IPv6 addresses
    bind_interface: str = ""  # optional device name or address to bind listening + outgoing sockets
    enable_dht: bool = True
    enable_pex: bool = True  # applied when the engine starts
    enable_lsd: bool = True
    enable_upnp: bool = True
    enable_natpmp: bool = True
    encryption: str = "enabled"  # enabled | forced | disabled
    max_connections: int = 300
    proxy: TorrentProxy = field(default_factory=TorrentProxy)

    def validate(self) -> None:
        self.listen_port = _clamp(self.listen_port, 0, 65535)
        if self.encryption not in ("enabled", "forced", "disabled"):
            self.encryption = "enabled"
        self.max_connections = _clamp(self.max_connections, 2, 10_000)
        self.proxy.validate()


@dataclass(slots=True)
class HttpServiceNetwork:
    """HTTP behaviour for one non-BitTorrent service (RSS, publishing or payments)."""

    proxy_url: str = ""  # "" = direct connection; e.g. socks5://127.0.0.1:9050 or http://proxy:3128
    timeout_s: int = 20
    max_response_bytes: int = 4 * 1024 * 1024
    max_redirects: int = 5
    allow_loopback: bool = False
    allow_private: bool = False
    allow_http: bool = True

    def validate(self) -> None:
        self.timeout_s = _clamp(self.timeout_s, 2, 300)
        self.max_response_bytes = _clamp(self.max_response_bytes, 1024, 64 * 1024 * 1024)
        self.max_redirects = _clamp(self.max_redirects, 0, 10)
        if self.proxy_url and self.proxy_url.split("://")[0].lower() not in ("http", "https", "socks5", "socks5h"):
            self.proxy_url = ""


@dataclass(slots=True)
class BandwidthSchedule:
    name: str = ""
    enabled: bool = True
    days: list[int] = field(default_factory=lambda: [0, 1, 2, 3, 4, 5, 6])  # Monday = 0
    start_minute: int = 0  # minutes after local midnight
    end_minute: int = 0  # may be < start (wraps past midnight)
    download_limit: int = 0  # bytes/s, 0 = unlimited
    upload_limit: int = 0
    pause_all: bool = False

    def validate(self) -> None:
        self.days = sorted({d for d in self.days if isinstance(d, int) and 0 <= d <= 6})
        self.start_minute = _clamp(self.start_minute, 0, 1439)
        self.end_minute = _clamp(self.end_minute, 0, 1439)
        self.download_limit = max(0, self.download_limit)
        self.upload_limit = max(0, self.upload_limit)


@dataclass(slots=True)
class QueueSettings:
    max_active_downloads: int = 3
    max_active_seeds: int = 5
    max_active_total: int = 8
    download_limit: int = 0  # global, bytes/s, 0 = unlimited
    upload_limit: int = 0
    ratio_limit_permille: int = -1  # -1 = seed without a ratio limit
    seed_time_limit_minutes: int = -1  # -1 = no time limit
    schedules: list[BandwidthSchedule] = field(default_factory=list)

    def validate(self) -> None:
        self.max_active_downloads = _clamp(self.max_active_downloads, -1, 1000)
        self.max_active_seeds = _clamp(self.max_active_seeds, -1, 1000)
        self.max_active_total = _clamp(self.max_active_total, -1, 2000)
        self.download_limit = max(0, self.download_limit)
        self.upload_limit = max(0, self.upload_limit)
        self.ratio_limit_permille = max(-1, self.ratio_limit_permille)
        self.seed_time_limit_minutes = max(-1, self.seed_time_limit_minutes)
        self.schedules = self.schedules[:MAX_SCHEDULES]
        for s in self.schedules:
            s.validate()


@dataclass(slots=True)
class PaymentSettings:
    backend: str = "none"  # none | lnd_rest
    lnd_url: str = ""  # e.g. https://127.0.0.1:8080 ; macaroon lives in the credential store
    lnd_tls_cert_path: str = ""  # PEM file for a self-signed node certificate
    expected_network: str = "mainnet"  # mainnet | testnet | signet | regtest
    tip_presets_sat: list[int] = field(default_factory=lambda: [21, 100, 500, 1000, 5000])
    min_payment_sat: int = 1
    max_payment_sat: int = 100_000
    max_fee_ppm: int = 10_000  # default fee cap: 1 % of the amount ...
    min_fee_limit_sat: int = 5  # ... but never below this many sats
    invoice_expiry_s: int = 3600
    payment_timeout_s: int = 60

    def validate(self) -> None:
        if self.backend not in ("none", "lnd_rest"):
            self.backend = "none"
        if self.expected_network not in ("mainnet", "testnet", "signet", "regtest"):
            self.expected_network = "mainnet"
        self.tip_presets_sat = [int(v) for v in self.tip_presets_sat if isinstance(v, int) and 0 < v <= 10_000_000][:8]
        self.min_payment_sat = _clamp(self.min_payment_sat, 1, 21_000_000 * 100_000_000)
        self.max_payment_sat = _clamp(self.max_payment_sat, self.min_payment_sat, 21_000_000 * 100_000_000)
        self.max_fee_ppm = _clamp(self.max_fee_ppm, 0, 100_000)
        self.min_fee_limit_sat = _clamp(self.min_fee_limit_sat, 0, 100_000)
        self.invoice_expiry_s = _clamp(self.invoice_expiry_s, 60, 7 * 24 * 3600)
        self.payment_timeout_s = _clamp(self.payment_timeout_s, 10, 600)


@dataclass(slots=True)
class FeedSettings:
    default_interval_minutes: int = 60
    min_interval_minutes: int = 5
    max_entries_per_feed: int = 500
    regex_timeout_ms: int = 100

    def validate(self) -> None:
        self.min_interval_minutes = _clamp(self.min_interval_minutes, 1, 1440)
        self.default_interval_minutes = _clamp(self.default_interval_minutes, self.min_interval_minutes, 10_080)
        self.max_entries_per_feed = _clamp(self.max_entries_per_feed, 20, 5000)
        self.regex_timeout_ms = _clamp(self.regex_timeout_ms, 10, 2000)


@dataclass(slots=True)
class UiSettings:
    theme: str = "light"  # light | dark | system
    density: str = "compact"  # compact | comfortable
    reduced_motion: str = "system"  # system | on | off
    show_brand_line: bool = True
    confirm_remove: bool = True

    def validate(self) -> None:
        if self.theme not in ("light", "dark", "system"):
            self.theme = "light"
        if self.density not in ("compact", "comfortable"):
            self.density = "compact"
        if self.reduced_motion not in ("system", "on", "off"):
            self.reduced_motion = "system"


@dataclass(slots=True)
class GeneralSettings:
    default_save_path: str = ""
    categories: list[str] = field(default_factory=lambda: ["Software", "Documents", "Media"])
    add_paused: bool = False
    preview_magnets: bool = True
    resume_save_interval_s: int = 60
    shutdown_timeout_s: int = 15

    def validate(self) -> None:
        self.categories = [str(c)[:64] for c in self.categories if str(c).strip()][:64]
        self.resume_save_interval_s = _clamp(self.resume_save_interval_s, 10, 3600)
        self.shutdown_timeout_s = _clamp(self.shutdown_timeout_s, 2, 120)


@dataclass(slots=True)
class AppSettings:
    general: GeneralSettings = field(default_factory=GeneralSettings)
    bittorrent: BitTorrentNetwork = field(default_factory=BitTorrentNetwork)
    queue: QueueSettings = field(default_factory=QueueSettings)
    feeds: FeedSettings = field(default_factory=FeedSettings)
    feeds_network: HttpServiceNetwork = field(default_factory=HttpServiceNetwork)
    publishing_network: HttpServiceNetwork = field(
        default_factory=lambda: HttpServiceNetwork(max_response_bytes=1024 * 1024, allow_http=False))
    payments: PaymentSettings = field(default_factory=PaymentSettings)
    payments_network: HttpServiceNetwork = field(
        # A Lightning node is usually on this machine or the LAN, so loopback/private are allowed
        # by default *for the explicitly configured backend URL only*.
        default_factory=lambda: HttpServiceNetwork(max_response_bytes=1024 * 1024, allow_loopback=True,
                                                   allow_private=True, max_redirects=0))
    ui: UiSettings = field(default_factory=UiSettings)

    SECTIONS = ("general", "bittorrent", "queue", "feeds", "feeds_network", "publishing_network",
                "payments", "payments_network", "ui")

    def validate(self) -> None:
        for name in self.SECTIONS:
            getattr(self, name).validate()

    def to_dict(self) -> dict[str, Any]:
        return {name: dataclasses.asdict(getattr(self, name)) for name in self.SECTIONS}


def _clamp(value: Any, lo: int, hi: int) -> int:
    try:
        v = int(value)
    except (TypeError, ValueError):
        return lo
    return max(lo, min(hi, v))


def section_from_dict(cls: type, data: Any) -> tuple[Any, list[str]]:
    """Build a settings section from untrusted stored data.

    Unknown keys are ignored and wrongly typed values fall back to the default,
    each with a warning, so corrupt settings never prevent start-up.
    """
    warnings: list[str] = []
    obj = cls()
    if not isinstance(data, dict):
        return obj, [f"{cls.__name__}: stored value is not an object; using defaults"]
    hints = get_type_hints(cls)
    for f in dataclasses.fields(cls):
        if f.name not in data:
            continue
        raw = data[f.name]
        expected = hints[f.name]
        try:
            setattr(obj, f.name, _coerce(expected, raw))
        except (TypeError, ValueError) as exc:
            warnings.append(f"{cls.__name__}.{f.name}: {exc}; using default")
    obj.validate()
    return obj, warnings


def _coerce(expected: Any, raw: Any) -> Any:
    origin = get_origin(expected)
    if dataclasses.is_dataclass(expected):
        value, warns = section_from_dict(expected, raw)
        if warns and not isinstance(raw, dict):
            raise TypeError(warns[0])
        return value
    if origin is list:
        (inner,) = get_args(expected)
        if not isinstance(raw, list):
            raise TypeError("expected a list")
        return [_coerce(inner, item) for item in raw[:1024]]
    if expected is bool:
        if not isinstance(raw, bool):
            raise TypeError("expected true/false")
        return raw
    if expected is int:
        if isinstance(raw, bool) or not isinstance(raw, int):
            raise TypeError("expected a whole number")
        return raw
    if expected is str:
        if not isinstance(raw, str):
            raise TypeError("expected text")
        return raw[:4096]
    raise TypeError(f"unsupported setting type {expected!r}")
