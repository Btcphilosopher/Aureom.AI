"""Where the application keeps its own files."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

APP_DIR_NAME = "aureom-torrent"


def default_data_dir() -> Path:
    override = os.environ.get("AUREOM_TORRENT_HOME")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
        return base / "AureomTorrent"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "AureomTorrent"
    base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return base / APP_DIR_NAME


def default_download_dir() -> Path:
    xdg = os.environ.get("XDG_DOWNLOAD_DIR")
    return Path(xdg).expanduser() if xdg else Path.home() / "Downloads"


@dataclass(frozen=True, slots=True)
class AppPaths:
    data_dir: Path

    @property
    def database(self) -> Path:
        return self.data_dir / "aureom.sqlite3"

    @property
    def resume_dir(self) -> Path:
        return self.data_dir / "resume"

    @property
    def torrents_dir(self) -> Path:
        return self.data_dir / "torrents"

    @property
    def staging_dir(self) -> Path:
        """Scratch save-path for metadata-only magnet previews. No payload is written here."""
        return self.data_dir / "staging"

    @property
    def logs_dir(self) -> Path:
        return self.data_dir / "logs"

    @property
    def exports_dir(self) -> Path:
        return self.data_dir / "exports"

    def ensure(self) -> None:
        for d in (self.data_dir, self.resume_dir, self.torrents_dir, self.staging_dir,
                  self.logs_dir, self.exports_dir):
            d.mkdir(parents=True, exist_ok=True)
