"""Load and save :class:`AppSettings` in SQLite, one JSON document per section."""

from __future__ import annotations

import dataclasses
import json
import logging
import threading
import time
from typing import Callable

from ..persistence.database import Database
from .models import AppSettings, section_from_dict

log = logging.getLogger(__name__)


class SettingsStore:
    def __init__(self, db: Database):
        self._db = db
        self._lock = threading.RLock()
        self._listeners: list[Callable[[AppSettings], None]] = []
        self.warnings: list[str] = []
        self._settings = self._load()

    def _load(self) -> AppSettings:
        settings = AppSettings()
        hints = {f.name: f.type for f in dataclasses.fields(AppSettings)}
        rows = {r["key"]: r["value"] for r in self._db.query("SELECT key, value FROM settings")}
        for name in AppSettings.SECTIONS:
            raw = rows.get(name)
            if raw is None:
                continue
            cls = type(getattr(settings, name))
            try:
                data = json.loads(raw)
            except (ValueError, RecursionError):
                self.warnings.append(f"settings section “{name}” was unreadable; defaults restored")
                continue
            section, warns = section_from_dict(cls, data)
            self.warnings.extend(warns)
            setattr(settings, name, section)
        del hints
        settings.validate()
        for w in self.warnings:
            log.warning("settings: %s", w)
        return settings

    def get(self) -> AppSettings:
        """The live settings object. Treat as read-only; call :meth:`save` with a modified copy."""
        with self._lock:
            return self._settings

    def snapshot(self) -> AppSettings:
        with self._lock:
            return _deep_copy(self._settings)

    def save(self, settings: AppSettings) -> None:
        settings.validate()
        now = int(time.time())
        data = settings.to_dict()
        with self._lock:
            with self._db.tx() as conn:
                for name, section in data.items():
                    conn.execute(
                        "INSERT INTO settings(key, value, updated_at) VALUES (?,?,?) "
                        "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                        (name, json.dumps(section, sort_keys=True), now),
                    )
            self._settings = _deep_copy(settings)
            listeners = list(self._listeners)
        for fn in listeners:
            try:
                fn(self._settings)
            except Exception:  # a listener must not break saving
                log.exception("settings listener failed")

    def subscribe(self, fn: Callable[[AppSettings], None]) -> None:
        with self._lock:
            self._listeners.append(fn)


def _deep_copy(settings: AppSettings) -> AppSettings:
    out = AppSettings()
    for name, data in settings.to_dict().items():
        section, _ = section_from_dict(type(getattr(out, name)), data)
        setattr(out, name, section)
    return out
