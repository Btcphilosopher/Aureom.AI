"""Credential storage.

Secrets are kept in the operating system's credential store through the
``keyring`` library (Secret Service on Linux, Keychain on macOS, Credential
Manager on Windows).  They are never written to SQLite, logs, diagnostics or
exported pages.

When no OS store is available the application falls back to
:class:`MemorySecretStore`: credentials then last for the current session only
and the UI says so.
"""

from __future__ import annotations

import logging
import threading
from typing import Protocol

log = logging.getLogger(__name__)

SERVICE_NAME = "aureom-torrent"

# Well-known secret names
SECRET_LND_MACAROON = "lnd-macaroon-hex"
SECRET_BT_PROXY_PASSWORD = "bt-proxy-password"
SECRET_MANIFEST_SIGNING_KEY = "manifest-signing-key"


def upload_secret_name(destination_id: str) -> str:
    return f"publish-destination-{destination_id}"


class SecretStore(Protocol):
    persistent: bool
    description: str

    def get(self, name: str) -> str | None: ...
    def set(self, name: str, value: str) -> None: ...
    def delete(self, name: str) -> None: ...


class MemorySecretStore:
    persistent = False
    description = "memory only (not saved; no OS credential store is available)"

    def __init__(self) -> None:
        self._data: dict[str, str] = {}
        self._lock = threading.Lock()

    def get(self, name: str) -> str | None:
        with self._lock:
            return self._data.get(name)

    def set(self, name: str, value: str) -> None:
        with self._lock:
            self._data[name] = value

    def delete(self, name: str) -> None:
        with self._lock:
            self._data.pop(name, None)


class KeyringSecretStore:
    persistent = True

    def __init__(self, backend_name: str):
        self.description = f"operating-system credential store ({backend_name})"

    def get(self, name: str) -> str | None:
        import keyring
        from keyring.errors import KeyringError

        try:
            return keyring.get_password(SERVICE_NAME, name)
        except KeyringError as exc:
            log.warning("credential store read failed: %s", type(exc).__name__)
            return None

    def set(self, name: str, value: str) -> None:
        import keyring

        keyring.set_password(SERVICE_NAME, name, value)

    def delete(self, name: str) -> None:
        import keyring
        from keyring.errors import KeyringError

        try:
            keyring.delete_password(SERVICE_NAME, name)
        except KeyringError:
            pass


def open_secret_store() -> SecretStore:
    """Return the OS credential store when one is usable, else a session-only store."""
    try:
        import keyring
        from keyring.backends import fail, null

        backend = keyring.get_keyring()
        if isinstance(backend, (fail.Keyring, null.Keyring)):
            raise RuntimeError("no usable keyring backend")
        # ChainerBackend with no viable members also fails on use; probe with a harmless read.
        keyring.get_password(SERVICE_NAME, "__probe__")
        return KeyringSecretStore(type(backend).__module__.rsplit(".", 1)[-1])
    except Exception as exc:
        log.warning("no OS credential store available (%s); secrets will not be saved", exc)
        return MemorySecretStore()
