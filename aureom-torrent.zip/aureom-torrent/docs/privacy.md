# Networking and privacy

## What others can see

* **Peers, trackers and DHT nodes see your IP address** and which torrent you take part in. That
  is inherent to BitTorrent.
* **Protocol encryption is not anonymity.** It obscures the peer-to-peer byte stream; it does not
  hide addresses or the fact that BitTorrent is in use.
* **Metadata retrieval contacts peers.** Adding a magnet – including the metadata-only preview –
  announces interest in that torrent before you have decided to download anything.
* **Bitcoin transactions are public.** Amounts, addresses and timing are permanently visible on
  chain. A donation address published in a manifest links every payment made to it.
* **Tipping contacts the publisher's server.** Resolving a Lightning address is an HTTPS request
  to the publisher's domain.

## Four separate network configurations

| Service | Setting | Default | Notes |
|---|---|---|---|
| BitTorrent | Settings → BitTorrent network | direct | engine proxy: SOCKS5 / HTTP, with or without password |
| RSS / Atom | Settings → Service networks → RSS | direct, https and http, public addresses only | also used for `.torrent` enclosures |
| Publishing | Settings → Service networks → Publishing | direct, https only, public addresses only | uploads never follow redirects |
| Payment backend | Settings → Service networks → Payment backend | direct, loopback/private allowed, no redirects | the allowance applies to the configured node URL only; LNURL requests are https + public only |

A proxy configured for one service is never applied to another, and **a configured proxy is never
bypassed**: if it fails, the request fails (`trust_env=False`, so proxy environment variables are
ignored too).

With a BitTorrent proxy configured the application also switches off features that would talk to
the local network directly: local peer discovery, UPnP and NAT-PMP. With an **HTTP** proxy, DHT
and uTP are switched off as well, because an HTTP proxy cannot carry UDP. Whether libtorrent
routes every remaining packet through a SOCKS5 proxy is engine behaviour that was not verified in
this build (no proxy was available in the test environment).

## Destination checks for RSS, publishing and LNURL

`net/http.py` enforces, for every request and every redirect hop: http/https only (https only
where configured), no embedded credentials, no loopback / private / link-local / multicast
addresses unless explicitly allowed, a redirect limit, no https→http downgrade, a streaming
response-size cap, and timeouts.

Known limits:

* The host name is resolved before connecting. A DNS answer that changes between the check and
  the connection (DNS rebinding) is not defended against.
* When a proxy is configured, the proxy resolves host names, so only literal IP addresses can be
  checked locally.

## Binding to a network interface

When an interface (device name or IP address) is set, the engine listens on it; libtorrent 2.1
makes outgoing connections from its listen sockets (the separate `outgoing_interfaces` setting no
longer exists). A watchdog checks every 3 s that the interface still exists; if it disappears,
the session is paused, the status bar and a banner say so, and networking resumes when it returns.

This is a safeguard, **not** a guarantee of isolation:

* device binding relies on the operating system (`SO_BINDTODEVICE` on Linux; address binding
  elsewhere) and its routing rules;
* DNS lookups for tracker host names are made by the system resolver and are not bound;
* RSS, publishing and payment traffic are not bound to the interface;
* up to 3 s can pass between the interface disappearing and the pause.

Tested: the presence probe (`test_interface_presence_probe`). Not tested: behaviour with a real
VPN interface going down, on any platform.

## Secrets

Backend credentials (LND macaroon, proxy password, upload tokens, manifest signing key) are kept
in the operating system's credential store via `keyring`. If none is available they are held in
memory for the session and the application says so. They are never written to SQLite, logs,
diagnostics or exported pages; this is covered by tests. The application never asks for a seed
phrase or private key.

## Diagnostics

Logs are bounded (2 000 entries in memory, 4 × 1 MB on disk). Every record passes a redaction
filter before reaching any handler, and the diagnostic export is redacted again as a whole:
tracker passkeys (query and path forms), all URL query strings and user-info, BOLT11/LNURL
strings, macaroons and other long hex blobs, authorization headers, and values under sensitive
keys. Info-hashes are kept (they are not secrets, and are needed for support).

## Not available

Remote control (Web UI, RPC) does not exist in this release.
