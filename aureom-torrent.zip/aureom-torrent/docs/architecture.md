# Architecture

AUREOM TORRENT is a Python application with a Qt (PySide6) interface on top of the libtorrent
engine. The code is layered so that the engine, the feed fetcher, the payment backend and the
publishing adapters can each be replaced by a fake in tests.

```
ui/            Qt widgets, models, themes            (GUI thread only)
  bridge.py      runs callables on a worker pool, returns results via queued signals
app.py         composition root (dependency injection); no Qt
services/      transfer_service, event_pump, engine_config, interfaces (TransferGateway)
feeds/         client, parser, dedup, rules, opml, repository, service
publishing/    creator, manifests, sharing, repository, service, adapters/
payments/      models, amounts, invoices, bitcoin_uri, lnurl, reconciliation, service, adapters/lnd_rest
engine/        interface (protocols), commands, events, libtorrent_adapter, libtorrent_codec
domain/        identity, magnet, transfers, state, schedule    (pure, no I/O)
persistence/   database (migrations), transfers (records, resume store), migrations/*.sql
filesystem/    path validation, safe resolution, atomic writes, publish scan
net/           policy-checked, bounded HTTP fetching
settings/      typed models, SQLite store, OS credential store, data paths
diagnostics/   redaction, bounded logs, redacted export
```

`migrations/` lives inside the package (`persistence/migrations`) rather than at the repository
root so that it is shipped in wheels and frozen builds.

## Threads

| Thread | Owns | Notes |
|---|---|---|
| GUI | all widgets | never touches disk, database, network or engine |
| `aureom-engine` | the `lt.session` and every libtorrent object | executes commands in order, consumes alerts continuously |
| `aureom-events` | nothing | delivers engine events to services; coalesces status snapshots |
| `aureom-worker-N` (4) | nothing | runs what the GUI asked for (`Bridge.run`) |
| `aureom-scheduler` | nothing | 1 s transfer tick, 30 s feed refresh check, 20 s payment status poll |

### Command / event bridge

* `TorrentEngine.submit(command)` is non-blocking. Commands are immutable dataclasses
  (`engine/commands.py`); the owner thread drains the queue each loop iteration.
* The owner thread waits at most 100 ms for an alert, pops **all** pending alerts, translates them
  to neutral events (`engine/events.py`) and calls the sink. The sink (`EventPump.post`) only
  appends to a queue.
* `StatusBatch` is a snapshot event: consecutive undelivered batches are merged per transfer.
  Every other event is a lifecycle event and is never dropped or reordered.
* The GUI does not receive per-alert signals. Twice a second it asks a worker for
  `TransferService.snapshot()` (an in-memory read model of immutable `TransferView` rows) and
  diffs it into the table model, so update cost does not grow with alert volume. Discrete
  notifications (errors, "metadata ready", "export done") travel as one queued Qt signal.
* Status freshness: after an operation that changes what "finished" means (confirming a magnet
  preview), status snapshots requested before the change are discarded in the adapter, and the
  service drops its cached status. This closes a window in which a just-confirmed magnet could
  have been shown as complete.

## Lifecycle model

`domain/state.py` maps an engine status plus the user's intent to exactly one of: Added,
Retrieving metadata, Queued, Checking existing data, Downloading, Seeding, Paused, Moving storage,
Completed (stopped), Error. The function is pure and table-tested.

Distinct facts are kept distinct in `TransferView`:

| Fact | Source |
|---|---|
| verified progress of selected files | `total_wanted_done / total_wanted`, engine status requested **without** accurate download counters, i.e. hash-passed pieces only |
| selected files complete | engine `is_finished` (and something is selected) |
| entire torrent complete | engine `is_seeding` |
| seeding active | state Seeding (finished, not paused, not queued) |
| stopped | paused and not auto-managed |
| downloaded / uploaded bytes | engine all-time counters |

Progress is capped at 99.9 % until the engine reports completion; a stalled transfer stays
"Downloading (stalled)". Piece granularity: a piece that straddles a selected and a deselected
file is downloaded and counted whole; the deselected part is kept in libtorrent's `.parts` file.

## Persistence

SQLite (WAL) with ordered migrations (`0001_core`, `0002_feeds`, `0003_payments`,
`0004_publishing`), each applied in a transaction and recorded in `schema_migrations`. A database
written by a newer schema is refused; an unreadable database is moved aside and a fresh one
created (files on disk are untouched).

* The database is authoritative for user intent: destination, file selection, manual pause,
  limits, category. At start-up these override whatever the resume data says.
* Resume data and stored `.torrent` files are separate files written atomically (temp file,
  fsync, rename). Leftover temp files from an interrupted write are swept at start-up.
* Resume saves are debounced in the engine thread (changed transfers only, default every 60 s)
  and forced on finish, pause, move, metadata and shutdown.
* A persisted destination changes only on the engine's `storage_moved` event.
* Shutdown is bounded (`general.shutdown_timeout_s`); transfers whose resume data did not arrive
  in time are reported by name and will be re-checked.

Recovery paths with tests: corrupt/missing resume data (re-check), missing destination (paused
with an error instead of silently re-downloading), unreadable stored torrent (fall back to the
magnet), engine version change (noted; engine validates resume data), corrupt settings (per-section
defaults), interrupted publishing (job marked interrupted), unknown payment outcome (reconciled,
never resubmitted).

## Dependency injection

`AppContext(data_dir, engine=…, codec=…, creator=…, secrets=…, clock=…, lightning_backend=…)`.
Tests construct it (or individual services) with `tests/fakes/*`. Fakes live under `tests/` only;
the application never substitutes simulated progress or receipts. The one labelled demo switch is
`--local-demo`, which runs the *real* engine restricted to loopback.

## Boundaries that are enforced by tests

* `feeds/` does not import `payments/` (`test_feed_no_payments.py`): a feed rule cannot reach
  the payment service.
* `publishing/` does not import `payments/`; manifests carry payment endpoints as plain data.
* Payment code contains no floating-point arithmetic (`test_payment_amounts.py`).
* Magnet parsing ignores unknown parameters; nothing in a magnet, feed entry, manifest or torrent
  can start a payment. The only call sites of `approve_and_send` are behind the approval dialog.
