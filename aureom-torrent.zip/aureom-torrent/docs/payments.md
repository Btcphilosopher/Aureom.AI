# Payments: optional publisher support

AUREOM TORRENT can help you support a publisher with Bitcoin or Lightning.
This layer is **optional**. Downloading, seeding, RSS and publishing work with
no wallet and no payment backend configured, and keep working if a configured
backend goes offline.

## What this is — and is not

Provided in this release:

| Workflow | How |
| --- | --- |
| Pay a publisher's Lightning invoice (BOLT11) | Your own LND node, through its REST API |
| Send a one-off Lightning tip to a Lightning address | LNURL-pay fetches one invoice; your LND node pays it |
| Open a Bitcoin payment request in an external wallet | BIP21 `bitcoin:` URI hand-off |
| Receive a tip | An invoice created on your LND node, shown as text/QR |
| Payment history, linked to a publisher and/or torrent | Local SQLite |

These payments are **not native BitTorrent settlement**. They are voluntary
payments that happen next to a transfer. A payment does **not** provide:

- access control (a magnet or .torrent works the same whether or not you paid);
- proof of delivery, or any guarantee that data will be seeded;
- fair exchange or atomic "pay for bytes";
- refunds;
- payment-per-byte enforcement.

Lightning payments can incur routing fees and can take time or fail; nothing
here promises zero fees or instant settlement. On-chain Bitcoin transactions
are public and permanent.

The application never asks for a seed phrase or private key, never signs
transactions and does not contain a wallet or a Lightning node.

## Explicit approval, always

No payment is ever initiated by data: RSS entries and rules, magnet links,
torrent metadata, publisher manifests and `bitcoin:`/`lightning:` URIs cannot
trigger one. The code enforces this structurally — the `feeds` package does not
import `payments` (and vice versa; a unit test checks it) — and procedurally:

1. `prepare_invoice_payment` / `prepare_tip` validate the request and store an
   intent in **Awaiting approval**. Nothing is sent.
2. The approval dialog shows the `ApprovalSummary`: amount, network, recipient
   node key (and whether the backend confirmed the decoding), publisher
   association, invoice description, expiry, the maximum routing fee, and
   whether the publisher identity is **verified**, **self-asserted** or
   **unknown**.
3. Only `approve_and_send`, called from the user's click, submits the payment.

There is no background spending. Tip presets (default 21 / 100 / 500 / 1 000 /
5 000 sats) and per-payment minimum/maximum (default 1 – 100 000 sats) are in
Settings → Payments.

"Verified" means a signed publisher manifest validated against a key *you*
chose to trust. It does not prove that a particular invoice or address belongs
to that publisher.

## Setting up the Lightning backend (LND REST)

One backend is supported: **LND through its REST gateway**. You run the node;
the application is a client.

1. **REST address** — LND's REST listener (default port 8080), e.g.
   `https://127.0.0.1:8080`. `https` is required; plain `http` is accepted only
   for `localhost`/`127.0.0.1`. Redirects are never followed. Loopback and
   private addresses are allowed for this URL because you configured it
   explicitly; that allowance does not extend to anything else.
2. **TLS certificate** — LND uses a self-signed certificate. Point *TLS
   certificate* at the node's `tls.cert` (PEM). Verification is never disabled;
   without a certificate file the system trust store is used.
3. **Macaroon** — bake a least-privilege macaroon instead of using
   `admin.macaroon`:

   ```bash
   lncli bakemacaroon --save_to aureom.macaroon \
       info:read invoices:read invoices:write offchain:read offchain:write
   ```

   ```bash
   xxd -ps -u -c 10000 aureom.macaroon
   ```

   Paste the hex into Settings → Payments. `offchain:write` is what
   `SendPaymentV2` needs and `offchain:read` what `TrackPaymentV2` needs. Leave
   out `offchain:write` for a receive-only setup; never grant `onchain:*`,
   `address:*`, `peers:*` or `macaroon:*`.
4. **Network** — choose mainnet / testnet / signet / regtest. Invoices,
   addresses and the node's own network must all match or the payment is refused.

**Where the macaroon is stored:** in the operating system's credential store
(Secret Service / Keychain / Credential Manager) through `keyring`, under the
service name `aureom-torrent`, key `lnd-macaroon-hex`. If no OS store is
available it is kept in memory for the session only and the UI says so. It is
never written to SQLite, logs, diagnostics or exported publisher pages, and it
is read from the store for each request rather than cached.

The payment-backend network settings (their own proxy, timeout and size
limits) apply to the LND connection and to LNURL requests. It is separate from the BitTorrent,
RSS and publishing proxies; a BitTorrent proxy does **not** cover payment
traffic.

## State machine

```
                 ┌────────────── cancel ──────────────┐
                 │                                     ▼
 DRAFT ──► AWAITING_APPROVAL ──approve──► SUBMITTED   CANCELLED (before submission)
                 │                          │  │  │
     invoice expired                        │  │  └────────────► FAILED     (definitive)
     before approval                        │  └──► PENDING ───► SUCCEEDED / FAILED
                 ▼                          ▼          │
              EXPIRED                    UNKNOWN ◄─────┘   (no definitive answer)
                                            │
                              reconciliation only (read-only)
                                            ▼
                               PENDING / SUCCEEDED / FAILED
```

| State | Meaning |
| --- | --- |
| Draft | Record being created |
| Awaiting approval | Validated; nothing sent |
| Submitted | Written to disk as submitted; backend call in progress |
| Pending | Backend reports the payment in flight / invoice waiting for payment |
| Succeeded | Backend reports success / invoice settled |
| Failed | Definitive failure, or provably never sent |
| Expired | Invoice expired before approval, or incoming invoice expired unpaid |
| Unknown outcome | No definitive answer — **not** a failure |
| Cancelled | Cancelled by you before submission |

Kind-specific rules (all transitions are in `payments/models.py` and tested
exhaustively):

- **Incoming invoice**: `DRAFT → PENDING → SUCCEEDED | EXPIRED | FAILED`. It
  becomes *Succeeded* only when LND reports the invoice `SETTLED`. If the
  backend is unreachable after the expiry time, the record stays *Pending*
  (it may have been paid) until the backend can be asked.
- **Bitcoin (external wallet)**: `AWAITING_APPROVAL → UNKNOWN` when you click
  *Open in wallet*. It is shown as "Handed to external wallet — outcome not
  tracked" and can never become *Succeeded*: see below.

Every transition is appended to `payment_events` in the same SQLite
transaction as the state change.

## Timeouts, unknown outcomes and reconciliation

The intent is committed as **Submitted before the backend is contacted**, so a
crash at any point leaves a durable record.

How the result of `SendPaymentV2` is interpreted:

| What happened | Resulting state |
| --- | --- |
| Stream reports `SUCCEEDED` | Succeeded (fee recorded) |
| Stream reports `FAILED` (+ reason) | Failed |
| Stream ends / times out after an in-flight update | Pending |
| HTTP 4xx other than 408/409/429 | Failed (rejected before starting) |
| Connection could not be established | Failed — "not sent" |
| HTTP 409 (gRPC AlreadyExists) | Unknown → immediately tracked by hash |
| Read timeout, dropped connection, HTTP 5xx/408/429, error line mid-stream, unexpected exception | **Unknown outcome** |

An HTTP timeout is not proof of failure. *Unknown* is resolved only by
**read-only reconciliation**:

- The stable identifier is the invoice's **payment hash**. LND refuses a second
  payment for a hash that is in flight or already paid, and `TrackPaymentV2`
  reports a payment's state by hash. No extra idempotency key is needed.
- `reconcile_on_startup()` runs when the application starts; `poll_open()` runs
  on a low-frequency timer while payments are open; *Check status* runs
  `refresh()`. None of these ever calls `SendPaymentV2`.
- Backend says succeeded / failed / in flight → the record follows.
- Backend has **no record** of the hash:
  - invoice still valid → stays *Unknown* (the request could not have been
    lost *and* still arrive later, but the application does not gamble on it);
  - invoice expired more than 120 s ago → *Failed*, "never initiated; invoice
    expired", because an expired invoice can no longer be paid.
- A record found in *Submitted* at start-up (the process died mid-call) is
  moved to *Unknown* and then tracked like any other.
- Backend unreachable → nothing changes.

**Duplicate prevention.** While an outgoing record for a payment hash is
Submitted, Pending, Unknown or Succeeded, a second payment for that hash is
refused (`DuplicatePayment`). There are no automatic retries. After a
definitive *Failed*, paying the same invoice again requires a new explicit
prepare + approve.

Consequence to be aware of: if LND answers a send request with an HTTP 5xx for
something that was in fact a pre-flight rejection, the record is shown as
*Unknown* until the invoice expires. That is deliberate: the application
prefers a slow, correct answer to a fast, wrong one.

## Amounts and rounding

- Amounts are Python integers: **millisatoshis** for Lightning, **satoshis**
  for on-chain. No floating point exists in the payments package (a unit test
  walks the syntax tree to enforce this: no `float()`, no float literals, no
  `/`).
- To the backend: always the exact msat integer (`value_msat`, `amt_msat`,
  `fee_limit_msat`, sent as decimal strings as proto3 JSON expects for int64).
  LND's satoshi fields (`value`, `num_satoshis`, `fee_sat`, …) are ignored
  whenever an `_msat` field exists.
- From the backend: integers or decimal strings are accepted; JSON floats are
  rejected.
- Display: sub-satoshi values are shown exactly (`1,234.567 sats`) where
  precision matters. Where whole satoshis are shown, **money you pay** (amount
  and fee) is rounded **up** and **money you receive** is rounded **down**, so
  costs are never understated and income never overstated.
- Default fee cap: `ceil(amount × max_fee_ppm / 1 000 000)`, but at least
  `min_fee_limit_sat` (defaults: 1 %, 5 sats). `fee_limit_msat` is *always*
  sent — LND's default of 0 means "zero-fee routes only". You may set the cap
  to 0; the hard ceiling is the payment amount (or the suggested cap if larger).
- BTC text (BIP21) is produced and parsed with integer arithmetic: at most 8
  decimals, no exponents, signs or separators.

## Bitcoin: BIP21 hand-off to an external wallet

`create_bitcoin_request` validates the address for the configured network
(Base58Check P2PKH/P2SH; Bech32 P2WPKH/P2WSH; Bech32m P2TR — other witness
versions and program sizes are refused), builds
`bitcoin:<address>?amount=<BTC>&label=…&message=…` and records the intent. The
UI opens the URI with the operating system's handler **only after you click**.

After that the record reads **"Handed to external wallet — outcome not
tracked"**. The application does not watch the chain in this release, so:

- it never shows broadcast / unconfirmed / confirmed status;
- it never marks an on-chain payment as paid;
- replacement (RBF) and reorganisations are not tracked, because nothing is.

When parsing a BIP21 URI, unknown `req-` parameters make it invalid (as BIP21
requires); other unknown parameters, including `lightning=`, are ignored and
never acted upon.

## Lightning tips: LNURL-pay scope

For a publisher's Lightning address (`name@example.org`, LUD-16), a bech32
`lnurl1…` string or an `https://` LNURL-pay URL, the application:

1. fetches the pay parameters (`tag` must be `payRequest`);
2. requests **one** invoice for the exact amount you chose;
3. rejects the invoice unless its amount equals the requested millisatoshis
   **and** its `description_hash` equals `SHA-256(metadata)`;
4. shows the normal approval dialog.

Requests use https only, refuse loopback/private destinations, cap responses at
64 KiB and follow at most two redirects (each re-checked). They contact the
publisher's server, which sees your IP address (or your payments proxy). They
happen only when you ask for a tip. Unsupported: LNURL-auth/withdraw/channel,
`successAction` (ignored, never opened), payer data, onion addresses, BOLT12.

A manifest should carry a Lightning address or donation address — never an
invoice, because invoices expire.

## Privacy and data retention

Stored per payment: amount, fee limit and fee paid, network, payment hash,
recipient node key or Bitcoin address, sanitised description, your note,
publisher/torrent association, timestamps and state history.

- The BOLT11 string of an outgoing payment is deleted once the payment is
  terminal; an incoming invoice is deleted once settled, expired or failed.
- Payment **preimages are never stored or returned**: the LND adapter drops
  them at the boundary.
- Diagnostics (`PaymentService.diagnostics()`) contain counts, backend
  reachability and truncated ids/hash prefixes only — no invoices,
  descriptions, node keys or credentials — and the global redactor additionally
  strips BOLT11/LNURL strings, macaroons and `Authorization`-style headers from
  every log line.

## Not implemented: recurring support

Recurring or automatic payments are **not implemented and there is no setting
that enables them**. If added later they would be a separate, disabled-by-
default feature with: explicit opt-in per publisher, a recipient allow-list, a
per-payment approval policy, hard spending caps per period, and immediate
cancellation. Nothing in the current code schedules or repeats a payment.

## Tests

Default suite (no network beyond loopback, no funds):

```bash
python -m pytest tests/unit/test_payment_*.py tests/adapter/test_payment_*.py tests/integration/test_payment_*.py -q
```

It covers integer arithmetic, invoice and address validation, the full
transition matrix, the service against a scriptable fake backend (rejection,
timeout → unknown, reconciliation, duplicate prevention, persistence before
submission, restart recovery), the LND adapter against `httpx.MockTransport`,
and the LNURL flow against a local HTTP server.

### Optional: real LND on regtest

**Not executed for this release** — the build environment could not download
`bitcoind`/`lnd`. The test is included and skips itself (reported as skipped,
i.e. unexecuted) unless configured.

Topology: one `bitcoind -regtest`; two LND nodes, *alice* (payer, the
application's backend, REST `:8081`) and *bob* (payee, REST `:8082`); alice
funded with 2 regtest BTC from a mined coinbase; one 1 000 000-sat channel
alice → bob. Regtest coins are worthless; no real funds are involved.

Prerequisites: Bitcoin Core ≥ 25, LND ≥ 0.18 (`lnd`, `lncli`), `xxd`.

```bash
scripts/lightning_regtest_setup.sh start
```

Export the variables it prints (`AUREOM_LND_URL`, `AUREOM_LND_MACAROON_HEX`,
`AUREOM_LND_TLS_CERT`, and `AUREOM_LND_PAYEE_*` for bob — or
`AUREOM_LND_TEST_INVOICE` with a regtest invoice from any payee), then:

```bash
python -m pytest -m lightning_regtest tests/integration/test_payment_lnd_regtest.py -v
```

```bash
scripts/lightning_regtest_setup.sh stop
```

The test refuses to run against a node that is not on regtest. It pays a
1 000-sat invoice end to end and checks tracking, duplicate refusal and the
unknown-hash response.

## LND API facts: verified vs. unverified

Checked on 2026-11-25 against the `lightningnetwork/lnd` repository (`master`;
latest release v0.21.8-beta): `lnrpc/lightning.yaml`,
`lnrpc/routerrpc/router.yaml`, `lnrpc/lightning.proto`,
`lnrpc/routerrpc/router.proto`, `lnrpc/routerrpc/router_server.go`,
`docs/macaroons.md`, `docs/rest/websockets.md`. The rendered API documentation
site was not reachable from the build environment.

**Verified from source**

- Routes: `GET /v1/getinfo`, `POST /v1/invoices`, `GET /v1/invoice/{r_hash_str}`
  (hex), `GET /v1/payreq/{pay_req}`, `POST /v2/router/send`,
  `GET /v2/router/track/{payment_hash}`.
- Header `Grpc-Metadata-macaroon: <hex>`; default REST port 8080.
- `bytes` fields are base64 in REST JSON.
- `SendPaymentRequest`: `payment_request`, `amt_msat`, `fee_limit_msat`,
  `timeout_seconds` (0 → 60 s), `no_inflight_updates`; `amt`/`amt_msat` and
  `fee_limit_sat`/`fee_limit_msat` are mutually exclusive; a fee limit of 0
  means zero-fee routes only.
- `Payment`: `payment_hash`, `status` (`UNKNOWN`, `IN_FLIGHT`, `SUCCEEDED`,
  `FAILED`, `INITIATED`), `failure_reason` (`FAILURE_REASON_*`), `fee_msat`,
  `value_msat`, `payment_preimage`.
- `AddInvoiceResponse`: `r_hash`, `payment_request`, `add_index`, `payment_addr`.
- `GetInfoResponse`: `identity_pubkey`, `alias`, `version`, `synced_to_chain`,
  `num_active_channels`, `chains[].network`. `PayReq`: `destination`,
  `payment_hash`, `num_msat`, `timestamp`, `expiry`, `description`,
  `description_hash`.
- Permissions: `SendPaymentV2` → `offchain:write`; `TrackPaymentV2` →
  `offchain:read`. Payment-exists / in-flight / already-paid errors map to gRPC
  `AlreadyExists`.
- Streamed REST responses wrap each message in a `result` field.

**Not verified (handled defensively; confirmed only by the regtest test)**

- Whether the `{payment_hash}` path parameter must be standard or URL-safe
  base64. The adapter sends URL-safe base64 with padding.
- The response of `TrackPaymentV2` for an unknown hash. Expected gRPC
  `NotFound` (HTTP 404); the adapter also recognises gRPC code 5 and
  "not found / isn't initiated" messages on other statuses.
- The HTTP status for `AlreadyExists` (expected 409 from grpc-gateway) and the
  exact error texts.
- The JSON shape of an error emitted mid-stream (`{"error": {...}}` is assumed;
  any such line leads to *Unknown outcome*, never *Failed*).
- `Invoice` field names (`state`, `amt_paid_msat`, `value_msat`,
  `creation_date`, `expiry`, `settle_date`) and the `invoices:*` macaroon entity
  come from a summary of the proto and general LND documentation rather than a
  verbatim read.

## Known limitations

- One backend (LND REST). No Core Lightning, LNbits, phoenixd or NWC adapter.
- No on-chain tracking; no BOLT12; no keysend; no multi-invoice or recurring payments.
- LNURL-pay only, with a minimal feature set; no `comment` UI, no success actions.
- Destination checks resolve host names before connecting and do not defend
  against DNS answers that change between check and connection; with a proxy
  configured, only literal IP addresses can be checked locally.
- Real-node behaviour is unexecuted here (see above); treat mainnet use as
  experimental until the regtest test has passed in your environment.
