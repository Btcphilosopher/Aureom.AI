# Protocol support

Engine: **libtorrent 2.1.3** (Python bindings from PyPI, BSD-3-Clause). The application does not
implement peer negotiation, piece selection, transport encryption or any protocol extension of its
own; everything below is the engine's behaviour, configured through its documented settings.

"Verified here" means an automated test in this repository exercised it against real libtorrent
sessions on loopback. "Engine feature" means it is enabled through engine settings but cannot be
exercised without public network access, so it was **not** tested in this build.

| Capability | Status | Evidence / notes |
|---|---|---|
| Open `.torrent` files | Supported · verified here | `test_transfer_slice.py`; 32 MiB size cap and bdecode limits |
| Magnet links (BEP 9 metadata exchange) | Supported · verified here | `test_magnet_metadata_preview_then_selective_download[v1,v2,hybrid]` |
| BitTorrent v1 | Supported · verified here | all integration tests parametrised `v1` |
| BitTorrent v2 (BEP 52) | Supported · verified here | parametrised `v2` |
| Hybrid v1+v2 | Supported · verified here | parametrised `hybrid`; duplicate detection across identities |
| Selective download / file priorities | Supported · verified here | Skip / Low / Normal / High; boundary pieces go to the `.parts` file |
| Seeding / uploading | Supported · verified here | every integration test uses a real seeder |
| Piece verification, re-check, repair | Supported · verified here | `test_corruption_is_detected_and_repaired[v1,v2,hybrid]` |
| Resume data, pause/resume, restart | Supported · verified here | `test_transfer_pause_restart_resume_verify` |
| Move storage | Supported · verified here | success and failure paths |
| Private torrents | Supported · flag verified here | engine keeps DHT/PEX/LSD off; the app never sets a contrary flag |
| HTTP/HTTPS trackers | Engine feature · not tested here | announce results are shown and redacted in logs |
| UDP trackers (BEP 15) | Engine feature · not tested here | |
| DHT (BEP 5) | Engine feature · not tested here | off in tests and `--local-demo` |
| Peer exchange (BEP 11) | Engine feature · not tested here | session plug-in; a change applies at next start |
| Local peer discovery (BEP 14) | Engine feature · not tested here | off whenever a proxy is configured |
| Web seeds, BEP 19 (`url-list`) | Engine feature · creation verified | created torrents carry them; downloading from one is not tested |
| Web seeds, BEP 17 (`httpseeds`) | **Not offered** | deprecated in libtorrent 2.x |
| Protocol encryption (MSE) | Engine feature · not tested here | allow / require / disable; not anonymity |
| uTP | Engine feature | loopback tests may use either transport |
| UPnP / NAT-PMP port mapping | Engine feature · not tested here | off whenever a proxy is configured |
| SOCKS5 / HTTP proxies | Engine feature · settings translation unit-tested | see docs/privacy.md for what is switched off |
| Bind to interface | Listening address + watchdog · probe unit-tested | see docs/privacy.md for limits |
| Magnet `xt` v1 (hex, base32), v2 (`btmh`), multiple `xt`, `dn`, `tr`, `ws`, `x.pe`, `so` | Parsed and validated · unit-tested | `xs`/`as` are recorded but never fetched |
| Queueing (active downloads/seeds), rate limits | Engine auto-management | seeding ratio/time stops and schedules are application policy, unit/adapter-tested |
| Super-seeding, sequential download, share mode | Not exposed | |
| WebTorrent, I2P, SSL torrents | **Not supported** | not enabled in the PyPI build of the bindings |
| Remote control (Web UI / API) | **Not available** | deliberately absent in this release |

## Engine limitations worth knowing

* **Metadata-only preview.** Implemented with libtorrent's `upload_mode` flag ("the torrent will
  not request any pieces"). In our tests no payload byte is downloaded and nothing is written
  before confirmation. Peers are still contacted, and they learn your address.
* **Exporting a `.torrent` for a v2/hybrid magnet.** Magnet metadata does not include v2 piece
  layers; libtorrent can only write a complete `.torrent` once the payload has been verified.
  Until then "Export .torrent" reports that it is not available yet. (v1 magnets export
  immediately.) The transfer itself is restored from resume data, which embeds the info dictionary.
* **v1-only and v2-only magnets of the same hybrid torrent** cannot be recognised as duplicates
  until metadata arrives. When it does, the newer transfer is removed (never two writers).
* **Deletion** uses the engine's own removal of the torrent's files. A folder that still contains
  other files is kept and you are told so.
* **Path sanitising.** libtorrent rewrites unsafe paths on load. The application additionally
  inspects the raw info dictionary and refuses torrents that contain absolute or parent-directory
  components.
