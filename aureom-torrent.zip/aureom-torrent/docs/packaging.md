# Packaging

## Dependencies and licences

Verified on 2026-11-25 from PyPI metadata of the installed distributions (`requirements.lock`
holds the exact set). Redistribution notes are the author's reading, not legal advice.

| Component | Version tested | Licence | Redistribution note |
|---|---|---|---|
| libtorrent (python bindings) | 2.1.3 | BSD-3-Clause | bundle the licence text; statically includes Boost (BSL-1.0) and OpenSSL (Apache-2.0) |
| PySide6-Essentials / shiboken6 | 6.12.0 | LGPL-3.0-only (or GPL / commercial) | dynamic linking only; ship the LGPL text, keep Qt libraries replaceable, do not strip their notices. The one-folder bundle keeps them as separate shared objects |
| feedparser (+ feedparser-sgmllib) | 6.0.14 | BSD-2-Clause (PSF-2.0) | |
| nh3 | 0.3.8 | MIT | |
| regex | 2026.11.24 | Apache-2.0 AND CNRI-Python | |
| defusedxml | 0.7.1 | PSF-2.0 | |
| segno | 1.6.6 | BSD-3-Clause | |
| httpx (+ httpcore, h11, anyio, certifi, idna, socksio) | 0.28.1 | BSD-3-Clause (MPL-2.0 for certifi) | |
| keyring (+ SecretStorage, jeepney, jaraco.*) | 25.7.0 | MIT (BSD-3-Clause) | |
| bolt11 | 2.2.0 | MIT | |
| bitstring | 4.4.0 | MIT | **must be < 5**: bolt11 2.2.0 imports a name bitstring 5 removed (found during verification) |
| bech32, base58 | 1.2.0, 2.1.1 | MIT | |
| coincurve | 21.0.0 | MIT OR Apache-2.0 | bundles libsecp256k1 (MIT) |
| cryptography | 50.0.2 | Apache-2.0 OR BSD-3-Clause | bundles OpenSSL |
| pytest, pytest-qt, pytest-timeout | dev only | MIT | not shipped |
| PyInstaller | build only | GPL-2.0 with bootloader exception | the exception permits distributing bundles under any licence |

Only *Essentials* is used: no QtWebEngine, QML or Quick. Feed content is rendered with
`QTextBrowser`, with resource loading disabled.

## Wheel / sdist

```bash
pip install build
```

```bash
python -m build
```

The wheel is pure Python (`aureom_torrent`, including `persistence/migrations/*.sql`) and declares
the binary dependencies above. Entry point: `aureom-torrent` (GUI script).

## One-folder application bundle (PyInstaller)

```bash
pip install ".[package]"
```

```bash
pyinstaller --noconfirm packaging/aureom-torrent.spec
```

Result: `dist/aureom-torrent/aureom-torrent`. Verify a bundle before shipping it:

```bash
QT_QPA_PLATFORM=offscreen dist/aureom-torrent/aureom-torrent --local-demo --self-check --data-dir /tmp/aureom-check
```

**Actual result in the build environment** (Ubuntu 24.04, Python 3.12, PyInstaller 6.22): the
build completed; the bundle is 210 MB; `--self-check` exited 0 with the engine running, listening,
schema version 4 and a clean shutdown.

Two things the self-check caught and the spec now handles – keep them if you write your own spec:

* `bitstring` selects a storage back end with `importlib`; its sub-modules must be hidden imports;
* `coincurve` ships its own `_cffi_backend` inside the package; it must be collected explicitly.

Build-host caveat: the container had no X11 client libraries, so PyInstaller reported 32
"library not found" warnings for the Qt **xcb** platform plug-in (`libxcb-cursor.so.0`,
`libxkbcommon-x11.so.0`, …) and the bundle was verified with the *offscreen* platform only. Build
on a desktop system that has those libraries installed (Debian/Ubuntu: `libxcb-cursor0
libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-render-util0 libxcb-xkb1 libxkbcommon-x11-0`)
and run the bundle on a real display before distributing it. **That was not done here.**

Bundles are per platform: build on the oldest OS version you intend to support. Windows and macOS
bundles (and code signing / notarisation) were not attempted.

## File and URI association

Not installed automatically by the application; provided as packaging inputs.

* **Linux**: `packaging/aureom-torrent.desktop` declares
  `MimeType=application/x-bittorrent;x-scheme-handler/magnet;`. Install it to
  `~/.local/share/applications/`, the icon `resources/aureom-torrent.svg` to
  `~/.local/share/icons/hicolor/scalable/apps/`, then:

  ```bash
  xdg-mime default aureom-torrent.desktop application/x-bittorrent x-scheme-handler/magnet
  ```

* **Windows / macOS**: register the `.torrent` extension and the `magnet` URL scheme in the
  installer (registry keys / `CFBundleDocumentTypes` + `CFBundleURLTypes`). Not implemented.

The application accepts paths and magnet URIs as command-line arguments (`%U`), opens the review
dialog for each, and never starts a download or a payment without that confirmation.
**Association was not tested on any platform.** A second launch does not hand its arguments to
a running instance (no single-instance IPC yet).

## Data locations

| Platform | Directory |
|---|---|
| Linux | `$XDG_DATA_HOME/aureom-torrent` (default `~/.local/share/aureom-torrent`) |
| macOS | `~/Library/Application Support/AureomTorrent` |
| Windows | `%APPDATA%\AureomTorrent` |

Override with `--data-dir` or `AUREOM_TORRENT_HOME`. Contents: `aureom.sqlite3`, `resume/`,
`torrents/`, `staging/` (metadata previews; no payload), `logs/`, `exports/`, `cache/theme/`.
Credentials are not stored there.
