# RSS and Atom feeds

AUREOM TORRENT contains a real subscription reader (`src/aureom_torrent/feeds/`).
It discovers `.torrent` enclosures and magnet links in RSS 2.0 and Atom feeds,
lets you add them as transfers, and can — only when you opt in per feed — add
matching new items automatically.

Feed rules can create transfers. They can **never** trigger Bitcoin or
Lightning payments: the `feeds` package has no import path to `payments`, and a
unit test (`tests/unit/test_feed_no_payments.py`) fails the build if one appears.

## Module map

| Module | Responsibility |
| --- | --- |
| `feeds/client.py` | Conditional GET (ETag / Last-Modified), status handling, Retry-After, back-off schedule, `.torrent` enclosure download. All requests go through `net.http.Fetcher`. |
| `feeds/parser.py` | `feedparser` → normalised entries; `nh3` sanitisation; link-type detection. |
| `feeds/dedup.py` | De-duplication keys (GUID, link, enclosure URL, torrent identity, title hash). |
| `feeds/rules.py` | Pure rule validation and evaluation; budget arithmetic. |
| `feeds/opml.py` | OPML import (`defusedxml`) and export. |
| `feeds/repository.py` | SQLite persistence (`0002_feeds.sql`). |
| `feeds/service.py` | `FeedService`: subscriptions, refresh, baseline, automation, review queue, diagnostics. |

`FeedService` talks to the rest of the application only through
`services.interfaces.TransferGateway` (inspect / find duplicate / add), so it is
tested against `tests/fakes/feeds.py::FakeTransferGateway`.

## Network behaviour

* Feeds use their **own** network settings (`Settings → Network → RSS`,
  `AppSettings.feeds_network`): proxy, timeout, response-size limit, redirect
  limit, and whether loopback / private addresses may be contacted. A
  BitTorrent proxy does not apply to feed traffic, and a configured feed proxy
  is never bypassed: if it fails, the refresh fails.
* Only `http` and `https` addresses are accepted; addresses with embedded
  credentials are rejected. Redirects are followed manually with the same
  checks on every hop; `https → http` downgrades and non-HTTP targets are refused.
* Responses are capped while streaming (default 4 MiB); a missing or false
  `Content-Length` does not defeat the cap. `.torrent` enclosures are fetched
  under the same limits.
* Refreshes are conditional: stored `ETag` / `Last-Modified` values are sent as
  `If-None-Match` / `If-Modified-Since`, and `304 Not Modified` costs no parsing.
  Validators are stored only after the body was parsed successfully.
* Failures back off deterministically: 5, 10, 20, 40 … minutes, capped at
  24 hours (`client.backoff_seconds`). `Retry-After` on `429` / `503` can only
  lengthen the delay and is itself capped at 24 hours. A success resets the
  counter. The failure count, last error and next check time are persisted.
* A permanent redirect (`301` / `308` on every hop) updates the stored address
  only after the redirected document parsed as a feed. *(This needs per-hop
  status codes from the HTTP layer — see “Known limitations”.)*
* HTTPS is transport security, not trust. Nothing in the reader labels a feed
  or publisher as verified or trustworthy because of its scheme.
* Log lines and the diagnostic summary show scheme, host and path only — query
  strings (which often carry passkeys) are never written.

## Parsing and sanitisation

* `feedparser` is handed bytes in a stream; it never fetches URLs or opens files.
* Documents that declare XML entities (`<!ENTITY …>`) are rejected before
  parsing. `feedparser` would expand nested internal entities, which allows
  exponential “billion laughs” growth; refusing them is the conservative choice.
* Entry content is reduced to `p br b strong i em ul ol li blockquote code pre a`
  with `nh3`. Links keep only `http`/`https` targets and get
  `rel="noopener noreferrer"`. Images, scripts, styles, frames, event handlers
  and `javascript:` / `data:` / `magnet:` hrefs are removed, so displaying an
  entry never loads anything remote and never runs anything. A plain-text
  rendering is stored for search.
* Limits: entries per feed (`FeedSettings.max_entries_per_feed`, default 500),
  title 500 characters, summary 20 000 characters of markup.

### Link detection

| Found in | Result |
| --- | --- |
| Enclosure / `rel="enclosure"` link with type `application/x-bittorrent` or a path ending `.torrent` (http/https) | `link_type = "torrent"` |
| Entry link ending `.torrent` | `link_type = "torrent"` |
| Magnet in an enclosure, `torrent:magnetURI`, the entry link, the GUID, or an `href`/text in the content (validated by the strict magnet parser) | `link_type = "magnet"` |
| `torrent:infoHash` (40 or 64 hex) | identity only |
| none of the above | `link_type = "none"` (no Add Transfer action) |

Relative enclosure addresses are resolved against the final feed URL.

### Sizes

A feed can claim anything. Sizes from `torrent:contentLength` or an enclosure
`length` are stored as **feed-reported** (`FeedEntry.size_trusted == False`,
`size_label == "feed-reported"`) and are shown as such. A size becomes trusted
only when it was read from fetched torrent metadata. Size limits and byte
budgets are evaluated exclusively against trusted sizes.

## De-duplication

Each entry gets several keys (`feeds/dedup.py`):

| Key | Scope | Source |
| --- | --- | --- |
| `g` | feed | GUID / Atom id |
| `l` | feed | canonical link (lower-cased host, no fragment, no tracking parameters) |
| `t` | feed | hash of title + download link, only when there is neither GUID nor usable link |
| `e` | global | canonical `.torrent` enclosure URL |
| `i1`, `i2` | global | v1 / v2 info-hash |

* A changed GUID is tolerated when the link, enclosure or identity still
  matches; a missing GUID falls back to the link, then to the title hash.
* A link shared by several entries of one document does not identify an entry
  and is ignored as a key for those entries.
* Keys are persisted in `feed_seen`, which outlives the entry rows: pruned
  entries are not resurrected as “new”. Passive history that has not appeared in
  any feed for 400 days is forgotten; records of *added*, *dismissed* and
  *review* decisions are kept.
* Global keys carry the outcome. An item that history records as **added** or
  **dismissed** is never added automatically again — not by a re-post with a new
  GUID, not by another feed, and not after you removed the transfer.

## Baseline and automation

1. **Baseline.** The first successful refresh of a subscription marks everything
   already in the feed as `baseline`. Baseline entries are visible and can be
   added manually, but are never added automatically — unless you subscribed
   with “also process existing entries” (`download_existing=True`), which is an
   explicit choice. A failed first refresh does not consume the baseline.
2. **Opt-in.** Rules run only for feeds whose *automatic downloads* switch is on
   (off by default, including for OPML imports), and only for enabled rules.
3. **Scope.** Rules are applied to entries first seen in the current refresh.
   Applying them to older untouched entries is a separate explicit action
   (`FeedService.apply_rules_now`).
4. **Matching** (`feeds/rules.py`), against the entry title, case-insensitive:
   every *include* term must be present, no *exclude* term may be present, and
   the optional regular expression must match. The first matching rule wins.
   Regular expressions are limited to 500 characters, matched against at most
   1 000 characters, and evaluated with the `regex` library's timeout
   (`FeedSettings.regex_timeout_ms`, default 100 ms). A time-out sends the entry
   to review instead of blocking the refresh.
5. **Limits.** Minimum / maximum size, maximum additions per refresh, and a daily
   budget (count and/or bytes per UTC day, persisted in `feed_budget`).
6. **Review instead of guessing.** An entry goes to the review queue, with the
   reason, when a rule matched but could not be applied safely:
   * a size limit applies and the entry is a magnet link (no trustworthy size);
   * the `.torrent` file needed to verify the size could not be downloaded or is invalid;
   * a per-refresh limit or daily budget is exhausted;
   * the pattern timed out;
   * the transfer service rejected the addition (unusable destination, conflict, unsafe paths).

   For `.torrent` enclosures the file is fetched (bounded) and inspected by the
   engine to obtain the real size and identity before a size-limited rule decides.
7. **Manual decisions are not overwritten.** If an equivalent transfer already
   exists the entry is linked to it and marked `duplicate`; the transfer's pause
   state, priorities, category and destination are not touched.
8. **Dry run.** `preview_rule` evaluates a rule (saved or not) against the feed's
   current entries and returns a decision and reason per entry. It fetches
   nothing, adds nothing, changes no status and writes no log rows. Entries whose
   size would have to be verified are reported as `review` with that explanation.
9. Every automatic decision is written to a bounded log (`feed_rule_log`, 2 000
   rows) that is shown in the UI and included in the diagnostic export.

Entry statuses: `new`, `baseline`, `added`, `duplicate`, `review`, `dismissed`.

## OPML

* Import accepts OPML up to 2 MiB / 2 000 feeds, nested at most 16 levels;
  entity declarations and external references are rejected (`defusedxml`).
  Nested outlines become folder paths (`Parent/Child`); the first value of the
  `category` attribute becomes the feed category. Non-http(s) addresses are
  counted as invalid; existing subscriptions are skipped. Importing contacts no
  feed and never enables automatic downloads.
* Export writes OPML 2.0 with folders as nested outlines.

## Service API (used by the UI from worker threads)

```
FeedService(db, fetcher, gateway, settings, clock)
  add_feed(url, *, title="", folder="", category="", interval_minutes=None, download_existing=False) -> Feed
  update_feed(feed_id, **changes) -> Feed        # url, title, folder, category, interval_minutes, auto_download
  set_auto_download(feed_id, enabled) -> Feed
  remove_feed(feed_id); list_feeds() -> list[Feed]; get_feed(feed_id); list_folders() -> list[str]
  refresh_feed(feed_id, *, manual=True) -> RefreshResult
  refresh_due() -> list[RefreshResult]            # call from a worker timer; at most 10 feeds per call
  list_entries(*, feed_id=None, folder=None, unread_only=False, search="", link_type=None, status=None,
               limit=200, offset=0) -> list[FeedEntry]
  get_entry(entry_id); mark_read(entry_ids, read=True); mark_all_read(feed_id=None)
  add_entry_as_transfer(entry_id, *, save_path, category="", paused=False, preview=False) -> AddOutcome
  list_rules(feed_id=None); save_rule(rule) -> FeedRule; delete_rule(rule_id)
  preview_rule(rule) -> list[RulePreviewRow]; apply_rules_now(feed_id) -> RefreshResult
  rule_log(*, feed_id=None, limit=100) -> list[RuleLogRow]
  list_review(); approve_review(entry_id, *, save_path=None) -> AddOutcome; dismiss_review(entry_id)
  import_opml(text) -> OpmlImportResult; export_opml() -> str
  diagnostics() -> dict
```

Errors are `feeds.models.FeedError` (and subclasses `RuleError`, `OpmlError`,
`FeedFetchError`, `FeedParseError`) or `services.interfaces.AddRejected`; their
messages are safe to show. The same feed is never refreshed concurrently: a
second request returns a failed `RefreshResult` saying a refresh is running.

## Demo server

`scripts/demo_feed_server.py` serves an RSS and an Atom feed on loopback with
validators and `304` support. Its items are synthetic CC0 text datasets
generated on start-up; when libtorrent is importable it also creates and serves
real `.torrent` files and magnet links for them.

```bash
python scripts/demo_feed_server.py --port 8765
```

1. In Settings → Network → RSS, allow loopback addresses (they are refused by default).
2. Subscribe to `http://127.0.0.1:8765/rss.xml` and `http://127.0.0.1:8765/atom.xml`.
   The first refresh is the baseline: nothing is added automatically.
3. Enable automatic downloads for a feed and create a rule (use the dry run).
4. Publish a new item and refresh:

```bash
curl -X POST http://127.0.0.1:8765/publish
```

The server hosts metadata only. To actually transfer the sample data, seed the
generated folder (its path is printed on start-up) from another session.

## Tests

```bash
python -m pytest tests/unit/test_feed_*.py tests/adapter/test_feed_*.py tests/integration/test_feed_*.py -q
```

* `tests/unit` — parser (RSS, Atom, hostile markup, entity bombs, limits),
  de-duplication keys, rule evaluation (including a catastrophic pattern that
  must time out), OPML (round trip, malicious documents), client (back-off,
  Retry-After, address validation), and the no-payments import guard.
* `tests/adapter` — `FeedService` against a scripted fetcher and a fake
  transfer gateway: baseline, opt-in, conditional refresh, time-outs, malformed
  responses, changing and missing GUIDs, pruning, existing transfers left
  untouched, removed/dismissed items not re-added, size verification, limits and
  budgets, dry run without side effects, review queue, OPML, diagnostics.
* `tests/integration` — a real `http.server` on 127.0.0.1 with the real
  `HttpFetcher`: RSS and Atom fixtures, conditional requests answered with 304,
  oversized responses (declared and streamed), redirects and redirect limits,
  refusal of non-HTTP redirect targets, malformed content, time-outs, loopback
  refused unless allowed, rule limits end to end, and the demo server flow with
  real `.torrent` files inspected by libtorrent.

## Known limitations

* **Permanent redirects.** Moving a subscription on `301`/`308` needs the HTTP
  layer to report the status of each redirect hop (`HttpResult.redirect_statuses`).
  Until it does, redirects are followed but the stored address is not rewritten;
  the corresponding integration test is skipped and the service-level behaviour
  is covered with the fake fetcher.
* Rules match the entry title only (not the summary), by design: titles are
  what publishers version and what users can predict.
* Authentication (HTTP auth, cookies) for private feeds is not supported;
  addresses with embedded credentials are rejected. Feeds that carry a passkey
  in the query string work, and the query is kept out of logs and diagnostics.
* A size-limited rule cannot be applied automatically to magnet-only entries;
  they are queued for review.
* The daily budget is per UTC calendar day, not a sliding 24-hour window.
* Destination checks resolve host names before connecting and therefore do not
  defend against DNS answers that change between the check and the connection;
  with a proxy configured, names are resolved by the proxy (see `docs/privacy.md`).
