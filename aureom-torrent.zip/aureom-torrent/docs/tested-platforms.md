# Tested platforms and actual results

## Matrix

| OS | Arch | Python | libtorrent | PySide6 | Automated tests | GUI | Packaged build |
|---|---|---|---|---|---|---|---|
| Ubuntu 24.04.5 LTS (container, kernel 6.18) | x86-64 | 3.12.3 | 2.1.3 | 6.12.0 | **844 passed, 4 skipped** | offscreen only | PyInstaller one-folder: built, self-check passed (offscreen) |
| Ubuntu 24.04 | x86-64 | 3.11 / 3.13 | 2.1.3 wheel exists | wheel exists | not run | not run | not run |
| Windows 10/11 | x86-64 | 3.12 | wheel exists on PyPI | wheel exists | **not run** | **not run** | **not run** |
| macOS 13+ | arm64 / x86-64 | 3.12 | wheel exists on PyPI | wheel exists | **not run** | **not run** | **not run** |

"Wheel exists" was checked with `pip download --only-binary` for Linux x86-64 (cp311, cp312,
cp313); Windows/macOS availability is taken from the package index listing and is unverified.

## Results on the supported combination (2026-11-25)

```
python -W error::DeprecationWarning -m pytest -q -rs
844 passed, 4 skipped in 83.55s
SKIPPED [4] tests/integration/test_payment_lnd_regtest.py: LND regtest environment not configured
```

| Check | Result |
|---|---|
| Unit tests (565) | passed |
| Adapter tests with fakes (202) | passed |
| Integration: libtorrent on loopback, v1 / v2 / hybrid separately; local HTTP servers (74 incl. 4 skipped) | 70 passed, 4 skipped |
| GUI smoke tests, Qt offscreen (7) | passed |
| `scripts/demo_local_transfer.py` (hybrid) | byte-for-byte match |
| `scripts/demo_publish.py` (v1, v2, hybrid) | exit 0 |
| `scripts/ui_tour.py` (real engine + GUI, light and dark, all workspaces) | exit 0, screenshots reviewed |
| `python -m aureom_torrent --local-demo --self-check` | ok |
| PyInstaller bundle `--self-check` | ok (after two spec fixes, see packaging.md) |

What the loopback integration suite verifies with real engine sessions, each for v1, v2 and hybrid
where it says so: byte-for-byte transfer; verified progress while partially downloaded; manual
pause; clean shutdown with resume data; restart recovery without re-checking; magnet metadata
retrieval with no payload downloaded and nothing written; file selection and later re-selection;
duplicate handling across v1/v2/hybrid identities; destination conflicts; corruption detection by
re-check and repair; storage move success and failure (destination persisted only after the engine
confirms); removal without deletion; deletion limited to owned files (foreign files survive);
deletion refused when a path resolves outside the destination; corrupt and missing resume data;
missing destination; private flag preserved.

## Unexecuted checks

| Check | Why | How to run it |
|---|---|---|
| Lightning payment on regtest (4 tests) | bitcoind / LND release binaries were not downloadable (network policy) | `scripts/lightning_regtest_setup.sh`, then set `AUREOM_LND_URL`, `AUREOM_LND_MACAROON_HEX`, `AUREOM_LND_TLS_CERT` and run `pytest -m lightning_regtest` |
| LND specifics: URL-safe base64 path for TrackPaymentV2, 404 for an unknown hash, 409 for a known payment | need a live node | same |
| Public swarm behaviour: trackers, DHT, PEX, LSD, UPnP/NAT-PMP, web-seed download | no public peer networking in the build environment | manual |
| BitTorrent through a SOCKS5/HTTP proxy | no proxy available | manual |
| Interface disappearance with a real VPN | not available | manual |
| OS credential store (Secret Service / Keychain / Credential Manager) | none in the container | run on a desktop session |
| Real display, high-DPI, screen reader, system dark-mode switching | headless | manual |
| File / magnet association | not installed | see packaging.md |
| Windows, macOS | no such hosts | — |
| Very large libraries (10 000+ real torrents) | only the table model was exercised with 20 000 synthetic rows | manual |

Passing unit tests does not make this production-ready: the items above need to be run on real
desktops and networks first.
