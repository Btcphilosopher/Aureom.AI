# Publishing, sharing and publisher manifests

This document covers the **Publish & Share** backend (`aureom_torrent.publishing`):
creating a torrent from local files, the sharing artifacts, the publishing adapters and
the publisher-manifest format. The wizard UI drives `PublishService`; nothing here touches Qt.

> **What publishing does not do.** A magnet link only *identifies* content. Creating a torrent,
> copying a magnet, exporting a page or uploading a file does not host the payload and does not
> guarantee that anyone can download it. Until other people hold complete copies, the
> publisher's own device must stay online and seeding. The application says this on the sharing
> screen, in the share text and on the exported page.

## 1. The wizard steps and their backend calls

| Step | Backend |
| --- | --- |
| 1. Select a file or folder | `PublishService.scan(path, cancelled=…)` |
| 2. Review included files | `ScanResult.files` (included) and `ScanResult.skipped` (with reasons) |
| 3. Torrent format | `PublishDraft.format` = `v1`, `v2` or `hybrid` (default) |
| 4. Piece size | `PublishDraft.piece_length` = `0` (automatic) or a power of two, 16 KiB – 64 MiB; `piece_length_choices()` |
| 5. Trackers / web seeds | `trackers_text` (one URL per line, blank line = next tier) or `tracker_tiers`; `web_seeds` |
| 6. Public / private | `PublishDraft.private` |
| 7. Publisher metadata | `PublishDraft.publisher` (`PublisherInfo`), `embed_manifest`, `sign_manifest` |
| – validate | `check_options(draft, total_size=…)` → `OptionsCheck(errors, warnings, tiers, piece_length, estimated_pieces)` |
| 8. Generate hashes | `start_job(draft, on_progress=…, cancelled=…)` – blocking, run on a worker thread |
| 9. Save the .torrent | part of `start_job` (exclusive, atomic write to `output_torrent_path`) |
| 10. Start seeding | part of `start_job` when `start_seeding` is set (through `TransferGateway`) |
| 11. Sharing screen | `share_info(job_id)`, `build_artifacts`, `export_to_directory`, `publish` |

### File selection safety

* `scan()` delegates to `filesystem.paths.scan_for_publish`. **Symbolic links are never
  followed.** Links are listed under *skipped* – with the distinct reason "symbolic link
  pointing outside the selected folder" when that is the case – as are special files, unreadable
  entries, unsafe names and OS junk files (`.DS_Store`, `Thumbs.db`, …).
* A selection that is itself a symbolic link is refused.
* When the job starts, the service **re-scans** and requires every file in
  `PublishDraft.included_files` to be in the fresh scan. A stale or forged file list therefore
  cannot add a link, a path reached through a linked directory, or anything outside the root.
* The engine creator additionally refuses any entry that is a link or not a regular file.

### Options that are validated

* Format: `v1`, `v2`, `hybrid`. v1-only and v2-only produce an advisory warning (SHA-1 only /
  not readable by v1-only clients).
* Piece size: automatic targets roughly 1 000–2 000 pieces (16 KiB … 16 MiB). Warnings: more than
  100 000 pieces; a manual piece size larger than the content.
* Trackers: `http`, `https`, `udp` URLs; duplicates dropped; at most 64 trackers in 20 tiers.
  Error messages show only scheme and host because tracker URLs can carry passkeys.
* Web seeds: BEP 19 (`http`/`https` URL seeds) only, at most 16. BEP 17 is not offered.
* Private torrents: the engine disables DHT, peer exchange and local peer discovery for a torrent
  with the private flag. The wizard warns about this, and warns that a private torrent without a
  tracker cannot find peers. The private flag is written into the info dictionary; the
  application never overrides it.
* Name: defaults to the folder/file name. A folder torrent may be renamed only when *start
  seeding* is off (the files on disk would not match the torrent's top-level folder).
* Output: must be an absolute `.torrent` path, must not replace a published file.
  **Never overwritten silently** – see below.

### Job lifecycle

`start_job` raises `PublishError` for an invalid draft (nothing is recorded). Otherwise a row is
written to `publish_jobs` **before** hashing starts and the job ends in one of:

| State | Meaning |
| --- | --- |
| `completed` | .torrent written; magnet and identity recorded |
| `cancelled` | the user cancelled; **no .torrent and no temporary file is left** |
| `failed` | `job.error` explains (I/O error, file changed, output already exists, …) |
| `interrupted` | the application stopped while the job was `hashing`/`saving` |

* Hashing runs in the engine creator on the calling worker thread; `on_progress(pieces_done,
  pieces_total)` reports progress and `cancelled()` is polled per piece.
* Saving is exclusive unless `overwrite` is set: the bytes go to a temporary file in the target
  folder, are `fsync`ed and hard-linked into place, which fails if anything exists at the path
  (no check-then-write race). With `overwrite` the replacement is atomic (`os.replace`).
* `recover_interrupted()` (call once at start-up) marks jobs left in `hashing`/`saving` as
  `interrupted` and removes leftover `<name>.torrent.*.tmp` files. An interrupted job is never
  resumed or presented as shareable; the user runs the wizard again.
* Starting to seed hands the .torrent bytes to `TransferGateway.add_torrent_data(…,
  save_path=<parent of the selection>, source="created", paused=False)`. The transfer service
  **verifies the files** (no "seed mode" shortcut), so the UI shows *Checking* and then
  *Seeding*. If the add is refused or the torrent already exists, the job still completes and
  the outcome is recorded as the `start_seeding` operation.
* The file list is not persisted with the job (it can be very large); only its length is.

## 2. Sharing screen data

`share_info(job_id)` returns a `ShareInfo`: magnet, .torrent path (and whether it still exists),
identity, format, sizes, `qr: QrResult`, `share_text`, `publisher_label`, `transfer_id`,
`seeding_requested`, `seeding_started` (`None` = not requested, `False` = requested but the add
failed), every recorded `PublishOperationResult`, and the standing notes.

Live seeding state and the last announce result are owned by the transfer service; join on
`ShareInfo.transfer_id`. `sharing.SeedingStatusNote` holds the wording for each case.

### Magnet QR codes and the capacity limit

QR codes are generated with **segno** as SVG (text) and PNG (bytes).

* A QR symbol can hold 2 331 bytes at error level M, but dense codes do not scan reliably from a
  screen. The application caps codes at **version 25, level M, byte mode = 997 bytes**
  (`sharing.QR_MAX_VERSION`, `QR_MAX_BYTES`).
* A magnet that does not fit is **not** rendered as an unreadable code. `make_magnet_qr` tries
  shorter equivalents – info-hash(es) + name + the first 3, 2, 1 trackers, then without
  trackers – and returns the first that fits with `trimmed=True` and a reason stating what was
  left out (web seeds and remaining trackers stay in the full magnet text and the .torrent).
* For a **private** torrent the tracker is never trimmed away; if it cannot fit, or the caller
  passes `allow_trim=False`, the result is `ok=False` with
  `alternative="Copy the magnet text or share the .torrent file instead."`
* The magnets themselves are produced by the engine (`TorrentCodec.make_magnet`); the trimmed
  form is rebuilt from the strict parser's validated fields.

### Exports

`build_artifacts(job_id, kinds, public_torrent_url="")` produces, in memory:

| Kind | File | Notes |
| --- | --- | --- |
| `torrent` | `<stem>.torrent` | re-read from disk and checked against the job's identity |
| `page` | `<stem>.html` | static publisher page, see below |
| `atom` | `<stem>.atom.xml` | single-entry Atom feed |
| `qr_svg`, `qr_png` | `<stem>.qr.svg/.png` | omitted (with a reason) when no scannable code exists |
| `manifest` | `<stem>.manifest.json` | canonical publisher manifest, if publisher details were entered |
| `share_text` | `<stem>.txt` | short plain-text description |

**Static publisher page.** One self-contained HTML file: inline CSS, **no scripts, no remote
resources**, a restrictive `Content-Security-Policy` meta tag, every piece of text HTML-escaped,
the magnet as a link (only `magnet:` links are emitted) plus the inline QR SVG, a bounded file
list (200 rows), publisher details labelled with their trust level, optional Bitcoin address
(text + plain `bitcoin:` link) and Lightning address (text). Invoices are never included. The
page carries the visible note *"This page is a local file. Exporting it does not publish it or
host the files."* – the application does not invent hosting.

**Atom catalogue entry.** A valid Atom feed with one entry: the magnet is the entry's
`rel="alternate"` link (this application's feed reader ingests it), `id` is `urn:btih:<v1>` (or
`urn:btmh:1220<v2>` for v2-only), ezRSS-style `torrent:infoHash`, `torrent:contentLength` and
`torrent:magnetURI` elements are included, and a `rel="enclosure"` link to the .torrent is added
**only** when the publisher supplies the public URL where they host it.
`sharing.build_atom_entry(entry_only=True)` returns just the `<entry>` for pasting into an
existing feed.

## 3. Publishing adapters

A destination is configured explicitly by the user and stored in `publish_destinations`
(`PublishDestination(id, kind, name, config)`). **Credentials are never stored in SQLite**: an
upload token goes to the OS credential store under `publish-destination-<id>`; unknown config
keys are refused rather than persisted.

| Kind | Config | Behaviour |
| --- | --- | --- |
| `local_dir` | `{"directory": "/abs/path"}` | atomic writes into that folder; safe single-component names only; a planted symlink at the target is replaced, not followed |
| `https_upload` | `{"base_url": "https://host/path"}` | `PUT <base_url>/<artifact>` with `Authorization: Bearer <token>` |

HTTPS upload details:

* Requests use the shared policy-checked fetcher with the **publishing** network settings
  (`settings.publishing_network`): https only, no loopback/private addresses, the configured
  proxy or a direct connection – never a silent fallback. BitTorrent proxy settings do not apply
  to uploads, and vice versa.
* Redirects are never followed for uploads (the body and token are not re-sent elsewhere).
* The base URL may not contain credentials, a query string or a fragment: signed URLs are
  secrets and would otherwise end up in the database.
* Artifacts are limited to 32 MiB; the response body is capped at 64 KiB.
* A `2xx` answer is reported as *uploaded* with the explicit caveat that **the endpoint accepting
  a file does not prove it is publicly reachable**.

`publish(job_id, destination_id, artifacts=[…])` records one `PublishOperationResult` per
artifact **as it happens** (`operation="publish:<kind>"`, display-safe destination, `ok`,
message, timestamp), including artifacts that could not be produced and ones not attempted after
the user stopped the run. The sharing screen reads them from `job.operations` /
`ShareInfo.operations`, so it can always say which operations succeeded or failed.

**Not implemented:** an S3-compatible object-store adapter. It is listed as such in the
diagnostics (`"s3_adapter": "not implemented"`) and is not offered in the UI.

## 4. Publisher manifests

A manifest is a small JSON document describing the publisher. Schema version **1**:

| Member | Rules |
| --- | --- |
| `schema_version` | integer `1` (required; other versions are rejected) |
| `publisher` | display name, 1–120 characters (required) |
| `description` | up to 2 000 characters; `\n` allowed |
| `torrent` | `{"v1": <40 hex>, "v2": <64 hex>}`, at least one |
| `website`, `feed_url` | lowercase `http://` or `https://` URL, ≤ 512 characters, no credentials |
| `bitcoin` | `{"address", "network"}`; network ∈ mainnet, testnet, signet, regtest |
| `lightning_address` | Lightning address `name@domain` (LUD-16) or `lnurl1…`, lowercase |
| `licence` | SPDX-like identifier (`CC-BY-4.0`) or a URL |
| `created` | Unix time, integer seconds |
| `signature` | `{"alg": "ed25519", "public_key": <64 hex>, "value": <128 hex>}` |

* **Size limit:** 16 KiB serialised (also the limit for the embedded copy).
* **Unknown members are rejected**, at every level. A manifest is either fully understood or not
  used at all.
* **No expiring invoices.** A `lightning_address` that looks like a BOLT 11 invoice
  (`lnbc…`, `lntb…`, `lnbcrt…`, with or without `lightning:`) is rejected with an explanation;
  BOLT 12 strings are rejected as unsupported in schema 1.
* Bitcoin addresses get a **sanity check only** – character set, length and prefix versus
  network. The checksum is *not* verified here; the payments subsystem validates fully before any
  payment request is built. Nothing in `publishing` imports `payments`, contacts a payment
  endpoint or initiates a payment (a unit test enforces the import rule).
* Strings must be Unicode NFC without control characters. `build_manifest()` (used for user
  input) trims, NFC-normalises and lowercases Lightning addresses before validating;
  `parse_manifest()` (used for untrusted input) only validates.

### Canonical form

Used for storage and signing: UTF-8 JSON, no insignificant whitespace (`,` and `:` separators),
members sorted by key (all keys are ASCII), absent optional members omitted (no `null`), integers
only (floats, exponents and `NaN` are rejected when parsing), duplicate members rejected,
non-ASCII characters written literally, only `"`, `\` and newline escaped, hex in lowercase.
Parsing a canonical document and re-serialising it yields the same bytes.

### Provenance

| Provenance | Meaning |
| --- | --- |
| `embedded` | Found inside the torrent's info dictionary (key `x-aureom-publisher`). It is covered by the info-hash, so it is the manifest the torrent's creator shipped. **Preferred when provenance matters.** |
| `local` | Written on this device by the wizard (carries the torrent identity). |
| `external` | Imported from a file or fetched from a URL by explicit user action. **Untrusted**; if it names a torrent it must match the transfer it is attached to. |

The embedded copy **omits the `torrent` member**: the info-hash is computed over the dictionary
that contains the manifest, so the manifest cannot contain it. Being inside the info dictionary
is the binding. Embedding a manifest therefore changes the torrent's info-hash; it cannot be
added afterwards.

`record_embedded_manifest(metadata, transfer_id)` stores a valid embedded manifest when a torrent
is added (invalid ones are ignored); `import_manifest` / `fetch_manifest` store external ones.
`fetch_manifest` uses the publishing network policy and caps the response at 16 KiB.

### Signatures versus trust

Signatures are **Ed25519** (the `cryptography` library) over the canonical bytes of the manifest
*without* its `signature` member. The embedded and the full (identity-bearing) forms are signed
separately because they are different byte strings.

Two questions are kept strictly apart:

1. *Is the signature valid?* – `SignatureStatus`: `unsigned`, `valid`, `invalid`.
2. *Do I have a reason to believe who signed it?* – `TrustLevel`, from `assess_trust(manifest,
   pinned_keys)`:

| Trust level | Shown as | When |
| --- | --- | --- |
| `self_asserted` | "self-asserted" | no signature |
| `signed_unrecognised` | "signed by unrecognised key (self-asserted)" | valid signature, key not pinned |
| `pinned_key` | "verified against a key you pinned" | valid signature by a key in the user's local pin list |
| `invalid_signature` | "signature invalid — treat as untrusted" | signature does not match |

A valid signature shows that the bytes were not altered after signing. It does **not** show who
holds the key. **Key distribution is out of band:** there is no key server or web of trust. A key
becomes trusted only when the user pins it (`pin_key(public_key, label)`), having obtained it
through a channel they trust – and "verified" then means exactly "matches the key you pinned".
Pinning never rescues an invalid signature.

The publisher's own signing key is generated only on request (ticking *sign* in the wizard, or
`create_signing_key()`), and is stored **only** in the OS credential store
(`manifest-signing-key`). If no OS store is available it lives in memory for the session, and
signatures made with it cannot be reproduced later; the UI should say so
(`diagnostics()["credential_store"]`).

## 5. Diagnostics

`PublishService.diagnostics()` returns job counts by state, recent jobs (state, format, sizes,
redacted error, names of failed operations), destinations with display-safe targets (scheme,
host and path only) and whether a token is stored, manifest counts by provenance, the number of
pinned keys and whether a signing key exists. It never contains magnets, tracker URLs (which may
carry passkeys), tokens, signed URLs or key material. Adapter messages are passed through the
redactor before being stored.

## 6. Demonstration

```bash
python scripts/demo_publish.py --out ./demo-output/publish --sign
```

creates a synthetic folder and, for v1, v2 and hybrid in turn, builds the torrent with the real
libtorrent creator and writes the .torrent, QR SVG/PNG, static page, Atom entry, manifest and
share text. It uses an in-memory database and no transfer engine: nothing is uploaded or seeded.

## 7. Tests

```bash
python -m pytest tests/unit/test_publish_*.py tests/unit/test_manifest_*.py \
    tests/adapter/test_publish_*.py tests/integration/test_publish_*.py -q
```

* unit: manifest validation, canonicalisation, signing and trust labels; QR capacity fallback;
  static page (no scripts or remote resources, hostile names escaped); Atom export parsed with
  feedparser; option validation; exclusive file output.
* adapter (fakes): job lifecycle, cancellation, no silent overwrite, interrupted-job recovery,
  seeding hand-off, per-operation publish records, token handling, diagnostics.
* integration: real creation for v1, v2 and hybrid; symlink exclusion with real links; HTTPS
  upload adapter against a local `http.server` (loopback and http explicitly allowed in the
  test policy only).

## 8. Known limitations

* No S3-compatible adapter; no built-in public hosting of any kind.
* Uploads are single `PUT` requests of at most 32 MiB – suitable for .torrent files, pages and
  feeds, not for payload data.
* BEP 17 web seeds, BEP 47 padding attributes beyond what the engine emits, and BEP 52 symlink
  entries are not offered.
* A torrent cannot be renamed and seeded in place at the same time.
* The QR capacity cap is a conservative design choice, not a measured scan-success threshold.
* Manifest signing has no key rotation or revocation; replacing the key means re-pinning by
  recipients.
* Interrupted hashing is not resumed; the job is recreated from scratch.
