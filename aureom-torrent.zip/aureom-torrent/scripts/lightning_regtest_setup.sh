#!/usr/bin/env bash
# AUREOM TORRENT - local Lightning test environment (Bitcoin regtest, two LND nodes).
#
# STATUS: NOT EXECUTED in the build environment of this release. bitcoind and lnd
# could not be downloaded there (outbound access to bitcoincore.org and GitHub
# release assets was blocked), so this script is provided as documented,
# reviewable setup steps. Read it before running it; adjust versions/paths.
#
# Topology
#   bitcoind (regtest, RPC 18443, ZMQ 28332/28333)
#     |-- alice (lnd)  REST https://127.0.0.1:8081  p2p 9735  rpc 10009   <- the app's backend (payer)
#     `-- bob   (lnd)  REST https://127.0.0.1:8082  p2p 9736  rpc 10010   <- "publisher" (payee)
#   One channel alice -> bob, 1 000 000 sat, funded from regtest coinbase.
#
# No real funds are involved: regtest coins have no value and the chain is local.
#
# Prerequisites (install yourself, verify signatures):
#   - Bitcoin Core >= 25  (bitcoind, bitcoin-cli)  https://bitcoincore.org/en/download/
#   - LND >= 0.18         (lnd, lncli)             https://github.com/lightningnetwork/lnd/releases
#     (latest release when this was written: v0.21.8-beta)
#   - xxd, and free ports as listed above.
#
# Usage:
#   scripts/lightning_regtest_setup.sh start     # start everything, fund, open channel, print env vars
#   scripts/lightning_regtest_setup.sh stop      # stop all three daemons
#   scripts/lightning_regtest_setup.sh env       # print the env vars for the integration test again
set -euo pipefail

ROOT="${AUREOM_REGTEST_DIR:-$HOME/.aureom-regtest}"
BTC_DIR="$ROOT/bitcoind"
ALICE_DIR="$ROOT/alice"
BOB_DIR="$ROOT/bob"
RPC_USER="aureom"
RPC_PASS="regtest-only-not-a-secret"

bcli()  { bitcoin-cli -regtest -datadir="$BTC_DIR" -rpcuser="$RPC_USER" -rpcpassword="$RPC_PASS" "$@"; }
alice() { lncli --network=regtest --lnddir="$ALICE_DIR" --rpcserver=127.0.0.1:10009 "$@"; }
bob()   { lncli --network=regtest --lnddir="$BOB_DIR"   --rpcserver=127.0.0.1:10010 "$@"; }

need() { command -v "$1" >/dev/null 2>&1 || { echo "missing prerequisite: $1" >&2; exit 1; }; }

start_bitcoind() {
  mkdir -p "$BTC_DIR"
  bitcoind -regtest -daemon -datadir="$BTC_DIR" -server=1 -txindex=1 -fallbackfee=0.0002 \
    -rpcuser="$RPC_USER" -rpcpassword="$RPC_PASS" -rpcbind=127.0.0.1 -rpcallowip=127.0.0.1 \
    -zmqpubrawblock=tcp://127.0.0.1:28332 -zmqpubrawtx=tcp://127.0.0.1:28333
  for _ in $(seq 1 30); do bcli getblockchaininfo >/dev/null 2>&1 && break; sleep 1; done
  bcli -named createwallet wallet_name=miner >/dev/null 2>&1 || bcli loadwallet miner >/dev/null 2>&1 || true
}

start_lnd() { # name dir rest p2p rpc
  local name="$1" dir="$2" rest="$3" p2p="$4" rpc="$5"
  mkdir -p "$dir"
  # --noseedbackup: regtest convenience ONLY (no wallet password, no seed backup). Never use on mainnet.
  nohup lnd --lnddir="$dir" --alias="$name" --noseedbackup \
    --bitcoin.regtest --bitcoin.node=bitcoind \
    --bitcoind.rpchost=127.0.0.1:18443 --bitcoind.rpcuser="$RPC_USER" --bitcoind.rpcpass="$RPC_PASS" \
    --bitcoind.zmqpubrawblock=tcp://127.0.0.1:28332 --bitcoind.zmqpubrawtx=tcp://127.0.0.1:28333 \
    --listen=127.0.0.1:"$p2p" --rpclisten=127.0.0.1:"$rpc" --restlisten=127.0.0.1:"$rest" \
    --tlsextraip=127.0.0.1 >"$dir/lnd.out" 2>&1 &
  echo "started lnd '$name' (REST https://127.0.0.1:$rest)"
}

wait_synced() { # cli-function
  for _ in $(seq 1 60); do
    if "$1" getinfo 2>/dev/null | grep -q '"synced_to_chain": *true'; then return 0; fi
    sleep 1
  done
  echo "node did not sync in time" >&2; exit 1
}

bake() { # cli-function -> prints hex of a least-privilege macaroon for the application
  local tmp; tmp="$(mktemp)"
  "$1" bakemacaroon --save_to "$tmp" info:read invoices:read invoices:write offchain:read offchain:write >/dev/null
  xxd -ps -u -c 10000 "$tmp"; rm -f "$tmp"
}

print_env() {
  cat <<EOF

# --- environment for: python -m pytest -m lightning_regtest tests/integration/test_payment_lnd_regtest.py
export AUREOM_LND_URL=https://127.0.0.1:8081
export AUREOM_LND_TLS_CERT=$ALICE_DIR/tls.cert
export AUREOM_LND_MACAROON_HEX=$(bake alice)
export AUREOM_LND_PAYEE_URL=https://127.0.0.1:8082
export AUREOM_LND_PAYEE_TLS_CERT=$BOB_DIR/tls.cert
export AUREOM_LND_PAYEE_MACAROON_HEX=$(bake bob)
# In the application: Settings -> Payments -> backend "LND (REST)", URL https://127.0.0.1:8081,
# TLS certificate $ALICE_DIR/tls.cert, network "regtest", and paste the first macaroon above.
EOF
}

cmd="${1:-}"
case "$cmd" in
  start)
    for tool in bitcoind bitcoin-cli lnd lncli xxd; do need "$tool"; done
    start_bitcoind
    miner_addr="$(bcli -rpcwallet=miner getnewaddress)"
    bcli generatetoaddress 101 "$miner_addr" >/dev/null          # mature one coinbase
    start_lnd alice "$ALICE_DIR" 8081 9735 10009
    start_lnd bob   "$BOB_DIR"   8082 9736 10010
    wait_synced alice; wait_synced bob

    # Fund alice on-chain with 2 regtest BTC and confirm it.
    alice_addr="$(alice newaddress p2wkh | sed -n 's/.*"address": *"\([^"]*\)".*/\1/p')"
    bcli -rpcwallet=miner sendtoaddress "$alice_addr" 2 >/dev/null
    bcli generatetoaddress 6 "$miner_addr" >/dev/null
    wait_synced alice

    # Open a 1 000 000 sat channel alice -> bob and confirm it.
    bob_pubkey="$(bob getinfo | sed -n 's/.*"identity_pubkey": *"\([^"]*\)".*/\1/p')"
    alice connect "${bob_pubkey}@127.0.0.1:9736" >/dev/null || true
    alice openchannel --node_key "$bob_pubkey" --local_amt 1000000 >/dev/null
    bcli generatetoaddress 6 "$miner_addr" >/dev/null
    for _ in $(seq 1 60); do
      alice listchannels | grep -q '"active": *true' && break; sleep 1
    done
    echo "channel alice -> bob is active"
    print_env
    ;;
  env)
    print_env
    ;;
  stop)
    alice stop >/dev/null 2>&1 || true
    bob stop >/dev/null 2>&1 || true
    bcli stop >/dev/null 2>&1 || true
    echo "stopped. Data kept in $ROOT (delete it to start from scratch)."
    ;;
  *)
    sed -n '2,32p' "$0"
    exit 2
    ;;
esac
