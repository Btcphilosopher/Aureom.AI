"""Developer tool: start the real application against a loopback seeder, then save screenshots of
every workspace (light and dark).  Uses synthetic data only.

    QT_QPA_PLATFORM=offscreen python scripts/ui_tour.py OUTPUT_DIR
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PySide6.QtCore import QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from aureom_torrent.app import AppContext  # noqa: E402
from aureom_torrent.domain.transfers import TransferState  # noqa: E402
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec  # noqa: E402
from aureom_torrent.settings.secrets import MemorySecretStore  # noqa: E402
from aureom_torrent.ui.main_window import MainWindow  # noqa: E402
from tests.support import Node, create_torrent, make_payload  # noqa: E402


def pump(app: QApplication, seconds: float) -> None:
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        app.processEvents()
        time.sleep(0.02)


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "ui-tour")
    out.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="aureom-tour-"))
    app = QApplication(sys.argv[:1])

    seeder = Node(work / "seeder").start()
    torrents = {}
    for name, files, fmt in (("open-dataset-2026", {"data/part-1.csv": 2_400_000, "data/part-2.csv": 1_900_000,
                                                    "README.txt": 4_000, "LICENCE.txt": 7_000}, "hybrid"),
                             ("field-recordings-cc0", {"dawn-chorus.flac": 5_000_000, "notes.txt": 2_000}, "v2"),
                             ("manual-en-v3", {"manual.pdf": 900_000}, "v1"),
                             ("map-tiles-sample", {"z1/0.png": 300_000, "z1/1.png": 320_000, "index.json": 1_000}, "hybrid")):
        payload = make_payload(work / "seed-data" / name, files, seed=name)
        created = create_torrent(payload, fmt)
        tid = seeder.service.add_torrent_data(created.torrent_data, save_path=str(work / "seed-data")).transfer_id
        seeder.wait_state(tid, TransferState.SEEDING)
        torrents[name] = created

    ctx = AppContext(work / "home", isolated=True, secrets=MemorySecretStore())
    settings = ctx.settings.snapshot()
    settings.general.default_save_path = str(work / "Downloads")
    ctx.settings.save(settings)
    ctx.start()
    window = MainWindow(ctx)
    window.resize(1360, 860)
    window.show()
    pump(app, 1.0)

    dl = work / "Downloads"
    dl.mkdir(exist_ok=True)
    svc = ctx.transfers
    a = svc.add_torrent_data(torrents["open-dataset-2026"].torrent_data, save_path=str(dl), category="Documents").transfer_id
    svc.set_limits(a, download_limit=350_000)
    b = svc.add_torrent_data(torrents["manual-en-v3"].torrent_data, save_path=str(dl), category="Documents").transfer_id
    c = svc.add_torrent_data(torrents["field-recordings-cc0"].torrent_data, save_path=str(dl), category="Media",
                             paused=True).transfer_id
    magnet = LibtorrentCodec().make_magnet(torrents["map-tiles-sample"].torrent_data)
    d = svc.add_magnet(magnet, save_path=str(dl), preview=True).transfer_id
    window._review_open.add(d)  # keep the (modal) review dialog from opening during the scripted tour
    for tid in (a, b, d):
        svc.connect_peer(tid, "127.0.0.1", seeder.port)
    # a local seed of our own (created torrent), to show seeding
    own = make_payload(work / "Shared" / "press-kit", {"logo.svg": 40_000, "photos/team.jpg": 800_000}, seed="own")
    job_draft = None
    pump(app, 4.0)
    window.transfers_page.table.selectRow(0)
    pump(app, 1.5)

    def shot(name: str) -> None:
        pump(app, 0.6)
        window.grab().save(str(out / f"{name}.png"))
        print("saved", name)

    shot("01-transfers-light")
    for index, tab in enumerate(("overview", "files", "peers", "trackers", "pieces", "activity", "publisher")):
        window.transfers_page.tabs.setCurrentIndex(index)
        pump(app, 1.4)
        if tab in ("files", "pieces", "activity"):
            shot(f"02-details-{tab}")
    window.transfers_page.tabs.setCurrentIndex(0)

    # publishing: run a real job through the service, then show the share screen
    from aureom_torrent.publishing.models import PublishDraft, PublisherInfo

    scan = ctx.publishing.scan(str(own))
    draft = PublishDraft(source_path=str(own), included_files=[f.relative for f in scan.files], format="hybrid",
                         trackers_text="udp://tracker.example.org:6969/announce",
                         publisher=PublisherInfo(name="Example Press Office", website="https://example.org",
                                                 lightning_address="tips@example.org", licence="CC-BY-4.0"),
                         output_torrent_path=str(work / "Shared" / "press-kit.torrent"), start_seeding=True)
    job = ctx.publishing.start_job(draft)
    window.navigate("publish")
    pump(app, 0.5)
    window.publish_page.set_source(str(own))
    pump(app, 1.0)
    shot("03-publish-select")
    window.publish_page._go(2)
    window.publish_page.trackers.setPlainText("udp://tracker.example.org:6969/announce")
    shot("04-publish-trackers")
    window.publish_page._open_share(job.id)
    pump(app, 2.5)
    shot("05-publish-share")

    # feeds: the bundled demo server
    import subprocess

    server = subprocess.Popen([sys.executable, str(Path(__file__).parent / "demo_feed_server.py"), "--port", "18765"],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(1.5)
        settings = ctx.settings.snapshot()
        settings.feeds_network.allow_loopback = True
        ctx.settings.save(settings)
        for path, folder in (("rss.xml", "Open data"), ("atom.xml", "")):
            feed = ctx.feeds.add_feed(f"http://127.0.0.1:18765/{path}", folder=folder)
            ctx.feeds.refresh_feed(feed.id)
        window.navigate("feeds")
        pump(app, 1.5)
        window.feeds_page.entries.selectRow(0)
        shot("06-feeds")
    finally:
        server.terminate()

    window.navigate("payments")
    pump(app, 1.0)
    shot("07-payments")
    window.navigate("settings")
    for index, name in ((1, "queue"), (2, "bittorrent"), (4, "payments"), (6, "privacy")):
        window.settings_page.tabs.setCurrentIndex(index)
        shot(f"08-settings-{name}")

    settings = ctx.settings.snapshot()
    settings.ui.theme = "dark"
    settings.ui.density = "comfortable"
    ctx.settings.save(settings)
    window.apply_theme()
    window.navigate("all")
    pump(app, 1.0)
    window.transfers_page.table.selectRow(1)
    shot("09-transfers-dark-comfortable")
    window.navigate("feeds")
    shot("10-feeds-dark")

    window.close()
    pump(app, 4.0)
    seeder.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
