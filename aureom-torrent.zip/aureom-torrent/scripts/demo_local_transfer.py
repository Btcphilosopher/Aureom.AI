"""Local transfer demonstration (no GUI, no public network).

Two complete application back ends run in this process, each with its own data
directory and its own real libtorrent session bound to 127.0.0.1 with DHT,
local discovery and port mapping switched off.  The "publisher" creates a
torrent from synthetic files and seeds it; the "downloader" adds the magnet
link, previews the metadata, selects files, downloads, is paused, shut down,
restarted and resumed, and the result is compared byte for byte.

    python scripts/demo_local_transfer.py [--format v1|v2|hybrid] [--keep DIR]
"""

from __future__ import annotations

import argparse
import shutil
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aureom_torrent.domain.transfers import TransferState  # noqa: E402
from aureom_torrent.engine.libtorrent_codec import LibtorrentCodec  # noqa: E402
from tests.support import Node, create_torrent, make_payload, sha256_file  # noqa: E402


def say(step: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {step}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--format", choices=("v1", "v2", "hybrid"), default="hybrid")
    parser.add_argument("--keep", help="keep the working directory at this path")
    args = parser.parse_args()
    work = Path(args.keep) if args.keep else Path(tempfile.mkdtemp(prefix="aureom-demo-"))
    work.mkdir(parents=True, exist_ok=True)
    files = {"dataset/part-1.bin": 4_000_000, "dataset/part-2.bin": 2_500_000, "README.txt": 3_000}
    payload = make_payload(work / "publisher-files" / "open-sample", files, seed="demo")
    say(f"synthetic payload: {len(files)} files, {sum(files.values()):,} bytes")

    created = create_torrent(payload, args.format)
    magnet = LibtorrentCodec().make_magnet(created.torrent_data)
    say(f"created {created.metadata.identity.kind} torrent, {created.metadata.num_pieces} pieces")
    say(f"magnet: {magnet}")

    publisher = Node(work / "publisher-home").start()
    seed_id = publisher.service.add_torrent_data(created.torrent_data, save_path=str(payload.parent),
                                                 source="created").transfer_id
    publisher.wait_state(seed_id, TransferState.SEEDING)
    say(f"publisher is seeding on 127.0.0.1:{publisher.port} (files verified by the engine first)")

    dest = work / "downloads"
    downloader = Node(work / "downloader-home").start()
    tid = downloader.service.add_magnet(magnet, save_path=str(dest), preview=True).transfer_id
    downloader.connect(tid, publisher)
    say("downloader added the magnet: " + downloader.wait_state(tid, TransferState.RETRIEVING_METADATA).state.label)
    downloader.wait(lambda: downloader.service.metadata(tid) is not None, 30, "metadata")
    meta = downloader.service.metadata(tid)
    view = downloader.view(tid)
    say(f"metadata retrieved: {[f.path for f in meta.real_files]}; payload bytes downloaded so far: {view.downloaded}")
    assert view.downloaded == 0 and not dest.exists(), "metadata preview must not download payload"

    downloader.service.confirm_preview(tid, save_path=str(dest))
    downloader.wait(lambda: not downloader.view(tid).preview, 10, "confirmation")
    downloader.service.set_limits(tid, download_limit=1_500_000)
    downloader.connect(tid, publisher)
    downloader.wait(lambda: 150_000 < downloader.view(tid).progress_ppm < 900_000, 60, "partial download")
    downloader.service.pause([tid])
    paused = downloader.wait_state(tid, TransferState.PAUSED)
    say(f"paused by the user at {paused.progress_ppm / 10_000:.1f}% verified")
    report = downloader.stop()
    say(f"downloader closed: clean={report.clean}, resume data saved for {report.resume_saved} transfer(s)")

    downloader = Node(work / "downloader-home").start()
    again = downloader.wait_state(tid, TransferState.PAUSED)
    say(f"downloader restarted: still paused, {again.progress_ppm / 10_000:.1f}% verified (no re-download)")
    downloader.service.set_limits(tid, download_limit=0)
    downloader.service.resume([tid])
    downloader.connect(tid, publisher)
    done = downloader.wait_state(tid, TransferState.SEEDING, timeout=120)
    say(f"download complete: selected files complete={done.selected_complete}, entire torrent={done.torrent_complete}")

    ok = True
    for rel in files:
        same = sha256_file(dest / "open-sample" / rel) == sha256_file(payload / rel)
        ok &= same
        say(f"  {'identical' if same else 'DIFFERENT'}: {rel}")
    downloader.stop()
    publisher.stop()
    if not args.keep:
        shutil.rmtree(work, ignore_errors=True)
    say("RESULT: byte-for-byte match" if ok else "RESULT: MISMATCH")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
