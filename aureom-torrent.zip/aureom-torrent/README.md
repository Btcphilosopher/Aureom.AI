# AUREOM TORRENT

*Code at the speed of civilisation.*

A desktop BitTorrent application: discover or receive a link → preview → choose files and
destination → download → verify → seed → share → optionally support the publisher.

* Real engine: libtorrent 2.1.3 (BitTorrent v1, v2 and hybrid torrents).
* Qt interface (PySide6): transfers table with details tabs, RSS/Atom reader, Publish & Share
  wizard, Payments, Settings; light and dark themes.
* RSS/Atom subscriptions with opt-in, bounded download rules.
* Torrent creation, magnet + QR sharing, static publisher page and Atom entry export.
* Optional publisher support: Bitcoin BIP21 hand-off to an external wallet, and Lightning through
  your own LND node. **Transfers work without any wallet.**

**Status: a working first release, not production-hardened.** See [Known limitations](#known-limitations)
and [What was and was not executed](#what-was-and-was-not-executed).

## Supported platform

Developed and tested on one combination (details in [docs/tested-platforms.md](docs/tested-platforms.md)):

| | |
|---|---|
| OS | Ubuntu 24.04 LTS, x86-64 |
| Python | CPython 3.12 |
| Engine | libtorrent 2.1.3 (PyPI wheel) |
| UI | PySide6-Essentials 6.12.0 |

Wheels for the binary dependencies also exist for Python 3.11 and 3.13 and for Windows/macOS, but
**no other combination was tested**.

## Install and run

```bash
python3.12 -m venv .venv
```

```bash
. .venv/bin/activate
```

Reproducible install (exact versions that were tested), then the application itself:

```bash
pip install -r requirements.lock
```

```bash
pip install --no-deps -e .
```

Or let pip resolve within the declared ranges: `pip install -e ".[dev]"`.

On a minimal Linux system Qt needs a few system libraries
(`sudo apt-get install libegl1 libgl1 libxkbcommon0 libfontconfig1 libdbus-1-3 libxcb-cursor0`).

```bash
python -m aureom_torrent
```

Options: `--data-dir DIR` (default: `~/.local/share/aureom-torrent`), `--log-to-console`,
`--local-demo` (labelled demo mode: the real engine restricted to loopback), `--self-check`
(start, run two seconds, shut down, print a JSON report), and any number of `.torrent` paths or
magnet links to add.

## Demonstrations (synthetic data only, no public network)

**Local transfer** – two isolated application back ends in one process; magnet metadata preview,
download, pause, shutdown, restart, resume, byte-for-byte comparison:

```bash
python scripts/demo_local_transfer.py --format hybrid
```

**Torrent creation and sharing** – creates v1, v2 and hybrid torrents from a synthetic folder and
writes the magnet, QR (SVG/PNG), static page, Atom entry and manifest:

```bash
python scripts/demo_publish.py --out /tmp/aureom-publish-demo
```

**RSS/Atom** – a local feed server with ETag / Last-Modified / 304 support and real `.torrent`
enclosures and magnets for synthetic CC0 files:

```bash
python scripts/demo_feed_server.py --port 8765
```

Then, in the application, allow loopback under *Settings → Service networks → RSS* and subscribe to
`http://127.0.0.1:8765/rss.xml` or `/atom.xml`. `POST /publish` on the server appends an item.

**In the GUI with a local peer** – run one instance as a seeder and one as a downloader, each with
its own `--data-dir` and `--local-demo`; add the seeder under *Peers* by adding the magnet with an
`x.pe=127.0.0.1:<port>` parameter (the seeder's port is shown in its status bar).

**Payments** – see [docs/payments.md](docs/payments.md) for connecting an LND node and for the
regtest topology. No Lightning node could be run in the build environment, so the test-network
payment demonstration was **not executed**; the fake-backend and mocked-transport suites were.

## Tests

```bash
python -m pytest -q
```

| Suite | Tests | What it uses |
|---|---|---|
| `tests/unit` | 565 | pure logic: magnets, identities, state mapping, queue rules, paths, persistence, feeds, manifests, payment arithmetic/invoices/state machine, redaction, theme contrast |
| `tests/adapter` | 202 | services against fakes: engine (delayed alerts, metadata, failed moves, shutdown), feed fetcher, publish adapters, Lightning backend (rejection, timeout → unknown, reconciliation, duplicates), LND REST via mocked transport |
| `tests/integration` | 74 | real libtorrent sessions on loopback (v1, v2, hybrid run separately); real local HTTP servers for feeds, uploads and LNURL; restart recovery |
| `tests/gui` | 7 | the real window on a fake engine, Qt offscreen |

Last full run on the supported platform: **844 passed, 4 skipped in 83.6 s** with
`-W error::DeprecationWarning`. The 4 skipped tests are the LND regtest checks
(`tests/integration/test_payment_lnd_regtest.py`), which need a running node.

## Keyboard shortcuts

| Keys | Action |
|---|---|
| Ctrl+O | Add torrent file(s) |
| Ctrl+Shift+O | Add magnet link |
| Ctrl+V (table focused) | Paste a magnet link |
| Ctrl+N | Create torrent (Publish & Share) |
| Ctrl+S / Ctrl+P | Start / pause selected transfers |
| Delete | Remove selected transfers… |
| Ctrl+A | Select all transfers |
| Ctrl+F | Search transfers |
| Ctrl+1 … Ctrl+7 | All, Downloading, Seeding, Completed, Paused, Checking, Errors |
| Ctrl+8 / Ctrl+9 / Ctrl+0 | RSS Feeds / Publish & Share / Payments |
| Ctrl+, | Settings |
| F6 / Shift+F6 | Move focus between navigation, table and details |
| Alt+Left / Alt+Right | Previous / next details tab |
| F5 | Refresh the selected feed |
| Ctrl+Q | Quit |

Tab / Shift+Tab move between controls, arrow keys move inside tables, Space toggles check boxes,
and the context-menu key opens a row's actions. Buttons and form fields have Alt mnemonics.

## Documentation

* [docs/architecture.md](docs/architecture.md) – layers, threads, command/event bridge, lifecycle model, persistence
* [docs/protocol-support.md](docs/protocol-support.md) – protocol-support matrix and engine limitations
* [docs/feeds.md](docs/feeds.md) – reader, deduplication, baseline, rules, review queue
* [docs/publishing.md](docs/publishing.md) – wizard, manifests (format, canonicalisation, signatures, trust), sharing, adapters
* [docs/payments.md](docs/payments.md) – scope, LND setup, state machine, reconciliation, rounding, regtest
* [docs/privacy.md](docs/privacy.md) – what others can see, per-service networks, interface binding limits, diagnostics
* [docs/packaging.md](docs/packaging.md) – wheel, PyInstaller bundle, file/URI association, licences
* [docs/tested-platforms.md](docs/tested-platforms.md) – tested-platform matrix and actual results

## What was and was not executed

Executed in the build environment (Ubuntu 24.04, Python 3.12, headless):

* the full automated suite above;
* the three demonstration scripts;
* the real GUI under Qt's offscreen platform (`scripts/ui_tour.py` drives every workspace against a
  loopback seeder and saves screenshots; `--self-check`);
* a PyInstaller one-folder build, and that build's `--self-check`.

**Not executed:**

* any transfer over the public network (trackers, DHT, peer exchange, local discovery, port
  mapping, proxies, web-seed downloads) – outbound peer traffic was not available;
* Lightning payments against a real node (bitcoind/LND binaries could not be downloaded) and
  therefore three defensively handled LND behaviours listed in docs/payments.md;
* the OS credential store (no Secret Service in the container; the in-memory fallback was used);
* an interactive session on a real display, a screen reader, or high-DPI scaling;
* Windows and macOS in any form; file/URI association on any platform.

## Known limitations

* v2/hybrid magnets: a complete `.torrent` can be exported only after the payload is verified.
* Peer exchange on/off, and the listening port, take effect at the next start for PEX; other
  network settings apply live.
* No tracker merging when a duplicate torrent is added (the existing transfer is left untouched);
  trackers can be edited by hand.
* Feed rules match titles only; the daily budget is per UTC day; no HTTP auth for private feeds.
* Publishing: no S3 adapter; interrupted hashing is not resumed; an accepted upload is not proof of
  public availability.
* Payments: one Lightning backend (LND REST); no on-chain tracking at all (a BIP21 hand-off stays
  "outcome not tracked"); no recurring support; LNURL-pay only in its basic form.
* Interface binding is a safeguard with documented gaps, not a kill-switch guarantee.
* Reduced-motion detection is automatic on Windows only; elsewhere use the setting.
* DNS-rebinding is not defended against in the RSS/publishing destination checks.
* The file list in the add dialog is flat (no folder tree); bandwidth schedules have a simple editor.
* No remote control, no search plug-ins, no sequential download, no super-seeding.

## Licence

Application code: MIT. Third-party components and their licences are listed in
[docs/packaging.md](docs/packaging.md); note that PySide6/Qt is LGPL-3.0 and must stay replaceable
in any redistributed bundle.

## Screenshots

Captured from the real application (Qt offscreen platform) by `scripts/ui_tour.py`, with synthetic
data and a loopback seeder: see `docs/screenshots/`.
