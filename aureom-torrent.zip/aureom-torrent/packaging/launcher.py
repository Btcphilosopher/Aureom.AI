"""Entry script for frozen builds (PyInstaller runs a script, not ``python -m``)."""

from aureom_torrent.__main__ import main

if __name__ == "__main__":
    raise SystemExit(main())
