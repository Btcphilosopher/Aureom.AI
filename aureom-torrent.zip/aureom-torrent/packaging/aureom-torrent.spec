# PyInstaller spec for AUREOM TORRENT (one-folder build).
#   pip install ".[package]"
#   pyinstaller --noconfirm --distpath dist --workpath build packaging/aureom-torrent.spec
# The result is dist/aureom-torrent/ (run dist/aureom-torrent/aureom-torrent).
import os
from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs, collect_submodules

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))

datas = collect_data_files("aureom_torrent", includes=["persistence/migrations/*.sql"])
datas += collect_data_files("segno")
datas += [(os.path.join(ROOT, "resources"), "resources")]
hiddenimports = collect_submodules("keyring.backends") + ["aureom_torrent.persistence"]
# bitstring (a dependency of bolt11) selects its storage back end with importlib at import time.
hiddenimports += collect_submodules("bitstring") + collect_submodules("bitarray")
# coincurve (secp256k1 for BOLT11 signatures) ships its own cffi backend inside the package.
hiddenimports += ["coincurve._cffi_backend", "coincurve._libsecp256k1"]
binaries = collect_dynamic_libs("coincurve")

a = Analysis(
    [os.path.join(ROOT, "packaging", "launcher.py")],
    pathex=[os.path.join(ROOT, "src")],
    datas=datas,
    binaries=binaries,
    hiddenimports=hiddenimports,
    excludes=["tkinter", "pytest", "PySide6.QtWebEngineCore", "PySide6.QtQml", "PySide6.QtQuick"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="aureom-torrent", console=False,
          icon=None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="aureom-torrent")
