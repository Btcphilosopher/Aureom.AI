import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini SDK with User-Agent header
const getGeminiClient = () => {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Healthcheck endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    service: "Referent Harvard Referencing Engine",
    version: "1.0.0",
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Endpoint: AI Metadata Lookup by DOI / ISBN / Title / Abstract
app.post("/api/gemini/lookup", async (req, res) => {
  try {
    const { query, type } = req.body;
    if (!query) {
      return res.status(400).json({ error: "Search query is required." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "Gemini API Key is not configured in server environment.",
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `Search and extract complete academic publication metadata for: "${query}" (Type hint: ${type || "auto"}). 
If this is a DOI, ISBN, title, or citation snippet, resolve it into structured fields according to academic publication standards.`,
      config: {
        systemInstruction: `You are Referent's bibliographic metadata extraction system.
Output valid JSON matching the exact schema. Ensure author names are in 'Lastname, Initials' format (e.g. 'Smith, J. A.').
For dates, if year is unknown, use 'n.d.'. Choose referenceType strictly from: 'journal_article', 'book', 'conference_paper', 'government_report', 'website', 'thesis', 'dataset', 'patent', 'newspaper', 'magazine', 'video', 'podcast', 'legislation', 'court_case', 'standard', 'company_report', 'technical_manual', 'personal_communication'.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            referenceType: { type: Type.STRING },
            title: { type: Type.STRING },
            authors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  lastName: { type: Type.STRING },
                  firstName: { type: Type.STRING },
                  initials: { type: Type.STRING },
                  isCorporate: { type: Type.BOOLEAN },
                },
                required: ["lastName"],
              },
            },
            year: { type: Type.STRING },
            journalName: { type: Type.STRING },
            volume: { type: Type.STRING },
            issue: { type: Type.STRING },
            pages: { type: Type.STRING },
            publisher: { type: Type.STRING },
            publisherLocation: { type: Type.STRING },
            doi: { type: Type.STRING },
            isbn: { type: Type.STRING },
            url: { type: Type.STRING },
            accessDate: { type: Type.STRING },
            abstract: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["referenceType", "title", "authors", "year"],
        },
      },
    });

    const jsonText = response.text ? response.text.trim() : "{}";
    const parsed = JSON.parse(jsonText);
    res.json({ success: true, metadata: parsed });
  } catch (err: any) {
    console.error("Gemini lookup error:", err);
    res.status(500).json({ error: err.message || "Failed to lookup paper metadata" });
  }
});

// Endpoint: Analyze PDF / Text Content for Citations & Summaries
app.post("/api/gemini/analyze-pdf", async (req, res) => {
  try {
    const { text, fileName } = req.body;
    if (!text) {
      return res.status(400).json({ error: "PDF text content is required." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "Gemini API Key is not configured.",
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `Analyze the following academic document text from file "${fileName || "document.pdf"}":\n\n${text.slice(0, 8000)}`,
      config: {
        systemInstruction: `You are an expert academic research assistant and bibliographer.
Analyze the document snippet and extract:
1. Precise bibliographic reference details formatted for Harvard Referencing.
2. An executive abstract summary (3 bullet points).
3. Core methodology and key findings.
4. Suggested tags for research organization.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            authors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  lastName: { type: Type.STRING },
                  firstName: { type: Type.STRING },
                  initials: { type: Type.STRING },
                },
                required: ["lastName"],
              },
            },
            year: { type: Type.STRING },
            journalName: { type: Type.STRING },
            publisher: { type: Type.STRING },
            doi: { type: Type.STRING },
            referenceType: { type: Type.STRING },
            summaryBullets: { type: Type.ARRAY, items: { type: Type.STRING } },
            methodology: { type: Type.STRING },
            keyFindings: { type: Type.STRING },
            suggestedTags: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["title", "authors", "year", "summaryBullets"],
        },
      },
    });

    const jsonText = response.text ? response.text.trim() : "{}";
    const parsed = JSON.parse(jsonText);
    res.json({ success: true, analysis: parsed });
  } catch (err: any) {
    console.error("Gemini analyze error:", err);
    res.status(500).json({ error: err.message || "Failed to analyze paper" });
  }
});

// Endpoint: Harvard Citation Rule Auto-Validator
app.post("/api/gemini/validate-harvard", async (req, res) => {
  try {
    const { referenceString, referenceType } = req.body;
    if (!referenceString) {
      return res.status(400).json({ error: "Reference string is required." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "Gemini API Key is not configured.",
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `Evaluate this Harvard citation according to strict Harvard style (Cite Them Right / Standard UK & International Harvard rules):
Citation to audit: "${referenceString}"
Declared Type: ${referenceType || "auto"}`,
      config: {
        systemInstruction: `Check for proper author initials format, parentheses around year, italicization rules, volume/issue formatting, page number ranges (e.g. pp. 12-24), URL access date presence, and punctuation.
Provide a list of errors found (if any), a score out of 100, and the perfect corrected Harvard reference string.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isValid: { type: Type.BOOLEAN },
            score: { type: Type.INTEGER },
            issuesFound: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctedHarvardString: { type: Type.STRING },
            inTextCitationExample: { type: Type.STRING },
            explanation: { type: Type.STRING },
          },
          required: ["isValid", "score", "correctedHarvardString"],
        },
      },
    });

    const jsonText = response.text ? response.text.trim() : "{}";
    const parsed = JSON.parse(jsonText);
    res.json({ success: true, validation: parsed });
  } catch (err: any) {
    console.error("Harvard validation error:", err);
    res.status(500).json({ error: err.message || "Failed to validate citation" });
  }
});

// Vite & Static file handling
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Referent Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
