import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ReferenceList } from './components/ReferenceList';
import { ReferenceDetailModal } from './components/ReferenceDetailModal';
import { ReferenceEditModal } from './components/ReferenceEditModal';
import { HarvardValidatorWidget } from './components/HarvardValidatorWidget';
import { PdfViewerModal } from './components/PdfViewerModal';
import { WordProcessorPluginModal } from './components/WordProcessorPluginModal';
import { ImportExportModal } from './components/ImportExportModal';
import { DashboardAnalytics } from './components/DashboardAnalytics';
import { TechnicalDocsModal } from './components/TechnicalDocsModal';

import { initialReferences, initialProjects } from './data/seedData';
import { Project, Reference, ReferenceNote, ReferenceType } from './types';
import { validateHarvardRules } from './lib/harvardEngine';
import { exportToRIS, downloadFile } from './lib/exporters';

export default function App() {
  // Core Library Data State
  const [references, setReferences] = useState<Reference[]>(initialReferences);
  const [projects, setProjects] = useState<Project[]>(initialProjects);

  // Navigation & Filtering State
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'starred' | 'unread' | 'reading' | 'completed' | 'recent' | 'audit_issues'>('all');
  const [activeTypeFilter, setActiveTypeFilter] = useState<ReferenceType | 'all'>('all');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Panels State
  const [selectedReference, setSelectedReference] = useState<Reference | null>(null);
  const [editingReference, setEditingReference] = useState<Partial<Reference> | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isValidatorOpen, setIsValidatorOpen] = useState(false);
  const [isPdfViewerOpen, setIsPdfViewerOpen] = useState(false);
  const [pdfRef, setPdfRef] = useState<Reference | null>(null);
  const [isWordProcessorOpen, setIsWordProcessorOpen] = useState(false);
  const [isImportExportOpen, setIsImportExportOpen] = useState(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);

  // Filtered References Logic
  const filteredReferences = references.filter((ref) => {
    // Project filter
    if (activeProjectId && ref.projectId !== activeProjectId) return false;

    // View filter
    if (activeFilter === 'starred' && !ref.isStarred) return false;
    if (activeFilter === 'unread' && ref.readingStatus !== 'unread') return false;
    if (activeFilter === 'reading' && ref.readingStatus !== 'reading') return false;
    if (activeFilter === 'completed' && ref.readingStatus !== 'completed') return false;
    if (activeFilter === 'audit_issues') {
      const score = validateHarvardRules(ref).score;
      if (score >= 90) return false;
    }

    // Type filter
    if (activeTypeFilter !== 'all' && ref.referenceType !== activeTypeFilter) return false;

    // Tag filter
    if (activeTag && !ref.tags.includes(activeTag)) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = ref.title.toLowerCase().includes(q);
      const matchAuthor = ref.authors.some(
        (a) =>
          a.lastName.toLowerCase().includes(q) ||
          a.firstName?.toLowerCase().includes(q) ||
          a.corporateName?.toLowerCase().includes(q)
      );
      const matchDoi = ref.doi?.toLowerCase().includes(q);
      const matchTag = ref.tags.some((t) => t.toLowerCase().includes(q));
      const matchJournal = ref.journalName?.toLowerCase().includes(q);

      if (!matchTitle && !matchAuthor && !matchDoi && !matchTag && !matchJournal) return false;
    }

    return true;
  });

  // Reference Operations
  const handleSaveReference = (refToSave: Reference) => {
    const exists = references.some((r) => r.id === refToSave.id);
    if (exists) {
      setReferences(references.map((r) => (r.id === refToSave.id ? refToSave : r)));
      if (selectedReference?.id === refToSave.id) {
        setSelectedReference(refToSave);
      }
    } else {
      setReferences([refToSave, ...references]);
    }
    setIsEditModalOpen(false);
    setEditingReference(null);
  };

  const handleDeleteReference = (id: string) => {
    setReferences(references.filter((r) => r.id !== id));
    if (selectedReference?.id === id) {
      setSelectedReference(null);
    }
  };

  const handleToggleStarred = (id: string) => {
    setReferences(
      references.map((r) => (r.id === id ? { ...r, isStarred: !r.isStarred } : r))
    );
    if (selectedReference?.id === id) {
      setSelectedReference({
        ...selectedReference,
        isStarred: !selectedReference.isStarred,
      });
    }
  };

  const handleUpdateStatus = (id: string, status: 'unread' | 'reading' | 'completed') => {
    setReferences(
      references.map((r) => (r.id === id ? { ...r, readingStatus: status } : r))
    );
    if (selectedReference?.id === id) {
      setSelectedReference({ ...selectedReference, readingStatus: status });
    }
  };

  const handleSaveNote = (refId: string, note: ReferenceNote) => {
    setReferences(
      references.map((r) => {
        if (r.id === refId) {
          return { ...r, notes: [...r.notes, note] };
        }
        return r;
      })
    );
    if (selectedReference?.id === refId) {
      setSelectedReference({
        ...selectedReference,
        notes: [...selectedReference.notes, note],
      });
    }
  };

  const handleImportReferences = (newRefs: Reference[]) => {
    setReferences([...newRefs, ...references]);
  };

  const handleExportSelected = (selectedRefs: Reference[]) => {
    const ris = exportToRIS(selectedRefs);
    downloadFile('selected_harvard_references.ris', ris, 'application/x-research-info-systems');
  };

  // Project Operations
  const handleCreateProject = () => {
    const name = prompt('Enter research project or module title:');
    if (!name) return;

    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name,
      description: 'New academic project folder.',
      color: 'blue',
      createdAt: new Date().toISOString(),
      tags: ['Academic'],
      referenceIds: [],
    };

    setProjects([...projects, newProj]);
    setActiveProjectId(newProj.id);
  };

  const handleLaunchPdfReader = (ref: Reference) => {
    setPdfRef(ref);
    setIsPdfViewerOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-100 dark:bg-stone-950 text-stone-900 dark:text-stone-100 font-sans antialiased selection:bg-amber-200 selection:text-amber-900">
      
      {/* Top Application Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onNewReference={() => {
          setEditingReference({ projectId: activeProjectId || undefined });
          setIsEditModalOpen(true);
        }}
        onOpenValidator={() => setIsValidatorOpen(true)}
        onOpenWordPlugin={() => setIsWordProcessorOpen(true)}
        onOpenImportExport={() => setIsImportExportOpen(true)}
        onOpenAnalytics={() => setIsAnalyticsOpen(true)}
        onOpenDocs={() => setIsDocsOpen(true)}
      />

      {/* Main App Container */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Navigation Sidebar */}
        <Sidebar
          projects={projects}
          activeProjectId={activeProjectId}
          onSelectProject={setActiveProjectId}
          onCreateProject={handleCreateProject}
          activeFilter={activeFilter}
          onSelectFilter={setActiveFilter}
          activeTypeFilter={activeTypeFilter}
          onSelectTypeFilter={setActiveTypeFilter}
          activeTag={activeTag}
          onSelectTag={setActiveTag}
          totalReferences={references.length}
        />

        {/* Main Reference List Workspace */}
        <main className="flex-1 flex flex-col min-w-0 bg-[#0F0F0F] overflow-hidden">
          
          {/* Active Project/View Header Title */}
          <div className="px-8 py-5 flex items-baseline justify-between border-b border-[#1F1F1F]">
            <div>
              <h1 className="text-3xl font-light text-white italic font-serif">
                {activeProjectId
                  ? projects.find((p) => p.id === activeProjectId)?.name || 'Project References'
                  : activeFilter === 'starred'
                  ? 'Starred Publications'
                  : activeFilter === 'audit_issues'
                  ? 'Harvard Audit Warnings'
                  : activeFilter === 'unread'
                  ? 'Unread Papers'
                  : activeFilter === 'reading'
                  ? 'Currently Reading'
                  : activeFilter === 'completed'
                  ? 'Completed Literature'
                  : 'All Academic References'}
              </h1>
              <p className="text-xs text-[#666] mt-1">
                Showing {filteredReferences.length} of {references.length} references
              </p>
            </div>

            <div className="text-xs text-[#555] tracking-widest uppercase font-mono">
              Harvard Standard • 12th Ed.
            </div>
          </div>

          <ReferenceList
            references={filteredReferences}
            onSelectReference={setSelectedReference}
            onEditReference={(ref) => {
              setEditingReference(ref);
              setIsEditModalOpen(true);
            }}
            onDeleteReference={handleDeleteReference}
            onToggleStarred={handleToggleStarred}
            onUpdateStatus={handleUpdateStatus}
            onValidateReference={(ref) => setSelectedReference(ref)}
            onExportSelected={handleExportSelected}
          />
        </main>

      </div>

      {/* MODALS */}

      {/* Reference Detail View Modal */}
      {selectedReference && (
        <ReferenceDetailModal
          reference={selectedReference}
          onClose={() => setSelectedReference(null)}
          onEdit={(ref) => {
            setEditingReference(ref);
            setIsEditModalOpen(true);
          }}
          onSaveNote={handleSaveNote}
          onLaunchPdfReader={handleLaunchPdfReader}
          onUpdateReference={handleSaveReference}
        />
      )}

      {/* Reference Create / Edit Modal */}
      {isEditModalOpen && (
        <ReferenceEditModal
          reference={editingReference}
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setEditingReference(null);
          }}
          onSave={handleSaveReference}
        />
      )}

      {/* Harvard Rule Validator Widget */}
      <HarvardValidatorWidget
        isOpen={isValidatorOpen}
        onClose={() => setIsValidatorOpen(false)}
        references={references}
      />

      {/* PDF Viewer & Annotation Modal */}
      <PdfViewerModal
        reference={pdfRef || selectedReference}
        isOpen={isPdfViewerOpen}
        onClose={() => setIsPdfViewerOpen(false)}
        onUpdateReference={handleSaveReference}
      />

      {/* Word Processor Integration Plugin Modal */}
      <WordProcessorPluginModal
        isOpen={isWordProcessorOpen}
        onClose={() => setIsWordProcessorOpen(false)}
        references={references}
      />

      {/* Import / Export Modal */}
      <ImportExportModal
        isOpen={isImportExportOpen}
        onClose={() => setIsImportExportOpen(false)}
        references={references}
        onImportReferences={handleImportReferences}
      />

      {/* Dashboard Analytics Modal */}
      <DashboardAnalytics
        isOpen={isAnalyticsOpen}
        onClose={() => setIsAnalyticsOpen(false)}
        references={references}
        projects={projects}
      />

      {/* Technical Specifications Docs Modal */}
      <TechnicalDocsModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
      />

    </div>
  );
}
