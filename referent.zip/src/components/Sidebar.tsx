import React from 'react';
import {
  Library,
  Clock,
  Star,
  BookOpenCheck,
  FolderKanban,
  StickyNote,
  Tag,
  Plus,
  BookMarked,
  Layers,
  Sparkles,
  CheckSquare,
} from 'lucide-react';
import { Project, ReferenceType } from '../types';

export type ViewCategory = 'all' | 'recent' | 'starred' | 'unread' | 'projects' | 'notes' | 'tasks';

interface SidebarProps {
  activeCategory: ViewCategory;
  setActiveCategory: (cat: ViewCategory) => void;
  selectedType: ReferenceType | 'all';
  setSelectedType: (type: ReferenceType | 'all') => void;
  selectedTag: string | null;
  setSelectedTag: (tag: string | null) => void;
  projects: Project[];
  activeProject: Project | null;
  onSelectProject: (p: Project | null) => void;
  onNewProject: () => void;
  allTags: string[];
  referenceCount: number;
}

const typeLabels: Record<ReferenceType, string> = {
  journal_article: 'Journal Article',
  book: 'Book',
  conference_paper: 'Conference Paper',
  government_report: 'Government Report',
  website: 'Website',
  newspaper: 'Newspaper',
  magazine: 'Magazine',
  thesis: 'Thesis / Dissertation',
  dataset: 'Dataset',
  patent: 'Patent',
  video: 'Video',
  podcast: 'Podcast',
  map: 'Map',
  legislation: 'Legislation',
  court_case: 'Court Case',
  standard: 'Standard',
  company_report: 'Company Report',
  technical_manual: 'Technical Manual',
  personal_communication: 'Personal Comm.',
};

export const Sidebar: React.FC<SidebarProps> = ({
  activeCategory = 'all',
  setActiveCategory,
  selectedType = 'all',
  setSelectedType,
  selectedTag = null,
  setSelectedTag,
  projects = [],
  activeProject = null,
  onSelectProject,
  onNewProject,
  allTags = [],
  referenceCount = 0,
}) => {
  return (
    <aside className="w-full md:w-56 bg-[#0A0A0A] border-r border-[#1F1F1F] p-5 flex flex-col justify-between shrink-0 transition-colors">
      <div className="space-y-6">
        
        {/* Primary Views */}
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#555] mb-3 font-bold">
            Library
          </h3>
          <nav className="space-y-1">
            <button
              onClick={() => {
                setActiveCategory('all');
                onSelectProject(null);
                setSelectedTag(null);
              }}
              className={`w-full flex items-center justify-between py-1.5 px-2.5 rounded text-xs transition cursor-pointer ${
                activeCategory === 'all' && !activeProject && !selectedTag
                  ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                  : 'text-[#777] hover:text-white hover:bg-[#121212]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-1.5 h-1.5 rounded-full ${activeCategory === 'all' && !activeProject && !selectedTag ? 'bg-orange-500' : 'bg-[#333]'}`} />
                <span>All References</span>
              </div>
              <span className="text-[10px] font-mono text-[#555]">
                {referenceCount}
              </span>
            </button>

            <button
              onClick={() => setActiveCategory('recent')}
              className={`w-full flex items-center gap-2.5 py-1.5 px-2.5 rounded text-xs transition cursor-pointer ${
                activeCategory === 'recent'
                  ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                  : 'text-[#777] hover:text-white hover:bg-[#121212]'
              }`}
            >
              <div className={`w-1.5 h-1.5 rounded-full ${activeCategory === 'recent' ? 'bg-orange-500' : 'bg-[#333]'}`} />
              <span>Recently Added</span>
            </button>

            <button
              onClick={() => setActiveCategory('starred')}
              className={`w-full flex items-center gap-2.5 py-1.5 px-2.5 rounded text-xs transition cursor-pointer ${
                activeCategory === 'starred'
                  ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                  : 'text-[#777] hover:text-white hover:bg-[#121212]'
              }`}
            >
              <Star className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />
              <span>Starred</span>
            </button>

            <button
              onClick={() => setActiveCategory('unread')}
              className={`w-full flex items-center gap-2.5 py-1.5 px-2.5 rounded text-xs transition cursor-pointer ${
                activeCategory === 'unread'
                  ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                  : 'text-[#777] hover:text-white hover:bg-[#121212]'
              }`}
            >
              <BookOpenCheck className="w-3.5 h-3.5 text-green-400" />
              <span>Reading List</span>
            </button>

            <button
              onClick={() => setActiveCategory('notes')}
              className={`w-full flex items-center gap-2.5 py-1.5 px-2.5 rounded text-xs transition cursor-pointer ${
                activeCategory === 'notes'
                  ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                  : 'text-[#777] hover:text-white hover:bg-[#121212]'
              }`}
            >
              <StickyNote className="w-3.5 h-3.5 text-blue-400" />
              <span>Research Notes</span>
            </button>

            <button
              onClick={() => setActiveCategory('tasks')}
              className={`w-full flex items-center gap-2.5 py-1.5 px-2.5 rounded text-xs transition cursor-pointer ${
                activeCategory === 'tasks'
                  ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                  : 'text-[#777] hover:text-white hover:bg-[#121212]'
              }`}
            >
              <CheckSquare className="w-3.5 h-3.5 text-purple-400" />
              <span>Project Tasks</span>
            </button>
          </nav>
        </div>

        {/* Research Projects */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#555] font-bold">
              Primary Projects
            </h3>
            <button
              onClick={onNewProject}
              className="p-0.5 text-[#555] hover:text-white transition cursor-pointer"
              title="Create New Research Project"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
          <nav className="space-y-1">
            {(projects || []).map((proj) => {
              const isSelected = activeProject?.id === proj.id;
              return (
                <button
                  key={proj.id}
                  onClick={() => {
                    if (onSelectProject) onSelectProject(proj);
                    if (setActiveCategory) setActiveCategory('projects');
                  }}
                  className={`w-full flex items-center justify-between py-1.5 px-2.5 rounded text-xs transition cursor-pointer text-left ${
                    isSelected
                      ? 'bg-[#161616] text-white font-medium border border-[#2A2A2A]'
                      : 'text-[#777] hover:text-white hover:bg-[#121212]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <div className={`w-2 h-2 rounded-full shrink-0 ${isSelected ? 'bg-orange-500' : 'bg-[#333]'}`} />
                    <span className="truncate">{proj.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#555] shrink-0">
                    {(proj.referenceIds || []).length}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Reference Types Filter */}
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#555] mb-2 font-bold">
            Reference Type
          </h3>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType && setSelectedType(e.target.value as ReferenceType | 'all')}
            className="w-full text-xs py-1.5 px-2.5 bg-[#141414] border border-[#2A2A2A] rounded text-[#CCC] focus:outline-none focus:border-[#444]"
          >
            <option value="all" className="bg-[#0A0A0A]">All 20 Types</option>
            {Object.entries(typeLabels).map(([key, label]) => (
              <option key={key} value={key} className="bg-[#0A0A0A]">
                {label}
              </option>
            ))}
          </select>
        </div>

        {/* Tags Cloud */}
        {(allTags || []).length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#555] font-bold">
                Tags
              </h3>
              {selectedTag && (
                <button
                  onClick={() => setSelectedTag && setSelectedTag(null)}
                  className="text-[9px] uppercase tracking-wider text-[#666] hover:text-white cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(allTags || []).slice(0, 12).map((tag) => {
                const isSelected = selectedTag === tag;
                return (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(isSelected ? null : tag)}
                    className={`text-[9px] uppercase tracking-wider px-2 py-1 rounded cursor-pointer transition ${
                      isSelected
                        ? 'bg-white text-black font-bold'
                        : 'bg-[#161616] text-[#888] border border-[#222] hover:text-white hover:border-[#444]'
                    }`}
                  >
                    #{tag}
                  </button>
                );
              })}
            </div>
          </div>
        )}

      </div>

      {/* Footer Info */}
      <div className="pt-4 border-t border-[#1F1F1F] mt-6 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[10px] text-[#555] uppercase tracking-wider font-bold">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]"></div>
            Harvard Engine Active
          </div>
        </div>
        <p className="text-[10px] text-[#444] font-mono italic">
          Cite Them Right 12th Ed.
        </p>
      </div>
    </aside>
  );
};
