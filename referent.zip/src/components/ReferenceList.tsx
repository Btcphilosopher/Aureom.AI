import React, { useState } from 'react';
import {
  Book,
  FileText,
  Globe,
  Newspaper,
  FileSpreadsheet,
  Video,
  Mic,
  MapPin,
  Scale,
  Award,
  Building,
  Wrench,
  MessageSquare,
  Star,
  Copy,
  Check,
  Eye,
  Edit2,
  Trash2,
  FileCheck2,
  ExternalLink,
  Paperclip,
  Download,
  Filter,
  ArrowUpDown,
} from 'lucide-react';
import { Reference, ReferenceType } from '../types';
import {
  formatHarvardBibliography,
  formatInTextParenthetical,
  validateHarvardRules,
} from '../lib/harvardEngine';

interface ReferenceListProps {
  references: Reference[];
  onSelectReference: (ref: Reference) => void;
  onEditReference: (ref: Reference) => void;
  onDeleteReference: (id: string) => void;
  onToggleStarred: (id: string) => void;
  onUpdateStatus: (id: string, status: 'unread' | 'reading' | 'completed') => void;
  onValidateReference: (ref: Reference) => void;
  onExportSelected: (refs: Reference[]) => void;
}

const typeIcons: Record<ReferenceType, React.ReactNode> = {
  journal_article: <FileText className="w-4 h-4 text-blue-600" />,
  book: <Book className="w-4 h-4 text-amber-700" />,
  conference_paper: <FileText className="w-4 h-4 text-purple-600" />,
  government_report: <Building className="w-4 h-4 text-stone-700 dark:text-stone-300" />,
  website: <Globe className="w-4 h-4 text-emerald-600" />,
  newspaper: <Newspaper className="w-4 h-4 text-stone-600" />,
  magazine: <Newspaper className="w-4 h-4 text-pink-600" />,
  thesis: <Award className="w-4 h-4 text-indigo-600" />,
  dataset: <FileSpreadsheet className="w-4 h-4 text-teal-600" />,
  patent: <Wrench className="w-4 h-4 text-orange-600" />,
  video: <Video className="w-4 h-4 text-red-600" />,
  podcast: <Mic className="w-4 h-4 text-violet-600" />,
  map: <MapPin className="w-4 h-4 text-emerald-700" />,
  legislation: <Scale className="w-4 h-4 text-amber-800" />,
  court_case: <Scale className="w-4 h-4 text-amber-900" />,
  standard: <FileCheck2 className="w-4 h-4 text-cyan-700" />,
  company_report: <Building className="w-4 h-4 text-blue-800" />,
  technical_manual: <Wrench className="w-4 h-4 text-stone-700" />,
  personal_communication: <MessageSquare className="w-4 h-4 text-amber-600" />,
};

export const ReferenceList: React.FC<ReferenceListProps> = ({
  references,
  onSelectReference,
  onEditReference,
  onDeleteReference,
  onToggleStarred,
  onUpdateStatus,
  onValidateReference,
  onExportSelected,
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedInTextId, setCopiedInTextId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'year' | 'title' | 'author' | 'added'>('added');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(references.map((r) => r.id));
    } else {
      setSelectedIds([]);
    }
  };

  const toggleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((i) => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const copyHarvardRef = (ref: Reference, e: React.MouseEvent) => {
    e.stopPropagation();
    const formatted = formatHarvardBibliography(ref, false);
    navigator.clipboard.writeText(formatted);
    setCopiedId(ref.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const copyInTextCitation = (ref: Reference, e: React.MouseEvent) => {
    e.stopPropagation();
    const inText = formatInTextParenthetical(ref);
    navigator.clipboard.writeText(inText);
    setCopiedInTextId(ref.id);
    setTimeout(() => setCopiedInTextId(null), 2000);
  };

  const sortedReferences = [...references].sort((a, b) => {
    let comp = 0;
    if (sortBy === 'year') {
      comp = (a.year || '').localeCompare(b.year || '');
    } else if (sortBy === 'title') {
      comp = a.title.localeCompare(b.title);
    } else if (sortBy === 'author') {
      const aAuthor = a.authors[0]?.lastName || '';
      const bAuthor = b.authors[0]?.lastName || '';
      comp = aAuthor.localeCompare(bAuthor);
    } else {
      comp = a.createdAt.localeCompare(b.createdAt);
    }
    return sortOrder === 'asc' ? comp : -comp;
  });

  return (
    <div className="flex-1 flex flex-col bg-[#0F0F0F] overflow-hidden">
      
      {/* List Toolbar */}
      <div className="px-6 py-3 border-b border-[#1F1F1F] bg-[#0A0A0A] flex flex-wrap items-center justify-between gap-3 text-xs">
        
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 cursor-pointer font-medium text-[#AAA] hover:text-white transition">
            <input
              type="checkbox"
              checked={selectedIds.length > 0 && selectedIds.length === references.length}
              onChange={handleSelectAll}
              className="rounded bg-[#161616] border-[#333] text-orange-500 focus:ring-orange-500"
            />
            <span className="text-xs uppercase tracking-wider font-semibold">
              {selectedIds.length > 0 ? `${selectedIds.length} Selected` : 'Select All'}
            </span>
          </label>

          {selectedIds.length > 0 && (
            <button
              onClick={() => {
                const selected = references.filter((r) => selectedIds.includes(r.id));
                onExportSelected(selected);
              }}
              className="flex items-center gap-1.5 px-3 py-1 bg-white text-black text-xs font-bold uppercase tracking-widest rounded hover:bg-[#DDD] transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Selected</span>
            </button>
          )}
        </div>

        {/* Sorting controls */}
        <div className="flex items-center gap-2 text-[#777]">
          <ArrowUpDown className="w-3.5 h-3.5 text-[#555]" />
          <span className="uppercase text-[10px] tracking-wider font-bold">Sort:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#141414] border border-[#2A2A2A] rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-[#444]"
          >
            <option value="added" className="bg-[#0A0A0A]">Recently Added</option>
            <option value="year" className="bg-[#0A0A0A]">Year</option>
            <option value="author" className="bg-[#0A0A0A]">Author Last Name</option>
            <option value="title" className="bg-[#0A0A0A]">Title</option>
          </select>
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="px-2 py-1 bg-[#1A1A1A] border border-[#2A2A2A] text-white rounded font-mono text-[10px] uppercase tracking-wider hover:border-[#444] cursor-pointer"
          >
            {sortOrder.toUpperCase()}
          </button>
        </div>

      </div>

      {/* References Table */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {sortedReferences.length === 0 ? (
          <div className="p-16 text-center text-[#555]">
            <Book className="w-12 h-12 mx-auto mb-3 text-[#333] stroke-1" />
            <p className="font-serif text-lg font-light text-white italic">
              No references saved in this view
            </p>
            <p className="text-xs text-[#555] mt-1">
              Add a reference manually or import via DOI/ISBN to populate your library.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {sortedReferences.map((ref) => {
              const audit = validateHarvardRules(ref);
              const isSelected = selectedIds.includes(ref.id);

              return (
                <div
                  key={ref.id}
                  onClick={() => onSelectReference(ref)}
                  className={`group flex flex-col md:flex-row md:items-center justify-between p-4 bg-[#141414] border border-[#1F1F1F] hover:border-[#2A2A2A] hover:bg-[#1A1A1A] transition-all cursor-pointer rounded-md ${
                    isSelected ? 'border-orange-500/50 bg-[#1A1612]' : ''
                  }`}
                >
                  {/* Left Column: Selection, Type, Title, Authors, Citation */}
                  <div className="flex items-start gap-3.5 flex-1 min-w-0">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelectOne(ref.id)}
                      onClick={(e) => e.stopPropagation()}
                      className="mt-1 rounded bg-[#161616] border-[#333] text-orange-500 focus:ring-orange-500"
                    />

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleStarred(ref.id);
                      }}
                      className="mt-0.5 cursor-pointer"
                      title="Star reference"
                    >
                      <Star
                        className={`w-4 h-4 ${
                          ref.isStarred
                            ? 'text-orange-500 fill-orange-500'
                            : 'text-[#333] hover:text-[#666]'
                        }`}
                      />
                    </button>

                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] uppercase tracking-wider text-orange-500 font-bold">
                          {ref.referenceType.replace('_', ' ')}
                        </span>
                        <span className="text-[10px] text-[#555] font-mono">
                          ({ref.year || 'n.d.'})
                        </span>
                        {ref.attachments.length > 0 && (
                          <span
                            className="flex items-center gap-0.5 text-[9px] uppercase tracking-widest text-blue-400 bg-blue-500/10 border border-blue-500/30 px-1.5 py-0.2 rounded"
                            title="PDF attached"
                          >
                            <Paperclip className="w-2.5 h-2.5" />
                            <span>PDF</span>
                          </span>
                        )}
                        <span
                          className={`text-[9px] uppercase tracking-widest px-2 py-0.5 rounded font-mono font-bold ${
                            audit.score >= 90
                              ? 'bg-green-500/10 text-green-400 border border-green-500/30'
                              : audit.score >= 70
                              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                          title={`Harvard Formatting Audit Score: ${audit.score}/100`}
                        >
                          Harvard {audit.score}%
                        </span>
                      </div>

                      <h3 className="font-medium text-white text-sm hover:text-orange-400 transition leading-snug">
                        {ref.title}
                      </h3>

                      {/* Author & Publication Line */}
                      <p className="text-xs text-[#777]">
                        <span>
                          {ref.authors.map((a) => (a.isCorporate ? a.corporateName : `${a.lastName}, ${a.initials || ''}`)).join('; ')}
                        </span>
                        {(ref.journalName || ref.publisher || ref.institution) && (
                          <span className="italic text-[#555] ml-1">
                            — {ref.journalName || ref.publisher || ref.institution}
                          </span>
                        )}
                      </p>

                      {/* Formatted Harvard Bibliography Preview */}
                      <div
                        className="text-[11px] text-[#888] bg-[#0E0E0E] p-2.5 rounded border border-[#1E1E1E] font-serif leading-relaxed mt-1"
                        dangerouslySetInnerHTML={{ __html: audit.formattedBibliography }}
                      />

                      {/* Tags */}
                      {ref.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 pt-1">
                          {ref.tags.map((t) => (
                            <span
                              key={t}
                              className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#1C1C1C] text-[#888] border border-[#262626]"
                            >
                              #{t}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Status & Quick Actions */}
                  <div className="flex md:flex-col items-end justify-between gap-3 shrink-0 border-t md:border-t-0 pt-3 md:pt-0 border-[#1F1F1F] mt-2 md:mt-0">
                    
                    {/* Status dropdown */}
                    <select
                      value={ref.readingStatus}
                      onChange={(e) => {
                        e.stopPropagation();
                        onUpdateStatus(ref.id, e.target.value as any);
                      }}
                      onClick={(e) => e.stopPropagation()}
                      className="text-[10px] uppercase tracking-wider px-2 py-1 rounded border border-[#2A2A2A] bg-[#0A0A0A] text-[#AAA] focus:text-white font-medium cursor-pointer focus:outline-none"
                    >
                      <option value="unread" className="bg-[#0A0A0A]">Unread</option>
                      <option value="reading" className="bg-[#0A0A0A]">Reading</option>
                      <option value="completed" className="bg-[#0A0A0A]">Completed</option>
                    </select>

                    {/* Quick copy & Action buttons */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => copyInTextCitation(ref, e)}
                        className="px-2 py-1 text-[10px] uppercase tracking-widest bg-transparent border border-[#333] hover:border-[#555] text-white rounded font-mono transition cursor-pointer flex items-center gap-1"
                        title="Copy In-Text Harvard Citation (e.g., Smith, 2021)"
                      >
                        {copiedInTextId === ref.id ? (
                          <>
                            <Check className="w-3 h-3 text-green-400" />
                            <span className="text-green-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3 text-[#666]" />
                            <span>In-Text</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={(e) => copyHarvardRef(ref, e)}
                        className="px-2.5 py-1 text-[10px] uppercase tracking-widest bg-white text-black font-bold hover:bg-[#DDD] rounded transition cursor-pointer flex items-center gap-1"
                        title="Copy Full Harvard Reference List Item"
                      >
                        {copiedId === ref.id ? (
                          <>
                            <Check className="w-3 h-3 text-black" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3 text-black" />
                            <span>Citation</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditReference(ref);
                        }}
                        className="p-1.5 text-[#666] hover:text-white hover:bg-[#222] rounded transition cursor-pointer"
                        title="Edit Reference"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Delete "${ref.title}" from library?`)) {
                            onDeleteReference(ref.id);
                          }
                        }}
                        className="p-1.5 text-[#555] hover:text-rose-400 hover:bg-[#222] rounded transition cursor-pointer"
                        title="Delete Reference"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
