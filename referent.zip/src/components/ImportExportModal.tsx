import React, { useState } from 'react';
import {
  X,
  Upload,
  Download,
  FileCode,
  FileSpreadsheet,
  Globe,
  Sparkles,
  Check,
  FileText,
  Search,
} from 'lucide-react';
import { Reference } from '../types';
import { parseBibTeX, parseRIS } from '../lib/importers';
import {
  exportToBibTeX,
  exportToRIS,
  exportToCSV,
  exportToMarkdown,
  exportToLaTeX,
  downloadFile,
} from '../lib/exporters';

interface ImportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  references: Reference[];
  onImportReferences: (newRefs: Reference[]) => void;
}

export const ImportExportModal: React.FC<ImportExportModalProps> = ({
  isOpen,
  onClose,
  references,
  onImportReferences,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'import' | 'export'>('import');
  const [importSource, setImportSource] = useState<'doi_isbn' | 'paste' | 'file'>('doi_isbn');
  const [exportFormat, setExportFormat] = useState<'ris' | 'bibtex' | 'csv' | 'markdown' | 'latex' | 'json'>('ris');

  // Import State
  const [doiQuery, setDoiQuery] = useState('');
  const [pasteText, setPasteText] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [importedCount, setImportedCount] = useState<number | null>(null);

  const handleDoiImport = async () => {
    if (!doiQuery) return;
    setIsImporting(true);
    setImportedCount(null);
    try {
      const res = await fetch('/api/gemini/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: doiQuery }),
      });
      const data = await res.json();
      if (data.success && data.metadata) {
        const m = data.metadata;
        const newRef: Reference = {
          id: `ref-import-${Date.now()}`,
          referenceType: (m.referenceType as any) || 'journal_article',
          title: m.title || 'Imported Publication',
          authors: m.authors || [{ id: 'a1', lastName: 'Anonymous' }],
          year: m.year || '2026',
          journalName: m.journalName,
          volume: m.volume,
          issue: m.issue,
          pages: m.pages,
          publisher: m.publisher,
          doi: m.doi || (doiQuery.startsWith('10.') ? doiQuery : undefined),
          isbn: m.isbn,
          url: m.url,
          abstract: m.abstract,
          tags: ['Imported-DOI'],
          readingStatus: 'unread',
          attachments: [],
          notes: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        onImportReferences([newRef]);
        setImportedCount(1);
        setDoiQuery('');
      }
    } catch (err) {
      console.error('DOI Import Error:', err);
    } finally {
      setIsImporting(false);
    }
  };

  const handleTextPasteImport = () => {
    if (!pasteText) return;
    setIsImporting(true);
    try {
      let parsed: Reference[] = [];
      if (pasteText.includes('@') && pasteText.includes('{')) {
        parsed = parseBibTeX(pasteText);
      } else if (pasteText.includes('TY  -') || pasteText.includes('ER  -')) {
        parsed = parseRIS(pasteText);
      }

      if (parsed.length > 0) {
        onImportReferences(parsed);
        setImportedCount(parsed.length);
        setPasteText('');
      } else {
        alert('Could not parse text as BibTeX or RIS format. Please check formatting.');
      }
    } catch (err) {
      console.error('Text Import error:', err);
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) return;

      let parsed: Reference[] = [];
      if (file.name.endsWith('.bib') || content.includes('@')) {
        parsed = parseBibTeX(content);
      } else if (file.name.endsWith('.ris') || content.includes('TY  -')) {
        parsed = parseRIS(content);
      } else if (file.name.endsWith('.json')) {
        try {
          parsed = JSON.parse(content);
        } catch (e) {}
      }

      if (parsed.length > 0) {
        onImportReferences(parsed);
        setImportedCount(parsed.length);
      } else {
        alert('Could not parse file. Ensure it is a valid .bib, .ris, or .json file.');
      }
    };
    reader.readAsText(file);
  };

  const handleExport = () => {
    if (exportFormat === 'ris') {
      const content = exportToRIS(references);
      downloadFile('referent_bibliography.ris', content, 'application/x-research-info-systems');
    } else if (exportFormat === 'bibtex') {
      const content = exportToBibTeX(references);
      downloadFile('referent_bibliography.bib', content, 'text/x-bibtex');
    } else if (exportFormat === 'csv') {
      const content = exportToCSV(references);
      downloadFile('referent_bibliography.csv', content, 'text/csv');
    } else if (exportFormat === 'markdown') {
      const content = exportToMarkdown(references);
      downloadFile('referent_bibliography.md', content, 'text/markdown');
    } else if (exportFormat === 'latex') {
      const content = exportToLaTeX(references);
      downloadFile('referent_bibliography.tex', content, 'text/x-tex');
    } else if (exportFormat === 'json') {
      const content = JSON.stringify(references, null, 2);
      downloadFile('referent_library_backup.json', content, 'application/json');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0A0A0A] border border-[#1F1F1F] rounded-lg w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col text-white">
        
        {/* Header */}
        <div className="p-4 border-b border-[#1F1F1F] bg-[#0A0A0A] flex items-center justify-between">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('import')}
              className={`px-3 py-1.5 rounded text-xs uppercase tracking-wider font-bold cursor-pointer transition ${
                activeTab === 'import'
                  ? 'bg-white text-black'
                  : 'text-[#666] hover:text-[#AAA]'
              }`}
            >
              <Upload className="w-3.5 h-3.5 inline mr-1.5" />
              Import References
            </button>
            <button
              onClick={() => setActiveTab('export')}
              className={`px-3 py-1.5 rounded text-xs uppercase tracking-wider font-bold cursor-pointer transition ${
                activeTab === 'export'
                  ? 'bg-white text-black'
                  : 'text-[#666] hover:text-[#AAA]'
              }`}
            >
              <Download className="w-3.5 h-3.5 inline mr-1.5" />
              Export Bibliography
            </button>
          </div>

          <button onClick={onClose} className="p-1.5 text-[#555] hover:text-white rounded transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 bg-[#0F0F0F] space-y-6 text-xs">
          
          {/* TAB: IMPORT */}
          {activeTab === 'import' && (
            <div className="space-y-5">
              
              <div className="flex gap-2 border-b pb-2">
                <button
                  onClick={() => setImportSource('doi_isbn')}
                  className={`px-2.5 py-1 rounded text-xs font-medium cursor-pointer ${
                    importSource === 'doi_isbn' ? 'bg-amber-100 text-amber-900 font-bold' : 'text-stone-600'
                  }`}
                >
                  DOI / ISBN Lookup
                </button>
                <button
                  onClick={() => setImportSource('paste')}
                  className={`px-2.5 py-1 rounded text-xs font-medium cursor-pointer ${
                    importSource === 'paste' ? 'bg-amber-100 text-amber-900 font-bold' : 'text-stone-600'
                  }`}
                >
                  Paste BibTeX / RIS
                </button>
                <button
                  onClick={() => setImportSource('file')}
                  className={`px-2.5 py-1 rounded text-xs font-medium cursor-pointer ${
                    importSource === 'file' ? 'bg-amber-100 text-amber-900 font-bold' : 'text-stone-600'
                  }`}
                >
                  Upload File (.bib, .ris, .json)
                </button>
              </div>

              {importedCount !== null && (
                <div className="p-3 bg-emerald-50 text-emerald-800 rounded border border-emerald-200 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Successfully imported {importedCount} reference(s) into your library!</span>
                </div>
              )}

              {importSource === 'doi_isbn' && (
                <div className="space-y-3">
                  <label className="font-semibold text-stone-700 dark:text-stone-300">
                    Enter DOI, ISBN, PubMed ID, or Paper Title
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g., 10.1038/s41586-020-2649-2 or 978-0134685991..."
                      value={doiQuery}
                      onChange={(e) => setDoiQuery(e.target.value)}
                      className="flex-1 p-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                    />
                    <button
                      onClick={handleDoiImport}
                      disabled={isImporting || !doiQuery}
                      className="px-4 py-2 bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900 font-semibold rounded hover:bg-stone-800 cursor-pointer disabled:opacity-50"
                    >
                      {isImporting ? 'Fetching...' : 'Import'}
                    </button>
                  </div>
                </div>
              )}

              {importSource === 'paste' && (
                <div className="space-y-3">
                  <label className="font-semibold text-stone-700 dark:text-stone-300">
                    Paste Raw BibTeX or RIS Content
                  </label>
                  <textarea
                    rows={6}
                    placeholder={`@article{smith2021,\n  author = {Smith, John},\n  title = {Global warming pathways},\n  journal = {Nature},\n  year = {2021}\n}`}
                    value={pasteText}
                    onChange={(e) => setPasteText(e.target.value)}
                    className="w-full p-2.5 font-mono bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                  />
                  <button
                    onClick={handleTextPasteImport}
                    disabled={isImporting || !pasteText}
                    className="px-4 py-2 bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900 font-semibold rounded hover:bg-stone-800 cursor-pointer disabled:opacity-50"
                  >
                    Parse & Import
                  </button>
                </div>
              )}

              {importSource === 'file' && (
                <div className="p-8 text-center border-2 border-dashed border-stone-300 dark:border-stone-800 rounded-xl space-y-3 bg-stone-50 dark:bg-stone-900/50">
                  <Upload className="w-8 h-8 mx-auto text-stone-400 stroke-1" />
                  <p className="font-medium text-stone-700 dark:text-stone-300">
                    Drag and drop your .bib, .ris, or .json file here
                  </p>
                  <input
                    type="file"
                    accept=".bib,.ris,.json"
                    onChange={handleFileUpload}
                    className="block w-full text-xs text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:bg-stone-900 file:text-stone-100 cursor-pointer"
                  />
                </div>
              )}

            </div>
          )}

          {/* TAB: EXPORT */}
          {activeTab === 'export' && (
            <div className="space-y-5">
              <div className="space-y-2">
                <label className="font-semibold text-stone-700 dark:text-stone-300">
                  Select Export Format ({references.length} references)
                </label>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'ris', label: 'RIS (Zotero, EndNote)', ext: '.ris' },
                    { id: 'bibtex', label: 'BibTeX', ext: '.bib' },
                    { id: 'csv', label: 'CSV Table', ext: '.csv' },
                    { id: 'markdown', label: 'Markdown List', ext: '.md' },
                    { id: 'latex', label: 'LaTeX Bibliography', ext: '.tex' },
                    { id: 'json', label: 'JSON Backup', ext: '.json' },
                  ].map((fmt) => (
                    <button
                      key={fmt.id}
                      onClick={() => setExportFormat(fmt.id as any)}
                      className={`p-3 rounded-lg border text-left cursor-pointer transition ${
                        exportFormat === fmt.id
                          ? 'border-stone-900 bg-amber-50 dark:bg-amber-950/40 text-stone-900 dark:text-stone-100 font-bold'
                          : 'border-stone-200 dark:border-stone-800 hover:bg-stone-50'
                      }`}
                    >
                      <span className="block">{fmt.label}</span>
                      <span className="text-[10px] font-mono text-stone-400">{fmt.ext}</span>
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleExport}
                className="w-full py-2.5 bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900 font-semibold rounded hover:bg-stone-800 cursor-pointer flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Download {exportFormat.toUpperCase()} File</span>
              </button>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
