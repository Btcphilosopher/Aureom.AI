import React, { useState } from 'react';
import { X, FileCheck2, Check, Copy, Wand2, AlertTriangle, Sparkles, BookOpen } from 'lucide-react';
import { Reference } from '../types';
import { formatHarvardBibliography, validateHarvardRules } from '../lib/harvardEngine';

interface HarvardValidatorWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  references: Reference[];
}

export const HarvardValidatorWidget: React.FC<HarvardValidatorWidgetProps> = ({
  isOpen,
  onClose,
  references,
}) => {
  if (!isOpen) return null;

  const [pasteText, setPasteText] = useState('');
  const [auditResult, setAuditResult] = useState<any>(null);
  const [isAuditing, setIsAuditing] = useState(false);
  const [copied, setCopied] = useState(false);

  // Overall library health score
  const libraryScores = references.map((r) => validateHarvardRules(r).score);
  const avgScore = Math.round(
    libraryScores.reduce((a, b) => a + b, 0) / (libraryScores.length || 1)
  );

  const handleAuditPasted = async () => {
    if (!pasteText) return;
    setIsAuditing(true);
    try {
      const res = await fetch('/api/gemini/validate-harvard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ referenceString: pasteText }),
      });
      const data = await res.json();
      if (data.success) {
        setAuditResult(data.validation);
      }
    } catch (err) {
      console.error('Audit error:', err);
    } finally {
      setIsAuditing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0A0A0A] border border-[#1F1F1F] rounded-lg w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-white">
        
        {/* Header */}
        <div className="p-4 border-b border-[#1F1F1F] bg-[#0A0A0A] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-orange-500" />
            <h2 className="font-serif italic font-light text-lg text-white">
              Harvard Citation Rule Validator & Auto-Corrector
            </h2>
          </div>
          <button onClick={onClose} className="p-1.5 text-[#555] hover:text-white rounded transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 bg-[#0F0F0F] overflow-y-auto space-y-6 flex-1 text-xs">
          
          {/* Library Health Overview */}
          <div className="p-4 bg-[#141414] rounded-lg border border-[#2A2A2A] flex items-center justify-between">
            <div>
              <div className="font-medium text-white text-sm">
                Library Harvard Conformance Score
              </div>
              <p className="text-[#666] text-xs mt-0.5">
                Evaluated across all {references.length} references in your active workspace.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div
                className={`text-2xl font-bold font-mono px-3 py-1 rounded ${
                  avgScore >= 90
                    ? 'bg-green-500/10 text-green-400 border border-green-500/30'
                    : 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                }`}
              >
                {avgScore}%
              </div>
            </div>
          </div>

          {/* Test/Audit Pasted Citation */}
          <div className="space-y-3 p-4 bg-[#141414] rounded-lg border border-[#2A2A2A]">
            <h3 className="font-semibold text-orange-400 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-orange-500" />
              <span>Audit Raw Citation String</span>
            </h3>

            <textarea
              rows={3}
              placeholder="Paste any citation string here (e.g., 'Smith J, 2021, Global warming pathways, Nature, 1012-1022') to test formatting rules..."
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0A] border border-[#2A2A2A] rounded focus:outline-none focus:border-[#444] text-white placeholder-[#555]"
            />

            <button
              onClick={handleAuditPasted}
              disabled={isAuditing || !pasteText}
              className="px-4 py-2 bg-white text-black font-bold uppercase tracking-wider text-xs rounded hover:bg-[#DDD] transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>{isAuditing ? 'Running Audit...' : 'Audit & Auto-Fix Citation'}</span>
            </button>
          </div>

          {/* Audit Output Result */}
          {auditResult && (
            <div className="space-y-4 p-4 bg-stone-900 text-stone-100 rounded-xl font-mono">
              <div className="flex items-center justify-between border-b border-stone-800 pb-2">
                <span className="text-amber-400 font-bold">Audit Score: {auditResult.score}/100</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    auditResult.isValid ? 'bg-emerald-900 text-emerald-200' : 'bg-rose-900 text-rose-200'
                  }`}
                >
                  {auditResult.isValid ? 'VALID HARVARD' : 'NEEDS CORRECTION'}
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-stone-400 text-[11px]">Strict Corrected Harvard String:</span>
                <div className="p-3 bg-stone-950 rounded border border-stone-800 font-serif text-xs text-emerald-300 flex items-start justify-between gap-2">
                  <span>{auditResult.correctedHarvardString}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(auditResult.correctedHarvardString);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="p-1 hover:text-white cursor-pointer"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {auditResult.issuesFound && auditResult.issuesFound.length > 0 && (
                <div className="space-y-1">
                  <span className="text-stone-400 text-[11px]">Rule Violations Detected:</span>
                  <ul className="list-disc pl-4 text-rose-300 space-y-0.5 text-[11px]">
                    {auditResult.issuesFound.map((i: string, idx: number) => (
                      <li key={idx}>{i}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Library Audit Breakdown */}
          <div className="space-y-2">
            <h3 className="font-semibold text-stone-700 dark:text-stone-300 uppercase tracking-wider text-[11px]">
              Library References Audit Breakdown
            </h3>
            <div className="space-y-2">
              {references.map((ref) => {
                const rAudit = validateHarvardRules(ref);
                return (
                  <div
                    key={ref.id}
                    className="p-3 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-800 flex items-center justify-between"
                  >
                    <div className="space-y-0.5 max-w-lg">
                      <p className="font-serif font-medium text-stone-900 dark:text-stone-100 truncate">
                        {ref.title}
                      </p>
                      <p className="text-[11px] text-stone-500">
                        {ref.authors[0]?.lastName || 'Anon'} ({ref.year || 'n.d.'}) — {ref.referenceType}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`font-mono text-xs px-2 py-0.5 rounded font-bold ${
                          rAudit.score >= 90
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {rAudit.score}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
