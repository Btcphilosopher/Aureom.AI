import React from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Download,
  FileCheck,
  FileText,
  BarChart3,
  Moon,
  Sun,
  Code2,
  FolderPlus,
  Sparkles,
} from 'lucide-react';
import { Project } from '../types';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  activeProject: Project | null;
  projects: Project[];
  onSelectProject: (proj: Project | null) => void;
  onOpenNewReference: () => void;
  onOpenImportExport: () => void;
  onOpenWordProcessor: () => void;
  onOpenHarvardValidator: () => void;
  onOpenAnalytics: () => void;
  onOpenTechnicalDocs: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  setSearchQuery,
  activeProject,
  projects = [],
  onSelectProject,
  onOpenNewReference,
  onOpenImportExport,
  onOpenWordProcessor,
  onOpenHarvardValidator,
  onOpenAnalytics,
  onOpenTechnicalDocs,
  darkMode,
  setDarkMode,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-[#1F1F1F] bg-[#0A0A0A] px-6 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand & Active Project */}
        <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-[#333] to-[#111] border border-[#2A2A2A] flex items-center justify-center text-white font-bold font-serif text-sm shadow-sm">
              R
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif font-light text-xl text-white tracking-[0.2em]">
                  REFERENT
                </span>
                <span className="text-[9px] uppercase tracking-widest px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30 font-semibold">
                  HARVARD
                </span>
              </div>
            </div>
          </div>

          {/* Project Switcher */}
          <div className="flex items-center gap-1.5 bg-[#161616] border border-[#2A2A2A] px-2.5 py-1 rounded text-xs text-[#AAA]">
            <FolderPlus className="w-3.5 h-3.5 text-[#666]" />
            <select
              value={activeProject ? activeProject.id : 'all'}
              onChange={(e) => {
                const val = e.target.value;
                if (val === 'all') onSelectProject(null);
                else {
                  const proj = (projects || []).find((p) => p.id === val) || null;
                  onSelectProject(proj);
                }
              }}
              className="bg-transparent border-none focus:outline-none cursor-pointer font-medium text-white pr-1"
            >
              <option value="all" className="bg-[#0A0A0A] text-white">
                All Projects
              </option>
              {(projects || []).map((p) => (
                <option key={p.id} value={p.id} className="bg-[#0A0A0A] text-white">
                  📁 {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Global Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#555]" />
          <input
            type="text"
            placeholder="Quick search title, author, DOI..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs bg-[#161616] border border-[#2A2A2A] rounded focus:outline-none focus:border-[#444] text-white placeholder-[#555] transition"
          />
        </div>

        {/* Actions Toolbar */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={onOpenNewReference}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded bg-white text-black hover:bg-[#DDD] transition cursor-pointer whitespace-nowrap shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Reference</span>
          </button>

          <button
            onClick={onOpenImportExport}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold uppercase tracking-widest rounded bg-transparent border border-[#333] text-white hover:border-[#555] transition cursor-pointer whitespace-nowrap"
            title="Import DOI/ISBN or Export RIS/BibTeX"
          >
            <Download className="w-3.5 h-3.5 text-orange-500" />
            <span>Import / Export</span>
          </button>

          <button
            onClick={onOpenWordProcessor}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold uppercase tracking-widest rounded bg-transparent border border-[#333] text-[#AAA] hover:text-white hover:border-[#555] transition cursor-pointer whitespace-nowrap"
            title="Word Processor Toolbar Plugin Simulation"
          >
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden lg:inline">Plugin</span>
          </button>

          <button
            onClick={onOpenHarvardValidator}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold uppercase tracking-widest rounded bg-transparent border border-[#333] text-[#AAA] hover:text-white hover:border-[#555] transition cursor-pointer whitespace-nowrap"
            title="Harvard Referencing Rules Audit & Validator"
          >
            <FileCheck className="w-3.5 h-3.5 text-green-400" />
            <span className="hidden lg:inline">Audit</span>
          </button>

          <button
            onClick={onOpenAnalytics}
            className="p-2 text-[#777] hover:text-white hover:bg-[#1A1A1A] rounded transition cursor-pointer"
            title="Dashboard & Analytics"
          >
            <BarChart3 className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenTechnicalDocs}
            className="p-2 text-[#777] hover:text-white hover:bg-[#1A1A1A] rounded transition cursor-pointer"
            title="Technical Docs, Rust API & Database Schema"
          >
            <Code2 className="w-4 h-4" />
          </button>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 text-[#777] hover:text-white hover:bg-[#1A1A1A] rounded transition cursor-pointer"
            title="Toggle Light / Dark Mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-orange-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>

      </div>
    </header>
  );
};
