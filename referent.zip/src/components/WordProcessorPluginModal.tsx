import React, { useState } from 'react';
import {
  X,
  FileText,
  Search,
  Plus,
  Copy,
  Check,
  RefreshCw,
  Sparkles,
  BookOpen,
  Layers,
  Wand2,
} from 'lucide-react';
import { Reference } from '../types';
import {
  formatHarvardBibliography,
  formatInTextParenthetical,
  formatInTextNarrative,
} from '../lib/harvardEngine';

interface WordProcessorPluginModalProps {
  isOpen: boolean;
  onClose: () => void;
  references: Reference[];
}

export const WordProcessorPluginModal: React.FC<WordProcessorPluginModalProps> = ({
  isOpen,
  onClose,
  references,
}) => {
  if (!isOpen) return null;

  const [documentText, setDocumentText] = useState(
    `# Global Climate Change & Decarbonization Pathways

## 1. Introduction
Anthropogenic greenhouse gas emissions continue to drive global mean surface temperature rise. Integrated assessment modeling indicates that achieving carbon neutrality before 2050 is vital for stabilizing warming below 1.5°C (Rogelj et al., 2021).

## 2. Artificial Intelligence in Climate Modeling
Recent advances in transformer architectures (Vaswani et al., 2017) have revolutionized scientific literature analysis and climate prediction models.

## 3. Policy Frameworks
Governmental synthesize reports emphasize national carbon budgets and renewable infrastructure expansion (IPCC, 2024).
`
  );

  const [citedRefIds, setCitedRefIds] = useState<string[]>(['ref-1', 'ref-2', 'ref-4']);
  const [pluginSearch, setPluginSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'word' | 'gdocs' | 'libreoffice' | 'latex'>('word');
  const [copiedDoc, setCopiedDoc] = useState(false);

  const filteredRefs = references.filter(
    (r) =>
      r.title.toLowerCase().includes(pluginSearch.toLowerCase()) ||
      r.authors.some((a) => a.lastName.toLowerCase().includes(pluginSearch.toLowerCase()))
  );

  const insertCitation = (ref: Reference, style: 'parenthetical' | 'narrative') => {
    const citationStr =
      style === 'parenthetical' ? formatInTextParenthetical(ref) : formatInTextNarrative(ref);

    setDocumentText((prev) => prev + ` ${citationStr} `);
    if (!citedRefIds.includes(ref.id)) {
      setCitedRefIds([...citedRefIds, ref.id]);
    }
  };

  const generateHarvardBibliographyBlock = (): string => {
    const citedRefs = references.filter((r) => citedRefIds.includes(r.id));
    const sorted = [...citedRefs].sort((a, b) => {
      const aLast = a.authors[0]?.lastName || 'Anon';
      const bLast = b.authors[0]?.lastName || 'Anon';
      return aLast.localeCompare(bLast);
    });

    return sorted.map((r) => formatHarvardBibliography(r, false)).join('\n\n');
  };

  const appendBibliographyToDoc = () => {
    const bibBlock = generateHarvardBibliographyBlock();
    if (documentText.includes('\n\n# References (Harvard Style)\n')) {
      const parts = documentText.split('\n\n# References (Harvard Style)\n');
      setDocumentText(`${parts[0]}\n\n# References (Harvard Style)\n\n${bibBlock}`);
    } else {
      setDocumentText((prev) => `${prev}\n\n# References (Harvard Style)\n\n${bibBlock}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-hidden">
      <div className="bg-stone-100 dark:bg-stone-950 rounded-xl border border-stone-300 dark:border-stone-800 w-full max-w-6xl h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-3 border-b border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <div>
              <h2 className="font-serif font-bold text-sm text-stone-900 dark:text-stone-100">
                Word Processor Plugin Live Integration
              </h2>
              <p className="text-[10px] text-stone-500">
                Simulated live toolbar for MS Word, Google Docs, LibreOffice, and LaTeX
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-stone-200 dark:bg-stone-800 p-0.5 rounded font-mono text-[10px]">
              {(['word', 'gdocs', 'libreoffice', 'latex'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setActiveTab(t)}
                  className={`px-2.5 py-1 rounded cursor-pointer capitalize font-semibold transition ${
                    activeTab === t
                      ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-sm'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(documentText);
                setCopiedDoc(true);
                setTimeout(() => setCopiedDoc(false), 2000);
              }}
              className="px-3 py-1 bg-stone-900 dark:bg-stone-100 text-stone-100 dark:text-stone-900 font-semibold rounded text-xs hover:bg-stone-800 cursor-pointer flex items-center gap-1"
            >
              {copiedDoc ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedDoc ? 'Copied Document!' : 'Copy Essay'}</span>
            </button>

            <button onClick={onClose} className="p-1.5 text-stone-400 hover:text-stone-700 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Content Layout: Live Essay Canvas + Plugin Toolbar Drawer */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Document Editor Canvas */}
          <div className="flex-1 p-6 bg-white dark:bg-stone-900 overflow-y-auto flex flex-col space-y-3">
            <div className="flex items-center justify-between text-xs text-stone-500 border-b pb-2">
              <span className="font-semibold text-stone-800 dark:text-stone-200">
                Live Document Canvas ({documentText.split(' ').length} words)
              </span>
              <button
                onClick={appendBibliographyToDoc}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs transition cursor-pointer flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Update / Insert Harvard Bibliography</span>
              </button>
            </div>

            <textarea
              value={documentText}
              onChange={(e) => setDocumentText(e.target.value)}
              className="flex-1 w-full p-4 font-serif text-sm leading-relaxed text-stone-900 dark:text-stone-100 bg-stone-50/50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg focus:outline-none resize-none shadow-inner"
              placeholder="Start typing your research paper draft here..."
            />
          </div>

          {/* Plugin Sidebar Drawer */}
          <div className="w-full md:w-80 bg-stone-100 dark:bg-stone-950 border-t md:border-t-0 md:border-l border-stone-200 dark:border-stone-800 p-4 flex flex-col justify-between overflow-y-auto text-xs space-y-4">
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-900 dark:text-stone-100 uppercase tracking-wider text-[11px]">
                  Referent Toolbar
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 font-mono font-semibold">
                  Harvard Engine
                </span>
              </div>

              {/* Search References */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-stone-400" />
                <input
                  type="text"
                  placeholder="Search references to cite..."
                  value={pluginSearch}
                  onChange={(e) => setPluginSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded text-xs focus:outline-none"
                />
              </div>

              {/* Reference Search Results */}
              <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
                {filteredRefs.map((ref) => {
                  const isCited = citedRefIds.includes(ref.id);
                  return (
                    <div
                      key={ref.id}
                      className="p-2.5 bg-white dark:bg-stone-900 rounded border border-stone-200 dark:border-stone-800 space-y-1.5"
                    >
                      <div className="font-serif font-medium text-stone-900 dark:text-stone-100 text-[11px] leading-tight">
                        {ref.title}
                      </div>
                      <p className="text-[10px] text-stone-500">
                        {ref.authors[0]?.lastName || 'Anon'} ({ref.year || 'n.d.'})
                      </p>

                      <div className="flex items-center gap-1.5 pt-1">
                        <button
                          onClick={() => insertCitation(ref, 'parenthetical')}
                          className="flex-1 py-1 px-1.5 bg-stone-900 hover:bg-stone-800 text-stone-100 rounded text-[10px] font-mono cursor-pointer transition text-center"
                          title="Insert (Author, Year)"
                        >
                          + Parenthetical
                        </button>
                        <button
                          onClick={() => insertCitation(ref, 'narrative')}
                          className="flex-1 py-1 px-1.5 bg-stone-200 dark:bg-stone-800 hover:bg-stone-300 text-stone-800 dark:text-stone-200 rounded text-[10px] font-mono cursor-pointer transition text-center"
                          title="Insert Author (Year)"
                        >
                          + Narrative
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Currently Cited List */}
            <div className="pt-3 border-t border-stone-200 dark:border-stone-800 space-y-1">
              <span className="text-[10px] font-semibold text-stone-500 uppercase tracking-wider block">
                Cited in Document ({citedRefIds.length})
              </span>
              <p className="text-[10px] text-stone-400 leading-tight">
                Clicking "Update / Insert Harvard Bibliography" compiles these citations into alphabetical order at the end of your essay.
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
