import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Edit2,
  FileCheck2,
  BookOpen,
  FileText,
  Paperclip,
  Sparkles,
  ExternalLink,
  Plus,
  StickyNote,
  AlertTriangle,
  Award,
  Layers,
  Wand2,
} from 'lucide-react';
import { Reference, ReferenceNote } from '../types';
import {
  formatHarvardBibliography,
  formatInTextNarrative,
  formatInTextParenthetical,
  validateHarvardRules,
} from '../lib/harvardEngine';
import { exportToBibTeX, exportToRIS } from '../lib/exporters';

interface ReferenceDetailModalProps {
  reference: Reference | null;
  onClose: () => void;
  onEdit: (ref: Reference) => void;
  onSaveNote: (refId: string, note: ReferenceNote) => void;
  onLaunchPdfReader: (ref: Reference) => void;
  onUpdateReference: (updated: Reference) => void;
}

export const ReferenceDetailModal: React.FC<ReferenceDetailModalProps> = ({
  reference,
  onClose,
  onEdit,
  onSaveNote,
  onLaunchPdfReader,
  onUpdateReference,
}) => {
  if (!reference) return null;

  const [activeTab, setActiveTab] = useState<'harvard' | 'fields' | 'audit' | 'notes' | 'attachments'>('harvard');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteContent, setNewNoteContent] = useState('');
  const [newNoteType, setNewNoteType] = useState<ReferenceNote['type']>('lit_review');
  const [isValidatingWithAI, setIsValidatingWithAI] = useState(false);
  const [aiAuditResult, setAiAuditResult] = useState<any>(null);

  const audit = validateHarvardRules(reference);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(label);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteTitle || !newNoteContent) return;

    const note: ReferenceNote = {
      id: `note-${Date.now()}`,
      referenceId: reference.id,
      title: newNoteTitle,
      content: newNoteContent,
      tags: reference.tags,
      type: newNoteType,
      updatedAt: new Date().toISOString(),
    };

    onSaveNote(reference.id, note);
    setNewNoteTitle('');
    setNewNoteContent('');
  };

  const runAiAudit = async () => {
    setIsValidatingWithAI(true);
    try {
      const res = await fetch('/api/gemini/validate-harvard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          referenceString: formatHarvardBibliography(reference, false),
          referenceType: reference.referenceType,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setAiAuditResult(data.validation);
      }
    } catch (err) {
      console.error('AI Audit error:', err);
    } finally {
      setIsValidatingWithAI(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0A0A0A] border border-[#1F1F1F] rounded-lg w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-white">
        
        {/* Header */}
        <div className="p-5 border-b border-[#1F1F1F] bg-[#0A0A0A] flex items-start justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#1A1A1A] text-orange-400 border border-orange-500/30 uppercase font-bold">
                {reference.referenceType.replace(/_/g, ' ')}
              </span>
              <span
                className={`text-[9px] uppercase tracking-wider font-mono font-bold px-2 py-0.5 rounded ${
                  audit.score >= 90
                    ? 'bg-green-500/10 text-green-400 border border-green-500/30'
                    : 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                }`}
              >
                Harvard Score: {audit.score}%
              </span>
            </div>
            <h2 className="font-serif italic font-light text-xl text-white leading-snug">
              {reference.title}
            </h2>
            <p className="text-xs text-[#777]">
              {reference.authors.map((a) => (a.isCorporate ? a.corporateName : `${a.lastName}, ${a.firstName || a.initials || ''}`)).join('; ')}{' '}
              ({reference.year || 'n.d.'})
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(reference)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold uppercase tracking-widest bg-white text-black hover:bg-[#DDD] rounded transition cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Edit</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-[#555] hover:text-white rounded transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#1F1F1F] bg-[#0F0F0F] px-4 gap-2 overflow-x-auto text-xs">
          {[
            { id: 'harvard', label: 'Harvard Citation', icon: BookOpen },
            { id: 'fields', label: 'Metadata Fields', icon: FileText },
            { id: 'audit', label: `Harvard Audit (${audit.issues.length})`, icon: FileCheck2 },
            { id: 'notes', label: `Notes (${reference.notes.length})`, icon: StickyNote },
            { id: 'attachments', label: `PDF & Attachments (${reference.attachments.length})`, icon: Paperclip },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-3 border-b-2 font-medium flex items-center gap-2 cursor-pointer transition whitespace-nowrap text-xs uppercase tracking-wider ${
                  isActive
                    ? 'border-white text-white font-bold'
                    : 'border-transparent text-[#666] hover:text-[#AAA]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 bg-[#0F0F0F]">
          
          {/* TAB 1: HARVARD CITATIONS */}
          {activeTab === 'harvard' && (
            <div className="space-y-6">
              
              {/* Reference List Box */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#666]">
                    Harvard Reference List Format
                  </h3>
                  <button
                    onClick={() => handleCopy(formatHarvardBibliography(reference, false), 'bib')}
                    className="flex items-center gap-1.5 px-3 py-1 text-xs bg-transparent border border-[#333] hover:border-[#555] text-white font-mono cursor-pointer rounded transition"
                  >
                    {copiedSection === 'bib' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3 text-[#777]" />}
                    <span>{copiedSection === 'bib' ? 'Copied!' : 'Copy Citation'}</span>
                  </button>
                </div>
                <div
                  className="p-4 bg-[#111111] border border-[#2A2A2A] rounded-lg font-serif text-sm leading-relaxed text-[#E0E0E0]"
                  dangerouslySetInnerHTML={{ __html: audit.formattedBibliography }}
                />
              </div>

              {/* In-Text Citations Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div className="p-4 bg-[#111111] border border-[#2A2A2A] rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#666]">
                      Parenthetical In-Text
                    </span>
                    <button
                      onClick={() => handleCopy(formatInTextParenthetical(reference), 'parenthetical')}
                      className="text-xs text-[#777] hover:text-white cursor-pointer flex items-center gap-1 font-mono"
                    >
                      {copiedSection === 'parenthetical' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <div className="font-serif text-sm bg-[#161616] p-3 rounded border border-[#222] text-white">
                    {formatInTextParenthetical(reference)}
                  </div>
                </div>

                <div className="p-4 bg-[#111111] border border-[#2A2A2A] rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#666]">
                      Narrative In-Text
                    </span>
                    <button
                      onClick={() => handleCopy(formatInTextNarrative(reference), 'narrative')}
                      className="text-xs text-[#777] hover:text-white cursor-pointer flex items-center gap-1 font-mono"
                    >
                      {copiedSection === 'narrative' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <div className="font-serif text-sm bg-[#161616] p-3 rounded border border-[#222] text-white">
                    {formatInTextNarrative(reference)}
                  </div>
                </div>

              </div>

              {/* Raw Formats Snippets */}
              <div className="space-y-3">
                <h4 className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Raw Export Formats
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 bg-stone-900 text-stone-200 rounded-lg font-mono text-xs space-y-1">
                    <div className="flex items-center justify-between text-stone-400">
                      <span>BibTeX</span>
                      <button
                        onClick={() => handleCopy(exportToBibTeX([reference]), 'bibtex')}
                        className="hover:text-stone-100 cursor-pointer text-[10px]"
                      >
                        Copy BibTeX
                      </button>
                    </div>
                    <pre className="text-[10px] overflow-x-auto text-amber-300">
                      {exportToBibTeX([reference])}
                    </pre>
                  </div>

                  <div className="p-3 bg-stone-900 text-stone-200 rounded-lg font-mono text-xs space-y-1">
                    <div className="flex items-center justify-between text-stone-400">
                      <span>RIS Format</span>
                      <button
                        onClick={() => handleCopy(exportToRIS([reference]), 'ris')}
                        className="hover:text-stone-100 cursor-pointer text-[10px]"
                      >
                        Copy RIS
                      </button>
                    </div>
                    <pre className="text-[10px] overflow-x-auto text-emerald-300">
                      {exportToRIS([reference])}
                    </pre>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: METADATA FIELDS */}
          {activeTab === 'fields' && (
            <div className="space-y-4">
              <div className="border border-stone-200 dark:border-stone-800 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left border-collapse">
                  <tbody>
                    <tr className="border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900">
                      <td className="p-2.5 font-semibold text-stone-500 w-1/3">Reference Type</td>
                      <td className="p-2.5 text-stone-900 dark:text-stone-100 font-mono uppercase">{reference.referenceType}</td>
                    </tr>
                    <tr className="border-b border-stone-200 dark:border-stone-800">
                      <td className="p-2.5 font-semibold text-stone-500">Title</td>
                      <td className="p-2.5 text-stone-900 dark:text-stone-100 font-serif">{reference.title}</td>
                    </tr>
                    <tr className="border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900">
                      <td className="p-2.5 font-semibold text-stone-500">Authors</td>
                      <td className="p-2.5 text-stone-900 dark:text-stone-100">
                        {reference.authors.map((a) => (a.isCorporate ? a.corporateName : `${a.lastName}, ${a.firstName || ''} (${a.initials || ''})`)).join('; ')}
                      </td>
                    </tr>
                    <tr className="border-b border-stone-200 dark:border-stone-800">
                      <td className="p-2.5 font-semibold text-stone-500">Year</td>
                      <td className="p-2.5 text-stone-900 dark:text-stone-100">{reference.year}</td>
                    </tr>
                    {reference.journalName && (
                      <tr className="border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900">
                        <td className="p-2.5 font-semibold text-stone-500">Journal / Periodical</td>
                        <td className="p-2.5 italic text-stone-900 dark:text-stone-100">{reference.journalName}</td>
                      </tr>
                    )}
                    {reference.volume && (
                      <tr className="border-b border-stone-200 dark:border-stone-800">
                        <td className="p-2.5 font-semibold text-stone-500">Volume / Issue</td>
                        <td className="p-2.5 text-stone-900 dark:text-stone-100">Vol. {reference.volume}, Issue {reference.issue || 'N/A'}</td>
                      </tr>
                    )}
                    {reference.pages && (
                      <tr className="border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900">
                        <td className="p-2.5 font-semibold text-stone-500">Page Range</td>
                        <td className="p-2.5 text-stone-900 dark:text-stone-100">pp. {reference.pages}</td>
                      </tr>
                    )}
                    {reference.publisher && (
                      <tr className="border-b border-stone-200 dark:border-stone-800">
                        <td className="p-2.5 font-semibold text-stone-500">Publisher</td>
                        <td className="p-2.5 text-stone-900 dark:text-stone-100">{reference.publisher} ({reference.publisherLocation || 'Location unspecified'})</td>
                      </tr>
                    )}
                    {reference.doi && (
                      <tr className="border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900">
                        <td className="p-2.5 font-semibold text-stone-500">DOI</td>
                        <td className="p-2.5 font-mono text-blue-600 dark:text-blue-400">
                          <a href={`https://doi.org/${reference.doi}`} target="_blank" rel="noreferrer" className="hover:underline flex items-center gap-1">
                            {reference.doi} <ExternalLink className="w-3 h-3" />
                          </a>
                        </td>
                      </tr>
                    )}
                    {reference.url && (
                      <tr className="border-b border-stone-200 dark:border-stone-800">
                        <td className="p-2.5 font-semibold text-stone-500">URL & Access Date</td>
                        <td className="p-2.5 text-stone-900 dark:text-stone-100 break-all">
                          <a href={reference.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">
                            {reference.url}
                          </a>
                          {reference.accessDate && <span className="text-stone-500 block text-[11px] mt-0.5">Accessed: {reference.accessDate}</span>}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {reference.abstract && (
                <div className="space-y-1">
                  <h4 className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Abstract</h4>
                  <p className="text-xs leading-relaxed text-stone-700 dark:text-stone-300 bg-stone-50 dark:bg-stone-900 p-3 rounded border border-stone-200 dark:border-stone-800 italic">
                    "{reference.abstract}"
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: HARVARD AUDIT */}
          {activeTab === 'audit' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between bg-stone-100 dark:bg-stone-900 p-4 rounded-lg border border-stone-200 dark:border-stone-800">
                <div>
                  <div className="text-sm font-bold text-stone-900 dark:text-stone-100">
                    Harvard Formatting Strictness Score
                  </div>
                  <p className="text-xs text-stone-500">
                    Audited against standard Cite Them Right Harvard referencing rules.
                  </p>
                </div>
                <div className="text-2xl font-bold font-mono px-3 py-1 rounded bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900">
                  {audit.score}/100
                </div>
              </div>

              {/* Rules check list */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Formatting Rule Checks
                </h4>
                {audit.issues.length === 0 ? (
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 rounded-lg border border-emerald-200 dark:border-emerald-800 text-xs flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Pristine Harvard formatting! All required bibliographic fields are present and valid.</span>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {audit.issues.map((issue, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border text-xs flex items-start gap-2.5 ${
                          issue.type === 'error'
                            ? 'bg-rose-50 border-rose-200 text-rose-900 dark:bg-rose-950/30 dark:border-rose-900 dark:text-rose-200'
                            : 'bg-amber-50 border-amber-200 text-amber-900 dark:bg-amber-950/30 dark:border-amber-900 dark:text-amber-200'
                        }`}
                      >
                        <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                        <div className="space-y-0.5">
                          <p className="font-semibold">{issue.message}</p>
                          <p className="text-[11px] opacity-90">{issue.recommendation}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Gemini AI Citation Validator */}
              <div className="p-4 bg-gradient-to-r from-stone-900 to-stone-800 text-stone-100 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span className="font-semibold text-xs text-stone-100">
                      Gemini AI Deep Harvard Audit
                    </span>
                  </div>
                  <button
                    onClick={runAiAudit}
                    disabled={isValidatingWithAI}
                    className="px-3 py-1 bg-amber-400 hover:bg-amber-300 text-stone-950 font-semibold rounded text-xs transition cursor-pointer flex items-center gap-1 disabled:opacity-50"
                  >
                    {isValidatingWithAI ? <Wand2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
                    <span>{isValidatingWithAI ? 'Auditing...' : 'Run AI Audit'}</span>
                  </button>
                </div>

                {aiAuditResult && (
                  <div className="bg-stone-950/80 p-3 rounded-lg border border-stone-700 text-xs space-y-2 font-mono">
                    <div className="flex items-center justify-between text-amber-300">
                      <span>AI Score: {aiAuditResult.score}/100</span>
                      <span>Valid: {aiAuditResult.isValid ? 'YES' : 'NO'}</span>
                    </div>
                    <p className="text-stone-300 font-serif leading-relaxed">
                      Corrected: {aiAuditResult.correctedHarvardString}
                    </p>
                    {aiAuditResult.issuesFound?.length > 0 && (
                      <ul className="list-disc pl-4 text-rose-300 space-y-1 text-[11px]">
                        {aiAuditResult.issuesFound.map((iss: string, i: number) => (
                          <li key={i}>{iss}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 4: RESEARCH NOTES */}
          {activeTab === 'notes' && (
            <div className="space-y-5">
              
              {/* Existing Notes */}
              <div className="space-y-3">
                {reference.notes.length === 0 ? (
                  <p className="text-xs text-stone-400 text-center py-4">
                    No research notes linked to this reference yet. Add your first observation below.
                  </p>
                ) : (
                  reference.notes.map((n) => (
                    <div
                      key={n.id}
                      className="p-3.5 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-800 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-xs text-stone-900 dark:text-stone-100">
                          {n.title}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400 font-mono">
                          {n.type}
                        </span>
                      </div>
                      <p className="text-xs text-stone-700 dark:text-stone-300 whitespace-pre-wrap leading-relaxed">
                        {n.content}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {/* Add Note Form */}
              <form onSubmit={handleAddNote} className="p-4 bg-stone-100 dark:bg-stone-900 rounded-xl space-y-3">
                <h4 className="text-xs font-semibold text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-amber-600" />
                  <span>Add Linked Research Note</span>
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="Note Title / Summary Heading"
                    value={newNoteTitle}
                    onChange={(e) => setNewNoteTitle(e.target.value)}
                    className="sm:col-span-2 p-2 text-xs bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                    required
                  />
                  <select
                    value={newNoteType}
                    onChange={(e) => setNewNoteType(e.target.value as any)}
                    className="p-2 text-xs bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                  >
                    <option value="summary">Summary</option>
                    <option value="lit_review">Literature Review</option>
                    <option value="quote">Direct Quote</option>
                    <option value="idea">Idea / Hypothesis</option>
                    <option value="observation">Personal Observation</option>
                  </select>
                </div>

                <textarea
                  rows={3}
                  placeholder="Enter markdown note content, direct quotations with page numbers, or methodology critiques..."
                  value={newNoteContent}
                  onChange={(e) => setNewNoteContent(e.target.value)}
                  className="w-full p-2.5 text-xs bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                  required
                />

                <button
                  type="submit"
                  className="px-3 py-1.5 bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900 rounded text-xs font-medium hover:bg-stone-800 transition cursor-pointer"
                >
                  Save Note
                </button>
              </form>

            </div>
          )}

          {/* TAB 5: PDF & ATTACHMENTS */}
          {activeTab === 'attachments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Attached PDFs & Papers
                </h4>
                <button
                  onClick={() => onLaunchPdfReader(reference)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs transition cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Launch PDF Reader</span>
                </button>
              </div>

              {reference.attachments.length === 0 ? (
                <div className="p-8 text-center text-stone-400 bg-stone-50 dark:bg-stone-900/50 rounded-lg border border-dashed border-stone-300 dark:border-stone-800">
                  <Paperclip className="w-8 h-8 mx-auto mb-2 text-stone-300 stroke-1" />
                  <p className="text-xs">No PDF file attached to this reference.</p>
                  <button
                    onClick={() => onLaunchPdfReader(reference)}
                    className="mt-2 text-xs text-blue-600 hover:underline font-medium"
                  >
                    Launch Interactive Reader Simulation & Attach PDF
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {reference.attachments.map((att) => (
                    <div
                      key={att.id}
                      className="p-3 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <Paperclip className="w-5 h-5 text-blue-600 shrink-0" />
                        <div>
                          <p className="font-semibold text-xs text-stone-900 dark:text-stone-100">
                            {att.fileName}
                          </p>
                          <p className="text-[10px] text-stone-500">
                            {att.fileSize} • {att.pageCount || 10} pages • {att.highlights?.length || 0} highlights
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => onLaunchPdfReader(reference)}
                        className="px-2.5 py-1 text-xs bg-stone-200 dark:bg-stone-800 text-stone-800 dark:text-stone-200 rounded font-medium hover:bg-stone-300 cursor-pointer"
                      >
                        Open Reader
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
