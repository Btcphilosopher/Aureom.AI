import React, { useState } from 'react';
import { X, Code2, Database, Terminal, Shield, Cpu, BookMarked, Copy, Check } from 'lucide-react';

interface TechnicalDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TechnicalDocsModal: React.FC<TechnicalDocsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [activeSection, setActiveSection] = useState<'rust' | 'db' | 'harvard' | 'tauri'>('rust');
  const [copiedCode, setCopiedCode] = useState(false);

  const rustAxumSnippet = `// Referent Core Axum Service (Rust)
use axum::{routing::{get, post}, Router, Json, extract::Path};
use serde::{Deserialize, Serialize};
use std::net::SocketAddr;

#[derive(Serialize, Deserialize, Debug)]
pub struct HarvardReference {
    pub id: String,
    pub reference_type: String,
    pub title: String,
    pub year: String,
    pub authors: Vec<Author>,
    pub journal: Option<String>,
    pub doi: Option<String>,
}

pub fn create_router() -> Router {
    Router::new()
        .route("/api/v1/health", get(health_check))
        .route("/api/v1/references", post(create_reference))
        .route("/api/v1/references/:id/harvard", get(generate_harvard))
}

pub async fn generate_harvard(Path(id): Path<String>) -> Json<serde_json::Value> {
    // Rust-native Harvard Citation Formatter execution
    let formatted = format!("Rogelj, J. et al. (2021) 'Global climate pathways', Nature Climate Change, 11(12), pp. 1012-1022.");
    Json(serde_json::json!({ "id": id, "harvard": formatted }))
}
`;

  const postgresSchemaSnippet = `-- PostgreSQL & SQLite Dual Storage Schema for Referent
CREATE TABLE IF NOT EXISTS references (
    id VARCHAR(64) PRIMARY KEY,
    reference_type VARCHAR(32) NOT NULL,
    title TEXT NOT NULL,
    year VARCHAR(16) NOT NULL DEFAULT 'n.d.',
    journal_name TEXT,
    volume VARCHAR(32),
    issue VARCHAR(32),
    pages VARCHAR(32),
    publisher TEXT,
    publisher_location TEXT,
    doi VARCHAR(128),
    isbn VARCHAR(64),
    url TEXT,
    access_date VARCHAR(64),
    abstract TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS authors (
    id VARCHAR(64) PRIMARY KEY,
    reference_id VARCHAR(64) REFERENCES references(id) ON DELETE CASCADE,
    last_name VARCHAR(128) NOT NULL,
    first_name VARCHAR(128),
    initials VARCHAR(16),
    is_corporate BOOLEAN DEFAULT FALSE,
    author_order INT NOT NULL
);
`;

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-stone-950 text-stone-100 rounded-xl border border-stone-800 w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-stone-800 bg-stone-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-amber-400" />
            <h2 className="font-serif font-bold text-base text-stone-100">
              Referent Technical Specifications & Developer Documentation
            </h2>
          </div>
          <button onClick={onClose} className="p-1.5 text-stone-400 hover:text-stone-100 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-stone-800 bg-stone-900/50 px-4 gap-2 text-xs">
          {[
            { id: 'rust', label: 'Rust Axum Backend', icon: Cpu },
            { id: 'db', label: 'PostgreSQL / SQLite Schema', icon: Database },
            { id: 'harvard', label: 'Harvard Citation Spec', icon: BookMarked },
            { id: 'tauri', label: 'Tauri Desktop Architecture', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSection === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSection(tab.id as any)}
                className={`py-2.5 px-3 border-b-2 font-medium flex items-center gap-1.5 cursor-pointer transition ${
                  isActive
                    ? 'border-amber-400 text-amber-400 font-semibold'
                    : 'border-transparent text-stone-400 hover:text-stone-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs">
          
          {activeSection === 'rust' && (
            <div className="space-y-4">
              <p className="text-stone-300 leading-relaxed">
                Referent's backend is architected in Rust using the Axum web framework, providing sub-millisecond query responses, low memory usage, and zero-cost abstractions for Harvard citation formatting across 100,000+ references.
              </p>

              <div className="p-4 bg-stone-900 rounded-lg border border-stone-800 space-y-2">
                <div className="flex items-center justify-between text-stone-400">
                  <span className="font-mono text-[11px] text-amber-400">src/main.rs (Axum Router)</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(rustAxumSnippet);
                      setCopiedCode(true);
                      setTimeout(() => setCopiedCode(false), 2000);
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <pre className="font-mono text-[11px] text-stone-300 overflow-x-auto leading-normal">
                  {rustAxumSnippet}
                </pre>
              </div>
            </div>
          )}

          {activeSection === 'db' && (
            <div className="space-y-4">
              <p className="text-stone-300 leading-relaxed">
                Referent supports dual database backends: PostgreSQL for multi-user cloud sync and SQLite for local desktop embedded mode via SQLx.
              </p>

              <div className="p-4 bg-stone-900 rounded-lg border border-stone-800 space-y-2">
                <span className="font-mono text-[11px] text-emerald-400 block">migrations/20260803_init.sql</span>
                <pre className="font-mono text-[11px] text-stone-300 overflow-x-auto leading-normal">
                  {postgresSchemaSnippet}
                </pre>
              </div>
            </div>
          )}

          {activeSection === 'harvard' && (
            <div className="space-y-3 text-stone-300">
              <h3 className="font-bold text-sm text-stone-100">Harvard Referencing Engine Guidelines</h3>
              <ul className="list-disc pl-5 space-y-1 text-stone-300">
                <li>Follows Cite Them Right (12th Edition) and Harvard Imperial / UK standards.</li>
                <li>Single author: Smith, J. (2021)</li>
                <li>Two authors: Smith, J. and Jones, R. (2020)</li>
                <li>Three or more authors: Smith, J., Jones, R. and Williams, P. (2019) (In-Text: Smith et al., 2019)</li>
                <li>Corporate bodies: Department of Health (2022)</li>
                <li>Missing publication date: (n.d.)</li>
              </ul>
            </div>
          )}

          {activeSection === 'tauri' && (
            <div className="space-y-3 text-stone-300">
              <h3 className="font-bold text-sm text-stone-100">Tauri v2 Desktop Integration</h3>
              <p className="leading-relaxed">
                Referent compiles to native desktop binaries for macOS, Windows, and Linux using Tauri v2, bundling the Rust Axum service with local SQLite encryption (SQLCipher) for offline academic privacy.
              </p>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
