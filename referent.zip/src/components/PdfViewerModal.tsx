import React, { useState } from 'react';
import {
  X,
  BookOpen,
  Highlighter,
  MessageSquare,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Download,
  Paperclip,
  Check,
  Wand2,
} from 'lucide-react';
import { Reference, PDFHighlight } from '../types';

interface PdfViewerModalProps {
  reference: Reference | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateReference: (updated: Reference) => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  reference,
  isOpen,
  onClose,
  onUpdateReference,
}) => {
  if (!isOpen || !reference) return null;

  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 11;
  const [zoom, setZoom] = useState(100);
  const [activeTool, setActiveTool] = useState<'cursor' | 'highlight' | 'note'>('cursor');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);

  const [highlights, setHighlights] = useState<PDFHighlight[]>(
    reference.attachments[0]?.highlights || [
      {
        id: 'hl-sample-1',
        page: 2,
        text: 'Integrated assessment models demonstrate significant mitigation advantages when carbon tax pricing exceeds $75/ton before 2030.',
        color: 'yellow',
        comment: 'Key quote for Chapter 3 thesis argument.',
        createdAt: new Date().toISOString(),
      },
    ]
  );

  const handleAddHighlight = (color: PDFHighlight['color']) => {
    const textSelection = window.getSelection()?.toString();
    const newHl: PDFHighlight = {
      id: `hl-${Date.now()}`,
      page: currentPage,
      text: textSelection || 'Selected key passage on climate mitigation thresholds.',
      color,
      comment: 'User highlight on page ' + currentPage,
      createdAt: new Date().toISOString(),
    };
    setHighlights([...highlights, newHl]);
  };

  const handleRunAiPaperAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const paperText = `
TITLE: ${reference.title}
AUTHORS: ${reference.authors.map((a) => a.lastName).join(', ')}
YEAR: ${reference.year}
ABSTRACT: ${reference.abstract || 'This paper investigates climate change policy pathways, integrated assessment modeling, and carbon economics.'}

SECTION 1: INTRODUCTION
Climate change represents a critical challenge for global economic governance. In this study, we model decarbonization pathways across 204 sovereign states.

SECTION 2: METHODOLOGY
We deploy integrated assessment modeling (IAM) frameworks combining greenhouse gas inventory databases with macro-econometric projections.

SECTION 3: KEY FINDINGS
1. Carbon neutrality by 2050 prevents 1.5°C overshoot.
2. Grid storage investment must scale by 14x over 2020 baselines.
3. Direct air capture technology requires aggressive public subsidy scaling.
      `;

      const res = await fetch('/api/gemini/analyze-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: paperText,
          fileName: `${reference.authors[0]?.lastName}_${reference.year}_paper.pdf`,
        }),
      });

      const data = await res.json();
      if (data.success && data.analysis) {
        setAiAnalysis(data.analysis);
      }
    } catch (err) {
      console.error('AI Paper Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-hidden">
      <div className="bg-stone-900 text-stone-100 rounded-xl border border-stone-800 w-full max-w-6xl h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Reader Header */}
        <div className="p-3 border-b border-stone-800 bg-stone-950 flex items-center justify-between gap-3 text-xs">
          
          <div className="flex items-center gap-2 truncate max-w-lg">
            <BookOpen className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="font-serif font-bold text-sm truncate text-stone-100">
              {reference.title}
            </span>
            <span className="text-[10px] px-1.5 py-0.2 bg-stone-800 rounded font-mono text-stone-400 shrink-0">
              PDF Reader
            </span>
          </div>

          {/* Reader Controls */}
          <div className="flex items-center gap-2">
            
            <div className="flex items-center gap-1 bg-stone-900 px-2 py-1 rounded border border-stone-800">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                className="p-1 hover:text-white cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="font-mono text-[11px] px-1">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                className="p-1 hover:text-white cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center gap-1 bg-stone-900 px-2 py-1 rounded border border-stone-800">
              <button onClick={() => setZoom(Math.max(70, zoom - 10))} className="p-1 hover:text-white cursor-pointer">
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="font-mono text-[11px] px-1">{zoom}%</span>
              <button onClick={() => setZoom(Math.min(150, zoom + 10))} className="p-1 hover:text-white cursor-pointer">
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={handleRunAiPaperAnalysis}
              disabled={isAnalyzing}
              className="px-3 py-1 bg-amber-400 hover:bg-amber-300 text-stone-950 font-semibold rounded text-xs transition cursor-pointer flex items-center gap-1 disabled:opacity-50"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>{isAnalyzing ? 'Analyzing Paper...' : 'AI Key Insights'}</span>
            </button>

            <button onClick={onClose} className="p-1.5 text-stone-400 hover:text-white cursor-pointer ml-2">
              <X className="w-5 h-5" />
            </button>
          </div>

        </div>

        {/* Reader Layout: Paper Stage + Sidebar Panel */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Main Paper Viewer Stage */}
          <div className="flex-1 bg-stone-950 p-6 overflow-y-auto flex justify-center items-start">
            
            <div
              className="bg-white text-stone-900 shadow-2xl p-8 rounded min-h-[800px] w-full max-w-3xl font-serif space-y-6 transition-transform origin-top"
              style={{ transform: `scale(${zoom / 100})` }}
            >
              {/* Paper Simulated Page Header */}
              <div className="border-b border-stone-200 pb-4 text-center space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-stone-500">
                  {reference.journalName || 'ACADEMIC PUBLICATION'} — VOL {reference.volume || '11'}, ISSUE {reference.issue || '1'}
                </span>
                <h1 className="text-xl font-bold font-serif leading-tight text-stone-900">
                  {reference.title}
                </h1>
                <p className="text-xs font-sans text-stone-600">
                  {reference.authors.map((a) => (a.isCorporate ? a.corporateName : `${a.firstName || ''} ${a.lastName}`)).join(', ')}
                </p>
                <p className="text-[10px] font-mono text-stone-400">
                  DOI: {reference.doi || '10.1038/s41558-021-01185-3'}
                </p>
              </div>

              {/* Simulated Page Content */}
              <div className="space-y-4 text-xs leading-relaxed text-stone-800">
                
                <div className="bg-stone-50 p-4 rounded border-l-2 border-stone-900 space-y-1">
                  <span className="font-sans font-bold text-[10px] uppercase text-stone-500 tracking-wider">
                    Abstract
                  </span>
                  <p className="italic">
                    "{reference.abstract || 'We assess global decarbonization transformation pathways required to limit global mean surface temperature rise to 1.5°C above pre-industrial levels.'}"
                  </p>
                </div>

                <h3 className="font-sans font-bold text-sm text-stone-900 border-b pb-1">
                  1. Introduction & Theoretical Framework
                </h3>
                <p>
                  Anthropogenic climate change presents unprecedented risks to planetary systems and human socio-economic welfare.
                  Limiting warming requires structural transformation across energy, transportation, and industrial sectors.
                </p>

                {/* Highlight Overlay Simulation */}
                <div className="bg-yellow-100 text-stone-950 p-2 rounded border-l-4 border-amber-500 font-sans my-2 shadow-sm">
                  <span className="font-bold text-[10px] uppercase block text-amber-900">
                    Highlighted Passage (Page {currentPage}):
                  </span>
                  "Immediate reduction of methane emissions achieves near-term temperature stabilization benefits exceeding CO2 removal efforts alone."
                </div>

                <p>
                  As demonstrated in recent IAM simulations, carbon pricing mechanisms combined with renewable capital subsidies yield superior outcome trajectories compared to regulatory mandates alone.
                </p>

                <h3 className="font-sans font-bold text-sm text-stone-900 border-b pb-1">
                  2. Integrated Assessment Methodology
                </h3>
                <p>
                  We project carbon budget trajectories using the MESSAGEix-GLOBIOM integrated assessment model coupled with MAGICC7 climate emulators.
                </p>

              </div>

              <div className="pt-8 border-t border-stone-200 text-center text-[10px] font-mono text-stone-400">
                Page {currentPage} of {totalPages} • Referent Interactive PDF Engine
              </div>

            </div>

          </div>

          {/* Right Panel: Highlights, Sticky Notes & AI Insights */}
          <div className="w-80 bg-stone-900 border-l border-stone-800 p-4 overflow-y-auto space-y-5 text-xs">
            
            {/* Quick Tools */}
            <div className="space-y-2">
              <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
                Annotation Tools
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => handleAddHighlight('yellow')}
                  className="flex-1 py-1.5 bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 rounded hover:bg-yellow-400/30 font-medium cursor-pointer flex items-center justify-center gap-1"
                >
                  <Highlighter className="w-3.5 h-3.5" />
                  <span>Highlight</span>
                </button>
              </div>
            </div>

            {/* AI Insights Card */}
            {aiAnalysis && (
              <div className="p-3.5 bg-gradient-to-b from-stone-800 to-stone-950 rounded-xl border border-stone-700 space-y-2">
                <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
                  <Sparkles className="w-4 h-4" />
                  <span>Gemini Executive Summary</span>
                </div>
                
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-stone-300">
                  {aiAnalysis.summaryBullets?.map((b: string, i: number) => (
                    <li key={i}>{b}</li>
                  ))}
                </ul>

                {aiAnalysis.methodology && (
                  <div className="pt-2 border-t border-stone-800">
                    <span className="text-[10px] font-mono text-stone-400 uppercase">Methodology:</span>
                    <p className="text-[11px] text-stone-300">{aiAnalysis.methodology}</p>
                  </div>
                )}
              </div>
            )}

            {/* Highlights List */}
            <div className="space-y-3">
              <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
                Highlights & Annotations ({highlights.length})
              </span>

              {highlights.map((hl) => (
                <div key={hl.id} className="p-3 bg-stone-950 rounded-lg border border-stone-800 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-stone-400">
                    <span>Page {hl.page}</span>
                    <span className="font-mono text-amber-400">Highlight</span>
                  </div>
                  <p className="text-stone-200 italic font-serif text-[11px]">"{hl.text}"</p>
                  {hl.comment && <p className="text-[10px] text-stone-400 pt-1 border-t border-stone-900">Note: {hl.comment}</p>}
                </div>
              ))}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
