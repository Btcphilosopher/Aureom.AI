import React from 'react';
import {
  X,
  BarChart3,
  BookOpen,
  FolderKanban,
  Award,
  CheckCircle2,
  TrendingUp,
  Layers,
  Star,
  Users,
} from 'lucide-react';
import { Reference, Project } from '../types';
import { validateHarvardRules } from '../lib/harvardEngine';

interface DashboardAnalyticsProps {
  isOpen: boolean;
  onClose: () => void;
  references: Reference[];
  projects: Project[];
}

export const DashboardAnalytics: React.FC<DashboardAnalyticsProps> = ({
  isOpen,
  onClose,
  references,
  projects,
}) => {
  if (!isOpen) return null;

  const totalRefs = references.length;
  const completedCount = references.filter((r) => r.readingStatus === 'completed').length;
  const readingCount = references.filter((r) => r.readingStatus === 'reading').length;
  const starredCount = references.filter((r) => r.isStarred).length;

  const avgAuditScore = Math.round(
    references.reduce((acc, r) => acc + validateHarvardRules(r).score, 0) / (totalRefs || 1)
  );

  // Years distribution
  const yearCounts: Record<string, number> = {};
  references.forEach((r) => {
    const y = r.year || 'n.d.';
    yearCounts[y] = (yearCounts[y] || 0) + 1;
  });

  // Reference Type distribution
  const typeCounts: Record<string, number> = {};
  references.forEach((r) => {
    typeCounts[r.referenceType] = (typeCounts[r.referenceType] || 0) + 1;
  });

  // Top Authors
  const authorCounts: Record<string, number> = {};
  references.forEach((r) => {
    r.authors.forEach((a) => {
      const name = a.isCorporate ? a.corporateName || 'Corporate' : a.lastName;
      if (name) {
        authorCounts[name] = (authorCounts[name] || 0) + 1;
      }
    });
  });

  const topAuthors = Object.entries(authorCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0A0A0A] border border-[#1F1F1F] rounded-lg w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-white">
        
        {/* Header */}
        <div className="p-4 border-b border-[#1F1F1F] bg-[#0A0A0A] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-orange-500" />
            <h2 className="font-serif italic font-light text-lg text-white">
              Academic Dashboard & Citation Metrics
            </h2>
          </div>
          <button onClick={onClose} className="p-1.5 text-[#555] hover:text-white rounded transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 bg-[#0F0F0F] overflow-y-auto space-y-6 flex-1 text-xs">
          
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-[#141414] rounded-lg border border-[#2A2A2A] space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#666]">Total References</span>
              <div className="text-2xl font-light font-serif text-white">{totalRefs}</div>
              <p className="text-[10px] text-[#555]">{starredCount} starred papers</p>
            </div>

            <div className="p-4 bg-[#141414] rounded-lg border border-[#2A2A2A] space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#666]">Active Projects</span>
              <div className="text-2xl font-light font-serif text-orange-500">{projects.length}</div>
              <p className="text-[10px] text-[#555]">Structured bibliographies</p>
            </div>

            <div className="p-4 bg-[#141414] rounded-lg border border-[#2A2A2A] space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#666]">Reading Velocity</span>
              <div className="text-2xl font-light font-serif text-green-400">{completedCount}</div>
              <p className="text-[10px] text-[#555]">{readingCount} currently in progress</p>
            </div>

            <div className="p-4 bg-[#141414] rounded-lg border border-[#2A2A2A] space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#666]">Harvard Compliance</span>
              <div className="text-2xl font-light font-serif text-white">{avgAuditScore}%</div>
              <p className="text-[10px] text-[#555]">Cite Them Right Standard</p>
            </div>
          </div>

          {/* Breakdown Grids */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Reference Types */}
            <div className="p-4 bg-[#141414] rounded-lg border border-[#2A2A2A] space-y-3">
              <h3 className="font-bold text-orange-400 uppercase tracking-wider text-[10px]">
                Publication Types Distribution
              </h3>
              <div className="space-y-2">
                {Object.entries(typeCounts).map(([type, count]) => {
                  const pct = Math.round((count / totalRefs) * 100);
                  return (
                    <div key={type} className="space-y-0.5">
                      <div className="flex justify-between text-[11px]">
                        <span className="capitalize font-medium text-[#CCC]">
                          {type.replace(/_/g, ' ')}
                        </span>
                        <span className="font-mono text-[#666]">{count} ({pct}%)</span>
                      </div>
                      <div className="w-full bg-[#222] h-1.5 rounded-full overflow-hidden">
                        <div className="bg-orange-500 h-full rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Top Authors */}
            <div className="p-4 bg-stone-50 dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 space-y-3">
              <h3 className="font-semibold text-stone-800 dark:text-stone-200 uppercase tracking-wider text-[11px]">
                Most-Cited Authors in Workspace
              </h3>
              <div className="space-y-2">
                {topAuthors.map(([name, count]) => (
                  <div key={name} className="flex items-center justify-between p-2 bg-white dark:bg-stone-950 rounded border border-stone-200 dark:border-stone-800">
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-stone-400" />
                      <span className="font-serif font-medium text-stone-900 dark:text-stone-100">{name}</span>
                    </div>
                    <span className="font-mono px-2 py-0.5 bg-stone-100 dark:bg-stone-800 rounded font-bold text-stone-700 dark:text-stone-300">
                      {count} {count === 1 ? 'work' : 'works'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
