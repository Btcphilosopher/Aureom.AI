import React, { useState } from 'react';
import { X, Plus, Trash2, Building, User, Save, Sparkles, Search } from 'lucide-react';
import { Author, Reference, ReferenceType } from '../types';

interface ReferenceEditModalProps {
  reference: Partial<Reference> | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (ref: Reference) => void;
}

const typeLabels: Record<ReferenceType, string> = {
  journal_article: 'Journal Article',
  book: 'Book',
  conference_paper: 'Conference Paper',
  government_report: 'Government Report',
  website: 'Website',
  newspaper: 'Newspaper',
  magazine: 'Magazine',
  thesis: 'Thesis / Dissertation',
  dataset: 'Dataset',
  patent: 'Patent',
  video: 'Video',
  podcast: 'Podcast',
  map: 'Map',
  legislation: 'Legislation',
  court_case: 'Court Case',
  standard: 'Standard',
  company_report: 'Company Report',
  technical_manual: 'Technical Manual',
  personal_communication: 'Personal Comm.',
};

export const ReferenceEditModal: React.FC<ReferenceEditModalProps> = ({
  reference,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [type, setType] = useState<ReferenceType>(reference?.referenceType || 'journal_article');
  const [title, setTitle] = useState(reference?.title || '');
  const [year, setYear] = useState(reference?.year || new Date().getFullYear().toString());
  const [journalName, setJournalName] = useState(reference?.journalName || '');
  const [volume, setVolume] = useState(reference?.volume || '');
  const [issue, setIssue] = useState(reference?.issue || '');
  const [pages, setPages] = useState(reference?.pages || '');
  const [edition, setEdition] = useState(reference?.edition || '');
  const [publisher, setPublisher] = useState(reference?.publisher || '');
  const [publisherLocation, setPublisherLocation] = useState(reference?.publisherLocation || '');
  const [institution, setInstitution] = useState(reference?.institution || '');
  const [doi, setDoi] = useState(reference?.doi || '');
  const [isbn, setIsbn] = useState(reference?.isbn || '');
  const [url, setUrl] = useState(reference?.url || '');
  const [accessDate, setAccessDate] = useState(reference?.accessDate || '');
  const [abstract, setAbstract] = useState(reference?.abstract || '');
  const [tagsInput, setTagsInput] = useState(reference?.tags ? reference.tags.join(', ') : '');

  const [authors, setAuthors] = useState<Author[]>(
    reference?.authors && reference.authors.length > 0
      ? reference.authors
      : [{ id: 'aut-1', lastName: '', firstName: '', initials: '', isCorporate: false }]
  );

  const [isSearchingAi, setIsSearchingAi] = useState(false);
  const [aiQuery, setAiQuery] = useState('');

  const handleAddAuthor = () => {
    setAuthors([
      ...authors,
      { id: `aut-${Date.now()}`, lastName: '', firstName: '', initials: '', isCorporate: false },
    ]);
  };

  const handleRemoveAuthor = (index: number) => {
    if (authors.length > 1) {
      setAuthors(authors.filter((_, i) => i !== index));
    }
  };

  const handleAuthorChange = (index: number, field: keyof Author, val: any) => {
    const updated = [...authors];
    updated[index] = { ...updated[index], [field]: val };

    if (field === 'firstName' && val) {
      updated[index].initials = val.charAt(0).toUpperCase();
    }

    setAuthors(updated);
  };

  const handleAiLookup = async () => {
    if (!aiQuery) return;
    setIsSearchingAi(true);
    try {
      const res = await fetch('/api/gemini/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: aiQuery, type }),
      });
      const data = await res.json();
      if (data.success && data.metadata) {
        const m = data.metadata;
        if (m.title) setTitle(m.title);
        if (m.year) setYear(m.year);
        if (m.journalName) setJournalName(m.journalName);
        if (m.volume) setVolume(m.volume);
        if (m.issue) setIssue(m.issue);
        if (m.pages) setPages(m.pages);
        if (m.publisher) setPublisher(m.publisher);
        if (m.publisherLocation) setPublisherLocation(m.publisherLocation);
        if (m.doi) setDoi(m.doi);
        if (m.isbn) setIsbn(m.isbn);
        if (m.url) setUrl(m.url);
        if (m.accessDate) setAccessDate(m.accessDate);
        if (m.abstract) setAbstract(m.abstract);
        if (m.authors && Array.isArray(m.authors) && m.authors.length > 0) {
          setAuthors(
            m.authors.map((a: any, idx: number) => ({
              id: `aut-ai-${idx}`,
              lastName: a.lastName || 'Anon',
              firstName: a.firstName || '',
              initials: a.initials || (a.firstName ? a.firstName.charAt(0) : ''),
              isCorporate: Boolean(a.isCorporate),
              corporateName: a.corporateName || a.lastName,
            }))
          );
        }
      }
    } catch (err) {
      console.error('AI Lookup error:', err);
    } finally {
      setIsSearchingAi(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const updatedRef: Reference = {
      id: reference?.id || `ref-${Date.now()}`,
      referenceType: type,
      title: title || 'Untitled Publication',
      authors: authors.filter((a) => a.lastName || a.corporateName),
      year: year || 'n.d.',
      journalName,
      volume,
      issue,
      pages,
      edition,
      publisher,
      publisherLocation,
      institution,
      doi,
      isbn,
      url,
      accessDate,
      abstract,
      tags,
      projectId: reference?.projectId,
      isStarred: reference?.isStarred || false,
      readingStatus: reference?.readingStatus || 'unread',
      rating: reference?.rating || 3,
      attachments: reference?.attachments || [],
      notes: reference?.notes || [],
      createdAt: reference?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(updatedRef);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0A0A0A] border border-[#1F1F1F] rounded-lg w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-white">
        
        {/* Header */}
        <div className="p-4 border-b border-[#1F1F1F] bg-[#0A0A0A] flex items-center justify-between">
          <h2 className="font-serif italic font-light text-lg text-white">
            {reference?.id ? 'Edit Reference' : 'New Academic Reference'}
          </h2>
          <button onClick={onClose} className="p-1.5 text-[#555] hover:text-white rounded transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 bg-[#0F0F0F] overflow-y-auto space-y-6 flex-1 text-xs">
          
          {/* AI Auto Fill Assistant */}
          <div className="p-3.5 bg-[#141414] rounded-lg border border-[#2A2A2A] space-y-2">
            <div className="flex items-center gap-1.5 text-orange-400 font-semibold uppercase tracking-wider text-[10px]">
              <Sparkles className="w-3.5 h-3.5 text-orange-500" />
              <span>AI Auto-Fill by DOI / ISBN / Title</span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Paste DOI (10.1038/...), ISBN, or paper title..."
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                className="flex-1 p-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded focus:outline-none focus:border-[#444] text-white placeholder-[#555]"
              />
              <button
                type="button"
                onClick={handleAiLookup}
                disabled={isSearchingAi}
                className="px-3.5 py-1.5 bg-orange-500 hover:bg-orange-400 text-black font-bold uppercase tracking-wider text-[10px] rounded cursor-pointer transition flex items-center gap-1 disabled:opacity-50 shrink-0"
              >
                <Search className="w-3.5 h-3.5" />
                <span>{isSearchingAi ? 'Fetching...' : 'Auto-Fill'}</span>
              </button>
            </div>
          </div>

          {/* Type Selector */}
          <div className="space-y-1">
            <label className="font-semibold text-stone-700 dark:text-stone-300">
              Reference Type (20 Formats)
            </label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as ReferenceType)}
              className="w-full p-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded font-medium focus:outline-none"
            >
              {Object.entries(typeLabels).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          {/* Title & Year */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-3 space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Title *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                placeholder="Full publication title..."
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Year *</label>
              <input
                type="text"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                required
                placeholder="e.g. 2026 or n.d."
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
          </div>

          {/* Authors List */}
          <div className="space-y-3 p-3 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-stone-700 dark:text-stone-300">
                Authors / Editors / Corporate Bodies
              </label>
              <button
                type="button"
                onClick={handleAddAuthor}
                className="flex items-center gap-1 text-xs text-amber-700 dark:text-amber-400 font-semibold cursor-pointer hover:underline"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Author</span>
              </button>
            </div>

            {authors.map((author, index) => (
              <div key={author.id || index} className="flex flex-wrap items-center gap-2 p-2 bg-white dark:bg-stone-950 rounded border border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => handleAuthorChange(index, 'isCorporate', !author.isCorporate)}
                  className={`p-1.5 rounded text-[10px] font-mono cursor-pointer ${
                    author.isCorporate
                      ? 'bg-amber-100 text-amber-800 font-semibold'
                      : 'bg-stone-100 text-stone-600'
                  }`}
                  title="Toggle Corporate Author / Organization"
                >
                  {author.isCorporate ? <Building className="w-3.5 h-3.5 inline mr-1" /> : <User className="w-3.5 h-3.5 inline mr-1" />}
                  {author.isCorporate ? 'Corporate' : 'Person'}
                </button>

                {author.isCorporate ? (
                  <input
                    type="text"
                    placeholder="Organization / Corporate Name (e.g. World Health Organization)"
                    value={author.corporateName || author.lastName}
                    onChange={(e) => {
                      handleAuthorChange(index, 'corporateName', e.target.value);
                      handleAuthorChange(index, 'lastName', e.target.value);
                    }}
                    className="flex-1 p-1.5 bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                  />
                ) : (
                  <>
                    <input
                      type="text"
                      placeholder="Last Name *"
                      value={author.lastName}
                      onChange={(e) => handleAuthorChange(index, 'lastName', e.target.value)}
                      className="w-28 p-1.5 bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                    />
                    <input
                      type="text"
                      placeholder="First Name"
                      value={author.firstName || ''}
                      onChange={(e) => handleAuthorChange(index, 'firstName', e.target.value)}
                      className="w-24 p-1.5 bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                    />
                    <input
                      type="text"
                      placeholder="Initials"
                      value={author.initials || ''}
                      onChange={(e) => handleAuthorChange(index, 'initials', e.target.value)}
                      className="w-16 p-1.5 bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                    />
                  </>
                )}

                {authors.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveAuthor(index)}
                    className="p-1 text-stone-400 hover:text-rose-600 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Conditional Publication Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">
                {type === 'journal_article' ? 'Journal Name' : type === 'conference_paper' ? 'Conference Title' : 'Journal / Periodical'}
              </label>
              <input
                type="text"
                value={journalName}
                onChange={(e) => setJournalName(e.target.value)}
                placeholder="e.g. Nature Climate Change"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Volume & Issue</label>
              <div className="flex gap-1">
                <input
                  type="text"
                  placeholder="Vol."
                  value={volume}
                  onChange={(e) => setVolume(e.target.value)}
                  className="w-1/2 p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Issue"
                  value={issue}
                  onChange={(e) => setIssue(e.target.value)}
                  className="w-1/2 p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Pages</label>
              <input
                type="text"
                value={pages}
                onChange={(e) => setPages(e.target.value)}
                placeholder="e.g. 1012-1022"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Publisher / Institution</label>
              <input
                type="text"
                value={publisher}
                onChange={(e) => setPublisher(e.target.value)}
                placeholder="e.g. Oxford University Press"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Publisher Location</label>
              <input
                type="text"
                value={publisherLocation}
                onChange={(e) => setPublisherLocation(e.target.value)}
                placeholder="e.g. Oxford and New York"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
          </div>

          {/* DOI, ISBN, URL, Access Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">DOI</label>
              <input
                type="text"
                value={doi}
                onChange={(e) => setDoi(e.target.value)}
                placeholder="10.1038/s41558-021-01185-3"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">ISBN</label>
              <input
                type="text"
                value={isbn}
                onChange={(e) => setIsbn(e.target.value)}
                placeholder="978-0262035613"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">URL</label>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://..."
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-stone-700 dark:text-stone-300">Access Date (Website)</label>
              <input
                type="text"
                value={accessDate}
                onChange={(e) => setAccessDate(e.target.value)}
                placeholder="e.g. 15 March 2026"
                className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-stone-700 dark:text-stone-300">Abstract</label>
            <textarea
              rows={3}
              value={abstract}
              onChange={(e) => setAbstract(e.target.value)}
              placeholder="Paper abstract or summary..."
              className="w-full p-2.5 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-stone-700 dark:text-stone-300">Tags (comma separated)</label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="Climate, Policy, Review..."
              className="w-full p-2 bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-700 rounded focus:outline-none"
            />
          </div>

          <div className="pt-4 border-t border-[#1F1F1F] flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-[#333] hover:border-[#555] rounded text-white text-xs uppercase tracking-wider font-semibold cursor-pointer transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-white text-black font-bold uppercase tracking-wider text-xs rounded hover:bg-[#DDD] cursor-pointer flex items-center gap-1.5 transition"
            >
              <Save className="w-4 h-4" />
              <span>Save Reference</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
