export type ReferenceType =
  | 'book'
  | 'journal_article'
  | 'conference_paper'
  | 'government_report'
  | 'website'
  | 'newspaper'
  | 'magazine'
  | 'thesis'
  | 'dataset'
  | 'patent'
  | 'video'
  | 'podcast'
  | 'map'
  | 'legislation'
  | 'court_case'
  | 'standard'
  | 'company_report'
  | 'technical_manual'
  | 'personal_communication';

export interface Author {
  id: string;
  lastName: string;
  firstName?: string;
  initials?: string;
  isCorporate?: boolean;
  corporateName?: string;
  role?: 'author' | 'editor' | 'translator' | 'compiler' | 'inventor' | 'director' | 'presenter';
}

export interface PDFHighlight {
  id: string;
  page: number;
  text: string;
  color: 'yellow' | 'green' | 'blue' | 'pink' | 'purple';
  comment?: string;
  createdAt: string;
}

export interface PDFAnnotation {
  id: string;
  page: number;
  x: number;
  y: number;
  text: string;
  createdAt: string;
}

export interface Attachment {
  id: string;
  referenceId: string;
  fileName: string;
  fileSize: string;
  fileType: string;
  url: string;
  addedAt: string;
  pageCount?: number;
  readingProgress?: number; // 0 to 100
  highlights?: PDFHighlight[];
  annotations?: PDFAnnotation[];
}

export interface ReferenceNote {
  id: string;
  referenceId?: string;
  projectId?: string;
  title: string;
  content: string;
  tags: string[];
  updatedAt: string;
  type: 'summary' | 'lit_review' | 'quote' | 'idea' | 'observation';
}

export interface Reference {
  id: string;
  referenceType: ReferenceType;
  title: string;
  authors: Author[];
  year: string; // e.g., '2023' or 'n.d.'
  month?: string;
  day?: string;
  
  // Specific fields
  journalName?: string;
  volume?: string;
  issue?: string;
  pages?: string; // e.g. "102-118" or "102"
  edition?: string; // e.g. "2nd ed."
  publisher?: string;
  publisherLocation?: string; // e.g. "Oxford"
  institution?: string; // for theses/reports
  reportNumber?: string;
  doi?: string;
  isbn?: string;
  pmid?: string;
  url?: string;
  accessDate?: string; // e.g. "12 January 2026"
  database?: string; // e.g. "JSTOR", "IEEE Xplore"
  conferenceTitle?: string;
  conferenceLocation?: string;
  degreeType?: string; // e.g. "PhD dissertation"
  version?: string;
  patentNumber?: string;
  jurisdiction?: string; // for law
  caseName?: string;
  actTitle?: string;
  chapterNumber?: string;
  
  abstract?: string;
  tags: string[];
  folderId?: string;
  projectId?: string;
  isStarred?: boolean;
  readingStatus: 'unread' | 'reading' | 'completed';
  rating?: number; // 1 to 5
  citationCount?: number;
  attachments: Attachment[];
  notes: ReferenceNote[];
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  color: string;
  createdAt: string;
  tags: string[];
  referenceIds: string[];
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  status: 'todo' | 'in_progress' | 'done';
  dueDate?: string;
  priority: 'low' | 'medium' | 'high';
}

export interface CitationAuditIssue {
  type: 'error' | 'warning' | 'info';
  field?: string;
  message: string;
  recommendation: string;
}

export interface HarvardValidationResult {
  isValid: boolean;
  score: number;
  issues: CitationAuditIssue[];
  formattedBibliography: string;
  formattedInTextParenthetical: string;
  formattedInTextNarrative: string;
}
