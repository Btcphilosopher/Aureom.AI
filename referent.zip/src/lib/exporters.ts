import { Reference } from '../types';
import { formatHarvardBibliography, formatHarvardAuthorsList } from './harvardEngine';

/**
 * Converts references into BibTeX format string.
 */
export function exportToBibTeX(references: Reference[]): string {
  return references
    .map((ref) => {
      const citeKey = `${(ref.authors[0]?.lastName || 'Anon').toLowerCase()}${ref.year || 'nd'}${
        ref.title ? ref.title.split(' ')[0].toLowerCase().replace(/[^a-z]/g, '') : 'work'
      }`;

      let entryType = 'article';
      if (ref.referenceType === 'book') entryType = 'book';
      else if (ref.referenceType === 'conference_paper') entryType = 'inproceedings';
      else if (ref.referenceType === 'thesis') entryType = 'phdthesis';
      else if (ref.referenceType === 'government_report' || ref.referenceType === 'technical_manual') entryType = 'techreport';
      else if (ref.referenceType === 'website') entryType = 'misc';

      const authorList = ref.authors
        .map((a) => (a.isCorporate ? `{${a.corporateName}}` : `${a.lastName}, ${a.firstName || a.initials || ''}`))
        .join(' and ');

      const lines = [
        `@${entryType}{${citeKey},`,
        `  author = {${authorList}},`,
        `  title = {${ref.title}},`,
        `  year = {${ref.year || 'n.d.'}},`,
      ];

      if (ref.journalName) lines.push(`  journal = {${ref.journalName}},`);
      if (ref.volume) lines.push(`  volume = {${ref.volume}},`);
      if (ref.issue) lines.push(`  number = {${ref.issue}},`);
      if (ref.pages) lines.push(`  pages = {${ref.pages}},`);
      if (ref.publisher) lines.push(`  publisher = {${ref.publisher}},`);
      if (ref.publisherLocation) lines.push(`  address = {${ref.publisherLocation}},`);
      if (ref.doi) lines.push(`  doi = {${ref.doi}},`);
      if (ref.isbn) lines.push(`  isbn = {${ref.isbn}},`);
      if (ref.url) lines.push(`  url = {${ref.url}},`);
      if (ref.abstract) lines.push(`  abstract = {${ref.abstract.replace(/\n/g, ' ')}},`);

      lines.push('}');
      return lines.join('\n');
    })
    .join('\n\n');
}

/**
 * Converts references into RIS format string (Zotero, EndNote, Mendeley compatible).
 */
export function exportToRIS(references: Reference[]): string {
  return references
    .map((ref) => {
      let risType = 'JOUR';
      if (ref.referenceType === 'book') risType = 'BOOK';
      else if (ref.referenceType === 'conference_paper') risType = 'CPAPER';
      else if (ref.referenceType === 'thesis') risType = 'THES';
      else if (ref.referenceType === 'newspaper') risType = 'NEWS';
      else if (ref.referenceType === 'government_report') risType = 'RPRT';
      else if (ref.referenceType === 'website') risType = 'ELEC';

      const lines = [`TY  - ${risType}`];

      lines.push(`TI  - ${ref.title}`);

      ref.authors.forEach((a) => {
        if (a.isCorporate && a.corporateName) {
          lines.push(`AU  - ${a.corporateName}`);
        } else {
          lines.push(`AU  - ${a.lastName}, ${a.firstName || a.initials || ''}`);
        }
      });

      if (ref.year) lines.push(`PY  - ${ref.year}`);
      if (ref.journalName) lines.push(`JO  - ${ref.journalName}`);
      if (ref.volume) lines.push(`VL  - ${ref.volume}`);
      if (ref.issue) lines.push(`IS  - ${ref.issue}`);
      if (ref.pages) {
        const parts = ref.pages.split(/[-–]/);
        lines.push(`SP  - ${parts[0]?.trim() || ref.pages}`);
        if (parts[1]) lines.push(`EP  - ${parts[1]?.trim()}`);
      }
      if (ref.publisher) lines.push(`PB  - ${ref.publisher}`);
      if (ref.publisherLocation) lines.push(`CY  - ${ref.publisherLocation}`);
      if (ref.doi) lines.push(`DO  - ${ref.doi}`);
      if (ref.isbn) lines.push(`SN  - ${ref.isbn}`);
      if (ref.url) lines.push(`UR  - ${ref.url}`);
      if (ref.abstract) lines.push(`AB  - ${ref.abstract.replace(/\n/g, ' ')}`);

      lines.push('ER  - ');
      return lines.join('\n');
    })
    .join('\n\n');
}

/**
 * Converts references to CSV format string.
 */
export function exportToCSV(references: Reference[]): string {
  const headers = [
    'ID',
    'Type',
    'Title',
    'Authors',
    'Year',
    'Journal/Publication',
    'Volume',
    'Issue',
    'Pages',
    'Publisher',
    'DOI',
    'ISBN',
    'URL',
    'Harvard Citation',
  ];

  const escape = (str: string) => `"${(str || '').replace(/"/g, '""')}"`;

  const rows = references.map((ref) => {
    const authorsStr = formatHarvardAuthorsList(ref.authors);
    const harvardText = formatHarvardBibliography(ref, false);
    return [
      escape(ref.id),
      escape(ref.referenceType),
      escape(ref.title),
      escape(authorsStr),
      escape(ref.year),
      escape(ref.journalName || ref.conferenceTitle || ''),
      escape(ref.volume || ''),
      escape(ref.issue || ''),
      escape(ref.pages || ''),
      escape(ref.publisher || ref.institution || ''),
      escape(ref.doi || ''),
      escape(ref.isbn || ''),
      escape(ref.url || ''),
      escape(harvardText),
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Export bibliography as formatted Markdown.
 */
export function exportToMarkdown(references: Reference[]): string {
  const sorted = [...references].sort((a, b) => {
    const aLast = a.authors[0]?.lastName || 'Anon';
    const bLast = b.authors[0]?.lastName || 'Anon';
    return aLast.localeCompare(bLast);
  });

  const list = sorted
    .map((ref) => {
      const text = formatHarvardBibliography(ref, false); // plain text format
      return `- ${text}`;
    })
    .join('\n\n');

  return `# Bibliography (Harvard Style)\n\n${list}\n`;
}

/**
 * Export references as LaTeX bibliography block.
 */
export function exportToLaTeX(references: Reference[]): string {
  const items = references
    .map((ref) => {
      const citeKey = `${(ref.authors[0]?.lastName || 'Anon').toLowerCase()}${ref.year || 'nd'}`;
      const plainText = formatHarvardBibliography(ref, false);
      return `\\bibitem{${citeKey}}\n${plainText}`;
    })
    .join('\n\n');

  return `\\begin{thebibliography}{99}\n\n${items}\n\n\\end{thebibliography}`;
}

/**
 * Triggers a text file download in the browser.
 */
export function downloadFile(filename: string, content: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
