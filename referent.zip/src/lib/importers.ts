import { Reference, ReferenceType, Author } from '../types';

/**
 * Parses a BibTeX content string into Reference objects.
 */
export function parseBibTeX(bibtexString: string): Reference[] {
  const references: Reference[] = [];
  const entries = bibtexString.split(/@([a-zA-Z]+)\s*\{/);

  for (let i = 1; i < entries.length; i += 2) {
    const typeStr = entries[i].toLowerCase();
    const body = entries[i + 1];
    if (!body) continue;

    let refType: ReferenceType = 'journal_article';
    if (typeStr === 'book') refType = 'book';
    else if (typeStr === 'inproceedings' || typeStr === 'conference') refType = 'conference_paper';
    else if (typeStr === 'phdthesis' || typeStr === 'mastersthesis') refType = 'thesis';
    else if (typeStr === 'techreport') refType = 'government_report';
    else if (typeStr === 'misc') refType = 'website';

    const getField = (fieldName: string): string | undefined => {
      const regex = new RegExp(`${fieldName}\\s*=\\s*[\"{]([^\"}]+)[\"}]`, 'i');
      const match = body.match(regex);
      return match ? match[1].trim() : undefined;
    };

    const title = getField('title') || 'Untitled';
    const year = getField('year') || 'n.d.';
    const journal = getField('journal') || getField('booktitle');
    const volume = getField('volume');
    const issue = getField('number');
    const pages = getField('pages');
    const publisher = getField('publisher');
    const address = getField('address');
    const doi = getField('doi');
    const isbn = getField('isbn');
    const url = getField('url');
    const abstract = getField('abstract');

    const authorStr = getField('author') || '';
    const authors: Author[] = authorStr
      .split(' and ')
      .filter((a) => a.trim().length > 0)
      .map((a, idx) => {
        const parts = a.split(',');
        if (parts.length >= 2) {
          return {
            id: `aut-${Date.now()}-${idx}`,
            lastName: parts[0].trim(),
            firstName: parts[1].trim(),
            initials: parts[1].trim().charAt(0),
          };
        } else {
          const spaceParts = a.trim().split(' ');
          const lastName = spaceParts.pop() || 'Unknown';
          const firstName = spaceParts.join(' ');
          return {
            id: `aut-${Date.now()}-${idx}`,
            lastName,
            firstName,
            initials: firstName ? firstName.charAt(0) : '',
          };
        }
      });

    references.push({
      id: `ref-bib-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      referenceType: refType,
      title,
      authors: authors.length > 0 ? authors : [{ id: 'a1', lastName: 'Anonymous' }],
      year,
      journalName: journal,
      volume,
      issue,
      pages,
      publisher,
      publisherLocation: address,
      doi,
      isbn,
      url,
      abstract,
      tags: ['Imported-BibTeX'],
      readingStatus: 'unread',
      attachments: [],
      notes: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  return references;
}

/**
 * Parses RIS content string into Reference objects.
 */
export function parseRIS(risString: string): Reference[] {
  const references: Reference[] = [];
  const entries = risString.split(/ER\s*-\s*/);

  for (const entry of entries) {
    if (!entry.trim()) continue;

    let title = '';
    let year = '';
    let journal = '';
    let volume = '';
    let issue = '';
    let pagesStart = '';
    let pagesEnd = '';
    let publisher = '';
    let publisherLocation = '';
    let doi = '';
    let isbn = '';
    let url = '';
    let abstract = '';
    let risType = 'JOUR';
    const authors: Author[] = [];

    const lines = entry.split('\n');
    for (const line of lines) {
      const match = line.match(/^([A-Z0-9]{2})\s*-\s*(.*)$/);
      if (!match) continue;
      const tag = match[1].trim();
      const val = match[2].trim();

      if (tag === 'TY') risType = val;
      else if (tag === 'TI' || tag === 'T1') title = val;
      else if (tag === 'PY' || tag === 'Y1') year = val.substring(0, 4);
      else if (tag === 'JO' || tag === 'JF' || tag === 'T2') journal = val;
      else if (tag === 'VL') volume = val;
      else if (tag === 'IS') issue = val;
      else if (tag === 'SP') pagesStart = val;
      else if (tag === 'EP') pagesEnd = val;
      else if (tag === 'PB') publisher = val;
      else if (tag === 'CY') publisherLocation = val;
      else if (tag === 'DO') doi = val;
      else if (tag === 'SN') isbn = val;
      else if (tag === 'UR') url = val;
      else if (tag === 'AB') abstract = val;
      else if (tag === 'AU' || tag === 'A1') {
        const parts = val.split(',');
        authors.push({
          id: `aut-${Date.now()}-${authors.length}`,
          lastName: parts[0]?.trim() || val,
          firstName: parts[1]?.trim() || '',
          initials: parts[1]?.trim().charAt(0) || '',
        });
      }
    }

    if (!title) continue;

    let refType: ReferenceType = 'journal_article';
    if (risType === 'BOOK') refType = 'book';
    else if (risType === 'CPAPER') refType = 'conference_paper';
    else if (risType === 'THES') refType = 'thesis';
    else if (risType === 'RPRT') refType = 'government_report';
    else if (risType === 'ELEC') refType = 'website';

    const pages = pagesStart && pagesEnd ? `${pagesStart}-${pagesEnd}` : pagesStart || pagesEnd;

    references.push({
      id: `ref-ris-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      referenceType: refType,
      title,
      authors: authors.length > 0 ? authors : [{ id: 'a1', lastName: 'Anonymous' }],
      year: year || 'n.d.',
      journalName: journal,
      volume,
      issue,
      pages,
      publisher,
      publisherLocation,
      doi,
      isbn,
      url,
      abstract,
      tags: ['Imported-RIS'],
      readingStatus: 'unread',
      attachments: [],
      notes: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  return references;
}
