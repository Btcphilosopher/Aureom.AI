import { Author, HarvardValidationResult, Reference, CitationAuditIssue } from '../types';

/**
 * Formats a list of authors for Harvard style reference list.
 * e.g., "Smith, J.A., Jones, R.B. and Williams, P."
 */
export function formatHarvardAuthorsList(authors: Author[]): string {
  if (!authors || authors.length === 0) return 'Anonymous';

  const formatted = authors.map((a) => {
    if (a.isCorporate && a.corporateName) {
      return a.corporateName;
    }
    const initials = a.initials
      ? a.initials.replace(/\./g, '').split('').join('.') + '.'
      : a.firstName
      ? a.firstName.charAt(0) + '.'
      : '';
    return `${a.lastName}${initials ? ', ' + initials : ''}`;
  });

  if (formatted.length === 1) return formatted[0];
  if (formatted.length === 2) return `${formatted[0]} and ${formatted[1]}`;
  
  if (formatted.length > 3) {
    return `${formatted.slice(0, 3).join(', ')} et al.`;
  }

  const last = formatted.pop();
  return `${formatted.join(', ')} and ${last}`;
}

/**
 * Formats in-text citation parenthetical.
 * e.g. "(Smith, 2021)" or "(Smith and Jones, 2020, p. 14)" or "(Smith et al., 2019)"
 */
export function formatInTextParenthetical(
  ref: Reference,
  pageNumber?: string
): string {
  const yearStr = ref.year || 'n.d.';
  let authorStr = 'Anon.';

  if (ref.authors && ref.authors.length > 0) {
    if (ref.authors[0].isCorporate && ref.authors[0].corporateName) {
      authorStr = ref.authors[0].corporateName;
    } else if (ref.authors.length === 1) {
      authorStr = ref.authors[0].lastName;
    } else if (ref.authors.length === 2) {
      authorStr = `${ref.authors[0].lastName} and ${ref.authors[1].lastName}`;
    } else {
      authorStr = `${ref.authors[0].lastName} et al.`;
    }
  }

  const pageStr = pageNumber
    ? `, p. ${pageNumber}`
    : ref.pages
    ? `, p. ${ref.pages.includes('-') || ref.pages.includes('–') ? 'pp. ' + ref.pages : ref.pages}`
    : '';

  return `(${authorStr}, ${yearStr}${pageStr})`;
}

/**
 * Formats in-text citation narrative.
 * e.g. "Smith (2021)" or "Smith and Jones (2020, p. 14)" or "Smith et al. (2019)"
 */
export function formatInTextNarrative(
  ref: Reference,
  pageNumber?: string
): string {
  const yearStr = ref.year || 'n.d.';
  let authorStr = 'Anon.';

  if (ref.authors && ref.authors.length > 0) {
    if (ref.authors[0].isCorporate && ref.authors[0].corporateName) {
      authorStr = ref.authors[0].corporateName;
    } else if (ref.authors.length === 1) {
      authorStr = ref.authors[0].lastName;
    } else if (ref.authors.length === 2) {
      authorStr = `${ref.authors[0].lastName} and ${ref.authors[1].lastName}`;
    } else {
      authorStr = `${ref.authors[0].lastName} et al.`;
    }
  }

  const pageStr = pageNumber ? `, p. ${pageNumber}` : '';
  return `${authorStr} (${yearStr}${pageStr})`;
}

/**
 * Formats a full Harvard Reference List item as an HTML string (with <em> tags for titles).
 */
export function formatHarvardBibliography(ref: Reference, htmlMode: boolean = true): string {
  const authorsStr = formatHarvardAuthorsList(ref.authors);
  const yearStr = `(${ref.year || 'n.d.'})`;
  const titleStr = ref.title ? ref.title.trim() : 'Untitled Work';

  const em = (text: string) => (htmlMode ? `<em>${text}</em>` : text);

  switch (ref.referenceType) {
    case 'journal_article': {
      const journal = ref.journalName ? em(ref.journalName) : 'Journal';
      const vol = ref.volume ? `, ${ref.volume}` : '';
      const issue = ref.issue ? `(${ref.issue})` : '';
      const pages = ref.pages ? `, pp. ${ref.pages}` : '';
      const doi = ref.doi ? `. doi: ${ref.doi}` : '';
      const url = !ref.doi && ref.url ? `. Available at: ${ref.url}${ref.accessDate ? ` [Accessed ${ref.accessDate}]` : ''}` : '';
      return `${authorsStr} ${yearStr} '${titleStr}', ${journal}${vol}${issue}${pages}${doi}${url}.`;
    }

    case 'book': {
      const bookTitle = em(titleStr);
      const ed = ref.edition ? `. ${ref.edition}` : '';
      const loc = ref.publisherLocation ? `${ref.publisherLocation}: ` : '';
      const pub = ref.publisher ? `${loc}${ref.publisher}` : '';
      const pubStr = pub ? `. ${pub}` : '';
      const doi = ref.doi ? `. doi: ${ref.doi}` : '';
      return `${authorsStr} ${yearStr} ${bookTitle}${ed}${pubStr}${doi}.`;
    }

    case 'conference_paper': {
      const paperTitle = `'${titleStr}'`;
      const confTitle = ref.conferenceTitle ? em(ref.conferenceTitle) : 'Conference Proceedings';
      const loc = ref.conferenceLocation ? `${ref.conferenceLocation}, ` : '';
      const pages = ref.pages ? `, pp. ${ref.pages}` : '';
      const pub = ref.publisher ? `. ${ref.publisher}` : '';
      return `${authorsStr} ${yearStr} ${paperTitle}, in ${confTitle}. ${loc}${pub}${pages}.`;
    }

    case 'government_report': {
      const repTitle = em(titleStr);
      const repNum = ref.reportNumber ? ` (${ref.reportNumber})` : '';
      const loc = ref.publisherLocation ? `${ref.publisherLocation}: ` : '';
      const pub = ref.publisher ? `${loc}${ref.publisher}` : '';
      const pubStr = pub ? `. ${pub}` : '';
      const url = ref.url ? `. Available at: ${ref.url}${ref.accessDate ? ` [Accessed ${ref.accessDate}]` : ''}` : '';
      return `${authorsStr} ${yearStr} ${repTitle}${repNum}${pubStr}${url}.`;
    }

    case 'website': {
      const webTitle = em(titleStr);
      const url = ref.url ? `. Available at: ${ref.url}` : '';
      const access = ref.accessDate ? ` [Accessed ${ref.accessDate}]` : '';
      return `${authorsStr} ${yearStr} ${webTitle}${url}${access}.`;
    }

    case 'newspaper': {
      const newsName = ref.journalName ? em(ref.journalName) : 'Newspaper';
      const dayMonth = ref.day && ref.month ? `, ${ref.day} ${ref.month}` : ref.month ? `, ${ref.month}` : '';
      const pages = ref.pages ? `, p. ${ref.pages}` : '';
      const url = ref.url ? `. Available at: ${ref.url}${ref.accessDate ? ` [Accessed ${ref.accessDate}]` : ''}` : '';
      return `${authorsStr} ${yearStr} '${titleStr}', ${newsName}${dayMonth}${pages}${url}.`;
    }

    case 'magazine': {
      const magName = ref.journalName ? em(ref.journalName) : 'Magazine';
      const monthStr = ref.month ? `, ${ref.month}` : '';
      const pages = ref.pages ? `, pp. ${ref.pages}` : '';
      return `${authorsStr} ${yearStr} '${titleStr}', ${magName}${monthStr}${pages}.`;
    }

    case 'thesis': {
      const thesisTitle = em(titleStr);
      const deg = ref.degreeType || 'Unpublished PhD thesis';
      const inst = ref.institution ? `. ${ref.institution}` : '';
      return `${authorsStr} ${yearStr} ${thesisTitle}. ${deg}${inst}.`;
    }

    case 'dataset': {
      const dsTitle = em(titleStr);
      const pub = ref.publisher ? `. ${ref.publisher}` : '';
      const doi = ref.doi ? `. doi: ${ref.doi}` : '';
      const url = !ref.doi && ref.url ? `. Available at: ${ref.url}${ref.accessDate ? ` [Accessed ${ref.accessDate}]` : ''}` : '';
      return `${authorsStr} ${yearStr} ${dsTitle} [Data set]${pub}${doi}${url}.`;
    }

    case 'patent': {
      const patTitle = em(titleStr);
      const patNum = ref.patentNumber ? `. Patent ${ref.patentNumber}` : '';
      return `${authorsStr} ${yearStr} ${patTitle}${patNum}.`;
    }

    case 'video': {
      const vidTitle = em(titleStr);
      const url = ref.url ? `. Available at: ${ref.url}` : '';
      const access = ref.accessDate ? ` [Accessed ${ref.accessDate}]` : '';
      return `${authorsStr} ${yearStr} ${vidTitle} [Video]${url}${access}.`;
    }

    case 'podcast': {
      const podTitle = ref.journalName ? em(ref.journalName) : 'Podcast';
      const url = ref.url ? `. Available at: ${ref.url}` : '';
      const access = ref.accessDate ? ` [Accessed ${ref.accessDate}]` : '';
      return `${authorsStr} ${yearStr} '${titleStr}', ${podTitle} [Podcast]${url}${access}.`;
    }

    case 'map': {
      const mapTitle = em(titleStr);
      const scale = ref.version ? `, ${ref.version}` : '';
      const loc = ref.publisherLocation ? `${ref.publisherLocation}: ` : '';
      const pub = ref.publisher ? `${loc}${ref.publisher}` : '';
      return `${authorsStr} ${yearStr} ${mapTitle}${scale}. ${pub}.`;
    }

    case 'legislation': {
      const actTitle = ref.actTitle || titleStr;
      const ch = ref.chapterNumber ? ` (c. ${ref.chapterNumber})` : '';
      const loc = ref.publisherLocation ? `${ref.publisherLocation}: ` : '';
      const pub = ref.publisher ? `${loc}${ref.publisher}` : 'The Stationery Office';
      return `${em(actTitle)} ${yearStr}${ch}. ${pub}.`;
    }

    case 'court_case': {
      const caseName = ref.caseName || titleStr;
      const vol = ref.volume ? ` ${ref.volume}` : '';
      const rep = ref.journalName ? ` ${ref.journalName}` : ' All ER';
      const pg = ref.pages ? ` ${ref.pages}` : '';
      return `${em(caseName)} [${ref.year}]${vol}${rep}${pg}.`;
    }

    case 'standard': {
      const stdNum = ref.reportNumber ? `${ref.reportNumber}: ` : '';
      const stdTitle = em(`${stdNum}${titleStr}`);
      const pub = ref.publisher ? `. ${ref.publisher}` : '';
      return `${authorsStr} ${yearStr} ${stdTitle}${pub}.`;
    }

    case 'company_report': {
      const repTitle = em(titleStr);
      const pub = ref.publisher ? `. ${ref.publisher}` : '';
      return `${authorsStr} ${yearStr} ${repTitle}${pub}.`;
    }

    case 'technical_manual': {
      const manTitle = em(titleStr);
      const ver = ref.version ? ` Version ${ref.version}` : '';
      const pub = ref.publisher ? `. ${ref.publisher}` : '';
      return `${authorsStr} ${yearStr} ${manTitle}${ver}${pub}.`;
    }

    case 'personal_communication': {
      const desc = ref.title ? `'${ref.title}'` : 'Personal communication';
      const dayM = ref.day && ref.month ? `, ${ref.day} ${ref.month}` : '';
      return `${authorsStr} ${yearStr} ${desc}, Personal communication${dayM}.`;
    }

    default: {
      const genericTitle = em(titleStr);
      const pub = ref.publisher ? `. ${ref.publisher}` : '';
      return `${authorsStr} ${yearStr} ${genericTitle}${pub}.`;
    }
  }
}

/**
 * Validates a reference object against Harvard rules and calculates a score out of 100.
 */
export function validateHarvardRules(ref: Reference): HarvardValidationResult {
  const issues: CitationAuditIssue[] = [];
  let score = 100;

  if (!ref.authors || ref.authors.length === 0) {
    issues.push({
      type: 'error',
      field: 'authors',
      message: 'Missing author or organization name.',
      recommendation: 'Add author last name or select corporate author if published by an organization.',
    });
    score -= 25;
  }

  if (!ref.title || ref.title.trim() === '') {
    issues.push({
      type: 'error',
      field: 'title',
      message: 'Title is empty.',
      recommendation: 'Enter the exact document or article title.',
    });
    score -= 30;
  }

  if (!ref.year || ref.year.trim() === '') {
    issues.push({
      type: 'warning',
      field: 'year',
      message: 'Publication year is not specified.',
      recommendation: 'Use "n.d." if the publication year is truly unknown.',
    });
    score -= 10;
  }

  if (ref.referenceType === 'journal_article') {
    if (!ref.journalName) {
      issues.push({
        type: 'error',
        field: 'journalName',
        message: 'Journal name is missing for a journal article.',
        recommendation: 'Provide full journal name (e.g. "Nature").',
      });
      score -= 15;
    }
    if (!ref.volume) {
      issues.push({
        type: 'info',
        field: 'volume',
        message: 'Volume number is missing.',
        recommendation: 'Provide volume number for journal accuracy.',
      });
      score -= 5;
    }
    if (!ref.pages) {
      issues.push({
        type: 'warning',
        field: 'pages',
        message: 'Page range is missing.',
        recommendation: 'Include start and end page numbers (e.g. 102-118).',
      });
      score -= 10;
    }
  }

  if (ref.referenceType === 'book' && !ref.publisher) {
    issues.push({
      type: 'warning',
      field: 'publisher',
      message: 'Publisher is missing for a book.',
      recommendation: 'Specify the publisher name.',
    });
    score -= 10;
  }

  if (ref.referenceType === 'website') {
    if (!ref.url) {
      issues.push({
        type: 'error',
        field: 'url',
        message: 'Website URL is missing.',
        recommendation: 'Provide full URL starting with http:// or https://',
      });
      score -= 20;
    }
    if (!ref.accessDate) {
      issues.push({
        type: 'warning',
        field: 'accessDate',
        message: 'Access date is missing for website citation.',
        recommendation: 'Add access date in Harvard format (e.g. "15 March 2026").',
      });
      score -= 10;
    }
  }

  const finalScore = Math.max(0, score);

  return {
    isValid: issues.filter((i) => i.type === 'error').length === 0,
    score: finalScore,
    issues,
    formattedBibliography: formatHarvardBibliography(ref, true),
    formattedInTextParenthetical: formatInTextParenthetical(ref),
    formattedInTextNarrative: formatInTextNarrative(ref),
  };
}
