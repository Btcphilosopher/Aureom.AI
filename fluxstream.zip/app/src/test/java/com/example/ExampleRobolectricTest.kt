package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.FluxStreamDatabase
import com.example.data.model.ContentItem
import com.example.data.repository.ContentRepository
import com.example.data.repository.WalletLedgerRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  private lateinit var database: FluxStreamDatabase
  private lateinit var walletRepository: WalletLedgerRepository
  private lateinit var contentRepository: ContentRepository

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, FluxStreamDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    val dao = database.fluxStreamDao()
    walletRepository = WalletLedgerRepository(dao)
    contentRepository = ContentRepository(dao)
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun testAppNameResource() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FluxStream", appName)
  }

  @Test
  fun testDoubleEntryTopUpAndViewingCharge() = runBlocking {
    // 1. Initial balance is 0
    val initialBalance = walletRepository.userBalanceSats.first()
    assertEquals(0L, initialBalance)

    // 2. Create and settle a 24,500 sats top up
    val invoice = walletRepository.createTopUpInvoice(24500L, "Test Top Up")
    assertNotNull(invoice)
    walletRepository.settleInvoice(invoice.invoiceId)

    // 3. User balance should now be 24,500 sats
    val balanceAfterTopUp = walletRepository.userBalanceSats.first()
    assertEquals(24500L, balanceAfterTopUp)

    // 4. Double-entry ledger invariant: sum of all entries must be 0
    val isBalanced1 = walletRepository.auditLedgerIntegrity()
    assertTrue("Ledger must be balanced after top up", isBalanced1)

    // 5. Process a 10-minute viewing charge @ 20 sats/min = 200 sats
    val chargeSuccess = walletRepository.processStreamingCharge(
      contentId = "the-next-horizon",
      contentTitle = "The Next Horizon",
      creatorName = "Aethelgard Pictures",
      chargeSats = 200L,
      minutesBilled = 10
    )
    assertTrue(chargeSuccess)

    // 6. User balance should now be 24,500 - 200 = 24,300 sats
    val balanceAfterStream = walletRepository.userBalanceSats.first()
    assertEquals(24300L, balanceAfterStream)

    // 7. Creator royalties (80% of 200 sats = 160 sats)
    val creatorRoyalties = walletRepository.creatorEarningsSats.first()
    assertEquals(160L, creatorRoyalties)

    // 8. Platform fee (20% of 200 sats = 40 sats)
    val platformFee = walletRepository.platformFeeSats.first()
    assertEquals(40L, platformFee)

    // 9. Double-entry ledger invariant: total sum MUST still be exactly 0
    val isBalanced2 = walletRepository.auditLedgerIntegrity()
    assertTrue("Ledger must remain strictly balanced (Sum == 0)", isBalanced2)
  }
}
