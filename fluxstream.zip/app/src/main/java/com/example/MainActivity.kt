package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.components.LightningSidebar
import com.example.ui.components.TitleDetailModal
import com.example.ui.components.TopNavBar
import com.example.ui.components.TopUpInvoiceDialog
import com.example.ui.components.VideoPlayerOverlay
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.CreatorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.MoviesScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.FluxStreamTheme
import com.example.ui.theme.MidnightNavy
import com.example.ui.viewmodel.FluxStreamViewModel
import com.example.ui.viewmodel.NavDestination

class MainActivity : ComponentActivity() {

  private val viewModel: FluxStreamViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      FluxStreamTheme {
        Scaffold(
          modifier = Modifier
            .fillMaxSize()
            .background(MidnightNavy),
          contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
          FluxStreamApp(
            viewModel = viewModel,
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          )
        }
      }
    }
  }
}

@Composable
fun FluxStreamApp(
  viewModel: FluxStreamViewModel,
  modifier: Modifier = Modifier
) {
  val currentNav by viewModel.currentNav.collectAsState()
  val balanceBtc by viewModel.balanceBtcFormatted.collectAsState()
  val balanceFiat by viewModel.balanceFiatFormatted.collectAsState()
  val balanceSats by viewModel.userBalanceSats.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()

  val featuredItem by viewModel.featuredContent.collectAsState()
  val allContent by viewModel.allContent.collectAsState()
  val filteredContent by viewModel.filteredContent.collectAsState()
  val watchlistIds by viewModel.watchlistIds.collectAsState()
  val viewingHistory by viewModel.viewingHistory.collectAsState()

  val playbackState by viewModel.playbackState.collectAsState()
  val topUpState by viewModel.topUpState.collectAsState()
  val selectedDetailItem by viewModel.selectedDetailItem.collectAsState()
  val isSidebarVisible by viewModel.isSidebarVisible.collectAsState()

  val isSearchOpen by viewModel.isSearchOpen.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()

  val creatorEarnings by viewModel.creatorEarningsSats.collectAsState()
  val platformFee by viewModel.platformFeeSats.collectAsState()
  val ledgerEntries by viewModel.allLedgerEntries.collectAsState()

  var auditPassed by remember { mutableStateOf(true) }

  // Handle system back navigation
  BackHandler(enabled = playbackState.activeItem != null || selectedDetailItem != null || currentNav != NavDestination.HOME || isSidebarVisible) {
    when {
      playbackState.activeItem != null -> viewModel.playbackEngine.stopPlayback()
      selectedDetailItem != null -> viewModel.selectDetailItem(null)
      isSidebarVisible -> viewModel.toggleSidebar()
      currentNav != NavDestination.HOME -> viewModel.navigateTo(NavDestination.HOME)
    }
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize().background(MidnightNavy)) {
    val isWideScreen = maxWidth >= 840.dp
    val trendingItems = allContent.filter { it.category == "trending" }
    val popularItems = allContent.filter { it.category == "popular" }

    Column(modifier = Modifier.fillMaxSize()) {
      // Top Navigation Bar
      TopNavBar(
        currentNav = currentNav,
        onNavigate = { viewModel.navigateTo(it) },
        balanceBtc = balanceBtc,
        userRole = userProfile.role,
        onRoleChange = { viewModel.switchUserRole(it) },
        onOpenTopUp = { viewModel.openTopUpDialog() },
        onToggleSidebar = { viewModel.toggleSidebar() },
        isSearchOpen = isSearchOpen,
        searchQuery = searchQuery,
        onSearchToggle = { viewModel.toggleSearch() },
        onSearchQueryChange = { viewModel.updateSearchQuery(it) }
      )

      // Main Content Area (With optional side panel)
      Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
        // Main Screen Area
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
        ) {
          when (currentNav) {
            NavDestination.HOME -> {
              if (isSearchOpen && searchQuery.isNotBlank()) {
                MoviesScreen(
                  items = filteredContent,
                  watchlistIds = watchlistIds,
                  onPlayContent = { viewModel.playContent(it) },
                  onInspectContent = { viewModel.selectDetailItem(it) },
                  onToggleWatchlist = { viewModel.toggleWatchlist(it) }
                )
              } else {
                HomeScreen(
                  featuredItem = featuredItem,
                  trendingItems = trendingItems,
                  popularItems = popularItems,
                  watchlistIds = watchlistIds,
                  onPlayContent = { viewModel.playContent(it) },
                  onInspectContent = { viewModel.selectDetailItem(it) },
                  onToggleWatchlist = { viewModel.toggleWatchlist(it) }
                )
              }
            }
            NavDestination.MOVIES, NavDestination.SERIES, NavDestination.GENRES -> {
              MoviesScreen(
                items = if (searchQuery.isNotBlank()) filteredContent else allContent,
                watchlistIds = watchlistIds,
                onPlayContent = { viewModel.playContent(it) },
                onInspectContent = { viewModel.selectDetailItem(it) },
                onToggleWatchlist = { viewModel.toggleWatchlist(it) }
              )
            }
            NavDestination.LIVE_TV -> {
              LiveTvScreen(
                items = allContent,
                onPlayContent = { viewModel.playContent(it) }
              )
            }
            NavDestination.MY_LIBRARY -> {
              LibraryScreen(
                allContent = allContent,
                watchlistIds = watchlistIds,
                viewingHistory = viewingHistory,
                onPlayContent = { viewModel.playContent(it) },
                onInspectContent = { viewModel.selectDetailItem(it) },
                onToggleWatchlist = { viewModel.toggleWatchlist(it) }
              )
            }
            NavDestination.WALLET -> {
              WalletScreen(
                balanceSats = balanceSats,
                balanceBtc = balanceBtc,
                balanceFiat = balanceFiat,
                ledgerEntries = ledgerEntries,
                onOpenTopUp = { viewModel.openTopUpDialog() },
                onFastTopUp = { viewModel.fastTopUp25kSats() },
                onWithdraw = { amount, addr ->
                  // withdrawal
                }
              )
            }
            NavDestination.CREATOR -> {
              CreatorScreen(
                creatorEarningsSats = creatorEarnings,
                myCatalog = allContent.filter { it.creatorName == userProfile.username },
                onSubmitFilm = { title, syn, genre, runtime, rate ->
                  viewModel.submitCreatorFilm(title, syn, genre, runtime, rate)
                }
              )
            }
            NavDestination.ADMIN -> {
              AdminScreen(
                allContentCount = allContent.size,
                grossViewingChargesSats = creatorEarnings + platformFee,
                platformFeeSats = platformFee,
                creatorRoyaltiesSats = creatorEarnings,
                onRunAudit = { auditPassed = true },
                auditPassed = auditPassed
              )
            }
          }
        }

        // Desktop pinned right sidebar (if wide screen and on Home/Explore)
        if (isWideScreen) {
          LightningSidebar(
            balanceBtc = balanceBtc,
            balanceFiat = balanceFiat,
            onTopUpClick = { viewModel.openTopUpDialog() },
            onClose = null,
            modifier = Modifier
              .width(360.dp)
              .fillMaxHeight()
          )
        }
      }
    }

    // Mobile / Tablet Slide-out Drawer for Lightning Micropayments Sidebar
    if (!isWideScreen) {
      AnimatedVisibility(
        visible = isSidebarVisible,
        enter = slideInHorizontally(initialOffsetX = { it }),
        exit = slideOutHorizontally(targetOffsetX = { it }),
        modifier = Modifier.align(Alignment.CenterEnd)
      ) {
        LightningSidebar(
          balanceBtc = balanceBtc,
          balanceFiat = balanceFiat,
          onTopUpClick = {
            viewModel.toggleSidebar()
            viewModel.openTopUpDialog()
          },
          onClose = { viewModel.toggleSidebar() },
          modifier = Modifier
            .fillMaxHeight()
            .width(340.dp)
        )
      }
    }

    // Fullscreen / Overlay Video Player
    if (playbackState.activeItem != null) {
      VideoPlayerOverlay(
        state = playbackState,
        userBalanceSats = balanceSats,
        onPlayPauseToggle = { viewModel.playbackEngine.togglePlayPause() },
        onSeek = { viewModel.playbackEngine.seekTo(it) },
        onSeekRelative = { viewModel.playbackEngine.seekRelative(it) },
        onSpeedChange = { viewModel.playbackEngine.setPlaybackSpeed(it) },
        onQualityChange = { viewModel.playbackEngine.setQuality(it) },
        onToggleSubtitles = { viewModel.playbackEngine.toggleSubtitles() },
        onToggleFullscreen = { viewModel.playbackEngine.toggleFullscreen() },
        onClose = { viewModel.playbackEngine.stopPlayback() },
        onDismissLowBalance = { viewModel.playbackEngine.dismissLowBalanceWarning() },
        onOpenTopUp = { viewModel.openTopUpDialog() },
        modifier = Modifier.fillMaxSize()
      )
    }

    // Title Detail Modal (Inspect & Select Price/Watch)
    if (selectedDetailItem != null) {
      TitleDetailModal(
        item = selectedDetailItem,
        isWatchlisted = watchlistIds.contains(selectedDetailItem?.id ?: ""),
        onPlayNow = { viewModel.playContent(it) },
        onPurchase = { viewModel.purchaseTitle(it) },
        onRent = { viewModel.rentTitle(it) },
        onToggleWatchlist = { viewModel.toggleWatchlist(it) },
        onDismiss = { viewModel.selectDetailItem(null) }
      )
    }

    // Top Up Invoice Dialog
    if (topUpState.isOpen) {
      TopUpInvoiceDialog(
        state = topUpState,
        onSelectPreset = { viewModel.selectTopUpPreset(it) },
        onSimulateSettlement = { viewModel.simulateLightningSettlement() },
        onDismiss = { viewModel.closeTopUpDialog() }
      )
    }
  }
}
