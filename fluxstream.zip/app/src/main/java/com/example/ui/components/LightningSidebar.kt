package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MidnightNavyPanel
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LightningSidebar(
  balanceBtc: String,
  balanceFiat: String,
  onTopUpClick: () -> Unit,
  onClose: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .background(MidnightNavyPanel)
      .border(1.dp, BorderSubtle)
      .padding(horizontal = 20.dp, vertical = 20.dp)
      .verticalScroll(scrollState)
  ) {
    // Top Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(BrightCyan, ElectricBlue))),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "Lightning Micropayments",
            color = TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Pay only for what you watch. Instant. Global.",
            color = TextSecondary,
            fontSize = 12.sp
          )
        }
      }

      if (onClose != null) {
        IconButton(
          onClick = onClose,
          modifier = Modifier
            .size(32.dp)
            .testTag("close_sidebar_button")
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = TextSecondary,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // 4 Key Features (2x2 Grid)
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      FeatureMiniCard(
        icon = Icons.Default.ElectricBolt,
        title = "Instant Access",
        subtitle = "Stream in seconds with Lightning payments.",
        modifier = Modifier.weight(1f)
      )
      FeatureMiniCard(
        icon = Icons.Default.Payments,
        title = "Pay Per Minute",
        subtitle = "Ultra-small, fair micropayments.",
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      FeatureMiniCard(
        icon = Icons.Default.Language,
        title = "Global & Borderless",
        subtitle = "Any device. Anywhere. No subscriptions.",
        modifier = Modifier.weight(1f)
      )
      FeatureMiniCard(
        icon = Icons.Default.Security,
        title = "Secure & Private",
        subtitle = "Built on Bitcoin Lightning Network.",
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Balance Card (Exact Match to concept design)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(CinematicCard)
        .border(1.dp, BorderElectric, RoundedCornerShape(16.dp))
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(ElectricBlue.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Bolt,
              contentDescription = null,
              tint = BrightCyan,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = "Current Balance",
              color = TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = balanceBtc,
              color = TextPrimary,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = (-0.5).sp
            )
            Text(
              text = balanceFiat,
              color = TextMuted,
              fontSize = 12.sp
            )
          }
        }

        // Top Up Button
        Button(
          onClick = onTopUpClick,
          modifier = Modifier
            .height(38.dp)
            .testTag("sidebar_top_up_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = ElectricBlue,
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(20.dp)
        ) {
          Text("Top Up", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // How It Works
    Text(
      text = "How it works",
      color = TextPrimary,
      fontSize = 15.sp,
      fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(14.dp))

    HowItWorksStep(
      stepNumber = 1,
      title = "Start watching",
      description = "Choose a title and begin streaming.",
      isLast = false
    )
    HowItWorksStep(
      stepNumber = 2,
      title = "Pay per minute",
      description = "Lightning micropayments are sent in real time as you watch.",
      isLast = false
    )
    HowItWorksStep(
      stepNumber = 3,
      title = "Enjoy",
      description = "No subscriptions. No limits. Just great content.",
      isLast = true
    )

    Spacer(modifier = Modifier.height(24.dp))

    // Powered by Lightning Network Banner
    val meshResId = context.resources.getIdentifier("lightning_mesh_banner", "drawable", context.packageName)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(84.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(Brush.horizontalGradient(listOf(Color(0xFF0A2540), Color(0xFF0052CC))))
    ) {
      if (meshResId != 0) {
        Image(
          painter = painterResource(id = meshResId),
          contentDescription = "Lightning Mesh",
          contentScale = ContentScale.Crop,
          modifier = Modifier.matchParentSize()
        )
      }

      Row(
        modifier = Modifier
          .matchParentSize()
          .background(Brush.horizontalGradient(listOf(Color(0xCC051020), Color(0x330052CC))))
          .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Bolt,
          contentDescription = null,
          tint = BrightCyan,
          modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "Powered by the",
            color = TextSecondary,
            fontSize = 11.sp
          )
          Text(
            text = "Lightning Network",
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Small payments. Big freedom.",
            color = BrightCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Bottom Footer Badges: Bitcoin, Lightning, Global
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("₿", color = LightningGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.width(4.dp))
        Text("bitcoin", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("⚡", color = BrightCyan, fontSize = 14.sp)
        Spacer(modifier = Modifier.width(4.dp))
        Text("LIGHTNING", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Language, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Global", color = TextSecondary, fontSize = 12.sp)
      }
    }
  }
}

@Composable
private fun FeatureMiniCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(CinematicCard)
      .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
      .padding(12.dp)
  ) {
    Column {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = BrightCyan,
        modifier = Modifier.size(20.dp)
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = title,
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subtitle,
        color = TextSecondary,
        fontSize = 10.sp,
        lineHeight = 13.sp
      )
    }
  }
}

@Composable
private fun HowItWorksStep(
  stepNumber: Int,
  title: String,
  description: String,
  isLast: Boolean
) {
  Row(modifier = Modifier.fillMaxWidth()) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(BorderElectric),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = stepNumber.toString(),
          color = BrightCyan,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }
      if (!isLast) {
        Box(
          modifier = Modifier
            .width(1.dp)
            .height(32.dp)
            .background(BorderSubtle)
        )
      }
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.padding(bottom = if (isLast) 0.dp else 12.dp)) {
      Text(
        text = title,
        color = TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = description,
        color = TextSecondary,
        fontSize = 11.sp,
        lineHeight = 15.sp
      )
    }
  }
}
