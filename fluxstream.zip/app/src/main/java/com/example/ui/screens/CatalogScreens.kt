package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentItem
import com.example.data.model.ViewingHistory
import com.example.ui.components.PopularCard
import com.example.ui.components.TrendingCard
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MoviesScreen(
  items: List<ContentItem>,
  watchlistIds: List<String>,
  onPlayContent: (ContentItem) -> Unit,
  onInspectContent: (ContentItem) -> Unit,
  onToggleWatchlist: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedGenre by remember { mutableStateOf<String?>(null) }
  val genres = listOf("All", "Sci-Fi", "Drama", "Documentary", "Thriller", "Adventure", "Music")

  val filtered = if (selectedGenre == null || selectedGenre == "All") {
    items
  } else {
    items.filter { it.genre.equals(selectedGenre, ignoreCase = true) }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .padding(16.dp)
  ) {
    Text(
      text = "Feature Films & Documentaries",
      color = TextPrimary,
      fontSize = 20.sp,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Stream in 4K with instant Lightning pay-per-minute or single-title rentals.",
      color = TextSecondary,
      fontSize = 12.sp
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Genre filter chips
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(genres) { g ->
        val isSelected = (selectedGenre == g) || (selectedGenre == null && g == "All")
        FilterChip(
          selected = isSelected,
          onClick = { selectedGenre = if (g == "All") null else g },
          label = { Text(g, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = ElectricBlue,
            selectedLabelColor = Color.White,
            containerColor = CinematicCard,
            labelColor = TextSecondary
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = isSelected,
            borderColor = if (isSelected) BrightCyan else BorderSubtle
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    LazyVerticalGrid(
      columns = GridCells.Adaptive(minSize = 150.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
      modifier = Modifier.fillMaxSize().testTag("movies_grid")
    ) {
      items(filtered) { item ->
        TrendingCard(
          item = item,
          isWatchlisted = watchlistIds.contains(item.id),
          onCardClick = { onInspectContent(item) },
          onPlayClick = { onPlayContent(item) },
          onWatchlistToggle = { onToggleWatchlist(item.id) }
        )
      }
    }
  }
}

@Composable
fun LiveTvScreen(
  items: List<ContentItem>,
  onPlayContent: (ContentItem) -> Unit,
  modifier: Modifier = Modifier
) {
  val liveChannels = items.filter { it.category == "live" || it.liveViewerCount > 0 }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .padding(16.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(10.dp)
          .clip(CircleShape)
          .background(DangerRed)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Live Broadcasts & Channels",
        color = TextPrimary,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold
      )
    }
    Text(
      text = "Continuous broadcast feeds over Bitcoin Lightning. Pay exclusively for the minutes you watch.",
      color = TextSecondary,
      fontSize = 12.sp
    )

    Spacer(modifier = Modifier.height(18.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.fillMaxSize().testTag("live_channels_list")
    ) {
      items(liveChannels) { channel ->
        Card(
          colors = CardDefaults.cardColors(containerColor = CinematicCard),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .clickable { onPlayContent(channel) }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier = Modifier
                  .size(54.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(CinematicCardElevated)
                  .border(1.dp, BorderElectric, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.LiveTv, contentDescription = null, tint = BrightCyan, modifier = Modifier.size(28.dp))
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(DangerRed)
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text("LIVE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = channel.title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = channel.synopsis,
                  color = TextSecondary,
                  fontSize = 12.sp,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "${channel.liveViewerCount} active viewers",
                    color = BrightCyan,
                    fontSize = 11.sp
                  )
                  Text(text = " • ", color = TextMuted)
                  Text(
                    text = "${channel.satsPerMinute} sats/min",
                    color = LightningGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                  )
                }
              }
            }

            Button(
              onClick = { onPlayContent(channel) },
              colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Tune In")
            }
          }
        }
      }
    }
  }
}

@Composable
fun LibraryScreen(
  allContent: List<ContentItem>,
  watchlistIds: List<String>,
  viewingHistory: List<ViewingHistory>,
  onPlayContent: (ContentItem) -> Unit,
  onInspectContent: (ContentItem) -> Unit,
  onToggleWatchlist: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val watchlistedItems = allContent.filter { watchlistIds.contains(it.id) }
  val historyItems = viewingHistory.mapNotNull { h ->
    allContent.find { it.id == h.contentId }?.let { item -> item to h }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .padding(16.dp)
  ) {
    Text(
      text = "My Library",
      color = TextPrimary,
      fontSize = 20.sp,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Your saved watchlist and continue-watching sessions with exact timecodes.",
      color = TextSecondary,
      fontSize = 12.sp
    )

    Spacer(modifier = Modifier.height(20.dp))

    // Continue Watching
    Text(
      text = "Continue Watching",
      color = BrightCyan,
      fontSize = 15.sp,
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(10.dp))

    if (historyItems.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CinematicCard)
          .padding(20.dp),
        contentAlignment = Alignment.Center
      ) {
        Text("No active viewing sessions yet. Start watching any film to track timecodes.", color = TextMuted, fontSize = 12.sp)
      }
    } else {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(historyItems) { (item, history) ->
          Card(
            colors = CardDefaults.cardColors(containerColor = CinematicCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .width(220.dp)
              .clickable { onPlayContent(item) }
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(item.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text("Resumes at: ${history.lastPositionSeconds / 60}m ${history.lastPositionSeconds % 60}s", color = BrightCyan, fontSize = 11.sp)
              Text("Total paid: ${history.totalSatsCharged} sats", color = LightningGold, fontSize = 11.sp)
              Spacer(modifier = Modifier.height(8.dp))
              Button(
                onClick = { onPlayContent(item) },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text("Resume Stream", fontSize = 12.sp)
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Watchlist
    Text(
      text = "My Watchlist (${watchlistedItems.size})",
      color = BrightCyan,
      fontSize = 15.sp,
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(10.dp))

    if (watchlistedItems.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CinematicCard)
          .padding(20.dp),
        contentAlignment = Alignment.Center
      ) {
        Text("Your watchlist is empty. Tap '+ Add to Watchlist' on any title to save it.", color = TextMuted, fontSize = 12.sp)
      }
    } else {
      LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 140.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(watchlistedItems) { item ->
          TrendingCard(
            item = item,
            isWatchlisted = true,
            onCardClick = { onInspectContent(item) },
            onPlayClick = { onPlayContent(item) },
            onWatchlistToggle = { onToggleWatchlist(item.id) }
          )
        }
      }
    }
  }
}
