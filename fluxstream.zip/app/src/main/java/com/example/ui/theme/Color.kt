package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FluxStream Supermodernist Cinematic Palette
val MidnightNavy = Color(0xFF070B14)
val MidnightNavyPanel = Color(0xFF0B111E)
val CinematicSurface = Color(0xFF0E1726)
val CinematicCard = Color(0xFF131D31)
val CinematicCardElevated = Color(0xFF19253E)

val ElectricBlue = Color(0xFF0070F3)
val ElectricBlueHover = Color(0xFF1A82FF)
val BrightCyan = Color(0xFF00D2FF)
val CyanAccent = Color(0xFF38BDF8)
val CyanGlow = Color(0x3300D2FF)

val LightningAmber = Color(0xFFF59E0B)
val LightningGold = Color(0xFFFBBF24)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BorderSubtle = Color(0xFF1E293B)
val BorderElectric = Color(0xFF1D4ED8)
val BorderCyanGlow = Color(0xFF0284C7)

val SuccessGreen = Color(0xFF10B981)
val DangerRed = Color(0xFFEF4444)
