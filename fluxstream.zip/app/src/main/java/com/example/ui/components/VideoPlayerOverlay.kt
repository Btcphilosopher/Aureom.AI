package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentItem
import com.example.playback.PlaybackState
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.sin

@Composable
fun VideoPlayerOverlay(
  state: PlaybackState,
  userBalanceSats: Long,
  onPlayPauseToggle: () -> Unit,
  onSeek: (Long) -> Unit,
  onSeekRelative: (Long) -> Unit,
  onSpeedChange: (Float) -> Unit,
  onQualityChange: (String) -> Unit,
  onToggleSubtitles: () -> Unit,
  onToggleFullscreen: () -> Unit,
  onClose: () -> Unit,
  onDismissLowBalance: () -> Unit,
  onOpenTopUp: () -> Unit,
  modifier: Modifier = Modifier
) {
  val item = state.activeItem ?: return
  var showControls by remember { mutableStateOf(true) }
  var showSettingsMenu by remember { mutableStateOf(false) }

  // Animated video scene canvas values
  val infiniteTransition = rememberInfiniteTransition(label = "video_canvas")
  val phase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 6.28318f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 4000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "wave_phase"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black)
      .testTag("video_player_container")
      .clickable { showControls = !showControls }
  ) {
    // 1. Procedural Cinematic Video Viewport
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height

      // Background gradient
      drawRect(
        brush = Brush.verticalGradient(
          listOf(Color(0xFF030712), Color(0xFF0B1528), Color(0xFF050D1A))
        ),
        size = size
      )

      // Celestial Orbital Ring
      val ringCenter = Offset(w * 0.45f, h * 0.28f)
      drawCircle(
        color = Color(0x3300D2FF),
        radius = w * 0.22f,
        center = ringCenter,
        style = Stroke(width = 3.dp.toPx())
      )
      drawCircle(
        color = Color(0x1A0070F3),
        radius = w * 0.25f,
        center = ringCenter,
        style = Stroke(width = 1.dp.toPx())
      )

      // Distant stars / particles
      for (i in 0..25) {
        val x = (i * 97 % 100) / 100f * w
        val y = (i * 61 % 50) / 100f * h
        val radius = ((i % 3) + 1.5f).dp.toPx()
        drawCircle(color = Color(0x88FFFFFF), radius = radius, center = Offset(x, y))
      }

      // Futuristic City Skyline Silhouettes
      val buildingCount = 18
      val buildingWidth = w / buildingCount
      for (i in 0 until buildingCount) {
        val bh = (sin((i * 0.8f) + 1f) * 0.15f + 0.35f) * h
        val bx = i * buildingWidth
        val by = h - bh

        drawRect(
          color = Color(0xFF060B14),
          topLeft = Offset(bx, by),
          size = Size(buildingWidth * 0.95f, bh)
        )

        // Random illuminated windows
        val winCols = 3
        val winRows = (bh / 24.dp.toPx()).toInt().coerceAtMost(12)
        for (r in 0 until winRows) {
          for (c in 0 until winCols) {
            if ((i * 7 + r * 3 + c) % 4 == 0) {
              val wx = bx + 4.dp.toPx() + c * 8.dp.toPx()
              val wy = by + 8.dp.toPx() + r * 16.dp.toPx()
              drawRect(
                color = if ((i + r) % 3 == 0) Color(0xCC00D2FF) else Color(0xAAF59E0B),
                topLeft = Offset(wx, wy),
                size = Size(4.dp.toPx(), 6.dp.toPx())
              )
            }
          }
        }
      }

      // Audio waveform equalizer when playing
      if (state.isPlaying) {
        val barCount = 36
        val barWidth = w / (barCount * 1.5f)
        for (i in 0 until barCount) {
          val waveHeight = (sin(phase + i * 0.35f) * 0.5f + 0.5f) * (45.dp.toPx()) + 10.dp.toPx()
          val bx = w * 0.1f + i * (barWidth * 1.5f)
          val by = h - waveHeight - 120.dp.toPx()
          drawRect(
            brush = Brush.verticalGradient(
              listOf(Color(0xFF00D2FF), Color(0xFF0070F3)),
              startY = by,
              endY = by + waveHeight
            ),
            topLeft = Offset(bx, by),
            size = Size(barWidth, waveHeight)
          )
        }
      }
    }

    // Subtitles display if enabled
    if (state.subtitlesEnabled && state.isPlaying) {
      Box(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = 120.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xCC000000))
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        val subtitleLine = when ((state.currentPositionSeconds % 20) / 5) {
          0L -> "Initiating quantum transmission sequence..."
          1L -> "Telemetry synchronized with Lightning Node 03."
          2L -> "The perimeter shields are holding at maximum frequency."
          else -> "Looking out beyond the orbital horizon..."
        }
        Text(
          text = subtitleLine,
          color = Color.White,
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    // 2. LIVE PAYMENT INFORMATION HUD (Always visible or in player controls)
    Box(
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(top = 64.dp, end = 16.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xEE0B111E))
        .border(1.dp, BorderElectric, RoundedCornerShape(12.dp))
        .padding(horizontal = 14.dp, vertical = 10.dp)
        .testTag("live_payment_hud")
    ) {
      Column(horizontalAlignment = Alignment.End) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(if (state.isPlaying) SuccessGreen else DangerRed)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Payment: ${state.paymentStatus}",
            color = if (state.isPlaying) BrightCyan else LightningGold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "Rate: ${state.currentRateSatsPerMin} sats/min",
          color = TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
        Text(
          text = "Acc. Cost: ${state.accumulatedCostSats} sats",
          color = TextSecondary,
          fontSize = 11.sp
        )
        Text(
          text = "Session: ${state.sessionDurationMinutes} min",
          color = TextSecondary,
          fontSize = 11.sp
        )
        Text(
          text = "Balance: $userBalanceSats sats",
          color = LightningGold,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    // 3. Player Header & Controls Overlay (Toggleable)
    AnimatedVisibility(visible = showControls, modifier = Modifier.fillMaxSize()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0x66000000))
      ) {
        // Top Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .align(Alignment.TopStart),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onClose,
              modifier = Modifier.testTag("player_close_button")
            ) {
              Icon(Icons.Default.Close, contentDescription = "Close player", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = item.title,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${item.genre} • ${state.selectedQuality} • ${state.audioTrack}",
                color = TextSecondary,
                fontSize = 12.sp
              )
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            // Subtitles Toggle
            IconButton(onClick = onToggleSubtitles) {
              Icon(
                imageVector = Icons.Default.Subtitles,
                contentDescription = "Subtitles",
                tint = if (state.subtitlesEnabled) BrightCyan else TextSecondary
              )
            }

            // Settings Menu (Quality / Speed)
            Box {
              IconButton(onClick = { showSettingsMenu = true }) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextSecondary)
              }
              DropdownMenu(
                expanded = showSettingsMenu,
                onDismissRequest = { showSettingsMenu = false },
                modifier = Modifier.background(CinematicCard)
              ) {
                DropdownMenuItem(
                  text = { Text("Quality: 4K Ultra", color = TextPrimary) },
                  onClick = { onQualityChange("4K Ultra"); showSettingsMenu = false }
                )
                DropdownMenuItem(
                  text = { Text("Quality: 1080p FHD", color = TextPrimary) },
                  onClick = { onQualityChange("1080p"); showSettingsMenu = false }
                )
                DropdownMenuItem(
                  text = { Text("Speed: 0.75x", color = TextPrimary) },
                  onClick = { onSpeedChange(0.75f); showSettingsMenu = false }
                )
                DropdownMenuItem(
                  text = { Text("Speed: 1.0x Normal", color = BrightCyan) },
                  onClick = { onSpeedChange(1.0f); showSettingsMenu = false }
                )
                DropdownMenuItem(
                  text = { Text("Speed: 1.25x", color = TextPrimary) },
                  onClick = { onSpeedChange(1.25f); showSettingsMenu = false }
                )
                DropdownMenuItem(
                  text = { Text("Speed: 1.5x", color = TextPrimary) },
                  onClick = { onSpeedChange(1.5f); showSettingsMenu = false }
                )
              }
            }

            IconButton(onClick = onToggleFullscreen) {
              Icon(
                imageVector = if (state.isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                contentDescription = "Fullscreen",
                tint = TextSecondary
              )
            }
          }
        }

        // Center Controls (Play/Pause, Rewind, Fast Forward)
        Row(
          modifier = Modifier.align(Alignment.Center),
          horizontalArrangement = Arrangement.spacedBy(28.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = { onSeekRelative(-10L) },
            modifier = Modifier
              .size(48.dp)
              .testTag("seek_backward_10_button")
          ) {
            Icon(Icons.Default.Replay10, contentDescription = "Rewind 10s", tint = Color.White, modifier = Modifier.size(32.dp))
          }

          Box(
            modifier = Modifier
              .size(68.dp)
              .clip(CircleShape)
              .background(ElectricBlue)
              .clickable { onPlayPauseToggle() }
              .testTag("play_pause_toggle_button"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = if (state.isPlaying) "Pause" else "Play",
              tint = Color.White,
              modifier = Modifier.size(36.dp)
            )
          }

          IconButton(
            onClick = { onSeekRelative(10L) },
            modifier = Modifier
              .size(48.dp)
              .testTag("seek_forward_10_button")
          ) {
            Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(32.dp))
          }
        }

        // Bottom Controls (Seekbar & Timecode)
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter)
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = formatTimecode(state.currentPositionSeconds),
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = formatTimecode(state.totalDurationSeconds),
              color = TextSecondary,
              fontSize = 12.sp
            )
          }

          Slider(
            value = if (state.totalDurationSeconds > 0) state.currentPositionSeconds.toFloat() / state.totalDurationSeconds else 0f,
            onValueChange = { frac ->
              val targetSec = (frac * state.totalDurationSeconds).toLong()
              onSeek(targetSec)
            },
            colors = SliderDefaults.colors(
              thumbColor = BrightCyan,
              activeTrackColor = ElectricBlue,
              inactiveTrackColor = Color(0x66FFFFFF)
            ),
            modifier = Modifier.fillMaxWidth().testTag("video_seek_slider")
          )
        }
      }
    }

    // 4. LOW BALANCE WARNING MODAL
    if (state.showLowBalanceWarning) {
      AlertDialog(
        onDismissRequest = onDismissLowBalance,
        containerColor = MidnightNavy,
        icon = {
          Icon(Icons.Default.Bolt, contentDescription = null, tint = LightningGold, modifier = Modifier.size(36.dp))
        },
        title = {
          Text(text = "Lightning Balance Low", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
          Column {
            Text(
              text = "Playback paused. You need at least ${item.satsPerMinute} sats to stream the next minute.",
              color = TextSecondary,
              fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "Current balance: $userBalanceSats sats",
              color = DangerRed,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Top up using the Bitcoin Lightning Network to resume immediately without losing your spot.",
              color = TextMuted,
              fontSize = 12.sp
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              onDismissLowBalance()
              onOpenTopUp()
            },
            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("low_balance_top_up_button")
          ) {
            Text("Top Up Now", fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = onDismissLowBalance) {
            Text("Close", color = TextSecondary)
          }
        }
      )
    }
  }
}

private fun formatTimecode(totalSeconds: Long): String {
  val hours = totalSeconds / 3600
  val minutes = (totalSeconds % 3600) / 60
  val seconds = totalSeconds % 60
  return if (hours > 0) {
    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
  } else {
    String.format(Locale.US, "%02d:%02d", minutes, seconds)
  }
}
