package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentItem
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TrendingCard(
  item: ContentItem,
  isWatchlisted: Boolean,
  onCardClick: () -> Unit,
  onPlayClick: () -> Unit,
  onWatchlistToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val resId = context.resources.getIdentifier(item.drawableResName, "drawable", context.packageName)

  Column(
    modifier = modifier
      .width(170.dp)
      .testTag("trending_card_${item.id}")
      .clickable { onCardClick() }
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(210.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(CinematicCard)
        .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
    ) {
      if (resId != 0) {
        Image(
          painter = painterResource(id = resId),
          contentDescription = item.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )
      } else {
        // Fallback procedural artistic card
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.linearGradient(
                listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = item.title.take(2).uppercase(),
            color = BrightCyan,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // Dark gradient overlay
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(Color.Transparent, Color(0x66000000), Color(0xE6070B14)),
              startY = 80f
            )
          )
      )

      // 4K Badge at top left
      Box(
        modifier = Modifier
          .padding(8.dp)
          .align(Alignment.TopStart)
          .clip(RoundedCornerShape(4.dp))
          .background(Color(0x99000000))
          .padding(horizontal = 5.dp, vertical = 2.dp)
      ) {
        Text(
          text = item.resolution,
          color = Color.White,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // Watchlist toggle at top right
      IconButton(
        onClick = onWatchlistToggle,
        modifier = Modifier
          .align(Alignment.TopEnd)
          .size(36.dp)
      ) {
        Icon(
          imageVector = if (isWatchlisted) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
          contentDescription = "Watchlist",
          tint = if (isWatchlisted) BrightCyan else Color.White,
          modifier = Modifier.size(20.dp)
        )
      }

      // Play button hover / center overlay
      Box(
        modifier = Modifier
          .align(Alignment.Center)
          .size(44.dp)
          .clip(CircleShape)
          .background(Color(0xAA0B111E))
          .border(1.dp, BrightCyan, CircleShape)
          .clickable { onPlayClick() },
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = "Play",
          tint = BrightCyan,
          modifier = Modifier.size(26.dp)
        )
      }

      // Price per minute pill at bottom
      Row(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Bolt,
          contentDescription = null,
          tint = LightningGold,
          modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
          text = "${item.satsPerMinute} sats/m",
          color = Color.White,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = item.title,
      color = TextPrimary,
      fontSize = 14.sp,
      fontWeight = FontWeight.SemiBold,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )

    Spacer(modifier = Modifier.height(2.dp))

    val runtimeText = "${item.runtimeMinutes / 60}h ${item.runtimeMinutes % 60}m"
    Text(
      text = "${item.genre} • $runtimeText",
      color = TextSecondary,
      fontSize = 12.sp,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

@Composable
fun PopularCard(
  item: ContentItem,
  onCardClick: () -> Unit,
  onPlayClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val resId = context.resources.getIdentifier(item.drawableResName, "drawable", context.packageName)

  Column(
    modifier = modifier
      .width(180.dp)
      .testTag("popular_card_${item.id}")
      .clickable { onCardClick() }
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(105.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(CinematicCard)
        .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
    ) {
      if (resId != 0) {
        Image(
          painter = painterResource(id = resId),
          contentDescription = item.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )
      } else {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E293B)),
          contentAlignment = Alignment.Center
        ) {
          Text(text = item.genre, color = TextSecondary, fontSize = 12.sp)
        }
      }

      // Gradient overlay
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(Color.Transparent, Color(0x99000000))
            )
          )
      )

      // Play icon button
      Box(
        modifier = Modifier
          .align(Alignment.Center)
          .size(36.dp)
          .clip(CircleShape)
          .background(Color(0x88000000))
          .clickable { onPlayClick() },
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = "Play",
          tint = Color.White,
          modifier = Modifier.size(20.dp)
        )
      }

      // Price tag at bottom right
      Row(
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(6.dp)
          .clip(RoundedCornerShape(4.dp))
          .background(Color(0xCC070B14))
          .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Bolt,
          contentDescription = null,
          tint = LightningGold,
          modifier = Modifier.size(10.dp)
        )
        Spacer(modifier = Modifier.width(2.dp))
        Text(
          text = "${item.satsPerMinute} s/m",
          color = Color.White,
          fontSize = 10.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = item.title,
      color = TextPrimary,
      fontSize = 13.sp,
      fontWeight = FontWeight.Medium,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )

    val runtimeStr = if (item.runtimeMinutes >= 60) "${item.runtimeMinutes / 60}h ${item.runtimeMinutes % 60}m" else "${item.runtimeMinutes}m"
    Text(
      text = "${item.genre} • $runtimeStr",
      color = TextSecondary,
      fontSize = 11.sp,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}
