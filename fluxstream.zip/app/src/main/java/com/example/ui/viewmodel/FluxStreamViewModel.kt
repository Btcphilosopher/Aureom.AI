package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FluxStreamDatabase
import com.example.data.model.ContentItem
import com.example.data.model.LedgerEntry
import com.example.data.model.LightningInvoice
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.model.ViewingHistory
import com.example.data.repository.ContentRepository
import com.example.data.repository.WalletLedgerRepository
import com.example.playback.PlaybackEngine
import com.example.playback.PlaybackState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

enum class NavDestination {
  HOME,
  MOVIES,
  SERIES,
  LIVE_TV,
  GENRES,
  MY_LIBRARY,
  WALLET,
  CREATOR,
  ADMIN
}

data class TopUpUiState(
  val isOpen: Boolean = false,
  val selectedAmountSats: Long = 10000L,
  val activeInvoice: LightningInvoice? = null,
  val isSettling: Boolean = false,
  val settlementSuccess: Boolean = false
)

class FluxStreamViewModel(application: Application) : AndroidViewModel(application) {

  private val database = FluxStreamDatabase.getDatabase(application, viewModelScope)
  val contentRepository = ContentRepository(database.fluxStreamDao())
  val walletRepository = WalletLedgerRepository(database.fluxStreamDao())
  val playbackEngine = PlaybackEngine(contentRepository, walletRepository, viewModelScope)

  // Navigation
  private val _currentNav = MutableStateFlow(NavDestination.HOME)
  val currentNav: StateFlow<NavDestination> = _currentNav.asStateFlow()

  // Selected Genre Filter
  private val _selectedGenre = MutableStateFlow<String?>(null)
  val selectedGenre: StateFlow<String?> = _selectedGenre.asStateFlow()

  // Search
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _isSearchOpen = MutableStateFlow(false)
  val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

  // User Profile
  private val _userProfile = MutableStateFlow(UserProfile())
  val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

  // Top Up UI
  private val _topUpState = MutableStateFlow(TopUpUiState())
  val topUpState: StateFlow<TopUpUiState> = _topUpState.asStateFlow()

  // Selected Title for Details Modal (if inspecting before watching)
  private val _selectedDetailItem = MutableStateFlow<ContentItem?>(null)
  val selectedDetailItem: StateFlow<ContentItem?> = _selectedDetailItem.asStateFlow()

  // Right Sidebar Toggle (desktop shows pinned, mobile/tablet toggles or drawer)
  private val _isSidebarVisible = MutableStateFlow(false)
  val isSidebarVisible: StateFlow<Boolean> = _isSidebarVisible.asStateFlow()

  // Content Flows
  val allContent: StateFlow<List<ContentItem>> = contentRepository.allContent
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val featuredContent: StateFlow<ContentItem?> = contentRepository.featuredContent
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val watchlistIds: StateFlow<List<String>> = contentRepository.watchlistIds
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val viewingHistory: StateFlow<List<ViewingHistory>> = contentRepository.viewingHistory
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Balance & Financial Flows
  val userBalanceSats: StateFlow<Long> = walletRepository.userBalanceSats
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 24500L)

  val creatorEarningsSats: StateFlow<Long> = walletRepository.creatorEarningsSats
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

  val platformFeeSats: StateFlow<Long> = walletRepository.platformFeeSats
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

  val allLedgerEntries: StateFlow<List<LedgerEntry>> = walletRepository.allLedgerEntries
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val playbackState: StateFlow<PlaybackState> = playbackEngine.state

  // Formatted Balance Helpers
  val balanceBtcFormatted: StateFlow<String> = userBalanceSats.map { sats ->
    val btc = sats.toDouble() / 100_000_000.0
    String.format(Locale.US, "%.6f BTC", btc)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "0.000245 BTC")

  val balanceFiatFormatted: StateFlow<String> = combine(userBalanceSats, _userProfile) { sats, profile ->
    val btc = sats.toDouble() / 100_000_000.0
    val fiat = btc * profile.btcToFiatRate
    String.format(Locale.UK, "≈ %s%.2f", profile.fiatSymbol, fiat)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "≈ £16.32")

  // Search results
  val filteredContent: StateFlow<List<ContentItem>> = combine(allContent, _searchQuery, _selectedGenre) { items, query, genre ->
    items.filter { item ->
      val matchesQuery = query.isBlank() ||
        item.title.contains(query, ignoreCase = true) ||
        item.synopsis.contains(query, ignoreCase = true) ||
        item.genre.contains(query, ignoreCase = true) ||
        item.creatorName.contains(query, ignoreCase = true)

      val matchesGenre = genre == null || item.genre.equals(genre, ignoreCase = true)
      matchesQuery && matchesGenre
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  fun navigateTo(destination: NavDestination) {
    _currentNav.value = destination
    _isSearchOpen.value = false
  }

  fun toggleSearch() {
    _isSearchOpen.update { !it }
  }

  fun updateSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setGenreFilter(genre: String?) {
    _selectedGenre.value = genre
  }

  fun toggleSidebar() {
    _isSidebarVisible.update { !it }
  }

  fun selectDetailItem(item: ContentItem?) {
    _selectedDetailItem.value = item
  }

  fun switchUserRole(newRole: UserRole) {
    _userProfile.update { it.copy(role = newRole) }
  }

  fun toggleWatchlist(contentId: String) {
    viewModelScope.launch {
      val isSaved = watchlistIds.value.contains(contentId)
      contentRepository.toggleWatchlist(contentId, isSaved)
    }
  }

  // Playback Triggers
  fun playContent(item: ContentItem) {
    viewModelScope.launch {
      val history = contentRepository.viewingHistory
      val resumePos = 0L // can check history for contentId if desired
      playbackEngine.startPlayback(item, resumePos)
      _selectedDetailItem.value = null
    }
  }

  // Top Up Dialog
  fun openTopUpDialog(presetSats: Long = 10000L) {
    viewModelScope.launch {
      val invoice = walletRepository.createTopUpInvoice(presetSats)
      _topUpState.value = TopUpUiState(
        isOpen = true,
        selectedAmountSats = presetSats,
        activeInvoice = invoice,
        isSettling = false,
        settlementSuccess = false
      )
    }
  }

  fun selectTopUpPreset(sats: Long) {
    viewModelScope.launch {
      val invoice = walletRepository.createTopUpInvoice(sats)
      _topUpState.update {
        it.copy(
          selectedAmountSats = sats,
          activeInvoice = invoice,
          settlementSuccess = false
        )
      }
    }
  }

  fun closeTopUpDialog() {
    _topUpState.value = TopUpUiState(isOpen = false)
  }

  fun simulateLightningSettlement() {
    val invoice = _topUpState.value.activeInvoice ?: return
    viewModelScope.launch {
      _topUpState.update { it.copy(isSettling = true) }
      // Simulate lightning network routing & payment receipt
      kotlinx.coroutines.delay(1200L)
      walletRepository.settleInvoice(invoice.invoiceId)
      _topUpState.update {
        it.copy(
          isSettling = false,
          settlementSuccess = true
        )
      }
    }
  }

  // Fast demo top up helper for convenience
  fun fastTopUp25kSats() {
    viewModelScope.launch {
      val invoice = walletRepository.createTopUpInvoice(24500L, "Quick 0.000245 BTC top up")
      walletRepository.settleInvoice(invoice.invoiceId)
    }
  }

  // Purchase/Rental triggers
  fun purchaseTitle(item: ContentItem) {
    viewModelScope.launch {
      val balance = userBalanceSats.value
      if (balance >= item.purchasePriceSats) {
        walletRepository.processPurchase(
          contentId = item.id,
          contentTitle = item.title,
          creatorName = item.creatorName,
          amountSats = item.purchasePriceSats,
          isRental = false
        )
        playContent(item)
      } else {
        openTopUpDialog(item.purchasePriceSats)
      }
    }
  }

  fun rentTitle(item: ContentItem) {
    viewModelScope.launch {
      val balance = userBalanceSats.value
      if (balance >= item.rentalPriceSats) {
        walletRepository.processPurchase(
          contentId = item.id,
          contentTitle = item.title,
          creatorName = item.creatorName,
          amountSats = item.rentalPriceSats,
          isRental = true
        )
        playContent(item)
      } else {
        openTopUpDialog(item.rentalPriceSats)
      }
    }
  }

  // Creator publish content
  fun submitCreatorFilm(
    title: String,
    synopsis: String,
    genre: String,
    runtimeMinutes: Int,
    satsPerMinute: Long
  ) {
    viewModelScope.launch {
      val newId = title.lowercase().replace(" ", "-").filter { it.isLetterOrDigit() || it == '-' }
      val newItem = ContentItem(
        id = newId,
        title = title,
        synopsis = synopsis,
        genre = genre,
        releaseYear = 2028,
        runtimeMinutes = runtimeMinutes,
        resolution = "4K",
        category = "trending",
        pricingModel = "pay_per_minute",
        satsPerMinute = satsPerMinute,
        purchasePriceSats = satsPerMinute * 80,
        rentalPriceSats = satsPerMinute * 25,
        drawableResName = "card_velvet_city",
        creatorName = userProfile.value.username,
        isFeatured = false,
        liveViewerCount = 1
      )
      contentRepository.addCreatorContent(newItem)
    }
  }
}
