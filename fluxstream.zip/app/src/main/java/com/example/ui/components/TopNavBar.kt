package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.NavDestination

@Composable
fun TopNavBar(
  currentNav: NavDestination,
  onNavigate: (NavDestination) -> Unit,
  balanceBtc: String,
  userRole: UserRole,
  onRoleChange: (UserRole) -> Unit,
  onOpenTopUp: () -> Unit,
  onToggleSidebar: () -> Unit,
  isSearchOpen: Boolean,
  searchQuery: String,
  onSearchToggle: () -> Unit,
  onSearchQueryChange: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var showRoleMenu by remember { mutableStateOf(false) }

  val navItems = listOf(
    NavDestination.HOME to "Home",
    NavDestination.MOVIES to "Movies",
    NavDestination.SERIES to "Series",
    NavDestination.LIVE_TV to "Live TV",
    NavDestination.GENRES to "Genres",
    NavDestination.MY_LIBRARY to "My Library"
  )

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(MidnightNavy)
      .border(1.dp, BorderSubtle)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left: Logo
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .testTag("logo_button")
          .clickable { onNavigate(NavDestination.HOME) }
      ) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(ElectricBlue),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = "FluxStream Bolt",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "FluxStream",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = (-0.5).sp
        )
      }

      // Middle: Navigation links (for wider / scrollable row)
      LazyRow(
        modifier = Modifier.weight(1f, fill = false).padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        items(navItems) { (dest, label) ->
          val isSelected = currentNav == dest
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
              .testTag("nav_tab_${dest.name.lowercase()}")
              .clickable { onNavigate(dest) }
              .padding(vertical = 4.dp, horizontal = 4.dp)
          ) {
            Text(
              text = label,
              color = if (isSelected) TextPrimary else TextSecondary,
              fontSize = 14.sp,
              fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (isSelected) {
              Box(
                modifier = Modifier
                  .width(20.dp)
                  .height(2.dp)
                  .background(BrightCyan, RoundedCornerShape(1.dp))
              )
            } else {
              Spacer(modifier = Modifier.height(2.dp))
            }
          }
        }
      }

      // Right: Actions (Search, Profile, Wallet Balance)
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Search icon
        IconButton(
          onClick = onSearchToggle,
          modifier = Modifier
            .size(36.dp)
            .testTag("search_toggle_button")
        ) {
          Icon(
            imageVector = if (isSearchOpen) Icons.Default.Close else Icons.Default.Search,
            contentDescription = "Search",
            tint = if (isSearchOpen) BrightCyan else TextSecondary,
            modifier = Modifier.size(20.dp)
          )
        }

        // Profile / Role switcher icon
        Box {
          IconButton(
            onClick = { showRoleMenu = true },
            modifier = Modifier
              .size(36.dp)
              .testTag("profile_button")
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = "Profile and role",
              tint = if (userRole != UserRole.VIEWER) BrightCyan else TextSecondary,
              modifier = Modifier.size(20.dp)
            )
          }

          DropdownMenu(
            expanded = showRoleMenu,
            onDismissRequest = { showRoleMenu = false },
            modifier = Modifier.background(CinematicCard)
          ) {
            DropdownMenuItem(
              text = { Text("Viewer Mode", color = if (userRole == UserRole.VIEWER) BrightCyan else TextPrimary) },
              onClick = {
                onRoleChange(UserRole.VIEWER)
                showRoleMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Creator Studio", color = if (userRole == UserRole.CREATOR) BrightCyan else TextPrimary) },
              onClick = {
                onRoleChange(UserRole.CREATOR)
                onNavigate(NavDestination.CREATOR)
                showRoleMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Admin Audit Dashboard", color = if (userRole == UserRole.ADMIN) BrightCyan else TextPrimary) },
              onClick = {
                onRoleChange(UserRole.ADMIN)
                onNavigate(NavDestination.ADMIN)
                showRoleMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Full Wallet Ledger", color = TextPrimary) },
              onClick = {
                onNavigate(NavDestination.WALLET)
                showRoleMenu = false
              }
            )
          }
        }

        // Wallet Balance Pill: ⚡ 0.000245 BTC ⌵
        Row(
          modifier = Modifier
            .testTag("wallet_balance_pill")
            .clip(RoundedCornerShape(20.dp))
            .background(CinematicCard)
            .border(1.dp, BorderElectric, RoundedCornerShape(20.dp))
            .clickable { onToggleSidebar() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = "Lightning",
            tint = LightningGold,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = balanceBtc,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(2.dp))
          Icon(
            imageVector = Icons.Default.KeyboardArrowDown,
            contentDescription = "Expand wallet",
            tint = TextSecondary,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }

    // Expandable Search Bar
    AnimatedVisibility(visible = isSearchOpen) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(CinematicCard)
          .padding(horizontal = 16.dp, vertical = 8.dp)
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onSearchQueryChange,
          placeholder = { Text("Search movies, series, documentaries, creators...", color = TextMuted) },
          leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = null, tint = BrightCyan)
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchQueryChange("") }) {
                Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary)
              }
            }
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_input_field"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BorderCyanGlow,
            unfocusedBorderColor = BorderSubtle,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          shape = RoundedCornerShape(12.dp)
        )
      }
    }
  }
}
