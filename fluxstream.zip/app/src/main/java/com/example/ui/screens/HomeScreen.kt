package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentItem
import com.example.ui.components.PopularCard
import com.example.ui.components.TrendingCard
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
  featuredItem: ContentItem?,
  trendingItems: List<ContentItem>,
  popularItems: List<ContentItem>,
  watchlistIds: List<String>,
  onPlayContent: (ContentItem) -> Unit,
  onInspectContent: (ContentItem) -> Unit,
  onToggleWatchlist: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .verticalScroll(scrollState)
  ) {
    // 1. Featured Cinematic Hero Panel
    if (featuredItem != null) {
      val heroResId = context.resources.getIdentifier("hero_next_horizon", "drawable", context.packageName)
      val isSaved = watchlistIds.contains(featuredItem.id)

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(340.dp)
          .testTag("featured_hero_section")
      ) {
        if (heroResId != 0) {
          Image(
            painter = painterResource(id = heroResId),
            contentDescription = featuredItem.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.radialGradient(
                  listOf(Color(0xFF0D1E3A), Color(0xFF070B14))
                )
              )
          )
        }

        // Cinematic gradients (left fade for text readability + bottom fade)
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.horizontalGradient(
                listOf(Color(0xE6070B14), Color(0x99070B14), Color.Transparent),
                endX = 900f
              )
            )
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color(0x99070B14), Color(0xFF070B14)),
                startY = 180f
              )
            )
        )

        // Hero Info & Actions
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 20.dp),
          verticalArrangement = Arrangement.Bottom
        ) {
          Text(
            text = "FEATURED",
            color = BrightCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = featuredItem.title,
            color = TextPrimary,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.5).sp
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "A stunning journey into a future worth fighting for.",
            color = TextSecondary,
            fontSize = 13.sp,
            maxLines = 2
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Metadata pill badges
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = featuredItem.genre, color = TextSecondary, fontSize = 12.sp)
            Text(text = " • ", color = TextMuted, fontSize = 12.sp)
            Text(text = "${featuredItem.releaseYear}", color = TextSecondary, fontSize = 12.sp)
            Text(text = " • ", color = TextMuted, fontSize = 12.sp)
            Text(text = "${featuredItem.runtimeMinutes / 60}h ${featuredItem.runtimeMinutes % 60}m", color = TextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0x801E293B))
                .border(1.dp, BorderSubtle, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(text = "4K", color = BrightCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Action Buttons: Watch Now & Add to Watchlist
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
              onClick = { onPlayContent(featuredItem) },
              colors = ButtonDefaults.buttonColors(
                containerColor = ElectricBlue,
                contentColor = Color.White
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("watch_now_button")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Watch Now", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            OutlinedButton(
              onClick = { onToggleWatchlist(featuredItem.id) },
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isSaved) BrightCyan else BorderSubtle),
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color(0x66000000),
                contentColor = if (isSaved) BrightCyan else Color.White
              ),
              modifier = Modifier.testTag("watchlist_button")
            ) {
              Icon(
                imageVector = if (isSaved) Icons.Default.Check else Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isSaved) "In Watchlist" else "Add to Watchlist",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // 2. Trending Now Section
    Column(modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp)) {
      Text(
        text = "Trending Now",
        color = TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    LazyRow(
      contentPadding = PaddingValues(horizontal = 20.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(trendingItems) { item ->
        TrendingCard(
          item = item,
          isWatchlisted = watchlistIds.contains(item.id),
          onCardClick = { onInspectContent(item) },
          onPlayClick = { onPlayContent(item) },
          onWatchlistToggle = { onToggleWatchlist(item.id) }
        )
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    // 3. Popular This Week Section
    Column(modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp)) {
      Text(
        text = "Popular This Week",
        color = TextPrimary,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    LazyRow(
      contentPadding = PaddingValues(horizontal = 20.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(popularItems) { item ->
        PopularCard(
          item = item,
          onCardClick = { onInspectContent(item) },
          onPlayClick = { onPlayContent(item) }
        )
      }
    }

    Spacer(modifier = Modifier.height(36.dp))

    // 4. Bottom Footer (Matching Reference Design)
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(Color(0xFF05080E))
        .border(1.dp, BorderSubtle)
        .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "FluxStream",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(16.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("About", color = TextMuted, fontSize = 11.sp)
            Text("Help", color = TextMuted, fontSize = 11.sp)
            Text("Terms", color = TextMuted, fontSize = 11.sp)
            Text("Privacy", color = TextMuted, fontSize = 11.sp)
            Text("Contact", color = TextMuted, fontSize = 11.sp)
          }
        }

        Text(
          text = "MORE CONTENT  /  LESS FRICTION  /  INSTANTLY",
          color = TextMuted,
          fontSize = 10.sp,
          fontWeight = FontWeight.Medium,
          letterSpacing = 1.sp
        )
      }
    }
  }
}
