package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentItem
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CreatorScreen(
  creatorEarningsSats: Long,
  myCatalog: List<ContentItem>,
  onSubmitFilm: (String, String, String, Int, Long) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var title by remember { mutableStateOf("") }
  var synopsis by remember { mutableStateOf("") }
  var genre by remember { mutableStateOf("Sci-Fi") }
  var runtimeStr by remember { mutableStateOf("94") }
  var rateStr by remember { mutableStateOf("20") }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(
      text = "Creator Studio & Royalties",
      color = TextPrimary,
      fontSize = 20.sp,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "80% creator revenue share deposited directly to your Lightning settlement balance.",
      color = TextSecondary,
      fontSize = 12.sp
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Creator Stats Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Card(
        colors = CardDefaults.cardColors(containerColor = CinematicCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.weight(1f).border(1.dp, BorderElectric, RoundedCornerShape(12.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text("Settled Royalties", color = TextSecondary, fontSize = 11.sp)
          Spacer(modifier = Modifier.height(4.dp))
          Text("$creatorEarningsSats sats", color = LightningGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          Text("80% of streaming gross", color = TextMuted, fontSize = 10.sp)
        }
      }

      Card(
        colors = CardDefaults.cardColors(containerColor = CinematicCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.weight(1f).border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text("Active Titles", color = TextSecondary, fontSize = 11.sp)
          Spacer(modifier = Modifier.height(4.dp))
          Text("${myCatalog.size}", color = BrightCyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          Text("Published to network", color = TextMuted, fontSize = 10.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Submit New Content
    Text(
      text = "Publish Independent Content",
      color = TextPrimary,
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(10.dp))

    Card(
      colors = CardDefaults.cardColors(containerColor = CinematicCard),
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier.fillMaxWidth().border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Film or Episode Title") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrightCyan,
            unfocusedBorderColor = BorderSubtle,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("creator_title_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = synopsis,
          onValueChange = { synopsis = it },
          label = { Text("Synopsis / Logline") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrightCyan,
            unfocusedBorderColor = BorderSubtle,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          maxLines = 3,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedTextField(
            value = genre,
            onValueChange = { genre = it },
            label = { Text("Genre") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = BrightCyan,
              unfocusedBorderColor = BorderSubtle,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = rateStr,
            onValueChange = { rateStr = it },
            label = { Text("Rate (sats/min)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = BrightCyan,
              unfocusedBorderColor = BorderSubtle,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = {
            if (title.isNotBlank()) {
              val runtime = runtimeStr.toIntOrNull() ?: 90
              val rate = rateStr.toLongOrNull() ?: 20L
              onSubmitFilm(title, synopsis, genre, runtime, rate)
              Toast.makeText(context, "Published \"$title\" to FluxStream!", Toast.LENGTH_SHORT).show()
              title = ""
              synopsis = ""
            } else {
              Toast.makeText(context, "Please enter a title", Toast.LENGTH_SHORT).show()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().testTag("creator_submit_button")
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Publish to FluxStream Catalogue", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun AdminScreen(
  allContentCount: Int,
  grossViewingChargesSats: Long,
  platformFeeSats: Long,
  creatorRoyaltiesSats: Long,
  onRunAudit: () -> Unit,
  auditPassed: Boolean,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(ElectricBlue),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text("FluxStream Platform Administration", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Financial reconciliation & double-entry ledger verification", color = TextSecondary, fontSize = 11.sp)
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Financial Reconciliation Cards
    Card(
      colors = CardDefaults.cardColors(containerColor = CinematicCard),
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier.fillMaxWidth().border(1.dp, BorderElectric, RoundedCornerShape(14.dp))
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("Reconciled Revenue Breakdown", color = BrightCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Platform Routing Fee (20%):", color = TextSecondary, fontSize = 13.sp)
          Text("$platformFeeSats sats", color = SuccessGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Creator Earnings Escrow (80%):", color = TextSecondary, fontSize = 13.sp)
          Text("$creatorRoyaltiesSats sats", color = LightningGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Active Catalogue Titles:", color = TextSecondary, fontSize = 13.sp)
          Text("$allContentCount titles", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Audit Invariant Check
    Card(
      colors = CardDefaults.cardColors(containerColor = CinematicCardElevated),
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier.fillMaxWidth().border(1.dp, if (auditPassed) SuccessGreen else DangerRed, RoundedCornerShape(14.dp))
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Security, contentDescription = null, tint = if (auditPassed) SuccessGreen else DangerRed, modifier = Modifier.size(22.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Double-Entry Ledger Integrity Audit", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = if (auditPassed) {
            "Status: VERIFIED PASSED. Every credit has an exact corresponding debit. Sum(debits) + Sum(credits) == 0."
          } else {
            "Status: AUDITING. Click below to verify all double-entry ledger accounts."
          },
          color = if (auditPassed) SuccessGreen else TextSecondary,
          fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = {
            onRunAudit()
            Toast.makeText(context, "Ledger integrity check: PASSED (Sum = 0)", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = if (auditPassed) Color(0xFF065F46) else ElectricBlue),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth().testTag("run_audit_button")
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (auditPassed) "Audit Invariants Re-Verified" else "Run Ledger Audit Check", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
