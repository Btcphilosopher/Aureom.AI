package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TopUpUiState

@Composable
fun TopUpInvoiceDialog(
  state: TopUpUiState,
  onSelectPreset: (Long) -> Unit,
  onSimulateSettlement: () -> Unit,
  onDismiss: () -> Unit
) {
  if (!state.isOpen) return
  val context = LocalContext.current
  val invoice = state.activeInvoice

  val presets = listOf(
    5000L to "5K sats",
    10000L to "10K sats",
    24500L to "0.000245 BTC",
    50000L to "50K sats",
    100000L to "100K sats"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 24.dp)
        .clip(RoundedCornerShape(20.dp))
        .border(1.dp, BorderElectric, RoundedCornerShape(20.dp))
        .testTag("top_up_dialog"),
      color = MidnightNavy
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(ElectricBlue),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Fund Viewing Balance",
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Bitcoin Lightning Network",
                color = BrightCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("close_top_up_dialog_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        if (state.settlementSuccess) {
          // Success State
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(CinematicCard)
              .border(1.dp, SuccessGreen, RoundedCornerShape(14.dp))
              .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Success",
              tint = SuccessGreen,
              modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "Payment Settled Instantly!",
              color = TextPrimary,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "+${state.selectedAmountSats} satoshis credited to your double-entry ledger balance.",
              color = TextSecondary,
              fontSize = 13.sp,
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))

            Button(
              onClick = onDismiss,
              colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth().testTag("settlement_done_button")
            ) {
              Text("Start Streaming", color = Color.Black, fontWeight = FontWeight.Bold)
            }
          }
        } else {
          // Preset Amount Selector
          Text(
            text = "Select Amount:",
            color = TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            presets.take(3).forEach { (sats, label) ->
              val isSelected = state.selectedAmountSats == sats
              Box(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) ElectricBlue else CinematicCard)
                  .border(1.dp, if (isSelected) BrightCyan else BorderSubtle, RoundedCornerShape(10.dp))
                  .clickable { onSelectPreset(sats) }
                  .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = label,
                  color = if (isSelected) Color.White else TextSecondary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            presets.drop(3).forEach { (sats, label) ->
              val isSelected = state.selectedAmountSats == sats
              Box(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) ElectricBlue else CinematicCard)
                  .border(1.dp, if (isSelected) BrightCyan else BorderSubtle, RoundedCornerShape(10.dp))
                  .clickable { onSelectPreset(sats) }
                  .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = label,
                  color = if (isSelected) Color.White else TextSecondary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          // QR Code Canvas & Invoice Box
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(CinematicCard)
              .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
              .padding(16.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              // Procedural Lightning QR Pattern Canvas
              Box(
                modifier = Modifier
                  .size(160.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color.White)
                  .padding(10.dp),
                contentAlignment = Alignment.Center
              ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                  val s = size.width
                  val grid = 17
                  val cell = s / grid

                  // Finder corners
                  drawRoundRect(Color.Black, Offset(0f, 0f), Size(cell * 5, cell * 5), CornerRadius(2f))
                  drawRoundRect(Color.White, Offset(cell, cell), Size(cell * 3, cell * 3), CornerRadius(2f))
                  drawRoundRect(Color.Black, Offset(cell * 1.5f, cell * 1.5f), Size(cell * 2, cell * 2), CornerRadius(1f))

                  drawRoundRect(Color.Black, Offset(s - cell * 5, 0f), Size(cell * 5, cell * 5), CornerRadius(2f))
                  drawRoundRect(Color.White, Offset(s - cell * 4, cell), Size(cell * 3, cell * 3), CornerRadius(2f))
                  drawRoundRect(Color.Black, Offset(s - cell * 3.5f, cell * 1.5f), Size(cell * 2, cell * 2), CornerRadius(1f))

                  drawRoundRect(Color.Black, Offset(0f, s - cell * 5), Size(cell * 5, cell * 5), CornerRadius(2f))
                  drawRoundRect(Color.White, Offset(cell, s - cell * 4), Size(cell * 3, cell * 3), CornerRadius(2f))
                  drawRoundRect(Color.Black, Offset(cell * 1.5f, s - cell * 3.5f), Size(cell * 2, cell * 2), CornerRadius(1f))

                  // Center Lightning Glyph in QR
                  drawCircle(Color.Black, radius = cell * 2f, center = Offset(s / 2, s / 2))
                  drawCircle(Color(0xFF0070F3), radius = cell * 1.5f, center = Offset(s / 2, s / 2))

                  // Data dots
                  val hash = invoice?.paymentHash ?: "fluxstream"
                  for (r in 0 until grid) {
                    for (c in 0 until grid) {
                      val isCorner = (r < 6 && c < 6) || (r < 6 && c > grid - 7) || (r > grid - 7 && c < 6)
                      val isCenter = (r in 6..10 && c in 6..10)
                      if (!isCorner && !isCenter) {
                        val bit = (hash.hashCode() + r * 13 + c * 7) % 3 == 0
                        if (bit) {
                          drawRect(
                            color = Color.Black,
                            topLeft = Offset(c * cell, r * cell),
                            size = Size(cell * 0.9f, cell * 0.9f)
                          )
                        }
                      }
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Copyable Invoice String Box
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(MidnightNavy)
                  .border(1.dp, BorderElectric, RoundedCornerShape(8.dp))
                  .clickable {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Lightning Invoice", invoice?.paymentRequest ?: ""))
                    Toast.makeText(context, "Invoice copied to clipboard!", Toast.LENGTH_SHORT).show()
                  }
                  .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = invoice?.paymentRequest ?: "lnbc...",
                  color = TextSecondary,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  imageVector = Icons.Default.ContentCopy,
                  contentDescription = "Copy invoice",
                  tint = BrightCyan,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Settlement button (Real-time simulated Lightning payment dispatch)
          Button(
            onClick = onSimulateSettlement,
            enabled = !state.isSettling,
            colors = ButtonDefaults.buttonColors(
              containerColor = ElectricBlue,
              contentColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("simulate_settlement_button")
          ) {
            if (state.isSettling) {
              CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Routing over Lightning Network...")
            } else {
              Icon(Icons.Default.Bolt, contentDescription = null, tint = LightningGold, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Simulate Settlement (Pay Invoice)", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}
