package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ContentItem
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TitleDetailModal(
  item: ContentItem?,
  isWatchlisted: Boolean,
  onPlayNow: (ContentItem) -> Unit,
  onPurchase: (ContentItem) -> Unit,
  onRent: (ContentItem) -> Unit,
  onToggleWatchlist: (String) -> Unit,
  onDismiss: () -> Unit
) {
  if (item == null) return
  val context = LocalContext.current
  val resId = context.resources.getIdentifier(item.drawableResName, "drawable", context.packageName)

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 24.dp)
        .clip(RoundedCornerShape(20.dp))
        .border(1.dp, BorderElectric, RoundedCornerShape(20.dp))
        .testTag("title_detail_modal"),
      color = MidnightNavy
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
      ) {
        // Hero Artwork Box with Dismiss button
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
        ) {
          if (resId != 0) {
            Image(
              painter = painterResource(id = resId),
              contentDescription = item.title,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxWidth()
            )
          } else {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(CinematicCard)
            )
          }

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(200.dp)
              .background(
                Brush.verticalGradient(
                  listOf(Color.Transparent, Color(0x99070B14), MidnightNavy)
                )
              )
          )

          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(12.dp)
              .clip(CircleShape)
              .background(Color(0x88000000))
          ) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        // Details content
        Column(modifier = Modifier.padding(20.dp)) {
          Text(
            text = item.title,
            color = TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(4.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(item.genre, color = BrightCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(" • ", color = TextMuted)
            Text("${item.releaseYear}", color = TextSecondary, fontSize = 12.sp)
            Text(" • ", color = TextMuted)
            Text("${item.runtimeMinutes / 60}h ${item.runtimeMinutes % 60}m", color = TextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0x801E293B))
                .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
              Text(item.resolution, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = item.synopsis,
            color = TextSecondary,
            fontSize = 13.sp,
            lineHeight = 18.sp
          )

          Spacer(modifier = Modifier.height(18.dp))

          // Pricing Models
          Text("Streaming & Access Options:", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          Spacer(modifier = Modifier.height(8.dp))

          // Option 1: Pay Per Minute
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(CinematicCard)
              .border(1.dp, BorderElectric, RoundedCornerShape(10.dp))
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Bolt, contentDescription = null, tint = LightningGold, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("Pay Per Minute (Default)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("Stream freely. Micro-billed every minute.", color = TextMuted, fontSize = 11.sp)
              }
            }
            Text("${item.satsPerMinute} sats/m", color = BrightCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Option 2 & 3: Rent & Buy
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Rent
            Column(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(CinematicCard)
                .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                .padding(10.dp)
            ) {
              Text("48h Rental", color = TextSecondary, fontSize = 11.sp)
              Text("${item.rentalPriceSats} sats", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(6.dp))
              Button(
                onClick = { onRent(item) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text("Rent", fontSize = 11.sp)
              }
            }

            // Buy
            Column(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(CinematicCard)
                .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                .padding(10.dp)
            ) {
              Text("Buy in 4K", color = TextSecondary, fontSize = 11.sp)
              Text("${item.purchasePriceSats} sats", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(6.dp))
              Button(
                onClick = { onPurchase(item) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text("Buy", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Primary Actions
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onPlayNow(item) },
              colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f).height(46.dp).testTag("detail_watch_now_button")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Watch Now", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = { onToggleWatchlist(item.id) },
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isWatchlisted) BrightCyan else BorderSubtle),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color(0x66000000),
                contentColor = if (isWatchlisted) BrightCyan else Color.White
              ),
              modifier = Modifier.height(46.dp)
            ) {
              Icon(
                imageVector = if (isWatchlisted) Icons.Default.Check else Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }
  }
}
