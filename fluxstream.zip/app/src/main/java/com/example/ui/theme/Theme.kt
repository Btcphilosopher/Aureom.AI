package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val FluxStreamColorScheme = darkColorScheme(
  primary = ElectricBlue,
  onPrimary = TextPrimary,
  primaryContainer = MidnightNavyPanel,
  onPrimaryContainer = BrightCyan,
  secondary = BrightCyan,
  onSecondary = MidnightNavy,
  secondaryContainer = CinematicCardElevated,
  onSecondaryContainer = TextPrimary,
  tertiary = LightningGold,
  onTertiary = MidnightNavy,
  background = MidnightNavy,
  onBackground = TextPrimary,
  surface = CinematicSurface,
  onSurface = TextPrimary,
  surfaceVariant = CinematicCard,
  onSurfaceVariant = TextSecondary,
  outline = BorderSubtle,
  outlineVariant = BorderElectric,
)

@Composable
fun FluxStreamTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = FluxStreamColorScheme,
    typography = Typography,
    content = content
  )
}

// Alias for template compatibility
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  FluxStreamTheme(content = content)
}
