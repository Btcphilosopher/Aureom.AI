package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LedgerEntry
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BrightCyan
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightningGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
  balanceSats: Long,
  balanceBtc: String,
  balanceFiat: String,
  ledgerEntries: List<LedgerEntry>,
  onOpenTopUp: () -> Unit,
  onFastTopUp: () -> Unit,
  onWithdraw: (Long, String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var showWithdrawDialog by remember { mutableStateOf(false) }
  var withdrawAmountText by remember { mutableStateOf("5000") }
  var withdrawAddressText by remember { mutableStateOf("satoshi@getalby.com") }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MidnightNavy)
      .padding(16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "Bitcoin Lightning Wallet",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Real-time double-entry accounting ledger & Lightning settlement.",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }

      // Lightning Node Status Pill
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(12.dp))
          .background(CinematicCard)
          .border(1.dp, BorderElectric, RoundedCornerShape(12.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(7.dp)
            .clip(CircleShape)
            .background(SuccessGreen)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text("LND Synced", color = BrightCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Big Balance Card
    Card(
      colors = CardDefaults.cardColors(containerColor = CinematicCard),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, BorderElectric, RoundedCornerShape(16.dp))
        .testTag("wallet_main_balance_card")
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top
        ) {
          Column {
            Text("Available Viewing Balance", color = TextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
              Text(
                text = "$balanceSats",
                color = TextPrimary,
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-1).sp
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("sats", color = BrightCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text(
              text = "$balanceBtc  •  $balanceFiat",
              color = TextMuted,
              fontSize = 13.sp
            )
          }

          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(ElectricBlue.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = BrightCyan, modifier = Modifier.size(28.dp))
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = onOpenTopUp,
            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f).testTag("wallet_top_up_button")
          ) {
            Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Top Up (Invoice)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }

          OutlinedButton(
            onClick = { showWithdrawDialog = true },
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = CinematicCardElevated),
            modifier = Modifier.weight(1f).testTag("wallet_withdraw_button")
          ) {
            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = LightningGold, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Withdraw", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Invariant Verification Box
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(Color(0xFF0C1929))
        .border(1.dp, BorderCyanGlow, RoundedCornerShape(8.dp))
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Double-Entry Invariant: Balanced (Sum of all accounts = 0 sats)",
        color = BrightCyan,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Ledger Transactions Header
    Text(
      text = "Transaction Ledger (${ledgerEntries.size} entries)",
      color = TextPrimary,
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold
    )

    Spacer(modifier = Modifier.height(8.dp))

    val userEntries = ledgerEntries.filter { it.account == "USER_BALANCE" }

    if (userEntries.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CinematicCard)
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Text("No transactions recorded yet.", color = TextMuted)
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize().testTag("ledger_entries_list")
      ) {
        items(userEntries) { entry ->
          val isCredit = entry.amountSats > 0
          val dateStr = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date(entry.timestamp))

          Card(
            colors = CardDefaults.cardColors(containerColor = CinematicCard),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                  modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (isCredit) Color(0x2210B981) else Color(0x22EF4444)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = if (isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    contentDescription = null,
                    tint = if (isCredit) SuccessGreen else DangerRed,
                    modifier = Modifier.size(16.dp)
                  )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                  Text(
                    text = entry.description,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                  )
                  Text(
                    text = "$dateStr • Ref: ${entry.referenceId.take(12)}",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }

              Text(
                text = if (isCredit) "+${entry.amountSats} sats" else "${entry.amountSats} sats",
                color = if (isCredit) SuccessGreen else DangerRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }

  // Withdraw Dialog
  if (showWithdrawDialog) {
    AlertDialog(
      onDismissRequest = { showWithdrawDialog = false },
      containerColor = MidnightNavy,
      title = { Text("Withdraw Satoshis", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("Send funds to any Lightning Address or BOLT11 Invoice:", color = TextSecondary, fontSize = 12.sp)
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = withdrawAddressText,
            onValueChange = { withdrawAddressText = it },
            label = { Text("Lightning Address / Invoice") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = BrightCyan,
              unfocusedBorderColor = BorderSubtle,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = withdrawAmountText,
            onValueChange = { withdrawAmountText = it },
            label = { Text("Amount (Satoshis)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = BrightCyan,
              unfocusedBorderColor = BorderSubtle,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amount = withdrawAmountText.toLongOrNull() ?: 0L
            if (amount > 0 && amount <= balanceSats) {
              onWithdraw(amount, withdrawAddressText)
              showWithdrawDialog = false
              Toast.makeText(context, "Withdrawal of $amount sats dispatched!", Toast.LENGTH_SHORT).show()
            } else {
              Toast.makeText(context, "Insufficient balance", Toast.LENGTH_SHORT).show()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Send via Lightning", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showWithdrawDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}
