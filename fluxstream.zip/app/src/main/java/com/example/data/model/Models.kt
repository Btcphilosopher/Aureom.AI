package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "content_items")
data class ContentItem(
  @PrimaryKey val id: String,
  val title: String,
  val synopsis: String,
  val genre: String,
  val releaseYear: Int,
  val runtimeMinutes: Int,
  val resolution: String = "4K", // "4K", "1080p", "HD"
  val category: String = "trending", // "featured", "trending", "popular", "live"
  val pricingModel: String = "pay_per_minute", // "pay_per_minute", "pay_per_title", "rental"
  val satsPerMinute: Long = 20L,
  val purchasePriceSats: Long = 1500L,
  val rentalPriceSats: Long = 500L,
  val drawableResName: String,
  val creatorName: String = "FluxStream Studios",
  val isFeatured: Boolean = false,
  val liveViewerCount: Int = 0
)

@Entity(tableName = "watchlist_items")
data class WatchlistItem(
  @PrimaryKey val contentId: String,
  val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "viewing_history")
data class ViewingHistory(
  @PrimaryKey val contentId: String,
  val lastPositionSeconds: Long,
  val totalMinutesWatched: Int,
  val totalSatsCharged: Long,
  val lastWatchedAt: Long = System.currentTimeMillis()
)

/**
 * Double-entry ledger entry.
 * Accounts:
 * - "USER_BALANCE": available viewing balance for the user
 * - "LIGHTNING_PROVIDER": settlement from Lightning Network
 * - "ESCROW_STREAMING": active in-flight playback sessions
 * - "CREATOR_EARNINGS": allocated 80% to content creator
 * - "PLATFORM_FEE": allocated 20% to FluxStream platform
 */
@Entity(tableName = "ledger_entries")
data class LedgerEntry(
  @PrimaryKey val id: String,
  val timestamp: Long = System.currentTimeMillis(),
  val account: String,
  val amountSats: Long, // positive = credit, negative = debit
  val transactionType: String, // "TOP_UP", "STREAMING_CHARGE", "PURCHASE", "RENTAL", "REFUND", "CREATOR_PAYOUT"
  val referenceId: String, // invoiceId, contentId, or sessionId
  val description: String
)

@Entity(tableName = "lightning_invoices")
data class LightningInvoice(
  @PrimaryKey val invoiceId: String,
  val paymentHash: String,
  val paymentRequest: String, // BOLT11 string like lnbc...
  val amountSats: Long,
  val status: String = "PENDING", // "PENDING", "SETTLED", "EXPIRED"
  val createdAt: Long = System.currentTimeMillis(),
  val settledAt: Long? = null,
  val memo: String = "FluxStream Balance Top Up"
)

enum class UserRole {
  VIEWER,
  CREATOR,
  ADMIN
}

data class UserProfile(
  val id: String = "usr_flux_01",
  val email: String = "tom@ahyx.org",
  val username: String = "SatoshiStreamer",
  val role: UserRole = UserRole.VIEWER,
  val preferredFiat: String = "GBP", // "GBP", "USD", "EUR"
  val fiatSymbol: String = "£",
  val btcToFiatRate: Double = 66600.0 // fiat price per 1.0 BTC
)
