package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ContentItem
import com.example.data.model.LedgerEntry
import com.example.data.model.LightningInvoice
import com.example.data.model.ViewingHistory
import com.example.data.model.WatchlistItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    ContentItem::class,
    WatchlistItem::class,
    ViewingHistory::class,
    LedgerEntry::class,
    LightningInvoice::class
  ],
  version = 1,
  exportSchema = false
)
abstract class FluxStreamDatabase : RoomDatabase() {
  abstract fun fluxStreamDao(): FluxStreamDao

  companion object {
    @Volatile
    private var INSTANCE: FluxStreamDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): FluxStreamDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          FluxStreamDatabase::class.java,
          "fluxstream.db"
        )
          .addCallback(DatabaseCallback(scope))
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database.fluxStreamDao())
          }
        }
      }

      private suspend fun populateInitialData(dao: FluxStreamDao) {
        val items = listOf(
          ContentItem(
            id = "the-next-horizon",
            title = "The Next Horizon",
            synopsis = "A stunning journey into a future worth fighting for. As orbital rings circle high above the neon metropolis, an explorer uncovers the encrypted memory of humanity's greatest discovery.",
            genre = "Sci-Fi",
            releaseYear = 2028,
            runtimeMinutes = 112,
            resolution = "4K",
            category = "trending",
            pricingModel = "pay_per_minute",
            satsPerMinute = 20L,
            purchasePriceSats = 1800L,
            rentalPriceSats = 550L,
            drawableResName = "card_next_horizon",
            creatorName = "Aethelgard Pictures",
            isFeatured = true,
            liveViewerCount = 4210
          ),
          ContentItem(
            id = "river-of-ash",
            title = "River of Ash",
            synopsis = "In the burning aftermath of an industrial collapse, an exiled investigator traverses volcanic ruins to expose the hidden corporate consortium.",
            genre = "Drama",
            releaseYear = 2027,
            runtimeMinutes = 98,
            resolution = "4K",
            category = "trending",
            pricingModel = "pay_per_minute",
            satsPerMinute = 18L,
            purchasePriceSats = 1600L,
            rentalPriceSats = 500L,
            drawableResName = "card_river_of_ash",
            creatorName = "Cinder Peak Films",
            isFeatured = false,
            liveViewerCount = 1840
          ),
          ContentItem(
            id = "the-last-quarter",
            title = "The Last Quarter",
            synopsis = "An intimate, electric look inside the final championship match of the stadium era under roaring digital crowds and biometric scoreboards.",
            genre = "Documentary",
            releaseYear = 2027,
            runtimeMinutes = 84,
            resolution = "4K",
            category = "trending",
            pricingModel = "pay_per_minute",
            satsPerMinute = 15L,
            purchasePriceSats = 1400L,
            rentalPriceSats = 400L,
            drawableResName = "card_last_quarter",
            creatorName = "Apex DocuLab",
            isFeatured = false,
            liveViewerCount = 2950
          ),
          ContentItem(
            id = "velvet-city",
            title = "Velvet City",
            synopsis = "Under the rain-slicked pink and violet alleyways, a rogue cryptographic broker races against syndicates hunting the private master key.",
            genre = "Thriller",
            releaseYear = 2028,
            runtimeMinutes = 106,
            resolution = "4K",
            category = "trending",
            pricingModel = "pay_per_minute",
            satsPerMinute = 22L,
            purchasePriceSats = 1900L,
            rentalPriceSats = 600L,
            drawableResName = "card_velvet_city",
            creatorName = "Neon Shroud Media",
            isFeatured = false,
            liveViewerCount = 3120
          ),
          ContentItem(
            id = "the-wild-coast",
            title = "The Wild Coast",
            synopsis = "Sailing the untouched cliffs of the Northern Cape, free divers and oceanographers document marine migration corridors.",
            genre = "Adventure",
            releaseYear = 2026,
            runtimeMinutes = 93,
            resolution = "4K",
            category = "trending",
            pricingModel = "pay_per_minute",
            satsPerMinute = 16L,
            purchasePriceSats = 1500L,
            rentalPriceSats = 450L,
            drawableResName = "card_wild_coast",
            creatorName = "Horizon Wild Collective",
            isFeatured = false,
            liveViewerCount = 1200
          ),
          ContentItem(
            id = "neon-dreams",
            title = "Neon Dreams",
            synopsis = "A psychedelic synthwave concert captured live from the high-altitude geodesic dome overlooking New Kyoto.",
            genre = "Music",
            releaseYear = 2028,
            runtimeMinutes = 80,
            resolution = "4K",
            category = "popular",
            pricingModel = "pay_per_minute",
            satsPerMinute = 12L,
            purchasePriceSats = 1200L,
            rentalPriceSats = 350L,
            drawableResName = "card_neon_dreams",
            creatorName = "Sub-Bass Horizon",
            isFeatured = false,
            liveViewerCount = 890
          ),
          ContentItem(
            id = "the-build",
            title = "The Build",
            synopsis = "Two master architects construct the world's first carbon-negative geothermal residential spire in Iceland.",
            genre = "Documentary",
            releaseYear = 2027,
            runtimeMinutes = 72,
            resolution = "4K",
            category = "popular",
            pricingModel = "pay_per_minute",
            satsPerMinute = 14L,
            purchasePriceSats = 1300L,
            rentalPriceSats = 380L,
            drawableResName = "card_the_build",
            creatorName = "Construct Media",
            isFeatured = false,
            liveViewerCount = 1420
          ),
          ContentItem(
            id = "lost-in-tokyo",
            title = "Lost in Tokyo",
            synopsis = "Late-night ramen counters, subterranean jazz clubs, and an unexpected encounter between two wandering travelers.",
            genre = "Drama",
            releaseYear = 2028,
            runtimeMinutes = 105,
            resolution = "4K",
            category = "popular",
            pricingModel = "pay_per_minute",
            satsPerMinute = 18L,
            purchasePriceSats = 1600L,
            rentalPriceSats = 500L,
            drawableResName = "card_lost_in_tokyo",
            creatorName = "Shibuya Cinema",
            isFeatured = false,
            liveViewerCount = 2100
          ),
          ContentItem(
            id = "solar-winds",
            title = "Solar Winds",
            synopsis = "An orbital crew rides electromagnetic solar sails across the heliosphere on a mission to intercept an interstellar probe.",
            genre = "Sci-Fi",
            releaseYear = 2028,
            runtimeMinutes = 96,
            resolution = "4K",
            category = "popular",
            pricingModel = "pay_per_minute",
            satsPerMinute = 20L,
            purchasePriceSats = 1750L,
            rentalPriceSats = 520L,
            drawableResName = "card_solar_winds",
            creatorName = "Starward Studios",
            isFeatured = false,
            liveViewerCount = 3400
          ),
          ContentItem(
            id = "kitchen-stories",
            title = "Kitchen Stories",
            synopsis = "Michelin chefs and street hawkers share heritage sourdough starters, heirloom spices, and generational culinary craft.",
            genre = "Lifestyle",
            releaseYear = 2027,
            runtimeMinutes = 52,
            resolution = "1080p",
            category = "popular",
            pricingModel = "pay_per_minute",
            satsPerMinute = 10L,
            purchasePriceSats = 950L,
            rentalPriceSats = 280L,
            drawableResName = "card_kitchen_stories",
            creatorName = "Culinary Visions",
            isFeatured = false,
            liveViewerCount = 670
          ),
          ContentItem(
            id = "the-long-road",
            title = "The Long Road",
            synopsis = "Crossing the desert plateau at sunset, an electric camper van crew finds silence, solidarity, and panoramic horizons.",
            genre = "Drama",
            releaseYear = 2027,
            runtimeMinutes = 88,
            resolution = "4K",
            category = "popular",
            pricingModel = "pay_per_minute",
            satsPerMinute = 16L,
            purchasePriceSats = 1450L,
            rentalPriceSats = 420L,
            drawableResName = "card_the_long_road",
            creatorName = "Desert Nomad Works",
            isFeatured = false,
            liveViewerCount = 1150
          ),
          // Live Channels
          ContentItem(
            id = "live-flux-news",
            title = "Flux 24/7 Global Live",
            synopsis = "Continuous global financial technology updates, Bitcoin Lightning network metrics, and tech broadcasts.",
            genre = "Live TV",
            releaseYear = 2028,
            runtimeMinutes = 0,
            resolution = "1080p 60fps",
            category = "live",
            pricingModel = "pay_per_minute",
            satsPerMinute = 15L,
            purchasePriceSats = 0L,
            rentalPriceSats = 0L,
            drawableResName = "card_next_horizon",
            creatorName = "FluxStream Global News",
            isFeatured = false,
            liveViewerCount = 14820
          ),
          ContentItem(
            id = "live-cyber-beats",
            title = "Cyber Beats Live Radio",
            synopsis = "24/7 lo-fi beats, synthwave streams, and animated procedural cyber visualizers.",
            genre = "Live TV",
            releaseYear = 2028,
            runtimeMinutes = 0,
            resolution = "1080p 60fps",
            category = "live",
            pricingModel = "pay_per_minute",
            satsPerMinute = 5L,
            purchasePriceSats = 0L,
            rentalPriceSats = 0L,
            drawableResName = "card_neon_dreams",
            creatorName = "Lofi Labs Broadcast",
            isFeatured = false,
            liveViewerCount = 8930
          )
        )
        dao.insertContents(items)

        // Seed initial wallet balance matching reference: 0.000245 BTC = 24,500 sats
        val now = System.currentTimeMillis() - 86400000L
        val initialInvoiceId = "inv_seed_init_245"
        val invoice = LightningInvoice(
          invoiceId = initialInvoiceId,
          paymentHash = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
          paymentRequest = "lnbc245u1pj8sflqpp5n6y2...",
          amountSats = 24500L,
          status = "SETTLED",
          createdAt = now,
          settledAt = now,
          memo = "Initial Lightning balance funding"
        )
        dao.insertInvoice(invoice)

        val entryUser = LedgerEntry(
          id = "ledg_init_cr",
          timestamp = now,
          account = "USER_BALANCE",
          amountSats = 24500L,
          transactionType = "TOP_UP",
          referenceId = initialInvoiceId,
          description = "Initial Lightning Top Up (0.000245 BTC)"
        )
        val entryProvider = LedgerEntry(
          id = "ledg_init_dr",
          timestamp = now,
          account = "LIGHTNING_PROVIDER",
          amountSats = -24500L,
          transactionType = "TOP_UP",
          referenceId = initialInvoiceId,
          description = "Settled via Lightning Gateway"
        )
        dao.insertLedgerEntries(listOf(entryUser, entryProvider))
      }
    }
  }
}
