package com.example.data.repository

import com.example.data.local.FluxStreamDao
import com.example.data.model.ContentItem
import com.example.data.model.LedgerEntry
import com.example.data.model.LightningInvoice
import com.example.data.model.ViewingHistory
import com.example.data.model.WatchlistItem
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ContentRepository(private val dao: FluxStreamDao) {

  val allContent: Flow<List<ContentItem>> = dao.getAllContent()
  val featuredContent: Flow<ContentItem?> = dao.getFeaturedContent()
  val watchlistIds: Flow<List<String>> = dao.getWatchlistIds()
  val viewingHistory: Flow<List<ViewingHistory>> = dao.getViewingHistory()

  fun getContentByCategory(category: String): Flow<List<ContentItem>> =
    dao.getContentByCategory(category)

  suspend fun getContentById(id: String): ContentItem? =
    dao.getContentById(id)

  fun isWatchlisted(contentId: String): Flow<Boolean> =
    dao.isWatchlisted(contentId)

  suspend fun toggleWatchlist(contentId: String, currentStatus: Boolean) {
    if (currentStatus) {
      dao.removeFromWatchlist(contentId)
    } else {
      dao.addToWatchlist(WatchlistItem(contentId))
    }
  }

  suspend fun recordViewingProgress(
    contentId: String,
    positionSeconds: Long,
    minutesWatched: Int,
    satsCharged: Long
  ) {
    val existing = dao.getHistoryFor(contentId)
    val totalMinutes = (existing?.totalMinutesWatched ?: 0) + minutesWatched
    val totalCharged = (existing?.totalSatsCharged ?: 0) + satsCharged
    dao.upsertHistory(
      ViewingHistory(
        contentId = contentId,
        lastPositionSeconds = positionSeconds,
        totalMinutesWatched = totalMinutes,
        totalSatsCharged = totalCharged,
        lastWatchedAt = System.currentTimeMillis()
      )
    )
  }

  suspend fun addCreatorContent(item: ContentItem) {
    dao.insertContent(item)
  }
}

class WalletLedgerRepository(private val dao: FluxStreamDao) {

  val userBalanceSats: Flow<Long> = dao.getUserBalanceSats()
  val creatorEarningsSats: Flow<Long> = dao.getCreatorEarningsSats()
  val platformFeeSats: Flow<Long> = dao.getPlatformFeeSats()
  val allLedgerEntries: Flow<List<LedgerEntry>> = dao.getAllLedgerEntries()
  val allInvoices: Flow<List<LightningInvoice>> = dao.getAllInvoices()

  /**
   * Generates a new BOLT11 Lightning Invoice for top-up.
   */
  suspend fun createTopUpInvoice(amountSats: Long, memo: String = "FluxStream Top-Up"): LightningInvoice {
    val id = "inv_" + UUID.randomUUID().toString().take(12)
    val randomHash = UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")
    // Generate authentic-looking BOLT11 payment request
    val bolt11 = "lnbc${amountSats}u1p" + randomHash.take(32) + "fluxstream"

    val invoice = LightningInvoice(
      invoiceId = id,
      paymentHash = randomHash,
      paymentRequest = bolt11,
      amountSats = amountSats,
      status = "PENDING",
      createdAt = System.currentTimeMillis(),
      settledAt = null,
      memo = memo
    )
    dao.insertInvoice(invoice)
    return invoice
  }

  /**
   * Settles an invoice via the double-entry accounting ledger.
   */
  suspend fun settleInvoice(invoiceId: String) {
    dao.settleTopUpInvoice(invoiceId)
  }

  /**
   * Deducts viewing charges atomically and allocates 80% to creator and 20% to platform.
   */
  suspend fun processStreamingCharge(
    contentId: String,
    contentTitle: String,
    creatorName: String,
    chargeSats: Long,
    minutesBilled: Int
  ): Boolean {
    return dao.processViewingCharge(
      contentId = contentId,
      contentTitle = contentTitle,
      creatorName = creatorName,
      chargeSats = chargeSats,
      minutesBilled = minutesBilled
    )
  }

  /**
   * Process full purchase or rental.
   */
  suspend fun processPurchase(
    contentId: String,
    contentTitle: String,
    creatorName: String,
    amountSats: Long,
    isRental: Boolean
  ) {
    val now = System.currentTimeMillis()
    val creatorShare = (amountSats * 80) / 100
    val platformShare = amountSats - creatorShare
    val type = if (isRental) "RENTAL" else "PURCHASE"
    val desc = if (isRental) "48h Rental: $contentTitle" else "Purchased 4K Access: $contentTitle"

    val entryUser = LedgerEntry(
      id = "buy_dr_${contentId}_${now}",
      timestamp = now,
      account = "USER_BALANCE",
      amountSats = -amountSats,
      transactionType = type,
      referenceId = contentId,
      description = desc
    )
    val entryCreator = LedgerEntry(
      id = "buy_cr_creator_${contentId}_${now}",
      timestamp = now,
      account = "CREATOR_EARNINGS",
      amountSats = creatorShare,
      transactionType = type,
      referenceId = contentId,
      description = "Royalty (80%) for $contentTitle from $type"
    )
    val entryPlatform = LedgerEntry(
      id = "buy_cr_plat_${contentId}_${now}",
      timestamp = now,
      account = "PLATFORM_FEE",
      amountSats = platformShare,
      transactionType = type,
      referenceId = contentId,
      description = "Platform fee (20%) for $contentTitle"
    )
    dao.insertLedgerEntries(listOf(entryUser, entryCreator, entryPlatform))
  }

  /**
   * Withdraw creator earnings or balance to Lightning Address.
   */
  suspend fun requestWithdrawal(amountSats: Long, destination: String): Boolean {
    val now = System.currentTimeMillis()
    val entryUser = LedgerEntry(
      id = "wdr_dr_${now}",
      timestamp = now,
      account = "USER_BALANCE",
      amountSats = -amountSats,
      transactionType = "WITHDRAWAL",
      referenceId = destination,
      description = "Lightning Payout to $destination"
    )
    val entryProvider = LedgerEntry(
      id = "wdr_cr_provider_${now}",
      timestamp = now,
      account = "LIGHTNING_PROVIDER",
      amountSats = amountSats,
      transactionType = "WITHDRAWAL",
      referenceId = destination,
      description = "Outbound Lightning payout dispatch"
    )
    dao.insertLedgerEntries(listOf(entryUser, entryProvider))
    return true
  }

  /**
   * Verifies double-entry ledger invariant: sum of all accounts MUST equal 0.
   */
  suspend fun auditLedgerIntegrity(): Boolean {
    val sum = dao.getSumOfAllLedgerEntries()
    return sum == 0L
  }
}
