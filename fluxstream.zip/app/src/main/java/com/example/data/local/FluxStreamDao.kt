package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.ContentItem
import com.example.data.model.LedgerEntry
import com.example.data.model.LightningInvoice
import com.example.data.model.ViewingHistory
import com.example.data.model.WatchlistItem
import kotlinx.coroutines.flow.Flow

@Dao
interface FluxStreamDao {

  // Content items
  @Query("SELECT * FROM content_items ORDER BY releaseYear DESC")
  fun getAllContent(): Flow<List<ContentItem>>

  @Query("SELECT * FROM content_items WHERE id = :id")
  suspend fun getContentById(id: String): ContentItem?

  @Query("SELECT * FROM content_items WHERE isFeatured = 1 LIMIT 1")
  fun getFeaturedContent(): Flow<ContentItem?>

  @Query("SELECT * FROM content_items WHERE category = :category")
  fun getContentByCategory(category: String): Flow<List<ContentItem>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertContents(items: List<ContentItem>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertContent(item: ContentItem)

  // Watchlist
  @Query("SELECT contentId FROM watchlist_items")
  fun getWatchlistIds(): Flow<List<String>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun addToWatchlist(item: WatchlistItem)

  @Query("DELETE FROM watchlist_items WHERE contentId = :contentId")
  suspend fun removeFromWatchlist(contentId: String)

  @Query("SELECT EXISTS(SELECT 1 FROM watchlist_items WHERE contentId = :contentId)")
  fun isWatchlisted(contentId: String): Flow<Boolean>

  // Viewing History
  @Query("SELECT * FROM viewing_history ORDER BY lastWatchedAt DESC")
  fun getViewingHistory(): Flow<List<ViewingHistory>>

  @Query("SELECT * FROM viewing_history WHERE contentId = :contentId")
  suspend fun getHistoryFor(contentId: String): ViewingHistory?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertHistory(history: ViewingHistory)

  // Ledger
  @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC")
  fun getAllLedgerEntries(): Flow<List<LedgerEntry>>

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertLedgerEntries(entries: List<LedgerEntry>)

  @Query("SELECT COALESCE(SUM(amountSats), 0) FROM ledger_entries WHERE account = 'USER_BALANCE'")
  fun getUserBalanceSats(): Flow<Long>

  @Query("SELECT COALESCE(SUM(amountSats), 0) FROM ledger_entries WHERE account = 'CREATOR_EARNINGS'")
  fun getCreatorEarningsSats(): Flow<Long>

  @Query("SELECT COALESCE(SUM(amountSats), 0) FROM ledger_entries WHERE account = 'PLATFORM_FEE'")
  fun getPlatformFeeSats(): Flow<Long>

  @Query("SELECT COALESCE(SUM(amountSats), 0) FROM ledger_entries")
  suspend fun getSumOfAllLedgerEntries(): Long

  // Invoices
  @Query("SELECT * FROM lightning_invoices ORDER BY createdAt DESC")
  fun getAllInvoices(): Flow<List<LightningInvoice>>

  @Query("SELECT * FROM lightning_invoices WHERE invoiceId = :invoiceId")
  suspend fun getInvoiceById(invoiceId: String): LightningInvoice?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInvoice(invoice: LightningInvoice)

  @Query("UPDATE lightning_invoices SET status = :status, settledAt = :settledAt WHERE invoiceId = :invoiceId")
  suspend fun updateInvoiceStatus(invoiceId: String, status: String, settledAt: Long?)

  // Double-Entry Atomic Settlement for Top Up
  @Transaction
  suspend fun settleTopUpInvoice(invoiceId: String) {
    val invoice = getInvoiceById(invoiceId) ?: return
    if (invoice.status == "SETTLED") return // idempotency check

    val now = System.currentTimeMillis()
    updateInvoiceStatus(invoiceId, "SETTLED", now)

    val entryUser = LedgerEntry(
      id = "ledg_cr_${invoiceId}_${now}",
      timestamp = now,
      account = "USER_BALANCE",
      amountSats = invoice.amountSats, // Credit user balance
      transactionType = "TOP_UP",
      referenceId = invoiceId,
      description = "Lightning Top Up (+${invoice.amountSats} sats)"
    )

    val entryProvider = LedgerEntry(
      id = "ledg_dr_${invoiceId}_${now}",
      timestamp = now,
      account = "LIGHTNING_PROVIDER",
      amountSats = -invoice.amountSats, // Debit Lightning settlement
      transactionType = "TOP_UP",
      referenceId = invoiceId,
      description = "Settlement from Lightning node"
    )

    insertLedgerEntries(listOf(entryUser, entryProvider))
  }

  // Double-Entry Atomic Streaming Viewing Charge
  @Transaction
  suspend fun processViewingCharge(
    contentId: String,
    contentTitle: String,
    creatorName: String,
    chargeSats: Long,
    minutesBilled: Int
  ): Boolean {
    if (chargeSats <= 0) return true

    val now = System.currentTimeMillis()
    val creatorShare = (chargeSats * 80) / 100 // 80% to creator
    val platformShare = chargeSats - creatorShare // 20% to FluxStream platform

    val entryUser = LedgerEntry(
      id = "view_dr_${contentId}_${now}",
      timestamp = now,
      account = "USER_BALANCE",
      amountSats = -chargeSats,
      transactionType = "STREAMING_CHARGE",
      referenceId = contentId,
      description = "Streamed $contentTitle ($minutesBilled min @ ${chargeSats / minutesBilled.coerceAtLeast(1)} sats/m)"
    )

    val entryCreator = LedgerEntry(
      id = "view_cr_creator_${contentId}_${now}",
      timestamp = now,
      account = "CREATOR_EARNINGS",
      amountSats = creatorShare,
      transactionType = "STREAMING_CHARGE",
      referenceId = contentId,
      description = "Creator 80% royalty ($creatorName for $contentTitle)"
    )

    val entryPlatform = LedgerEntry(
      id = "view_cr_plat_${contentId}_${now}",
      timestamp = now,
      account = "PLATFORM_FEE",
      amountSats = platformShare,
      transactionType = "STREAMING_CHARGE",
      referenceId = contentId,
      description = "FluxStream 20% platform routing fee"
    )

    insertLedgerEntries(listOf(entryUser, entryCreator, entryPlatform))
    return true
  }
}
