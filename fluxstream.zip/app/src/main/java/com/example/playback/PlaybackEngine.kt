package com.example.playback

import com.example.data.model.ContentItem
import com.example.data.repository.ContentRepository
import com.example.data.repository.WalletLedgerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlaybackState(
  val activeItem: ContentItem? = null,
  val isPlaying: Boolean = false,
  val isBuffering: Boolean = false,
  val currentPositionSeconds: Long = 0L,
  val totalDurationSeconds: Long = 6720L, // 112 mins default
  val playbackSpeed: Float = 1.0f,
  val selectedQuality: String = "4K Ultra",
  val subtitlesEnabled: Boolean = true,
  val audioTrack: String = "English (Dolby Atmos)",
  val isFullscreen: Boolean = false,

  // Pay-per-minute metrics
  val sessionDurationMinutes: Int = 0,
  val accumulatedCostSats: Long = 0L,
  val currentRateSatsPerMin: Long = 20L,
  val paymentStatus: String = "Active", // "Active", "Paused", "Low Balance", "Purchased"
  val lastHeartbeatTime: Long = 0L,
  val showLowBalanceWarning: Boolean = false
)

class PlaybackEngine(
  private val contentRepository: ContentRepository,
  private val walletRepository: WalletLedgerRepository,
  private val scope: CoroutineScope
) {
  private val _state = MutableStateFlow(PlaybackState())
  val state: StateFlow<PlaybackState> = _state.asStateFlow()

  private var timerJob: Job? = null
  private var accumulatedSecondsInCurrentMinute = 0

  fun startPlayback(item: ContentItem, resumePosition: Long = 0L) {
    stopPlayback()

    _state.update {
      PlaybackState(
        activeItem = item,
        isPlaying = true,
        currentPositionSeconds = resumePosition,
        totalDurationSeconds = (item.runtimeMinutes * 60).toLong().coerceAtLeast(3600L),
        currentRateSatsPerMin = item.satsPerMinute,
        accumulatedCostSats = 0L,
        sessionDurationMinutes = 0,
        paymentStatus = "Active",
        showLowBalanceWarning = false
      )
    }

    startBillingAndPlaybackLoop()
  }

  fun togglePlayPause() {
    val current = _state.value
    if (current.activeItem == null) return

    val newPlaying = !current.isPlaying
    _state.update { it.copy(isPlaying = newPlaying, paymentStatus = if (newPlaying) "Active" else "Paused") }
    if (newPlaying) {
      startBillingAndPlaybackLoop()
    } else {
      timerJob?.cancel()
    }
  }

  fun seekTo(seconds: Long) {
    _state.update {
      val clamped = seconds.coerceIn(0L, it.totalDurationSeconds)
      it.copy(currentPositionSeconds = clamped)
    }
  }

  fun seekRelative(deltaSeconds: Long) {
    seekTo(_state.value.currentPositionSeconds + deltaSeconds)
  }

  fun setPlaybackSpeed(speed: Float) {
    _state.update { it.copy(playbackSpeed = speed) }
  }

  fun setQuality(quality: String) {
    _state.update { it.copy(selectedQuality = quality) }
  }

  fun toggleSubtitles() {
    _state.update { it.copy(subtitlesEnabled = !it.subtitlesEnabled) }
  }

  fun setAudioTrack(track: String) {
    _state.update { it.copy(audioTrack = track) }
  }

  fun toggleFullscreen() {
    _state.update { it.copy(isFullscreen = !it.isFullscreen) }
  }

  fun dismissLowBalanceWarning() {
    _state.update { it.copy(showLowBalanceWarning = false) }
  }

  fun stopPlayback() {
    timerJob?.cancel()
    timerJob = null
    val current = _state.value
    val item = current.activeItem

    if (item != null) {
      scope.launch(Dispatchers.IO) {
        contentRepository.recordViewingProgress(
          contentId = item.id,
          positionSeconds = current.currentPositionSeconds,
          minutesWatched = current.sessionDurationMinutes,
          satsCharged = current.accumulatedCostSats
        )
      }
    }

    _state.update { PlaybackState() }
    accumulatedSecondsInCurrentMinute = 0
  }

  private fun startBillingAndPlaybackLoop() {
    timerJob?.cancel()
    timerJob = scope.launch(Dispatchers.Default) {
      while (isActive && _state.value.isPlaying) {
        delay(1000L)

        // Advance position
        val currentState = _state.value
        val item = currentState.activeItem ?: break
        val newPos = currentState.currentPositionSeconds + 1
        accumulatedSecondsInCurrentMinute++

        // Check if 60 seconds of real streaming elapsed (or simulation step)
        if (accumulatedSecondsInCurrentMinute >= 60) {
          accumulatedSecondsInCurrentMinute = 0

          // Check wallet balance
          val balance = walletRepository.userBalanceSats.first()
          val rate = item.satsPerMinute

          if (balance < rate) {
            // Low balance! Pause playback immediately to prevent unauthorized viewing
            _state.update {
              it.copy(
                isPlaying = false,
                paymentStatus = "Low Balance",
                showLowBalanceWarning = true
              )
            }
            break
          } else {
            // Server-side authoritative charge
            walletRepository.processStreamingCharge(
              contentId = item.id,
              contentTitle = item.title,
              creatorName = item.creatorName,
              chargeSats = rate,
              minutesBilled = 1
            )

            _state.update {
              it.copy(
                sessionDurationMinutes = it.sessionDurationMinutes + 1,
                accumulatedCostSats = it.accumulatedCostSats + rate,
                lastHeartbeatTime = System.currentTimeMillis()
              )
            }
          }
        }

        _state.update {
          it.copy(
            currentPositionSeconds = newPos,
            lastHeartbeatTime = if (newPos % 5L == 0L) System.currentTimeMillis() else it.lastHeartbeatTime
          )
        }
      }
    }
  }
}
