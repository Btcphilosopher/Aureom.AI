package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.aureom.components.AureomNavigationRail
import com.example.aureom.controller.FocusEngine
import com.example.aureom.controller.LocalFocusEngine
import com.example.aureom.core.state.ConsoleRoute
import com.example.aureom.core.theme.AureomTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      CompositionLocalProvider(LocalFocusEngine provides FocusEngine()) {
        AureomTheme {
          AureomNavigationRail(
            currentRoute = ConsoleRoute.HOME,
            onNavigate = {},
            isDevModeEnabled = true
          )
        }
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
