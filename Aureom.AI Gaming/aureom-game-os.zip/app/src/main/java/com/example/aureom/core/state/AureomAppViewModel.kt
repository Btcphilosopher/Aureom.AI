package com.example.aureom.core.state

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aureom.core.logging.AureomLogger
import com.example.aureom.core.telemetry.UiTelemetry
import com.example.aureom.data.mock.MockAureomBackend
import com.example.aureom.domain.model.*
import com.example.aureom.domain.repository.*
import com.example.aureom.platform.websocket.AureomRealtimeClient
import com.example.aureom.platform.websocket.RealtimeEvent
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AureomAppViewModel(
    val backend: MockAureomBackend,
    val realtimeClient: AureomRealtimeClient
) : ViewModel() {

    private val _appState = MutableStateFlow(
        AppState(
            currentUser = backend.playerProfile.value
        )
    )
    val appState: StateFlow<AppState> = _appState.asStateFlow()

    // Expose underlying reactive state from repositories
    val games: StateFlow<List<Game>> = backend.games
    val quickResumeList: StateFlow<List<QuickResumeGame>> = backend.quickResumeList
    val friends: StateFlow<List<Friend>> = backend.friends
    val activeParty: StateFlow<Party?> = backend.activeParty
    val conversations: StateFlow<List<Conversation>> = backend.conversations
    val achievements: StateFlow<List<Achievement>> = backend.achievements
    val downloads: StateFlow<List<DownloadItem>> = backend.downloads
    val storeProducts: StateFlow<List<StoreProduct>> = backend.storeProducts
    val systemStatus: StateFlow<SystemStatus> = backend.systemStatus
    val notifications: StateFlow<List<AureomNotification>> = backend.notifications
    val playerProfile: StateFlow<PlayerProfile> = backend.playerProfile
    val displaySettings: StateFlow<DisplaySettings> = backend.displaySettings
    val audioSettings: StateFlow<AudioSettings> = backend.audioSettings
    val controllerSettings: StateFlow<ControllerSettings> = backend.controllerSettings
    val accessibilitySettings: StateFlow<AccessibilitySettings> = backend.accessibilitySettings
    val privacySettings: StateFlow<PrivacySettings> = backend.privacySettings

    init {
        // Observe currently running game from backend
        viewModelScope.launch {
            backend.currentlyRunningGame.collect { running ->
                _appState.update { it.copy(activeRunningGame = running) }
            }
        }

        // Observe profile updates
        viewModelScope.launch {
            backend.playerProfile.collect { profile ->
                _appState.update { it.copy(currentUser = profile) }
            }
        }

        // Realtime event listener
        viewModelScope.launch {
            realtimeClient.events.collect { event ->
                when (event) {
                    is RealtimeEvent.NotificationCreated -> {
                        showOverlayNotification(event.notification)
                    }
                    is RealtimeEvent.AchievementUnlocked -> {
                        backend.unlockAchievement(event.achievementId)
                    }
                    else -> {}
                }
            }
        }
    }

    fun navigateTo(route: ConsoleRoute) {
        UiTelemetry.screenOpen(route.routeId)
        _appState.update { it.copy(currentRoute = route, isSearchOpen = false, isGuideMenuOpen = false) }
    }

    fun setSelectedGame(gameId: String) {
        val game = backend.getGameById(gameId)
        if (game != null) {
            UiTelemetry.gameSelected(gameId, game.title)
            _appState.update { it.copy(selectedGameId = gameId, currentGame = game) }
        }
    }

    fun launchGame(gameId: String) {
        viewModelScope.launch {
            val game = backend.getGameById(gameId) ?: return@launch
            AureomLogger.info("AureomAppViewModel", "Initiating console launch sequence for ${game.title}")
            _appState.update { it.copy(isGameLaunching = true) }
            delay(1200) // Realistic console splash/handshake delay
            backend.launchGame(gameId)
            _appState.update { it.copy(isGameLaunching = false) }
        }
    }

    fun exitGame() {
        viewModelScope.launch {
            backend.exitRunningGame()
        }
    }

    fun suspendCurrentGameToQuickResume() {
        viewModelScope.launch {
            val running = _appState.value.activeRunningGame ?: return@launch
            backend.suspendToQuickResume(running.id)
        }
    }

    fun toggleSearch(open: Boolean? = null) {
        _appState.update { current ->
            current.copy(isSearchOpen = open ?: !current.isSearchOpen)
        }
    }

    fun toggleGuideMenu(open: Boolean? = null) {
        _appState.update { current ->
            current.copy(isGuideMenuOpen = open ?: !current.isGuideMenuOpen)
        }
    }

    fun toggleDeveloperMode() {
        _appState.update { it.copy(isDevModeEnabled = !it.isDevModeEnabled) }
    }

    fun toggleDebugOverlay() {
        _appState.update { it.copy(showDebugOverlay = !it.showDebugOverlay) }
    }

    fun toggleOfflineMode() {
        _appState.update { it.copy(isOfflineMode = !it.isOfflineMode) }
    }

    fun showOverlayNotification(notification: AureomNotification) {
        viewModelScope.launch {
            _appState.update { it.copy(overlayNotification = notification) }
            delay(4000)
            _appState.update {
                if (it.overlayNotification?.id == notification.id) it.copy(overlayNotification = null) else it
            }
        }
    }

    fun dismissOverlayNotification() {
        _appState.update { it.copy(overlayNotification = null) }
    }
}
