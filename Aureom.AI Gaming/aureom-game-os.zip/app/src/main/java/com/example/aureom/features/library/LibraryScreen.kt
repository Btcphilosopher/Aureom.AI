package com.example.aureom.features.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.components.GameCard
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.EntitlementType
import com.example.aureom.domain.model.Game

enum class LibraryTab(val label: String) {
    ALL("ALL GAMES"),
    INSTALLED("INSTALLED"),
    RECENT("RECENT"),
    FAVOURITES("FAVORITES"),
    READY_TO_INSTALL("READY TO INSTALL"),
    PASS("AUREOM PASS")
}

enum class LibrarySort(val label: String) {
    RECENT("Most Recent"),
    NAME("Alphabetical"),
    SIZE("Storage Size"),
    PLAYTIME("Playtime"),
    ACHIEVEMENTS("Achievements")
}

@Composable
fun LibraryScreen(
    viewModel: AureomAppViewModel,
    onNavigateToGameDetails: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val games by viewModel.games.collectAsState()
    var selectedTab by remember { mutableStateOf(LibraryTab.ALL) }
    var selectedSort by remember { mutableStateOf(LibrarySort.RECENT) }

    val filteredGames = remember(games, selectedTab, selectedSort) {
        val tabFiltered = when (selectedTab) {
            LibraryTab.ALL -> games
            LibraryTab.INSTALLED -> games.filter { it.isInstalled }
            LibraryTab.RECENT -> games.filter { it.lastPlayedTimestamp > 0 }.sortedByDescending { it.lastPlayedTimestamp }
            LibraryTab.FAVOURITES -> games.filter { it.isFavorite }
            LibraryTab.READY_TO_INSTALL -> games.filter { !it.isInstalled }
            LibraryTab.PASS -> games.filter { it.entitlement == EntitlementType.SUBSCRIPTION_PASS }
        }

        when (selectedSort) {
            LibrarySort.RECENT -> tabFiltered.sortedByDescending { it.lastPlayedTimestamp }
            LibrarySort.NAME -> tabFiltered.sortedBy { it.title }
            LibrarySort.SIZE -> tabFiltered.sortedByDescending { it.sizeGb }
            LibrarySort.PLAYTIME -> tabFiltered.sortedByDescending { it.playtimeMinutes }
            LibrarySort.ACHIEVEMENTS -> tabFiltered.sortedByDescending { it.unlockedAchievements }
        }
    }

    Column(
        modifier = modifier
            .testTag("library_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg)
    ) {
        // Header with Counts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.sm),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "MY GAMES & APPS",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "${filteredGames.size} games available • ${games.count { it.isInstalled }} installed",
                    color = AureomColors.TextSecondary,
                    fontSize = 13.sp
                )
            }

            // Quick Sort Selector
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(AureomColors.SurfaceCard)
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
                    .clickable {
                        selectedSort = when (selectedSort) {
                            LibrarySort.RECENT -> LibrarySort.NAME
                            LibrarySort.NAME -> LibrarySort.PLAYTIME
                            LibrarySort.PLAYTIME -> LibrarySort.SIZE
                            LibrarySort.SIZE -> LibrarySort.ACHIEVEMENTS
                            LibrarySort.ACHIEVEMENTS -> LibrarySort.RECENT
                        }
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Sort,
                    contentDescription = "Sort",
                    tint = AureomColors.AureomGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Sort: ${selectedSort.label}",
                    color = AureomColors.TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Horizontal Category Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.xs),
            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
        ) {
            LibraryTab.values().forEach { tab ->
                val isSelected = selectedTab == tab
                ConsoleFocusable(
                    nodeId = "tab_${tab.name}",
                    groupId = "library_tabs",
                    onClick = { selectedTab = tab },
                    shape = RoundedCornerShape(8.dp)
                ) { isFocused ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) AureomColors.AureomGold
                                else if (isFocused) AureomColors.SurfaceCardElevated
                                else AureomColors.SurfaceDark
                            )
                            .border(
                                1.dp,
                                if (isSelected) AureomColors.AureomGoldBright else AureomColors.BorderSubtle,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = tab.label,
                            color = if (isSelected) Color.Black else AureomColors.TextPrimary,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(AureomSpacing.sm))

        // Games Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 180.dp),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.md),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
            items(filteredGames, key = { it.id }) { game ->
                GameCard(
                    game = game,
                    groupId = "library_grid",
                    cardWidth = 190.dp,
                    cardHeight = 240.dp,
                    onClick = { onNavigateToGameDetails(game.id) }
                )
            }
        }
    }
}
