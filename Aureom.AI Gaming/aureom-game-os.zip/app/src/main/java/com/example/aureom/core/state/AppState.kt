package com.example.aureom.core.state

import com.example.aureom.domain.model.*

enum class ConsoleRoute(val routeId: String, val displayName: String) {
    HOME("home", "HOME"),
    LIBRARY("library", "MY GAMES"),
    STORE("store", "STORE"),
    SOCIAL("social", "SOCIAL"),
    ACHIEVEMENTS("achievements", "ACHIEVEMENTS"),
    PROFILE("profile", "PROFILE"),
    SETTINGS("settings", "SETTINGS"),
    SYSTEM("system", "SYSTEM"),
    DOWNLOADS("downloads", "DOWNLOADS"),
    DEVELOPER("developer", "DEV MODE");

    companion object {
        fun fromRouteId(id: String): ConsoleRoute =
            values().firstOrNull { it.routeId == id } ?: HOME
    }
}

data class AppState(
    val currentUser: PlayerProfile,
    val currentRoute: ConsoleRoute = ConsoleRoute.HOME,
    val currentGame: Game? = null,
    val selectedGameId: String = "game_01",
    val activeRunningGame: Game? = null,
    val isGameLaunching: Boolean = false,
    val isSearchOpen: Boolean = false,
    val isGuideMenuOpen: Boolean = false,
    val isDevModeEnabled: Boolean = false,
    val showDebugOverlay: Boolean = false,
    val overlayNotification: AureomNotification? = null,
    val isOfflineMode: Boolean = false
)
