package com.example.aureom.features.system

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel

@Composable
fun SystemScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val systemStatus by viewModel.systemStatus.collectAsState()
    val games by viewModel.games.collectAsState()

    val totalInstalledGb = games.filter { it.isInstalled }.sumOf { it.sizeGb }
    val totalCapacityGb = 2000.0
    val systemReserveGb = 160.0
    val freeGb = totalCapacityGb - totalInstalledGb - systemReserveGb
    val usedRatio = ((totalInstalledGb + systemReserveGb) / totalCapacityGb).toFloat()

    LazyColumn(
        modifier = modifier
            .testTag("system_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(AureomSpacing.lg),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(vertical = AureomSpacing.sm)) {
                Text(
                    text = "SYSTEM & STORAGE POOL",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Aureom HyperVelocity Architecture NVMe Bus",
                    color = AureomColors.TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Storage Visualizer Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AureomColors.SurfaceCard)
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(16.dp))
                    .padding(AureomSpacing.lg)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storage,
                                contentDescription = "Internal NVMe",
                                tint = AureomColors.AureomGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(AureomSpacing.sm))
                            Column {
                                Text(
                                    text = "INTERNAL GEN-5 NVMe SSD",
                                    color = AureomColors.TextPrimary,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "${"%.1f".format(freeGb)} GB Free of 2,000 GB",
                                    color = AureomColors.TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Text(
                            text = "${(usedRatio * 100).toInt()}% USED",
                            color = AureomColors.AureomGoldBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    }

                    LinearProgressIndicator(
                        progress = { usedRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp)),
                        color = AureomColors.AureomGold,
                        trackColor = AureomColors.SurfaceDark
                    )

                    // Breakdown tags
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "■ Games: ${"%.1f".format(totalInstalledGb)} GB",
                            color = AureomColors.AureomGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "■ System Reserved: ${"%.1f".format(systemReserveGb)} GB",
                            color = AureomColors.AureomCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "■ Free: ${"%.1f".format(freeGb)} GB",
                            color = AureomColors.Success,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Hardware & Firmware Telemetry
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AureomColors.SurfaceCard)
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(16.dp))
                    .padding(AureomSpacing.lg)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                    Text(
                        text = "CONSOLE SPECIFICATIONS & FIRMWARE",
                        color = AureomColors.AureomGold,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )

                    val specs = listOf(
                        "Operating System" to systemStatus.osVersion,
                        "Kernel Architecture" to "Aureom Microkernel v6.12-rt (Custom)",
                        "Compute Hardware" to "16-Core Zen 5 + RDNA 3.5 24TFLOPS Unified",
                        "System Memory" to "24 GB GDDR7 @ 768 GB/s",
                        "DirectStorage I/O" to "Hardware Decompression 8.5 GB/s Raw",
                        "Console Hardware ID" to "AU-X99-4482-9014-E",
                        "Ethernet MAC" to "00:1A:7D:DA:71:02",
                        "IP Address" to "192.168.1.144 (DHCP)",
                        "Cloud Fabric State" to "Synced • Zero Sync Latency"
                    )

                    specs.forEach { (label, value) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = label, color = AureomColors.TextSecondary, fontSize = 12.sp)
                            Text(
                                text = value,
                                color = AureomColors.TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
