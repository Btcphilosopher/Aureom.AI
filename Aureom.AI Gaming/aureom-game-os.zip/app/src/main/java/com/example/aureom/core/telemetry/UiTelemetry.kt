package com.example.aureom.core.telemetry

import com.example.aureom.core.logging.AureomLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TelemetryEvent(
    val eventName: String,
    val payload: Map<String, String>,
    val timestamp: Long = System.currentTimeMillis()
)

object UiTelemetry {
    private var isEnabled = true
    private val _events = MutableStateFlow<List<TelemetryEvent>>(emptyList())
    val events: StateFlow<List<TelemetryEvent>> = _events.asStateFlow()

    fun setEnabled(enabled: Boolean) {
        isEnabled = enabled
    }

    fun track(eventName: String, params: Map<String, String> = emptyMap()) {
        if (!isEnabled) return
        AureomLogger.debug("UiTelemetry", "Event: $eventName | $params")
        val event = TelemetryEvent(eventName, params)
        _events.value = (_events.value + event).takeLast(50)
    }

    fun screenOpen(screen: String) = track("screen_open", mapOf("screen" to screen))
    fun gameSelected(gameId: String, title: String) = track("game_selected", mapOf("id" to gameId, "title" to title))
    fun gameLaunched(gameId: String) = track("game_launched", mapOf("id" to gameId))
    fun search(query: String) = track("search", mapOf("query" to query))
    fun purchaseView(productId: String) = track("purchase_view", mapOf("productId" to productId))
    fun achievementView(achievementId: String) = track("achievement_view", mapOf("id" to achievementId))
    fun friendAction(friendId: String, action: String) = track("friend_action", mapOf("friendId" to friendId, "action" to action))
    fun downloadView(downloadId: String) = track("download_view", mapOf("downloadId" to downloadId))
    fun settingsChange(category: String, key: String, value: String) =
        track("settings_change", mapOf("category" to category, "key" to key, "value" to value))
}
