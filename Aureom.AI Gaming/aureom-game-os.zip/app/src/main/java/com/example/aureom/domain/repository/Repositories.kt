package com.example.aureom.domain.repository

import com.example.aureom.domain.model.*
import kotlinx.coroutines.flow.StateFlow

interface GameRepository {
    val games: StateFlow<List<Game>>
    val currentlyRunningGame: StateFlow<Game?>
    val quickResumeList: StateFlow<List<QuickResumeGame>>

    fun getGameById(id: String): Game?
    suspend fun launchGame(id: String): Boolean
    suspend fun exitRunningGame()
    suspend fun suspendToQuickResume(id: String)
    suspend fun closeQuickResume(id: String)
    suspend fun installGame(id: String)
    suspend fun uninstallGame(id: String)
    suspend fun toggleFavorite(id: String)
}

interface SocialRepository {
    val friends: StateFlow<List<Friend>>
    val activeParty: StateFlow<Party?>
    val conversations: StateFlow<List<Conversation>>

    suspend fun sendPartyInvite(friendId: String)
    suspend fun joinParty(partyId: String)
    suspend fun leaveParty()
    suspend fun toggleMuteMember(playerId: String)
    suspend fun toggleFriendMute(friendId: String)
    suspend fun sendMessage(friendId: String, text: String)
}

interface AchievementRepository {
    val achievements: StateFlow<List<Achievement>>
    val totalGamerscore: StateFlow<Int>

    suspend fun unlockAchievement(id: String)
}

interface DownloadRepository {
    val downloads: StateFlow<List<DownloadItem>>

    suspend fun pauseDownload(id: String)
    suspend fun resumeDownload(id: String)
    suspend fun cancelDownload(id: String)
    suspend fun startDownload(game: Game)
}

interface StoreRepository {
    val storeProducts: StateFlow<List<StoreProduct>>

    suspend fun purchaseProduct(id: String): Boolean
}

interface SystemRepository {
    val systemStatus: StateFlow<SystemStatus>
    val notifications: StateFlow<List<AureomNotification>>
    val playerProfile: StateFlow<PlayerProfile>

    suspend fun markNotificationRead(id: String)
    suspend fun dismissNotification(id: String)
    suspend fun clearAllNotifications()
    suspend fun runNetworkDiagnostics()
}

interface SettingsRepository {
    val displaySettings: StateFlow<DisplaySettings>
    val audioSettings: StateFlow<AudioSettings>
    val controllerSettings: StateFlow<ControllerSettings>
    val accessibilitySettings: StateFlow<AccessibilitySettings>
    val privacySettings: StateFlow<PrivacySettings>
    val familySettings: StateFlow<FamilySettings>

    suspend fun updateDisplay(settings: DisplaySettings)
    suspend fun updateAudio(settings: AudioSettings)
    suspend fun updateController(settings: ControllerSettings)
    suspend fun updateAccessibility(settings: AccessibilitySettings)
    suspend fun updatePrivacy(settings: PrivacySettings)
    suspend fun updateFamily(settings: FamilySettings)
}
