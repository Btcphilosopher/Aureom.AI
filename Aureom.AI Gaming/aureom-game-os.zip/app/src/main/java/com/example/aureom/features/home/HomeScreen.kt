package com.example.aureom.features.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.components.GameCard
import com.example.aureom.components.HeroBanner
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.core.state.ConsoleRoute
import com.example.aureom.domain.model.Friend
import com.example.aureom.domain.model.Game
import com.example.aureom.domain.model.PresenceStatus

@Composable
fun HomeScreen(
    viewModel: AureomAppViewModel,
    onNavigateToGameDetails: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val games by viewModel.games.collectAsState()
    val quickResumeList by viewModel.quickResumeList.collectAsState()
    val friends by viewModel.friends.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    val featuredGame = games.firstOrNull { it.id == "game_01" } ?: games.firstOrNull()
    val recentlyPlayed = games.filter { it.isInstalled }.take(6)
    val friendsInGame = friends.filter { it.presence == PresenceStatus.IN_GAME }

    LazyColumn(
        modifier = modifier
            .testTag("home_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(AureomSpacing.xl),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        // 1. Primary Hero Game Banner
        if (featuredGame != null) {
            item {
                HeroBanner(
                    game = featuredGame,
                    onPlay = { viewModel.launchGame(featuredGame.id) },
                    onContinue = { viewModel.launchGame(featuredGame.id) },
                    onDetails = { onNavigateToGameDetails(featuredGame.id) }
                )
            }
        }

        // 2. Quick Resume Carousel
        if (quickResumeList.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Quick Resume",
                            tint = AureomColors.AureomGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "QUICK RESUME",
                            color = AureomColors.TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Instant state restore",
                            color = AureomColors.TextTertiary,
                            fontSize = 12.sp
                        )
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        items(quickResumeList, key = { it.gameId }) { qr ->
                            ConsoleFocusable(
                                nodeId = "qr_${qr.gameId}",
                                groupId = "quick_resume",
                                onClick = { viewModel.launchGame(qr.gameId) },
                                shape = RoundedCornerShape(12.dp)
                            ) { isFocused ->
                                Row(
                                    modifier = Modifier
                                        .testTag("qr_card_${qr.gameId}")
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isFocused) AureomColors.SurfaceCardElevated else AureomColors.SurfaceCard
                                        )
                                        .border(1.dp, if (isFocused) AureomColors.AureomGold else AureomColors.BorderSubtle, RoundedCornerShape(12.dp))
                                        .padding(horizontal = AureomSpacing.md, vertical = AureomSpacing.sm),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(AureomColors.AureomGold)
                                    )
                                    Spacer(modifier = Modifier.width(AureomSpacing.sm))
                                    Column {
                                        Text(
                                            text = qr.title,
                                            color = AureomColors.TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "Suspended ${qr.suspendedAt} • ${qr.memoryUsageMb} MB",
                                            color = AureomColors.TextTertiary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Recently Played Games Row
        item {
            Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECENTLY PLAYED",
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Press [A] to launch",
                        color = AureomColors.TextTertiary,
                        fontSize = 12.sp
                    )
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(recentlyPlayed, key = { it.id }) { game ->
                        GameCard(
                            game = game,
                            groupId = "recent_games",
                            onClick = { viewModel.launchGame(game.id) },
                            onContextual = { onNavigateToGameDetails(game.id) }
                        )
                    }
                }
            }
        }

        // 4. Friends In Game
        if (friendsInGame.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = "Friends Playing",
                            tint = AureomColors.AureomCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "FRIENDS PLAYING NOW",
                            color = AureomColors.TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp
                        )
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        items(friendsInGame, key = { it.id }) { friend ->
                            ConsoleFocusable(
                                nodeId = "friend_home_${friend.id}",
                                groupId = "friends_home",
                                onClick = { viewModel.navigateTo(ConsoleRoute.SOCIAL) },
                                shape = RoundedCornerShape(12.dp)
                            ) { isFocused ->
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isFocused) AureomColors.SurfaceCardElevated else AureomColors.SurfaceCard)
                                        .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(12.dp))
                                        .padding(AureomSpacing.sm),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(AureomColors.AureomCyan),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = friend.gamertag.take(1),
                                            color = Color.Black,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(AureomSpacing.sm))
                                    Column {
                                        Text(
                                            text = friend.gamertag,
                                            color = AureomColors.TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "Playing ${friend.currentGameTitle}",
                                            color = AureomColors.AureomCyan,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. Installed Games Row
        item {
            Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                Text(
                    text = "MY INSTALLED TITLES",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(games.filter { it.isInstalled }, key = { it.id }) { game ->
                        GameCard(
                            game = game,
                            groupId = "installed_games",
                            onClick = { onNavigateToGameDetails(game.id) }
                        )
                    }
                }
            }
        }
    }
}
