package com.example.aureom.components

import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.aureom.controller.FocusNode
import com.example.aureom.controller.LocalFocusEngine
import com.example.aureom.core.design.AureomColors
import com.example.aureom.graphics.AureomMotion

@Composable
fun ConsoleFocusable(
    nodeId: String,
    groupId: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    scaleOnFocus: Float = 1.04f,
    focusBorderColor: Color = AureomColors.FocusBorder,
    borderWidth: Dp = 2.5.dp,
    onContextual: () -> Unit = {},
    content: @Composable (isFocused: Boolean) -> Unit
) {
    val focusEngine = LocalFocusEngine.current
    val isFocused = focusEngine.currentFocusedId == nodeId

    DisposableEffect(nodeId, groupId) {
        val node = FocusNode(
            id = nodeId,
            groupId = groupId,
            onConfirm = onClick,
            onContextual = onContextual
        )
        focusEngine.registerNode(node)
        onDispose {
            focusEngine.unregisterNode(nodeId)
        }
    }

    val animatedScale by animateFloatAsState(
        targetValue = if (isFocused) scaleOnFocus else 1.0f,
        animationSpec = AureomMotion.FocusSpring,
        label = "focusScale"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isFocused) focusBorderColor else Color.Transparent,
        animationSpec = tween(durationMillis = 220),
        label = "focusBorder"
    )

    val shadowElevation by animateFloatAsState(
        targetValue = if (isFocused) 16f else 2f,
        label = "focusElevation"
    )

    Box(
        modifier = modifier
            .testTag("focusable_$nodeId")
            .scale(animatedScale)
            .shadow(
                elevation = shadowElevation.dp,
                shape = shape,
                ambientColor = if (isFocused) AureomColors.FocusGlow else Color.Black.copy(alpha = 0.4f),
                spotColor = if (isFocused) AureomColors.AureomGold else Color.Black
            )
            .border(
                border = BorderStroke(borderWidth, borderColor),
                shape = shape
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = AureomColors.AureomGoldBright),
                onClick = {
                    focusEngine.requestFocus(nodeId)
                    onClick()
                }
            )
    ) {
        content(isFocused)
    }
}
