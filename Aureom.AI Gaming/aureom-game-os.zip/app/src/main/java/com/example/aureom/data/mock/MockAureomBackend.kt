package com.example.aureom.data.mock

import com.example.aureom.core.logging.AureomLogger
import com.example.aureom.core.telemetry.UiTelemetry
import com.example.aureom.domain.model.*
import com.example.aureom.domain.repository.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MockAureomBackend(private val scope: CoroutineScope) :
    GameRepository,
    SocialRepository,
    AchievementRepository,
    DownloadRepository,
    StoreRepository,
    SystemRepository,
    SettingsRepository {

    // --- StateFlows for Games ---
    private val _games = MutableStateFlow<List<Game>>(emptyList())
    override val games: StateFlow<List<Game>> = _games.asStateFlow()

    private val _currentlyRunningGame = MutableStateFlow<Game?>(null)
    override val currentlyRunningGame: StateFlow<Game?> = _currentlyRunningGame.asStateFlow()

    private val _quickResumeList = MutableStateFlow<List<QuickResumeGame>>(emptyList())
    override val quickResumeList: StateFlow<List<QuickResumeGame>> = _quickResumeList.asStateFlow()

    // --- StateFlows for Social ---
    private val _friends = MutableStateFlow<List<Friend>>(emptyList())
    override val friends: StateFlow<List<Friend>> = _friends.asStateFlow()

    private val _activeParty = MutableStateFlow<Party?>(null)
    override val activeParty: StateFlow<Party?> = _activeParty.asStateFlow()

    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    override val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    // --- StateFlows for Achievements ---
    private val _achievements = MutableStateFlow<List<Achievement>>(emptyList())
    override val achievements: StateFlow<List<Achievement>> = _achievements.asStateFlow()

    private val _totalGamerscore = MutableStateFlow(14250)
    override val totalGamerscore: StateFlow<Int> = _totalGamerscore.asStateFlow()

    // --- StateFlows for Downloads ---
    private val _downloads = MutableStateFlow<List<DownloadItem>>(emptyList())
    override val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    // --- StateFlows for Store ---
    private val _storeProducts = MutableStateFlow<List<StoreProduct>>(emptyList())
    override val storeProducts: StateFlow<List<StoreProduct>> = _storeProducts.asStateFlow()

    // --- StateFlows for System & Profile ---
    private val _systemStatus = MutableStateFlow(SystemStatus())
    override val systemStatus: StateFlow<SystemStatus> = _systemStatus.asStateFlow()

    private val _notifications = MutableStateFlow<List<AureomNotification>>(emptyList())
    override val notifications: StateFlow<List<AureomNotification>> = _notifications.asStateFlow()

    private val _playerProfile = MutableStateFlow(
        PlayerProfile(
            id = "player_01",
            gamertag = "AUREOM_COMMANDER",
            bio = "Competitive sim racer & sci-fi action connoisseur. Aureom OS Founder.",
            gamerscore = 14250,
            level = 42,
            tenureYears = 6,
            completedGamesCount = 18,
            subscriptionTier = "AUREOM PASS ULTIMATE",
            subscriptionExpires = "Nov 2027",
            reputation = "EXCELLENT"
        )
    )
    override val playerProfile: StateFlow<PlayerProfile> = _playerProfile.asStateFlow()

    // --- StateFlows for Settings ---
    private val _displaySettings = MutableStateFlow(DisplaySettings())
    override val displaySettings: StateFlow<DisplaySettings> = _displaySettings.asStateFlow()

    private val _audioSettings = MutableStateFlow(AudioSettings())
    override val audioSettings: StateFlow<AudioSettings> = _audioSettings.asStateFlow()

    private val _controllerSettings = MutableStateFlow(ControllerSettings())
    override val controllerSettings: StateFlow<ControllerSettings> = _controllerSettings.asStateFlow()

    private val _accessibilitySettings = MutableStateFlow(AccessibilitySettings())
    override val accessibilitySettings: StateFlow<AccessibilitySettings> = _accessibilitySettings.asStateFlow()

    private val _privacySettings = MutableStateFlow(PrivacySettings())
    override val privacySettings: StateFlow<PrivacySettings> = _privacySettings.asStateFlow()

    private val _familySettings = MutableStateFlow(FamilySettings())
    override val familySettings: StateFlow<FamilySettings> = _familySettings.asStateFlow()

    init {
        seedInitialData()
        startDownloadSimulation()
    }

    private fun seedInitialData() {
        val seededGames = listOf(
            Game(
                id = "game_01",
                title = "AUREOM RACING",
                tagline = "Apex Velocity Grand Prix",
                description = "Experience the next era of high-speed hypercar simulation. Featuring dynamic volumetric weather, precision tire thermodynamics, 120 FPS ray-traced reflections, and over 400 meticulously modeled vehicles.",
                developer = "Aureom Speedworks",
                publisher = "Aureom Studios",
                releaseYear = 2026,
                genre = "Racing / Simulation",
                sizeGb = 94.2,
                rating = 4.9,
                ageRating = "PEGI 3",
                accentColorHex = "#F5B700",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.OWNED,
                playtimeMinutes = 1840,
                totalAchievements = 45,
                unlockedAchievements = 28,
                isInstalled = true,
                isFavorite = true,
                dlcList = listOf(
                    GameDLC("dlc_01", "Monaco GP Revival Track Pack", "$14.99", true),
                    GameDLC("dlc_02", "Hypercar Season Pass Vol. 2", "$29.99", false)
                )
            ),
            Game(
                id = "game_02",
                title = "NORTHLINE",
                tagline = "Frostbitten Wilderness Survival",
                description = "A deep atmospheric survival journey through the unforgiving Arctic permafrost. Navigate blinding blizzards, construct thermal shelters, and uncover the mystery of an abandoned research facility.",
                developer = "Cold Iron Interactive",
                publisher = "Subzero Games",
                releaseYear = 2025,
                genre = "Survival / Adventure",
                sizeGb = 48.6,
                rating = 4.8,
                ageRating = "PEGI 16",
                accentColorHex = "#00E5FF",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.OWNED,
                playtimeMinutes = 960,
                totalAchievements = 35,
                unlockedAchievements = 19,
                isInstalled = true,
                isFavorite = true
            ),
            Game(
                id = "game_03",
                title = "METROPOLIS 2049",
                tagline = "Cybernetic Neo-Noir Thriller",
                description = "Delve into the rain-slicked neon alleys of Megacity 4. As an augmented detective, hack security grids, interrogate corrupt synth syndicates, and shape the destiny of humanity's last refuge.",
                developer = "Synapse Works",
                publisher = "Aureom Studios",
                releaseYear = 2026,
                genre = "Action RPG",
                sizeGb = 82.1,
                rating = 4.9,
                ageRating = "PEGI 18",
                accentColorHex = "#FF007F",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.OWNED,
                playtimeMinutes = 2400,
                totalAchievements = 50,
                unlockedAchievements = 42,
                isInstalled = true,
                isFavorite = true
            ),
            Game(
                id = "game_04",
                title = "THE LAST FRONTIER",
                tagline = "Deep Space Colonization Odyssey",
                description = "Command the vanguard expedition to the Kepler nebula. Build planetary bases, research alien ecosystems, and defend your colony against cosmic phenomena in real-time procedural orbits.",
                developer = "Starlight Engine",
                publisher = "Cosmic Interactive",
                releaseYear = 2025,
                genre = "Strategy / Sci-Fi",
                sizeGb = 65.4,
                rating = 4.7,
                ageRating = "PEGI 12",
                accentColorHex = "#7B1FA2",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.SUBSCRIPTION_PASS,
                playtimeMinutes = 720,
                totalAchievements = 30,
                unlockedAchievements = 12,
                isInstalled = true
            ),
            Game(
                id = "game_05",
                title = "CIRCUIT ZERO",
                tagline = "Fast-Paced Cyberpunk Arena Combat",
                description = "High-octane arena shooter built for twitch reflexes and surgical precision. Master wall-running, railguns, and tactical electromagnetic shields in 120Hz competitive multiplayer.",
                developer = "Zero Point Labs",
                publisher = "Aureom Studios",
                releaseYear = 2026,
                genre = "Competitive FPS",
                sizeGb = 42.0,
                rating = 4.6,
                ageRating = "PEGI 16",
                accentColorHex = "#00FF9D",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.FREE_TO_PLAY,
                playtimeMinutes = 3100,
                totalAchievements = 40,
                unlockedAchievements = 31,
                isInstalled = true
            ),
            Game(
                id = "game_06",
                title = "KINGDOMS OF ASH",
                tagline = "Dark Mythic Souls Fantasy",
                description = "Awaken in a shattered realm of fallen gods and petrified dragons. Master lethal parry timings, dark pyromancy, and ancient relic weapons in an interconnected gothic world.",
                developer = "Grimspire Games",
                publisher = "Abyssal Arts",
                releaseYear = 2025,
                genre = "Action RPG / Souls-like",
                sizeGb = 78.5,
                rating = 4.9,
                ageRating = "PEGI 18",
                accentColorHex = "#FF5722",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.OWNED,
                playtimeMinutes = 4120,
                totalAchievements = 42,
                unlockedAchievements = 38,
                isInstalled = true,
                isFavorite = true
            ),
            Game(
                id = "game_07",
                title = "NEBULA DRIFT",
                tagline = "Zero-G Anti-Grav Racing",
                description = "Gravity-defying supersonic speed across asteroid belts, quantum rings, and Dyson spheres. Pulse jet engines and magnetic trajectory drift at mach 4.",
                developer = "Vector Velocity",
                publisher = "Quantum Media",
                releaseYear = 2026,
                genre = "Anti-Grav Racing",
                sizeGb = 38.0,
                rating = 4.7,
                accentColorHex = "#00D2FF",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.SUBSCRIPTION_PASS,
                isInstalled = true
            ),
            Game(
                id = "game_08",
                title = "VALKYRIE CHRONICLES",
                tagline = "Norse Tactical Squad Combat",
                description = "Lead an elite band of Norse shield-maidens against corrupted mythic titans in stunning cinematic tactical skirmishes.",
                developer = "Runestone Games",
                publisher = "Nordic Digital",
                releaseYear = 2024,
                genre = "Tactical RPG",
                sizeGb = 52.0,
                rating = 4.5,
                accentColorHex = "#4A90E2",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.OWNED,
                isInstalled = true
            ),
            Game(
                id = "game_09",
                title = "VOID RUNNER",
                tagline = "Infinite Hyperspace Parkour",
                description = "Dash, grapple, and phase through collapsing dimensional rifts to an electronic synthwave soundtrack.",
                developer = "Pulse Wave",
                publisher = "Indie Arcade",
                releaseYear = 2026,
                genre = "Platformer / Arcade",
                sizeGb = 14.2,
                rating = 4.8,
                accentColorHex = "#E040FB",
                playState = GamePlayState.READY_TO_PLAY,
                entitlement = EntitlementType.OWNED,
                isInstalled = true
            ),
            Game(
                id = "game_10",
                title = "TITAN CORE",
                tagline = "Colossal Mech Warfare",
                description = "Pilot 60-foot bipedal combat engines equipped with particle cannons and plasma blades across destructible warzones.",
                developer = "Ironclad Studios",
                publisher = "Aureom Studios",
                releaseYear = 2025,
                genre = "Action / Mech Sim",
                sizeGb = 89.0,
                rating = 4.7,
                accentColorHex = "#FFB300",
                playState = GamePlayState.DOWNLOADING,
                currentDownloadPercent = 0.64f,
                downloadSpeedMbps = 112.4f,
                entitlement = EntitlementType.SUBSCRIPTION_PASS,
                isInstalled = false
            ),
            Game(
                id = "game_11",
                title = "CHRONO PROTOCOL",
                tagline = "Temporal Paradox Heist",
                description = "Rewind, freeze, and fast-forward time to infiltrate hyper-secure vault networks in an alternate 1980s retro-futuristic Berlin.",
                developer = "Temporal Mind",
                publisher = "Paradox Works",
                releaseYear = 2026,
                genre = "Stealth / Puzzle",
                sizeGb = 34.0,
                rating = 4.6,
                accentColorHex = "#26C6DA",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.OWNED,
                isInstalled = false
            ),
            Game(
                id = "game_12",
                title = "ECHOES OF AETHER",
                tagline = "Floating Island Action RPG",
                description = "Glide between celestial skylands on customized gliders and awaken guardian spirits in a vibrant watercolor world.",
                developer = "Skylight Art",
                publisher = "Aetherial Media",
                releaseYear = 2025,
                genre = "Action RPG",
                sizeGb = 56.7,
                rating = 4.9,
                accentColorHex = "#66BB6A",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.SUBSCRIPTION_PASS,
                isInstalled = false
            ),
            Game(
                id = "game_13",
                title = "SOLARIS VECTOR",
                tagline = "Orbital Fighter Squadron",
                description = "Engage in planetary defense dogfights in low orbit with atmospheric entry physics and capital ship bombing runs.",
                developer = "Aero Dynamics",
                publisher = "Spaceflight Interactive",
                releaseYear = 2025,
                genre = "Flight Simulator",
                sizeGb = 68.3,
                rating = 4.5,
                accentColorHex = "#FF7043",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.OWNED,
                isInstalled = false
            ),
            Game(
                id = "game_14",
                title = "SHADOW SYNDICATE",
                tagline = "Underworld Espionage Strategy",
                description = "Manage a global rogue operative network. Infiltrate megacorporations, conduct covert operations, and control black markets.",
                developer = "Blackout Interactive",
                publisher = "Sub Rosa Games",
                releaseYear = 2024,
                genre = "Strategy / Management",
                sizeGb = 28.5,
                rating = 4.4,
                accentColorHex = "#78909C",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.OWNED,
                isInstalled = false
            ),
            Game(
                id = "game_15",
                title = "DRIFT KINGS 2",
                tagline = "Midnight Touge Underground",
                description = "Downhill mountain pass drifting at 3 AM. Custom turbos, deep suspension telemetry tuning, and eurobeat synth tracks.",
                developer = "Nightfall Works",
                publisher = "Tuning Media",
                releaseYear = 2026,
                genre = "Street Racing",
                sizeGb = 49.2,
                rating = 4.7,
                accentColorHex = "#AB47BC",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.OWNED,
                isInstalled = false
            ),
            Game(
                id = "game_16",
                title = "NEON BLADE",
                tagline = "Ultra-Responsive Sword Action",
                description = "Slash through waves of augmented cyber-ninjas with one-hit-kill mechanics and bullet-deflection katana combat.",
                developer = "Katana Core",
                publisher = "Slash Interactive",
                releaseYear = 2025,
                genre = "Hack and Slash",
                sizeGb = 22.4,
                rating = 4.8,
                accentColorHex = "#FF1744",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.SUBSCRIPTION_PASS,
                isInstalled = false
            ),
            Game(
                id = "game_17",
                title = "ABYSS HORIZON",
                tagline = "Deep Oceanic Submersible Horror",
                description = "Explore the Mariana Trench in a pressurized exploration submarine. Manage oxygen, power grids, and survive benthic horrors.",
                developer = "Benthic Studio",
                publisher = "Deep Dark",
                releaseYear = 2026,
                genre = "Survival Horror",
                sizeGb = 44.0,
                rating = 4.6,
                accentColorHex = "#00838F",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.OWNED,
                isInstalled = false
            ),
            Game(
                id = "game_18",
                title = "BIOHACKER 2088",
                tagline = "Genetic Engineering Sandbox",
                description = "Synthesize custom bioweapons, chimeric companions, and mutagenic serums in a subterranean genetic science lab.",
                developer = "Helix Digital",
                publisher = "Bio Systems",
                releaseYear = 2025,
                genre = "Simulation / Sci-Fi",
                sizeGb = 31.8,
                rating = 4.5,
                accentColorHex = "#9CCC65",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.OWNED,
                isInstalled = false
            ),
            Game(
                id = "game_19",
                title = "SKYBOUND WINGS",
                tagline = "Soaring Aerial Combat",
                description = "Tame majestic sky wyverns, equip enchanted lances, and battle storm titans across hurricane cloudscapes.",
                developer = "Winged Interactive",
                publisher = "Zephyr Entertainment",
                releaseYear = 2024,
                genre = "Fantasy Action",
                sizeGb = 50.1,
                rating = 4.3,
                accentColorHex = "#29B6F6",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.FREE_TO_PLAY,
                isInstalled = false
            ),
            Game(
                id = "game_20",
                title = "RUNE WARRIOR",
                tagline = "Ancient Rune Alchemy Brawler",
                description = "Combine elemental runes into over 100 spell combos to battle hordes of primordial monoliths.",
                developer = "Alchemical Games",
                publisher = "Rune Digital",
                releaseYear = 2026,
                genre = "Action Roguelike",
                sizeGb = 18.0,
                rating = 4.7,
                accentColorHex = "#FFCA28",
                playState = GamePlayState.NOT_INSTALLED,
                entitlement = EntitlementType.SUBSCRIPTION_PASS,
                isInstalled = false
            )
        )
        _games.value = seededGames

        _quickResumeList.value = listOf(
            QuickResumeGame("game_01", "AUREOM RACING", "Racing", 4810, "12m ago"),
            QuickResumeGame("game_02", "NORTHLINE", "Survival", 3420, "2h ago"),
            QuickResumeGame("game_03", "METROPOLIS 2049", "Action RPG", 5600, "Yesterday")
        )

        val seededFriends = listOf(
            Friend("f_01", "CyberValkyrie", "Elena Rostova", presence = PresenceStatus.IN_GAME, currentGameTitle = "AUREOM RACING", gamerscore = 18920, isPartyJoinable = true),
            Friend("f_02", "GhostBlade99", "Kenji Sato", presence = PresenceStatus.ONLINE, currentGameTitle = null, gamerscore = 12400, isPartyJoinable = false),
            Friend("f_03", "SolarKnight", "Marcus Vance", presence = PresenceStatus.IN_GAME, currentGameTitle = "CIRCUIT ZERO", gamerscore = 24150, isPartyJoinable = true),
            Friend("f_04", "PixelSamurai", "Hiroshi Tanaka", presence = PresenceStatus.IN_GAME, currentGameTitle = "KINGDOMS OF ASH", gamerscore = 15300, isPartyJoinable = false),
            Friend("f_05", "NovaStrike", "Sarah Connor", presence = PresenceStatus.ONLINE, currentGameTitle = null, gamerscore = 8900),
            Friend("f_06", "NeonPulse", "Zoe Chen", presence = PresenceStatus.BUSY, currentGameTitle = "METROPOLIS 2049", gamerscore = 31200),
            Friend("f_07", "QuantumDrifter", "Leo Thorne", presence = PresenceStatus.OFFLINE, lastOnline = "3h ago", gamerscore = 9400),
            Friend("f_08", "ShadowRanger", "Devon Lee", presence = PresenceStatus.IN_GAME, currentGameTitle = "NORTHLINE", gamerscore = 14200),
            Friend("f_09", "ApexGamer", "Jack Sterling", presence = PresenceStatus.OFFLINE, lastOnline = "1d ago", gamerscore = 21000),
            Friend("f_10", "AuraMage", "Lyra Silvers", presence = PresenceStatus.ONLINE, gamerscore = 11750)
        )
        _friends.value = seededFriends

        _activeParty.value = Party(
            id = "party_01",
            title = "Aureom Speed Squad",
            leaderGamertag = "AUREOM_COMMANDER",
            members = listOf(
                PartyMember("player_01", "AUREOM_COMMANDER", isLeader = true, isTalking = false),
                PartyMember("f_01", "CyberValkyrie", isLeader = false, isTalking = true),
                PartyMember("f_03", "SolarKnight", isLeader = false, isTalking = false)
            ),
            gameTitle = "AUREOM RACING"
        )

        _conversations.value = listOf(
            Conversation(
                friendId = "f_01",
                friendGamertag = "CyberValkyrie",
                unreadCount = 1,
                lastMessage = "Ready for the 120 FPS Nürburgring time trial lobby?",
                messages = listOf(
                    ChatMessage("m1", "CyberValkyrie", "Hey! Loved your lap time on Circuit Zero.", "14:20", true),
                    ChatMessage("m2", "AUREOM_COMMANDER", "Thanks! Tweaked the suspension dampers yesterday.", "14:22", false),
                    ChatMessage("m3", "CyberValkyrie", "Ready for the 120 FPS Nürburgring time trial lobby?", "14:25", true)
                )
            ),
            Conversation(
                friendId = "f_03",
                friendGamertag = "SolarKnight",
                unreadCount = 0,
                lastMessage = "Party invite sent for Circuit Zero tournament.",
                messages = listOf(
                    ChatMessage("m4", "SolarKnight", "Party invite sent for Circuit Zero tournament.", "Yesterday", true)
                )
            )
        )

        val seededAchievements = listOf(
            Achievement("ach_01", "game_01", "AUREOM RACING", "FIRST FLIGHT", "Complete your first clean lap at over 300 km/h.", 50, true, System.currentTimeMillis() - 86400000L, 100, isRare = false),
            Achievement("ach_02", "game_01", "AUREOM RACING", "APEX PREDATOR", "Win 10 consecutive multiplayer ranked sprint races.", 100, true, System.currentTimeMillis() - 43200000L, 100, isRare = true, rarityPercent = 4.2f),
            Achievement("ach_03", "game_01", "AUREOM RACING", "RAIN MASTER", "Win in dynamic torrential rain with zero assists.", 80, false, null, 75, isRare = true, rarityPercent = 8.1f),
            Achievement("ach_04", "game_02", "NORTHLINE", "WARM EMBRACE", "Survive a category 5 blizzard without freezing.", 60, true, System.currentTimeMillis() - 172800000L, 100, isRare = false),
            Achievement("ach_05", "game_02", "NORTHLINE", "ICEBREAKER", "Explore the deep reactor shaft in the Arctic facility.", 75, false, null, 40, isRare = false),
            Achievement("ach_06", "game_03", "METROPOLIS 2049", "NEURAL OVERDRIVE", "Equip tier-5 quantum ocular cyberware.", 90, true, System.currentTimeMillis() - 259200000L, 100, isRare = true, rarityPercent = 9.8f),
            Achievement("ach_07", "game_03", "METROPOLIS 2049", "SYNTH SAVIOR", "Negotiate peace between human factions and the synths.", 150, false, null, 60, isRare = true, rarityPercent = 3.5f),
            Achievement("ach_08", "game_05", "CIRCUIT ZERO", "PERFECT RAIL", "Hit 5 consecutive enemies with railgun headshots.", 50, true, System.currentTimeMillis() - 86400000L, 100, isRare = true, rarityPercent = 6.4f),
            Achievement("ach_09", "game_06", "KINGDOMS OF ASH", "GODSLAYER", "Defeat the Dragon Emperor without taking damage.", 200, false, null, 90, isRare = true, rarityPercent = 1.8f),
            Achievement("ach_10", "game_04", "THE LAST FRONTIER", "NEW DAWN", "Establish the first self-sustaining biosphere colony.", 100, true, System.currentTimeMillis() - 500000000L, 100, isRare = false)
        )
        _achievements.value = seededAchievements

        _downloads.value = listOf(
            DownloadItem("dl_01", "game_10", "TITAN CORE", "v1.2.0", (89.0 * 1024 * 1024 * 1024 * 0.64).toLong(), (89.0 * 1024 * 1024 * 1024).toLong(), 112.4f, 290L, DownloadStatus.DOWNLOADING),
            DownloadItem("dl_02", "game_11", "CHRONO PROTOCOL (Update)", "v1.0.4", (4.2 * 1024 * 1024 * 1024 * 0.20).toLong(), (4.2 * 1024 * 1024 * 1024).toLong(), 85.0f, 410L, DownloadStatus.QUEUED),
            DownloadItem("dl_03", "game_01", "AUREOM RACING: 4K Texture Pack", "v2.1", (18.5 * 1024 * 1024 * 1024).toLong(), (18.5 * 1024 * 1024 * 1024).toLong(), 0f, 0L, DownloadStatus.COMPLETED),
            DownloadItem("dl_04", "game_07", "NEBULA DRIFT: Sound Pack", "v1.0", (2.1 * 1024 * 1024 * 1024).toLong(), (2.1 * 1024 * 1024 * 1024).toLong(), 0f, 0L, DownloadStatus.COMPLETED),
            DownloadItem("dl_05", "game_03", "METROPOLIS 2049: Ray Tracing Patch", "v1.1", (12.0 * 1024 * 1024 * 1024).toLong(), (12.0 * 1024 * 1024 * 1024).toLong(), 0f, 0L, DownloadStatus.COMPLETED)
        )

        _storeProducts.value = listOf(
            StoreProduct("sp_01", "AUREOM RACING: DELUXE EDITION", "Includes 40 Car Pass & Monaco GP", "Featured", 79.99, 20, 4.9, "Aureom Studios", 94.2, badge = "20% OFF", isOwned = true),
            StoreProduct("sp_02", "METROPOLIS 2049", "The Cybernetic Masterpiece", "AAA", 69.99, 0, 4.9, "Aureom Studios", 82.1, badge = "TOP SELLER", isOwned = true),
            StoreProduct("sp_03", "NORTHLINE", "Atmospheric Arctic Survival", "Indie", 39.99, 15, 4.8, "Subzero Games", 48.6, badge = "EDITOR'S CHOICE", isOwned = true),
            StoreProduct("sp_04", "KINGDOMS OF ASH", "Gothic Souls Action", "AAA", 59.99, 0, 4.9, "Abyssal Arts", 78.5, isOwned = true),
            StoreProduct("sp_05", "TITAN CORE: MECH COMBAT", "Colossal Mech Warfare", "New Releases", 59.99, 10, 4.7, "Aureom Studios", 89.0, badge = "NEW"),
            StoreProduct("sp_06", "AUREOM PASS ULTIMATE", "Over 200 High-End Games, Day One Access", "Subscriptions", 16.99, 0, 5.0, "Aureom Gaming", 0.0, badge = "SUBSCRIPTION", isIncludedInPass = true),
            StoreProduct("sp_07", "CIRCUIT ZERO: FOUNDER PACK", "Exclusive Neon Railgun Skins + 2000 Aureom Credits", "Free to Play", 19.99, 0, 4.6, "Zero Point Labs", 42.0),
            StoreProduct("sp_08", "ECHOES OF AETHER", "Soar above celestial skylands", "Deals", 49.99, 30, 4.9, "Aetherial Media", 56.7, badge = "30% OFF"),
            StoreProduct("sp_09", "NEBULA DRIFT", "Zero-G Anti-Grav Racing", "AAA", 49.99, 0, 4.7, "Quantum Media", 38.0),
            StoreProduct("sp_10", "CHRONO PROTOCOL", "Temporal Heist Espionage", "Indie", 29.99, 0, 4.6, "Paradox Works", 34.0)
        )

        _notifications.value = listOf(
            AureomNotification("notif_01", "Achievement Unlocked!", "FIRST FLIGHT (50G) in AUREOM RACING", "5m ago", NotificationType.ACHIEVEMENT, points = 50),
            AureomNotification("notif_02", "Party Invitation", "CyberValkyrie invited you to Aureom Speed Squad", "12m ago", NotificationType.PARTY_INVITE, actionLabel = "Join Party"),
            AureomNotification("notif_03", "Download Completed", "AUREOM RACING: 4K Texture Pack is ready to play", "45m ago", NotificationType.DOWNLOAD_COMPLETE),
            AureomNotification("notif_04", "System Update", "Aureom OS 2026.4.1 performance firmware applied", "2h ago", NotificationType.SYSTEM),
            AureomNotification("notif_05", "Aureom Pass Deal", "Metropolis 2049 DLC available with 20% Pass discount", "1d ago", NotificationType.STORE_PROMOTION)
        )
    }

    private fun startDownloadSimulation() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(1500)
                val current = _downloads.value
                val downloading = current.firstOrNull { it.status == DownloadStatus.DOWNLOADING }
                if (downloading != null) {
                    val increment = (downloading.speedMbps * 1024 * 1024 / 8 * 1.5).toLong()
                    val newDownloaded = (downloading.downloadedBytes + increment).coerceAtMost(downloading.totalBytes)
                    val newEta = if (downloading.speedMbps > 0) {
                        ((downloading.totalBytes - newDownloaded) / (downloading.speedMbps * 1024 * 1024 / 8)).toLong()
                    } else 0L

                    val isDone = newDownloaded >= downloading.totalBytes
                    val updated = current.map { item ->
                        if (item.id == downloading.id) {
                            if (isDone) {
                                item.copy(
                                    downloadedBytes = item.totalBytes,
                                    status = DownloadStatus.COMPLETED,
                                    etaSeconds = 0
                                )
                            } else {
                                item.copy(downloadedBytes = newDownloaded, etaSeconds = newEta)
                            }
                        } else item
                    }
                    _downloads.value = updated

                    if (isDone) {
                        // Mark game installed
                        val updatedGames = _games.value.map { g ->
                            if (g.id == downloading.gameId) g.copy(isInstalled = true, playState = GamePlayState.READY_TO_PLAY) else g
                        }
                        _games.value = updatedGames

                        // Add notification
                        val newNotif = AureomNotification(
                            id = "notif_${System.currentTimeMillis()}",
                            title = "Download Complete",
                            message = "${downloading.title} is now installed and ready to play.",
                            timestamp = "Just now",
                            type = NotificationType.DOWNLOAD_COMPLETE
                        )
                        _notifications.value = listOf(newNotif) + _notifications.value
                    }
                }
            }
        }
    }

    // --- Game Repository Implementations ---
    override fun getGameById(id: String): Game? = _games.value.firstOrNull { it.id == id }

    override suspend fun launchGame(id: String): Boolean {
        val game = getGameById(id) ?: return false
        UiTelemetry.gameLaunched(id)
        AureomLogger.info("MockAureomBackend", "Launching game: ${game.title}")
        _currentlyRunningGame.value = game
        // Update recently played
        _games.value = _games.value.map {
            if (it.id == id) it.copy(lastPlayedTimestamp = System.currentTimeMillis()) else it
        }
        return true
    }

    override suspend fun exitRunningGame() {
        val running = _currentlyRunningGame.value
        if (running != null) {
            AureomLogger.info("MockAureomBackend", "Exited game: ${running.title}")
            _currentlyRunningGame.value = null
        }
    }

    override suspend fun suspendToQuickResume(id: String) {
        val game = getGameById(id) ?: return
        val currentQr = _quickResumeList.value.filter { it.gameId != id }
        val newSlot = QuickResumeGame(
            gameId = game.id,
            title = game.title,
            genre = game.genre,
            memoryUsageMb = 4500,
            suspendedAt = "Just now"
        )
        _quickResumeList.value = listOf(newSlot) + currentQr.take(2)
        _currentlyRunningGame.value = null
        AureomLogger.info("MockAureomBackend", "Suspended ${game.title} to Quick Resume")
    }

    override suspend fun closeQuickResume(id: String) {
        _quickResumeList.value = _quickResumeList.value.filter { it.gameId != id }
    }

    override suspend fun installGame(id: String) {
        val game = getGameById(id) ?: return
        startDownload(game)
    }

    override suspend fun uninstallGame(id: String) {
        _games.value = _games.value.map {
            if (it.id == id) it.copy(isInstalled = false, playState = GamePlayState.NOT_INSTALLED) else it
        }
    }

    override suspend fun toggleFavorite(id: String) {
        _games.value = _games.value.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
    }

    // --- Social Repository Implementations ---
    override suspend fun sendPartyInvite(friendId: String) {
        val friend = _friends.value.firstOrNull { it.id == friendId } ?: return
        UiTelemetry.friendAction(friendId, "send_party_invite")
        val notif = AureomNotification(
            id = "notif_${System.currentTimeMillis()}",
            title = "Invite Sent",
            message = "Party invitation dispatched to ${friend.gamertag}",
            timestamp = "Just now",
            type = NotificationType.PARTY_INVITE
        )
        _notifications.value = listOf(notif) + _notifications.value
    }

    override suspend fun joinParty(partyId: String) {
        _activeParty.value = Party(
            id = partyId,
            title = "Aureom Speed Squad",
            leaderGamertag = "CyberValkyrie",
            members = listOf(
                PartyMember("f_01", "CyberValkyrie", isLeader = true, isTalking = true),
                PartyMember("player_01", "AUREOM_COMMANDER", isLeader = false, isTalking = false)
            ),
            gameTitle = "AUREOM RACING"
        )
    }

    override suspend fun leaveParty() {
        _activeParty.value = null
    }

    override suspend fun toggleMuteMember(playerId: String) {
        val party = _activeParty.value ?: return
        val updatedMembers = party.members.map {
            if (it.playerId == playerId) it.copy(isMuted = !it.isMuted) else it
        }
        _activeParty.value = party.copy(members = updatedMembers)
    }

    override suspend fun toggleFriendMute(friendId: String) {
        _friends.value = _friends.value.map {
            if (it.id == friendId) it.copy(isMuted = !it.isMuted) else it
        }
    }

    override suspend fun sendMessage(friendId: String, text: String) {
        val target = _friends.value.firstOrNull { it.id == friendId } ?: return
        val existing = _conversations.value.firstOrNull { it.friendId == friendId }
        val newMsg = ChatMessage("msg_${System.currentTimeMillis()}", "AUREOM_COMMANDER", text, "Just now", false)
        val updatedConv = if (existing != null) {
            existing.copy(
                lastMessage = text,
                messages = existing.messages + newMsg
            )
        } else {
            Conversation(friendId, target.gamertag, 0, text, listOf(newMsg))
        }
        _conversations.value = listOf(updatedConv) + _conversations.value.filter { it.friendId != friendId }
    }

    // --- Achievement Repository Implementations ---
    override suspend fun unlockAchievement(id: String) {
        val ach = _achievements.value.firstOrNull { it.id == id } ?: return
        if (ach.isUnlocked) return

        _achievements.value = _achievements.value.map {
            if (it.id == id) it.copy(isUnlocked = true, unlockTimestamp = System.currentTimeMillis(), progressPercent = 100) else it
        }
        _totalGamerscore.value += ach.gamerscore
        _playerProfile.value = _playerProfile.value.copy(gamerscore = _totalGamerscore.value)

        val notif = AureomNotification(
            id = "notif_${System.currentTimeMillis()}",
            title = "Achievement Unlocked!",
            message = "${ach.title} (${ach.gamerscore}G) in ${ach.gameTitle}",
            timestamp = "Just now",
            type = NotificationType.ACHIEVEMENT,
            points = ach.gamerscore
        )
        _notifications.value = listOf(notif) + _notifications.value
        UiTelemetry.achievementView(id)
    }

    // --- Download Repository Implementations ---
    override suspend fun pauseDownload(id: String) {
        _downloads.value = _downloads.value.map {
            if (it.id == id) it.copy(status = DownloadStatus.PAUSED, speedMbps = 0f) else it
        }
    }

    override suspend fun resumeDownload(id: String) {
        _downloads.value = _downloads.value.map {
            if (it.id == id) it.copy(status = DownloadStatus.DOWNLOADING, speedMbps = 95.0f) else it
        }
    }

    override suspend fun cancelDownload(id: String) {
        _downloads.value = _downloads.value.filter { it.id != id }
    }

    override suspend fun startDownload(game: Game) {
        val existing = _downloads.value.firstOrNull { it.gameId == game.id }
        if (existing != null) {
            resumeDownload(existing.id)
            return
        }
        val totalBytes = (game.sizeGb * 1024 * 1024 * 1024).toLong()
        val newDl = DownloadItem(
            id = "dl_${System.currentTimeMillis()}",
            gameId = game.id,
            title = game.title,
            downloadedBytes = 0L,
            totalBytes = totalBytes,
            speedMbps = 115.0f,
            etaSeconds = (totalBytes / (115 * 1024 * 1024 / 8)),
            status = DownloadStatus.DOWNLOADING
        )
        _downloads.value = listOf(newDl) + _downloads.value
        _games.value = _games.value.map {
            if (it.id == game.id) it.copy(playState = GamePlayState.DOWNLOADING) else it
        }
    }

    // --- Store Repository Implementations ---
    override suspend fun purchaseProduct(id: String): Boolean {
        _storeProducts.value = _storeProducts.value.map {
            if (it.id == id) it.copy(isOwned = true) else it
        }
        // If it matches a game, grant ownership
        _games.value = _games.value.map {
            if (it.id == id || it.title.contains(id, ignoreCase = true)) {
                it.copy(entitlement = EntitlementType.OWNED)
            } else it
        }
        val notif = AureomNotification(
            id = "notif_${System.currentTimeMillis()}",
            title = "Order Confirmed",
            message = "Product unlocked in your Aureom Library.",
            timestamp = "Just now",
            type = NotificationType.STORE_PROMOTION
        )
        _notifications.value = listOf(notif) + _notifications.value
        return true
    }

    // --- System Repository Implementations ---
    override suspend fun markNotificationRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    override suspend fun dismissNotification(id: String) {
        _notifications.value = _notifications.value.filter { it.id != id }
    }

    override suspend fun clearAllNotifications() {
        _notifications.value = emptyList()
    }

    override suspend fun runNetworkDiagnostics() {
        delay(1200)
        _systemStatus.value = _systemStatus.value.copy(
            pingMs = (14..22).random(),
            downloadSpeedMbps = (820..890).random().toFloat(),
            uploadSpeedMbps = (200..230).random().toFloat()
        )
    }

    // --- Settings Repository Implementations ---
    override suspend fun updateDisplay(settings: DisplaySettings) {
        _displaySettings.value = settings
    }

    override suspend fun updateAudio(settings: AudioSettings) {
        _audioSettings.value = settings
    }

    override suspend fun updateController(settings: ControllerSettings) {
        _controllerSettings.value = settings
    }

    override suspend fun updateAccessibility(settings: AccessibilitySettings) {
        _accessibilitySettings.value = settings
    }

    override suspend fun updatePrivacy(settings: PrivacySettings) {
        _privacySettings.value = settings
    }

    override suspend fun updateFamily(settings: FamilySettings) {
        _familySettings.value = settings
    }
}
