package com.example.aureom.features.achievements

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.Achievement
import kotlinx.coroutines.launch

@Composable
fun AchievementsScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val achievements by viewModel.achievements.collectAsState()
    val totalGamerscore by viewModel.backend.totalGamerscore.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var filterRareOnly by remember { mutableStateOf(false) }

    val filteredList = remember(achievements, filterRareOnly) {
        if (filterRareOnly) achievements.filter { it.isRare } else achievements
    }

    val unlockedCount = achievements.count { it.isUnlocked }
    val completionPercent = if (achievements.isNotEmpty()) (unlockedCount.toFloat() / achievements.size) else 0f

    Column(
        modifier = modifier
            .testTag("achievements_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg)
    ) {
        // Gamerscore Summary Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.sm)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            AureomColors.SurfaceCardElevated,
                            AureomColors.Canvas
                        )
                    )
                )
                .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(16.dp))
                .padding(AureomSpacing.lg)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(AureomColors.AureomGold),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Trophy",
                            tint = Color.Black,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(AureomSpacing.md))
                    Column {
                        Text(
                            text = "TOTAL GAMERSCORE",
                            color = AureomColors.TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "$totalGamerscore G",
                            color = AureomColors.AureomGoldBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 28.sp
                        )
                    }
                }

                // Overall Unlock Progress
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$unlockedCount / ${achievements.size} UNLOCKED",
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { completionPercent },
                        modifier = Modifier
                            .width(180.dp)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = AureomColors.AureomGold,
                        trackColor = AureomColors.SurfaceDark
                    )
                }
            }
        }

        // Filter Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.xs),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "GLOBAL ACHIEVEMENTS",
                color = AureomColors.TextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!filterRareOnly) AureomColors.AureomGold else AureomColors.SurfaceCard)
                        .clickable { filterRareOnly = false }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "ALL",
                        color = if (!filterRareOnly) Color.Black else AureomColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (filterRareOnly) AureomColors.AureomCyan else AureomColors.SurfaceCard)
                        .clickable { filterRareOnly = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = "Rare",
                            tint = if (filterRareOnly) Color.Black else AureomColors.AureomCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RARE ONLY (<10%)",
                            color = if (filterRareOnly) Color.Black else AureomColors.TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(AureomSpacing.xs))

        // Achievements List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
            items(filteredList, key = { it.id }) { ach ->
                ConsoleFocusable(
                    nodeId = "ach_${ach.id}",
                    groupId = "achievements_list",
                    onClick = {
                        if (!ach.isUnlocked) {
                            coroutineScope.launch { viewModel.backend.unlockAchievement(ach.id) }
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                ) { isFocused ->
                    Row(
                        modifier = Modifier
                            .testTag("achievement_row_${ach.id}")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isFocused) AureomColors.SurfaceCardElevated
                                else if (ach.isUnlocked) AureomColors.SurfaceCard
                                else AureomColors.SurfaceDark
                            )
                            .border(
                                1.dp,
                                if (isFocused) AureomColors.AureomGold else AureomColors.BorderSubtle,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(AureomSpacing.md),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (ach.isUnlocked) AureomColors.AureomGold.copy(alpha = 0.2f)
                                        else AureomColors.SurfaceDark
                                    )
                                    .border(
                                        1.dp,
                                        if (ach.isUnlocked) AureomColors.AureomGold else AureomColors.BorderSubtle,
                                        RoundedCornerShape(10.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (ach.isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                                    contentDescription = "Status",
                                    tint = if (ach.isUnlocked) AureomColors.AureomGold else AureomColors.TextDisabled,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(AureomSpacing.md))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = ach.title,
                                        color = if (ach.isUnlocked) AureomColors.TextPrimary else AureomColors.TextTertiary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    if (ach.isRare) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(AureomColors.AureomCyan.copy(alpha = 0.2f))
                                                .border(0.5.dp, AureomColors.AureomCyan, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "DIAMOND (${ach.rarityPercent}%)",
                                                color = AureomColors.AureomCyan,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 8.sp
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "${ach.gameTitle} • ${ach.description}",
                                    color = AureomColors.TextSecondary,
                                    fontSize = 12.sp
                                )

                                if (!ach.isUnlocked && ach.progressPercent > 0) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        LinearProgressIndicator(
                                            progress = { ach.progressPercent / 100f },
                                            modifier = Modifier
                                                .width(100.dp)
                                                .height(4.dp)
                                                .clip(RoundedCornerShape(2.dp)),
                                            color = AureomColors.AureomGold,
                                            trackColor = AureomColors.SurfaceDark
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${ach.progressPercent}%",
                                            color = AureomColors.TextTertiary,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${ach.gamerscore} G",
                                color = if (ach.isUnlocked) AureomColors.AureomGoldBright else AureomColors.TextDisabled,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                            if (!ach.isUnlocked) {
                                Text(
                                    text = "Click to unlock [Test]",
                                    color = AureomColors.TextTertiary,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
