package com.example.aureom.features.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.core.state.ConsoleRoute

@Composable
fun SearchOverlayScreen(
    viewModel: AureomAppViewModel,
    onNavigateToGame: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val games by viewModel.games.collectAsState()
    val friends by viewModel.friends.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    val matchedGames = remember(searchQuery, games) {
        if (searchQuery.isBlank()) emptyList()
        else games.filter { it.title.contains(searchQuery, ignoreCase = true) || it.genre.contains(searchQuery, ignoreCase = true) }
    }

    val matchedFriends = remember(searchQuery, friends) {
        if (searchQuery.isBlank()) emptyList()
        else friends.filter { it.gamertag.contains(searchQuery, ignoreCase = true) }
    }

    val matchedAchievements = remember(searchQuery, achievements) {
        if (searchQuery.isBlank()) emptyList()
        else achievements.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Box(
        modifier = modifier
            .testTag("search_overlay")
            .fillMaxSize()
            .background(AureomColors.Canvas.copy(alpha = 0.95f))
            .padding(horizontal = AureomSpacing.xl, vertical = AureomSpacing.lg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 850.dp)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.md)
        ) {
            // Search Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AureomColors.SurfaceCardElevated)
                    .border(1.5.dp, AureomColors.AureomGold, RoundedCornerShape(14.dp))
                    .padding(horizontal = AureomSpacing.md, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = AureomColors.AureomGold,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(AureomSpacing.sm))
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search games, friends, achievements...", color = AureomColors.TextTertiary) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = AureomColors.TextPrimary,
                        unfocusedTextColor = AureomColors.TextPrimary,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.toggleSearch(false) }) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = AureomColors.TextSecondary
                    )
                }
            }

            // Results List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm),
                modifier = Modifier.fillMaxSize()
            ) {
                if (searchQuery.isBlank()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Start typing to search games, store, friends or achievements across Aureom OS",
                                color = AureomColors.TextTertiary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    // Games results
                    if (matchedGames.isNotEmpty()) {
                        item {
                            Text(
                                text = "GAMES (${matchedGames.size})",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }
                        items(matchedGames) { game ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AureomColors.SurfaceCard)
                                    .clickable {
                                        viewModel.toggleSearch(false)
                                        onNavigateToGame(game.id)
                                    }
                                    .padding(AureomSpacing.md),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = game.title, color = AureomColors.TextPrimary, fontWeight = FontWeight.Bold)
                                    Text(text = "${game.genre} • ${game.developer}", color = AureomColors.TextSecondary, fontSize = 12.sp)
                                }
                                Text(
                                    text = if (game.isInstalled) "INSTALLED" else "AVAILABLE",
                                    color = if (game.isInstalled) AureomColors.Success else AureomColors.AureomCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Friends results
                    if (matchedFriends.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(AureomSpacing.xs))
                            Text(
                                text = "FRIENDS (${matchedFriends.size})",
                                color = AureomColors.AureomCyan,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }
                        items(matchedFriends) { friend ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AureomColors.SurfaceCard)
                                    .clickable {
                                        viewModel.toggleSearch(false)
                                        viewModel.navigateTo(ConsoleRoute.SOCIAL)
                                    }
                                    .padding(AureomSpacing.md),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = friend.gamertag, color = AureomColors.TextPrimary, fontWeight = FontWeight.Bold)
                                Text(text = "${friend.gamerscore} G", color = AureomColors.AureomGold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
