package com.example.aureom.features.developer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.logging.AureomLogger
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.AureomNotification
import com.example.aureom.domain.model.NotificationType
import kotlinx.coroutines.launch

@Composable
fun DeveloperScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val appState by viewModel.appState.collectAsState()
    val logs = AureomLogger.recentLogs

    Column(
        modifier = modifier
            .testTag("developer_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg, vertical = AureomSpacing.sm),
        verticalArrangement = Arrangement.spacedBy(AureomSpacing.md)
    ) {
        Text(
            text = "AUREOM OS DEVELOPER WORKSPACE",
            color = AureomColors.AureomGold,
            fontWeight = FontWeight.Black,
            fontSize = 24.sp,
            letterSpacing = (-0.5).sp
        )

        // Event Simulation Toolbar
        Row(
            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.sm),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    coroutineScope.launch {
                        viewModel.backend.unlockAchievement("ach_03")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AureomColors.SurfaceCardElevated)
            ) {
                Text("Simulate Unlock", color = AureomColors.AureomGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    viewModel.showOverlayNotification(
                        AureomNotification(
                            id = "notif_sim_${System.currentTimeMillis()}",
                            title = "Simulated Party Invite",
                            message = "GhostBlade99 invited you to Northline Expedition",
                            timestamp = "Just now",
                            type = NotificationType.PARTY_INVITE
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = AureomColors.SurfaceCardElevated)
            ) {
                Text("Simulate Invite", color = AureomColors.AureomCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { viewModel.toggleDebugOverlay() },
                colors = ButtonDefaults.buttonColors(containerColor = AureomColors.SurfaceCardElevated)
            ) {
                Text(
                    text = if (appState.showDebugOverlay) "Hide HUD" else "Show HUD",
                    color = AureomColors.TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { viewModel.toggleOfflineMode() },
                colors = ButtonDefaults.buttonColors(containerColor = AureomColors.SurfaceCardElevated)
            ) {
                Text(
                    text = if (appState.isOfflineMode) "Go Online" else "Go Offline",
                    color = if (appState.isOfflineMode) AureomColors.Success else AureomColors.Warning,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Live Log Stream
        Column(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = 0.9f))
                .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(12.dp))
                .padding(AureomSpacing.md)
        ) {
            Text(
                text = "SYSTEM KERNEL LOG STREAM",
                color = AureomColors.AureomCyan,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(AureomSpacing.xs))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(logs.toList()) { log: String ->
                    val textColor = when {
                        log.contains("[ERROR]") -> AureomColors.Error
                        log.contains("[WARN]") -> AureomColors.Warning
                        log.contains("[INFO]") -> AureomColors.AureomCyan
                        else -> AureomColors.TextSecondary
                    }
                    Text(
                        text = log,
                        color = textColor,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
