package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import com.example.aureom.core.logging.AureomLogger
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.core.theme.AureomTheme
import com.example.aureom.data.mock.MockAureomBackend
import com.example.aureom.platform.websocket.AureomRealtimeClient
import com.example.aureom.ui.AureomApp

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    AureomLogger.info("MainActivity", "Aureom Game OS starting...")

    setContent {
      val scope = rememberCoroutineScope()
      val backend = remember { MockAureomBackend(scope) }
      val realtimeClient = remember { AureomRealtimeClient(scope) }
      val appViewModel = remember { AureomAppViewModel(backend, realtimeClient) }

      AureomTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
          AureomApp(
            viewModel = appViewModel,
            modifier = Modifier.padding(innerPadding)
          )
        }
      }
    }
  }
}

