package com.example.aureom.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.domain.model.Game
import com.example.aureom.domain.model.GamePlayState

@Composable
fun HeroBanner(
    game: Game,
    onPlay: () -> Unit,
    onContinue: () -> Unit,
    onDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = try {
        Color(android.graphics.Color.parseColor(game.accentColorHex))
    } catch (_: Exception) {
        AureomColors.AureomGold
    }

    Box(
        modifier = modifier
            .testTag("hero_banner_${game.id}")
            .fillMaxWidth()
            .height(320.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        accent.copy(alpha = 0.35f),
                        AureomColors.SurfaceCardElevated.copy(alpha = 0.95f),
                        AureomColors.Canvas
                    )
                )
            )
            .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(20.dp))
            .padding(AureomSpacing.xl)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.72f),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Tags
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AureomColors.AureomGold)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "FEATURED CONSOLE TITLE",
                        color = Color.Black,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AureomColors.SurfaceCard)
                        .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${game.genre} • ${game.releaseYear}",
                        color = AureomColors.TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Features Chips
                game.supportedFeatures.take(2).forEach { feat ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AureomColors.SurfaceCard.copy(alpha = 0.6f))
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = feat,
                            color = AureomColors.AureomCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Title & Description
            Column {
                Text(
                    text = game.title,
                    color = AureomColors.TextPrimary,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
                Spacer(modifier = Modifier.height(AureomSpacing.xxs))
                Text(
                    text = game.tagline,
                    color = AureomColors.AureomGoldBright,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(AureomSpacing.xs))
                Text(
                    text = game.description,
                    color = AureomColors.TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Primary Action Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(AureomSpacing.sm)
            ) {
                // Main Action (Play / Resume / Install)
                ConsoleFocusable(
                    nodeId = "hero_play",
                    groupId = "hero_actions",
                    onClick = onPlay,
                    shape = RoundedCornerShape(12.dp)
                ) { isFocused ->
                    Row(
                        modifier = Modifier
                            .testTag("hero_play_button")
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isFocused) AureomColors.AureomGoldBright else AureomColors.AureomGold
                            )
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (game.playState == GamePlayState.DOWNLOADING) "DOWNLOADING..." else "PLAY NOW",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                }

                // Continue Button
                ConsoleFocusable(
                    nodeId = "hero_continue",
                    groupId = "hero_actions",
                    onClick = onContinue,
                    shape = RoundedCornerShape(12.dp)
                ) { isFocused ->
                    Row(
                        modifier = Modifier
                            .testTag("hero_continue_button")
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isFocused) AureomColors.SurfaceCardElevated else AureomColors.SurfaceCard
                            )
                            .border(1.dp, if (isFocused) AureomColors.FocusBorder else AureomColors.BorderSubtle, RoundedCornerShape(12.dp))
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Continue",
                            tint = AureomColors.TextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CONTINUE",
                            color = AureomColors.TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                // View Details Button
                ConsoleFocusable(
                    nodeId = "hero_details",
                    groupId = "hero_actions",
                    onClick = onDetails,
                    shape = RoundedCornerShape(12.dp)
                ) { isFocused ->
                    Row(
                        modifier = Modifier
                            .testTag("hero_details_button")
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isFocused) AureomColors.SurfaceCardElevated else Color.Transparent
                            )
                            .border(1.dp, if (isFocused) AureomColors.FocusBorder else AureomColors.BorderSubtle, RoundedCornerShape(12.dp))
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Details",
                            tint = AureomColors.TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "DETAILS",
                            color = AureomColors.TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
