package com.example.aureom.domain.model

enum class GamePlayState {
    NOT_INSTALLED,
    READY_TO_PLAY,
    RUNNING,
    SUSPENDED,
    DOWNLOADING,
    UPDATING,
    QUEUED
}

enum class EntitlementType {
    OWNED,
    SUBSCRIPTION_PASS,
    FREE_TO_PLAY,
    DEMO,
    LOCKED
}

data class Game(
    val id: String,
    val title: String,
    val tagline: String,
    val description: String,
    val developer: String,
    val publisher: String,
    val releaseYear: Int,
    val genre: String,
    val sizeGb: Double,
    val rating: Double,
    val ageRating: String = "PEGI 16",
    val heroCoverUrl: String = "",
    val accentColorHex: String = "#F5B700",
    val playState: GamePlayState = GamePlayState.READY_TO_PLAY,
    val entitlement: EntitlementType = EntitlementType.OWNED,
    val playtimeMinutes: Int = 0,
    val totalAchievements: Int = 30,
    val unlockedAchievements: Int = 0,
    val lastPlayedTimestamp: Long = 0L,
    val isInstalled: Boolean = true,
    val isFavorite: Boolean = false,
    val isQuickResumeCapable: Boolean = true,
    val currentDownloadPercent: Float = 0f,
    val downloadSpeedMbps: Float = 0f,
    val supportedFeatures: List<String> = listOf("4K UHD", "120 FPS", "Ray Tracing", "HDR10", "Spatial Audio", "Quick Resume"),
    val dlcList: List<GameDLC> = emptyList(),
    val screenshots: List<String> = emptyList()
)

data class GameDLC(
    val id: String,
    val title: String,
    val priceFormatted: String,
    val isOwned: Boolean = false
)

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    VERIFYING,
    INSTALLING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class DownloadItem(
    val id: String,
    val gameId: String,
    val title: String,
    val version: String = "1.4.2",
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedMbps: Float,
    val etaSeconds: Long,
    val status: DownloadStatus,
    val priority: Int = 1
) {
    val progressPercent: Float
        get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

data class Achievement(
    val id: String,
    val gameId: String,
    val gameTitle: String,
    val title: String,
    val description: String,
    val gamerscore: Int,
    val isUnlocked: Boolean,
    val unlockTimestamp: Long? = null,
    val progressPercent: Int = 0,
    val isRare: Boolean = false,
    val rarityPercent: Float = 12.5f,
    val iconName: String = "trophy"
)

enum class PresenceStatus {
    ONLINE,
    IN_GAME,
    BUSY,
    OFFLINE
}

data class Friend(
    val id: String,
    val gamertag: String,
    val realName: String,
    val avatarUrl: String = "",
    val presence: PresenceStatus,
    val currentGameTitle: String? = null,
    val gamerscore: Int,
    val lastOnline: String = "Just now",
    val isPartyJoinable: Boolean = false,
    val currentPartyId: String? = null,
    val isMuted: Boolean = false,
    val isBlocked: Boolean = false
)

data class PartyMember(
    val playerId: String,
    val gamertag: String,
    val isLeader: Boolean = false,
    val isTalking: Boolean = false,
    val isMuted: Boolean = false,
    val volume: Float = 1.0f
)

data class Party(
    val id: String,
    val title: String,
    val leaderGamertag: String,
    val members: List<PartyMember>,
    val isJoinable: Boolean = true,
    val gameTitle: String? = null
)

data class ChatMessage(
    val id: String,
    val senderGamertag: String,
    val text: String,
    val timestamp: String,
    val isIncoming: Boolean = true
)

data class Conversation(
    val friendId: String,
    val friendGamertag: String,
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val messages: List<ChatMessage> = emptyList(),
    val isTyping: Boolean = false
)

data class PlayerProfile(
    val id: String,
    val gamertag: String,
    val bio: String,
    val gamerscore: Int,
    val level: Int,
    val tenureYears: Int,
    val completedGamesCount: Int,
    val subscriptionTier: String = "AUREOM PASS ULTIMATE",
    val subscriptionExpires: String = "Nov 2027",
    val reputation: String = "EXCELLENT",
    val avatarColorHex: String = "#F5B700"
)

enum class NotificationType {
    ACHIEVEMENT,
    FRIEND_REQUEST,
    PARTY_INVITE,
    DOWNLOAD_COMPLETE,
    GAME_UPDATE,
    MESSAGE,
    STORE_PROMOTION,
    SYSTEM
}

data class AureomNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val type: NotificationType,
    val isRead: Boolean = false,
    val points: Int? = null,
    val actionLabel: String? = "View",
    val deepLink: String = "home"
)

data class StoreProduct(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String, // AAA, Indie, Aureom Pass, Deals
    val price: Double,
    val discountPercent: Int = 0,
    val rating: Double,
    val publisher: String,
    val sizeGb: Double,
    val heroUrl: String = "",
    val badge: String? = null,
    val isIncludedInPass: Boolean = true,
    val isOwned: Boolean = false
) {
    val formattedPrice: String
        get() = if (price == 0.0) "Free" else if (discountPercent > 0) {
            val discounted = price * (1 - discountPercent / 100.0)
            "$%.2f".format(discounted)
        } else "$%.2f".format(price)
}

data class QuickResumeGame(
    val gameId: String,
    val title: String,
    val genre: String,
    val memoryUsageMb: Int,
    val suspendedAt: String
)

data class SystemStatus(
    val osVersion: String = "Aureom OS 2026.4.1 (Build 8912)",
    val runtimeVersion: String = "Aureom Kernel v5.14-console",
    val ipAddress: String = "192.168.1.104",
    val natType: String = "Open (Type 1)",
    val pingMs: Int = 18,
    val jitterMs: Int = 1,
    val packetLossPercent: Float = 0.0f,
    val downloadSpeedMbps: Float = 842.5f,
    val uploadSpeedMbps: Float = 210.3f,
    val storageTotalGb: Double = 1000.0,
    val storageUsedGb: Double = 612.4,
    val activeControllerConnected: Boolean = true,
    val controllerBatteryPercent: Int = 92,
    val cloudSyncState: String = "Synced (All game states saved)",
    val fpsTarget: Int = 120
)

data class DisplaySettings(
    val resolution: String = "3840x2160 (4K UHD)",
    val refreshRate: String = "120 Hz",
    val hdrEnabled: Boolean = true,
    val vrrEnabled: Boolean = true,
    val brightnessPercent: Int = 85,
    val uiScalePercent: Int = 100,
    val motionReduction: Boolean = false
)

data class AudioSettings(
    val masterVolume: Int = 90,
    val musicVolume: Int = 80,
    val sfxVolume: Int = 95,
    val voiceChatVolume: Int = 100,
    val chatMixerPercent: Int = 50,
    val spatialAudioEnabled: Boolean = true,
    val spatialAudioFormat: String = "Dolby Atmos",
    val micMonitoring: Boolean = false,
    val micMonitoringEnabled: Boolean = false
)

data class ControllerSettings(
    val vibrationEnabled: Boolean = true,
    val triggerFeedbackStrength: Int = 80,
    val triggerImpulseEnabled: Boolean = true,
    val stickDeadzonePercent: Int = 8,
    val stickSensitivityPercent: Int = 100,
    val invertYAxis: Boolean = false
)

data class AccessibilitySettings(
    val highContrast: Boolean = false,
    val textScalingPercent: Int = 100,
    val largeFocusIndicators: Boolean = true,
    val screenReaderSemantics: Boolean = true,
    val screenReader: Boolean = false,
    val subtitlesEnabled: Boolean = true,
    val reducedMotion: Boolean = false
)

data class PrivacySettings(
    val onlineStatusVisibleTo: String = "Everyone",
    val gameActivityVisibleTo: String = "Friends Only",
    val achievementVisibility: String = "Everyone",
    val friendRequestsAllowedFrom: String = "Everyone",
    val partyInvitesAllowedFrom: String = "Friends Only",
    val allowPresenceSharing: Boolean = true
)

data class FamilySettings(
    val screenTimeLimitHoursPerDay: Int = 4,
    val contentFilterRating: String = "PEGI 16",
    val purchaseApprovalRequired: Boolean = true,
    val multiplayerAllowed: Boolean = true
)
