package com.example.aureom.features.game

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.Game
import kotlinx.coroutines.delay

@Composable
fun GameRuntimeOverlay(
    game: Game,
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val accent = try {
        Color(android.graphics.Color.parseColor(game.accentColorHex))
    } catch (_: Exception) {
        AureomColors.AureomGold
    }

    var inGameSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(game.id) {
        while (true) {
            delay(1000)
            inGameSeconds++
        }
    }

    Box(
        modifier = modifier
            .testTag("game_runtime_viewport")
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        accent.copy(alpha = 0.5f),
                        AureomColors.Canvas,
                        Color.Black
                    )
                )
            )
            .padding(AureomSpacing.xl)
    ) {
        // Game HUD Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(AureomColors.Success)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RUNNING: ${game.title}",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Specs Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "4K 120 FPS • HDR10 • VRR ACTIVE",
                    color = AureomColors.AureomCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Center Game Simulation Reticle & Scene Representation
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.md)
        ) {
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .border(2.dp, accent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SportsEsports,
                    contentDescription = "In Game",
                    tint = accent,
                    modifier = Modifier.size(64.dp)
                )
            }

            Text(
                text = "ACTIVE GAMEPLAY SESSION",
                color = AureomColors.TextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                letterSpacing = 1.sp
            )

            Text(
                text = "Session Duration: ${inGameSeconds / 60}m ${inGameSeconds % 60}s",
                color = AureomColors.TextSecondary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Bottom Console Controller Hints Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black.copy(alpha = 0.85f))
                .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(16.dp))
                .padding(horizontal = AureomSpacing.lg, vertical = AureomSpacing.md),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Aureom DirectStorage Runtime active",
                color = AureomColors.TextTertiary,
                fontSize = 11.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md)) {
                // Suspend to Quick Resume
                Button(
                    onClick = { viewModel.suspendCurrentGameToQuickResume() },
                    colors = ButtonDefaults.buttonColors(containerColor = AureomColors.SurfaceCardElevated),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "Quick Resume",
                        tint = AureomColors.AureomGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SUSPEND TO QUICK RESUME [View]",
                        color = AureomColors.AureomGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                // Exit Game
                Button(
                    onClick = { viewModel.exitGame() },
                    colors = ButtonDefaults.buttonColors(containerColor = AureomColors.Error.copy(alpha = 0.8f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Exit",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "EXIT TO DASHBOARD [B]",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
