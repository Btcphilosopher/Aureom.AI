package com.example.aureom.data.remote

import com.example.aureom.core.logging.AureomLogger

data class AureomBackendConfig(
    val baseUrl: String = "https://api.aureom.os/v1",
    val authUrl: String = "https://auth.aureom.os/oauth2",
    val websocketUrl: String = "wss://realtime.aureom.os/events",
    val isSimulationMode: Boolean = true
)

/**
 * Production REST Backend Adapter Boundary.
 * All communication conforms to this contract, allowing clean transition
 * between the offline/in-memory console simulator and production cloud edge services.
 */
class RemoteAureomBackend(
    val config: AureomBackendConfig = AureomBackendConfig()
) {
    init {
        AureomLogger.info("RemoteAureomBackend", "Initialized with BaseURL: ${config.baseUrl}")
    }

    object Endpoints {
        const val PROFILE = "/api/v1/profile"
        const val LIBRARY = "/api/v1/library"
        const val GAMES = "/api/v1/games"
        const val STORE = "/api/v1/store"
        const val SOCIAL = "/api/v1/social"
        const val FRIENDS = "/api/v1/friends"
        const val PARTY = "/api/v1/party"
        const val MESSAGES = "/api/v1/messages"
        const val ACHIEVEMENTS = "/api/v1/achievements"
        const val DOWNLOADS = "/api/v1/downloads"
        const val SETTINGS = "/api/v1/settings"
        const val SYSTEM = "/api/v1/system"
        const val STORAGE = "/api/v1/storage"
        const val NETWORK = "/api/v1/network"
    }
}
