package com.example.aureom.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing

@Composable
fun LaunchTransitionOverlay(
    isLaunching: Boolean,
    gameTitle: String?,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isLaunching,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .testTag("launch_transition_overlay")
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.96f)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(AureomSpacing.md)
            ) {
                CircularProgressIndicator(
                    color = AureomColors.AureomGold,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(54.dp)
                )

                Text(
                    text = "INITIALIZING DIRECTSTORAGE RUNTIME",
                    color = AureomColors.AureomGold,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                )

                if (gameTitle != null) {
                    Text(
                        text = "Launching $gameTitle",
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                Text(
                    text = "Verifying Entitlement • Compiling PSO Shader Cache",
                    color = AureomColors.TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
