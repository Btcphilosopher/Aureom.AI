package com.example.aureom.features.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import kotlinx.coroutines.launch

enum class SettingsCategory(val label: String, val icon: ImageVector) {
    DISPLAY("Display & TV", Icons.Default.Tv),
    AUDIO("Audio & Headset", Icons.Default.VolumeUp),
    CONTROLLER("Controller & Input", Icons.Default.SportsEsports),
    NETWORK("Network & Diagnostics", Icons.Default.Wifi),
    ACCESSIBILITY("Accessibility", Icons.Default.AccessibilityNew),
    PRIVACY("Privacy & Safety", Icons.Default.Security),
    DEVELOPER("Developer Mode", Icons.Default.DeveloperMode)
}

@Composable
fun SettingsScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val displaySettings by viewModel.displaySettings.collectAsState()
    val audioSettings by viewModel.audioSettings.collectAsState()
    val controllerSettings by viewModel.controllerSettings.collectAsState()
    val accessibilitySettings by viewModel.accessibilitySettings.collectAsState()
    val privacySettings by viewModel.privacySettings.collectAsState()
    val systemStatus by viewModel.systemStatus.collectAsState()
    val appState by viewModel.appState.collectAsState()

    var selectedCategory by remember { mutableStateOf(SettingsCategory.DISPLAY) }
    val coroutineScope = rememberCoroutineScope()
    var isRunningSpeedTest by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .testTag("settings_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg, vertical = AureomSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.lg)
    ) {
        // Left Column: Category Selector (35% width)
        Column(
            modifier = Modifier
                .weight(0.35f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
        ) {
            Text(
                text = "SETTINGS",
                color = AureomColors.TextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.padding(bottom = AureomSpacing.xs)
            )

            SettingsCategory.values().forEach { cat ->
                val isSelected = selectedCategory == cat
                ConsoleFocusable(
                    nodeId = "settings_cat_${cat.name}",
                    groupId = "settings_categories",
                    onClick = { selectedCategory = cat },
                    shape = RoundedCornerShape(10.dp)
                ) { isFocused ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) AureomColors.SurfaceCardElevated
                                else if (isFocused) AureomColors.SurfaceCard
                                else AureomColors.SurfaceDark
                            )
                            .border(
                                1.dp,
                                if (isSelected) AureomColors.AureomGold else AureomColors.BorderSubtle,
                                RoundedCornerShape(10.dp)
                            )
                            .padding(horizontal = AureomSpacing.md, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = cat.icon,
                            contentDescription = cat.label,
                            tint = if (isSelected) AureomColors.AureomGold else AureomColors.TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(AureomSpacing.sm))
                        Text(
                            text = cat.label,
                            color = if (isSelected) AureomColors.TextPrimary else AureomColors.TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Right Column: Category Settings Inspector (65% width)
        Column(
            modifier = Modifier
                .weight(0.65f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(AureomColors.SurfaceCard)
                .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(16.dp))
                .padding(AureomSpacing.lg)
        ) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                modifier = Modifier.fillMaxSize()
            ) {
                when (selectedCategory) {
                    SettingsCategory.DISPLAY -> {
                        item {
                            Text(
                                text = "DISPLAY & TV OUTPUT",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Variable Refresh Rate (VRR)",
                                subtitle = "Enables AMD FreeSync & HDMI 2.1 VRR (48-120 Hz)",
                                isChecked = displaySettings.vrrEnabled,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateDisplay(displaySettings.copy(vrrEnabled = it))
                                    }
                                }
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "High Dynamic Range (HDR10)",
                                subtitle = "Wide color gamut calibration for OLED / Mini-LED",
                                isChecked = displaySettings.hdrEnabled,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateDisplay(displaySettings.copy(hdrEnabled = it))
                                    }
                                }
                            )
                        }
                        item {
                            SettingValueItem(
                                title = "Output Resolution",
                                value = displaySettings.resolution,
                                onClick = {
                                    val next = when (displaySettings.resolution) {
                                        "4K UHD" -> "1440p QHD"
                                        "1440p QHD" -> "1080p FHD"
                                        else -> "4K UHD"
                                    }
                                    coroutineScope.launch {
                                        viewModel.backend.updateDisplay(displaySettings.copy(resolution = next))
                                    }
                                }
                            )
                        }
                        item {
                            SettingValueItem(
                                title = "Refresh Rate",
                                value = displaySettings.refreshRate,
                                onClick = {
                                    val next = if (displaySettings.refreshRate == "120Hz") "60Hz" else "120Hz"
                                    coroutineScope.launch {
                                        viewModel.backend.updateDisplay(displaySettings.copy(refreshRate = next))
                                    }
                                }
                            )
                        }
                    }

                    SettingsCategory.AUDIO -> {
                        item {
                            Text(
                                text = "AUDIO & HEADSET CALIBRATION",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            SettingValueItem(
                                title = "Spatial Audio Format",
                                value = audioSettings.spatialAudioFormat,
                                onClick = {
                                    val next = when (audioSettings.spatialAudioFormat) {
                                        "Dolby Atmos" -> "DTS Headphone:X"
                                        "DTS Headphone:X" -> "Windows Sonic"
                                        else -> "Dolby Atmos"
                                    }
                                    coroutineScope.launch {
                                        viewModel.backend.updateAudio(audioSettings.copy(spatialAudioFormat = next))
                                    }
                                }
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Microphone Monitoring (Sidetone)",
                                subtitle = "Hear your own voice in real-time with zero latency",
                                isChecked = audioSettings.micMonitoringEnabled,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateAudio(audioSettings.copy(micMonitoringEnabled = it))
                                    }
                                }
                            )
                        }
                    }

                    SettingsCategory.CONTROLLER -> {
                        item {
                            Text(
                                text = "CONTROLLER & HAPTICS",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Haptic Vibration",
                                subtitle = "Dual impulse actuators in grips and triggers",
                                isChecked = controllerSettings.vibrationEnabled,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateController(controllerSettings.copy(vibrationEnabled = it))
                                    }
                                }
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Trigger Impulse Feedback",
                                subtitle = "Adaptive resistance on RT / LT during braking & firing",
                                isChecked = controllerSettings.triggerImpulseEnabled,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateController(controllerSettings.copy(triggerImpulseEnabled = it))
                                    }
                                }
                            )
                        }
                    }

                    SettingsCategory.NETWORK -> {
                        item {
                            Text(
                                text = "NETWORK DIAGNOSTICS & MULTIPLAYER",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AureomColors.SurfaceDark)
                                    .padding(AureomSpacing.md),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "NAT Type: ${systemStatus.natType}",
                                        color = AureomColors.Success,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "Ping: ${systemStatus.pingMs} ms • Packet Loss: 0.0%",
                                        color = AureomColors.TextSecondary,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "Speed: ${"%.1f".format(systemStatus.downloadSpeedMbps)} Mbps Down / ${"%.1f".format(systemStatus.uploadSpeedMbps)} Mbps Up",
                                        color = AureomColors.AureomCyan,
                                        fontSize = 12.sp
                                    )
                                }

                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isRunningSpeedTest = true
                                            viewModel.backend.runNetworkDiagnostics()
                                            isRunningSpeedTest = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AureomColors.AureomGold)
                                ) {
                                    Text(
                                        text = if (isRunningSpeedTest) "TESTING..." else "RUN TEST",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }

                    SettingsCategory.ACCESSIBILITY -> {
                        item {
                            Text(
                                text = "ACCESSIBILITY SUITE",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "High Contrast Mode",
                                subtitle = "Increases edge outline clarity and color separation",
                                isChecked = accessibilitySettings.highContrast,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateAccessibility(accessibilitySettings.copy(highContrast = it))
                                    }
                                }
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Text-to-Speech Console Narrator",
                                subtitle = "Reads on-screen menu elements as focus shifts",
                                isChecked = accessibilitySettings.screenReader,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updateAccessibility(accessibilitySettings.copy(screenReader = it))
                                    }
                                }
                            )
                        }
                    }

                    SettingsCategory.PRIVACY -> {
                        item {
                            Text(
                                text = "PRIVACY & CLOUD TELEMETRY",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Share Online Game Presence",
                                subtitle = "Allow friends to see current game and party status",
                                isChecked = privacySettings.allowPresenceSharing,
                                onCheckedChange = {
                                    coroutineScope.launch {
                                        viewModel.backend.updatePrivacy(privacySettings.copy(allowPresenceSharing = it))
                                    }
                                }
                            )
                        }
                    }

                    SettingsCategory.DEVELOPER -> {
                        item {
                            Text(
                                text = "DEVELOPER TOOLS & SANDBOX",
                                color = AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Enable Dev Mode Route",
                                subtitle = "Unlocks kernel diagnostics, live logs & simulation sandbox",
                                isChecked = appState.isDevModeEnabled,
                                onCheckedChange = { viewModel.toggleDeveloperMode() }
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "On-Screen Performance HUD",
                                subtitle = "Displays 120 FPS realtime frame counters and heap pool",
                                isChecked = appState.showDebugOverlay,
                                onCheckedChange = { viewModel.toggleDebugOverlay() }
                            )
                        }
                        item {
                            SettingToggleItem(
                                title = "Simulate Offline Console State",
                                subtitle = "Cuts off network sockets to test offline behavior",
                                isChecked = appState.isOfflineMode,
                                onCheckedChange = { viewModel.toggleOfflineMode() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingToggleItem(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AureomColors.SurfaceDark)
            .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
            .clickable { onCheckedChange(!isChecked) }
            .padding(AureomSpacing.md),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = AureomColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(text = subtitle, color = AureomColors.TextSecondary, fontSize = 12.sp)
        }
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = AureomColors.AureomGold,
                uncheckedThumbColor = AureomColors.TextSecondary,
                uncheckedTrackColor = AureomColors.SurfaceCard
            )
        )
    }
}

@Composable
fun SettingValueItem(
    title: String,
    value: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AureomColors.SurfaceDark)
            .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(AureomSpacing.md),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = title, color = AureomColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = value, color = AureomColors.AureomGoldBright, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.ChevronRight, contentDescription = "Change", tint = AureomColors.TextTertiary)
        }
    }
}
