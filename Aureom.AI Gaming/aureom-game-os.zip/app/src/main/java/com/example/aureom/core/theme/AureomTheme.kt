package com.example.aureom.core.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors

@Immutable
data class AureomExtendedColors(
    val canvas: Color = AureomColors.Canvas,
    val surfaceElevated: Color = AureomColors.SurfaceCardElevated,
    val surfaceGlass: Color = AureomColors.SurfaceCardGlass,
    val gold: Color = AureomColors.AureomGold,
    val goldBright: Color = AureomColors.AureomGoldBright,
    val cyan: Color = AureomColors.AureomCyan,
    val focusGlow: Color = AureomColors.FocusGlow,
    val borderSubtle: Color = AureomColors.BorderSubtle,
    val textTertiary: Color = AureomColors.TextTertiary,
    val online: Color = AureomColors.Online,
    val inGame: Color = AureomColors.InGame,
    val highContrast: Boolean = false
)

val LocalAureomColors = staticCompositionLocalOf { AureomExtendedColors() }

private val ConsoleDarkColorScheme = darkColorScheme(
    primary = AureomColors.AureomGold,
    onPrimary = Color.Black,
    primaryContainer = AureomColors.SurfaceCardElevated,
    onPrimaryContainer = AureomColors.AureomGoldBright,
    secondary = AureomColors.AureomCyan,
    onSecondary = Color.Black,
    secondaryContainer = AureomColors.SurfaceCard,
    onSecondaryContainer = AureomColors.AureomCyan,
    tertiary = AureomColors.AureomAmber,
    background = AureomColors.Canvas,
    onBackground = AureomColors.TextPrimary,
    surface = AureomColors.SurfaceDark,
    onSurface = AureomColors.TextPrimary,
    surfaceVariant = AureomColors.SurfaceCard,
    onSurfaceVariant = AureomColors.TextSecondary,
    outline = AureomColors.BorderSubtle,
    error = AureomColors.Error,
    onError = Color.White
)

private val HighContrastColorScheme = darkColorScheme(
    primary = Color(0xFFFFEB3B),
    onPrimary = Color.Black,
    secondary = Color(0xFF00FFFF),
    onSecondary = Color.Black,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color(0xFF111111),
    onSurface = Color.White,
    outline = Color.White,
    error = Color(0xFFFF1744),
    onError = Color.White
)

val AureomTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Black,
        fontSize = 36.sp,
        lineHeight = 44.sp,
        letterSpacing = (-0.5).sp,
        color = AureomColors.TextPrimary
    ),
    displayMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.25).sp,
        color = AureomColors.TextPrimary
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        color = AureomColors.TextPrimary
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        color = AureomColors.TextPrimary
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.15.sp,
        color = AureomColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
        color = AureomColors.TextPrimary
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp,
        color = AureomColors.TextSecondary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.25.sp,
        color = AureomColors.TextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.5.sp,
        color = AureomColors.TextPrimary
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.5.sp,
        color = AureomColors.TextTertiary
    )
)

val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun AureomTheme(
    highContrast: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (highContrast) HighContrastColorScheme else ConsoleDarkColorScheme
    val extendedColors = AureomExtendedColors(highContrast = highContrast)

    CompositionLocalProvider(LocalAureomColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AureomTypography,
            shapes = AureomShapes,
            content = content
        )
    }
}
