package com.example.aureom.features.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.components.GameCard
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel

@Composable
fun ProfileScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val user by viewModel.playerProfile.collectAsState()
    val games by viewModel.games.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    val completedGames = games.filter { it.isFavorite }

    LazyColumn(
        modifier = modifier
            .testTag("profile_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(AureomSpacing.lg),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        // Profile Hero Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = AureomSpacing.sm)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                AureomColors.AureomGold.copy(alpha = 0.25f),
                                AureomColors.SurfaceCardElevated,
                                AureomColors.SurfaceDark
                            )
                        )
                    )
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(20.dp))
                    .padding(AureomSpacing.xl)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Large Avatar
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(AureomColors.AureomGold)
                            .border(3.dp, AureomColors.AureomGoldBright, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.gamertag.take(1),
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 42.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(AureomSpacing.lg))

                    // Bio and Gamertag
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
                        ) {
                            Text(
                                text = user.gamertag,
                                color = AureomColors.TextPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 28.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AureomColors.AureomGold)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "LVL ${user.level}",
                                    color = Color.Black,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Text(
                            text = user.bio,
                            color = AureomColors.TextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Stars,
                                    contentDescription = "Gamerscore",
                                    tint = AureomColors.AureomGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${user.gamerscore} G",
                                    color = AureomColors.AureomGoldBright,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp
                                )
                            }

                            Text(
                                text = "Member for ${user.tenureYears} Years",
                                color = AureomColors.TextTertiary,
                                fontSize = 12.sp
                            )

                            Text(
                                text = "Reputation: ${user.reputation}",
                                color = AureomColors.Success,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Subscription & Membership Tier
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AureomColors.SurfaceCard)
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(14.dp))
                    .padding(AureomSpacing.md),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Premium",
                        tint = AureomColors.AureomGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(AureomSpacing.sm))
                    Column {
                        Text(
                            text = user.subscriptionTier,
                            color = AureomColors.AureomGoldBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Next renewal on ${user.subscriptionExpires} • Cloud Gaming + 200 Games",
                            color = AureomColors.TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(AureomColors.SurfaceDark)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "MANAGE MEMBERSHIP",
                        color = AureomColors.TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Showcase / Favorite Games
        item {
            Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                Text(
                    text = "FEATURED SHOWCASE TITLES",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(completedGames, key = { it.id }) { game ->
                        GameCard(
                            game = game,
                            groupId = "profile_showcase",
                            onClick = { viewModel.setSelectedGame(game.id) }
                        )
                    }
                }
            }
        }
    }
}
