package com.example.aureom.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.controller.LocalFocusEngine
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import kotlinx.coroutines.delay

@Composable
fun DebugOverlay(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val appState by viewModel.appState.collectAsState()
    val focusEngine = LocalFocusEngine.current
    val systemStatus by viewModel.systemStatus.collectAsState()
    val downloads by viewModel.downloads.collectAsState()

    var simulatedFps by remember { mutableIntStateOf(120) }
    var simulatedFrameTime by remember { mutableFloatStateOf(8.33f) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            simulatedFps = (118..120).random()
            simulatedFrameTime = 1000f / simulatedFps
        }
    }

    Box(
        modifier = modifier
            .testTag("debug_overlay")
            .padding(AureomSpacing.sm)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Black.copy(alpha = 0.85f))
            .border(1.dp, AureomColors.AureomCyan, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = "AUREOM ENGINE HUD",
                color = AureomColors.AureomGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "FPS: $simulatedFps (${"%.2f".format(simulatedFrameTime)} ms)",
                color = if (simulatedFps >= 115) AureomColors.Success else AureomColors.Warning,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "ROUTE: ${appState.currentRoute.name}",
                color = AureomColors.AureomCyan,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "FOCUS: ${focusEngine.currentFocusedId} [${focusEngine.currentFocusedGroup}]",
                color = AureomColors.TextPrimary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "PING: ${systemStatus.pingMs}ms | NAT: ${systemStatus.natType.take(4)}",
                color = AureomColors.TextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "MEM EST: 264 MB / 16 GB CONSOLE POOL",
                color = AureomColors.TextTertiary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
