package com.example.aureom.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.domain.model.AureomNotification
import com.example.aureom.domain.model.NotificationType

@Composable
fun NotificationOverlay(
    notification: AureomNotification?,
    onAction: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = notification != null,
        enter = slideInVertically(initialOffsetY = { -it }),
        exit = slideOutVertically(targetOffsetY = { -it }),
        modifier = modifier
    ) {
        if (notification != null) {
            Box(
                modifier = Modifier
                    .testTag("notification_toast")
                    .padding(AureomSpacing.lg)
                    .widthIn(max = 420.dp)
                    .shadow(16.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(AureomColors.SurfaceCardElevated)
                    .border(1.5.dp, AureomColors.AureomGold, RoundedCornerShape(16.dp))
                    .clickable { onAction() }
                    .padding(AureomSpacing.md)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Icon
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                if (notification.type == NotificationType.ACHIEVEMENT) AureomColors.AureomGold else AureomColors.SurfaceDark
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (notification.type == NotificationType.ACHIEVEMENT) Icons.Default.EmojiEvents else Icons.Default.Notifications,
                            contentDescription = "Notification Icon",
                            tint = if (notification.type == NotificationType.ACHIEVEMENT) Color.Black else AureomColors.AureomCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(AureomSpacing.sm))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = notification.title,
                            color = AureomColors.AureomGoldBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = notification.message,
                            color = AureomColors.TextPrimary,
                            fontSize = 12.sp,
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Press [A] View   [B] Dismiss",
                                color = AureomColors.TextTertiary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
