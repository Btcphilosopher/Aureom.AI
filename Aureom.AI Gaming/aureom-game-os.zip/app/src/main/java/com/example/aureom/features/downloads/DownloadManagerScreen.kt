package com.example.aureom.features.downloads

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.DownloadItem
import com.example.aureom.domain.model.DownloadStatus
import kotlinx.coroutines.launch

@Composable
fun DownloadManagerScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val downloads by viewModel.downloads.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    val activeDownloads = downloads.filter { it.status != DownloadStatus.COMPLETED }
    val completedDownloads = downloads.filter { it.status == DownloadStatus.COMPLETED }

    Column(
        modifier = modifier
            .testTag("download_manager_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.sm),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DOWNLOAD QUEUE & NETWORK DISK",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "High-speed decompression pipeline active",
                    color = AureomColors.TextSecondary,
                    fontSize = 13.sp
                )
            }

            // Storage Disk Overview Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(AureomColors.SurfaceCard)
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Storage,
                        contentDescription = "Storage",
                        tint = AureomColors.AureomCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "NVMe Pool: 1,480 GB Free / 2,000 GB",
                        color = AureomColors.TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.md),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
            // Active Download Queue
            if (activeDownloads.isNotEmpty()) {
                item {
                    Text(
                        text = "ACTIVE DOWNLOAD QUEUE (${activeDownloads.size})",
                        color = AureomColors.AureomGold,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }

                items(activeDownloads, key = { it.id }) { item ->
                    val progress = if (item.totalBytes > 0) item.downloadedBytes.toFloat() / item.totalBytes else 0f
                    val downloadedGb = item.downloadedBytes / (1024.0 * 1024.0 * 1024.0)
                    val totalGb = item.totalBytes / (1024.0 * 1024.0 * 1024.0)

                    ConsoleFocusable(
                        nodeId = "dl_${item.id}",
                        groupId = "downloads_active",
                        onClick = {
                            coroutineScope.launch {
                                if (item.status == DownloadStatus.DOWNLOADING) {
                                    viewModel.backend.pauseDownload(item.id)
                                } else {
                                    viewModel.backend.resumeDownload(item.id)
                                }
                            }
                        },
                        shape = RoundedCornerShape(14.dp)
                    ) { isFocused ->
                        Box(
                            modifier = Modifier
                                .testTag("download_item_${item.id}")
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isFocused) AureomColors.SurfaceCardElevated else AureomColors.SurfaceCard
                                )
                                .border(
                                    1.dp,
                                    if (isFocused) AureomColors.AureomGold else AureomColors.BorderSubtle,
                                    RoundedCornerShape(14.dp)
                                )
                                .padding(AureomSpacing.md)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = item.title,
                                            color = AureomColors.TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        Text(
                                            text = "${item.version} • Status: ${item.status.name}",
                                            color = when (item.status) {
                                                DownloadStatus.DOWNLOADING -> AureomColors.AureomGold
                                                DownloadStatus.PAUSED -> AureomColors.Warning
                                                else -> AureomColors.TextSecondary
                                            },
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                                        // Pause/Resume button
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(AureomColors.SurfaceDark)
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = if (item.status == DownloadStatus.DOWNLOADING) "PAUSE [A]" else "RESUME [A]",
                                                color = AureomColors.AureomGold,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }

                                        // Cancel button
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(AureomColors.SurfaceDark)
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = "CANCEL",
                                                color = AureomColors.Error,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }

                                // Progress Bar
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = AureomColors.AureomGold,
                                    trackColor = AureomColors.SurfaceDark
                                )

                                // Download Speed, Progress GB & ETA
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${"%.1f".format(downloadedGb)} GB / ${"%.1f".format(totalGb)} GB (${(progress * 100).toInt()}%)",
                                        color = AureomColors.TextSecondary,
                                        fontSize = 11.sp
                                    )
                                    if (item.status == DownloadStatus.DOWNLOADING) {
                                        Text(
                                            text = "${item.speedMbps} MB/s • ETA: ${item.etaSeconds / 60}m ${item.etaSeconds % 60}s",
                                            color = AureomColors.AureomGoldBright,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Completed Downloads Section
            if (completedDownloads.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(AureomSpacing.sm))
                    Text(
                        text = "RECENTLY INSTALLED (${completedDownloads.size})",
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }

                items(completedDownloads, key = { it.id }) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AureomColors.SurfaceDark)
                            .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
                            .padding(AureomSpacing.md),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Completed",
                                tint = AureomColors.Success,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(AureomSpacing.sm))
                            Column {
                                Text(
                                    text = item.title,
                                    color = AureomColors.TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Ready to play • ${"%.1f".format(item.totalBytes / (1024.0 * 1024.0 * 1024.0))} GB",
                                    color = AureomColors.TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Text(
                            text = "INSTALLED",
                            color = AureomColors.Success,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
