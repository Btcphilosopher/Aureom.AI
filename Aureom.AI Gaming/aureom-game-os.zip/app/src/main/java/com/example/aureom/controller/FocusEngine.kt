package com.example.aureom.controller

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.aureom.core.logging.AureomLogger
import java.util.Stack

enum class FocusDirection {
    UP, DOWN, LEFT, RIGHT, NEXT, PREVIOUS
}

data class FocusNode(
    val id: String,
    val groupId: String,
    val order: Int = 0,
    val onConfirm: () -> Unit = {},
    val onBack: () -> Unit = {},
    val onContextual: () -> Unit = {}
)

data class FocusGroup(
    val id: String,
    val parentGroupId: String? = null,
    val defaultNodeId: String? = null,
    val isHorizontal: Boolean = true
)

class FocusEngine {
    var currentFocusedId by mutableStateOf("hero_play")
        private set

    var currentFocusedGroup by mutableStateOf("hero_actions")
        private set

    private val nodes = mutableMapOf<String, FocusNode>()
    private val groups = mutableMapOf<String, FocusGroup>()
    private val groupNodes = mutableMapOf<String, MutableList<String>>()
    private val history = Stack<String>()
    private val savedGroupFocus = mutableMapOf<String, String>()

    fun registerGroup(group: FocusGroup) {
        groups[group.id] = group
        if (!groupNodes.containsKey(group.id)) {
            groupNodes[group.id] = mutableListOf()
        }
    }

    fun registerNode(node: FocusNode) {
        nodes[node.id] = node
        val list = groupNodes.getOrPut(node.groupId) { mutableListOf() }
        if (!list.contains(node.id)) {
            list.add(node.id)
            list.sortBy { nodes[it]?.order ?: 0 }
        }
    }

    fun unregisterNode(nodeId: String) {
        val node = nodes.remove(nodeId) ?: return
        groupNodes[node.groupId]?.remove(nodeId)
    }

    fun requestFocus(nodeId: String, addToHistory: Boolean = true) {
        val node = nodes[nodeId] ?: return
        if (currentFocusedId != nodeId && addToHistory) {
            history.push(currentFocusedId)
        }
        currentFocusedId = nodeId
        currentFocusedGroup = node.groupId
        savedGroupFocus[node.groupId] = nodeId
        AureomLogger.trace("FocusEngine", "Focus set to $nodeId in group ${node.groupId}")
    }

    fun restoreGroupFocus(groupId: String) {
        val lastFocusedNodeId = savedGroupFocus[groupId]
            ?: groups[groupId]?.defaultNodeId
            ?: groupNodes[groupId]?.firstOrNull()

        if (lastFocusedNodeId != null && nodes.containsKey(lastFocusedNodeId)) {
            requestFocus(lastFocusedNodeId, addToHistory = false)
        }
    }

    fun moveFocus(direction: FocusDirection): Boolean {
        val currentNode = nodes[currentFocusedId]
        val currentGroup = groups[currentFocusedGroup]

        if (currentNode == null) {
            val fallback = nodes.keys.firstOrNull() ?: return false
            requestFocus(fallback)
            return true
        }

        val siblings = groupNodes[currentNode.groupId] ?: emptyList()
        val currentIndex = siblings.indexOf(currentNode.id)

        when (direction) {
            FocusDirection.RIGHT, FocusDirection.NEXT -> {
                if (currentGroup?.isHorizontal != false && currentIndex >= 0 && currentIndex < siblings.size - 1) {
                    requestFocus(siblings[currentIndex + 1])
                    return true
                }
            }
            FocusDirection.LEFT, FocusDirection.PREVIOUS -> {
                if (currentGroup?.isHorizontal != false && currentIndex > 0) {
                    requestFocus(siblings[currentIndex - 1])
                    return true
                }
            }
            FocusDirection.DOWN -> {
                if (currentGroup?.isHorizontal == false && currentIndex >= 0 && currentIndex < siblings.size - 1) {
                    requestFocus(siblings[currentIndex + 1])
                    return true
                }
            }
            FocusDirection.UP -> {
                if (currentGroup?.isHorizontal == false && currentIndex > 0) {
                    requestFocus(siblings[currentIndex - 1])
                    return true
                }
            }
        }
        return false
    }

    fun triggerConfirm(): Boolean {
        val node = nodes[currentFocusedId] ?: return false
        node.onConfirm()
        return true
    }

    fun triggerBack(): Boolean {
        val node = nodes[currentFocusedId]
        if (node != null) {
            node.onBack()
        }
        if (history.isNotEmpty()) {
            val prev = history.pop()
            if (nodes.containsKey(prev)) {
                currentFocusedId = prev
                nodes[prev]?.let { currentFocusedGroup = it.groupId }
                return true
            }
        }
        return false
    }

    fun triggerContextual(): Boolean {
        val node = nodes[currentFocusedId] ?: return false
        node.onContextual()
        return true
    }
}

val LocalFocusEngine = compositionLocalOf { FocusEngine() }
