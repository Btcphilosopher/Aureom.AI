package com.example.aureom.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.domain.model.DownloadStatus
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.core.state.ConsoleRoute
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TopBar(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val appState by viewModel.appState.collectAsState()
    val user by viewModel.playerProfile.collectAsState()
    val downloads by viewModel.downloads.collectAsState()
    val activeParty by viewModel.activeParty.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val systemStatus by viewModel.systemStatus.collectAsState()

    val activeDownloadsCount = downloads.count { it.status == DownloadStatus.DOWNLOADING }
    val unreadNotifsCount = notifications.count { !it.isRead }

    var currentTimeString by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTimeString = sdf.format(Date())
            delay(1000)
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        // Offline Warning Banner
        AnimatedVisibility(visible = appState.isOfflineMode) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AureomColors.Warning)
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CloudOff,
                        contentDescription = "Offline Mode",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "OFFLINE MODE — Network services simulated offline. Local library available.",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AureomSpacing.lg, vertical = AureomSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Player Profile Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .testTag("topbar_profile_pill")
                    .clip(RoundedCornerShape(20.dp))
                    .background(AureomColors.SurfaceCardElevated.copy(alpha = 0.85f))
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(20.dp))
                    .clickable { viewModel.navigateTo(ConsoleRoute.PROFILE) }
                    .padding(horizontal = AureomSpacing.sm, vertical = AureomSpacing.xs)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(AureomColors.AureomGold),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = user.gamertag.take(1),
                        fontWeight = FontWeight.Black,
                        color = Color.Black,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(AureomSpacing.xs))
                Column {
                    Text(
                        text = user.gamertag,
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = "Gamerscore",
                            tint = AureomColors.AureomGold,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${user.gamerscore} G",
                            color = AureomColors.AureomGoldBright,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Center / Status Pill widgets
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(AureomSpacing.sm)
            ) {
                // Active Party Indicator
                if (activeParty != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(AureomColors.SurfaceCard.copy(alpha = 0.8f))
                            .border(1.dp, AureomColors.AureomCyanMuted, RoundedCornerShape(16.dp))
                            .clickable { viewModel.navigateTo(ConsoleRoute.SOCIAL) }
                            .padding(horizontal = AureomSpacing.sm, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AureomColors.AureomCyan)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.HeadsetMic,
                            contentDescription = "Party Voice",
                            tint = AureomColors.AureomCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${activeParty?.members?.size} in Party",
                            color = AureomColors.AureomCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Active Downloads Indicator
                if (activeDownloadsCount > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(AureomColors.SurfaceCard.copy(alpha = 0.8f))
                            .border(1.dp, AureomColors.AureomGoldMuted, RoundedCornerShape(16.dp))
                            .clickable { viewModel.navigateTo(ConsoleRoute.DOWNLOADS) }
                            .padding(horizontal = AureomSpacing.sm, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Active Downloads",
                            tint = AureomColors.AureomGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$activeDownloadsCount Downloading",
                            color = AureomColors.AureomGoldBright,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Right: Global Search, Notifications, Network, Controller, Time
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
            ) {
                // Global Search button [Y]
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AureomColors.SurfaceCard)
                        .clickable { viewModel.toggleSearch(true) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = AureomColors.TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .background(AureomColors.AureomGold, CircleShape)
                            .size(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Y",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 9.sp
                        )
                    }
                }

                // Notifications Bell
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AureomColors.SurfaceCard)
                        .clickable { viewModel.navigateTo(ConsoleRoute.SYSTEM) }
                        .padding(8.dp)
                ) {
                    Icon(
                        imageVector = if (unreadNotifsCount > 0) Icons.Default.NotificationsActive else Icons.Outlined.Notifications,
                        contentDescription = "Notifications",
                        tint = if (unreadNotifsCount > 0) AureomColors.AureomGold else AureomColors.TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Network Ping & NAT
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AureomColors.SurfaceCard)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (appState.isOfflineMode) Icons.Default.WifiOff else Icons.Default.Wifi,
                        contentDescription = "Network",
                        tint = if (appState.isOfflineMode) AureomColors.Error else AureomColors.Online,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (appState.isOfflineMode) "Offline" else "${systemStatus.pingMs}ms",
                        color = AureomColors.TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Controller Battery
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AureomColors.SurfaceCard)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = "Controller",
                        tint = AureomColors.AureomCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${systemStatus.controllerBatteryPercent}%",
                        color = AureomColors.TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // System Clock
                Text(
                    text = currentTimeString,
                    color = AureomColors.TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 6.dp)
                )
            }
        }
    }
}
