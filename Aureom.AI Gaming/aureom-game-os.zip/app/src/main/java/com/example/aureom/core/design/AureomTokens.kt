package com.example.aureom.core.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Aureom Game OS Canonical Design Tokens.
 * Strict spacing hierarchy: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128.
 */
object AureomSpacing {
    val xxs: Dp = 4.dp
    val xs: Dp = 8.dp
    val sm: Dp = 12.dp
    val md: Dp = 16.dp
    val lg: Dp = 24.dp
    val xl: Dp = 32.dp
    val xxl: Dp = 48.dp
    val huge: Dp = 64.dp
    val massive: Dp = 96.dp
    val epic: Dp = 128.dp
}

object AureomColors {
    // Deep Console Obsidian Canvas
    val Canvas = Color(0xFF07090E)
    val BackgroundElevated = Color(0xFF0E131F)
    val SurfaceDark = Color(0xFF141926)
    val SurfaceCard = Color(0xFF1B2234)
    val SurfaceCardElevated = Color(0xFF242D45)
    val SurfaceCardGlass = Color(0xCC182033)

    // Console Accents & Brand Gold/Cyan
    val AureomGold = Color(0xFFF5B700)
    val AureomGoldBright = Color(0xFFFFD152)
    val AureomGoldMuted = Color(0x99F5B700)
    val AureomCyan = Color(0xFF00E5FF)
    val AureomCyanMuted = Color(0x8000E5FF)
    val AureomAmber = Color(0xFFFF7A00)

    // Focus State Tokens (Controller Glow)
    val FocusBorder = Color(0xFFFFD152)
    val FocusGlow = Color(0x66FFD152)
    val FocusCyan = Color(0xFF38E1FF)

    // Typography Tokens
    val TextPrimary = Color(0xFFF3F5FA)
    val TextSecondary = Color(0xFF9EAABF)
    val TextTertiary = Color(0xFF5E6C87)
    val TextDisabled = Color(0xFF3D4657)
    val TextGold = Color(0xFFFFD152)

    // Semantic Status Tokens
    val Success = Color(0xFF00E676)
    val Warning = Color(0xFFFFAB00)
    val Error = Color(0xFFFF5252)
    val Info = Color(0xFF448AFF)
    val Online = Color(0xFF00E676)
    val InGame = Color(0xFF00E5FF)
    val Busy = Color(0xFFFFAB00)
    val Offline = Color(0xFF5E6C87)

    // Borders & Dividers
    val BorderSubtle = Color(0xFF222B3D)
    val BorderFocus = Color(0xFFFFD152)
    val Divider = Color(0xFF1E2638)
}

object AureomElevation {
    val flat: Dp = 0.dp
    val low: Dp = 2.dp
    val medium: Dp = 6.dp
    val high: Dp = 12.dp
    val focus: Dp = 16.dp
}
