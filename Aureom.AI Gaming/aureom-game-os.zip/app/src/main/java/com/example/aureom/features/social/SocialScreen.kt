package com.example.aureom.features.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.Friend
import com.example.aureom.domain.model.PartyMember
import com.example.aureom.domain.model.PresenceStatus
import kotlinx.coroutines.launch

@Composable
fun SocialScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val friends by viewModel.friends.collectAsState()
    val activeParty by viewModel.activeParty.collectAsState()
    val conversations by viewModel.conversations.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var selectedFriendId by remember { mutableStateOf("f_01") }
    var chatInputText by remember { mutableStateOf("") }

    val currentConversation = conversations.firstOrNull { it.friendId == selectedFriendId }
    val selectedFriend = friends.firstOrNull { it.id == selectedFriendId }

    Row(
        modifier = modifier
            .testTag("social_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg, vertical = AureomSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.lg)
    ) {
        // Left Column: Friends List & Active Party (40% width)
        Column(
            modifier = Modifier
                .weight(0.42f)
                .fillMaxHeight()
        ) {
            Text(
                text = "FRIENDS & SQUAD",
                color = AureomColors.TextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 22.sp,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = "${friends.count { it.presence != PresenceStatus.OFFLINE }} friends online",
                color = AureomColors.TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(AureomSpacing.sm))

            // Active Party Card
            if (activeParty != null) {
                val party = activeParty!!
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(AureomColors.SurfaceCardElevated)
                        .border(1.dp, AureomColors.AureomCyan, RoundedCornerShape(12.dp))
                        .padding(AureomSpacing.md)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.HeadsetMic,
                                    contentDescription = "Voice",
                                    tint = AureomColors.AureomCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = party.title,
                                    color = AureomColors.AureomCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Text(
                                text = "LEAVE",
                                color = AureomColors.Error,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .clickable { coroutineScope.launch { viewModel.backend.leaveParty() } }
                                    .padding(4.dp)
                            )
                        }

                        party.members.forEach { member ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (member.isTalking) AureomColors.Success else AureomColors.TextTertiary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = member.gamertag,
                                        color = AureomColors.TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = if (member.isLeader) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                                Icon(
                                    imageVector = if (member.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                    contentDescription = "Mute",
                                    tint = if (member.isMuted) AureomColors.Error else AureomColors.TextSecondary,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable {
                                            coroutineScope.launch { viewModel.backend.toggleMuteMember(member.playerId) }
                                        }
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(AureomSpacing.sm))
            }

            // Friends List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs),
                modifier = Modifier.fillMaxSize()
            ) {
                items(friends, key = { it.id }) { friend ->
                    val isSelected = friend.id == selectedFriendId
                    ConsoleFocusable(
                        nodeId = "friend_${friend.id}",
                        groupId = "friends_list",
                        onClick = { selectedFriendId = friend.id },
                        shape = RoundedCornerShape(10.dp)
                    ) { isFocused ->
                        Row(
                            modifier = Modifier
                                .testTag("friend_item_${friend.id}")
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) AureomColors.SurfaceCardElevated
                                    else if (isFocused) AureomColors.SurfaceCard
                                    else AureomColors.SurfaceDark
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) AureomColors.AureomGold else AureomColors.BorderSubtle,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(AureomSpacing.sm),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (friend.presence) {
                                                PresenceStatus.IN_GAME -> AureomColors.AureomCyan
                                                PresenceStatus.ONLINE -> AureomColors.Success
                                                PresenceStatus.BUSY -> AureomColors.Warning
                                                PresenceStatus.OFFLINE -> AureomColors.SurfaceCard
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = friend.gamertag.take(1),
                                        color = Color.Black,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(AureomSpacing.sm))
                                Column {
                                    Text(
                                        text = friend.gamertag,
                                        color = AureomColors.TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = when (friend.presence) {
                                            PresenceStatus.IN_GAME -> "Playing ${friend.currentGameTitle}"
                                            PresenceStatus.ONLINE -> "Online"
                                            PresenceStatus.BUSY -> "Busy"
                                            PresenceStatus.OFFLINE -> "Offline • ${friend.lastOnline ?: "long ago"}"
                                        },
                                        color = when (friend.presence) {
                                            PresenceStatus.IN_GAME -> AureomColors.AureomCyan
                                            PresenceStatus.ONLINE -> AureomColors.Success
                                            else -> AureomColors.TextTertiary
                                        },
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Quick Invite Button
                            if (friend.presence != PresenceStatus.OFFLINE) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(AureomColors.SurfaceCard)
                                        .clickable {
                                            coroutineScope.launch { viewModel.backend.sendPartyInvite(friend.id) }
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "INVITE",
                                        color = AureomColors.AureomGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Chat & Profile Viewer (58% width)
        Column(
            modifier = Modifier
                .weight(0.58f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(AureomColors.SurfaceCard)
                .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(16.dp))
                .padding(AureomSpacing.md),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Friend Chat Header
            if (selectedFriend != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = selectedFriend.gamertag,
                            color = AureomColors.TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "${selectedFriend.gamerscore} G • ${selectedFriend.realName}",
                            color = AureomColors.AureomGoldBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AureomColors.AureomGold)
                                .clickable {
                                    coroutineScope.launch { viewModel.backend.sendPartyInvite(selectedFriend.id) }
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "INVITE TO PARTY",
                                color = Color.Black,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                HorizontalDivider(
                    color = AureomColors.BorderSubtle,
                    modifier = Modifier.padding(vertical = AureomSpacing.xs)
                )

                // Message Thread
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs),
                    reverseLayout = false
                ) {
                    val messages = currentConversation?.messages ?: emptyList()
                    if (messages.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No prior messages. Send a message to start party coordination.",
                                    color = AureomColors.TextTertiary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    } else {
                        items(messages, key = { it.id }) { msg ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (msg.isIncoming) Arrangement.Start else Arrangement.End
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(
                                            RoundedCornerShape(
                                                topStart = 12.dp,
                                                topEnd = 12.dp,
                                                bottomStart = if (msg.isIncoming) 2.dp else 12.dp,
                                                bottomEnd = if (msg.isIncoming) 12.dp else 2.dp
                                            )
                                        )
                                        .background(
                                            if (msg.isIncoming) AureomColors.SurfaceCardElevated else AureomColors.AureomGold
                                        )
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .widthIn(max = 340.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = msg.senderGamertag,
                                            color = if (msg.isIncoming) AureomColors.AureomCyan else Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                        Text(
                                            text = msg.text,
                                            color = if (msg.isIncoming) AureomColors.TextPrimary else Color.Black,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = msg.timestamp,
                                            color = if (msg.isIncoming) AureomColors.TextTertiary else Color.Black.copy(alpha = 0.6f),
                                            fontSize = 9.sp,
                                            modifier = Modifier.align(Alignment.End)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick Phrases & Message Input
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Quick Phrases
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Ready to play!", "Joining in 2 mins", "Inv me to party!").forEach { phrase ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AureomColors.SurfaceDark)
                                    .clickable {
                                        coroutineScope.launch {
                                            viewModel.backend.sendMessage(selectedFriend.id, phrase)
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = phrase,
                                    color = AureomColors.TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Input Box
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AureomColors.SurfaceDark)
                            .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
                            .padding(horizontal = AureomSpacing.sm, vertical = 4.dp)
                    ) {
                        TextField(
                            value = chatInputText,
                            onValueChange = { chatInputText = it },
                            placeholder = { Text("Type message or press [Y] for virtual keyboard...", fontSize = 12.sp) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = AureomColors.TextPrimary,
                                unfocusedTextColor = AureomColors.TextPrimary,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                if (chatInputText.isNotBlank()) {
                                    coroutineScope.launch {
                                        viewModel.backend.sendMessage(selectedFriend.id, chatInputText)
                                        chatInputText = ""
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = AureomColors.AureomGold
                            )
                        }
                    }
                }
            }
        }
    }
}
