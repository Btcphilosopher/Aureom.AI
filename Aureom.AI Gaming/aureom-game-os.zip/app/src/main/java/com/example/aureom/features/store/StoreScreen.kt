package com.example.aureom.features.store

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.StoreProduct
import kotlinx.coroutines.launch

@Composable
fun StoreScreen(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val storeProducts by viewModel.storeProducts.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var selectedCategory by remember { mutableStateOf("ALL") }

    val categories = listOf("ALL", "Featured", "AAA", "Indie", "New Releases", "Deals", "Subscriptions", "Free to Play")

    val filteredProducts = remember(storeProducts, selectedCategory) {
        if (selectedCategory == "ALL") storeProducts
        else storeProducts.filter { it.category.contains(selectedCategory, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .testTag("store_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg)
    ) {
        // Store Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.sm),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AUREOM STORE",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Next-gen games, season passes & expansions",
                    color = AureomColors.TextSecondary,
                    fontSize = 13.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomColors.AureomGold.copy(alpha = 0.2f))
                    .border(1.dp, AureomColors.AureomGold, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Pass",
                        tint = AureomColors.AureomGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AUREOM PASS ACTIVE",
                        color = AureomColors.AureomGoldBright,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // Category Filter Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = AureomSpacing.xs),
            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.xs)
        ) {
            categories.forEach { cat ->
                val isSelected = selectedCategory == cat
                ConsoleFocusable(
                    nodeId = "store_cat_$cat",
                    groupId = "store_categories",
                    onClick = { selectedCategory = cat },
                    shape = RoundedCornerShape(8.dp)
                ) { isFocused ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) AureomColors.AureomGold
                                else if (isFocused) AureomColors.SurfaceCardElevated
                                else AureomColors.SurfaceDark
                            )
                            .border(
                                1.dp,
                                if (isSelected) AureomColors.AureomGoldBright else AureomColors.BorderSubtle,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat.uppercase(),
                            color = if (isSelected) Color.Black else AureomColors.TextPrimary,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(AureomSpacing.sm))

        // Store Products Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 220.dp),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.md),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
            items(filteredProducts, key = { it.id }) { product ->
                ConsoleFocusable(
                    nodeId = "product_${product.id}",
                    groupId = "store_products",
                    onClick = {
                        if (!product.isOwned) {
                            coroutineScope.launch { viewModel.backend.purchaseProduct(product.id) }
                        }
                    },
                    shape = RoundedCornerShape(14.dp)
                ) { isFocused ->
                    Box(
                        modifier = Modifier
                            .testTag("store_product_${product.id}")
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        AureomColors.SurfaceCardElevated,
                                        AureomColors.SurfaceDark
                                    )
                                )
                            )
                            .border(
                                1.dp,
                                if (isFocused) AureomColors.AureomGold else AureomColors.BorderSubtle,
                                RoundedCornerShape(14.dp)
                            )
                            .padding(AureomSpacing.md)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                // Badge & Rating
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (product.badge != null) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(AureomColors.AureomGold)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = product.badge,
                                                color = Color.Black,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.width(1.dp))
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "Rating",
                                            tint = AureomColors.AureomGold,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = "${product.rating}",
                                            color = AureomColors.TextSecondary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(AureomSpacing.sm))

                                Text(
                                    text = product.title,
                                    color = if (isFocused) AureomColors.AureomGoldBright else AureomColors.TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    text = product.subtitle,
                                    color = AureomColors.TextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "${product.publisher} • ${product.sizeGb} GB",
                                    color = AureomColors.TextTertiary,
                                    fontSize = 11.sp
                                )
                            }

                            // Price and Purchase Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    if (product.discountPercent > 0) {
                                        Text(
                                            text = "$${product.price}",
                                            color = AureomColors.TextTertiary,
                                            fontSize = 11.sp,
                                            style = androidx.compose.ui.text.TextStyle(
                                                textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                            )
                                        )
                                    }
                                    Text(
                                        text = product.formattedPrice,
                                        color = AureomColors.AureomGoldBright,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (product.isOwned) AureomColors.Success
                                            else if (isFocused) AureomColors.AureomGoldBright
                                            else AureomColors.AureomGold
                                        )
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (product.isOwned) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Owned",
                                                tint = Color.Black,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "IN LIBRARY",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 11.sp
                                            )
                                        } else {
                                            Text(
                                                text = "BUY [A]",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
