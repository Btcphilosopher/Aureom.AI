package com.example.aureom.platform.websocket

import com.example.aureom.core.logging.AureomLogger
import com.example.aureom.domain.model.AureomNotification
import com.example.aureom.domain.model.NotificationType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

sealed class RealtimeEvent {
    data class PresenceChanged(val friendId: String, val gamertag: String, val isOnline: Boolean, val game: String?) : RealtimeEvent()
    data class FriendRequest(val requesterId: String, val gamertag: String) : RealtimeEvent()
    data class PartyInvite(val partyId: String, val senderGamertag: String) : RealtimeEvent()
    data class AchievementUnlocked(val achievementId: String, val title: String, val score: Int) : RealtimeEvent()
    data class DownloadProgress(val downloadId: String, val percent: Float, val speedMbps: Float) : RealtimeEvent()
    data class GameUpdated(val gameId: String, val version: String) : RealtimeEvent()
    data class NotificationCreated(val notification: AureomNotification) : RealtimeEvent()
    data class MessageReceived(val friendId: String, val text: String) : RealtimeEvent()
    data class SystemStatusChanged(val natType: String, val pingMs: Int) : RealtimeEvent()
}

class AureomRealtimeClient(private val scope: CoroutineScope) {
    private val _events = MutableSharedFlow<RealtimeEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<RealtimeEvent> = _events.asSharedFlow()

    private var isConnected = true

    init {
        AureomLogger.info("AureomRealtimeClient", "Connected to wss://realtime.aureom.os/events")
        startHeartbeatSimulation()
    }

    fun postEvent(event: RealtimeEvent) {
        AureomLogger.trace("AureomRealtimeClient", "Dispatched: $event")
        _events.tryEmit(event)
    }

    private fun startHeartbeatSimulation() {
        scope.launch {
            while (isConnected) {
                delay(30000) // Periodic live server presence update
                postEvent(
                    RealtimeEvent.PresenceChanged(
                        friendId = "f_02",
                        gamertag = "GhostBlade99",
                        isOnline = true,
                        game = "NORTHLINE"
                    )
                )
            }
        }
    }
}
