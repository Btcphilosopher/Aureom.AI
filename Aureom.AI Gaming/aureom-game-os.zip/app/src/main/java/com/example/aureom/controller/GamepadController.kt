package com.example.aureom.controller

import android.view.KeyEvent
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import com.example.aureom.core.logging.AureomLogger

sealed class GamepadEvent {
    object ButtonA : GamepadEvent() // Confirm
    object ButtonB : GamepadEvent() // Back / Cancel
    object ButtonX : GamepadEvent() // Contextual action / Details
    object ButtonY : GamepadEvent() // Global search / Filter
    object DpadUp : GamepadEvent()
    object DpadDown : GamepadEvent()
    object DpadLeft : GamepadEvent()
    object DpadRight : GamepadEvent()
    object LeftShoulder : GamepadEvent() // Prev tab
    object RightShoulder : GamepadEvent() // Next tab
    object MenuButton : GamepadEvent() // System Quick Menu / Guide
    object ViewButton : GamepadEvent() // Secondary Navigation
}

class GamepadController(private val focusEngine: FocusEngine) {

    fun handleGamepadEvent(event: GamepadEvent): Boolean {
        AureomLogger.debug("GamepadController", "Event: $event")
        return when (event) {
            GamepadEvent.ButtonA -> focusEngine.triggerConfirm()
            GamepadEvent.ButtonB -> focusEngine.triggerBack()
            GamepadEvent.ButtonX -> focusEngine.triggerContextual()
            GamepadEvent.DpadUp -> focusEngine.moveFocus(FocusDirection.UP)
            GamepadEvent.DpadDown -> focusEngine.moveFocus(FocusDirection.DOWN)
            GamepadEvent.DpadLeft -> focusEngine.moveFocus(FocusDirection.LEFT)
            GamepadEvent.DpadRight -> focusEngine.moveFocus(FocusDirection.RIGHT)
            else -> false
        }
    }

    fun handleComposeKeyEvent(keyEvent: androidx.compose.ui.input.key.KeyEvent): Boolean {
        if (keyEvent.type != KeyEventType.KeyDown) return false

        return when (keyEvent.key) {
            Key.DirectionUp -> handleGamepadEvent(GamepadEvent.DpadUp)
            Key.DirectionDown -> handleGamepadEvent(GamepadEvent.DpadDown)
            Key.DirectionLeft -> handleGamepadEvent(GamepadEvent.DpadLeft)
            Key.DirectionRight -> handleGamepadEvent(GamepadEvent.DpadRight)
            Key.Enter, Key.NumPadEnter, Key.Spacebar -> handleGamepadEvent(GamepadEvent.ButtonA)
            Key.Escape, Key.Back -> handleGamepadEvent(GamepadEvent.ButtonB)
            Key.Tab -> focusEngine.moveFocus(FocusDirection.NEXT)
            Key.F -> handleGamepadEvent(GamepadEvent.ButtonY)
            else -> false
        }
    }
}
