package com.example.aureom.features.game

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.components.ConsoleFocusable
import com.example.aureom.components.GameCard
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.domain.model.EntitlementType
import com.example.aureom.domain.model.GamePlayState
import kotlinx.coroutines.launch

@Composable
fun GameDetailsScreen(
    gameId: String,
    viewModel: AureomAppViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val games by viewModel.games.collectAsState()
    val achievements by viewModel.achievements.collectAsState()
    val friends by viewModel.friends.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    val game = games.firstOrNull { it.id == gameId } ?: games.firstOrNull()

    if (game == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Game not found", color = AureomColors.TextSecondary)
        }
        return
    }

    val gameAchievements = achievements.filter { it.gameId == game.id }
    val friendsPlaying = friends.filter { it.currentGameTitle == game.title }
    val relatedGames = games.filter { it.genre == game.genre && it.id != game.id }.take(5)

    val accent = try {
        Color(android.graphics.Color.parseColor(game.accentColorHex))
    } catch (_: Exception) {
        AureomColors.AureomGold
    }

    LazyColumn(
        modifier = modifier
            .testTag("game_details_screen")
            .fillMaxSize()
            .padding(horizontal = AureomSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(AureomSpacing.lg),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        // Back Navigation Bar
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = AureomSpacing.sm)
            ) {
                ConsoleFocusable(
                    nodeId = "details_back",
                    groupId = "details_nav",
                    onClick = onBack,
                    shape = RoundedCornerShape(8.dp)
                ) { isFocused ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isFocused) AureomColors.SurfaceCardElevated else AureomColors.SurfaceDark)
                            .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = AureomColors.TextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "BACK [B]",
                            color = AureomColors.TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Cinematic Hero Visual Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                accent.copy(alpha = 0.45f),
                                AureomColors.SurfaceCardElevated,
                                AureomColors.Canvas
                            )
                        )
                    )
                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(20.dp))
                    .padding(AureomSpacing.xl)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Developer and Rating Tag
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AureomColors.SurfaceCard)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${game.developer} • ${game.releaseYear}",
                                color = AureomColors.AureomGoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AureomColors.SurfaceDark)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = game.ageRating,
                                color = AureomColors.TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Text(
                            text = "Rating: ★ ${game.rating}",
                            color = AureomColors.AureomGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Title & Description
                    Column {
                        Text(
                            text = game.title,
                            color = AureomColors.TextPrimary,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = game.tagline,
                            color = AureomColors.AureomGoldBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(AureomSpacing.xs))
                        Text(
                            text = game.description,
                            color = AureomColors.TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 3
                        )
                    }

                    // Action Buttons (Play / Install, Favorite, DLC)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (game.isInstalled) {
                            ConsoleFocusable(
                                nodeId = "details_play",
                                groupId = "details_actions",
                                onClick = { viewModel.launchGame(game.id) },
                                shape = RoundedCornerShape(12.dp)
                            ) { isFocused ->
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isFocused) AureomColors.AureomGoldBright else AureomColors.AureomGold)
                                        .padding(horizontal = 24.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "PLAY NOW [A]",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        } else {
                            ConsoleFocusable(
                                nodeId = "details_install",
                                groupId = "details_actions",
                                onClick = {
                                    coroutineScope.launch { viewModel.backend.installGame(game.id) }
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) { isFocused ->
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isFocused) AureomColors.AureomCyan else AureomColors.AureomCyanMuted)
                                        .padding(horizontal = 24.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = "Install", tint = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "INSTALL (${game.sizeGb} GB)",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }

                        // Favorite toggle
                        ConsoleFocusable(
                            nodeId = "details_fav",
                            groupId = "details_actions",
                            onClick = {
                                coroutineScope.launch { viewModel.backend.toggleFavorite(game.id) }
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) { isFocused ->
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isFocused) AureomColors.SurfaceCardElevated else AureomColors.SurfaceCard)
                                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (game.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (game.isFavorite) AureomColors.Error else AureomColors.TextSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (game.isFavorite) "Favorited" else "Favorite",
                                    color = AureomColors.TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Hardware & Technical Capabilities
        item {
            Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                Text(
                    text = "TECHNICAL CAPABILITIES",
                    color = AureomColors.TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(AureomSpacing.sm),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    game.supportedFeatures.forEach { feature ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AureomColors.SurfaceCard)
                                .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = feature,
                                color = AureomColors.AureomCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Achievements Preview
        if (gameAchievements.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACHIEVEMENTS (${gameAchievements.count { it.isUnlocked }}/${gameAchievements.size})",
                            color = AureomColors.TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                        gameAchievements.forEach { ach ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AureomColors.SurfaceCard)
                                    .border(1.dp, AureomColors.BorderSubtle, RoundedCornerShape(10.dp))
                                    .padding(AureomSpacing.sm),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = "Achievement",
                                        tint = if (ach.isUnlocked) AureomColors.AureomGold else AureomColors.TextDisabled,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(AureomSpacing.sm))
                                    Column {
                                        Text(
                                            text = ach.title,
                                            color = if (ach.isUnlocked) AureomColors.TextPrimary else AureomColors.TextTertiary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = ach.description,
                                            color = AureomColors.TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Text(
                                    text = "${ach.gamerscore} G",
                                    color = AureomColors.AureomGoldBright,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // DLC & Add-ons
        if (game.dlcList.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs)) {
                    Text(
                        text = "ADD-ONS & DLC",
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )

                    game.dlcList.forEach { dlc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(AureomColors.SurfaceCard)
                                .padding(AureomSpacing.sm),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = dlc.title,
                                color = AureomColors.TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (dlc.isOwned) "OWNED" else dlc.priceFormatted,
                                color = if (dlc.isOwned) AureomColors.Success else AureomColors.AureomGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Related Titles
        if (relatedGames.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(AureomSpacing.sm)) {
                    Text(
                        text = "RELATED TITLES IN ${game.genre.uppercase()}",
                        color = AureomColors.TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(AureomSpacing.md)) {
                        items(relatedGames) { related ->
                            GameCard(
                                game = related,
                                groupId = "related_games",
                                onClick = { viewModel.setSelectedGame(related.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}
