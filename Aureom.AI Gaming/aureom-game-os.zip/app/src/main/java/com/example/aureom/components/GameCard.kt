package com.example.aureom.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timelapse
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.domain.model.EntitlementType
import com.example.aureom.domain.model.Game
import com.example.aureom.domain.model.GamePlayState

@Composable
fun GameCard(
    game: Game,
    onClick: () -> Unit,
    groupId: String,
    modifier: Modifier = Modifier,
    cardWidth: Dp = 190.dp,
    cardHeight: Dp = 250.dp,
    onContextual: () -> Unit = {}
) {
    val accent = try {
        Color(android.graphics.Color.parseColor(game.accentColorHex))
    } catch (_: Exception) {
        AureomColors.AureomGold
    }

    ConsoleFocusable(
        nodeId = "game_${game.id}",
        groupId = groupId,
        onClick = onClick,
        onContextual = onContextual,
        modifier = modifier
            .testTag("game_card_${game.id}")
            .width(cardWidth)
            .height(cardHeight),
        shape = RoundedCornerShape(14.dp)
    ) { isFocused ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            accent.copy(alpha = if (isFocused) 0.45f else 0.25f),
                            AureomColors.SurfaceCardElevated,
                            AureomColors.SurfaceDark
                        )
                    )
                )
        ) {
            // Artwork placeholder / synthetic abstract graphic
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                accent.copy(alpha = 0.4f),
                                Color.Black.copy(alpha = 0.8f)
                            )
                        )
                    )
                    .padding(AureomSpacing.sm)
            ) {
                // Top Tag: Entitlement or Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (game.entitlement) {
                        EntitlementType.SUBSCRIPTION_PASS -> {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AureomColors.AureomCyan)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PASS",
                                    color = Color.Black,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        EntitlementType.FREE_TO_PLAY -> {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AureomColors.Success)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "FREE",
                                    color = Color.Black,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        else -> {
                            if (game.isQuickResumeCapable && game.isInstalled) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(AureomColors.SurfaceCard.copy(alpha = 0.8f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "QUICK RESUME",
                                        color = AureomColors.TextGold,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (isFocused) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Ready",
                            tint = AureomColors.AureomGoldBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Card Content Metadata
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 115.dp)
                    .padding(horizontal = AureomSpacing.sm, vertical = AureomSpacing.xs),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = game.title,
                        color = if (isFocused) AureomColors.AureomGoldBright else AureomColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = game.genre,
                        color = AureomColors.TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Download or Achievements bar
                if (game.playState == GamePlayState.DOWNLOADING) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Downloading...",
                                color = AureomColors.AureomGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${(game.currentDownloadPercent * 100).toInt()}%",
                                color = AureomColors.AureomGoldBright,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { game.currentDownloadPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = AureomColors.AureomGold,
                            trackColor = AureomColors.SurfaceDark
                        )
                    }
                } else {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Timelapse,
                                    contentDescription = "Playtime",
                                    tint = AureomColors.TextTertiary,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${game.playtimeMinutes / 60}h",
                                    color = AureomColors.TextSecondary,
                                    fontSize = 10.sp
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = "Achievements",
                                    tint = AureomColors.AureomGold,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${game.unlockedAchievements}/${game.totalAchievements}",
                                    color = AureomColors.AureomGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
