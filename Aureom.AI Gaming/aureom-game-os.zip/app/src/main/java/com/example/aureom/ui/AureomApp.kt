package com.example.aureom.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.aureom.components.*
import com.example.aureom.controller.FocusEngine
import com.example.aureom.controller.GamepadController
import com.example.aureom.controller.LocalFocusEngine
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.state.AureomAppViewModel
import com.example.aureom.core.state.ConsoleRoute
import com.example.aureom.features.achievements.AchievementsScreen
import com.example.aureom.features.developer.DeveloperScreen
import com.example.aureom.features.downloads.DownloadManagerScreen
import com.example.aureom.features.game.GameDetailsScreen
import com.example.aureom.features.game.GameRuntimeOverlay
import com.example.aureom.features.home.HomeScreen
import com.example.aureom.features.library.LibraryScreen
import com.example.aureom.features.profile.ProfileScreen
import com.example.aureom.features.search.SearchOverlayScreen
import com.example.aureom.features.settings.SettingsScreen
import com.example.aureom.features.social.SocialScreen
import com.example.aureom.features.store.StoreScreen
import com.example.aureom.features.system.SystemScreen
import com.example.aureom.graphics.DynamicBackground

@Composable
fun AureomApp(
    viewModel: AureomAppViewModel,
    modifier: Modifier = Modifier
) {
    val focusEngine = remember { FocusEngine() }
    val gamepadController = remember(focusEngine) { GamepadController(focusEngine) }
    val appState by viewModel.appState.collectAsState()
    val games by viewModel.games.collectAsState()

    var activeDetailGameId by remember { mutableStateOf<String?>(null) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    val selectedGame = remember(games, appState.selectedGameId) {
        games.firstOrNull { it.id == appState.selectedGameId } ?: games.firstOrNull()
    }

    val accentColor = remember(selectedGame) {
        try {
            Color(android.graphics.Color.parseColor(selectedGame?.accentColorHex ?: "#F5B700"))
        } catch (_: Exception) {
            AureomColors.AureomGold
        }
    }

    CompositionLocalProvider(LocalFocusEngine provides focusEngine) {
        Box(
            modifier = modifier
                .testTag("aureom_app_root")
                .fillMaxSize()
                .background(AureomColors.Canvas)
                .focusRequester(focusRequester)
                .focusable()
                .onKeyEvent { event ->
                    gamepadController.handleComposeKeyEvent(event)
                }
        ) {
            // 1. Dynamic Canvas Ambient Background
            DynamicBackground(accentColor = accentColor)

            // 2. Main Console Layout: TopBar + (NavigationRail + Content)
            Column(modifier = Modifier.fillMaxSize()) {
                TopBar(viewModel = viewModel)

                Row(modifier = Modifier.fillMaxSize()) {
                    // Navigation Rail on the Left
                    AureomNavigationRail(
                        currentRoute = appState.currentRoute,
                        onNavigate = { route ->
                            activeDetailGameId = null
                            viewModel.navigateTo(route)
                        },
                        isDevModeEnabled = appState.isDevModeEnabled
                    )

                    // Main Content Area
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (activeDetailGameId != null) {
                            GameDetailsScreen(
                                gameId = activeDetailGameId!!,
                                viewModel = viewModel,
                                onBack = { activeDetailGameId = null }
                            )
                        } else {
                            Crossfade(
                                targetState = appState.currentRoute,
                                label = "consoleScreenFade"
                            ) { route ->
                                when (route) {
                                    ConsoleRoute.HOME -> HomeScreen(
                                        viewModel = viewModel,
                                        onNavigateToGameDetails = { activeDetailGameId = it }
                                    )
                                    ConsoleRoute.LIBRARY -> LibraryScreen(
                                        viewModel = viewModel,
                                        onNavigateToGameDetails = { activeDetailGameId = it }
                                    )
                                    ConsoleRoute.STORE -> StoreScreen(viewModel = viewModel)
                                    ConsoleRoute.SOCIAL -> SocialScreen(viewModel = viewModel)
                                    ConsoleRoute.ACHIEVEMENTS -> AchievementsScreen(viewModel = viewModel)
                                    ConsoleRoute.PROFILE -> ProfileScreen(viewModel = viewModel)
                                    ConsoleRoute.SETTINGS -> SettingsScreen(viewModel = viewModel)
                                    ConsoleRoute.SYSTEM -> SystemScreen(viewModel = viewModel)
                                    ConsoleRoute.DOWNLOADS -> DownloadManagerScreen(viewModel = viewModel)
                                    ConsoleRoute.DEVELOPER -> DeveloperScreen(viewModel = viewModel)
                                }
                            }
                        }
                    }
                }
            }

            // 3. Search Overlay
            if (appState.isSearchOpen) {
                SearchOverlayScreen(
                    viewModel = viewModel,
                    onNavigateToGame = { gameId ->
                        activeDetailGameId = gameId
                    }
                )
            }

            // 4. Game Launching Transition Modal
            LaunchTransitionOverlay(
                isLaunching = appState.isGameLaunching,
                gameTitle = selectedGame?.title
            )

            // 5. Game Active Runtime Viewport Simulation
            if (appState.activeRunningGame != null) {
                GameRuntimeOverlay(
                    game = appState.activeRunningGame!!,
                    viewModel = viewModel
                )
            }

            // 6. Non-intrusive Overlay Toast Notifications
            NotificationOverlay(
                notification = appState.overlayNotification,
                onAction = {
                    val notif = appState.overlayNotification
                    viewModel.dismissOverlayNotification()
                    if (notif?.type == com.example.aureom.domain.model.NotificationType.ACHIEVEMENT) {
                        viewModel.navigateTo(ConsoleRoute.ACHIEVEMENTS)
                    } else if (notif?.type == com.example.aureom.domain.model.NotificationType.PARTY_INVITE) {
                        viewModel.navigateTo(ConsoleRoute.SOCIAL)
                    }
                },
                onDismiss = { viewModel.dismissOverlayNotification() },
                modifier = Modifier.align(Alignment.TopEnd)
            )

            // 7. Developer Performance HUD
            if (appState.showDebugOverlay) {
                DebugOverlay(
                    viewModel = viewModel,
                    modifier = Modifier.align(Alignment.BottomEnd)
                )
            }
        }
    }
}
