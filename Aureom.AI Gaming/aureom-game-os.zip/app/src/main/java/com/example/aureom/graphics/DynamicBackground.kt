package com.example.aureom.graphics

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.aureom.core.design.AureomColors

object AureomMotion {
    val FocusSpring = spring<Float>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    val FastTransition = tween<Float>(
        durationMillis = 220,
        easing = FastOutSlowInEasing
    )

    val RouteTransitionDuration = 250
}

@Composable
fun DynamicBackground(
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Base obsidian console canvas
        drawRect(color = AureomColors.Canvas)

        // Radial atmospheric glow behind featured game/upper-right zone
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentColor.copy(alpha = 0.18f),
                    accentColor.copy(alpha = 0.05f),
                    Color.Transparent
                ),
                center = Offset(width * 0.75f, height * 0.25f),
                radius = width * 0.65f
            )
        )

        // Secondary subtle ambient floor glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    AureomColors.AureomGold.copy(alpha = 0.08f),
                    Color.Transparent
                ),
                center = Offset(width * 0.2f, height * 0.85f),
                radius = width * 0.5f
            )
        )
    }
}
