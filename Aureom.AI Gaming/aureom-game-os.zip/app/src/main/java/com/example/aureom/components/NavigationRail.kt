package com.example.aureom.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.core.design.AureomColors
import com.example.aureom.core.design.AureomSpacing
import com.example.aureom.core.state.ConsoleRoute

data class NavItem(
    val route: ConsoleRoute,
    val icon: ImageVector,
    val label: String
)

@Composable
fun AureomNavigationRail(
    currentRoute: ConsoleRoute,
    onNavigate: (ConsoleRoute) -> Unit,
    isDevModeEnabled: Boolean = false,
    modifier: Modifier = Modifier
) {
    val navItems = buildList {
        add(NavItem(ConsoleRoute.HOME, Icons.Default.Home, "HOME"))
        add(NavItem(ConsoleRoute.LIBRARY, Icons.Default.VideogameAsset, "MY GAMES"))
        add(NavItem(ConsoleRoute.STORE, Icons.Default.ShoppingBag, "STORE"))
        add(NavItem(ConsoleRoute.SOCIAL, Icons.Default.Groups, "SOCIAL"))
        add(NavItem(ConsoleRoute.ACHIEVEMENTS, Icons.Default.EmojiEvents, "ACHIEVEMENTS"))
        add(NavItem(ConsoleRoute.PROFILE, Icons.Default.Person, "PROFILE"))
        add(NavItem(ConsoleRoute.SETTINGS, Icons.Default.Settings, "SETTINGS"))
        add(NavItem(ConsoleRoute.SYSTEM, Icons.Default.Dns, "SYSTEM"))
        if (isDevModeEnabled) {
            add(NavItem(ConsoleRoute.DEVELOPER, Icons.Default.Terminal, "DEV MODE"))
        }
    }

    Column(
        modifier = modifier
            .width(108.dp)
            .fillMaxHeight()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        AureomColors.Canvas.copy(alpha = 0.95f),
                        AureomColors.SurfaceDark.copy(alpha = 0.85f)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = AureomColors.BorderSubtle,
                shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            )
            .padding(vertical = AureomSpacing.md),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Platform Crest / Brand Pill
        Box(
            modifier = Modifier
                .padding(bottom = AureomSpacing.md)
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AureomColors.SurfaceCardElevated)
                .border(1.5.dp, AureomColors.AureomGold, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "AU",
                color = AureomColors.AureomGold,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(AureomSpacing.xs))

        // Navigation Items
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(AureomSpacing.xs),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            navItems.forEach { item ->
                val isSelected = currentRoute == item.route

                val backgroundColor by animateColorAsState(
                    targetValue = if (isSelected) AureomColors.AureomGold.copy(alpha = 0.2f) else Color.Transparent,
                    label = "navBg"
                )
                val iconTint by animateColorAsState(
                    targetValue = if (isSelected) AureomColors.AureomGold else AureomColors.TextSecondary,
                    label = "navIcon"
                )

                ConsoleFocusable(
                    nodeId = "nav_${item.route.routeId}",
                    groupId = "navigation_rail",
                    onClick = { onNavigate(item.route) },
                    modifier = Modifier.fillMaxWidth(0.9f),
                    shape = RoundedCornerShape(12.dp)
                ) { isFocused ->
                    Column(
                        modifier = Modifier
                            .testTag("nav_item_${item.route.routeId}")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isFocused) AureomColors.SurfaceCardElevated else backgroundColor
                            )
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = if (isFocused) AureomColors.AureomGoldBright else iconTint,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.label,
                            color = if (isSelected || isFocused) AureomColors.TextPrimary else AureomColors.TextTertiary,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
