package com.example.aureom.core.logging

import android.util.Log
import androidx.compose.runtime.mutableStateListOf

enum class AureomLogLevel {
    TRACE, DEBUG, INFO, WARN, ERROR, CRITICAL
}

/**
 * Enterprise console logger. Never logs credentials, private tokens, or sensitive payload.
 */
object AureomLogger {
    private const val TAG = "AureomGameOS"
    private var minLevel = AureomLogLevel.DEBUG
    val recentLogs = mutableStateListOf<String>(
        "[INFO][System] Aureom OS kernel initialised successfully.",
        "[INFO][DirectStorage] Hardware decompression stream open (NVMe Pool).",
        "[INFO][Display] AMD FreeSync & HDMI 2.1 VRR sync established @ 120Hz.",
        "[DEBUG][Presence] WebSocket heartbeat connected to wss://realtime.aureom.os/events"
    )

    fun setLevel(level: AureomLogLevel) {
        minLevel = level
    }

    private fun recordLog(levelStr: String, tag: String, message: String) {
        if (recentLogs.size > 80) recentLogs.removeAt(0)
        recentLogs.add("[$levelStr][$tag] $message")
    }

    fun trace(tag: String, message: String) {
        if (minLevel <= AureomLogLevel.TRACE) {
            Log.v(TAG, "[$tag] $message")
            recordLog("TRACE", tag, message)
        }
    }

    fun debug(tag: String, message: String) {
        if (minLevel <= AureomLogLevel.DEBUG) {
            Log.d(TAG, "[$tag] $message")
            recordLog("DEBUG", tag, message)
        }
    }

    fun info(tag: String, message: String) {
        if (minLevel <= AureomLogLevel.INFO) {
            Log.i(TAG, "[$tag] $message")
            recordLog("INFO", tag, message)
        }
    }

    fun warn(tag: String, message: String) {
        if (minLevel <= AureomLogLevel.WARN) {
            Log.w(TAG, "[$tag] $message")
            recordLog("WARN", tag, message)
        }
    }

    fun error(tag: String, message: String, throwable: Throwable? = null) {
        if (minLevel <= AureomLogLevel.ERROR) {
            Log.e(TAG, "[$tag] $message", throwable)
            recordLog("ERROR", tag, message)
        }
    }

    fun critical(tag: String, message: String, throwable: Throwable? = null) {
        Log.e(TAG, "[CRITICAL][$tag] $message", throwable)
        recordLog("CRITICAL", tag, message)
    }
}
