#!/usr/bin/env python3
"""
AUREK SABER ENGINE — first-playable prototype demo (design doc §101).

Runs one arena, two humanoid combatants, two lightsaber-style weapons, AI
vs AI (or pass --player to drive fighter A with a simple scripted
attacker so you can see the parry/counter loop respond to a human-shaped
input pattern). Prints a human-readable duel log and writes a replay JSON.

Usage:
    python examples/run_duel.py
    python examples/run_duel.py --a-archetype AGGRESSOR --b-archetype DEFENDER --seed 7
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from aurek_saber.ai.personality import Archetype, Difficulty
from aurek_saber.camera.duel_camera import DuelCamera
from aurek_saber.combat.duel import DuelSimulation, FighterSpec
from aurek_saber.core.clock import SIMULATION_DT
from aurek_saber.core.enums import DuelOutcome
from aurek_saber.core.math import vec3
from aurek_saber.replay.recorder import ReplayRecorder

MAX_TICKS = 120 * 45  # 45 seconds of simulated duel, hard cap


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one AUREK SABER ENGINE duel.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--a-archetype", default="DUELIST")
    parser.add_argument("--b-archetype", default="AGGRESSOR")
    parser.add_argument("--a-difficulty", default="NORMAL")
    parser.add_argument("--b-difficulty", default="NORMAL")
    parser.add_argument("--replay-out", default="duel_replay.json")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    spec_a = FighterSpec(
        combatant_id="fighter_a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1),
        archetype=Archetype[args.a_archetype], difficulty=Difficulty[args.a_difficulty], is_ai=True,
    )
    spec_b = FighterSpec(
        combatant_id="fighter_b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1),
        archetype=Archetype[args.b_archetype], difficulty=Difficulty[args.b_difficulty], is_ai=True,
    )

    sim = DuelSimulation(duel_id="demo_duel", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=args.seed)
    recorder = ReplayRecorder(sim)
    camera = DuelCamera()

    printed = 0
    for _ in range(MAX_TICKS):
        recorder.tick(SIMULATION_DT)
        cam_state = camera.update(sim.controllers["fighter_a"].position, sim.controllers["fighter_b"].position, sim.intensity, SIMULATION_DT)

        if not args.quiet:
            while printed < len(sim.events.log):
                print(sim.events.log[printed])
                printed += 1

        if sim.is_over():
            break

    print("\n=== DUEL SUMMARY ===")
    print(f"Ticks simulated : {sim.tick_index} ({sim.sim_time:.2f}s)")
    print(f"Outcome         : {sim.outcome.name}")
    print(f"Hit counts      : {sim.hit_counts}")
    for cid, ctrl in sim.controllers.items():
        print(f"  {cid}: stamina={ctrl.stamina.current:5.1f} balance={ctrl.balance.value:5.1f} guard={ctrl.guard.name} state={ctrl.duel_state.name}")

    with open(args.replay_out, "w") as f:
        f.write(recorder.log.to_json())
    print(f"\nReplay written to {args.replay_out} ({len(recorder.log.records)} ticks recorded)")


if __name__ == "__main__":
    main()
