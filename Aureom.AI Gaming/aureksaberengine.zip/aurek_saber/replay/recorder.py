"""
aurek_saber.replay.recorder
==============================
design doc §60-61, §97. Because the simulation is fixed-timestep and
seeded (core.clock, combat.duel's `random.Random(seed)`), recording the
seed + initial fighter specs + every tick's *inputs* (AI/player intents)
is enough to reproduce a duel exactly. We additionally snapshot a compact
per-tick state digest so `verify_determinism()` can catch any accidental
nondeterminism (e.g. an unseeded `random` call slipping into new code)
without having to diff full float state.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from ..combat.duel import DuelSimulation, FighterSpec
from ..core.enums import CombatIntent


def _state_digest(sim: DuelSimulation) -> str:
    parts = []
    for cid in sorted(sim.ids()):
        c = sim.controllers[cid]
        parts.append(
            f"{cid}:{c.position.round(4).tolist()}:{c.stamina.current:.2f}:{c.balance.value:.2f}:{c.guard.name}"
        )
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:16]


@dataclass
class TickRecord:
    tick: int
    time: float
    intents: Dict[str, str]
    state_digest: str
    events: List[str] = field(default_factory=list)


@dataclass
class ReplayLog:
    duel_id: str
    seed: int
    dt: float
    records: List[TickRecord] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps({
            "duel_id": self.duel_id,
            "seed": self.seed,
            "dt": self.dt,
            "records": [asdict(r) for r in self.records],
        }, indent=2)

    @staticmethod
    def from_json(text: str) -> "ReplayLog":
        data = json.loads(text)
        records = [TickRecord(**r) for r in data["records"]]
        return ReplayLog(duel_id=data["duel_id"], seed=data["seed"], dt=data["dt"], records=records)


class ReplayRecorder:
    """Wrap a DuelSimulation, recording one TickRecord per `tick()` call."""

    def __init__(self, sim: DuelSimulation):
        self.sim = sim
        self.log = ReplayLog(duel_id=sim.duel_id, seed=sim.seed, dt=1.0 / 120.0)

    def tick(self, dt: float) -> None:
        events_before = len(self.sim.events.log)
        self.sim.tick(dt)
        new_events = [repr(e) for e in self.sim.events.log[events_before:]]
        intents = {cid: d.intent.name for cid, d in self.sim.last_decisions.items()}
        self.log.records.append(TickRecord(
            tick=self.sim.tick_index,
            time=self.sim.sim_time,
            intents=intents,
            state_digest=_state_digest(self.sim),
            events=new_events,
        ))
        self.log.dt = dt


class ReplayPlayer:
    """Steps through a recorded log for analysis/scrubbing (design doc
    §61, §97): rewind, pause, frame-advance, slow motion. This player
    replays the *record*, not a re-simulation — for a true deterministic
    re-simulation (to catch nondeterminism bugs), see `verify_determinism`.
    """

    def __init__(self, log: ReplayLog):
        self.log = log
        self.index = 0

    def frame_advance(self) -> Optional[TickRecord]:
        if self.index >= len(self.log.records):
            return None
        rec = self.log.records[self.index]
        self.index += 1
        return rec

    def rewind(self, to_tick: int = 0) -> None:
        self.index = max(0, to_tick)

    def seek(self, tick: int) -> Optional[TickRecord]:
        for i, rec in enumerate(self.log.records):
            if rec.tick == tick:
                self.index = i
                return rec
        return None

    def scrub_slow_motion(self, factor: float = 0.25):
        """Generator yielding (record, effective_dt) pairs at `factor`x
        speed — a UI layer can drive real playback timing off this."""
        for rec in self.log.records[self.index:]:
            yield rec, self.log.dt * factor


def verify_determinism(spec_a: FighterSpec, spec_b: FighterSpec, seed: int, n_ticks: int, scripted_intents=None) -> bool:
    """Runs the same duel spec+seed twice and checks the per-tick state
    digests match exactly — proof the simulation is actually deterministic
    (design doc §60), not just "probably fine"."""
    digests_runs = []
    for _ in range(2):
        sim = DuelSimulation(duel_id="determinism_check", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=seed)
        digests = []
        for i in range(n_ticks):
            if scripted_intents:
                for cid, intent_fn in scripted_intents.items():
                    intent = intent_fn(i)
                    if intent is not None:
                        sim.set_external_intent(cid, intent)
            sim.tick(1.0 / 120.0)
            digests.append(_state_digest(sim))
        digests_runs.append(digests)
    return digests_runs[0] == digests_runs[1]
