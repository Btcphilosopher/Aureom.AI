"""
aurek_saber.camera.duel_camera
=================================
design doc §47-50. Pure data/framing logic — no renderer here, but the
maths a real camera rig needs: a position/lookat/FOV computed from both
fighters' state each tick, reacting to distance and intensity without
snapping (design doc §88 applies to the camera too: everything eases).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from ..core.math import UP, Vec3, clamp, length, lerp, normalize, vec3, vmove_toward


class CameraMode(Enum):
    DUEL = auto()
    CLOSE = auto()
    TACTICAL = auto()
    CINEMATIC = auto()
    FIRST_PERSON = auto()
    OVER_SHOULDER = auto()


@dataclass
class CameraState:
    position: Vec3
    look_at: Vec3
    fov_degrees: float = 50.0
    mode: CameraMode = CameraMode.DUEL


class DuelCamera:
    """design doc §48-49: keep both fighters visible and the distance
    readable; tighten framing as intensity rises, widen during
    repositioning."""

    def __init__(self, height: float = 1.55, base_back: float = 3.4, base_fov: float = 52.0):
        self.height = height
        self.base_back = base_back
        self.base_fov = base_fov
        self._position: Vec3 = vec3(0.0, height, -base_back)
        self._fov = base_fov

    def update(self, pos_a: Vec3, pos_b: Vec3, intensity: float, dt: float) -> CameraState:
        midpoint = (pos_a + pos_b) * 0.5
        separation = length(pos_a - pos_b)

        # A side-on offset keeps both blades legible rather than a
        # dead-on view that flattens depth.
        line = normalize(pos_b - pos_a, vec3(1.0, 0.0, 0.0))
        side = vec3(-line[2], 0.0, line[0])

        back_distance = self.base_back + separation * 0.55 - intensity * 0.6
        back_distance = clamp(back_distance, 1.8, 8.0)

        # Sit off to the side and slightly back, scaled by separation,
        # looking at the midpoint between both fighters.
        desired_pos = midpoint + side * back_distance * 0.5 + vec3(0.0, self.height + separation * 0.08, 0.0)

        self._position = vmove_toward(self._position, desired_pos, 6.0 * dt)

        # Dynamic framing (design doc §49): tighten FOV during intense
        # exchanges, widen during repositioning/large separation.
        target_fov = self.base_fov - intensity * 10.0 + clamp(separation - 2.0, 0.0, 3.0) * 3.0
        self._fov = lerp(self._fov, clamp(target_fov, 32.0, 68.0), min(1.0, dt * 3.0))

        return CameraState(position=self._position.copy(), look_at=midpoint, fov_degrees=self._fov, mode=CameraMode.DUEL)
