"""
aurek_saber.character.reaction
=================================
design doc §29. Reactions are *computed*, not picked from a fixed hit-
animation list: the same DIRECT_CONTACT at low balance produces a
different reaction than one at high balance, or one taken while
retreating vs. advancing.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from ..core.enums import ContactType
from ..core.math import Vec3, clamp, length


class ReactionKind(Enum):
    NONE = auto()
    FLINCH = auto()
    STEP_BACK = auto()
    STAGGER = auto()
    STAGGER_TURN = auto()
    RECOIL = auto()
    DUCK = auto()
    LOSS_OF_BALANCE = auto()
    KNOCKDOWN = auto()


@dataclass
class ReactionResult:
    kind: ReactionKind
    duration: float
    impulse_direction: Vec3
    impulse_magnitude: float
    torque: float
    turn_toward_attacker: bool = False


def generate_reaction(
    contact_type: ContactType,
    impact_direction: Vec3,
    impact_speed: float,
    defender_balance: float,
    defender_stance_width: float,
    defender_was_moving_forward: bool,
) -> ReactionResult:
    """Computes a reaction from contact classification + physical state
    rather than switching on an animation name (design doc §29)."""
    dirn = impact_direction
    mag = clamp(impact_speed, 0.0, 12.0)

    if contact_type in (ContactType.PERFECT_PARRY,):
        # The *attacker* is who reacts here; defender barely moves.
        return ReactionResult(ReactionKind.NONE, 0.0, dirn, 0.0, 0.0)

    if contact_type in (ContactType.CLEAN_BLOCK, ContactType.PARRY):
        kind = ReactionKind.FLINCH if mag < 3 else ReactionKind.RECOIL
        return ReactionResult(kind, 0.12 + mag * 0.01, dirn, mag * 0.4, mag * 0.1)

    if contact_type == ContactType.GLANCING_BLOCK:
        return ReactionResult(ReactionKind.STEP_BACK, 0.18, dirn, mag * 0.5, mag * 0.15)

    if contact_type == ContactType.EDGE_CONTACT:
        return ReactionResult(ReactionKind.STAGGER_TURN, 0.22, dirn, mag * 0.6, mag * 0.3, turn_toward_attacker=True)

    if contact_type in (ContactType.FAILED_PARRY, ContactType.DIRECT_CONTACT):
        if defender_balance < 30:
            kind = ReactionKind.KNOCKDOWN if mag > 6 else ReactionKind.LOSS_OF_BALANCE
        elif defender_was_moving_forward:
            kind = ReactionKind.STAGGER_TURN
        else:
            kind = ReactionKind.STAGGER
        duration = 0.28 + mag * 0.03 + (0.15 if defender_stance_width < 0.35 else 0.0)
        return ReactionResult(kind, duration, dirn, mag, mag * 0.5, turn_toward_attacker=(kind == ReactionKind.STAGGER_TURN))

    if contact_type == ContactType.BLADE_LOCK:
        return ReactionResult(ReactionKind.NONE, 0.0, dirn, 0.0, 0.0)

    return ReactionResult(ReactionKind.FLINCH, 0.1, dirn, mag * 0.2, 0.0)
