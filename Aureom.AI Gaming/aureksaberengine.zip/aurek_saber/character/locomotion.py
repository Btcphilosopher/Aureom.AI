"""
aurek_saber.character.locomotion
===================================
design doc §20, §23. Footwork primitives. Everything here returns a
*desired velocity contribution* that the controller blends and then rate
limits (never a direct position write) — this is what keeps combat
geometry physical instead of teleport-y (design doc §88).
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.math import UP, Vec3, horizontal, normalize, rotate_yaw

MAX_WALK_SPEED = 1.8
MAX_STEP_SPEED = 3.2
MAX_LUNGE_SPEED = 5.5
MAX_YAW_RATE = 6.5  # rad/s, cap on pivot/circling turn rate
MAX_ACCEL = 14.0  # m/s^2, cap on how fast velocity can change (no snapping)


def forward_step(forward: Vec3, speed: float) -> Vec3:
    return normalize(forward) * speed


def backward_step(forward: Vec3, speed: float) -> Vec3:
    return -normalize(forward) * speed


def side_step(forward: Vec3, speed: float, right: bool = True) -> Vec3:
    lateral = rotate_yaw(normalize(forward), -1.5708 if right else 1.5708)
    return lateral * speed


def circle_step(to_opponent: Vec3, forward: Vec3, speed: float, clockwise: bool = True) -> Vec3:
    """Movement that orbits the opponent while preserving distance and
    facing (design doc §23) — this is the "don't strafe-slide" primitive:
    velocity is tangential to the line to the opponent, not just lateral
    to the character's own forward."""
    radial = normalize(to_opponent)
    tangent = rotate_yaw(radial, -1.5708 if clockwise else 1.5708)
    return tangent * speed


def lunge(forward: Vec3, speed: float = MAX_LUNGE_SPEED) -> Vec3:
    return normalize(forward) * speed


def retreat_step(forward: Vec3, speed: float) -> Vec3:
    return -normalize(forward) * speed


@dataclass
class LocomotionState:
    velocity: Vec3
    yaw_rate: float = 0.0

    def integrate_velocity(self, desired: Vec3, dt: float, max_accel: float = MAX_ACCEL) -> Vec3:
        from ..core.math import vmove_toward

        self.velocity = vmove_toward(self.velocity, desired, max_accel * dt)
        return self.velocity
