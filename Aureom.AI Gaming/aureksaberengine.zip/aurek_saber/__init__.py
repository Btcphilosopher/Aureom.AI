"""
AUREK SABER ENGINE
====================
A physical, systemic lightsaber-duelling combat simulation core.

See the package README for architecture, scope, and how to run the demo
duel and self-play balancing harness.
"""

__version__ = "0.1.0"
