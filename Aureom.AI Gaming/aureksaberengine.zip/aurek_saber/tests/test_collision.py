from aurek_saber.combat.blade import SaberBlade
from aurek_saber.combat.collision import closest_points_segment_segment, sweep_blade_blade
from aurek_saber.core.math import vec3


def test_closest_points_parallel_segments():
    p1, p2, dist = closest_points_segment_segment(vec3(0, 0, 0), vec3(1, 0, 0), vec3(0, 1, 0), vec3(1, 1, 0))
    assert abs(dist - 1.0) < 1e-9


def test_closest_points_crossing_segments():
    # Two segments crossing in an X shape at the origin.
    p1, p2, dist = closest_points_segment_segment(vec3(-1, 0, 0), vec3(1, 0, 0), vec3(0, -1, 0), vec3(0, 1, 0))
    assert dist < 1e-9


def test_swept_blade_blade_catches_fast_passthrough():
    """The core continuous-collision guarantee (design doc §06): a blade
    that would tunnel through another between two single-frame poses must
    still register contact via the swept tip-path segment."""
    a = SaberBlade(owner_id="a")
    b = SaberBlade(owner_id="b")

    # Blade A starts far left, ends far right, tip passing straight
    # through where blade B's tip sits — classic tunnelling setup.
    a.prev_base_position = vec3(-5, 1, 0)
    a.prev_tip_position = vec3(-5, 1, 1.05)
    a.base_position = vec3(5, 1, 0)
    a.tip_position = vec3(5, 1, 1.05)

    b.prev_base_position = vec3(0, 1, 0)
    b.prev_tip_position = vec3(0, 1, 1.05)
    b.base_position = vec3(0, 1, 0)
    b.tip_position = vec3(0, 1, 1.05)

    geom = sweep_blade_blade(a, b)
    assert geom is not None


def test_no_collision_when_far_apart():
    a = SaberBlade(owner_id="a")
    b = SaberBlade(owner_id="b")
    a.prev_base_position = a.base_position = vec3(0, 0, 0)
    a.prev_tip_position = a.tip_position = vec3(0, 0, 1)
    b.prev_base_position = b.base_position = vec3(10, 0, 0)
    b.prev_tip_position = b.tip_position = vec3(10, 0, 1)
    assert sweep_blade_blade(a, b) is None
