from aurek_saber.combat.balance import CombatBalance, STAGGER_THRESHOLD
from aurek_saber.combat.collision import ContactGeometry
from aurek_saber.combat.guard import GuardCoverage
from aurek_saber.combat.parry import classify_contact, resolve_blade_lock
from aurek_saber.combat.stamina import StaminaModel
from aurek_saber.core.enums import AttackPhase, ContactType, GuardZone
from aurek_saber.core.math import vec3


def _geom():
    return ContactGeometry(contact_point=vec3(0, 1, 0.5), contact_normal=vec3(0, 1, 0), penetration=0.01, t_a=0.5, t_b=0.5)


def test_well_timed_well_aligned_contact_is_perfect_parry():
    coverage = GuardCoverage(GuardZone.HIGH_LEFT, alignment=0.95, exposed=False)
    result = classify_contact(
        _geom(), "attacker", "defender",
        attacker_blade_speed=6.0, defender_blade_speed=2.0,
        coverage=coverage, defender_reaction_lag=-0.05,
        defender_guard_intentional=True, defender_stamina_ratio=1.0, defender_balance_ratio=1.0,
        defender_attack_phase=AttackPhase.NONE, is_attacker_committed=True,
    )
    assert result.contact_type == ContactType.PERFECT_PARRY
    assert result.attacker_stagger > 0
    assert result.opening_for_defender > 0


def test_late_misaligned_contact_is_failed_parry_or_direct():
    coverage = GuardCoverage(GuardZone.LOW_LEFT, alignment=0.1, exposed=True)
    result = classify_contact(
        _geom(), "attacker", "defender",
        attacker_blade_speed=6.0, defender_blade_speed=1.0,
        coverage=coverage, defender_reaction_lag=0.5,
        defender_guard_intentional=True, defender_stamina_ratio=0.3, defender_balance_ratio=0.3,
        defender_attack_phase=AttackPhase.NONE, is_attacker_committed=True,
    )
    assert result.contact_type in (ContactType.DIRECT_CONTACT, ContactType.FAILED_PARRY)
    assert result.defender_stagger > 0
    assert result.opening_for_attacker > 0


def test_open_guard_is_direct_contact():
    coverage = GuardCoverage(GuardZone.OPEN, alignment=0.0, exposed=True)
    result = classify_contact(
        _geom(), "attacker", "defender",
        attacker_blade_speed=5.0, defender_blade_speed=0.0,
        coverage=coverage, defender_reaction_lag=0.0,
        defender_guard_intentional=False, defender_stamina_ratio=1.0, defender_balance_ratio=1.0,
        defender_attack_phase=AttackPhase.NONE, is_attacker_committed=True,
    )
    assert result.contact_type == ContactType.DIRECT_CONTACT


def test_resolve_blade_lock_favours_greater_power():
    assert resolve_blade_lock(10, 5) > 0
    assert resolve_blade_lock(5, 10) < 0
    assert resolve_blade_lock(5, 5) == 0


def test_balance_recovers_over_time_and_staggers_when_low():
    bal = CombatBalance()
    bal.apply_impulse(vec3(1, 0, 0), magnitude=80.0)
    assert bal.value < STAGGER_THRESHOLD
    assert bal.is_staggered()
    for _ in range(200):
        bal.tick(1 / 120)
    assert bal.value > STAGGER_THRESHOLD


def test_stamina_spend_and_regen():
    st = StaminaModel(current=100, maximum=100)
    sufficient = st.spend(30)
    assert sufficient
    assert st.current == 70
    st.tick(1.0, is_idle=True)
    assert st.current > 70


def test_stamina_fatigue_slows_speed():
    st = StaminaModel(current=10, maximum=100)
    for _ in range(400):
        st.tick(1 / 120, is_idle=False)
    assert st.fatigue > 0.0
    assert st.speed_multiplier() < 1.0
