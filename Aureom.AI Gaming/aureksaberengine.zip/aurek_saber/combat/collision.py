"""
aurek_saber.combat.collision
==============================
Continuous collision detection for blade-to-blade, blade-to-body and
blade-to-weapon contact (design doc §06-07). We never do a single-frame
point/sphere check — every query sweeps the blade's *swept volume* between
the previous and current tick, modelled as capsules along segments, so a
fast swing at a low tick rate cannot pass through a target between frames.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..core.math import Vec3, length


def closest_points_segment_segment(p1: Vec3, q1: Vec3, p2: Vec3, q2: Vec3):
    """Classic closest-point-between-two-segments (Ericson, RTCD 5.1.9).
    Returns (point_on_seg1, point_on_seg2, distance)."""
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = float(d1 @ d1)
    e = float(d2 @ d2)
    f = float(d2 @ r)

    EPS = 1e-9
    if a <= EPS and e <= EPS:
        return p1, p2, length(p1 - p2)

    if a <= EPS:
        s = 0.0
        t = np.clip(f / e, 0.0, 1.0) if e > EPS else 0.0
    else:
        c = float(d1 @ r)
        if e <= EPS:
            t = 0.0
            s = np.clip(-c / a, 0.0, 1.0)
        else:
            b = float(d1 @ d2)
            denom = a * e - b * b
            if denom > EPS:
                s = np.clip((b * f - c * e) / denom, 0.0, 1.0)
            else:
                s = 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = np.clip(-c / a, 0.0, 1.0)
            elif t > 1.0:
                t = 1.0
                s = np.clip((b - c) / a, 0.0, 1.0)

    c1 = p1 + d1 * s
    c2 = p2 + d2 * t
    return c1, c2, length(c1 - c2)


def closest_point_on_segment(p: Vec3, a: Vec3, b: Vec3):
    ab = b - a
    denom = float(ab @ ab)
    t = 0.0 if denom < 1e-9 else np.clip(float((p - a) @ ab) / denom, 0.0, 1.0)
    pt = a + ab * t
    return pt, length(p - pt)


@dataclass
class ContactGeometry:
    contact_point: Vec3
    contact_normal: Vec3
    penetration: float
    t_a: float  # 0..1, fraction along blade A's swept segment where contact occurred
    t_b: float


def sweep_blade_blade(blade_a, blade_b, combined_radius: Optional[float] = None) -> Optional[ContactGeometry]:
    """Continuous blade-vs-blade collision. We approximate the swept
    volume of each blade over the tick as the segment from its *previous*
    tip to its *current* tip (the dominant sweep for a saber, since angular
    velocity about a near-fixed hilt means the tip travels far more than
    the base) unioned with the static current segment, and test both the
    "start" and "end" blade segments plus the tip-sweep segments against
    the other blade's equivalent set. This catches both a fast pass-through
    swing and a slow blade-lock press.
    """
    r = combined_radius if combined_radius is not None else (blade_a.radius + blade_b.radius)

    candidates = []
    segs_a = [
        (blade_a.prev_base_position, blade_a.prev_tip_position, 0.0),
        (blade_a.base_position, blade_a.tip_position, 1.0),
        (blade_a.prev_tip_position, blade_a.tip_position, 0.5),  # tip sweep
    ]
    segs_b = [
        (blade_b.prev_base_position, blade_b.prev_tip_position, 0.0),
        (blade_b.base_position, blade_b.tip_position, 1.0),
        (blade_b.prev_tip_position, blade_b.tip_position, 0.5),
    ]

    best: Optional[ContactGeometry] = None
    for (a0, a1, ta) in segs_a:
        for (b0, b1, tb) in segs_b:
            if length(a1 - a0) < 1e-9 or length(b1 - b0) < 1e-9:
                continue
            pa, pb, dist = closest_points_segment_segment(a0, a1, b0, b1)
            if dist <= r:
                penetration = r - dist
                normal = (pa - pb)
                normal = normal / length(normal) if length(normal) > 1e-9 else np.array([0.0, 1.0, 0.0])
                geom = ContactGeometry(
                    contact_point=(pa + pb) * 0.5,
                    contact_normal=normal,
                    penetration=penetration,
                    t_a=ta,
                    t_b=tb,
                )
                if best is None or geom.penetration > best.penetration:
                    best = geom
    return best


def sweep_blade_capsule(blade, capsule_a: Vec3, capsule_b: Vec3, capsule_radius: float) -> Optional[ContactGeometry]:
    """Blade-vs-body(or limb) continuous collision. The body part is
    modelled as a capsule (e.g. torso spine, forearm) for the duration of
    the tick; the blade sweeps its tip-path segment plus its current pose
    segment against it."""
    r = blade.radius + capsule_radius
    segs = [
        (blade.prev_tip_position, blade.tip_position),  # tip sweep — the dangerous one
        (blade.base_position, blade.tip_position),  # resting pose
    ]
    best: Optional[ContactGeometry] = None
    for a0, a1 in segs:
        if length(a1 - a0) < 1e-9:
            continue
        pa, pb, dist = closest_points_segment_segment(a0, a1, capsule_a, capsule_b)
        if dist <= r:
            penetration = r - dist
            normal = (pa - pb)
            normal = normal / length(normal) if length(normal) > 1e-9 else np.array([0.0, 1.0, 0.0])
            geom = ContactGeometry(contact_point=(pa + pb) * 0.5, contact_normal=normal, penetration=penetration, t_a=0.5, t_b=0.5)
            if best is None or geom.penetration > best.penetration:
                best = geom
    return best
