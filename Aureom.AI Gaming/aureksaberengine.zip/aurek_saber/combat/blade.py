"""
aurek_saber.combat.blade
==========================
The blade as a real simulation object (design doc §04, §06) rather than a
hitbox glued to an animation event. Even though a lightsaber is fictional
energy weaponry, we give it a gameplay-physics abstraction: mass-equivalent
inertia ("mass_proxy"), a swept trace between frames for continuous
collision, and an explicit contact/energy state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto

from ..core.enums import Stance
from ..core.math import ZERO, Vec3, length, normalize, vec3


class EnergyState(Enum):
    IGNITED = auto()
    EXTINGUISHED = auto()
    UNSTABLE = auto()  # e.g. post blade-lock overheat, content-defined


class WeaponGrip(Enum):
    ONE_HANDED = auto()
    TWO_HANDED = auto()
    DUAL_WIELD = auto()
    STAFF = auto()
    REVERSE = auto()


@dataclass
class SaberHandle:
    """design doc §05 — the physical hilt in the combatant's hand(s)."""

    position: Vec3 = field(default_factory=lambda: ZERO.copy())
    orientation: Vec3 = field(default_factory=lambda: vec3(0, 0, 1))
    hand_alignment: float = 1.0  # 0..1, how squarely both hands are on-grip
    grip: WeaponGrip = WeaponGrip.ONE_HANDED
    stance: Stance = Stance.NEUTRAL
    weapon_state: str = "ready"


@dataclass
class SaberBlade:
    """A single blade segment from base (hilt emitter) to tip."""

    owner_id: str = ""
    length: float = 1.05  # metres, canonical lightsaber-ish blade
    radius: float = 0.014
    mass_proxy: float = 0.9  # kg-equivalent swing inertia, tunable per hilt

    base_position: Vec3 = field(default_factory=lambda: ZERO.copy())
    tip_position: Vec3 = field(default_factory=lambda: vec3(0, 0, 1.05))
    direction: Vec3 = field(default_factory=lambda: vec3(0, 0, 1))

    velocity: Vec3 = field(default_factory=lambda: ZERO.copy())  # tip linear velocity
    angular_velocity: float = 0.0  # rad/s about the base, swing speed

    contact_state: str = "clear"
    energy_state: EnergyState = EnergyState.IGNITED

    # --- swept trace for continuous collision (design doc §06) ---
    prev_base_position: Vec3 = field(default_factory=lambda: ZERO.copy())
    prev_tip_position: Vec3 = field(default_factory=lambda: vec3(0, 0, 1.05))

    def set_transform(self, base: Vec3, direction: Vec3, dt: float) -> None:
        """Advance the blade to a new base/direction, recording the previous
        transform for swept collision and deriving tip velocity."""
        self.prev_base_position = self.base_position.copy()
        self.prev_tip_position = self.tip_position.copy()

        direction = normalize(direction, self.direction)
        new_tip = base + direction * self.length

        if dt > 1e-9:
            self.velocity = (new_tip - self.prev_tip_position) / dt
            d_theta = 0.0
            prev_dir = normalize(self.prev_tip_position - self.prev_base_position, direction)
            cos_a = max(-1.0, min(1.0, float(direction @ prev_dir)))
            import math

            d_theta = math.acos(cos_a)
            self.angular_velocity = d_theta / dt

        self.base_position = base
        self.tip_position = new_tip
        self.direction = direction

    @property
    def tip_speed(self) -> float:
        return length(self.velocity)

    def midpoint(self) -> Vec3:
        return (self.base_position + self.tip_position) * 0.5

    def is_ignited(self) -> bool:
        return self.energy_state == EnergyState.IGNITED

    def swept_segments(self):
        """Return the two segments (base->prev_base pairing excluded) that
        bound the swept volume for this frame: the segment the *tip* traced
        and the segment the *base* traced, plus start/end blade segments.
        Used by combat.collision for continuous (capsule-sweep) detection.
        """
        return {
            "start_base": self.prev_base_position,
            "start_tip": self.prev_tip_position,
            "end_base": self.base_position,
            "end_tip": self.tip_position,
        }
