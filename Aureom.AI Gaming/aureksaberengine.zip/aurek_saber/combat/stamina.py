"""
aurek_saber.combat.stamina
=============================
design doc §31. Stamina/fatigue is a soft constraint that degrades every
other system rather than a hard "can't act" gate — matching how a tired
duellist gets *worse*, not frozen.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.math import clamp

# Stamina costs, in points-per-action (design doc §31). Tuned by
# self-play/balancing (see training/dojo.py, examples/self_play_balance.py).
COST_ATTACK_LIGHT = 6.0
COST_ATTACK_HEAVY = 14.0
COST_BLOCK = 3.0
COST_PARRY = 4.0
COST_DODGE = 8.0
COST_SPRINT_PER_SEC = 5.0
COST_POWER_ACTION = 20.0

REGEN_PER_SEC_IDLE = 9.0
REGEN_PER_SEC_MOVING = 4.5


@dataclass
class StaminaModel:
    current: float = 100.0
    maximum: float = 100.0
    fatigue: float = 0.0  # 0..1, rises as reserves are repeatedly drained low

    def spend(self, amount: float) -> bool:
        """Returns False (and still spends, going negative-clamped-to-0
        with a stumble penalty) if the action was attempted while
        under-resourced — callers use this to trigger a weaker/slower
        version of the action rather than silently blocking it."""
        sufficient = self.current >= amount
        self.current = clamp(self.current - amount, 0.0, self.maximum)
        return sufficient

    def tick(self, dt: float, is_idle: bool) -> None:
        regen = REGEN_PER_SEC_IDLE if is_idle else REGEN_PER_SEC_MOVING
        regen *= (1.0 - 0.5 * self.fatigue)  # fatigue blunts recovery too
        self.current = clamp(self.current + regen * dt, 0.0, self.maximum)

        # Fatigue rises when reserves are run low, decays slowly when kept high.
        low_pressure = clamp(1.0 - self.current / self.maximum, 0.0, 1.0)
        if low_pressure > 0.6:
            self.fatigue = clamp(self.fatigue + 0.15 * dt, 0.0, 1.0)
        else:
            self.fatigue = clamp(self.fatigue - 0.05 * dt, 0.0, 1.0)

    @property
    def ratio(self) -> float:
        return self.current / self.maximum if self.maximum > 0 else 0.0

    def speed_multiplier(self) -> float:
        """Attack/movement speed scaling from fatigue (design doc §31)."""
        return clamp(1.0 - 0.35 * self.fatigue - 0.15 * (1.0 - self.ratio), 0.45, 1.0)

    def guard_stability_multiplier(self) -> float:
        return clamp(1.0 - 0.45 * self.fatigue, 0.4, 1.0)

    def recovery_multiplier(self) -> float:
        """Higher = slower recovery from staggers/attacks when tired."""
        return clamp(1.0 + 0.6 * self.fatigue, 1.0, 1.8)
