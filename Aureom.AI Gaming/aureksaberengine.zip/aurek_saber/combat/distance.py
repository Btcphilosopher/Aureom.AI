"""
aurek_saber.combat.distance
=============================
design doc §21-23. Distance is a first-class combat variable, not a side
effect of movement — the AI and the player both reason about it
explicitly every tick.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.enums import DistanceZone
from ..core.math import Vec3, horizontal, length


@dataclass
class DistancePreferences:
    """Different fighters/archetypes/forms genuinely prefer different
    ranges (design doc §22, §107)."""

    preferred: float = 1.7
    minimum: float = 0.55
    attack: float = 1.9  # blade reach engagement distance
    retreat: float = 1.3  # distance below which this fighter wants to open back up


ZONE_BOUNDS = {
    # (max distance for this zone, inclusive upper bound)
    DistanceZone.CLINCH: 0.5,
    DistanceZone.CLOSE: 1.1,
    DistanceZone.ENGAGEMENT: 2.2,
    DistanceZone.MEASURE: 3.5,
    DistanceZone.LONG_RANGE: 6.0,
    DistanceZone.OUT_OF_RANGE: float("inf"),
}

_ORDER = [
    DistanceZone.CLINCH,
    DistanceZone.CLOSE,
    DistanceZone.ENGAGEMENT,
    DistanceZone.MEASURE,
    DistanceZone.LONG_RANGE,
    DistanceZone.OUT_OF_RANGE,
]


def classify_distance(d: float) -> DistanceZone:
    for zone in _ORDER:
        if d <= ZONE_BOUNDS[zone]:
            return zone
    return DistanceZone.OUT_OF_RANGE


def horizontal_distance(pos_a: Vec3, pos_b: Vec3) -> float:
    return length(horizontal(pos_a) - horizontal(pos_b))


class CombatDistanceController:
    """Turns "I want to be at range X" into a bounded desired-velocity
    contribution, to be blended with circling/facing by
    character.locomotion. No teleporting, no snapping (design doc §88)."""

    def __init__(self, prefs: DistancePreferences):
        self.prefs = prefs

    def desired_radial_speed(self, current_distance: float, urgency: float = 1.0) -> float:
        """Positive = close the distance (advance), negative = open it
        (retreat). Magnitude scales with how far off-preference we are,
        capped by `urgency` (0..1, e.g. reduced by fatigue/stamina)."""
        error = current_distance - self.prefs.preferred
        # Deadband so fighters don't jitter in/out at the preferred range.
        if abs(error) < 0.12:
            return 0.0
        max_speed = 2.6 * urgency
        gain = 1.4
        speed = max(-max_speed, min(max_speed, error * gain))
        # Hard floor: never voluntarily advance past minimum distance.
        if current_distance - speed < self.prefs.minimum and speed > 0:
            speed = max(0.0, current_distance - self.prefs.minimum)
        return speed

    def in_attack_range(self, current_distance: float) -> bool:
        return current_distance <= self.prefs.attack

    def wants_retreat(self, current_distance: float) -> bool:
        return current_distance <= self.prefs.retreat
