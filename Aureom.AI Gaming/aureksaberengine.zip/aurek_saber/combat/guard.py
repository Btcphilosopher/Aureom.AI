"""
aurek_saber.combat.guard
==========================
design doc §12-13. Guard is *not* a menu selection — it's read off the
actual blade transform relative to the body. The AI reads the opponent's
real blade position the same way a human duellist reads a weapon.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.enums import GuardZone
from ..core.math import Vec3, normalize


# Each zone's "canonical" defensive direction in the body's local frame
# (x = right, y = up, z = forward), used both to classify a blade pose into
# a zone and to score how well a given zone covers an incoming attack
# vector.
_ZONE_DIRECTIONS = {
    GuardZone.HIGH_LEFT: (-0.55, 0.7, 0.45),
    GuardZone.HIGH_RIGHT: (0.55, 0.7, 0.45),
    GuardZone.LOW_LEFT: (-0.55, -0.55, 0.45),
    GuardZone.LOW_RIGHT: (0.55, -0.55, 0.45),
    GuardZone.CENTER: (0.0, 0.05, 1.0),
}


def guard_pose_offset(zone: GuardZone, reach: float = 0.85) -> Vec3:
    """The resting blade-tip local offset (right, up, forward) a
    combatant holds while defending in `zone` — used by
    character.controller to pose the idle/guard blade transform, and by
    attacks.py-style trajectory building for parries/counters."""
    direction = _ZONE_DIRECTIONS.get(zone, _ZONE_DIRECTIONS[GuardZone.CENTER])
    return normalize(np.array(direction, dtype=float)) * reach


def classify_guard(blade_direction_local: Vec3, blade_extended: bool) -> GuardZone:
    """blade_direction_local: blade tip-from-hilt direction, expressed in
    the combatant's local frame (right, up, forward). If the blade isn't
    meaningfully raised/extended toward the opponent, the guard is OPEN —
    a real vulnerability, exactly as design doc §12 asks for."""
    if not blade_extended:
        return GuardZone.OPEN

    best_zone = GuardZone.OPEN
    best_score = -2.0
    bd = normalize(blade_direction_local)
    for zone, dir_tuple in _ZONE_DIRECTIONS.items():
        zd = normalize(np.array(dir_tuple, dtype=float))
        score = float(bd @ zd)
        if score > best_score:
            best_score = score
            best_zone = zone
    # If even the best zone is a poor match (blade pointed away/down/back),
    # treat it as an opening rather than force a false-positive guard.
    if best_score < 0.25:
        return GuardZone.OPEN
    return best_zone


@dataclass
class GuardCoverage:
    zone: GuardZone
    alignment: float  # 0..1, how well the guard covers the attack line
    exposed: bool


def coverage_against(guard_zone: GuardZone, incoming_zone: GuardZone) -> GuardCoverage:
    """How well a defender's current guard zone covers an attack arriving
    in `incoming_zone`. Adjacent zones give partial ("glancing") coverage;
    matching zones give strong coverage; OPEN gives none."""
    if guard_zone == GuardZone.OPEN:
        return GuardCoverage(guard_zone, 0.0, True)
    if guard_zone == incoming_zone:
        return GuardCoverage(guard_zone, 1.0, False)
    if guard_zone == GuardZone.CENTER or incoming_zone == GuardZone.CENTER:
        return GuardCoverage(guard_zone, 0.55, False)

    adjacency = {
        GuardZone.HIGH_LEFT: {GuardZone.HIGH_RIGHT: 0.35, GuardZone.LOW_LEFT: 0.45},
        GuardZone.HIGH_RIGHT: {GuardZone.HIGH_LEFT: 0.35, GuardZone.LOW_RIGHT: 0.45},
        GuardZone.LOW_LEFT: {GuardZone.LOW_RIGHT: 0.35, GuardZone.HIGH_LEFT: 0.45},
        GuardZone.LOW_RIGHT: {GuardZone.LOW_LEFT: 0.35, GuardZone.HIGH_RIGHT: 0.45},
    }
    align = adjacency.get(guard_zone, {}).get(incoming_zone, 0.15)
    return GuardCoverage(guard_zone, align, align < 0.3)
