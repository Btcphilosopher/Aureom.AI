"""
aurek_saber.combat.attacks
=============================
design doc §14-18. An attack is a *trajectory through space* the blade
follows over time, not a canned animation clip with a hit-frame. It can be
interrupted (parried, staggered) or aborted mid-flight (a feint, §17), and
it carries real commitment/recovery/momentum costs (§18).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from ..core.enums import AttackPhase, AttackType
from ..core.math import Vec3, clamp, vlerp


# Phase timing profile, in seconds, before speed/stance/stamina scaling.
# (windup, acceleration, contact, follow_through, recovery)
_BASE_TIMING = {
    AttackType.SHORT: (0.10, 0.07, 0.03, 0.08, 0.14),
    AttackType.HORIZONTAL: (0.16, 0.11, 0.04, 0.14, 0.22),
    AttackType.VERTICAL: (0.15, 0.10, 0.04, 0.13, 0.20),
    AttackType.DIAGONAL: (0.17, 0.12, 0.04, 0.15, 0.23),
    AttackType.THRUST: (0.11, 0.08, 0.03, 0.10, 0.16),
    AttackType.RISING: (0.16, 0.11, 0.04, 0.14, 0.21),
    AttackType.DESCENDING: (0.14, 0.10, 0.04, 0.13, 0.19),
    AttackType.LONG: (0.24, 0.16, 0.05, 0.20, 0.32),
    AttackType.COUNTER: (0.08, 0.06, 0.03, 0.09, 0.13),
    AttackType.FEINT: (0.12, 0.06, 0.0, 0.0, 0.10),
}

# Relative power/commitment/opening-if-missed, used by AI risk scoring
# (design doc §18, §39) and by damage/consequence classification (§42).
_BASE_POWER = {
    AttackType.SHORT: 0.35,
    AttackType.HORIZONTAL: 0.65,
    AttackType.VERTICAL: 0.7,
    AttackType.DIAGONAL: 0.68,
    AttackType.THRUST: 0.5,
    AttackType.RISING: 0.6,
    AttackType.DESCENDING: 0.72,
    AttackType.LONG: 0.95,
    AttackType.COUNTER: 0.55,
    AttackType.FEINT: 0.0,
}


@dataclass
class AttackTrajectory:
    """Live state of one in-flight attack. `character.controller` drives
    the blade transform each tick from `sample_blade_offset()`; the phase
    machine here is authoritative over what state the attack is in."""

    attack_type: AttackType
    attacker_id: str
    target_id: Optional[str] = None

    start_local_offset: Vec3 = None  # type: ignore[assignment]
    target_local_offset: Vec3 = None  # type: ignore[assignment]

    phase: AttackPhase = AttackPhase.WINDUP
    elapsed_in_phase: float = 0.0
    total_elapsed: float = 0.0

    speed_scale: float = 1.0  # from stance/stamina/fatigue
    is_feint: bool = False
    aborted_to: Optional[AttackType] = None  # what a feint redirected into
    target_zone: Optional[object] = None  # combat.guard.GuardZone the attack is aimed at
    contact_resolved: bool = False  # guards against re-resolving the same contact every tick

    def __post_init__(self):
        import numpy as np

        if self.start_local_offset is None:
            self.start_local_offset = np.array([0.3, 0.9, 0.15])
        if self.target_local_offset is None:
            self.target_local_offset = np.array([-0.25, 0.55, 0.55])

    def timing(self):
        base = _BASE_TIMING[self.attack_type]
        return tuple(clamp(t / max(self.speed_scale, 0.25), 0.0, 5.0) for t in base)

    @property
    def power(self) -> float:
        return _BASE_POWER[self.attack_type]

    @property
    def commitment(self) -> float:
        """0..1: how hard this attack is to abort/redeem once past
        acceleration — heavier attacks commit harder (design doc §18)."""
        windup, accel, contact, follow, recovery = self.timing()
        return clamp(self.power * 0.7 + (follow + recovery) / 1.2, 0.0, 1.0)

    def phase_progress(self) -> float:
        durations = self.timing()
        idx = [AttackPhase.WINDUP, AttackPhase.ACCELERATION, AttackPhase.CONTACT, AttackPhase.FOLLOW_THROUGH, AttackPhase.RECOVERY]
        if self.phase not in idx:
            return 1.0
        d = durations[idx.index(self.phase)]
        return 0.0 if d <= 1e-9 else clamp(self.elapsed_in_phase / d, 0.0, 1.0)

    def tick(self, dt: float) -> bool:
        """Advance phase timing. Returns True while the attack is still
        active (WINDUP..RECOVERY), False once it has finished/aborted."""
        if self.phase in (AttackPhase.NONE, AttackPhase.ABORTED):
            return False

        self.elapsed_in_phase += dt
        self.total_elapsed += dt
        durations = self.timing()
        order = [AttackPhase.WINDUP, AttackPhase.ACCELERATION, AttackPhase.CONTACT, AttackPhase.FOLLOW_THROUGH, AttackPhase.RECOVERY]
        i = order.index(self.phase)
        if self.elapsed_in_phase >= durations[i]:
            self.elapsed_in_phase -= durations[i]
            if i + 1 < len(order):
                self.phase = order[i + 1]
            else:
                self.phase = AttackPhase.NONE
                return False
        return True

    def can_abort(self) -> bool:
        """A feint/redirect (design doc §17) is only possible before the
        attack commits — during WINDUP or early ACCELERATION."""
        return self.phase == AttackPhase.WINDUP or (
            self.phase == AttackPhase.ACCELERATION and self.phase_progress() < 0.4
        )

    def abort(self) -> None:
        self.phase = AttackPhase.ABORTED

    def redirect(self, new_type: AttackType, new_target_offset: Vec3) -> None:
        """A feint payoff: cancel the telegraphed line and re-aim into a
        new one, paying a small extra windup rather than teleporting the
        blade there (design doc §88-89)."""
        self.aborted_to = new_type
        self.attack_type = new_type
        self.target_local_offset = new_target_offset
        self.phase = AttackPhase.WINDUP
        self.elapsed_in_phase = 0.0
        self.is_feint = False

    def sample_blade_local_offset(self) -> Vec3:
        """Where the blade tip *wants* to be, in the attacker's local
        frame, at the current point in the trajectory. Windup eases back
        from target toward start; acceleration/contact eases toward
        target; follow-through overshoots slightly past target; recovery
        eases back to a neutral guard offset."""
        p = self.phase_progress()
        ease_out = 1 - (1 - p) ** 2
        ease_in = p * p

        if self.phase == AttackPhase.WINDUP:
            return vlerp(self.target_local_offset, self.start_local_offset, ease_out)
        if self.phase == AttackPhase.ACCELERATION:
            return vlerp(self.start_local_offset, self.target_local_offset, ease_in)
        if self.phase == AttackPhase.CONTACT:
            return self.target_local_offset
        if self.phase == AttackPhase.FOLLOW_THROUGH:
            overshoot = self.target_local_offset + (self.target_local_offset - self.start_local_offset) * 0.12
            return vlerp(self.target_local_offset, overshoot, ease_out)
        if self.phase == AttackPhase.RECOVERY:
            neutral = (self.start_local_offset + self.target_local_offset) * 0.5
            return vlerp(self.target_local_offset, neutral, ease_out)
        return self.target_local_offset

    def is_in_contact_window(self) -> bool:
        return self.phase in (AttackPhase.ACCELERATION, AttackPhase.CONTACT, AttackPhase.FOLLOW_THROUGH)
