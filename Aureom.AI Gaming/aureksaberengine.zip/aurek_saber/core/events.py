"""
aurek_saber.core.events
=========================
Combat event bus (design doc §59). Every meaningful thing that happens in a
duel — a swing starting, a blade contact, a perfect parry, a stagger — is
emitted as a CombatEvent. Camera, audio, replay, training-analytics and the
AI's own opponent model all subscribe to this stream rather than reaching
into simulation internals, which keeps the simulation authoritative
(design doc §90).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List


class EventType(Enum):
    DUEL_STARTED = auto()
    DUEL_ENDED = auto()
    BLADE_SWING = auto()
    BLADE_CONTACT = auto()
    PARRY = auto()
    PERFECT_PARRY = auto()
    BLOCK = auto()
    FAILED_PARRY = auto()
    FEINT = auto()
    COUNTER = auto()
    DISARM = auto()
    HIT = auto()
    STAGGER = auto()
    BALANCE_LOST = auto()
    BLADE_LOCK = auto()
    FORCE_PUSH = auto()
    FORCE_PULL = auto()
    RETREAT = auto()
    STANCE_CHANGE = auto()
    GUARD_CHANGE = auto()
    ATTACK_STARTED = auto()
    ATTACK_MISSED = auto()
    ATTACK_ABORTED = auto()


@dataclass
class CombatEvent:
    type: EventType
    tick: int
    time: float
    source: str = ""
    target: str = ""
    data: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        extra = f" {self.data}" if self.data else ""
        return f"[t={self.time:7.3f} #{self.tick:06d}] {self.type.name:16s} {self.source}->{self.target}{extra}"


class EventBus:
    def __init__(self) -> None:
        self._subscribers: Dict[EventType, List[Callable[[CombatEvent], None]]] = {}
        self._global_subscribers: List[Callable[[CombatEvent], None]] = []
        self.log: List[CombatEvent] = []

    def subscribe(self, event_type: EventType, callback: Callable[[CombatEvent], None]) -> None:
        self._subscribers.setdefault(event_type, []).append(callback)

    def subscribe_all(self, callback: Callable[[CombatEvent], None]) -> None:
        self._global_subscribers.append(callback)

    def publish(self, event: CombatEvent) -> None:
        self.log.append(event)
        for cb in self._subscribers.get(event.type, []):
            cb(event)
        for cb in self._global_subscribers:
            cb(event)

    def clear(self) -> None:
        self.log.clear()
