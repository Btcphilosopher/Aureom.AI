"""
aurek_saber.core.enums
=========================
Shared vocabulary used across combat / character / ai layers. Centralised
here (rather than declared in `combat/*`) so every layer can depend
downward on `core` without circular imports.
"""

from __future__ import annotations

from enum import Enum, auto


class DistanceZone(Enum):
    """design doc §21"""

    OUT_OF_RANGE = auto()
    LONG_RANGE = auto()
    MEASURE = auto()
    ENGAGEMENT = auto()
    CLOSE = auto()
    CLINCH = auto()


class GuardZone(Enum):
    """design doc §12. OPEN = blade not covering any zone (a real
    vulnerability, not a menu default)."""

    HIGH_LEFT = auto()
    HIGH_RIGHT = auto()
    LOW_LEFT = auto()
    LOW_RIGHT = auto()
    CENTER = auto()
    OPEN = auto()


class Stance(Enum):
    """design doc §19"""

    NEUTRAL = auto()
    AGGRESSIVE = auto()
    DEFENSIVE = auto()
    DUELIST = auto()
    POWER = auto()
    MOBILE = auto()
    TWO_HANDED = auto()
    ONE_HANDED = auto()


class AttackType(Enum):
    """design doc §14"""

    HORIZONTAL = auto()
    VERTICAL = auto()
    DIAGONAL = auto()
    THRUST = auto()
    RISING = auto()
    DESCENDING = auto()
    SHORT = auto()
    LONG = auto()
    COUNTER = auto()
    FEINT = auto()


class AttackPhase(Enum):
    """design doc §15"""

    NONE = auto()
    WINDUP = auto()
    ACCELERATION = auto()
    CONTACT = auto()
    FOLLOW_THROUGH = auto()
    RECOVERY = auto()
    ABORTED = auto()


class ContactType(Enum):
    """design doc §8"""

    CLEAN_BLOCK = auto()
    GLANCING_BLOCK = auto()
    EDGE_CONTACT = auto()
    DIRECT_CONTACT = auto()
    BLADE_LOCK = auto()
    PARRY = auto()
    PERFECT_PARRY = auto()
    FAILED_PARRY = auto()
    DISARM_ATTEMPT = auto()
    COUNTER_CONTACT = auto()


class ConsequenceType(Enum):
    """design doc §42 — fictional, configurable gameplay consequences
    rather than a literal HP subtraction."""

    NONE = auto()
    CLEAN_CONTACT = auto()
    GLANCING_CONTACT = auto()
    ARMOUR_CONTACT = auto()
    WEAPON_CONTACT = auto()
    LIMB_DISABLED = auto()
    CRITICAL_CONTACT = auto()


class CombatIntent(Enum):
    """design doc §39 — the action vocabulary both AI and player intent
    resolve to before the controller turns it into footwork/blade motion."""

    NONE = auto()
    ATTACK = auto()
    FEINT = auto()
    PARRY = auto()
    RETREAT = auto()
    ADVANCE = auto()
    CIRCLE_LEFT = auto()
    CIRCLE_RIGHT = auto()
    WAIT = auto()
    FORCE_ABILITY = auto()
    COUNTER = auto()


class DuelOutcome(Enum):
    """design doc §57"""

    ONGOING = auto()
    DISARMED = auto()
    DEFEATED = auto()
    INCAPACITATED = auto()
    FORCED_RETREAT = auto()
    CRITICAL_HIT = auto()
    SURRENDER = auto()


class CombatantDuelState(Enum):
    """design doc §58"""

    IDLE = auto()
    AWARE = auto()
    MEASURING = auto()
    ENGAGED = auto()
    ATTACKING = auto()
    DEFENDING = auto()
    PARRYING = auto()
    COUNTERING = auto()
    STAGGERED = auto()
    DISARMED = auto()
    RETREATING = auto()
    DEFEATED = auto()


class BodyZone(Enum):
    """design doc §43 — content-configurable; the engine only needs a zone
    identity to route reaction/consequence logic, dismemberment content
    itself is opt-in and lives in `content/`."""

    HEAD = auto()
    TORSO = auto()
    LEFT_ARM = auto()
    RIGHT_ARM = auto()
    LEFT_LEG = auto()
    RIGHT_LEG = auto()
