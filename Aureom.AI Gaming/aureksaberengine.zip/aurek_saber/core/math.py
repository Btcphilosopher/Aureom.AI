"""
aurek_saber.core.math
======================
Shared vector / geometry math for the whole engine.

Design note: the engine is a *simulation core*, not a renderer, so we keep
orientation as a forward-facing unit vector + an explicit "up" (world Y-up,
right-handed) rather than pulling in a full quaternion/transform stack. This
is enough to drive footwork, blade orientation, guard geometry and IK
targets, and it keeps every combat formula in this codebase readable in
plain vector algebra. A rendering integration can trivially convert
(position, forward, up) into a transform/quaternion at the presentation
boundary.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

Vec3 = np.ndarray


def vec3(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> Vec3:
    return np.array([x, y, z], dtype=np.float64)


ZERO = vec3(0.0, 0.0, 0.0)
UP = vec3(0.0, 1.0, 0.0)
FORWARD = vec3(0.0, 0.0, 1.0)
RIGHT = vec3(1.0, 0.0, 0.0)


def length(v: Vec3) -> float:
    return float(np.linalg.norm(v))


def normalize(v: Vec3, fallback: Vec3 = FORWARD) -> Vec3:
    n = length(v)
    if n < 1e-9:
        return fallback.copy()
    return v / n


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * clamp(t, 0.0, 1.0)


def vlerp(a: Vec3, b: Vec3, t: float) -> Vec3:
    return a + (b - a) * clamp(t, 0.0, 1.0)


def move_toward(current: float, target: float, max_delta: float) -> float:
    """Numeric approach with a hard rate cap — the workhorse of every
    "no teleporting" constraint in the engine (see design doc §88)."""
    diff = target - current
    if abs(diff) <= max_delta:
        return target
    return current + math.copysign(max_delta, diff)


def vmove_toward(current: Vec3, target: Vec3, max_delta: float) -> Vec3:
    delta = target - current
    dist = length(delta)
    if dist <= max_delta or dist < 1e-9:
        return target.copy()
    return current + delta / dist * max_delta


def signed_angle(a: Vec3, b: Vec3, axis: Vec3 = UP) -> float:
    """Signed angle in radians from `a` to `b`, measured about `axis`
    (projected onto the plane perpendicular to axis). Positive = clockwise
    looking down -axis, matching a standard right-handed yaw."""
    a_p = a - axis * np.dot(a, axis)
    b_p = b - axis * np.dot(b, axis)
    a_p = normalize(a_p, a)
    b_p = normalize(b_p, b)
    dot = clamp(float(np.dot(a_p, b_p)), -1.0, 1.0)
    ang = math.acos(dot)
    cross = np.cross(a_p, b_p)
    if np.dot(cross, axis) < 0:
        ang = -ang
    return ang


def angle_between(a: Vec3, b: Vec3) -> float:
    na, nb = normalize(a), normalize(b)
    return math.acos(clamp(float(np.dot(na, nb)), -1.0, 1.0))


def rotate_yaw(v: Vec3, radians: float) -> Vec3:
    c, s = math.cos(radians), math.sin(radians)
    x, y, z = v
    return vec3(x * c + z * s, y, -x * s + z * c)


def horizontal(v: Vec3) -> Vec3:
    return vec3(v[0], 0.0, v[2])


@dataclass
class Orientation:
    """Decoupled facing state: body heading vs. weapon/blade heading vs.
    head/gaze heading (design doc §24-25). Each is a yaw-plane unit vector
    plus a small vertical (pitch) component for blade/gaze aiming."""

    forward: Vec3 = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.forward is None:
            self.forward = FORWARD.copy()
        else:
            self.forward = normalize(self.forward)

    def turn_toward(self, target_dir: Vec3, max_radians: float) -> None:
        target_dir = normalize(target_dir)
        ang = signed_angle(self.forward, target_dir)
        step = clamp(ang, -max_radians, max_radians)
        self.forward = normalize(rotate_yaw(self.forward, step))
