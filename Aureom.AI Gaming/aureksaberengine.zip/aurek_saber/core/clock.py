"""
aurek_saber.core.clock
========================
Deterministic fixed-timestep simulation clock (design doc §71, §60).

The combat simulation always advances in fixed 1/120s steps regardless of
how fast/slow the host loop calls `tick()`. This is what makes the engine
replay-deterministic: given the same seed and the same recorded intents,
`advance(dt)` called with any wall-clock dt produces the exact same
sequence of simulation ticks.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List

SIMULATION_HZ = 120.0
SIMULATION_DT = 1.0 / SIMULATION_HZ

# Sanity cap so a debugger breakpoint / hitch doesn't cause a "spiral of
# death" catch-up burst of thousands of steps.
MAX_STEPS_PER_ADVANCE = 16


@dataclass
class FixedTimestepClock:
    dt: float = SIMULATION_DT
    accumulator: float = 0.0
    tick_index: int = 0
    sim_time: float = 0.0
    on_tick: List[Callable[[int, float], None]] = field(default_factory=list)

    def advance(self, wall_dt: float) -> int:
        """Feed real elapsed time in; returns how many fixed steps ran."""
        self.accumulator += wall_dt
        steps = 0
        while self.accumulator >= self.dt and steps < MAX_STEPS_PER_ADVANCE:
            self.accumulator -= self.dt
            self.tick_index += 1
            self.sim_time += self.dt
            for cb in self.on_tick:
                cb(self.tick_index, self.dt)
            steps += 1
        return steps

    def alpha(self) -> float:
        """Interpolation fraction into the *next* tick, for render
        smoothing between fixed simulation steps."""
        return self.accumulator / self.dt if self.dt > 0 else 0.0

    def run_fixed_ticks(self, n: int) -> None:
        """Headless/replay mode: run exactly n ticks with no wall-clock
        involved at all (used by self-play and tests)."""
        for _ in range(n):
            self.tick_index += 1
            self.sim_time += self.dt
            for cb in self.on_tick:
                cb(self.tick_index, self.dt)
