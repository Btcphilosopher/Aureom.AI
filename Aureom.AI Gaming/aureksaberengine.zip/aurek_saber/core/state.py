"""
aurek_saber.core.state
=========================
Canonical simulation state (design doc §77-78). `DuelState` is the single
source of truth the whole engine reads and writes each tick — camera,
audio, replay and AI all derive from it rather than keeping their own
shadow copies.

`CombatantState.blade`/`handle` are typed loosely (`Any`) to avoid a
circular import between `core` (which everything depends on) and `combat`
(which depends on `core`); `combat.duel` is what actually populates them
with real `SaberBlade`/`SaberHandle` instances.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .enums import (
    AttackPhase,
    CombatantDuelState,
    CombatIntent,
    DistanceZone,
    DuelOutcome,
    GuardZone,
    Stance,
)
from .math import FORWARD, UP, ZERO, Vec3, vec3


@dataclass
class CombatantState:
    combatant_id: str

    # Physical body state
    position: Vec3 = field(default_factory=lambda: ZERO.copy())
    velocity: Vec3 = field(default_factory=lambda: ZERO.copy())
    body_forward: Vec3 = field(default_factory=lambda: FORWARD.copy())
    head_forward: Vec3 = field(default_factory=lambda: FORWARD.copy())
    angular_velocity: float = 0.0  # yaw rate, rad/s

    # Weapon (populated by combat.blade.SaberBlade / SaberHandle)
    blade: Any = None
    handle: Any = None

    # Combat systems
    stance: Stance = Stance.NEUTRAL
    guard: GuardZone = GuardZone.CENTER
    stamina: float = 100.0
    max_stamina: float = 100.0
    balance: float = 100.0  # 100 = perfectly balanced, 0 = falling
    duel_state: CombatantDuelState = CombatantDuelState.IDLE

    # Attack in progress
    attack_phase: AttackPhase = AttackPhase.NONE
    attack_type: Optional[Any] = None
    attack_elapsed: float = 0.0
    attack_target_id: Optional[str] = None

    # Intent (what the controller/AI wants to do this tick)
    intent: CombatIntent = CombatIntent.WAIT
    intent_target: Optional[str] = None

    # Health / consequence bookkeeping (design doc §42-43)
    limb_disabled: Dict[str, bool] = field(default_factory=dict)
    disarmed: bool = False
    incapacitated: bool = False
    surrendered: bool = False

    # Misc bookkeeping
    animation_state: str = "idle"
    reaction_state: str = "none"
    ability_state: Dict[str, float] = field(default_factory=dict)
    fatigue: float = 0.0  # 0 = fresh, 1 = exhausted

    def is_out(self) -> bool:
        return self.incapacitated or self.surrendered or self.disarmed and self.balance <= 0


@dataclass
class DuelState:
    duel_id: str
    tick: int = 0
    timestamp: float = 0.0

    fighter_a: Optional[CombatantState] = None
    fighter_b: Optional[CombatantState] = None

    distance: float = 0.0
    distance_zone: DistanceZone = DistanceZone.OUT_OF_RANGE

    contact_state: Optional[Any] = None  # combat.parry.ContactResult | None
    environment: Dict[str, Any] = field(default_factory=dict)
    camera_state: Dict[str, Any] = field(default_factory=dict)

    outcome: DuelOutcome = DuelOutcome.ONGOING
    intensity: float = 0.0  # design doc §92

    events: List[Any] = field(default_factory=list)

    def fighters(self) -> List[CombatantState]:
        return [f for f in (self.fighter_a, self.fighter_b) if f is not None]

    def other(self, combatant_id: str) -> Optional[CombatantState]:
        for f in self.fighters():
            if f.combatant_id != combatant_id:
                return f
        return None

    def get(self, combatant_id: str) -> Optional[CombatantState]:
        for f in self.fighters():
            if f.combatant_id == combatant_id:
                return f
        return None
