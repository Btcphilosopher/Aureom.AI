"""Small shared helpers: vector math, clamping/lerp, logging."""
