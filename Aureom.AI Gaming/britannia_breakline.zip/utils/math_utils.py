"""Scalar math helpers used across physics/AI/procedural systems."""
from __future__ import annotations


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * clamp(t, 0.0, 1.0)


def approach(current: float, target: float, delta: float) -> float:
    """Move `current` toward `target` by at most `delta` (always positive)."""
    if current < target:
        return min(current + delta, target)
    return max(current - delta, target)


def aabb_overlap(ax, ay, aw, ah, bx, by, bw, bh) -> bool:
    return ax < bx + bw and ax + aw > bx and ay < by + bh and ay + ah > by
