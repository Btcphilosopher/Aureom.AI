"""Minimal 2D/3D vector type (no numpy dependency, pygame-only per spec)."""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class Vec2:
    x: float = 0.0
    y: float = 0.0

    def __add__(self, o: "Vec2") -> "Vec2":
        return Vec2(self.x + o.x, self.y + o.y)

    def __sub__(self, o: "Vec2") -> "Vec2":
        return Vec2(self.x - o.x, self.y - o.y)

    def __mul__(self, s: float) -> "Vec2":
        return Vec2(self.x * s, self.y * s)

    __rmul__ = __mul__

    def length(self) -> float:
        return math.hypot(self.x, self.y)

    def normalized(self) -> "Vec2":
        length = self.length()
        if length < 1e-8:
            return Vec2(0.0, 0.0)
        return Vec2(self.x / length, self.y / length)

    def as_tuple(self) -> tuple[float, float]:
        return (self.x, self.y)
