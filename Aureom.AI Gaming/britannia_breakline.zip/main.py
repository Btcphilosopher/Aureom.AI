#!/usr/bin/env python3
"""Britannia Breakline — entry point.

    python main.py                        # 2-player local match, player 1 on WASD+JKLI
    python main.py --players 8            # 8-player match; slots beyond available
                                           # keyboard zones/gamepads are bot-controlled
    python main.py --seed 12345           # deterministic run from a fixed seed
    python main.py --headless-frames 3000 # run the sim with no window, for CI/verification
    python main.py --screenshot out.png   # play interactively, then save a screenshot on exit

Controls (keyboard zone 1 / player 1): WASD move, J light attack, K heavy
attack, L grab, I special. Up to 3 more keyboard zones share the keyboard
for local players 2-4 (see input/keybindings.py); connected gamepads take
priority over keyboard zones; any remaining player slots are bot-controlled.
F1 toggles the adaptive-AI debug overlay. Escape quits.
"""
from __future__ import annotations

import argparse
import os
import random
import sys

from entities.characters import ROSTER, ROSTER_BY_NAME


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Britannia Breakline")
    parser.add_argument("--players", type=int, default=2, help="number of players, 1-8 (default 2)")
    parser.add_argument("--seed", type=int, default=None, help="deterministic run seed")
    parser.add_argument("--zones", type=int, default=3, help="number of city zones to route through")
    parser.add_argument("--character", type=str, default=None,
                         help="force player 1's character, e.g. 'The Dockhand'")
    parser.add_argument("--headless-frames", type=int, default=0,
                         help="run N simulation frames with no window and exit (verification/demo mode)")
    parser.add_argument("--screenshot", type=str, default=None,
                         help="save a PNG screenshot of the final frame to this path before exiting")
    return parser.parse_args(argv)


def build_roster(num_players: int, forced_character: str | None) -> list[type]:
    num_players = max(1, min(8, num_players))
    classes = [ROSTER[i % len(ROSTER)] for i in range(num_players)]
    if forced_character:
        cls = ROSTER_BY_NAME.get(forced_character)
        if cls is None:
            raise SystemExit(f"Unknown character '{forced_character}'. Options: {list(ROSTER_BY_NAME)}")
        classes[0] = cls
    return classes


def print_roster_banner(classes: list[type]) -> None:
    print("=" * 72)
    print("BRITANNIA BREAKLINE — squad loadout")
    for i, cls in enumerate(classes):
        p = cls.profile
        tag = "BOT" if i >= 4 else "LOCAL"
        print(f"  P{i + 1} [{tag:5}] {p.display_name:16} {p.role:28} passive={p.passive_name}")
    print("=" * 72)


def run_headless(world, num_frames: int) -> None:
    from core.game_loop import FixedTimestepLoop

    loop = FixedTimestepLoop(world, poll_inputs=world.poll_inputs)
    loop.run_headless(num_frames)

    alive = sum(1 for p in world.players if p.alive)
    downed = sum(1 for p in world.players if p.downed)
    mods = world.director.get_modifiers()
    print(f"[headless] ran {world.frame_count} frames | seed={world.rng_factory.master_seed}")
    print(f"[headless] room={world.current_room_id} zone_order={world.level.zone_order}")
    print(f"[headless] players alive={alive} downed={downed} victory={world.victory} game_over={world.game_over}")
    print(f"[headless] adaptive director notes: {mods.notes}")
    print(f"[headless] telemetry: strategy={world.telemetry.dominant_strategy()} "
          f"coordination={world.telemetry.coordination_score():.2f}")


def run_interactive(world, screenshot_path: str | None) -> None:
    import pygame

    from core.constants import SCREEN_HEIGHT, SCREEN_WIDTH
    from core.game_loop import FixedTimestepLoop
    from rendering.renderer import Renderer

    pygame.init()
    pygame.display.set_caption("Britannia Breakline")
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    renderer = Renderer(screen)

    state = {"quit": False}

    def should_quit() -> bool:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                state["quit"] = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    state["quit"] = True
                elif event.key == pygame.K_F1:
                    renderer.show_debug = not renderer.show_debug
        return state["quit"]

    def render() -> None:
        renderer.render(world)
        pygame.display.flip()

    loop = FixedTimestepLoop(world, poll_inputs=world.poll_inputs, render=render)
    loop.run_interactive(should_quit)

    if screenshot_path:
        pygame.image.save(screen, screenshot_path)
        print(f"Saved screenshot to {screenshot_path}")

    pygame.quit()


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    seed = args.seed if args.seed is not None else random.randint(0, 2**31 - 1)
    classes = build_roster(args.players, args.character)
    print_roster_banner(classes)

    headless = args.headless_frames > 0
    if headless:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    import pygame
    pygame.init()
    if headless:
        pygame.display.set_mode((1, 1))

    from core.world import World
    world = World(seed=seed, character_classes=classes, headless=headless, num_zones=args.zones)

    if headless:
        run_headless(world, args.headless_frames)
    else:
        run_interactive(world, args.screenshot)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
