"""Main draw routine: background, entities (as vector silhouettes whose pose
reacts to animation phase), hazards, HUD and screen-shake compositing.
"""
from __future__ import annotations

import random

import pygame

from core.constants import PALETTE, SCREEN_HEIGHT, SCREEN_WIDTH
from procedural.zone_definitions import ZONES
from rendering import hud, vfx
from rendering.background import draw_background

_ZONE_ACCENTS = {z.name: z.accent_color for z in ZONES}


class Renderer:
    def __init__(self, screen: "pygame.Surface"):
        self.screen = screen
        pygame.font.init()
        self.font = pygame.font.SysFont("consolas", 15)
        self.big_font = pygame.font.SysFont("consolas", 28, bold=True)
        self._shake_rng = random.Random(1)
        self.show_debug = False

    def render(self, world) -> None:
        room = world.level.room(world.current_room_id)
        accent = _ZONE_ACCENTS.get(room.zone_name, PALETTE["brass"])
        shake = vfx.screen_shake_offset(world.hitstop.screen_shake, self._shake_rng)

        draw_background(self.screen, room.zone_name, accent, world.camera.x, world.frame_count)

        surface = self.screen
        offset = shake

        for zone in world.slow_zones:
            self._draw_hazard(surface, world.camera, zone, offset)
        for mine in world.mines:
            self._draw_mine(surface, world.camera, mine, offset)

        drawables = sorted(world.players + world.enemies, key=lambda e: e.body.y)
        for entity in drawables:
            if entity.alive or getattr(entity, "downed", False):
                self._draw_entity(surface, world, entity, offset)

        for proj in world.projectiles:
            self._draw_projectile(surface, world.camera, proj, offset)

        hud.draw_hud(surface, self.font, world, self.show_debug)

        if world.victory:
            self._center_text(surface, "RUN COMPLETE — BREAKLINE HELD", PALETTE["slum_neon"])
        elif world.game_over:
            self._center_text(surface, "TEAM DOWN — LONDON FALLS SILENT", PALETTE["imperial_red"])

    def _draw_entity(self, surface, world, entity, offset) -> None:
        sx, sy = world.camera.world_to_screen(entity.body.x, entity.body.y, entity.body.z)
        sx += offset[0]
        sy += offset[1]
        zoom = world.camera.zoom
        w = int(entity.width * zoom)
        h = int(entity.height * zoom)

        base_color = getattr(entity.profile, "color", (200, 200, 200))
        frozen = world.hitstop.is_frozen(entity.id)
        color = vfx.hit_flash_color(base_color, frozen)

        downed = getattr(entity, "downed", False)
        rect_h = h // 2 if downed else h
        rect = pygame.Rect(int(sx - w / 2), int(sy - rect_h), w, rect_h)
        pygame.draw.rect(surface, color, rect, border_radius=4)
        pygame.draw.rect(surface, PALETTE["bone_white"], rect, 1, border_radius=4)

        # Weapon/limb telegraph: a line that extends in front of the entity
        # during an attack's active window, giving the swing visible reach.
        animator = getattr(entity, "animator", None)
        if animator is not None and animator.phase in ("startup", "active"):
            reach = 10 + 40 * animator.progress
            lx = sx + entity.body.facing * (w / 2 + reach * zoom)
            line_color = PALETTE["signal_amber"] if animator.phase == "active" else PALETTE["fog_grey"]
            pygame.draw.line(surface, line_color, (sx, sy - rect_h / 2), (lx, sy - rect_h / 2), 4)

        if getattr(entity, "armored", False):
            pygame.draw.rect(surface, PALETTE["brass"], rect, 3, border_radius=4)

        if entity.faction == "enemy" and entity.alive:
            hp_ratio = entity.hp / max(1.0, entity.max_hp)
            bw = w
            pygame.draw.rect(surface, PALETTE["fog_grey"], (rect.x, rect.y - 8, bw, 4))
            pygame.draw.rect(surface, PALETTE["imperial_red"], (rect.x, rect.y - 8, int(bw * hp_ratio), 4))

    def _draw_mine(self, surface, camera, mine, offset) -> None:
        sx, sy = camera.world_to_screen(mine.body.x, mine.body.y)
        color = PALETTE["signal_amber"] if mine.armed else PALETTE["fog_grey"]
        pygame.draw.circle(surface, color, (int(sx + offset[0]), int(sy + offset[1])), max(3, int(6 * camera.zoom)))

    def _draw_hazard(self, surface, camera, zone, offset) -> None:
        sx, sy = camera.world_to_screen(zone.body.x, zone.body.y)
        radius = int(zone.radius * camera.zoom)
        hazard_surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(hazard_surf, (*PALETTE["slum_neon"], 70), (radius, radius), radius)
        surface.blit(hazard_surf, (sx - radius + offset[0], sy - radius + offset[1]))

    def _draw_projectile(self, surface, camera, proj, offset) -> None:
        sx, sy = camera.world_to_screen(proj.body.x, proj.body.y)
        pygame.draw.circle(surface, proj.color, (int(sx + offset[0]), int(sy + offset[1])), 4)

    def _center_text(self, surface, text, color) -> None:
        surf = self.big_font.render(text, True, color)
        surface.blit(surf, (SCREEN_WIDTH // 2 - surf.get_width() // 2, SCREEN_HEIGHT // 2 - 20))
