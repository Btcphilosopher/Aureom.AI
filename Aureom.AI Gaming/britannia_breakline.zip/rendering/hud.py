"""HUD: per-player HP/meter bars, combo counters, room banner, and an
optional adaptive-AI debug overlay (toggle with F1) showing the director's
current rule-weighted modifiers so "adaptive AI in action" is visible, not
just implied.
"""
from __future__ import annotations

import pygame

from core.constants import PALETTE, SCREEN_WIDTH

BAR_W, BAR_H = 130, 10


def draw_hud(screen: "pygame.Surface", font: "pygame.font.Font", world, show_debug: bool) -> None:
    hud_rows = max(1, -(-len(world.players) // 4))  # ceil division: 4 players per row
    for i, player in enumerate(world.players):
        x = 12 + (i % 4) * 150
        y = 12 + (i // 4) * 46
        _draw_bar(screen, x, y, BAR_W, BAR_H, player.hp / max(1.0, player.max_hp), PALETTE["imperial_red"])
        _draw_bar(screen, x, y + 12, BAR_W, 6, player.meter / max(1.0, player.max_meter), PALETTE["slum_neon"])
        label = f"P{i + 1} {player.profile.display_name.replace('The ', '')}"
        if player.downed:
            label += " [DOWN]"
        screen.blit(font.render(label, True, PALETTE["bone_white"]), (x, y - 14))
        if player.combo.hits > 1:
            combo_txt = font.render(f"x{player.combo.hits}", True, PALETTE["signal_amber"])
            screen.blit(combo_txt, (x + BAR_W + 4, y))

    below_hud_y = 12 + hud_rows * 46 + 4
    if world.last_room_message:
        msg = font.render(world.last_room_message, True, PALETTE["bone_white"])
        screen.blit(msg, (SCREEN_WIDTH // 2 - msg.get_width() // 2, below_hud_y))
        below_hud_y += 20

    if show_debug:
        _draw_debug_overlay(screen, font, world, below_hud_y)


def _draw_bar(screen, x, y, w, h, ratio, color) -> None:
    ratio = max(0.0, min(1.0, ratio))
    pygame.draw.rect(screen, PALETTE["fog_grey"], (x, y, w, h))
    pygame.draw.rect(screen, color, (x, y, int(w * ratio), h))
    pygame.draw.rect(screen, PALETTE["bone_white"], (x, y, w, h), 1)


def _draw_debug_overlay(screen, font, world, start_y: int) -> None:
    mods = world.director.get_modifiers()
    lines = [
        "ADAPTIVE AI DIRECTOR (F1 to hide)",
        f"strategy={world.telemetry.dominant_strategy()} coordination={world.telemetry.coordination_score():.2f}",
        f"hazard_density={mods.hazard_density:.2f} armored_weight={mods.armored_spawn_weight:.2f}",
        f"ambush_chance={mods.ambush_squad_chance:.2f} ranged_weight={mods.ranged_spawn_weight:.2f}",
    ]
    lines.extend(f"- {n}" for n in mods.notes[-3:])
    for i, line in enumerate(lines):
        surf = font.render(line, True, PALETTE["slum_neon"])
        screen.blit(surf, (12, start_y + i * 16))
