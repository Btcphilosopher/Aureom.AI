"""Procedural, per-zone backdrop: a soot-dark sky, a silhouette skyline built
from the zone's accent colour, and slow parallax so the crowd never reads
as floating in a void.
"""
from __future__ import annotations

import math

import pygame

from core.constants import PALETTE, SCREEN_HEIGHT, SCREEN_WIDTH


def draw_background(screen: "pygame.Surface", zone_name: str, accent_color: tuple[int, int, int],
                     camera_x: float, frame_count: int) -> None:
    screen.fill(PALETTE["soot_black"])

    horizon_y = int(SCREEN_HEIGHT * 0.62)
    pygame.draw.rect(screen, _blend(PALETTE["soot_black"], PALETTE["fog_grey"], 0.25),
                      (0, 0, SCREEN_WIDTH, horizon_y))

    # Skyline silhouettes, offset by a fraction of camera_x for cheap parallax.
    rng_seed = sum(ord(c) for c in zone_name)
    parallax = camera_x * 0.05
    for i in range(14):
        seed = (rng_seed + i * 97) % 997
        w = 40 + (seed % 70)
        h = 60 + (seed % 220)
        x = (i * 105 - parallax) % (SCREEN_WIDTH + 200) - 100
        pygame.draw.rect(screen, _blend(PALETTE["soot_black"], accent_color, 0.18),
                          (x, horizon_y - h, w, h))

    # Ground band.
    pygame.draw.rect(screen, _blend(PALETTE["soot_black"], PALETTE["fog_grey"], 0.4),
                      (0, horizon_y, SCREEN_WIDTH, SCREEN_HEIGHT - horizon_y))

    # A slow neon strip pulse to sell "machine-city" ambience.
    pulse = (math.sin(frame_count / 40.0) + 1.0) / 2.0
    strip_color = _blend(accent_color, PALETTE["slum_neon"], 0.5 * pulse)
    pygame.draw.line(screen, strip_color, (0, horizon_y + 4), (SCREEN_WIDTH, horizon_y + 4), 2)


def _blend(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
