"""Screen-shake offset and hit-flash colouring — the visible half of
combat/hitstop.py's feedback loop.
"""
from __future__ import annotations

import random


def screen_shake_offset(magnitude: float, rng: random.Random) -> tuple[int, int]:
    if magnitude <= 0:
        return (0, 0)
    return (rng.randint(-int(magnitude), int(magnitude)), rng.randint(-int(magnitude), int(magnitude)))


def hit_flash_color(base_color: tuple[int, int, int], is_frozen: bool) -> tuple[int, int, int]:
    if not is_frozen:
        return base_color
    return tuple(min(255, c + 120) for c in base_color)
