"""Pygame-primitive rendering: no sprite sheets, a deliberate vector/silhouette
Anglo-futuristic art direction (industrial palette, geometric city backdrops)."""
