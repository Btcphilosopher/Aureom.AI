"""Default keyboard layouts for up to 4 keyboard-sharing players, plus the
gamepad axis/button mapping used for any connected joystick. Players beyond
available physical devices are bot-controlled (see multiplayer/bot_controller.py)
so an 8-player match is always playable/demoable on one machine.
"""
from __future__ import annotations

import pygame

# Four independent keyboard zones sharing one keyboard (classic local co-op
# convention). Slot 0 is the "main" WASD+space player.
KEYBOARD_LAYOUTS = [
    {
        "up": pygame.K_w, "down": pygame.K_s, "left": pygame.K_a, "right": pygame.K_d,
        "light": pygame.K_j, "heavy": pygame.K_k, "grab": pygame.K_l, "special": pygame.K_i,
    },
    {
        "up": pygame.K_UP, "down": pygame.K_DOWN, "left": pygame.K_LEFT, "right": pygame.K_RIGHT,
        "light": pygame.K_KP1, "heavy": pygame.K_KP2, "grab": pygame.K_KP3, "special": pygame.K_KP0,
    },
    {
        "up": pygame.K_t, "down": pygame.K_g, "left": pygame.K_f, "right": pygame.K_h,
        "light": pygame.K_r, "heavy": pygame.K_y, "grab": pygame.K_u, "special": pygame.K_5,
    },
    {
        "up": pygame.K_p, "down": pygame.K_SEMICOLON, "left": pygame.K_l, "right": pygame.K_QUOTE,
        "light": pygame.K_LEFTBRACKET, "heavy": pygame.K_RIGHTBRACKET, "grab": pygame.K_BACKSLASH,
        "special": pygame.K_MINUS,
    },
]

GAMEPAD_DEADZONE = 0.25
GAMEPAD_BUTTON_LIGHT = 0
GAMEPAD_BUTTON_HEAVY = 1
GAMEPAD_BUTTON_GRAB = 2
GAMEPAD_BUTTON_SPECIAL = 3
