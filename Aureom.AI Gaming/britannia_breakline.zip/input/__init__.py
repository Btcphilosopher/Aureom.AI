"""Input abstraction: per-player InputState, keyboard/gamepad polling, buffering."""
