"""Short input buffering so an attack press slightly before recovery ends
still registers — standard beat-em-up leniency, without which combat feels
unresponsive at 60fps.
"""
from __future__ import annotations

from dataclasses import dataclass, field

BUFFER_FRAMES = 6


@dataclass
class InputBuffer:
    pending: dict[str, int] = field(default_factory=dict)

    def push(self, action: str) -> None:
        self.pending[action] = BUFFER_FRAMES

    def tick(self) -> None:
        for action in list(self.pending.keys()):
            self.pending[action] -= 1
            if self.pending[action] <= 0:
                del self.pending[action]

    def consume(self, action: str) -> bool:
        if action in self.pending:
            del self.pending[action]
            return True
        return False
