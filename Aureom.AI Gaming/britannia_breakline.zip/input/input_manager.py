"""Produces a per-player InputState each frame from keyboard, gamepad, or a
bot policy. Downstream gameplay code (character_base) only ever sees
InputState, so it never has to know or care where the input came from.
"""
from __future__ import annotations

from dataclasses import dataclass

from input.keybindings import (
    GAMEPAD_BUTTON_GRAB,
    GAMEPAD_BUTTON_HEAVY,
    GAMEPAD_BUTTON_LIGHT,
    GAMEPAD_BUTTON_SPECIAL,
    GAMEPAD_DEADZONE,
    KEYBOARD_LAYOUTS,
)


@dataclass
class InputState:
    move_x: float = 0.0
    move_y: float = 0.0
    light_attack: bool = False
    heavy_attack: bool = False
    grab: bool = False
    special: bool = False


class PlayerInputSource:
    """Base class: keyboard/gamepad/bot sources all implement `poll`."""

    def poll(self, world_context: dict) -> InputState:
        raise NotImplementedError


class KeyboardInputSource(PlayerInputSource):
    def __init__(self, layout_index: int):
        self.layout = KEYBOARD_LAYOUTS[layout_index % len(KEYBOARD_LAYOUTS)]

    def poll(self, world_context: dict) -> InputState:
        import pygame
        keys = pygame.key.get_pressed()
        mx = (1 if keys[self.layout["right"]] else 0) - (1 if keys[self.layout["left"]] else 0)
        my = (1 if keys[self.layout["down"]] else 0) - (1 if keys[self.layout["up"]] else 0)
        return InputState(
            move_x=float(mx), move_y=float(my),
            light_attack=bool(keys[self.layout["light"]]),
            heavy_attack=bool(keys[self.layout["heavy"]]),
            grab=bool(keys[self.layout["grab"]]),
            special=bool(keys[self.layout["special"]]),
        )


class GamepadInputSource(PlayerInputSource):
    def __init__(self, joystick_index: int):
        import pygame
        self.joystick = pygame.joystick.Joystick(joystick_index)
        self.joystick.init()

    def poll(self, world_context: dict) -> InputState:
        j = self.joystick
        mx = j.get_axis(0) if j.get_numaxes() > 0 else 0.0
        my = j.get_axis(1) if j.get_numaxes() > 1 else 0.0
        mx = mx if abs(mx) > GAMEPAD_DEADZONE else 0.0
        my = my if abs(my) > GAMEPAD_DEADZONE else 0.0
        get = j.get_button
        return InputState(
            move_x=mx, move_y=my,
            light_attack=bool(get(GAMEPAD_BUTTON_LIGHT)) if j.get_numbuttons() > GAMEPAD_BUTTON_LIGHT else False,
            heavy_attack=bool(get(GAMEPAD_BUTTON_HEAVY)) if j.get_numbuttons() > GAMEPAD_BUTTON_HEAVY else False,
            grab=bool(get(GAMEPAD_BUTTON_GRAB)) if j.get_numbuttons() > GAMEPAD_BUTTON_GRAB else False,
            special=bool(get(GAMEPAD_BUTTON_SPECIAL)) if j.get_numbuttons() > GAMEPAD_BUTTON_SPECIAL else False,
        )


class InputManager:
    def __init__(self):
        self.sources: dict[int, PlayerInputSource] = {}

    def assign(self, player_index: int, source: PlayerInputSource) -> None:
        self.sources[player_index] = source

    def poll_all(self, world_context: dict) -> dict[int, InputState]:
        return {idx: src.poll(world_context) for idx, src in self.sources.items()}

    def poll_one(self, player_index: int, world_context: dict) -> InputState:
        """Poll a single slot with a per-player context (bots need to know
        which entity is "self" and where the enemies are; keyboard/gamepad
        sources simply ignore the context).
        """
        source = self.sources.get(player_index)
        if source is None:
            return InputState()
        return source.poll(world_context)
