"""Combat core: hitbox resolution, damage/knockback application, combo scaling."""
from combat.combat_resolver import CombatResolver
from combat.combo_system import ComboTracker
from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from combat.hitstop import HitstopManager
from core.event_bus import EventBus
from entities.entity import Entity
from physics.aabb import AABB


def make_entity(faction: str, x: float = 0.0) -> Entity:
    e = Entity(name="dummy", faction=faction, max_hp=100.0)
    e.body.x = x
    e.combo = ComboTracker()
    return e


def test_hit_applies_damage_and_knockback():
    bus = EventBus()
    resolver = CombatResolver(bus, HitstopManager())
    attacker = make_entity("player", x=0.0)
    target = make_entity("enemy", x=10.0)

    hitbox = Hitbox(
        owner_id=attacker.id, aabb=AABB(-10, -10, 40, 40), damage=15.0,
        damage_type=DamageType.LIGHT, knockback=(100.0, 0.0, 0.0), hitstun_frames=10, life_frames=1,
    )
    resolver.resolve([hitbox], [attacker, target])

    assert target.hp == 85.0
    assert target.body.vx != 0.0
    assert target.body.knockback_lock_frames == 10


def test_hitbox_does_not_hit_same_faction():
    bus = EventBus()
    resolver = CombatResolver(bus, HitstopManager())
    attacker = make_entity("player", x=0.0)
    ally = make_entity("player", x=5.0)
    hitbox = Hitbox(
        owner_id=attacker.id, aabb=AABB(-10, -10, 40, 40), damage=15.0,
        damage_type=DamageType.LIGHT, knockback=(0, 0, 0), hitstun_frames=0, life_frames=1,
    )
    resolver.resolve([hitbox], [attacker, ally])
    assert ally.hp == 100.0


def test_hitbox_hits_each_target_only_once():
    bus = EventBus()
    resolver = CombatResolver(bus, HitstopManager())
    attacker = make_entity("player", x=0.0)
    target = make_entity("enemy", x=5.0)
    hitbox = Hitbox(
        owner_id=attacker.id, aabb=AABB(-10, -10, 40, 40), damage=10.0,
        damage_type=DamageType.LIGHT, knockback=(0, 0, 0), hitstun_frames=0, life_frames=1,
    )
    resolver.resolve([hitbox], [attacker, target])
    resolver.resolve([hitbox], [attacker, target])  # same hitbox instance, second resolve pass
    assert target.hp == 90.0  # only hit once thanks to `already_hit`


def test_combo_multiplier_decays_and_resets():
    combo = ComboTracker()
    m1 = combo.register_hit()
    m2 = combo.register_hit()
    m3 = combo.register_hit()
    assert m1 == 1.0
    assert m2 < m1
    assert m3 < m2
    combo.reset()
    assert combo.hits == 0
    assert combo.register_hit() == 1.0


def test_armored_target_takes_reduced_damage_unless_pierced():
    bus = EventBus()
    resolver = CombatResolver(bus, HitstopManager())
    attacker = make_entity("player", x=0.0)
    armored_target = make_entity("enemy", x=5.0)
    armored_target.armored = True

    normal_hit = Hitbox(owner_id=attacker.id, aabb=AABB(-10, -10, 40, 40), damage=20.0,
                         damage_type=DamageType.LIGHT, knockback=(0, 0, 0), hitstun_frames=0, life_frames=1)
    resolver.resolve([normal_hit], [attacker, armored_target])
    assert armored_target.hp == 90.0  # halved

    attacker.combo.reset()  # isolate this assertion from the first hit's combo decay
    pierce_hit = Hitbox(owner_id=attacker.id, aabb=AABB(-10, -10, 40, 40), damage=20.0,
                         damage_type=DamageType.LIGHT, knockback=(0, 0, 0), hitstun_frames=0, life_frames=1,
                         armor_piercing=True)
    resolver.resolve([pierce_hit], [attacker, armored_target])
    assert armored_target.hp == 70.0  # full damage, not halved
