"""End-to-end determinism: the same seed, character roster and bot-driven
inputs must produce byte-identical simulation outcomes across runs. This is
the property the whole engine's "deterministic simulation core" claim rests
on, so it's exercised at the World level, not just in individual subsystems.
"""
import os

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame  # noqa: E402

pygame.init()
pygame.display.set_mode((1, 1))

from core.world import World  # noqa: E402
from entities.characters import ROSTER  # noqa: E402


def _run(seed: int, num_frames: int):
    world = World(seed=seed, character_classes=list(ROSTER), headless=True, num_zones=2)
    for _ in range(num_frames):
        world.step(world.poll_inputs())
    return world


def _snapshot(world) -> tuple:
    return tuple(
        (round(p.body.x, 4), round(p.body.y, 4), round(p.hp, 4), p.alive, p.downed)
        for p in world.players
    ) + (world.current_room_id, world.frame_count)


def test_identical_seed_yields_identical_outcome():
    world_a = _run(seed=2024, num_frames=400)
    world_b = _run(seed=2024, num_frames=400)
    assert _snapshot(world_a) == _snapshot(world_b)


def test_eight_player_match_runs_without_crashing():
    world = _run(seed=55, num_frames=200)
    assert world.frame_count == 200
    assert len(world.players) == 8
