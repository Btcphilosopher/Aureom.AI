"""The adaptive AI director must react to team composition/behaviour with
deterministic, rule-based (not learned) weight shifts.
"""
from ai.adaptive_director import AdaptiveAIDirector
from ai.telemetry import MatchTelemetry
from core.constants import ADAPTIVE_WINDOW_FRAMES
from core.event_bus import EventBus


class FakeProfile:
    def __init__(self, role):
        self.role = role


class FakeBody:
    def __init__(self, x, y):
        self.x, self.y = x, y


class FakePlayer:
    def __init__(self, role, x=0.0, y=0.0):
        self.profile = FakeProfile(role)
        self.body = FakeBody(x, y)
        self.alive = True
        self.downed = False


def _run_to_reevaluation(director, players):
    for _ in range(ADAPTIVE_WINDOW_FRAMES + 1):
        director.tick(players)


def test_tank_heavy_team_triggers_armored_spawn_bonus():
    bus = EventBus()
    director = AdaptiveAIDirector(MatchTelemetry(bus))
    players = [FakePlayer("Tank / Grappler"), FakePlayer("Defensive Anchor"),
               FakePlayer("Speed / Hit-and-Run DPS"), FakePlayer("Ranged Control")]
    _run_to_reevaluation(director, players)
    mods = director.get_modifiers()
    assert mods.armored_spawn_weight > 1.0


def test_split_team_triggers_ambush_bonus():
    bus = EventBus()
    director = AdaptiveAIDirector(MatchTelemetry(bus))
    # Scattered across the arena -> low coordination score.
    players = [FakePlayer("Speed / Hit-and-Run DPS", x=-400), FakePlayer("Ranged Control", x=400),
               FakePlayer("Utility / Traps / Control", x=-380, y=200), FakePlayer("Support / Buff / AI Disruptor", x=390, y=-200)]
    _run_to_reevaluation(director, players)
    mods = director.get_modifiers()
    assert mods.ambush_squad_chance > 0.15


def test_default_modifiers_are_neutral_before_first_evaluation():
    bus = EventBus()
    director = AdaptiveAIDirector(MatchTelemetry(bus))
    mods = director.get_modifiers()
    assert mods.hazard_density == 1.0
    assert mods.armored_spawn_weight == 1.0
