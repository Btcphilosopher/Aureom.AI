"""Procedural level generation must be fully deterministic given a seed."""
from core.rng import DeterministicRNG
from procedural.level_generator import generate_run
from procedural.room import RoomType


def _room_signature(run):
    return [
        (r.room_id, r.zone_name, r.room_type.value, r.layer, tuple(sorted(r.connections)))
        for r in sorted(run.rooms.values(), key=lambda x: x.room_id)
    ]


def test_same_seed_produces_identical_run():
    run_a = generate_run(DeterministicRNG(42))
    run_b = generate_run(DeterministicRNG(42))
    assert _room_signature(run_a) == _room_signature(run_b)
    assert run_a.zone_order == run_b.zone_order
    assert run_a.entry_room_id == run_b.entry_room_id


def test_different_seeds_can_produce_different_runs():
    run_a = generate_run(DeterministicRNG(1))
    run_b = generate_run(DeterministicRNG(2))
    assert _room_signature(run_a) != _room_signature(run_b) or run_a.zone_order != run_b.zone_order


def test_run_ends_in_a_boss_chamber():
    run = generate_run(DeterministicRNG(7))
    terminal_rooms = [r for r in run.rooms.values() if not r.connections]
    assert terminal_rooms
    assert all(r.room_type == RoomType.BOSS for r in terminal_rooms)


def test_every_room_reachable_from_entry():
    run = generate_run(DeterministicRNG(99))
    seen = set()
    frontier = [run.entry_room_id]
    while frontier:
        rid = frontier.pop()
        if rid in seen:
            continue
        seen.add(rid)
        frontier.extend(run.rooms[rid].connections)
    assert seen == set(run.rooms.keys())
