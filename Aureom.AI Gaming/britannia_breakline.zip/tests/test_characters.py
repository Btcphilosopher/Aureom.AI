"""Sanity checks across all 8 playable archetypes: each must define a role,
a passive, a stated weakness, a synergy note, and at least a light attack.
"""
import pytest

from entities.characters import ROSTER


@pytest.mark.parametrize("character_cls", ROSTER)
def test_character_profile_is_complete(character_cls):
    profile = character_cls.profile
    assert profile.display_name.startswith("The ")
    assert profile.role
    assert profile.passive_name and profile.passive_description
    assert profile.weakness
    assert profile.synergy
    assert profile.max_hp > 0
    assert profile.move_speed > 0


@pytest.mark.parametrize("character_cls", ROSTER)
def test_character_has_attacks(character_cls):
    instance = character_cls(player_index=0)
    attacks = instance.build_attacks()
    assert "light" in attacks
    for attack in attacks.values():
        assert attack.startup > 0
        assert attack.active > 0
        assert attack.recovery >= 0


def test_roster_has_eight_distinct_archetypes():
    assert len(ROSTER) == 8
    names = {cls.profile.display_name for cls in ROSTER}
    assert len(names) == 8


def test_dockhand_is_tankiest_and_runner_is_frailest():
    from entities.characters.dockhand import Dockhand
    from entities.characters.runner import Runner
    assert Dockhand.profile.max_hp > Runner.profile.max_hp
    assert Runner.profile.move_speed > Dockhand.profile.move_speed
