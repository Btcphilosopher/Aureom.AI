"""1-8 player difficulty scaling rules: fewer players -> fewer, sharper
enemies; more players -> larger, looser mobs (chaos scaling)."""
import random

from multiplayer.difficulty_scaler import get_difficulty_profile, room_enemy_count


def test_enemy_count_grows_with_player_count():
    small = get_difficulty_profile(1)
    large = get_difficulty_profile(8)
    assert large.base_enemy_count > small.base_enemy_count


def test_ai_precision_is_higher_with_fewer_players():
    small = get_difficulty_profile(1)
    large = get_difficulty_profile(8)
    assert small.ai_reaction_precision > large.ai_reaction_precision
    assert small.ai_cooldown_mult < large.ai_cooldown_mult  # smaller team -> faster enemy attacks


def test_room_enemy_count_scales_across_full_player_range():
    rng = random.Random(0)
    counts = [room_enemy_count("brawl_arena", n, rng) for n in range(1, 9)]
    assert all(c >= 1 for c in counts)
    assert counts[-1] >= counts[0]


def test_choke_and_hazard_rooms_spawn_fewer_than_brawl_arenas():
    rng = random.Random(0)
    brawl = room_enemy_count("brawl_arena", 8, rng)
    choke = room_enemy_count("choke_corridor", 8, rng)
    hazard = room_enemy_count("hazard_room", 8, rng)
    assert choke <= brawl
    assert hazard <= brawl
