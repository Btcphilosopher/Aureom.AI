"""Cross-character aura effects: Guardian's shield dome, Tactician's command
field and slow-time zone. These read simple timer/flag fields that any
PlayableCharacter carries (see entities/character_base.py) so no character
needs a direct reference to any other — the World just calls this once a
frame after everyone's own update() has run.
"""
from __future__ import annotations

import math

SHIELD_DOME_RADIUS = 140.0
SHIELD_DOME_REDUCTION = 0.35


def _dist(a, b) -> float:
    return math.hypot(a.body.x - b.body.x, a.body.y - b.body.y)


def apply_player_auras(players: list) -> None:
    """Recomputes each player's `damage_reduction_mult`/`damage_mult` bonus
    contribution from teammates' active auras. Personal passive contributions
    (e.g. Guardian's own Wall State) are applied earlier in on_passive_tick
    and are multiplied together with the aura bonus here.
    """
    alive_players = [p for p in players if p.alive and not p.downed]
    for target in alive_players:
        aura_damage_reduction = 1.0
        aura_damage_bonus = 1.0
        for source in alive_players:
            if source is target:
                continue
            if source.shield_dome_timer > 0 and _dist(source, target) <= SHIELD_DOME_RADIUS:
                aura_damage_reduction *= (1.0 - SHIELD_DOME_REDUCTION)
            if source.command_buff_radius > 0 and _dist(source, target) <= source.command_buff_radius:
                aura_damage_bonus *= (1.0 + source.command_buff_strength)
        target.aura_damage_reduction_mult = aura_damage_reduction
        target.aura_damage_bonus_mult = aura_damage_bonus


def apply_enemy_slow_fields(players: list, enemies: list) -> None:
    """Tactician's slow-time zone saps nearby enemies' effective move speed."""
    active_sources = [p for p in players if p.alive and getattr(p, "slow_field_timer", 0) > 0]
    if not active_sources:
        for enemy in enemies:
            enemy.ai_speed_mult = 1.0
        return
    for enemy in enemies:
        slowed = any(_dist(source, enemy) <= 220.0 for source in active_sources)
        enemy.ai_speed_mult = 0.45 if slowed else 1.0
