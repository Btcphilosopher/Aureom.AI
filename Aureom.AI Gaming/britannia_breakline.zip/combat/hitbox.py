"""A single active hitbox spawned by an attack's active frame window."""
from __future__ import annotations

from dataclasses import dataclass, field

from combat.damage_types import DamageType
from physics.aabb import AABB


@dataclass
class Hitbox:
    owner_id: int
    aabb: AABB
    damage: float
    damage_type: DamageType
    knockback: tuple[float, float, float]  # (x, y, z) impulse
    hitstun_frames: int
    life_frames: int  # how many more sim frames this hitbox stays active
    armor_piercing: bool = False
    already_hit: set = field(default_factory=set)  # entity ids already struck

    def tick(self) -> bool:
        """Advance one frame; returns True once the hitbox has expired."""
        self.life_frames -= 1
        return self.life_frames <= 0

    def can_hit(self, entity_id: int) -> bool:
        return entity_id not in self.already_hit

    def mark_hit(self, entity_id: int) -> None:
        self.already_hit.add(entity_id)
