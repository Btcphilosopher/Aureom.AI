"""Resolves live hitboxes against hurtboxes and applies all combat effects:
damage, combo scaling, knockback, hitstun, hitstop and screen shake.

This is the single place damage is ever applied so balance stays coherent
(everything, including boss/enemy attacks, funnels through here).
"""
from __future__ import annotations

from combat.damage_types import HITSTOP_BY_TYPE
from combat.hitbox import Hitbox
from core.constants import HITSTUN_TO_KNOCKDOWN_HITS
from core.event_bus import EventBus


class CombatResolver:
    def __init__(self, event_bus: EventBus, hitstop_manager) -> None:
        self.event_bus = event_bus
        self.hitstop = hitstop_manager

    def resolve(self, hitboxes: list[Hitbox], entities: list) -> None:
        entity_by_id = {e.id: e for e in entities}
        for hitbox in hitboxes:
            attacker = entity_by_id.get(hitbox.owner_id)
            for target in entities:
                if not target.alive or target.id == hitbox.owner_id:
                    continue
                if attacker is not None and target.faction == attacker.faction:
                    continue
                if not hitbox.can_hit(target.id):
                    continue
                if not hitbox.aabb.intersects(target.hurtbox):
                    continue
                self._apply_hit(hitbox, attacker, target)
                hitbox.mark_hit(target.id)

    def _apply_hit(self, hitbox: Hitbox, attacker, target) -> None:
        damage = hitbox.damage
        if hitbox.armor_piercing and getattr(target, "armored", False):
            damage *= 1.0  # armor-piercing ignores the armor reduction below
        elif getattr(target, "armored", False):
            damage *= 0.5

        combo_multiplier = 1.0
        if attacker is not None and hasattr(attacker, "combo"):
            combo_multiplier = attacker.combo.register_hit()
        damage *= combo_multiplier

        target.take_damage(damage, hitbox.damage_type)
        if attacker is not None and hasattr(attacker, "on_hit_landed"):
            attacker.on_hit_landed(target)
        kx, ky, kz = hitbox.knockback
        facing = 1 if (target.body.x - hitbox.aabb.x) >= 0 else -1
        target.body.apply_knockback(kx * facing, ky, kz, hitbox.hitstun_frames)
        target.hitstun_hits_taken = getattr(target, "hitstun_hits_taken", 0) + 1
        if target.hitstun_hits_taken >= HITSTUN_TO_KNOCKDOWN_HITS:
            target.knock_down()
            target.hitstun_hits_taken = 0

        self.hitstop.freeze(hitbox.owner_id, HITSTOP_BY_TYPE[hitbox.damage_type])
        self.hitstop.freeze(target.id, HITSTOP_BY_TYPE[hitbox.damage_type])
        self.hitstop.add_screen_shake(2.0 if hitbox.damage_type.value in ("heavy", "special") else 0.8)

        self.event_bus.publish(
            "hit_landed",
            attacker=attacker,
            target=target,
            damage=damage,
            damage_type=hitbox.damage_type,
        )
        if target.hp <= 0 and target.alive:
            target.alive = False
            self.event_bus.publish("entity_ko", entity=target, killer=attacker)
