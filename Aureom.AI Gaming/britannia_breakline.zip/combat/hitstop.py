"""Hitstop ("freeze frames") and screen shake bookkeeping.

Hitstop is what makes a hit register as *impactful*: both combatants freeze
for a handful of frames on connect. We model it as a per-entity counter that
the entity update loop checks before running its normal think/physics step,
plus a global screen-shake magnitude the renderer decays each frame.
"""
from __future__ import annotations


class HitstopManager:
    def __init__(self) -> None:
        self._frozen: dict[int, int] = {}
        self.screen_shake = 0.0

    def freeze(self, entity_id: int, frames: int) -> None:
        self._frozen[entity_id] = max(self._frozen.get(entity_id, 0), frames)

    def add_screen_shake(self, magnitude: float) -> None:
        self.screen_shake = max(self.screen_shake, magnitude)

    def is_frozen(self, entity_id: int) -> bool:
        return self._frozen.get(entity_id, 0) > 0

    def tick(self) -> None:
        for entity_id in list(self._frozen.keys()):
            self._frozen[entity_id] -= 1
            if self._frozen[entity_id] <= 0:
                del self._frozen[entity_id]
        self.screen_shake = max(0.0, self.screen_shake - 0.6)
