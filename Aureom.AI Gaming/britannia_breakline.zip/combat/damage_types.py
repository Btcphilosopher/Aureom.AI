"""Damage type taxonomy shared by every character/enemy attack."""
from __future__ import annotations

from enum import Enum

from core.constants import HITSTOP_GRAB, HITSTOP_HEAVY, HITSTOP_LIGHT, HITSTOP_SPECIAL


class DamageType(Enum):
    LIGHT = "light"
    HEAVY = "heavy"
    GRAB = "grab"
    SPECIAL = "special"


HITSTOP_BY_TYPE = {
    DamageType.LIGHT: HITSTOP_LIGHT,
    DamageType.HEAVY: HITSTOP_HEAVY,
    DamageType.GRAB: HITSTOP_GRAB,
    DamageType.SPECIAL: HITSTOP_SPECIAL,
}
