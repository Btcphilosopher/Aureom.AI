"""Hitbox-driven combat core: frame windows, damage resolution, combos, hitstop."""
