"""Per-entity combo chain tracking with diminishing-returns damage scaling."""
from __future__ import annotations

from dataclasses import dataclass

from core.constants import COMBO_DECAY_PER_HIT, COMBO_MIN_MULTIPLIER, COMBO_WINDOW_FRAMES


@dataclass
class ComboTracker:
    hits: int = 0
    frames_since_last_hit: int = COMBO_WINDOW_FRAMES

    def tick(self) -> None:
        self.frames_since_last_hit += 1
        if self.frames_since_last_hit > COMBO_WINDOW_FRAMES and self.hits > 0:
            self.reset()

    def register_hit(self) -> float:
        """Register a landed hit and return the damage multiplier to apply."""
        multiplier = max(COMBO_MIN_MULTIPLIER, 1.0 - COMBO_DECAY_PER_HIT * self.hits)
        self.hits += 1
        self.frames_since_last_hit = 0
        return multiplier

    def reset(self) -> None:
        self.hits = 0
        self.frames_since_last_hit = COMBO_WINDOW_FRAMES
