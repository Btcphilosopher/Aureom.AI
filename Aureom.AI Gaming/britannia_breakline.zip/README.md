# Britannia Breakline

An adaptive, procedural, Anglo-futuristic 2D beat-'em-up engine for up to 8
players, built system-first (no scripted encounters, no hard-coded outcomes)
in pure Python 3.11 + Pygame.

> "Victorian industrial Britain rebuilt as a machine-city combat ecosystem."

## Quick start

```bash
pip install -r requirements.txt

python main.py                          # 2-player local match
python main.py --players 8              # 8-player match (bots fill empty slots)
python main.py --seed 12345             # deterministic run from a fixed seed
python main.py --character "The Rioter" # force player 1's archetype
python main.py --headless-frames 3000   # run the sim with no window (CI/verification)
python main.py --screenshot out.png     # play interactively, save a screenshot on exit

python -m pytest                        # run the test suite
```

**Controls** (keyboard zone 1 / player 1): `WASD` move, `J` light attack,
`K` heavy attack, `L` grab, `I` special. Up to three more players can share
the same keyboard (zones 2-4, see `input/keybindings.py`); connected
gamepads take priority over keyboard zones; any player slot beyond
available devices is bot-controlled, so an 8-player match is always
playable/demoable on one machine. `F1` toggles the adaptive-AI debug
overlay. `Escape` quits.

## What this is

A *system*, not a scripted level: every run is generated from a seed, every
enemy decision comes from a deterministic behaviour tree, and the AI
director re-weights future spawns based on how your specific team actually
plays. Two runs with the same seed and the same input sequence produce
byte-identical outcomes (see `tests/test_determinism.py`) — there is no
hidden randomness, no ML, nothing that can't be inspected.

## Project layout

```
britannia_breakline/
├── core/         fixed-timestep loop, deterministic RNG, event bus, World (sim root)
├── entities/     base actor, 8 playable archetypes, 4 enemy archetypes, projectiles, traps
├── combat/       hitboxes, frame-window resolution, combos, hitstop, cross-character auras
├── animation/    startup/active/recovery frame data + the animator state machine
├── input/        per-player InputState, keyboard/gamepad polling, input buffering
├── ai/           behaviour trees, match telemetry, the adaptive AI director
├── procedural/   branching room-graph generation, zone themes, spawn resolution
├── multiplayer/  player slots, difficulty scaling, shared camera, revives, bot policy
├── physics/      AABB collision, kinematic body integration, crowd separation
├── rendering/    vector/silhouette renderer, HUD, backgrounds, VFX
├── levels/       the boss encounter, per-room-type flavor text
├── tests/        pytest suite covering every system below
└── main.py       entry point (interactive + headless modes)
```

## Core systems

- **Fixed-timestep 60 FPS simulation.** `core/game_loop.py` + `core/world.py`.
  The sim always advances by exactly `1/60s` of game time per step,
  independent of render time.
- **Frame-window combat.** Every attack (`animation/frame_data.py`) is
  startup → active → recovery frame counts plus damage/knockback/hitstun.
  Hits resolve through one funnel (`combat/combat_resolver.py`) with
  hitstop freeze-frames and screen shake (`combat/hitstop.py`), combo-scaled
  damage with diminishing returns (`combat/combo_system.py`), and four
  damage types — light, heavy, grab, special.
- **Behaviour-tree AI.** `ai/behavior_tree.py` is a small real BT engine
  (Selector/Sequence/Condition/Action); `ai/enemy_ai.py` composes it into
  melee/ranged-kiting/ambush-flanking archetypes.
- **Adaptive AI director.** `ai/adaptive_director.py` reads rolling match
  telemetry (`ai/telemetry.py`) and deterministically re-weights the next
  wave's spawns: a fast team draws more traps/slow zones, a tank-heavy team
  draws more armoured enemies, a split (uncoordinated) team draws more
  ambush squads. Rule-weighted, no ML, fully inspectable (`F1` overlay).
- **Procedural levels.** `procedural/level_graph.py` builds a branching,
  multi-path room graph per zone (financial rooftops, rail tunnels, dockside
  yards, data corridors); `procedural/level_generator.py` chains 3 of the 5
  zones into one run ending in a boss chamber. Same seed → identical graph
  (`tests/test_procedural.py`).
- **1-8 player co-op.** `multiplayer/` handles player slots
  (keyboard/gamepad/bot), player-count-driven difficulty scaling (fewer
  players → fewer, sharper enemies; more players → larger, looser mobs), a
  shared soft-zoom camera, and assist-revive mechanics.
- **Deterministic simulation core.** `core/rng.py` derives named,
  independent random substreams from one master seed so every subsystem's
  randomness is reproducible and isolated from every other subsystem's.

## The eight archetypes

| Archetype | Role | Passive | Weakness |
|---|---|---|---|
| The Dockhand | Tank / Grappler | Steel Grip (longer grab hitstun) | Slow, poor ranged options |
| The Runner | Speed / Hit-and-run DPS | Momentum Boost (speed on hit) | Low HP, easily interrupted |
| The Marksman | Ranged control | Focus Aim (damage while stationary) | Weak melee, slow recovery |
| The Engineer | Utility / traps | Field Deployment (cheaper specials) | Low direct combat power |
| The Guardian | Defensive anchor | Wall State (reduced dmg while still) | Low mobility, boss magnet |
| The Rioter | Berserker / chaos DPS | Escalation (dmg scales below 30% HP) | Fragile, hard to coordinate |
| The Tactician | Support / debuff | Command Field (buffs nearby allies) | Very low direct damage |
| The Augment | Adaptive hybrid | Adaptive Systems (Speed/Power/Defence modes) | Needs meter to switch modes |

## Enemy roster

Streetlevel Grunt (baseline melee), Ironclad Brute (armoured heavy —
countered by armor-piercing attacks), Skyline Marksdrone (ranged kiter),
Ambush Cutter (flanking striker), and the end-of-run boss, the Regency
Combine Warmachine (phase-aware slam attacks, enrages under 35% HP).

## Testing

`tests/` covers combat resolution and combo scaling, all 8 character
profiles, procedural-generation determinism and full reachability, the
adaptive director's rule triggers, 1-8 player difficulty scaling, and
full-World determinism (identical seed → byte-identical outcome). Run with
`python -m pytest`.
