"""Generates the branching room graph for one zone.

Layout: a sequence of "layers" (like the classic brawler's room-to-room
progression), where most layers are a single room but some fork into 2-3
parallel branches that reconnect at the next layer — giving the "multi-path
city zones" called for in the design brief while keeping traversal simple
(every room in layer N connects forward to every room in layer N+1).
"""
from __future__ import annotations

import random

from procedural.room import Room, RoomType
from procedural.zone_definitions import ZoneDefinition

BRANCH_CHANCE = 0.35
MAX_BRANCHES = 3


def _pick_room_type(zone: ZoneDefinition, rng: random.Random, is_last_layer: bool) -> RoomType:
    if is_last_layer:
        return RoomType.BOSS
    types = list(zone.room_type_weights.keys())
    weights = list(zone.room_type_weights.values())
    return rng.choices(types, weights=weights, k=1)[0]


def generate_zone_graph(zone: ZoneDefinition, rng: random.Random, num_layers: int,
                         id_start: int) -> tuple[list[Room], int]:
    """Returns (rooms, next_free_id)."""
    rooms: list[Room] = []
    next_id = id_start
    previous_layer_ids: list[int] = []

    for layer in range(num_layers):
        is_last = layer == num_layers - 1
        branch_count = 1
        if not is_last and layer != 0 and rng.random() < BRANCH_CHANCE:
            branch_count = rng.randint(2, MAX_BRANCHES)

        layer_ids = []
        for _ in range(branch_count):
            room_type = _pick_room_type(zone, rng, is_last)
            width = 900.0 if room_type == RoomType.BRAWL else 620.0
            if room_type == RoomType.BOSS:
                width = 1200.0
            room = Room(room_id=next_id, zone_name=zone.name, room_type=room_type,
                        layer=layer, arena_width=width)
            rooms.append(room)
            layer_ids.append(next_id)
            next_id += 1

        if previous_layer_ids:
            for prev_id in previous_layer_ids:
                prev_room = next(r for r in rooms if r.room_id == prev_id)
                prev_room.connections.extend(layer_ids)

        previous_layer_ids = layer_ids

    return rooms, next_id
