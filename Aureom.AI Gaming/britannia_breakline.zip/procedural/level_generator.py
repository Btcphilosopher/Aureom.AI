"""Builds a full run: a seeded sequence of zones, each a branching room
graph, culminating in a boss chamber. Fully deterministic given the same
DeterministicRNG seed (see core/rng.py + tests/test_procedural.py).
"""
from __future__ import annotations

from dataclasses import dataclass

from core.rng import DeterministicRNG
from procedural.level_graph import generate_zone_graph
from procedural.room import Room
from procedural.zone_definitions import ZONES

LAYERS_PER_ZONE = 4


@dataclass
class LevelRun:
    rooms: dict[int, Room]
    zone_order: list[str]
    entry_room_id: int

    def room(self, room_id: int) -> Room:
        return self.rooms[room_id]


def generate_run(rng_factory: DeterministicRNG, num_zones: int = 3) -> LevelRun:
    """Routes through `num_zones` of the five Anglo-futuristic districts,
    picked (and ordered) deterministically from the seed, each contributing
    a branching room graph.
    """
    zone_rng = rng_factory.stream("zone_order")
    chosen_zones = zone_rng.sample(ZONES, k=min(num_zones, len(ZONES)))

    all_rooms: dict[int, Room] = {}
    next_id = 0
    first_room_id = None
    tail_ids: list[int] = []

    for zone in chosen_zones:
        graph_rng = rng_factory.stream(f"zone_graph:{zone.name}")
        rooms, next_id = generate_zone_graph(zone, graph_rng, LAYERS_PER_ZONE, next_id)
        for room in rooms:
            all_rooms[room.room_id] = room
        first_of_zone = min(r.room_id for r in rooms if r.layer == 0)
        if first_room_id is None:
            first_room_id = first_of_zone
        elif tail_ids:
            for tid in tail_ids:
                all_rooms[tid].connections.append(first_of_zone)
        last_layer = max(r.layer for r in rooms)
        tail_ids = [r.room_id for r in rooms if r.layer == last_layer]

    return LevelRun(rooms=all_rooms, zone_order=[z.name for z in chosen_zones], entry_room_id=first_room_id)
