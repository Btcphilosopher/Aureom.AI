"""The five Anglo-futuristic zones a run can route through, with their
themed room pools and rendering palette accents.

"Victorian industrial Britain rebuilt as a machine-city combat ecosystem."
"""
from __future__ import annotations

from dataclasses import dataclass

from core.constants import PALETTE
from procedural.room import RoomType


@dataclass(frozen=True)
class ZoneDefinition:
    name: str
    flavor: str
    accent_color: tuple[int, int, int]
    room_type_weights: dict[RoomType, float]


ZONES: list[ZoneDefinition] = [
    ZoneDefinition(
        name="Dockside Megaflow District",
        flavor="Cargo cranes and flooded loading bays under a sodium haze.",
        accent_color=PALETTE["rust"],
        room_type_weights={RoomType.BRAWL: 0.5, RoomType.CHOKE: 0.3, RoomType.HAZARD: 0.2},
    ),
    ZoneDefinition(
        name="Crown Industrial Spine",
        flavor="A brutalist foundry corridor still stamped with royal ironwork.",
        accent_color=PALETTE["brass"],
        room_type_weights={RoomType.BRAWL: 0.45, RoomType.CHOKE: 0.35, RoomType.HAZARD: 0.2},
    ),
    ZoneDefinition(
        name="Rail Cathedral Network",
        flavor="Vaulted tunnels where freight rail replaced stained glass.",
        accent_color=PALETTE["steel_blue"],
        room_type_weights={RoomType.CHOKE: 0.5, RoomType.BRAWL: 0.3, RoomType.HAZARD: 0.2},
    ),
    ZoneDefinition(
        name="Data Estate Undergrid",
        flavor="Server-farm catacombs lit by cold slum-neon strip lighting.",
        accent_color=PALETTE["slum_neon"],
        room_type_weights={RoomType.HAZARD: 0.45, RoomType.BRAWL: 0.35, RoomType.CHOKE: 0.2},
    ),
    ZoneDefinition(
        name="Financial Stack Towers",
        flavor="Rooftop plazas of the vertical bank-spires, wind-lashed and exposed.",
        accent_color=PALETTE["imperial_red"],
        room_type_weights={RoomType.BRAWL: 0.55, RoomType.HAZARD: 0.25, RoomType.CHOKE: 0.2},
    ),
]
