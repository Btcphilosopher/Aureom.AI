"""Procedural, branching Anglo-futuristic level generation."""
