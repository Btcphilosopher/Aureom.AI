"""Resolves what actually spawns in a room at the moment it's entered.

Split from level_graph.py deliberately: the *shape* of a run (which rooms,
how they connect) is fixed at generation time from the seed, but *what
spawns* in a room also depends on the AdaptiveAIDirector's current weights,
which evolve live during play. Baking spawns in at generation time would
defeat the adaptive system.
"""
from __future__ import annotations

import random

from ai.adaptive_director import DirectorModifiers
from multiplayer.difficulty_scaler import room_enemy_count
from procedural.room import Room, RoomType

BASE_WEIGHTS = {"grunt": 1.0, "brute": 0.35, "drone": 0.35, "cutter": 0.3}


def resolve_room_spawns(room: Room, num_players: int, modifiers: DirectorModifiers,
                         rng: random.Random) -> list[str]:
    if room.room_type == RoomType.BOSS:
        return []  # bosses are staged explicitly by the level generator, not the spawn table

    count = room_enemy_count(room.room_type.value, num_players, rng)
    if room.room_type == RoomType.CHOKE:
        count = max(1, int(count * 0.75))

    count += modifiers.enemy_count_bonus

    weights = dict(BASE_WEIGHTS)
    weights["brute"] *= modifiers.armored_spawn_weight
    weights["cutter"] *= (1.0 + modifiers.ambush_squad_chance)
    weights["drone"] *= modifiers.ranged_spawn_weight

    types = list(weights.keys())
    picked = rng.choices(types, weights=list(weights.values()), k=count)
    room.hazard_slow_zones = 0
    if room.room_type == RoomType.HAZARD:
        room.hazard_slow_zones = max(1, round(1 * modifiers.hazard_density))
    room.enemy_spawn_plan = picked
    return picked
