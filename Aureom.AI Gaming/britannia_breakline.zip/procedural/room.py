"""Room data: the atomic unit of a procedurally generated run."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class RoomType(Enum):
    BRAWL = "brawl_arena"
    CHOKE = "choke_corridor"
    HAZARD = "hazard_room"
    BOSS = "boss_chamber"


@dataclass
class Room:
    room_id: int
    zone_name: str
    room_type: RoomType
    layer: int
    arena_width: float
    connections: list[int] = field(default_factory=list)
    cleared: bool = False
    enemy_spawn_plan: list[str] = field(default_factory=list)
    hazard_slow_zones: int = 0
