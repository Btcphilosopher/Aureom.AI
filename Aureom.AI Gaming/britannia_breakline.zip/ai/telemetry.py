"""Rolling-window telemetry the adaptive director reads to decide how the
next wave of enemies should be composed. Everything here is plain counting
and averaging — no learning, no external data, fully deterministic given
the same sequence of gameplay events.
"""
from __future__ import annotations

from collections import deque

from core.constants import ADAPTIVE_WINDOW_FRAMES
from core.event_bus import EventBus


class MatchTelemetry:
    def __init__(self, event_bus: EventBus):
        self.melee_hits = 0
        self.ranged_hits = 0
        self.grab_hits = 0
        self.player_spread_samples: deque[float] = deque(maxlen=ADAPTIVE_WINDOW_FRAMES)
        self._frame = 0
        event_bus.subscribe("hit_landed", self._on_hit_landed)

    def _on_hit_landed(self, attacker, target, damage, damage_type) -> None:
        if attacker is None or attacker.faction != "player":
            return
        name = damage_type.value
        if name == "grab":
            self.grab_hits += 1
        elif getattr(attacker, "profile", None) is not None and attacker.profile.role.startswith("Ranged"):
            self.ranged_hits += 1
        else:
            self.melee_hits += 1

    def sample_players(self, players: list) -> None:
        alive = [p for p in players if p.alive and not p.downed]
        if len(alive) < 2:
            self.player_spread_samples.append(0.0)
            return
        cx = sum(p.body.x for p in alive) / len(alive)
        cy = sum(p.body.y for p in alive) / len(alive)
        avg_dist = sum(((p.body.x - cx) ** 2 + (p.body.y - cy) ** 2) ** 0.5 for p in alive) / len(alive)
        self.player_spread_samples.append(avg_dist)
        self._frame += 1

    def dominant_strategy(self) -> str:
        total = self.melee_hits + self.ranged_hits + self.grab_hits
        if total == 0:
            return "balanced"
        if self.ranged_hits / total > 0.5:
            return "ranged"
        if self.grab_hits / total > 0.35:
            return "grapple"
        return "rush"

    def average_spread(self) -> float:
        if not self.player_spread_samples:
            return 0.0
        return sum(self.player_spread_samples) / len(self.player_spread_samples)

    def coordination_score(self) -> float:
        """0 (scattered/split team) .. 1 (tightly grouped)."""
        spread = self.average_spread()
        return max(0.0, 1.0 - min(spread / 260.0, 1.0))

    def team_role_composition(self, players: list) -> dict[str, int]:
        counts: dict[str, int] = {}
        for p in players:
            role = getattr(p, "profile", None)
            key = role.role if role else "unknown"
            counts[key] = counts.get(key, 0) + 1
        return counts
