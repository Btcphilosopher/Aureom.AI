"""The core adaptive-AI feature: a deterministic, rule-weighted director
that reads MatchTelemetry and adjusts how the *next* wave of enemies is
composed and equipped. No machine learning, no hidden state beyond simple
counters — every rule below is inspectable and reproducible.

Rules implemented (directly from the design brief):
  * Fast team (Runner/Speed-heavy, high average speed)  -> more traps/slow zones.
  * Tank-heavy team (Dockhand/Guardian-heavy)            -> armour-piercing-resistant
                                                             (i.e. more armoured) enemies.
  * Split team (low coordination score)                  -> more ambush squads.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ai.telemetry import MatchTelemetry
from core.constants import ADAPTIVE_WINDOW_FRAMES

TANK_ROLE_MARKERS = ("Tank", "Defensive")
SPEED_ROLE_MARKERS = ("Speed",)


@dataclass
class DirectorModifiers:
    hazard_density: float = 1.0        # trap/slow-zone spawn multiplier
    armored_spawn_weight: float = 1.0  # extra weight for armoured enemy types
    ambush_squad_chance: float = 0.15  # chance a room spawns a flanking squad
    ranged_spawn_weight: float = 1.0   # counters ranged-heavy teams by pressuring them
    enemy_hp_mult: float = 1.0
    enemy_count_bonus: int = 0
    notes: list[str] = field(default_factory=list)


class AdaptiveAIDirector:
    def __init__(self, telemetry: MatchTelemetry):
        self.telemetry = telemetry
        self.modifiers = DirectorModifiers()
        self._frames_since_eval = 0

    def tick(self, players: list) -> None:
        self.telemetry.sample_players(players)
        self._frames_since_eval += 1
        if self._frames_since_eval >= ADAPTIVE_WINDOW_FRAMES:
            self._frames_since_eval = 0
            self._reevaluate(players)

    def _reevaluate(self, players: list) -> None:
        mods = DirectorModifiers()
        composition = self.telemetry.team_role_composition(players)
        team_size = max(1, sum(composition.values()))

        tank_ratio = sum(v for k, v in composition.items() if any(m in k for m in TANK_ROLE_MARKERS)) / team_size
        speed_ratio = sum(v for k, v in composition.items() if any(m in k for m in SPEED_ROLE_MARKERS)) / team_size
        coordination = self.telemetry.coordination_score()
        strategy = self.telemetry.dominant_strategy()

        if speed_ratio >= 0.25 or strategy == "rush":
            mods.hazard_density = 1.0 + speed_ratio * 1.5
            mods.notes.append(f"fast team detected (speed_ratio={speed_ratio:.2f}) -> +traps/slow zones")

        if tank_ratio >= 0.25:
            mods.armored_spawn_weight = 1.0 + tank_ratio * 2.0
            mods.enemy_hp_mult = 1.0 + tank_ratio * 0.4
            mods.notes.append(f"tank-heavy team detected (tank_ratio={tank_ratio:.2f}) -> +armoured enemies")

        if coordination < 0.5:
            mods.ambush_squad_chance = 0.15 + (0.5 - coordination) * 0.9
            mods.notes.append(f"split team detected (coordination={coordination:.2f}) -> +ambush squads")

        if strategy == "ranged":
            mods.ranged_spawn_weight = 1.4
            mods.enemy_count_bonus = 1
            mods.notes.append("ranged-dominant team -> pressure with more closers")

        self.modifiers = mods

    def get_modifiers(self) -> DirectorModifiers:
        return self.modifiers
