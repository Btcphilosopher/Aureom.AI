"""Builds a behaviour tree per enemy archetype and drives its per-frame tick.

Shared moves (seek nearest player, melee strike, keep-away ranged kiting,
flanking approach for ambush types) are composed from a handful of Action/
Condition nodes so each enemy type differs only in the small set of
parameters on its EnemyProfile plus which branch of the tree it uses.
"""
from __future__ import annotations

import math

from ai.behavior_tree import Action, Condition, Node, Selector, Sequence, Status
from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from physics.aabb import AABB


def _nearest_player(enemy, players) -> object | None:
    alive = [p for p in players if p.alive and not getattr(p, "downed", False)]
    if not alive:
        return None
    return min(alive, key=lambda p: (p.body.x - enemy.body.x) ** 2 + (p.body.y - enemy.body.y) ** 2)


def _distance(a, b) -> float:
    return math.hypot(a.body.x - b.body.x, a.body.y - b.body.y)


def _move_toward(enemy, target_x, target_y) -> None:
    dx = target_x - enemy.body.x
    dy = target_y - enemy.body.y
    dist = math.hypot(dx, dy)
    if dist < 1e-3:
        return
    speed = enemy.profile.move_speed * enemy.ai_speed_mult
    enemy.body.vx = (dx / dist) * speed
    enemy.body.vy = (dy / dist) * speed * 0.6
    enemy.body.facing = 1 if dx >= 0 else -1


def _melee_strike(enemy, target) -> Status:
    if not enemy.attack_cooldown.ready:
        return Status.RUNNING
    enemy.attack_cooldown.start()
    w, h = 40.0, 50.0
    ox = 28.0 * enemy.body.facing
    enemy._pending_hitboxes.append(Hitbox(
        owner_id=enemy.id,
        aabb=AABB(enemy.body.x + ox - w / 2, enemy.body.y - h / 2, w, h),
        damage=enemy.profile.attack_damage,
        damage_type=DamageType.HEAVY,
        knockback=(140.0, 0.0, 30.0),
        hitstun_frames=16,
        life_frames=1,
    ))
    return Status.SUCCESS


def _ranged_strike(enemy, target, world) -> Status:
    if not enemy.attack_cooldown.ready:
        return Status.RUNNING
    enemy.attack_cooldown.start()
    dx = target.body.x - enemy.body.x
    dy = target.body.y - enemy.body.y
    dist = math.hypot(dx, dy) or 1.0
    speed = 260.0
    world.spawn_enemy_projectile(
        enemy, vx=(dx / dist) * speed, vy=(dy / dist) * speed, damage=enemy.profile.attack_damage,
    )
    return Status.SUCCESS


class EnemyAI:
    def __init__(self, tree: Node):
        self.tree = tree

    def tick(self, enemy, world) -> None:
        ctx = {"enemy": enemy, "world": world, "players": world.players}
        self.tree.tick(ctx)


def _acquire_target(ctx) -> Status:
    ctx["target"] = _nearest_player(ctx["enemy"], ctx["players"])
    return Status.SUCCESS if ctx["target"] is not None else Status.FAILURE


def _in_attack_range(ctx) -> bool:
    return _distance(ctx["enemy"], ctx["target"]) <= ctx["enemy"].profile.attack_range


def _in_vision_range(ctx) -> bool:
    return _distance(ctx["enemy"], ctx["target"]) <= ctx["enemy"].profile.vision_range


def _do_melee_strike(ctx) -> Status:
    enemy = ctx["enemy"]
    enemy.body.vx *= 0.2
    enemy.body.vy *= 0.2
    return _melee_strike(enemy, ctx["target"])


def _do_approach(ctx) -> Status:
    enemy, target = ctx["enemy"], ctx["target"]
    _move_toward(enemy, target.body.x, target.body.y)
    return Status.RUNNING


# The grunt/brute behaviour tree, built from real Selector/Sequence/Condition
# nodes: acquire a target, then prefer striking over approaching.
_MELEE_TREE = Sequence([
    Action(_acquire_target),
    Selector([
        Sequence([Condition(_in_attack_range), Action(_do_melee_strike)]),
        Sequence([Condition(_in_vision_range), Action(_do_approach)]),
    ]),
])


def _kite_and_shoot(ctx) -> Status:
    enemy, players, world = ctx["enemy"], ctx["players"], ctx["world"]
    target = _nearest_player(enemy, players)
    if target is None:
        return Status.FAILURE
    dist = _distance(enemy, target)
    ideal_range = enemy.profile.attack_range
    if dist < ideal_range * 0.6:
        # too close: back away
        _move_toward(enemy, 2 * enemy.body.x - target.body.x, 2 * enemy.body.y - target.body.y)
    elif dist > ideal_range:
        _move_toward(enemy, target.body.x, target.body.y)
    else:
        enemy.body.vx *= 0.3
        enemy.body.vy *= 0.3
        return _ranged_strike(enemy, target, world)
    return Status.RUNNING


def _flank_and_ambush(ctx) -> Status:
    """Ambush enemies circle to a target's blind side before committing."""
    enemy, players = ctx["enemy"], ctx["players"]
    target = _nearest_player(enemy, players)
    if target is None:
        return Status.FAILURE
    dist = _distance(enemy, target)
    if dist <= enemy.profile.attack_range:
        enemy.body.vx *= 0.2
        enemy.body.vy *= 0.2
        return _melee_strike(enemy, target)
    if enemy.blackboard.get("flank_committed"):
        _move_toward(enemy, target.body.x, target.body.y)
        return Status.RUNNING
    flank_x = target.body.x - 120.0 * target.body.facing
    if dist <= enemy.profile.vision_range:
        if _distance_to_point(enemy, flank_x, target.body.y) < 30.0 or dist < 90.0:
            enemy.blackboard["flank_committed"] = True
        _move_toward(enemy, flank_x, target.body.y)
        return Status.RUNNING
    return Status.FAILURE


def _distance_to_point(enemy, x, y) -> float:
    return math.hypot(enemy.body.x - x, enemy.body.y - y)


def build_behaviour_tree(enemy) -> EnemyAI:
    profile = enemy.profile
    if profile.ranged:
        root: Node = Action(_kite_and_shoot)
    elif profile.ambush:
        root = Action(_flank_and_ambush)
    else:
        root = _MELEE_TREE
    return EnemyAI(root)
