"""A small, real behaviour-tree engine: Selector / Sequence / Condition /
Action / Inverter / Cooldown. No ML anywhere in this file or its callers —
every decision is a deterministic rule evaluated against a context dict, so
the same context always produces the same tick result.
"""
from __future__ import annotations

from enum import Enum
from typing import Callable


class Status(Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    RUNNING = "running"


class Node:
    def tick(self, ctx: dict) -> Status:
        raise NotImplementedError


class Selector(Node):
    """Runs children in order; succeeds as soon as one succeeds/runs."""

    def __init__(self, children: list[Node]):
        self.children = children

    def tick(self, ctx: dict) -> Status:
        for child in self.children:
            result = child.tick(ctx)
            if result != Status.FAILURE:
                return result
        return Status.FAILURE


class Sequence(Node):
    """Runs children in order; fails as soon as one fails."""

    def __init__(self, children: list[Node]):
        self.children = children

    def tick(self, ctx: dict) -> Status:
        for child in self.children:
            result = child.tick(ctx)
            if result != Status.SUCCESS:
                return result
        return Status.SUCCESS


class Condition(Node):
    def __init__(self, predicate: Callable[[dict], bool]):
        self.predicate = predicate

    def tick(self, ctx: dict) -> Status:
        return Status.SUCCESS if self.predicate(ctx) else Status.FAILURE


class Action(Node):
    def __init__(self, fn: Callable[[dict], Status]):
        self.fn = fn

    def tick(self, ctx: dict) -> Status:
        return self.fn(ctx)


class Inverter(Node):
    def __init__(self, child: Node):
        self.child = child

    def tick(self, ctx: dict) -> Status:
        result = self.child.tick(ctx)
        if result == Status.SUCCESS:
            return Status.FAILURE
        if result == Status.FAILURE:
            return Status.SUCCESS
        return Status.RUNNING
