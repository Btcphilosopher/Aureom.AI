"""Frame-window driven animation/pose state machine (vector-rendered, no sprite sheets)."""
