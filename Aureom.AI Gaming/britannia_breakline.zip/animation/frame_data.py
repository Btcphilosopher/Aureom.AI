"""Startup / active / recovery frame windows — the backbone of combat feel.

An attack is entirely described by three frame counts plus its hitbox and
damage parameters. Startup = wind-up (punishable, no hitbox). Active = the
hitbox actually exists. Recovery = committed lag after the swing.
"""
from __future__ import annotations

from dataclasses import dataclass

from combat.damage_types import DamageType


@dataclass(frozen=True)
class AttackDef:
    name: str
    startup: int
    active: int
    recovery: int
    damage: float
    damage_type: DamageType
    knockback: tuple[float, float, float]
    hitstun_frames: int
    hitbox_size: tuple[float, float]  # (w, h) relative to entity
    hitbox_offset: tuple[float, float]
    armor_piercing: bool = False
    stamina_cost: float = 0.0

    @property
    def total_frames(self) -> int:
        return self.startup + self.active + self.recovery

    def is_active_at(self, elapsed_frames: int) -> bool:
        return self.startup <= elapsed_frames < self.startup + self.active
