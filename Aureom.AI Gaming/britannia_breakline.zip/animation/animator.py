"""Drives an entity's current action/pose from frame data.

There are no sprite sheets in this engine (Pygame-primitive rendering per
the Anglo-futuristic vector-silhouette art direction) — the Animator just
tracks *which phase* of an action we're in and how far through it, and the
renderer maps that to a pose (limb angles, lunge offset, flash colour).
"""
from __future__ import annotations

from dataclasses import dataclass

from animation.frame_data import AttackDef


@dataclass
class ActionState:
    name: str
    elapsed: int = 0
    attack: AttackDef | None = None
    locked: bool = False  # True while an attack/hitstun action can't be canceled


class Animator:
    def __init__(self) -> None:
        self.state = ActionState(name="idle")

    def play(self, name: str, attack: AttackDef | None = None, locked: bool = False) -> None:
        self.state = ActionState(name=name, elapsed=0, attack=attack, locked=locked)

    def tick(self) -> None:
        self.state.elapsed += 1
        if self.state.attack is not None and self.state.elapsed >= self.state.attack.total_frames:
            self.locked_finished()

    def locked_finished(self) -> None:
        self.state.locked = False

    @property
    def phase(self) -> str:
        """Returns 'startup' | 'active' | 'recovery' | '' for non-attacks."""
        atk = self.state.attack
        if atk is None:
            return ""
        e = self.state.elapsed
        if e < atk.startup:
            return "startup"
        if e < atk.startup + atk.active:
            return "active"
        return "recovery"

    @property
    def progress(self) -> float:
        atk = self.state.attack
        if atk is None or atk.total_frames == 0:
            return 0.0
        return min(1.0, self.state.elapsed / atk.total_frames)

    @property
    def is_busy(self) -> bool:
        return self.state.locked
