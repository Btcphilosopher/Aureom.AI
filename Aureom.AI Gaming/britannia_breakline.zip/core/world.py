"""The simulation root: owns every system and advances the whole game one
fixed-timestep frame at a time. This is what main.py drives, whether that's
an interactive pygame window or a headless deterministic run.
"""
from __future__ import annotations

from ai.adaptive_director import AdaptiveAIDirector
from ai.telemetry import MatchTelemetry
from combat.combat_resolver import CombatResolver
from combat.damage_types import DamageType
from combat.hitstop import HitstopManager
from combat.team_auras import apply_enemy_slow_fields, apply_player_auras
from core.event_bus import EventBus
from core.game_state import GameState, StateManager
from core.rng import DeterministicRNG
from entities.enemies import ENEMY_TYPES
from entities.projectile import Projectile
from entities.trap import Mine, SlowZone
from input.input_manager import InputState
from levels.boss_data import RegencyWarmachine
from levels.zone_flavor import flavor_for
from multiplayer.camera_system import CameraSystem
from multiplayer.player_manager import PlayerManager
from multiplayer.difficulty_scaler import scale_enemy_cooldown
from multiplayer.revive_system import team_wiped, update_revives
from physics.collision_world import CollisionWorld
from procedural.level_generator import generate_run
from procedural.room import RoomType
from procedural.spawn_tables import resolve_room_spawns

MAX_KEYBOARD_ZONES = 4


class World:
    def __init__(self, seed: int, character_classes: list[type], headless: bool = False,
                 num_zones: int = 3):
        self.headless = headless
        self.rng_factory = DeterministicRNG(seed)
        self.event_bus = EventBus()
        self.hitstop = HitstopManager()
        self.combat_resolver = CombatResolver(self.event_bus, self.hitstop)
        self.telemetry = MatchTelemetry(self.event_bus)
        self.director = AdaptiveAIDirector(self.telemetry)
        self.spawn_rng = self.rng_factory.stream("spawns")
        self.routing_rng = self.rng_factory.stream("routing")
        self.hazard_rng = self.rng_factory.stream("hazards")

        self.player_manager = PlayerManager(
            character_classes, self.rng_factory.stream("bots"),
            num_keyboard_zones=min(MAX_KEYBOARD_ZONES, len(character_classes)), headless=headless,
        )
        self.players = self.player_manager.instantiate_characters()

        self.level = generate_run(self.rng_factory, num_zones=num_zones)
        self.current_room_id = self.level.entry_room_id
        self.arena_x_min = 0.0
        self.arena_x_max = 0.0
        self.collision_world = CollisionWorld(0.0, 0.0)

        self.enemies: list = []
        self.projectiles: list[Projectile] = []
        self.mines: list[Mine] = []
        self.slow_zones: list[SlowZone] = []

        self.camera = CameraSystem()
        self.state_manager = StateManager()
        self.state_manager.transition(GameState.PLAYING)
        self.frame_count = 0
        self.victory = False
        self.game_over = False
        self.last_room_message = ""

        self._enter_room(self.current_room_id, is_first=True)

    # --- room lifecycle -----------------------------------------------------------
    def _enter_room(self, room_id: int, is_first: bool = False) -> None:
        room = self.level.room(room_id)
        self.current_room_id = room_id
        self.arena_x_min = -room.arena_width / 2
        self.arena_x_max = room.arena_width / 2
        self.collision_world = CollisionWorld(self.arena_x_min, self.arena_x_max)
        self.last_room_message = f"{room.zone_name} — {flavor_for(room.room_type)}"

        self.projectiles.clear()
        self.mines.clear()
        self.slow_zones.clear()

        if room.room_type == RoomType.BOSS:
            boss = RegencyWarmachine()
            boss.body.x = self.arena_x_max - 160
            boss.body.y = 100.0
            self.enemies = [boss]
        else:
            modifiers = self.director.get_modifiers()
            plan = resolve_room_spawns(room, len(self.players), modifiers, self.spawn_rng)
            self.enemies = []
            for i, key in enumerate(plan):
                enemy = ENEMY_TYPES[key]()
                enemy.body.x = self.arena_x_min + 220 + (i % 4) * 90 + self.spawn_rng.uniform(-20, 20)
                enemy.body.y = self.spawn_rng.uniform(40, 180)
                enemy.attack_cooldown.duration = scale_enemy_cooldown(
                    enemy.profile.attack_cooldown_frames, len(self.players))
                enemy.hp = enemy.max_hp = enemy.max_hp * modifiers.enemy_hp_mult
                self.enemies.append(enemy)
            for _ in range(room.hazard_slow_zones):
                zx = self.hazard_rng.uniform(self.arena_x_min + 200, self.arena_x_max - 200)
                zy = self.hazard_rng.uniform(40, 180)
                self.slow_zones.append(SlowZone(zx, zy))

        if is_first:
            for i, player in enumerate(self.players):
                player.body.x = self.arena_x_min + 60 + (i % 4) * 40
                player.body.y = 60 + (i // 4) * 60
        else:
            for player in self.players:
                player.body.x = self.arena_x_min + 60

        self.event_bus.publish("room_entered", room=room)

    def _room_cleared(self) -> bool:
        return all(not e.alive for e in self.enemies)

    def _try_advance_room(self) -> None:
        room = self.level.room(self.current_room_id)
        if not room.connections:
            self.victory = True
            self.state_manager.transition(GameState.VICTORY)
            return
        anyone_at_edge = any(p.alive and p.body.x >= self.arena_x_max - 50 for p in self.players)
        if anyone_at_edge or self.headless:
            next_id = self.routing_rng.choice(room.connections)
            self._enter_room(next_id)

    # --- per-frame step -------------------------------------------------------------
    def step(self, inputs: dict[int, InputState]) -> None:
        self.frame_count += 1
        hitboxes = []

        for idx, player in enumerate(self.players):
            input_state = inputs.get(idx, InputState())
            frozen = self.hitstop.is_frozen(player.id)
            spawned = player.update(input_state, frozen)
            hitboxes.extend(spawned)
            hitboxes.extend(player.collect_hitboxes())
            if hasattr(player, "collect_mines"):
                self.mines.extend(player.collect_mines())

        apply_player_auras(self.players)
        apply_enemy_slow_fields(self.players, self.enemies)

        for enemy in self.enemies:
            if not enemy.alive:
                continue
            if self.hitstop.is_frozen(enemy.id):
                continue
            enemy.update(self)
            hitboxes.extend(enemy.collect_hitboxes())

        for mine in list(self.mines):
            hb = mine.update(self.enemies)
            if hb is not None:
                hitboxes.append(hb)
        self.mines = [m for m in self.mines if m.alive]

        for zone in self.slow_zones:
            zone.update(self.players)
        self.slow_zones = [z for z in self.slow_zones if z.alive]

        for proj in list(self.projectiles):
            hb = proj.update()
            if hb is not None:
                hitboxes.append(hb)
        self.projectiles = [p for p in self.projectiles if p.alive]

        self.combat_resolver.resolve(hitboxes, self.players + self.enemies)
        self.hitstop.tick()

        update_revives(self.players)

        living = [e for e in self.players + self.enemies if e.alive]
        self.collision_world.separate_crowd(living)
        for e in living:
            self.collision_world.clamp_to_arena(e)

        self.director.tick(self.players)

        if not self.game_over and not self.victory:
            if self._room_cleared():
                self._try_advance_room()
            if team_wiped(self.players):
                self.game_over = True
                self.state_manager.transition(GameState.GAME_OVER)

        self.camera.update(self.players, self.arena_x_min, self.arena_x_max)

    def spawn_enemy_projectile(self, enemy, vx: float, vy: float, damage: float) -> None:
        self.projectiles.append(Projectile(
            owner_id=enemy.id, faction="enemy",
            x=enemy.body.x, y=enemy.body.y, vx=vx, vy=vy,
            damage=damage, damage_type=DamageType.LIGHT, color=(220, 90, 90),
        ))

    def poll_inputs(self) -> dict[int, InputState]:
        inputs = {}
        for idx, player in enumerate(self.players):
            ctx = {"self": player, "enemies": self.enemies, "allies": self.players}
            inputs[idx] = self.player_manager.input_manager.poll_one(idx, ctx)
        return inputs
