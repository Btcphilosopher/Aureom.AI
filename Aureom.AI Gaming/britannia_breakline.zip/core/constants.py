"""Global constants for Britannia Breakline.

Kept in one place so tuning the game feel (frame data, knockback, scaling
curves) never requires hunting through gameplay code.
"""

FPS = 60
DT = 1.0 / FPS
MAX_PLAYERS = 8

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# --- World space -----------------------------------------------------------
# Beat-em-up "2.5D" space: X is horizontal, Y is depth ("lane"), Z is jump
# height (visual only, does not affect collision). Depth range emulates the
# classic Streets-of-Rage brawling corridor.
DEPTH_MIN = 0.0
DEPTH_MAX = 220.0
GRAVITY = 1400.0
JUMP_VELOCITY = 520.0

GROUND_FRICTION = 2200.0
AIR_FRICTION = 400.0

# --- Combat ------------------------------------------------------------
HITSTOP_LIGHT = 3
HITSTOP_HEAVY = 6
HITSTOP_GRAB = 8
HITSTOP_SPECIAL = 10

COMBO_WINDOW_FRAMES = 90  # ~1.5s to keep a combo alive
COMBO_DECAY_PER_HIT = 0.12  # damage multiplier lost per chained hit
COMBO_MIN_MULTIPLIER = 0.35

KNOCKBACK_FRICTION = 1800.0
HITSTUN_TO_KNOCKDOWN_HITS = 5  # hits in one combo before a forced knockdown

# --- Adaptive AI ---------------------------------------------------------
ADAPTIVE_WINDOW_SECONDS = 20.0
ADAPTIVE_WINDOW_FRAMES = int(ADAPTIVE_WINDOW_SECONDS * FPS)

# --- Anglo-futuristic palette -------------------------------------------
# Industrial Britain rebuilt as a machine-city: brass, soot, imperial red,
# cold steel-blue neon, fog grey.
PALETTE = {
    "soot_black": (18, 17, 20),
    "fog_grey": (72, 78, 86),
    "steel_blue": (58, 110, 140),
    "brass": (176, 141, 87),
    "imperial_red": (168, 42, 46),
    "royal_purple": (94, 63, 120),
    "slum_neon": (64, 214, 181),
    "bone_white": (223, 219, 208),
    "rust": (120, 72, 46),
    "signal_amber": (222, 156, 61),
}

MAX_ENTITY_HP = 9999
