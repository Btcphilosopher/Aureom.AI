"""Deterministic RNG plumbing.

Every subsystem that needs randomness (procedural generation, AI decisions,
spawn tables) pulls its own named substream derived from a single master
seed. This keeps the whole simulation reproducible: same seed -> same run,
frame for frame, regardless of which systems happen to consume random
numbers in which order.
"""
from __future__ import annotations

import hashlib
import random


class DeterministicRNG:
    """Factory for independent, seed-derived random.Random substreams."""

    def __init__(self, master_seed: int):
        self.master_seed = master_seed
        self._streams: dict[str, random.Random] = {}

    def stream(self, name: str) -> random.Random:
        """Return a stable Random instance for a named subsystem."""
        if name not in self._streams:
            digest = hashlib.sha256(f"{self.master_seed}:{name}".encode()).digest()
            derived_seed = int.from_bytes(digest[:8], "big")
            self._streams[name] = random.Random(derived_seed)
        return self._streams[name]
