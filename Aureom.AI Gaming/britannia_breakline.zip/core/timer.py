"""Frame-counted timers used throughout combat, AI and procedural systems.

Everything in the simulation ticks in whole frames rather than wall-clock
seconds so replays / determinism hold regardless of render framerate.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class FrameTimer:
    duration: int
    elapsed: int = 0

    def reset(self, duration: int | None = None) -> None:
        if duration is not None:
            self.duration = duration
        self.elapsed = 0

    def tick(self, frames: int = 1) -> bool:
        """Advance the timer; returns True the frame it completes."""
        if self.elapsed >= self.duration:
            return False
        self.elapsed += frames
        return self.elapsed >= self.duration

    @property
    def done(self) -> bool:
        return self.elapsed >= self.duration

    @property
    def progress(self) -> float:
        if self.duration <= 0:
            return 1.0
        return min(1.0, self.elapsed / self.duration)


@dataclass
class Cooldown:
    """A timer that starts already-expired and can be re-armed."""
    duration: int
    remaining: int = 0

    def start(self, duration: int | None = None) -> None:
        self.remaining = duration if duration is not None else self.duration

    def tick(self, frames: int = 1) -> None:
        if self.remaining > 0:
            self.remaining = max(0, self.remaining - frames)

    @property
    def ready(self) -> bool:
        return self.remaining <= 0
