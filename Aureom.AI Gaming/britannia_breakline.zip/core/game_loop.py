"""Fixed-timestep driver.

The simulation always advances by exactly `core.constants.DT` seconds of
game time per `World.step()` call, regardless of how long real rendering
takes — this is what "deterministic simulation" means in practice: given
the same seed and the same sequence of per-frame inputs, the exact same
sequence of world states is produced every run, on any machine. In
interactive mode we simply cap real time to ~60Hz with pygame's Clock; in
headless mode we just call step() in a tight loop with no clock at all.
"""
from __future__ import annotations

from typing import Callable

from core.constants import FPS


class FixedTimestepLoop:
    def __init__(self, world, poll_inputs: Callable[[], dict], render: Callable[[], None] | None = None):
        self.world = world
        self.poll_inputs = poll_inputs
        self.render = render
        self._running = True

    def stop(self) -> None:
        self._running = False

    def run_interactive(self, should_quit: Callable[[], bool]) -> None:
        import pygame
        clock = pygame.time.Clock()
        while self._running and not should_quit():
            inputs = self.poll_inputs()
            self.world.step(inputs)
            if self.render is not None:
                self.render()
            clock.tick(FPS)

    def run_headless(self, num_frames: int) -> None:
        for _ in range(num_frames):
            if not self._running:
                break
            inputs = self.poll_inputs()
            self.world.step(inputs)
