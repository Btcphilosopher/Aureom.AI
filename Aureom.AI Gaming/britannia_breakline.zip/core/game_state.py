"""Top-level game state machine."""
from __future__ import annotations

from enum import Enum, auto


class GameState(Enum):
    BOOT = auto()
    CHARACTER_SELECT = auto()
    PLAYING = auto()
    ROOM_TRANSITION = auto()
    PAUSED = auto()
    VICTORY = auto()
    GAME_OVER = auto()


class StateManager:
    def __init__(self) -> None:
        self.state = GameState.BOOT
        self._history: list[GameState] = []

    def transition(self, new_state: GameState) -> None:
        self._history.append(self.state)
        self.state = new_state

    def pop(self) -> None:
        if self._history:
            self.state = self._history.pop()

    def is_(self, state: GameState) -> bool:
        return self.state == state
