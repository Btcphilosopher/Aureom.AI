"""Core engine: fixed-timestep loop, deterministic RNG, state management, event bus."""
