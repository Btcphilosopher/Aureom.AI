"""Lightweight pub/sub so gameplay systems stay decoupled from rendering/VFX.

Combat, AI and procedural systems publish events (hit landed, entity KO'd,
room cleared, director re-weighted...). Rendering/VFX/HUD subscribe without
combat needing to know they exist. Deterministic: subscriber order is
insertion order, and publishing never itself consumes randomness or timing.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Callable


class EventBus:
    def __init__(self) -> None:
        self._subscribers: dict[str, list[Callable[..., None]]] = defaultdict(list)

    def subscribe(self, event_type: str, callback: Callable[..., None]) -> None:
        self._subscribers[event_type].append(callback)

    def unsubscribe(self, event_type: str, callback: Callable[..., None]) -> None:
        if callback in self._subscribers[event_type]:
            self._subscribers[event_type].remove(callback)

    def publish(self, event_type: str, **data) -> None:
        for callback in list(self._subscribers.get(event_type, ())):
            callback(**data)

    def clear(self) -> None:
        self._subscribers.clear()
