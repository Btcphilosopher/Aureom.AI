"""Downed-state / assist-revive mechanics for co-op play.

A downed player can be revived by a nearby ally holding position next to
them for REVIVE_FRAMES; each player carries a small pool of `lives` so a
full-team wipe (all players downed with no reviver available) ends the run.
"""
from __future__ import annotations

REVIVE_RADIUS = 60.0
REVIVE_FRAMES = 90


def update_revives(players: list) -> None:
    downed = [p for p in players if p.downed and p.lives > 0]
    reviving = [p for p in players if p.alive and not p.downed]

    for target in downed:
        target.revive_progress = max(0.0, target.revive_progress - 0.5)  # decays if no one is near
        for helper in reviving:
            dx = helper.body.x - target.body.x
            dy = helper.body.y - target.body.y
            if dx * dx + dy * dy <= REVIVE_RADIUS * REVIVE_RADIUS:
                target.revive_progress += 1.5
                break
        if target.revive_progress >= REVIVE_FRAMES:
            target.revive()


def team_wiped(players: list) -> bool:
    """A revive requires a standing (alive and not downed) ally nearby, so
    the moment nobody is standing the team can never recover on its own —
    that is the wipe condition, independent of any individual's remaining
    assist-revive lives (those only matter for *repeated* downs while at
    least one teammate is still up to perform the revive).
    """
    return not any(p.alive and not p.downed for p in players)
