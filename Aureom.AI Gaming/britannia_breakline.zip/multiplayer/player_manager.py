"""Owns the 1-8 PlayerSlot roster: which character each slot plays and
which input source (keyboard / gamepad / bot) drives it.
"""
from __future__ import annotations

from dataclasses import dataclass

import pygame

from core.constants import MAX_PLAYERS
from input.input_manager import GamepadInputSource, InputManager, KeyboardInputSource
from multiplayer.bot_controller import BotInputSource


@dataclass
class PlayerSlot:
    index: int
    character_cls: type
    is_bot: bool


class PlayerManager:
    def __init__(self, character_classes: list[type], rng, num_keyboard_zones: int = 1,
                 headless: bool = False):
        assert 1 <= len(character_classes) <= MAX_PLAYERS
        self.slots = [
            PlayerSlot(index=i, character_cls=cls, is_bot=False)
            for i, cls in enumerate(character_classes)
        ]
        self.input_manager = InputManager()
        self._assign_input_sources(rng, num_keyboard_zones, headless)

    def _assign_input_sources(self, rng, num_keyboard_zones: int, headless: bool) -> None:
        num_joysticks = 0 if headless else pygame.joystick.get_count()
        for slot in self.slots:
            if not headless and slot.index < num_joysticks:
                self.input_manager.assign(slot.index, GamepadInputSource(slot.index))
            elif not headless and slot.index < num_keyboard_zones:
                self.input_manager.assign(slot.index, KeyboardInputSource(slot.index))
            else:
                slot.is_bot = True
                self.input_manager.assign(slot.index, BotInputSource(rng))

    def instantiate_characters(self) -> list:
        return [slot.character_cls(slot.index) for slot in self.slots]
