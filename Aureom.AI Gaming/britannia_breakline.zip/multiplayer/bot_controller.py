"""Bot policy used for player slots without a physical input device attached.

This is what makes an 8-player match runnable/demoable on one machine: any
slot beyond the available keyboard zones / gamepads is driven by a simple,
deterministic policy (move toward the nearest enemy, attack in range,
occasionally use the special) rather than sitting idle. It also prioritizes
reviving a downed ally over fighting, so the assist-revive mechanic actually
gets exercised in bot-driven and mixed-bot matches instead of the team
quietly bleeding out.
"""
from __future__ import annotations

import math
import random

from input.input_manager import InputState, PlayerInputSource
from multiplayer.revive_system import REVIVE_RADIUS

REVIVE_SEEK_RANGE = 320.0


class BotInputSource(PlayerInputSource):
    def __init__(self, rng: random.Random):
        self.rng = rng
        self._special_cooldown = rng.randint(30, 90)

    def poll(self, world_context: dict) -> InputState:
        me = world_context["self"]
        if me.downed:
            return InputState()

        downed_ally = self._nearest_downed_ally(me, world_context.get("allies", ()))
        if downed_ally is not None:
            return self._move_toward(me, downed_ally.body.x, downed_ally.body.y, REVIVE_RADIUS * 0.6)

        enemies = [e for e in world_context["enemies"] if e.alive]
        if not enemies:
            return InputState()

        target = min(enemies, key=lambda e: (e.body.x - me.body.x) ** 2 + (e.body.y - me.body.y) ** 2)
        dx = target.body.x - me.body.x
        dy = target.body.y - me.body.y
        dist = math.hypot(dx, dy)

        move_x = move_y = 0.0
        if dist > 1e-3:
            move_x, move_y = dx / dist, dy / dist

        in_range = dist <= 55.0
        light = in_range and self.rng.random() < 0.9
        heavy = in_range and not light and self.rng.random() < 0.25

        self._special_cooldown -= 1
        special = False
        if self._special_cooldown <= 0:
            special = True
            self._special_cooldown = self.rng.randint(90, 180)

        if in_range:
            move_x *= 0.15
            move_y *= 0.15

        return InputState(
            move_x=move_x, move_y=move_y,
            light_attack=light, heavy_attack=heavy, grab=False, special=special,
        )

    def _nearest_downed_ally(self, me, allies):
        candidates = [a for a in allies if a is not me and a.downed and a.lives > 0]
        if not candidates:
            return None
        nearest = min(candidates, key=lambda a: (a.body.x - me.body.x) ** 2 + (a.body.y - me.body.y) ** 2)
        dist_sq = (nearest.body.x - me.body.x) ** 2 + (nearest.body.y - me.body.y) ** 2
        return nearest if dist_sq <= REVIVE_SEEK_RANGE * REVIVE_SEEK_RANGE else None

    @staticmethod
    def _move_toward(me, target_x, target_y, stop_radius) -> InputState:
        dx, dy = target_x - me.body.x, target_y - me.body.y
        dist = math.hypot(dx, dy)
        if dist <= stop_radius or dist < 1e-3:
            return InputState()
        return InputState(move_x=dx / dist, move_y=dy / dist)
