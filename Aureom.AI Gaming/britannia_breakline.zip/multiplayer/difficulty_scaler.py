"""Player-count-driven difficulty scaling.

Design brief's rule, made concrete:
  * fewer players -> fewer enemies, but the AI plays with higher precision
    (shorter reaction/cooldown windows, so a duo fight still feels sharp).
  * more players -> "chaos scaling": noticeably larger enemy groups with
    slightly *looser* individual AI (so an 8-player brawl feels like a mob,
    not eight simultaneous precision duelists).
"""
from __future__ import annotations

from dataclasses import dataclass

from core.constants import MAX_PLAYERS


@dataclass(frozen=True)
class DifficultyProfile:
    base_enemy_count: int
    enemy_count_per_extra_player: float
    ai_cooldown_mult: float      # <1.0 = enemies attack more often (precise)
    ai_reaction_precision: float  # 0..1, higher = enemies commit to reads faster


def get_difficulty_profile(num_players: int) -> DifficultyProfile:
    num_players = max(1, min(MAX_PLAYERS, num_players))
    # Precision climbs as the group shrinks (a lone duelist AI plays tight);
    # chaos (raw numbers, looser individual play) climbs as the group grows.
    # Tuned so 1p and 8p are both a real fight but for very different reasons.
    base = max(2, round(1.5 + num_players * 0.7))  # room population baseline
    per_extra = 1.35 if num_players > 4 else 0.9
    cooldown_mult = max(0.7, min(1.3, 0.68 + 0.06 * num_players))
    precision = max(0.3, min(1.0, 1.3 - 0.1 * num_players))
    return DifficultyProfile(
        base_enemy_count=base,
        enemy_count_per_extra_player=per_extra,
        ai_cooldown_mult=cooldown_mult,
        ai_reaction_precision=precision,
    )


def scale_enemy_cooldown(base_cooldown_frames: int, num_players: int) -> int:
    profile = get_difficulty_profile(num_players)
    return max(8, int(base_cooldown_frames * profile.ai_cooldown_mult))


def room_enemy_count(room_type_value: str, num_players: int, rng) -> int:
    profile = get_difficulty_profile(num_players)
    count = profile.base_enemy_count
    if room_type_value == "choke_corridor":
        count = max(1, int(count * 0.6))
    elif room_type_value == "hazard_room":
        count = max(1, int(count * 0.5))
    elif room_type_value == "boss_chamber":
        count = max(1, num_players)  # bosses are staged separately; this is the escort count
    jitter = rng.randint(-1, 1)
    return max(1, count + jitter)
