"""1-8 player local co-op: player slots, difficulty scaling, shared camera, revives."""
