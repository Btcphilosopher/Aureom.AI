"""Shared camera with soft zoom: frames the bounding box of all living
players so an 8-player scrum stays fully visible while a 1-2 player match
stays tightly zoomed for readability.
"""
from __future__ import annotations

from core.constants import SCREEN_HEIGHT, SCREEN_WIDTH
from utils.math_utils import clamp, lerp

MIN_ZOOM = 0.55
MAX_ZOOM = 1.15
PADDING = 220.0
CAMERA_SMOOTHING = 0.12


class CameraSystem:
    def __init__(self):
        self.x = 0.0
        self.zoom = 1.0
        self._target_x = 0.0
        self._target_zoom = 1.0

    def update(self, players: list, arena_x_min: float, arena_x_max: float) -> None:
        alive = [p for p in players if p.alive]
        if not alive:
            return
        min_x = min(p.body.x for p in alive)
        max_x = max(p.body.x for p in alive)
        span = max(1.0, max_x - min_x + PADDING * 2)

        self._target_zoom = clamp(SCREEN_WIDTH / span, MIN_ZOOM, MAX_ZOOM)
        self._target_x = clamp((min_x + max_x) / 2.0, arena_x_min, arena_x_max)

        self.x = lerp(self.x, self._target_x, CAMERA_SMOOTHING)
        self.zoom = lerp(self.zoom, self._target_zoom, CAMERA_SMOOTHING)

    def world_to_screen(self, wx: float, wy: float, wz: float = 0.0) -> tuple[float, float]:
        sx = SCREEN_WIDTH / 2.0 + (wx - self.x) * self.zoom
        sy = SCREEN_HEIGHT * 0.72 + wy * self.zoom * 0.5 - wz * self.zoom
        return sx, sy
