"""Shared skeleton for all 8 playable archetypes.

Concrete characters (entities/characters/*.py) fill in `attacks`, stats,
passive trait behaviour and special-ability behaviour. Everything about
input handling, state transitions and stamina/meter economy lives here so
each archetype file only has to describe what makes it *different*.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from animation.animator import Animator
from animation.frame_data import AttackDef
from combat.combo_system import ComboTracker
from combat.hitbox import Hitbox
from core.constants import DT
from entities.entity import Entity
from input.input_manager import InputState
from utils.math_utils import approach, clamp


@dataclass
class CharacterProfile:
    display_name: str
    role: str
    passive_name: str
    passive_description: str
    special_name: str
    weakness: str
    synergy: str
    color: tuple[int, int, int]
    move_speed: float
    max_hp: float
    max_meter: float = 100.0


class PlayableCharacter(Entity):
    profile: CharacterProfile = None  # set by subclasses

    def __init__(self, player_index: int):
        assert self.profile is not None, "Character subclass must set `profile`"
        super().__init__(self.profile.display_name, faction="player", max_hp=self.profile.max_hp)
        self.player_index = player_index
        self.animator = Animator()
        self.combo = ComboTracker()
        self.attacks: dict[str, AttackDef] = self.build_attacks()
        self.meter = 0.0
        self.max_meter = self.profile.max_meter
        self.state = "idle"
        self.downed = False
        self.revive_progress = 0.0
        self.body.facing = 1
        self.stationary_frames = 0
        self._pending_hitboxes: list[Hitbox] = []
        self.lives = 2  # assist-revive pool per player
        self.special_cooldown = 0  # frames until special can be used again

        # Generic buff/aura timers a subclass may drive; team_auras.py reads
        # these each frame so cross-character effects (shields, slow fields,
        # command buffs) don't require every character to know about others.
        self.shield_dome_timer = 0
        self.damage_reduction_mult = 1.0
        self.slow_field_timer = 0
        self.command_buff_radius = 0.0
        self.command_buff_strength = 0.0
        self.speed_mult = 1.0
        self.damage_mult = 1.0
        # Filled in each frame by combat/team_auras.py from teammates' active
        # auras (Guardian's shield dome, Tactician's command field).
        self.aura_damage_reduction_mult = 1.0
        self.aura_damage_bonus_mult = 1.0

    # --- overridden by each archetype -------------------------------------------------
    def build_attacks(self) -> dict[str, AttackDef]:
        raise NotImplementedError

    def on_passive_tick(self) -> None:
        """Called every frame; implements the character's passive trait."""

    def on_hit_landed(self, target) -> None:
        """Called when one of this character's hitboxes connects."""

    def try_special(self) -> list[Hitbox]:
        """Return hitboxes (if any) spawned by the special ability."""
        return []

    def spend_meter(self, cost: float) -> bool:
        if self.meter >= cost and self.special_cooldown <= 0:
            self.meter -= cost
            return True
        return False

    # --- shared state machine ----------------------------------------------------------
    def update(self, input_state: InputState, hitstop_frozen: bool) -> list[Hitbox]:
        spawned: list[Hitbox] = []
        if hitstop_frozen:
            return spawned

        if self.downed:
            self._update_downed(input_state)
            return spawned

        if self.body.y == self.body.y:  # no-op, keeps y warm for depth AI queries
            pass

        moving = abs(input_state.move_x) > 0.05 or abs(input_state.move_y) > 0.05
        self.stationary_frames = 0 if moving else self.stationary_frames + 1

        if self.animator.is_busy:
            self._advance_action()
        elif self.body.in_hitstun_lock:
            self.state = "hitstun"
        else:
            self._handle_free_input(input_state, spawned)

        self.on_passive_tick()
        self.combo.tick()
        self.meter = clamp(self.meter + 0.03, 0.0, self.max_meter)  # slow passive meter build
        if self.special_cooldown > 0:
            self.special_cooldown -= 1
        for timer_name in ("shield_dome_timer", "slow_field_timer"):
            if getattr(self, timer_name) > 0:
                setattr(self, timer_name, getattr(self, timer_name) - 1)
        self.update_common()
        return spawned

    def _handle_free_input(self, input_state: InputState, spawned: list[Hitbox]) -> None:
        self.state = "idle"
        speed = self.profile.move_speed * self.speed_mult
        if input_state.move_x or input_state.move_y:
            self.body.vx = input_state.move_x * speed
            self.body.vy = input_state.move_y * speed * 0.6  # depth movement is slower
            self.body.facing = 1 if input_state.move_x >= 0 and input_state.move_x != 0 else self.body.facing
            if input_state.move_x < 0:
                self.body.facing = -1
            elif input_state.move_x > 0:
                self.body.facing = 1
            self.state = "walk"
        else:
            self.body.vx *= 0.5
            self.body.vy *= 0.5

        if input_state.light_attack and "light" in self.attacks:
            self._start_attack("light")
        elif input_state.heavy_attack and "heavy" in self.attacks:
            self._start_attack("heavy")
        elif input_state.grab and "grab" in self.attacks:
            self._start_attack("grab")
        elif input_state.special:
            spawned.extend(self.try_special())

    def _start_attack(self, key: str) -> None:
        attack = self.attacks[key]
        self.animator.play(f"attack_{key}", attack=attack, locked=True)
        self.state = f"attack_{key}"
        self.body.vx *= 0.3

    def _advance_action(self) -> None:
        self.animator.tick()
        atk = self.animator.state.attack
        if atk is not None and self.animator.phase == "active":
            hb = self._spawn_attack_hitbox(atk)
            self._pending_hitboxes.append(hb)

    def collect_hitboxes(self) -> list[Hitbox]:
        out = self._pending_hitboxes
        self._pending_hitboxes = []
        return out

    def _spawn_attack_hitbox(self, atk: AttackDef) -> Hitbox:
        from physics.aabb import AABB
        w, h = atk.hitbox_size
        ox, oy = atk.hitbox_offset
        x = self.body.x + (ox * self.body.facing) - w / 2
        y = self.body.y + oy - h / 2
        return Hitbox(
            owner_id=self.id,
            aabb=AABB(x, y, w, h),
            damage=atk.damage * self.damage_mult * self.aura_damage_bonus_mult,
            damage_type=atk.damage_type,
            knockback=atk.knockback,
            hitstun_frames=atk.hitstun_frames,
            life_frames=1,
            armor_piercing=atk.armor_piercing,
        )

    def _update_downed(self, input_state: InputState) -> None:
        self.state = "downed"
        self.body.vx = 0
        self.body.vy = 0

    def knock_down(self) -> None:
        super().knock_down()
        if self.hp <= 0:
            self.downed = True
            self.state = "downed"

    def take_damage(self, amount: float, damage_type) -> None:
        super().take_damage(amount * self.damage_reduction_mult * self.aura_damage_reduction_mult, damage_type)
        if self.hp <= 0 and not self.downed:
            self.downed = True
            self.state = "downed"

    def revive(self) -> None:
        if self.lives > 0:
            self.lives -= 1
            self.downed = False
            self.alive = True
            self.hp = self.max_hp * 0.5
            self.knocked_down_timer = 0
            self.hitstun_hits_taken = 0
            self.state = "idle"
