"""Deployable hazard entities: the Engineer's mines/turret, and adaptive
"slow zones" the level spawns against fast-moving teams.
"""
from __future__ import annotations

from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from entities.entity import Entity
from physics.aabb import AABB


class Mine(Entity):
    """Arms after a short delay, then detonates once an enemy steps on it."""

    def __init__(self, owner_id: int, x: float, y: float, damage: float = 22.0, arm_frames: int = 30):
        super().__init__("mine", "player", max_hp=1, width=20, height=20)
        self.owner_id = owner_id
        self.body.x, self.body.y = x, y
        self.arm_timer = arm_frames
        self.armed = False
        self.detonated = False
        self.life_frames = 600

    def update(self, enemies: list) -> Hitbox | None:
        self.life_frames -= 1
        if self.life_frames <= 0:
            self.alive = False
            return None
        if not self.armed:
            self.arm_timer -= 1
            self.armed = self.arm_timer <= 0
            return None
        for enemy in enemies:
            if enemy.alive and self.hurtbox.intersects(enemy.hurtbox):
                self.detonated = True
                self.alive = False
                return Hitbox(
                    owner_id=self.owner_id,
                    aabb=AABB(self.body.x - 40, self.body.y - 40, 80, 80),
                    damage=self.damage_value,
                    damage_type=DamageType.SPECIAL,
                    knockback=(260.0, 0.0, 140.0),
                    hitstun_frames=20,
                    life_frames=1,
                )
        return None

    damage_value = 22.0


class SlowZone(Entity):
    """A hazardous ground zone the adaptive director spawns against fast
    teams; entities standing in it have their velocity dampened each frame.
    """

    def __init__(self, x: float, y: float, radius: float = 70.0, life_frames: int = 300):
        super().__init__("slow_zone", "neutral", max_hp=1, width=radius * 2, height=radius * 2)
        self.body.x, self.body.y = x, y
        self.radius = radius
        self.life_frames = life_frames

    def update(self, entities: list) -> None:
        self.life_frames -= 1
        if self.life_frames <= 0:
            self.alive = False
            return
        for e in entities:
            if e.faction != "player" or not e.alive:
                continue
            dx = e.body.x - self.body.x
            dy = e.body.y - self.body.y
            if dx * dx + dy * dy <= self.radius * self.radius:
                e.body.vx *= 0.85
                e.body.vy *= 0.85
