"""Shared skeleton for enemy archetypes; AI behaviour lives in ai/enemy_ai.py
and is attached to the enemy instance so enemy_base stays pure state/combat.
"""
from __future__ import annotations

from dataclasses import dataclass

from animation.animator import Animator
from combat.hitbox import Hitbox
from core.timer import Cooldown
from entities.entity import Entity


@dataclass
class EnemyProfile:
    display_name: str
    max_hp: float
    move_speed: float
    color: tuple[int, int, int]
    armored: bool = False
    ranged: bool = False
    ambush: bool = False
    threat_tier: int = 1  # used by the adaptive director / spawn tables
    attack_damage: float = 10.0
    attack_range: float = 46.0
    attack_cooldown_frames: int = 55
    vision_range: float = 420.0
    attack_startup_frames: int = 14


class Enemy(Entity):
    profile: EnemyProfile = None

    def __init__(self):
        assert self.profile is not None
        super().__init__(self.profile.display_name, faction="enemy", max_hp=self.profile.max_hp)
        self.armored = self.profile.armored
        self.animator = Animator()
        self.ai = None  # assigned by ai.enemy_ai.build_behaviour_tree
        self.blackboard: dict = {"state": "seek"}
        self._pending_hitboxes: list[Hitbox] = []
        self.ai_speed_mult = 1.0  # set each frame by combat/team_auras.py (Tactician slow-time zone)
        self.attack_cooldown = Cooldown(self.profile.attack_cooldown_frames)
        self.attack_windup = 0

    def collect_hitboxes(self) -> list[Hitbox]:
        out = self._pending_hitboxes
        self._pending_hitboxes = []
        return out

    def update(self, world) -> None:
        if self.hp <= 0:
            self.alive = False
            return
        self.attack_cooldown.tick()
        if self.ai is not None:
            self.ai.tick(self, world)
        self.animator.tick()
        self.update_common()
