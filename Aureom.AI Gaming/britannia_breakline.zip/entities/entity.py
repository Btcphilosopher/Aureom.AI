"""Base actor: anything that occupies world space, can be hit, and can die."""
from __future__ import annotations

import itertools

from combat.damage_types import DamageType
from physics.aabb import AABB
from physics.physics_body import PhysicsBody

_id_counter = itertools.count(1)


def next_entity_id() -> int:
    return next(_id_counter)


class Entity:
    def __init__(self, name: str, faction: str, max_hp: float, width: float = 34.0, height: float = 64.0):
        self.id = next_entity_id()
        self.name = name
        self.faction = faction  # "player" | "enemy"
        self.body = PhysicsBody()
        self.max_hp = max_hp
        self.hp = max_hp
        self.alive = True
        self.width = width
        self.height = height
        self.armored = False
        self.hitstun_hits_taken = 0
        self.knocked_down_timer = 0

    @property
    def hurtbox(self) -> AABB:
        return AABB(self.body.x - self.width / 2, self.body.y - self.height / 2, self.width, self.height)

    def take_damage(self, amount: float, damage_type: DamageType) -> None:
        self.hp = max(0.0, self.hp - amount)

    def knock_down(self) -> None:
        self.knocked_down_timer = 45

    def is_knocked_down(self) -> bool:
        return self.knocked_down_timer > 0

    def update_common(self) -> None:
        self.body.integrate()
        if self.knocked_down_timer > 0:
            self.knocked_down_timer -= 1
