"""THE TACTICIAN — Support / buff / AI disruptor.

Strength: buffs allies, debuffs enemies.
Weakness: very low direct damage; requires team coordination to matter.
Passive "Command Field": continuously buffs nearby allies' damage output
(read by combat/team_auras.py).
Special: slow-time zone — briefly saps enemy movement/attack speed in a
radius (also read by combat/team_auras.py against the enemy roster).
"""
from __future__ import annotations

from combat.damage_types import DamageType
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter

COMMAND_FIELD_RADIUS = 160.0
COMMAND_FIELD_STRENGTH = 0.15


class Tactician(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Tactician",
        role="Support / Buff / AI Disruptor",
        passive_name="Command Field",
        passive_description="Continuously buffs nearby allies' damage output.",
        special_name="Slow-Time Zone",
        weakness="Very low direct damage; contributes almost nothing solo.",
        synergy="Multiplies whatever the rest of the team is already doing well.",
        color=(120, 70, 150),
        move_speed=130.0,
        max_hp=90.0,
    )

    def build_attacks(self):
        return {
            "light": AttackDef("tact_jab", startup=7, active=3, recovery=12, damage=5,
                                damage_type=DamageType.LIGHT, knockback=(60, 0, 10), hitstun_frames=8,
                                hitbox_size=(28, 36), hitbox_offset=(22, 0)),
            "heavy": AttackDef("tact_baton", startup=11, active=4, recovery=16, damage=8,
                                damage_type=DamageType.HEAVY, knockback=(90, 0, 20), hitstun_frames=12,
                                hitbox_size=(32, 40), hitbox_offset=(24, 0)),
        }

    def on_passive_tick(self) -> None:
        self.command_buff_radius = COMMAND_FIELD_RADIUS
        self.command_buff_strength = COMMAND_FIELD_STRENGTH

    def try_special(self) -> list:
        if not self.spend_meter(50.0):
            return []
        self.special_cooldown = 150
        self.slow_field_timer = 210  # 3.5s
        self.animator.play("slow_time_zone", locked=True)
        self.state = "special"
        return []
