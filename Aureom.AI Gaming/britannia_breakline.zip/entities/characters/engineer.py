"""THE ENGINEER — Utility / traps / control.

Strength: deployable traps, turret bursts.
Weakness: low direct combat power; needs protection from the team.
Passive "Field Deployment": faster trap placement (lower special cooldown
and lower meter cost than other characters' specials).
Special: electrified mine grid (deploys several mines at once).
"""
from __future__ import annotations

from combat.damage_types import DamageType
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter
from entities.trap import Mine


class Engineer(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Engineer",
        role="Utility / Traps / Control",
        passive_name="Field Deployment",
        passive_description="Trap specials cost less meter and recharge faster than other characters' specials.",
        special_name="Electrified Mine Grid",
        weakness="Very low direct combat power; needs the team to screen melee for them.",
        synergy="Turns choke corridors into kill zones the rest of the team can herd enemies into.",
        color=(150, 120, 40),
        move_speed=110.0,
        max_hp=100.0,
    )

    def build_attacks(self):
        return {
            "light": AttackDef("eng_prod", startup=7, active=3, recovery=12, damage=6,
                                damage_type=DamageType.LIGHT, knockback=(70, 0, 10), hitstun_frames=8,
                                hitbox_size=(34, 30), hitbox_offset=(26, 0)),
            "heavy": AttackDef("eng_burst", startup=12, active=3, recovery=20, damage=11,
                                damage_type=DamageType.HEAVY, knockback=(100, 0, 20), hitstun_frames=12,
                                hitbox_size=(90, 20), hitbox_offset=(55, 0)),
        }

    def try_special(self) -> list:
        # Field Deployment: 20% cheaper meter cost, faster recharge than peers.
        if not self.spend_meter(28.0):
            return []
        self.special_cooldown = 50
        self.animator.play("mine_grid", locked=True)
        self.state = "special"
        self.pending_mines = getattr(self, "pending_mines", [])
        for i in range(-1, 2):
            mx = self.body.x + i * 46 * self.body.facing + 40 * self.body.facing
            my = self.body.y
            self.pending_mines.append(Mine(owner_id=self.id, x=mx, y=my))
        return []

    def collect_mines(self) -> list[Mine]:
        mines = getattr(self, "pending_mines", [])
        self.pending_mines = []
        return mines
