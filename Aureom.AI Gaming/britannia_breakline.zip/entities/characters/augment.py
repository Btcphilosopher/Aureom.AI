"""THE AUGMENT — Adaptive hybrid (late-game unlock).

Strength: switches between Speed / Power / Defence modes mid-combat.
Weakness: requires resource meter build-up before a mode switch is
affordable — misplaying the meter leaves the Augment stuck in a bad mode.
Passive "Adaptive Systems": stats shift according to the active mode.
Highest skill ceiling of the roster.
"""
from __future__ import annotations

from enum import Enum

from combat.damage_types import DamageType
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter

MODE_SWITCH_COST = 35.0


class AugmentMode(Enum):
    SPEED = "speed"
    POWER = "power"
    DEFENCE = "defence"


MODE_STATS = {
    AugmentMode.SPEED: {"speed_mult": 1.5, "damage_mult": 0.85, "damage_reduction_mult": 1.1},
    AugmentMode.POWER: {"speed_mult": 0.85, "damage_mult": 1.45, "damage_reduction_mult": 1.0},
    AugmentMode.DEFENCE: {"speed_mult": 0.95, "damage_mult": 0.9, "damage_reduction_mult": 0.6},
}


class Augment(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Augment",
        role="Adaptive Hybrid",
        passive_name="Adaptive Systems",
        passive_description="Stats shift with the active mode: Speed, Power, or Defence.",
        special_name="Mode Shift",
        weakness="Needs meter built up before switching; caught mid-shift with no meter is a liability.",
        synergy="Plugs whichever gap the team composition is currently missing.",
        color=(60, 180, 200),
        move_speed=140.0,
        max_hp=120.0,
    )

    def __init__(self, player_index: int):
        super().__init__(player_index)
        self.mode = AugmentMode.POWER
        self._apply_mode()

    def build_attacks(self):
        return {
            "light": AttackDef("aug_strike", startup=6, active=4, recovery=10, damage=9,
                                damage_type=DamageType.LIGHT, knockback=(90, 0, 15), hitstun_frames=10,
                                hitbox_size=(34, 44), hitbox_offset=(26, 0)),
            "heavy": AttackDef("aug_overload", startup=12, active=5, recovery=18, damage=17,
                                damage_type=DamageType.HEAVY, knockback=(150, 0, 40), hitstun_frames=16,
                                hitbox_size=(40, 48), hitbox_offset=(28, 0)),
        }

    def _apply_mode(self) -> None:
        stats = MODE_STATS[self.mode]
        self.speed_mult = stats["speed_mult"]
        self.damage_mult = stats["damage_mult"]
        self.damage_reduction_mult = stats["damage_reduction_mult"]

    def on_passive_tick(self) -> None:
        self._apply_mode()

    def try_special(self) -> list:
        if not self.spend_meter(MODE_SWITCH_COST):
            return []
        self.special_cooldown = 30
        order = [AugmentMode.SPEED, AugmentMode.POWER, AugmentMode.DEFENCE]
        self.mode = order[(order.index(self.mode) + 1) % len(order)]
        self._apply_mode()
        self.state = "mode_shift"
        return []
