"""THE DOCKHAND — Tank / Grappler.

Strength: high HP, strong throws, crowd control.
Weakness: slow movement, poor ranged options.
Passive "Steel Grip": grabbed enemies are held in extended hitstun.
Special: ground slam AoE.
"""
from __future__ import annotations

from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter
from physics.aabb import AABB


class Dockhand(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Dockhand",
        role="Tank / Grappler",
        passive_name="Steel Grip",
        passive_description="Grabbed enemies are held in hitstun far longer than normal.",
        special_name="Ground Slam",
        weakness="Slow movement and almost no ranged answer to kiting enemies.",
        synergy="Anchors the group and locks down targets for fast characters to burst.",
        color=(90, 100, 70),
        move_speed=95.0,
        max_hp=180.0,
    )

    def build_attacks(self):
        return {
            "light": AttackDef("dock_jab", startup=6, active=4, recovery=10, damage=8,
                                damage_type=DamageType.LIGHT, knockback=(90, 0, 20), hitstun_frames=10,
                                hitbox_size=(40, 50), hitbox_offset=(30, 0)),
            "heavy": AttackDef("dock_haul", startup=14, active=6, recovery=22, damage=20,
                                damage_type=DamageType.HEAVY, knockback=(220, 0, 60), hitstun_frames=22,
                                hitbox_size=(50, 60), hitbox_offset=(34, 0)),
            "grab": AttackDef("dock_grip", startup=10, active=6, recovery=18, damage=14,
                               damage_type=DamageType.GRAB, knockback=(40, 0, 10),
                               hitstun_frames=45,  # extended by Steel Grip passive below
                               hitbox_size=(36, 55), hitbox_offset=(26, 0)),
        }

    def on_passive_tick(self) -> None:
        # Steel Grip: while a grab hitbox is live, its hitstun window is
        # already elevated in build_attacks (45 vs the ~20 baseline for other
        # cast's grabs), representing "enemies grabbed longer".
        pass

    def try_special(self) -> list[Hitbox]:
        if not self.spend_meter(55.0):
            return []
        self.special_cooldown = 90
        self.animator.play("ground_slam", locked=True)
        self.state = "special"
        return [Hitbox(
            owner_id=self.id,
            aabb=AABB(self.body.x - 90, self.body.y - 70, 180, 140),
            damage=32 * self.damage_mult,
            damage_type=DamageType.SPECIAL,
            knockback=(160, 0, 220),
            hitstun_frames=30,
            life_frames=1,
        )]
