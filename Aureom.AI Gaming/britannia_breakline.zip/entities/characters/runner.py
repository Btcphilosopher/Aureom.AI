"""THE RUNNER — Speed / hit-and-run DPS.

Strength: extremely fast, combo chaining.
Weakness: low HP, easily interrupted; weak vs heavy enemies and AoE zones.
Passive "Momentum Boost": speed increases after each hit landed, decays
back down if no hit is scored for a while.
Special: dash strike chain.
"""
from __future__ import annotations

from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter
from physics.aabb import AABB
from utils.math_utils import clamp

MOMENTUM_STEP = 0.06
MOMENTUM_MAX = 1.6
MOMENTUM_DECAY = 0.01


class Runner(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Runner",
        role="Speed / Hit-and-Run DPS",
        passive_name="Momentum Boost",
        passive_description="Speed increases with each successful hit, decaying if the streak stalls.",
        special_name="Dash Strike Chain",
        weakness="Low HP and easily interrupted; struggles vs. heavy armour and AoE zones.",
        synergy="Punishes anything the Dockhand or Guardian pins in place.",
        color=(200, 190, 60),
        move_speed=190.0,
        max_hp=85.0,
    )

    def __init__(self, player_index: int):
        super().__init__(player_index)
        self._momentum = 1.0

    def build_attacks(self):
        return {
            "light": AttackDef("run_slash", startup=3, active=3, recovery=6, damage=6,
                                damage_type=DamageType.LIGHT, knockback=(60, 0, 10), hitstun_frames=8,
                                hitbox_size=(30, 40), hitbox_offset=(24, 0)),
            "heavy": AttackDef("run_uppercut", startup=8, active=4, recovery=14, damage=13,
                                damage_type=DamageType.HEAVY, knockback=(120, 0, 90), hitstun_frames=16,
                                hitbox_size=(32, 44), hitbox_offset=(26, 0)),
        }

    def on_passive_tick(self) -> None:
        self._momentum = clamp(self._momentum - MOMENTUM_DECAY, 1.0, MOMENTUM_MAX)
        self.speed_mult = self._momentum

    def on_hit_landed(self, target) -> None:
        self._momentum = clamp(self._momentum + MOMENTUM_STEP, 1.0, MOMENTUM_MAX)

    def try_special(self) -> list[Hitbox]:
        if not self.spend_meter(40.0):
            return []
        self.special_cooldown = 45
        self.body.vx = 520.0 * self.body.facing
        self.animator.play("dash_chain", locked=True)
        self.state = "special"
        hits = []
        for i in range(3):
            hits.append(Hitbox(
                owner_id=self.id,
                aabb=AABB(self.body.x + (20 + i * 26) * self.body.facing - 16, self.body.y - 30, 32, 60),
                damage=9 * self.damage_mult,
                damage_type=DamageType.SPECIAL,
                knockback=(60, 0, 20),
                hitstun_frames=8,
                life_frames=1,
            ))
        return hits
