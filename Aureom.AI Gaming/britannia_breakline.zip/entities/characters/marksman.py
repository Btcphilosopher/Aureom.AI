"""THE MARKSMAN — Ranged control.

Strength: high precision ranged attacks.
Weakness: weak in melee, slow recovery; vulnerable when rushed.
Passive "Focus Aim": damage/accuracy increases the longer the Marksman
stands still (tracked via `stationary_frames` on the base class).
Special: piercing shot line (armor-piercing projectile hitbox).
"""
from __future__ import annotations

from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter
from physics.aabb import AABB
from utils.math_utils import clamp

FOCUS_MAX_BONUS = 0.5
FOCUS_RAMP_FRAMES = 90.0


class Marksman(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Marksman",
        role="Ranged Control",
        passive_name="Focus Aim",
        passive_description="Accuracy and damage climb the longer the Marksman holds a stationary position.",
        special_name="Piercing Shot Line",
        weakness="Weak melee damage and slow recovery; easily punished up close.",
        synergy="Zones enemies off the Engineer/Tactician while the frontline holds aggro.",
        color=(70, 150, 90),
        move_speed=125.0,
        max_hp=95.0,
    )

    def build_attacks(self):
        return {
            "light": AttackDef("mark_shot", startup=8, active=3, recovery=16, damage=10,
                                damage_type=DamageType.LIGHT, knockback=(140, 0, 10), hitstun_frames=10,
                                hitbox_size=(120, 14), hitbox_offset=(70, 0)),
            "heavy": AttackDef("mark_buttstrike", startup=10, active=4, recovery=20, damage=9,
                                damage_type=DamageType.HEAVY, knockback=(70, 0, 20), hitstun_frames=14,
                                hitbox_size=(28, 40), hitbox_offset=(22, 0)),
        }

    def _focus_bonus(self) -> float:
        ramp = clamp(self.stationary_frames / FOCUS_RAMP_FRAMES, 0.0, 1.0)
        return 1.0 + ramp * FOCUS_MAX_BONUS

    def on_passive_tick(self) -> None:
        self.damage_mult = self._focus_bonus()

    def try_special(self) -> list[Hitbox]:
        if not self.spend_meter(35.0):
            return []
        self.special_cooldown = 70
        self.animator.play("pierce_shot", locked=True)
        self.state = "special"
        line_length = 400.0
        line_x = self.body.x + 20 * self.body.facing if self.body.facing > 0 else self.body.x - 20 - line_length
        return [Hitbox(
            owner_id=self.id,
            aabb=AABB(line_x, self.body.y - 8, line_length, 16),
            damage=26 * self.damage_mult,
            damage_type=DamageType.SPECIAL,
            knockback=(200, 0, 20),
            hitstun_frames=20,
            life_frames=1,
            armor_piercing=True,
        )]
