"""The eight playable archetypes of Britannia Breakline."""
from entities.characters.dockhand import Dockhand
from entities.characters.runner import Runner
from entities.characters.marksman import Marksman
from entities.characters.engineer import Engineer
from entities.characters.guardian import Guardian
from entities.characters.rioter import Rioter
from entities.characters.tactician import Tactician
from entities.characters.augment import Augment

ROSTER = [Dockhand, Runner, Marksman, Engineer, Guardian, Rioter, Tactician, Augment]

ROSTER_BY_NAME = {cls.profile.display_name: cls for cls in ROSTER}
