"""THE RIOTER — Berserker / chaos DPS.

Strength: damage output climbs sharply under 30% HP.
Weakness: uncontrollable aggression; the exact power spike that makes the
Rioter dangerous also makes them fragile and hard to keep alive as a team.
Passive "Escalation": damage multiplier increases below 30% HP.
Special: rage flurry mode — a short window of much faster attack recovery.
"""
from __future__ import annotations

from combat.damage_types import DamageType
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter

ESCALATION_HP_THRESHOLD = 0.30
ESCALATION_MAX_BONUS = 0.9  # up to +90% damage near death


class Rioter(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Rioter",
        role="Berserker / Chaos DPS",
        passive_name="Escalation",
        passive_description="Damage output rises the lower this character's HP falls, capping near death.",
        special_name="Rage Flurry",
        weakness="Uncontrollable aggression and fragile stability; hard to coordinate with the team.",
        synergy="A wildcard finisher once the rest of the team has softened a target.",
        color=(180, 50, 40),
        move_speed=150.0,
        max_hp=110.0,
    )

    def __init__(self, player_index: int):
        super().__init__(player_index)
        self._flurry_frames = 0

    def build_attacks(self):
        return {
            "light": AttackDef("riot_swing", startup=5, active=4, recovery=9, damage=9,
                                damage_type=DamageType.LIGHT, knockback=(80, 0, 10), hitstun_frames=9,
                                hitbox_size=(34, 42), hitbox_offset=(26, 0)),
            "heavy": AttackDef("riot_smash", startup=10, active=5, recovery=18, damage=18,
                                damage_type=DamageType.HEAVY, knockback=(160, 0, 40), hitstun_frames=16,
                                hitbox_size=(40, 48), hitbox_offset=(28, 0)),
        }

    def on_passive_tick(self) -> None:
        hp_ratio = self.hp / self.max_hp if self.max_hp else 1.0
        if hp_ratio < ESCALATION_HP_THRESHOLD:
            deficit = (ESCALATION_HP_THRESHOLD - hp_ratio) / ESCALATION_HP_THRESHOLD
            self.damage_mult = 1.0 + ESCALATION_MAX_BONUS * min(1.0, deficit)
        else:
            self.damage_mult = 1.0
        if self._flurry_frames > 0:
            self._flurry_frames -= 1

    def try_special(self) -> list:
        if not self.spend_meter(45.0):
            return []
        self.special_cooldown = 100
        self._flurry_frames = 180
        self.animator.play("rage_flurry", locked=True)
        self.state = "special"
        return []

    def _advance_action(self) -> None:
        # Rage Flurry halves recovery on whatever comes next by ticking the
        # animator faster during the recovery phase only.
        if self._flurry_frames > 0 and self.animator.phase == "recovery":
            self.animator.tick()
        super()._advance_action()
