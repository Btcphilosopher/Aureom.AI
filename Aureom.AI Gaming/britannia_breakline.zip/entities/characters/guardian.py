"""THE GUARDIAN — Defensive anchor.

Strength: shields, blocking, damage reduction.
Weakness: low mobility, predictable patterns; becomes the AI's preferred
target in boss fights (see ai/enemy_ai.py targeting weights).
Passive "Wall State": damage taken is reduced while stationary.
Special: team shield dome — a radius aura that reduces damage taken by
nearby allies for a short duration (read by combat/team_auras.py).
"""
from __future__ import annotations

from combat.damage_types import DamageType
from animation.frame_data import AttackDef
from entities.character_base import CharacterProfile, PlayableCharacter

WALL_STATE_REDUCTION = 0.45
STATIONARY_FRAMES_FOR_WALL = 20


class Guardian(PlayableCharacter):
    profile = CharacterProfile(
        display_name="The Guardian",
        role="Defensive Anchor",
        passive_name="Wall State",
        passive_description="Damage taken is sharply reduced while standing still.",
        special_name="Team Shield Dome",
        weakness="Low mobility and predictable patterns; bosses will target it first.",
        synergy="Buys the fragile Runner/Rioter/Marksman/Tactician breathing room.",
        color=(80, 90, 160),
        move_speed=90.0,
        max_hp=160.0,
    )

    def build_attacks(self):
        return {
            "light": AttackDef("guard_bash", startup=8, active=4, recovery=14, damage=9,
                                damage_type=DamageType.LIGHT, knockback=(90, 0, 10), hitstun_frames=10,
                                hitbox_size=(36, 46), hitbox_offset=(28, 0)),
            "heavy": AttackDef("guard_slam", startup=13, active=5, recovery=20, damage=16,
                                damage_type=DamageType.HEAVY, knockback=(150, 0, 30), hitstun_frames=18,
                                hitbox_size=(44, 50), hitbox_offset=(30, 0)),
        }

    def on_passive_tick(self) -> None:
        if self.stationary_frames >= STATIONARY_FRAMES_FOR_WALL:
            self.damage_reduction_mult = 1.0 - WALL_STATE_REDUCTION
        else:
            self.damage_reduction_mult = 1.0

    def try_special(self) -> list:
        if not self.spend_meter(60.0):
            return []
        self.special_cooldown = 120
        self.shield_dome_timer = 240  # 4 seconds at 60fps
        self.animator.play("shield_dome", locked=True)
        self.state = "special"
        return []
