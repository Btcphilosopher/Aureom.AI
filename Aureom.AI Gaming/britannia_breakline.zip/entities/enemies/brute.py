"""Ironclad Brute — slow, armoured heavy that the adaptive director spawns
more of (and buffs) against tank-heavy player teams, per the design brief's
"tank-heavy team -> armour-piercing-resistant enemies spawn" rule.
"""
from __future__ import annotations

from ai.enemy_ai import build_behaviour_tree
from entities.enemy_base import Enemy, EnemyProfile


class IroncladBrute(Enemy):
    profile = EnemyProfile(
        display_name="Ironclad Brute",
        max_hp=110.0,
        move_speed=70.0,
        color=(90, 80, 70),
        armored=True,
        threat_tier=2,
        attack_damage=18.0,
        attack_range=52.0,
        attack_cooldown_frames=75,
    )

    def __init__(self):
        super().__init__()
        self.ai = build_behaviour_tree(self)
