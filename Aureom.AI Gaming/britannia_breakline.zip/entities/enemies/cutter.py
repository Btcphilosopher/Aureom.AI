"""Ambush Cutter — fast flanker that circles to a target's blind side before
committing to a strike. The adaptive director spawns more of these against
split/uncoordinated teams (see ai/adaptive_director.py).
"""
from __future__ import annotations

from ai.enemy_ai import build_behaviour_tree
from entities.enemy_base import Enemy, EnemyProfile


class AmbushCutter(Enemy):
    profile = EnemyProfile(
        display_name="Ambush Cutter",
        max_hp=35.0,
        move_speed=170.0,
        color=(140, 40, 90),
        ambush=True,
        threat_tier=2,
        attack_damage=14.0,
        attack_range=44.0,
        attack_cooldown_frames=45,
        vision_range=460.0,
    )

    def __init__(self):
        super().__init__()
        self.ai = build_behaviour_tree(self)
