"""Streetlevel Grunt — the baseline melee enemy. Cheap, common, unarmoured."""
from __future__ import annotations

from ai.enemy_ai import build_behaviour_tree
from entities.enemy_base import Enemy, EnemyProfile


class StreetlevelGrunt(Enemy):
    profile = EnemyProfile(
        display_name="Streetlevel Grunt",
        max_hp=40.0,
        move_speed=115.0,
        color=(110, 110, 110),
        threat_tier=1,
        attack_damage=8.0,
        attack_range=48.0,
        attack_cooldown_frames=50,
    )

    def __init__(self):
        super().__init__()
        self.ai = build_behaviour_tree(self)
