"""Enemy archetypes populating Britannia Breakline's procedural rooms."""
from entities.enemies.grunt import StreetlevelGrunt
from entities.enemies.brute import IroncladBrute
from entities.enemies.drone import SkylineMarksdrone
from entities.enemies.cutter import AmbushCutter

ENEMY_TYPES = {
    "grunt": StreetlevelGrunt,
    "brute": IroncladBrute,
    "drone": SkylineMarksdrone,
    "cutter": AmbushCutter,
}
