"""Skyline Marksdrone — ranged harasser that kites to its ideal range and
fires. The adaptive director increases the closer/ambush spawn rate to
pressure teams that lean on ranged play (see ai/adaptive_director.py).
"""
from __future__ import annotations

from ai.enemy_ai import build_behaviour_tree
from entities.enemy_base import Enemy, EnemyProfile


class SkylineMarksdrone(Enemy):
    profile = EnemyProfile(
        display_name="Skyline Marksdrone",
        max_hp=30.0,
        move_speed=95.0,
        color=(60, 130, 150),
        ranged=True,
        threat_tier=2,
        attack_damage=10.0,
        attack_range=260.0,
        attack_cooldown_frames=70,
        vision_range=520.0,
    )

    def __init__(self):
        super().__init__()
        self.ai = build_behaviour_tree(self)
