"""Entities: base actor, playable archetypes, enemy archetypes, projectiles, traps."""
