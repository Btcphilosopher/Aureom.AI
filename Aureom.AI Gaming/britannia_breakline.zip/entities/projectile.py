"""Simple ballistic/linear projectile used by the Marksman and ranged enemies."""
from __future__ import annotations

from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from entities.entity import Entity
from physics.aabb import AABB


class Projectile(Entity):
    def __init__(self, owner_id: int, faction: str, x: float, y: float, vx: float, vy: float,
                 damage: float, damage_type: DamageType = DamageType.LIGHT, pierce: bool = False,
                 life_frames: int = 90, color=(220, 220, 220)):
        super().__init__("projectile", faction, max_hp=1, width=10, height=6)
        self.owner_id = owner_id
        self.body.x, self.body.y = x, y
        self.body.vx, self.body.vy = vx, vy
        self.body.affected_by_gravity = False
        self.body.friction_enabled = False
        self.damage = damage
        self.damage_type = damage_type
        self.pierce = pierce
        self.life_frames = life_frames
        self.color = color

    def update(self) -> Hitbox | None:
        self.life_frames -= 1
        self.body.integrate()
        if self.life_frames <= 0:
            self.alive = False
            return None
        return Hitbox(
            owner_id=self.owner_id,
            aabb=self.hurtbox,
            damage=self.damage,
            damage_type=self.damage_type,
            knockback=(180.0, 0.0, 0.0),
            hitstun_frames=10,
            life_frames=1,
            armor_piercing=self.pierce,
        )
