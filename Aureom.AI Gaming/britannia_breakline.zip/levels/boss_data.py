"""The Regency Combine Warmachine — end-of-run boss.

A heavier, phase-aware variant of the standard melee behaviour: it uses the
same seek-and-strike tree for basic positioning but periodically interrupts
itself with a telegraphed AoE slam, and enrages (faster attacks) below 35% HP.
"""
from __future__ import annotations

from ai.behavior_tree import Action, Node, Status
from ai.enemy_ai import _MELEE_TREE, _acquire_target
from combat.damage_types import DamageType
from combat.hitbox import Hitbox
from core.timer import Cooldown
from entities.enemy_base import Enemy, EnemyProfile
from physics.aabb import AABB

ENRAGE_HP_RATIO = 0.35
SLAM_COOLDOWN_FRAMES = 240


class RegencyWarmachine(Enemy):
    profile = EnemyProfile(
        display_name="Regency Combine Warmachine",
        max_hp=520.0,
        move_speed=80.0,
        color=(60, 45, 45),
        armored=True,
        threat_tier=5,
        attack_damage=24.0,
        attack_range=70.0,
        attack_cooldown_frames=60,
        vision_range=900.0,
    )

    def __init__(self):
        super().__init__()
        self.slam_cooldown = Cooldown(SLAM_COOLDOWN_FRAMES)
        self.slam_cooldown.start(120)
        self.ai = _BossAI()

    def update(self, world) -> None:
        super().update(world)
        if self.hp / self.profile.max_hp < ENRAGE_HP_RATIO:
            self.attack_cooldown.duration = max(20, int(self.profile.attack_cooldown_frames * 0.55))
        self.slam_cooldown.tick()


def _slam_attack(ctx) -> Status:
    boss = ctx["enemy"]
    if not boss.slam_cooldown.ready:
        return Status.FAILURE
    boss.slam_cooldown.start()
    boss._pending_hitboxes.append(Hitbox(
        owner_id=boss.id,
        aabb=AABB(boss.body.x - 130, boss.body.y - 100, 260, 200),
        damage=boss.profile.attack_damage * 1.6,
        damage_type=DamageType.SPECIAL,
        knockback=(240.0, 0.0, 260.0),
        hitstun_frames=30,
        life_frames=1,
    ))
    return Status.SUCCESS


class _BossAI:
    """Wraps the shared melee tree with a periodic slam override."""

    def tick(self, enemy, world) -> None:
        ctx = {"enemy": enemy, "world": world, "players": world.players}
        if _acquire_target(ctx) == Status.SUCCESS and _slam_attack(ctx) == Status.SUCCESS:
            return
        _MELEE_TREE.tick(ctx)
