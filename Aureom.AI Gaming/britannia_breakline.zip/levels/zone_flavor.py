"""Short HUD flavor lines shown when entering a room, keyed by room type."""
from __future__ import annotations

from procedural.room import RoomType

ROOM_TYPE_FLAVOR = {
    RoomType.BRAWL: "The crowd closes in from every side.",
    RoomType.CHOKE: "The corridor narrows to a single contested line.",
    RoomType.HAZARD: "Live current hums under the grating. Mind your footing.",
    RoomType.BOSS: "The Combine's enforcer blocks the way forward.",
}


def flavor_for(room_type: RoomType) -> str:
    return ROOM_TYPE_FLAVOR.get(room_type, "")
