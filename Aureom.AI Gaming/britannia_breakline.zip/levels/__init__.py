"""Curated level content layered on top of the procedural systems: the boss
encounter and per-room-type flavor text.
"""
