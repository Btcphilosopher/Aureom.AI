"""Broad-phase collision helpers: entity separation and world bounds."""
from __future__ import annotations

from core.constants import DEPTH_MAX, DEPTH_MIN
from utils.math_utils import clamp


class CollisionWorld:
    """Keeps entities inside the arena bounds and pushes overlapping bodies
    apart on the depth axis so a beat-em-up "crowd" doesn't stack perfectly.
    """

    def __init__(self, arena_x_min: float, arena_x_max: float) -> None:
        self.arena_x_min = arena_x_min
        self.arena_x_max = arena_x_max

    def clamp_to_arena(self, entity) -> None:
        entity.body.x = clamp(entity.body.x, self.arena_x_min, self.arena_x_max)
        entity.body.y = clamp(entity.body.y, DEPTH_MIN, DEPTH_MAX)

    def separate_crowd(self, entities: list) -> None:
        """Cheap O(n^2) separation; fine at brawler crowd sizes (<60)."""
        radius = 22.0
        for i in range(len(entities)):
            a = entities[i]
            if not a.alive:
                continue
            for j in range(i + 1, len(entities)):
                b = entities[j]
                if not b.alive:
                    continue
                dx = b.body.x - a.body.x
                dy = b.body.y - a.body.y
                dist_sq = dx * dx + dy * dy
                min_dist = radius * 2
                if 0.0 < dist_sq < min_dist * min_dist:
                    dist = dist_sq ** 0.5
                    overlap = (min_dist - dist) / 2.0
                    nx, ny = dx / dist, dy / dist
                    a.body.x -= nx * overlap
                    a.body.y -= ny * overlap
                    b.body.x += nx * overlap
                    b.body.y += ny * overlap
