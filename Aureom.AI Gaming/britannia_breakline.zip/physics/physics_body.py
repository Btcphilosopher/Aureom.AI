"""Kinematic body: position/velocity integration for the X (horizontal),
Y (depth/lane) and Z (jump height, visual-only) axes.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.constants import AIR_FRICTION, DEPTH_MAX, DEPTH_MIN, DT, GRAVITY, GROUND_FRICTION
from utils.math_utils import clamp


@dataclass
class PhysicsBody:
    x: float = 0.0
    y: float = 0.0  # depth/lane
    z: float = 0.0  # jump height
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0
    facing: int = 1  # -1 left, +1 right
    knockback_lock_frames: int = 0
    # Projectiles fly in a straight line: they opt out of the brawler-style
    # ground friction and gravity that characters use to decelerate/land.
    affected_by_gravity: bool = True
    friction_enabled: bool = True

    def apply_knockback(self, kx: float, ky: float, kz: float, lock_frames: int) -> None:
        self.vx += kx
        self.vy += ky
        self.vz += kz
        self.knockback_lock_frames = max(self.knockback_lock_frames, lock_frames)

    def integrate(self) -> None:
        grounded = self.z <= 0.0
        if not grounded and self.affected_by_gravity:
            self.vz -= GRAVITY * DT
        self.x += self.vx * DT
        self.y += self.vy * DT
        self.z += self.vz * DT
        if self.z < 0.0:
            self.z = 0.0
            self.vz = 0.0

        if self.friction_enabled:
            friction = GROUND_FRICTION if grounded else AIR_FRICTION
            self.vx = _apply_friction(self.vx, friction)
            self.vy = _apply_friction(self.vy, friction)

        self.y = clamp(self.y, DEPTH_MIN, DEPTH_MAX)

        if self.knockback_lock_frames > 0:
            self.knockback_lock_frames -= 1

    @property
    def in_hitstun_lock(self) -> bool:
        return self.knockback_lock_frames > 0

    @property
    def grounded(self) -> bool:
        return self.z <= 0.0


def _apply_friction(v: float, friction: float) -> float:
    if v > 0:
        return max(0.0, v - friction * DT)
    if v < 0:
        return min(0.0, v + friction * DT)
    return 0.0
