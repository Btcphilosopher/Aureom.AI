"""AABB collision and physics-body integration for the 2.5D brawl space."""
