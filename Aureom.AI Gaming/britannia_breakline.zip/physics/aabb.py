"""Axis-aligned bounding box used for hurtboxes, hitboxes and level geometry."""
from __future__ import annotations

from dataclasses import dataclass

from utils.math_utils import aabb_overlap


@dataclass
class AABB:
    x: float
    y: float
    w: float
    h: float

    def intersects(self, other: "AABB") -> bool:
        return aabb_overlap(self.x, self.y, self.w, self.h, other.x, other.y, other.w, other.h)

    def moved_to(self, x: float, y: float) -> "AABB":
        return AABB(x, y, self.w, self.h)

    @property
    def center(self) -> tuple[float, float]:
        return (self.x + self.w / 2.0, self.y + self.h / 2.0)
