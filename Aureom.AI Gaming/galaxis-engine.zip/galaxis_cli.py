#!/usr/bin/env python3
"""
GALAXIS COMMAND LINE INTERFACE (CLI)
Unified terminal command center for simulation operations, inspection, and benchmarks.
"""

import sys
import json
import argparse
from galaxis.engine.simulator import GalaxisEngine
from galaxis.engine.types import GalacticEra

def main():
    parser = argparse.ArgumentParser(description="GALAXIS: Star Wars Galactic Strategy & Sandbox Engine")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # galaxis generate
    gen_parser = subparsers.add_parser("generate", help="Generate a new galaxy")
    gen_parser.add_argument("--seed", type=int, default=1138, help="RNG Seed")
    gen_parser.add_argument("--era", type=str, default="IMPERIAL_ERA", help="Galactic Era")

    # galaxis simulate
    sim_parser = subparsers.add_parser("simulate", help="Advance simulation ticks")
    sim_parser.add_argument("ticks", type=int, nargs="?", default=1, help="Number of ticks")
    sim_parser.add_argument("--seed", type=int, default=1138)

    # galaxis inspect-system
    sys_parser = subparsers.add_parser("inspect-system", help="Inspect a star system")
    sys_parser.add_argument("system_id", type=str, help="Star system ID (e.g., CORUSCANT, KUAT, TATOOINE)")

    # galaxis inspect-faction
    fac_parser = subparsers.add_parser("inspect-faction", help="Inspect a faction")
    fac_parser.add_argument("faction_id", type=str, help="Faction ID")

    # galaxis inspect-market
    subparsers.add_parser("inspect-market", help="Inspect galactic market and commodity price index")

    # galaxis inspect-history
    subparsers.add_parser("inspect-history", help="Inspect galactic timeline and historical chronicles")

    # galaxis balance
    bal_parser = subparsers.add_parser("balance", help="Run automated Monte Carlo balance simulator")
    bal_parser.add_argument("--ticks", type=int, default=100, help="Ticks to simulate")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    seed = getattr(args, "seed", 1138)
    era_str = getattr(args, "era", "IMPERIAL_ERA")
    era = GalacticEra(era_str) if era_str in [e.value for e in GalacticEra] else GalacticEra.IMPERIAL_ERA

    engine = GalaxisEngine(seed=seed, era=era)

    if args.command == "generate":
        print(f"\n[GALAXIS ENGINE] Initialized Galaxy (Seed: {seed}, Era: {era.value})")
        print(f"-> Star Systems: {len(engine.state.systems)}")
        print(f"-> Major Hyperlanes: {len(engine.state.hyperlanes)}")
        print(f"-> Active Factions: {len(engine.state.factions)}")
        print(f"-> Military Fleets: {len(engine.state.fleets)}")
        print(f"-> Technology Tree: {len(engine.state.technologies)} nodes")

    elif args.command == "simulate":
        print(f"\n[GALAXIS ENGINE] Advancing simulation by {args.ticks} ticks...")
        for t in range(args.ticks):
            summary = engine.tick()
        print(f"[+] Simulation reached Calendar Tick: {engine.state.calendar_tick}")
        if summary.get("news"):
            print(f"Latest News: {summary['news']}")

    elif args.command == "inspect-system":
        sys_id = args.system_id.upper()
        if sys_id in engine.state.systems:
            system = engine.state.systems[sys_id]
            print(f"\n=== STAR SYSTEM: {system.name} ({system.region.value}) ===")
            print(f"Controller: {system.controlling_faction}")
            print(f"Coordinates: ({system.coord_x}, {system.coord_y})")
            print(f"Connected Hyperlanes: {', '.join(system.hyperlanes)}")
            print(f"Planets ({len(system.planets)}):")
            for p in system.planets:
                print(f"  - {p.name} [{p.planet_type.value} / {p.development_tier}] Pop: {p.population:,} | Stability: {p.stability}% | Wealth: {p.wealth:,.0f}cr")
        else:
            print(f"[!] System '{sys_id}' not found in galaxy.")

    elif args.command == "inspect-faction":
        fac_id = args.faction_id.upper()
        if fac_id in engine.state.factions:
            f = engine.state.factions[fac_id]
            print(f"\n=== FACTION: {f.name} ===")
            print(f"Archetype: {f.archetype.value} | Personality: {f.personality.value}")
            print(f"Treasury: {f.credits:,.2f} Galactic Credits")
            print(f"Capital: {f.capital_system_id}")
            print(f"Controlled Systems: {', '.join(f.controlled_system_ids)}")
            print(f"Known Technologies: {len(f.known_technologies)}")
        else:
            print(f"[!] Faction '{fac_id}' not found.")

    elif args.command == "inspect-market":
        print("\n=== GALACTIC COMMODITY MARKET INDEX ===")
        # Gather sample prices from Coruscant
        coruscant = engine.state.systems["CORUSCANT"].planets[0]
        for comm, price in coruscant.commodity_prices.items():
            stock = coruscant.commodity_stockpiles.get(comm, 0)
            print(f"• {comm:<22} Stock: {stock:>7.1f} units | Price: {price:>6.2f} cr")

    elif args.command == "inspect-history":
        print("\n=== GALACTIC CHRONICLE TIMELINE ===")
        for record in engine.state.historical_events:
            print(f"[{record.tick:04d}] {record.category}: {record.title}")
            print(f"       {record.description}")

    elif args.command == "balance":
        print(f"\n[GALAXIS ENGINE] Executing automated Monte Carlo balance test ({args.ticks} ticks)...")
        results = engine.run_balance_benchmark(args.ticks)
        print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()
