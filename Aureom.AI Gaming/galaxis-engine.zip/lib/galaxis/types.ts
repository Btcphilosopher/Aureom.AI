export type GalacticRegion = 'CORE' | 'INNER_RIM' | 'MID_RIM' | 'OUTER_RIM' | 'WILD_SPACE' | 'UNKNOWN_REGIONS';

export type PlanetType = 
  | 'ECUMENOPOLIS' | 'DESERT' | 'FOREST' | 'OCEAN' | 'ICE' | 'VOLCANIC'
  | 'JUNGLE' | 'SWAMP' | 'MINING' | 'AGRICULTURAL' | 'INDUSTRIAL'
  | 'COLONY' | 'BARREN' | 'GAS_GIANT' | 'MOON' | 'ASTEROID_COLONY' | 'SPACE_STATION';

export type CityType = 'CAPITAL' | 'INDUSTRIAL' | 'TRADE' | 'MILITARY' | 'MINING' | 'AGRICULTURAL' | 'FRONTIER' | 'PORT' | 'CRIMINAL';

export type GovernmentType = 
  | 'REPUBLIC' | 'EMPIRE' | 'KINGDOM' | 'CORPORATE_STATE' | 'MILITARY_GOVERNMENT'
  | 'CONFEDERATION' | 'FEDERATION' | 'LOCAL_GOVERNMENT' | 'PLANETARY_COUNCIL'
  | 'CRIMINAL_SYNDICATE' | 'REBEL_ADMINISTRATION';

export type FactionArchetype = 
  | 'GALACTIC_REPUBLIC' | 'GALACTIC_EMPIRE' | 'NEW_REPUBLIC' | 'SEPARATIST_CONFEDERATION'
  | 'REBEL_ALLIANCE' | 'CORPORATE_CONSORTIUM' | 'HUTT_STYLE_SYNDICATE' | 'PIRATE_CONFEDERATION'
  | 'MANDALORIAN_WARRIOR' | 'INDEPENDENT_SYSTEMS' | 'CRIMINAL_NETWORK' | 'ANCIENT_FORCE_ORDER';

export type Commodity = 
  | 'FOOD' | 'FUEL' | 'METALS' | 'RARE_METALS' | 'SPARE_PARTS' | 'MEDICINES'
  | 'LUXURY_GOODS' | 'DROID_COMPONENTS' | 'SHIP_COMPONENTS' | 'WEAPONS'
  | 'RAW_MATERIALS' | 'HYPERDRIVE_COMPONENTS';

export type ShipClass = 
  | 'FIGHTER' | 'INTERCEPTOR' | 'BOMBER' | 'CORVETTE' | 'FRIGATE' | 'DESTROYER'
  | 'CRUISER' | 'BATTLESHIP' | 'CARRIER' | 'TRANSPORT' | 'FREIGHTER' | 'TANKER'
  | 'SCOUT' | 'DIPLOMATIC_SHIP' | 'COLONY_SHIP' | 'SCIENCE_SHIP' | 'MEDICAL_SHIP'
  | 'PATROL_SHIP' | 'DREADNOUGHT' | 'SUPER_CAPITAL' | 'MEGA_SHIP';

export type FleetMission = 
  | 'IDLE' | 'PATROL' | 'ESCORT' | 'SCOUT' | 'TRADE' | 'RAID' | 'BLOCKADE'
  | 'ATTACK' | 'DEFEND' | 'INVASION' | 'COLONISE' | 'TRANSPORT' | 'DIPLOMACY';

export type ExplorationState = 'UNKNOWN' | 'RUMOURED' | 'SCANNED' | 'EXPLORED' | 'MAPPED' | 'CONTROLLED';

export type ResistanceStage = 'CONTENT' | 'PROTEST' | 'SABOTAGE' | 'INSURGENCY' | 'REBELLION' | 'CIVIL_WAR' | 'INDEPENDENCE';

export type CharacterType = 'LEADER' | 'GENERAL' | 'ADMIRAL' | 'DIPLOMAT' | 'SCIENTIST' | 'SPY' | 'BOUNTY_HUNTER' | 'FORCE_USER' | 'GOVERNOR' | 'MERCHANT' | 'PIRATE';

export type ForceAlignment = 'LIGHT' | 'BALANCED' | 'DARK' | 'UNALIGNED';

export type WarGoal = 'CONQUEST' | 'LIBERATION' | 'SECESSION' | 'RESOURCE' | 'DEFENCE' | 'REGIME_CHANGE' | 'BLOCKADE' | 'PUNISHMENT';

export type AIPersonality = 'IMPERIALIST' | 'REPUBLICAN' | 'TRADER' | 'PIRATE' | 'CRIMINAL' | 'TECHNOCRAT' | 'ISOLATIONIST' | 'REVOLUTIONARY' | 'COLONIALIST' | 'DIPLOMAT' | 'MILITARIST' | 'OPPORTUNIST';

export type GalacticEra = 'HIGH_REPUBLIC' | 'REPUBLIC' | 'CLONE_WARS' | 'IMPERIAL_ERA' | 'REBELLION' | 'NEW_REPUBLIC' | 'POST_IMPERIAL' | 'LEGACY' | 'CUSTOM';

export interface ModularComponent {
  slot: string;
  name: string;
  techLevel: number;
  powerDraw: number;
  mass: number;
  stats: Record<string, number>;
}

export interface ShipState {
  shipId: string;
  name: string;
  shipClass: ShipClass;
  ownerFaction: string;
  hullMax: number;
  hullCurrent: number;
  shieldsMax: number;
  shieldsCurrent: number;
  armour: number;
  firepower: number;
  hyperdriveRating: number;
  speed: number;
  manoeuvrability: number;
  sensorRange: number;
  cargoCapacity: number;
  cargo: Record<string, number>;
  fighterCapacity: number;
  fighters: string[];
  components: Record<string, ModularComponent>;
  experience: number;
}

export interface FleetState {
  fleetId: string;
  name: string;
  ownerFaction: string;
  commanderId?: string;
  locationSystemId: string;
  destinationSystemId?: string;
  hyperspaceEtaTicks: number;
  mission: FleetMission;
  targetId?: string;
  ships: ShipState[];
  fuel: number;
  maxFuel: number;
  supplies: number;
  morale: number;
  readiness: number;
  inHyperspace: boolean;
  blockadingPlanetId?: string;
}

export interface SpaceportState {
  capacity: number;
  shipyardCapacity: number;
  tradeCapacity: number;
  traffic: number;
  fuelStockpile: number;
  repairRate: number;
  securityLevel: number;
  customsEfficiency: number;
  defenceRating: number;
}

export interface CityState {
  cityId: string;
  name: string;
  cityType: CityType;
  population: number;
  districts: number;
  industryRating: number;
  housingCapacity: number;
  commerceRating: number;
  spaceportLevel: number;
  militaryGarrison: number;
  crimeRate: number;
  cultureRating: number;
}

export interface PopulationGroup {
  groupId: string;
  species: string;
  culture: string;
  count: number;
  employment: number;
  wealth: number;
  health: number;
  education: number;
  loyalty: number;
  politicalAlignment: string;
  migrationRate: number;
}

export interface GroundUnit {
  unitId: string;
  name: string;
  unitType: string;
  ownerFaction: string;
  strength: number;
  combatPower: number;
  experience: number;
}

export interface PlanetState {
  planetId: string;
  systemId: string;
  name: string;
  planetType: PlanetType;
  developmentTier: string;
  population: number;
  habitability: number;
  climate: string;
  government: GovernmentType;
  ownerFaction: string;
  culture: string;
  primarySpecies: string;
  industry: number;
  agriculture: number;
  mining: number;
  research: number;
  trade: number;
  spaceport: SpaceportState;
  cities: CityState[];
  populations: PopulationGroup[];
  groundForces: GroundUnit[];
  defenceShield: number;
  orbitalDefence: number;
  fortification: number;
  stability: number;
  loyalty: number;
  crime: number;
  resistanceStage: ResistanceStage;
  resistancePoints: number;
  infrastructure: number;
  wealth: number;
  strategicValue: number;
  isBlockaded: boolean;
  commodityStockpiles: Record<string, number>;
  commodityPrices: Record<string, number>;
}

export interface HyperspaceRoute {
  routeId: string;
  name: string;
  originSystemId: string;
  destinationSystemId: string;
  distance: number;
  travelTimeBase: number;
  stability: number;
  capacity: number;
  security: number;
  isMajorLane: boolean;
  strategicValue: number;
}

export interface StarSystem {
  systemId: string;
  name: string;
  region: GalacticRegion;
  coordX: number;
  coordY: number;
  starType: string;
  planets: PlanetState[];
  hyperlanes: string[];
  controllingFaction: string;
  explorationState: Record<string, ExplorationState>;
  isHyperspaceJunction: boolean;
  pirateActivity: number;
  marketHub: boolean;
}

export interface TradeRoute {
  routeId: string;
  ownerFaction: string;
  originSystemId: string;
  destinationSystemId: string;
  commodity: Commodity;
  volume: number;
  profitPerTick: number;
  travelTime: number;
  risk: number;
  security: number;
  assignedFreighters: number;
  isSmuggling: boolean;
  isDisrupted: boolean;
}

export interface ForceProfile {
  isSensitive: boolean;
  sensitivityScore: number;
  trainingLevel: number;
  discipline: number;
  alignment: ForceAlignment;
  darkSideCorruption: number;
  knowledge: number;
  mastery: number;
  orderAffiliation?: string;
  abilities: string[];
}

export interface CharacterState {
  characterId: string;
  name: string;
  species: string;
  age: number;
  locationSystemId: string;
  faction: string;
  occupation: CharacterType;
  traits: string[];
  skills: Record<string, number>;
  relationships: Record<string, number>;
  loyalty: number;
  reputation: number;
  experience: number;
  status: string;
  force: ForceProfile;
}

export interface ForceOrderState {
  orderId: string;
  name: string;
  philosophy: string;
  grandmasterId?: string;
  templeSystemIds: string[];
  members: string[];
  holocrons: number;
  influence: number;
}

export interface BountyContract {
  bountyId: string;
  targetCharacterId: string;
  targetName: string;
  issuerFaction: string;
  rewardCredits: number;
  locationSystemId: string;
  difficulty: string;
  assignedHunterId?: string;
  isCompleted: boolean;
}

export interface WarState {
  warId: string;
  name: string;
  belligerentsA: string[];
  belligerentsB: string[];
  warGoal: WarGoal;
  startTick: number;
  battlesCount: number;
  occupiedPlanetIds: string[];
  casualtiesA: number;
  casualtiesB: number;
  economicDamageA: number;
  economicDamageB: number;
  warExhaustionA: number;
  warExhaustionB: number;
  isActive: boolean;
}

export interface SenateBill {
  billId: string;
  title: string;
  description: string;
  sponsorFaction: string;
  effectType: string;
  effectPayload: Record<string, any>;
  votesFor: number;
  votesAgainst: number;
  status: 'ACTIVE' | 'PASSED' | 'REJECTED';
  turnRemaining: number;
}

export interface TechnologyNode {
  techId: string;
  name: string;
  branch: string;
  tier: number;
  costResearchPoints: number;
  prerequisites: string[];
  modifiers: Record<string, number>;
  description: string;
}

export interface HistoricalRecord {
  eventId: string;
  tick: number;
  title: string;
  category: string;
  description: string;
  systemId?: string;
  involvedFactions: string[];
  impactMetrics: Record<string, any>;
}

export interface NewsEvent {
  newsId: string;
  tick: number;
  headline: string;
  body: string;
  sourceOutlet: string;
  isGalacticAlert: boolean;
}

export interface FactionState {
  factionId: string;
  name: string;
  archetype: FactionArchetype;
  personality: AIPersonality;
  government: GovernmentType;
  colorHex: string;
  credits: number;
  capitalSystemId: string;
  isPlayer: boolean;
  controlledSystemIds: string[];
  knownTechnologies: string[];
  currentResearchTechId?: string;
  researchProgress: number;
  diplomaticRelations: Record<string, number>;
  treaties: string[];
  militaryDoctrine: string;
  economicModel: string;
  powerScore: number;
  senateDelegates: number;
}

export interface GalaxyState {
  galaxySeed: number;
  era: GalacticEra;
  calendarTick: number;
  systems: Record<string, StarSystem>;
  hyperlanes: Record<string, HyperspaceRoute>;
  factions: Record<string, FactionState>;
  fleets: Record<string, FleetState>;
  characters: Record<string, CharacterState>;
  forceOrders: Record<string, ForceOrderState>;
  tradeRoutes: Record<string, TradeRoute>;
  bounties: Record<string, BountyContract>;
  wars: Record<string, WarState>;
  senateBills: SenateBill[];
  technologies: Record<string, TechnologyNode>;
  historicalEvents: HistoricalRecord[];
  newsFeed: NewsEvent[];
  rumours: Record<string, any>[];
  simulationSpeed: number;
  isPaused: boolean;
}
