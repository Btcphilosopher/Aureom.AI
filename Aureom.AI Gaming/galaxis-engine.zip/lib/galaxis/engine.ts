import {
  GalaxyState, StarSystem, PlanetState, FleetState, ShipState, CharacterState,
  TradeRoute, BountyContract, WarState, SenateBill, TechnologyNode, NewsEvent,
  HistoricalRecord, FactionState, GalacticEra, ShipClass, FleetMission, Commodity,
  ForceAlignment, ResistanceStage, ExplorationState, GovernmentType, PlanetType
} from './types';
import {
  STAR_WARS_FACTIONS_INIT, STAR_WARS_SYSTEMS_INIT, STAR_WARS_HYPERLANES_INIT,
  STAR_WARS_SHIP_SPECS, STAR_WARS_TECH_DATA
} from './data';

// Simple Linear Congruential Generator for deterministic browser simulation
class FastRNG {
  private seed: number;
  constructor(seed: number) {
    this.seed = seed % 2147483647;
    if (this.seed <= 0) this.seed += 2147483646;
  }
  next(): number {
    this.seed = (this.seed * 16807) % 2147483647;
    return (this.seed - 1) / 2147483646;
  }
  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }
  int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }
  choice<T>(arr: T[]): T {
    return arr[this.int(0, arr.length - 1)];
  }
}

export function createInitialGalaxy(seed: number = 1138, era: GalacticEra = 'IMPERIAL_ERA'): GalaxyState {
  const rng = new FastRNG(seed);
  const state: GalaxyState = {
    galaxySeed: seed,
    era,
    calendarTick: 0,
    systems: {},
    hyperlanes: {},
    factions: {},
    fleets: {},
    characters: {},
    forceOrders: {},
    tradeRoutes: {},
    bounties: {},
    wars: {},
    senateBills: [],
    technologies: {},
    historicalEvents: [],
    newsFeed: [],
    rumours: [],
    simulationSpeed: 1,
    isPaused: false
  };

  // 1. Technologies
  for (const t of STAR_WARS_TECH_DATA) {
    state.technologies[t.techId] = { ...t };
  }

  // 2. Factions
  for (const f of STAR_WARS_FACTIONS_INIT) {
    state.factions[f.factionId] = {
      ...f,
      controlledSystemIds: [],
      knownTechnologies: f.factionId === 'GALACTIC_EMPIRE' ? ['TURBOLASER_OVERCHARGE'] : ['HYPERDRIVE_CLASS_1'],
      researchProgress: 0,
      diplomaticRelations: {},
      treaties: []
    };
  }

  // 3. Systems and Planets
  for (const sysData of STAR_WARS_SYSTEMS_INIT) {
    const planets: PlanetState[] = sysData.planets.map(p => {
      const stockpiles: Record<string, number> = {
        FOOD: 200, FUEL: 300, METALS: 400, RARE_METALS: 100, SPARE_PARTS: 150,
        MEDICINES: 120, LUXURY_GOODS: 80, DROID_COMPONENTS: 100, SHIP_COMPONENTS: 100,
        WEAPONS: 150, RAW_MATERIALS: 300, HYPERDRIVE_COMPONENTS: 50
      };
      const prices: Record<string, number> = {};
      for (const k of Object.keys(stockpiles)) {
        prices[k] = 50;
      }

      if (p.planetType === 'AGRICULTURAL') {
        stockpiles.FOOD = 800;
        prices.FOOD = 18;
      } else if (p.planetType === 'INDUSTRIAL') {
        stockpiles.SHIP_COMPONENTS = 600;
        stockpiles.WEAPONS = 450;
        prices.SHIP_COMPONENTS = 42;
      } else if (p.planetType === 'GAS_GIANT') {
        stockpiles.FUEL = 1200;
        prices.FUEL = 12;
      }

      return {
        ...p,
        resistanceStage: (p.resistanceStage || 'CONTENT') as ResistanceStage,
        government: (p.government || 'DIRECT_GOVERNORSHIP') as GovernmentType,
        planetType: (p.planetType || 'TERRESTRIAL') as PlanetType,
        commodityStockpiles: stockpiles,
        commodityPrices: prices
      } as PlanetState;
    });

    const starSys: StarSystem = {
      systemId: sysData.systemId,
      name: sysData.name,
      region: sysData.region,
      coordX: sysData.coordX,
      coordY: sysData.coordY,
      starType: sysData.starType,
      planets,
      hyperlanes: [],
      controllingFaction: sysData.controllingFaction,
      explorationState: {
        GALACTIC_EMPIRE: 'CONTROLLED',
        REBEL_ALLIANCE: 'MAPPED',
        HUTT_CARTEL: 'MAPPED',
        CORPORATE_SECTOR: 'MAPPED',
        MANDALORIAN_CLANS: 'MAPPED',
        BLACK_SUN: 'MAPPED',
        INDEPENDENT_WORLDS: 'MAPPED'
      },
      isHyperspaceJunction: sysData.isHyperspaceJunction,
      marketHub: sysData.marketHub,
      pirateActivity: sysData.pirateActivity
    };
    state.systems[starSys.systemId] = starSys;

    if (state.factions[sysData.controllingFaction]) {
      state.factions[sysData.controllingFaction].controlledSystemIds.push(starSys.systemId);
    }
  }

  // 4. Hyperlanes
  for (const hl of STAR_WARS_HYPERLANES_INIT) {
    if (state.systems[hl.orig] && state.systems[hl.dest]) {
      const dist = Math.hypot(
        state.systems[hl.orig].coordX - state.systems[hl.dest].coordX,
        state.systems[hl.orig].coordY - state.systems[hl.dest].coordY
      );
      state.hyperlanes[hl.id] = {
        routeId: hl.id,
        name: hl.name,
        originSystemId: hl.orig,
        destinationSystemId: hl.dest,
        distance: Math.round(dist),
        travelTimeBase: hl.ticks,
        stability: hl.major ? 0.98 : 0.88,
        capacity: hl.major ? 1500 : 600,
        security: hl.major ? 0.85 : 0.65,
        isMajorLane: hl.major,
        strategicValue: hl.major ? 95 : 45
      };
      state.systems[hl.orig].hyperlanes.push(hl.dest);
      state.systems[hl.dest].hyperlanes.push(hl.orig);
    }
  }

  // 5. Initial Fleets
  state.fleets['FLEET_IMP_1'] = {
    fleetId: 'FLEET_IMP_1',
    name: 'Imperial 1st Sector Fleet (ISD Devastator)',
    ownerFaction: 'GALACTIC_EMPIRE',
    commanderId: 'CHAR_TARKIN',
    locationSystemId: 'CORUSCANT',
    hyperspaceEtaTicks: 0,
    mission: 'PATROL',
    ships: [
      createShip('ISD-1', 'ISD Devastator', 'DESTROYER', 'GALACTIC_EMPIRE'),
      createShip('ISD-2', 'ISD Tyrant', 'DESTROYER', 'GALACTIC_EMPIRE'),
      createShip('CR-1', 'Imperial Patrol Corvette Alpha', 'CORVETTE', 'GALACTIC_EMPIRE'),
      createShip('CR-2', 'Imperial Patrol Corvette Beta', 'CORVETTE', 'GALACTIC_EMPIRE')
    ],
    fuel: 100,
    maxFuel: 100,
    supplies: 100,
    morale: 95,
    readiness: 98,
    inHyperspace: false
  };

  state.fleets['FLEET_REB_1'] = {
    fleetId: 'FLEET_REB_1',
    name: 'Alliance Vanguard Taskforce (Home One)',
    ownerFaction: 'REBEL_ALLIANCE',
    commanderId: 'CHAR_ACKBAR',
    locationSystemId: 'MON_CALA',
    hyperspaceEtaTicks: 0,
    mission: 'PATROL',
    ships: [
      createShip('MC80-1', 'Home One', 'CRUISER', 'REBEL_ALLIANCE'),
      createShip('NEB-1', 'Redemption', 'FRIGATE', 'REBEL_ALLIANCE'),
      createShip('CR90-1', 'Tantive IV', 'CORVETTE', 'REBEL_ALLIANCE')
    ],
    fuel: 100,
    maxFuel: 100,
    supplies: 100,
    morale: 100,
    readiness: 95,
    inHyperspace: false
  };

  state.fleets['FLEET_HUTT_1'] = {
    fleetId: 'FLEET_HUTT_1',
    name: 'Cartel Enforcer Skiff Squadron',
    ownerFaction: 'HUTT_CARTEL',
    commanderId: 'CHAR_BOBA_FETT',
    locationSystemId: 'TATOOINE',
    hyperspaceEtaTicks: 0,
    mission: 'RAID',
    ships: [
      createShip('CR90-H1', 'Dune Runner', 'CORVETTE', 'HUTT_CARTEL'),
      createShip('CR90-H2', 'Kessel Marauder', 'CORVETTE', 'HUTT_CARTEL')
    ],
    fuel: 100,
    maxFuel: 100,
    supplies: 100,
    morale: 80,
    readiness: 85,
    inHyperspace: false
  };

  // 6. Characters
  state.characters['CHAR_TARKIN'] = {
    characterId: 'CHAR_TARKIN',
    name: 'Grand Moff Wilhuff Tarkin',
    species: 'Human',
    age: 64,
    locationSystemId: 'CORUSCANT',
    faction: 'GALACTIC_EMPIRE',
    occupation: 'LEADER',
    traits: ['RUTHLESS', 'DOCTRINE_OF_FEAR', 'TACTICIAN'],
    skills: { leadership: 98, fleetCommand: 85, diplomacy: 40 },
    relationships: { CHAR_VADER: 70, CHAR_MON_MOTHMA: -95 },
    loyalty: 100,
    reputation: 92,
    experience: 90,
    status: 'ACTIVE',
    force: {
      isSensitive: false,
      sensitivityScore: 0,
      trainingLevel: 0,
      discipline: 90,
      alignment: 'UNALIGNED',
      darkSideCorruption: 0,
      knowledge: 20,
      mastery: 0,
      abilities: []
    }
  };

  state.characters['CHAR_VADER'] = {
    characterId: 'CHAR_VADER',
    name: 'Lord Darth Vader',
    species: 'Human Cyborg',
    age: 45,
    locationSystemId: 'CORUSCANT',
    faction: 'GALACTIC_EMPIRE',
    occupation: 'FORCE_USER',
    traits: ['SITH_LORD', 'TERRIFYING_PRESENCE', 'FIGHTER_ACE'],
    skills: { lightsaberCombat: 100, forcePower: 99, intimidation: 100, fleetCommand: 90 },
    relationships: { CHAR_TARKIN: 65, CHAR_LUKE: 40 },
    loyalty: 85,
    reputation: 99,
    experience: 98,
    status: 'ACTIVE',
    force: {
      isSensitive: true,
      sensitivityScore: 99,
      trainingLevel: 98,
      discipline: 92,
      alignment: 'DARK',
      darkSideCorruption: 95,
      knowledge: 95,
      mastery: 99,
      orderAffiliation: 'SITH_ORDER',
      abilities: ['Force Choke', 'Lightsaber Form V', 'Telekinesis', 'Battle Intimidation']
    }
  };

  state.characters['CHAR_MON_MOTHMA'] = {
    characterId: 'CHAR_MON_MOTHMA',
    name: 'Chancellor Mon Mothma',
    species: 'Human',
    age: 48,
    locationSystemId: 'CHANDRILA',
    faction: 'REBEL_ALLIANCE',
    occupation: 'LEADER',
    traits: ['DIPLOMAT', 'INSPIRATIONAL', 'REPUBLICAN_IDEALIST'],
    skills: { diplomacy: 99, leadership: 92, senatePolitics: 95 },
    relationships: { CHAR_ACKBAR: 90, CHAR_TARKIN: -100 },
    loyalty: 100,
    reputation: 88,
    experience: 85,
    status: 'ACTIVE',
    force: { isSensitive: false, sensitivityScore: 0, trainingLevel: 0, discipline: 80, alignment: 'UNALIGNED', darkSideCorruption: 0, knowledge: 15, mastery: 0, abilities: [] }
  };

  state.characters['CHAR_ACKBAR'] = {
    characterId: 'CHAR_ACKBAR',
    name: 'Admiral Gial Ackbar',
    species: 'Mon Calamari',
    age: 58,
    locationSystemId: 'MON_CALA',
    faction: 'REBEL_ALLIANCE',
    occupation: 'ADMIRAL',
    traits: ['DEFENSIVE_MASTER', 'TRAP_AWARENESS', 'STEADFAST'],
    skills: { fleetCommand: 96, navalTactics: 94, logistics: 88 },
    relationships: { CHAR_MON_MOTHMA: 92 },
    loyalty: 98,
    reputation: 90,
    experience: 92,
    status: 'ACTIVE',
    force: { isSensitive: false, sensitivityScore: 0, trainingLevel: 0, discipline: 85, alignment: 'UNALIGNED', darkSideCorruption: 0, knowledge: 10, mastery: 0, abilities: [] }
  };

  state.characters['CHAR_BOBA_FETT'] = {
    characterId: 'CHAR_BOBA_FETT',
    name: 'Boba Fett',
    species: 'Human Clone',
    age: 36,
    locationSystemId: 'TATOOINE',
    faction: 'HUTT_CARTEL',
    occupation: 'BOUNTY_HUNTER',
    traits: ['DEADLY_HUNTER', 'BESKAR_ARMORED', 'COLD_PROFESSIONAL'],
    skills: { bountyHunting: 98, combat: 95, tracking: 94 },
    relationships: { CHAR_VADER: 50 },
    loyalty: 75,
    reputation: 95,
    experience: 88,
    status: 'ACTIVE',
    force: { isSensitive: false, sensitivityScore: 0, trainingLevel: 0, discipline: 95, alignment: 'UNALIGNED', darkSideCorruption: 0, knowledge: 20, mastery: 0, abilities: [] }
  };

  state.characters['CHAR_LUKE'] = {
    characterId: 'CHAR_LUKE',
    name: 'Luke Skywalker',
    species: 'Human',
    age: 22,
    locationSystemId: 'TATOOINE',
    faction: 'REBEL_ALLIANCE',
    occupation: 'FORCE_USER',
    traits: ['CHOSEN_SON', 'HEROIC_IDEALIST', 'STARFIGHTER_ACE'],
    skills: { forcePower: 90, starfighterPiloting: 98, lightsaberCombat: 85 },
    relationships: { CHAR_MON_MOTHMA: 85, CHAR_VADER: -10 },
    loyalty: 95,
    reputation: 80,
    experience: 70,
    status: 'ACTIVE',
    force: {
      isSensitive: true,
      sensitivityScore: 98,
      trainingLevel: 75,
      discipline: 80,
      alignment: 'LIGHT',
      darkSideCorruption: 5,
      knowledge: 60,
      mastery: 78,
      orderAffiliation: 'JEDI_ORDER',
      abilities: ['Telekinesis', 'Enhanced Reflexes', 'Sensing Presence', 'Lightsaber Form IV']
    }
  };

  // 7. Force Orders
  state.forceOrders['JEDI_ORDER'] = {
    orderId: 'JEDI_ORDER',
    name: 'The Jedi Order (Remnant)',
    philosophy: 'JEDI_ORDER',
    grandmasterId: 'CHAR_LUKE',
    templeSystemIds: ['CORUSCANT', 'ALDERAAN'],
    members: ['CHAR_LUKE'],
    holocrons: 4,
    influence: 65
  };

  state.forceOrders['SITH_ORDER'] = {
    orderId: 'SITH_ORDER',
    name: 'The Sith Order',
    philosophy: 'SITH_ORDER',
    grandmasterId: 'CHAR_VADER',
    templeSystemIds: ['KORRIBAN', 'CORUSCANT'],
    members: ['CHAR_VADER'],
    holocrons: 6,
    influence: 88
  };

  // 8. Initial Trade Routes
  state.tradeRoutes['TR_1'] = {
    routeId: 'TR_1',
    ownerFaction: 'CORPORATE_SECTOR',
    originSystemId: 'FONDO',
    destinationSystemId: 'CORUSCANT',
    commodity: 'SHIP_COMPONENTS',
    volume: 80,
    profitPerTick: 620,
    travelTime: 2,
    risk: 0.05,
    security: 0.9,
    assignedFreighters: 4,
    isSmuggling: false,
    isDisrupted: false
  };

  state.tradeRoutes['TR_2'] = {
    routeId: 'TR_2',
    ownerFaction: 'HUTT_CARTEL',
    originSystemId: 'BESPIN',
    destinationSystemId: 'TATOOINE',
    commodity: 'FUEL',
    volume: 120,
    profitPerTick: 480,
    travelTime: 3,
    risk: 0.35,
    security: 0.4,
    assignedFreighters: 3,
    isSmuggling: true,
    isDisrupted: false
  };

  // 9. Initial Bounties
  state.bounties['BOUNTY_1'] = {
    bountyId: 'BOUNTY_1',
    targetCharacterId: 'CHAR_LUKE',
    targetName: 'Luke Skywalker (Rebel Pilot)',
    issuerFaction: 'GALACTIC_EMPIRE',
    rewardCredits: 50000,
    locationSystemId: 'TATOOINE',
    difficulty: 'DEADLY',
    assignedHunterId: 'CHAR_BOBA_FETT',
    isCompleted: false
  };

  // 10. Initial Senate Bills
  state.senateBills.push({
    billId: 'BILL_101',
    title: 'Hydian Way Security Enhancement Mandate',
    description: 'Imposes 2.5% interstellar trade tariff to subsidize anti-piracy battlecruisers along outer sector junctions.',
    sponsorFaction: 'GALACTIC_EMPIRE',
    effectType: 'TARIFF_SECURITY',
    effectPayload: { securityBoost: 0.2, tariffTax: 0.025 },
    votesFor: 175,
    votesAgainst: 82,
    status: 'ACTIVE',
    turnRemaining: 3
  });

  state.senateBills.push({
    billId: 'BILL_102',
    title: 'Outer Rim Mining Rights Deregulation',
    description: 'Grants corporate tax exemptions on Tibanna gas and Beskar ore extractions in independent sectors.',
    sponsorFaction: 'CORPORATE_SECTOR',
    effectType: 'MINING_SUBSIDY',
    effectPayload: { miningBoost: 0.25, corporateWealth: 15000 },
    votesFor: 120,
    votesAgainst: 135,
    status: 'ACTIVE',
    turnRemaining: 2
  });

  // 11. Initial News and History
  state.historicalEvents.push({
    eventId: 'HIST_INIT',
    tick: 0,
    title: 'Galactic Horizon Initialized',
    category: 'CHRONICLE',
    description: `Simulation booted under ${era} protocol. Strategic hyperlane network verified across ${Object.keys(state.systems).length} systems and ${Object.keys(state.hyperlanes).length} major lanes.`,
    involvedFactions: Object.keys(state.factions),
    impactMetrics: { systems: Object.keys(state.systems).length }
  });

  state.newsFeed.push({
    newsId: 'NEWS_INIT',
    tick: 0,
    headline: 'Imperial High Command Announces Sector Fleet Readiness',
    body: 'ISD taskforces have begun routine patrols of the Corellian Run and Perlemian trade spine.',
    sourceOutlet: 'Coruscant HoloNet Central',
    isGalacticAlert: false
  });

  return state;
}

export function createShip(id: string, name: string, shipClass: ShipClass, ownerFaction: string): ShipState {
  const spec = STAR_WARS_SHIP_SPECS[shipClass] || STAR_WARS_SHIP_SPECS.CORVETTE;
  return {
    shipId: id,
    name,
    shipClass,
    ownerFaction,
    hullMax: spec.hull,
    hullCurrent: spec.hull,
    shieldsMax: spec.shields,
    shieldsCurrent: spec.shields,
    armour: spec.armour,
    firepower: spec.firepower,
    hyperdriveRating: spec.hyperdrive,
    speed: spec.speed,
    manoeuvrability: 40,
    sensorRange: 60,
    cargoCapacity: 100,
    cargo: {},
    fighterCapacity: shipClass === 'CARRIER' || shipClass === 'DESTROYER' ? 24 : 0,
    fighters: [],
    components: {},
    experience: 0
  };
}

export function advanceGalaxyTick(state: GalaxyState): { state: GalaxyState; log: string[] } {
  const nextState: GalaxyState = JSON.parse(JSON.stringify(state));
  nextState.calendarTick += 1;
  const logs: string[] = [];
  const rng = new FastRNG(nextState.galaxySeed + nextState.calendarTick * 31);

  // 1. Planetary Economy & Resource Dynamics
  for (const sysId of Object.keys(nextState.systems)) {
    const sys = nextState.systems[sysId];
    for (const p of sys.planets) {
      // Production
      const fuelBoost = p.planetType === 'GAS_GIANT' ? 15 : 2;
      const metalsBoost = p.mining * 0.2;
      const foodBoost = p.agriculture * 0.25;
      const shipCompBoost = p.industry * 0.15;

      p.commodityStockpiles.FUEL = Math.max(0, (p.commodityStockpiles.FUEL || 100) + fuelBoost - 3);
      p.commodityStockpiles.METALS = Math.max(0, (p.commodityStockpiles.METALS || 100) + metalsBoost - 2);
      p.commodityStockpiles.FOOD = Math.max(0, (p.commodityStockpiles.FOOD || 100) + foodBoost - Math.round(p.population / 400000000));
      p.commodityStockpiles.SHIP_COMPONENTS = Math.max(0, (p.commodityStockpiles.SHIP_COMPONENTS || 100) + shipCompBoost - 1.5);

      // Price calculation
      for (const [comm, stock] of Object.entries(p.commodityStockpiles)) {
        const base = 50;
        const scarcityMult = 150 / Math.max(10, stock + 25);
        p.commodityPrices[comm] = Math.round(Math.max(5, Math.min(600, base * scarcityMult)));
      }

      // Tax to faction
      if (nextState.factions[p.ownerFaction]) {
        const taxRev = Math.round((p.wealth * 0.006) * (p.stability / 100));
        nextState.factions[p.ownerFaction].credits += taxRev;
      }
    }
  }

  // 2. Trade Route Profits
  for (const tr of Object.values(nextState.tradeRoutes)) {
    if (!tr.isDisrupted && nextState.factions[tr.ownerFaction]) {
      nextState.factions[tr.ownerFaction].credits += tr.profitPerTick;
    }
  }

  // 3. Tech Research Progress
  for (const f of Object.values(nextState.factions)) {
    if (f.currentResearchTechId) {
      const tech = nextState.technologies[f.currentResearchTechId];
      if (tech) {
        f.researchProgress += 45 + rng.int(10, 30);
        if (f.researchProgress >= tech.costResearchPoints) {
          f.knownTechnologies.push(tech.techId);
          f.currentResearchTechId = undefined;
          f.researchProgress = 0;
          logs.push(`${f.name} completed research: ${tech.name}!`);

          if (f.isPlayer) {
            nextState.newsFeed.unshift({
              newsId: `NEWS_TECH_${nextState.calendarTick}`,
              tick: nextState.calendarTick,
              headline: `${f.name} Unveils Breakthrough: ${tech.name}`,
              body: `Technological doctrine updated across all navy yards and engineering academies.`,
              sourceOutlet: 'HoloNet Technology Bulletin',
              isGalacticAlert: false
            });
          }
        }
      }
    }
  }

  // 4. Fleet Movements & Hyperspace Jumps
  for (const fleet of Object.values(nextState.fleets)) {
    if (fleet.inHyperspace) {
      fleet.hyperspaceEtaTicks -= 1;
      if (fleet.hyperspaceEtaTicks <= 0) {
        fleet.inHyperspace = false;
        fleet.locationSystemId = fleet.destinationSystemId || fleet.locationSystemId;
        fleet.destinationSystemId = undefined;
        const sysName = nextState.systems[fleet.locationSystemId]?.name || 'Deep Space';
        logs.push(`Fleet ${fleet.name} exited hyperspace at ${sysName}.`);

        // Check for hostile fleets at arrival location
        const hostiles = Object.values(nextState.fleets).filter(
          f => f.fleetId !== fleet.fleetId &&
               f.locationSystemId === fleet.locationSystemId &&
               !f.inHyperspace &&
               isHostile(fleet.ownerFaction, f.ownerFaction)
        );

        if (hostiles.length > 0) {
          const defender = hostiles[0];
          logs.push(`🚨 Space Battle Initiated in ${sysName}: ${fleet.name} vs ${defender.name}!`);
          resolveCombat(fleet, defender, nextState, logs, rng);
        }
      }
    }
  }

  // 5. Planetary Resistance & Rebellion Growth
  for (const sys of Object.values(nextState.systems)) {
    for (const p of sys.planets) {
      if (p.stability < 60 || p.loyalty < 55) {
        p.resistancePoints += rng.range(1.5, 3.5);
      } else {
        p.resistancePoints = Math.max(0, p.resistancePoints - 0.8);
      }

      if (p.resistancePoints > 100) {
        p.resistanceStage = 'INDEPENDENCE';
        const prevOwner = p.ownerFaction;
        p.ownerFaction = p.ownerFaction === 'GALACTIC_EMPIRE' ? 'REBEL_ALLIANCE' : 'INDEPENDENT_WORLDS';
        p.resistancePoints = 15;
        p.stability = 75;
        logs.push(`💥 REVOLUTION: ${p.name} has declared independence from ${prevOwner}!`);

        nextState.historicalEvents.unshift({
          eventId: `HIST_REV_${nextState.calendarTick}`,
          tick: nextState.calendarTick,
          title: `Revolution on ${p.name}`,
          category: 'REBELLION',
          description: `Planetary populace overthrew garrison forces and raised the banner of ${p.ownerFaction}.`,
          systemId: sys.systemId,
          involvedFactions: [prevOwner, p.ownerFaction],
          impactMetrics: { lostPlanet: p.name }
        });

        nextState.newsFeed.unshift({
          newsId: `NEWS_REV_${nextState.calendarTick}`,
          tick: nextState.calendarTick,
          headline: `Planetary Insurgency Overthrows Garrison on ${p.name}`,
          body: `Local militia and partisan units have seized orbital defense stations and declared secession.`,
          sourceOutlet: 'Galaxy Breaking News',
          isGalacticAlert: true
        });
      } else if (p.resistancePoints > 70) {
        p.resistanceStage = 'REBELLION';
      } else if (p.resistancePoints > 45) {
        p.resistanceStage = 'INSURGENCY';
      } else if (p.resistancePoints > 20) {
        p.resistanceStage = 'PROTEST';
      } else {
        p.resistanceStage = 'CONTENT';
      }
    }
  }

  // 6. Senate Bills Voting
  for (const bill of nextState.senateBills) {
    if (bill.status === 'ACTIVE') {
      bill.turnRemaining -= 1;
      // AI Faction votes
      for (const f of Object.values(nextState.factions)) {
        if (f.factionId !== bill.sponsorFaction) {
          if (f.archetype === 'GALACTIC_REPUBLIC' || f.archetype === 'GALACTIC_EMPIRE' || f.archetype === 'CORPORATE_CONSORTIUM') {
            bill.votesFor += Math.round(f.senateDelegates * 0.4);
          } else {
            bill.votesAgainst += Math.round(f.senateDelegates * 0.35);
          }
        }
      }

      if (bill.turnRemaining <= 0) {
        if (bill.votesFor > bill.votesAgainst) {
          bill.status = 'PASSED';
          logs.push(`📜 Galactic Senate PASSED bill: "${bill.title}" (${bill.votesFor} For vs ${bill.votesAgainst} Against).`);
          nextState.newsFeed.unshift({
            newsId: `NEWS_BILL_${nextState.calendarTick}`,
            tick: nextState.calendarTick,
            headline: `Senate Resolution Ratified: ${bill.title}`,
            body: bill.description,
            sourceOutlet: 'Coruscant Senate Rotunda',
            isGalacticAlert: false
          });
        } else {
          bill.status = 'REJECTED';
          logs.push(`❌ Galactic Senate REJECTED bill: "${bill.title}".`);
        }
      }
    }
  }

  // 7. AI Faction Autonomous Orders
  for (const f of Object.values(nextState.factions)) {
    if (!f.isPlayer) {
      if (!f.currentResearchTechId) {
        const available = Object.values(nextState.technologies).filter(t => !f.knownTechnologies.includes(t.techId));
        if (available.length > 0) {
          f.currentResearchTechId = rng.choice(available).techId;
        }
      }
    }
  }

  return { state: nextState, log: logs };
}

function isHostile(f1: string, f2: string): boolean {
  if (f1 === f2 || f1 === 'NEUTRAL' || f2 === 'NEUTRAL') return false;
  if ((f1 === 'GALACTIC_EMPIRE' && f2 === 'REBEL_ALLIANCE') || (f2 === 'GALACTIC_EMPIRE' && f1 === 'REBEL_ALLIANCE')) return true;
  if (f1 === 'BLACK_SUN' || f2 === 'BLACK_SUN') return true;
  return false;
}

function resolveCombat(fleetA: FleetState, fleetB: FleetState, state: GalaxyState, logs: string[], rng: FastRNG) {
  const pwrA = fleetA.ships.reduce((sum, s) => sum + s.firepower, 0);
  const pwrB = fleetB.ships.reduce((sum, s) => sum + s.firepower, 0);

  const rollA = rng.range(0.8, 1.25) * pwrA;
  const rollB = rng.range(0.8, 1.25) * pwrB;

  const dmgToB = Math.round(rollA * 0.2);
  const dmgToA = Math.round(rollB * 0.2);

  applyDamageToFleet(fleetA, dmgToA);
  applyDamageToFleet(fleetB, dmgToB);

  const winner = rollA >= rollB ? fleetA.ownerFaction : fleetB.ownerFaction;
  logs.push(`Combat Result: ${winner} victorious! Damage Inflicted: ${fleetA.name} (-${dmgToA} HP), ${fleetB.name} (-${dmgToB} HP).`);

  state.historicalEvents.unshift({
    eventId: `HIST_BATTLE_${state.calendarTick}`,
    tick: state.calendarTick,
    title: `Battle of ${fleetA.locationSystemId}`,
    category: 'FLEET_WARFARE',
    description: `Tactical engagement between ${fleetA.name} (${fleetA.ownerFaction}) and ${fleetB.name} (${fleetB.ownerFaction}). Sector lanes secured by ${winner}.`,
    systemId: fleetA.locationSystemId,
    involvedFactions: [fleetA.ownerFaction, fleetB.ownerFaction],
    impactMetrics: { winner, dmgToA, dmgToB }
  });

  state.newsFeed.unshift({
    newsId: `NEWS_COMBAT_${state.calendarTick}`,
    tick: state.calendarTick,
    headline: `Naval Clash Reported in ${state.systems[fleetA.locationSystemId]?.name || 'Deep Space'}`,
    body: `Heavy capital ship weapon discharges reported. Naval observers confirm ${winner} superiority in the sector.`,
    sourceOutlet: 'Sector Tactical HoloFeed',
    isGalacticAlert: true
  });
}

function applyDamageToFleet(fleet: FleetState, damage: number) {
  let rem = damage;
  for (const ship of fleet.ships) {
    if (rem <= 0) break;
    if (ship.shieldsCurrent > 0) {
      const abs = Math.min(ship.shieldsCurrent, rem);
      ship.shieldsCurrent -= abs;
      rem -= abs;
    }
    if (rem > 0) {
      const hullDmg = Math.min(ship.hullCurrent, rem);
      ship.hullCurrent -= hullDmg;
      rem -= hullDmg;
    }
  }
  // Remove destroyed ships
  fleet.ships = fleet.ships.filter(s => s.hullCurrent > 0);
}
