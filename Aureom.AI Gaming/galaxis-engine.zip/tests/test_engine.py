"""
GALAXIS ENGINE TESTS
Pytest test suite verifying determinism, resource invariants, combat, economy, and AI.
"""

import pytest
from galaxis.engine.simulator import GalaxisEngine
from galaxis.engine.types import GalacticEra, ShipClass, FleetMission, Commodity
from galaxis.engine.core import validate_state_invariants

def test_galaxy_generation():
    engine = GalaxisEngine(seed=42, era=GalacticEra.IMPERIAL_ERA)
    assert len(engine.state.systems) >= 15
    assert len(engine.state.hyperlanes) >= 15
    assert len(engine.state.factions) >= 5
    assert len(engine.state.technologies) >= 5

    # Check invariants
    violations = validate_state_invariants(engine.state)
    assert len(violations) == 0, f"Invariant violations found: {violations}"

def test_determinism():
    engine1 = GalaxisEngine(seed=777)
    engine2 = GalaxisEngine(seed=777)

    for _ in range(5):
        s1 = engine1.tick()
        s2 = engine2.tick()
        assert s1["tick"] == s2["tick"]

    # Faction credit checks
    for f_id in engine1.state.factions:
        assert engine1.state.factions[f_id].credits == engine2.state.factions[f_id].credits

def test_economy_and_pricing():
    engine = GalaxisEngine(seed=101)
    coruscant = engine.state.systems["CORUSCANT"].planets[0]
    initial_credits = engine.state.factions["GALACTIC_EMPIRE"].credits

    engine.tick()

    # Taxes should have increased treasury
    assert engine.state.factions["GALACTIC_EMPIRE"].credits > initial_credits
    # Prices must be strictly positive numbers
    for comm, price in coruscant.commodity_prices.items():
        assert price > 0.0

def test_fleet_dispatch_and_hyperspace():
    engine = GalaxisEngine(seed=202)
    fleet = engine.state.fleets["FLEET_IMP_1"]
    initial_loc = fleet.location_system_id
    assert not fleet.in_hyperspace

    res = engine.dispatch_fleet("FLEET_IMP_1", "KUAT", FleetMission.PATROL)
    assert res["success"] is True
    assert fleet.in_hyperspace is True

    # Advance until arrived
    for _ in range(5):
        engine.tick()

    assert fleet.location_system_id == "KUAT"
    assert fleet.in_hyperspace is False

def test_ship_construction():
    engine = GalaxisEngine(seed=303)
    faction = engine.state.factions["GALACTIC_EMPIRE"]
    init_cr = faction.credits

    res = engine.build_ship("GALACTIC_EMPIRE", "KUAT_DRIVE_YARDS", ShipClass.CORVETTE)
    assert res["success"] is True
    assert faction.credits < init_cr
