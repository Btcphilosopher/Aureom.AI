import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

export async function POST(req: NextRequest) {
  try {
    const { faction, tick, context } = await req.json();

    const ai = getAI();
    if (!ai) {
      // Fallback local heuristic strategic advice if GEMINI_API_KEY is not configured
      return NextResponse.json({
        advisorText: `[HIGH COMMAND STRATEGIC ADVISORY - CALENDAR TICK ${tick}]\n\n` +
          `• Naval Deployments: Imperial star destroyers are holding choke-points along the Perlemian corridor. Prioritize building heavy escorts to safeguard mineral convoys.\n` +
          `• Planetary Governance: Outer Rim discontent is escalating on frontier agricultural worlds. Maintain security garrisons above 40 strength to prevent spontaneous insurrection.\n` +
          `• Economic Doctrine: Commodity markets reflect a surge in ship component prices. Expand foundry infrastructure on industrial worlds to maximize trade surplus.`
      });
    }

    const prompt = `You are the Supreme Strategic Tactical AI Advisor for the Star Wars Grand Strategy 4X game engine 'GALAXIS'.
Faction: ${faction || 'Galactic Empire'}
Calendar Tick: ${tick || 1}
Galaxy Context: ${JSON.stringify(context || {})}

Provide a concise, authentic, military & economic tactical advisory briefing to the faction high command. Give 3 actionable strategic bullet points (Naval Movements, Planetary Stability, Resource/Tech Priority). Keep it immersive in Lucasfilm Star Wars style.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return NextResponse.json({ advisorText: response.text });
  } catch (error: any) {
    return NextResponse.json(
      { advisorText: `Tactical telemetry interrupted: ${error.message}` },
      { status: 200 }
    );
  }
}
