import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Galaxis: Star Wars - Galactic Strategy Engine',
  description: 'Sophisticated Star Wars 4X grand strategy and galactic sandbox simulation engine featuring deep economy, hyperspace navigation, fleet warfare, planetary politics, Force mysticism, and dynamic alternate history.',
  openGraph: {
    title: 'Galaxis: Star Wars - Galactic Strategy Engine',
    description: 'Sophisticated Star Wars 4X grand strategy and galactic sandbox simulation engine featuring deep economy, hyperspace navigation, fleet warfare, planetary politics, Force mysticism, and dynamic alternate history.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Galaxis: Star Wars - Galactic Strategy Engine',
    description: 'Sophisticated Star Wars 4X grand strategy and galactic sandbox simulation engine featuring deep economy, hyperspace navigation, fleet warfare, planetary politics, Force mysticism, and dynamic alternate history.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
