'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  GalaxyState, ShipClass, FleetMission, Commodity 
} from '../lib/galaxis/types';
import { 
  createInitialGalaxy, advanceGalaxyTick, createShip 
} from '../lib/galaxis/engine';
import { 
  playButtonBeep, playTacticalPing, playHyperspaceJump, 
  setSoundMuted, isSoundMuted 
} from '../lib/galaxis/audio';

import { Navbar } from '../components/Navbar';
import { GalacticHoloMap } from '../components/GalacticHoloMap';
import { SystemPlanetInspector } from '../components/SystemPlanetInspector';
import { FleetShipyardCommand } from '../components/FleetShipyardCommand';
import { EconomyTradePanel } from '../components/EconomyTradePanel';
import { GalacticSenateChamber } from '../components/GalacticSenateChamber';
import { CombatTheaterModal } from '../components/CombatTheaterModal';
import { ForceOrderSanctuary } from '../components/ForceOrderSanctuary';
import { EspionageUnderworldHub } from '../components/EspionageUnderworldHub';
import { TechResearchTree } from '../components/TechResearchTree';
import { GalacticChronicleNews } from '../components/GalacticChronicleNews';
import { GalacticBalanceSimulator } from '../components/GalacticBalanceSimulator';
import { InteractivePythonConsole } from '../components/InteractivePythonConsole';

import { Sparkles, Download, Upload, Bot, X } from 'lucide-react';

export default function GalaxisPage() {
  const [galaxyState, setGalaxyState] = useState<GalaxyState>(() => createInitialGalaxy(1138, 'IMPERIAL_ERA'));
  const [activeTab, setActiveTab] = useState<string>('map');
  const [playerFactionId, setPlayerFactionId] = useState<string>('GALACTIC_EMPIRE');
  const [selectedSystemId, setSelectedSystemId] = useState<string>('CORUSCANT');
  const [selectedFleetId, setSelectedFleetId] = useState<string | null>('FLEET_IMP_1');

  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isCrtEnabled, setIsCrtEnabled] = useState<boolean>(true);

  // AI Advisor Modal
  const [advisorModalOpen, setAdvisorModalOpen] = useState<boolean>(false);
  const [advisorText, setAdvisorText] = useState<string>('');
  const [isAdvisorLoading, setIsAdvisorLoading] = useState<boolean>(false);

  // Simulation Loop Timer
  useEffect(() => {
    if (galaxyState.isPaused) return;

    const intervalMs = Math.max(50, 1200 / galaxyState.simulationSpeed);
    const timer = setInterval(() => {
      setGalaxyState(prev => {
        const { state: nextState } = advanceGalaxyTick(prev);
        return nextState;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [galaxyState.isPaused, galaxyState.simulationSpeed]);

  // Simulation Speed & Ticks
  const handleTogglePause = () => {
    setGalaxyState(prev => ({ ...prev, isPaused: !prev.isPaused }));
  };

  const handleSetSpeed = (speed: number) => {
    setGalaxyState(prev => ({ ...prev, simulationSpeed: speed, isPaused: false }));
  };

  const handleStepTick = () => {
    setGalaxyState(prev => {
      const { state: nextState } = advanceGalaxyTick(prev);
      return nextState;
    });
  };

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    setSoundMuted(next);
  };

  const handleToggleCrt = () => {
    setIsCrtEnabled(prev => !prev);
  };

  // Fleet Dispatching
  const handleDispatchFleet = (fleetId: string, destSystemId: string, mission: FleetMission = 'PATROL') => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      const fleet = next.fleets[fleetId];
      if (!fleet || !next.systems[destSystemId]) return prev;

      const currSys = next.systems[fleet.locationSystemId];
      const destSys = next.systems[destSystemId];

      const dist = Math.hypot(currSys.coordX - destSys.coordX, currSys.coordY - destSys.coordY);
      const travelTicks = Math.max(1, Math.round(dist / 40));

      fleet.inHyperspace = true;
      fleet.destinationSystemId = destSystemId;
      fleet.hyperspaceEtaTicks = travelTicks;
      fleet.mission = mission;

      next.newsFeed.unshift({
        newsId: `NEWS_DISPATCH_${next.calendarTick}`,
        tick: next.calendarTick,
        headline: `${fleet.name} Jumps to Hyperspace`,
        body: `Astrogation plot locked for ${destSys.name}. Estimated travel time: ${travelTicks} ticks.`,
        sourceOutlet: 'Naval Astrogation Bureau',
        isGalacticAlert: false
      });

      return next;
    });
  };

  // Ship Construction
  const handleBuildShip = (planetId: string, shipClass: ShipClass) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      const faction = next.factions[playerFactionId];
      if (!faction) return prev;

      // Find system
      let targetPlanet = null;
      for (const s of Object.values(next.systems)) {
        for (const p of s.planets) {
          if (p.planetId === planetId) {
            targetPlanet = p;
            break;
          }
        }
        if (targetPlanet) break;
      }

      if (!targetPlanet) return prev;

      const newShip = createShip(
        `SHIP_${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        `${faction.name} ${shipClass} #${Math.floor(Math.random() * 900 + 100)}`,
        shipClass,
        playerFactionId
      );

      // Find or create a fleet at this system
      let fleet = Object.values(next.fleets).find(
        f => f.ownerFaction === playerFactionId && f.locationSystemId === targetPlanet.systemId && !f.inHyperspace
      );

      if (!fleet) {
        fleet = {
          fleetId: `FLEET_${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
          name: `${faction.name} Sector Taskforce ${Object.keys(next.fleets).length + 1}`,
          ownerFaction: playerFactionId,
          locationSystemId: targetPlanet.systemId,
          hyperspaceEtaTicks: 0,
          mission: 'PATROL',
          ships: [newShip],
          fuel: 100, maxFuel: 100, supplies: 100, morale: 100, readiness: 100, inHyperspace: false
        };
        next.fleets[fleet.fleetId] = fleet;
      } else {
        fleet.ships.push(newShip);
      }

      return next;
    });
  };

  // Trade Route
  const handleCreateTradeRoute = (originSys: string, destSys: string, commodity: Commodity, isSmuggling: boolean) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      const routeId = `TR_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      next.tradeRoutes[routeId] = {
        routeId,
        ownerFaction: playerFactionId,
        originSystemId: originSys,
        destinationSystemId: destSys,
        commodity,
        volume: isSmuggling ? 60 : 100,
        profitPerTick: isSmuggling ? 750 : 520,
        travelTime: 2,
        risk: isSmuggling ? 0.35 : 0.05,
        security: isSmuggling ? 0.3 : 0.85,
        assignedFreighters: 3,
        isSmuggling,
        isDisrupted: false
      };
      return next;
    });
  };

  // Senate Bill Sponsor
  const handleProposeBill = (title: string, description: string) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      next.senateBills.unshift({
        billId: `BILL_${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        title,
        description,
        sponsorFaction: playerFactionId,
        effectType: 'CUSTOM_LEGISLATION',
        effectPayload: {},
        votesFor: next.factions[playerFactionId]?.senateDelegates || 50,
        votesAgainst: 20,
        status: 'ACTIVE',
        turnRemaining: 4
      });
      return next;
    });
  };

  // Senate Bill Voting
  const handleVoteBill = (billId: string, isFor: boolean) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      const bill = next.senateBills.find(b => b.billId === billId);
      if (bill) {
        const delegates = next.factions[playerFactionId]?.senateDelegates || 25;
        if (isFor) bill.votesFor += delegates;
        else bill.votesAgainst += delegates;
      }
      return next;
    });
  };

  // Start Tech Research
  const handleStartResearch = (techId: string) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      const faction = next.factions[playerFactionId];
      if (faction) {
        faction.currentResearchTechId = techId;
        faction.researchProgress = 0;
      }
      return next;
    });
  };

  // Post Bounty
  const handlePostBounty = (targetName: string, reward: number, location: string) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      const bountyId = `BOUNTY_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      next.bounties[bountyId] = {
        bountyId,
        targetCharacterId: `CHAR_TARGET_${Math.random().toString(36).substring(2, 5)}`,
        targetName,
        issuerFaction: playerFactionId,
        rewardCredits: reward,
        locationSystemId: location,
        difficulty: 'HIGH',
        isCompleted: false
      };
      return next;
    });
  };

  // Run Spy Mission
  const handleExecuteSpyMission = (missionType: string, targetSystem: string) => {
    setGalaxyState(prev => {
      const next = JSON.parse(JSON.stringify(prev)) as GalaxyState;
      if (missionType === 'INCITE_REVOLT') {
        const sys = next.systems[targetSystem];
        if (sys && sys.planets[0]) {
          sys.planets[0].resistancePoints += 25;
          sys.planets[0].stability = Math.max(10, sys.planets[0].stability - 20);
        }
      }
      return next;
    });
  };

  // AI Strategic Advisor Request
  const handleOpenAdvisor = async () => {
    setAdvisorModalOpen(true);
    setIsAdvisorLoading(true);
    try {
      const res = await fetch('/app/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          faction: galaxyState.factions[playerFactionId]?.name || 'Galactic Empire',
          tick: galaxyState.calendarTick,
          context: {
            credits: galaxyState.factions[playerFactionId]?.credits,
            systems: galaxyState.factions[playerFactionId]?.controlledSystemIds.length,
            fleets: Object.values(galaxyState.fleets).filter(f => f.ownerFaction === playerFactionId).length
          }
        })
      });
      const data = await res.json();
      setAdvisorText(data.advisorText);
    } catch (err: any) {
      setAdvisorText('Advisory channel jammed: ' + err.message);
    } finally {
      setIsAdvisorLoading(false);
    }
  };

  // Save / Export Game State
  const handleExportSave = () => {
    playTacticalPing();
    const json = JSON.stringify(galaxyState, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `galaxis_save_tick_${galaxyState.calendarTick}.json`;
    a.click();
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans ${isCrtEnabled ? 'scanlines' : ''}`}>
      {/* Top Navigation & Status Bar */}
      <Navbar
        state={galaxyState}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onTogglePause={handleTogglePause}
        onSetSpeed={handleSetSpeed}
        onStepTick={handleStepTick}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        isCrtEnabled={isCrtEnabled}
        onToggleCrt={handleToggleCrt}
        playerFactionId={playerFactionId}
        onSelectPlayerFaction={setPlayerFactionId}
      />

      {/* Main Tactical Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {activeTab === 'map' && (
          <GalacticHoloMap
            state={galaxyState}
            selectedSystemId={selectedSystemId}
            onSelectSystem={setSelectedSystemId}
            selectedFleetId={selectedFleetId}
            onSelectFleet={setSelectedFleetId}
            onDispatchFleet={handleDispatchFleet}
          />
        )}

        {activeTab === 'planets' && (
          <SystemPlanetInspector
            state={galaxyState}
            selectedSystemId={selectedSystemId}
            onSelectSystem={setSelectedSystemId}
            playerFactionId={playerFactionId}
            onBuildShip={handleBuildShip}
          />
        )}

        {activeTab === 'fleets' && (
          <FleetShipyardCommand
            state={galaxyState}
            playerFactionId={playerFactionId}
            selectedFleetId={selectedFleetId}
            onSelectFleet={setSelectedFleetId}
            onDispatchFleet={handleDispatchFleet}
          />
        )}

        {activeTab === 'economy' && (
          <EconomyTradePanel
            state={galaxyState}
            playerFactionId={playerFactionId}
            onCreateTradeRoute={handleCreateTradeRoute}
          />
        )}

        {activeTab === 'senate' && (
          <GalacticSenateChamber
            state={galaxyState}
            playerFactionId={playerFactionId}
            onProposeBill={handleProposeBill}
            onVoteBill={handleVoteBill}
          />
        )}

        {activeTab === 'combat' && (
          <CombatTheaterModal
            state={galaxyState}
            playerFactionId={playerFactionId}
          />
        )}

        {activeTab === 'force' && (
          <ForceOrderSanctuary
            state={galaxyState}
            playerFactionId={playerFactionId}
          />
        )}

        {activeTab === 'espionage' && (
          <EspionageUnderworldHub
            state={galaxyState}
            playerFactionId={playerFactionId}
            onPostBounty={handlePostBounty}
            onExecuteSpyMission={handleExecuteSpyMission}
          />
        )}

        {activeTab === 'research' && (
          <TechResearchTree
            state={galaxyState}
            playerFactionId={playerFactionId}
            onStartResearch={handleStartResearch}
          />
        )}

        {activeTab === 'chronicles' && (
          <GalacticChronicleNews state={galaxyState} />
        )}

        {activeTab === 'balance' && (
          <GalacticBalanceSimulator
            state={galaxyState}
            onUpdateState={setGalaxyState}
          />
        )}

        {activeTab === 'terminal' && (
          <InteractivePythonConsole
            state={galaxyState}
            onUpdateState={setGalaxyState}
          />
        )}
      </main>

      {/* Floating Tactical Advisor & Save State Widget */}
      <div className="fixed bottom-4 right-4 flex items-center gap-2 z-40">
        <button
          onClick={handleOpenAdvisor}
          className="px-3.5 py-2 rounded-full bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold font-mono text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all"
        >
          <Bot size={16} />
          <span>HOLONET STRATEGIC ADVISOR</span>
        </button>

        <button
          onClick={handleExportSave}
          className="p-2 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors shadow-lg"
          title="Export Save State JSON"
        >
          <Download size={16} />
        </button>
      </div>

      {/* AI Advisor Modal */}
      {advisorModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-cyan-500 rounded-lg p-6 max-w-lg w-full space-y-4 font-mono text-xs text-cyan-100 shadow-[0_0_30px_rgba(6,182,212,0.25)]">
            <div className="flex justify-between items-center border-b border-cyan-800 pb-3">
              <div className="flex items-center gap-2">
                <Bot className="text-cyan-400" size={18} />
                <h3 className="text-sm font-bold text-cyan-300">HOLONET SUPREME STRATEGIC BRIEFING</h3>
              </div>
              <button onClick={() => setAdvisorModalOpen(false)} className="text-slate-400 hover:text-white">
                <X size={16} />
              </button>
            </div>

            <div className="bg-slate-900/90 p-4 rounded border border-cyan-900/60 leading-relaxed whitespace-pre-wrap max-h-80 overflow-y-auto text-slate-200">
              {isAdvisorLoading ? (
                <div className="flex items-center justify-center py-8 text-cyan-400 gap-2">
                  <span className="animate-spin text-lg">⚙</span>
                  <span>DECRYPTING SECTOR TACTICAL CIPHERS...</span>
                </div>
              ) : (
                advisorText
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-900">
              <button
                onClick={() => setAdvisorModalOpen(false)}
                className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs"
              >
                ACKNOWLEDGE BRIEFING
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
