"""
GALAXIS STAR WARS CONTENT PACK
Data-driven Star Wars galaxy definitions, eras, factions, systems, ships, and technologies.
"""

from typing import Dict, List, Any
from galaxis.engine.types import (
    GalacticRegion, PlanetType, CityType, GovernmentType, FactionArchetype,
    Commodity, ShipClass, CharacterType, ForceAlignment, AIPersonality, GalacticEra
)

STAR_WARS_REGIONS_CONFIG = {
    GalacticRegion.CORE: {
        "pop_density": 0.95,
        "wealth_density": 0.9,
        "military_density": 0.85,
        "hyperlane_density": 0.9,
        "piracy_risk": 0.05,
        "stability": 90.0,
    },
    GalacticRegion.INNER_RIM: {
        "pop_density": 0.8,
        "wealth_density": 0.75,
        "military_density": 0.7,
        "hyperlane_density": 0.8,
        "piracy_risk": 0.1,
        "stability": 80.0,
    },
    GalacticRegion.MID_RIM: {
        "pop_density": 0.6,
        "wealth_density": 0.55,
        "military_density": 0.5,
        "hyperlane_density": 0.6,
        "piracy_risk": 0.25,
        "stability": 70.0,
    },
    GalacticRegion.OUTER_RIM: {
        "pop_density": 0.35,
        "wealth_density": 0.3,
        "military_density": 0.3,
        "hyperlane_density": 0.4,
        "piracy_risk": 0.55,
        "stability": 50.0,
    },
    GalacticRegion.WILD_SPACE: {
        "pop_density": 0.1,
        "wealth_density": 0.15,
        "military_density": 0.1,
        "hyperlane_density": 0.2,
        "piracy_risk": 0.7,
        "stability": 35.0,
    },
    GalacticRegion.UNKNOWN_REGIONS: {
        "pop_density": 0.05,
        "wealth_density": 0.1,
        "military_density": 0.05,
        "hyperlane_density": 0.1,
        "piracy_risk": 0.8,
        "stability": 30.0,
    }
}

STAR_WARS_FACTIONS_DATA = [
    {
        "faction_id": "GALACTIC_EMPIRE",
        "name": "Galactic Empire",
        "archetype": FactionArchetype.GALACTIC_EMPIRE,
        "personality": AIPersonality.IMPERIALIST,
        "government": GovernmentType.EMPIRE,
        "color_hex": "#1e3a8a", # Deep Imperial Blue / Slate
        "credits": 250000.0,
        "capital_system": "CORUSCANT",
        "military_doctrine": "DREADNOUGHT_SUPREMACY",
        "senate_delegates": 120,
    },
    {
        "faction_id": "REBEL_ALLIANCE",
        "name": "Alliance to Restore the Republic",
        "archetype": FactionArchetype.REBEL_ALLIANCE,
        "personality": AIPersonality.REVOLUTIONARY,
        "government": GovernmentType.REBEL_ADMINISTRATION,
        "color_hex": "#dc2626", # Rebel Crimson
        "credits": 65000.0,
        "capital_system": "MON_CALA",
        "military_doctrine": "STARFIGHTER_GUERRILLA",
        "senate_delegates": 30,
    },
    {
        "faction_id": "HUTT_CARTEL",
        "name": "Hutt Grand Cartel",
        "archetype": FactionArchetype.HUTT_STYLE_SYNDICATE,
        "personality": AIPersonality.CRIMINAL,
        "government": GovernmentType.CRIMINAL_SYNDICATE,
        "color_hex": "#854d0e", # Hutt Bronze
        "credits": 180000.0,
        "capital_system": "TATOOINE",
        "military_doctrine": "MERCENARY_FLEETS",
        "senate_delegates": 45,
    },
    {
        "faction_id": "CORPORATE_SECTOR",
        "name": "Corporate Sector Consortium",
        "archetype": FactionArchetype.CORPORATE_CONSORTIUM,
        "personality": AIPersonality.TRADER,
        "government": GovernmentType.CORPORATE_STATE,
        "color_hex": "#0d9488", # Teal
        "credits": 210000.0,
        "capital_system": "FONDO",
        "military_doctrine": "ECONOMIC_DEFENSE",
        "senate_delegates": 60,
    },
    {
        "faction_id": "MANDALORIAN_CLANS",
        "name": "Mandalorian Protectors",
        "archetype": FactionArchetype.MANDALORIAN_WARRIOR,
        "personality": AIPersonality.MILITARIST,
        "government": GovernmentType.PLANETARY_COUNCIL,
        "color_hex": "#d97706", # Beskar Gold
        "credits": 80000.0,
        "capital_system": "MANDALORE",
        "military_doctrine": "ELITE_COMMANDO",
        "senate_delegates": 15,
    },
    {
        "faction_id": "BLACK_SUN",
        "name": "Black Sun Syndicate",
        "archetype": FactionArchetype.CRIMINAL_NETWORK,
        "personality": AIPersonality.PIRATE,
        "government": GovernmentType.CRIMINAL_SYNDICATE,
        "color_hex": "#7e22ce", # Shadow Purple
        "credits": 120000.0,
        "capital_system": "ORD_MANTELL",
        "military_doctrine": "CORVETTE_RAIDERS",
        "senate_delegates": 10,
    },
    {
        "faction_id": "INDEPENDENT_WORLDS",
        "name": "Frontier Independent League",
        "archetype": FactionArchetype.INDEPENDENT_SYSTEMS,
        "personality": AIPersonality.ISOLATIONIST,
        "government": GovernmentType.FEDERATION,
        "color_hex": "#4b5563", # Neutral Slate
        "credits": 50000.0,
        "capital_system": "ERIADU",
        "military_doctrine": "SYSTEM_PATROL",
        "senate_delegates": 40,
    }
]

STAR_WARS_SYSTEMS_DATA = [
    # Core Worlds
    {
        "system_id": "CORUSCANT",
        "name": "Coruscant",
        "region": GalacticRegion.CORE,
        "x": 0.0, "y": 0.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "CORUSCANT_PRIME",
                "name": "Coruscant",
                "type": PlanetType.ECUMENOPOLIS,
                "tier": "CORE_WORLD",
                "population": 1000000000000,
                "habitability": 0.9,
                "climate": "CONTROLLED_URBAN",
                "government": GovernmentType.EMPIRE,
                "wealth": 500000.0,
                "industry": 95.0, "agriculture": 10.0, "mining": 5.0, "research": 98.0, "trade": 100.0,
                "stability": 92.0, "loyalty": 88.0, "crime": 18.0,
                "spaceport_cap": 50, "shipyard_cap": 8,
            }
        ]
    },
    {
        "system_id": "KUAT",
        "name": "Kuat",
        "region": GalacticRegion.CORE,
        "x": 12.0, "y": 8.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "KUAT_DRIVE_YARDS",
                "name": "Kuat",
                "type": PlanetType.INDUSTRIAL,
                "tier": "CORE_WORLD",
                "population": 3500000000,
                "habitability": 0.85,
                "climate": "TEMPERATE",
                "government": GovernmentType.CORPORATE_STATE,
                "wealth": 380000.0,
                "industry": 100.0, "agriculture": 20.0, "mining": 70.0, "research": 85.0, "trade": 90.0,
                "stability": 94.0, "loyalty": 90.0, "crime": 8.0,
                "spaceport_cap": 40, "shipyard_cap": 15,
            }
        ]
    },
    {
        "system_id": "CORELLIA",
        "name": "Corellia",
        "region": GalacticRegion.CORE,
        "x": -8.0, "y": -12.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "CORELLIA_PRIME",
                "name": "Corellia",
                "type": PlanetType.INDUSTRIAL,
                "tier": "CORE_WORLD",
                "population": 3000000000,
                "habitability": 0.9,
                "climate": "TEMPERATE_OCEANIC",
                "government": GovernmentType.PLANETARY_COUNCIL,
                "wealth": 320000.0,
                "industry": 95.0, "agriculture": 45.0, "mining": 60.0, "research": 80.0, "trade": 95.0,
                "stability": 80.0, "loyalty": 72.0, "crime": 25.0,
                "spaceport_cap": 35, "shipyard_cap": 12,
            }
        ]
    },
    {
        "system_id": "ALDERAAN",
        "name": "Alderaan",
        "region": GalacticRegion.CORE,
        "x": 6.0, "y": -6.0,
        "controller": "REBEL_ALLIANCE",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "ALDERAAN_PRIME",
                "name": "Alderaan",
                "type": PlanetType.FOREST,
                "tier": "CORE_WORLD",
                "population": 2000000000,
                "habitability": 0.98,
                "climate": "PRISTINE_ALPINE",
                "government": GovernmentType.KINGDOM,
                "wealth": 260000.0,
                "industry": 40.0, "agriculture": 90.0, "mining": 30.0, "research": 90.0, "trade": 75.0,
                "stability": 88.0, "loyalty": 92.0, "crime": 5.0,
                "spaceport_cap": 20, "shipyard_cap": 3,
            }
        ]
    },
    {
        "system_id": "CHANDRILA",
        "name": "Chandrila",
        "region": GalacticRegion.CORE,
        "x": 4.0, "y": 14.0,
        "controller": "REBEL_ALLIANCE",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "CHANDRILA_PRIME",
                "name": "Chandrila",
                "type": PlanetType.AGRICULTURAL,
                "tier": "CORE_WORLD",
                "population": 1200000000,
                "habitability": 0.96,
                "climate": "TEMPERATE_PLAINS",
                "government": GovernmentType.REPUBLIC,
                "wealth": 210000.0,
                "industry": 50.0, "agriculture": 95.0, "mining": 20.0, "research": 85.0, "trade": 80.0,
                "stability": 90.0, "loyalty": 88.0, "crime": 6.0,
                "spaceport_cap": 20, "shipyard_cap": 3,
            }
        ]
    },
    # Inner Rim & Mid Rim
    {
        "system_id": "FONDO",
        "name": "Fondor",
        "region": GalacticRegion.INNER_RIM,
        "x": -18.0, "y": -22.0,
        "controller": "CORPORATE_SECTOR",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "FONDOR_SHIPYARDS",
                "name": "Fondor",
                "type": PlanetType.INDUSTRIAL,
                "tier": "INDUSTRIAL_WORLD",
                "population": 5000000000,
                "habitability": 0.7,
                "climate": "INDUSTRIALIZED_SMOG",
                "government": GovernmentType.CORPORATE_STATE,
                "wealth": 310000.0,
                "industry": 98.0, "agriculture": 10.0, "mining": 80.0, "research": 75.0, "trade": 88.0,
                "spaceport_cap": 35, "shipyard_cap": 14,
            }
        ]
    },
    {
        "system_id": "NABOO",
        "name": "Naboo",
        "region": GalacticRegion.MID_RIM,
        "x": 28.0, "y": -32.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "NABOO_PRIME",
                "name": "Naboo",
                "type": PlanetType.SWAMP,
                "tier": "CITY",
                "population": 4500000000,
                "habitability": 0.95,
                "climate": "MEDITERRANEAN_LAKES",
                "government": GovernmentType.KINGDOM,
                "wealth": 190000.0,
                "industry": 55.0, "agriculture": 85.0, "mining": 60.0, "research": 80.0, "trade": 65.0,
                "spaceport_cap": 18, "shipyard_cap": 4,
            }
        ]
    },
    {
        "system_id": "KASHYYYK",
        "name": "Kashyyyk",
        "region": GalacticRegion.MID_RIM,
        "x": 36.0, "y": 12.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "KASHYYYK_PRIME",
                "name": "Kashyyyk",
                "type": PlanetType.JUNGLE,
                "tier": "SETTLEMENT",
                "population": 1000000000,
                "habitability": 0.88,
                "climate": "GIANT_WROSHYR_FOREST",
                "government": GovernmentType.LOCAL_GOVERNMENT,
                "wealth": 80000.0,
                "industry": 30.0, "agriculture": 70.0, "mining": 40.0, "research": 40.0, "trade": 45.0,
                "stability": 55.0, "loyalty": 35.0, "crime": 35.0,
                "resistance_points": 45.0,
                "spaceport_cap": 12, "shipyard_cap": 2,
            }
        ]
    },
    # Outer Rim Worlds
    {
        "system_id": "MON_CALA",
        "name": "Mon Cala",
        "region": GalacticRegion.OUTER_RIM,
        "x": 58.0, "y": 42.0,
        "controller": "REBEL_ALLIANCE",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "MON_CALA_PRIME",
                "name": "Mon Cala",
                "type": PlanetType.OCEAN,
                "tier": "CITY",
                "population": 27000000000,
                "habitability": 0.9,
                "climate": "AQUATIC_OCEANIC",
                "government": GovernmentType.CONFEDERATION,
                "wealth": 240000.0,
                "industry": 90.0, "agriculture": 60.0, "mining": 75.0, "research": 85.0, "trade": 80.0,
                "spaceport_cap": 30, "shipyard_cap": 12,
            }
        ]
    },
    {
        "system_id": "MANDALORE",
        "name": "Mandalore",
        "region": GalacticRegion.OUTER_RIM,
        "x": 42.0, "y": 48.0,
        "controller": "MANDALORIAN_CLANS",
        "is_junction": True,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "MANDALORE_SUNDARI",
                "name": "Mandalore",
                "type": PlanetType.DESERT,
                "tier": "CITY",
                "population": 4000000000,
                "habitability": 0.65,
                "climate": "ARID_BIO_DOMES",
                "government": GovernmentType.MILITARY_GOVERNMENT,
                "wealth": 150000.0,
                "industry": 85.0, "agriculture": 30.0, "mining": 95.0, "research": 70.0, "trade": 55.0,
                "spaceport_cap": 25, "shipyard_cap": 6,
            }
        ]
    },
    {
        "system_id": "TATOOINE",
        "name": "Tatooine",
        "region": GalacticRegion.OUTER_RIM,
        "x": -52.0, "y": -46.0,
        "controller": "HUTT_CARTEL",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "TATOOINE_MOS_EISLEY",
                "name": "Tatooine",
                "type": PlanetType.DESERT,
                "tier": "SETTLEMENT",
                "population": 200000,
                "habitability": 0.45,
                "climate": "TWIN_SUN_DESERT",
                "government": GovernmentType.CRIMINAL_SYNDICATE,
                "wealth": 45000.0,
                "industry": 20.0, "agriculture": 25.0, "mining": 50.0, "research": 20.0, "trade": 80.0,
                "stability": 40.0, "loyalty": 30.0, "crime": 85.0,
                "spaceport_cap": 15, "shipyard_cap": 2,
            }
        ]
    },
    {
        "system_id": "GEONOSIS",
        "name": "Geonosis",
        "region": GalacticRegion.OUTER_RIM,
        "x": -48.0, "y": -42.0,
        "controller": "INDEPENDENT_WORLDS",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "GEONOSIS_HIVES",
                "name": "Geonosis",
                "type": PlanetType.BARREN,
                "tier": "INDUSTRIAL_WORLD",
                "population": 100000000,
                "habitability": 0.4,
                "climate": "ARID_CANYONS",
                "government": GovernmentType.LOCAL_GOVERNMENT,
                "wealth": 95000.0,
                "industry": 92.0, "agriculture": 10.0, "mining": 90.0, "research": 65.0, "trade": 50.0,
                "spaceport_cap": 20, "shipyard_cap": 8,
            }
        ]
    },
    {
        "system_id": "ERIADU",
        "name": "Eriadu",
        "region": GalacticRegion.OUTER_RIM,
        "x": -35.0, "y": -58.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "ERIADU_PRIME",
                "name": "Eriadu",
                "type": PlanetType.INDUSTRIAL,
                "tier": "CITY",
                "population": 22000000000,
                "habitability": 0.75,
                "climate": "POLLUTED_TEMPERATE",
                "government": GovernmentType.MILITARY_GOVERNMENT,
                "wealth": 280000.0,
                "industry": 95.0, "agriculture": 35.0, "mining": 85.0, "research": 70.0, "trade": 85.0,
                "spaceport_cap": 30, "shipyard_cap": 10,
            }
        ]
    },
    {
        "system_id": "BESPIN",
        "name": "Bespin",
        "region": GalacticRegion.OUTER_RIM,
        "x": -64.0, "y": -28.0,
        "controller": "INDEPENDENT_WORLDS",
        "is_junction": False,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "BESPIN_CLOUD_CITY",
                "name": "Bespin Cloud City",
                "type": PlanetType.GAS_GIANT,
                "tier": "CITY",
                "population": 6000000,
                "habitability": 0.8,
                "climate": "LIFE_ZONE_ATMOSPHERE",
                "government": GovernmentType.PLANETARY_COUNCIL,
                "wealth": 140000.0,
                "industry": 60.0, "agriculture": 10.0, "mining": 98.0, "research": 60.0, "trade": 90.0,
                "spaceport_cap": 25, "shipyard_cap": 2,
            }
        ]
    },
    {
        "system_id": "MUSTAFAR",
        "name": "Mustafar",
        "region": GalacticRegion.OUTER_RIM,
        "x": -68.0, "y": -60.0,
        "controller": "GALACTIC_EMPIRE",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "MUSTAFAR_MINING",
                "name": "Mustafar",
                "type": PlanetType.VOLCANIC,
                "tier": "MINING",
                "population": 20000,
                "habitability": 0.2,
                "climate": "MOLTEN_LAVA",
                "government": GovernmentType.MILITARY_GOVERNMENT,
                "wealth": 60000.0,
                "industry": 70.0, "agriculture": 0.0, "mining": 100.0, "research": 50.0, "trade": 30.0,
                "spaceport_cap": 12, "shipyard_cap": 2,
            }
        ]
    },
    {
        "system_id": "SULLUST",
        "name": "Sullust",
        "region": GalacticRegion.OUTER_RIM,
        "x": -26.0, "y": -44.0,
        "controller": "CORPORATE_SECTOR",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "SULLUST_INCOM",
                "name": "Sullust",
                "type": PlanetType.VOLCANIC,
                "tier": "INDUSTRIAL_WORLD",
                "population": 18000000000,
                "habitability": 0.6,
                "climate": "SUBTERRANEAN_CITIES",
                "government": GovernmentType.CORPORATE_STATE,
                "wealth": 220000.0,
                "industry": 96.0, "agriculture": 20.0, "mining": 92.0, "research": 85.0, "trade": 80.0,
                "spaceport_cap": 28, "shipyard_cap": 8,
            }
        ]
    },
    {
        "system_id": "RYLOTH",
        "name": "Ryloth",
        "region": GalacticRegion.OUTER_RIM,
        "x": -32.0, "y": -68.0,
        "controller": "INDEPENDENT_WORLDS",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "RYLOTH_KALA_UUN",
                "name": "Ryloth",
                "type": PlanetType.DESERT,
                "tier": "SETTLEMENT",
                "population": 1500000000,
                "habitability": 0.55,
                "climate": "TIDALLY_LOCKED",
                "government": GovernmentType.LOCAL_GOVERNMENT,
                "wealth": 55000.0,
                "industry": 35.0, "agriculture": 30.0, "mining": 85.0, "research": 30.0, "trade": 60.0,
                "stability": 45.0, "crime": 60.0,
                "spaceport_cap": 12, "shipyard_cap": 1,
            }
        ]
    },
    {
        "system_id": "HOTH",
        "name": "Hoth",
        "region": GalacticRegion.OUTER_RIM,
        "x": -56.0, "y": -72.0,
        "controller": "REBEL_ALLIANCE",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "HOTH_ECHO_BASE",
                "name": "Hoth",
                "type": PlanetType.ICE,
                "tier": "OUTPOST",
                "population": 5000,
                "habitability": 0.25,
                "climate": "PERPETUAL_BLIZZARDS",
                "government": GovernmentType.REBEL_ADMINISTRATION,
                "wealth": 15000.0,
                "industry": 15.0, "agriculture": 5.0, "mining": 20.0, "research": 40.0, "trade": 10.0,
                "spaceport_cap": 8, "shipyard_cap": 0,
            }
        ]
    },
    {
        "system_id": "ORD_MANTELL",
        "name": "Ord Mantell",
        "region": GalacticRegion.MID_RIM,
        "x": 18.0, "y": 38.0,
        "controller": "BLACK_SUN",
        "is_junction": True,
        "market_hub": True,
        "planets": [
            {
                "planet_id": "ORD_MANTELL_SCRAP",
                "name": "Ord Mantell",
                "type": PlanetType.COLONY,
                "tier": "CITY",
                "population": 4000000000,
                "habitability": 0.7,
                "climate": "POLLUTED_COASTAL",
                "government": GovernmentType.CRIMINAL_SYNDICATE,
                "wealth": 120000.0,
                "industry": 65.0, "agriculture": 30.0, "mining": 60.0, "research": 45.0, "trade": 95.0,
                "stability": 48.0, "crime": 80.0,
                "spaceport_cap": 25, "shipyard_cap": 4,
            }
        ]
    },
    {
        "system_id": "KORRIBAN",
        "name": "Korriban (Moraband)",
        "region": GalacticRegion.OUTER_RIM,
        "x": 75.0, "y": 62.0,
        "controller": "INDEPENDENT_WORLDS",
        "is_junction": False,
        "market_hub": False,
        "planets": [
            {
                "planet_id": "KORRIBAN_VALLEY",
                "name": "Korriban",
                "type": PlanetType.BARREN,
                "tier": "OUTPOST",
                "population": 1000,
                "habitability": 0.3,
                "climate": "RED_DUST_RUINS",
                "government": GovernmentType.LOCAL_GOVERNMENT,
                "wealth": 20000.0,
                "industry": 10.0, "agriculture": 0.0, "mining": 40.0, "research": 95.0, "trade": 10.0,
                "spaceport_cap": 6, "shipyard_cap": 0,
            }
        ]
    }
]

# Major Hyperspace Lanes (Hydian Way, Perlemian Trade Route, Corellian Run, Rimma Trade Spine)
STAR_WARS_HYPERLANES_DATA = [
    # Core Connections
    ("CORUSCANT", "KUAT", "Perlemian Trade Route", True, 2),
    ("CORUSCANT", "CORELLIA", "Corellian Run", True, 2),
    ("CORUSCANT", "ALDERAAN", "Alderaan Trunk", True, 1),
    ("CORUSCANT", "CHANDRILA", "Daro Corridor", False, 2),
    ("KUAT", "FONDO", "Shipbuilders Span", True, 3),
    ("CORELLIA", "FONDO", "Corellian-Fondor Route", True, 2),
    ("ALDERAAN", "CHANDRILA", "Core Unity Lane", False, 2),

    # Mid & Outer Rim Connections
    ("CORELLIA", "NABOO", "Corellian Trade Spine", True, 4),
    ("CORUSCANT", "ORD_MANTELL", "Hydian Way North", True, 4),
    ("ORD_MANTELL", "MANDALORE", "Mandalorian Reach", True, 3),
    ("MANDALORE", "MON_CALA", "Hydian Northeast Sector", True, 4),
    ("ORD_MANTELL", "KASHYYYK", "Mid Rim Spur", False, 3),
    ("NABOO", "TATOOINE", "Outer Rim Southern Spur", False, 4),
    ("TATOOINE", "GEONOSIS", "Arkanis Route", False, 1),
    ("GEONOSIS", "SULLUST", "Rimma Trade Connector", True, 3),
    ("SULLUST", "ERIADU", "Rimma Trade Spine", True, 3),
    ("ERIADU", "BESPIN", "Anoat Sector Lane", False, 4),
    ("BESPIN", "HOTH", "Anoat Deep Reach", False, 3),
    ("ERIADU", "MUSTAFAR", "Outer Slicers Run", False, 4),
    ("ERIADU", "RYLOTH", "Death Wind Corridor", False, 3),
    ("MON_CALA", "KORRIBAN", "Esstran Unknown Corridor", False, 6),
]

STAR_WARS_SHIP_TEMPLATES = {
    ShipClass.FIGHTER: {
        "name": "T-65 X-Wing Starfighter",
        "hull": 40.0, "shields": 30.0, "armour": 15.0, "firepower": 35.0, "speed": 85.0, "hyperdrive": 1.0, "cost": 150.0
    },
    ShipClass.INTERCEPTOR: {
        "name": "TIE Interceptor",
        "hull": 25.0, "shields": 0.0, "armour": 10.0, "firepower": 45.0, "speed": 100.0, "hyperdrive": 0.0, "cost": 90.0
    },
    ShipClass.BOMBER: {
        "name": "B-Wing Heavy Bomber",
        "hull": 60.0, "shields": 45.0, "armour": 30.0, "firepower": 70.0, "speed": 55.0, "hyperdrive": 2.0, "cost": 220.0
    },
    ShipClass.CORVETTE: {
        "name": "CR90 Corellian Corvette",
        "hull": 250.0, "shields": 180.0, "armour": 80.0, "firepower": 110.0, "speed": 60.0, "hyperdrive": 2.0, "cost": 1200.0
    },
    ShipClass.FRIGATE: {
        "name": "Nebulon-B Escort Frigate",
        "hull": 600.0, "shields": 450.0, "armour": 200.0, "firepower": 280.0, "speed": 40.0, "hyperdrive": 2.0, "cost": 3500.0
    },
    ShipClass.DESTROYER: {
        "name": "Imperial I-Class Star Destroyer",
        "hull": 3200.0, "shields": 2400.0, "armour": 1200.0, "firepower": 1800.0, "speed": 30.0, "hyperdrive": 2.0, "cost": 28000.0
    },
    ShipClass.CRUISER: {
        "name": "MC80 Liberty Star Cruiser",
        "hull": 3500.0, "shields": 3200.0, "armour": 1000.0, "firepower": 1650.0, "speed": 32.0, "hyperdrive": 1.0, "cost": 29500.0
    },
    ShipClass.BATTLESHIP: {
        "name": "Lucrehulk Battleship",
        "hull": 8500.0, "shields": 6000.0, "armour": 2500.0, "firepower": 3200.0, "speed": 18.0, "hyperdrive": 2.0, "cost": 65000.0
    },
    ShipClass.CARRIER: {
        "name": "Venator-Class Star Destroyer",
        "hull": 2800.0, "shields": 2000.0, "armour": 900.0, "firepower": 1400.0, "speed": 35.0, "hyperdrive": 1.0, "cost": 24000.0
    },
    ShipClass.DREADNOUGHT: {
        "name": "Executor-Class Super Star Destroyer",
        "hull": 45000.0, "shields": 35000.0, "armour": 18000.0, "firepower": 24000.0, "speed": 15.0, "hyperdrive": 2.0, "cost": 450000.0
    },
    ShipClass.FREIGHTER: {
        "name": "YT-1300 Light Freighter",
        "hull": 180.0, "shields": 120.0, "armour": 60.0, "firepower": 45.0, "speed": 75.0, "hyperdrive": 0.5, "cost": 650.0
    },
    ShipClass.COLONY_SHIP: {
        "name": "Modular Ark Colony Vessel",
        "hull": 500.0, "shields": 300.0, "armour": 100.0, "firepower": 20.0, "speed": 25.0, "hyperdrive": 3.0, "cost": 8500.0
    },
    ShipClass.SCIENCE_SHIP: {
        "name": "Surveyor Exploratory Vessel",
        "hull": 200.0, "shields": 180.0, "armour": 50.0, "firepower": 15.0, "speed": 55.0, "hyperdrive": 1.0, "cost": 1800.0
    }
}

STAR_WARS_CHARACTERS_DATA = [
    {
        "id": "TARKIN",
        "name": "Grand Moff Wilhuff Tarkin",
        "species": "Human",
        "age": 64,
        "faction": "GALACTIC_EMPIRE",
        "occupation": CharacterType.LEADER,
        "location": "CORUSCANT",
        "traits": ["RUTHLESS", "TACTICIAN", "DOCTRINE_OF_FEAR"],
        "loyalty": 99.0,
        "force_sensitive": False
    },
    {
        "id": "THRAWN",
        "name": "Grand Admiral Thrawn",
        "species": "Chiss",
        "age": 52,
        "faction": "GALACTIC_EMPIRE",
        "occupation": CharacterType.ADMIRAL,
        "location": "KUAT",
        "traits": ["GENIUS_TACTICIAN", "ART_ANALYST", "CALM_LOGISTICIAN"],
        "loyalty": 92.0,
        "force_sensitive": False
    },
    {
        "id": "MON_MOTHMA",
        "name": "Chancellor Mon Mothma",
        "species": "Human",
        "age": 48,
        "faction": "REBEL_ALLIANCE",
        "occupation": CharacterType.LEADER,
        "location": "CHANDRILA",
        "traits": ["DIPLOMAT", "INSPIRING", "REPUBLICAN_IDEALIST"],
        "loyalty": 100.0,
        "force_sensitive": False
    },
    {
        "id": "ACKBAR",
        "name": "Admiral Gial Ackbar",
        "species": "Mon Calamari",
        "age": 58,
        "faction": "REBEL_ALLIANCE",
        "occupation": CharacterType.ADMIRAL,
        "location": "MON_CALA",
        "traits": ["FLEET_DEFENDER", "TRAP_DETECTION", "STEADFAST"],
        "loyalty": 96.0,
        "force_sensitive": False
    },
    {
        "id": "JABBA",
        "name": "Jabba Desilijic Tiure",
        "species": "Hutt",
        "age": 600,
        "faction": "HUTT_CARTEL",
        "occupation": CharacterType.LEADER,
        "location": "TATOOINE",
        "traits": ["CORRUPT_MAGNATE", "EXTORTIONIST", "PIRATE_KING"],
        "loyalty": 85.0,
        "force_sensitive": False
    },
    {
        "id": "BOBA_FETT",
        "name": "Boba Fett",
        "species": "Human Clone",
        "age": 36,
        "faction": "HUTT_CARTEL",
        "occupation": CharacterType.BOUNTY_HUNTER,
        "location": "TATOOINE",
        "traits": ["DEADLY_ACCURACY", "UNYIELDING", "MANDALORIAN_ARMOR"],
        "loyalty": 75.0,
        "force_sensitive": False
    },
    {
        "id": "VADER",
        "name": "Lord Darth Vader",
        "species": "Human Cyborg",
        "age": 45,
        "faction": "GALACTIC_EMPIRE",
        "occupation": CharacterType.FORCE_USER,
        "location": "MUSTAFAR",
        "traits": ["TERRIFYING_PRESENCE", "FIGHTER_ACE", "SITH_LORD"],
        "loyalty": 80.0,
        "force_sensitive": True,
        "force_score": 98.0,
        "alignment": ForceAlignment.DARK,
        "order": "SITH_ORDER"
    },
    {
        "id": "LUKE_SKYWALKER",
        "name": "Luke Skywalker",
        "species": "Human",
        "age": 22,
        "faction": "REBEL_ALLIANCE",
        "occupation": CharacterType.FORCE_USER,
        "location": "TATOOINE",
        "traits": ["CHOSEN_SON", "HEROIC", "JEDI_KNIGHT"],
        "loyalty": 98.0,
        "force_sensitive": True,
        "force_score": 96.0,
        "alignment": ForceAlignment.LIGHT,
        "order": "JEDI_ORDER"
    }
]

STAR_WARS_TECH_TREE = [
    {
        "tech_id": "HYPERDRIVE_CLASS_1",
        "name": "Class 1.0 Hyperdrive Navicomputers",
        "branch": "HYPERDRIVES",
        "tier": 1,
        "cost": 1000.0,
        "description": "Cuts hyperspace travel times across all naval craft by 25%."
    },
    {
        "tech_id": "TURBOLASER_OVERCHARGE",
        "name": "Heavy Kyber Turbolasers",
        "branch": "WEAPONS",
        "tier": 2,
        "cost": 2500.0,
        "description": "Increases capital ship firepower rating by 35%."
    },
    {
        "tech_id": "DEFLECTOR_REINFORCEMENT",
        "name": "Dual-Layer Deflector Array",
        "branch": "SHIELDS",
        "tier": 2,
        "cost": 2200.0,
        "description": "Provides +40% shield capacity and 50% faster shield recharge."
    },
    {
        "tech_id": "BESKAR_PLATING",
        "name": "Beskar Alloy Lamination",
        "branch": "ARMOUR",
        "tier": 3,
        "cost": 4000.0,
        "description": "Halves critical damage intake from kinetic and ion munitions."
    },
    {
        "tech_id": "DROID_LOGISTICS_NETWORK",
        "name": "Automated Droid Logistic Corridors",
        "branch": "DROIDS",
        "tier": 1,
        "cost": 1200.0,
        "description": "Boosts planetary manufacturing and trade throughput by 20%."
    },
    {
        "tech_id": "INTERDICTOR_GRAVITY_WELLS",
        "name": "Gravity Well Projector Cores",
        "branch": "HYPERDRIVES",
        "tier": 4,
        "cost": 8000.0,
        "description": "Enables creation of Interdictor cruisers to pull enemy fleets from hyperspace."
    },
    {
        "tech_id": "HOLONET_CIPHER_BREAKING",
        "name": "Shadow HoloNet Signal Interceptors",
        "branch": "ESPIONAGE",
        "tier": 2,
        "cost": 3000.0,
        "description": "Unveils enemy fleet deployments and gives 40% espionage success boost."
    },
    {
        "tech_id": "PLANETARY_SHIELD_GENERATOR",
        "name": "Theater Planetary Shield Emitters",
        "branch": "PLANETARY_ENGINEERING",
        "tier": 3,
        "cost": 6500.0,
        "description": "Protects planetary surface from orbital bombardment."
    }
]
