"""
GALAXIS CORE ENGINE: Authoritative Data Models
Defines complete state representations for all galactic entities.
"""

from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
import uuid
import json

from galaxis.engine.types import (
    GalacticRegion, PlanetType, CityType, GovernmentType, FactionArchetype,
    Commodity, ShipClass, FleetMission, ExplorationState, ResistanceStage,
    CharacterType, ForceAlignment, WarGoal, TreatyType, AIPersonality, GalacticEra
)

@dataclass
class ModularComponent:
    slot: str  # hull, armour, shields, engines, hyperdrive, weapons, sensors, power, life_support, cargo, fighter_capacity, computer
    name: str
    tech_level: int = 1
    power_draw: float = 10.0
    mass: float = 20.0
    stats: Dict[str, float] = field(default_factory=dict)

@dataclass
class ShipState:
    ship_id: str
    name: str
    ship_class: ShipClass
    owner_faction: str
    hull_max: float = 100.0
    hull_current: float = 100.0
    shields_max: float = 50.0
    shields_current: float = 50.0
    armour: float = 20.0
    firepower: float = 30.0
    hyperdrive_rating: float = 1.0  # Lower is faster (Class 1 vs Class 2)
    speed: float = 40.0
    manoeuvrability: float = 30.0
    sensor_range: float = 50.0
    cargo_capacity: float = 100.0
    cargo: Dict[str, float] = field(default_factory=dict)
    fighter_capacity: int = 0
    fighters: List[str] = field(default_factory=list)
    components: Dict[str, ModularComponent] = field(default_factory=dict)
    experience: float = 0.0

@dataclass
class FleetState:
    fleet_id: str
    name: str
    owner_faction: str
    commander_id: Optional[str] = None
    location_system_id: str = ""
    destination_system_id: Optional[str] = None
    hyperspace_eta_ticks: int = 0
    mission: FleetMission = FleetMission.IDLE
    target_id: Optional[str] = None
    ships: List[ShipState] = field(default_factory=list)
    fuel: float = 100.0
    max_fuel: float = 100.0
    supplies: float = 100.0
    morale: float = 100.0
    readiness: float = 100.0
    in_hyperspace: bool = False
    blockading_planet_id: Optional[str] = None

    @property
    def total_firepower(self) -> float:
        return sum(s.firepower for s in self.ships)

    @property
    def total_hull(self) -> float:
        return sum(s.hull_current for s in self.ships)

    @property
    def ship_count(self) -> int:
        return len(self.ships)

@dataclass
class SpaceportState:
    capacity: int = 10
    shipyard_capacity: int = 2
    trade_capacity: float = 500.0
    traffic: float = 0.0
    fuel_stockpile: float = 1000.0
    repair_rate: float = 25.0
    security_level: float = 0.8
    customs_efficiency: float = 0.7
    defence_rating: float = 50.0

@dataclass
class CityState:
    city_id: str
    name: str
    city_type: CityType
    population: int
    districts: int = 5
    industry_rating: float = 20.0
    housing_capacity: int = 1000000
    commerce_rating: float = 20.0
    spaceport_level: int = 1
    military_garrison: int = 1000
    crime_rate: float = 0.1
    culture_rating: float = 15.0

@dataclass
class PopulationGroup:
    group_id: str
    species: str
    culture: str
    count: int
    employment: float = 0.9
    wealth: float = 50.0
    health: float = 90.0
    education: float = 70.0
    loyalty: float = 80.0
    political_alignment: str = "CENTRISM"
    migration_rate: float = 0.0

@dataclass
class GroundUnit:
    unit_id: str
    name: str
    unit_type: str  # INFANTRY, ARMOUR, ARTILLERY, SPECIAL_FORCES, DROID_UNITS
    owner_faction: str
    strength: float = 100.0
    combat_power: float = 25.0
    experience: float = 0.0

@dataclass
class PlanetState:
    planet_id: str
    system_id: str
    name: str
    planet_type: PlanetType
    development_tier: str = "COLONY"  # OUTPOST, COLONY, SETTLEMENT, CITY, INDUSTRIAL_WORLD, CORE_WORLD
    population: int = 1000000
    habitability: float = 0.8
    climate: str = "TEMPERATE"
    resources: Dict[str, float] = field(default_factory=dict)
    government: GovernmentType = GovernmentType.LOCAL_GOVERNMENT
    owner_faction: str = "NEUTRAL"
    culture: str = "GALACTIC_STANDARD"
    primary_species: str = "HUMAN"
    industry: float = 50.0
    agriculture: float = 50.0
    mining: float = 50.0
    research: float = 20.0
    trade: float = 30.0
    spaceport: SpaceportState = field(default_factory=SpaceportState)
    cities: List[CityState] = field(default_factory=list)
    populations: List[PopulationGroup] = field(default_factory=list)
    ground_forces: List[GroundUnit] = field(default_factory=list)
    defence_shield: float = 0.0
    orbital_defence: float = 0.0
    fortification: float = 20.0
    stability: float = 85.0
    loyalty: float = 80.0
    crime: float = 15.0
    resistance_stage: ResistanceStage = ResistanceStage.CONTENT
    resistance_points: float = 0.0
    infrastructure: float = 50.0
    wealth: float = 1000.0
    strategic_value: float = 50.0
    is_blockaded: bool = False
    commodity_stockpiles: Dict[str, float] = field(default_factory=dict)
    commodity_prices: Dict[str, float] = field(default_factory=dict)

@dataclass
class HyperspaceRoute:
    route_id: str
    name: str
    origin_system_id: str
    destination_system_id: str
    distance: float
    travel_time_base: int  # in ticks
    stability: float = 0.95  # 0.0 - 1.0
    capacity: float = 1000.0
    security: float = 0.8
    is_major_lane: bool = False
    strategic_value: float = 50.0

@dataclass
class StarSystem:
    system_id: str
    name: str
    region: GalacticRegion
    coord_x: float
    coord_y: float
    coord_z: float = 0.0
    star_type: str = "G_TYPE_YELLOW"
    planets: List[PlanetState] = field(default_factory=list)
    hyperlanes: List[str] = field(default_factory=list)  # connected system_ids
    controlling_faction: str = "NEUTRAL"
    exploration_state: Dict[str, ExplorationState] = field(default_factory=dict)  # faction_id -> ExplorationState
    is_hyperspace_junction: bool = False
    pirate_activity: float = 0.0
    market_hub: bool = False

@dataclass
class TradeRoute:
    route_id: str
    owner_faction: str
    origin_system_id: str
    destination_system_id: str
    commodity: Commodity
    volume: float
    profit_per_tick: float
    travel_time: int
    risk: float = 0.1
    security: float = 0.8
    assigned_freighters: int = 2
    is_smuggling: bool = False
    is_disrupted: bool = False

@dataclass
class ForceProfile:
    is_sensitive: bool = False
    sensitivity_score: float = 0.0  # 0.0 - 100.0 (Midichlorian metric abstraction)
    training_level: float = 0.0
    discipline: float = 50.0
    alignment: ForceAlignment = ForceAlignment.BALANCED
    dark_side_corruption: float = 0.0
    knowledge: float = 10.0
    mastery: float = 0.0
    order_affiliation: Optional[str] = None
    abilities: List[str] = field(default_factory=list)

@dataclass
class CharacterState:
    character_id: str
    name: str
    species: str
    age: int
    location_system_id: str
    faction: str
    occupation: CharacterType
    traits: List[str] = field(default_factory=list)
    skills: Dict[str, float] = field(default_factory=dict)
    relationships: Dict[str, float] = field(default_factory=dict)  # character_id -> -100 to 100
    loyalty: float = 85.0
    reputation: float = 50.0
    experience: float = 0.0
    status: str = "ACTIVE"
    force: ForceProfile = field(default_factory=ForceProfile)

@dataclass
class ForceOrderState:
    order_id: str
    name: str
    philosophy: str  # JEDI_ORDER, SITH_ORDER, FORCE_CULT, INDEPENDENT
    grandmaster_id: Optional[str] = None
    temple_system_ids: List[str] = field(default_factory=list)
    members: List[str] = field(default_factory=list)
    holocrons: int = 1
    influence: float = 50.0

@dataclass
class BountyContract:
    bounty_id: str
    target_character_id: str
    issuer_faction: str
    reward_credits: float
    location_system_id: str
    difficulty: str  # LOW, MEDIUM, HIGH, DEADLY
    assigned_hunter_id: Optional[str] = None
    is_completed: bool = False

@dataclass
class WarState:
    war_id: str
    name: str
    belligerents_a: List[str]
    belligerents_b: List[str]
    war_goal: WarGoal
    start_tick: int
    battles_count: int = 0
    occupied_planet_ids: List[str] = field(default_factory=list)
    casualties_a: int = 0
    casualties_b: int = 0
    economic_damage_a: float = 0.0
    economic_damage_b: float = 0.0
    war_exhaustion_a: float = 0.0
    war_exhaustion_b: float = 0.0
    is_active: bool = True

@dataclass
class SenateBill:
    bill_id: str
    title: str
    description: str
    sponsor_faction: str
    effect_type: str
    effect_payload: Dict[str, Any]
    votes_for: int = 0
    votes_against: int = 0
    status: str = "ACTIVE"  # ACTIVE, PASSED, REJECTED
    turn_remaining: int = 3

@dataclass
class TechnologyNode:
    tech_id: str
    name: str
    branch: str  # HYPERDRIVES, POWER, SHIELDS, WEAPONS, ARMOUR, DROIDS, AI, MEDICINE, INDUSTRY, SHIPBUILDING, PLANETARY_ENGINEERING, COMPUTING, COMMUNICATIONS, FLEET_DOCTRINE, GROUND_WARFARE, ESPIONAGE
    tier: int
    cost_research_points: float
    prerequisites: List[str] = field(default_factory=list)
    modifiers: Dict[str, float] = field(default_factory=dict)
    description: str = ""

@dataclass
class HistoricalRecord:
    event_id: str
    tick: int
    title: str
    category: str
    description: str
    system_id: Optional[str] = None
    involved_factions: List[str] = field(default_factory=list)
    impact_metrics: Dict[str, Any] = field(default_factory=dict)

@dataclass
class NewsEvent:
    news_id: str
    tick: int
    headline: str
    body: str
    source_outlet: str
    is_galactic_alert: bool = False

@dataclass
class FactionState:
    faction_id: str
    name: str
    archetype: FactionArchetype
    personality: AIPersonality
    government: GovernmentType
    color_hex: str
    credits: float = 50000.0
    capital_system_id: str = ""
    is_player: bool = False
    controlled_system_ids: List[str] = field(default_factory=list)
    known_technologies: List[str] = field(default_factory=list)
    current_research_tech_id: Optional[str] = None
    research_progress: float = 0.0
    diplomatic_relations: Dict[str, float] = field(default_factory=dict)  # faction_id -> -100 to 100
    treaties: List[str] = field(default_factory=list)
    military_doctrine: str = "BALANCED"
    economic_model: str = "MIXED"
    power_score: float = 100.0
    senate_delegates: int = 1

@dataclass
class GalaxyState:
    galaxy_seed: int
    era: GalacticEra
    calendar_tick: int = 0
    systems: Dict[str, StarSystem] = field(default_factory=dict)
    hyperlanes: Dict[str, HyperspaceRoute] = field(default_factory=dict)
    factions: Dict[str, FactionState] = field(default_factory=dict)
    fleets: Dict[str, FleetState] = field(default_factory=dict)
    characters: Dict[str, CharacterState] = field(default_factory=dict)
    force_orders: Dict[str, ForceOrderState] = field(default_factory=dict)
    trade_routes: Dict[str, TradeRoute] = field(default_factory=dict)
    bounties: Dict[str, BountyContract] = field(default_factory=dict)
    wars: Dict[str, WarState] = field(default_factory=dict)
    senate_bills: List[SenateBill] = field(default_factory=list)
    technologies: Dict[str, TechnologyNode] = field(default_factory=dict)
    historical_events: List[HistoricalRecord] = field(default_factory=list)
    news_feed: List[NewsEvent] = field(default_factory=list)
    rumours: List[Dict[str, Any]] = field(default_factory=list)
    simulation_speed: int = 1  # 1x, 2x, 4x, etc.
    is_paused: bool = False
