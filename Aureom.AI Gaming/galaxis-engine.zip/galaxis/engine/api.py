"""
GALAXIS PYTHON API
Standardized programmatic interface for game scripts, headless benchmarking, and external tools.
"""

import json
from typing import Dict, Any, Optional
from galaxis.engine.simulator import GalaxisEngine
from galaxis.engine.types import GalacticEra, ShipClass, FleetMission, Commodity, WarGoal, TreatyType
from galaxis.engine.models import ShipState, FleetState, WarState

_CURRENT_ENGINE: Optional[GalaxisEngine] = None

def get_engine() -> GalaxisEngine:
    global _CURRENT_ENGINE
    if _CURRENT_ENGINE is None:
        _CURRENT_ENGINE = GalaxisEngine(seed=1138, era=GalacticEra.IMPERIAL_ERA)
    return _CURRENT_ENGINE

def create_galaxy(seed: int = 1138, era: str = "IMPERIAL_ERA") -> GalaxisEngine:
    global _CURRENT_ENGINE
    era_enum = GalacticEra(era) if era in [e.value for e in GalacticEra] else GalacticEra.IMPERIAL_ERA
    _CURRENT_ENGINE = GalaxisEngine(seed=seed, era=era_enum)
    return _CURRENT_ENGINE

def simulate(ticks: int = 1) -> Dict[str, Any]:
    engine = get_engine()
    results = []
    for _ in range(ticks):
        res = engine.tick()
        results.append(res)
    return {
        "ticks_executed": ticks,
        "current_tick": engine.state.calendar_tick,
        "latest_summary": results[-1] if results else {}
    }

def move_fleet(fleet_id: str, destination_system_id: str, mission: str = "PATROL") -> Dict[str, Any]:
    engine = get_engine()
    mission_enum = FleetMission(mission) if mission in [m.value for m in FleetMission] else FleetMission.PATROL
    return engine.dispatch_fleet(fleet_id, destination_system_id, mission_enum)

def create_ship(faction_id: str, planet_id: str, ship_class: str = "CORVETTE") -> Dict[str, Any]:
    engine = get_engine()
    class_enum = ShipClass(ship_class) if ship_class in [s.value for s in ShipClass] else ShipClass.CORVETTE
    return engine.build_ship(faction_id, planet_id, class_enum)

def research(faction_id: str, tech_id: str) -> Dict[str, Any]:
    engine = get_engine()
    return engine.start_research(faction_id, tech_id)

def create_trade_route(faction_id: str, origin_sys: str, dest_sys: str, commodity: str = "FOOD") -> Dict[str, Any]:
    engine = get_engine()
    comm_enum = Commodity(commodity) if commodity in [c.value for c in Commodity] else Commodity.FOOD
    return engine.establish_trade_route(faction_id, origin_sys, dest_sys, comm_enum)

def declare_war(aggressor_faction: str, defender_faction: str, war_goal: str = "CONQUEST") -> Dict[str, Any]:
    engine = get_engine()
    war_id = f"WAR_{aggressor_faction}_{defender_faction}_{engine.state.calendar_tick}"
    goal_enum = WarGoal(war_goal) if war_goal in [w.value for w in WarGoal] else WarGoal.CONQUEST
    war = WarState(
        war_id=war_id,
        name=f"War of {aggressor_faction} Aggression",
        belligerents_a=[aggressor_faction],
        belligerents_b=[defender_faction],
        war_goal=goal_enum,
        start_tick=engine.state.calendar_tick
    )
    engine.state.wars[war_id] = war
    return {"success": True, "war_id": war_id, "name": war.name}

def inspect_galaxy() -> Dict[str, Any]:
    engine = get_engine()
    s = engine.state
    return {
        "seed": s.galaxy_seed,
        "era": s.era.value,
        "tick": s.calendar_tick,
        "systems_count": len(s.systems),
        "factions_count": len(s.factions),
        "fleets_count": len(s.fleets),
        "technologies_count": len(s.technologies),
        "trade_routes_count": len(s.trade_routes),
        "wars_count": len(s.wars)
    }
