"""
GALAXIS CORE ENGINE: Simulation Clock, Seeded RNG, Event Bus & Invariant Validation
"""

import random
from typing import Dict, List, Callable, Any, Optional
from galaxis.engine.models import GalaxyState, NewsEvent, HistoricalRecord

class SeededRNG:
    def __init__(self, seed: int):
        self.seed = seed
        self.rng = random.Random(seed)

    def random(self) -> float:
        return self.rng.random()

    def uniform(self, a: float, b: float) -> float:
        return self.rng.uniform(a, b)

    def randint(self, a: int, b: int) -> int:
        return self.rng.randint(a, b)

    def choice(self, seq: list) -> Any:
        if not seq:
            return None
        return self.rng.choice(seq)

    def sample(self, seq: list, k: int) -> list:
        if not seq:
            return []
        k = min(k, len(seq))
        return self.rng.sample(seq, k)

class EventBus:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}

    def subscribe(self, event_type: str, handler: Callable[[Dict[str, Any]], None]):
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(handler)

    def publish(self, event_type: str, data: Dict[str, Any]):
        if event_type in self._subscribers:
            for handler in self._subscribers[event_type]:
                try:
                    handler(data)
                except Exception as e:
                    print(f"[EventBus] Error in handler for {event_type}: {e}")

def validate_state_invariants(state: GalaxyState) -> List[str]:
    """
    Enforces engine invariants:
    - population >= 0
    - resources >= 0
    - ships have valid owners
    - fleets occupy valid systems
    - planets belong to valid systems
    - hyperlanes connect valid systems
    """
    violations = []

    # Check systems and hyperlanes
    for route_id, route in state.hyperlanes.items():
        if route.origin_system_id not in state.systems:
            violations.append(f"Hyperlane {route_id} origin {route.origin_system_id} not in systems")
        if route.destination_system_id not in state.systems:
            violations.append(f"Hyperlane {route_id} destination {route.destination_system_id} not in systems")

    # Check planets
    for sys_id, system in state.systems.items():
        for planet in system.planets:
            if planet.population < 0:
                violations.append(f"Planet {planet.name} has negative population {planet.population}")
            for res, amount in planet.resources.items():
                if amount < 0:
                    violations.append(f"Planet {planet.name} has negative resource {res}: {amount}")
            for stock, amt in planet.commodity_stockpiles.items():
                if amt < 0:
                    violations.append(f"Planet {planet.name} has negative stockpile {stock}: {amt}")

    # Check fleets
    for fleet_id, fleet in state.fleets.items():
        if fleet.owner_faction not in state.factions and fleet.owner_faction != "NEUTRAL":
            violations.append(f"Fleet {fleet_id} owner {fleet.owner_faction} does not exist")
        if fleet.location_system_id and fleet.location_system_id not in state.systems:
            violations.append(f"Fleet {fleet_id} location {fleet.location_system_id} does not exist")

    return violations
