"""
GALAXIS SIMULATION ENGINE
Comprehensive authoritative galactic strategy engine.
"""

import math
import uuid
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import asdict

from galaxis.engine.types import (
    GalacticRegion, PlanetType, CityType, GovernmentType, FactionArchetype,
    Commodity, ShipClass, FleetMission, ExplorationState, ResistanceStage,
    CharacterType, ForceAlignment, WarGoal, TreatyType, AIPersonality, GalacticEra
)
from galaxis.engine.models import (
    GalaxyState, StarSystem, PlanetState, CityState, SpaceportState,
    PopulationGroup, GroundUnit, ShipState, FleetState, HyperspaceRoute,
    TradeRoute, CharacterState, ForceProfile, ForceOrderState, BountyContract,
    WarState, SenateBill, TechnologyNode, HistoricalRecord, NewsEvent, FactionState
)
from galaxis.engine.core import SeededRNG, EventBus, validate_state_invariants
from galaxis.content.star_wars.catalog import (
    STAR_WARS_REGIONS_CONFIG, STAR_WARS_FACTIONS_DATA, STAR_WARS_SYSTEMS_DATA,
    STAR_WARS_HYPERLANES_DATA, STAR_WARS_SHIP_TEMPLATES, STAR_WARS_CHARACTERS_DATA,
    STAR_WARS_TECH_TREE
)

class GalaxisEngine:
    def __init__(self, seed: int = 1138, era: GalacticEra = GalacticEra.IMPERIAL_ERA):
        self.rng = SeededRNG(seed)
        self.event_bus = EventBus()
        self.state = self._initialize_galaxy(seed, era)

    def _initialize_galaxy(self, seed: int, era: GalacticEra) -> GalaxyState:
        state = GalaxyState(
            galaxy_seed=seed,
            era=era,
            calendar_tick=0,
        )

        # 1. Technologies
        for t in STAR_WARS_TECH_TREE:
            node = TechnologyNode(
                tech_id=t["tech_id"],
                name=t["name"],
                branch=t["branch"],
                tier=t["tier"],
                cost_research_points=t["cost"],
                description=t["description"]
            )
            state.technologies[node.tech_id] = node

        # 2. Factions
        for f in STAR_WARS_FACTIONS_DATA:
            faction = FactionState(
                faction_id=f["faction_id"],
                name=f["name"],
                archetype=f["archetype"],
                personality=f["personality"],
                government=f["government"],
                color_hex=f["color_hex"],
                credits=f["credits"],
                capital_system_id=f["capital_system"],
                military_doctrine=f["military_doctrine"],
                senate_delegates=f["senate_delegates"]
            )
            state.factions[faction.faction_id] = faction

        # 3. Systems and Planets
        for sys_data in STAR_WARS_SYSTEMS_DATA:
            planets_list = []
            for p in sys_data["planets"]:
                # Stockpiles & Base Prices
                stockpiles = {c.value: 100.0 for c in Commodity}
                prices = {c.value: 50.0 for c in Commodity}

                # Specialized commodity adjustments based on planet type
                if p["type"] == PlanetType.AGRICULTURAL:
                    stockpiles[Commodity.FOOD.value] = 500.0
                    prices[Commodity.FOOD.value] = 20.0
                elif p["type"] == PlanetType.MINING or p["type"] == PlanetType.VOLCANIC:
                    stockpiles[Commodity.METALS.value] = 600.0
                    stockpiles[Commodity.RARE_METALS.value] = 300.0
                    prices[Commodity.METALS.value] = 18.0
                elif p["type"] == PlanetType.INDUSTRIAL:
                    stockpiles[Commodity.SHIP_COMPONENTS.value] = 400.0
                    stockpiles[Commodity.DROID_COMPONENTS.value] = 400.0
                    stockpiles[Commodity.WEAPONS.value] = 300.0
                    prices[Commodity.SHIP_COMPONENTS.value] = 45.0
                elif p["type"] == PlanetType.GAS_GIANT:
                    stockpiles[Commodity.FUEL.value] = 800.0
                    prices[Commodity.FUEL.value] = 15.0

                cities = [
                    CityState(
                        city_id=f"CITY_{p['planet_id']}_1",
                        name=f"{p['name']} Prime District",
                        city_type=CityType.CAPITAL,
                        population=int(p["population"] * 0.4),
                        industry_rating=p["industry"],
                        commerce_rating=p.get("trade", 40.0)
                    )
                ]

                pop_groups = [
                    PopulationGroup(
                        group_id=f"POP_{p['planet_id']}_1",
                        species="Human" if p["planet_id"] != "MON_CALA_PRIME" else "Mon Calamari",
                        culture="Core Standard" if sys_data["region"] == GalacticRegion.CORE else "Outer Rim Frontier",
                        count=int(p["population"]),
                        loyalty=p.get("loyalty", 75.0)
                    )
                ]

                planet = PlanetState(
                    planet_id=p["planet_id"],
                    system_id=sys_data["system_id"],
                    name=p["name"],
                    planet_type=p["type"],
                    development_tier=p["tier"],
                    population=p["population"],
                    habitability=p["habitability"],
                    climate=p["climate"],
                    government=p["government"],
                    owner_faction=sys_data["controller"],
                    wealth=p["wealth"],
                    industry=p["industry"],
                    agriculture=p["agriculture"],
                    mining=p["mining"],
                    research=p["research"],
                    trade=p.get("trade", 40.0),
                    spaceport=SpaceportState(
                        capacity=p.get("spaceport_cap", 15),
                        shipyard_capacity=p.get("shipyard_cap", 2)
                    ),
                    cities=cities,
                    populations=pop_groups,
                    stability=p.get("stability", 80.0),
                    loyalty=p.get("loyalty", 75.0),
                    crime=p.get("crime", 20.0),
                    resistance_points=p.get("resistance_points", 0.0),
                    commodity_stockpiles=stockpiles,
                    commodity_prices=prices
                )
                planets_list.append(planet)

            star_system = StarSystem(
                system_id=sys_data["system_id"],
                name=sys_data["name"],
                region=sys_data["region"],
                coord_x=sys_data["x"],
                coord_y=sys_data["y"],
                planets=planets_list,
                controlling_faction=sys_data["controller"],
                is_hyperspace_junction=sys_data.get("is_junction", False),
                market_hub=sys_data.get("market_hub", False),
                exploration_state={f.faction_id: ExplorationState.MAPPED for f in state.factions.values()}
            )
            state.systems[star_system.system_id] = star_system

            # Assign controlled system to faction
            if sys_data["controller"] in state.factions:
                state.factions[sys_data["controller"]].controlled_system_ids.append(star_system.system_id)

        # 4. Hyperlanes
        for idx, (orig, dest, name, is_major, base_ticks) in enumerate(STAR_WARS_HYPERLANES_DATA):
            if orig in state.systems and dest in state.systems:
                dist = math.hypot(
                    state.systems[orig].coord_x - state.systems[dest].coord_x,
                    state.systems[orig].coord_y - state.systems[dest].coord_y
                )
                route = HyperspaceRoute(
                    route_id=f"HYPERLANE_{idx+1}",
                    name=name,
                    origin_system_id=orig,
                    destination_system_id=dest,
                    distance=dist,
                    travel_time_base=base_ticks,
                    is_major_lane=is_major,
                    stability=0.98 if is_major else 0.88,
                    strategic_value=90.0 if is_major else 40.0
                )
                state.hyperlanes[route.route_id] = route
                state.systems[orig].hyperlanes.append(dest)
                state.systems[dest].hyperlanes.append(orig)

        # 5. Characters & Force Orders
        jedi_order = ForceOrderState(
            order_id="JEDI_ORDER",
            name="The Jedi Order",
            philosophy="JEDI_ORDER",
            temple_system_ids=["CORUSCANT", "CHANDRILA"],
            influence=75.0
        )
        sith_order = ForceOrderState(
            order_id="SITH_ORDER",
            name="The Sith Order",
            philosophy="SITH_ORDER",
            temple_system_ids=["KORRIBAN", "MUSTAFAR"],
            influence=85.0
        )
        state.force_orders["JEDI_ORDER"] = jedi_order
        state.force_orders["SITH_ORDER"] = sith_order

        for c_data in STAR_WARS_CHARACTERS_DATA:
            force_prof = ForceProfile(
                is_sensitive=c_data.get("force_sensitive", False),
                sensitivity_score=c_data.get("force_score", 0.0),
                training_level=80.0 if c_data.get("force_sensitive") else 0.0,
                alignment=c_data.get("alignment", ForceAlignment.BALANCED),
                order_affiliation=c_data.get("order")
            )
            char = CharacterState(
                character_id=c_data["id"],
                name=c_data["name"],
                species=c_data["species"],
                age=c_data["age"],
                location_system_id=c_data["location"],
                faction=c_data["faction"],
                occupation=c_data["occupation"],
                traits=c_data.get("traits", []),
                loyalty=c_data.get("loyalty", 80.0),
                force=force_prof
            )
            state.characters[char.character_id] = char

        # 6. Initial Fleets
        self._spawn_initial_fleets(state)

        # 7. Initial Trade Routes
        state.trade_routes["TR_1"] = TradeRoute(
            route_id="TR_1",
            owner_faction="CORPORATE_SECTOR",
            origin_system_id="FONDO",
            destination_system_id="CORUSCANT",
            commodity=Commodity.SHIP_COMPONENTS,
            volume=50.0,
            profit_per_tick=450.0,
            travel_time=2
        )
        state.trade_routes["TR_2"] = TradeRoute(
            route_id="TR_2",
            owner_faction="GALACTIC_EMPIRE",
            origin_system_id="KUAT",
            destination_system_id="ERIADU",
            commodity=Commodity.WEAPONS,
            volume=40.0,
            profit_per_tick=380.0,
            travel_time=3
        )

        # 8. Initial Historical Log & News
        state.historical_events.append(
            HistoricalRecord(
                event_id="HIST_0",
                tick=0,
                title="Galactic Stasis Established",
                category="ERA_START",
                description=f"Galaxy initialized under {era.value}. Imperial armada dominates core hyperspace junctions while rebellion smolders in the Outer Rim."
            )
        )
        state.news_feed.append(
            NewsEvent(
                news_id="NEWS_0",
                tick=0,
                headline="Imperial Security Bureau Heightens Hyperlane Checkpoints",
                body="Grand Moff Tarkin has mandated Level-1 clearance across the Perlemian and Corellian trade corridors.",
                source_outlet="Coruscant HoloNet Central",
                is_galactic_alert=False
            )
        )

        # 9. Senate Bills
        state.senate_bills.append(
            SenateBill(
                bill_id="BILL_101",
                title="Hydian Way Anti-Piracy Patrol Mandate",
                description="Levy a 2% trade tariff to fund unified security cruisers patrolling Outer Rim junctions.",
                sponsor_faction="GALACTIC_EMPIRE",
                effect_type="SECURITY_SUBSIDY",
                effect_payload={"security_boost": 0.15, "trade_tax": 0.02},
                votes_for=165,
                votes_against=70,
                status="ACTIVE",
                turn_remaining=2
            )
        )

        return state

    def _spawn_initial_fleets(self, state: GalaxyState):
        # Imperial Sector Fleet
        imp_ships = [
            ShipState(
                ship_id=f"SHIP_ISD_{i}",
                name=f"ISD Devastator {i+1}",
                ship_class=ShipClass.DESTROYER,
                owner_faction="GALACTIC_EMPIRE",
                hull_max=3200.0, hull_current=3200.0,
                shields_max=2400.0, shields_current=2400.0,
                armour=1200.0, firepower=1800.0
            ) for i in range(3)
        ] + [
            ShipState(
                ship_id=f"SHIP_CR90_{i}",
                name=f"Imperial Patrol Corvette {i+1}",
                ship_class=ShipClass.CORVETTE,
                owner_faction="GALACTIC_EMPIRE",
                hull_max=250.0, hull_current=250.0,
                shields_max=180.0, shields_current=180.0,
                armour=80.0, firepower=110.0
            ) for i in range(4)
        ]
        state.fleets["FLEET_IMP_1"] = FleetState(
            fleet_id="FLEET_IMP_1",
            name="Imperial 1st Sector Fleet",
            owner_faction="GALACTIC_EMPIRE",
            commander_id="TARKIN",
            location_system_id="CORUSCANT",
            mission=FleetMission.PATROL,
            ships=imp_ships
        )

        # Rebel Alliance Fleet
        reb_ships = [
            ShipState(
                ship_id=f"SHIP_MC80_{i}",
                name=f"Home One Class Cruiser {i+1}",
                ship_class=ShipClass.CRUISER,
                owner_faction="REBEL_ALLIANCE",
                hull_max=3500.0, hull_current=3500.0,
                shields_max=3200.0, shields_current=3200.0,
                armour=1000.0, firepower=1650.0
            ) for i in range(2)
        ] + [
            ShipState(
                ship_id=f"SHIP_NEB_{i}",
                name=f"Redemption Frigate {i+1}",
                ship_class=ShipClass.FRIGATE,
                owner_faction="REBEL_ALLIANCE",
                hull_max=600.0, hull_current=600.0,
                shields_max=450.0, shields_current=450.0,
                armour=200.0, firepower=280.0
            ) for i in range(3)
        ]
        state.fleets["FLEET_REB_1"] = FleetState(
            fleet_id="FLEET_REB_1",
            name="Alliance Vanguard Taskforce",
            owner_faction="REBEL_ALLIANCE",
            commander_id="ACKBAR",
            location_system_id="MON_CALA",
            mission=FleetMission.PATROL,
            ships=reb_ships
        )

        # Hutt Syndicate Raider Fleet
        hutt_ships = [
            ShipState(
                ship_id=f"SHIP_HUTT_{i}",
                name=f"Dune Raider Skiff {i+1}",
                ship_class=ShipClass.CORVETTE,
                owner_faction="HUTT_CARTEL",
                hull_max=220.0, hull_current=220.0,
                shields_max=120.0, shields_current=120.0,
                armour=70.0, firepower=100.0
            ) for i in range(3)
        ]
        state.fleets["FLEET_HUTT_1"] = FleetState(
            fleet_id="FLEET_HUTT_1",
            name="Cartel Enforcement Armada",
            owner_faction="HUTT_CARTEL",
            commander_id="JABBA",
            location_system_id="TATOOINE",
            mission=FleetMission.RAID,
            ships=hutt_ships
        )

    # -------------------------------------------------------------
    # SIMULATION TICK
    # -------------------------------------------------------------
    def tick(self) -> Dict[str, Any]:
        """
        Advances the galaxy simulation by 1 tick.
        Resolves economy, trade, movement, combat, research, AI, politics, and events.
        """
        self.state.calendar_tick += 1
        tick_summary = {
            "tick": self.state.calendar_tick,
            "combats": [],
            "completed_missions": [],
            "rebellions": [],
            "passed_bills": [],
            "news": []
        }

        # 1. Economy & Commodity Updates
        self._update_economy()

        # 2. Research & Tech Progression
        self._update_research()

        # 3. Fleet Movement & Hyperspace Transit
        self._update_fleet_movement(tick_summary)

        # 4. Planetary Resistance & Rebellion Progression
        self._update_planetary_resistance(tick_summary)

        # 5. Galactic Senate Cycle
        self._update_senate(tick_summary)

        # 6. AI Decisions & Autonomous Expansion
        self._update_ai_factions()

        # 7. Stochastic Events
        self._check_stochastic_events(tick_summary)

        return tick_summary

    def _update_economy(self):
        for sys_id, system in self.state.systems.items():
            for planet in system.planets:
                # Planetary production
                fuel_prod = planet.mining * 0.1 if planet.planet_type == PlanetType.GAS_GIANT else 0.0
                metals_prod = planet.mining * 0.15
                food_prod = planet.agriculture * 0.2
                comp_prod = planet.industry * 0.12

                planet.commodity_stockpiles[Commodity.FUEL.value] = max(0.0, planet.commodity_stockpiles.get(Commodity.FUEL.value, 0) + fuel_prod - 2.0)
                planet.commodity_stockpiles[Commodity.METALS.value] = max(0.0, planet.commodity_stockpiles.get(Commodity.METALS.value, 0) + metals_prod - 1.5)
                planet.commodity_stockpiles[Commodity.FOOD.value] = max(0.0, planet.commodity_stockpiles.get(Commodity.FOOD.value, 0) + food_prod - (planet.population / 500000000.0))
                planet.commodity_stockpiles[Commodity.SHIP_COMPONENTS.value] = max(0.0, planet.commodity_stockpiles.get(Commodity.SHIP_COMPONENTS.value, 0) + comp_prod - 1.0)

                # Dynamic price based on supply/demand
                for comm in Commodity:
                    stock = planet.commodity_stockpiles.get(comm.value, 50.0)
                    base_price = 50.0
                    # Scarcity raises prices, abundance lowers prices
                    current_price = max(5.0, min(500.0, base_price * (150.0 / max(10.0, stock + 20.0))))
                    planet.commodity_prices[comm.value] = round(current_price, 2)

                # Tax revenue to faction
                if planet.owner_faction in self.state.factions:
                    tax = (planet.wealth * 0.005) * (planet.stability / 100.0)
                    self.state.factions[planet.owner_faction].credits += tax

        # Trade route income
        for tr_id, tr in self.state.trade_routes.items():
            if not tr.is_disrupted and tr.owner_faction in self.state.factions:
                self.state.factions[tr.owner_faction].credits += tr.profit_per_tick

    def _update_research(self):
        for f_id, faction in self.state.factions.items():
            if faction.current_research_tech_id:
                tech = self.state.technologies.get(faction.current_research_tech_id)
                if tech:
                    # Calculate research points from controlled planets
                    research_pts = sum(
                        p.research for s in self.state.systems.values()
                        if s.controlling_faction == f_id
                        for p in s.planets
                    ) * 0.2 + 5.0
                    faction.research_progress += research_pts
                    if faction.research_progress >= tech.cost_research_points:
                        faction.known_technologies.append(tech.tech_id)
                        faction.current_research_tech_id = None
                        faction.research_progress = 0.0

    def _update_fleet_movement(self, summary: Dict[str, Any]):
        for fleet_id, fleet in list(self.state.fleets.items()):
            if fleet.in_hyperspace:
                fleet.hyperspace_eta_ticks -= 1
                if fleet.hyperspace_eta_ticks <= 0:
                    fleet.in_hyperspace = False
                    fleet.location_system_id = fleet.destination_system_id or fleet.location_system_id
                    fleet.destination_system_id = None
                    dest_sys = self.state.systems.get(fleet.location_system_id)
                    dest_name = dest_sys.name if dest_sys else "Deep Space"

                    # Check for combat on arrival
                    hostile_fleets = [
                        other for other in self.state.fleets.values()
                        if other.fleet_id != fleet.fleet_id
                        and other.location_system_id == fleet.location_system_id
                        and not other.in_hyperspace
                        and self._is_hostile(fleet.owner_faction, other.owner_faction)
                    ]

                    if hostile_fleets:
                        combat_log = self._resolve_space_combat(fleet, hostile_fleets[0])
                        summary["combats"].append(combat_log)
                    else:
                        summary["completed_missions"].append({
                            "fleet_id": fleet_id,
                            "name": fleet.name,
                            "location": dest_name,
                            "event": "HYPERSPACE_EXIT"
                        })

    def _is_hostile(self, f1: str, f2: str) -> bool:
        if f1 == f2 or f1 == "NEUTRAL" or f2 == "NEUTRAL":
            return False
        # Rebellion vs Empire is naturally hostile
        if (f1 == "GALACTIC_EMPIRE" and f2 == "REBEL_ALLIANCE") or (f2 == "GALACTIC_EMPIRE" and f1 == "REBEL_ALLIANCE"):
            return True
        # Pirates hostile to everyone
        if f1 == "BLACK_SUN" or f2 == "BLACK_SUN":
            return True
        return False

    def _resolve_space_combat(self, fleet_a: FleetState, fleet_b: FleetState) -> Dict[str, Any]:
        """
        Executes Strategic Space Combat Stages:
        DETECTION -> POSITION -> INITIATIVE -> ENGAGEMENT -> DAMAGE -> RETREAT / AFTERMATH
        """
        pwr_a = fleet_a.total_firepower
        pwr_b = fleet_b.total_firepower

        # Random engagement factor
        roll_a = self.rng.uniform(0.8, 1.2) * pwr_a
        roll_b = self.rng.uniform(0.8, 1.2) * pwr_b

        dmg_to_b = roll_a * 0.15
        dmg_to_a = roll_b * 0.15

        # Apply damage
        self._apply_fleet_damage(fleet_a, dmg_to_a)
        self._apply_fleet_damage(fleet_b, dmg_to_b)

        winner = fleet_a.owner_faction if roll_a >= roll_b else fleet_b.owner_faction
        loser_fleet = fleet_b if roll_a >= roll_b else fleet_a

        combat_log = {
            "location": fleet_a.location_system_id,
            "fleet_a": fleet_a.name,
            "fleet_b": fleet_b.name,
            "damage_a": round(dmg_to_a, 1),
            "damage_b": round(dmg_to_b, 1),
            "winner": winner
        }

        # News event for major engagements
        news = NewsEvent(
            news_id=f"NEWS_COMBAT_{self.state.calendar_tick}",
            tick=self.state.calendar_tick,
            headline=f"Naval Engagement in {fleet_a.location_system_id} Sector",
            body=f"{fleet_a.name} engaged {fleet_b.name}. Forces of {winner} secured the tactical orbital lane.",
            source_outlet="Sector Tactical HoloFeed",
            is_galactic_alert=True
        )
        self.state.news_feed.insert(0, news)
        return combat_log

    def _apply_fleet_damage(self, fleet: FleetState, damage: float):
        dmg_remaining = damage
        for ship in fleet.ships:
            if dmg_remaining <= 0:
                break
            # Shield absorption
            if ship.shields_current > 0:
                absorbed = min(ship.shields_current, dmg_remaining)
                ship.shields_current -= absorbed
                dmg_remaining -= absorbed
            # Hull damage
            if dmg_remaining > 0:
                hull_dmg = min(ship.hull_current, dmg_remaining)
                ship.hull_current -= hull_dmg
                dmg_remaining -= hull_dmg

        # Clean destroyed ships
        fleet.ships = [s for s in fleet.ships if s.hull_current > 0]

    def _update_planetary_resistance(self, summary: Dict[str, Any]):
        for sys_id, system in self.state.systems.items():
            for planet in system.planets:
                # Discontent conditions
                if planet.stability < 60.0 or planet.loyalty < 50.0:
                    planet.resistance_points += self.rng.uniform(1.0, 3.0)
                else:
                    planet.resistance_points = max(0.0, planet.resistance_points - 0.5)

                # Resistance stages: CONTENT -> PROTEST -> SABOTAGE -> INSURGENCY -> REBELLION -> CIVIL_WAR -> INDEPENDENCE
                if planet.resistance_points > 100.0:
                    planet.resistance_stage = ResistanceStage.INDEPENDENCE
                    planet.owner_faction = "REBEL_ALLIANCE" if planet.owner_faction == "GALACTIC_EMPIRE" else "INDEPENDENT_WORLDS"
                    planet.resistance_points = 0.0
                    summary["rebellions"].append(f"{planet.name} declared independence!")
                elif planet.resistance_points > 70.0:
                    planet.resistance_stage = ResistanceStage.REBELLION
                elif planet.resistance_points > 45.0:
                    planet.resistance_stage = ResistanceStage.INSURGENCY
                elif planet.resistance_points > 20.0:
                    planet.resistance_stage = ResistanceStage.PROTEST
                else:
                    planet.resistance_stage = ResistanceStage.CONTENT

    def _update_senate(self, summary: Dict[str, Any]):
        for bill in list(self.state.senate_bills):
            if bill.status == "ACTIVE":
                bill.turn_remaining -= 1
                # AI Faction voting
                for f_id, faction in self.state.factions.items():
                    if f_id != bill.sponsor_faction:
                        if faction.archetype in [FactionArchetype.GALACTIC_REPUBLIC, FactionArchetype.NEW_REPUBLIC, FactionArchetype.GALACTIC_EMPIRE]:
                            bill.votes_for += int(faction.senate_delegates * 0.6)
                        else:
                            bill.votes_against += int(faction.senate_delegates * 0.4)

                if bill.turn_remaining <= 0:
                    if bill.votes_for > bill.votes_against:
                        bill.status = "PASSED"
                        summary["passed_bills"].append(bill.title)
                        news = NewsEvent(
                            news_id=f"NEWS_SENATE_{self.state.calendar_tick}",
                            tick=self.state.calendar_tick,
                            headline=f"Galactic Senate Passes: {bill.title}",
                            body=f"Resolution approved by majority vote ({bill.votes_for} vs {bill.votes_against}).",
                            source_outlet="Coruscant Senate Rotunda",
                            is_galactic_alert=False
                        )
                        self.state.news_feed.insert(0, news)
                    else:
                        bill.status = "REJECTED"

    def _update_ai_factions(self):
        for f_id, faction in self.state.factions.items():
            if faction.is_player:
                continue

            # AI decision: Research tech if none active
            if not faction.current_research_tech_id:
                available_techs = [
                    t for t in self.state.technologies.values()
                    if t.tech_id not in faction.known_technologies
                ]
                if available_techs:
                    chosen = self.rng.choice(available_techs)
                    if chosen:
                        faction.current_research_tech_id = chosen.tech_id

            # AI decision: Build ships if wealthy
            if faction.credits > 60000.0:
                controlled_planets = [
                    p for s in self.state.systems.values()
                    if s.controlling_faction == f_id
                    for p in s.planets
                    if p.spaceport.shipyard_capacity > 0
                ]
                if controlled_planets:
                    p = self.rng.choice(controlled_planets)
                    # Deduct cost & add ship
                    faction.credits -= 1200.0
                    new_ship = ShipState(
                        ship_id=f"SHIP_AI_{uuid.uuid4().hex[:6]}",
                        name=f"{faction.name} Patrol Vessel",
                        ship_class=ShipClass.CORVETTE,
                        owner_faction=f_id,
                        hull_max=250.0, hull_current=250.0,
                        shields_max=180.0, shields_current=180.0,
                        armour=80.0, firepower=110.0
                    )
                    # Assign to nearest fleet or create
                    f_fleets = [fl for fl in self.state.fleets.values() if fl.owner_faction == f_id]
                    if f_fleets:
                        f_fleets[0].ships.append(new_ship)

    def _check_stochastic_events(self, summary: Dict[str, Any]):
        if self.rng.random() < 0.08:
            # Pirate surge or hyperlane anomaly
            sys = self.rng.choice(list(self.state.systems.values()))
            if sys:
                sys.pirate_activity = min(1.0, sys.pirate_activity + 0.3)
                news = NewsEvent(
                    news_id=f"NEWS_EVENT_{self.state.calendar_tick}",
                    tick=self.state.calendar_tick,
                    headline=f"Pirate Incursions Reported in {sys.name} System",
                    body="Unregistered raiders have targeted local cargo freighters. Insurance premiums along connecting hyperspace spurs have increased.",
                    source_outlet="Outer Rim Dispatch",
                    is_galactic_alert=False
                )
                self.state.news_feed.insert(0, news)

    # -------------------------------------------------------------
    # PLAYER ACTIONS / API
    # -------------------------------------------------------------
    def dispatch_fleet(self, fleet_id: str, dest_system_id: str, mission: FleetMission) -> Dict[str, Any]:
        if fleet_id not in self.state.fleets:
            return {"success": False, "error": f"Fleet {fleet_id} not found"}
        if dest_system_id not in self.state.systems:
            return {"success": False, "error": f"System {dest_system_id} not found"}

        fleet = self.state.fleets[fleet_id]
        if fleet.in_hyperspace:
            return {"success": False, "error": "Fleet is already navigating hyperspace"}

        # Calculate travel time
        curr_sys = fleet.location_system_id
        if curr_sys == dest_system_id:
            fleet.mission = mission
            return {"success": True, "message": f"Fleet mission updated to {mission.value}"}

        # Check lane distance
        dist = math.hypot(
            self.state.systems[curr_sys].coord_x - self.state.systems[dest_system_id].coord_x,
            self.state.systems[curr_sys].coord_y - self.state.systems[dest_system_id].coord_y
        )
        travel_ticks = max(1, int(dist / 20.0))

        fleet.in_hyperspace = True
        fleet.destination_system_id = dest_system_id
        fleet.hyperspace_eta_ticks = travel_ticks
        fleet.mission = mission

        return {
            "success": True,
            "message": f"Fleet {fleet.name} entered hyperspace destined for {dest_system_id}. ETA: {travel_ticks} ticks."
        }

    def build_ship(self, faction_id: str, planet_id: str, ship_class: ShipClass) -> Dict[str, Any]:
        if faction_id not in self.state.factions:
            return {"success": False, "error": "Faction not found"}

        faction = self.state.factions[faction_id]
        template = STAR_WARS_SHIP_TEMPLATES.get(ship_class, STAR_WARS_SHIP_TEMPLATES[ShipClass.CORVETTE])
        cost = template["cost"]

        if faction.credits < cost:
            return {"success": False, "error": f"Insufficient credits (Need {cost}, have {faction.credits:.0f})"}

        faction.credits -= cost
        new_ship = ShipState(
            ship_id=f"SHIP_{uuid.uuid4().hex[:6]}",
            name=f"{template['name']} #{self.rng.randint(10, 99)}",
            ship_class=ship_class,
            owner_faction=faction_id,
            hull_max=template["hull"], hull_current=template["hull"],
            shields_max=template["shields"], shields_current=template["shields"],
            armour=template["armour"], firepower=template["firepower"],
            speed=template["speed"], hyperdrive_rating=template["hyperdrive"]
        )

        # Find or create a fleet at planet's system
        planet = None
        for s in self.state.systems.values():
            for p in s.planets:
                if p.planet_id == planet_id:
                    planet = p
                    break
            if planet:
                break

        if not planet:
            return {"success": False, "error": "Planet not found"}

        sys_id = planet.system_id
        matching_fleet = next(
            (f for f in self.state.fleets.values() if f.owner_faction == faction_id and f.location_system_id == sys_id and not f.in_hyperspace),
            None
        )

        if not matching_fleet:
            matching_fleet = FleetState(
                fleet_id=f"FLEET_{uuid.uuid4().hex[:6]}",
                name=f"{faction.name} Taskforce {len(self.state.fleets)+1}",
                owner_faction=faction_id,
                location_system_id=sys_id,
                ships=[new_ship]
            )
            self.state.fleets[matching_fleet.fleet_id] = matching_fleet
        else:
            matching_fleet.ships.append(new_ship)

        return {
            "success": True,
            "ship": new_ship.name,
            "fleet": matching_fleet.name,
            "remaining_credits": faction.credits
        }

    def start_research(self, faction_id: str, tech_id: str) -> Dict[str, Any]:
        if faction_id not in self.state.factions:
            return {"success": False, "error": "Faction not found"}
        if tech_id not in self.state.technologies:
            return {"success": False, "error": "Technology not found"}

        faction = self.state.factions[faction_id]
        if tech_id in faction.known_technologies:
            return {"success": False, "error": "Technology already researched"}

        faction.current_research_tech_id = tech_id
        faction.research_progress = 0.0
        return {"success": True, "message": f"Started research on {self.state.technologies[tech_id].name}"}

    def establish_trade_route(self, faction_id: str, orig_sys: str, dest_sys: str, commodity: Commodity) -> Dict[str, Any]:
        if orig_sys not in self.state.systems or dest_sys not in self.state.systems:
            return {"success": False, "error": "Invalid star systems"}

        route_id = f"TR_{uuid.uuid4().hex[:6]}"
        route = TradeRoute(
            route_id=route_id,
            owner_faction=faction_id,
            origin_system_id=orig_sys,
            destination_system_id=dest_sys,
            commodity=commodity,
            volume=30.0,
            profit_per_tick=250.0,
            travel_time=2
        )
        self.state.trade_routes[route_id] = route
        return {"success": True, "route_id": route_id, "profit": route.profit_per_tick}

    def run_balance_benchmark(self, ticks: int = 100) -> Dict[str, Any]:
        """
        Executes automated headless simulation to evaluate galactic balance,
        economic expansion, faction survival rates, and military hegemonies.
        """
        history_gdp: Dict[str, List[float]] = {f: [] for f in self.state.factions}
        history_fleets: Dict[str, List[int]] = {f: [] for f in self.state.factions}

        for _ in range(ticks):
            self.tick()
            for f_id, faction in self.state.factions.items():
                history_gdp[f_id].append(faction.credits)
                fleet_count = sum(len(fl.ships) for fl in self.state.fleets.values() if fl.owner_faction == f_id)
                history_fleets[f_id].append(fleet_count)

        return {
            "total_ticks_simulated": ticks,
            "final_calendar_tick": self.state.calendar_tick,
            "factions_status": {
                f_id: {
                    "final_credits": round(faction.credits, 2),
                    "known_tech_count": len(faction.known_technologies),
                    "controlled_systems": len(faction.controlled_system_ids),
                    "total_ships": sum(len(fl.ships) for fl in self.state.fleets.values() if fl.owner_faction == f_id)
                } for f_id, faction in self.state.factions.items()
            }
        }
