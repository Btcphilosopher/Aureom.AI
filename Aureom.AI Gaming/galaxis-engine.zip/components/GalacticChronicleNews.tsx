'use client';

import React from 'react';
import { GalaxyState } from '../lib/galaxis/types';
import { Radio, BookOpen, AlertTriangle, Globe, Award } from 'lucide-react';

interface NewsProps {
  state: GalaxyState;
}

export const GalacticChronicleNews: React.FC<NewsProps> = ({ state }) => {
  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex justify-between items-center">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">IMPERIAL / REPUBLIC BROADCAST SERVICE</div>
          <h1 className="text-xl font-bold text-cyan-200">HOLONET NEWS AGENCY & GALACTIC CHRONICLES</h1>
        </div>
        <div className="text-xs text-slate-400">
          Calendar Tick: <span className="text-cyan-300 font-bold">{state.calendarTick}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Col: Live HoloNet News Broadcast Feed */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex items-center gap-2">
            <Radio size={16} className="text-rose-400 animate-pulse" />
            <h3 className="font-bold text-cyan-200">LIVE HOLONET WIRE DISPATCHES</h3>
          </div>

          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
            {state.newsFeed.map(news => (
              <div
                key={news.newsId}
                className={`p-3.5 rounded-lg border space-y-1.5 ${
                  news.isGalacticAlert
                    ? 'bg-rose-950/40 border-rose-800 text-rose-100'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-slate-400 font-bold">{news.sourceOutlet}</span>
                  <span className="font-mono text-slate-400">TICK {news.tick}</span>
                </div>
                <h4 className="font-bold text-sm text-cyan-300">{news.headline}</h4>
                <p className="text-[11px] leading-relaxed text-slate-300">{news.body}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Historical Chronicles & Era Milestones */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex items-center gap-2">
            <BookOpen size={16} className="text-amber-400" />
            <h3 className="font-bold text-cyan-200">GALACTIC ARCHIVES & CHRONICLES</h3>
          </div>

          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
            {state.historicalEvents.map(record => (
              <div key={record.eventId} className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-lg space-y-1 text-xs">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold">
                    {record.category}
                  </span>
                  <span className="font-mono text-slate-400">TICK {record.tick}</span>
                </div>
                <h4 className="font-bold text-cyan-200 text-sm">{record.title}</h4>
                <p className="text-[11px] text-slate-300 leading-relaxed">{record.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
