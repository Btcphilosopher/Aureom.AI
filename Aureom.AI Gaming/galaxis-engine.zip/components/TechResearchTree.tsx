'use client';

import React from 'react';
import { GalaxyState, TechnologyNode } from '../lib/galaxis/types';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { Cpu, CheckCircle, Clock, Zap, Shield, Rocket } from 'lucide-react';

interface TechTreeProps {
  state: GalaxyState;
  playerFactionId: string;
  onStartResearch: (techId: string) => void;
}

export const TechResearchTree: React.FC<TechTreeProps> = ({
  state,
  playerFactionId,
  onStartResearch
}) => {
  const playerFaction = state.factions[playerFactionId];
  const knownTechs = playerFaction?.knownTechnologies || [];
  const currentTechId = playerFaction?.currentResearchTechId;
  const currentTech = currentTechId ? state.technologies[currentTechId] : null;

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex flex-wrap justify-between items-center gap-4">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">MINISTRY OF SCIENTIFIC ADVANCEMENT</div>
          <h1 className="text-xl font-bold text-cyan-200">GALACTIC RESEARCH MATRIX & SCHEMATICS</h1>
        </div>
        <div className="flex gap-4 text-xs">
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Researched Technologies: </span>
            <span className="text-emerald-400 font-bold">{knownTechs.length} / {Object.keys(state.technologies).length}</span>
          </div>
        </div>
      </div>

      {/* Active Research Banner */}
      {currentTech ? (
        <div className="bg-cyan-950/40 border border-cyan-700/80 p-4 rounded-lg space-y-2 text-xs">
          <div className="flex justify-between items-center">
            <span className="font-bold text-cyan-300 flex items-center gap-2">
              <Clock size={14} className="animate-spin-slow text-cyan-400" />
              CURRENT LABORATORY INITIATIVE: {currentTech.name}
            </span>
            <span className="text-cyan-400 font-mono">
              {playerFaction.researchProgress} / {currentTech.costResearchPoints} RP
            </span>
          </div>
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-cyan-400 h-full transition-all duration-300"
              style={{ width: `${Math.min(100, (playerFaction.researchProgress / currentTech.costResearchPoints) * 100)}%` }}
            ></div>
          </div>
          <p className="text-slate-300 text-[11px]">{currentTech.description}</p>
        </div>
      ) : (
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-lg text-xs text-slate-400 italic text-center">
          Laboratories currently idle. Select a schematic below to begin scientific research.
        </div>
      )}

      {/* Technology Nodes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        {Object.values(state.technologies).map(tech => {
          const isKnown = knownTechs.includes(tech.techId);
          const isCurrent = currentTechId === tech.techId;

          return (
            <div
              key={tech.techId}
              className={`p-4 rounded-lg border flex flex-col justify-between space-y-3 transition-all ${
                isKnown
                  ? 'bg-emerald-950/30 border-emerald-800 text-slate-300'
                  : isCurrent
                  ? 'bg-cyan-950/60 border-cyan-400 text-cyan-100 shadow-[0_0_12px_rgba(6,182,212,0.2)]'
                  : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-cyan-800'
              }`}
            >
              <div className="space-y-1.5">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] text-cyan-500 uppercase font-bold">{tech.branch} (TIER {tech.tier})</span>
                  {isKnown ? (
                    <CheckCircle size={14} className="text-emerald-400" />
                  ) : (
                    <span className="text-amber-400 font-mono text-[10px]">{tech.costResearchPoints} RP</span>
                  )}
                </div>
                <h3 className="font-bold text-slate-100 text-sm">{tech.name}</h3>
                <p className="text-slate-400 text-[11px] leading-relaxed">{tech.description}</p>
              </div>

              <div>
                {isKnown ? (
                  <div className="w-full py-1 bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-center rounded text-[10px] font-bold">
                    ✓ PROTOCOL INTEGRATED
                  </div>
                ) : isCurrent ? (
                  <div className="w-full py-1 bg-cyan-950 border border-cyan-600 text-cyan-300 text-center rounded text-[10px] font-bold animate-pulse">
                    ⟳ RESEARCH IN PROGRESS
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      playTacticalPing();
                      onStartResearch(tech.techId);
                    }}
                    className="w-full py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-[11px] transition-colors flex items-center justify-center gap-1"
                  >
                    <Cpu size={12} /> INITIATE RESEARCH
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
