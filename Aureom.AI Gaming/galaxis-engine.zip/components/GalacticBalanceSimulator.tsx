'use client';

import React, { useState } from 'react';
import { GalaxyState } from '../lib/galaxis/types';
import { advanceGalaxyTick } from '../lib/galaxis/engine';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { BarChart2, Play, RefreshCw, Award, CheckCircle } from 'lucide-react';

interface BalanceProps {
  state: GalaxyState;
  onUpdateState: (nextState: GalaxyState) => void;
}

export const GalacticBalanceSimulator: React.FC<BalanceProps> = ({ state, onUpdateState }) => {
  const [ticksToRun, setTicksToRun] = useState<number>(50);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [benchmarkSummary, setBenchmarkSummary] = useState<any>(null);

  const runBenchmark = () => {
    setIsRunning(true);
    playTacticalPing();

    setTimeout(() => {
      let currentState = state;
      const initialCredits: Record<string, number> = {};
      for (const [id, f] of Object.entries(state.factions)) {
        initialCredits[id] = f.credits;
      }

      for (let i = 0; i < ticksToRun; i++) {
        const { state: next } = advanceGalaxyTick(currentState);
        currentState = next;
      }

      onUpdateState(currentState);

      const report = {
        ticksExecuted: ticksToRun,
        finalTick: currentState.calendarTick,
        factionResults: Object.values(currentState.factions).map(f => ({
          name: f.name,
          color: f.colorHex,
          credits: Math.round(f.credits),
          deltaCredits: Math.round(f.credits - (initialCredits[f.factionId] || 0)),
          controlledSystems: f.controlledSystemIds.length,
          techsCount: f.knownTechnologies.length,
          fleetCount: Object.values(currentState.fleets).filter(fl => fl.ownerFaction === f.factionId).length
        }))
      };

      setBenchmarkSummary(report);
      setIsRunning(false);
    }, 100);
  };

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex flex-wrap justify-between items-center gap-4">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">MONTE CARLO STATISTICAL LABORATORY</div>
          <h1 className="text-xl font-bold text-cyan-200">GALACTIC BALANCE BENCHMARK RUNNER</h1>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={ticksToRun}
            onChange={(e) => setTicksToRun(Number(e.target.value))}
            className="bg-slate-900 border border-cyan-800 rounded px-3 py-1.5 text-xs text-cyan-200 focus:outline-none"
          >
            <option value={10}>Simulate 10 Ticks</option>
            <option value={50}>Simulate 50 Ticks</option>
            <option value={100}>Simulate 100 Ticks</option>
            <option value={250}>Simulate 250 Ticks</option>
          </select>

          <button
            onClick={runBenchmark}
            disabled={isRunning}
            className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold rounded text-xs transition-colors flex items-center gap-2 shadow-[0_0_12px_rgba(6,182,212,0.3)]"
          >
            {isRunning ? <RefreshCw className="animate-spin" size={14} /> : <Play size={14} />}
            {isRunning ? 'EXECUTING SIMULATION...' : 'RUN BENCHMARK'}
          </button>
        </div>
      </div>

      {/* Benchmark Results */}
      {benchmarkSummary ? (
        <div className="bg-slate-950/80 border border-cyan-900/60 p-5 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="text-base font-bold text-cyan-300 flex items-center gap-2">
              <BarChart2 size={18} /> BENCHMARK METRICS (OVER {benchmarkSummary.ticksExecuted} TICKS)
            </h3>
            <span className="text-slate-400">Current Calendar: Tick {benchmarkSummary.finalTick}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                  <th className="py-2">Faction Power</th>
                  <th className="py-2">Treasury Balance</th>
                  <th className="py-2">Net Treasury Delta</th>
                  <th className="py-2">Systems Held</th>
                  <th className="py-2">Tech Researched</th>
                  <th className="py-2">Active Taskforces</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {benchmarkSummary.factionResults.map((r: any) => (
                  <tr key={r.name} className="hover:bg-slate-900/40">
                    <td className="py-2.5 font-bold text-cyan-200 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: r.color }}></span>
                      {r.name}
                    </td>
                    <td className="py-2.5 font-mono text-amber-300 font-bold">{r.credits.toLocaleString()} ⬡</td>
                    <td className={`py-2.5 font-mono font-bold ${r.deltaCredits >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {r.deltaCredits >= 0 ? `+${r.deltaCredits.toLocaleString()}` : r.deltaCredits.toLocaleString()} ⬡
                    </td>
                    <td className="py-2.5 text-slate-300">{r.controlledSystems} Systems</td>
                    <td className="py-2.5 text-blue-300">{r.techsCount} Nodes</td>
                    <td className="py-2.5 text-slate-300">{r.fleetCount} Fleets</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-slate-950/80 border border-slate-800 p-8 rounded-lg text-center text-slate-500 text-xs space-y-2">
          <BarChart2 size={32} className="mx-auto text-slate-700" />
          <div>Select number of ticks and press RUN BENCHMARK to execute automated Monte Carlo simulations.</div>
        </div>
      )}
    </div>
  );
};
