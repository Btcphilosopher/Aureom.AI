'use client';

import React, { useState, useRef, useEffect } from 'react';
import { GalaxyState, GalacticEra } from '../lib/galaxis/types';
import { advanceGalaxyTick, createInitialGalaxy } from '../lib/galaxis/engine';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { Terminal, Send, Trash2, HelpCircle } from 'lucide-react';

interface ConsoleProps {
  state: GalaxyState;
  onUpdateState: (nextState: GalaxyState) => void;
}

export const InteractivePythonConsole: React.FC<ConsoleProps> = ({ state, onUpdateState }) => {
  const [input, setInput] = useState<string>('');
  const [history, setHistory] = useState<Array<{ cmd: string; output: string[] }>>([
    {
      cmd: 'galaxis --version',
      output: [
        'GALAXIS ENGINE v1.0.0 [Star Wars Grand Strategy & 4X Core]',
        'Type "help" or "galaxis help" for available commands.',
        'Run "galaxis simulate 5", "galaxis inspect-system Coruscant", etc.'
      ]
    }
  ]);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleRunCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    playButtonBeep();
    const cmdStr = input.trim();
    const parts = cmdStr.split(' ');
    const mainCmd = parts[0].toLowerCase();
    const subCmd = parts[1]?.toLowerCase();
    const output: string[] = [];

    if (mainCmd === 'clear') {
      setHistory([]);
      setInput('');
      return;
    }

    if (mainCmd === 'help' || (mainCmd === 'galaxis' && subCmd === 'help')) {
      output.push('AVAILABLE GALAXIS CLI COMMANDS:');
      output.push('  galaxis generate [--seed N] [--era ERA]  : Re-generate universe');
      output.push('  galaxis simulate [N]                     : Step simulation forward N ticks');
      output.push('  galaxis inspect-system <SYSTEM_ID>       : Query star system planetary telemetry');
      output.push('  galaxis inspect-faction <FACTION_ID>     : Inspect faction statistics');
      output.push('  galaxis inspect-market                   : Print galactic commodity price index');
      output.push('  galaxis inspect-history                  : Display chronicles & historical events');
      output.push('  galaxis balance [--ticks N]              : Run Monte Carlo balance benchmark');
      output.push('  galaxis export-save                      : Export JSON save state');
      output.push('  clear                                    : Clear terminal buffer');
    } else if (mainCmd === 'galaxis') {
      if (subCmd === 'simulate') {
        const ticks = parseInt(parts[2] || '1', 10) || 1;
        let cur = state;
        for (let i = 0; i < ticks; i++) {
          const res = advanceGalaxyTick(cur);
          cur = res.state;
        }
        onUpdateState(cur);
        output.push(`[+] Simulation advanced by ${ticks} ticks. Current Calendar Tick: ${cur.calendarTick}`);
      } else if (subCmd === 'generate') {
        const newState = createInitialGalaxy(1138, 'IMPERIAL_ERA');
        onUpdateState(newState);
        output.push('[+] New galaxy generated with Seed 1138 under IMPERIAL_ERA protocol.');
      } else if (subCmd === 'inspect-system') {
        const sysId = (parts[2] || '').toUpperCase();
        const sys = state.systems[sysId] || Object.values(state.systems).find(s => s.name.toUpperCase() === sysId);
        if (sys) {
          output.push(`=== STAR SYSTEM: ${sys.name} (${sys.region}) ===`);
          output.push(`Controller: ${sys.controllingFaction}`);
          output.push(`Coordinates: (${sys.coordX}, ${sys.coordY})`);
          output.push(`Planets: ${sys.planets.length}`);
          for (const p of sys.planets) {
            output.push(`  - ${p.name} [${p.planetType}] Pop: ${p.population.toLocaleString()} | Stability: ${p.stability}% | Loyalty: ${p.loyalty}%`);
          }
        } else {
          output.push(`[!] Star system "${parts[2]}" not found in galactic astrogation database.`);
        }
      } else if (subCmd === 'inspect-faction') {
        const facId = (parts[2] || '').toUpperCase();
        const f = state.factions[facId] || Object.values(state.factions).find(fac => fac.name.toUpperCase().includes(facId));
        if (f) {
          output.push(`=== FACTION: ${f.name} ===`);
          output.push(`Treasury: ${Math.round(f.credits).toLocaleString()} Galactic Credits`);
          output.push(`Capital: ${f.capitalSystemId}`);
          output.push(`Controlled Systems (${f.controlledSystemIds.length}): ${f.controlledSystemIds.join(', ')}`);
          output.push(`Researched Techs: ${f.knownTechnologies.length}`);
        } else {
          output.push(`[!] Faction "${parts[2]}" not found.`);
        }
      } else if (subCmd === 'inspect-market') {
        output.push('=== GALACTIC COMMODITY PRICE INDEX (SAMPLE: CORUSCANT) ===');
        const coruscant = state.systems['CORUSCANT']?.planets[0];
        if (coruscant) {
          for (const [comm, price] of Object.entries(coruscant.commodityPrices)) {
            const stock = coruscant.commodityStockpiles[comm] || 0;
            output.push(`• ${comm.padEnd(22)} Stock: ${Math.round(stock).toString().padStart(6)} | Price: ${price} ⬡`);
          }
        }
      } else if (subCmd === 'inspect-history') {
        output.push('=== GALACTIC CHRONICLES TIMELINE ===');
        for (const ev of state.historicalEvents.slice(0, 8)) {
          output.push(`[TICK ${ev.tick.toString().padStart(4, '0')}] ${ev.category}: ${ev.title}`);
          output.push(`       ${ev.description}`);
        }
      } else if (subCmd === 'export-save') {
        output.push(`[+] Save State JSON generated. Payload Size: ${JSON.stringify(state).length} bytes.`);
      } else {
        output.push(`Unknown subcommand "${subCmd}". Type "help" for syntax.`);
      }
    } else {
      output.push(`Command not recognized: "${cmdStr}". Type "help" for syntax.`);
    }

    setHistory(prev => [...prev, { cmd: cmdStr, output }]);
    setInput('');
  };

  return (
    <div className="space-y-4 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex justify-between items-center">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">GALACTIC MAINFRAME TERMINAL</div>
          <h1 className="text-xl font-bold text-cyan-200">PYTHON & CLI COMMAND CENTER</h1>
        </div>
        <button
          onClick={() => setHistory([])}
          className="px-3 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-xs text-slate-400 flex items-center gap-1.5"
        >
          <Trash2 size={12} /> Clear Buffer
        </button>
      </div>

      {/* Terminal Viewport */}
      <div className="bg-black/90 border border-cyan-950 rounded-lg p-4 h-[500px] overflow-y-auto flex flex-col justify-between text-xs space-y-3 shadow-inner">
        <div className="space-y-3">
          {history.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="text-cyan-400 font-bold flex items-center gap-1.5">
                <span className="text-slate-500">galaxis@core-terminal:~$</span>
                <span>{item.cmd}</span>
              </div>
              <div className="text-slate-300 pl-4 space-y-0.5 whitespace-pre-wrap leading-relaxed">
                {item.output.map((line, lIdx) => (
                  <div key={lIdx}>{line}</div>
                ))}
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Command Input Bar */}
        <form onSubmit={handleRunCommand} className="flex items-center gap-2 pt-2 border-t border-slate-900">
          <span className="text-cyan-400 font-bold">▶</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type 'help' or 'galaxis simulate 5'..."
            className="flex-1 bg-transparent border-none text-cyan-200 focus:outline-none text-xs font-mono"
            autoFocus
          />
          <button
            type="submit"
            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs flex items-center gap-1"
          >
            <Send size={12} /> RUN
          </button>
        </form>
      </div>
    </div>
  );
};
