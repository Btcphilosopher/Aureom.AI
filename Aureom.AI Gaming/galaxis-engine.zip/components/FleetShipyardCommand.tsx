'use client';

import React, { useState } from 'react';
import { GalaxyState, FleetState, ShipState, ShipClass, FleetMission } from '../lib/galaxis/types';
import { STAR_WARS_SHIP_SPECS } from '../lib/galaxis/data';
import { playButtonBeep, playHyperspaceJump, playLaserBlaster } from '../lib/galaxis/audio';
import { Anchor, Navigation, Shield, Zap, Crosshair, Plus, Trash2, Sliders } from 'lucide-react';

interface FleetCommandProps {
  state: GalaxyState;
  playerFactionId: string;
  selectedFleetId: string | null;
  onSelectFleet: (fleetId: string) => void;
  onDispatchFleet: (fleetId: string, destSysId: string, mission: FleetMission) => void;
}

export const FleetShipyardCommand: React.FC<FleetCommandProps> = ({
  state,
  playerFactionId,
  selectedFleetId,
  onSelectFleet,
  onDispatchFleet
}) => {
  const playerFleets = Object.values(state.fleets).filter(f => f.ownerFaction === playerFactionId);
  const activeFleet = playerFleets.find(f => f.fleetId === selectedFleetId) || playerFleets[0];

  const [destSysId, setDestSysId] = useState<string>('');
  const [mission, setMission] = useState<FleetMission>('PATROL');

  // Modular Designer State
  const [designClass, setDesignClass] = useState<ShipClass>('DESTROYER');
  const [designName, setDesignName] = useState<string>('Custom Heavy Battlecruiser');
  const [extraShields, setExtraShields] = useState<number>(200);
  const [extraFirepower, setExtraFirepower] = useState<number>(300);
  const [extraArmour, setExtraArmour] = useState<number>(150);

  const baseSpec = STAR_WARS_SHIP_SPECS[designClass] || STAR_WARS_SHIP_SPECS.DESTROYER;
  const customCost = baseSpec.cost + extraShields * 5 + extraFirepower * 10 + extraArmour * 8;

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header Banner */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex justify-between items-center">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">NAVAL SUPREME COMMAND</div>
          <h1 className="text-xl font-bold text-cyan-200">ARMADA DISPATCH & MODULAR SHIPYARDS</h1>
        </div>
        <div className="text-xs text-slate-400">
          Total Active Fleets: <span className="text-cyan-300 font-bold">{playerFleets.length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Player Taskforces */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Taskforces</div>
          {playerFleets.length === 0 ? (
            <div className="text-xs text-slate-500 italic p-4 text-center">No active fleets. Construct vessels at a planetary shipyard.</div>
          ) : (
            playerFleets.map(fleet => {
              const isSelected = fleet.fleetId === activeFleet?.fleetId;
              const totalFirepower = fleet.ships.reduce((sum, s) => sum + s.firepower, 0);
              return (
                <div
                  key={fleet.fleetId}
                  onClick={() => {
                    playButtonBeep();
                    onSelectFleet(fleet.fleetId);
                  }}
                  className={`p-3 rounded border cursor-pointer transition-all space-y-2 text-xs ${
                    isSelected
                      ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.15)]'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-cyan-800'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-cyan-300">{fleet.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 border border-slate-700 text-amber-400">
                      {fleet.ships.length} Ships
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Loc: <span className="text-slate-200">{state.systems[fleet.locationSystemId]?.name || fleet.locationSystemId}</span></span>
                    <span>Status: <span className={fleet.inHyperspace ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}>
                      {fleet.inHyperspace ? `Hyperspace (${fleet.hyperspaceEtaTicks}T)` : fleet.mission}
                    </span></span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Total Firepower: <span className="text-rose-400 font-bold">{totalFirepower}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Center Column: Selected Fleet Roster & Dispatch Controls */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4">
          {activeFleet ? (
            <>
              <div className="border-b border-slate-800 pb-3 flex justify-between items-start">
                <div>
                  <h2 className="text-base font-bold text-cyan-200">{activeFleet.name}</h2>
                  <div className="text-xs text-slate-400">
                    Commander: <span className="text-cyan-300">{activeFleet.commanderId || 'Sector Moff (Assigned)'}</span>
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400">
                  {activeFleet.mission}
                </span>
              </div>

              {/* Ship Roster */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-slate-400 uppercase">Capital Vessels & Escorts ({activeFleet.ships.length})</div>
                <div className="max-h-56 overflow-y-auto space-y-2 pr-1 text-xs">
                  {activeFleet.ships.map(ship => (
                    <div key={ship.shipId} className="bg-slate-900/80 p-2.5 rounded border border-slate-800 space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-cyan-300">{ship.name}</span>
                        <span className="text-[10px] text-slate-400">{ship.shipClass}</span>
                      </div>
                      {/* Shield & Hull bars */}
                      <div className="space-y-1 text-[10px]">
                        <div className="flex justify-between text-cyan-400">
                          <span>Shields:</span>
                          <span>{Math.round(ship.shieldsCurrent)} / {ship.shieldsMax}</span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-cyan-500 h-full" style={{ width: `${(ship.shieldsCurrent / ship.shieldsMax) * 100}%` }}></div>
                        </div>

                        <div className="flex justify-between text-rose-400">
                          <span>Hull:</span>
                          <span>{Math.round(ship.hullCurrent)} / {ship.hullMax}</span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-rose-500 h-full" style={{ width: `${(ship.hullCurrent / ship.hullMax) * 100}%` }}></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dispatch Controls */}
              <div className="p-3 bg-slate-900/90 rounded border border-cyan-900 space-y-2 text-xs">
                <div className="font-bold text-cyan-300 flex items-center gap-1.5">
                  <Navigation size={14} /> ORDER HYPERSPACE VECTOR
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400">Destination:</label>
                    <select
                      value={destSysId}
                      onChange={(e) => setDestSysId(e.target.value)}
                      className="w-full bg-slate-950 border border-cyan-800 rounded p-1 text-cyan-200 text-xs focus:outline-none"
                    >
                      <option value="">-- Choose System --</option>
                      {Object.values(state.systems)
                        .filter(s => s.systemId !== activeFleet.locationSystemId)
                        .map(s => (
                          <option key={s.systemId} value={s.systemId}>{s.name}</option>
                        ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400">Mission Type:</label>
                    <select
                      value={mission}
                      onChange={(e) => setMission(e.target.value as FleetMission)}
                      className="w-full bg-slate-950 border border-cyan-800 rounded p-1 text-cyan-200 text-xs focus:outline-none"
                    >
                      {(['PATROL', 'RAID', 'BLOCKADE', 'INVASION', 'DEFEND', 'SCOUT'] as FleetMission[]).map(m => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  disabled={!destSysId || activeFleet.inHyperspace}
                  onClick={() => {
                    playHyperspaceJump();
                    onDispatchFleet(activeFleet.fleetId, destSysId, mission);
                  }}
                  className="w-full py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-1 mt-2"
                >
                  <Navigation size={12} /> INITIATE HYPERSPACE TRANSIT
                </button>
              </div>
            </>
          ) : (
            <div className="text-center p-8 text-slate-500 text-xs">Select a fleet on the left to inspect and dispatch.</div>
          )}
        </div>

        {/* Right Column: Modular Ship Blueprint Designer */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-1.5">
              <Sliders size={16} /> MODULAR SHIP BLUEPRINT DESIGNER
            </h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] text-slate-400">Blueprint Class:</label>
              <select
                value={designClass}
                onChange={(e) => setDesignClass(e.target.value as ShipClass)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-1.5 text-cyan-200 focus:outline-none text-xs"
              >
                {(['FIGHTER', 'CORVETTE', 'FRIGATE', 'DESTROYER', 'CRUISER', 'BATTLESHIP'] as ShipClass[]).map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400">Custom Vessel Name:</label>
              <input
                type="text"
                value={designName}
                onChange={(e) => setDesignName(e.target.value)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-1.5 text-cyan-200 focus:outline-none text-xs"
              />
            </div>

            {/* Custom module sliders */}
            <div className="space-y-2 bg-slate-900/60 p-3 rounded border border-slate-800">
              <div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-cyan-400">Additional Deflector Overcharge:</span>
                  <span className="text-cyan-300">+{extraShields} MW</span>
                </div>
                <input
                  type="range" min={0} max={1000} step={50}
                  value={extraShields}
                  onChange={(e) => setExtraShields(Number(e.target.value))}
                  className="w-full accent-cyan-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-rose-400">Kyber Turbolaser Batteries:</span>
                  <span className="text-rose-300">+{extraFirepower} FP</span>
                </div>
                <input
                  type="range" min={0} max={1500} step={50}
                  value={extraFirepower}
                  onChange={(e) => setExtraFirepower(Number(e.target.value))}
                  className="w-full accent-rose-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-amber-400">Reinforced Beskar Lamination:</span>
                  <span className="text-amber-300">+{extraArmour} AR</span>
                </div>
                <input
                  type="range" min={0} max={800} step={25}
                  value={extraArmour}
                  onChange={(e) => setExtraArmour(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>
            </div>

            {/* Estimated Stats & Cost */}
            <div className="p-3 bg-cyan-950/40 border border-cyan-800 rounded space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Firepower:</span>
                <span className="text-rose-400 font-bold">{baseSpec.firepower + extraFirepower}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Shields:</span>
                <span className="text-cyan-400 font-bold">{baseSpec.shields + extraShields}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Armour:</span>
                <span className="text-amber-400 font-bold">{baseSpec.armour + extraArmour}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-cyan-800 text-xs">
                <span className="text-amber-400 font-bold">Estimated Cost:</span>
                <span className="text-amber-300 font-bold font-mono">{customCost.toLocaleString()} ⬡</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
