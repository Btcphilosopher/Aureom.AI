'use client';

import React, { useState } from 'react';
import { GalaxyState, BountyContract } from '../lib/galaxis/types';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { Eye, Crosshair, Plus, ShieldAlert, Cpu, Award } from 'lucide-react';

interface EspionageProps {
  state: GalaxyState;
  playerFactionId: string;
  onPostBounty: (targetName: string, reward: number, location: string) => void;
  onExecuteSpyMission: (missionType: string, targetSystem: string) => void;
}

export const EspionageUnderworldHub: React.FC<EspionageProps> = ({
  state,
  playerFactionId,
  onPostBounty,
  onExecuteSpyMission
}) => {
  const [bountyName, setBountyName] = useState('');
  const [bountyReward, setBountyReward] = useState(25000);
  const [bountyLocation, setBountyLocation] = useState('TATOOINE');
  const [spyTargetSys, setSpyTargetSys] = useState('CORUSCANT');
  const [missionLog, setMissionLog] = useState<string | null>(null);

  const handleRunSpyMission = (type: string) => {
    playTacticalPing();
    const targetName = state.systems[spyTargetSys]?.name || spyTargetSys;
    let log = '';

    if (type === 'SLICE_ORDERS') {
      log = `OPERATION SUCCESSFUL: Sliced Imperial transmission relays at ${targetName}. Intercepted sector patrol routes for next 5 ticks.`;
    } else if (type === 'SABOTAGE_FOUNDRY') {
      log = `OPERATION SUCCESSFUL: Thermal detonators ignited power generator in ${targetName} drydock. Shipyard output stalled.`;
    } else if (type === 'INCITE_REVOLT') {
      log = `OPERATION SUCCESSFUL: Underground partisan cell funded in ${targetName}. Planetary Resistance increased by +25 points!`;
    } else if (type === 'STEAL_TECH') {
      log = `OPERATION SUCCESSFUL: Cyber-infiltrator copied classified weapon schematics from ${targetName} research bureau.`;
    }

    setMissionLog(log);
    onExecuteSpyMission(type, spyTargetSys);
  };

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex justify-between items-center">
        <div>
          <div className="text-[10px] text-amber-500 uppercase tracking-widest">SHADOW INTELLIGENCE NETWORK</div>
          <h1 className="text-xl font-bold text-amber-300">ESPIONAGE, SLICING & BOUNTY GUILD</h1>
        </div>
        <div className="text-xs bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
          <span className="text-slate-400">Underworld Guild Standing: </span>
          <span className="text-amber-400 font-bold">Respected</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Col: Bounty Hunter Guild Board */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="font-bold text-cyan-200 flex items-center gap-2">
              <Crosshair size={16} className="text-amber-400" /> BOUNTY HUNTERS GUILD CONTRACTS
            </h3>
          </div>

          {/* Active Bounties */}
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {Object.values(state.bounties).map(b => (
              <div key={b.bountyId} className="bg-slate-900/80 p-3 rounded border border-slate-800 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-amber-300">{b.targetName}</span>
                  <span className="text-amber-400 font-mono font-bold">{b.rewardCredits.toLocaleString()} ⬡</span>
                </div>
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Last Seen: {state.systems[b.locationSystemId]?.name || b.locationSystemId}</span>
                  <span>Hunter: <span className="text-cyan-300">{b.assignedHunterId || 'Guild Contract (Open)'}</span></span>
                </div>
              </div>
            ))}
          </div>

          {/* Post New Bounty */}
          <div className="p-3 bg-slate-900/60 rounded border border-slate-800 space-y-2">
            <div className="text-[10px] font-bold text-slate-400 uppercase">Post Galactic Bounty Contract</div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400">Target Mark:</label>
                <input
                  type="text"
                  placeholder="e.g. Rogue Sector Moff"
                  value={bountyName}
                  onChange={(e) => setBountyName(e.target.value)}
                  className="w-full bg-slate-950 border border-cyan-800 rounded p-1.5 text-cyan-200 text-xs focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Reward Bounty (⬡):</label>
                <input
                  type="number"
                  value={bountyReward}
                  onChange={(e) => setBountyReward(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-cyan-800 rounded p-1.5 text-cyan-200 text-xs focus:outline-none"
                />
              </div>
            </div>

            <button
              disabled={!bountyName.trim()}
              onClick={() => {
                playTacticalPing();
                onPostBounty(bountyName, bountyReward, bountyLocation);
                setBountyName('');
              }}
              className="w-full py-1.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-1 mt-1"
            >
              <Plus size={12} /> REGISTER WITH GUILD
            </button>
          </div>
        </div>

        {/* Right Col: Covert Black-Ops & Slicing Missions */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="font-bold text-cyan-200 flex items-center gap-2">
              <Eye size={16} className="text-cyan-400" /> COVERT SHADOW OPERATIONS
            </h3>
          </div>

          <div>
            <label className="text-[10px] text-slate-400">Select Target Star System:</label>
            <select
              value={spyTargetSys}
              onChange={(e) => setSpyTargetSys(e.target.value)}
              className="w-full bg-slate-900 border border-cyan-800 rounded p-2 text-cyan-200 text-xs focus:outline-none"
            >
              {Object.values(state.systems).map(s => (
                <option key={s.systemId} value={s.systemId}>{s.name} ({s.region})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleRunSpyMission('SLICE_ORDERS')}
              className="p-3 bg-slate-900 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-700 rounded text-left space-y-1 transition-all"
            >
              <div className="font-bold text-cyan-300">📡 Slice HoloNet Comms</div>
              <div className="text-[10px] text-slate-400">Intercept target fleet movements & tactical orders.</div>
            </button>

            <button
              onClick={() => handleRunSpyMission('SABOTAGE_FOUNDRY')}
              className="p-3 bg-slate-900 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-700 rounded text-left space-y-1 transition-all"
            >
              <div className="font-bold text-rose-300">💣 Sabotage Shipyard</div>
              <div className="text-[10px] text-slate-400">Detonate power conduits to delay ship builds.</div>
            </button>

            <button
              onClick={() => handleRunSpyMission('INCITE_REVOLT')}
              className="p-3 bg-slate-900 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-700 rounded text-left space-y-1 transition-all"
            >
              <div className="font-bold text-amber-300">🔥 Fund Insurgency</div>
              <div className="text-[10px] text-slate-400">Arm partisan cells to trigger planetary rebellion.</div>
            </button>

            <button
              onClick={() => handleRunSpyMission('STEAL_TECH')}
              className="p-3 bg-slate-900 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-700 rounded text-left space-y-1 transition-all"
            >
              <div className="font-bold text-purple-300">💾 Infiltrate Database</div>
              <div className="text-[10px] text-slate-400">Exfiltrate research prototypes from engineering bureaus.</div>
            </button>
          </div>

          {/* Operation Status Log */}
          {missionLog && (
            <div className="p-3 bg-cyan-950/80 border border-cyan-600 rounded text-xs text-cyan-200 leading-relaxed animate-pulse">
              {missionLog}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
