'use client';

import React, { useRef, useEffect, useState } from 'react';
import { GalaxyState, StarSystem, FleetState } from '../lib/galaxis/types';
import { playTacticalPing, playHyperspaceJump } from '../lib/galaxis/audio';
import { Compass, Shield, Navigation, AlertTriangle, Radio, Play } from 'lucide-react';

interface MapProps {
  state: GalaxyState;
  selectedSystemId: string | null;
  onSelectSystem: (systemId: string) => void;
  selectedFleetId: string | null;
  onSelectFleet: (fleetId: string) => void;
  onDispatchFleet: (fleetId: string, destSystemId: string) => void;
}

export const GalacticHoloMap: React.FC<MapProps> = ({
  state,
  selectedSystemId,
  onSelectSystem,
  selectedFleetId,
  onSelectFleet,
  onDispatchFleet
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoveredSystemId, setHoveredSystemId] = useState<string | null>(null);
  const [dispatchModalOpen, setDispatchModalOpen] = useState(false);
  const [targetSystemId, setTargetSystemId] = useState<string>('');

  const selectedSystem = selectedSystemId ? state.systems[selectedSystemId] : null;
  const selectedFleet = selectedFleetId ? state.fleets[selectedFleetId] : null;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrameId: number;
    let pulseTime = 0;

    const render = () => {
      pulseTime += 0.03;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;

      // 1. Draw Tactical Galactic Grid & Concentric Sector Rings
      ctx.save();
      ctx.strokeStyle = 'rgba(14, 116, 144, 0.12)';
      ctx.lineWidth = 1;

      // Concentric rings (Deep Core, Core, Inner Rim, Mid Rim, Outer Rim)
      const ringRadii = [80, 160, 240, 320, 400];
      for (const r of ringRadii) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Radial sector lines
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI) / 4;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX + Math.cos(angle) * 440, centerY + Math.sin(angle) * 440);
        ctx.stroke();
      }

      // Galactic Core Glow
      const coreGrad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, 100);
      coreGrad.addColorStop(0, 'rgba(255, 255, 255, 0.25)');
      coreGrad.addColorStop(0.4, 'rgba(56, 189, 248, 0.1)');
      coreGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 100, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // 2. Draw Hyperlanes
      for (const route of Object.values(state.hyperlanes)) {
        const orig = state.systems[route.originSystemId];
        const dest = state.systems[route.destinationSystemId];
        if (!orig || !dest) continue;

        const x1 = orig.coordX;
        const y1 = orig.coordY;
        const x2 = dest.coordX;
        const y2 = dest.coordY;

        ctx.save();
        if (route.isMajorLane) {
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
          ctx.lineWidth = 2.5;
          ctx.setLineDash([8, 4]);
          ctx.lineDashOffset = -pulseTime * 15;
        } else {
          ctx.strokeStyle = 'rgba(71, 85, 105, 0.35)';
          ctx.lineWidth = 1.2;
          ctx.setLineDash([]);
        }

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        // Route Name on major lanes
        if (route.isMajorLane) {
          const midX = (x1 + x2) / 2;
          const midY = (y1 + y2) / 2;
          ctx.font = '8px monospace';
          ctx.fillStyle = 'rgba(125, 211, 252, 0.4)';
          ctx.textAlign = 'center';
          ctx.fillText(route.name, midX, midY - 4);
        }
        ctx.restore();
      }

      // 3. Draw Fleets in Hyperspace Transit
      for (const fleet of Object.values(state.fleets)) {
        if (fleet.inHyperspace && fleet.destinationSystemId) {
          const orig = state.systems[fleet.locationSystemId];
          const dest = state.systems[fleet.destinationSystemId];
          if (orig && dest) {
            // Calculate interpolation along hyperlane
            const t = 0.5 + Math.sin(pulseTime * 2) * 0.2;
            const fx = orig.coordX + (dest.coordX - orig.coordX) * t;
            const fy = orig.coordY + (dest.coordY - orig.coordY) * t;

            ctx.save();
            ctx.fillStyle = '#f43f5e';
            ctx.shadowColor = '#f43f5e';
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(fx, fy, 4, 0, Math.PI * 2);
            ctx.fill();

            // Label
            ctx.font = '9px monospace';
            ctx.fillStyle = '#fda4af';
            ctx.fillText(`⚡ ${fleet.name}`, fx + 6, fy - 4);
            ctx.restore();
          }
        }
      }

      // 4. Draw Star Systems
      for (const sys of Object.values(state.systems)) {
        const isSelected = sys.systemId === selectedSystemId;
        const isHovered = sys.systemId === hoveredSystemId;
        const faction = state.factions[sys.controllingFaction];
        const factionColor = faction?.colorHex || '#94a3b8';

        ctx.save();

        // Selection / Hover Target Reticle
        if (isSelected || isHovered) {
          ctx.strokeStyle = isSelected ? '#22d3ee' : '#94a3b8';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(sys.coordX, sys.coordY, 14 + Math.sin(pulseTime * 4) * 2, 0, Math.PI * 2);
          ctx.stroke();

          // Corner reticles
          const r = 16;
          ctx.strokeRect(sys.coordX - r, sys.coordY - r, r * 2, r * 2);
        }

        // Star Core Glow
        const starGrad = ctx.createRadialGradient(sys.coordX, sys.coordY, 1, sys.coordX, sys.coordY, 10);
        starGrad.addColorStop(0, '#ffffff');
        starGrad.addColorStop(0.3, factionColor);
        starGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = starGrad;
        ctx.beginPath();
        ctx.arc(sys.coordX, sys.coordY, 10, 0, Math.PI * 2);
        ctx.fill();

        // Star Center Dot
        ctx.fillStyle = factionColor;
        ctx.shadowColor = factionColor;
        ctx.shadowBlur = isSelected ? 12 : 6;
        ctx.beginPath();
        ctx.arc(sys.coordX, sys.coordY, sys.isHyperspaceJunction ? 5 : 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Fleets stationed at this system icon
        const stationedFleets = Object.values(state.fleets).filter(
          f => f.locationSystemId === sys.systemId && !f.inHyperspace
        );
        if (stationedFleets.length > 0) {
          ctx.fillStyle = '#38bdf8';
          ctx.font = '10px monospace';
          ctx.fillText(`▲ ${stationedFleets.length}`, sys.coordX + 8, sys.coordY + 12);
        }

        // Pirate Danger Indicator
        if (sys.pirateActivity > 0.2) {
          ctx.fillStyle = '#eab308';
          ctx.font = '8px monospace';
          ctx.fillText('☠', sys.coordX - 12, sys.coordY - 6);
        }

        // System Name Label
        ctx.font = isSelected ? 'bold 11px monospace' : '10px monospace';
        ctx.fillStyle = isSelected ? '#38bdf8' : '#cbd5e1';
        ctx.textAlign = 'center';
        ctx.shadowBlur = 0;
        ctx.fillText(sys.name, sys.coordX, sys.coordY + 16);

        ctx.restore();
      }

      animFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrameId);
    };
  }, [state, selectedSystemId, hoveredSystemId]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    for (const sys of Object.values(state.systems)) {
      const dist = Math.hypot(sys.coordX - x, sys.coordY - y);
      if (dist < 18) {
        playTacticalPing();
        onSelectSystem(sys.systemId);
        return;
      }
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    let found: string | null = null;
    for (const sys of Object.values(state.systems)) {
      const dist = Math.hypot(sys.coordX - x, sys.coordY - y);
      if (dist < 18) {
        found = sys.systemId;
        break;
      }
    }
    setHoveredSystemId(found);
  };

  return (
    <div className="relative w-full h-[720px] bg-slate-950 border border-cyan-900/50 rounded-lg overflow-hidden flex">
      {/* 2D Tactical Map Viewport */}
      <div className="flex-1 relative h-full">
        <canvas
          ref={canvasRef}
          width={960}
          height={720}
          onClick={handleCanvasClick}
          onMouseMove={handleCanvasMouseMove}
          className="w-full h-full object-contain cursor-crosshair bg-radial-galaxy"
        />

        {/* Map Legend Overlay */}
        <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md border border-slate-800 p-2.5 rounded text-[11px] font-mono space-y-1 text-slate-300 pointer-events-none">
          <div className="text-cyan-400 font-bold text-xs flex items-center gap-1.5">
            <Radio size={12} className="animate-pulse text-cyan-400" />
            HOLONET TACTICAL GRID
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-0.5 bg-cyan-400"></span> Major Hyperlane
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-0.5 bg-slate-600"></span> Secondary Spur
          </div>
          <div className="flex items-center gap-2">
            <span className="text-rose-400">⚡</span> Fleet in Hyperspace
          </div>
        </div>
      </div>

      {/* Right Strategic Inspector Sidebar */}
      <aside className="w-80 border-l border-cyan-900/60 bg-slate-950/90 backdrop-blur-md p-4 flex flex-col justify-between overflow-y-auto">
        {selectedSystem ? (
          <div className="space-y-4 text-xs font-mono">
            <div className="border-b border-cyan-800/80 pb-3">
              <div className="text-[10px] text-cyan-400 uppercase tracking-widest">{selectedSystem.region} REGION</div>
              <h2 className="text-lg font-bold text-cyan-100">{selectedSystem.name} SYSTEM</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-slate-400">Controlling Power:</span>
                <span className="font-bold text-amber-300">
                  {state.factions[selectedSystem.controllingFaction]?.name || selectedSystem.controllingFaction}
                </span>
              </div>
            </div>

            {/* Planets in this system */}
            <div className="space-y-2">
              <div className="text-slate-400 font-bold text-[11px] uppercase tracking-wider">Planetary Bodies ({selectedSystem.planets.length})</div>
              {selectedSystem.planets.map(p => (
                <div key={p.planetId} className="bg-slate-900/80 border border-slate-800 p-2.5 rounded space-y-1">
                  <div className="flex justify-between items-center text-cyan-200 font-bold">
                    <span>{p.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                      {p.planetType}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[10px] text-slate-400">
                    <div>Pop: <span className="text-slate-200">{p.population.toLocaleString()}</span></div>
                    <div>Stability: <span className={p.stability > 70 ? 'text-emerald-400' : 'text-rose-400'}>{p.stability}%</span></div>
                    <div>Industry: <span className="text-slate-200">{p.industry}/100</span></div>
                    <div>Mining: <span className="text-slate-200">{p.mining}/100</span></div>
                  </div>
                  {/* Resistance Stage */}
                  <div className="flex justify-between items-center text-[10px] pt-1 border-t border-slate-800">
                    <span className="text-slate-400">Resistance:</span>
                    <span className={`font-bold ${p.resistanceStage === 'CONTENT' ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {p.resistanceStage} ({p.resistancePoints.toFixed(0)} pts)
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Stationed Fleets */}
            <div className="space-y-2">
              <div className="text-slate-400 font-bold text-[11px] uppercase tracking-wider">Stationed Armada</div>
              {Object.values(state.fleets).filter(f => f.locationSystemId === selectedSystem.systemId && !f.inHyperspace).length === 0 ? (
                <div className="text-slate-500 italic p-2 bg-slate-900/40 rounded text-center">No military taskforces currently present.</div>
              ) : (
                Object.values(state.fleets)
                  .filter(f => f.locationSystemId === selectedSystem.systemId && !f.inHyperspace)
                  .map(fleet => (
                    <div key={fleet.fleetId} className="bg-cyan-950/40 border border-cyan-800/80 p-2.5 rounded space-y-1.5">
                      <div className="flex justify-between items-center text-cyan-300 font-bold">
                        <span>{fleet.name}</span>
                        <span className="text-[10px] text-amber-400">{fleet.ships.length} Ships</span>
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Firepower: <span className="text-rose-400 font-bold">{fleet.ships.reduce((s, sh) => s + sh.firepower, 0)}</span> | Morale: <span className="text-emerald-400">{fleet.morale}%</span>
                      </div>
                      <button
                        onClick={() => {
                          onSelectFleet(fleet.fleetId);
                          setDispatchModalOpen(true);
                        }}
                        className="w-full py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-[10px] transition-colors flex items-center justify-center gap-1"
                      >
                        <Navigation size={10} /> DISPATCH HYPERSPACE JUMP
                      </button>
                    </div>
                  ))
              )}
            </div>

            {/* Connected Hyperlanes */}
            <div className="space-y-1 text-[11px]">
              <div className="text-slate-400 font-bold uppercase tracking-wider">Direct Hyperlanes:</div>
              <div className="flex flex-wrap gap-1">
                {selectedSystem.hyperlanes.map(destId => (
                  <button
                    key={destId}
                    onClick={() => {
                      playTacticalPing();
                      onSelectSystem(destId);
                    }}
                    className="px-2 py-0.5 rounded bg-slate-900 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-700 text-cyan-300 text-[10px]"
                  >
                    → {state.systems[destId]?.name || destId}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 space-y-2 font-mono">
            <Compass size={32} className="text-cyan-800 animate-spin-slow" />
            <div className="text-xs">SELECT A STAR SYSTEM TO INSPECT TACTICAL DATA</div>
          </div>
        )}
      </aside>

      {/* Dispatch Fleet Hyperspace Modal */}
      {dispatchModalOpen && selectedFleet && (
        <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500 rounded-lg p-5 max-w-md w-full space-y-4 font-mono text-xs text-cyan-100 shadow-2xl">
            <div className="flex justify-between items-center border-b border-cyan-800 pb-2">
              <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
                <Navigation size={14} /> NAVICOMPUTER FLIGHT PLOT
              </h3>
              <button onClick={() => setDispatchModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-2">
              <div>Fleet: <span className="font-bold text-white">{selectedFleet.name}</span></div>
              <div>Current Location: <span className="text-amber-400">{state.systems[selectedFleet.locationSystemId]?.name}</span></div>
              <div>
                <label className="block text-slate-400 mb-1">Select Hyperspace Destination:</label>
                <select
                  value={targetSystemId}
                  onChange={(e) => setTargetSystemId(e.target.value)}
                  className="w-full bg-slate-950 border border-cyan-700 rounded p-2 text-cyan-200 focus:outline-none"
                >
                  <option value="">-- Choose Target System --</option>
                  {Object.values(state.systems)
                    .filter(s => s.systemId !== selectedFleet.locationSystemId)
                    .map(s => (
                      <option key={s.systemId} value={s.systemId}>
                        {s.name} ({s.region})
                      </option>
                    ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setDispatchModalOpen(false)}
                className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                Abort
              </button>
              <button
                disabled={!targetSystemId}
                onClick={() => {
                  playHyperspaceJump();
                  onDispatchFleet(selectedFleet.fleetId, targetSystemId);
                  setDispatchModalOpen(false);
                }}
                className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold"
              >
                ENGAGE HYPERDRIVE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
