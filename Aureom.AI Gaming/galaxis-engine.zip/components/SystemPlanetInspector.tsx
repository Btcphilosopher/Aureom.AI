'use client';

import React, { useState } from 'react';
import { GalaxyState, PlanetState, ShipClass } from '../lib/galaxis/types';
import { STAR_WARS_SHIP_SPECS } from '../lib/galaxis/data';
import { playButtonBeep, playLaserBlaster } from '../lib/galaxis/audio';
import { Compass, Shield, Users, Factory, Pickaxe, Hammer, Anchor, AlertCircle, Plus } from 'lucide-react';

interface PlanetInspectorProps {
  state: GalaxyState;
  selectedSystemId: string;
  onSelectSystem: (sysId: string) => void;
  playerFactionId: string;
  onBuildShip: (planetId: string, shipClass: ShipClass) => void;
}

export const SystemPlanetInspector: React.FC<PlanetInspectorProps> = ({
  state,
  selectedSystemId,
  onSelectSystem,
  playerFactionId,
  onBuildShip
}) => {
  const system = state.systems[selectedSystemId] || Object.values(state.systems)[0];
  const [selectedPlanetIndex, setSelectedPlanetIndex] = useState(0);
  const planet: PlanetState | undefined = system?.planets[selectedPlanetIndex] || system?.planets[0];

  if (!system || !planet) {
    return <div className="p-8 text-center text-cyan-400 font-mono">Select a Star System to inspect planetary colonies.</div>;
  }

  const isPlayerOwned = planet.ownerFaction === playerFactionId;

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Top System Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg">
        <div className="flex items-center gap-3">
          <Compass className="text-cyan-400" size={24} />
          <div>
            <div className="text-[10px] text-cyan-500 uppercase tracking-widest">{system.region} SECTOR</div>
            <h1 className="text-xl font-bold text-cyan-200">{system.name} STAR SYSTEM</h1>
          </div>
        </div>

        {/* Quick System Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">JUMP TO:</span>
          <select
            value={system.systemId}
            onChange={(e) => {
              playButtonBeep();
              onSelectSystem(e.target.value);
            }}
            className="bg-slate-900 border border-cyan-800 rounded px-3 py-1 text-xs text-cyan-300 focus:outline-none"
          >
            {Object.values(state.systems).map(s => (
              <option key={s.systemId} value={s.systemId}>
                {s.name} ({s.region})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Planetary Tabs (if multiple planets in system) */}
      <div className="flex gap-2 border-b border-cyan-950 pb-2 overflow-x-auto">
        {system.planets.map((p, idx) => (
          <button
            key={p.planetId}
            onClick={() => {
              playButtonBeep();
              setSelectedPlanetIndex(idx);
            }}
            className={`px-4 py-2 rounded-t-md text-xs font-bold transition-all border-b-2 ${
              idx === selectedPlanetIndex
                ? 'bg-cyan-950/70 border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-cyan-200'
            }`}
          >
            {p.name} [{p.planetType}]
          </button>
        ))}
      </div>

      {/* Main Colony Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Planetary Metadata & Demographics */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-5 rounded-lg space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-bold text-cyan-200">{planet.name}</h2>
                <div className="text-xs text-slate-400">{planet.climate}</div>
              </div>
              <span className="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-[10px] text-cyan-400">
                {planet.developmentTier}
              </span>
            </div>
            <div className="mt-2 text-xs flex justify-between">
              <span className="text-slate-400">Controlling Faction:</span>
              <span className="font-bold text-amber-300">
                {state.factions[planet.ownerFaction]?.name || planet.ownerFaction}
              </span>
            </div>
          </div>

          {/* Core Metrics Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">POPULATION</div>
              <div className="text-base font-bold text-slate-100">{planet.population.toLocaleString()}</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">STABILITY</div>
              <div className={`text-base font-bold ${planet.stability > 70 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {planet.stability}%
              </div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">LOYALTY</div>
              <div className="text-base font-bold text-cyan-300">{planet.loyalty}%</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">CRIME INDEX</div>
              <div className={`text-base font-bold ${planet.crime < 30 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {planet.crime}%
              </div>
            </div>
          </div>

          {/* Resistance Meter */}
          <div className="bg-slate-900/90 p-3 rounded border border-rose-950 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">RESISTANCE STAGE:</span>
              <span className={`font-bold ${planet.resistanceStage === 'CONTENT' ? 'text-emerald-400' : 'text-rose-400'}`}>
                {planet.resistanceStage}
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-rose-500 h-full transition-all duration-300"
                style={{ width: `${Math.min(100, planet.resistancePoints)}%` }}
              ></div>
            </div>
            <div className="text-[10px] text-slate-400 text-right">
              {planet.resistancePoints.toFixed(1)} / 100.0 Rebellion Threshold
            </div>
          </div>

          {/* Planetary Ratings */}
          <div className="space-y-2 text-xs">
            <div className="text-slate-400 text-[10px] uppercase font-bold">Industrial Yields</div>
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="flex items-center gap-1.5"><Factory size={12} className="text-blue-400" /> Industry</span>
                <span className="text-blue-300">{planet.industry}/100</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="flex items-center gap-1.5"><Pickaxe size={12} className="text-amber-400" /> Mining</span>
                <span className="text-amber-300">{planet.mining}/100</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="flex items-center gap-1.5"><Hammer size={12} className="text-emerald-400" /> Agriculture</span>
                <span className="text-emerald-300">{planet.agriculture}/100</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center Column: Commodity Stockpiles & Spaceport */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-5 rounded-lg space-y-4">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
              <Anchor size={16} /> SPACEPORT & SHIPYARD DOCKS
            </h3>
            <span className="text-xs text-slate-400">Cap: {planet.spaceport.capacity} Docks</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">SHIPYARD SLOTS</div>
              <div className="text-cyan-300 font-bold">{planet.spaceport.shipyardCapacity} Berths</div>
            </div>
            <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">FUEL RESERVE</div>
              <div className="text-amber-300 font-bold">{planet.spaceport.fuelStockpile} Units</div>
            </div>
          </div>

          {/* Commodity Stockpiles Table */}
          <div className="space-y-2">
            <div className="text-slate-400 text-[10px] uppercase font-bold">Local Commodity Stockpiles & Prices</div>
            <div className="max-h-56 overflow-y-auto space-y-1 pr-1 text-xs">
              {Object.entries(planet.commodityStockpiles || {}).map(([comm, stock]) => {
                const price = planet.commodityPrices?.[comm] || 50;
                return (
                  <div key={comm} className="flex justify-between items-center bg-slate-900/60 px-2.5 py-1.5 rounded border border-slate-800/80 text-[11px]">
                    <span className="text-slate-300">{comm}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">{Math.round(stock)} units</span>
                      <span className="text-amber-300 font-bold font-mono">{price} ⬡</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Shipyard Construction Queue */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-5 rounded-lg space-y-4">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
              <Factory size={16} /> SHIP CONSTRUCTION BERTHS
            </h3>
          </div>

          {isPlayerOwned ? (
            <div className="space-y-3">
              <div className="text-slate-400 text-xs">Authorise naval vessel construction at this drydock:</div>
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {(['FIGHTER', 'CORVETTE', 'FRIGATE', 'DESTROYER', 'CRUISER'] as ShipClass[]).map(sClass => {
                  const spec = STAR_WARS_SHIP_SPECS[sClass];
                  return (
                    <div key={sClass} className="bg-slate-900/90 border border-slate-800 p-2.5 rounded space-y-1.5 text-xs">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-cyan-200">{spec.name}</span>
                        <span className="text-amber-300 font-mono font-bold">{spec.cost.toLocaleString()} ⬡</span>
                      </div>
                      <div className="text-[10px] text-slate-400">
                        FP: <span className="text-rose-400">{spec.firepower}</span> | Shields: <span className="text-cyan-400">{spec.shields}</span> | Hull: <span className="text-slate-300">{spec.hull}</span>
                      </div>
                      <button
                        onClick={() => {
                          playLaserBlaster();
                          onBuildShip(planet.planetId, sClass);
                        }}
                        className="w-full py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-[11px] transition-colors flex items-center justify-center gap-1"
                      >
                        <Plus size={12} /> CONSTRUCT VESSEL
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="p-4 bg-slate-900/40 border border-slate-800 rounded text-center text-xs text-slate-400">
              <AlertCircle size={20} className="mx-auto text-amber-500 mb-2" />
              You do not control this planetary shipyard.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
