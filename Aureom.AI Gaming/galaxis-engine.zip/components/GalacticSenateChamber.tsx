'use client';

import React, { useState } from 'react';
import { GalaxyState, SenateBill } from '../lib/galaxis/types';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { Landmark, Plus, CheckCircle, XCircle, Users, ThumbsUp, ThumbsDown } from 'lucide-react';

interface SenateProps {
  state: GalaxyState;
  playerFactionId: string;
  onProposeBill: (title: string, description: string) => void;
  onVoteBill: (billId: string, isFor: boolean) => void;
}

export const GalacticSenateChamber: React.FC<SenateProps> = ({
  state,
  playerFactionId,
  onProposeBill,
  onVoteBill
}) => {
  const [billTitle, setBillTitle] = useState<string>('');
  const [billDesc, setBillDesc] = useState<string>('');

  const playerFaction = state.factions[playerFactionId];
  const totalDelegates = Object.values(state.factions).reduce((sum, f) => sum + f.senateDelegates, 0);

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Senate Chamber Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex flex-wrap justify-between items-center gap-4">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">CORUSCANT ROTUNDA ASSEMBLY</div>
          <h1 className="text-xl font-bold text-cyan-200">THE GALACTIC SENATE & DELEGATIONS</h1>
        </div>
        <div className="flex gap-3 text-xs">
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Your Delegation: </span>
            <span className="text-cyan-300 font-bold">{playerFaction?.senateDelegates || 0} Reps</span>
          </div>
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Total Chamber Seats: </span>
            <span className="text-slate-200 font-bold">{totalDelegates}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active & Historical Senate Bills */}
        <div className="lg:col-span-2 bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <Landmark size={14} className="text-cyan-400" />
            Active Floor Resolutions on Docket
          </div>

          <div className="space-y-3">
            {state.senateBills.map(bill => {
              const totalVotes = bill.votesFor + bill.votesAgainst;
              const forPct = totalVotes > 0 ? (bill.votesFor / totalVotes) * 100 : 50;

              return (
                <div key={bill.billId} className="bg-slate-900/80 border border-slate-800 p-4 rounded-lg space-y-3 text-xs">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-sm font-bold text-cyan-200">{bill.title}</h3>
                      <div className="text-[10px] text-slate-400">
                        Sponsor: <span className="text-amber-400">{state.factions[bill.sponsorFaction]?.name || bill.sponsorFaction}</span> | Remaining: {bill.turnRemaining} Ticks
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                      bill.status === 'PASSED'
                        ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                        : bill.status === 'REJECTED'
                        ? 'bg-rose-950 border-rose-600 text-rose-300'
                        : 'bg-cyan-950 border-cyan-600 text-cyan-300'
                    }`}>
                      {bill.status}
                    </span>
                  </div>

                  <p className="text-slate-300 text-[11px] leading-relaxed">{bill.description}</p>

                  {/* Vote bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px]">
                      <span className="text-emerald-400 font-bold">{bill.votesFor} For ({forPct.toFixed(0)}%)</span>
                      <span className="text-rose-400 font-bold">{bill.votesAgainst} Against ({(100 - forPct).toFixed(0)}%)</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex">
                      <div className="bg-emerald-500 h-full" style={{ width: `${forPct}%` }}></div>
                      <div className="bg-rose-500 h-full" style={{ width: `${100 - forPct}%` }}></div>
                    </div>
                  </div>

                  {/* Vote Action Buttons (if active) */}
                  {bill.status === 'ACTIVE' && (
                    <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                      <button
                        onClick={() => {
                          playButtonBeep();
                          onVoteBill(bill.billId, true);
                        }}
                        className="px-3 py-1 bg-emerald-700/80 hover:bg-emerald-600 text-white rounded text-[11px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <ThumbsUp size={12} /> VOTE FOR (+{playerFaction?.senateDelegates || 10})
                      </button>
                      <button
                        onClick={() => {
                          playButtonBeep();
                          onVoteBill(bill.billId, false);
                        }}
                        className="px-3 py-1 bg-rose-700/80 hover:bg-rose-600 text-white rounded text-[11px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <ThumbsDown size={12} /> VOTE AGAINST (+{playerFaction?.senateDelegates || 10})
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Sponsor New Bill */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex items-center gap-2">
            <Plus size={16} className="text-cyan-400" />
            <h3 className="font-bold text-cyan-200">SPONSOR SENATE RESOLUTION</h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] text-slate-400">Resolution Title:</label>
              <input
                type="text"
                value={billTitle}
                placeholder="e.g. Outer Rim Hyperlane Security Pact"
                onChange={(e) => setBillTitle(e.target.value)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-2 text-cyan-200 focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400">Bill Description & Statutory Mandates:</label>
              <textarea
                rows={4}
                value={billDesc}
                placeholder="Describe statutory taxes, trade embargoes, or mutual defense subsidies..."
                onChange={(e) => setBillDesc(e.target.value)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-2 text-cyan-200 focus:outline-none text-xs"
              />
            </div>

            <button
              disabled={!billTitle.trim()}
              onClick={() => {
                playTacticalPing();
                onProposeBill(billTitle, billDesc || 'Statutory mandate registered with the Grand Convocation.');
                setBillTitle('');
                setBillDesc('');
              }}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <Landmark size={14} /> TABLE BEFORE ROTUNDA
            </button>
          </div>

          {/* Faction Delegates Breakdown */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Chamber Delegation Blocs</div>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {Object.values(state.factions).map(f => (
                <div key={f.factionId} className="flex justify-between items-center text-[11px] bg-slate-900/60 px-2 py-1 rounded">
                  <span className="text-slate-300">{f.name}</span>
                  <span className="text-cyan-300 font-bold">{f.senateDelegates} Seats</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
