'use client';

import React, { useState } from 'react';
import { GalaxyState, Commodity, TradeRoute } from '../lib/galaxis/types';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { TrendingUp, Plus, ShieldCheck, AlertTriangle, ArrowRight, DollarSign, Package } from 'lucide-react';

interface EconomyPanelProps {
  state: GalaxyState;
  playerFactionId: string;
  onCreateTradeRoute: (originSys: string, destSys: string, commodity: Commodity, isSmuggling: boolean) => void;
}

const ALL_COMMODITIES: { id: Commodity; label: string; desc: string }[] = [
  { id: 'FOOD', label: 'Agricultural Provisions', desc: 'Nutritional rations for core & frontier populations' },
  { id: 'FUEL', label: 'Refined Tibanna & Coaxium', desc: 'Sub-light propellants & hyperdrive fuel' },
  { id: 'METALS', label: 'Doonium & Durasteel', desc: 'Structural alloy for capital ships & orbital habitats' },
  { id: 'RARE_METALS', label: 'Beskar & Phrik Ore', desc: 'Lightsaber-resistant superalloys' },
  { id: 'SPARE_PARTS', label: 'Mechanic Sub-assemblies', desc: 'Navicomputers, servomotors, repulsorlift coils' },
  { id: 'MEDICINES', label: 'Bacta & Kolto Vials', desc: 'Cellular regeneration fluid & triage medicine' },
  { id: 'LUXURY_GOODS', label: 'Chandrilan Wines & Fine Silks', desc: 'High society cultural luxuries' },
  { id: 'DROID_COMPONENTS', label: 'Astromech & Protocol Brains', desc: 'Autonomous heuristic processors' },
  { id: 'SHIP_COMPONENTS', label: 'Deflector Arrays & Turbines', desc: 'Heavy starship subsystem modules' },
  { id: 'WEAPONS', label: 'Kyber Blasters & Torpedoes', desc: 'Military armament & munitions' },
  { id: 'RAW_MATERIALS', label: 'Unprocessed Silicates', desc: 'Base minerals for heavy foundries' },
  { id: 'HYPERDRIVE_COMPONENTS', label: 'Hyperdrive Motivators', desc: 'Precision relativistic jump cores' },
];

export const EconomyTradePanel: React.FC<EconomyPanelProps> = ({
  state,
  playerFactionId,
  onCreateTradeRoute
}) => {
  const [originSys, setOriginSys] = useState<string>('CORUSCANT');
  const [destSys, setDestSys] = useState<string>('KUAT');
  const [commodity, setCommodity] = useState<Commodity>('FOOD');
  const [isSmuggling, setIsSmuggling] = useState<boolean>(false);

  const playerRoutes = Object.values(state.tradeRoutes).filter(r => r.ownerFaction === playerFactionId);
  const totalTradeIncome = playerRoutes.reduce((sum, r) => sum + (r.isDisrupted ? 0 : r.profitPerTick), 0);

  // Compute Galactic Average Price for each commodity
  const avgPrices: Record<string, number> = {};
  for (const comm of ALL_COMMODITIES) {
    let sum = 0;
    let count = 0;
    for (const sys of Object.values(state.systems)) {
      for (const p of sys.planets) {
        if (p.commodityPrices && p.commodityPrices[comm.id]) {
          sum += p.commodityPrices[comm.id];
          count += 1;
        }
      }
    }
    avgPrices[comm.id] = count > 0 ? Math.round(sum / count) : 50;
  }

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Economy Overview Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex flex-wrap justify-between items-center gap-4">
        <div>
          <div className="text-[10px] text-cyan-500 uppercase tracking-widest">GALACTIC COMMERCE COMMISSION</div>
          <h1 className="text-xl font-bold text-cyan-200">INTERSTELLAR TRADE & COMMODITY INDEX</h1>
        </div>
        <div className="flex gap-4 text-xs">
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Total Trade Inflow: </span>
            <span className="text-emerald-400 font-bold">+{totalTradeIncome.toLocaleString()} ⬡/tick</span>
          </div>
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-slate-400">Active Freighters: </span>
            <span className="text-cyan-300 font-bold">{playerRoutes.reduce((s, r) => s + r.assignedFreighters, 0)}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Galactic 12 Commodity Price Board */}
        <div className="lg:col-span-2 bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <TrendingUp size={14} className="text-cyan-400" />
            Galactic 12 Commodity Price Exchange (Supply / Demand Equilibrium)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
            {ALL_COMMODITIES.map(c => {
              const avg = avgPrices[c.id] || 50;
              return (
                <div key={c.id} className="bg-slate-900/70 p-2.5 rounded border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-cyan-300">{c.label}</span>
                    <span className="font-mono font-bold text-amber-300">{avg} ⬡</span>
                  </div>
                  <div className="text-[10px] text-slate-400">{c.desc}</div>
                  <div className="flex justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/80">
                    <span>Key Exporters: Core / Industrial</span>
                    <span className={avg > 60 ? 'text-rose-400' : 'text-emerald-400'}>
                      {avg > 60 ? '▲ High Scarcity' : '▼ Stable Surplus'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Trade Route Creator */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3 flex items-center gap-2">
            <Plus size={16} className="text-cyan-400" />
            <h3 className="font-bold text-cyan-200">ESTABLISH TRADE CORRIDOR</h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] text-slate-400">Origin Export System:</label>
              <select
                value={originSys}
                onChange={(e) => setOriginSys(e.target.value)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-1.5 text-cyan-200 focus:outline-none text-xs"
              >
                {Object.values(state.systems).map(s => (
                  <option key={s.systemId} value={s.systemId}>{s.name} ({s.region})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400">Destination Import Market:</label>
              <select
                value={destSys}
                onChange={(e) => setDestSys(e.target.value)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-1.5 text-cyan-200 focus:outline-none text-xs"
              >
                {Object.values(state.systems).filter(s => s.systemId !== originSys).map(s => (
                  <option key={s.systemId} value={s.systemId}>{s.name} ({s.region})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400">Commodity Cargo:</label>
              <select
                value={commodity}
                onChange={(e) => setCommodity(e.target.value as Commodity)}
                className="w-full bg-slate-900 border border-cyan-800 rounded p-1.5 text-cyan-200 focus:outline-none text-xs"
              >
                {ALL_COMMODITIES.map(c => (
                  <option key={c.id} value={c.id}>{c.label}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="smuggling"
                checked={isSmuggling}
                onChange={(e) => setIsSmuggling(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <label htmlFor="smuggling" className="text-slate-300 cursor-pointer">
                Route through Shadow / Smuggler Channels (+40% Profit, High Risk)
              </label>
            </div>

            <button
              onClick={() => {
                playTacticalPing();
                onCreateTradeRoute(originSys, destSys, commodity, isSmuggling);
              }}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <Package size={14} /> COMMISSION TRADE CONVOY
            </button>
          </div>

          {/* Active Player Trade Routes */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Commissioned Routes ({playerRoutes.length})</div>
            {playerRoutes.length === 0 ? (
              <div className="text-slate-500 italic text-[11px]">No active trade routes.</div>
            ) : (
              playerRoutes.map(r => (
                <div key={r.routeId} className="bg-slate-900/80 p-2 rounded border border-slate-800 text-[11px] space-y-1">
                  <div className="flex justify-between items-center text-cyan-300">
                    <span>{state.systems[r.originSystemId]?.name} → {state.systems[r.destinationSystemId]?.name}</span>
                    <span className="text-emerald-400 font-bold font-mono">+{r.profitPerTick} ⬡</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Cargo: {r.commodity}</span>
                    <span className={r.isSmuggling ? 'text-amber-400' : 'text-cyan-400'}>
                      {r.isSmuggling ? 'Shadow Smuggling' : 'Standard Convoy'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
