'use client';

import React from 'react';
import { 
  Play, Pause, FastForward, Volume2, VolumeX, Shield, Terminal, 
  Globe, Compass, Anchor, TrendingUp, Landmark, Flame, Eye, Cpu, BookOpen, BarChart2
} from 'lucide-react';
import { GalaxyState, GalacticEra } from '../lib/galaxis/types';
import { playButtonBeep } from '../lib/galaxis/audio';

interface NavbarProps {
  state: GalaxyState;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onTogglePause: () => void;
  onSetSpeed: (speed: number) => void;
  onStepTick: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  isCrtEnabled: boolean;
  onToggleCrt: () => void;
  playerFactionId: string;
  onSelectPlayerFaction: (factionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  state,
  activeTab,
  setActiveTab,
  onTogglePause,
  onSetSpeed,
  onStepTick,
  isMuted,
  onToggleMute,
  isCrtEnabled,
  onToggleCrt,
  playerFactionId,
  onSelectPlayerFaction
}) => {
  const playerFaction = state.factions[playerFactionId] || Object.values(state.factions)[0];

  const tabs = [
    { id: 'map', label: 'HoloMap', icon: Globe },
    { id: 'planets', label: 'Planets', icon: Compass },
    { id: 'fleets', label: 'Fleet Command', icon: Anchor },
    { id: 'economy', label: 'Economy & Trade', icon: TrendingUp },
    { id: 'senate', label: 'Senate', icon: Landmark },
    { id: 'combat', label: 'Combat Theater', icon: Flame },
    { id: 'force', label: 'The Force', icon: Shield },
    { id: 'espionage', label: 'Shadow Net', icon: Eye },
    { id: 'research', label: 'Tech Matrix', icon: Cpu },
    { id: 'chronicles', label: 'HoloNet & Lore', icon: BookOpen },
    { id: 'balance', label: 'Benchmark', icon: BarChart2 },
    { id: 'terminal', label: 'Python CLI', icon: Terminal },
  ];

  return (
    <header className="bg-slate-950/90 backdrop-blur-md border-b border-cyan-900/60 sticky top-0 z-50 text-cyan-100 select-none">
      {/* Top Strategic Status Ribbon */}
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs border-b border-slate-800/80">
        {/* Brand & Era */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#22d3ee]"></span>
            <span className="font-mono font-black tracking-widest text-sm text-cyan-300">GALAXIS</span>
            <span className="text-slate-500 font-mono">| STAR WARS 4X ENGINE</span>
          </div>
          <span className="px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 text-[10px] font-mono text-cyan-400 tracking-wider">
            {state.era}
          </span>
        </div>

        {/* Player Faction Selector & Strategic Metrics */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800">
            <span className="text-slate-400">FACTION:</span>
            <select
              value={playerFactionId}
              onChange={(e) => {
                playButtonBeep();
                onSelectPlayerFaction(e.target.value);
              }}
              className="bg-transparent text-cyan-300 font-semibold focus:outline-none cursor-pointer"
            >
              {Object.values(state.factions).map(f => (
                <option key={f.factionId} value={f.factionId} className="bg-slate-900 text-slate-100">
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800 font-mono">
            <span className="text-amber-400">CREDITS:</span>
            <span className="text-amber-300 font-bold">{Math.round(playerFaction.credits).toLocaleString()} ⬡</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800 font-mono">
            <span className="text-blue-400">RESEARCH:</span>
            <span className="text-blue-300">{playerFaction.knownTechnologies.length} Techs</span>
          </div>
        </div>

        {/* Simulation Controls & Calendar Tick */}
        <div className="flex items-center gap-2">
          <div className="font-mono text-xs bg-cyan-950/60 border border-cyan-800/80 px-2.5 py-1 rounded text-cyan-300">
            TICK: <span className="text-white font-bold">{state.calendarTick.toString().padStart(4, '0')}</span>
          </div>

          {/* Pause / Play */}
          <button
            onClick={() => { playButtonBeep(); onTogglePause(); }}
            className={`p-1.5 rounded border transition-colors flex items-center gap-1 ${
              state.isPaused 
                ? 'bg-amber-950/80 border-amber-600 text-amber-300' 
                : 'bg-cyan-950/80 border-cyan-600 text-cyan-300'
            }`}
            title={state.isPaused ? 'Resume Simulation' : 'Pause Simulation'}
          >
            {state.isPaused ? <Play size={14} /> : <Pause size={14} />}
          </button>

          {/* Step 1 Tick */}
          <button
            onClick={() => { playButtonBeep(); onStepTick(); }}
            className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-[11px] font-mono text-cyan-300"
            title="Step 1 Tick"
          >
            +1T
          </button>

          {/* Speed Buttons */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded overflow-hidden">
            {[1, 2, 4, 16].map((spd) => (
              <button
                key={spd}
                onClick={() => { playButtonBeep(); onSetSpeed(spd); }}
                className={`px-2 py-1 text-[10px] font-mono transition-colors ${
                  state.simulationSpeed === spd && !state.isPaused
                    ? 'bg-cyan-600 text-black font-bold'
                    : 'text-slate-400 hover:text-cyan-200'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>

          {/* Audio Toggle */}
          <button
            onClick={() => { playButtonBeep(); onToggleMute(); }}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-slate-300"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>

          {/* CRT Scanline Toggle */}
          <button
            onClick={() => { playButtonBeep(); onToggleCrt(); }}
            className={`px-2 py-1 rounded text-[10px] font-mono border ${
              isCrtEnabled ? 'bg-cyan-950 border-cyan-500 text-cyan-300' : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            CRT
          </button>
        </div>
      </div>

      {/* Main Tab Navigation Bar */}
      <nav className="max-w-7xl mx-auto px-2 flex items-center overflow-x-auto scrollbar-none gap-1 py-1 text-xs">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => { playButtonBeep(); setActiveTab(tab.id); }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-t-md font-mono transition-all whitespace-nowrap border-b-2 ${
                isActive
                  ? 'bg-cyan-950/60 border-cyan-400 text-cyan-200 font-bold shadow-[0_2px_8px_rgba(6,182,212,0.2)]'
                  : 'border-transparent text-slate-400 hover:text-cyan-300 hover:bg-slate-900/60'
              }`}
            >
              <Icon size={14} className={isActive ? 'text-cyan-400' : 'text-slate-500'} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
