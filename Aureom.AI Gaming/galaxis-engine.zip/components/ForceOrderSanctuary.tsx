'use client';

import React, { useState } from 'react';
import { GalaxyState, CharacterState, ForceAlignment } from '../lib/galaxis/types';
import { playButtonBeep, playTacticalPing } from '../lib/galaxis/audio';
import { Shield, Sparkles, BookOpen, UserPlus, Flame } from 'lucide-react';

interface ForceSanctuaryProps {
  state: GalaxyState;
  playerFactionId: string;
}

export const ForceOrderSanctuary: React.FC<ForceSanctuaryProps> = ({ state, playerFactionId }) => {
  const forceCharacters = Object.values(state.characters).filter(c => c.force.isSensitive);
  const [selectedCharId, setSelectedCharId] = useState<string>(forceCharacters[0]?.characterId || '');
  const [meditationLog, setMeditationLog] = useState<string | null>(null);

  const activeChar = state.characters[selectedCharId] || forceCharacters[0];

  const handleMeditate = () => {
    if (!activeChar) return;
    playTacticalPing();
    const isDark = activeChar.force.alignment === 'DARK';
    setMeditationLog(
      isDark
        ? `${activeChar.name} channeled the Dark Side on Korriban. Mastered Dark Telekinesis and +5 Force Intimidation!`
        : `${activeChar.name} communed with the Living Force in the Jedi Temple. Acquired ancient Holocron wisdom and +5 Battle Meditation!`
    );
  };

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex justify-between items-center">
        <div>
          <div className="text-[10px] text-purple-400 uppercase tracking-widest">MYSTIC ARCHIVES OF THE COSMOS</div>
          <h1 className="text-xl font-bold text-purple-300">THE LIVING FORCE & ANCIENT ORDERS</h1>
        </div>
        <div className="flex gap-4 text-xs">
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-blue-400">Jedi Influence: </span>
            <span className="text-white font-bold">{state.forceOrders['JEDI_ORDER']?.influence || 50}%</span>
          </div>
          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <span className="text-rose-400">Sith Influence: </span>
            <span className="text-white font-bold">{state.forceOrders['SITH_ORDER']?.influence || 50}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Force Adepts Roster */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Identified Force-Sensitives</div>
          <div className="space-y-2">
            {forceCharacters.map(char => {
              const isSelected = char.characterId === activeChar?.characterId;
              const isDark = char.force.alignment === 'DARK';
              return (
                <div
                  key={char.characterId}
                  onClick={() => {
                    playButtonBeep();
                    setSelectedCharId(char.characterId);
                  }}
                  className={`p-3 rounded border cursor-pointer transition-all space-y-1 text-xs ${
                    isSelected
                      ? isDark
                        ? 'bg-rose-950/60 border-rose-500 text-rose-200'
                        : 'bg-cyan-950/60 border-cyan-400 text-cyan-200'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">{char.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      isDark ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-blue-950 text-blue-400 border border-blue-800'
                    }`}>
                      {char.force.alignment} SIDE
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Order: <span className="text-slate-300">{char.force.orderAffiliation || 'Independent'}</span> | Location: {char.locationSystemId}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center & Right 2 Cols: Character Profile & Holocron Meditation */}
        <div className="lg:col-span-2 bg-slate-950/80 border border-cyan-900/60 p-5 rounded-lg space-y-4">
          {activeChar ? (
            <>
              <div className="border-b border-slate-800 pb-3 flex justify-between items-start">
                <div>
                  <h2 className="text-lg font-bold text-slate-100">{activeChar.name}</h2>
                  <div className="text-xs text-slate-400">
                    Species: <span className="text-slate-300">{activeChar.species}</span> | Age: {activeChar.age} | Faction: {state.factions[activeChar.faction]?.name || activeChar.faction}
                  </div>
                </div>
                <button
                  onClick={handleMeditate}
                  className="px-4 py-1.5 rounded bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-[0_0_8px_rgba(168,85,247,0.4)]"
                >
                  <Sparkles size={14} /> INITIATE FORCE MEDITATION
                </button>
              </div>

              {/* Force Alignment Spectrum */}
              <div className="space-y-2 bg-slate-900/70 p-3 rounded border border-slate-800 text-xs">
                <div className="flex justify-between">
                  <span className="text-blue-400 font-bold">LIGHT SIDE (Ashla)</span>
                  <span className="text-rose-400 font-bold">DARK SIDE (Bogan)</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden flex">
                  <div
                    className="bg-blue-500 h-full transition-all"
                    style={{ width: `${100 - activeChar.force.darkSideCorruption}%` }}
                  ></div>
                  <div
                    className="bg-rose-600 h-full transition-all"
                    style={{ width: `${activeChar.force.darkSideCorruption}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Sensitivity Score: {activeChar.force.sensitivityScore}/100</span>
                  <span>Mastery: {activeChar.force.mastery}/100</span>
                </div>
              </div>

              {/* Known Abilities */}
              <div className="space-y-2 text-xs">
                <div className="text-[10px] font-bold text-slate-400 uppercase">Disciplines & Force Powers</div>
                <div className="flex flex-wrap gap-2">
                  {activeChar.force.abilities.map(ab => (
                    <span key={ab} className="px-3 py-1 rounded bg-purple-950/80 border border-purple-800 text-purple-200 text-xs font-semibold">
                      ✧ {ab}
                    </span>
                  ))}
                </div>
              </div>

              {/* Meditation result notification */}
              {meditationLog && (
                <div className="p-3 bg-purple-950/60 border border-purple-600 rounded text-xs text-purple-200 leading-relaxed animate-pulse">
                  🔮 {meditationLog}
                </div>
              )}
            </>
          ) : (
            <div className="text-slate-500 text-xs italic text-center p-8">No Force Adept selected.</div>
          )}
        </div>
      </div>
    </div>
  );
};
