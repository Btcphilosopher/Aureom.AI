'use client';

import React, { useState } from 'react';
import { GalaxyState, FleetState } from '../lib/galaxis/types';
import { playLaserBlaster, playAlertSiren, playButtonBeep } from '../lib/galaxis/audio';
import { Flame, Shield, Zap, Skull, Award, RefreshCw } from 'lucide-react';

interface CombatModalProps {
  state: GalaxyState;
  playerFactionId: string;
}

export const CombatTheaterModal: React.FC<CombatModalProps> = ({ state, playerFactionId }) => {
  const [selectedFleetAId, setSelectedFleetAId] = useState<string>(Object.keys(state.fleets)[0] || '');
  const [selectedFleetBId, setSelectedFleetBId] = useState<string>(Object.keys(state.fleets)[1] || '');
  const [battleLogs, setBattleLogs] = useState<string[]>([]);
  const [battleResult, setBattleResult] = useState<string | null>(null);

  const fleetA = state.fleets[selectedFleetAId];
  const fleetB = state.fleets[selectedFleetBId];

  const handleSimulateBattle = () => {
    if (!fleetA || !fleetB) return;
    playAlertSiren();

    const logs: string[] = [];
    logs.push(`=== TACTICAL COMBAT INITIATED: ${fleetA.name} VS ${fleetB.name} ===`);
    logs.push(`STAGE 1: Sensor Sweeps & Astrogation Intercept locked in ${fleetA.locationSystemId}.`);

    const pwrA = fleetA.ships.reduce((s, sh) => s + sh.firepower, 0);
    const pwrB = fleetB.ships.reduce((s, sh) => s + sh.firepower, 0);

    logs.push(`STAGE 2: Capital Broadside Exchanges — Fleet A (${pwrA} FP) vs Fleet B (${pwrB} FP).`);

    const rollA = Math.random() * pwrA * 1.2;
    const rollB = Math.random() * pwrB * 1.2;

    const dmgToB = Math.round(rollA * 0.35);
    const dmgToA = Math.round(rollB * 0.35);

    logs.push(`STAGE 3: Heavy Turbolaser Impacts! ${fleetA.name} inflicts ${dmgToB} damage on enemy shielding.`);
    logs.push(`STAGE 4: Return Salvo! ${fleetB.name} counters with ${dmgToA} damage.`);

    const winner = rollA >= rollB ? fleetA.ownerFaction : fleetB.ownerFaction;
    const winnerFleet = rollA >= rollB ? fleetA.name : fleetB.name;

    logs.push(`STAGE 5: Aftermath — ${winnerFleet} forces secure orbital dominance. Opposing taskforce initiates emergency retreat.`);

    setBattleLogs(logs);
    setBattleResult(`VICTORY: ${winnerFleet} (${winner})`);
    setTimeout(() => playLaserBlaster(), 400);
  };

  return (
    <div className="space-y-6 font-mono text-cyan-100">
      {/* Header */}
      <div className="bg-slate-950/80 p-4 border border-cyan-900/60 rounded-lg flex justify-between items-center">
        <div>
          <div className="text-[10px] text-rose-500 uppercase tracking-widest">TACTICAL SIMULATION MATRIX</div>
          <h1 className="text-xl font-bold text-rose-300">NAVAL COMBAT THEATER & DOGFIGHT ARENA</h1>
        </div>
        <button
          onClick={handleSimulateBattle}
          disabled={!fleetA || !fleetB || fleetA.fleetId === fleetB.fleetId}
          className="px-5 py-2 rounded bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold text-xs transition-colors flex items-center gap-2 shadow-[0_0_12px_rgba(244,63,94,0.4)]"
        >
          <Flame size={16} /> ENGAGE FLEET CLASH
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Attacking Taskforce Select */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-cyan-400">TASKFORCE ALPHA</span>
            <select
              value={selectedFleetAId}
              onChange={(e) => setSelectedFleetAId(e.target.value)}
              className="bg-slate-900 border border-cyan-800 rounded p-1 text-cyan-200 text-xs focus:outline-none"
            >
              {Object.values(state.fleets).map(f => (
                <option key={f.fleetId} value={f.fleetId}>{f.name} ({f.ownerFaction})</option>
              ))}
            </select>
          </div>

          {fleetA && (
            <div className="bg-slate-900/60 p-3 rounded border border-slate-800 space-y-2 text-xs">
              <div className="text-slate-300 font-bold">{fleetA.name}</div>
              <div className="text-slate-400 text-[11px]">Location: {fleetA.locationSystemId} | Morale: {fleetA.morale}%</div>
              <div className="text-[11px] text-rose-400">
                Total Firepower: <span className="font-bold">{fleetA.ships.reduce((s, sh) => s + sh.firepower, 0)}</span> FP
              </div>
              <div className="space-y-1 pt-2 border-t border-slate-800 max-h-36 overflow-y-auto">
                {fleetA.ships.map(s => (
                  <div key={s.shipId} className="flex justify-between text-[10px] text-slate-300">
                    <span>{s.name} ({s.shipClass})</span>
                    <span className="text-cyan-400">HP: {s.hullCurrent} / Sh: {s.shieldsCurrent}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Defending Taskforce Select */}
        <div className="bg-slate-950/80 border border-cyan-900/60 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-rose-400">TASKFORCE OMEGA</span>
            <select
              value={selectedFleetBId}
              onChange={(e) => setSelectedFleetBId(e.target.value)}
              className="bg-slate-900 border border-cyan-800 rounded p-1 text-cyan-200 text-xs focus:outline-none"
            >
              {Object.values(state.fleets).map(f => (
                <option key={f.fleetId} value={f.fleetId}>{f.name} ({f.ownerFaction})</option>
              ))}
            </select>
          </div>

          {fleetB && (
            <div className="bg-slate-900/60 p-3 rounded border border-slate-800 space-y-2 text-xs">
              <div className="text-slate-300 font-bold">{fleetB.name}</div>
              <div className="text-slate-400 text-[11px]">Location: {fleetB.locationSystemId} | Morale: {fleetB.morale}%</div>
              <div className="text-[11px] text-rose-400">
                Total Firepower: <span className="font-bold">{fleetB.ships.reduce((s, sh) => s + sh.firepower, 0)}</span> FP
              </div>
              <div className="space-y-1 pt-2 border-t border-slate-800 max-h-36 overflow-y-auto">
                {fleetB.ships.map(s => (
                  <div key={s.shipId} className="flex justify-between text-[10px] text-slate-300">
                    <span>{s.name} ({s.shipClass})</span>
                    <span className="text-cyan-400">HP: {s.hullCurrent} / Sh: {s.shieldsCurrent}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Battle Log Terminal */}
      <div className="bg-slate-950/90 border border-slate-800 p-4 rounded-lg space-y-2">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <span className="text-xs font-bold text-slate-400 uppercase">Live Battle Telegraph Logs</span>
          {battleResult && (
            <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              {battleResult}
            </span>
          )}
        </div>

        <div className="min-h-48 max-h-64 overflow-y-auto bg-black/60 p-3 rounded border border-slate-900 space-y-1 text-xs font-mono text-cyan-300">
          {battleLogs.length === 0 ? (
            <div className="text-slate-600 italic">No combat engagements simulated. Select taskforces and press ENGAGE.</div>
          ) : (
            battleLogs.map((log, idx) => (
              <div key={idx} className="leading-relaxed">
                <span className="text-slate-500">[{new Date().toLocaleTimeString()}]</span> {log}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
