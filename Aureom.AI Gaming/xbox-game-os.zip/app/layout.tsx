import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aureom Game OS',
  description: 'Foundational operating system, runtime, developer SDK, and console simulation platform for the Aureom gaming ecosystem.',
  openGraph: {
    title: 'Aureom Game OS',
    description: 'Foundational operating system, runtime, developer SDK, and console simulation platform for the Aureom gaming ecosystem.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aureom Game OS',
    description: 'Foundational operating system, runtime, developer SDK, and console simulation platform for the Aureom gaming ecosystem.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
