'use client';

import React, { useState, useEffect } from 'react';
import {
  Home,
  Play,
  Package,
  ShoppingBag,
  Trophy,
  Users,
  Cloud,
  HardDrive,
  ShieldCheck,
  Terminal as TerminalIcon,
  Layers,
  Cpu,
  Zap,
  Flame,
  Volume2,
  VolumeX,
  Gamepad2,
  Award,
  Bell,
  Sparkles,
} from 'lucide-react';
import { soundEngine } from '@/components/SoundFX';
import CanvasGame from '@/components/CanvasGame';
import HomeView from '@/components/HomeView';
import LibraryView, { CANONICAL_PACKAGES } from '@/components/LibraryView';
import StoreView, { STORE_PRODUCTS } from '@/components/StoreView';
import AchievementsView, { AchievementItem } from '@/components/AchievementsView';
import SocialView from '@/components/SocialView';
import CloudSaveView, { SaveSlotItem } from '@/components/CloudSaveView';
import DigitalTwinView, { SystemProfile } from '@/components/DigitalTwinView';
import CertificationView from '@/components/CertificationView';
import TerminalView from '@/components/TerminalView';
import ArchitectureDocsView from '@/components/ArchitectureDocsView';

const INITIAL_ACHIEVEMENTS: AchievementItem[] = [
  {
    id: 'ach_01',
    gameId: 'aegame.aureom.neon-vanguard',
    title: 'First Quantum Jump',
    description: 'Engage the slipspace drive and leave the Sol quarantine sector.',
    gamerscore: 20,
    unlocked: true,
    unlockedAt: 'Sep 10, 2026',
    progressPct: 100,
  },
  {
    id: 'ach_02',
    gameId: 'aegame.aureom.neon-vanguard',
    title: 'FrameGraph Purity',
    description: 'Maintain 60.0 FPS locked across 1,000 continuous render cycles.',
    gamerscore: 30,
    unlocked: true,
    unlockedAt: 'Sep 11, 2026',
    progressPct: 100,
  },
  {
    id: 'ach_03',
    gameId: 'aegame.aureom.neon-vanguard',
    title: 'Neon Conqueror',
    description: 'Destroy 15 rogue orbital asteroids in the active arena.',
    gamerscore: 50,
    unlocked: false,
    progressPct: 40,
  },
  {
    id: 'ach_04',
    gameId: 'aegame.aureom.neon-vanguard',
    title: 'Zero Memory Leak',
    description: 'Survive 1 hour of intense battle without exceeding the 12 GB title arena.',
    gamerscore: 50,
    unlocked: true,
    unlockedAt: 'Sep 12, 2026',
    progressPct: 100,
  },
  {
    id: 'ach_05',
    gameId: 'aegame.aureom.neon-vanguard',
    title: 'Architect of the Abyss',
    description: 'Secret milestone: Discover the classified jump gate in sector 9.',
    gamerscore: 100,
    unlocked: false,
    hidden: true,
    progressPct: 0,
  },
];

export default function AureomOSPage() {
  const [activeTab, setActiveTab] = useState<string>('HOME');
  const [systemProfile, setSystemProfile] = useState<SystemProfile>('AUREOM_CONSOLE');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [gamerscore, setGamerscore] = useState(1450);
  const [achievements, setAchievements] = useState<AchievementItem[]>(INITIAL_ACHIEVEMENTS);
  const [toastMessage, setToastMessage] = useState<{ title: string; subtitle: string; icon: string } | null>(null);
  const [ownedProducts, setOwnedProducts] = useState<string[]>(['prod_01']);

  // Gamepad Detection
  const [gamepadConnected, setGamepadConnected] = useState(false);

  useEffect(() => {
    const onGamepadConnect = () => setGamepadConnected(true);
    const onGamepadDisconnect = () => setGamepadConnected(false);
    window.addEventListener('gamepadconnected', onGamepadConnect);
    window.addEventListener('gamepaddisconnected', onGamepadDisconnect);
    return () => {
      window.removeEventListener('gamepadconnected', onGamepadConnect);
      window.removeEventListener('gamepaddisconnected', onGamepadDisconnect);
    };
  }, []);

  const triggerToast = (title: string, subtitle: string, icon: string = 'award') => {
    setToastMessage({ title, subtitle, icon });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleUnlockAchievement = (title: string, points: number) => {
    setGamerscore(g => g + points);
    setAchievements(prev =>
      prev.map(a =>
        a.title.toLowerCase().includes(title.toLowerCase()) || a.id === 'ach_03'
          ? { ...a, unlocked: true, unlockedAt: 'Just Now', progressPct: 100 }
          : a
      )
    );
    triggerToast(`Achievement Unlocked! (+${points} G)`, title, 'award');
  };

  const handleSaveCreated = (slot: string, version: number) => {
    triggerToast('Save Snapshot Committed', `${slot} (v${version}) written to WAL & synced`, 'save');
  };

  const handleCrashLogged = (error: string) => {
    triggerToast('Kernel Failsafe Intercepted', error, 'alert');
  };

  const handleProductPurchased = (product: { id: string; title: string }) => {
    setOwnedProducts(prev => [...prev, product.id]);
    triggerToast('Entitlement Granted', `${product.title} added to digital library`, 'store');
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEngine.enabled = next;
    if (next) soundEngine.playSelectBoop();
  };

  const navItems = [
    { id: 'HOME', label: 'Home', icon: Home },
    { id: 'SIMULATOR', label: 'Running Title', icon: Play },
    { id: 'LIBRARY', label: 'Library', icon: Package },
    { id: 'STORE', label: 'Store', icon: ShoppingBag },
    { id: 'ACHIEVEMENTS', label: 'Achievements', icon: Trophy },
    { id: 'SOCIAL', label: 'Social & Voice', icon: Users },
    { id: 'CLOUD_SAVE', label: 'Cloud Save', icon: Cloud },
    { id: 'DIGITAL_TWIN', label: 'Digital Twin', icon: HardDrive },
    { id: 'CERTIFICATION', label: 'Certification', icon: ShieldCheck },
    { id: 'TERMINAL', label: 'Developer CLI', icon: TerminalIcon },
    { id: 'ARCHITECTURE', label: 'Architecture', icon: Layers },
  ];

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* Top System Bar */}
      <header className="sticky top-0 z-40 bg-[#0c101c]/95 backdrop-blur-md border-b border-white/10 px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Brand & Kernel Version */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 to-amber-400 text-black font-black flex items-center justify-center text-sm shadow-md shadow-amber-500/30">
              A
            </div>
            <div>
              <div className="font-extrabold text-white text-sm tracking-tight flex items-center gap-1.5">
                <span>AUREOM GAME OS</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  v1.0.4-LNX
                </span>
              </div>
              <div className="text-[10px] font-mono text-slate-400">
                AUREOM_KERNEL_SIM • {systemProfile}
              </div>
            </div>
          </div>
        </div>

        {/* Live Hardware Telemetry Chips */}
        <div className="hidden md:flex items-center gap-2 text-xs font-mono">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-white/5 text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span>CPU: <b className="text-white">6.7/8c</b></span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-white/5 text-slate-300">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>GPU: <b className="text-white">71.4%</b></span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-white/5 text-slate-300">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>58.2°C</span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-white/5 text-emerald-400 font-bold">
            <span>60.0 FPS</span>
          </div>
        </div>

        {/* Profile Pill & Global Quick Actions */}
        <div className="flex items-center gap-3">
          {/* Gamepad status indicator */}
          <div
            title={gamepadConnected ? 'Controller Connected' : 'Virtual Controller Active'}
            className="flex items-center gap-1 text-xs font-mono text-slate-400"
          >
            <Gamepad2 className={`w-4 h-4 ${gamepadConnected ? 'text-emerald-400' : 'text-slate-500'}`} />
            <span className="hidden sm:inline">{gamepadConnected ? 'Gamepad 1' : 'KB/Mouse'}</span>
          </div>

          {/* Sound Mute Toggle */}
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Mute System Audio' : 'Unmute System Audio'}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* User Profile Chip */}
          <div className="flex items-center gap-2 pl-2 border-l border-white/10">
            <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 font-bold font-mono text-xs flex items-center justify-center border border-amber-500/40">
              AP
            </div>
            <div className="hidden lg:flex flex-col text-left">
              <span className="text-xs font-bold text-white leading-tight">AureomPilot</span>
              <span className="text-[10px] font-mono text-amber-400 leading-none">{gamerscore} G</span>
            </div>
          </div>
        </div>
      </header>

      {/* 10-Foot Navigation Bar */}
      <nav className="bg-[#0b0e17] border-b border-white/10 px-4 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1 py-1.5 min-w-max">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  soundEngine.playNavTick();
                  setActiveTab(item.id);
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all duration-150 ${
                  isActive
                    ? 'bg-amber-500 text-black font-bold shadow-md shadow-amber-500/20 scale-[1.02]'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-black' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Main Content View Container */}
      <main className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto">
        {activeTab === 'HOME' && (
          <HomeView
            onNavigate={setActiveTab}
            gamerscore={gamerscore}
            recentGames={[
              {
                id: 'aegame.aureom.neon-vanguard',
                title: 'Neon Vanguard: Aureom Odyssey',
                genre: 'Sci-Fi Action / Flight',
                lastPlayed: '4m ago',
                image: 'neon',
                sizeGb: 85.4,
              },
              {
                id: 'aegame.aureom.stellar-shift',
                title: 'Stellar Shift: Zero Gravity',
                genre: 'Physics Dogfighting',
                lastPlayed: 'Yesterday',
                image: 'stellar',
                sizeGb: 42.0,
              },
              {
                id: 'aegame.aureom.chrono-rift',
                title: 'Chrono Rift: Eternal Epoch',
                genre: 'Action RPG',
                lastPlayed: '3 days ago',
                image: 'chrono',
                sizeGb: 110.2,
              },
            ]}
            onlineFriendsCount={3}
          />
        )}

        {activeTab === 'SIMULATOR' && (
          <CanvasGame
            onUnlockAchievement={handleUnlockAchievement}
            onSaveCreated={handleSaveCreated}
            onCrashLogged={handleCrashLogged}
          />
        )}

        {activeTab === 'LIBRARY' && (
          <LibraryView
            onLaunchGame={gameId => {
              setActiveTab('SIMULATOR');
            }}
          />
        )}

        {activeTab === 'STORE' && (
          <StoreView
            onPurchaseComplete={handleProductPurchased}
            ownedProductIds={ownedProducts}
          />
        )}

        {activeTab === 'ACHIEVEMENTS' && (
          <AchievementsView
            achievements={achievements}
            totalGamerscore={gamerscore}
            onUnlockManual={id => {
              const ach = achievements.find(a => a.id === id);
              if (ach) handleUnlockAchievement(ach.title, ach.gamerscore);
            }}
          />
        )}

        {activeTab === 'SOCIAL' && <SocialView />}

        {activeTab === 'CLOUD_SAVE' && <CloudSaveView />}

        {activeTab === 'DIGITAL_TWIN' && (
          <DigitalTwinView
            currentProfile={systemProfile}
            onChangeProfile={setSystemProfile}
          />
        )}

        {activeTab === 'CERTIFICATION' && <CertificationView />}

        {activeTab === 'TERMINAL' && <TerminalView />}

        {activeTab === 'ARCHITECTURE' && <ArchitectureDocsView />}
      </main>

      {/* Global Console Achievement / Notification Toast Broker */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 p-4 rounded-2xl bg-[#111622] border border-amber-500/40 text-white shadow-2xl animate-in slide-in-from-bottom-5 duration-200">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-amber-400 font-mono">{toastMessage.title}</div>
            <div className="text-sm font-semibold text-white">{toastMessage.subtitle}</div>
          </div>
        </div>
      )}

      {/* Global Footer */}
      <footer className="border-t border-white/5 py-4 px-6 text-center text-xs font-mono text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div>Aureom Game OS • Built for Xbox-Class Gaming Ecosystems</div>
        <div className="flex items-center gap-3">
          <span>Linux Simulator (AUREOM_KERNEL_SIM)</span>
          <span>•</span>
          <span>Vulkan 1.3 DAG</span>
          <span>•</span>
          <span>Rust Ed25519 Package Security</span>
        </div>
      </footer>
    </div>
  );
}
