'use client';

import React, { useState } from 'react';
import { Cloud, Save, ShieldCheck, AlertTriangle, RefreshCw, CheckCircle2, History, ArrowRight } from 'lucide-react';
import { soundEngine } from './SoundFX';

export interface SaveSlotItem {
  slotName: string;
  gameId: string;
  localVersion: number;
  cloudVersion: number;
  localDate: string;
  cloudDate: string;
  sizeKb: number;
  sha256: string;
  syncStatus: 'SYNCHRONIZED' | 'CONFLICT' | 'LOCAL_AHEAD' | 'CLOUD_AHEAD';
}

const INITIAL_SAVES: SaveSlotItem[] = [
  {
    slotName: 'slot_auto_01',
    gameId: 'aegame.aureom.neon-vanguard',
    localVersion: 14,
    cloudVersion: 14,
    localDate: 'Today, 11:04 AM',
    cloudDate: 'Today, 11:04 AM',
    sizeKb: 412,
    sha256: '4f82d1c93a8...e7102',
    syncStatus: 'SYNCHRONIZED',
  },
  {
    slotName: 'slot_quicksave',
    gameId: 'aegame.aureom.neon-vanguard',
    localVersion: 9,
    cloudVersion: 11,
    localDate: 'Yesterday, 8:30 PM',
    cloudDate: 'Today, 9:15 AM (Handheld Sync)',
    sizeKb: 408,
    sha256: '7b22a091fe...90aa1',
    syncStatus: 'CONFLICT',
  },
  {
    slotName: 'slot_manual_slot1',
    gameId: 'aegame.aureom.stellar-shift',
    localVersion: 4,
    cloudVersion: 3,
    localDate: 'Today, 10:10 AM',
    cloudDate: 'Yesterday, 6:00 PM',
    sizeKb: 285,
    sha256: '88de0112fa...3311b',
    syncStatus: 'LOCAL_AHEAD',
  },
];

export default function CloudSaveView() {
  const [saves, setSaves] = useState<SaveSlotItem[]>(INITIAL_SAVES);
  const [selectedConflict, setSelectedConflict] = useState<SaveSlotItem | null>(null);

  const handleResolve = (slotName: string, choice: 'USE_CLOUD' | 'USE_LOCAL') => {
    soundEngine.playSelectBoop();
    setSaves(prev =>
      prev.map(s => {
        if (s.slotName === slotName) {
          const finalVer = choice === 'USE_CLOUD' ? s.cloudVersion : s.localVersion + 1;
          const finalDate = choice === 'USE_CLOUD' ? s.cloudDate : 'Just now';
          return {
            ...s,
            localVersion: finalVer,
            cloudVersion: finalVer,
            localDate: finalDate,
            cloudDate: finalDate,
            syncStatus: 'SYNCHRONIZED',
          };
        }
        return s;
      })
    );
    setSelectedConflict(null);
  };

  const handleUploadLocal = (slotName: string) => {
    soundEngine.playSelectBoop();
    setSaves(prev =>
      prev.map(s => {
        if (s.slotName === slotName) {
          return {
            ...s,
            cloudVersion: s.localVersion,
            cloudDate: 'Just now',
            syncStatus: 'SYNCHRONIZED',
          };
        }
        return s;
      })
    );
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Cloud className="w-6 h-6 text-amber-400" />
            Aureom Cloud Save & Versioned Storage
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Immutable versioned objects with write-ahead logs and deterministic conflict resolution.
          </p>
        </div>
      </div>

      {/* Save Slots List */}
      <div className="flex flex-col gap-4">
        {saves.map(save => (
          <div
            key={save.slotName}
            className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            <div className="flex items-start gap-4">
              <div
                className={`p-3 rounded-xl border shrink-0 ${
                  save.syncStatus === 'CONFLICT'
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                    : save.syncStatus === 'LOCAL_AHEAD'
                    ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                }`}
              >
                {save.syncStatus === 'CONFLICT' ? (
                  <AlertTriangle className="w-6 h-6" />
                ) : (
                  <Save className="w-6 h-6" />
                )}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-white text-base">{save.slotName}</h3>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                      save.syncStatus === 'CONFLICT'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30 font-bold'
                        : save.syncStatus === 'LOCAL_AHEAD'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    }`}
                  >
                    {save.syncStatus}
                  </span>
                </div>

                <p className="text-xs text-slate-400 font-mono mt-1">
                  Title: {save.gameId} • Size: {save.sizeKb} KB • SHA-256: {save.sha256}
                </p>

                <div className="flex items-center gap-4 text-xs font-mono text-slate-300 mt-2">
                  <span>Local: v{save.localVersion} ({save.localDate})</span>
                  <span>•</span>
                  <span>Cloud: v{save.cloudVersion} ({save.cloudDate})</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {save.syncStatus === 'CONFLICT' ? (
                <button
                  onClick={() => setSelectedConflict(save)}
                  className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-black font-bold text-xs flex items-center gap-1.5 transition-colors shadow"
                >
                  <AlertTriangle className="w-4 h-4" />
                  Resolve Conflict
                </button>
              ) : save.syncStatus === 'LOCAL_AHEAD' ? (
                <button
                  onClick={() => handleUploadLocal(save.slotName)}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  Sync to Cloud
                </button>
              ) : (
                <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  In Sync
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Conflict Resolution Modal */}
      {selectedConflict && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl bg-[#111622] rounded-2xl border border-white/15 p-6 shadow-2xl flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 border-b border-white/10 pb-3">
              <div className="p-2.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Save State Conflict Detected</h3>
                <p className="text-xs text-slate-400 font-mono">
                  Cloud snapshot differs from current local disk payload for {selectedConflict.slotName}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Aureom Game OS never silently overwrites save data. Please inspect the timestamps and select which immutable version to commit as the authoritative head:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-white/10 flex flex-col justify-between gap-3">
                <div className="space-y-1 text-xs font-mono">
                  <div className="text-amber-400 font-bold">LOCAL FILE</div>
                  <div className="text-slate-300">Version: v{selectedConflict.localVersion}</div>
                  <div className="text-slate-400">Timestamp: {selectedConflict.localDate}</div>
                  <div className="text-[10px] text-slate-500">Hash: {selectedConflict.sha256}</div>
                </div>
                <button
                  onClick={() => handleResolve(selectedConflict.slotName, 'USE_LOCAL')}
                  className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
                >
                  Keep Local Version
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 flex flex-col justify-between gap-3">
                <div className="space-y-1 text-xs font-mono">
                  <div className="text-emerald-400 font-bold">CLOUD REPOSITORY (NEWER)</div>
                  <div className="text-slate-300">Version: v{selectedConflict.cloudVersion}</div>
                  <div className="text-slate-400">Timestamp: {selectedConflict.cloudDate}</div>
                  <div className="text-[10px] text-slate-500">Origin: Aureom Handheld Node</div>
                </div>
                <button
                  onClick={() => handleResolve(selectedConflict.slotName, 'USE_CLOUD')}
                  className="w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-colors"
                >
                  Apply Cloud Version
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
