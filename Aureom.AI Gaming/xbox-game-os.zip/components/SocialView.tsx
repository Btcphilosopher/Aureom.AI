'use client';

import React, { useState, useEffect } from 'react';
import { Users, Mic, MicOff, Volume2, VolumeX, Radio, Shield, Zap, CheckCircle2, Clock } from 'lucide-react';
import { soundEngine } from './SoundFX';

interface Friend {
  id: string;
  gamertag: string;
  presence: 'ONLINE' | 'IN_GAME' | 'IN_PARTY' | 'AWAY' | 'OFFLINE';
  currentGame?: string;
  avatarSeed: string;
}

const INITIAL_FRIENDS: Friend[] = [
  { id: 'f_01', gamertag: 'Valkyrie_Nine', presence: 'IN_GAME', currentGame: 'Neon Vanguard: Aureom Odyssey', avatarSeed: 'valk' },
  { id: 'f_02', gamertag: 'EchoRider', presence: 'IN_PARTY', currentGame: 'In Aureom Voice Room', avatarSeed: 'echo' },
  { id: 'f_03', gamertag: 'ZeroLag_Pro', presence: 'ONLINE', currentGame: 'Main Dashboard', avatarSeed: 'zerolag' },
  { id: 'f_04', gamertag: 'QuantumPilot', presence: 'AWAY', avatarSeed: 'quantum' },
  { id: 'f_05', gamertag: 'ShadowStrike', presence: 'OFFLINE', avatarSeed: 'shadow' },
];

export default function SocialView() {
  const [friends] = useState<Friend[]>(INITIAL_FRIENDS);
  const [inParty, setInParty] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);

  // Matchmaking Simulator states
  const [isSearching, setIsSearching] = useState(false);
  const [searchSeconds, setSearchSeconds] = useState(0);
  const [matchFound, setMatchFound] = useState<{
    sessionId: string;
    serverRegion: string;
    pingMs: number;
    teamA: string[];
    teamB: string[];
  } | null>(null);

  const [region, setRegion] = useState('EU-West (Frankfurt)');
  const [crossplay, setCrossplay] = useState('CONTROLLER_STRICT');

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isSearching) {
      timer = setInterval(() => {
        setSearchSeconds(s => {
          if (s >= 5) {
            // Found match deterministically!
            soundEngine.playAchievementChime();
            setIsSearching(false);
            setMatchFound({
              sessionId: `SES-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
              serverRegion: region,
              pingMs: 24,
              teamA: ['AureomPilot (You)', 'Valkyrie_Nine'],
              teamB: ['EchoRider', 'HyperDrive_X'],
            });
            return 0;
          }
          return s + 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isSearching, region]);

  const startMatchmaking = () => {
    soundEngine.playSelectBoop();
    setMatchFound(null);
    setSearchSeconds(0);
    setIsSearching(true);
  };

  const cancelMatchmaking = () => {
    soundEngine.playNavTick();
    setIsSearching(false);
    setSearchSeconds(0);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-cyan-400" />
            Social Graph, Voice Chat & Multiplayer
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Privacy-governed presence boundaries, DTLS-encrypted voice relay, and deterministic matchmaking.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Friends List & Party Voice */}
        <div className="lg:col-span-6 flex flex-col gap-4">
          {/* Party Voice Module */}
          <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span className="font-bold text-white text-sm">Aureom Party Voice (Opus 48kHz)</span>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                LOW LATENCY RELAY
              </span>
            </div>

            {/* Simulated Voice Waveform / Participants */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 font-bold font-mono flex items-center justify-center text-xs border border-amber-500/40">
                    AP
                  </div>
                  <div>
                    <div className="font-semibold text-white text-xs">AureomPilot (You)</div>
                    <div className="text-[10px] font-mono text-emerald-400">Transmitting • 24ms jitter buffer</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-1 h-3 bg-emerald-400 rounded-full animate-pulse" />
                  <span className="w-1 h-5 bg-emerald-400 rounded-full animate-pulse" />
                  <span className="w-1 h-2 bg-emerald-400 rounded-full animate-pulse" />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-cyan-500/20 text-cyan-400 font-bold font-mono flex items-center justify-center text-xs border border-cyan-500/40">
                    ER
                  </div>
                  <div>
                    <div className="font-semibold text-white text-xs">EchoRider</div>
                    <div className="text-[10px] font-mono text-slate-400">Connected • Voice Activity Mode</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-1 h-2 bg-cyan-400 rounded-full" />
                  <span className="w-1 h-3 bg-cyan-400 rounded-full" />
                  <span className="w-1 h-1.5 bg-cyan-400 rounded-full" />
                </div>
              </div>
            </div>

            {/* Voice Controls */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => {
                  soundEngine.playNavTick();
                  setIsMuted(!isMuted);
                }}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors border ${
                  isMuted
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                    : 'bg-slate-800 text-slate-200 border-white/10 hover:bg-slate-700'
                }`}
              >
                {isMuted ? <MicOff className="w-4 h-4 text-rose-400" /> : <Mic className="w-4 h-4 text-emerald-400" />}
                {isMuted ? 'Muted' : 'Microphone ON'}
              </button>

              <button
                onClick={() => {
                  soundEngine.playNavTick();
                  setIsDeafened(!isDeafened);
                }}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors border ${
                  isDeafened
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                    : 'bg-slate-800 text-slate-200 border-white/10 hover:bg-slate-700'
                }`}
              >
                {isDeafened ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
                {isDeafened ? 'Deafened' : 'Audio ON'}
              </button>
            </div>
          </div>

          {/* Friends List */}
          <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col gap-3">
            <h3 className="font-bold text-white text-sm">Friends & Social Graph</h3>
            <div className="space-y-2">
              {friends.map(friend => (
                <div
                  key={friend.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-900/40 border border-white/5 hover:border-white/15 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-9 h-9 rounded-full bg-slate-800 text-slate-200 font-bold font-mono flex items-center justify-center text-xs border border-white/10">
                        {friend.gamertag.slice(0, 2).toUpperCase()}
                      </div>
                      <span
                        className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-[#111622] ${
                          friend.presence === 'IN_GAME'
                            ? 'bg-emerald-400'
                            : friend.presence === 'IN_PARTY'
                            ? 'bg-cyan-400'
                            : friend.presence === 'ONLINE'
                            ? 'bg-emerald-500'
                            : friend.presence === 'AWAY'
                            ? 'bg-amber-400'
                            : 'bg-slate-600'
                        }`}
                      />
                    </div>
                    <div>
                      <div className="font-bold text-white text-xs">{friend.gamertag}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {friend.currentGame || friend.presence}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => soundEngine.playNavTick()}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium border border-white/5 transition-colors"
                  >
                    Invite
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Deterministic Matchmaker Simulator */}
        <div className="lg:col-span-6 flex flex-col gap-4">
          <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-base">Aureom Matchmaking Simulator</h3>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
                MMR: 1,850 (Diamond)
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Matchmaking evaluates skill variance, region latency, party size, and input method policies without exposing private networking credentials.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-slate-400">Target Region Relay</label>
                <select
                  value={region}
                  onChange={e => setRegion(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                >
                  <option>EU-West (Frankfurt)</option>
                  <option>US-East (Virginia)</option>
                  <option>US-West (Oregon)</option>
                  <option>AP-East (Tokyo)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Crossplay & Input Method</label>
                <select
                  value={crossplay}
                  onChange={e => setCrossplay(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="CONTROLLER_STRICT">Controller Strict (Haptics)</option>
                  <option value="KEYBOARD_MOUSE">Keyboard & Mouse Only</option>
                  <option value="UNRESTRICTED">Unrestricted Crossplay</option>
                </select>
              </div>
            </div>

            {/* Queue / Search Status */}
            <div className="p-4 rounded-xl bg-slate-950 border border-white/5 flex flex-col gap-3">
              {isSearching ? (
                <div className="flex flex-col items-center justify-center py-6 gap-3">
                  <div className="w-10 h-10 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
                  <div className="text-sm font-bold text-white font-mono">
                    Searching Matchmaking Pool... ({searchSeconds}s)
                  </div>
                  <p className="text-xs text-slate-400 font-mono">
                    Scoring candidates in {region} • MMR tolerance ±50
                  </p>
                  <button
                    onClick={cancelMatchmaking}
                    className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 text-xs font-medium mt-2"
                  >
                    Cancel Queue
                  </button>
                </div>
              ) : matchFound ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-emerald-400 text-xs font-mono font-bold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      MATCH FOUND & COMMITTED
                    </span>
                    <span>Session: {matchFound.sessionId}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 rounded bg-slate-900 border border-white/5 space-y-1">
                      <div className="text-amber-400 font-bold">ALPHA SQUAD</div>
                      {matchFound.teamA.map(p => (
                        <div key={p} className="text-slate-300">{p}</div>
                      ))}
                    </div>
                    <div className="p-3 rounded bg-slate-900 border border-white/5 space-y-1">
                      <div className="text-cyan-400 font-bold">BRAVO SQUAD</div>
                      {matchFound.teamB.map(p => (
                        <div key={p} className="text-slate-300">{p}</div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[11px] font-mono text-slate-400 pt-1">
                    <span>Relay Ping: <b className="text-emerald-400">{matchFound.pingMs} ms</b></span>
                    <span>Tick Rate: <b className="text-white">60 Hz Server-Authoritative</b></span>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center gap-3">
                  <Users className="w-8 h-8 text-slate-500" />
                  <div>
                    <div className="font-bold text-white text-sm">Matchmaker Idle</div>
                    <div className="text-xs text-slate-400 font-mono">Configure region and start simulation search.</div>
                  </div>
                  <button
                    onClick={startMatchmaking}
                    className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
                  >
                    Enter Matchmaking Queue
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
