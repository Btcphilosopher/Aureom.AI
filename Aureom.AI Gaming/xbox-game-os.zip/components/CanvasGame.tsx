'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Play, Pause, AlertOctagon, Save, Award, RefreshCw, Cpu, Zap, Activity } from 'lucide-react';
import { soundEngine } from './SoundFX';

interface FrameGraphPass {
  name: string;
  category: 'Raster' | 'Compute' | 'RayTracing' | 'Post';
  costMs: number;
  active: boolean;
}

interface CanvasGameProps {
  onUnlockAchievement: (title: string, gamerscore: number) => void;
  onSaveCreated: (slot: string, version: number) => void;
  onCrashLogged: (error: string) => void;
}

export default function CanvasGame({
  onUnlockAchievement,
  onSaveCreated,
  onCrashLogged,
}: CanvasGameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game states: RUNNING, SUSPENDED, CRASHED
  const [gameState, setGameState] = useState<'RUNNING' | 'SUSPENDED' | 'CRASHED'>('RUNNING');
  const [score, setScore] = useState(1280);
  const [shieldHp, setShieldHp] = useState(100);
  const [fps, setFps] = useState(60);
  const [rayTracingEnabled, setRayTracingEnabled] = useState(true);

  // FrameGraph passes matching Section 10 of specification
  const [passes, setPasses] = useState<FrameGraphPass[]>([
    { name: 'ShadowPass', category: 'Raster', costMs: 0.8, active: true },
    { name: 'DepthPrepass', category: 'Raster', costMs: 0.9, active: true },
    { name: 'GBuffer', category: 'Raster', costMs: 2.4, active: true },
    { name: 'Lighting', category: 'Compute', costMs: 3.1, active: true },
    { name: 'Reflection', category: 'Compute', costMs: 1.8, active: true },
    { name: 'RayTracing', category: 'RayTracing', costMs: 3.4, active: true },
    { name: 'Transparency', category: 'Raster', costMs: 0.7, active: true },
    { name: 'PostProcessing', category: 'Post', costMs: 1.4, active: true },
    { name: 'TemporalUpscaling', category: 'Post', costMs: 1.6, active: true },
    { name: 'UI', category: 'Raster', costMs: 0.4, active: true },
    { name: 'Present', category: 'Raster', costMs: 0.1, active: true },
  ]);

  // Simulation internal state
  const playerRef = useRef({
    x: 350,
    y: 280,
    vx: 0,
    vy: 0,
    angle: 0,
    isFiring: false,
    shieldActive: false,
  });

  const keysPressed = useRef<{ [key: string]: boolean }>({});
  const lasersRef = useRef<Array<{ x: number; y: number; vx: number; vy: number; life: number }>>([]);
  const asteroidsRef = useRef<Array<{ x: number; y: number; radius: number; vx: number; vy: number; rot: number; rotSpeed: number }>>([]);
  const particlesRef = useRef<Array<{ x: number; y: number; vx: number; vy: number; color: string; life: number }>>([]);

  // Initialize random asteroid field
  useEffect(() => {
    const list = [];
    for (let i = 0; i < 7; i++) {
      list.push({
        x: Math.random() * 700,
        y: Math.random() * 380,
        radius: 14 + Math.random() * 18,
        vx: (Math.random() - 0.5) * 1.2,
        vy: (Math.random() - 0.5) * 1.2,
        rot: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.03,
      });
    }
    asteroidsRef.current = list;
  }, []);

  const fireLaser = useCallback(() => {
    soundEngine.playLaser();
    const p = playerRef.current;
    const speed = 7;
    lasersRef.current.push({
      x: p.x,
      y: p.y,
      vx: Math.cos(p.angle) * speed,
      vy: Math.sin(p.angle) * speed,
      life: 55,
    });
  }, []);

  // Keyboard handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current[e.code] = true;
      if (e.code === 'KeyP') {
        setGameState(prev => (prev === 'RUNNING' ? 'SUSPENDED' : 'RUNNING'));
        soundEngine.playNavTick();
      }
      if (e.code === 'Space' && gameState === 'RUNNING') {
        e.preventDefault();
        fireLaser();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState, fireLaser]);

  const triggerAchievement = () => {
    soundEngine.playAchievementChime();
    onUnlockAchievement('Neon Conqueror', 50);
  };

  const triggerSave = () => {
    soundEngine.playSelectBoop();
    onSaveCreated('slot_quicksave', Date.now());
  };

  const triggerCrash = () => {
    soundEngine.playExplosion();
    setGameState('CRASHED');
    onCrashLogged('AUREOM_KERNEL_EXCEPTION: GPU_PAGE_FAULT at 0x7FFF98A2 in GBufferPass');
  };

  const recoverCrash = () => {
    soundEngine.playSelectBoop();
    setGameState('RUNNING');
  };

  // Main render and physics loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = performance.now();

    const render = (now: number) => {
      animId = requestAnimationFrame(render);

      const dt = (now - lastTime) / 1000;
      lastTime = now;

      // Calculate FPS
      frameCount++;
      if (now - fpsTimer >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        fpsTimer = now;
      }

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = canvas.width;
      const height = canvas.height;

      // Clear & Background
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, width, height);

      if (gameState === 'CRASHED') {
        // Crash Screen (Failsafe Kernel Dump)
        ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
        ctx.fillRect(0, 0, width, height);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.strokeRect(20, 20, width - 40, height - 40);

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 22px monospace';
        ctx.fillText('AUREOM CRASH REPORTER [KERNEL FAILSAFE]', 50, 80);

        ctx.fillStyle = '#e2e8f0';
        ctx.font = '14px monospace';
        ctx.fillText('Exception Type: GPU_PAGE_FAULT (0x7FFF98A2)', 50, 130);
        ctx.fillText('Game: aegame.aureom.neon-vanguard v1.2.0', 50, 160);
        ctx.fillText('Resource Arena: 9.42 GB / 12.00 GB (No leak detected)', 50, 190);
        ctx.fillText('Sandbox Status: Core state preserved. Non-destructive dump written.', 50, 220);
        ctx.fillText('Press "Recover Subsystem" above to reload runtime state.', 50, 270);
        return;
      }

      // Draw Starfield grid (simulating GBuffer Depth)
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      if (gameState === 'RUNNING') {
        // Update Player Controls
        const p = playerRef.current;
        if (keysPressed.current['KeyA'] || keysPressed.current['ArrowLeft']) p.angle -= 3.8 * dt;
        if (keysPressed.current['KeyD'] || keysPressed.current['ArrowRight']) p.angle += 3.8 * dt;
        if (keysPressed.current['KeyW'] || keysPressed.current['ArrowUp']) {
          p.vx += Math.cos(p.angle) * 12 * dt;
          p.vy += Math.sin(p.angle) * 12 * dt;

          // Engine exhaust particle
          particlesRef.current.push({
            x: p.x - Math.cos(p.angle) * 16,
            y: p.y - Math.sin(p.angle) * 16,
            vx: -Math.cos(p.angle) * 2 + (Math.random() - 0.5),
            vy: -Math.sin(p.angle) * 2 + (Math.random() - 0.5),
            color: '#f59e0b',
            life: 25,
          });
        }
        if (keysPressed.current['ShiftLeft'] || keysPressed.current['ShiftRight']) {
          p.shieldActive = true;
        } else {
          p.shieldActive = false;
        }

        // Apply friction & boundary wrap
        p.vx *= 0.98;
        p.vy *= 0.98;
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Update Asteroids
        asteroidsRef.current.forEach(ast => {
          ast.x += ast.vx;
          ast.y += ast.vy;
          ast.rot += ast.rotSpeed;
          if (ast.x < -30) ast.x = width + 30;
          if (ast.x > width + 30) ast.x = -30;
          if (ast.y < -30) ast.y = height + 30;
          if (ast.y > height + 30) ast.y = -30;
        });

        // Update Lasers & Collisions
        lasersRef.current.forEach((laser, lIdx) => {
          laser.x += laser.vx;
          laser.y += laser.vy;
          laser.life--;

          asteroidsRef.current.forEach(ast => {
            const dist = Math.hypot(laser.x - ast.x, laser.y - ast.y);
            if (dist < ast.radius) {
              laser.life = 0;
              setScore(s => s + 100);
              soundEngine.playExplosion();
              // Spawn explosion debris
              for (let k = 0; k < 8; k++) {
                particlesRef.current.push({
                  x: ast.x,
                  y: ast.y,
                  vx: (Math.random() - 0.5) * 4,
                  vy: (Math.random() - 0.5) * 4,
                  color: '#38bdf8',
                  life: 30,
                });
              }
              // Reposition asteroid
              ast.x = Math.random() * width;
              ast.y = -20;
            }
          });
        });
        lasersRef.current = lasersRef.current.filter(l => l.life > 0);

        // Update Particles
        particlesRef.current.forEach(pt => {
          pt.x += pt.vx;
          pt.y += pt.vy;
          pt.life--;
        });
        particlesRef.current = particlesRef.current.filter(pt => pt.life > 0);
      }

      // Draw Asteroids
      asteroidsRef.current.forEach(ast => {
        ctx.save();
        ctx.translate(ast.x, ast.y);
        ctx.rotate(ast.rot);
        ctx.strokeStyle = '#64748b';
        ctx.fillStyle = '#1e293b';
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (i * Math.PI * 2) / 6;
          const r = ast.radius * (i % 2 === 0 ? 1 : 0.82);
          const px = Math.cos(a) * r;
          const py = Math.sin(a) * r;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      });

      // Draw Particles
      particlesRef.current.forEach(pt => {
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, Math.max(1, pt.life / 8), 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Lasers
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      lasersRef.current.forEach(l => {
        ctx.beginPath();
        ctx.moveTo(l.x, l.y);
        ctx.lineTo(l.x - l.vx * 1.5, l.y - l.vy * 1.5);
        ctx.stroke();
      });

      // Draw Player Spacecraft
      const p = playerRef.current;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.angle);

      // Ship hull
      ctx.fillStyle = '#f59e0b';
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(18, 0);
      ctx.lineTo(-14, -10);
      ctx.lineTo(-8, 0);
      ctx.lineTo(-14, 10);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Cockpit glow
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.arc(2, 0, 4, 0, Math.PI * 2);
      ctx.fill();

      // Shield active ring
      if (p.shieldActive) {
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.7)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, 24, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();

      // Suspended Overlay
      if (gameState === 'SUSPENDED') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = '#f59e0b';
        ctx.font = 'bold 20px monospace';
        ctx.fillText('AUREOM RUNTIME: TITLE SUSPENDED (MEMORY PRESERVED)', 70, height / 2 - 10);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '14px monospace';
        ctx.fillText('Press "Resume" or [P] to restore execution context.', 70, height / 2 + 20);
      }
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [gameState]);

  const totalGpuMs = passes
    .filter(p => p.active)
    .reduce((acc, curr) => acc + (curr.name === 'RayTracing' && !rayTracingEnabled ? 0 : curr.costMs), 0);

  return (
    <div className="flex flex-col gap-4">
      {/* Title Header & Runtime Action Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-[#111622] rounded-xl border border-white/10 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white text-lg">Neon Vanguard: Aureom Odyssey</span>
              <span className="px-2 py-0.5 text-xs font-mono rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {gameState}
              </span>
              <span className="px-2 py-0.5 text-xs font-mono rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {fps} FPS (16.6ms)
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              PID: 1042 | Unified Arena: 9.42 GB / 12.00 GB | Vulkan Render Target
            </p>
          </div>
        </div>

        {/* Runtime Lifecycle Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {gameState === 'RUNNING' ? (
            <button
              onClick={() => {
                soundEngine.playNavTick();
                setGameState('SUSPENDED');
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/10 flex items-center gap-1.5 transition-colors"
            >
              <Pause className="w-3.5 h-3.5 text-amber-400" />
              Suspend [P]
            </button>
          ) : gameState === 'SUSPENDED' ? (
            <button
              onClick={() => {
                soundEngine.playSelectBoop();
                setGameState('RUNNING');
              }}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <Play className="w-3.5 h-3.5" />
              Resume Title
            </button>
          ) : (
            <button
              onClick={recoverCrash}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Recover Subsystem
            </button>
          )}

          <button
            onClick={triggerSave}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/10 flex items-center gap-1.5 transition-colors"
          >
            <Save className="w-3.5 h-3.5 text-cyan-400" />
            Snapshot Save
          </button>

          <button
            onClick={triggerAchievement}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/10 flex items-center gap-1.5 transition-colors"
          >
            <Award className="w-3.5 h-3.5 text-yellow-400" />
            Trigger Unlock
          </button>

          <button
            onClick={triggerCrash}
            className="px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-xs font-medium border border-rose-800/50 flex items-center gap-1.5 transition-colors"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-rose-400" />
            Inject Crash
          </button>
        </div>
      </div>

      {/* Main Canvas & FrameGraph Pipeline Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Game Canvas */}
        <div className="lg:col-span-8 flex flex-col gap-2">
          <div className="relative rounded-xl overflow-hidden border border-white/10 bg-black aspect-[16/9] shadow-2xl flex items-center justify-center">
            <canvas
              ref={canvasRef}
              width={760}
              height={428}
              className="w-full h-full object-contain"
            />

            {/* Quick in-canvas HUD */}
            <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded border border-white/10 text-xs font-mono text-slate-300 flex items-center gap-3">
              <span>Score: <b className="text-amber-400">{score}</b></span>
              <span>Shield: <b className="text-cyan-400">{shieldHp}%</b></span>
            </div>

            <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded border border-white/10 text-[11px] font-mono text-slate-400">
              Controls: <span className="text-white">WASD/Arrows</span> = Thrust & Turn | <span className="text-white">SPACE</span> = Laser | <span className="text-white">SHIFT</span> = Shield Barrier
            </div>
          </div>
        </div>

        {/* Aureom FrameGraph Execution Pipeline Breakdown */}
        <div className="lg:col-span-4 flex flex-col gap-3 p-4 bg-[#111622] rounded-xl border border-white/10 shadow-lg">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-white text-sm">FrameGraph DAG Pipeline</span>
            </div>
            <span className="text-xs font-mono text-cyan-400 font-medium">
              {totalGpuMs.toFixed(1)} ms / 16.6 ms
            </span>
          </div>

          <p className="text-[11px] text-slate-400">
            Aureom compiles a DAG of render passes with automatic memory aliasing and asynchronous compute queues.
          </p>

          <div className="flex items-center justify-between py-1 px-2 rounded bg-slate-900/60 border border-white/5 text-xs">
            <span className="text-slate-300">Hardware Ray Tracing Pass</span>
            <button
              onClick={() => {
                soundEngine.playNavTick();
                setRayTracingEnabled(v => !v);
              }}
              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                rayTracingEnabled
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {rayTracingEnabled ? 'ON (BVH Traversal)' : 'OFF (Fallback)'}
            </button>
          </div>

          {/* Pass Nodes List */}
          <div className="flex flex-col gap-1.5 overflow-y-auto max-h-[300px] pr-1">
            {passes.map(pass => {
              const isRt = pass.name === 'RayTracing';
              const cost = isRt && !rayTracingEnabled ? 0.0 : pass.costMs;
              const barPct = Math.min(100, (cost / 4.0) * 100);

              return (
                <div
                  key={pass.name}
                  className="flex flex-col gap-1 p-2 rounded bg-slate-900/40 border border-white/5 hover:border-white/15 transition-colors text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-slate-200">{pass.name}</span>
                      <span
                        className={`text-[9px] px-1 rounded font-mono ${
                          pass.category === 'RayTracing'
                            ? 'bg-purple-950 text-purple-300'
                            : pass.category === 'Compute'
                            ? 'bg-cyan-950 text-cyan-300'
                            : pass.category === 'Post'
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {pass.category}
                      </span>
                    </div>
                    <span className="font-mono text-slate-400 text-[11px]">{cost.toFixed(1)} ms</span>
                  </div>

                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        pass.category === 'RayTracing'
                          ? 'bg-purple-500'
                          : pass.category === 'Compute'
                          ? 'bg-cyan-500'
                          : pass.category === 'Post'
                          ? 'bg-emerald-500'
                          : 'bg-amber-500'
                      }`}
                      style={{ width: `${barPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
