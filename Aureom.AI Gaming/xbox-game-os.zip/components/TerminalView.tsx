'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, RefreshCw, Sparkles, Check, Copy } from 'lucide-react';
import { soundEngine } from './SoundFX';

interface TerminalLine {
  text: string;
  type: 'cmd' | 'info' | 'success' | 'warning' | 'error';
}

const DEFAULT_HISTORY: TerminalLine[] = [
  { text: 'Aureom Game OS Developer Suite [Version 1.0.4-LNX]', type: 'info' },
  { text: 'Target Architecture: x86_64 / Zen 4 | Vulkan 1.3 SDK | Kernel Simulator Active', type: 'info' },
  { text: 'Type "help" or "aureom help" for a list of platform commands.', type: 'info' },
  { text: '', type: 'info' },
];

export default function TerminalView() {
  const [history, setHistory] = useState<TerminalLine[]>(DEFAULT_HISTORY);
  const [inputVal, setInputVal] = useState('');
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (rawCmd: string) => {
    const cmd = rawCmd.trim();
    if (!cmd) return;

    soundEngine.playNavTick();

    const newLines: TerminalLine[] = [{ text: `$ ${cmd}`, type: 'cmd' }];
    const parts = cmd.split(' ');
    const root = parts[0].toLowerCase();
    const sub = parts[1]?.toLowerCase();
    const arg = parts.slice(2).join(' ');

    if (root === 'help' || (root === 'aureom' && sub === 'help')) {
      newLines.push(
        { text: 'AUREOM GAME OS DEVELOPER COMMANDS:', type: 'info' },
        { text: '  aureom init <name>       Initialize a new Aureom C++/Rust game title workspace', type: 'info' },
        { text: '  aureom build             Compile game source targeting Vulkan and Aureom SDK', type: 'info' },
        { text: '  aureom run               Launch game binary in the AUREOM_KERNEL_SIM sandbox', type: 'info' },
        { text: '  aureom package           Assemble, compress and Ed25519-sign .aegame package', type: 'info' },
        { text: '  aureom certify           Run the 18 mandatory platform certification tests', type: 'info' },
        { text: '  aureom profile           Sample CPU/GPU FrameGraph execution timings', type: 'info' },
        { text: '  aureom test              Execute unit, integration and performance tests', type: 'info' },
        { text: '  aureom-pack inspect <pkg> Inspect manifest, signatures, and permissions of package', type: 'info' },
        { text: '  twin status              Query hardware digital twin telemetry metrics', type: 'info' },
        { text: '  twin fail <fault>        Inject hardware failure: network, tdr, storage, controller', type: 'info' },
        { text: '  clear                    Clear terminal history', type: 'info' }
      );
    } else if (root === 'clear') {
      setHistory([]);
      setInputVal('');
      return;
    } else if (root === 'aureom' && sub === 'init') {
      const name = arg || parts[2] || 'MyAureomGame';
      newLines.push(
        { text: `[INIT] Generating Aureom title template for "${name}"...`, type: 'info' },
        { text: `  -> Created src/main.cpp (Entry point with aureom_init_params)`, type: 'info' },
        { text: `  -> Created package.manifest.json (Resource budgets & permissions)`, type: 'info' },
        { text: `  -> Created CMakeLists.txt (Linked against AureomSDK::Runtime)`, type: 'info' },
        { text: `[SUCCESS] Title workspace "${name}" ready. Run "aureom build" to compile.`, type: 'success' }
      );
    } else if (root === 'aureom' && sub === 'build') {
      newLines.push(
        { text: '[BUILD] Invoking clang++ with -target x86_64-aureom-elf -O3...', type: 'info' },
        { text: '  Compiling src/main.cpp...', type: 'info' },
        { text: '  Compiling shaders: shadow.vert, gbuffer.frag, rt_reflection.rgen...', type: 'info' },
        { text: '  Linking against libaureom_runtime.so and libvulkan.so.1...', type: 'info' },
        { text: '[SUCCESS] Binary generated: bin/game.x86_64 (SHA-256 verified)', type: 'success' }
      );
    } else if (root === 'aureom' && sub === 'package') {
      newLines.push(
        { text: '[PACKAGE] Assembling .aegame distribution container...', type: 'info' },
        { text: '  Scanning assets and compute shaders...', type: 'info' },
        { text: '  Applying chunk-based LZ4 compression (Ratio: 0.62)...', type: 'info' },
        { text: '  Signing package with Ed25519 developer private key...', type: 'info' },
        { text: '  Generated: dist/aegame.aureom.neon-vanguard-1.2.0.aegame (85.4 GB payload)', type: 'success' },
        { text: '  Digest: 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', type: 'info' }
      );
    } else if (root === 'aureom' && sub === 'certify') {
      newLines.push(
        { text: '[CERTIFY] Invoking Aureom Platform Certification Engine...', type: 'info' },
        { text: '  [CERT-01] Package Signature Valid ................... PASS (14ms)', type: 'success' },
        { text: '  [CERT-02] Resource Budget Sandboxing ................ PASS (28ms)', type: 'success' },
        { text: '  [CERT-04] Save Atomicity & WAL Commit ............... PASS (65ms)', type: 'success' },
        { text: '  [CERT-05] Quick Suspend/Resume (<800ms) ............. PASS (340ms)', type: 'success' },
        { text: '  [CERT-06] Gamepad Disconnect Auto-Pause ............. PASS (18ms)', type: 'success' },
        { text: '  [CERT-12] Framerate Determinism (60 FPS Locked) ..... PASS (120ms)', type: 'success' },
        { text: '[RESULT] 18/18 RULES PASSED. Title certified for Global Release.', type: 'success' }
      );
    } else if (root === 'aureom' && sub === 'profile') {
      newLines.push(
        { text: '[PROFILER] Sampling 1,200 frames from Vulkan FrameGraph:', type: 'info' },
        { text: '  ShadowPass:           0.82 ms (Raster)', type: 'info' },
        { text: '  DepthPrepass:         0.91 ms (Raster)', type: 'info' },
        { text: '  GBuffer:              2.38 ms (Raster MRT)', type: 'info' },
        { text: '  DirectLighting:       3.12 ms (Compute)', type: 'info' },
        { text: '  RayTracingReflection: 3.42 ms (Hardware BVH)', type: 'info' },
        { text: '  TemporalUpscaling:    1.60 ms (Post)', type: 'info' },
        { text: '  Frame Pacing:         16.66 ms +/- 0.04 ms (No stutter)', type: 'success' }
      );
    } else if (root === 'twin' && sub === 'status') {
      newLines.push(
        { text: '[DIGITAL TWIN] Hardware State Query:', type: 'info' },
        { text: '  Profile:        AUREOM_CONSOLE (4K 60FPS TV)', type: 'info' },
        { text: '  Power State:    PERFORMANCE (220W Package)', type: 'info' },
        { text: '  CPU Cores:      8 Active (83.7% allocated)', type: 'info' },
        { text: '  GPU Compute:    52 CUs (71.4% utilization)', type: 'info' },
        { text: '  Thermals:       58.2 C | Fans: 1,840 RPM', type: 'info' },
        { text: '  Memory Arena:   9.42 GB / 12.00 GB Allocated', type: 'info' }
      );
    } else if (root === 'aureom-pack') {
      newLines.push(
        { text: '[AUREOM-PACK] Package Inspector:', type: 'info' },
        { text: '  Container: aegame.aureom.neon-vanguard.aegame', type: 'info' },
        { text: '  Signature: Ed25519 Verified [Root CA: Aureom Production]', type: 'success' },
        { text: '  Permissions: [controller.gamepad, audio.spatial, network.relay]', type: 'info' },
        { text: '  Save Schema: v2 with WAL', type: 'info' }
      );
    } else {
      newLines.push({
        text: `Command not recognized: "${cmd}". Type "help" for a list of valid commands.`,
        type: 'error',
      });
    }

    setHistory(prev => [...prev, ...newLines]);
    setInputVal('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleCommand(inputVal);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Terminal className="w-6 h-6 text-amber-400" />
            Aureom Developer CLI & Toolchain
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Command-line interface to the Aureom toolchain, simulator daemon, packager, and certification runner.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {['aureom build', 'aureom certify', 'twin status', 'aureom profile'].map(quickCmd => (
            <button
              key={quickCmd}
              onClick={() => handleCommand(quickCmd)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-mono border border-white/10 transition-colors"
            >
              {quickCmd}
            </button>
          ))}
        </div>
      </div>

      {/* Terminal Window */}
      <div className="rounded-2xl bg-black border border-white/15 p-4 shadow-2xl font-mono text-xs flex flex-col h-[520px]">
        {/* Terminal top bar */}
        <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="text-slate-400 text-[11px] ml-2">aureom-developer-shell — /usr/bin/aureom</span>
          </div>
          <button
            onClick={() => setHistory([])}
            className="text-[11px] text-slate-500 hover:text-slate-300"
          >
            Clear
          </button>
        </div>

        {/* Scrollable output area */}
        <div className="flex-1 overflow-y-auto space-y-1.5 pr-2">
          {history.map((line, idx) => (
            <div
              key={idx}
              className={`leading-relaxed ${
                line.type === 'cmd'
                  ? 'text-amber-400 font-bold'
                  : line.type === 'success'
                  ? 'text-emerald-400'
                  : line.type === 'warning'
                  ? 'text-yellow-400'
                  : line.type === 'error'
                  ? 'text-rose-400'
                  : 'text-slate-300'
              }`}
            >
              {line.text}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input prompt */}
        <div className="flex items-center gap-2 border-t border-white/10 pt-3 mt-2">
          <span className="text-amber-400 font-bold">$</span>
          <input
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type 'help', 'aureom certify', 'twin status'..."
            className="flex-1 bg-transparent text-white focus:outline-none placeholder:text-slate-600 font-mono text-xs"
            autoFocus
          />
          <button
            onClick={() => handleCommand(inputVal)}
            className="p-1.5 rounded bg-amber-500 hover:bg-amber-400 text-black transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
