'use client';

import React, { useState } from 'react';
import { ShieldCheck, Play, CheckCircle2, AlertTriangle, XCircle, FileText, Download, RefreshCw } from 'lucide-react';
import { soundEngine } from './SoundFX';

interface CertRule {
  id: string;
  ruleNumber: number;
  name: string;
  category: 'Security' | 'Lifecycle' | 'Accessibility' | 'Performance' | 'Audio/Visual';
  status: 'PASS' | 'WARNING' | 'FAIL' | 'PENDING';
  details: string;
  executionMs: number;
}

export const CERTIFICATION_RULES: CertRule[] = [
  { id: 'CERT-01', ruleNumber: 1, name: 'Package Signature Cryptographic Attestation', category: 'Security', status: 'PASS', details: 'Ed25519 root signature verified against Aureom production CA.', executionMs: 14 },
  { id: 'CERT-02', ruleNumber: 2, name: 'Sandbox Resource Budget Limits', category: 'Performance', status: 'PASS', details: 'RAM arena peak 9.42 GB <= 12.0 GB ceiling. Zero cgroup overflow.', executionMs: 28 },
  { id: 'CERT-03', ruleNumber: 3, name: 'Crash Threshold & MTBF Stability', category: 'Performance', status: 'PASS', details: '0 unhandled exceptions across 48-hour continuous stress soak.', executionMs: 310 },
  { id: 'CERT-04', ruleNumber: 4, name: 'Save Data Atomicity & WAL Integrity', category: 'Lifecycle', status: 'PASS', details: 'Power-cut simulation during write-ahead commit resulted in zero corruptions.', executionMs: 65 },
  { id: 'CERT-05', ruleNumber: 5, name: 'Quick Suspend & Resume Speed', category: 'Lifecycle', status: 'PASS', details: 'Memory paging snapshot took 340 ms (Requirement: < 800 ms).', executionMs: 340 },
  { id: 'CERT-06', ruleNumber: 6, name: 'Controller Disconnect Mandatory Pause', category: 'Lifecycle', status: 'PASS', details: 'Title pauses execution and raises modal within 1 frame of gamepad disconnect.', executionMs: 18 },
  { id: 'CERT-07', ruleNumber: 7, name: 'Subtitle Scalability & Contrast Standards', category: 'Accessibility', status: 'PASS', details: 'Supports 100% to 200% font scaling with minimum 4.5:1 contrast ratio.', executionMs: 22 },
  { id: 'CERT-08', ruleNumber: 8, name: 'Color-Blind Vision Assistive Modes', category: 'Accessibility', status: 'PASS', details: 'Protanopia, Deuteranopia, and Tritanopia LUT filters validated.', executionMs: 19 },
  { id: 'CERT-09', ruleNumber: 9, name: 'Global Age Rating & Descriptors Metadata', category: 'Security', status: 'PASS', details: 'ESRB, PEGI, USK, and CERO descriptors declared and registered.', executionMs: 12 },
  { id: 'CERT-10', ruleNumber: 10, name: 'Network Disconnect & Socket Recovery', category: 'Lifecycle', status: 'PASS', details: 'Soft timeout handled gracefully without process termination.', executionMs: 45 },
  { id: 'CERT-11', ruleNumber: 11, name: 'Crossplay & Input Pool Policy Enforcement', category: 'Security', status: 'PASS', details: 'Controller strict lobbies isolate keyboard/mouse inputs appropriately.', executionMs: 16 },
  { id: 'CERT-12', ruleNumber: 12, name: 'Framerate Determinism & Zero Frame Drop', category: 'Performance', status: 'PASS', details: '99.9th percentile frame time is 16.68 ms with zero tear lines.', executionMs: 120 },
  { id: 'CERT-13', ruleNumber: 13, name: 'HDR10 Metadata & Dynamic Range Clamping', category: 'Audio/Visual', status: 'PASS', details: 'MaxCLL (1000 nits) and MaxFALL (400 nits) compliant with SMPTE ST 2086.', executionMs: 25 },
  { id: 'CERT-14', ruleNumber: 14, name: 'Audio Dynamic Range Profiles (Midnight/Studio)', category: 'Audio/Visual', status: 'PASS', details: 'Home Theater, Night Mode, and Headphone curves verified in DSP.', executionMs: 30 },
  { id: 'CERT-15', ruleNumber: 15, name: 'Player Privacy & Telemetry Redaction', category: 'Security', status: 'PASS', details: 'PII, auth tokens, and raw IP addresses stripped before telemetry ingestion.', executionMs: 15 },
  { id: 'CERT-16', ruleNumber: 16, name: 'Low Memory Pressure Recovery Handler', category: 'Lifecycle', status: 'PASS', details: 'Title flushes transient caches upon receiving AUREOM_LOW_MEMORY signal.', executionMs: 38 },
  { id: 'CERT-17', ruleNumber: 17, name: 'Storage Exhaustion Graceful Handling', category: 'Lifecycle', status: 'PASS', details: 'Presents friendly prompt and allows slot cleanup without crashing.', executionMs: 29 },
  { id: 'CERT-18', ruleNumber: 18, name: 'Differential Chunk Patch Verification', category: 'Security', status: 'PASS', details: 'v1.1.0 -> v1.2.0 delta patch applied cleanly with bitwise SHA-256 match.', executionMs: 72 },
];

export default function CertificationView() {
  const [rules, setRules] = useState<CertRule[]>(CERTIFICATION_RULES);
  const [isRunning, setIsRunning] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('ALL');

  const runAllTests = () => {
    soundEngine.playNavTick();
    setIsRunning(true);
    // Mark all as pending
    setRules(prev => prev.map(r => ({ ...r, status: 'PENDING' })));

    setTimeout(() => {
      soundEngine.playAchievementChime();
      setRules(CERTIFICATION_RULES);
      setIsRunning(false);
    }, 1800);
  };

  const filteredRules = activeCategory === 'ALL'
    ? rules
    : rules.filter(r => r.category === activeCategory);

  const passedCount = rules.filter(r => r.status === 'PASS').length;

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-purple-400" />
            Aureom Certification Engine (18 Standards)
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Automated compliance engine enforcing quality, security, and stability standards before store distribution.
          </p>
        </div>

        <button
          onClick={runAllTests}
          disabled={isRunning}
          className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-lg shadow-purple-600/25 disabled:opacity-50"
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Executing Certification Suite...
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              Run 18-Rule Suite
            </>
          )}
        </button>
      </div>

      {/* Scoreboard Banner */}
      <div className="p-6 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="p-4 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <div className="text-xs font-mono text-emerald-400 font-bold uppercase">Store Qualification Status</div>
            <div className="text-2xl md:text-3xl font-extrabold text-white">
              CERTIFIED FOR RELEASE ({passedCount}/18 PASS)
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Candidate: <span className="text-white font-mono">Neon Vanguard v1.2.0 (.aegame)</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => soundEngine.playSelectBoop()}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/10 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            Export Audit JSON
          </button>
        </div>
      </div>

      {/* Categories Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        {['ALL', 'Security', 'Lifecycle', 'Accessibility', 'Performance', 'Audio/Visual'].map(cat => (
          <button
            key={cat}
            onClick={() => {
              soundEngine.playNavTick();
              setActiveCategory(cat);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
              activeCategory === cat
                ? 'bg-purple-600 text-white font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Rules List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filteredRules.map(rule => (
          <div
            key={rule.id}
            className="p-4 rounded-xl bg-[#111622] border border-white/10 flex flex-col justify-between gap-2 text-xs font-mono"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-amber-400 font-bold">{rule.id}</span>
                <span className="font-semibold text-white font-sans text-sm">{rule.name}</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${
                  rule.status === 'PASS'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : rule.status === 'PENDING'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 animate-pulse'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                }`}
              >
                {rule.status}
              </span>
            </div>

            <p className="text-slate-400 font-sans text-xs leading-relaxed">
              {rule.details}
            </p>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-white/5">
              <span>Category: {rule.category}</span>
              <span>Test Runtime: {rule.executionMs} ms</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
