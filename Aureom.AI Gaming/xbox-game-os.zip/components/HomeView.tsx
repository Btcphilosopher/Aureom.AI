'use client';

import React from 'react';
import { Play, Sparkles, Trophy, Users, HardDrive, ShieldCheck, ArrowRight, Activity, Clock } from 'lucide-react';
import { soundEngine } from './SoundFX';

interface HomeViewProps {
  onNavigate: (viewId: string) => void;
  gamerscore: number;
  recentGames: Array<{
    id: string;
    title: string;
    genre: string;
    lastPlayed: string;
    image: string;
    sizeGb: number;
  }>;
  onlineFriendsCount: number;
}

export default function HomeView({
  onNavigate,
  gamerscore,
  recentGames,
  onlineFriendsCount,
}: HomeViewProps) {
  const activeGame = recentGames[0];

  return (
    <div className="flex flex-col gap-6">
      {/* Hero Active Game Card (10-foot Console Experience) */}
      <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-br from-slate-900 via-[#111827] to-[#0b0f19] p-6 md:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex flex-col gap-3 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                Quick Resume Ready
              </span>
              <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Played 4m ago
              </span>
            </div>

            <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight">
              {activeGame.title}
            </h1>

            <p className="text-slate-300 text-sm md:text-base leading-relaxed">
              Experience the canonical reference title engineered for Aureom Game OS.
              Fully native Vulkan FrameGraph with temporal upscaling, 3D binaural spatial audio, and zero-stutter frame pacing.
            </p>

            <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1">
              <span>Resolution: <b className="text-white">4K Dynamic (1800p-2160p)</b></span>
              <span>•</span>
              <span>Framerate: <b className="text-emerald-400">60 FPS Locked</b></span>
              <span>•</span>
              <span>Audio: <b className="text-cyan-400">Dolby Atmos / HRTF</b></span>
            </div>

            <div className="flex items-center gap-3 pt-3 flex-wrap">
              <button
                onClick={() => {
                  soundEngine.playSelectBoop();
                  onNavigate('SIMULATOR');
                }}
                className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm flex items-center gap-2 transition-all duration-200 shadow-lg shadow-amber-500/25 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Play className="w-4 h-4 fill-black" />
                Resume Game
              </button>

              <button
                onClick={() => {
                  soundEngine.playNavTick();
                  onNavigate('LIBRARY');
                }}
                className="px-5 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white font-medium text-sm border border-white/10 flex items-center gap-2 transition-all"
              >
                Inspect GamePackage (.aegame)
              </button>
            </div>
          </div>

          {/* Quick Telemetry Widget */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-white/10 backdrop-blur-md flex flex-col gap-3 min-w-[240px]">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400 border-b border-white/10 pb-2">
              <span className="flex items-center gap-1.5 text-white">
                <Activity className="w-3.5 h-3.5 text-amber-400" />
                Resource Allocation
              </span>
              <span className="text-emerald-400">BOUNDED</span>
            </div>
            <div className="space-y-2 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>CPU Cores</span>
                  <span className="text-white">6.7 / 8.0</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full w-[83%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>RAM Arena</span>
                  <span className="text-white">9.42 / 12.0 GB</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-cyan-500 h-full w-[78%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Thermal Load</span>
                  <span className="text-white">58.2°C (1,840 RPM)</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[65%]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Quick Service Gateway Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => {
            soundEngine.playNavTick();
            onNavigate('ACHIEVEMENTS');
          }}
          className="p-5 rounded-xl bg-[#111622] hover:bg-[#151c2c] border border-white/10 hover:border-amber-500/40 text-left transition-all duration-200 group flex flex-col justify-between h-36"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Trophy className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-amber-400 font-bold tracking-wider">{gamerscore} G</span>
          </div>
          <div>
            <div className="font-semibold text-white text-base group-hover:text-amber-300 transition-colors">Achievements</div>
            <div className="text-xs text-slate-400">14 Unlocked • 4 Milestones pending</div>
          </div>
        </button>

        <button
          onClick={() => {
            soundEngine.playNavTick();
            onNavigate('SOCIAL');
          }}
          className="p-5 rounded-xl bg-[#111622] hover:bg-[#151c2c] border border-white/10 hover:border-cyan-500/40 text-left transition-all duration-200 group flex flex-col justify-between h-36"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-cyan-400 font-bold">{onlineFriendsCount} Online</span>
          </div>
          <div>
            <div className="font-semibold text-white text-base group-hover:text-cyan-300 transition-colors">Party & Friends</div>
            <div className="text-xs text-slate-400">Voice Session Active • Matchmaker Idle</div>
          </div>
        </button>

        <button
          onClick={() => {
            soundEngine.playNavTick();
            onNavigate('DIGITAL_TWIN');
          }}
          className="p-5 rounded-xl bg-[#111622] hover:bg-[#151c2c] border border-white/10 hover:border-emerald-500/40 text-left transition-all duration-200 group flex flex-col justify-between h-36"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <HardDrive className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">AUREOM_CONSOLE</span>
          </div>
          <div>
            <div className="font-semibold text-white text-base group-hover:text-emerald-300 transition-colors">Hardware Digital Twin</div>
            <div className="text-xs text-slate-400">Thermals • Power Profiles • Fault Injection</div>
          </div>
        </button>

        <button
          onClick={() => {
            soundEngine.playNavTick();
            onNavigate('CERTIFICATION');
          }}
          className="p-5 rounded-xl bg-[#111622] hover:bg-[#151c2c] border border-white/10 hover:border-purple-500/40 text-left transition-all duration-200 group flex flex-col justify-between h-36"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-purple-300 font-bold">18/18 PASS</span>
          </div>
          <div>
            <div className="font-semibold text-white text-base group-hover:text-purple-300 transition-colors">Certification Engine</div>
            <div className="text-xs text-slate-400">Pre-flight Store Compliance Automation</div>
          </div>
        </button>
      </div>

      {/* Recent Games Library Carousel */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight">Recent Games & Installed Packages</h2>
          <button
            onClick={() => {
              soundEngine.playNavTick();
              onNavigate('LIBRARY');
            }}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium transition-colors"
          >
            View All in Library
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {recentGames.map(game => (
            <div
              key={game.id}
              className="p-4 rounded-xl bg-[#111622] border border-white/10 hover:border-white/20 transition-all group flex flex-col justify-between gap-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-semibold text-white text-sm group-hover:text-amber-400 transition-colors">{game.title}</div>
                  <div className="text-xs text-slate-400">{game.genre} • {game.sizeGb} GB</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-white/5">
                  .aegame
                </span>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                <span className="text-slate-400 font-mono text-[11px]">Last played: {game.lastPlayed}</span>
                <button
                  onClick={() => {
                    soundEngine.playSelectBoop();
                    onNavigate('SIMULATOR');
                  }}
                  className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-amber-500 hover:text-black text-slate-200 font-medium transition-colors text-xs flex items-center gap-1"
                >
                  <Play className="w-3 h-3" />
                  Launch
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
