'use client';

import React from 'react';
import { Trophy, Award, Lock, CheckCircle2, Star, Sparkles } from 'lucide-react';
import { soundEngine } from './SoundFX';

export interface AchievementItem {
  id: string;
  gameId: string;
  title: string;
  description: string;
  gamerscore: number;
  unlocked: boolean;
  unlockedAt?: string;
  hidden?: boolean;
  progressPct: number;
}

interface AchievementsViewProps {
  achievements: AchievementItem[];
  totalGamerscore: number;
  onUnlockManual: (id: string) => void;
}

export default function AchievementsView({
  achievements,
  totalGamerscore,
  onUnlockManual,
}: AchievementsViewProps) {
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const maxScore = achievements.reduce((acc, a) => acc + a.gamerscore, 0);
  const completionPct = Math.round((unlockedCount / achievements.length) * 100);

  return (
    <div className="flex flex-col gap-6">
      {/* Header Stat Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-amber-500/10 via-[#111622] to-slate-900 border border-amber-500/20 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="p-4 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-400">
            <Trophy className="w-8 h-8" />
          </div>
          <div>
            <div className="text-xs font-mono text-amber-400 font-bold tracking-wider uppercase">
              Aureom Gamerscore Profile
            </div>
            <div className="text-3xl md:text-4xl font-extrabold text-white flex items-baseline gap-2">
              <span>{totalGamerscore.toLocaleString()}</span>
              <span className="text-amber-400 text-lg font-mono">G</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {unlockedCount} of {achievements.length} Unlocked ({completionPct}% overall title completion)
            </p>
          </div>
        </div>

        {/* Progression Bar */}
        <div className="flex flex-col gap-2 min-w-[220px]">
          <div className="flex justify-between text-xs font-mono text-slate-300">
            <span>Overall Completion</span>
            <span className="text-amber-400 font-bold">{completionPct}%</span>
          </div>
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden border border-white/5">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-500"
              style={{ width: `${completionPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Achievement List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {achievements.map(ach => (
          <div
            key={ach.id}
            className={`p-4 rounded-xl border transition-all duration-200 flex items-start gap-4 ${
              ach.unlocked
                ? 'bg-[#111622] border-amber-500/30 shadow-lg'
                : 'bg-slate-900/50 border-white/5 opacity-80'
            }`}
          >
            <div
              className={`p-3 rounded-xl border shrink-0 ${
                ach.unlocked
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-400'
                  : 'bg-slate-800 border-white/10 text-slate-500'
              }`}
            >
              {ach.unlocked ? <Award className="w-6 h-6" /> : <Lock className="w-6 h-6" />}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-bold text-white text-sm truncate">
                  {ach.hidden && !ach.unlocked ? 'Secret Achievement' : ach.title}
                </h4>
                <span className="px-2 py-0.5 rounded text-xs font-mono bg-amber-500/10 text-amber-400 font-bold border border-amber-500/20 shrink-0">
                  +{ach.gamerscore} G
                </span>
              </div>

              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {ach.hidden && !ach.unlocked
                  ? 'Keep playing the title to reveal and unlock this milestone.'
                  : ach.description}
              </p>

              <div className="flex items-center justify-between mt-3 text-[11px] font-mono">
                {ach.unlocked ? (
                  <span className="text-emerald-400 flex items-center gap-1 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Unlocked on {ach.unlockedAt || 'Today'}
                  </span>
                ) : (
                  <span className="text-slate-500">Locked</span>
                )}

                {!ach.unlocked && (
                  <button
                    onClick={() => {
                      soundEngine.playAchievementChime();
                      onUnlockManual(ach.id);
                    }}
                    className="px-2.5 py-1 rounded bg-slate-800 hover:bg-amber-500 hover:text-black text-slate-300 text-[10px] font-medium transition-colors"
                  >
                    Simulate Unlock
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
