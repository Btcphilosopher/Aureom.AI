'use client';

import React, { useState } from 'react';
import { Layers, Cpu, Shield, Code, Server, Database, Sparkles, ChevronRight, Check } from 'lucide-react';
import { soundEngine } from './SoundFX';

interface LayerDef {
  layer: string;
  name: string;
  tech: string;
  description: string;
  components: string[];
}

const ARCHITECTURE_LAYERS: LayerDef[] = [
  {
    layer: 'L10',
    name: 'Shell & Console Experience',
    tech: 'Kotlin / React / 10-Foot UI',
    description: 'Xbox-style living room shell, guide overlays, notification center, quick resume picker, and accessibility HUD.',
    components: ['Guide Overlay', 'Notification Toast Broker', 'Quick Resume Manager', 'Store Client'],
  },
  {
    layer: 'L9',
    name: 'Developer SDK & Tools',
    tech: 'C ABI / Python CLI / Clang',
    description: 'Zero-overhead stable C API (aureom_sdk.h), package tool (aureom-pack), memory profiler, and certification engine.',
    components: ['aureom_sdk.h', 'Certification Engine (18 Rules)', 'Asset Cooker', 'Crash Dumper'],
  },
  {
    layer: 'L8',
    name: 'Platform Services & Cloud',
    tech: 'Python FastAPI / Redis / Postgres',
    description: 'Cloud identity, entitlement commerce, matchmaking relay, presence graph, and immutable cloud saves.',
    components: ['FastAPI Services', 'PostgreSQL Schemas', 'Matchmaker Daemon', 'Telemetry Ingestion'],
  },
  {
    layer: 'L7',
    name: 'Multiplayer & Networking',
    tech: 'Rust / DTLS / UDP / Opus',
    description: 'High-frequency deterministic game networking, client prediction, lag compensation, and encrypted voice chat.',
    components: ['DTLS Voice Relay', 'Matchmaking Client', 'P2P NAT Traversal', 'Opus Audio Codec'],
  },
  {
    layer: 'L6',
    name: 'Storage & Cloud Save Engine',
    tech: 'Rust / LZ4 / AES-GCM / WAL',
    description: 'Sandboxed isolated file systems, write-ahead logs for power-loss resistance, and delta cloud synchronization.',
    components: ['SaveSlot Manager', 'Conflict Detection', 'Differential Patch Engine', 'WAL Journal'],
  },
  {
    layer: 'L5',
    name: 'Audio & DSP Pipeline',
    tech: 'C++20 / SIMD / HRTF / 3D Binaural',
    description: 'Low-latency spatial audio engine with HRTF binaural rendering, occlusion raycasts, and dynamic range clamping.',
    components: ['SpatialAudioEngine', 'HRTF Convolver', 'Ambisonics Bus', 'DSP Limiter'],
  },
  {
    layer: 'L4',
    name: 'Input & Controller Subsystem',
    tech: 'C++20 / USB HID / BLE / Haptics',
    description: 'Deterministic 1000 Hz polling, dual-actuator haptic feedback, adaptive triggers, and disconnect failsafes.',
    components: ['ControllerManager', 'HapticWaveformSynthesizer', 'Deadzone Calibrator', 'Virtual Gamepad'],
  },
  {
    layer: 'L3',
    name: 'Graphics & FrameGraph Pipeline',
    tech: 'C++20 / Vulkan 1.3 / SPIR-V',
    description: 'DAG-based transient resource FrameGraph, hardware ray tracing (BVH), temporal upscaling, and async compute.',
    components: ['FrameGraph DAG', 'VulkanDeviceAbstraction', 'TransientAllocator', 'RayTracingPipeline'],
  },
  {
    layer: 'L2',
    name: 'Game Runtime & Title Sandbox',
    tech: 'C++20 / Rust Security Core',
    description: 'Strict memory arena isolation (12 GB Title / 4 GB OS), lifecycle supervisor, and unhandled exception interceptors.',
    components: ['AureomGameRuntime', 'ResourceBudgetSupervisor', 'ProcessSandbox', 'StateSnapshotter'],
  },
  {
    layer: 'L1',
    name: 'Operating System & Kernel Simulator',
    tech: 'C++20 / Linux cgroups / eBPF',
    description: 'Process scheduling, memory paging, thread affinity pinning, thermal power profiles, and failure injection.',
    components: ['AureomKernelSim', 'SchedulerAffinity', 'ThermalSupervisor', 'FaultInjector'],
  },
  {
    layer: 'L0',
    name: 'Hardware Platforms & Silicon',
    tech: 'x86_64 Zen 4 / RDNA 3 / NVMe Gen4',
    description: 'Dedicated console silicon, handheld APUs, gaming desktop PCs, and cloud virtualization nodes.',
    components: ['Aureom Console (4K)', 'Aureom Handheld (15W)', 'PC Target', 'Cloud Streaming Node'],
  },
];

export default function ArchitectureDocsView() {
  const [selectedLayer, setSelectedLayer] = useState<LayerDef>(ARCHITECTURE_LAYERS[0]);

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-amber-400" />
            Aureom Platform Architecture (10-Layer Stack)
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Exhaustive engineering specification from bare metal silicon (L0) to the 10-foot living room experience (L10).
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Layer Stack Navigation */}
        <div className="lg:col-span-5 flex flex-col gap-2">
          {ARCHITECTURE_LAYERS.map(item => {
            const isSelected = selectedLayer.layer === item.layer;
            return (
              <button
                key={item.layer}
                onClick={() => {
                  soundEngine.playNavTick();
                  setSelectedLayer(item);
                }}
                className={`p-3.5 rounded-xl border text-left transition-all duration-150 flex items-center justify-between ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500/50 shadow-lg text-white'
                    : 'bg-[#111622] border-white/5 text-slate-300 hover:border-white/15'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`font-mono text-xs px-2 py-0.5 rounded font-bold ${
                      isSelected
                        ? 'bg-amber-500 text-black'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.layer}
                  </span>
                  <div>
                    <div className="font-bold text-sm">{item.name}</div>
                    <div className="text-[11px] font-mono text-slate-400">{item.tech}</div>
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'rotate-90 text-amber-400' : 'text-slate-600'}`} />
              </button>
            );
          })}
        </div>

        {/* Layer Detail Inspector */}
        <div className="lg:col-span-7 flex flex-col gap-4 p-6 rounded-2xl bg-[#111622] border border-white/10 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded bg-amber-500 text-black font-bold font-mono text-xs">
                {selectedLayer.layer}
              </span>
              <h3 className="text-xl font-bold text-white">{selectedLayer.name}</h3>
            </div>
            <span className="text-xs font-mono text-cyan-400">{selectedLayer.tech}</span>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed">
            {selectedLayer.description}
          </p>

          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-white text-xs font-mono uppercase tracking-wider text-slate-400">
              Key Subsystems & Architectural Modules
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {selectedLayer.components.map(comp => (
                <div
                  key={comp}
                  className="p-3 rounded-xl bg-slate-950/70 border border-white/5 flex items-center gap-2 text-xs font-mono text-slate-200"
                >
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                  <span>{comp}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Canonical Invariant Callout */}
          <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-amber-500/20 space-y-1.5 text-xs font-mono">
            <div className="text-amber-400 font-bold flex items-center gap-1.5">
              <Shield className="w-4 h-4" />
              SYSTEM INVARIANT: ZERO INDETERMINISM
            </div>
            <p className="text-slate-400 leading-relaxed">
              Every allocation in {selectedLayer.layer} is bound to explicit resource quotas.
              Titles cannot exceed allocated memory arenas, and all storage operations are committed through write-ahead journals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
