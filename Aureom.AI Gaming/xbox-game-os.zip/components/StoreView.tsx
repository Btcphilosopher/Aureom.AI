'use client';

import React, { useState } from 'react';
import { ShoppingBag, CreditCard, CheckCircle2, ShieldCheck, Tag, Sparkles, RefreshCw } from 'lucide-react';
import { soundEngine } from './SoundFX';

type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY';

interface StoreProduct {
  id: string;
  gameId: string;
  title: string;
  category: 'Game' | 'DLC' | 'Pass';
  basePriceCents: {
    USD: number;
    EUR: number;
    GBP: number;
    JPY: number;
  };
  discountPercent: number; // integer 0..100
  description: string;
}

export const STORE_PRODUCTS: StoreProduct[] = [
  {
    id: 'prod_01',
    gameId: 'aegame.aureom.neon-vanguard',
    title: 'Neon Vanguard: Aureom Odyssey',
    category: 'Game',
    basePriceCents: { USD: 6999, EUR: 6999, GBP: 5999, JPY: 9800 },
    discountPercent: 15,
    description: 'The flagship sci-fi epic. 4K 60FPS Vulkan FrameGraph with temporal upscaling.',
  },
  {
    id: 'prod_02',
    gameId: 'aegame.aureom.neon-vanguard-dlc1',
    title: 'Neon Vanguard: Cyber Void Expansion',
    category: 'DLC',
    basePriceCents: { USD: 1999, EUR: 1999, GBP: 1699, JPY: 2800 },
    discountPercent: 0,
    description: '3 new star systems, 12 ship hulls, and extended campaign quests.',
  },
  {
    id: 'prod_03',
    gameId: 'aegame.aureom.game-pass-ultimate',
    title: 'Aureom Game Pass - 1 Month',
    category: 'Pass',
    basePriceCents: { USD: 1499, EUR: 1499, GBP: 1299, JPY: 1980 },
    discountPercent: 0,
    description: 'Access over 200 titles on Console, Handheld, PC, and Cloud Streaming.',
  },
  {
    id: 'prod_04',
    gameId: 'aegame.aureom.stellar-shift',
    title: 'Stellar Shift: Zero Gravity',
    category: 'Game',
    basePriceCents: { USD: 4999, EUR: 4999, GBP: 4299, JPY: 7200 },
    discountPercent: 20,
    description: 'Zero-g physics dogfighting with multi-channel positional audio.',
  },
];

// Exact Decimal money formatting - strictly no floating point multiplication drift
function formatDecimalPrice(cents: number, discountPct: number, curr: Currency): string {
  const discountFactor = (100 - discountPct) / 100;
  const finalCents = Math.round(cents * discountFactor);

  if (curr === 'JPY') {
    return `¥${finalCents.toLocaleString()}`;
  }
  const dollars = (finalCents / 100).toFixed(2);
  switch (curr) {
    case 'USD':
      return `$${dollars}`;
    case 'EUR':
      return `€${dollars}`;
    case 'GBP':
      return `£${dollars}`;
  }
}

interface StoreViewProps {
  onPurchaseComplete: (product: StoreProduct) => void;
  ownedProductIds: string[];
}

let orderCounter = 1001;
function generateOrderId(): string {
  return `ORD-${(orderCounter++).toString(36).toUpperCase()}`;
}
function generateEntitlementId(): string {
  return `ENT-${(orderCounter + 500).toString(36).toUpperCase()}`;
}

export default function StoreView({ onPurchaseComplete, ownedProductIds }: StoreViewProps) {
  const [currency, setCurrency] = useState<Currency>('USD');
  const [activeReceipt, setActiveReceipt] = useState<{
    orderId: string;
    productTitle: string;
    amount: string;
    currency: string;
    entitlementId: string;
    timestamp: string;
  } | null>(null);

  const handleBuy = (product: StoreProduct) => {
    soundEngine.playAchievementChime();
    const formattedPrice = formatDecimalPrice(
      product.basePriceCents[currency],
      product.discountPercent,
      currency
    );

    const receipt = {
      orderId: generateOrderId(),
      productTitle: product.title,
      amount: formattedPrice,
      currency,
      entitlementId: generateEntitlementId(),
      timestamp: '2026-09-12T12:00:00Z',
    };

    setActiveReceipt(receipt);
    onPurchaseComplete(product);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Header & Currency Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-amber-400" />
            Aureom Digital Store
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Deterministic Decimal arithmetic with instant cryptographic entitlement issuance.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-xl border border-white/10">
          {(['USD', 'EUR', 'GBP', 'JPY'] as Currency[]).map(curr => (
            <button
              key={curr}
              onClick={() => {
                soundEngine.playNavTick();
                setCurrency(curr);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-semibold transition-colors ${
                currency === curr
                  ? 'bg-amber-500 text-black shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {curr}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {STORE_PRODUCTS.map(product => {
          const isOwned = ownedProductIds.includes(product.id);
          const formatted = formatDecimalPrice(
            product.basePriceCents[currency],
            product.discountPercent,
            currency
          );
          const rawPrice = formatDecimalPrice(
            product.basePriceCents[currency],
            0,
            currency
          );

          return (
            <div
              key={product.id}
              className="flex flex-col justify-between p-5 rounded-2xl bg-[#111622] border border-white/10 hover:border-amber-500/30 transition-all duration-200 shadow-xl"
            >
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-white/5 uppercase">
                    {product.category}
                  </span>
                  {product.discountPercent > 0 && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
                      -{product.discountPercent}% PROMO
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="font-bold text-white text-base line-clamp-1">{product.title}</h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-white/5 flex flex-col gap-3">
                <div className="flex items-baseline gap-2 font-mono">
                  <span className="text-xl font-extrabold text-white">{formatted}</span>
                  {product.discountPercent > 0 && (
                    <span className="text-xs text-slate-500 line-through">{rawPrice}</span>
                  )}
                </div>

                {isOwned ? (
                  <button
                    disabled
                    className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-400 font-medium text-xs flex items-center justify-center gap-1.5 cursor-not-allowed border border-white/5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Entitlement Owned
                  </button>
                ) : (
                  <button
                    onClick={() => handleBuy(product)}
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-amber-500/20 active:scale-[0.98]"
                  >
                    <CreditCard className="w-4 h-4" />
                    Purchase Entitlement
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Cryptographic Order Receipt Modal */}
      {activeReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-[#111622] rounded-2xl border border-white/15 p-6 shadow-2xl flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Purchase Successful</h3>
                <p className="text-xs text-slate-400 font-mono">Cryptographic receipt signed by Aureom Commerce</p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-white/10 space-y-2 text-xs font-mono text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">Order ID:</span>
                <span className="text-amber-400">{activeReceipt.orderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Product:</span>
                <span className="text-white">{activeReceipt.productTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount Paid:</span>
                <span className="text-emerald-400 font-bold">{activeReceipt.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Entitlement Grant:</span>
                <span className="text-cyan-400">{activeReceipt.entitlementId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Timestamp:</span>
                <span className="text-slate-400">{activeReceipt.timestamp.split('T')[0]}</span>
              </div>
            </div>

            <button
              onClick={() => setActiveReceipt(null)}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-colors"
            >
              Continue to Library
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
