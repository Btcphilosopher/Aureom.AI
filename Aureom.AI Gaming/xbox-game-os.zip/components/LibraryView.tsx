'use client';

import React, { useState } from 'react';
import { Package, ShieldCheck, Play, HardDrive, Cpu, Terminal, FileCode, CheckCircle2, ChevronRight, X } from 'lucide-react';
import { soundEngine } from './SoundFX';

export interface GamePackageData {
  game_id: string;
  title: string;
  publisher: string;
  developer: string;
  executable: string;
  version: string;
  architecture: string;
  dependencies: string[];
  save_schema_version: number;
  permissions: string[];
  age_rating: string;
  esrb_descriptor: string;
  resource_budget: {
    cpu_cores: number;
    ram_mb: number;
    vram_mb: number;
    storage_quota_gb: number;
  };
  signature: string;
  sha256: string;
}

export const CANONICAL_PACKAGES: GamePackageData[] = [
  {
    game_id: 'aegame.aureom.neon-vanguard',
    title: 'Neon Vanguard: Aureom Odyssey',
    publisher: 'Aureom Studios',
    developer: 'Odyssey Interactive',
    executable: 'bin/neon_vanguard.x86_64',
    version: '1.2.0',
    architecture: 'x86_64 / Zen 4',
    dependencies: ['aureom.runtime.v1', 'vulkan.loader.1.3', 'opus.dsp.v2'],
    save_schema_version: 2,
    permissions: [
      'controller.gamepad.haptics',
      'audio.spatial.hrtf',
      'storage.sandboxed_save',
      'network.multiplayer.relay'
    ],
    age_rating: 'ESRB_TEEN (13+)',
    esrb_descriptor: 'Fantasy Violence, Mild Language',
    resource_budget: {
      cpu_cores: 8,
      ram_mb: 12288,
      vram_mb: 10240,
      storage_quota_gb: 85,
    },
    signature: 'ed25519:3b7a81c4e9f04128...88ae90d1f',
    sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
  },
  {
    game_id: 'aegame.aureom.stellar-shift',
    title: 'Stellar Shift: Zero Gravity',
    publisher: 'Hyperion Interactive',
    developer: 'Warp Engine Labs',
    executable: 'bin/stellar_shift.bin',
    version: '2.0.4',
    architecture: 'x86_64',
    dependencies: ['aureom.runtime.v1', 'aureom.net.mesh'],
    save_schema_version: 1,
    permissions: [
      'controller.adaptive_triggers',
      'audio.voice_chat',
      'storage.sandboxed_save'
    ],
    age_rating: 'ESRB_EVERYONE',
    esrb_descriptor: 'Mild Fantasy Themes',
    resource_budget: {
      cpu_cores: 6,
      ram_mb: 8192,
      vram_mb: 6144,
      storage_quota_gb: 42,
    },
    signature: 'ed25519:6c8109d93e18...29fa8c',
    sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  },
  {
    game_id: 'aegame.aureom.chrono-rift',
    title: 'Chrono Rift: Eternal Epoch',
    publisher: 'Aureom Publishing',
    developer: 'Mythic Core',
    executable: 'bin/chrono_rift.x86_64',
    version: '1.0.1',
    architecture: 'x86_64',
    dependencies: ['aureom.runtime.v1', 'raytracing.bvh.v2'],
    save_schema_version: 3,
    permissions: [
      'controller.gamepad.haptics',
      'storage.sandboxed_save',
      'graphics.raytracing'
    ],
    age_rating: 'ESRB_MATURE (17+)',
    esrb_descriptor: 'Intense Violence, Blood and Gore',
    resource_budget: {
      cpu_cores: 8,
      ram_mb: 14336,
      vram_mb: 11264,
      storage_quota_gb: 110,
    },
    signature: 'ed25519:f12ab569021...eef940',
    sha256: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
  },
];

interface LibraryViewProps {
  onLaunchGame: (gameId: string) => void;
}

export default function LibraryView({ onLaunchGame }: LibraryViewProps) {
  const [selectedPkg, setSelectedPkg] = useState<GamePackageData | null>(null);

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-400" />
            Game Library & Package Manager
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Canonical .aegame packages verified by Aureom cryptographic root of trust.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono text-slate-300">
          <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10">
            Total Installed: <b className="text-amber-400">3 Packages</b>
          </span>
          <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10">
            Storage Quota: <b className="text-cyan-400">237 / 1,000 GB</b>
          </span>
        </div>
      </div>

      {/* Packages Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {CANONICAL_PACKAGES.map(pkg => (
          <div
            key={pkg.game_id}
            className="flex flex-col justify-between p-5 rounded-2xl bg-[#111622] border border-white/10 hover:border-amber-500/40 transition-all duration-200 shadow-xl group"
          >
            <div className="flex flex-col gap-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-white text-base group-hover:text-amber-300 transition-colors">
                    {pkg.title}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono">
                    {pkg.developer} • {pkg.publisher}
                  </p>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  SIGNED
                </span>
              </div>

              {/* Resource & Runtime summary */}
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/5 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Package ID</span>
                  <span className="text-slate-200 truncate max-w-[170px]">{pkg.game_id}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Version / Arch</span>
                  <span className="text-slate-200">v{pkg.version} ({pkg.architecture.split(' ')[0]})</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Memory Quota</span>
                  <span className="text-cyan-300">{pkg.resource_budget.ram_mb / 1024} GB RAM / {pkg.resource_budget.vram_mb / 1024} GB VRAM</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Age Rating</span>
                  <span className="text-amber-300">{pkg.age_rating.split(' ')[0]}</span>
                </div>
              </div>

              {/* Permissions Pills */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {pkg.permissions.slice(0, 3).map(p => (
                  <span
                    key={p}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-white/5"
                  >
                    {p.split('.')[1] || p}
                  </span>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-4 mt-2 border-t border-white/5">
              <button
                onClick={() => {
                  soundEngine.playSelectBoop();
                  onLaunchGame(pkg.game_id);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                Launch Title
              </button>

              <button
                onClick={() => {
                  soundEngine.playNavTick();
                  setSelectedPkg(pkg);
                }}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-white/10 flex items-center justify-center gap-1 transition-colors"
              >
                <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                Manifest
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Package Manifest Modal */}
      {selectedPkg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl bg-[#111622] rounded-2xl border border-white/15 p-6 shadow-2xl flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-amber-400" />
                <h3 className="text-lg font-bold text-white">
                  Package Manifest: {selectedPkg.title} (.aegame)
                </h3>
              </div>
              <button
                onClick={() => setSelectedPkg(null)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono text-slate-300">
              <div className="p-3 rounded-xl bg-slate-950 border border-white/5 space-y-1">
                <div className="text-amber-400 font-bold mb-1">CRYPTOGRAPHIC ATTESTATION</div>
                <div>Algorithm: <span className="text-white">Ed25519 / SHA-256</span></div>
                <div className="break-all">Signature: <span className="text-emerald-400">{selectedPkg.signature}</span></div>
                <div className="break-all">Hash: <span className="text-cyan-400">{selectedPkg.sha256}</span></div>
              </div>

              <div>
                <div className="text-slate-400 mb-1">Declared Capability Permissions:</div>
                <div className="flex flex-wrap gap-2">
                  {selectedPkg.permissions.map(perm => (
                    <span key={perm} className="px-2.5 py-1 rounded bg-slate-900 border border-white/10 text-cyan-300">
                      {perm}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-slate-400 mb-1">Runtime Dependencies:</div>
                <div className="flex flex-wrap gap-2">
                  {selectedPkg.dependencies.map(dep => (
                    <span key={dep} className="px-2.5 py-1 rounded bg-slate-900 border border-white/10 text-purple-300">
                      {dep}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-white/5 space-y-1">
                <div className="text-amber-400 font-bold mb-1">SANDBOX RESOURCE ENFORCEMENT</div>
                <div>Target CPU Cores: <span className="text-white">{selectedPkg.resource_budget.cpu_cores} dedicated</span></div>
                <div>Unified System Memory: <span className="text-white">{selectedPkg.resource_budget.ram_mb} MB</span></div>
                <div>Dedicated Video Memory: <span className="text-white">{selectedPkg.resource_budget.vram_mb} MB</span></div>
                <div>Encrypted Storage Quota: <span className="text-white">{selectedPkg.resource_budget.storage_quota_gb} GB</span></div>
                <div>Save Schema Version: <span className="text-white">v{selectedPkg.save_schema_version} (WAL Enabled)</span></div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedPkg(null)}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
