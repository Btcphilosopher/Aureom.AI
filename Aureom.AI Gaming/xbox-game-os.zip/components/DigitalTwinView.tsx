'use client';

import React, { useState, useEffect } from 'react';
import { HardDrive, Cpu, Zap, Activity, Flame, ShieldAlert, Wifi, WifiOff, Battery, Volume2, CheckCircle2 } from 'lucide-react';
import { soundEngine } from './SoundFX';

export type SystemProfile = 'AUREOM_CONSOLE' | 'AUREOM_HANDHELD' | 'AUREOM_DEV_PC' | 'AUREOM_CLOUD';
export type PowerProfile = 'PERFORMANCE' | 'BALANCED' | 'QUIET' | 'BATTERY' | 'THERMAL_LIMIT';

interface DigitalTwinViewProps {
  currentProfile: SystemProfile;
  onChangeProfile: (p: SystemProfile) => void;
}

export default function DigitalTwinView({ currentProfile, onChangeProfile }: DigitalTwinViewProps) {
  const [powerProfile, setPowerProfile] = useState<PowerProfile>('PERFORMANCE');
  const [cpuTemp, setCpuTemp] = useState(58.2);
  const [fanRpm, setFanRpm] = useState(1840);
  const [injectedFault, setInjectedFault] = useState<string | null>(null);
  const [networkOnline, setNetworkOnline] = useState(true);
  const [controllerBattery, setControllerBattery] = useState(88);

  // Dynamic telemetry tick
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuTemp(t => +(t + (Math.random() - 0.5) * 0.4).toFixed(1));
      setFanRpm(r => Math.round(r + (Math.random() - 0.5) * 20));
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const handleInjectFault = (faultType: string) => {
    soundEngine.playExplosion();
    setInjectedFault(faultType);
    if (faultType === 'NETWORK_DISCONNECT') {
      setNetworkOnline(false);
    }
  };

  const handleClearFault = () => {
    soundEngine.playSelectBoop();
    setInjectedFault(null);
    setNetworkOnline(true);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Activity className="w-6 h-6 text-emerald-400" />
            Console Digital Twin & Hardware Simulator
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Complete telemetry simulator for SOC thermals, fan curves, memory bandwidth, and failure states.
          </p>
        </div>

        {/* Profile Selector */}
        <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-xl border border-white/10 text-xs font-mono">
          {(['AUREOM_CONSOLE', 'AUREOM_HANDHELD', 'AUREOM_DEV_PC', 'AUREOM_CLOUD'] as SystemProfile[]).map(p => (
            <button
              key={p}
              onClick={() => {
                soundEngine.playNavTick();
                onChangeProfile(p);
              }}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                currentProfile === p
                  ? 'bg-emerald-500 text-black font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {p.replace('AUREOM_', '')}
            </button>
          ))}
        </div>
      </div>

      {/* Main Hardware Telemetry Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col justify-between h-44">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-emerald-400">8c / 16t @ 3.8 GHz</span>
          </div>
          <div>
            <div className="text-xs font-mono text-slate-400">CPU Core Budget</div>
            <div className="text-2xl font-bold text-white font-mono">83.7%</div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
              <div className="bg-amber-500 h-full w-[83.7%]" />
            </div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col justify-between h-44">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Zap className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-cyan-300">52 CUs @ 2.4 GHz</span>
          </div>
          <div>
            <div className="text-xs font-mono text-slate-400">GPU RDNA3 Compute</div>
            <div className="text-2xl font-bold text-white font-mono">71.4%</div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
              <div className="bg-cyan-500 h-full w-[71.4%]" />
            </div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col justify-between h-44">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20">
              <Flame className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-rose-300">{fanRpm} RPM</span>
          </div>
          <div>
            <div className="text-xs font-mono text-slate-400">SOC Temperature</div>
            <div className="text-2xl font-bold text-white font-mono">{cpuTemp}°C</div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
              <div className="bg-rose-500 h-full w-[58%]" />
            </div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col justify-between h-44">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Battery className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-purple-300">Wireless Gamepad</span>
          </div>
          <div>
            <div className="text-xs font-mono text-slate-400">Controller Battery</div>
            <div className="text-2xl font-bold text-white font-mono">{controllerBattery}%</div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
              <div className="bg-purple-500 h-full w-[88%]" />
            </div>
          </div>
        </div>
      </div>

      {/* Power Profile & Failure Injection Subsystems */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Power Profile Manager */}
        <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col gap-4">
          <h3 className="font-bold text-white text-base">Thermal & Power Profiles</h3>
          <p className="text-xs text-slate-400">
            Governs dynamic frequency scaling (DFS), fan curve slope, and title GPU TDP limits.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {(['PERFORMANCE', 'BALANCED', 'QUIET', 'BATTERY', 'THERMAL_LIMIT'] as PowerProfile[]).map(p => (
              <button
                key={p}
                onClick={() => {
                  soundEngine.playNavTick();
                  setPowerProfile(p);
                }}
                className={`p-3 rounded-xl border text-xs font-mono font-medium text-left transition-all ${
                  powerProfile === p
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow'
                    : 'bg-slate-900/60 text-slate-400 border-white/5 hover:border-white/15'
                }`}
              >
                <div className="font-bold">{p}</div>
                <div className="text-[10px] text-slate-500 mt-1">
                  {p === 'PERFORMANCE'
                    ? '220W TDP • Max Boost'
                    : p === 'BALANCED'
                    ? '150W TDP • Dynamic'
                    : p === 'BATTERY'
                    ? '15W TDP • Handheld'
                    : 'Acoustic Silent'}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Failure Injection Testing Suite */}
        <div className="p-5 rounded-2xl bg-[#111622] border border-white/10 shadow-xl flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              Injected Failure Simulator
            </h3>
            {injectedFault && (
              <button
                onClick={handleClearFault}
                className="text-xs font-mono text-emerald-400 hover:underline"
              >
                Reset Faults
              </button>
            )}
          </div>

          <p className="text-xs text-slate-400">
            Section 35 & 50 require runtime verification against hostile fault conditions:
          </p>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <button
              onClick={() => handleInjectFault('NETWORK_DISCONNECT')}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-left text-slate-300 transition-colors"
            >
              Drop Network Link
            </button>

            <button
              onClick={() => handleInjectFault('GPU_HANG_TDR')}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-left text-slate-300 transition-colors"
            >
              Simulate GPU TDR Hang
            </button>

            <button
              onClick={() => handleInjectFault('STORAGE_FULL')}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-left text-slate-300 transition-colors"
            >
              Simulate Storage Full
            </button>

            <button
              onClick={() => handleInjectFault('CONTROLLER_LOST')}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-left text-slate-300 transition-colors"
            >
              Drop Primary Gamepad
            </button>
          </div>

          {injectedFault && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-800/40 text-rose-300 text-xs font-mono flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <div>
                <span className="font-bold">Active Injected Fault: {injectedFault}</span>
                <p className="text-[11px] text-rose-400/80 mt-0.5">
                  Kernel supervisor intercepted event. Game notified via `AUREOM_EVENT_SUBSYSTEM_STATE`.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
