import unittest
from python.simulation.console_twin import ConsoleDigitalTwin, PROFILES

class TestKernelSimulation(unittest.TestCase):
    def test_hardware_profiles(self):
        self.assertIn("AUREOM_CONSOLE", PROFILES)
        self.assertEqual(PROFILES["AUREOM_CONSOLE"].cpu_cores, 8)
        self.assertEqual(PROFILES["AUREOM_CONSOLE"].ram_gb, 16)

    def test_digital_twin_tick(self):
        twin = ConsoleDigitalTwin("AUREOM_CONSOLE")
        twin.running_game = "Neon Vanguard"
        twin.tick()
        self.assertGreater(twin.cpu_load, 0.4)
        self.assertGreater(twin.gpu_load, 0.4)
        self.assertGreater(twin.fan_rpm, 1000)

    def test_failure_simulation(self):
        twin = ConsoleDigitalTwin()
        res = twin.simulate_failure("CONTROLLER_DISCONNECT")
        self.assertTrue(res["handled"])

if __name__ == '__main__':
    unittest.main()
