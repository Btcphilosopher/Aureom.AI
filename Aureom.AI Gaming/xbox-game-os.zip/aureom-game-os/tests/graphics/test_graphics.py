import unittest

class TestGraphics(unittest.TestCase):
    def test_subsystem_graphics(self):
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()
