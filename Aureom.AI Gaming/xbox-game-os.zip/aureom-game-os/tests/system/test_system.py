import unittest

class TestSystem(unittest.TestCase):
    def test_subsystem_system(self):
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()
