import unittest

class TestNetwork(unittest.TestCase):
    def test_subsystem_network(self):
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()
