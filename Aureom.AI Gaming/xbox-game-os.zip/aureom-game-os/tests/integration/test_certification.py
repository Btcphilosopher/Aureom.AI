import unittest
from python.certification.certification_engine import CertificationEngine

class TestCertification(unittest.TestCase):
    def test_certification_suite(self):
        engine = CertificationEngine()
        report = engine.run_full_suite("aegame.aureom.neon-vanguard")
        self.assertEqual(report["total_rules"], 18)
        self.assertEqual(report["passed"], 18)
        self.assertEqual(report["overall_status"], "APPROVED")

if __name__ == '__main__':
    unittest.main()
