package org.aureom.dashboard
class DashboardController { fun refresh() = "Refreshed" }
