package org.aureom.dev
class DevConsole { fun runDiagnostics() = true }
