package org.aureom.companion
class CompanionApp { fun connect() = true }
