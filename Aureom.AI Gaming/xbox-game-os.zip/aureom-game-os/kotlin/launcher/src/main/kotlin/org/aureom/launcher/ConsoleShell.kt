package org.aureom.launcher

data class UserSession(val userId: String, val gamertag: String, val gamerscore: Int)

enum class DashboardView {
    HOME, LIBRARY, STORE, PROFILE, FRIENDS, PARTIES, ACHIEVEMENTS, SETTINGS, DOWNLOADS, SYSTEM, DEVELOPER
}

class AureomConsoleShell {
    private var activeView: DashboardView = DashboardView.HOME
    private var currentUser = UserSession("usr_aureom_01", "AureomPilot", 1450)

    fun navigateTo(view: DashboardView) {
        activeView = view
        println("[AureomShell] Navigation: Switched to view: \$view")
    }

    fun renderHeader(): String {
        return "AUREOM OS | 60 FPS | User: \${currentUser.gamertag} (\${currentUser.gamerscore} G)"
    }
}
