#pragma once
#include <string>
#include <vector>

namespace Aureom::OS {
class IPCChannel {
public:
    static bool SendToRuntime(uint64_t target_pid, const std::string& message_payload);
    static std::string ReceiveFromKernel();
};
}
