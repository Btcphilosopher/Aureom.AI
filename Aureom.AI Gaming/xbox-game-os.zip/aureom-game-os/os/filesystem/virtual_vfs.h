#pragma once
#include <string>
#include <vector>

namespace Aureom::OS {
class VirtualVFS {
public:
    static bool MountPackage(const std::string& package_path, const std::string& mount_point);
    static bool ReadFile(const std::string& virtual_path, std::vector<uint8_t>& out_bytes);
};
}
