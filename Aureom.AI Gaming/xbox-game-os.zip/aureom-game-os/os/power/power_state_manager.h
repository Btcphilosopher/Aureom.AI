#pragma once

namespace Aureom::OS {
enum class PowerProfile { PERFORMANCE, BALANCED, QUIET, BATTERY, THERMAL_LIMIT };
class PowerStateManager {
public:
    static void SetProfile(PowerProfile profile);
    static PowerProfile GetCurrentProfile();
    static float GetCurrentWattage();
};
}
