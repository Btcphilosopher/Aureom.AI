#pragma once
#include <string>
#include <cstdint>

namespace Aureom::OS {
struct ProcessDescriptor {
    uint64_t pid;
    std::string game_id;
    uint64_t ram_limit_bytes;
    bool network_allowed;
};
}
