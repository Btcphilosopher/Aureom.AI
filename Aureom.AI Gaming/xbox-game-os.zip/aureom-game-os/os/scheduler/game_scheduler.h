#pragma once
#include <cstdint>
#include <vector>

namespace Aureom::OS {
enum class ThreadAffinity { RenderThread, AudioThread, PhysicsThread, WorkerPool };
struct ScheduledTask {
    uint64_t task_id;
    ThreadAffinity affinity;
    uint32_t priority_level; // 0 (Highest/Render) to 15 (Idle)
};
class GameScheduler {
public:
    void Schedule(const ScheduledTask& task);
    void YieldSlice();
};
}
