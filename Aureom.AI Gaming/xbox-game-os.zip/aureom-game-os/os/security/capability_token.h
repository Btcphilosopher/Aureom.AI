#pragma once
#include <cstdint>

namespace Aureom::OS {
enum CapabilityFlags : uint32_t {
    CAP_GRAPHICS_QUEUE = 1 << 0,
    CAP_AUDIO_STREAM   = 1 << 1,
    CAP_INPUT_POLL     = 1 << 2,
    CAP_SAVE_DATA      = 1 << 3,
    CAP_NET_SOCKET     = 1 << 4
};
struct CapabilityToken {
    uint64_t token_id;
    uint32_t granted_flags;
};
}
