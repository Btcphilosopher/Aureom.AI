#pragma once
#include <cstddef>
#include <cstdint>

namespace Aureom::OS {
class GameMemoryArena {
public:
    explicit GameMemoryArena(size_t total_bytes);
    ~GameMemoryArena();
    void* Allocate(size_t bytes, size_t alignment);
    void Reset();
    size_t GetUsedBytes() const { return used_offset_; }
private:
    uint8_t* base_ptr_{nullptr};
    size_t capacity_{0};
    size_t used_offset_{0};
};
}
