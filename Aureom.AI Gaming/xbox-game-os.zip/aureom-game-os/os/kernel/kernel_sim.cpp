#include "kernel_sim.h"
#include <iostream>

namespace Aureom::Kernel {

GameProcess::GameProcess(uint64_t pid, const std::string& game_id, const std::string& user_id, const ResourceBudget& budget)
    : pid_(pid), game_id_(game_id), user_id_(user_id), budget_(budget) {}

KernelSim& KernelSim::Instance() {
    static KernelSim instance;
    return instance;
}

bool KernelSim::Initialize() {
    initialized_ = true;
    std::cout << "[AureomKernelSim] Initialized simulation kernel subsystem on Linux Host." << std::endl;
    return true;
}

void KernelSim::Shutdown() {
    for (auto& proc : processes_) {
        proc->SetState(ProcessState::TERMINATING);
    }
    processes_.clear();
    initialized_ = false;
    std::cout << "[AureomKernelSim] Kernel shutdown completed cleanly." << std::endl;
}

std::shared_ptr<GameProcess> KernelSim::LaunchGame(const std::string& game_id, const std::string& user_id, const ResourceBudget& budget) {
    if (!initialized_) Initialize();
    auto proc = std::make_shared<GameProcess>(next_pid_++, game_id, user_id, budget);
    proc->SetState(ProcessState::RUNNING);
    processes_.push_back(proc);
    std::cout << "[AureomKernelSim] Game launched: " << game_id << " with PID " << proc->GetPid() << std::endl;
    return proc;
}

bool KernelSim::SuspendGame(uint64_t pid) {
    for (auto& proc : processes_) {
        if (proc->GetPid() == pid) {
            proc->SetState(ProcessState::SUSPENDED);
            std::cout << "[AureomKernelSim] Game suspended PID: " << pid << std::endl;
            return true;
        }
    }
    return false;
}

bool KernelSim::ResumeGame(uint64_t pid) {
    for (auto& proc : processes_) {
        if (proc->GetPid() == pid) {
            proc->SetState(ProcessState::RUNNING);
            std::cout << "[AureomKernelSim] Game resumed PID: " << pid << std::endl;
            return true;
        }
    }
    return false;
}

bool KernelSim::TerminateGame(uint64_t pid) {
    for (auto it = processes_.begin(); it != processes_.end(); ++it) {
        if ((*it)->GetPid() == pid) {
            (*it)->SetState(ProcessState::TERMINATING);
            processes_.erase(it);
            std::cout << "[AureomKernelSim] Game terminated PID: " << pid << std::endl;
            return true;
        }
    }
    return false;
}

} // namespace Aureom::Kernel
