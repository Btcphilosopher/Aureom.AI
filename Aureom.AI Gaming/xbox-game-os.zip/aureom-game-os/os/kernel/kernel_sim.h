#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <memory>

namespace Aureom::Kernel {

enum class ProcessState {
    CREATED, INSTALLING, READY, LAUNCHING, RUNNING, SUSPENDED, BACKGROUND, TERMINATING, CRASHED, UNINSTALLED
};

struct ResourceBudget {
    uint32_t cpu_cores{8};
    float cpu_quota_pct{95.0f};
    uint64_t ram_bytes{12ULL * 1024 * 1024 * 1024};
    uint64_t vram_bytes{10ULL * 1024 * 1024 * 1024};
    uint64_t storage_quota_bytes{100ULL * 1024 * 1024 * 1024};
    uint32_t max_audio_channels{128};
    uint32_t network_bandwidth_mbps{1000};
};

struct ResourceUsage {
    float cpu_used_cores{0.0f};
    float gpu_utilization_pct{0.0f};
    uint64_t ram_used_bytes{0};
    uint64_t vram_used_bytes{0};
    uint64_t io_read_bytes_sec{0};
    uint64_t io_write_bytes_sec{0};
    float temperature_celsius{45.0f};
    float power_draw_watts{85.0f};
};

class GameProcess {
public:
    GameProcess(uint64_t pid, const std::string& game_id, const std::string& user_id, const ResourceBudget& budget);
    
    uint64_t GetPid() const { return pid_; }
    const std::string& GetGameId() const { return game_id_; }
    ProcessState GetState() const { return state_; }
    void SetState(ProcessState new_state) { state_ = new_state; }

    const ResourceBudget& GetBudget() const { return budget_; }
    ResourceUsage GetCurrentUsage() const { return usage_; }
    void UpdateUsage(const ResourceUsage& new_usage) { usage_ = new_usage; }

private:
    uint64_t pid_;
    std::string game_id_;
    std::string user_id_;
    ProcessState state_{ProcessState::CREATED};
    ResourceBudget budget_;
    ResourceUsage usage_;
};

class KernelSim {
public:
    static KernelSim& Instance();
    bool Initialize();
    void Shutdown();

    std::shared_ptr<GameProcess> LaunchGame(const std::string& game_id, const std::string& user_id, const ResourceBudget& budget);
    bool SuspendGame(uint64_t pid);
    bool ResumeGame(uint64_t pid);
    bool TerminateGame(uint64_t pid);

private:
    KernelSim() = default;
    std::vector<std::shared_ptr<GameProcess>> processes_;
    uint64_t next_pid_{1000};
    bool initialized_{false};
};

} // namespace Aureom::Kernel
