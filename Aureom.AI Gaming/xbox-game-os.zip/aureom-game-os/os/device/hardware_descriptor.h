#pragma once
#include <string>

namespace Aureom::OS {
struct DeviceDescriptor {
    std::string device_id;
    std::string model_name;
    uint32_t bus_id;
    bool is_present;
};
}
