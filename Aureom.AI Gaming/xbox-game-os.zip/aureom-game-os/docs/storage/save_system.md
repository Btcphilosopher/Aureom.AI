# Aureom Cloud Save Architecture
Versioned, immutable save slots with SHA-256 validation. Local write is committed to a write-ahead log before cloud upload.
