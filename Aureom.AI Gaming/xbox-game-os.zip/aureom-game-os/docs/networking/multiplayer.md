# Aureom Multiplayer and Relay Protocol
Architecture: Client -> Relay -> Matchmaker -> Session -> Peers
Uses encrypted UDP packets with DTLS session keys, deterministic jitter buffer, and tick-rate synchronization.
