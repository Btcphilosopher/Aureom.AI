# Aureom SDK Guide
Exposes clean C and C++ interfaces: AureomInitialize(), AureomUser(), AureomGraphics(), AureomAudio(), AureomStorage().
