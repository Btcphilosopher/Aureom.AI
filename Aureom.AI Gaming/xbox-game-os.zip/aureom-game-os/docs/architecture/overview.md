# Aureom Game OS Architecture

## Philosophy: First-Class Game Process
Unlike general-purpose operating systems where a game is treated as an arbitrary desktop process competing with background Daemons, Aureom Game OS allocates deterministic compute, memory, and bandwidth budgets via `ResourceManager` and `GameProcess`.

### Memory Hierarchy
- OS / System Partition: Fixed reservation (e.g., 3.5 GB on AUREOM_CONSOLE)
- Game Title Partition: Deterministic unfragmented Physical Allocation (e.g., 12.5 GB unified RAM/VRAM)
- Sandboxing: Capability-based handles; no raw POSIX arbitrary filesystem write permissions.
