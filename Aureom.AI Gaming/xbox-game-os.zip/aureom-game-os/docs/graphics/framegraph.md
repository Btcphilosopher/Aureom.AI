# Aureom FrameGraph Execution Model

The `FrameGraph` is a directed acyclic graph (DAG) of render passes:
`ShadowPass -> DepthPrepass -> GBuffer -> Lighting -> Reflection -> RayTracing -> Transparency -> PostProcessing -> TemporalUpscaling -> UI -> Present`

Memory is aliased across non-overlapping transient resources, eliminating VRAM waste.
