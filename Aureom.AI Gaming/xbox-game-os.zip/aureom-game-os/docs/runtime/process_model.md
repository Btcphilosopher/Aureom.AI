# Aureom Game Process & Sandbox Isolation
Games run under an unprivileged user ID with explicit capability handles for GPU queues, audio endpoints, and storage quotas.
