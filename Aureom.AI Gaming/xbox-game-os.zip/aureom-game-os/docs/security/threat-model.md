# Aureom Security & Anti-Cheat Architecture

## Core Security Tenets
1. **Server-Authoritative Networking**: No reliance on client-side memory trust.
2. **Cryptographically Signed GamePackages (`.aegame`)**: Ed25519 signatures validated at mount time.
3. **No Invasive Kernel Surveillance**: Anti-cheat is achieved through process sandboxing, replay verification, and server-side behavioral anomaly telemetry.
4. **Argon2id & Token Rotation**: Cloud tokens use short TTLs with strict audience scoping.
