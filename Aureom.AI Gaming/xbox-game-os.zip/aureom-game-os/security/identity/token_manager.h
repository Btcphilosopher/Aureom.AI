#pragma once
#include <string>
namespace Aureom::Security {
class TokenManager {
public:
    static std::string IssueToken(const std::string& user_id);
    static bool ValidateToken(const std::string& token);
};
}
