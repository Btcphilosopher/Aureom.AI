#pragma once
namespace Aureom::Security {
class PlatformAttestation {
public:
    static bool MeasurePlatformQuote();
};
}
