#pragma once
namespace Aureom::Security {
class SandboxPolicy {
public:
    static void EnforceGameSandbox();
};
}
