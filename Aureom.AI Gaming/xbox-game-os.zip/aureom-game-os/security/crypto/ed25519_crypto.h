#pragma once
#include <cstdint>
namespace Aureom::Security {
class CryptoEngine {
public:
    static bool VerifyHashSignature(const uint8_t* hash, const uint8_t* sig, const uint8_t* pubkey);
};
}
