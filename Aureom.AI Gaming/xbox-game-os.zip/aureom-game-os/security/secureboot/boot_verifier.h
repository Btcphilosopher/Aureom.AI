#pragma once
namespace Aureom::Security {
class BootVerifier {
public:
    static bool VerifyKernelChain();
};
}
