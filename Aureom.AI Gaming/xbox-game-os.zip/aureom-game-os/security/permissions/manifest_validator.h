#pragma once
#include <string>
#include <vector>
namespace Aureom::Security {
class ManifestValidator {
public:
    static bool ValidatePermissions(const std::vector<std::string>& perms);
};
}
