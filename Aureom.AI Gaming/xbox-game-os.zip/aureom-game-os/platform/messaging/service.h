#pragma once
#include <string>
namespace Aureom::Platform::Messaging {
class MessagingService {
public:
    bool IsAvailable() const { return true; }
};
}
