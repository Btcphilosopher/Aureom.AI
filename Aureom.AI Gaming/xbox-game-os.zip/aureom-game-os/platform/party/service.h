#pragma once
#include <string>
namespace Aureom::Platform::Party {
class PartyService {
public:
    bool IsAvailable() const { return true; }
};
}
