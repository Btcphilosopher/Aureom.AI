#pragma once
#include <string>
namespace Aureom::Platform::Friends {
class FriendsService {
public:
    bool IsAvailable() const { return true; }
};
}
