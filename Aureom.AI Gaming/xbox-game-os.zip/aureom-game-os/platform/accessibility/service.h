#pragma once
#include <string>
namespace Aureom::Platform::Accessibility {
class AccessibilityService {
public:
    bool IsAvailable() const { return true; }
};
}
