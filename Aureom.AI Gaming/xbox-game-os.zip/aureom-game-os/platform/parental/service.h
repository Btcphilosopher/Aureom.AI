#pragma once
#include <string>
namespace Aureom::Platform::Parental {
class ParentalService {
public:
    bool IsAvailable() const { return true; }
};
}
