#pragma once
#include <string>
namespace Aureom::Platform::Identity {
class IdentityService {
public:
    bool IsAvailable() const { return true; }
};
}
