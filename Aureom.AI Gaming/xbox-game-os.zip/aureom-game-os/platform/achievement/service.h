#pragma once
#include <string>
namespace Aureom::Platform::Achievement {
class AchievementService {
public:
    bool IsAvailable() const { return true; }
};
}
