#pragma once
#include <string>
namespace Aureom::Platform::Entitlement {
class EntitlementService {
public:
    bool IsAvailable() const { return true; }
};
}
