#pragma once
namespace Aureom::Distribution::Updates {
class DistributionComponent {
public:
    void Execute() {}
};
}
