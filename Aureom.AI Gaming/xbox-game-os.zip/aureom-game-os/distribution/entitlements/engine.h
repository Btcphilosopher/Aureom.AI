#pragma once
namespace Aureom::Distribution::Entitlements {
class DistributionComponent {
public:
    void Execute() {}
};
}
