#pragma once
namespace Aureom::Distribution::Patching {
class DistributionComponent {
public:
    void Execute() {}
};
}
