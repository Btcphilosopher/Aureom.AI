#pragma once
namespace Aureom::Distribution::Catalogue {
class DistributionComponent {
public:
    void Execute() {}
};
}
