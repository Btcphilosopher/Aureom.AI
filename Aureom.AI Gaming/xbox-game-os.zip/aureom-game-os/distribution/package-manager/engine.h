#pragma once
namespace Aureom::Distribution::Package_Manager {
class DistributionComponent {
public:
    void Execute() {}
};
}
