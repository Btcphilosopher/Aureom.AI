#pragma once
namespace Aureom::Distribution::Store {
class DistributionComponent {
public:
    void Execute() {}
};
}
