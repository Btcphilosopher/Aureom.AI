#pragma once
namespace Aureom::Audio {
class AudioEndpoint {
public:
    bool OpenDefaultPlaybackDevice();
};
}
