#pragma once
#include <vector>
namespace Aureom::Audio {
class OpusVoiceCodec {
public:
    static std::vector<uint8_t> EncodeVoice(const float* pcm_samples, int sample_count);
};
}
