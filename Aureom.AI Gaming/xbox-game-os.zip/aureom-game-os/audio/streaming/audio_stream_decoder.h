#pragma once
namespace Aureom::Audio {
class AudioStreamDecoder {
public:
    void StreamChunk();
};
}
