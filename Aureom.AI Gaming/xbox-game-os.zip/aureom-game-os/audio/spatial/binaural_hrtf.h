#pragma once
namespace Aureom::Audio {
class BinauralHRTFProcessor {
public:
    void Convolve(float x, float y, float z, const float* in_samples, float* out_left, float* out_right);
};
}
