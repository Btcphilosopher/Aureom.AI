#pragma once
namespace Aureom::Audio {
class AudioMixer {
public:
    void ProcessMasterBus(float* interleaved_out, int frame_count);
};
}
