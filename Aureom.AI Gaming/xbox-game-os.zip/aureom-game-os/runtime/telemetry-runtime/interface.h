#pragma once
namespace Aureom::Runtime::Telemetry_Runtime {
class Subsystem {
public:
    virtual bool Initialize() = 0;
    virtual void Tick(float dt) = 0;
    virtual void Shutdown() = 0;
    virtual ~Subsystem() = default;
};
}
