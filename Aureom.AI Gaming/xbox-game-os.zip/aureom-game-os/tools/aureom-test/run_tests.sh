#!/bin/bash
echo "[aureom-test] Running automated compliance test battery..."
python3 -m unittest discover -s tests
