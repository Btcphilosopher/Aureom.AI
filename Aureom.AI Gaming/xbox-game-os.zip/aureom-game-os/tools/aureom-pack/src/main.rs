fn main() {
    println!("[aureom-pack] Aureom Game Packaging Utility v1.0.0");
    println!("Commands: build, validate, sign, inspect, verify");
}
