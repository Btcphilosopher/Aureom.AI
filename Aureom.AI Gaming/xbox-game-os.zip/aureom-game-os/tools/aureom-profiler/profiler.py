# Aureom Profiler
def sample_timelines():
    return {"cpu_ms": 11.2, "gpu_ms": 13.4, "fps": 60.0}
