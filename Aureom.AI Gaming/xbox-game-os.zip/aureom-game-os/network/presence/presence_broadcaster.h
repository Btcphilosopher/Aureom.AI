#pragma once
#include <string>
namespace Aureom::Network {
class PresenceBroadcaster {
public:
    void Broadcast(const std::string& state);
};
}
