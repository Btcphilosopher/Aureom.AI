#pragma once
#include <cstdint>
namespace Aureom::Network {
class UDPTransport {
public:
    bool Bind(uint16_t port);
    int SendTo(const void* buf, size_t len, const char* ip, uint16_t port);
};
}
