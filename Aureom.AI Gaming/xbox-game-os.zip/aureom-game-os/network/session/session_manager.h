#pragma once
#include <string>
namespace Aureom::Network {
class GameSessionManager {
public:
    void CreateLobby(const std::string& host_player_id);
};
}
