#pragma once
#include <string>
namespace Aureom::Network {
struct MatchRequest { std::string player_id; int mmr; std::string region; };
class MatchmakerSim {
public:
    std::string FindMatch(const MatchRequest& req);
};
}
