#pragma once
namespace Aureom::Network {
class StunTurnRelay {
public:
    bool EstablishRelayConnection();
};
}
