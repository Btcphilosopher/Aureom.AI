# GDB stub integration
def attach(): pass
