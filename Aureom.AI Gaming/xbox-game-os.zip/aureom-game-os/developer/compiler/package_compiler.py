# Package Compiler
class PackageCompiler:
    def compile_aegame(self, source_dir, out_file):
        print(f"Compiling {source_dir} -> {out_file}")
