# Linux Simulator Host
def start_host():
    print("[AureomSimulator] Host started.")
