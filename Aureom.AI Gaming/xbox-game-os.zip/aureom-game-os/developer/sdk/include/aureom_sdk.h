#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

typedef struct {
    const char* game_id;
    const char* title;
    const char* version;
} AureomInitParams;

typedef enum {
    AUREOM_SUCCESS = 0,
    AUREOM_ERROR_NOT_INITIALIZED = 1,
    AUREOM_ERROR_AUTH_EXPIRED = 2,
    AUREOM_ERROR_ENTITLEMENT_MISSING = 3,
    AUREOM_ERROR_SAVE_CONFLICT = 4,
    AUREOM_ERROR_RESOURCE_EXHAUSTED = 5
} AureomResult;

// Core SDK lifecycle
AureomResult AureomInitialize(const AureomInitParams* params);
AureomResult AureomShutdown(void);

// Subsystem handles
const char* AureomUser_GetActiveGamerTag(void);
uint64_t AureomUser_GetActiveUserId(void);

// Achievements
AureomResult AureomAchievements_Unlock(const char* achievement_id);
AureomResult AureomAchievements_SetProgress(const char* achievement_id, float percent);

// Cloud Save
AureomResult AureomStorage_WriteSave(const char* slot_name, const void* data, uint64_t size_bytes);
AureomResult AureomStorage_ReadSave(const char* slot_name, void* out_buffer, uint64_t* inout_size);

// Telemetry
void AureomTelemetry_EmitEvent(const char* event_name, const char* json_payload);

#ifdef __cplusplus
}
#endif
