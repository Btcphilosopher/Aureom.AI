# Trace collector
def collect(): return {}
