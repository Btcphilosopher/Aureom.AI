# Certification CLI
from python.certification.certification_engine import CertificationEngine
def run_cli():
    print(CertificationEngine().run_full_suite("test_game"))
