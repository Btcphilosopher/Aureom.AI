# Aureom CLI Runner
import sys
def run():
    print("[aureom-cli] Ready")
if __name__ == '__main__':
    run()
