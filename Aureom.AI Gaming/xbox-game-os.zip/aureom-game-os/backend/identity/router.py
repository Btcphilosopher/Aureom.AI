from fastapi import APIRouter
router = APIRouter(prefix="/identity")
@router.get("/health")
def health():
    return {"module": "identity", "status": "UP"}
