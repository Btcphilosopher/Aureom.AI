from fastapi import APIRouter
router = APIRouter(prefix="/multiplayer")
@router.get("/health")
def health():
    return {"module": "multiplayer", "status": "UP"}
