from fastapi import APIRouter
router = APIRouter(prefix="/commerce")
@router.get("/health")
def health():
    return {"module": "commerce", "status": "UP"}
