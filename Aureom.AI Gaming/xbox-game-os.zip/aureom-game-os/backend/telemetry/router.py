from fastapi import APIRouter
router = APIRouter(prefix="/telemetry")
@router.get("/health")
def health():
    return {"module": "telemetry", "status": "UP"}
