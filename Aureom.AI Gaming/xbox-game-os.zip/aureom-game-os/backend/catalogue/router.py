from fastapi import APIRouter
router = APIRouter(prefix="/catalogue")
@router.get("/health")
def health():
    return {"module": "catalogue", "status": "UP"}
