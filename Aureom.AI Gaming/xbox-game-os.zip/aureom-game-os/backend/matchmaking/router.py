from fastapi import APIRouter
router = APIRouter(prefix="/matchmaking")
@router.get("/health")
def health():
    return {"module": "matchmaking", "status": "UP"}
