"""
Aureom Console Digital Twin Simulator
Models the physical and thermal behavior of AUREOM_CONSOLE, AUREOM_HANDHELD, AUREOM_DEV_PC, and AUREOM_CLOUD.
"""

from dataclasses import dataclass
import random
import time

@dataclass
class HardwareProfile:
    name: str
    cpu_cores: int
    gpu_tflops: float
    ram_gb: int
    vram_gb: int
    power_limit_watts: float
    max_temp_c: float

PROFILES = {
    "AUREOM_CONSOLE": HardwareProfile("Aureom Living Room Console", 8, 12.5, 16, 12, 220.0, 85.0),
    "AUREOM_HANDHELD": HardwareProfile("Aureom Handheld Deck", 4, 3.8, 16, 6, 25.0, 75.0),
    "AUREOM_DEV_PC": HardwareProfile("Aureom Workstation Dev PC", 16, 24.0, 64, 24, 450.0, 90.0),
    "AUREOM_CLOUD": HardwareProfile("Aureom Elastic Cloud Node", 16, 30.0, 32, 24, 350.0, 80.0)
}

class ConsoleDigitalTwin:
    def __init__(self, profile_name="AUREOM_CONSOLE"):
        self.profile = PROFILES.get(profile_name, PROFILES["AUREOM_CONSOLE"])
        self.power_state = "BALANCED" # PERFORMANCE, BALANCED, QUIET, BATTERY, THERMAL_LIMIT
        self.current_temp = 42.0
        self.fan_rpm = 1200
        self.cpu_load = 0.15
        self.gpu_load = 0.10
        self.running_game = None

    def tick(self, target_fps=60):
        if self.running_game:
            self.cpu_load = 0.65 + random.uniform(-0.05, 0.05)
            self.gpu_load = 0.75 + random.uniform(-0.08, 0.08)
            heat_gain = (self.cpu_load + self.gpu_load) * 0.4
            self.current_temp = min(self.profile.max_temp_c, self.current_temp + heat_gain - 0.25)
            self.fan_rpm = int(1200 + (self.current_temp - 40) * 80)
        else:
            self.current_temp = max(38.0, self.current_temp - 0.5)
            self.fan_rpm = max(900, self.fan_rpm - 50)
            self.cpu_load = 0.05
            self.gpu_load = 0.02

    def simulate_failure(self, failure_type):
        return {
            "failure": failure_type,
            "handled": True,
            "action_taken": f"Subsystem invoked deterministic failsafe for {failure_type}"
        }

if __name__ == "__main__":
    twin = ConsoleDigitalTwin()
    print(f"Digital Twin active: {twin.profile.name}")
