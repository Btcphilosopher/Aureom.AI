pub struct Matchmaker {
    pub region: String,
}

impl Matchmaker {
    pub fn new(region: &str) -> Self {
        Self { region: region.to_string() }
    }
}
