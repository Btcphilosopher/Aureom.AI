use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GamePackage {
    pub game_id: String,
    pub title: String,
    pub publisher: String,
    pub developer: String,
    pub executable: String,
    pub version: String,
    pub architecture: String,
    pub dependencies: Vec<String>,
    pub save_schema_version: u32,
    pub permissions: Vec<String>,
    pub age_rating: String,
    pub resource_budget: ResourceBudget,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceBudget {
    pub cpu_cores: u32,
    pub ram_mb: u64,
    pub vram_mb: u64,
    pub storage_quota_gb: u64,
}

impl GamePackage {
    pub fn new_synthetic_sample() -> Self {
        Self {
            game_id: "aegame.aureom.neon-vanguard".to_string(),
            title: "Neon Vanguard: Aureom Odyssey".to_string(),
            publisher: "Aureom Studios".to_string(),
            developer: "Odyssey Interactive".to_string(),
            executable: "bin/neon_vanguard.bin".to_string(),
            version: "1.2.0".to_string(),
            architecture: "x86_64".to_string(),
            dependencies: vec!["aureom.runtime.v1".to_string()],
            save_schema_version: 2,
            permissions: vec![
                "controller.gamepad".to_string(),
                "audio.spatial".to_string(),
                "storage.save".to_string(),
                "network.multiplayer".to_string()
            ],
            age_rating: "ESRB_TEEN".to_string(),
            resource_budget: ResourceBudget {
                cpu_cores: 8,
                ram_mb: 12288,
                vram_mb: 10240,
                storage_quota_gb: 85,
            },
        }
    }
}
