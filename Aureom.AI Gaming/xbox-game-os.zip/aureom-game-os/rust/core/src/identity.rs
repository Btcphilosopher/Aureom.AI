use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlayerProfile {
    pub player_id: String,
    pub gamertag: String,
    pub avatar_url: String,
    pub locale: String,
    pub timezone: String,
    pub gamerscore: u32,
    pub presence_state: String,
}
