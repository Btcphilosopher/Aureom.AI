use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HardwareProfile {
    pub name: String,
    pub cpu_cores: u32,
    pub gpu_model: String,
    pub memory_gb: u32,
    pub target_fps: u32,
}
