#pragma once
#include <cstdint>
namespace Aureom::Input {
struct GamepadState {
    float left_stick_x, left_stick_y;
    float right_stick_x, right_stick_y;
    float left_trigger, right_trigger;
    uint32_t buttons;
};
}
