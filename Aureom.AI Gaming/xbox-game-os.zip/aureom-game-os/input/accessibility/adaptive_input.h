#pragma once
namespace Aureom::Input {
class AdaptiveInputRemapper {
public:
    void RemapButton(uint32_t source_btn, uint32_t target_btn);
};
}
