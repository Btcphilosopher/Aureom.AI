#pragma once
namespace Aureom::Input {
class KeyboardHandler { public: bool IsKeyDown(int key_code); };
}
