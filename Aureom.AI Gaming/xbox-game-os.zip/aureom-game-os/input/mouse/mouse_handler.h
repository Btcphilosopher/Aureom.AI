#pragma once
namespace Aureom::Input {
class MouseHandler { public: void GetDelta(int& dx, int& dy); };
}
