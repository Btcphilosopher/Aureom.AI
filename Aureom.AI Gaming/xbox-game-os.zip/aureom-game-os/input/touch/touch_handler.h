#pragma once
namespace Aureom::Input {
class TouchHandler { public: void RegisterTap(float x, float y); };
}
