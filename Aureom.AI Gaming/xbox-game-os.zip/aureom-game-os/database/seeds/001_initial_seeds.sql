-- Initial seeds for Aureom Platform
INSERT INTO games.catalog (game_id, title, publisher, developer, current_version, age_rating)
VALUES ('aegame.aureom.neon-vanguard', 'Neon Vanguard: Aureom Odyssey', 'Aureom Studios', 'Odyssey Interactive', '1.2.0', 'ESRB_TEEN')
ON CONFLICT DO NOTHING;
