-- Migration 001 v1
-- Indexes and performance tuning
CREATE INDEX IF NOT EXISTS idx_entitlements_user ON library.entitlements(user_id);
CREATE INDEX IF NOT EXISTS idx_saves_user_game ON saves.slots(user_id, game_id);
