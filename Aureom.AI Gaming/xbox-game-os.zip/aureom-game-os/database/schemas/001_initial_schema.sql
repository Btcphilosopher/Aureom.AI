-- AUREOM GAME OS PLATFORM DATABASE SCHEMA
-- PostgreSQL 15+ compatible

CREATE SCHEMA IF NOT EXISTS identity;
CREATE SCHEMA IF NOT EXISTS games;
CREATE SCHEMA IF NOT EXISTS library;
CREATE SCHEMA IF NOT EXISTS achievements;
CREATE SCHEMA IF NOT EXISTS saves;
CREATE SCHEMA IF NOT EXISTS store;
CREATE SCHEMA IF NOT EXISTS multiplayer;
CREATE SCHEMA IF NOT EXISTS telemetry;
CREATE SCHEMA IF NOT EXISTS audit;

-- Identity
CREATE TABLE identity.users (
    user_id UUID PRIMARY KEY,
    gamertag VARCHAR(32) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL, -- Argon2id hash
    avatar_url TEXT,
    locale VARCHAR(10) DEFAULT 'en_US',
    timezone VARCHAR(50) DEFAULT 'UTC',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Games Catalogue
CREATE TABLE games.catalog (
    game_id VARCHAR(128) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    publisher VARCHAR(255) NOT NULL,
    developer VARCHAR(255) NOT NULL,
    current_version VARCHAR(32) NOT NULL,
    age_rating VARCHAR(16) NOT NULL,
    esrb_descriptor TEXT,
    pegi_rating INT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Library & Entitlements
CREATE TABLE library.entitlements (
    entitlement_id UUID PRIMARY KEY,
    user_id UUID REFERENCES identity.users(user_id) ON DELETE CASCADE,
    game_id VARCHAR(128) REFERENCES games.catalog(game_id),
    source VARCHAR(64) NOT NULL, -- PURCHASE, SUBSCRIPTION, DEMO
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE'
);

-- Achievements
CREATE TABLE achievements.definitions (
    achievement_id VARCHAR(64) PRIMARY KEY,
    game_id VARCHAR(128) REFERENCES games.catalog(game_id),
    title VARCHAR(128) NOT NULL,
    description TEXT NOT NULL,
    gamerscore INT NOT NULL CHECK (gamerscore >= 0),
    is_hidden BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE achievements.user_progress (
    user_id UUID REFERENCES identity.users(user_id) ON DELETE CASCADE,
    achievement_id VARCHAR(64) REFERENCES achievements.definitions(achievement_id),
    progress_pct NUMERIC(5, 2) DEFAULT 0.00,
    unlocked_at TIMESTAMPTZ,
    PRIMARY KEY(user_id, achievement_id)
);

-- Cloud Saves
CREATE TABLE saves.slots (
    save_id UUID PRIMARY KEY,
    user_id UUID REFERENCES identity.users(user_id) ON DELETE CASCADE,
    game_id VARCHAR(128) REFERENCES games.catalog(game_id),
    slot_name VARCHAR(64) NOT NULL,
    version INT NOT NULL,
    size_bytes BIGINT NOT NULL,
    sha256_hash CHAR(64) NOT NULL,
    storage_url TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, game_id, slot_name, version)
);

-- Digital Store (DECIMAL ARITHMETIC - NEVER FLOATS FOR MONEY)
CREATE TABLE store.products (
    product_id UUID PRIMARY KEY,
    game_id VARCHAR(128) REFERENCES games.catalog(game_id),
    price_usd NUMERIC(10, 2) NOT NULL CHECK (price_usd >= 0.00),
    price_eur NUMERIC(10, 2) NOT NULL CHECK (price_eur >= 0.00),
    price_gbp NUMERIC(10, 2) NOT NULL CHECK (price_gbp >= 0.00),
    price_jpy NUMERIC(10, 0) NOT NULL CHECK (price_jpy >= 0),
    discount_pct NUMERIC(5, 2) DEFAULT 0.00,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Audit System (Append-only)
CREATE TABLE audit.events (
    event_id UUID PRIMARY KEY,
    actor_id VARCHAR(64) NOT NULL,
    actor_type VARCHAR(32) NOT NULL,
    action VARCHAR(64) NOT NULL,
    resource_type VARCHAR(64) NOT NULL,
    resource_id VARCHAR(128) NOT NULL,
    ip_hash CHAR(64) NOT NULL,
    result VARCHAR(32) NOT NULL,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
