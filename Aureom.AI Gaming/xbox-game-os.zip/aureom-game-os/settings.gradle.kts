rootProject.name = "aureom-game-os"
include(":kotlin:launcher")
include(":kotlin:dashboard")
include(":kotlin:developer-console")
include(":kotlin:companion")
