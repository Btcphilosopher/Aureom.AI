#pragma once
#include <string>
namespace Aureom::Storage {
class EncryptedFilesystem {
public:
    static bool EncryptVolume(const std::string& volume_path);
};
}
