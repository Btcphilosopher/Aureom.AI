#pragma once
#include <string>
namespace Aureom::Storage {
class LocalKVStore {
public:
    void Put(const std::string& key, const std::string& val);
    std::string Get(const std::string& key);
};
}
