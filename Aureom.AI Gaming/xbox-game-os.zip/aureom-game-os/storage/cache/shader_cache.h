#pragma once
#include <string>
namespace Aureom::Storage {
class ShaderCache {
public:
    static bool LookupBlob(const std::string& hash_key, void* out_blob);
};
}
