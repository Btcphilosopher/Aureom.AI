#pragma once
#include <string>
namespace Aureom::Storage {
class AEGamePackageReader {
public:
    bool Open(const std::string& path);
};
}
