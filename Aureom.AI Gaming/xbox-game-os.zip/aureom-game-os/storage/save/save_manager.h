#pragma once
#include <string>
#include <vector>
namespace Aureom::Storage {
class SaveManager {
public:
    static bool CommitSave(const std::string& slot, const std::vector<uint8_t>& payload);
};
}
