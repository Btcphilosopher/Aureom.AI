#include <iostream>
int main() {
    std::cout << "[GraphicsDemo] FrameGraph pipeline initialized." << std::endl;
    return 0;
}
