#include <iostream>
int main() {
    std::cout << "[MultiplayerDemo] Connected to simulated relay." << std::endl;
    return 0;
}
