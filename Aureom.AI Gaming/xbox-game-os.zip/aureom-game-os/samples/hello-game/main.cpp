#include "aureom_sdk.h"
#include <iostream>

int main() {
    AureomInitParams params;
    params.game_id = "aegame.aureom.sample-hello";
    params.title = "Aureom Reference Title: Hello Cosmos";
    params.version = "1.0.0";

    AureomResult res = AureomInitialize(&params);
    if (res != AUREOM_SUCCESS) {
        std::cerr << "Failed to initialize Aureom SDK" << std::endl;
        return 1;
    }

    std::cout << "[SampleGame] Running reference loop..." << std::endl;
    std::cout << "[SampleGame] Active user: " << AureomUser_GetActiveGamerTag() << std::endl;
    
    AureomAchievements_Unlock("ACH_FIRST_BOOT");
    AureomShutdown();
    return 0;
}
