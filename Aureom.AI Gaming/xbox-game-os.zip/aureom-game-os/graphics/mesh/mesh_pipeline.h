#pragma once
namespace Aureom::Graphics {
class MeshPipeline {
public:
    void Bind();
};
}
