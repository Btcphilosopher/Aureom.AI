#pragma once
namespace Aureom::Graphics {
class TemporalSuperResolution {
public:
    void Upscale(void* input_color, void* motion_vectors, void* depth, void* output_target);
};
}
