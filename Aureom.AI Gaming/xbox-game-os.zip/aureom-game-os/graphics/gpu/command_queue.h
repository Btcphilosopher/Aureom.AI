#pragma once
#include <cstdint>
namespace Aureom::Graphics {
class CommandQueue {
public:
    void Submit(void* command_buffer);
    void WaitForFence(uint64_t fence_value);
};
}
