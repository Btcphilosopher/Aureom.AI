#pragma once
#include <string>
#include <vector>
namespace Aureom::Graphics {
class ShaderCompiler {
public:
    static std::vector<uint32_t> CompileHLSLToSPIRV(const std::string& hlsl_source, const std::string& entry_point);
};
}
