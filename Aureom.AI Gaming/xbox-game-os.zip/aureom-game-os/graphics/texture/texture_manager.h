#pragma once
#include <string>
#include <cstdint>
namespace Aureom::Graphics {
struct TextureInfo { uint32_t width; uint32_t height; uint32_t format; };
class TextureManager {
public:
    uint64_t LoadTexture(const std::string& path);
};
}
