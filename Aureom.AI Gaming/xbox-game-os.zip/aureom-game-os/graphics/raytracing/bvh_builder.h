#pragma once
namespace Aureom::Graphics {
class BVHBuilder {
public:
    void BuildAccelerationStructure();
};
}
