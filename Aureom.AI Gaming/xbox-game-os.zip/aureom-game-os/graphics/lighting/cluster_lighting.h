#pragma once
namespace Aureom::Graphics {
class ClusterLightingSystem {
public:
    void UpdateLightClusters();
};
}
