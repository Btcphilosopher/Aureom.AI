#pragma once
namespace Aureom::Graphics {
class DeferredRenderer {
public:
    void RenderScene();
};
}
