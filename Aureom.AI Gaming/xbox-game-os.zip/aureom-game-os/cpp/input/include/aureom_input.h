#pragma once
#include <cstdint>
#include <string>

namespace Aureom::Input {

enum class ControlType {
    ButtonA, ButtonB, ButtonX, ButtonY,
    DpadUp, DpadDown, DpadLeft, DpadRight,
    LeftBumper, RightBumper,
    LeftTrigger, RightTrigger,
    LeftStickX, LeftStickY,
    RightStickX, RightStickY,
    Start, Select, AureomGuide
};

struct InputEvent {
    uint64_t timestamp_ns;
    uint32_t device_id;
    uint32_t player_id;
    ControlType control;
    float value;
    uint32_t action; // 0=Release, 1=Press, 2=Repeat
    uint32_t modifiers;
    uint64_t sequence;
};

class ControllerManager {
public:
    static ControllerManager& Instance();
    bool PollEvent(InputEvent& out_event);
    void SetVibration(uint32_t device_id, float low_freq_motor, float high_freq_motor);
    void SetTriggerHaptics(uint32_t device_id, float left_trigger_resist, float right_trigger_resist);
};

} // namespace Aureom::Input
