#include "aureom_input.h"
#include <iostream>

namespace Aureom::Input {

ControllerManager& ControllerManager::Instance() {
    static ControllerManager instance;
    return instance;
}

bool ControllerManager::PollEvent(InputEvent& out_event) {
    return false;
}

void ControllerManager::SetVibration(uint32_t device_id, float low, float high) {
    // Sends haptic vibration packet
}

void ControllerManager::SetTriggerHaptics(uint32_t device_id, float left, float right) {
    // Sends adaptive trigger feedback resistance
}

} // namespace Aureom::Input
