#pragma once
#include <string>
#include <memory>
#include <functional>

namespace Aureom::Runtime {

struct RuntimeConfig {
    std::string platform_target{"AUREOM_CONSOLE"};
    bool enable_telemetry{true};
    bool enable_spatial_audio{true};
    bool enable_hdr{true};
};

class AureomGameRuntime {
public:
    static AureomGameRuntime& Instance();
    bool Boot(const RuntimeConfig& config);
    bool LaunchTitle(const std::string& package_path);
    void Tick(float delta_time_seconds);
    void Suspend();
    void Resume();
    void Terminate();

private:
    AureomGameRuntime() = default;
    bool is_running_{false};
    RuntimeConfig config_;
};

} // namespace Aureom::Runtime
