#include <iostream>
#include <cstdint>

namespace Aureom::Runtime {

class ResourceManager {
public:
    struct HardwareTelemetry {
        float cpu_utilization{0.0f};
        float gpu_utilization{0.0f};
        uint64_t ram_used_mb{0};
        uint64_t vram_used_mb{0};
        float thermal_temp_c{0.0f};
    };

    static HardwareTelemetry Poll() {
        return HardwareTelemetry{
            .cpu_utilization = 68.4f,
            .gpu_utilization = 74.2f,
            .ram_used_mb = 9420,
            .vram_used_mb = 8150,
            .thermal_temp_c = 58.5f
        };
    }
};

} // namespace Aureom::Runtime
