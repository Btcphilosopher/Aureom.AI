#pragma once
#include <string>
#include <vector>
#include <memory>

namespace Aureom::Graphics {

enum class PassType {
    ShadowPass, DepthPrepass, GBuffer, Lighting, Reflection, RayTracing, Transparency, PostProcessing, TemporalUpscaling, UI, Present
};

struct RenderPassNode {
    PassType type;
    std::string name;
    std::vector<std::string> inputs;
    std::vector<std::string> outputs;
    bool is_async_compute{false};
};

class FrameGraph {
public:
    void AddPass(const RenderPassNode& node);
    void Compile();
    void Execute();

    const std::vector<RenderPassNode>& GetNodes() const { return nodes_; }

private:
    std::vector<RenderPassNode> nodes_;
    bool compiled_{false};
};

class GraphicsDevice {
public:
    bool Initialize();
    void BeginFrame();
    void EndFrame();
};

} // namespace Aureom::Graphics
