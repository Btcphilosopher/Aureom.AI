#include "aureom_graphics.h"
#include <iostream>

namespace Aureom::Graphics {

void FrameGraph::AddPass(const RenderPassNode& node) {
    nodes_.push_back(node);
}

void FrameGraph::Compile() {
    std::cout << "[AureomGraphics] Compiling FrameGraph with " << nodes_.size() << " passes." << std::endl;
    // Calculates resource dependencies and aliases transient memory
    compiled_ = true;
}

void FrameGraph::Execute() {
    if (!compiled_) Compile();
    for (const auto& pass : nodes_) {
        // Execute render pass on command queue
    }
}

bool GraphicsDevice::Initialize() {
    std::cout << "[AureomGraphics] Initialized Aureom Graphics Device (Vulkan Hardware Abstraction)." << std::endl;
    return true;
}

void GraphicsDevice::BeginFrame() {}
void GraphicsDevice::EndFrame() {}

} // namespace Aureom::Graphics
