#pragma once
#include <cstdint>
#include <vector>

namespace Aureom::Audio {

struct Vec3 { float x, y, z; };

struct SpatialSoundEmitter {
    uint32_t emitter_id;
    Vec3 position;
    Vec3 velocity;
    float volume{1.0f};
    float pitch{1.0f};
    bool looping{false};
};

class AureomAudioEngine {
public:
    static AureomAudioEngine& Instance();
    bool Initialize();
    void SetListenerTransform(const Vec3& position, const Vec3& forward, const Vec3& up);
    void PlaySpatialSound(uint32_t sound_id, const Vec3& pos);
    void Mix(float* output_buffer, uint32_t frames, uint32_t channels);
    void Shutdown();

private:
    AureomAudioEngine() = default;
    Vec3 listener_pos_{0,0,0};
};

} // namespace Aureom::Audio
