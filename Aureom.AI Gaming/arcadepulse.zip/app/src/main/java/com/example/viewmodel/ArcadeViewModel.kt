package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class AppMode {
    CONSUMER, KIOSK, STAFF
}

class ArcadeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ArcadeRepository

    // Flows from Repository
    val powerCards: StateFlow<List<PowerCardEntity>>
    val mainPowerCard: StateFlow<PowerCardEntity?>
    val games: StateFlow<List<GameEntity>>
    val challenges: StateFlow<List<ChallengeEntity>>
    val prizes: StateFlow<List<PrizeEntity>>
    val foodItems: StateFlow<List<FoodItemEntity>>
    val orders: StateFlow<List<OrderEntity>>
    val reservations: StateFlow<List<ReservationEntity>>
    val transactions: StateFlow<List<TransactionEntity>>
    val notifications: StateFlow<List<NotificationEntity>>

    // Active Selection State
    var selectedGame by mutableStateOf<GameEntity?>(null)
    var selectedPowerCard by mutableStateOf<PowerCardEntity?>(null)

    // Simulation Engine State
    var isSimulationRunning by mutableStateOf(false)
        private set
    var simulationScore by mutableStateOf(0L)
        private set
    var simulationTickets by mutableStateOf(0)
        private set
    var simulationTimeLeft by mutableStateOf(0)
        private set
    var simulationMultiplier by mutableStateOf(1)
        private set
    var simulationStage by mutableStateOf("READY") // "READY", "PLAYING", "FINISHED"
        private set
    private var simulationJob: Job? = null

    // QR & Dining Basket State
    var scannedTableNumber by mutableStateOf<Int?>(null)
    var basket = mutableStateOf<Map<FoodItemEntity, Int>>(emptyMap())
    var activeOrderTrackId by mutableStateOf<Long?>(null)

    // App Control & Mode State
    var currentMode by mutableStateOf(AppMode.CONSUMER)
    var showSimulationConsole by mutableStateOf(false)
    var showSoundLog by mutableStateOf(false)
    var soundLogs = mutableStateOf<List<String>>(emptyList())

    // UI Error / Dialog Message states
    var errorMessage by mutableStateOf<String?>(null)
    var infoMessage by mutableStateOf<String?>(null)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ArcadeRepository(database.arcadeDao())

        // Seeding database if empty
        viewModelScope.launch {
            repository.checkAndSeedData()
        }

        // Initialize StateFlows from database
        powerCards = repository.allPowerCards.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        mainPowerCard = repository.mainPowerCardFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), null
        )
        games = repository.allGames.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        challenges = repository.allChallenges.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        prizes = repository.allPrizes.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        foodItems = repository.allFoodItems.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        orders = repository.allOrders.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        reservations = repository.allReservations.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        transactions = repository.allTransactions.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )
        notifications = repository.allNotifications.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )

        // Automatically set selectedPowerCard once loaded
        viewModelScope.launch {
            mainPowerCard.collect { mainCard ->
                if (mainCard != null && selectedPowerCard == null) {
                    selectedPowerCard = mainCard
                }
            }
        }
    }

    // --- SOUND LOGGING ARCHITECTURE ---
    fun playSoundEffect(event: String) {
        val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val log = "[$timeStr] Sound Triggered: $event (Audio Hardware Mock Active)"
        soundLogs.value = listOf(log) + soundLogs.value.take(20) // Keep last 20
    }

    // --- GAME SIMULATION ENGINE ---
    fun selectGameToPlay(game: GameEntity) {
        selectedGame = game
        simulationStage = "READY"
        simulationScore = 0L
        simulationTickets = 0
        simulationTimeLeft = 30
        simulationMultiplier = 1
    }

    fun startArcadeSimulation() {
        val game = selectedGame ?: return
        val card = selectedPowerCard ?: mainPowerCard.value ?: return

        if (!game.isAvailable) {
            errorMessage = "GAME UNAVAILABLE: This machine is temporarily offline."
            return
        }

        if (card.status == "LOCKED") {
            errorMessage = "POWER CARD LOCKED: This card cannot currently be used. Unlock it in settings."
            return
        }

        if (card.chips < game.chipsRequired) {
            errorMessage = "NOT ENOUGH CHIPS: You need ${game.chipsRequired} chips to play, but you only have ${card.chips}."
            return
        }

        // Subtract chips from card and insert transaction
        viewModelScope.launch {
            val updatedCard = card.copy(chips = card.chips - game.chipsRequired)
            repository.savePowerCard(updatedCard)
            selectedPowerCard = updatedCard

            repository.addTransaction(
                TransactionEntity(
                    type = "CHIPS_PLAYED",
                    amountChips = game.chipsRequired,
                    amountTickets = 0,
                    amountCash = 0.0,
                    timestamp = System.currentTimeMillis(),
                    description = "Played ${game.name} using card ${card.id}"
                )
            )

            // Trigger sound
            playSoundEffect("gameWin")

            // Begin Simulation State
            isSimulationRunning = true
            simulationStage = "PLAYING"
            simulationScore = 0L
            simulationTickets = 0
            simulationTimeLeft = 10 // Accelerated 10 seconds for engaging, quick prototype sessions
            simulationMultiplier = 1

            simulationJob = launch {
                while (simulationTimeLeft > 0) {
                    delay(1000)
                    simulationTimeLeft--
                    
                    // Increment score and multiplier dynamically
                    val gainedScore = Random.nextLong(10000, 35000) * simulationMultiplier
                    simulationScore += gainedScore
                    
                    // Small chance to increment tickets dynamically
                    val gainedTickets = Random.nextInt(5, 15)
                    simulationTickets += gainedTickets

                    // Periodic multiplier increase
                    if (Random.nextFloat() > 0.7f && simulationMultiplier < 3) {
                        simulationMultiplier++
                        playSoundEffect("comboStreak")
                    }
                }
                finishArcadeSimulation()
            }
        }
    }

    fun simulateAction(actionName: String) {
        if (simulationStage != "PLAYING") return
        playSoundEffect("shootAction")
        
        // Boost score and chances
        simulationScore += Random.nextLong(15000, 45000) * simulationMultiplier
        simulationTickets += Random.nextInt(8, 22)
        if (Random.nextFloat() > 0.8f) {
            simulationMultiplier = (simulationMultiplier + 1).coerceAtMost(4)
            playSoundEffect("ticketAward")
        }
    }

    private suspend fun finishArcadeSimulation() {
        val game = selectedGame ?: return
        val card = selectedPowerCard ?: mainPowerCard.value ?: return

        isSimulationRunning = false
        simulationStage = "FINISHED"
        playSoundEffect("levelUp")

        // Finalize tickets
        val finalTickets = simulationTickets + Random.nextInt(10, 50) // add final completion bonus
        simulationTickets = finalTickets

        // Award tickets to Card
        val updatedCard = card.copy(tickets = card.tickets + finalTickets)
        repository.savePowerCard(updatedCard)
        selectedPowerCard = updatedCard

        // Save session record
        repository.saveSession(
            GameSessionEntity(
                cardId = card.id,
                gameId = game.id,
                gameName = game.name,
                score = simulationScore,
                chipsUsed = game.chipsRequired,
                ticketsWon = finalTickets,
                timestamp = System.currentTimeMillis()
            )
        )

        // Add transaction
        repository.addTransaction(
            TransactionEntity(
                type = "TICKETS_WON",
                amountChips = 0,
                amountTickets = finalTickets,
                amountCash = 0.0,
                timestamp = System.currentTimeMillis(),
                description = "Earned $finalTickets Tickets playing ${game.name}"
            )
        )

        // Check and update Game High Score
        if (simulationScore > game.personalHighScore) {
            val updatedGame = game.copy(personalHighScore = simulationScore)
            repository.updateGame(updatedGame)
            selectedGame = updatedGame
            playSoundEffect("achievementUnlocks")
        }

        // Update active challenges associated with this game or general category
        val currentChallenges = challenges.value
        currentChallenges.forEach { challenge ->
            if (!challenge.completed) {
                var progressAdded = false
                if (challenge.associatedGameId == game.id) {
                    progressAdded = true
                } else if (challenge.id == "CH-002") { // Arcade Explorer - play general games
                    progressAdded = true
                } else if (challenge.id == "CH-004" && game.category == "SOCIAL") {
                    progressAdded = true
                } else if (challenge.id == "CH-005" && game.id == "GODZ-005") {
                    progressAdded = true
                }

                if (progressAdded) {
                    val nextProgress = (challenge.currentProgress + 1).coerceAtMost(challenge.targetProgress)
                    val isNowCompleted = nextProgress >= challenge.targetProgress
                    
                    val updatedCh = challenge.copy(
                        currentProgress = nextProgress,
                        completed = isNowCompleted
                    )
                    
                    repository.updateChallenge(updatedCh)

                    if (isNowCompleted) {
                        playSoundEffect("challengeComplete")
                        repository.addNotification(
                            NotificationEntity(
                                title = "🏆 Challenge Complete!",
                                message = "You've completed '${challenge.title}' and unlocked +${challenge.rewardChips} Bonus Chips!",
                                timestamp = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
        }

        // Create completion notification
        repository.addNotification(
            NotificationEntity(
                title = "🎮 ${game.name} Finished!",
                message = "Session complete. Score: ${String.format("%,d", simulationScore)}. Earned $finalTickets Tickets!",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // --- CHIPS PURCHASING (SIMULATED PAYMENTS) ---
    fun buyGameChips(chipsToBuy: Int, costDollars: Double, paymentMethod: String) {
        val card = selectedPowerCard ?: mainPowerCard.value ?: return

        viewModelScope.launch {
            playSoundEffect("paymentLoading")
            delay(1500) // Simulate processing

            // Simulated decline rule: If using cash or mock wallet and price is high, can simulate rare error
            if (paymentMethod == "DECLINE_MOCK") {
                errorMessage = "PAYMENT FAILED: Your simulated card was declined. Please try another payment method."
                return@launch
            }

            // Credit chips
            val updatedCard = card.copy(chips = card.chips + chipsToBuy)
            repository.savePowerCard(updatedCard)
            selectedPowerCard = updatedCard

            // Ledger Transaction
            repository.addTransaction(
                TransactionEntity(
                    type = "CHIPS_PURCHASED",
                    amountChips = chipsToBuy,
                    amountTickets = 0,
                    amountCash = costDollars,
                    timestamp = System.currentTimeMillis(),
                    description = "Purchased $chipsToBuy Chips package for $$costDollars via $paymentMethod"
                )
            )

            repository.addNotification(
                NotificationEntity(
                    title = "💳 Chips Reload Success!",
                    message = "Successfully loaded $chipsToBuy Game Chips onto your Power Card ${card.id}.",
                    timestamp = System.currentTimeMillis()
                )
            )

            playSoundEffect("rewardUnlock")
            infoMessage = "RELOAD SUCCESSFUL! Added $chipsToBuy chips instantly."
        }
    }

    // --- CHALLENGES MANAGEMENT ---
    fun claimChallengeReward(challenge: ChallengeEntity) {
        if (!challenge.completed || challenge.claimed) return
        val card = selectedPowerCard ?: mainPowerCard.value ?: return

        viewModelScope.launch {
            val updatedCard = card.copy(chips = card.chips + challenge.rewardChips)
            repository.savePowerCard(updatedCard)
            selectedPowerCard = updatedCard

            repository.updateChallenge(challenge.copy(claimed = true))

            repository.addTransaction(
                TransactionEntity(
                    type = "CHALLENGE_REWARD",
                    amountChips = challenge.rewardChips,
                    amountTickets = 0,
                    amountCash = 0.0,
                    timestamp = System.currentTimeMillis(),
                    description = "Claimed ${challenge.rewardChips} Bonus Chips for ${challenge.title}"
                )
            )

            playSoundEffect("rewardUnlock")
            infoMessage = "REWARD CLAIMED: +${challenge.rewardChips} Chips added!"
        }
    }

    // --- PRIZE REDEMPTION ---
    fun redeemPrize(prize: PrizeEntity) {
        val card = selectedPowerCard ?: mainPowerCard.value ?: return

        if (card.tickets < prize.cost) {
            errorMessage = "NOT ENOUGH TICKETS: You need ${prize.cost} tickets, but you only have ${card.tickets}."
            return
        }

        viewModelScope.launch {
            // Subtract tickets from card
            val updatedCard = card.copy(tickets = card.tickets - prize.cost)
            repository.savePowerCard(updatedCard)
            selectedPowerCard = updatedCard

            // Log Transaction
            repository.addTransaction(
                TransactionEntity(
                    type = "TICKETS_REDEEMED",
                    amountChips = 0,
                    amountTickets = prize.cost,
                    amountCash = 0.0,
                    timestamp = System.currentTimeMillis(),
                    description = "Redeemed synthetic prize: ${prize.name}"
                )
            )

            repository.addNotification(
                NotificationEntity(
                    title = "🎁 Prize Redeemed!",
                    message = "Your ticket code for '${prize.name}' has been added to your digital voucher box.",
                    timestamp = System.currentTimeMillis()
                )
            )

            playSoundEffect("ticketAward")
            infoMessage = "REDEEMED! Show voucher code in-venue to collect your ${prize.name}."
        }
    }

    // --- FOOD ORDERING & DINING SERVICE ---
    fun scanTableQRCode(tableNum: Int) {
        scannedTableNumber = tableNum
        basket.value = emptyMap()
        playSoundEffect("qrScanSuccess")
    }

    fun addFoodToBasket(item: FoodItemEntity) {
        val current = basket.value.toMutableMap()
        current[item] = (current[item] ?: 0) + 1
        basket.value = current
        playSoundEffect("shootAction")
    }

    fun removeFoodFromBasket(item: FoodItemEntity) {
        val current = basket.value.toMutableMap()
        val qty = current[item] ?: return
        if (qty <= 1) {
            current.remove(item)
        } else {
            current[item] = qty - 1
        }
        basket.value = current
        playSoundEffect("shootAction")
    }

    fun submitFoodOrder() {
        val tableNum = scannedTableNumber ?: 42
        val currentBasket = basket.value
        if (currentBasket.isEmpty()) return

        val totalAmount = currentBasket.map { (item, qty) -> item.price * qty }.sum()

        viewModelScope.launch {
            playSoundEffect("paymentLoading")
            val orderList = currentBasket.map { Pair(it.key, it.value) }
            val orderId = repository.placeOrder(
                tableNumber = tableNum,
                partySize = 4,
                total = totalAmount,
                items = orderList
            )

            activeOrderTrackId = orderId
            basket.value = emptyMap() // Clear basket

            playSoundEffect("orderReady")
            repository.addNotification(
                NotificationEntity(
                    title = "🍔 Food Order Received!",
                    message = "Your kitchen order (Table $tableNum) has been placed. Chefs are preparing it now!",
                    timestamp = System.currentTimeMillis()
                )
            )

            // Simulate order track states
            launch {
                delay(6000)
                repository.updateOrderStatus(orderId, "ON_THE_WAY")
                playSoundEffect("orderReady")
                repository.addNotification(
                    NotificationEntity(
                        title = "🚴 Food is on the way!",
                        message = "Your order is ready. Sizzling hot dishes are heading to Table $tableNum!",
                        timestamp = System.currentTimeMillis()
                    )
                )

                delay(6000)
                repository.updateOrderStatus(orderId, "SERVED")
                playSoundEffect("levelUp")
                repository.addNotification(
                    NotificationEntity(
                        title = "✨ Food Served!",
                        message = "Table $tableNum order has been fully served. Bon Appetit!",
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    // --- RESERVATIONS FLOW ---
    fun makeReservation(date: String, time: String, people: Int, experience: String) {
        viewModelScope.launch {
            repository.addReservation(
                ReservationEntity(
                    date = date,
                    time = time,
                    people = people,
                    experience = experience,
                    status = "CONFIRMED"
                )
            )

            repository.addNotification(
                NotificationEntity(
                    title = "📅 Booking Confirmed!",
                    message = "Your $experience reservation for $people people on $date at $time is locked in.",
                    timestamp = System.currentTimeMillis()
                )
            )

            playSoundEffect("rewardUnlock")
            infoMessage = "RESERVATION SECURED! Table booked for $experience on $date at $time."
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    // --- DEV CONTROL ROOM SIMULATIONS ---
    fun devAddChips(amount: Int) {
        val card = selectedPowerCard ?: mainPowerCard.value ?: return
        viewModelScope.launch {
            val updated = card.copy(chips = card.chips + amount)
            repository.savePowerCard(updated)
            selectedPowerCard = updated

            repository.addTransaction(
                TransactionEntity(
                    type = "CHIPS_PURCHASED",
                    amountChips = amount,
                    amountTickets = 0,
                    amountCash = 0.0,
                    timestamp = System.currentTimeMillis(),
                    description = "Dev Console Instant +$amount Chips Injection"
                )
            )
            playSoundEffect("rewardUnlock")
        }
    }

    fun devAddTickets(amount: Int) {
        val card = selectedPowerCard ?: mainPowerCard.value ?: return
        viewModelScope.launch {
            val updated = card.copy(tickets = card.tickets + amount)
            repository.savePowerCard(updated)
            selectedPowerCard = updated

            repository.addTransaction(
                TransactionEntity(
                    type = "TICKETS_WON",
                    amountChips = 0,
                    amountTickets = amount,
                    amountCash = 0.0,
                    timestamp = System.currentTimeMillis(),
                    description = "Dev Console Instant +$amount Tickets Injection"
                )
            )
            playSoundEffect("ticketAward")
        }
    }

    fun devToggleGameAvailability(gameId: String) {
        viewModelScope.launch {
            val game = games.value.find { it.id == gameId } ?: return@launch
            val updated = game.copy(isAvailable = !game.isAvailable)
            repository.updateGame(updated)
            if (selectedGame?.id == gameId) {
                selectedGame = updated
            }
            playSoundEffect("shootAction")
        }
    }

    fun devCompleteAllChallenges() {
        viewModelScope.launch {
            val list = challenges.value
            list.forEach { ch ->
                if (!ch.completed) {
                    repository.updateChallenge(
                        ch.copy(
                            currentProgress = ch.targetProgress,
                            completed = true
                        )
                    )
                }
            }
            playSoundEffect("challengeComplete")
        }
    }

    fun selectCardToManage(card: PowerCardEntity) {
        selectedPowerCard = card
    }

    fun toggleCardLockState(cardId: String) {
        viewModelScope.launch {
            val card = powerCards.value.find { it.id == cardId } ?: return@launch
            val nextStatus = if (card.status == "ACTIVE") "LOCKED" else "ACTIVE"
            val updated = card.copy(status = nextStatus)
            repository.savePowerCard(updated)
            if (selectedPowerCard?.id == cardId) {
                selectedPowerCard = updated
            }
            playSoundEffect("shootAction")
        }
    }

    fun transferChipsBetweenCards(fromCardId: String, toCardId: String, amount: Int) {
        viewModelScope.launch {
            val fromCard = repository.getPowerCardById(fromCardId)
            val toCard = repository.getPowerCardById(toCardId)
            if (fromCard == null || toCard == null) return@launch

            if (fromCard.chips < amount) {
                errorMessage = "TRANSFER ERROR: Source card has insufficient chips."
                return@launch
            }

            repository.savePowerCard(fromCard.copy(chips = fromCard.chips - amount))
            repository.savePowerCard(toCard.copy(chips = toCard.chips + amount))

            repository.addTransaction(
                TransactionEntity(
                    type = "CHIPS_PLAYED",
                    amountChips = amount,
                    amountTickets = 0,
                    amountCash = 0.0,
                    timestamp = System.currentTimeMillis(),
                    description = "Transferred $amount Chips from $fromCardId to $toCardId"
                )
            )

            // Trigger sound
            playSoundEffect("rewardUnlock")
            infoMessage = "TRANSFERRED SUCCESSFUL! Moved $amount chips."
        }
    }

    override fun onCleared() {
        super.onCleared()
        simulationJob?.cancel()
    }
}
