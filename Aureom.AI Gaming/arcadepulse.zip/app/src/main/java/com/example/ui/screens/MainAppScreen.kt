package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.AppMode
import com.example.viewmodel.ArcadeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: ArcadeViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf("home") }

    // Dialog Toggle States
    var showProfileDialog by remember { mutableStateOf(false) }
    var showReloadDialog by remember { mutableStateOf(false) }
    var showManageCardsDialog by remember { mutableStateOf(false) }
    var showWinStoreDialog by remember { mutableStateOf(false) }
    var showSplitBillDialog by remember { mutableStateOf(false) }
    var showReservationDialog by remember { mutableStateOf(false) }
    var showGameSimulatorDialog by remember { mutableStateOf(false) }

    // State collections
    val powerCards by viewModel.powerCards.collectAsStateWithLifecycle()
    val mainPowerCard by viewModel.mainPowerCard.collectAsStateWithLifecycle()
    val games by viewModel.games.collectAsStateWithLifecycle()
    val challenges by viewModel.challenges.collectAsStateWithLifecycle()
    val prizes by viewModel.prizes.collectAsStateWithLifecycle()
    val foodItems by viewModel.foodItems.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()

    // Error / info snackbar states
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Synchronize toast notifications
    LaunchedEffect(viewModel.errorMessage) {
        viewModel.errorMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.errorMessage = null
        }
    }

    LaunchedEffect(viewModel.infoMessage) {
        viewModel.infoMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.infoMessage = null
        }
    }

    // Main App Layout
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = "Arcade Launcher",
                            tint = BrightOrange,
                            modifier = Modifier.size(32.dp)
                        )
                        Column {
                            Text(
                                text = "ArcadePulse",
                                color = PureWhite,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "MANCHESTER • ACTIVE FLOOR",
                                color = TextGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                actions = {
                    // Quick stats & modes
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        // Dev Simulation Button
                        IconButton(
                            onClick = { viewModel.showSimulationConsole = !viewModel.showSimulationConsole },
                            modifier = Modifier.testTag("dev_simulation_toggle")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Simulation Console",
                                tint = if (viewModel.showSimulationConsole) BrightOrange else TextGray
                            )
                        }

                        // Notifications Badge
                        val unreadCount = notifications.size
                        IconButton(
                            onClick = { currentTab = "notifications" }
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge(containerColor = TicketOrange) {
                                            Text(unreadCount.toString(), color = PureWhite)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = PureWhite
                                )
                            }
                        }

                        // Profile Card
                        Button(
                            onClick = { showProfileDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Profile",
                                tint = BrightOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Alex",
                                color = PureWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepBlueBg,
                    titleContentColor = PureWhite,
                    actionIconContentColor = PureWhite
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DeepBlueCard,
                tonalElevation = 8.dp
            ) {
                val navItems = listOf(
                    Triple("home", "HOME", Icons.Default.Home),
                    Triple("play", "PLAY", Icons.Default.PlayArrow),
                    Triple("rewards", "REWARDS", Icons.Default.EmojiEvents),
                    Triple("eat", "EAT", Icons.Default.Restaurant),
                    Triple("venue", "VENUE", Icons.Default.Map)
                )

                navItems.forEach { (route, label, icon) ->
                    val isSelected = currentTab == route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = route },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) BrightOrange else TextGray
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) BrightOrange else TextGray
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = SoftBorder
                        ),
                        modifier = Modifier.testTag("tab_$route")
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentTab == "home" || currentTab == "play") {
                ExtendedFloatingActionButton(
                    text = { Text("RELOAD CHIPS", color = PureWhite, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.AddCard, contentDescription = null, tint = PureWhite) },
                    onClick = { showReloadDialog = true },
                    containerColor = BrightOrange,
                    elevation = FloatingActionButtonDefaults.elevation(8.dp),
                    modifier = Modifier.testTag("reload_chips_fab")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepBlueBg)
                .padding(paddingValues)
        ) {
            // Main navigation router
            when (currentTab) {
                "home" -> HomeTabContent(
                    viewModel = viewModel,
                    mainCard = mainPowerCard,
                    onSwitchTab = { currentTab = it },
                    onOpenReload = { showReloadDialog = true },
                    onOpenManageCards = { showManageCardsDialog = true }
                )
                "play" -> PlayTabContent(
                    viewModel = viewModel,
                    gamesList = games,
                    onGameSelected = { game ->
                        viewModel.selectGameToPlay(game)
                        showGameSimulatorDialog = true
                    }
                )
                "rewards" -> RewardsTabContent(
                    viewModel = viewModel,
                    challenges = challenges
                )
                "eat" -> EatTabContent(
                    viewModel = viewModel,
                    foodItems = foodItems,
                    orders = orders,
                    onOpenSplitBill = { showSplitBillDialog = true }
                )
                "venue" -> VenueTabContent(
                    viewModel = viewModel,
                    onOpenReservation = { showReservationDialog = true }
                )
                "notifications" -> NotificationsTabContent(
                    viewModel = viewModel,
                    notifications = notifications
                )
            }

            // Developer Simulation Control overlay dashboard
            if (viewModel.showSimulationConsole) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkCharcoal.copy(alpha = 0.96f))
                        .border(1.dp, BrightOrange, RoundedCornerShape(12.dp))
                ) {
                    SimulationConsoleOverlay(viewModel = viewModel)
                }
            }

            // Global floating alert info
            if (viewModel.soundLogs.value.isNotEmpty() && viewModel.showSoundLog) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                        .width(280.dp)
                        .height(150.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.85f))
                        .border(1.dp, ElectricGreen, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AUDIO LOGS (MOCK)", color = ElectricGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            IconButton(
                                onClick = { viewModel.showSoundLog = false },
                                modifier = Modifier.size(16.dp)
                            ) {
                                Icon(Icons.Default.Close, "Close", tint = PureWhite, modifier = Modifier.size(12.dp))
                            }
                        }
                        Divider(color = SoftBorder, modifier = Modifier.padding(vertical = 4.dp))
                        Box(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                            Column {
                                viewModel.soundLogs.value.forEach { log ->
                                    Text(log, color = PureWhite, fontSize = 9.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- MODALS & DIALOGS ---

    // 1. Profile & Stats & Ledger Dialog
    if (showProfileDialog) {
        ProfileDialog(
            viewModel = viewModel,
            transactions = transactions,
            onDismiss = { showProfileDialog = false },
            onOpenPrizeVoucher = { showWinStoreDialog = true }
        )
    }

    // 2. Add Chips / Purchase Dialog
    if (showReloadDialog) {
        ReloadChipsDialog(
            viewModel = viewModel,
            mainCard = mainPowerCard,
            onDismiss = { showReloadDialog = false }
        )
    }

    // 3. Power Card Manager Dialog
    if (showManageCardsDialog) {
        ManagePowerCardsDialog(
            viewModel = viewModel,
            powerCards = powerCards,
            onDismiss = { showManageCardsDialog = false }
        )
    }

    // 4. Ticket Win! Store Dialog
    if (showWinStoreDialog) {
        WinStoreDialog(
            viewModel = viewModel,
            prizes = prizes,
            mainCard = mainPowerCard,
            onDismiss = { showWinStoreDialog = false }
        )
    }

    // 5. Split Bill / Group Ordering Dialog
    if (showSplitBillDialog) {
        SplitBillDialog(
            viewModel = viewModel,
            onDismiss = { showSplitBillDialog = false }
        )
    }

    // 6. Reservation Dialog
    if (showReservationDialog) {
        BookReservationDialog(
            viewModel = viewModel,
            onDismiss = { showReservationDialog = false }
        )
    }

    // 7. Active Play Simulator Modal Dialog
    if (showGameSimulatorDialog) {
        GameSimulatorDialog(
            viewModel = viewModel,
            onDismiss = { showGameSimulatorDialog = false }
        )
    }
}

// ==========================================
// 1. HOME TAB COMPONENT
// ==========================================
@Composable
fun HomeTabContent(
    viewModel: ArcadeViewModel,
    mainCard: PowerCardEntity?,
    onSwitchTab: (String) -> Unit,
    onOpenReload: () -> Unit,
    onOpenManageCards: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Current state
        item {
            Column {
                Text(
                    text = "WELCOME BACK, ALEX",
                    fontSize = 24.sp,
                    color = PureWhite,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.testTag("home_greeting")
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = BrightOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "MANCHESTER URBAN CENTRE • OPEN UNTIL 01:00 AM",
                        fontSize = 11.sp,
                        color = TextGray,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Metallic Digital Power Card Hero Widget
        item {
            PowerCardHeroCard(
                card = mainCard,
                onReload = onOpenReload,
                onManage = onOpenManageCards,
                onPlayNow = { onSwitchTab("play") }
            )
        }

        // Live Operational Summary Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, SoftBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GAMES", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("96 ACTIVE", color = ElectricGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(SoftBorder))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WAIT TIMES", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("< 5 MINS", color = ElectricCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(SoftBorder))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SPORTS WALL", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("4 WATCHING", color = BrightOrange, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // "WHAT'S HAPPENING NOW" Feed Title
        item {
            Text(
                text = "WHAT'S HAPPENING TONIGHT",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = PureWhite,
                letterSpacing = 1.sp
            )
        }

        // Banners list
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Banner 1: Game Challenge
                FeaturedEventCard(
                    title = "🔥 HIGH ROLLER CHALLENGE",
                    subtitle = "Skee-Ball King Elite",
                    description = "Play 20 games of Skee-Ball to secure a legendary badge + 100 BONUS Game Chips immediately.",
                    accentColor = ElectricGreen,
                    imagePlaceholder = "🎱",
                    onClick = { onSwitchTab("rewards") }
                )

                // Banner 2: Sports Watch
                FeaturedEventCard(
                    title = "⚽ WOW WALL BIG BROADCAST",
                    subtitle = "Arsenal vs Chelsea Live at 20:00",
                    description = "Catch the massive London Derby on our gigantic 40-foot multiscreen sports display with gameday offers.",
                    accentColor = ElectricCyan,
                    imagePlaceholder = "📺",
                    onClick = { onSwitchTab("venue") }
                )

                // Banner 3: Food combo
                FeaturedEventCard(
                    title = "🍔 DINING & ARCADE SPECIFICATION",
                    subtitle = "Burger + 100 Chips Package",
                    description = "Score our famous double-beef bacon cheeseburger deluxe plus 100 loaded Game Chips for just $29.99.",
                    accentColor = BrightOrange,
                    imagePlaceholder = "🍔",
                    onClick = { onSwitchTab("eat") }
                )
            }
        }

        // Footnote Rule Statement
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Independent Entertainment App Prototype — Synthetic Venue Data",
                    fontSize = 10.sp,
                    color = TextGray,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun PowerCardHeroCard(
    card: PowerCardEntity?,
    onReload: () -> Unit,
    onManage: () -> Unit,
    onPlayNow: () -> Unit
) {
    if (card == null) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            modifier = Modifier.fillMaxWidth().height(180.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                CircularProgressIndicator(color = BrightOrange)
            }
        }
        return
    }

    // Metallic premium styling card
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("power_card_hero"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DeepBlueCard, DeepBlueBg)
                    )
                )
                .border(2.dp, Brush.horizontalGradient(listOf(BrightOrange, VibrantBlue)), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CardMembership,
                            contentDescription = null,
                            tint = BrightOrange,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "DIGITAL POWER CARD",
                            color = PureWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (card.status == "ACTIVE") ElectricGreen else Color.Red)
                        )
                        Text(
                            text = card.status,
                            color = if (card.status == "ACTIVE") ElectricGreen else Color.Red,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = String.format("%,d", card.chips),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = PureWhite,
                            modifier = Modifier.testTag("chip_count_text")
                        )
                        Text(
                            text = "GAME CHIPS",
                            color = TextLightGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = String.format("%,d", card.tickets),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = ElectricCyan,
                            modifier = Modifier.testTag("ticket_count_text")
                        )
                        Text(
                            text = "TICKETS WON",
                            color = ElectricCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Loyalty progress bar
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TIER LEVEL 5 • ICON MEMBER",
                            color = BrightOrange,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "72% TO LEGEND",
                            color = TextGray,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { 0.72f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = BrightOrange,
                        trackColor = SoftBorder
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onPlayNow,
                        colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .testTag("play_now_card_button")
                    ) {
                        Text("PLAY NOW", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onReload,
                        colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                    ) {
                        Text("ADD CHIPS", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onManage,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(SoftBorder)
                    ) {
                        Icon(Icons.Default.CreditCard, contentDescription = "Manage Cards", tint = PureWhite)
                    }
                }
            }
        }
    }
}

@Composable
fun FeaturedEventCard(
    title: String,
    subtitle: String,
    description: String,
    accentColor: Color,
    imagePlaceholder: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SoftBorder)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SoftBorder),
                contentAlignment = Alignment.Center
            ) {
                Text(imagePlaceholder, fontSize = 24.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = accentColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = PureWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    color = TextGray,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Medium
                )
            }

            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextGray
            )
        }
    }
}

// ==========================================
// 2. PLAY TAB COMPONENT
// ==========================================
@Composable
fun PlayTabContent(
    viewModel: ArcadeViewModel,
    gamesList: List<GameEntity>,
    onGameSelected: (GameEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }

    val categories = listOf("ALL", "ARCADE", "SPORTS", "RACING", "SKILL", "VR", "PRIZE_GAMES", "SOCIAL")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("ARCADE GAME PLATFORM", fontSize = 22.sp, color = PureWhite, fontWeight = FontWeight.Black)

        // Search Bar
        TextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search arcade machines...", color = TextGray) },
            leadingIcon = { Icon(Icons.Default.Search, "Search", tint = TextGray) },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .testTag("game_search_input"),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = DeepBlueCard,
                unfocusedContainerColor = DeepBlueCard,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = PureWhite,
                unfocusedTextColor = PureWhite
            ),
            singleLine = true
        )

        // Horizontal Category Selectors
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val isSel = selectedCategory == cat
                Button(
                    onClick = { selectedCategory = cat },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSel) BrightOrange else DeepBlueCard
                    ),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp).testTag("category_filter_$cat")
                ) {
                    Text(
                        cat,
                        color = if (isSel) PureWhite else TextLightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Filtering Logic
        val filteredGames = gamesList.filter { game ->
            val matchSearch = game.name.contains(searchQuery, ignoreCase = true) ||
                    game.description.contains(searchQuery, ignoreCase = true)
            val matchCat = selectedCategory == "ALL" || game.category.equals(selectedCategory, ignoreCase = true)
            matchSearch && matchCat
        }

        // Games Grid
        if (filteredGames.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No matching arcade machines found.", color = TextGray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredGames) { game ->
                    GameCatalogueCard(
                        game = game,
                        onClick = { onGameSelected(game) }
                    )
                }
            }
        }
    }
}

@Composable
fun GameCatalogueCard(
    game: GameEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("game_card_${game.id}"),
        colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (game.isNew) BrightOrange else SoftBorder)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Visual Character badge
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SoftBorder),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when (game.category) {
                        "VR" -> "🕶️"
                        "RACING" -> "🏎️"
                        "SPORTS" -> "🏀"
                        "SHOOTING" -> "✈️"
                        "SKILL" -> "🔮"
                        "PRIZE_GAMES" -> "🧸"
                        else -> "🕹️"
                    },
                    fontSize = 32.sp
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = game.name,
                        color = PureWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (game.isNew) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(BrightOrange)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("NEW", color = PureWhite, fontSize = 8.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Text(game.category, color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, "Rating", tint = BrightOrange, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(game.popularity.toString(), color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, "Chips required", tint = BrightOrange, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("${game.chipsRequired} Chips", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (!game.isAvailable) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Red.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("OFFLINE", color = Color.Red, fontSize = 8.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }

            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextGray
            )
        }
    }
}

// ==========================================
// 3. REWARDS TAB COMPONENT
// ==========================================
@Composable
fun RewardsTabContent(
    viewModel: ArcadeViewModel,
    challenges: List<ChallengeEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("LOYALTY REWARDS & MISSIONS", fontSize = 22.sp, color = PureWhite, fontWeight = FontWeight.Black)
        }

        // Member Profile Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BrightOrange)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ALEX MORGAN", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text("LEVEL 5 MEMBER • ICON", color = BrightOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(BrightOrange),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MilitaryTech, "Badge", tint = PureWhite, modifier = Modifier.size(32.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = SoftBorder)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CHIPS PLAYED", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("2,460", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("NEXT TIER", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("LEGEND (3,000 CHIPS)", color = TextLightGray, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { 2460f / 3000f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = BrightOrange,
                        trackColor = SoftBorder
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("540 CHIPS TO LEVEL 6!", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Tiers description
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, SoftBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("TIER REWARDS STRUCTURE", color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("• PLAYER (Level 1-2):", color = TextLightGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Standard ticket multiplier x1", color = TextGray, fontSize = 11.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("• ICON (Level 3-5):", color = BrightOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("10% bonus tickets, Free birthday play", color = TextGray, fontSize = 11.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("• LEGEND (Level 6+):", color = ElectricGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("20% bonus tickets, Unlimited 10% food discounts", color = TextGray, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Text("ACTIVE MISSIONS & CHALLENGES", fontSize = 15.sp, color = PureWhite, fontWeight = FontWeight.Bold)
        }

        // Active Challenges List
        if (challenges.isEmpty()) {
            item {
                Text("No active challenges available.", color = TextGray, fontSize = 12.sp)
            }
        } else {
            items(challenges) { challenge ->
                ChallengeCard(
                    challenge = challenge,
                    onClaim = { viewModel.claimChallengeReward(challenge) }
                )
            }
        }
    }
}

@Composable
fun ChallengeCard(
    challenge: ChallengeEntity,
    onClaim: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("challenge_card_${challenge.id}"),
        colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (challenge.completed && !challenge.claimed) ElectricGreen else SoftBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = challenge.title,
                            color = PureWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SoftBorder)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(challenge.category, color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(challenge.description, color = TextGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                }

                // Check Stamp
                if (challenge.claimed) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SoftBorder)
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text("CLAIMED", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                } else if (challenge.completed) {
                    Button(
                        onClick = onClaim,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricGreen),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp).testTag("claim_button_${challenge.id}")
                    ) {
                        Text("CLAIM", color = DeepBlueBg, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SoftBorder)
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text("+${challenge.rewardChips} CHIPS", color = BrightOrange, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress bar
            val fraction = challenge.currentProgress.toFloat() / challenge.targetProgress.toFloat()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (challenge.completed) ElectricGreen else BrightOrange,
                    trackColor = SoftBorder
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    "${challenge.currentProgress}/${challenge.targetProgress}",
                    color = PureWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// 4. EAT TAB COMPONENT
// ==========================================
@Composable
fun EatTabContent(
    viewModel: ArcadeViewModel,
    foodItems: List<FoodItemEntity>,
    orders: List<OrderEntity>,
    onOpenSplitBill: () -> Unit
) {
    var selectedCat by remember { mutableStateOf("ALL") }
    val categories = listOf("ALL", "BURGERS", "STARTERS", "SANDWICHES", "WINGS", "PIZZA", "DESSERTS", "BEER", "COCKTAILS")

    var showBasket by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Table scan indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("EAT • DRINK • REFUEL", fontSize = 22.sp, color = PureWhite, fontWeight = FontWeight.Black)
                Text(
                    text = if (viewModel.scannedTableNumber != null) "LOGGED AT TABLE ${viewModel.scannedTableNumber}" else "NOT LOGGED AT TABLE (ORDER TO GO)",
                    color = if (viewModel.scannedTableNumber != null) ElectricGreen else BrightOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Table QR Scan Simulator button
                Button(
                    onClick = { viewModel.scanTableQRCode(42) },
                    colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier.height(34.dp).testTag("scan_table_qr")
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = BrightOrange, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("SCAN TAB", fontSize = 10.sp, color = PureWhite, fontWeight = FontWeight.Bold)
                }

                val itemsCount = viewModel.basket.value.values.sum()
                if (itemsCount > 0) {
                    IconButton(
                        onClick = { showBasket = true },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrightOrange)
                            .testTag("basket_button")
                    ) {
                        BadgedBox(
                            badge = {
                                Badge(containerColor = VibrantBlue) {
                                    Text(itemsCount.toString(), color = PureWhite)
                                }
                            }
                        ) {
                            Icon(Icons.Default.ShoppingCart, "Basket", tint = PureWhite, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // Horizontal Category Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                val isSel = selectedCat == cat
                Button(
                    onClick = { selectedCat = cat },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSel) VibrantBlue else DeepBlueCard
                    ),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text(cat, color = if (isSel) PureWhite else TextLightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active kitchen order tracker
        val activeOrder = orders.firstOrNull { !it.isPaid }
        if (activeOrder != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, ElectricCyan)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(ElectricCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (activeOrder.status) {
                                    "PREPARING" -> Icons.Default.Kitchen
                                    "ON_THE_WAY" -> Icons.Default.DirectionsRun
                                    else -> Icons.Default.Check
                                },
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("TABLE ${activeOrder.tableNumber} ORDER ACTIVE", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("STATUS: ${activeOrder.status}", color = ElectricCyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Button(
                        onClick = onOpenSplitBill,
                        colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        modifier = Modifier.height(28.dp).testTag("split_bill_button")
                    ) {
                        Text("SPLIT BILL", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Food menu Items List
        val filteredFood = foodItems.filter { selectedCat == "ALL" || it.category == selectedCat }
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filteredFood) { item ->
                FoodCatalogueCard(
                    item = item,
                    onAdd = { viewModel.addFoodToBasket(item) }
                )
            }
        }
    }

    // Basket / Cart Sheet Dialog Overlay
    if (showBasket) {
        Dialog(onDismissRequest = { showBasket = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, SoftBorder),
                modifier = Modifier.fillMaxWidth().height(480.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("YOUR DINING BASKET", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(viewModel.basket.value.toList()) { (item, qty) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("$${item.price}", color = TextGray, fontSize = 11.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { viewModel.removeFoodFromBasket(item) }) {
                                        Icon(Icons.Default.RemoveCircleOutline, "Remove", tint = BrightOrange)
                                    }
                                    Text(qty.toString(), color = PureWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { viewModel.addFoodToBasket(item) }) {
                                        Icon(Icons.Default.AddCircleOutline, "Add", tint = BrightOrange)
                                    }
                                }
                            }
                        }
                    }

                    val totalCost = viewModel.basket.value.map { it.key.price * it.value }.sum()
                    Divider(color = SoftBorder, modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL AMOUNT", color = TextGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(String.format("$%.2f", totalCost), color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            viewModel.submitFoodOrder()
                            showBasket = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("place_kitchen_order_button")
                    ) {
                        Text("PLACE KITCHEN ORDER", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun FoodCatalogueCard(
    item: FoodItemEntity,
    onAdd: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SoftBorder),
        modifier = Modifier.testTag("food_card_${item.id}")
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SoftBorder),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when (item.category) {
                        "BURGERS" -> "🍔"
                        "STARTERS" -> "🍟"
                        "WINGS" -> "🍗"
                        "PIZZA" -> "🍕"
                        "DESSERTS" -> "🧁"
                        "BEER" -> "🍺"
                        "COCKTAILS" -> "🍸"
                        else -> "🍽️"
                    },
                    fontSize = 32.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(item.name, color = PureWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(item.description, color = TextGray, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(4.dp))
                Text(String.format("$%.2f", item.price), color = BrightOrange, fontSize = 13.sp, fontWeight = FontWeight.Black)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onAdd,
                colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.height(34.dp).testTag("add_food_button_${item.id}")
            ) {
                Text("ADD", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 5. VENUE TAB COMPONENT
// ==========================================
@Composable
fun VenueTabContent(
    viewModel: ArcadeViewModel,
    onOpenReservation: () -> Unit
) {
    var selectedZone by remember { mutableStateOf("ARCADE") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("VENUE DESIGNS & MAP", fontSize = 22.sp, color = PureWhite, fontWeight = FontWeight.Black)
        }

        // Venue details header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
                border = BorderStroke(1.dp, SoftBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("MANCHESTER CITY CENTRE", color = PureWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Unit 3, Great Northern Warehouse, Manchester", color = TextGray, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TODAY'S HOURS: 11:00 AM - 01:00 AM", color = ElectricGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Button(
                            onClick = onOpenReservation,
                            colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp),
                            modifier = Modifier.height(32.dp).testTag("book_table_button")
                        ) {
                            Text("BOOK SPOT", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // WATCH WOW WALL HIGHLIGHT
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                border = BorderStroke(1.dp, TicketOrange),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TicketOrange.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.LiveTv, "Wow Wall", tint = TicketOrange)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("📺 WOW WALL SPORTS SCREENING", color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Arsenal vs Chelsea (Live at 20:00 tonight) on 40-foot massive multiscreens", color = TextGray, fontSize = 11.sp)
                    }
                }
            }
        }

        // INTERACTIVE MAP SCHEMATIC
        item {
            Text("INTERACTIVE INDOOR VENUE ZONES", color = PureWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }

        item {
            val zones = listOf(
                Triple("ARCADE", "🕹️ ARCADE ZONE", "AVAILABLE"),
                Triple("RESTAURANT", "🍔 DINING ROOM", "BUSY"),
                Triple("BAR", "🍸 SPORTS BAR", "AVAILABLE"),
                Triple("RACING", "🏎️ RACING SIMS", "2 MIN WAIT"),
                Triple("VR", "🕶️ VR SUITE", "12 MIN WAIT"),
                Triple("PRIZE_STORE", "🎁 WIN! STORE", "AVAILABLE"),
                Triple("DARTS", "🎯 TECH DARTS", "AVAILABLE"),
                Triple("SHUFFLEBOARD", "🏓 SHUFFLEBOARD", "2 TABLES BUSY")
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                zones.forEach { (id, name, wait) ->
                    val isSel = selectedZone == id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedZone = id }
                            .testTag("zone_card_$id"),
                        colors = CardDefaults.cardColors(containerColor = if (isSel) SoftBorder else DeepBlueCard),
                        border = BorderStroke(1.dp, if (isSel) BrightOrange else SoftBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSel) BrightOrange.copy(alpha = 0.2f) else SoftBorder),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(name.take(2)) // grab emoji
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(name.drop(3), color = PureWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            wait.contains("AVAILABLE") -> ElectricGreen.copy(alpha = 0.2f)
                                            wait.contains("WAIT") -> BrightOrange.copy(alpha = 0.2f)
                                            else -> Color.Red.copy(alpha = 0.2f)
                                        }
                                    )
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = wait,
                                    color = when {
                                        wait.contains("AVAILABLE") -> ElectricGreen
                                        wait.contains("WAIT") -> BrightOrange
                                        else -> Color.Red
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. NOTIFICATIONS TAB COMPONENT
// ==========================================
@Composable
fun NotificationsTabContent(
    viewModel: ArcadeViewModel,
    notifications: List<NotificationEntity>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("NOTIFICATIONS INBOX", fontSize = 22.sp, color = PureWhite, fontWeight = FontWeight.Black)
            Button(
                onClick = { viewModel.markAllNotificationsAsRead() },
                colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text("CLEAR ALL", color = PureWhite, fontSize = 10.sp)
            }
        }

        if (notifications.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Your notification box is empty.", color = TextGray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                items(notifications) { notif ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
                        border = BorderStroke(1.dp, SoftBorder),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(notif.title, color = BrightOrange, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(notif.message, color = PureWhite, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 7. DEV SIMULATION CONSOLE WIDGET
// ==========================================
@Composable
fun SimulationConsoleOverlay(viewModel: ArcadeViewModel) {
    Column(modifier = Modifier.padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(ElectricGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("ADMIN / SIMULATOR CONTROL CENTRE", color = ElectricGreen, fontSize = 12.sp, fontWeight = FontWeight.Black)
            }

            IconButton(
                onClick = { viewModel.showSimulationConsole = false },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(Icons.Default.Close, "Close", tint = PureWhite, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { viewModel.devAddChips(100) },
                colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                modifier = Modifier.weight(1.0f).height(32.dp).testTag("dev_add_chips"),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("+100 CHIPS", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { viewModel.devAddTickets(500) },
                colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                modifier = Modifier.weight(1.0f).height(32.dp).testTag("dev_add_tickets"),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("+500 TICKETS", color = ElectricCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { viewModel.devCompleteAllChallenges() },
                colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                modifier = Modifier.weight(1.2f).height(32.dp).testTag("dev_complete_challenges"),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("COMPLETE ALL", color = ElectricGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("APP VIEW MODE", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                AppMode.values().forEach { mode ->
                    val isSel = viewModel.currentMode == mode
                    Button(
                        onClick = { viewModel.currentMode = mode },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSel) BrightOrange else SoftBorder
                        ),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        modifier = Modifier.height(24.dp).testTag("mode_toggle_$mode")
                    ) {
                        Text(mode.name, color = if (isSel) PureWhite else TextGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (viewModel.currentMode == AppMode.STAFF) {
            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = SoftBorder)
            Spacer(modifier = Modifier.height(8.dp))
            Text("STAFF HUD - VENUE STATUS SUMMARY", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Kitchen Orders: Active", color = TextGray, fontSize = 10.sp)
                Text("3 Preparing • 1 Served", color = PureWhite, fontSize = 10.sp)
            }
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Floor Machines: Operational", color = TextGray, fontSize = 10.sp)
                Text("98.4%", color = ElectricGreen, fontSize = 10.sp)
            }
        }
    }
}

// ==========================================
// 8. CUSTOM MODALS & DIALOG DESIGN
// ==========================================

// A. Profile Transactions & History
@Composable
fun ProfileDialog(
    viewModel: ArcadeViewModel,
    transactions: List<TransactionEntity>,
    onDismiss: () -> Unit,
    onOpenPrizeVoucher: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(1.dp, SoftBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(480.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("YOUR PROFILE HUD", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.showSoundLog = !viewModel.showSoundLog },
                        colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f).height(34.dp)
                    ) {
                        Text("AUDIO MOCK DIALOG", color = PureWhite, fontSize = 10.sp)
                    }

                    Button(
                        onClick = {
                            onDismiss()
                            onOpenPrizeVoucher()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1.0f).height(34.dp).testTag("open_win_store")
                    ) {
                        Text("WIN! STORE", color = PureWhite, fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text("PERSONAL STATISTICS", color = BrightOrange, fontSize = 11.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GAMES PLAYED", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("248", color = PureWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TICKETS EARNED", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("18,240", color = ElectricCyan, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("FAVORITE GAME", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("Skee-Ball", color = PureWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = SoftBorder)
                Spacer(modifier = Modifier.height(14.dp))

                Text("TRANSACTION AUDIT LEDGER", color = BrightOrange, fontSize = 11.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(transactions) { tx ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tx.description, color = PureWhite, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val dateStr = java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(tx.timestamp))
                                Text(dateStr, color = TextGray, fontSize = 9.sp)
                            }
                            Text(
                                text = when (tx.type) {
                                    "CHIPS_PURCHASED" -> "+${tx.amountChips} Ch"
                                    "CHIPS_PLAYED" -> "-${tx.amountChips} Ch"
                                    "TICKETS_WON" -> "+${tx.amountTickets} Tk"
                                    "TICKETS_REDEEMED" -> "-${tx.amountTickets} Tk"
                                    else -> "+${tx.amountChips} Ch"
                                },
                                color = when (tx.type) {
                                    "CHIPS_PURCHASED" -> ElectricGreen
                                    "TICKETS_WON" -> ElectricCyan
                                    else -> PureWhite
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// B. Chips Package Reloader Selection
@Composable
fun ReloadChipsDialog(
    viewModel: ArcadeViewModel,
    mainCard: PowerCardEntity?,
    onDismiss: () -> Unit
) {
    val packages = listOf(
        Pair(75, 15.0),
        Pair(135, 25.0),
        Pair(200, 35.0),
        Pair(275, 45.0),
        Pair(400, 60.0),
        Pair(550, 75.0),
        Pair(750, 100.0)
    )

    var selectedMethod by remember { mutableStateOf("MOCK_VISA") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(1.dp, SoftBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(520.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ADD GAME CHIPS PACKAGE", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Text("Select synthetic demonstration pricing package to reload card.", color = TextGray, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(packages) { (chips, cost) ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SoftBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.buyGameChips(chips, cost, selectedMethod)
                                    onDismiss()
                                }
                                .testTag("chips_pack_$chips"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bolt, "Chips", tint = BrightOrange)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("$chips GAME CHIPS", color = PureWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(String.format("$%.0f", cost), color = BrightOrange, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                Divider(color = SoftBorder, modifier = Modifier.padding(vertical = 12.dp))

                Text("PAYMENT METHOD", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val methods = listOf(
                        Pair("MOCK_VISA", "VISA"),
                        Pair("MOCK_GPAY", "G-PAY"),
                        Pair("DECLINE_MOCK", "DECLINE")
                    )

                    methods.forEach { (id, label) ->
                        val sel = selectedMethod == id
                        Button(
                            onClick = { selectedMethod = id },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (sel) BrightOrange else SoftBorder
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f).height(30.dp).testTag("pay_method_$id"),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(label, color = if (sel) PureWhite else TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// C. Manage Card Lock and Transfers Screen
@Composable
fun ManagePowerCardsDialog(
    viewModel: ArcadeViewModel,
    powerCards: List<PowerCardEntity>,
    onDismiss: () -> Unit
) {
    var transferFrom by remember { mutableStateOf("") }
    var transferTo by remember { mutableStateOf("") }
    var transferAmount by remember { mutableStateOf("50") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(1.dp, SoftBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(480.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("MANAGE YOUR POWER CARDS", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.height(180.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(powerCards) { card ->
                        val isSel = viewModel.selectedPowerCard?.id == card.id
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (isSel) SoftBorder else DarkCharcoal),
                            modifier = Modifier.fillMaxWidth().clickable { viewModel.selectCardToManage(card) },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (isSel) BrightOrange else Color.Transparent)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(card.name, color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        if (card.isMain) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("(MAIN)", color = BrightOrange, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                    Text(card.id, color = TextGray, fontSize = 10.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("${card.chips} Ch", color = PureWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Button(
                                        onClick = { viewModel.toggleCardLockState(card.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (card.status == "ACTIVE") Color.DarkGray else Color.Red),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 6.dp),
                                        modifier = Modifier.height(24.dp).testTag("lock_card_${card.id}")
                                    ) {
                                        Text(if (card.status == "ACTIVE") "LOCK" else "UNLOCK", color = PureWhite, fontSize = 8.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Divider(color = SoftBorder, modifier = Modifier.padding(vertical = 12.dp))

                Text("CHIPS TRANSFER SYSTEM", color = BrightOrange, fontSize = 12.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = transferFrom,
                        onValueChange = { transferFrom = it },
                        placeholder = { Text("From ID", color = TextGray, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f).height(44.dp).testTag("transfer_from_input"),
                        colors = TextFieldDefaults.colors(focusedTextColor = PureWhite, unfocusedTextColor = PureWhite)
                    )

                    TextField(
                        value = transferTo,
                        onValueChange = { transferTo = it },
                        placeholder = { Text("To ID", color = TextGray, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f).height(44.dp).testTag("transfer_to_input"),
                        colors = TextFieldDefaults.colors(focusedTextColor = PureWhite, unfocusedTextColor = PureWhite)
                    )

                    TextField(
                        value = transferAmount,
                        onValueChange = { transferAmount = it },
                        placeholder = { Text("Qty", color = TextGray, fontSize = 11.sp) },
                        modifier = Modifier.width(60.dp).height(44.dp).testTag("transfer_amount_input"),
                        colors = TextFieldDefaults.colors(focusedTextColor = PureWhite, unfocusedTextColor = PureWhite)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val amt = transferAmount.toIntOrNull() ?: 50
                        viewModel.transferChipsBetweenCards(transferFrom, transferTo, amt)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(40.dp).testTag("execute_transfer_button")
                ) {
                    Text("CONFIRM TRANSFER", color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// D. Ticket Win! Store Redemptions
@Composable
fun WinStoreDialog(
    viewModel: ArcadeViewModel,
    prizes: List<PrizeEntity>,
    mainCard: PowerCardEntity?,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(1.dp, SoftBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(520.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("WIN! STORE REDEMPTION", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        Text(
                            text = "Your Balance: ${String.format("%,d", mainCard?.tickets ?: 0)} Tickets",
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(prizes) { prize ->
                        val ticketDiff = prize.cost - (mainCard?.tickets ?: 0)
                        val canAfford = ticketDiff <= 0

                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, SoftBorder),
                            modifier = Modifier.testTag("prize_item_${prize.id}")
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(SoftBorder),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = when (prize.category) {
                                            "BIG_WINS" -> "🏆"
                                            "ELECTRONICS" -> "🎧"
                                            "APPAREL" -> "🧥"
                                            "NOVELTY" -> "💡"
                                            "PLUSH" -> "🧸"
                                            else -> "🎁"
                                        },
                                        fontSize = 24.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prize.name, color = PureWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text("${String.format("%,d", prize.cost)} TICKETS", color = ElectricCyan, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                    if (!canAfford) {
                                        Text("${String.format("%,d", ticketDiff)} MORE NEEDED", color = Color.Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Button(
                                    onClick = {
                                        viewModel.redeemPrize(prize)
                                        onDismiss()
                                    },
                                    enabled = canAfford,
                                    colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp),
                                    modifier = Modifier.height(30.dp).testTag("redeem_button_${prize.id}")
                                ) {
                                    Text("REDEEM", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// E. Table ordering split bill
@Composable
fun SplitBillDialog(
    viewModel: ArcadeViewModel,
    onDismiss: () -> Unit
) {
    var tipPercent by remember { mutableStateOf(15) }
    var selectedSplitOption by remember { mutableStateOf("EQUAL") } // "EQUAL", "ITEMS"

    val baseTotal = 126.40
    val tipAmount = baseTotal * (tipPercent / 100.0)
    val finalTotal = baseTotal + tipAmount

    val friends = listOf(
        Pair("Tom", 0.25),
        Pair("Jordan", 0.22),
        Pair("Alex (You)", 0.33),
        Pair("Sam", 0.20)
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(1.dp, SoftBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(460.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SPLIT TABLE BILL (TABLE 42)", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("BASE SUBTOTAL: $126.40", color = TextGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(String.format("TOTAL WITH TIP: $%.2f", finalTotal), color = PureWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                    // Tip select
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(10, 15, 20).forEach { tip ->
                            Button(
                                onClick = { tipPercent = tip },
                                colors = ButtonDefaults.buttonColors(containerColor = if (tipPercent == tip) BrightOrange else SoftBorder),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Text("${tip}%", fontSize = 10.sp, color = PureWhite)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = SoftBorder)
                Spacer(modifier = Modifier.height(14.dp))

                Text("GROUP PARTICIPANTS", color = BrightOrange, fontSize = 12.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(friends) { (name, ratio) ->
                        val friendTotal = if (selectedSplitOption == "EQUAL") finalTotal / 4.0 else finalTotal * ratio
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(name, color = PureWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(String.format("$%.2f", friendTotal), color = PureWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { selectedSplitOption = "EQUAL" },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedSplitOption == "EQUAL") VibrantBlue else SoftBorder),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("EQUAL SPLIT", fontSize = 11.sp)
                    }
                    Button(
                        onClick = { selectedSplitOption = "RATIO" },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedSplitOption == "RATIO") VibrantBlue else SoftBorder),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("BY ITEMS", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        viewModel.playSoundEffect("paymentLoading")
                        viewModel.infoMessage = "PAYMENT COMPLETE: Table bill fully paid."
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricGreen),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(42.dp).testTag("split_bill_pay_button")
                ) {
                    Text("AUTHORIZE SIMULATED GROUP PAYMENT", color = DeepBlueBg, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// F. Reservation booking creator
@Composable
fun BookReservationDialog(
    viewModel: ArcadeViewModel,
    onDismiss: () -> Unit
) {
    var partySize by remember { mutableStateOf("6") }
    var selectedExp by remember { mutableStateOf("DINNER + PLAY") }
    var selectedDay by remember { mutableStateOf("SATURDAY") }

    val experiences = listOf("DINNER + PLAY", "BIRTHDAY", "SPORTS WATCH PARTY", "DARTS", "SHUFFLEBOARD")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(1.dp, SoftBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(440.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("BOOK YOUR NIGHT", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("CHOOSE EXPERIENCE", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    experiences.forEach { exp ->
                        val isSel = selectedExp == exp
                        Button(
                            onClick = { selectedExp = exp },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isSel) BrightOrange else SoftBorder),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(exp, fontSize = 9.sp, color = PureWhite)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PARTY SIZE", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        TextField(
                            value = partySize,
                            onValueChange = { partySize = it },
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("party_size_input"),
                            colors = TextFieldDefaults.colors(focusedTextColor = PureWhite, unfocusedTextColor = PureWhite)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("DAY", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Button(
                            onClick = { selectedDay = if (selectedDay == "SATURDAY") "SUNDAY" else "SATURDAY" },
                            colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("day_select_button")
                        ) {
                            Text(selectedDay, color = PureWhite, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("TIME SLOT PREFERRED: 19:30 PM", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.makeReservation(selectedDay, "19:30 PM", partySize.toIntOrNull() ?: 6, selectedExp)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp).testTag("confirm_reservation_button")
                ) {
                    Text("CONFIRM RESERVATION", color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// G. Play Session Simulation overlay Dialog
@Composable
fun GameSimulatorDialog(
    viewModel: ArcadeViewModel,
    onDismiss: () -> Unit
) {
    val game = viewModel.selectedGame ?: return

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DeepBlueCard),
            border = BorderStroke(2.dp, BrightOrange),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().wrapContentHeight()
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(game.name.uppercase(), color = BrightOrange, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss, enabled = !viewModel.isSimulationRunning) {
                        Icon(Icons.Default.Close, "Close", tint = PureWhite)
                    }
                }

                Text(game.description, color = TextGray, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 4.dp))
                Spacer(modifier = Modifier.height(10.dp))

                if (viewModel.simulationStage == "READY") {
                    Text("READY TO PLAY", color = ElectricGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Required chips: ${game.chipsRequired}", color = TextGray, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("HOW TO PLAY:", color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                    Text(game.howToPlay, color = TextLightGray, fontSize = 11.sp, modifier = Modifier.align(Alignment.Start).padding(top = 4.dp, bottom = 14.dp))

                    Button(
                        onClick = { viewModel.startArcadeSimulation() },
                        colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("start_simulation_button")
                    ) {
                        Text("START GAME SESSION", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                } else if (viewModel.simulationStage == "PLAYING") {
                    Text("GAME SESSION ACTIVE", color = Color.Red, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("TIME LEFT", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${viewModel.simulationTimeLeft}s", color = PureWhite, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("SCORE Ticker", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(String.format("%,d", viewModel.simulationScore), color = BrightOrange, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.testTag("sim_score"))
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("MULTIPLIER", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("x${viewModel.simulationMultiplier}", color = ElectricGreen, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("TICKETS ACCUMULATED: ${viewModel.simulationTickets}", color = ElectricCyan, fontSize = 13.sp, fontWeight = FontWeight.Black)

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.simulateAction("SHOOT") },
                            colors = ButtonDefaults.buttonColors(containerColor = BrightOrange),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(44.dp).testTag("sim_action_shoot")
                        ) {
                            Text("AIM & FIRE!", color = PureWhite, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.simulateAction("COMBO") },
                            colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(44.dp).testTag("sim_action_combo")
                        ) {
                            Text("COMBO ATTACK!", color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                } else if (viewModel.simulationStage == "FINISHED") {
                    Text("GAME OVER • SESSION COMPLETED", color = ElectricGreen, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(14.dp))

                    Text("FINAL SCORE: ${String.format("%,d", viewModel.simulationScore)}", color = PureWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("TICKETS EARNED: ${viewModel.simulationTickets}", color = ElectricCyan, fontSize = 16.sp, fontWeight = FontWeight.Black)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.selectGameToPlay(game) },
                        colors = ButtonDefaults.buttonColors(containerColor = VibrantBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(40.dp).testTag("play_again_button")
                    ) {
                        Text("PLAY AGAIN", color = PureWhite, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = SoftBorder),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(40.dp)
                    ) {
                        Text("RETURN TO ARCADE FLOOR", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
