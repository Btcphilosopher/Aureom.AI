package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrightOrange,
    secondary = VibrantBlue,
    tertiary = ElectricGreen,
    background = DeepBlueBg,
    surface = DeepBlueCard,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = DeepBlueBg,
    onBackground = PureWhite,
    onSurface = PureWhite,
    outline = SoftBorder,
    surfaceVariant = DarkCharcoal
)

private val LightColorScheme = lightColorScheme(
    primary = VibrantBlue,
    secondary = BrightOrange,
    tertiary = TicketOrange,
    background = IceWhite,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = DeepBlueBg,
    onSurface = DeepBlueBg,
    outline = Color(0xFFE4E9F2),
    surfaceVariant = Color(0xFFEDF1F7)
)

@Composable
fun ArcadePulseTheme(
    darkTheme: Boolean = true, // Force Dark Theme for immersive arcade feel!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
