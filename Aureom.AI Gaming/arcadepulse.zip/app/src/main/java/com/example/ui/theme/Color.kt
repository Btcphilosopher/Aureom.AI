package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Arcade Theme Colors
val DeepBlueBg = Color(0xFF090D22)       // Dark midnight floor
val DeepBlueCard = Color(0xFF131A40)     // Premium high-contrast card
val VibrantBlue = Color(0xFF0052FF)      // Electric brand blue
val BrightOrange = Color(0xFFFFA500)     // Energetic brand orange
val PureWhite = Color(0xFFFFFFFF)
val DarkCharcoal = Color(0xFF1C1D21)     // Smooth secondary surface
val ElectricGreen = Color(0xFF39FF14)    // Score, Level Up & Success Accent
val ElectricCyan = Color(0xFF00E5FF)     // Ticket counter Accent
val TicketOrange = Color(0xFFFF5A09)     // Orange ticket Accent
val IceWhite = Color(0xFFF4F6FA)
val TextGray = Color(0xFF8F9BB3)
val TextLightGray = Color(0xFFC5CEE0)
val SoftBorder = Color(0xFF222B45)
