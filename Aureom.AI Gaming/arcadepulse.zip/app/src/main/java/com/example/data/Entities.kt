package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "power_cards")
data class PowerCardEntity(
    @PrimaryKey val id: String,
    val name: String,
    val chips: Int,
    val tickets: Int,
    val status: String, // "ACTIVE", "LOCKED"
    val isMain: Boolean = false
)

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // "ARCADE", "RACING", "SPORTS", "SHOOTING", "SKILL", "VR", "CLASSICS", "PRIZE_GAMES", "SOCIAL"
    val chipsRequired: Int,
    val ticketsMin: Int,
    val ticketsMax: Int,
    val difficulty: Double, // 1.0 to 5.0
    val popularity: Double, // 1.0 to 5.0
    val personalHighScore: Long,
    val venueHighScore: Long,
    val isNew: Boolean = false,
    val isFavorite: Boolean = false,
    val description: String,
    val howToPlay: String,
    val isAvailable: Boolean = true,
    val waitTimeMinutes: Int = 0
)

@Entity(tableName = "game_sessions")
data class GameSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardId: String,
    val gameId: String,
    val gameName: String,
    val score: Long,
    val chipsUsed: Int,
    val ticketsWon: Int,
    val timestamp: Long
)

@Entity(tableName = "challenges")
data class ChallengeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val targetProgress: Int,
    val currentProgress: Int,
    val rewardChips: Int,
    val completed: Boolean = false,
    val claimed: Boolean = false,
    val category: String, // "DAILY", "WEEKLY", "VENUE", "GAME_SPECIFIC", "FOOD", "SOCIAL"
    val associatedGameId: String? = null
)

@Entity(tableName = "prizes")
data class PrizeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val cost: Int,
    val category: String, // "PLUSH", "ELECTRONICS", "TOYS", "COLLECTIBLES", "GAMES", "APPAREL", "NOVELTY", "BIG_WINS"
    val image: String,
    val availableQty: Int = 10
)

@Entity(tableName = "food_items")
data class FoodItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val category: String, // "STARTERS", "BURGERS", "SANDWICHES", "WINGS", "PIZZA", "SALADS", "DESSERTS", "DRINKS", "COCKTAILS", "BEER"
    val image: String
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableNumber: Int,
    val partySize: Int,
    val total: Double,
    val status: String, // "PREPARING", "ON_THE_WAY", "SERVED"
    val timestamp: Long,
    val isPaid: Boolean = false
)

@Entity(tableName = "order_items")
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val itemId: String,
    val name: String,
    val price: Double,
    val quantity: Int
)

@Entity(tableName = "reservations")
data class ReservationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val time: String,
    val people: Int,
    val experience: String, // "DINNER + PLAY", "BIRTHDAY", "SPORTS WATCH PARTY", "DARTS", "SHUFFLEBOARD", "CORPORATE"
    val status: String = "CONFIRMED", // "CONFIRMED", "COMPLETED"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val timestamp: Long,
    val isRead: Boolean = false
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "CHIPS_PURCHASED", "CHIPS_PLAYED", "TICKETS_WON", "TICKETS_REDEEMED", "FOOD_PURCHASED", "CHALLENGE_REWARD"
    val amountChips: Int,
    val amountTickets: Int,
    val amountCash: Double,
    val timestamp: Long,
    val description: String
)
