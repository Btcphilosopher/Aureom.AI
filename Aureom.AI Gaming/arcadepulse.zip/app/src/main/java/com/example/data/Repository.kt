package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ArcadeRepository(private val dao: ArcadeDao) {

    // Power Cards
    val allPowerCards: Flow<List<PowerCardEntity>> = dao.getAllPowerCards()
    val mainPowerCardFlow: Flow<PowerCardEntity?> = dao.getMainPowerCardFlow()

    suspend fun getMainPowerCard(): PowerCardEntity? = dao.getMainPowerCard()
    suspend fun getPowerCardById(id: String): PowerCardEntity? = dao.getPowerCardById(id)
    suspend fun savePowerCard(card: PowerCardEntity) = dao.insertPowerCard(card)
    suspend fun updatePowerCard(card: PowerCardEntity) = dao.updatePowerCard(card)

    // Games
    val allGames: Flow<List<GameEntity>> = dao.getAllGames()
    fun getGameFlowById(id: String): Flow<GameEntity?> = dao.getGameFlowById(id)
    suspend fun getGameById(id: String): GameEntity? = dao.getGameById(id)
    suspend fun updateGame(game: GameEntity) = dao.updateGame(game)

    // Game Sessions
    val allSessions: Flow<List<GameSessionEntity>> = dao.getAllSessions()
    suspend fun saveSession(session: GameSessionEntity) = dao.insertSession(session)

    // Challenges
    val allChallenges: Flow<List<ChallengeEntity>> = dao.getAllChallenges()
    suspend fun getChallengeById(id: String): ChallengeEntity? = dao.getChallengeById(id)
    suspend fun updateChallenge(challenge: ChallengeEntity) = dao.updateChallenge(challenge)

    // Prizes
    val allPrizes: Flow<List<PrizeEntity>> = dao.getAllPrizes()

    // Menu Items
    val allFoodItems: Flow<List<FoodItemEntity>> = dao.getAllFoodItems()

    // Orders
    val allOrders: Flow<List<OrderEntity>> = dao.getAllOrders()
    fun getOrderItemsFlow(orderId: Long): Flow<List<OrderItemEntity>> = dao.getOrderItemsByOrderIdFlow(orderId)
    suspend fun getOrderItems(orderId: Long): List<OrderItemEntity> = dao.getOrderItemsByOrderId(orderId)

    suspend fun placeOrder(tableNumber: Int, partySize: Int, total: Double, items: List<Pair<FoodItemEntity, Int>>): Long {
        val order = OrderEntity(
            tableNumber = tableNumber,
            partySize = partySize,
            total = total,
            status = "PREPARING",
            timestamp = System.currentTimeMillis()
        )
        val orderId = dao.insertOrder(order)
        val orderItemEntities = items.map { (item, qty) ->
            OrderItemEntity(
                orderId = orderId,
                itemId = item.id,
                name = item.name,
                price = item.price,
                quantity = qty
            )
        }
        dao.insertOrderItems(orderItemEntities)
        return orderId
    }

    suspend fun updateOrderStatus(orderId: Long, status: String) {
        // Find order
        val orders = dao.getAllOrders().firstOrNull() ?: return
        val order = orders.find { it.id == orderId } ?: return
        dao.updateOrder(order.copy(status = status))
    }

    suspend fun payOrder(orderId: Long) {
        val orders = dao.getAllOrders().firstOrNull() ?: return
        val order = orders.find { it.id == orderId } ?: return
        dao.updateOrder(order.copy(isPaid = true))
    }

    // Reservations
    val allReservations: Flow<List<ReservationEntity>> = dao.getAllReservations()
    suspend fun addReservation(res: ReservationEntity) = dao.insertReservation(res)

    // Notifications
    val allNotifications: Flow<List<NotificationEntity>> = dao.getAllNotifications()
    suspend fun addNotification(notif: NotificationEntity) = dao.insertNotification(notif)
    suspend fun markAllNotificationsAsRead() = dao.markAllNotificationsAsRead()

    // Transactions Ledger
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    suspend fun addTransaction(tx: TransactionEntity) = dao.insertTransaction(tx)


    // Seeding logic
    suspend fun checkAndSeedData() {
        val existingCards = dao.getAllPowerCards().firstOrNull()
        if (!existingCards.isNullOrEmpty()) {
            // Already seeded
            return
        }

        // Seed Power Cards
        dao.insertPowerCard(PowerCardEntity("DEMO-483920", "MAIN CARD", 1248, 1820, "ACTIVE", true))
        dao.insertPowerCard(PowerCardEntity("DEMO-123456", "FAMILY CARD", 420, 250, "ACTIVE", false))
        dao.insertPowerCard(PowerCardEntity("DEMO-789012", "GUEST CARD", 150, 10, "ACTIVE", false))

        // Seed Games
        val games = listOf(
            GameEntity(
                id = "SKEE-001",
                name = "Skee-Ball Classic",
                category = "SKILL",
                chipsRequired = 6,
                ticketsMin = 10,
                ticketsMax = 200,
                difficulty = 2.5,
                popularity = 4.8,
                personalHighScore = 84200,
                venueHighScore = 120480,
                isFavorite = true,
                description = "The absolute arcade classic! Smoothly roll the wooden balls down the lane and aim for high-value rings.",
                howToPlay = "1. Lift balls from the tray.\n2. Roll ball up the lane with consistent force.\n3. Target the high-value 100 & 50 rings in the top corners.\n4. Score points over 9 shots to win tickets."
            ),
            GameEntity(
                id = "TOPG-002",
                name = "Top Gun: Jet Fighter",
                category = "SHOOTING",
                chipsRequired = 8,
                ticketsMin = 20,
                ticketsMax = 450,
                difficulty = 4.0,
                popularity = 4.9,
                personalHighScore = 428300,
                venueHighScore = 1204800,
                isNew = true,
                description = "Immersive motion flight simulator with realistic cockpit seating and physical rumble feedback.",
                howToPlay = "1. Hold the flight joystick with dual triggers.\n2. Steer your F-18 fighter plane through obstacles.\n3. Fire cannon at targets and pull missile triggers when locked on.\n4. Survive wave attacks to set the high score."
            ),
            GameEntity(
                id = "MKART-003",
                name = "Mario Kart Arcade GP DX",
                category = "RACING",
                chipsRequired = 7,
                ticketsMin = 15,
                ticketsMax = 250,
                difficulty = 3.0,
                popularity = 5.0,
                personalHighScore = 1520,
                venueHighScore = 2100,
                isFavorite = true,
                description = "Official Nintendo racing simulation cabin. Force-feedback steering wheel, pedal, and character camera.",
                howToPlay = "1. Sit down, adjust seat, and choose character.\n2. Smile for the camera (your face is on screen!).\n3. Press the green pedal to race and spin the steering wheel.\n4. Press the item button on the wheel to shoot shell items."
            ),
            GameEntity(
                id = "UFC-004",
                name = "UFC Punch Out",
                category = "SPORTS",
                chipsRequired = 8,
                ticketsMin = 5,
                ticketsMax = 150,
                difficulty = 3.5,
                popularity = 4.2,
                personalHighScore = 23400,
                venueHighScore = 48000,
                description = "Test your arm strength and visual speed. Strike the heavy bag pads as they illuminate.",
                howToPlay = "1. Don boxing gloves and stand clear.\n2. Press Start and await the light signals.\n3. Punch the specific pads as they flash green.\n4. Deliver a final knockout punch to record maximum impact score."
            ),
            GameEntity(
                id = "GODZ-005",
                name = "Godzilla VR: Tokyo Smash",
                category = "VR",
                chipsRequired = 12,
                ticketsMin = 50,
                ticketsMax = 800,
                difficulty = 4.5,
                popularity = 4.9,
                isNew = true,
                personalHighScore = 78000,
                venueHighScore = 154000,
                description = "Virtual reality 360-degree chaos simulator. Enter the beast and defend or destroy the Japanese metropolis.",
                howToPlay = "1. Secure the VR Headset and put on headphones.\n2. Grip the dual handheld motion sensors.\n3. Swipe arm to claw and smash buildings.\n4. Hold trigger and roar to unleash Godzilla atomic heat breath."
            ),
            GameEntity(
                id = "CRANE-006",
                name = "Mega Claw Crane",
                category = "PRIZE_GAMES",
                chipsRequired = 4,
                ticketsMin = 0,
                ticketsMax = 0,
                difficulty = 5.0,
                popularity = 4.0,
                personalHighScore = 3,
                venueHighScore = 10,
                description = "High-accuracy mechanical grabber. Grab massive high-quality plushies, devices, or prize tickets directly.",
                howToPlay = "1. Insert chips and position joystick.\n2. Use joystick to move crane claw left/right & back/forth.\n3. Watch the dual-angled mirrors for perfect prize alignment.\n4. Hit the red button to drop claw and secure the loot."
            ),
            GameEntity(
                id = "HOCKEY-007",
                name = "Neon Fast-Track Air Hockey",
                category = "SOCIAL",
                chipsRequired = 6,
                ticketsMin = 10,
                ticketsMax = 100,
                difficulty = 2.0,
                popularity = 4.6,
                personalHighScore = 7,
                venueHighScore = 9,
                description = "Double-blower powerful frictionless table. Ideal for competitive social play with friends.",
                howToPlay = "1. Grab your player mallet.\n2. Strike the hovering puck with force.\n3. Block puck from sliding into your net slot.\n4. First player to score 7 goals wins the game!"
            ),
            GameEntity(
                id = "BASKET-008",
                name = "Super Shot Basketball",
                category = "SPORTS",
                chipsRequired = 6,
                ticketsMin = 10,
                ticketsMax = 180,
                difficulty = 3.0,
                popularity = 4.7,
                personalHighScore = 82,
                venueHighScore = 114,
                description = "Rapid shooter challenge. Real basketballs, dual moving hoops, and high-intensity digital clock.",
                howToPlay = "1. Take a basketball from the metal ramp.\n2. Shoot smoothly from the wrist towards hoop.\n3. Clean shots get clean points.\n4. In final 15 seconds, the hoop begins moving; score now for triple-points."
            )
        )
        games.forEach { dao.insertGame(it) }

        // Seed Challenges
        val challenges = listOf(
            ChallengeEntity("CH-001", "Skee-Ball King", "Play 20 games of Skee-Ball Classic to prove your roll superiority.", 20, 7, 100, false, false, "GAME_SPECIFIC", "SKEE-001"),
            ChallengeEntity("CH-002", "Arcade Explorer", "Play 5 completely different games on the arcade floor.", 5, 3, 75, false, false, "DAILY", null),
            ChallengeEntity("CH-003", "Zone Destroyer", "Achieve a score higher than 500,000 on any jet action game.", 1, 1, 150, true, true, "WEEKLY", "TOPG-002"),
            ChallengeEntity("CH-004", "Ice Warrior", "Complete 3 air hockey matches against friends.", 3, 1, 50, false, false, "SOCIAL", "HOCKEY-007"),
            ChallengeEntity("CH-005", "Tokyo Savior", "Unleash Godzilla VR Tokyo Smash twice on high-end virtual headsets.", 2, 1, 120, false, false, "DAILY", "GODZ-005"),
            ChallengeEntity("CH-006", "Sizzling Bite", "Order any hot food special and complete any 1 arcade game during your visit.", 1, 1, 50, true, false, "FOOD", null),
            ChallengeEntity("CH-007", "Weekend Vanguard", "Visit and scan your Power Card at Manchester Venue on any Saturday.", 1, 1, 80, true, true, "VENUE", null)
        )
        challenges.forEach { dao.insertChallenge(it) }

        // Seed Prizes
        val prizes = listOf(
            PrizeEntity("PR-001", "Legendary Golden Game Controller", 50000, "BIG_WINS", "golden_controller"),
            PrizeEntity("PR-002", "Pro ANC Wireless Headphones", 12000, "ELECTRONICS", "headphones"),
            PrizeEntity("PR-003", "Super Sonic Gaming Mouse", 4500, "ELECTRONICS", "gaming_mouse"),
            PrizeEntity("PR-004", "Retro Arcade Cabinet (Mini-Edition)", 25000, "COLLECTIBLES", "mini_cabinet"),
            PrizeEntity("PR-005", "Pulse Premium Branded Hoodie", 3500, "APPAREL", "hoodie"),
            PrizeEntity("PR-006", "Neon Hexagon Table Smart Lamp", 2800, "NOVELTY", "hexagon_lamp"),
            PrizeEntity("PR-007", "Giant Octopus Plushie", 1500, "PLUSH", "octopus_plush"),
            PrizeEntity("PR-008", "ArcadePulse Mystery Toys Box", 800, "TOYS", "mystery_box")
        )
        prizes.forEach { dao.insertPrize(it) }

        // Seed Food Menu Items
        val foodItems = listOf(
            FoodItemEntity("FD-001", "Bacon Cheeseburger Deluxe", "Premium double beef patties, melted American cheddar, crispy hickory-smoked bacon, house sauce, toasted brioche bun, seasoned spiral fries.", 17.99, "BURGERS", "burger"),
            FoodItemEntity("FD-002", "Crispy Premium Chicken Tenders", "Fresh hand-breaded chicken tenders marinated in buttermilk, fried golden-crispy, honey mustard and smokey BBQ dips, served with fries.", 14.99, "STARTERS", "tenders"),
            FoodItemEntity("FD-003", "Chilli Cheese Volcano Fries", "Large tray of crispy fries smothered in ground beef chili, hot melted craft cheddar cheese, jalapeño slices, and fresh green onions.", 12.99, "STARTERS", "fries"),
            FoodItemEntity("FD-004", "Philly Steak & Cheese Sub", "Thinly shaved premium ribeye steak, caramelized sweet onions, sautéed green peppers, loaded with melted sharp provolone cheese.", 16.99, "SANDWICHES", "philly"),
            FoodItemEntity("FD-005", "Buffalo Fire Jumbo Wings", "10 pieces of giant bone-in wings tossed in tangy cayenne pepper buffalo glaze, crunchy celery sticks, creamy blue cheese dressing.", 18.49, "WINGS", "wings"),
            FoodItemEntity("FD-006", "Ultimate Meat Flatbread Pizza", "Oven-fired artisanal flatbread loaded with spicy Italian pepperoni, crumbled sausage, bacon bits, classic marinara, fresh mozzarella.", 15.99, "PIZZA", "pizza"),
            FoodItemEntity("FD-007", "Hot Fudge Brownie Mountain", "Warm soft-baked chocolate brownie crowned with dual scoops of vanilla bean ice cream, hot fudge drizzle, fluffy whipped cream, cherry.", 9.99, "DESSERTS", "brownie"),
            FoodItemEntity("FD-008", "Local Rotating Craft Pint", "Fresh poured pint of our custom craft beers. Ask your digital server for current rotating seasonal draft specials.", 7.50, "BEER", "beer"),
            FoodItemEntity("FD-009", "Signature Electric Blue Tonic", "Refreshing blend of premium citrus vodka, fresh lemonade, Blue Curaçao, garnished with a souvenir flashing neon LED ice cube.", 13.99, "COCKTAILS", "cocktail")
        )
        foodItems.forEach { dao.insertFoodItem(it) }

        // Seed initial notifications
        dao.insertNotification(NotificationEntity(0, "🏆 Skee-Ball King Level-Up!", "You earned 100 Bonus Chips in your Skee-Ball King challenge.", System.currentTimeMillis() - 3600000))
        dao.insertNotification(NotificationEntity(0, "🎮 New Game Arrival!", "Godzilla VR: Tokyo Smash is now live and waiting for you in the VR Zone.", System.currentTimeMillis() - 7200000))
        dao.insertNotification(NotificationEntity(0, "🍔 Weekend Hot Offer!", "Grab a Bacon Cheeseburger Deluxe + 100 Game Chips for just $29.99 today.", System.currentTimeMillis() - 86400000))

        // Seed initial transaction records
        dao.insertTransaction(TransactionEntity(0, "CHIPS_PURCHASED", 275, 0, 45.0, System.currentTimeMillis() - 172800000, "Purchased 275 Game Chips package via Visa"))
        dao.insertTransaction(TransactionEntity(0, "TICKETS_WON", 0, 180, 0.0, System.currentTimeMillis() - 1500000, "Won 180 Tickets playing Skee-Ball Classic"))
    }
}
