import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { MacroTab } from './components/MacroTab';
import { CapitalStructureTab } from './components/CapitalStructureTab';
import { OrderBookTab } from './components/OrderBookTab';
import { BitcoinTab } from './components/BitcoinTab';
import { LedgerTab } from './components/LedgerTab';
import { RResearchTab } from './components/RResearchTab';
import { CodeInspectorTab } from './components/CodeInspectorTab';
import { ScenarioPreset, EconomicMetrics, ProductionStage, BitcoinNetworkState, CausalDiagnosticNode, LimitOrder, LedgerEntry } from './engine/simulation';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('macro');
  const [tick, setTick] = useState<number>(0);
  const [scenario, setScenario] = useState<ScenarioPreset>('BITCOIN_STANDARD');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  
  const [metrics, setMetrics] = useState<EconomicMetrics | null>(null);
  const [history, setHistory] = useState<EconomicMetrics[]>([]);
  const [stages, setStages] = useState<ProductionStage[]>([]);
  const [btcNetwork, setBtcNetwork] = useState<BitcoinNetworkState | null>(null);
  const [causalDiagnostics, setCausalDiagnostics] = useState<CausalDiagnosticNode[]>([]);
  
  const [bids, setBids] = useState<LimitOrder[]>([]);
  const [asks, setAsks] = useState<LimitOrder[]>([]);
  const [lastTradedPrice, setLastTradedPrice] = useState<number>(148.50);
  const [volume24h, setVolume24h] = useState<number>(52400);

  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>([]);

  // Timer reference for live ticking
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch initial state
  useEffect(() => {
    fetchState();
  }, []);

  const fetchState = async () => {
    try {
      const res = await fetch('/api/simulation/state');
      const data = await res.json();
      setTick(data.tick);
      setScenario(data.scenario);
      setMetrics(data.latestMetrics);
      setHistory(data.history || []);
      setStages(data.stages || []);
      setBtcNetwork(data.btcNetwork);
      setCausalDiagnostics(data.causalDiagnostics || []);

      fetchOrderBook();
      fetchLedger();
    } catch (err) {
      console.error('Failed to fetch simulation state', err);
    }
  };

  const fetchOrderBook = async () => {
    try {
      const res = await fetch('/api/market/orderbook');
      const data = await res.json();
      setBids(data.bids || []);
      setAsks(data.asks || []);
      setLastTradedPrice(data.lastTradedPrice || 148.5);
      setVolume24h(data.volume24h || 52400);
    } catch (err) {
      console.error('Failed to fetch order book', err);
    }
  };

  const fetchLedger = async () => {
    try {
      const res = await fetch('/api/ledger/entries');
      const data = await res.json();
      setLedgerEntries(data.ledger || []);
    } catch (err) {
      console.error('Failed to fetch ledger entries', err);
    }
  };

  const handleStepTick = async (count: number = 1) => {
    try {
      const res = await fetch('/api/simulation/tick', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ steps: count }),
      });
      const data = await res.json();
      setTick(data.tick);
      fetchState();
    } catch (err) {
      console.error('Failed to step tick', err);
    }
  };

  const handleSelectScenario = async (newScenario: ScenarioPreset) => {
    setIsRunning(false);
    try {
      const res = await fetch('/api/simulation/scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario: newScenario }),
      });
      const data = await res.json();
      setScenario(data.scenario);
      fetchState();
    } catch (err) {
      console.error('Failed to switch scenario', err);
    }
  };

  const handlePlaceOrder = async (price: number, quantity: number, isBuy: boolean) => {
    try {
      const res = await fetch('/api/market/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId: 'HH_1', price, quantity, isBuy }),
      });
      const data = await res.json();
      setBids(data.bids || []);
      setAsks(data.asks || []);
      setLastTradedPrice(data.lastTradedPrice || lastTradedPrice);
    } catch (err) {
      console.error('Failed to place order', err);
    }
  };

  // Live simulation ticker interval
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        handleStepTick(1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRunning]);

  return (
    <div id="app-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Navigation Header */}
      <Header
        tick={tick}
        scenario={scenario}
        isRunning={isRunning}
        onTogglePlay={() => setIsRunning(!isRunning)}
        onStepTick={handleStepTick}
        onSelectScenario={handleSelectScenario}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Tab Workspace */}
      <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6">
        
        {activeTab === 'macro' && (
          <MacroTab
            metrics={metrics}
            history={history}
            causalDiagnostics={causalDiagnostics}
          />
        )}

        {activeTab === 'capital' && (
          <CapitalStructureTab
            stages={stages}
            interestRateMarket={metrics?.interestRateMarket || 0.045}
          />
        )}

        {activeTab === 'orderbook' && (
          <OrderBookTab
            lastTradedPrice={lastTradedPrice}
            volume24h={volume24h}
            bids={bids}
            asks={asks}
            onPlaceOrder={handlePlaceOrder}
          />
        )}

        {activeTab === 'bitcoin' && btcNetwork && (
          <BitcoinTab btcNetwork={btcNetwork} />
        )}

        {activeTab === 'ledger' && (
          <LedgerTab entries={ledgerEntries} />
        )}

        {activeTab === 'r_lab' && (
          <RResearchTab />
        )}

        {activeTab === 'code' && (
          <CodeInspectorTab />
        )}

      </main>

      {/* Footer */}
      <footer id="footer-container" className="border-t border-slate-900 bg-slate-950 py-3 px-4 text-center font-mono text-xs text-slate-500">
        GameEconomy Engine v0.1.0 • High-Performance Rust Simulation Core & R Econometric Lab • Double-Entry Accounting Invariant
      </footer>

    </div>
  );
}
