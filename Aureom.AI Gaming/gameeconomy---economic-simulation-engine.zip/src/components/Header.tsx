import React from 'react';
import { Play, Pause, FastForward, RotateCcw } from 'lucide-react';
import { ScenarioPreset } from '../engine/simulation';

interface HeaderProps {
  tick: number;
  scenario: ScenarioPreset;
  isRunning: boolean;
  onTogglePlay: () => void;
  onStepTick: (count: number) => void;
  onSelectScenario: (scenario: ScenarioPreset) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  tick,
  scenario,
  isRunning,
  onTogglePlay,
  onStepTick,
  onSelectScenario,
  activeTab,
  setActiveTab,
}) => {
  const tabs = [
    { id: 'macro', label: '1. Macro & Business Cycles', icon: '📊' },
    { id: 'capital', label: '2. Capital Structure (Triangle)', icon: '🔺' },
    { id: 'orderbook', label: '3. Order Book & Markets', icon: '📈' },
    { id: 'bitcoin', label: '4. Bitcoin & Mining', icon: '⚡' },
    { id: 'ledger', label: '5. Double-Entry Ledger', icon: '📜' },
    { id: 'r_lab', label: '6. R Research & Monte Carlo', icon: '🧪' },
    { id: 'code', label: '7. Rust & R Code Inspector', icon: '💻' },
  ];

  return (
    <header id="header-container" className="bg-[#111114] border-b border-[#2A2A2E] text-[#D1D1D1] px-4 py-3 sticky top-0 z-50">
      <div id="header-top-bar" className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 max-w-7xl mx-auto">
        
        {/* Brand & Status */}
        <div id="brand-section" className="flex items-center gap-3">
          <div id="brand-logo" className="w-8 h-8 bg-[#E64A19] text-black font-bold font-mono rounded-sm flex items-center justify-center text-sm tracking-tighter shadow-sm">
            GE
          </div>
          <div>
            <div id="brand-title-group" className="flex items-center gap-2">
              <h1 id="brand-title" className="font-mono text-base font-medium tracking-tight text-white uppercase">
                GameEconomy <span className="text-[#666] font-light text-xs">v1.0.4-stable</span>
              </h1>
              <span id="brand-tag" className="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded-sm bg-[#1A1A1E] text-[#E64A19] border border-[#E64A19]/30 uppercase tracking-wider">
                RUST + R ENGINE
              </span>
            </div>
            <p id="brand-subtitle" className="text-[11px] text-[#666] font-sans">
              Austrian Economic Simulation & Econometric Lab
            </p>
          </div>
        </div>

        {/* System Engine Status Indicators */}
        <div id="system-status-pills" className="hidden xl:flex items-center gap-6 text-[10px] font-mono">
          <div className="flex flex-col">
            <span className="text-[#666] uppercase tracking-wider">Rust Core</span>
            <span className="text-[#4CAF50] font-bold">● ACTIVE [4.2ms/tick]</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[#666] uppercase tracking-wider">R Research</span>
            <span className="text-[#2196F3] font-bold">● LINKED [Calibrating]</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[#666] uppercase tracking-wider">SQL Ledger</span>
            <span className="text-[#FFC107] font-bold">● AUTHORITATIVE</span>
          </div>
        </div>

        {/* Engine Tick & Play Controls */}
        <div id="controls-section" className="flex flex-wrap items-center gap-2.5">
          
          {/* Tick Counter */}
          <div id="tick-counter" className="bg-[#16161A] border border-[#222] px-3 py-1.5 rounded-sm font-mono text-xs flex items-center gap-2">
            <span className="text-[#666] uppercase text-[10px] tracking-wider font-bold">TICK:</span>
            <span className="text-white font-bold text-sm">{tick.toLocaleString()}</span>
          </div>

          {/* Scenario Picker */}
          <div id="scenario-selector-group" className="flex items-center gap-1.5">
            <label id="scenario-label" htmlFor="scenario-select" className="text-[10px] text-[#666] font-mono font-bold uppercase tracking-wider hidden sm:inline">
              SCENARIO:
            </label>
            <select
              id="scenario-select"
              value={scenario}
              onChange={(e) => onSelectScenario(e.target.value as ScenarioPreset)}
              className="bg-[#16161A] border border-[#2A2A2E] text-white text-xs font-mono rounded-sm px-2.5 py-1.5 focus:outline-none focus:border-[#E64A19] transition-colors"
            >
              <option value="BITCOIN_STANDARD">1. Bitcoin Standard & Sound Money</option>
              <option value="EASY_CREDIT_BOOM_BUST">2. Easy Credit Boom & Malinvestment Bust</option>
              <option value="TECH_DEFLATION_BOOM">3. Technology Revolution & Deflation</option>
              <option value="RESOURCE_SCARCITY">4. Resource Scarcity & Bottlenecks</option>
            </select>
          </div>

          {/* Simulation Controls */}
          <div id="play-controls-group" className="flex items-center gap-1 bg-[#16161A] p-1 rounded-sm border border-[#222]">
            <button
              id="btn-toggle-play"
              onClick={onTogglePlay}
              className={`px-3 py-1 rounded-sm text-xs font-mono font-bold flex items-center gap-1.5 transition-colors uppercase tracking-wider ${
                isRunning
                  ? 'bg-[#FF9800] text-black hover:bg-[#FFB74D]'
                  : 'bg-[#E64A19] text-black hover:bg-[#FF5722]'
              }`}
            >
              {isRunning ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              {isRunning ? 'PAUSE' : 'RUN'}
            </button>

            <button
              id="btn-step-1"
              onClick={() => onStepTick(1)}
              title="Step 1 Tick"
              className="p-1.5 text-[#888] hover:text-white hover:bg-[#222] rounded-sm transition-colors"
            >
              <FastForward className="w-3.5 h-3.5" />
            </button>

            <button
              id="btn-step-10"
              onClick={() => onStepTick(10)}
              className="px-2 py-1 text-[10px] font-mono text-[#888] hover:text-white hover:bg-[#222] rounded-sm transition-colors font-bold"
            >
              +10
            </button>

            <button
              id="btn-reset"
              onClick={() => onSelectScenario(scenario)}
              title="Reset Scenario"
              className="p-1.5 text-[#666] hover:text-[#F44336] hover:bg-[#222] rounded-sm transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

      </div>

      {/* Tabs */}
      <nav id="tabs-navigation" className="max-w-7xl mx-auto mt-3 border-t border-[#222] pt-2 flex items-center gap-1 overflow-x-auto no-scrollbar">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-btn-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-sm whitespace-nowrap transition-all flex items-center gap-1.5 border-b-2 ${
                isActive
                  ? 'bg-[#1A1A1E] text-white border-[#E64A19]'
                  : 'text-[#888] hover:text-[#D1D1D1] hover:bg-[#1A1A1E] border-transparent'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};

