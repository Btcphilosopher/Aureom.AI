import React, { useState, useEffect } from 'react';
import { FileCode, Folder, ChevronRight, Copy, Check } from 'lucide-react';

export const CodeInspectorTab: React.FC = () => {
  const [activeFile, setActiveFile] = useState<string>('gameeconomy/src/core/economic_state.rs');
  const [codeContent, setCodeContent] = useState<string>('// Loading file...');
  const [copied, setCopied] = useState<boolean>(false);

  const fileTree = [
    {
      group: 'RUST ENGINE (gameeconomy/)',
      files: [
        'gameeconomy/Cargo.toml',
        'gameeconomy/src/lib.rs',
        'gameeconomy/src/main.rs',
        'gameeconomy/src/core/economic_state.rs',
        'gameeconomy/src/core/agent.rs',
        'gameeconomy/src/accounting/ledger.rs',
        'gameeconomy/src/capital/structure.rs',
        'gameeconomy/src/markets/order_book.rs',
        'gameeconomy/src/monetary/bitcoin.rs',
      ],
    },
    {
      group: 'R RESEARCH LAYER (R/)',
      files: [
        'R/economics/preferences.R',
        'R/economics/capital.R',
        'R/monetary/bitcoin.R',
        'R/research/monte_carlo.R',
      ],
    },
    {
      group: 'POSTGRESQL LEDGER (migrations/)',
      files: [
        'migrations/0001_initial_economic_ledger.sql',
      ],
    },
  ];

  useEffect(() => {
    fetchFileContent(activeFile);
  }, [activeFile]);

  const fetchFileContent = async (path: string) => {
    try {
      const res = await fetch(`/api/source-code?path=${encodeURIComponent(path)}`);
      const data = await res.json();
      if (data.content) {
        setCodeContent(data.content);
      } else {
        setCodeContent(`// Could not load content for ${path}`);
      }
    } catch (err: any) {
      setCodeContent(`// Error loading file: ${err.message}`);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="code-inspector-tab" className="grid grid-cols-1 lg:grid-cols-4 gap-4">
      
      {/* File Tree Navigator */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-4 font-mono text-xs">
        <div className="text-slate-200 font-bold border-b border-slate-800 pb-2 flex items-center gap-2">
          <Folder className="w-4 h-4 text-cyan-400" />
          <span>PROJECT FILE TREE</span>
        </div>

        <div className="space-y-3">
          {fileTree.map((section) => (
            <div key={section.group} className="space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{section.group}</div>
              <div className="space-y-0.5">
                {section.files.map((filePath) => {
                  const isActive = activeFile === filePath;
                  const fileName = filePath.split('/').pop();
                  return (
                    <button
                      key={filePath}
                      onClick={() => setActiveFile(filePath)}
                      className={`w-full text-left px-2 py-1.5 rounded transition-colors flex items-center gap-1.5 truncate ${
                        isActive
                          ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      <FileCode className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{fileName}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Code Viewer Panel */}
      <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded flex flex-col overflow-hidden">
        
        <div className="bg-slate-950 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
          <div className="font-mono text-xs font-bold text-cyan-400 flex items-center gap-2">
            <FileCode className="w-4 h-4 text-cyan-400" />
            <span>{activeFile}</span>
          </div>

          <button
            onClick={handleCopy}
            className="text-xs font-mono text-slate-400 hover:text-cyan-300 flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'COPIED' : 'COPY'}</span>
          </button>
        </div>

        <div className="p-4 bg-slate-950 overflow-x-auto flex-1 font-mono text-xs text-slate-200">
          <pre className="whitespace-pre font-mono text-[11px] leading-relaxed text-slate-300">
            {codeContent}
          </pre>
        </div>

      </div>

    </div>
  );
};
