import React, { useState } from 'react';
import { LimitOrder } from '../engine/simulation';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface OrderBookTabProps {
  lastTradedPrice: number;
  volume24h: number;
  bids: LimitOrder[];
  asks: LimitOrder[];
  onPlaceOrder: (price: number, quantity: number, isBuy: boolean) => void;
}

export const OrderBookTab: React.FC<OrderBookTabProps> = ({
  lastTradedPrice,
  volume24h,
  bids,
  asks,
  onPlaceOrder,
}) => {
  const [priceInput, setPriceInput] = useState<string>(lastTradedPrice.toFixed(2));
  const [qtyInput, setQtyInput] = useState<string>('10');

  const handleOrderSubmit = (isBuy: boolean) => {
    const p = parseFloat(priceInput);
    const q = parseFloat(qtyInput);
    if (!isNaN(p) && !isNaN(q) && p > 0 && q > 0) {
      onPlaceOrder(p, q, isBuy);
    }
  };

  return (
    <div id="orderbook-tab" className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      
      {/* Left Column: Order Book Depth */}
      <div className="lg:col-span-2 bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-4">
        
        <div className="flex items-center justify-between border-b border-[#222] pb-3">
          <div>
            <h2 className="font-mono text-xs font-bold text-white flex items-center gap-2 uppercase tracking-wider">
              <span>L2 ORDER BOOK MATCHING ENGINE</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#1A1A1E] text-[#E64A19] border border-[#E64A19]/30">
                SYMBOL: GOOD_ALPHA
              </span>
            </h2>
            <div className="text-[11px] text-[#666] mt-0.5 font-sans">Continuous Double Auction & Settlement</div>
          </div>

          <div className="flex items-center gap-4 font-mono text-xs">
            <div>
              <span className="text-[#666]">LAST: </span>
              <span className="text-white font-bold">${lastTradedPrice.toFixed(2)}</span>
            </div>
            <div>
              <span className="text-[#666]">24H VOL: </span>
              <span className="text-[#FF9800] font-bold">{volume24h.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Order Book Grid (Asks above Bids) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          
          {/* ASKS (Sell Orders) */}
          <div className="bg-[#16161A] p-3 rounded-sm border border-[#222] space-y-2">
            <div className="text-[#F44336] font-bold flex justify-between border-b border-[#222] pb-1 text-[10px] tracking-wider">
              <span>ASK PRICE ($)</span>
              <span>QTY</span>
            </div>
            <div className="space-y-1">
              {asks.slice(0, 8).map((ask) => (
                <div key={ask.orderId} className="flex justify-between text-[#F44336] hover:bg-[#F44336]/10 px-1 py-0.5 rounded-sm">
                  <span>${ask.price.toFixed(2)}</span>
                  <span>{ask.quantity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* BIDS (Buy Orders) */}
          <div className="bg-[#16161A] p-3 rounded-sm border border-[#222] space-y-2">
            <div className="text-[#4CAF50] font-bold flex justify-between border-b border-[#222] pb-1 text-[10px] tracking-wider">
              <span>BID PRICE ($)</span>
              <span>QTY</span>
            </div>
            <div className="space-y-1">
              {bids.slice(0, 8).map((bid) => (
                <div key={bid.orderId} className="flex justify-between text-[#4CAF50] hover:bg-[#4CAF50]/10 px-1 py-0.5 rounded-sm">
                  <span>${bid.price.toFixed(2)}</span>
                  <span>{bid.quantity}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Right Column: Order Placement Form */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-4">
        <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider border-b border-[#222] pb-2">
          Place Limit Order
        </h3>

        <div className="space-y-3 font-mono text-xs">
          <div>
            <label className="text-[#666] block mb-1 font-bold text-[10px] tracking-wider">PRICE ($)</label>
            <input
              type="number"
              step="0.1"
              value={priceInput}
              onChange={(e) => setPriceInput(e.target.value)}
              className="w-full bg-[#16161A] border border-[#2A2A2E] rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#E64A19] transition-colors"
            />
          </div>

          <div>
            <label className="text-[#666] block mb-1 font-bold text-[10px] tracking-wider">QUANTITY</label>
            <input
              type="number"
              step="1"
              value={qtyInput}
              onChange={(e) => setQtyInput(e.target.value)}
              className="w-full bg-[#16161A] border border-[#2A2A2E] rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#E64A19] transition-colors"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => handleOrderSubmit(true)}
              className="bg-[#4CAF50] hover:bg-[#66BB6A] text-black font-bold py-2 px-3 rounded-sm flex items-center justify-center gap-1.5 transition-colors uppercase tracking-wider text-xs"
            >
              <ArrowUpRight className="w-4 h-4" />
              BUY LIMIT
            </button>

            <button
              onClick={() => handleOrderSubmit(false)}
              className="bg-[#E64A19] hover:bg-[#FF5722] text-black font-bold py-2 px-3 rounded-sm flex items-center justify-center gap-1.5 transition-colors uppercase tracking-wider text-xs"
            >
              <ArrowDownRight className="w-4 h-4" />
              SELL LIMIT
            </button>
          </div>
        </div>

        <div className="bg-[#16161A] p-3 rounded-sm text-[11px] font-mono text-[#888] border border-[#222] space-y-1">
          <div className="text-white font-bold text-[10px] uppercase tracking-wider">Matching Protocol Rules:</div>
          <div>• Price-time priority order execution</div>
          <div>• Instant clearance against double-entry ledger</div>
          <div>• Zero counterparty settlement risk</div>
        </div>
      </div>

    </div>
  );
};

