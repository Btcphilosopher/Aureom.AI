import React from 'react';
import { EconomicMetrics, CausalDiagnosticNode } from '../engine/simulation';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, AreaChart, Area } from 'recharts';
import { AlertCircle, Activity, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface MacroTabProps {
  metrics: EconomicMetrics | null;
  history: EconomicMetrics[];
  causalDiagnostics: CausalDiagnosticNode[];
}

export const MacroTab: React.FC<MacroTabProps> = ({ metrics, history, causalDiagnostics }) => {
  if (!metrics) return null;

  return (
    <div id="macro-tab-container" className="space-y-6">
      
      {/* Top Key Metric Cards */}
      <div id="metric-cards-grid" className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        
        <div id="card-gdp" className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] font-mono text-[#666] font-bold uppercase tracking-wider">REAL GDP</div>
          <div className="text-xl font-mono font-bold text-[#4CAF50] mt-1">
            ${(metrics.gdp / 1000).toFixed(1)}k
          </div>
          <div className="text-[10px] font-mono text-[#555] mt-0.5">Annual Output</div>
        </div>

        <div id="card-cpi" className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] font-mono text-[#666] font-bold uppercase tracking-wider">CONSUMER CPI</div>
          <div className="text-xl font-mono font-bold text-[#FFC107] mt-1">
            {metrics.cpi.toFixed(1)}
          </div>
          <div className="text-[10px] font-mono text-[#555] mt-0.5">Base Index 100</div>
        </div>

        <div id="card-ppi" className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] font-mono text-[#666] font-bold uppercase tracking-wider">CAPITAL PPI</div>
          <div className="text-xl font-mono font-bold text-[#E64A19] mt-1">
            {metrics.ppiCapitalGoods.toFixed(1)}
          </div>
          <div className="text-[10px] font-mono text-[#555] mt-0.5">Stage 1-3 Input Index</div>
        </div>

        <div id="card-m2" className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] font-mono text-[#666] font-bold uppercase tracking-wider">MONEY M2</div>
          <div className="text-xl font-mono font-bold text-[#2196F3] mt-1">
            ${(metrics.moneySupplyM2 / 1000000).toFixed(2)}M
          </div>
          <div className="text-[10px] font-mono text-[#555] mt-0.5">Bank Credit + Base</div>
        </div>

        <div id="card-interest" className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] font-mono text-[#666] font-bold uppercase tracking-wider">MARKET RATE</div>
          <div className="text-xl font-mono font-bold text-white mt-1">
            {(metrics.interestRateMarket * 100).toFixed(2)}%
          </div>
          <div className="text-[10px] font-mono text-[#555] mt-0.5">Natural: {(metrics.interestRateOriginary * 100).toFixed(1)}%</div>
        </div>

        <div id="card-malinvestment" className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] font-mono text-[#666] font-bold uppercase tracking-wider">MALINVESTMENT</div>
          <div className={`text-xl font-mono font-bold mt-1 ${metrics.malinvestmentRatio > 0.15 ? 'text-[#F44336]' : 'text-[#4CAF50]'}`}>
            {(metrics.malinvestmentRatio * 100).toFixed(1)}%
          </div>
          <div className="text-[10px] font-mono text-[#555] mt-0.5">Distorted Capital</div>
        </div>

      </div>

      {/* Causal Diagnostics Engine */}
      <div id="causal-diagnostics-section" className="bg-[#0F0F12] border border-[#222] rounded-sm p-4">
        <div className="flex items-center gap-2 mb-3">
          <Activity className="w-4 h-4 text-[#E64A19]" />
          <h2 className="font-mono text-xs font-bold text-white uppercase tracking-wider">
            Austrian Causal Business Cycle Diagnostics
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {causalDiagnostics.map((node) => {
            let badgeBg = 'bg-[#16161A] text-[#D1D1D1] border-[#2A2A2E]';
            let icon = <CheckCircle2 className="w-4 h-4 text-[#4CAF50]" />;

            if (node.impactLevel === 'WARNING') {
              badgeBg = 'bg-[#16161A] text-[#FFC107] border-[#FFC107]/30';
              icon = <AlertTriangle className="w-4 h-4 text-[#FFC107]" />;
            } else if (node.impactLevel === 'CRITICAL') {
              badgeBg = 'bg-[#16161A] text-[#F44336] border-[#F44336]/30';
              icon = <AlertCircle className="w-4 h-4 text-[#F44336]" />;
            }

            return (
              <div key={node.id} className={`p-3 rounded-sm border ${badgeBg} space-y-1.5`}>
                <div className="flex items-center gap-2 font-mono text-xs font-bold">
                  {icon}
                  <span>{node.title}</span>
                </div>
                <p className="text-xs text-[#D1D1D1] font-sans leading-relaxed">
                  {node.description}
                </p>
                <div className="text-[10px] font-mono text-[#666] border-t border-[#222] pt-1.5 mt-1.5">
                  Cause: {node.triggerReason}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Charts Section */}
      <div id="charts-grid" className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Chart 1: Real GDP & Capital Stock */}
        <div id="chart-gdp-container" className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider">REAL OUTPUT & CAPITAL ACCUMULATION</h3>
            <span className="text-[10px] font-mono text-[#666]">TICK TIME-SERIES</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222226" />
                <XAxis dataKey="tick" stroke="#555" fontSize={11} fontStyle="monospace" />
                <YAxis stroke="#555" fontSize={11} fontStyle="monospace" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111114', borderColor: '#2A2A2E', color: '#FFFFFF' }}
                  labelStyle={{ color: '#888888' }}
                />
                <Area type="monotone" dataKey="gdp" name="Real GDP ($)" stroke="#4CAF50" fill="#4CAF50" fillOpacity={0.15} />
                <Area type="monotone" dataKey="totalCapitalStock" name="Capital Stock ($)" stroke="#E64A19" fill="#E64A19" fillOpacity={0.15} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Consumer CPI vs Capital PPI Divergence */}
        <div id="chart-inflation-container" className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider">CPI VS CAPITAL GOODS PPI DIVERGENCE</h3>
            <span className="text-[10px] font-mono text-[#666]">AUSTRIAN PRICE DISTORTION</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222226" />
                <XAxis dataKey="tick" stroke="#555" fontSize={11} fontStyle="monospace" />
                <YAxis stroke="#555" fontSize={11} fontStyle="monospace" domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111114', borderColor: '#2A2A2E', color: '#FFFFFF' }}
                />
                <Line type="monotone" dataKey="cpi" name="Consumer CPI" stroke="#FFC107" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="ppiCapitalGoods" name="Capital Goods PPI" stroke="#E64A19" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};

