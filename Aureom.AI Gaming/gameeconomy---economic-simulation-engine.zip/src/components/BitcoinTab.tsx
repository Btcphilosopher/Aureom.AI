import React from 'react';
import { BitcoinNetworkState } from '../engine/simulation';
import { Zap } from 'lucide-react';

interface BitcoinTabProps {
  btcNetwork: BitcoinNetworkState;
}

export const BitcoinTab: React.FC<BitcoinTabProps> = ({ btcNetwork }) => {
  const currentBtc = btcNetwork.currentSupplySats / 1e8;
  const maxBtc = btcNetwork.maxSupplySats / 1e8;
  const progressPct = ((currentBtc / maxBtc) * 100).toFixed(2);
  const blocksToHalving = btcNetwork.nextHalvingBlock - btcNetwork.blockHeight;

  return (
    <div id="bitcoin-tab" className="space-y-6">
      
      {/* Header Info */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#FF9800]" />
            <h2 className="font-mono text-xs font-bold text-white uppercase tracking-wider">
              BITCOIN PROTOCOL & MINING NETWORK ENGINE
            </h2>
          </div>
          <p className="text-xs text-[#D1D1D1] mt-1 max-w-2xl font-sans leading-relaxed">
            Protocol-defined 21,000,000 BTC hard cap with difficulty adjustment, halving block subsidy schedule, and ASIC capital expenditure economics.
          </p>
        </div>

        <div className="bg-[#16161A] border border-[#222] px-4 py-2.5 rounded-sm font-mono text-xs text-right">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">MARKET PRICE</div>
          <div className="text-[#FF9800] font-bold text-lg">${btcNetwork.marketPriceUSD.toLocaleString()}</div>
          <div className="text-[#555] text-[10px]">USD / BTC</div>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        
        <div className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">CIRCULATING SUPPLY</div>
          <div className="text-[#4CAF50] font-bold text-base mt-1">{currentBtc.toFixed(2)} BTC</div>
          <div className="text-[#555] text-[10px] mt-0.5">{progressPct}% of 21.0M Cap</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">BLOCK HEIGHT</div>
          <div className="text-[#E64A19] font-bold text-base mt-1">#{btcNetwork.blockHeight.toLocaleString()}</div>
          <div className="text-[#555] text-[10px] mt-0.5">Subsidy: {(btcNetwork.blockSubsidySats / 1e8).toFixed(3)} BTC</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">TOTAL HASHRATE</div>
          <div className="text-[#2196F3] font-bold text-base mt-1">{(btcNetwork.totalHashrateTH / 1e6).toFixed(1)} EH/s</div>
          <div className="text-[#555] text-[10px] mt-0.5">{btcNetwork.activeMiners} Mining Pools</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">NEXT HALVING</div>
          <div className="text-[#FFC107] font-bold text-base mt-1">{blocksToHalving.toLocaleString()} BLOCKS</div>
          <div className="text-[#555] text-[10px] mt-0.5">Target: Block 1,050,000</div>
        </div>

      </div>

      {/* Progress Bar for 21M Cap */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-2">
        <div className="flex justify-between font-mono text-xs">
          <span className="text-white font-bold text-[10px] uppercase tracking-wider">21,000,000 BTC HARD CAP ISSUANCE PROGRESS</span>
          <span className="text-[#FF9800] font-bold">{progressPct}% MINED</span>
        </div>
        <div className="w-full bg-[#16161A] h-3 rounded-sm overflow-hidden border border-[#222]">
          <div
            className="bg-[#E64A19] h-full transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

    </div>
  );
};

