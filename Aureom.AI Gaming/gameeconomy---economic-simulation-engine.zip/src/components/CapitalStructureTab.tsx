import React from 'react';
import { ProductionStage } from '../engine/simulation';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Cell } from 'recharts';
import { Layers, Clock } from 'lucide-react';

interface CapitalStructureTabProps {
  stages: ProductionStage[];
  interestRateMarket: number;
}

export const CapitalStructureTab: React.FC<CapitalStructureTabProps> = ({ stages, interestRateMarket }) => {
  // Elegant Dark palette for Hayekian capital stage levels
  const STAGE_COLORS = ['#E64A19', '#FF9800', '#2196F3', '#FFC107', '#4CAF50'];

  const totalCapital = stages.reduce((acc, s) => acc + s.capitalInvested, 0);

  return (
    <div id="capital-structure-tab" className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#E64A19]" />
            <h2 className="font-mono text-sm font-bold text-white uppercase tracking-wider">
              Hayekian Capital Structure & Production Stages
            </h2>
          </div>
          <p className="text-xs text-[#D1D1D1] mt-1 max-w-2xl font-sans leading-relaxed">
            In Austrian capital theory, production takes place through temporal stages. Lower interest rates elongate the structure by increasing capital allocation to early higher-order stages.
          </p>
        </div>

        <div className="bg-[#16161A] border border-[#222] px-4 py-2.5 rounded-sm font-mono text-xs space-y-1">
          <div className="text-[10px] text-[#666] font-bold uppercase tracking-wider">TOTAL CAPITAL STOCK</div>
          <div className="text-[#E64A19] font-bold text-lg">${(totalCapital / 1000000).toFixed(2)}M</div>
          <div className="text-[#555] text-[10px]">Market Interest Rate: {(interestRateMarket * 100).toFixed(2)}%</div>
        </div>
      </div>

      {/* Stage Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {stages.map((stage, idx) => {
          const sharePct = totalCapital > 0 ? ((stage.capitalInvested / totalCapital) * 100).toFixed(1) : '0.0';
          return (
            <div key={stage.stageNumber} className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm space-y-2 relative overflow-hidden">
              <div
                className="absolute top-0 left-0 right-0 h-1"
                style={{ backgroundColor: STAGE_COLORS[idx % STAGE_COLORS.length] }}
              />
              
              <div className="text-[10px] font-mono font-bold text-[#666] uppercase tracking-wider">
                {stage.name}
              </div>

              <div className="text-lg font-mono font-bold text-white mt-1">
                ${(stage.capitalInvested / 1000).toFixed(0)}k
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-[#888] border-t border-[#222] pt-2">
                <span>SHARE: {sharePct}%</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#555]" />
                  {stage.timeToConsumptionYears}y
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Production Stages Chart */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider">
            HAYEKIAN TRIANGLE - CAPITAL INVESTMENT BY STAGE
          </h3>
          <span className="text-[10px] font-mono text-[#666]">HIGHER ORDER (LEFT) TO RETAIL (RIGHT)</span>
        </div>

        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stages}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222226" />
              <XAxis dataKey="name" stroke="#555" fontSize={10} fontStyle="monospace" />
              <YAxis stroke="#555" fontSize={11} fontStyle="monospace" />
              <Tooltip
                contentStyle={{ backgroundColor: '#111114', borderColor: '#2A2A2E', color: '#FFFFFF' }}
                formatter={(val: any) => `$${Number(val).toLocaleString()}`}
              />
              <Bar dataKey="capitalInvested" name="Capital Invested ($)">
                {stages.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={STAGE_COLORS[index % STAGE_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};

