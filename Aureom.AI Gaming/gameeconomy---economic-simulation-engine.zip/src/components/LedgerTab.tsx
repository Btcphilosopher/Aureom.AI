import React from 'react';
import { LedgerEntry } from '../engine/simulation';
import { ShieldCheck } from 'lucide-react';

interface LedgerTabProps {
  entries: LedgerEntry[];
}

export const LedgerTab: React.FC<LedgerTabProps> = ({ entries }) => {
  return (
    <div id="ledger-tab" className="space-y-6">
      
      {/* Header Audit status */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-sm bg-[#16161A] border border-[#4CAF50]/30 flex items-center justify-center text-[#4CAF50]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-mono text-xs font-bold text-white flex items-center gap-2 uppercase tracking-wider">
              <span>DOUBLE-ENTRY AUDITABLE LEDGER</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#16161A] text-[#4CAF50] border border-[#4CAF50]/30 font-bold">
                INVARIANTS: VERIFIED PASS
              </span>
            </h2>
            <p className="text-xs text-[#D1D1D1] mt-0.5 font-sans">
              Strict accounting invariants enforced: Assets = Liabilities + Equity across all agents & monetary transactions.
            </p>
          </div>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-[#0F0F12] border border-[#222] rounded-sm overflow-hidden">
        <div className="p-3 border-b border-[#222] font-mono text-xs font-bold text-white flex justify-between items-center uppercase tracking-wider">
          <span>RECENT DOUBLE-ENTRY TRANSACTIONS</span>
          <span className="text-[#666] text-[10px]">{entries.length} LOGGED ENTRIES</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-[#D1D1D1]">
            <thead className="bg-[#16161A] text-[#666] border-b border-[#222] text-[10px] font-bold uppercase tracking-wider">
              <tr>
                <th className="p-2.5">ENTRY ID</th>
                <th className="p-2.5">TICK</th>
                <th className="p-2.5">DEBIT ACCOUNT</th>
                <th className="p-2.5">CREDIT ACCOUNT</th>
                <th className="p-2.5 text-right">AMOUNT ($)</th>
                <th className="p-2.5">MEMO</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#222] bg-[#0F0F12]">
              {entries.slice(-12).reverse().map((entry) => (
                <tr key={entry.id} className="hover:bg-[#1A1A1E] transition-colors">
                  <td className="p-2.5 text-[#E64A19] font-bold">{entry.id}</td>
                  <td className="p-2.5 text-[#4CAF50] font-bold">{entry.tick}</td>
                  <td className="p-2.5 text-white">{entry.debitAccount}</td>
                  <td className="p-2.5 text-white">{entry.creditAccount}</td>
                  <td className="p-2.5 text-right font-bold text-white">${entry.amount.toFixed(2)}</td>
                  <td className="p-2.5 text-[#888] truncate max-w-xs">{entry.memo}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

