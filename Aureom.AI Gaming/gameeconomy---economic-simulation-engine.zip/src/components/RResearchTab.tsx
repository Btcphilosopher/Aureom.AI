import React, { useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Terminal, Play, BarChart3 } from 'lucide-react';

export const RResearchTab: React.FC = () => {
  const [selectedScript, setSelectedScript] = useState<string>('economics/preferences.R');
  const [consoleOutput, setConsoleOutput] = useState<string>(
    `[R Console Initialized v4.3.2]\n> library(GameEconomy)\n> library(ggplot2)\n[Ready to execute econometric script]`
  );
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [monteCarloData, setMonteCarloData] = useState<any[]>([]);

  const rScripts = [
    { path: 'economics/preferences.R', name: 'Preferences & Subjective Utility Fitting' },
    { path: 'economics/capital.R', name: 'Capital Structure & Hayekian Ratios' },
    { path: 'monetary/bitcoin.R', name: 'Bitcoin Stock-to-Flow Model' },
    { path: 'research/monte_carlo.R', name: 'Monte Carlo P10/P50/P90 Fan Charts' },
  ];

  const handleRunScript = async () => {
    setIsExecuting(true);
    setConsoleOutput((prev) => `${prev}\n\n> source("R/${selectedScript}")\nRunning econometric models...`);

    try {
      const res = await fetch('/api/research/r-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scriptName: selectedScript }),
      });
      const data = await res.json();
      setConsoleOutput((prev) => `${prev}\n${data.outputConsole}`);

      // If Monte Carlo, fetch MC fan chart data
      if (selectedScript.includes('monte_carlo')) {
        const mcRes = await fetch('/api/research/monte-carlo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ simulations: 100, duration: 25 }),
        });
        const mcData = await mcRes.json();
        setMonteCarloData(mcData.percentiles);
      }
    } catch (err: any) {
      setConsoleOutput((prev) => `${prev}\n[ERROR]: ${err.message}`);
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div id="r-research-tab" className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-[#0F0F12] border border-[#222] p-4 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[#2196F3]" />
            <h2 className="font-mono text-xs font-bold text-white uppercase tracking-wider">
              R RESEARCH LABORATORY & ECONOMETRIC ENVIRONMENT
            </h2>
          </div>
          <p className="text-xs text-[#D1D1D1] mt-1 max-w-2xl font-sans leading-relaxed">
            Statistical calibration, Monte Carlo confidence intervals, preference parameter estimation, and time-series econometrics in R.
          </p>
        </div>

        <button
          onClick={handleRunScript}
          disabled={isExecuting}
          className="bg-[#E64A19] hover:bg-[#FF5722] text-black font-mono text-xs font-bold px-4 py-2 rounded-sm flex items-center gap-2 transition-colors self-start md:self-auto uppercase tracking-wider"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          {isExecuting ? 'EXECUTING R...' : 'RUN R SCRIPT'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Left Column: Script Selection & R Console */}
        <div className="space-y-4">
          
          <div className="bg-[#0F0F12] border border-[#222] p-3 rounded-sm space-y-2">
            <label className="text-[10px] font-mono font-bold text-[#666] uppercase tracking-wider block">SELECT R RESEARCH SCRIPT:</label>
            <select
              value={selectedScript}
              onChange={(e) => setSelectedScript(e.target.value)}
              className="w-full bg-[#16161A] border border-[#2A2A2E] text-white font-mono text-xs rounded-sm px-2.5 py-2 focus:outline-none focus:border-[#E64A19] transition-colors"
            >
              {rScripts.map((s) => (
                <option key={s.path} value={s.path}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="bg-[#16161A] border border-[#222] p-3 rounded-sm font-mono text-xs text-[#D1D1D1] h-64 overflow-y-auto space-y-1">
            <div className="text-[#666] border-b border-[#222] pb-1 mb-2 font-bold text-[10px] uppercase tracking-wider flex justify-between">
              <span>R STDOUT / CONSOLE LOG</span>
              <span className="text-[#2196F3]">R 4.3.2</span>
            </div>
            <pre className="whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-[#D1D1D1]">{consoleOutput}</pre>
          </div>

        </div>

        {/* Right Column: Monte Carlo Fan Chart output */}
        <div className="lg:col-span-2 bg-[#0F0F12] border border-[#222] p-4 rounded-sm space-y-3">
          <div className="flex items-center justify-between border-b border-[#222] pb-2">
            <h3 className="font-mono text-xs font-bold text-white uppercase tracking-wider">
              MONTE CARLO SIMULATION FAN CHART (P10 - P50 - P90)
            </h3>
            <span className="text-[10px] font-mono text-[#666]">100 SIMULATED GDP PATHS</span>
          </div>

          <div className="h-72">
            {monteCarloData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monteCarloData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222226" />
                  <XAxis dataKey="step" stroke="#555" fontSize={11} fontStyle="monospace" />
                  <YAxis stroke="#555" fontSize={11} fontStyle="monospace" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#111114', borderColor: '#2A2A2E', color: '#FFFFFF' }}
                  />
                  <Area type="monotone" dataKey="p90" name="P90 Optimistic" stroke="#2196F3" fill="#2196F3" fillOpacity={0.15} />
                  <Area type="monotone" dataKey="p50" name="P50 Median GDP" stroke="#4CAF50" fill="#4CAF50" fillOpacity={0.25} />
                  <Area type="monotone" dataKey="p10" name="P10 Stress Scenario" stroke="#F44336" fill="#F44336" fillOpacity={0.1} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-[#666] font-mono text-xs space-y-2">
                <BarChart3 className="w-8 h-8 text-[#555]" />
                <p>Run <span className="text-[#E64A19]">research/monte_carlo.R</span> to generate Monte Carlo percentile bands.</p>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};

