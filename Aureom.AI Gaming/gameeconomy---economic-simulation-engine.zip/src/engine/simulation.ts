export interface Agent {
  id: string;
  name: string;
  type: 'Household' | 'Entrepreneur' | 'CommercialBank' | 'CentralBank' | 'BitcoinMiner';
  timePreference: number; // discount rate, e.g. 0.02 - 0.15
  riskTolerance: number;
  fiatBalance: number;
  btcBalance: number;
  capitalValue: number;
}

export interface LedgerEntry {
  id: string;
  tick: number;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  currency: string;
  memo: string;
  timestamp: string;
}

export interface LimitOrder {
  orderId: string;
  agentId: string;
  price: number;
  quantity: number;
  isBuy: boolean;
  timestamp: string;
}

export interface ProductionStage {
  stageNumber: number;
  name: string;
  capitalInvested: number;
  laborHours: number;
  timeToConsumptionYears: number;
  profitabilityPct: number;
}

export interface BitcoinNetworkState {
  maxSupplySats: number;
  currentSupplySats: number;
  blockHeight: number;
  blockSubsidySats: number;
  totalHashrateTH: number;
  difficulty: number;
  marketPriceUSD: number;
  nextHalvingBlock: number;
  activeMiners: number;
}

export interface EconomicMetrics {
  tick: number;
  gdp: number;
  cpi: number;
  ppiCapitalGoods: number;
  moneySupplyM0: number;
  moneySupplyM2: number;
  bankReserveRatio: number;
  avgTimePreference: number;
  interestRateOriginary: number;
  interestRateMarket: number;
  btcPriceUSD: number;
  btcHashrateTH: number;
  malinvestmentRatio: number;
  unemploymentRate: number;
  totalCapitalStock: number;
}

export interface CausalDiagnosticNode {
  id: string;
  title: string;
  description: string;
  impactLevel: 'INFO' | 'WARNING' | 'CRITICAL' | 'RECOVERY';
  triggerReason: string;
}

export type ScenarioPreset = 
  | 'BITCOIN_STANDARD'
  | 'EASY_CREDIT_BOOM_BUST'
  | 'RESOURCE_SCARCITY'
  | 'TECH_DEFLATION_BOOM'
  | 'FREE_BANKING_SOUND_MONEY';

export class EconomicEngine {
  public tick: number = 0;
  public activeScenario: ScenarioPreset = 'BITCOIN_STANDARD';
  public agents: Agent[] = [];
  public ledger: LedgerEntry[] = [];
  public bids: LimitOrder[] = [];
  public asks: LimitOrder[] = [];
  public lastTradedPrice: number = 148.50;
  public totalVolume24h: number = 52400;
  public btcNetwork: BitcoinNetworkState;
  public stages: ProductionStage[] = [];
  public history: EconomicMetrics[] = [];
  public causalNodeTrace: CausalDiagnosticNode[] = [];

  constructor() {
    this.btcNetwork = {
      maxSupplySats: 21_000_000_0000_0000,
      currentSupplySats: 19_750_000_0000_0000,
      blockHeight: 852_410,
      blockSubsidySats: 312500000, // 3.125 BTC
      totalHashrateTH: 680_000_000,
      difficulty: 89_200_000_000_000,
      marketPriceUSD: 68_450.00,
      nextHalvingBlock: 1_050_000,
      activeMiners: 1420,
    };

    this.resetScenario('BITCOIN_STANDARD');
  }

  public resetScenario(preset: ScenarioPreset) {
    this.activeScenario = preset;
    this.tick = 0;
    this.agents = [];
    this.ledger = [];
    this.history = [];
    this.causalNodeTrace = [];

    // Create agents
    for (let i = 1; i <= 50; i++) {
      if (i % 6 === 0) {
        this.agents.push({
          id: `ENT_${i}`,
          name: `Venture Capital Firm ${i}`,
          type: 'Entrepreneur',
          timePreference: preset === 'EASY_CREDIT_BOOM_BUST' ? 0.02 : 0.04,
          riskTolerance: 0.80,
          fiatBalance: 250000 + i * 10000,
          btcBalance: 5.2 + i * 0.5,
          capitalValue: 800000,
        });
      } else if (i % 15 === 0) {
        this.agents.push({
          id: `BANK_${i}`,
          name: `First Reserve Bank ${i}`,
          type: 'CommercialBank',
          timePreference: 0.03,
          riskTolerance: 0.40,
          fiatBalance: 1200000,
          btcBalance: 45.0,
          capitalValue: 2000000,
        });
      } else if (i % 10 === 0) {
        this.agents.push({
          id: `MINER_${i}`,
          name: `Antminer Pool ${i}`,
          type: 'BitcoinMiner',
          timePreference: 0.05,
          riskTolerance: 0.70,
          fiatBalance: 85000,
          btcBalance: 18.4,
          capitalValue: 350000,
        });
      } else {
        this.agents.push({
          id: `HH_${i}`,
          name: `Household Citizen ${i}`,
          type: 'Household',
          timePreference: preset === 'EASY_CREDIT_BOOM_BUST' ? 0.08 : 0.05,
          riskTolerance: 0.35,
          fiatBalance: 15000 + (i * 1200),
          btcBalance: 0.25 + (i * 0.05),
          capitalValue: 45000,
        });
      }
    }

    // Capital Stages
    this.stages = [
      { stageNumber: 1, name: "1. Raw Materials & Energy", capitalInvested: 2400000, laborHours: 65000, timeToConsumptionYears: 5.0, profitabilityPct: 8.2 },
      { stageNumber: 2, name: "2. Capital Equipment & Robotics", capitalInvested: 3100000, laborHours: 82000, timeToConsumptionYears: 3.5, profitabilityPct: 9.5 },
      { stageNumber: 3, name: "3. Logistics & Heavy Industry", capitalInvested: 2200000, laborHours: 54000, timeToConsumptionYears: 2.0, profitabilityPct: 7.1 },
      { stageNumber: 4, name: "4. Wholesale & Commercial Distribution", capitalInvested: 1500000, laborHours: 38000, timeToConsumptionYears: 0.8, profitabilityPct: 6.4 },
      { stageNumber: 5, name: "5. Retail Goods & Services", capitalInvested: 1100000, laborHours: 29000, timeToConsumptionYears: 0.1, profitabilityPct: 5.8 },
    ];

    // Seed Order Book
    this.seedOrderBook();

    // Generate initial metric point
    this.stepTick(0);
  }

  private seedOrderBook() {
    this.bids = [];
    this.asks = [];
    const base = this.lastTradedPrice;

    for (let i = 1; i <= 6; i++) {
      this.bids.push({
        orderId: `bid_${i}_${Date.now()}`,
        agentId: `HH_${i}`,
        price: +(base - i * 1.2).toFixed(2),
        quantity: +(15 + i * 5).toFixed(1),
        isBuy: true,
        timestamp: new Date().toISOString(),
      });
      this.asks.push({
        orderId: `ask_${i}_${Date.now()}`,
        agentId: `ENT_${i}`,
        price: +(base + i * 1.25).toFixed(2),
        quantity: +(12 + i * 4).toFixed(1),
        isBuy: false,
        timestamp: new Date().toISOString(),
      });
    }
  }

  public stepTick(stepCount: number = 1) {
    for (let s = 0; s < Math.max(1, stepCount); s++) {
      this.tick += 1;

      // Scenario dynamic behaviors
      let creditMult = 1.0;
      let inflationRate = 0.002;
      let interestTarget = 0.045;

      if (this.activeScenario === 'EASY_CREDIT_BOOM_BUST') {
        if (this.tick < 20) {
          creditMult = 1.0 + (this.tick * 0.08);
          interestTarget = 0.015; // artificially low rate
          inflationRate = 0.008;
        } else if (this.tick < 35) {
          // Bottlenecks & cost surges
          interestTarget = 0.065;
          inflationRate = 0.022;
        } else {
          // Liquidation / Bust
          creditMult = 0.6;
          interestTarget = 0.055;
          inflationRate = -0.005;
        }
      } else if (this.activeScenario === 'BITCOIN_STANDARD') {
        interestTarget = 0.038;
        inflationRate = -0.001; // gentle deflationary productivity
      } else if (this.activeScenario === 'TECH_DEFLATION_BOOM') {
        inflationRate = -0.004;
        interestTarget = 0.032;
      }

      // Update Bitcoin Network
      if (this.tick % 5 === 0) {
        this.btcNetwork.blockHeight += 1;
        this.btcNetwork.currentSupplySats += this.btcNetwork.blockSubsidySats;
        this.btcNetwork.totalHashrateTH += 150000 + (Math.random() * 50000 - 20000);
        
        const priceShift = (Math.sin(this.tick * 0.2) * 450) + (Math.random() * 200 - 100);
        this.btcNetwork.marketPriceUSD = +(this.btcNetwork.marketPriceUSD + priceShift).toFixed(2);
      }

      // Update Order Book prices
      this.lastTradedPrice = +(this.lastTradedPrice + (Math.random() * 0.8 - 0.39)).toFixed(2);
      this.totalVolume24h += Math.floor(Math.random() * 120 + 50);

      // Shift Capital Stages based on interest rates
      const rateDelta = 0.05 - interestTarget;
      this.stages[0].capitalInvested = Math.max(500000, +(this.stages[0].capitalInvested * (1 + rateDelta * 0.15)).toFixed(0));
      this.stages[1].capitalInvested = Math.max(600000, +(this.stages[1].capitalInvested * (1 + rateDelta * 0.12)).toFixed(0));
      this.stages[4].capitalInvested = Math.max(400000, +(this.stages[4].capitalInvested * (1 - rateDelta * 0.08)).toFixed(0));

      // Calculate Macro Metrics
      const lastMetric = this.history[this.history.length - 1];
      const prevGdp = lastMetric ? lastMetric.gdp : 1500000;
      const prevCpi = lastMetric ? lastMetric.cpi : 100.0;
      const prevPpi = lastMetric ? lastMetric.ppiCapitalGoods : 100.0;
      const prevM2 = lastMetric ? lastMetric.moneySupplyM2 : 2400000;

      const newGdp = +(prevGdp * (1 + (this.activeScenario === 'TECH_DEFLATION_BOOM' ? 0.008 : 0.004))).toFixed(2);
      const newCpi = +(prevCpi * (1 + inflationRate)).toFixed(2);
      const newPpi = +(prevPpi * (1 + inflationRate * 1.5)).toFixed(2);
      const newM2 = +(prevM2 * creditMult).toFixed(2);

      const malinvestment = +(
        this.activeScenario === 'EASY_CREDIT_BOOM_BUST' && this.tick >= 20
          ? Math.min(0.35, 0.05 + (this.tick - 15) * 0.015)
          : 0.04
      ).toFixed(3);

      const metrics: EconomicMetrics = {
        tick: this.tick,
        gdp: newGdp,
        cpi: newCpi,
        ppiCapitalGoods: newPpi,
        moneySupplyM0: 850000,
        moneySupplyM2: newM2,
        bankReserveRatio: 0.12,
        avgTimePreference: 0.048,
        interestRateOriginary: 0.042,
        interestRateMarket: interestTarget,
        btcPriceUSD: this.btcNetwork.marketPriceUSD,
        btcHashrateTH: this.btcNetwork.totalHashrateTH,
        malinvestmentRatio: malinvestment,
        unemploymentRate: +(0.04 + (malinvestment * 0.2)).toFixed(3),
        totalCapitalStock: +(this.stages.reduce((acc, s) => acc + s.capitalInvested, 0)).toFixed(2),
      };

      this.history.push(metrics);

      // Record double entry log
      this.ledger.push({
        id: `LEDGER_${this.tick}_${Math.floor(Math.random() * 1000)}`,
        tick: this.tick,
        debitAccount: `AGENT_ENT_1_CAPITAL`,
        creditAccount: `AGENT_BANK_1_LOANS`,
        amount: +(Math.random() * 25000 + 5000).toFixed(2),
        currency: 'USD',
        memo: `Capital Investment Loan Issuance - Stage ${Math.floor(Math.random() * 3) + 1}`,
        timestamp: new Date().toISOString(),
      });

      // Update Causal Diagnostic Nodes
      this.updateCausalDiagnostics();
    }
  }

  private updateCausalDiagnostics() {
    this.causalNodeTrace = [];

    if (this.activeScenario === 'EASY_CREDIT_BOOM_BUST') {
      if (this.tick >= 1 && this.tick < 15) {
        this.causalNodeTrace.push({
          id: 'node_1',
          title: 'Artificial Credit Expansion',
          description: 'Central rate suppressed below natural originary time preference. Money supply M2 grows rapidly.',
          impactLevel: 'INFO',
          triggerReason: 'Interest rate set at 1.5% vs 4.2% natural time preference',
        });
      }
      if (this.tick >= 15 && this.tick < 28) {
        this.causalNodeTrace.push({
          id: 'node_2',
          title: 'Stage 1-2 Capital Over-Investment',
          description: 'Entrepreneurs overestimate profitability of long-duration capital projects due to cheap credit signals.',
          impactLevel: 'WARNING',
          triggerReason: 'Capital goods PPI surging faster than consumer CPI',
        });
      }
      if (this.tick >= 28) {
        this.causalNodeTrace.push({
          id: 'node_3',
          title: 'Resource Bottlenecks & Liquidation Bust',
          description: 'Shortage of real physical savings causes input costs to rise. Unprofitable malinvested capital must be liquidated.',
          impactLevel: 'CRITICAL',
          triggerReason: 'Malinvestment ratio hit peak 35%, rate hike forces project defaults',
        });
      }
    } else if (this.activeScenario === 'BITCOIN_STANDARD') {
      this.causalNodeTrace.push({
        id: 'node_btc_1',
        title: 'Hard-Money Price Stability',
        description: 'Fixed 21M BTC issuance prevents monetary dilutive distortion. Capital allocation reflects genuine time preferences.',
        impactLevel: 'INFO',
        triggerReason: 'Zero unbacked credit creation; prices naturally align with productivity gains',
      });
    } else {
      this.causalNodeTrace.push({
        id: 'node_gen_1',
        title: 'Steady-State Market Coordination',
        description: 'Decentralized price signals guide capital allocation across production stages efficiently.',
        impactLevel: 'INFO',
        triggerReason: 'Supply and demand order books clearing with stable interest rates',
      });
    }
  }

  public placeOrder(agentId: string, price: number, quantity: number, isBuy: boolean): LimitOrder {
    const order: LimitOrder = {
      orderId: `order_${Date.now()}`,
      agentId,
      price: +price.toFixed(2),
      quantity: +quantity.toFixed(2),
      isBuy,
      timestamp: new Date().toISOString(),
    };

    if (isBuy) {
      this.bids.push(order);
      this.bids.sort((a, b) => b.price - a.price);
    } else {
      this.asks.push(order);
      this.asks.sort((a, b) => a.price - b.price);
    }

    // Try match top
    if (this.bids.length > 0 && this.asks.length > 0) {
      if (this.bids[0].price >= this.asks[0].price) {
        const tradePrice = this.asks[0].price;
        this.lastTradedPrice = tradePrice;
        this.bids.shift();
        this.asks.shift();
      }
    }

    return order;
  }

  public runMonteCarlo(simulations: number = 50, durationTicks: number = 30) {
    const results: number[][] = [];
    
    for (let sim = 0; sim < simulations; sim++) {
      let gdp = this.history[this.history.length - 1]?.gdp || 1500000;
      const simPath: number[] = [gdp];

      for (let t = 0; t < durationTicks; t++) {
        const shock = (Math.random() - 0.48) * 0.02; // slight upward drift
        gdp = +(gdp * (1 + shock)).toFixed(2);
        simPath.push(gdp);
      }
      results.push(simPath);
    }

    // Calculate percentiles per tick step
    const summary = [];
    for (let step = 0; step <= durationTicks; step++) {
      const values = results.map(r => r[step]).sort((a, b) => a - b);
      const p10 = values[Math.floor(values.length * 0.10)];
      const p50 = values[Math.floor(values.length * 0.50)];
      const p90 = values[Math.floor(values.length * 0.90)];
      summary.push({ step, p10, p50, p90 });
    }

    return summary;
  }
}
