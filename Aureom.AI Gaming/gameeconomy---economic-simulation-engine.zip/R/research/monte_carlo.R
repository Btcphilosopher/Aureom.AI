# GameEconomy R Research - Monte Carlo Simulation & Percentile Confidence Bands

run_monte_carlo_analysis <- function(sim_matrix, confidence_level = 0.90) {
  p10 <- apply(sim_matrix, 1, quantile, probs = 0.10)
  p50 <- apply(sim_matrix, 1, quantile, probs = 0.50)
  p90 <- apply(sim_matrix, 1, quantile, probs = 0.90)
  
  return(data.frame(Tick = 1:length(p50), P10 = p10, P50 = p50, P90 = p90))
}
