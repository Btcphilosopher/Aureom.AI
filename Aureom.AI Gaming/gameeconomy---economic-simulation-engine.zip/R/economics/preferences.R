# GameEconomy R Research Laboratory - Subjective Value & Preferences
# Fits agent utility functions: U(c, l, k) = c^alpha * l^beta * k^gamma

library(ggplot2)
library(dplyr)

estimate_preference_distribution <- function(agent_data) {
  cat("Estimating Subjective Value Parameters across Agents...\n")
  alpha_mean <- mean(agent_data$time_preference)
  cat(sprintf("Average Time Preference (Discount Rate): %.4f\n", alpha_mean))
  return(alpha_mean)
}

plot_time_preference_cdf <- function(agent_data) {
  ggplot(agent_data, aes(x = time_preference)) +
    stat_ecdf(geom = "step", color = "#00F0FF", size = 1.2) +
    theme_minimal() +
    labs(title = "Cumulative Distribution of Time Preferences",
         x = "Time Preference Rate (Discount Factor)",
         y = "Cumulative Probability")
}
