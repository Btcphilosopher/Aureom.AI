# GameEconomy R Research - Capital Structure & Heterogeneous Capital Accumulation

library(dplyr)

analyse_capital_structure <- function(stages_df) {
  cat("Calculating Hayekian Triangle Capital Intensity...\n")
  total_k <- sum(stages_df$capital_invested)
  stage_ratios <- stages_df$capital_invested / total_k
  
  cat(sprintf("Total Real Capital Stock: $%.2f\n", total_k))
  cat(sprintf("Higher-Order Capital Ratio (Stages 1-3): %.2f%%\n", sum(stage_ratios[1:3]) * 100))
  cat(sprintf("Lower-Order Consumer Stage Ratio (Stages 4-5): %.2f%%\n", sum(stage_ratios[4:5]) * 100))
  
  return(list(total_k = total_k, ratios = stage_ratios))
}
