# GameEconomy R Research - Bitcoin Mining Economics & Stock-to-Flow Model

calculate_s2f_ratio <- function(current_supply_sats, annual_issuance_sats) {
  s2f <- (current_supply_sats / 1e8) / (annual_issuance_sats / 1e8)
  cat(sprintf("Current Bitcoin Stock-to-Flow Ratio: %.2f\n", s2f))
  return(s2f)
}

plot_halving_issuance_curve <- function() {
  blocks <- seq(0, 1500000, by = 21000)
  subsidies <- 50 / (2 ^ (blocks %/% 210000))
  
  df <- data.frame(Block = blocks, Subsidy = subsidies)
  return(df)
}
