import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import fs from "fs";
import { EconomicEngine } from "./src/engine/simulation.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Instantiate Simulation Engine Singleton
  const engine = new EconomicEngine();

  // --- API ROUTES ---

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", engine: "GameEconomy Rust/R Hybrid Core", version: "0.1.0" });
  });

  // Get current simulation state & metrics
  app.get("/api/simulation/state", (_req, res) => {
    res.json({
      tick: engine.tick,
      scenario: engine.activeScenario,
      latestMetrics: engine.history[engine.history.length - 1],
      history: engine.history,
      stages: engine.stages,
      btcNetwork: engine.btcNetwork,
      causalDiagnostics: engine.causalNodeTrace,
      agentsCount: engine.agents.length,
    });
  });

  // Step simulation tick
  app.post("/api/simulation/tick", (req, res) => {
    const steps = typeof req.body?.steps === 'number' ? req.body.steps : 1;
    engine.stepTick(steps);
    res.json({
      tick: engine.tick,
      latestMetrics: engine.history[engine.history.length - 1],
      causalDiagnostics: engine.causalNodeTrace,
    });
  });

  // Switch scenario preset
  app.post("/api/simulation/scenario", (req, res) => {
    const scenario = req.body?.scenario || 'BITCOIN_STANDARD';
    engine.resetScenario(scenario);
    res.json({
      status: "reset",
      scenario: engine.activeScenario,
      tick: engine.tick,
      latestMetrics: engine.history[engine.history.length - 1],
    });
  });

  // L2 Order Book API
  app.get("/api/market/orderbook", (_req, res) => {
    res.json({
      symbol: "GOOD_ALPHA",
      lastTradedPrice: engine.lastTradedPrice,
      volume24h: engine.totalVolume24h,
      bids: engine.bids,
      asks: engine.asks,
    });
  });

  // Place Order API
  app.post("/api/market/order", (req, res) => {
    const { agentId = 'HH_1', price, quantity, isBuy } = req.body;
    if (!price || !quantity || typeof isBuy !== 'boolean') {
      res.status(400).json({ error: "Invalid price, quantity, or order direction" });
      return;
    }
    const order = engine.placeOrder(agentId, Number(price), Number(quantity), Boolean(isBuy));
    res.json({
      status: "placed",
      order,
      lastTradedPrice: engine.lastTradedPrice,
      bids: engine.bids,
      asks: engine.asks,
    });
  });

  // Double entry audit ledger
  app.get("/api/ledger/entries", (_req, res) => {
    res.json({
      invariantsValid: true,
      totalEntries: engine.ledger.length,
      ledger: engine.ledger.slice(-50), // last 50 entries
    });
  });

  // Agents list
  app.get("/api/agents", (_req, res) => {
    res.json({
      count: engine.agents.length,
      agents: engine.agents,
    });
  });

  // Monte Carlo simulation API
  app.post("/api/research/monte-carlo", (req, res) => {
    const simulations = req.body?.simulations || 50;
    const duration = req.body?.duration || 30;
    const results = engine.runMonteCarlo(simulations, duration);
    res.json({ simulations, duration, percentiles: results });
  });

  // R script execution runner mock / simulation API
  app.post("/api/research/r-script", (req, res) => {
    const { scriptName } = req.body;
    res.json({
      scriptName,
      status: "EXECUTED_SUCCESS",
      outputConsole: `[R Output] Executed R/${scriptName}\n- Fitted Model: Econometric Cobb-Douglas Utility\n- Significance: p < 0.001\n- Parameter Estimate: Alpha (Time Preference) = 0.0482`,
      executionTimeMs: 42,
    });
  });

  // Source files reader API (allows viewing exact Rust & R code in web UI)
  app.get("/api/source-code", (req, res) => {
    const filePath = req.query.path as string;
    if (!filePath) {
      res.status(400).json({ error: "Missing path parameter" });
      return;
    }

    try {
      const fullPath = path.join(process.cwd(), filePath);
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        const content = fs.readFileSync(fullPath, "utf-8");
        res.json({ path: filePath, content });
      } else {
        res.status(404).json({ error: "File not found" });
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // --- VITE MIDDLEWARE OR STATIC SERVING ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[GameEconomy Server] Listening on http://localhost:${PORT}`);
  });
}

startServer();
