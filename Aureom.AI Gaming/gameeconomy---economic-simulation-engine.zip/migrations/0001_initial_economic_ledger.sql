-- GameEconomy Authoritative Economic Ledger Schema
-- PostgreSQL Migration Version 0001

CREATE TABLE IF NOT EXISTS agents (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    agent_type VARCHAR(32) NOT NULL,
    time_preference NUMERIC(10, 6) NOT NULL DEFAULT 0.05,
    risk_tolerance NUMERIC(10, 6) NOT NULL DEFAULT 0.50,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS double_entry_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tick BIGINT NOT NULL,
    debit_account VARCHAR(64) NOT NULL,
    credit_account VARCHAR(64) NOT NULL,
    amount NUMERIC(18, 4) NOT NULL,
    currency VARCHAR(16) NOT NULL DEFAULT 'USD',
    memo TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS capital_goods (
    id VARCHAR(64) PRIMARY KEY,
    owner_agent_id VARCHAR(64) REFERENCES agents(id),
    name VARCHAR(255) NOT NULL,
    purchase_price NUMERIC(18, 4) NOT NULL,
    productive_capacity NUMERIC(18, 4) NOT NULL,
    current_stage INT NOT NULL DEFAULT 1,
    depreciation_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.05
);

CREATE TABLE IF NOT EXISTS order_book_trades (
    trade_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tick BIGINT NOT NULL,
    symbol VARCHAR(32) NOT NULL,
    buyer_id VARCHAR(64) REFERENCES agents(id),
    seller_id VARCHAR(64) REFERENCES agents(id),
    price NUMERIC(18, 4) NOT NULL,
    quantity NUMERIC(18, 4) NOT NULL,
    executed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bitcoin_blocks (
    height BIGINT PRIMARY KEY,
    miner_agent_id VARCHAR(64) REFERENCES agents(id),
    subsidy_sats BIGINT NOT NULL,
    fees_sats BIGINT NOT NULL,
    hashrate_th NUMERIC(18, 2) NOT NULL,
    difficulty NUMERIC(24, 2) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS economic_metrics (
    tick BIGINT PRIMARY KEY,
    gdp NUMERIC(18, 2) NOT NULL,
    cpi NUMERIC(10, 4) NOT NULL,
    ppi_capital_goods NUMERIC(10, 4) NOT NULL,
    money_supply_m0 NUMERIC(18, 2) NOT NULL,
    money_supply_m2 NUMERIC(18, 2) NOT NULL,
    interest_rate_market NUMERIC(8, 6) NOT NULL,
    malinvestment_ratio NUMERIC(6, 4) NOT NULL,
    btc_price_usd NUMERIC(18, 2) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
