pub mod structure;

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapitalGood {
    pub id: String,
    pub name: String,
    pub purchase_price: f64,
    pub productive_capacity: f64,
    pub useful_life_years: f64,
    pub annual_depreciation_rate: f64,
    pub current_stage: u8,
}
