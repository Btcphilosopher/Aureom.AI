use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductionStage {
    pub stage_number: u8,
    pub name: String,
    pub capital_invested: f64,
    pub labor_hours: f64,
    pub time_to_consumption_years: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapitalStructure {
    pub stages: Vec<ProductionStage>,
}

impl CapitalStructure {
    pub fn new() -> Self {
        Self {
            stages: vec![
                ProductionStage { stage_number: 1, name: "Raw Material Extraction".into(), capital_invested: 1_200_000.0, labor_hours: 50_000.0, time_to_consumption_years: 5.0 },
                ProductionStage { stage_number: 2, name: "Capital Goods & Machinery".into(), capital_invested: 1_800_000.0, labor_hours: 65_000.0, time_to_consumption_years: 3.5 },
                ProductionStage { stage_number: 3, name: "Heavy Processing & Logistics".into(), capital_invested: 1_400_000.0, labor_hours: 45_000.0, time_to_consumption_years: 2.0 },
                ProductionStage { stage_number: 4, name: "Wholesale & Distribution".into(), capital_invested: 900_000.0, labor_hours: 30_000.0, time_to_consumption_years: 0.8 },
                ProductionStage { stage_number: 5, name: "Retail & Consumer Goods".into(), capital_invested: 700_000.0, labor_hours: 25_000.0, time_to_consumption_years: 0.1 },
            ],
        }
    }

    pub fn update_stage_allocations(&mut self, interest_rate: f64) {
        // Lower interest rates elongate structure (increase early stages capital)
        let rate_factor = (0.10 - interest_rate).max(-0.05);
        if let Some(early_stage) = self.stages.get_mut(0) {
            early_stage.capital_invested += early_stage.capital_invested * rate_factor * 0.1;
        }
    }
}
