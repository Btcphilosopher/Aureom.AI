//! GameEconomy Simulation Engine Core Library
//! High-performance, double-entry invariant, agent-based Austrian economic model.

pub mod core;
pub mod accounting;
pub mod subjective_value;
pub mod time_preference;
pub mod goods;
pub mod capital;
pub mod entrepreneurship;
pub mod markets;
pub mod banking;
pub mod monetary;
pub mod cycles;
pub mod policy;
pub mod analytics;
pub mod api;

pub use core::economic_state::EconomicState;
pub use core::agent::Agent;
