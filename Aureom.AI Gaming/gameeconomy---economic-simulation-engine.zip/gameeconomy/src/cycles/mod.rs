use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CyclePhase {
    Expansion,
    Boom,
    Bottleneck,
    Bust,
    Liquidation,
    Recovery,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BusinessCycleState {
    pub current_phase: CyclePhase,
    pub credit_expansion_pct: f64,
    pub malinvestment_ratio: f64,
    pub capital_liquidation_rate: f64,
}
