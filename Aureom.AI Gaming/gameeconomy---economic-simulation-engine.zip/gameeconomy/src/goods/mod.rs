use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoodItem {
    pub id: String,
    pub name: String,
    pub is_capital_good: bool,
    pub current_market_price: f64,
}
