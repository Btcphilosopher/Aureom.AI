use axum::{routing::get, Json, Router};
use crate::EconomicState;
use serde_json::{json, Value};
use std::sync::{Arc, Mutex};

pub fn create_router(state: EconomicState) -> Router {
    let shared_state = Arc::new(Mutex::new(state));

    Router::new()
        .route("/health", get(|| async { Json(json!({"status": "ok", "engine": "gameeconomy-rust"})) }))
        .route("/metrics", get({
            let state = Arc::clone(&shared_state);
            move || async move {
                let st = state.lock().unwrap();
                Json(st.metrics())
            }
        }))
}
