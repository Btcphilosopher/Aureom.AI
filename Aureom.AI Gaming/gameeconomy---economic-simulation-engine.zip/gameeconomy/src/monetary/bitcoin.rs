use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BitcoinNetwork {
    pub max_supply_sats: u64,
    pub current_supply_sats: u64,
    pub block_height: u64,
    pub block_subsidy_sats: u64,
    pub total_hashrate_th: f64,
    pub difficulty: f64,
    pub market_price_usd: f64,
    pub next_halving_block: u64,
}

impl BitcoinNetwork {
    pub fn new() -> Self {
        Self {
            max_supply_sats: 21_000_000_0000_0000,
            current_supply_sats: 19_750_000_0000_0000,
            block_height: 850_000,
            block_subsidy_sats: 3_1250_0000, // 3.125 BTC
            total_hashrate_th: 620_000_000.0,
            difficulty: 86_000_000_000_000.0,
            market_price_usd: 67_400.0,
            next_halving_block: 1_050_000,
        }
    }

    pub fn step_block_progress(&mut self, tick: u64) {
        if tick % 10 == 0 {
            self.block_height += 1;
            self.current_supply_sats += self.block_subsidy_sats;
            self.market_price_usd += (tick as f64 * 12.5) % 150.0 - 60.0;
        }
    }
}
