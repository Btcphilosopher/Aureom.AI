pub mod bitcoin;

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MonetaryRegime {
    Fiat,
    FixedSupply,
    CommodityGold,
    FreeBanking,
    BitcoinStandard,
}
