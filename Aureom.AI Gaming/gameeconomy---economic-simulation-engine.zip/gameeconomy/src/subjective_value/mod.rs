pub mod preference;

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UtilityFunction {
    pub alpha_consumption: f64,
    pub beta_leisure: f64,
    pub gamma_capital: f64,
}
