use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PreferenceProfile {
    pub food_weight: f64,
    pub housing_weight: f64,
    pub luxury_weight: f64,
    pub capital_goods_weight: f64,
    pub btc_weight: f64,
}
