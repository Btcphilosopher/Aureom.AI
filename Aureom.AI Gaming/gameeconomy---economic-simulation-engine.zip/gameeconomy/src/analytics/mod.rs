use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MacroAnalytics {
    pub gini_coefficient: f64,
    pub top_1pct_wealth_share: f64,
    pub bottom_50pct_wealth_share: f64,
    pub velocity_m2: f64,
    pub capital_consumption_allowance: f64,
}
