use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolicyConfiguration {
    pub income_tax_rate: f64,
    pub corporate_tax_rate: f64,
    pub central_bank_target_rate: f64,
    pub reserve_requirement_pct: f64,
    pub subsidy_capital_goods_pct: f64,
}
