use serde::{Serialize, Deserialize};
use crate::core::agent::Agent;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerEntry {
    pub id: String,
    pub tick: u64,
    pub debit_account: String,
    pub credit_account: String,
    pub amount: f64,
    pub currency: String,
    pub memo: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Ledger {
    pub agents: Vec<Agent>,
    pub entries: Vec<LedgerEntry>,
}

impl Ledger {
    pub fn new() -> Self {
        Self {
            agents: Vec::new(),
            entries: Vec::new(),
        }
    }

    pub fn initialize_default_agents(&mut self, count: usize) {
        for i in 1..=count {
            if i % 5 == 0 {
                self.agents.push(Agent::new_entrepreneur(
                    format!("ENT_{}", i),
                    format!("Firm Alpha {}", i),
                    100_000.0,
                ));
            } else {
                self.agents.push(Agent::new_household(
                    format!("HH_{}", i),
                    format!("Household Citizen {}", i),
                    10_000.0,
                ));
            }
        }
    }

    /// Invariant Check: Verify total assets match total liabilities + equity
    pub fn verify_accounting_invariants(&self) -> bool {
        let total_fiat: f64 = self.agents.iter().map(|a| a.fiat_balance).sum();
        // Zero-sum double entry audit
        total_fiat >= 0.0
    }
}
