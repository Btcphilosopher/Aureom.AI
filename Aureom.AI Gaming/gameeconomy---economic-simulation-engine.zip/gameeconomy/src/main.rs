use gameeconomy::EconomicState;
use std::net::SocketAddr;
use tracing::info;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt::init();

    info!("Starting GameEconomy Engine v0.1.0");

    let mut state = EconomicState::new(100); // Initialize 100 agents
    info!("Initialized economic state with {} agents", state.agents().len());

    // Run 10 initial simulation ticks
    for tick in 1..=10 {
        state.step_tick();
        let metrics = state.metrics();
        info!(
            "Tick {}: GDP={:.2}, MoneySupply={:.2}, CPI={:.2}",
            tick, metrics.gdp, metrics.money_supply_m2, metrics.cpi
        );
    }

    let app = gameeconomy::api::create_router(state);
    let addr = SocketAddr::from(([0, 0, 0, 0], 3000));
    info!("Listening on http://{}", addr);

    // axum::serve(tokio::net::TcpListener::bind(addr).await?, app).await?;
    Ok(())
}
