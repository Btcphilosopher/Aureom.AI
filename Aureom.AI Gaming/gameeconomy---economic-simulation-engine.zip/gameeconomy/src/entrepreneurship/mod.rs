use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Firm {
    pub id: String,
    pub name: String,
    pub equity_shares: f64,
    pub cash_reserve: f64,
    pub capital_assets_value: f64,
    pub debt_balance: f64,
    pub expected_roi: f64,
    pub is_liquidated: bool,
}
