use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LimitOrder {
    pub order_id: String,
    pub agent_id: String,
    pub price: f64,
    pub quantity: f64,
    pub is_buy: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderBook {
    pub symbol: String,
    pub bids: Vec<LimitOrder>,
    pub asks: Vec<LimitOrder>,
    pub last_traded_price: f64,
    pub 24h_volume: f64,
}

impl OrderBook {
    pub fn new(symbol: impl Into<String>) -> Self {
        let mut book = Self {
            symbol: symbol.into(),
            bids: Vec::new(),
            asks: Vec::new(),
            last_traded_price: 150.0,
            24h_volume: 42500.0,
        };
        book.seed_sample_depth();
        book
    }

    pub fn seed_sample_depth(&mut self) {
        let base = self.last_traded_price;
        for i in 1..=5 {
            self.bids.push(LimitOrder {
                order_id: format!("bid_{}", i),
                agent_id: "HH_1".into(),
                price: base - (i as f64 * 1.5),
                quantity: (10.0 * i as f64),
                is_buy: true,
            });
            self.asks.push(LimitOrder {
                order_id: format!("ask_{}", i),
                agent_id: "ENT_1".into(),
                price: base + (i as f64 * 1.5),
                quantity: (8.0 * i as f64),
                is_buy: false,
            });
        }
    }
}
