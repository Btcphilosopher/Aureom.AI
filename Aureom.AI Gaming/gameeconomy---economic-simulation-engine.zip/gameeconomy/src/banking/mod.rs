use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BankLoan {
    pub loan_id: String,
    pub borrower_id: String,
    pub principal: f64,
    pub interest_rate: f64,
    pub duration_months: u32,
    pub is_defaulted: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Bank {
    pub id: String,
    pub deposits: f64,
    pub reserves: f64,
    pub loans: Vec<BankLoan>,
}
