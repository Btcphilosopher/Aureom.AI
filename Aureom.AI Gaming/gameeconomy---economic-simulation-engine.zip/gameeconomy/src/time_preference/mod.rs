use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimePreferenceEngine {
    pub average_originary_rate: f64,
    pub liquidity_preference_index: f64,
}
