use serde::{Serialize, Deserialize};
use crate::accounting::ledger::Ledger;
use crate::markets::order_book::OrderBook;
use crate::monetary::bitcoin::BitcoinNetwork;
use crate::capital::structure::CapitalStructure;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EconomicMetrics {
    pub tick: u64,
    pub gdp: f64,
    pub cpi: f64,
    pub ppi_capital_goods: f64,
    pub money_supply_m0: f64,
    pub money_supply_m2: f64,
    pub bank_reserve_ratio: f64,
    pub avg_time_preference: f64,
    pub interest_rate_originary: f64,
    pub interest_rate_market: f64,
    pub btc_price_usd: f64,
    pub btc_hashrate_th: f64,
    pub malinvestment_ratio: f64,
    pub unemployment_rate: f64,
    pub total_capital_stock: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct EconomicState {
    pub tick: u64,
    pub ledger: Ledger,
    pub goods_order_book: OrderBook,
    pub btc_network: BitcoinNetwork,
    pub capital_structure: CapitalStructure,
    pub metrics_history: Vec<EconomicMetrics>,
}

impl EconomicState {
    pub fn new(agent_count: usize) -> Self {
        let mut ledger = Ledger::new();
        ledger.initialize_default_agents(agent_count);

        Self {
            tick: 0,
            ledger,
            goods_order_book: OrderBook::new("CONSUMER_GOOD_ALPHA"),
            btc_network: BitcoinNetwork::new(),
            capital_structure: CapitalStructure::new(),
            metrics_history: Vec::new(),
        }
    }

    pub fn agents(&self) -> usize {
        self.ledger.agents.len()
    }

    pub fn step_tick(&mut self) {
        self.tick += 1;
        self.btc_network.step_block_progress(self.tick);
        self.capital_structure.update_stage_allocations(0.05); // sample interest rate

        let metrics = EconomicMetrics {
            tick: self.tick,
            gdp: 1_250_000.0 + (self.tick as f64 * 1200.0),
            cpi: 100.0 + (self.tick as f64 * 0.15),
            ppi_capital_goods: 100.0 + (self.tick as f64 * 0.22),
            money_supply_m0: 500_000.0,
            money_supply_m2: 2_100_000.0 + (self.tick as f64 * 5000.0),
            bank_reserve_ratio: 0.12,
            avg_time_preference: 0.045,
            interest_rate_originary: 0.04,
            interest_rate_market: 0.035,
            btc_price_usd: self.btc_network.market_price_usd,
            btc_hashrate_th: self.btc_network.total_hashrate_th,
            malinvestment_ratio: 0.08,
            unemployment_rate: 0.042,
            total_capital_stock: 4_800_000.0 + (self.tick as f64 * 3500.0),
        };

        self.metrics_history.push(metrics);
    }

    pub fn metrics(&self) -> EconomicMetrics {
        self.metrics_history.last().cloned().unwrap_or(EconomicMetrics {
            tick: 0,
            gdp: 1_000_000.0,
            cpi: 100.0,
            ppi_capital_goods: 100.0,
            money_supply_m0: 500_000.0,
            money_supply_m2: 2_000_000.0,
            bank_reserve_ratio: 0.15,
            avg_time_preference: 0.05,
            interest_rate_originary: 0.05,
            interest_rate_market: 0.05,
            btc_price_usd: 65_000.0,
            btc_hashrate_th: 450_000.0,
            malinvestment_ratio: 0.05,
            unemployment_rate: 0.04,
            total_capital_stock: 4_500_000.0,
        })
    }
}
