use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AgentType {
    Household,
    Entrepreneur,
    CommercialBank,
    CentralBank,
    BitcoinMiner,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Agent {
    pub id: String,
    pub name: String,
    pub agent_type: AgentType,
    pub time_preference: f64, // discount rate alpha (0.01 to 0.20)
    pub risk_tolerance: f64,    // 0.0 to 1.0
    pub fiat_balance: f64,
    pub btc_balance: f64,
    pub capital_assets_value: f64,
}

impl Agent {
    pub fn new_household(id: impl Into<String>, name: impl Into<String>, initial_cash: f64) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            agent_type: AgentType::Household,
            time_preference: 0.05,
            risk_tolerance: 0.30,
            fiat_balance: initial_cash,
            btc_balance: 0.1,
            capital_assets_value: 1000.0,
        }
    }

    pub fn new_entrepreneur(id: impl Into<String>, name: impl Into<String>, capital: f64) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            agent_type: AgentType::Entrepreneur,
            time_preference: 0.03,
            risk_tolerance: 0.75,
            fiat_balance: capital,
            btc_balance: 1.5,
            capital_assets_value: 50000.0,
        }
    }
}
