import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'MITHRIL.OS — Middle-earth Strategy Engine',
  description: 'AAA Middle-earth Strategy Engine and Command Interface across the Ages, featuring living cartographic canvas, simulation engine, and tactical command hierarchy.',
  openGraph: {
    title: 'MITHRIL.OS — Middle-earth Strategy Engine',
    description: 'AAA Middle-earth Strategy Engine and Command Interface across the Ages, featuring living cartographic canvas, simulation engine, and tactical command hierarchy.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MITHRIL.OS — Middle-earth Strategy Engine',
    description: 'AAA Middle-earth Strategy Engine and Command Interface across the Ages, featuring living cartographic canvas, simulation engine, and tactical command hierarchy.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700;800;900&family=Cinzel+Decorative:wght@700&family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body suppressHydrationWarning className="bg-[#0c0c0b] text-[#d4c5a9] font-sans antialiased select-none overflow-hidden h-screen w-screen">
        {children}
      </body>
    </html>
  );
}
