'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  AgeId,
  Army,
  ArmyFormation,
  ArmyStance,
  CameraState,
  DiplomacyRelation,
  FactionId,
  MapLayerId,
  Settlement,
  WeatherType,
  ActiveCombat,
} from '@/types/game';
import {
  INITIAL_SETTLEMENTS,
  INITIAL_ARMIES,
  TECH_TREE_DATA,
  DIPLOMACY_MATRIX,
  HISTORY_CHRONICLES,
} from '@/lib/gameData';
import {
  SimulationState,
  calculateInitialResourceRates,
  runSimulationTick,
} from '@/lib/simulationEngine';
import { soundEngine } from '@/lib/soundEngine';

// Components
import { MainMenu } from '@/components/menu/MainMenu';
import { WorldMapCanvas } from '@/components/map/WorldMapCanvas';
import { TopBar } from '@/components/hud/TopBar';
import { Minimap } from '@/components/hud/Minimap';
import { CommandPanel } from '@/components/hud/CommandPanel';
import { SettlementPanel } from '@/components/hud/SettlementPanel';
import { ArmyPanel } from '@/components/hud/ArmyPanel';
import { NotificationStream } from '@/components/hud/NotificationStream';
import { CombatModal } from '@/components/hud/CombatModal';

// Modals
import { TechTreeModal } from '@/components/modals/TechTreeModal';
import { DiplomacyModal } from '@/components/modals/DiplomacyModal';
import { HistoryChronicleModal } from '@/components/modals/HistoryChronicleModal';
import { AtlasModal } from '@/components/modals/AtlasModal';
import { ResourceOverviewModal } from '@/components/modals/ResourceOverviewModal';
import { PopulationModal } from '@/components/modals/PopulationModal';
import { CommandPalette } from '@/components/modals/CommandPalette';
import { DebugModal } from '@/components/modals/DebugModal';

export default function GameMasterPage() {
  // Game Mode State: MENU vs IN_GAME
  const [gameMode, setGameMode] = useState<'MENU' | 'IN_GAME'>('MENU');
  const [isCinematic, setIsCinematic] = useState(false);

  // Simulation State
  const [simState, setSimState] = useState<SimulationState>(() => {
    const defaultFaction: FactionId = 'GONDOR';
    const defaultRates = calculateInitialResourceRates(
      defaultFaction,
      INITIAL_SETTLEMENTS,
      INITIAL_ARMIES
    );

    return {
      age: 'THIRD_AGE',
      year: 3019,
      season: 'AUTUMN',
      day: 143,
      hour: 14,
      minute: 32,
      simulationSpeed: 1,
      weather: 'CLEAR',
      temperatureC: 14,
      windSpeedKmh: 18,

      playerFaction: defaultFaction,
      resources: {
        food: 12420,
        wood: 8350,
        stone: 6200,
        iron: 4800,
        gold: 15600,
        mithril: 45,
      },
      resourceRates: defaultRates,

      settlements: INITIAL_SETTLEMENTS,
      armies: INITIAL_ARMIES,
      activeCombats: [
        {
          id: 'combat-osgiliath',
          name: 'The Battle for the Bridges of Osgiliath',
          x: 670,
          y: 595,
          attackerArmyName: 'Legion of the Black Gate',
          defenderArmyName: 'Garrison of Minas Tirith',
          attackerMorale: 85,
          defenderMorale: 78,
          attackerCasualties: 420,
          defenderCasualties: 380,
          terrainType: 'RIVER_CROSSING',
          durationTicks: 45,
        },
      ],
      activeSieges: [],
      techTree: TECH_TREE_DATA,
      notifications: [
        {
          id: 'notif-1',
          timestamp: 'Day 143, 14:00',
          priority: 'CRITICAL',
          title: 'Siege of Osgiliath Underway',
          message: 'Mordor vanguard has breached the eastern arches of the Great River Anduin.',
          entityId: 'osgiliath',
          entityType: 'SETTLEMENT',
          x: 670,
          y: 595,
        },
        {
          id: 'notif-2',
          timestamp: 'Day 143, 11:30',
          priority: 'IMPORTANT',
          title: 'The Beacons of Amon Dîn Kindled',
          message: 'Summons sent across the Anórien border to Théoden King in Edoras.',
          x: 580,
          y: 560,
        },
      ],

      fps: 60,
      tickCount: 1,
      threatLevel: 'HIGH',
    };
  });

  // Diplomacy Relations
  const [diplomacy, setDiplomacy] = useState<DiplomacyRelation[]>(DIPLOMACY_MATRIX);

  // Map & Camera State
  const [camera, setCamera] = useState<CameraState>({
    x: 610,
    y: 580,
    zoom: 1.1,
    pitchDeg: 0,
    rotationDeg: 0,
  });

  const [activeLayer, setActiveLayer] = useState<MapLayerId>('TERRAIN');

  // Selection States
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>('minas-tirith');
  const [selectedEntityType, setSelectedEntityType] = useState<'SETTLEMENT' | 'ARMY' | 'HERO' | null>(
    'SETTLEMENT'
  );
  const [selectedArmyIds, setSelectedArmyIds] = useState<string[]>([]);
  const [buildModeBuilding, setBuildModeBuilding] = useState<string | null>(null);

  // Modals
  const [activeModal, setActiveModal] = useState<
    'TECH' | 'DIPLOMACY' | 'HISTORY' | 'ATLAS' | 'SEARCH' | 'DEBUG' | 'RESOURCES' | 'POPULATION' | null
  >(null);
  const [activeCombatModal, setActiveCombatModal] = useState<ActiveCombat | null>(null);

  // Start Simulation Tick Interval
  useEffect(() => {
    if (gameMode !== 'IN_GAME') return;

    let lastTime = performance.now();

    const interval = setInterval(() => {
      const now = performance.now();
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      setSimState((prevState) => runSimulationTick(prevState, delta));
    }, 250); // Tick 4 times a second

    return () => clearInterval(interval);
  }, [gameMode]);

  // Keyboard navigation & Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If typing in an input element, do not trigger global game hotkeys
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      switch (e.key) {
        case ' ':
          e.preventDefault();
          setSimState((s) => ({
            ...s,
            simulationSpeed: s.simulationSpeed === 0 ? 1 : 0,
          }));
          soundEngine.playTacticalClick();
          break;
        case '/':
          e.preventDefault();
          setActiveModal('SEARCH');
          break;
        case 'Escape':
          e.preventDefault();
          if (activeModal) setActiveModal(null);
          else if (activeCombatModal) setActiveCombatModal(null);
          else if (buildModeBuilding) setBuildModeBuilding(null);
          else {
            setSelectedEntityId(null);
            setSelectedEntityType(null);
            setSelectedArmyIds([]);
          }
          break;
        case 't':
        case 'T':
          setActiveModal((m) => (m === 'TECH' ? null : 'TECH'));
          break;
        case 'd':
        case 'D':
          setActiveModal((m) => (m === 'DIPLOMACY' ? null : 'DIPLOMACY'));
          break;
        case 'h':
        case 'H':
          setActiveModal((m) => (m === 'HISTORY' ? null : 'HISTORY'));
          break;
        case 'm':
        case 'M':
          setActiveModal((m) => (m === 'ATLAS' ? null : 'ATLAS'));
          break;
        case 'w':
        case 'W':
        case 'ArrowUp':
          setCamera((c) => ({ ...c, y: Math.max(100, c.y - 30 / c.zoom) }));
          break;
        case 's':
        case 'S':
        case 'ArrowDown':
          setCamera((c) => ({ ...c, y: Math.min(900, c.y + 30 / c.zoom) }));
          break;
        case 'a':
        case 'A':
        case 'ArrowLeft':
          setCamera((c) => ({ ...c, x: Math.max(100, c.x - 30 / c.zoom) }));
          break;
        case 'd':
        case 'ArrowRight':
          setCamera((c) => ({ ...c, x: Math.min(1000, c.x + 30 / c.zoom) }));
          break;
        case 'q':
        case 'Q':
          setCamera((c) => ({ ...c, rotationDeg: (c.rotationDeg - 15 + 360) % 360 }));
          break;
        case 'e':
        case 'E':
          setCamera((c) => ({ ...c, rotationDeg: (c.rotationDeg + 15) % 360 }));
          break;
        case '+':
        case '=':
          setCamera((c) => ({ ...c, zoom: Math.min(2.8, c.zoom * 1.15) }));
          break;
        case '-':
        case '_':
          setCamera((c) => ({ ...c, zoom: Math.max(0.4, c.zoom * 0.85) }));
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeModal, activeCombatModal, buildModeBuilding]);

  // Campaign Launcher
  const handleStartCampaign = (age: AgeId, faction: FactionId) => {
    const rates = calculateInitialResourceRates(faction, simState.settlements, simState.armies);
    setSimState((s) => ({
      ...s,
      age,
      playerFaction: faction,
      resourceRates: rates,
      simulationSpeed: 1,
    }));
    setGameMode('IN_GAME');
    soundEngine.playWarHorn();

    // Pan camera to player faction's capital
    const playerCapital = simState.settlements.find(
      (set) => set.faction === faction && set.isCapital
    );
    if (playerCapital) {
      setCamera({
        x: playerCapital.x,
        y: playerCapital.y,
        zoom: 1.2,
        pitchDeg: 0,
        rotationDeg: 0,
      });
      setSelectedEntityId(playerCapital.id);
      setSelectedEntityType('SETTLEMENT');
    }
  };

  // Selection Callbacks
  const handleSelectSettlement = useCallback((settlement: Settlement) => {
    setSelectedEntityId(settlement.id);
    setSelectedEntityType('SETTLEMENT');
    setSelectedArmyIds([]);
  }, []);

  const handleSelectArmy = useCallback((army: Army, isMultiSelect = false) => {
    if (isMultiSelect) {
      setSelectedArmyIds((prev) =>
        prev.includes(army.id) ? prev.filter((id) => id !== army.id) : [...prev, army.id]
      );
    } else {
      setSelectedEntityId(army.id);
      setSelectedEntityType('ARMY');
      setSelectedArmyIds([army.id]);
    }
  }, []);

  const handleMoveArmyOrder = useCallback((armyId: string, targetX: number, targetY: number) => {
    setSimState((prev) => ({
      ...prev,
      armies: prev.armies.map((a) =>
        a.id === armyId ? { ...a, targetX, targetY } : a
      ),
    }));
  }, []);

  const handleQueueBuilding = (buildingName: string) => {
    if (!selectedEntityId) return;
    setSimState((prev) => ({
      ...prev,
      settlements: prev.settlements.map((s) => {
        if (s.id === selectedEntityId) {
          return {
            ...s,
            constructionQueue: [
              ...s.constructionQueue,
              {
                id: 'cq-' + Date.now(),
                name: buildingName,
                totalDays: 20,
                daysRemaining: 20,
                progressPercent: 0,
              },
            ],
          };
        }
        return s;
      }),
    }));
  };

  const handleFocusCoordinates = useCallback((x: number, y: number) => {
    setCamera((prev) => ({
      ...prev,
      x,
      y,
      zoom: Math.max(1.1, prev.zoom),
    }));
  }, []);

  const selectedSettlement =
    selectedEntityType === 'SETTLEMENT'
      ? simState.settlements.find((s) => s.id === selectedEntityId) || null
      : null;

  const selectedArmy =
    selectedEntityType === 'ARMY'
      ? simState.armies.find((a) => a.id === selectedEntityId) || null
      : null;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#090b0e] select-none font-sans">
      {/* 1. Main Menu Screen */}
      {gameMode === 'MENU' && (
        <MainMenu
          onStartGame={handleStartCampaign}
          onOpenAtlas={() => setActiveModal('ATLAS')}
          onOpenChronicles={() => setActiveModal('HISTORY')}
        />
      )}

      {/* 2. Living Interactive Strategy Map (World is Primary Object) */}
      {gameMode === 'IN_GAME' && (
        <main className="relative w-full h-full">
          <WorldMapCanvas
            settlements={simState.settlements}
            armies={simState.armies}
            activeCombats={simState.activeCombats}
            selectedEntityId={selectedEntityId}
            selectedEntityType={selectedEntityType}
            selectedArmyIds={selectedArmyIds}
            activeLayer={activeLayer}
            weather={simState.weather}
            camera={camera}
            onCameraChange={setCamera}
            onSelectSettlement={handleSelectSettlement}
            onSelectArmy={handleSelectArmy}
            onMoveArmyOrder={handleMoveArmyOrder}
            buildModeBuilding={buildModeBuilding}
            onPlaceBuilding={(setlId, bType) => {
              handleQueueBuilding(bType);
              setBuildModeBuilding(null);
            }}
            playerFaction={simState.playerFaction}
          />

          {/* HUD Overlays (Only shown when not in pure cinematic view) */}
          {!isCinematic && (
            <>
              {/* Top Imperial Bar */}
              <TopBar
                age={simState.age}
                year={simState.year}
                season={simState.season}
                day={simState.day}
                hour={simState.hour}
                minute={simState.minute}
                simulationSpeed={simState.simulationSpeed}
                onSetSimulationSpeed={(speed) =>
                  setSimState((s) => ({ ...s, simulationSpeed: speed }))
                }
                playerFaction={simState.playerFaction}
                resources={simState.resources}
                resourceRates={simState.resourceRates}
                activeLayer={activeLayer}
                onSelectLayer={setActiveLayer}
                weather={simState.weather}
                threatLevel={simState.threatLevel}
                onOpenModal={setActiveModal}
                onToggleCinematic={() => setIsCinematic(!isCinematic)}
                isCinematic={isCinematic}
              />

              {/* Minimap (Bottom-Left) */}
              <Minimap
                settlements={simState.settlements}
                armies={simState.armies}
                camera={camera}
                onCameraChange={setCamera}
                playerFaction={simState.playerFaction}
              />

              {/* Tactical Command Bar (Bottom Center) */}
              <CommandPanel
                selectedSettlement={selectedSettlement}
                selectedArmy={selectedArmy}
                selectedArmyCount={selectedArmyIds.length}
                onArmyOrder={(order) => {
                  if (order === 'MOVE') {
                    // Instruct player to click target
                  } else if (order === 'FORTIFY') {
                    if (selectedSettlement) {
                      setSimState((prev) => ({
                        ...prev,
                        settlements: prev.settlements.map((s) =>
                          s.id === selectedSettlement.id
                            ? { ...s, wallsLevel: s.wallsLevel + 1, defence: s.defence + 15 }
                            : s
                        ),
                      }));
                    }
                  }
                }}
                onSetFormation={(formation: ArmyFormation) => {
                  if (selectedArmy) {
                    setSimState((prev) => ({
                      ...prev,
                      armies: prev.armies.map((a) =>
                        a.id === selectedArmy.id ? { ...a, formation } : a
                      ),
                    }));
                  }
                }}
                onSetStance={(stance: ArmyStance) => {
                  if (selectedArmy) {
                    setSimState((prev) => ({
                      ...prev,
                      armies: prev.armies.map((a) =>
                        a.id === selectedArmy.id ? { ...a, stance } : a
                      ),
                    }));
                  }
                }}
                onOpenBuildMode={() => setBuildModeBuilding('Valley Farm')}
                onOpenRecruitModal={() => {
                  if (selectedSettlement) {
                    setSimState((prev) => ({
                      ...prev,
                      settlements: prev.settlements.map((s) =>
                        s.id === selectedSettlement.id
                          ? { ...s, garrisonStrength: s.garrisonStrength + 500 }
                          : s
                      ),
                    }));
                    soundEngine.playDrumStrike();
                  }
                }}
                onDeselect={() => {
                  setSelectedEntityId(null);
                  setSelectedEntityType(null);
                  setSelectedArmyIds([]);
                  setBuildModeBuilding(null);
                }}
              />

              {/* Contextual Side Panels (Right Side) */}
              {selectedSettlement && (
                <SettlementPanel
                  settlement={selectedSettlement}
                  onClose={() => {
                    setSelectedEntityId(null);
                    setSelectedEntityType(null);
                  }}
                  onQueueBuilding={handleQueueBuilding}
                  playerResources={simState.resources}
                  onFocusCoordinates={handleFocusCoordinates}
                />
              )}

              {selectedArmy && (
                <ArmyPanel
                  army={selectedArmy}
                  onClose={() => {
                    setSelectedEntityId(null);
                    setSelectedEntityType(null);
                    setSelectedArmyIds([]);
                  }}
                  onSetFormation={(formation) => {
                    setSimState((prev) => ({
                      ...prev,
                      armies: prev.armies.map((a) =>
                        a.id === selectedArmy.id ? { ...a, formation } : a
                      ),
                    }));
                  }}
                  onSetStance={(stance) => {
                    setSimState((prev) => ({
                      ...prev,
                      armies: prev.armies.map((a) =>
                        a.id === selectedArmy.id ? { ...a, stance } : a
                      ),
                    }));
                  }}
                  onFocusCoordinates={handleFocusCoordinates}
                />
              )}

              {/* Strategic Notifications Stream (Top-Left) */}
              <NotificationStream
                notifications={simState.notifications}
                onDismiss={(notifId) =>
                  setSimState((prev) => ({
                    ...prev,
                    notifications: prev.notifications.filter((n) => n.id !== notifId),
                  }))
                }
                onJumpToLocation={handleFocusCoordinates}
              />
            </>
          )}

          {/* Cinematic Exit Button (when in cinematic mode) */}
          {isCinematic && (
            <button
              onClick={() => setIsCinematic(false)}
              className="absolute top-4 right-4 z-50 px-3 py-1.5 bg-[#0e1015]/80 hover:bg-[#151922] border border-[#a88e5e]/50 rounded text-xs font-display text-[#f5eedf] backdrop-blur-sm transition-colors"
            >
              EXIT CINEMATIC VIEW
            </button>
          )}
        </main>
      )}

      {/* 3. Global Full-Screen Modals & Command Overlays */}
      {activeModal === 'TECH' && (
        <TechTreeModal
          techTree={simState.techTree}
          onStartResearch={(techId) => {
            setSimState((prev) => ({
              ...prev,
              techTree: prev.techTree.map((t) =>
                t.id === techId ? { ...t, isResearching: true, progressPercent: 0 } : t
              ),
            }));
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'DIPLOMACY' && (
        <DiplomacyModal
          playerFaction={simState.playerFaction}
          diplomacy={diplomacy}
          onUpdateRelation={(targetFaction, newStatus) => {
            setDiplomacy((prev) =>
              prev.map((d) =>
                (d.factionA === simState.playerFaction && d.factionB === targetFaction) ||
                (d.factionB === simState.playerFaction && d.factionA === targetFaction)
                  ? { ...d, status: newStatus }
                  : d
              )
            );
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'HISTORY' && (
        <HistoryChronicleModal
          events={HISTORY_CHRONICLES}
          onClose={() => setActiveModal(null)}
          onJumpToEvent={handleFocusCoordinates}
        />
      )}

      {activeModal === 'ATLAS' && (
        <AtlasModal
          settlements={simState.settlements}
          onClose={() => setActiveModal(null)}
          onJumpToLocation={handleFocusCoordinates}
        />
      )}

      {activeModal === 'RESOURCES' && (
        <ResourceOverviewModal
          resources={simState.resources}
          resourceRates={simState.resourceRates}
          onClose={() => setActiveModal(null)}
          onShowOnMap={() => setActiveLayer('RESOURCES')}
        />
      )}

      {activeModal === 'POPULATION' && (
        <PopulationModal onClose={() => setActiveModal(null)} />
      )}

      <CommandPalette
        settlements={simState.settlements}
        armies={simState.armies}
        isOpen={activeModal === 'SEARCH'}
        onClose={() => setActiveModal(null)}
        onSelectSettlement={(setl) => {
          handleSelectSettlement(setl);
          handleFocusCoordinates(setl.x, setl.y);
        }}
        onSelectArmy={(army) => {
          handleSelectArmy(army);
          handleFocusCoordinates(army.x, army.y);
        }}
      />

      {activeModal === 'DEBUG' && (
        <DebugModal
          fps={simState.fps}
          camera={camera}
          entityCount={{
            settlements: simState.settlements.length,
            armies: simState.armies.length,
            combats: simState.activeCombats.length,
          }}
          tickCount={simState.tickCount}
          onClose={() => setActiveModal(null)}
          onTriggerEvent={() => {
            setSimState((prev) => ({
              ...prev,
              notifications: [
                {
                  id: 'notif-' + Date.now(),
                  timestamp: `Day ${prev.day}, ${prev.hour}:${prev.minute}`,
                  priority: 'CRITICAL',
                  title: 'Sudden Hostile Incursion',
                  message: 'A fierce horde of Mordor warg-riders has crossed the Cair Andros shallows!',
                  x: 650,
                  y: 530,
                },
                ...prev.notifications,
              ],
            }));
          }}
        />
      )}

      {/* Active Battle / Engagement Modal */}
      {activeCombatModal && (
        <CombatModal
          combat={activeCombatModal}
          onClose={() => setActiveCombatModal(null)}
          onTacticalCommand={(cmd) => {
            // Apply tactic to combat
          }}
        />
      )}
    </div>
  );
}
