import {
  AgeId,
  Army,
  FactionId,
  GameNotification,
  GameResources,
  ResourceRate,
  Season,
  Settlement,
  TechNode,
  WeatherType,
  ActiveCombat,
  ActiveSiege,
} from '@/types/game';

export interface SimulationState {
  age: AgeId;
  year: number;
  season: Season;
  day: number;
  hour: number;
  minute: number;
  simulationSpeed: number; // 0 = pause, 1, 2, 4, 8, 16
  weather: WeatherType;
  temperatureC: number;
  windSpeedKmh: number;

  playerFaction: FactionId;
  resources: GameResources;
  resourceRates: ResourceRate;

  settlements: Settlement[];
  armies: Army[];
  activeCombats: ActiveCombat[];
  activeSieges: ActiveSiege[];
  techTree: TechNode[];
  notifications: GameNotification[];

  fps: number;
  tickCount: number;
  threatLevel: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH' | 'CRITICAL';
}

export function calculateInitialResourceRates(
  faction: FactionId,
  settlements: Settlement[],
  armies: Army[]
): ResourceRate {
  const ownedSettlements = settlements.filter((s) => s.faction === faction);
  const ownedArmies = armies.filter((a) => a.faction === faction);

  let foodRate = 60;
  let woodRate = 35;
  let stoneRate = 25;
  let ironRate = 20;
  let goldRate = 45;
  let mithrilRate = faction === 'RIVENDELL' || faction === 'EREBOR' ? 2 : 0;

  // Add settlement building production
  for (const s of ownedSettlements) {
    foodRate += Math.floor(s.population * 0.002);
    goldRate += Math.floor(s.wealth * 0.005);
    for (const b of s.buildings) {
      if (b.production.food) foodRate += b.production.food;
      if (b.production.wood) woodRate += b.production.wood;
      if (b.production.stone) stoneRate += b.production.stone;
      if (b.production.iron) ironRate += b.production.iron;
      if (b.production.gold) goldRate += b.production.gold;
    }
  }

  // Deduct military army upkeep
  for (const a of ownedArmies) {
    for (const u of a.units) {
      if (u.upkeep.food) foodRate -= Math.floor(u.upkeep.food * 0.4);
      if (u.upkeep.iron) ironRate -= Math.floor((u.upkeep.iron || 0) * 0.3);
      if (u.upkeep.wood) woodRate -= Math.floor((u.upkeep.wood || 0) * 0.3);
      if (u.upkeep.gold) goldRate -= Math.floor((u.upkeep.gold || 0) * 0.3);
    }
  }

  return {
    food: foodRate,
    wood: woodRate,
    stone: stoneRate,
    iron: ironRate,
    gold: goldRate,
    mithril: mithrilRate,
  };
}

export function runSimulationTick(
  state: SimulationState,
  deltaSeconds: number
): SimulationState {
  if (state.simulationSpeed === 0) {
    return { ...state, fps: Math.round(1 / Math.max(0.001, deltaSeconds)) };
  }

  const effectiveDelta = deltaSeconds * state.simulationSpeed;
  const tickCount = state.tickCount + 1;

  // 1. Advance Game Clock
  let { minute, hour, day, season, year } = state;
  minute += Math.floor(effectiveDelta * 4); // each real second at 1x is ~4 minutes
  if (minute >= 60) {
    hour += Math.floor(minute / 60);
    minute %= 60;
  }
  if (hour >= 24) {
    day += Math.floor(hour / 24);
    hour %= 24;
  }
  if (day > 365) {
    day = 1;
    year += 1;
  }

  // Seasons
  if (day < 90) season = 'SPRING';
  else if (day < 180) season = 'SUMMER';
  else if (day < 270) season = 'AUTUMN';
  else season = 'WINTER';

  // 2. Resource Accumulation
  const rateFactor = effectiveDelta / 60; // rates are per minute
  const newResources: GameResources = {
    food: Math.max(0, Math.round(state.resources.food + state.resourceRates.food * rateFactor)),
    wood: Math.max(0, Math.round(state.resources.wood + state.resourceRates.wood * rateFactor)),
    stone: Math.max(0, Math.round(state.resources.stone + state.resourceRates.stone * rateFactor)),
    iron: Math.max(0, Math.round(state.resources.iron + state.resourceRates.iron * rateFactor)),
    gold: Math.max(0, Math.round(state.resources.gold + state.resourceRates.gold * rateFactor)),
    mithril: Math.max(0, Math.round(state.resources.mithril + state.resourceRates.mithril * rateFactor)),
  };

  const newNotifications = [...state.notifications];

  // 3. Construction Queues
  const updatedSettlements = state.settlements.map((settlement) => {
    if (settlement.constructionQueue.length === 0) return settlement;
    const queue = settlement.constructionQueue.map((item, idx) => {
      if (idx === 0) {
        const increment = (effectiveDelta / 10) * (100 / Math.max(5, item.totalDays));
        const newProgress = Math.min(100, item.progressPercent + increment);
        const daysLeft = Math.max(0, Math.ceil(item.totalDays * (1 - newProgress / 100)));
        return { ...item, progressPercent: Math.round(newProgress), daysRemaining: daysLeft };
      }
      return item;
    });

    const completed = queue.filter((q) => q.progressPercent >= 100);
    const remaining = queue.filter((q) => q.progressPercent < 100);

    if (completed.length > 0 && settlement.faction === state.playerFaction) {
      completed.forEach((c) => {
        newNotifications.unshift({
          id: 'notif-' + Date.now() + Math.random(),
          timestamp: `Day ${day}, ${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
          priority: 'INFORMATION',
          title: 'Construction Completed',
          message: `${c.name} has been completed in ${settlement.name}.`,
          entityId: settlement.id,
          entityType: 'SETTLEMENT',
          x: settlement.x,
          y: settlement.y,
        });
      });
    }

    return {
      ...settlement,
      constructionQueue: remaining,
    };
  });

  // 4. Research Queues
  const updatedTechTree = state.techTree.map((tech) => {
    if (!tech.isResearching) return tech;
    const increment = (effectiveDelta / 15) * 5;
    const newProgress = Math.min(100, tech.progressPercent + increment);
    if (newProgress >= 100) {
      newNotifications.unshift({
        id: 'notif-' + Date.now() + Math.random(),
        timestamp: `Day ${day}, ${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
        priority: 'IMPORTANT',
        title: 'Technology Discovered',
        message: `${tech.name} has been fully researched.`,
        entityType: 'TECH',
      });
      return {
        ...tech,
        progressPercent: 100,
        isResearched: true,
        isResearching: false,
      };
    }
    return { ...tech, progressPercent: Math.round(newProgress) };
  });

  // 5. Army Movement & Destination
  const updatedArmies = state.armies.map((army) => {
    if (army.targetX !== undefined && army.targetY !== undefined) {
      const dx = army.targetX - army.x;
      const dy = army.targetY - army.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist > 4) {
        const step = (army.movementSpeed * effectiveDelta * 0.8) / Math.max(1, dist);
        const newX = army.x + dx * Math.min(1, step);
        const newY = army.y + dy * Math.min(1, step);
        return {
          ...army,
          x: Math.round(newX * 10) / 10,
          y: Math.round(newY * 10) / 10,
        };
      } else {
        // Arrived at destination
        return {
          ...army,
          x: army.targetX,
          y: army.targetY,
          targetX: undefined,
          targetY: undefined,
        };
      }
    }
    return army;
  });

  // 6. Combat Simulation
  let updatedCombats = [...state.activeCombats];
  if (updatedCombats.length > 0) {
    updatedCombats = updatedCombats
      .map((combat) => {
        const attackerLoss = Math.floor(10 * state.simulationSpeed);
        const defenderLoss = Math.floor(12 * state.simulationSpeed);

        const nextAttackerMorale = Math.max(0, combat.attackerMorale - 0.2 * state.simulationSpeed);
        const nextDefenderMorale = Math.max(0, combat.defenderMorale - 0.25 * state.simulationSpeed);

        return {
          ...combat,
          durationTicks: combat.durationTicks + 1,
          attackerMorale: Math.round(nextAttackerMorale * 10) / 10,
          defenderMorale: Math.round(nextDefenderMorale * 10) / 10,
          attackerCasualties: combat.attackerCasualties + attackerLoss,
          defenderCasualties: combat.defenderCasualties + defenderLoss,
        };
      })
      .filter((c) => c.attackerMorale > 10 && c.defenderMorale > 10);
  }

  // 7. Dynamic Periodic Events
  if (tickCount % 450 === 0) {
    const randomEvents = [
      { title: 'The Beacons of Amon Dîn Are Kindled', message: 'Flames rise atop the mountain passes; summons call to Rohan.', priority: 'IMPORTANT' as const },
      { title: 'Dwarven Delvers Strike Rich Vein', message: 'Prospectors in the White Mountains uncover high-grade iron ore.', priority: 'INFORMATION' as const },
      { title: 'Bumper Harvest in Pelennor', message: 'Granaries are brimming with winter wheat surplus.', priority: 'BACKGROUND' as const },
      { title: 'Hostile Scout Pack Sighted', message: 'Warg riders spotted patrolling the frontiers of the Westfold.', priority: 'IMPORTANT' as const },
    ];
    const ev = randomEvents[Math.floor(Math.random() * randomEvents.length)];
    newNotifications.unshift({
      id: 'notif-event-' + Date.now(),
      timestamp: `Day ${day}, ${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
      priority: ev.priority,
      title: ev.title,
      message: ev.message,
    });
  }

  // Trim notifications to 25
  if (newNotifications.length > 25) {
    newNotifications.splice(25);
  }

  // Threat level evaluation
  const hostileArmiesNearCapital = updatedArmies.filter(
    (a) => a.faction === 'MORDOR' && a.x < 750 && a.x > 600 && a.y < 620 && a.y > 540
  );
  const threatLevel =
    hostileArmiesNearCapital.length > 0
      ? 'CRITICAL'
      : updatedCombats.length > 0
      ? 'HIGH'
      : 'MODERATE';

  return {
    ...state,
    tickCount,
    fps: Math.round(1 / Math.max(0.001, deltaSeconds)),
    age: state.age,
    year,
    season,
    day,
    hour,
    minute,
    resources: newResources,
    settlements: updatedSettlements,
    armies: updatedArmies,
    techTree: updatedTechTree,
    activeCombats: updatedCombats,
    notifications: newNotifications,
    threatLevel,
  };
}
