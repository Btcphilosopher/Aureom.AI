'use client';

import React from 'react';
import { Army, ArmyFormation, ArmyStance, Settlement } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import {
  Shield,
  Swords,
  Footprints,
  Eye,
  Flag,
  Hammer,
  Castle,
  Users,
  Compass,
  Zap,
} from 'lucide-react';

interface CommandPanelProps {
  selectedSettlement: Settlement | null;
  selectedArmy: Army | null;
  selectedArmyCount: number;
  onArmyOrder: (order: string) => void;
  onSetFormation: (formation: ArmyFormation) => void;
  onSetStance: (stance: ArmyStance) => void;
  onOpenBuildMode: () => void;
  onOpenRecruitModal: () => void;
  onDeselect: () => void;
}

export const CommandPanel: React.FC<CommandPanelProps> = ({
  selectedSettlement,
  selectedArmy,
  selectedArmyCount,
  onArmyOrder,
  onSetFormation,
  onSetStance,
  onOpenBuildMode,
  onOpenRecruitModal,
  onDeselect,
}) => {
  // If nothing is selected, render a minimal subtle bar
  if (!selectedSettlement && !selectedArmy && selectedArmyCount === 0) {
    return (
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pointer-events-auto">
        <div className="px-5 py-2 bg-[#0c0c0b]/90 border border-[#a68a53]/20 rounded-sm shadow-xl backdrop-blur-md flex items-center space-x-3 text-xs font-serif text-[#d4c5a9]/70">
          <div className="w-2 h-2 bg-[#a68a53]" />
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#a68a53]">
            Select a settlement or army on the map to issue strategic orders
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pointer-events-auto flex flex-col items-center">
      <div className="bg-[#0c0c0b]/95 border border-[#a68a53]/30 shadow-2xl rounded-sm p-2.5 backdrop-blur-md flex items-center space-x-4">
        {/* Entity Summary Badge */}
        <div className="flex flex-col pr-4 border-r border-[#a68a53]/20">
          <span className="text-xs font-serif font-bold tracking-wider text-[#d4c5a9]">
            {selectedSettlement
              ? selectedSettlement.name.toUpperCase()
              : selectedArmyCount > 1
              ? `${selectedArmyCount} ARMIES MULTI-SELECTED`
              : selectedArmy?.name.toUpperCase()}
          </span>
          <span className="text-[11px] font-serif text-[#d4c5a9]/60 italic">
            {selectedSettlement
              ? `Province of ${selectedSettlement.region} • Garrison: ${selectedSettlement.garrisonStrength.toLocaleString()}`
              : selectedArmy
              ? `${selectedArmy.commanderName} • ${selectedArmy.size.toLocaleString()} warriors`
              : 'Joint Strategic Task Force'}
          </span>
        </div>

        {/* Tactical Actions if Army is Selected */}
        {selectedArmy && (
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                onArmyOrder('MOVE');
                soundEngine.playTacticalClick();
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9] border border-[#a68a53]/40 rounded-sm text-[10px] uppercase tracking-widest transition-colors"
              title="Click ground to march army (or Right-Click on map)"
            >
              <Footprints className="w-3.5 h-3.5 text-[#a68a53]" />
              <span>March</span>
            </button>

            <button
              onClick={() => {
                onSetStance('AGGRESSIVE');
                soundEngine.playDrumStrike();
              }}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-sm text-[10px] uppercase tracking-widest transition-colors ${
                selectedArmy.stance === 'AGGRESSIVE'
                  ? 'bg-red-950/80 text-red-200 border border-red-700'
                  : 'bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9] border border-[#a68a53]/30'
              }`}
              title="Aggressive Assault Stance"
            >
              <Swords className="w-3.5 h-3.5 text-red-500" />
              <span>Attack</span>
            </button>

            <button
              onClick={() => {
                onSetStance('DEFENSIVE');
                soundEngine.playTacticalClick();
              }}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-sm text-[10px] uppercase tracking-widest transition-colors ${
                selectedArmy.stance === 'DEFENSIVE'
                  ? 'bg-[#1a2233] text-[#8fb9d4] border border-[#8fb9d4]/60'
                  : 'bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9] border border-[#a68a53]/30'
              }`}
              title="Hold ground and form shieldwall"
            >
              <Shield className="w-3.5 h-3.5 text-[#8fb9d4]" />
              <span>Defend</span>
            </button>

            <button
              onClick={() => {
                onSetStance('PATROL');
                soundEngine.playTacticalClick();
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm text-[10px] uppercase tracking-widest transition-colors"
              title="Patrol province roads"
            >
              <Eye className="w-3.5 h-3.5 text-[#a68a53]" />
              <span>Scout</span>
            </button>

            {/* Formations dropdown / quick toggles */}
            <div className="flex items-center space-x-1 pl-3 border-l border-[#a68a53]/20">
              {(['SHIELDWALL', 'WEDGE', 'LINE'] as ArmyFormation[]).map((form) => (
                <button
                  key={form}
                  onClick={() => {
                    onSetFormation(form);
                    soundEngine.playTacticalClick();
                  }}
                  className={`px-2 py-1 text-[9px] font-mono uppercase tracking-wider rounded-sm border transition-colors ${
                    selectedArmy.formation === form
                      ? 'bg-[#a68a53]/20 border-[#a68a53] text-[#d4c5a9] font-bold'
                      : 'border-[#a68a53]/20 text-[#a68a53]/70 hover:text-[#d4c5a9] hover:bg-[#a68a53]/5'
                  }`}
                >
                  {form}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Tactical Actions if Settlement is Selected */}
        {selectedSettlement && (
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                onOpenBuildMode();
                soundEngine.playTacticalClick();
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#a68a53]/20 hover:bg-[#a68a53]/30 text-[#d4c5a9] border border-[#a68a53]/60 rounded-sm text-[10px] font-serif uppercase tracking-widest font-bold transition-colors"
              title="Construct buildings & fortifications"
            >
              <Hammer className="w-3.5 h-3.5 text-[#a68a53]" />
              <span>Construction</span>
            </button>

            <button
              onClick={() => {
                onOpenRecruitModal();
                soundEngine.playTacticalClick();
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm text-[10px] font-serif uppercase tracking-widest transition-colors"
              title="Recruit regional regiments"
            >
              <Users className="w-3.5 h-3.5 text-[#8fb9d4]" />
              <span>Recruit Host</span>
            </button>

            <button
              onClick={() => {
                onArmyOrder('FORTIFY');
                soundEngine.playTacticalClick();
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm text-[10px] font-serif uppercase tracking-widest transition-colors"
              title="Reinforce garrison and gates"
            >
              <Castle className="w-3.5 h-3.5 text-[#a68a53]" />
              <span>Fortify (Lvl {selectedSettlement.wallsLevel})</span>
            </button>
          </div>
        )}

        {/* Deselect button */}
        <button
          onClick={() => {
            onDeselect();
            soundEngine.playTacticalClick();
          }}
          className="text-xs text-[#a68a53]/60 hover:text-[#d4c5a9] px-2 py-1 transition-colors"
          title="Clear Selection (Esc)"
        >
          ✕
        </button>
      </div>
    </div>
  );
};
