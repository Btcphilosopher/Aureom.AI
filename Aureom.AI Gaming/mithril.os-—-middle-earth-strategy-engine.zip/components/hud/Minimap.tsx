'use client';

import React, { useRef, useEffect } from 'react';
import { Army, CameraState, FactionId, Settlement } from '@/types/game';
import { FACTIONS_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import { ZoomIn, ZoomOut, Compass, Navigation } from 'lucide-react';

interface MinimapProps {
  settlements: Settlement[];
  armies: Army[];
  camera: CameraState;
  onCameraChange: (camera: CameraState) => void;
  playerFaction: FactionId;
}

export const Minimap: React.FC<MinimapProps> = ({
  settlements,
  armies,
  camera,
  onCameraChange,
  playerFaction,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Minimap world coordinates span roughly (100, 100) to (1000, 900)
  const WORLD_MIN_X = 100;
  const WORLD_MAX_X = 1050;
  const WORLD_MIN_Y = 100;
  const WORLD_MAX_Y = 920;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // 1. Clear background (Ancient dark obsidian)
    ctx.fillStyle = '#0c0c0b';
    ctx.fillRect(0, 0, w, h);

    // 2. Base coastline silhouette
    ctx.fillStyle = '#151412';
    ctx.beginPath();
    const mapX = (x: number) => ((x - WORLD_MIN_X) / (WORLD_MAX_X - WORLD_MIN_X)) * w;
    const mapY = (y: number) => ((y - WORLD_MIN_Y) / (WORLD_MAX_Y - WORLD_MIN_Y)) * h;

    ctx.moveTo(mapX(140), mapY(100));
    ctx.bezierCurveTo(mapX(240), mapY(200), mapX(200), mapY(380), mapX(260), mapY(500));
    ctx.bezierCurveTo(mapX(320), mapY(620), mapX(390), mapY(710), mapX(480), mapY(760));
    ctx.bezierCurveTo(mapX(550), mapY(800), mapX(600), mapY(880), mapX(650), mapY(920));
    ctx.lineTo(mapX(1050), mapY(920));
    ctx.lineTo(mapX(1050), mapY(100));
    ctx.closePath();
    ctx.fill();

    // Mordor shadow zone
    ctx.fillStyle = 'rgba(26, 24, 20, 0.75)';
    ctx.beginPath();
    ctx.moveTo(mapX(730), mapY(490));
    ctx.lineTo(mapX(950), mapY(495));
    ctx.lineTo(mapX(940), mapY(700));
    ctx.lineTo(mapX(720), mapY(690));
    ctx.closePath();
    ctx.fill();

    // 3. Mountain ridges (simplified dots)
    ctx.fillStyle = 'rgba(166, 138, 83, 0.4)';
    const mountainPasses = [
      [420, 120], [435, 180], [445, 240], [455, 300], [440, 360], [410, 420], // Misty
      [380, 490], [450, 530], [520, 560], [600, 575], // White
      [730, 520], [720, 580], [710, 640], [750, 690], // Ephel Duath
      [770, 490], [840, 490], [910, 495], // Ered Lithui
    ];
    mountainPasses.forEach(([mx, my]) => {
      ctx.fillRect(mapX(mx) - 1, mapY(my) - 1, 2, 2);
    });

    // 4. Settlements dots
    settlements.forEach((s) => {
      const sx = mapX(s.x);
      const sy = mapY(s.y);
      const faction = FACTIONS_DATA[s.faction];

      ctx.fillStyle = faction.accentColor;
      if (s.isCapital) {
        ctx.fillRect(sx - 2.5, sy - 2.5, 5, 5);
      } else {
        ctx.beginPath();
        ctx.arc(sx, sy, 2, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // 5. Armies markers
    armies.forEach((a) => {
      const ax = mapX(a.x);
      const ay = mapY(a.y);
      const isPlayer = a.faction === playerFaction;

      ctx.fillStyle = isPlayer ? '#8fb9d4' : '#ef4444';
      ctx.beginPath();
      ctx.arc(ax, ay, 2.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // 6. Camera Frustum / Viewport Box
    const camCenterScreenX = mapX(camera.x);
    const camCenterScreenY = mapY(camera.y);
    const boxW = Math.max(15, (w / camera.zoom) * 0.25);
    const boxH = Math.max(12, (h / camera.zoom) * 0.25);

    ctx.strokeStyle = '#a68a53';
    ctx.lineWidth = 1.2;
    ctx.strokeRect(camCenterScreenX - boxW / 2, camCenterScreenY - boxH / 2, boxW, boxH);

    // Center cross
    ctx.fillStyle = '#a68a53';
    ctx.fillRect(camCenterScreenX - 1, camCenterScreenY - 1, 2, 2);
  }, [settlements, armies, camera, playerFaction]);

  const handleMinimapClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const normX = clickX / canvas.width;
    const normY = clickY / canvas.height;

    const targetWorldX = WORLD_MIN_X + normX * (WORLD_MAX_X - WORLD_MIN_X);
    const targetWorldY = WORLD_MIN_Y + normY * (WORLD_MAX_Y - WORLD_MIN_Y);

    onCameraChange({
      ...camera,
      x: Math.round(targetWorldX),
      y: Math.round(targetWorldY),
    });
    soundEngine.playTacticalClick();
  };

  return (
    <div className="absolute left-4 bottom-4 z-20 flex flex-col bg-[#0c0c0b]/95 border border-[#a68a53]/20 shadow-2xl rounded-sm p-2 backdrop-blur-md">
      {/* Header bar with coordinates & zoom buttons */}
      <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-[#a68a53]/20 text-[10px] font-serif uppercase tracking-widest text-[#d4c5a9]">
        <div className="flex items-center space-x-1.5">
          <div className="w-1.5 h-1.5 bg-[#a68a53]" />
          <span>Sector Overview</span>
        </div>

        <div className="flex items-center space-x-1 text-[#a68a53]">
          <button
            onClick={() => {
              onCameraChange({ ...camera, zoom: Math.min(2.8, camera.zoom * 1.2) });
              soundEngine.playTacticalClick();
            }}
            title="Zoom In"
            className="p-0.5 hover:text-[#d4c5a9] hover:bg-[#a68a53]/10 rounded-sm"
          >
            <ZoomIn className="w-3 h-3" />
          </button>
          <button
            onClick={() => {
              onCameraChange({ ...camera, zoom: Math.max(0.4, camera.zoom * 0.8) });
              soundEngine.playTacticalClick();
            }}
            title="Zoom Out"
            className="p-0.5 hover:text-[#d4c5a9] hover:bg-[#a68a53]/10 rounded-sm"
          >
            <ZoomOut className="w-3 h-3" />
          </button>
          <button
            onClick={() => {
              onCameraChange({ ...camera, rotationDeg: 0, x: 550, y: 500, zoom: 1 });
              soundEngine.playTacticalClick();
            }}
            title="Reset View"
            className="p-0.5 hover:text-[#d4c5a9] hover:bg-[#a68a53]/10 rounded-sm"
          >
            <Navigation className="w-3 h-3" />
          </button>
        </div>
      </div>

      <canvas
        ref={canvasRef}
        width={190}
        height={135}
        onClick={handleMinimapClick}
        className="cursor-crosshair block rounded-sm border border-[#a68a53]/20 bg-[#151412]"
      />

      <div className="flex items-center justify-between pt-1.5 mt-1.5 border-t border-[#a68a53]/15 text-[9px] font-mono text-[#a68a53]/60">
        <span>X:{Math.round(camera.x)} Y:{Math.round(camera.y)}</span>
        <span>MAG: {(camera.zoom * 100).toFixed(0)}%</span>
      </div>
    </div>
  );
};
