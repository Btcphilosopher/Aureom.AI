'use client';

import React, { useState } from 'react';
import {
  AgeId,
  FactionId,
  GameResources,
  MapLayerId,
  ResourceRate,
  Season,
  WeatherType,
} from '@/types/game';
import { FACTIONS_DATA, AGES_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import {
  Play,
  Pause,
  FastForward,
  Layers,
  Search,
  BookOpen,
  Compass,
  Crown,
  Sparkles,
  Volume2,
  VolumeX,
  Eye,
  ShieldAlert,
  Flame,
  Wheat,
  Trees,
  Gem,
  Coins,
  Users,
  Mountain,
} from 'lucide-react';

interface TopBarProps {
  age: AgeId;
  year: number;
  season: Season;
  day: number;
  hour: number;
  minute: number;
  simulationSpeed: number;
  onSetSimulationSpeed: (speed: number) => void;
  playerFaction: FactionId;
  resources: GameResources;
  resourceRates: ResourceRate;
  activeLayer: MapLayerId;
  onSelectLayer: (layer: MapLayerId) => void;
  weather: WeatherType;
  threatLevel: string;
  onOpenModal: (
    modal: 'TECH' | 'DIPLOMACY' | 'HISTORY' | 'ATLAS' | 'SEARCH' | 'DEBUG' | 'RESOURCES' | 'POPULATION'
  ) => void;
  onToggleCinematic: () => void;
  isCinematic: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  age,
  year,
  season,
  day,
  hour,
  minute,
  simulationSpeed,
  onSetSimulationSpeed,
  playerFaction,
  resources,
  resourceRates,
  activeLayer,
  onSelectLayer,
  weather,
  threatLevel,
  onOpenModal,
  onToggleCinematic,
  isCinematic,
}) => {
  const [isLayerDropdownOpen, setIsLayerDropdownOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const faction = FACTIONS_DATA[playerFaction];
  const ageData = AGES_DATA[age];

  const toggleSound = () => {
    const next = !isMuted;
    setIsMuted(next);
    soundEngine.setMuted(next);
  };

  const layers: { id: MapLayerId; label: string }[] = [
    { id: 'TERRAIN', label: 'Terrain Elevation' },
    { id: 'POLITICAL', label: 'Sovereign Borders' },
    { id: 'MILITARY', label: 'Military & Threat Fronts' },
    { id: 'ECONOMIC', label: 'Economic Trade & Flows' },
    { id: 'TRADE', label: 'Caravan Corridors' },
    { id: 'POPULATION', label: 'Demographics & Cities' },
    { id: 'RESOURCES', label: 'Deposits & Mines' },
    { id: 'ROADS', label: 'Imperial Highways' },
    { id: 'DIPLOMACY', label: 'Geopolitical Stance' },
    { id: 'WEATHER', label: 'Weather & Ash Plumes' },
    { id: 'HISTORY', label: 'Ancient Battlegrounds' },
  ];

  return (
    <header className="relative z-30 w-full flex flex-col pointer-events-auto select-none border-b border-[#a68a53]/20 bg-[#0c0c0b]/85 backdrop-blur-md text-[#d4c5a9]">
      {/* Upper Tier: Imperial Time, Chronicle, Faction Crest & Navigation Tools */}
      <div className="flex items-center justify-between px-6 py-2 border-b border-[#a68a53]/20">
        {/* Left: Chronicle, Age & Time */}
        <div className="flex items-center space-x-6">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-[0.3em] text-[#a68a53] font-bold">Chronicle</span>
            <span className="font-serif italic text-lg leading-tight text-[#d4c5a9]">
              {ageData.name} • Year {year}
            </span>
          </div>

          <div className="h-8 w-[1px] bg-[#a68a53]/20" />

          {/* Temporal & Simulation Controls */}
          <div className="flex items-center space-x-4 bg-[#1a1814] px-3.5 py-1.5 rounded-sm border border-[#a68a53]/20">
            <div className="flex items-center space-x-2 text-xs font-serif italic text-[#d4c5a9]">
              <span className="uppercase text-[10px] tracking-widest text-[#a68a53] font-bold not-italic">
                {season}
              </span>
              <span>•</span>
              <span className="font-mono text-[11px] not-italic text-[#d4c5a9]/80">
                Day {day}
              </span>
              <span>•</span>
              <span className="font-mono text-[11px] font-semibold not-italic text-[#d4c5a9]">
                {hour.toString().padStart(2, '0')}:{minute.toString().padStart(2, '0')}
              </span>
            </div>

            {/* Time Controls */}
            <div className="flex items-center space-x-1 pl-3 border-l border-[#a68a53]/20">
              <button
                onClick={() => {
                  onSetSimulationSpeed(simulationSpeed === 0 ? 1 : 0);
                  soundEngine.playTacticalClick();
                }}
                title="Pause/Play Simulation (Space)"
                className={`p-1 rounded-sm transition-colors ${
                  simulationSpeed === 0
                    ? 'bg-[#a68a53] text-[#0c0c0b]'
                    : 'text-[#a68a53]/70 hover:text-[#d4c5a9] hover:bg-[#a68a53]/10'
                }`}
              >
                {simulationSpeed === 0 ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
              </button>

              {[1, 2, 4, 8].map((spd) => (
                <button
                  key={spd}
                  onClick={() => {
                    onSetSimulationSpeed(spd);
                    soundEngine.playTacticalClick();
                  }}
                  className={`px-1.5 py-0.5 text-[10px] font-mono rounded-sm transition-colors ${
                    simulationSpeed === spd
                      ? 'bg-[#a68a53]/20 text-[#d4c5a9] border border-[#a68a53]/50 font-bold'
                      : 'text-[#a68a53]/60 hover:text-[#d4c5a9] hover:bg-[#a68a53]/5'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Threat Alert, Command Search & Faction Crest */}
        <div className="flex items-center space-x-5">
          {/* Threat Indicator */}
          <div
            className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-sm text-[10px] uppercase tracking-widest font-serif border ${
              threatLevel === 'CRITICAL'
                ? 'bg-red-950/60 border-red-800 text-red-300 animate-pulse'
                : threatLevel === 'HIGH'
                ? 'bg-[#2d1b10]/60 border-[#a68a53]/60 text-[#f5cca0]'
                : 'bg-[#151a14]/60 border-emerald-900/60 text-emerald-400'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Threat: {threatLevel}</span>
          </div>

          {/* Quick Command Palette Button */}
          <button
            onClick={() => {
              onOpenModal('SEARCH');
              soundEngine.playTacticalClick();
            }}
            title="Search World or Press /"
            className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-[#d4c5a9]/80 hover:text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm text-[10px] font-mono uppercase tracking-wider transition-colors"
          >
            <Search className="w-3 h-3 text-[#a68a53]" />
            <span className="hidden sm:inline">Search ( / )</span>
          </button>

          {/* Mute Audio */}
          <button
            onClick={toggleSound}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            className="p-1.5 text-[#a68a53]/70 hover:text-[#d4c5a9] hover:bg-[#a68a53]/10 border border-[#a68a53]/20 rounded-sm transition-colors"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Cinematic Mode */}
          <button
            onClick={onToggleCinematic}
            title="Cinematic Camera Mode (Hide HUD)"
            className={`p-1.5 rounded-sm border transition-colors ${
              isCinematic
                ? 'bg-[#a68a53] text-[#0c0c0b] border-[#a68a53]'
                : 'border-[#a68a53]/20 text-[#a68a53]/70 hover:text-[#d4c5a9] hover:bg-[#a68a53]/10'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
          </button>

          {/* Dev / Architect Panel */}
          <button
            onClick={() => {
              onOpenModal('DEBUG');
              soundEngine.playTacticalClick();
            }}
            title="Architect Telemetry & Debug"
            className="px-2 py-1 text-[9px] font-mono bg-[#1a1814] text-[#a68a53] hover:text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm uppercase tracking-wider"
          >
            Dev
          </button>

          <div className="h-8 w-[1px] bg-[#a68a53]/20" />

          {/* Sovereign Faction Crest Block */}
          <div className="flex items-center space-x-3">
            <div className="flex flex-col items-end">
              <span className="text-[10px] uppercase tracking-widest text-[#a68a53] font-bold">
                {faction.name}
              </span>
              <span className="text-xs opacity-60 italic font-serif">
                {faction.leaderTitle}
              </span>
            </div>
            <div className="w-9 h-9 border border-[#a68a53]/40 rounded-sm flex items-center justify-center bg-[#1a1814] shadow-sm">
              <div
                className="w-4 h-5 border border-[#d4c5a9]/30 relative rounded-[1px]"
                style={{ backgroundColor: faction.accentColor }}
              >
                <div className="absolute top-0.5 left-0.5 w-2.5 h-0.5 bg-[#d4c5a9]/40" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lower Tier: Imperial Resources Bar & Map Layer Selector */}
      <div className="flex items-center justify-between px-6 py-1.5 bg-[#0c0c0b]/95 text-xs">
        {/* Left: Resource Group */}
        <div className="flex items-center space-x-6 overflow-x-auto py-0.5">
          {/* FOOD */}
          <div
            onClick={() => onOpenModal('RESOURCES')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-2 py-0.5 rounded-sm transition-colors"
            title="Grain & Rations"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Food</span>
            <span className="font-mono text-sm text-[#d4c5a9]">
              {resources.food.toLocaleString()}{' '}
              <span className="text-[10px] text-green-500 font-mono">+{resourceRates.food}</span>
            </span>
          </div>

          {/* WOOD */}
          <div
            onClick={() => onOpenModal('RESOURCES')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-2 py-0.5 rounded-sm transition-colors"
            title="Timber for fortifications & siege"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Timber</span>
            <span className="font-mono text-sm text-[#d4c5a9]">
              {resources.wood.toLocaleString()}{' '}
              <span className="text-[10px] text-green-500 font-mono">+{resourceRates.wood}</span>
            </span>
          </div>

          {/* STONE */}
          <div
            onClick={() => onOpenModal('RESOURCES')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-2 py-0.5 rounded-sm transition-colors"
            title="Quarried stone for walls"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Stone</span>
            <span className="font-mono text-sm text-[#d4c5a9]">
              {resources.stone.toLocaleString()}{' '}
              <span className="text-[10px] text-slate-500 font-mono">+{resourceRates.stone}</span>
            </span>
          </div>

          {/* IRON */}
          <div
            onClick={() => onOpenModal('RESOURCES')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-2 py-0.5 rounded-sm transition-colors"
            title="Iron for swords & armor"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Iron</span>
            <span className="font-mono text-sm text-[#d4c5a9]">
              {resources.iron.toLocaleString()}{' '}
              <span className="text-[10px] text-green-500 font-mono">+{resourceRates.iron}</span>
            </span>
          </div>

          {/* GOLD */}
          <div
            onClick={() => onOpenModal('RESOURCES')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-2 py-0.5 rounded-sm transition-colors"
            title="Treasury"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Gold</span>
            <span className="font-mono text-sm text-[#d4c5a9]">
              {resources.gold.toLocaleString()}{' '}
              <span className="text-[10px] text-green-500 font-mono">+{resourceRates.gold}</span>
            </span>
          </div>

          {/* MITHRIL */}
          <div
            onClick={() => onOpenModal('RESOURCES')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-2 py-0.5 rounded-sm transition-colors"
            title="True-silver / Mithril"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Mithril</span>
            <span className="font-mono text-sm text-[#8fb9d4] font-semibold">
              {resources.mithril.toLocaleString()}
            </span>
          </div>

          {/* POPULATION */}
          <div
            onClick={() => onOpenModal('POPULATION')}
            className="flex flex-col items-center cursor-pointer hover:bg-[#a68a53]/5 px-3 py-0.5 border-l border-[#a68a53]/15 rounded-sm transition-colors"
            title="Kingdom Demographics"
          >
            <span className="text-[9px] uppercase tracking-widest text-[#a68a53]/60 font-bold">Population</span>
            <span className="font-mono text-sm text-[#d4c5a9]">
              38,400 <span className="text-[10px] text-[#a68a53]/70 font-sans">/ 50k</span>
            </span>
          </div>
        </div>

        {/* Right: Map Layers & Global Modal Shortcuts */}
        <div className="flex items-center space-x-3">
          {/* Layer Selector */}
          <div className="relative">
            <button
              onClick={() => setIsLayerDropdownOpen(!isLayerDropdownOpen)}
              className="flex items-center space-x-2 px-3 py-1.5 border border-[#a68a53]/20 bg-[#a68a53]/5 hover:bg-[#a68a53]/10 rounded-sm text-xs font-serif tracking-wider text-[#d4c5a9] transition-colors"
            >
              <div className="w-2 h-2 bg-[#a68a53]" />
              <span className="uppercase text-[10px] tracking-[0.2em] font-bold">LAYER: {activeLayer}</span>
            </button>

            {isLayerDropdownOpen && (
              <div className="absolute right-0 top-full mt-1 w-56 bg-[#0c0c0b] border border-[#a68a53]/30 rounded-sm shadow-2xl z-50 py-1 backdrop-blur-md">
                <div className="px-3 py-1.5 text-[9px] font-sans uppercase text-[#a68a53] tracking-[0.3em] font-bold border-b border-[#a68a53]/20">
                  Strategic Layers
                </div>
                {layers.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => {
                      onSelectLayer(l.id);
                      setIsLayerDropdownOpen(false);
                      soundEngine.playParchmentPage();
                    }}
                    className={`w-full text-left px-3 py-1.5 text-xs font-serif flex items-center justify-between transition-colors ${
                      activeLayer === l.id
                        ? 'bg-[#a68a53]/15 text-[#d4c5a9] font-bold'
                        : 'text-[#d4c5a9]/70 hover:bg-[#a68a53]/10 hover:text-[#d4c5a9]'
                    }`}
                  >
                    <span>{l.label}</span>
                    {activeLayer === l.id ? (
                      <div className="w-2 h-2 bg-[#a68a53]" />
                    ) : (
                      <div className="w-2 h-2 border border-[#a68a53]/40" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quick System Buttons */}
          <div className="flex items-center space-x-1.5 pl-3 border-l border-[#a68a53]/20">
            <button
              onClick={() => {
                onOpenModal('TECH');
                soundEngine.playParchmentPage();
              }}
              title="Lore & Inventions"
              className="px-2.5 py-1 text-[10px] font-serif uppercase tracking-widest hover:bg-[#a68a53]/10 text-[#d4c5a9] rounded-sm border border-[#a68a53]/20 transition-colors"
            >
              Lore
            </button>

            <button
              onClick={() => {
                onOpenModal('DIPLOMACY');
                soundEngine.playParchmentPage();
              }}
              title="Geopolitical Diplomacy"
              className="px-2.5 py-1 text-[10px] font-serif uppercase tracking-widest hover:bg-[#a68a53]/10 text-[#d4c5a9] rounded-sm border border-[#a68a53]/20 transition-colors"
            >
              Diplomacy
            </button>

            <button
              onClick={() => {
                onOpenModal('HISTORY');
                soundEngine.playParchmentPage();
              }}
              title="Chronicles of Middle-earth"
              className="px-2.5 py-1 text-[10px] font-serif uppercase tracking-widest hover:bg-[#a68a53]/10 text-[#d4c5a9] rounded-sm border border-[#a68a53]/20 transition-colors"
            >
              Chronicle
            </button>

            <button
              onClick={() => {
                onOpenModal('ATLAS');
                soundEngine.playParchmentPage();
              }}
              title="Royal World Atlas"
              className="px-2.5 py-1 text-[10px] font-serif uppercase tracking-widest hover:bg-[#a68a53]/10 text-[#d4c5a9] rounded-sm border border-[#a68a53]/20 transition-colors"
            >
              Atlas
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
