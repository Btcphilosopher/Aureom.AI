'use client';

import React from 'react';
import { GameNotification } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import { ShieldAlert, Info, Bell, Swords, X, ArrowRight } from 'lucide-react';

interface NotificationStreamProps {
  notifications: GameNotification[];
  onDismiss: (id: string) => void;
  onJumpToLocation: (x: number, y: number) => void;
}

export const NotificationStream: React.FC<NotificationStreamProps> = ({
  notifications,
  onDismiss,
  onJumpToLocation,
}) => {
  if (notifications.length === 0) return null;

  return (
    <div className="absolute left-4 top-20 z-20 pointer-events-auto flex flex-col space-y-2 max-w-sm">
      {notifications.slice(0, 4).map((notif) => {
        const isCritical = notif.priority === 'CRITICAL';
        const isImportant = notif.priority === 'IMPORTANT';

        return (
          <div
            key={notif.id}
            className={`p-3 rounded-sm border shadow-xl backdrop-blur-md transition-all duration-300 ${
              isCritical
                ? 'bg-[#200e0e]/92 border-red-800 text-red-200'
                : isImportant
                ? 'bg-[#1e170e]/92 border-[#a68a53]/60 text-[#f5cca0]'
                : 'bg-[#0c0c0b]/92 border-[#a68a53]/25 text-[#d4c5a9]'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2">
                {isCritical ? (
                  <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
                ) : isImportant ? (
                  <Swords className="w-4 h-4 text-[#a68a53]" />
                ) : (
                  <Info className="w-4 h-4 text-[#8fb9d4]" />
                )}
                <span className="text-[11px] font-serif uppercase tracking-wider font-bold">
                  {notif.title}
                </span>
              </div>

              <button
                onClick={() => {
                  onDismiss(notif.id);
                  soundEngine.playTacticalClick();
                }}
                className="text-[#a68a53]/60 hover:text-[#d4c5a9] p-0.5 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-xs font-serif mt-1.5 leading-relaxed text-[#d4c5a9]/80 italic">
              {notif.message}
            </p>

            <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-[#a68a53]/15 text-[10px] font-mono text-[#a68a53]/70">
              <span>{notif.timestamp}</span>

              {notif.x !== undefined && notif.y !== undefined && (
                <button
                  onClick={() => {
                    onJumpToLocation(notif.x!, notif.y!);
                    soundEngine.playTacticalClick();
                  }}
                  className="flex items-center space-x-1 text-[#a68a53] hover:text-[#d4c5a9] font-serif uppercase tracking-wider text-[9px] font-bold transition-colors"
                >
                  <span>Locate</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
