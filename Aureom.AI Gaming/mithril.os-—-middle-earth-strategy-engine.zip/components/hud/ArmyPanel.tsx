'use client';

import React, { useState } from 'react';
import { Army, ArmyFormation, ArmyStance } from '@/types/game';
import { FACTIONS_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import {
  Shield,
  Swords,
  Heart,
  Zap,
  TrendingUp,
  X,
  Compass,
  Footprints,
  Award,
  Package,
} from 'lucide-react';

interface ArmyPanelProps {
  army: Army;
  onClose: () => void;
  onSetFormation: (formation: ArmyFormation) => void;
  onSetStance: (stance: ArmyStance) => void;
  onFocusCoordinates: (x: number, y: number) => void;
}

export const ArmyPanel: React.FC<ArmyPanelProps> = ({
  army,
  onClose,
  onSetFormation,
  onSetStance,
  onFocusCoordinates,
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'ROSTER' | 'SUPPLY' | 'TACTICS'>('OVERVIEW');
  const faction = FACTIONS_DATA[army.faction];

  return (
    <aside className="absolute right-4 top-20 bottom-20 w-96 z-20 pointer-events-auto flex flex-col bg-[#0c0c0b]/90 border border-[#a68a53]/20 shadow-2xl rounded-sm backdrop-blur-md overflow-hidden text-[#d4c5a9]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#a68a53]/20 bg-[#0c0c0b]/70">
        <div className="flex items-center space-x-3">
          <div
            className="w-3 h-3 rounded-full ring-1 ring-[#a68a53]/40"
            style={{ backgroundColor: faction.accentColor }}
          />
          <div>
            <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] font-bold">
              Host Deployment
            </div>
            <div className="font-serif italic text-lg leading-tight text-[#d4c5a9]">
              {army.name}
            </div>
            <div className="text-[10px] font-serif italic text-[#d4c5a9]/60">
              Commander: {army.commanderName}
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1 hover:bg-[#a68a53]/10 rounded-sm text-[#a68a53]/60 hover:text-[#d4c5a9] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center border-b border-[#a68a53]/20 bg-[#0c0c0b] px-2 text-[10px] font-serif uppercase tracking-wider">
        {(['OVERVIEW', 'ROSTER', 'SUPPLY', 'TACTICS'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              soundEngine.playTacticalClick();
            }}
            className={`px-3 py-2 transition-colors border-b-2 ${
              activeTab === tab
                ? 'border-[#a68a53] text-[#d4c5a9] font-bold bg-[#1a1814]'
                : 'border-transparent text-[#a68a53]/60 hover:text-[#d4c5a9]'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-3">
            {/* Core Metrics Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Swords className="w-3 h-3 text-red-500" />
                  <span>Host Strength</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {army.size.toLocaleString()}
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-serif italic">Warriors & Auxiliaries</div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Heart className="w-3 h-3 text-[#a68a53]" />
                  <span>Morale & Valour</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {army.morale}%
                </div>
                <div className="w-full bg-[#0c0c0b] h-1.5 rounded-none overflow-hidden border border-[#a68a53]/30 mt-1.5">
                  <div
                    className="bg-[#a68a53] h-full"
                    style={{ width: `${army.morale}%` }}
                  />
                </div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Package className="w-3 h-3 text-[#a68a53]" />
                  <span>Supply Status</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {army.supplyDays ?? Math.round(army.supply / 3)} Days
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-serif italic">Grain, forage & water</div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Footprints className="w-3 h-3 text-[#8fb9d4]" />
                  <span>March Pace</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {army.movementSpeed} leagues/day
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-mono">Formation: {army.formation}</div>
              </div>
            </div>

            {/* Strategic Directive */}
            <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-1 font-bold">
                Tactical Orders & Objective
              </div>
              <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic">
                &ldquo;{army.objective || 'Guarding strategic frontiers and securing regional supply lanes.'}&rdquo;
              </p>
              {army.targetX !== undefined && (
                <div className="mt-2 text-[10px] font-mono text-[#a68a53]">
                  ● Marching to coordinates ({army.targetX}, {army.targetY})
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'ROSTER' && (
          <div className="space-y-2">
            <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-1 font-bold">
              Regimental Muster Roll
            </div>
            {army.units.map((unit) => (
              <div
                key={unit.id}
                className="p-2.5 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm text-xs"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-serif font-bold text-[#d4c5a9]">{unit.name}</span>
                    <div className="text-[10px] font-serif italic text-[#a68a53]/70">
                      {unit.category || unit.type} • Tier {unit.tier || 1}
                    </div>
                  </div>
                  <span className="font-mono font-bold text-[#d4c5a9]">
                    {unit.count.toLocaleString()}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1 mt-2 text-[9px] font-mono text-[#a68a53]/70">
                  <div>ATK: {unit.attack ?? 14}</div>
                  <div>DEF: {unit.defence ?? 12}</div>
                  <div>ARM: {unit.armor ?? 8}</div>
                </div>

                {(unit.veterancy ?? unit.experience ?? 0) > 0 && (
                  <div className="flex items-center space-x-1 mt-1.5 text-[9px] text-[#a68a53] font-mono">
                    <Award className="w-3 h-3" />
                    <span>Rank {unit.veterancy ?? unit.experience} Veterans</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'TACTICS' && (
          <div className="space-y-3">
            <div>
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-2 font-bold">
                Battle Formation
              </div>
              <div className="grid grid-cols-2 gap-2">
                {(['LINE', 'WEDGE', 'SQUARE', 'SHIELDWALL', 'ECHELON', 'COLUMN'] as ArmyFormation[]).map(
                  (form) => (
                    <button
                      key={form}
                      onClick={() => {
                        onSetFormation(form);
                        soundEngine.playTacticalClick();
                      }}
                      className={`p-2 text-xs font-serif uppercase tracking-wider rounded-sm border text-left transition-colors ${
                        army.formation === form
                          ? 'bg-[#a68a53]/20 border-[#a68a53] text-[#d4c5a9] font-bold'
                          : 'bg-[#1a1814] border-[#a68a53]/20 text-[#a68a53]/70 hover:text-[#d4c5a9]'
                      }`}
                    >
                      {form}
                    </button>
                  )
                )}
              </div>
            </div>

            <div>
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-2 font-bold">
                Doctrinal Stance
              </div>
              <div className="grid grid-cols-2 gap-2">
                {(['AGGRESSIVE', 'DEFENSIVE', 'PATROL', 'RAID', 'RETREAT'] as ArmyStance[]).map(
                  (stance) => (
                    <button
                      key={stance}
                      onClick={() => {
                        onSetStance(stance);
                        soundEngine.playTacticalClick();
                      }}
                      className={`p-2 text-xs font-serif uppercase tracking-wider rounded-sm border text-left transition-colors ${
                        army.stance === stance
                          ? 'bg-[#a68a53]/20 border-[#a68a53] text-[#d4c5a9] font-bold'
                          : 'bg-[#1a1814] border-[#a68a53]/20 text-[#a68a53]/70 hover:text-[#d4c5a9]'
                      }`}
                    >
                      {stance}
                    </button>
                  )
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Center Button */}
      <div className="p-3 border-t border-[#a68a53]/20 bg-[#0c0c0b]/80 flex justify-end">
        <button
          onClick={() => {
            onFocusCoordinates(army.x, army.y);
            soundEngine.playTacticalClick();
          }}
          className="px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm transition-colors"
        >
          Center Camera
        </button>
      </div>
    </aside>
  );
};
