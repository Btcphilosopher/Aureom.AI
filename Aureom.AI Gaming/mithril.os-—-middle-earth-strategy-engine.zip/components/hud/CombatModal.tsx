'use client';

import React, { useState } from 'react';
import { ActiveCombat } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import {
  Swords,
  Shield,
  Heart,
  Skull,
  TrendingDown,
  X,
  Flame,
  Flag,
  Zap,
} from 'lucide-react';

interface CombatModalProps {
  combat: ActiveCombat;
  onClose: () => void;
  onTacticalCommand: (command: string) => void;
}

export const CombatModal: React.FC<CombatModalProps> = ({
  combat,
  onClose,
  onTacticalCommand,
}) => {
  const [combatLog, setCombatLog] = useState<string[]>([
    'Vanguard skirmishers exchange lethal volleys across the riverbank.',
    'Heavy infantry ranks lock shields in standard formation.',
    'Commander inspires front-line battalions to hold the crest.',
  ]);

  const handleTactic = (cmd: string) => {
    onTacticalCommand(cmd);
    soundEngine.playDrumStrike();
    setCombatLog((prev) => [
      `[ORDER: ${cmd}] Front-line executed maneuver with discipline.`,
      ...prev.slice(0, 4),
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div className="relative w-full max-w-2xl bg-[#0f1218] border border-[#a88e5e]/50 shadow-2xl rounded-sm text-[#d4cbba] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#292f3d] bg-[#141822]">
          <div className="flex items-center space-x-2">
            <Swords className="w-5 h-5 text-[#ef4444]" />
            <div>
              <div className="text-sm font-display font-bold tracking-widest text-[#f5eedf]">
                FIELD OF ENGAGEMENT — TACTICAL COMMAND
              </div>
              <div className="text-[10px] font-archival italic text-[#959eb0]">
                Terrain: {combat.terrainType} • Weather: Clear • Visibility: 12 leagues
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#202534] rounded text-[#818a9c] hover:text-[#f0eae0]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Armies Matchup Bar */}
        <div className="p-5 space-y-5">
          <div className="grid grid-cols-2 gap-4">
            {/* Attacker Forces */}
            <div className="p-3.5 bg-[#141822] border border-[#2c3344] rounded-sm">
              <div className="text-xs font-display font-bold text-[#e6ded0]">
                {(combat.attackerArmyName || 'ATTACKING HOST').toUpperCase()}
              </div>
              <div className="text-[10px] font-archival text-[#9ca5b6] italic mb-3">
                Commanding: High Captain of the Realm
              </div>

              {/* Morale bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-data">
                  <span className="flex items-center space-x-1">
                    <Heart className="w-3 h-3 text-[#10b981]" />
                    <span>MORALE</span>
                  </span>
                  <span className="font-bold text-[#10b981]">{combat.attackerMorale}%</span>
                </div>
                <div className="w-full bg-[#0c0e12] h-2 rounded-full overflow-hidden border border-[#2b303d]">
                  <div
                    className="bg-[#10b981] h-full transition-all duration-300"
                    style={{ width: `${combat.attackerMorale}%` }}
                  />
                </div>
              </div>

              {/* Casualties */}
              <div className="flex items-center justify-between text-[11px] font-data text-[#ef4444] mt-3 pt-2 border-t border-[#252b3a]">
                <span className="flex items-center space-x-1">
                  <Skull className="w-3 h-3" />
                  <span>CASUALTIES</span>
                </span>
                <span className="font-bold">-{combat.attackerCasualties.toLocaleString()}</span>
              </div>
            </div>

            {/* Defender Forces */}
            <div className="p-3.5 bg-[#141822] border border-[#2c3344] rounded-sm">
              <div className="text-xs font-display font-bold text-[#e6ded0]">
                {(combat.defenderArmyName || 'DEFENDING HOST').toUpperCase()}
              </div>
              <div className="text-[10px] font-archival text-[#9ca5b6] italic mb-3">
                Commanding: Chieftain of Mordor
              </div>

              {/* Morale bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-data">
                  <span className="flex items-center space-x-1">
                    <Heart className="w-3 h-3 text-[#ef4444]" />
                    <span>MORALE</span>
                  </span>
                  <span className="font-bold text-[#ef4444]">{combat.defenderMorale}%</span>
                </div>
                <div className="w-full bg-[#0c0e12] h-2 rounded-full overflow-hidden border border-[#2b303d]">
                  <div
                    className="bg-[#ef4444] h-full transition-all duration-300"
                    style={{ width: `${combat.defenderMorale}%` }}
                  />
                </div>
              </div>

              {/* Casualties */}
              <div className="flex items-center justify-between text-[11px] font-data text-[#ef4444] mt-3 pt-2 border-t border-[#252b3a]">
                <span className="flex items-center space-x-1">
                  <Skull className="w-3 h-3" />
                  <span>CASUALTIES</span>
                </span>
                <span className="font-bold">-{combat.defenderCasualties.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Combat Log */}
          <div className="p-3 bg-[#0d0f14] border border-[#252b39] rounded-sm">
            <div className="text-[10px] font-display text-[#a88e5e] mb-1 font-semibold tracking-wider">
              BATTLEFIELD DISPATCHES
            </div>
            <div className="space-y-1 text-xs font-archival text-[#a9a293] italic">
              {combatLog.map((log, i) => (
                <div key={i} className="leading-snug">
                  • {log}
                </div>
              ))}
            </div>
          </div>

          {/* Tactical Orders Bar */}
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => handleTactic('ALL-OUT CHARGE')}
              className="p-2.5 bg-[#7f1d1d]/40 hover:bg-[#7f1d1d]/70 text-[#fca5a5] border border-[#ef4444]/60 rounded text-xs font-display font-bold flex flex-col items-center justify-center space-y-1 transition-colors"
            >
              <Swords className="w-4 h-4" />
              <span>CHARGE</span>
            </button>

            <button
              onClick={() => handleTactic('ARROW RAIN VOLLEY')}
              className="p-2.5 bg-[#1e3a8a]/40 hover:bg-[#1e3a8a]/70 text-[#93c5fd] border border-[#3b82f6]/60 rounded text-xs font-display font-bold flex flex-col items-center justify-center space-y-1 transition-colors"
            >
              <Zap className="w-4 h-4" />
              <span>ARROW VOLLEY</span>
            </button>

            <button
              onClick={() => handleTactic('LOCK SHIELDWALL')}
              className="p-2.5 bg-[#14532d]/40 hover:bg-[#14532d]/70 text-[#86efac] border border-[#22c55e]/60 rounded text-xs font-display font-bold flex flex-col items-center justify-center space-y-1 transition-colors"
            >
              <Shield className="w-4 h-4" />
              <span>SHIELDWALL</span>
            </button>

            <button
              onClick={() => handleTactic('TACTICAL WITHDRAWAL')}
              className="p-2.5 bg-[#374151]/40 hover:bg-[#374151]/70 text-[#d1d5db] border border-[#6b7280]/60 rounded text-xs font-display font-bold flex flex-col items-center justify-center space-y-1 transition-colors"
            >
              <Flag className="w-4 h-4" />
              <span>RETREAT</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#292f3d] bg-[#12161f] flex justify-between items-center text-xs">
          <span className="text-[10px] font-data text-[#8890a0]">
            Duration: {combat.durationTicks * 4} minutes
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#a88e5e] hover:bg-[#c2a670] text-[#0f1115] font-display font-bold text-xs rounded transition-colors"
          >
            DISMISS REPORT
          </button>
        </div>
      </div>
    </div>
  );
};
