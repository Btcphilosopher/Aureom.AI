'use client';

import React, { useState } from 'react';
import { GameResources, Settlement } from '@/types/game';
import { FACTIONS_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import {
  Castle,
  Users,
  Wheat,
  Coins,
  Shield,
  Hammer,
  TrendingUp,
  X,
  Clock,
  Plus,
  ArrowRight,
} from 'lucide-react';

interface SettlementPanelProps {
  settlement: Settlement;
  onClose: () => void;
  onQueueBuilding: (buildingType: string) => void;
  playerResources: GameResources;
  onFocusCoordinates: (x: number, y: number) => void;
}

export const SettlementPanel: React.FC<SettlementPanelProps> = ({
  settlement,
  onClose,
  onQueueBuilding,
  playerResources,
  onFocusCoordinates,
}) => {
  const [activeTab, setActiveTab] = useState<
    'OVERVIEW' | 'BUILDINGS' | 'MILITARY' | 'ECONOMY' | 'TRADE' | 'HISTORY'
  >('OVERVIEW');

  const faction = FACTIONS_DATA[settlement.faction];

  const availableStructures = [
    { id: 'farm', name: 'Terraced Valley Farms', cost: { wood: 150, food: 80 }, desc: '+35 Food/min' },
    { id: 'barracks', name: 'Royal Guard Barracks', cost: { stone: 200, iron: 120 }, desc: 'Recruits heavy infantry' },
    { id: 'armoury', name: 'Blacksmith Armoury', cost: { iron: 250, wood: 100 }, desc: '+20% Garrison attack' },
    { id: 'watchtower', name: 'Stone Beacon Bastion', cost: { stone: 180, gold: 80 }, desc: '+15 Defence, extended sight' },
  ];

  return (
    <aside className="absolute right-4 top-20 bottom-20 w-96 z-20 pointer-events-auto flex flex-col bg-[#0c0c0b]/90 border border-[#a68a53]/20 shadow-2xl rounded-sm backdrop-blur-md overflow-hidden text-[#d4c5a9]">
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#a68a53]/20 bg-[#0c0c0b]/70">
        <div className="flex items-center space-x-3">
          <div
            className="w-3 h-3 rounded-full ring-1 ring-[#a68a53]/40"
            style={{ backgroundColor: faction.accentColor }}
          />
          <div>
            <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] font-bold">
              Tactical Assessment
            </div>
            <div className="font-serif italic text-lg leading-tight text-[#d4c5a9]">
              {settlement.name}
            </div>
            <div className="text-[10px] font-serif italic text-[#d4c5a9]/60">
              {settlement.region} • {settlement.isCapital ? 'Crown Capital' : 'Fortified Township'}
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1 hover:bg-[#a68a53]/10 rounded-sm text-[#a68a53]/60 hover:text-[#d4c5a9] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center border-b border-[#a68a53]/20 bg-[#0c0c0b] px-2 text-[10px] font-serif uppercase tracking-wider">
        {(['OVERVIEW', 'BUILDINGS', 'MILITARY', 'ECONOMY', 'TRADE', 'HISTORY'] as const).map(
          (tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                soundEngine.playTacticalClick();
              }}
              className={`px-2.5 py-2 transition-colors border-b-2 ${
                activeTab === tab
                  ? 'border-[#a68a53] text-[#d4c5a9] font-bold bg-[#1a1814]'
                  : 'border-transparent text-[#a68a53]/60 hover:text-[#d4c5a9]'
              }`}
            >
              {tab}
            </button>
          )
        )}
      </div>

      {/* Tab Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-3">
            {/* Key Statistics Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Users className="w-3 h-3 text-[#a68a53]" />
                  <span>Population</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {settlement.population.toLocaleString()}
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-mono">Cap: {settlement.maxPopulation.toLocaleString()}</div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Shield className="w-3 h-3 text-[#8fb9d4]" />
                  <span>Defence</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {settlement.defence} / 100
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-serif italic">Walls: Tier {settlement.wallsLevel} Ashlar</div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Coins className="w-3 h-3 text-[#a68a53]" />
                  <span>Treasury</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  +{settlement.wealth.toLocaleString()} gold
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-serif italic">Trade & Royal Tax</div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="flex items-center space-x-1.5 text-[#a68a53] text-[9px] uppercase font-bold tracking-widest">
                  <Castle className="w-3 h-3 text-[#a68a53]" />
                  <span>Garrison</span>
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d4c5a9]">
                  {settlement.garrisonStrength.toLocaleString()}
                </div>
                <div className="text-[9px] text-[#a68a53]/60 font-serif italic">Ready at gates</div>
              </div>
            </div>

            {/* Construction Queue */}
            <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
              <div className="flex items-center justify-between text-[10px] font-serif uppercase tracking-widest text-[#a68a53] mb-2 font-bold">
                <div className="flex items-center space-x-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Works In Progress</span>
                </div>
                <span className="text-[9px] font-mono text-[#d4c5a9]/60">
                  {settlement.constructionQueue.length} Active
                </span>
              </div>

              {settlement.constructionQueue.length > 0 ? (
                <div className="space-y-2">
                  {settlement.constructionQueue.map((item) => (
                    <div key={item.id} className="p-2.5 bg-[#0c0c0b] border border-[#a68a53]/20 rounded-sm text-xs">
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="font-serif font-bold text-[#d4c5a9]">{item.name}</span>
                        <span className="font-mono text-[#a68a53]">{item.progressPercent}%</span>
                      </div>
                      <div className="w-full bg-[#151412] h-1.5 rounded-none overflow-hidden border border-[#a68a53]/30">
                        <div
                          className="bg-[#a68a53] h-full transition-all duration-300"
                          style={{ width: `${item.progressPercent}%` }}
                        />
                      </div>
                      <div className="text-[9px] text-[#a68a53]/60 mt-1 font-mono">
                        {item.daysRemaining} days remaining ({item.totalDays} total)
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs font-serif italic text-[#d4c5a9]/50 py-1 text-center">
                  Masons are idle. Select a structure in the Buildings tab to queue.
                </div>
              )}
            </div>

            {/* Historical Chronicle Snippet */}
            <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-1 font-bold">
                Royal Archive Record
              </div>
              <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic">
                &ldquo;{settlement.historicalNotes}&rdquo;
              </p>
            </div>
          </div>
        )}

        {activeTab === 'BUILDINGS' && (
          <div className="space-y-3">
            {/* Existing Buildings */}
            <div>
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-2 font-bold">
                Existing Citadel Structures
              </div>
              <div className="space-y-2">
                {settlement.buildings.map((b) => (
                  <div key={b.id} className="p-2.5 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-xs font-serif font-bold text-[#d4c5a9]">
                          {b.name}
                        </div>
                        <div className="text-[10px] font-serif italic text-[#a68a53]">
                          Tier {b.level} {b.category}
                        </div>
                      </div>
                    </div>
                    <div className="text-[11px] font-serif text-[#d4c5a9]/70 mt-1">
                      {b.bonusDescription}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Available to Construct */}
            <div>
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-2 font-bold">
                Order New Works
              </div>
              <div className="space-y-2">
                {availableStructures.map((s) => (
                  <div
                    key={s.id}
                    className="p-2.5 bg-[#1a1814] border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div className="font-serif font-semibold text-xs text-[#d4c5a9]">{s.name}</div>
                      <button
                        onClick={() => {
                          onQueueBuilding(s.name);
                          soundEngine.playTacticalClick();
                        }}
                        className="px-2 py-0.5 bg-[#a68a53]/20 hover:bg-[#a68a53]/30 text-[#d4c5a9] border border-[#a68a53]/50 rounded-sm text-[9px] uppercase tracking-wider font-bold flex items-center space-x-1 transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Queue</span>
                      </button>
                    </div>
                    <div className="text-[10px] font-serif text-[#d4c5a9]/60 mt-0.5">{s.desc}</div>
                    <div className="text-[9px] font-mono text-[#a68a53]/70 mt-1 flex space-x-2">
                      {Object.entries(s.cost).map(([res, amt]) => (
                        <span key={res} className="capitalize">
                          {res}: {amt}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'MILITARY' && (
          <div className="space-y-3">
            <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm text-xs">
              <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-2 font-bold">
                Garrison Breakdown
              </div>
              <div className="space-y-1.5 text-[#d4c5a9]/80 font-serif">
                <div className="flex justify-between">
                  <span>Citadel Spearmen</span>
                  <span className="font-mono text-[#d4c5a9]">1,200</span>
                </div>
                <div className="flex justify-between">
                  <span>Wall Longbowmen</span>
                  <span className="font-mono text-[#d4c5a9]">800</span>
                </div>
                <div className="flex justify-between">
                  <span>Heavy Gate Catapults</span>
                  <span className="font-mono text-[#d4c5a9]">100</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'TRADE' && (
          <div className="space-y-3">
            <div className="text-[9px] uppercase tracking-[0.25em] text-[#a68a53] mb-2 font-bold">
              Connected Commercial Caravans
            </div>
            {settlement.tradePartners.map((partnerId) => (
              <div
                key={partnerId}
                className="p-2.5 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm flex items-center justify-between text-xs"
              >
                <div className="flex items-center space-x-2">
                  <ArrowRight className="w-3.5 h-3.5 text-[#a68a53]" />
                  <span className="capitalize font-serif font-semibold text-[#d4c5a9]">
                    {partnerId.replace('-', ' ')}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-green-500">+180 Gold/m</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Focus Button */}
      <div className="p-3 border-t border-[#a68a53]/20 bg-[#0c0c0b]/80 flex justify-end">
        <button
          onClick={() => {
            onFocusCoordinates(settlement.x, settlement.y);
            soundEngine.playTacticalClick();
          }}
          className="px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm transition-colors"
        >
          Center Camera
        </button>
      </div>
    </aside>
  );
};
