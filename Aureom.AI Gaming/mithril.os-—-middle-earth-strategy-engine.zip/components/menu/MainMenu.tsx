'use client';

import React, { useState } from 'react';
import { AgeId, FactionId } from '@/types/game';
import { AGES_DATA, FACTIONS_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import {
  Compass,
  Crown,
  BookOpen,
  Settings,
  Swords,
  Play,
  ArrowRight,
  ArrowLeft,
  Shield,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface MainMenuProps {
  onStartGame: (age: AgeId, faction: FactionId) => void;
  onOpenAtlas: () => void;
  onOpenChronicles: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onOpenAtlas,
  onOpenChronicles,
}) => {
  const [screen, setScreen] = useState<'MAIN' | 'AGE_SELECT' | 'FACTION_SELECT' | 'CREDITS'>('MAIN');
  const [selectedAge, setSelectedAge] = useState<AgeId>('THIRD_AGE');
  const [selectedFaction, setSelectedFaction] = useState<FactionId>('GONDOR');
  const [isAudioMuted, setIsAudioMuted] = useState(false);

  const toggleSound = () => {
    const next = !isAudioMuted;
    setIsAudioMuted(next);
    soundEngine.setMuted(next);
  };

  const handleMenuClick = (action: () => void) => {
    soundEngine.playParchmentPage();
    action();
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden select-none bg-[#0c0c0b] text-[#d4c5a9] flex flex-col justify-between p-8 md:p-12">
      {/* Cinematic Map Background / Vignette */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#1a1814] via-[#0c0c0b] to-[#050505]" />
      <div
        className="absolute inset-0 z-0 pointer-events-none opacity-15"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 50%, rgba(166, 138, 83, 0.15) 0%, transparent 60%)',
        }}
      />

      {/* Top Header: Mute Audio & Engine Version */}
      <header className="relative z-10 flex items-center justify-between">
        <div className="flex items-center space-x-2 text-[10px] font-mono uppercase tracking-widest text-[#a68a53]/70">
          <span>Middle-Earth Strategy Engine</span>
          <span>•</span>
          <span className="text-[#a68a53] font-bold">Release v3.8</span>
        </div>

        <button
          onClick={toggleSound}
          className="p-2 bg-[#1a1814] hover:bg-[#a68a53]/10 border border-[#a68a53]/20 rounded-sm text-[#a68a53] hover:text-[#d4c5a9] transition-colors"
          title="Toggle Procedural Audio"
        >
          {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </header>

      {/* Center Stage: Changes based on Screen state */}
      <main className="relative z-10 max-w-4xl mx-auto w-full my-auto py-8">
        {screen === 'MAIN' && (
          <div className="flex flex-col items-center text-center space-y-8">
            {/* Title Block: Restrained, Archival, Elegant */}
            <div className="space-y-2">
              <div className="text-[10px] font-mono tracking-[0.3em] text-[#a68a53] uppercase font-bold">
                An Imperial Command Interface
              </div>
              <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-[0.2em] text-[#d4c5a9]">
                MITHRIL<span className="text-[#a68a53]">.OS</span>
              </h1>
              <p className="text-xs font-serif italic text-[#d4c5a9]/70 max-w-md mx-auto leading-relaxed">
                A grand tactical command engine spanning the ancient Wars of Beleriand, the Downfall of Númenor, and the War of the Ring.
              </p>
            </div>

            {/* Menu Items (Ancient manuscript vertical navigation) */}
            <div className="flex flex-col w-72 space-y-2 text-xs font-serif uppercase tracking-widest">
              <button
                onClick={() => handleMenuClick(() => setScreen('AGE_SELECT'))}
                className="group px-4 py-2.5 bg-[#1a1814]/90 hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm text-[#d4c5a9] transition-all flex items-center justify-between"
              >
                <span>New Campaign</span>
                <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-[#a68a53]" />
              </button>

              <button
                onClick={() => handleMenuClick(() => onStartGame('THIRD_AGE', 'GONDOR'))}
                className="group px-4 py-2.5 bg-[#1a1814]/90 hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm text-[#d4c5a9] transition-all flex items-center justify-between"
              >
                <span>Quick Start (Gondor)</span>
                <Play className="w-3.5 h-3.5 text-[#a68a53]" />
              </button>

              <button
                onClick={() => handleMenuClick(onOpenChronicles)}
                className="group px-4 py-2.5 bg-[#1a1814]/90 hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm text-[#d4c5a9] transition-all flex items-center justify-between"
              >
                <span>Chronicles of Arda</span>
                <BookOpen className="w-3.5 h-3.5 text-[#a68a53]" />
              </button>

              <button
                onClick={() => handleMenuClick(onOpenAtlas)}
                className="group px-4 py-2.5 bg-[#1a1814]/90 hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm text-[#d4c5a9] transition-all flex items-center justify-between"
              >
                <span>Atlas & Archive</span>
                <Compass className="w-3.5 h-3.5 text-[#a68a53]" />
              </button>

              <button
                onClick={() => handleMenuClick(() => setScreen('CREDITS'))}
                className="group px-4 py-2.5 bg-[#1a1814]/90 hover:bg-[#a68a53]/10 border border-[#a68a53]/15 rounded-sm text-[#a68a53]/60 hover:text-[#d4c5a9] transition-all flex items-center justify-between"
              >
                <span>Engine Codex & Credits</span>
                <span className="text-[10px] font-mono text-[#a68a53]/40">v3.8</span>
              </button>
            </div>
          </div>
        )}

        {/* Phase 04: Age Selection */}
        {screen === 'AGE_SELECT' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#a68a53]/20">
              <div>
                <h2 className="text-xl font-serif font-bold text-[#d4c5a9] tracking-wider uppercase">
                  Select Era & Campaign Epoch
                </h2>
                <p className="text-xs font-serif italic text-[#a68a53]/70">
                  Choose the chronological epoch of Middle-earth to command
                </p>
              </div>

              <button
                onClick={() => setScreen('MAIN')}
                className="px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 border border-[#a68a53]/30 rounded-sm text-xs font-serif uppercase tracking-wider text-[#d4c5a9] flex items-center space-x-1.5 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(Object.keys(AGES_DATA) as AgeId[]).map((ageId) => {
                const aData = AGES_DATA[ageId];
                const isSelected = selectedAge === ageId;

                return (
                  <div
                    key={ageId}
                    onClick={() => {
                      setSelectedAge(ageId);
                      soundEngine.playTacticalClick();
                    }}
                    className={`p-5 rounded-sm border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#1a1814] border-[#a68a53] shadow-xl ring-1 ring-[#a68a53]/30'
                        : 'bg-[#1a1814]/60 border-[#a68a53]/20 hover:border-[#a68a53]/40'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-serif font-bold text-[#d4c5a9]">
                        {aData.name}
                      </span>
                      <span className="text-[11px] font-mono text-[#a68a53] font-semibold">
                        YEAR {aData.defaultStartingYear}
                      </span>
                    </div>
                    <div className="text-xs font-serif text-[#a68a53]/70 mb-2">{aData.subtitle}</div>
                    <p className="text-xs font-serif italic text-[#d4c5a9]/80 leading-relaxed">
                      &ldquo;{aData.historicalDescription}&rdquo;
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-4">
              <button
                onClick={() => {
                  soundEngine.playParchmentPage();
                  setScreen('FACTION_SELECT');
                }}
                className="px-6 py-2.5 bg-[#a68a53] hover:bg-[#c4a974] text-[#0c0c0b] font-serif font-bold text-xs uppercase tracking-widest rounded-sm flex items-center space-x-2 transition-colors"
              >
                <span>Proceed to Faction Muster</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Phase 05: Faction Selection */}
        {screen === 'FACTION_SELECT' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#a68a53]/20">
              <div>
                <h2 className="text-xl font-serif font-bold text-[#d4c5a9] tracking-wider uppercase">
                  Declare Sovereign Realm & Faction
                </h2>
                <p className="text-xs font-serif italic text-[#a68a53]/70">
                  Take command of the High Crown of Men, Elven havens, Dwarven holds, or the Dark Host
                </p>
              </div>

              <button
                onClick={() => setScreen('AGE_SELECT')}
                className="px-3 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 border border-[#a68a53]/30 rounded-sm text-xs font-serif uppercase tracking-wider text-[#d4c5a9] flex items-center space-x-1.5 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Change Era</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(Object.keys(FACTIONS_DATA) as FactionId[]).map((fId) => {
                const fac = FACTIONS_DATA[fId];
                const isSelected = selectedFaction === fId;

                return (
                  <div
                    key={fId}
                    onClick={() => {
                      setSelectedFaction(fId);
                      soundEngine.playTacticalClick();
                    }}
                    className={`p-4 rounded-sm border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#1a1814] border-[#a68a53] shadow-xl ring-1 ring-[#a68a53]/30'
                        : 'bg-[#1a1814]/60 border-[#a68a53]/20 hover:border-[#a68a53]/40'
                    }`}
                  >
                    <div className="flex items-center space-x-2 mb-1.5">
                      <div
                        className="w-3 h-3 rounded-full ring-1 ring-[#a68a53]/40"
                        style={{ backgroundColor: fac.accentColor }}
                      />
                      <span className="text-xs font-serif font-bold text-[#d4c5a9]">
                        {fac.name}
                      </span>
                    </div>

                    <div className="text-[10px] font-serif text-[#a68a53] italic mb-1">
                      {fac.leaderTitle} • Capital: {fac.capitalName}
                    </div>

                    <p className="text-[11px] font-serif italic text-[#d4c5a9]/75 line-clamp-3 leading-relaxed">
                      &ldquo;{fac.startingDescription}&rdquo;
                    </p>

                    <div className="mt-2 pt-2 border-t border-[#a68a53]/15 flex justify-between text-[10px] font-mono text-[#a68a53]/70">
                      <span>War: {fac.militaryRating}%</span>
                      <span>Economy: {fac.economicRating}%</span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-4">
              <button
                onClick={() => {
                  soundEngine.playWarHorn();
                  onStartGame(selectedAge, selectedFaction);
                }}
                className="px-8 py-3 bg-[#a68a53] hover:bg-[#c2a670] text-[#0c0c0b] font-serif font-bold text-xs uppercase tracking-[0.2em] rounded-sm shadow-2xl flex items-center space-x-2 transition-all transform hover:scale-105"
              >
                <Swords className="w-4 h-4" />
                <span>Commence Grand Strategy</span>
              </button>
            </div>
          </div>
        )}

        {screen === 'CREDITS' && (
          <div className="p-6 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm max-w-xl mx-auto space-y-4 text-center">
            <h2 className="text-base font-serif font-bold text-[#d4c5a9] tracking-widest uppercase">
              MITHRIL.OS // SYSTEM CREDENTIALS
            </h2>
            <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic">
              Crafted as an authoritative Middle-earth military command interface and grand-strategy engine. Inspired by ancient cartography, royal chronicles, high tactical RTS command tables, and the legendarium of J.R.R. Tolkien.
            </p>
            <div className="text-[10px] font-mono text-[#a68a53]/70 pt-2 border-t border-[#a68a53]/20">
              HTML5 Canvas Cartographic Shaders • Web Audio API Synthesizers • React 19 State Engine
            </div>
            <button
              onClick={() => setScreen('MAIN')}
              className="px-4 py-1.5 bg-[#0c0c0b] hover:bg-[#a68a53]/10 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm mt-2 transition-colors"
            >
              Return
            </button>
          </div>
        )}
      </main>

      {/* Footer System Credits */}
      <footer className="relative z-10 flex items-center justify-between text-[10px] font-mono text-[#a68a53]/60 border-t border-[#a68a53]/20 pt-2">
        <span>Strategic Warfare & Archival Reconstruction</span>
        <span>Middle-Earth Chronicles • Third Age 3019</span>
      </footer>
    </div>
  );
};
