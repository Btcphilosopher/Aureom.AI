'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Army,
  CameraState,
  FactionId,
  MapLayerId,
  Settlement,
  WeatherType,
  ActiveCombat,
} from '@/types/game';
import { FACTIONS_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';

interface WorldMapCanvasProps {
  settlements: Settlement[];
  armies: Army[];
  activeCombats: ActiveCombat[];
  selectedEntityId: string | null;
  selectedEntityType: 'SETTLEMENT' | 'ARMY' | 'HERO' | null;
  selectedArmyIds: string[];
  activeLayer: MapLayerId;
  weather: WeatherType;
  camera: CameraState;
  onCameraChange: (camera: CameraState) => void;
  onSelectSettlement: (settlement: Settlement) => void;
  onSelectArmy: (army: Army, isMultiSelect?: boolean) => void;
  onMoveArmyOrder: (armyId: string, targetX: number, targetY: number) => void;
  buildModeBuilding: string | null;
  onPlaceBuilding: (settlementId: string, buildingType: string) => void;
  playerFaction: FactionId;
}

// Middle-earth geographical features
interface MountainRange {
  name: string;
  points: [number, number][];
  width: number;
}

interface River {
  name: string;
  points: [number, number][];
  width: number;
}

interface ForestArea {
  name: string;
  center: [number, number];
  rx: number;
  ry: number;
  rotation?: number;
}

interface MajorRoad {
  name: string;
  points: [number, number][];
}

const MOUNTAIN_RANGES: MountainRange[] = [
  // Misty Mountains (Hithaeglir)
  {
    name: 'Misty Mountains',
    points: [
      [420, 100], [435, 160], [445, 230], [455, 300], [440, 360], [410, 420], [360, 470],
    ],
    width: 28,
  },
  // White Mountains (Ered Nimrais)
  {
    name: 'White Mountains',
    points: [
      [360, 480], [420, 520], [490, 550], [560, 565], [630, 580],
    ],
    width: 26,
  },
  // Ephel Dúath (Mountains of Shadow - West & South Mordor)
  {
    name: 'Ephel Dúath',
    points: [
      [730, 490], [720, 550], [710, 620], [730, 690], [800, 700], [880, 710],
    ],
    width: 24,
  },
  // Ered Lithui (Ash Mountains - North Mordor)
  {
    name: 'Ered Lithui',
    points: [
      [740, 490], [820, 485], [900, 490], [980, 500],
    ],
    width: 22,
  },
  // Iron Hills
  {
    name: 'Iron Hills',
    points: [
      [750, 150], [810, 140], [870, 145],
    ],
    width: 20,
  },
  // Blue Mountains (Ered Luin)
  {
    name: 'Blue Mountains',
    points: [
      [180, 120], [170, 220], [160, 320],
    ],
    width: 24,
  },
];

const RIVERS: River[] = [
  // Great River Anduin
  {
    name: 'Anduin the Great',
    points: [
      [580, 120], [560, 200], [540, 310], [520, 410], [560, 470], [600, 520], [680, 570], [660, 630], [620, 720], [590, 780],
    ],
    width: 7,
  },
  // Entwash
  {
    name: 'Entwash',
    points: [
      [430, 440], [470, 470], [530, 490], [580, 500],
    ],
    width: 4,
  },
  // River Isen
  {
    name: 'River Isen',
    points: [
      [340, 410], [330, 470], [280, 550],
    ],
    width: 5,
  },
  // Brandywine (Baranduin)
  {
    name: 'Brandywine',
    points: [
      [270, 160], [290, 220], [280, 290], [240, 370],
    ],
    width: 5,
  },
];

const FORESTS: ForestArea[] = [
  { name: 'Mirkwood (Greenwood the Great)', center: [620, 250], rx: 80, ry: 130 },
  { name: 'Fangorn Forest', center: [430, 420], rx: 45, ry: 38 },
  { name: 'Lothlórien (The Golden Wood)', center: [480, 350], rx: 32, ry: 32 },
  { name: 'Old Forest', center: [290, 260], rx: 25, ry: 20 },
  { name: 'Ithilien Woodlands', center: [680, 610], rx: 35, ry: 60 },
];

const ROADS: MajorRoad[] = [
  // The Great East Road
  {
    name: 'The Great East Road',
    points: [[180, 230], [260, 235], [320, 240], [460, 190]],
  },
  // The Greenway (North-South Road)
  {
    name: 'The Greenway',
    points: [[320, 240], [330, 340], [350, 430], [440, 500], [640, 580]],
  },
  // The Harad Road
  {
    name: 'The Harad Road',
    points: [[640, 580], [660, 660], [620, 720], [580, 800], [540, 860]],
  },
];

export const WorldMapCanvas: React.FC<WorldMapCanvasProps> = ({
  settlements,
  armies,
  activeCombats,
  selectedEntityId,
  selectedArmyIds,
  activeLayer,
  weather,
  camera,
  onCameraChange,
  onSelectSettlement,
  onSelectArmy,
  onMoveArmyOrder,
  buildModeBuilding,
  onPlaceBuilding,
  playerFaction,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Mouse drag & interaction states
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hoveredEntity, setHoveredEntity] = useState<{
    type: 'SETTLEMENT' | 'ARMY';
    data: Settlement | Army;
    screenX: number;
    screenY: number;
  } | null>(null);
  const [mouseWorldPos, setMouseWorldPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isBoxSelecting, setIsBoxSelecting] = useState(false);
  const [boxSelectStart, setBoxSelectStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [boxSelectCurrent, setBoxSelectCurrent] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Animation frame loop
  const animFrameRef = useRef<number | null>(null);
  const weatherParticlesRef = useRef<{ x: number; y: number; speed: number; size: number }[]>([]);

  // Initialize weather particles
  useEffect(() => {
    const particles = [];
    for (let i = 0; i < 90; i++) {
      particles.push({
        x: Math.random() * 1200,
        y: Math.random() * 1000,
        speed: 0.5 + Math.random() * 1.5,
        size: 1 + Math.random() * 2.5,
      });
    }
    weatherParticlesRef.current = particles;
  }, []);

  // Convert screen coordinates to world coordinates
  const screenToWorld = useCallback(
    (screenX: number, screenY: number): { x: number; y: number } => {
      if (!canvasRef.current) return { x: 0, y: 0 };
      const width = canvasRef.current.width;
      const height = canvasRef.current.height;

      // Center offset
      const cx = width / 2;
      const cy = height / 2;

      // Inverse translate
      let relX = screenX - cx;
      let relY = screenY - cy;

      // Inverse rotation
      const rad = (-camera.rotationDeg * Math.PI) / 180;
      const rotX = relX * Math.cos(rad) - relY * Math.sin(rad);
      const rotY = relX * Math.sin(rad) + relY * Math.cos(rad);

      // Inverse zoom and camera pan
      const worldX = camera.x + rotX / camera.zoom;
      const worldY = camera.y + rotY / camera.zoom;

      return { x: worldX, y: worldY };
    },
    [camera]
  );

  // Convert world coordinates to screen coordinates
  const worldToScreen = useCallback(
    (worldX: number, worldY: number): { x: number; y: number } => {
      if (!canvasRef.current) return { x: 0, y: 0 };
      const width = canvasRef.current.width;
      const height = canvasRef.current.height;

      const cx = width / 2;
      const cy = height / 2;

      const relX = (worldX - camera.x) * camera.zoom;
      const relY = (worldY - camera.y) * camera.zoom;

      const rad = (camera.rotationDeg * Math.PI) / 180;
      const rotX = relX * Math.cos(rad) - relY * Math.sin(rad);
      const rotY = relX * Math.sin(rad) + relY * Math.cos(rad);

      return { x: cx + rotX, y: cy + rotY };
    },
    [camera]
  );

  // Main canvas render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isSubscribed = true;

    const render = () => {
      if (!isSubscribed) return;

      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();

      if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      const w = rect.width;
      const h = rect.height;

      // 1. Ancient Cartographic Background / Parchment Tone
      ctx.fillStyle = '#0f1115';
      ctx.fillRect(0, 0, w, h);

      // Set up camera matrix
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate((camera.rotationDeg * Math.PI) / 180);
      ctx.scale(camera.zoom, camera.zoom);
      ctx.translate(-camera.x, -camera.y);

      // 2. Base Landmass / Sea of Middle-earth
      // Sea of Belegaer tint (West)
      ctx.fillStyle = '#0c1017';
      ctx.fillRect(0, 0, 1100, 950);

      // Landmass gradient & texture (Middle-earth interior)
      const landGrad = ctx.createRadialGradient(550, 480, 50, 550, 480, 600);
      landGrad.addColorStop(0, '#191d24');
      landGrad.addColorStop(0.7, '#14171d');
      landGrad.addColorStop(1, '#0e1116');
      ctx.fillStyle = landGrad;
      ctx.beginPath();
      // Coastline outline of Middle-earth
      ctx.moveTo(140, 100);
      ctx.bezierCurveTo(240, 200, 200, 380, 260, 500);
      ctx.bezierCurveTo(320, 620, 390, 710, 480, 760);
      ctx.bezierCurveTo(550, 800, 600, 880, 650, 920);
      ctx.lineTo(1050, 920);
      ctx.lineTo(1050, 100);
      ctx.closePath();
      ctx.fill();

      // Ancient engraved cartographic grid lines (meridians and parallels)
      ctx.strokeStyle = 'rgba(214, 205, 184, 0.04)';
      ctx.lineWidth = 1 / camera.zoom;
      for (let x = 100; x < 1050; x += 100) {
        ctx.beginPath();
        ctx.moveTo(x, 80);
        ctx.lineTo(x, 920);
        ctx.stroke();
      }
      for (let y = 100; y < 950; y += 100) {
        ctx.beginPath();
        ctx.moveTo(80, y);
        ctx.lineTo(1050, y);
        ctx.stroke();
      }

      // Mordor volcanic ash wasteland (southeast)
      ctx.fillStyle = 'rgba(38, 24, 24, 0.45)';
      ctx.beginPath();
      ctx.moveTo(730, 490);
      ctx.lineTo(950, 495);
      ctx.lineTo(940, 700);
      ctx.lineTo(720, 690);
      ctx.closePath();
      ctx.fill();

      // Sea of Núrnen
      ctx.fillStyle = '#080c12';
      ctx.beginPath();
      ctx.ellipse(860, 640, 35, 20, -0.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(120, 140, 160, 0.2)';
      ctx.stroke();

      // Sea of Rhûn (Northeast)
      ctx.beginPath();
      ctx.ellipse(920, 260, 60, 45, 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // 3. Render Forests (Fangorn, Mirkwood, Lothlórien)
      FORESTS.forEach((f) => {
        ctx.save();
        ctx.translate(f.center[0], f.center[1]);
        if (f.rotation) ctx.rotate(f.rotation);

        const forestGrad = ctx.createRadialGradient(0, 0, 5, 0, 0, f.rx);
        forestGrad.addColorStop(0, 'rgba(28, 48, 32, 0.55)');
        forestGrad.addColorStop(0.8, 'rgba(18, 34, 22, 0.35)');
        forestGrad.addColorStop(1, 'rgba(18, 34, 22, 0)');

        ctx.fillStyle = forestGrad;
        ctx.beginPath();
        ctx.ellipse(0, 0, f.rx, f.ry, 0, 0, Math.PI * 2);
        ctx.fill();

        // Stippled trees in forest
        ctx.fillStyle = 'rgba(74, 112, 82, 0.3)';
        for (let i = -f.rx * 0.7; i <= f.rx * 0.7; i += 18) {
          for (let j = -f.ry * 0.7; j <= f.ry * 0.7; j += 18) {
            if ((i * i) / (f.rx * f.rx) + (j * j) / (f.ry * f.ry) < 0.6) {
              ctx.beginPath();
              ctx.arc(i + Math.sin(j) * 4, j, 2, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }

        // Label if zoomed in enough
        if (camera.zoom > 0.8) {
          ctx.font = '9px "Cinzel", Georgia, serif';
          ctx.fillStyle = 'rgba(168, 192, 164, 0.45)';
          ctx.textAlign = 'center';
          ctx.fillText(f.name.toUpperCase(), 0, 0);
        }
        ctx.restore();
      });

      // 4. Render Rivers with shimmer
      RIVERS.forEach((river) => {
        ctx.save();
        ctx.strokeStyle = '#2b3d4f';
        ctx.lineWidth = river.width;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        river.points.forEach((pt, idx) => {
          if (idx === 0) ctx.moveTo(pt[0], pt[1]);
          else ctx.lineTo(pt[0], pt[1]);
        });
        ctx.stroke();

        // Inner river highlight
        ctx.strokeStyle = 'rgba(110, 165, 205, 0.4)';
        ctx.lineWidth = Math.max(1, river.width * 0.35);
        ctx.stroke();
        ctx.restore();
      });

      // 5. Render Mountain Ranges (Engraved Relief & Ridges)
      MOUNTAIN_RANGES.forEach((range) => {
        ctx.save();
        for (let i = 0; i < range.points.length - 1; i++) {
          const p1 = range.points[i];
          const p2 = range.points[i + 1];
          const segDist = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]);
          const steps = Math.max(2, Math.floor(segDist / 16));

          for (let s = 0; s <= steps; s++) {
            const t = s / steps;
            const mx = p1[0] + (p2[0] - p1[0]) * t;
            const my = p1[1] + (p2[1] - p1[1]) * t;
            const h = range.width * (0.8 + Math.sin(s * 1.5) * 0.4);

            // Mountain shaded triangle
            ctx.beginPath();
            ctx.moveTo(mx, my - h);
            ctx.lineTo(mx - h * 0.65, my + h * 0.35);
            ctx.lineTo(mx + h * 0.65, my + h * 0.35);
            ctx.closePath();

            // Shaded relief: lit side & shadowed side
            ctx.fillStyle = '#22262d';
            ctx.fill();
            ctx.strokeStyle = 'rgba(180, 165, 140, 0.25)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Mountain ridge line
            ctx.strokeStyle = 'rgba(220, 210, 190, 0.4)';
            ctx.beginPath();
            ctx.moveTo(mx, my - h);
            ctx.lineTo(mx + 2, my + h * 0.35);
            ctx.stroke();
          }
        }
        ctx.restore();
      });

      // 6. Roads Layer
      ROADS.forEach((road) => {
        ctx.save();
        ctx.strokeStyle = activeLayer === 'ROADS' ? 'rgba(214, 185, 120, 0.7)' : 'rgba(140, 130, 115, 0.25)';
        ctx.lineWidth = activeLayer === 'ROADS' ? 3 : 1.5;
        ctx.setLineDash([4, 3]);
        ctx.beginPath();
        road.points.forEach((pt, idx) => {
          if (idx === 0) ctx.moveTo(pt[0], pt[1]);
          else ctx.lineTo(pt[0], pt[1]);
        });
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      });

      // 7. Layer Specific Visualisations:
      if (activeLayer === 'POLITICAL' || activeLayer === 'DIPLOMACY') {
        // Render sovereign territory zones
        settlements.forEach((s) => {
          const faction = FACTIONS_DATA[s.faction];
          ctx.save();
          ctx.fillStyle = faction.accentColor + '18'; // 10% opacity
          ctx.strokeStyle = faction.accentColor + '55';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.isCapital ? 75 : 45, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          ctx.restore();
        });
      }

      if (activeLayer === 'ECONOMIC' || activeLayer === 'TRADE') {
        // Draw moving trade caravan indicators
        const timeOffset = (Date.now() / 1500) % 1;
        settlements.forEach((s) => {
          s.tradePartners.forEach((partnerId) => {
            const partner = settlements.find((st) => st.id === partnerId);
            if (partner && s.id < partner.id) {
              ctx.save();
              ctx.strokeStyle = 'rgba(217, 180, 90, 0.4)';
              ctx.lineWidth = 1.8;
              ctx.beginPath();
              ctx.moveTo(s.x, s.y);
              ctx.lineTo(partner.x, partner.y);
              ctx.stroke();

              // Moving trader bead
              const bx = s.x + (partner.x - s.x) * timeOffset;
              const by = s.y + (partner.y - s.y) * timeOffset;
              ctx.fillStyle = '#f59e0b';
              ctx.beginPath();
              ctx.arc(bx, by, 3, 0, Math.PI * 2);
              ctx.fill();
              ctx.restore();
            }
          });
        });
      }

      if (activeLayer === 'MILITARY') {
        // Draw frontline threat corridors between Gondor/Rohan and Mordor
        ctx.save();
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        ctx.moveTo(690, 520);
        ctx.lineTo(700, 600);
        ctx.lineTo(670, 670);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      }

      // 8. Render Settlements
      settlements.forEach((s) => {
        const faction = FACTIONS_DATA[s.faction];
        const isSelected = selectedEntityId === s.id;
        const isHovered = hoveredEntity?.type === 'SETTLEMENT' && hoveredEntity.data.id === s.id;

        ctx.save();
        ctx.translate(s.x, s.y);

        // Selection ring & architectural radius
        if (isSelected) {
          ctx.strokeStyle = '#e2d8b8';
          ctx.lineWidth = 2 / camera.zoom;
          ctx.beginPath();
          ctx.arc(0, 0, 22, 0, Math.PI * 2);
          ctx.stroke();

          // Subtle compass crosshair
          ctx.strokeStyle = 'rgba(226, 216, 184, 0.5)';
          ctx.beginPath();
          ctx.moveTo(-28, 0);
          ctx.lineTo(-24, 0);
          ctx.moveTo(24, 0);
          ctx.lineTo(28, 0);
          ctx.moveTo(0, -28);
          ctx.lineTo(0, -24);
          ctx.moveTo(0, 24);
          ctx.lineTo(0, 28);
          ctx.stroke();
        }

        // Settlement icon / architectural token
        const radius = s.isCapital ? 10 : 7;
        ctx.fillStyle = isHovered ? '#ffffff' : faction.accentColor;
        ctx.strokeStyle = '#0b0c0e';
        ctx.lineWidth = 2;

        if (s.isCapital) {
          // Capital diamond fortress
          ctx.beginPath();
          ctx.moveTo(0, -radius * 1.3);
          ctx.lineTo(radius * 1.3, 0);
          ctx.lineTo(0, radius * 1.3);
          ctx.lineTo(-radius * 1.3, 0);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        } else {
          // Town circular fortress bastion
          ctx.beginPath();
          ctx.arc(0, 0, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }

        // City Label (Restrained, archival typography)
        ctx.font = s.isCapital ? 'bold 11px "Cinzel", Georgia, serif' : '10px "Cinzel", Georgia, serif';
        ctx.fillStyle = isSelected ? '#fef08a' : '#d4cebe';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 4;
        ctx.fillText(s.name.toUpperCase(), 0, radius + 14);

        if (camera.zoom > 0.9) {
          ctx.font = '8px "JetBrains Mono", monospace';
          ctx.fillStyle = 'rgba(210, 200, 180, 0.65)';
          ctx.fillText(`pop: ${s.population.toLocaleString()}`, 0, radius + 24);
        }
        ctx.restore();
      });

      // 9. Render Armies & Movement Paths
      armies.forEach((army) => {
        const isSelected = selectedEntityId === army.id || selectedArmyIds.includes(army.id);
        const faction = FACTIONS_DATA[army.faction];

        // Projected movement path line
        if (army.targetX !== undefined && army.targetY !== undefined) {
          ctx.save();
          ctx.strokeStyle = isSelected ? '#f59e0b' : 'rgba(180, 170, 150, 0.4)';
          ctx.lineWidth = isSelected ? 2 : 1.2;
          ctx.setLineDash([5, 4]);
          ctx.beginPath();
          ctx.moveTo(army.x, army.y);
          ctx.lineTo(army.targetX, army.targetY);
          ctx.stroke();
          ctx.setLineDash([]);

          // March destination cross
          ctx.strokeStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(army.targetX, army.targetY, 4, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Army Military Formation Token
        ctx.save();
        ctx.translate(army.x, army.y);

        // Selection Box / Banner
        if (isSelected) {
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 1.8 / camera.zoom;
          ctx.strokeRect(-16, -16, 32, 32);
        }

        // Military regiment rectangle token
        ctx.fillStyle = faction.secondaryColor;
        ctx.fillRect(-11, -7, 22, 14);
        ctx.strokeStyle = faction.accentColor;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-11, -7, 22, 14);

        // Tactical symbol (cross or chevron)
        ctx.beginPath();
        ctx.moveTo(-11, -7);
        ctx.lineTo(11, 7);
        ctx.moveTo(-11, 7);
        ctx.lineTo(11, -7);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Army Name / Size badge
        ctx.font = 'bold 9px "JetBrains Mono", monospace';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 3;
        ctx.fillText(`${(army.size / 1000).toFixed(1)}k`, 0, 18);

        ctx.restore();
      });

      // 10. Active Combats & Sieges
      activeCombats.forEach((combat) => {
        ctx.save();
        ctx.translate(combat.x, combat.y);

        // Pulsing clash circle
        const pulse = 1 + Math.sin(Date.now() / 120) * 0.15;
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, 24 * pulse, 0, Math.PI * 2);
        ctx.stroke();

        // Crossed swords tactical banner
        ctx.fillStyle = '#7f1d1d';
        ctx.fillRect(-20, -12, 40, 24);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-20, -12, 40, 24);

        ctx.font = 'bold 10px "Cinzel", Georgia, serif';
        ctx.fillStyle = '#fef2f2';
        ctx.textAlign = 'center';
        ctx.fillText('CLASH', 0, 4);

        // Attacker Morale vs Defender Morale Bar
        ctx.fillStyle = '#10b981';
        ctx.fillRect(-18, 16, 16 * (combat.attackerMorale / 100), 3);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(2, 16, 16 * (combat.defenderMorale / 100), 3);

        ctx.restore();
      });

      // 11. Ghost Building Placement in Build Mode
      if (buildModeBuilding) {
        ctx.save();
        const snappedX = Math.round(mouseWorldPos.x / 10) * 10;
        const snappedY = Math.round(mouseWorldPos.y / 10) * 10;

        // Radius circle
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.arc(snappedX, snappedY, 20, 0, Math.PI * 2);
        ctx.stroke();

        // Ghost structure outline
        ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
        ctx.fillRect(snappedX - 12, snappedY - 12, 24, 24);
        ctx.strokeRect(snappedX - 12, snappedY - 12, 24, 24);

        ctx.font = '9px "Cinzel", Georgia, serif';
        ctx.fillStyle = '#38bdf8';
        ctx.textAlign = 'center';
        ctx.fillText(buildModeBuilding.toUpperCase(), snappedX, snappedY - 18);
        ctx.restore();
      }

      // 12. Multi-selection Drag Rectangle
      if (isBoxSelecting) {
        const start = screenToWorld(boxSelectStart.x, boxSelectStart.y);
        const curr = screenToWorld(boxSelectCurrent.x, boxSelectCurrent.y);

        const bx = Math.min(start.x, curr.x);
        const by = Math.min(start.y, curr.y);
        const bw = Math.abs(curr.x - start.x);
        const bh = Math.abs(curr.y - start.y);

        ctx.save();
        ctx.fillStyle = 'rgba(217, 180, 90, 0.12)';
        ctx.strokeStyle = 'rgba(217, 180, 90, 0.8)';
        ctx.lineWidth = 1 / camera.zoom;
        ctx.fillRect(bx, by, bw, bh);
        ctx.strokeRect(bx, by, bw, bh);
        ctx.restore();
      }

      // 13. Atmospheric Weather Particles (Mist, Rain, Ash, Snow)
      if (weather !== 'CLEAR') {
        ctx.save();
        weatherParticlesRef.current.forEach((p) => {
          p.y += p.speed;
          if (p.y > 1000) p.y = 0;

          if (weather === 'ASH_FALL') {
            p.x -= 0.6; // Mordor volcanic ash blowing west towards Gondor
            if (p.x < 0) p.x = 1200;
            ctx.fillStyle = 'rgba(45, 30, 30, 0.6)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
          } else if (weather === 'HEAVY_RAIN') {
            ctx.strokeStyle = 'rgba(148, 180, 210, 0.35)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p.x - 2, p.y + p.size * 4);
            ctx.stroke();
          } else if (weather === 'MIST') {
            ctx.fillStyle = 'rgba(180, 190, 205, 0.08)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * 12, 0, Math.PI * 2);
            ctx.fill();
          } else if (weather === 'SNOW') {
            ctx.fillStyle = 'rgba(240, 245, 255, 0.65)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * 0.9, 0, Math.PI * 2);
            ctx.fill();
          }
        });
        ctx.restore();
      }

      ctx.restore(); // Restore camera matrix

      // 14. Subtle Vignette & Compass Rose in viewport
      const vignette = ctx.createRadialGradient(w / 2, h / 2, w * 0.3, w / 2, h / 2, w * 0.7);
      vignette.addColorStop(0, 'rgba(0,0,0,0)');
      vignette.addColorStop(1, 'rgba(6,8,10,0.6)');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, w, h);

      ctx.restore(); // Restore dpr scale

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      isSubscribed = false;
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [
    settlements,
    armies,
    activeCombats,
    selectedEntityId,
    selectedArmyIds,
    activeLayer,
    weather,
    camera,
    hoveredEntity,
    mouseWorldPos,
    buildModeBuilding,
    isBoxSelecting,
    boxSelectStart,
    boxSelectCurrent,
    screenToWorld,
  ]);

  // Mouse Handlers: Pan, Zoom, Selection, Orders
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const worldPos = screenToWorld(mouseX, mouseY);

    // Left click
    if (e.button === 0) {
      if (e.shiftKey) {
        // Multi-select box mode
        setIsBoxSelecting(true);
        setBoxSelectStart({ x: mouseX, y: mouseY });
        setBoxSelectCurrent({ x: mouseX, y: mouseY });
        return;
      }

      // If in build mode, place structure on closest settlement
      if (buildModeBuilding) {
        const closest = settlements.find(
          (s) => Math.hypot(s.x - worldPos.x, s.y - worldPos.y) < 35 && s.faction === playerFaction
        );
        if (closest) {
          onPlaceBuilding(closest.id, buildModeBuilding);
          soundEngine.playTacticalClick();
        }
        return;
      }

      // Check click on army
      const clickedArmy = armies.find(
        (a) => Math.hypot(a.x - worldPos.x, a.y - worldPos.y) < 20 / camera.zoom
      );
      if (clickedArmy) {
        onSelectArmy(clickedArmy, e.ctrlKey || e.metaKey);
        soundEngine.playTacticalClick();
        return;
      }

      // Check click on settlement
      const clickedSettlement = settlements.find(
        (s) => Math.hypot(s.x - worldPos.x, s.y - worldPos.y) < 25 / camera.zoom
      );
      if (clickedSettlement) {
        onSelectSettlement(clickedSettlement);
        soundEngine.playTacticalClick();
        return;
      }

      // Otherwise, start dragging camera
      setIsDragging(true);
      setDragStart({ x: e.clientX, y: e.clientY });
    }

    // Right click: Issue movement or attack order for selected army
    if (e.button === 2) {
      e.preventDefault();
      if (selectedEntityId) {
        const selArmy = armies.find((a) => a.id === selectedEntityId);
        if (selArmy && selArmy.faction === playerFaction) {
          onMoveArmyOrder(selArmy.id, Math.round(worldPos.x), Math.round(worldPos.y));
          soundEngine.playDrumStrike();
        }
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const worldPos = screenToWorld(mouseX, mouseY);
    setMouseWorldPos(worldPos);

    if (isBoxSelecting) {
      setBoxSelectCurrent({ x: mouseX, y: mouseY });
      return;
    }

    if (isDragging) {
      const dx = (e.clientX - dragStart.x) / camera.zoom;
      const dy = (e.clientY - dragStart.y) / camera.zoom;

      // Handle pan with camera rotation angle
      const rad = (-camera.rotationDeg * Math.PI) / 180;
      const rx = dx * Math.cos(rad) - dy * Math.sin(rad);
      const ry = dx * Math.sin(rad) + dy * Math.cos(rad);

      onCameraChange({
        ...camera,
        x: Math.max(100, Math.min(1000, camera.x - rx)),
        y: Math.max(100, Math.min(900, camera.y - ry)),
      });
      setDragStart({ x: e.clientX, y: e.clientY });
      return;
    }

    // Detect hover
    const hoveredArmy = armies.find(
      (a) => Math.hypot(a.x - worldPos.x, a.y - worldPos.y) < 18 / camera.zoom
    );
    if (hoveredArmy) {
      setHoveredEntity({ type: 'ARMY', data: hoveredArmy, screenX: mouseX, screenY: mouseY });
      return;
    }

    const hoveredSet = settlements.find(
      (s) => Math.hypot(s.x - worldPos.x, s.y - worldPos.y) < 22 / camera.zoom
    );
    if (hoveredSet) {
      setHoveredEntity({ type: 'SETTLEMENT', data: hoveredSet, screenX: mouseX, screenY: mouseY });
      return;
    }

    if (hoveredEntity) setHoveredEntity(null);
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isBoxSelecting) {
      const start = screenToWorld(boxSelectStart.x, boxSelectStart.y);
      const curr = screenToWorld(boxSelectCurrent.x, boxSelectCurrent.y);
      const minX = Math.min(start.x, curr.x);
      const maxX = Math.max(start.x, curr.x);
      const minY = Math.min(start.y, curr.y);
      const maxY = Math.max(start.y, curr.y);

      // Select armies in bounding box
      const enclosedArmies = armies.filter(
        (a) => a.faction === playerFaction && a.x >= minX && a.x <= maxX && a.y >= minY && a.y <= maxY
      );
      if (enclosedArmies.length > 0) {
        onSelectArmy(enclosedArmies[0]);
      }
      setIsBoxSelecting(false);
    }
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomDelta = e.deltaY < 0 ? 1.15 : 0.87;
    const newZoom = Math.max(0.4, Math.min(2.8, camera.zoom * zoomDelta));
    onCameraChange({
      ...camera,
      zoom: Math.round(newZoom * 100) / 100,
    });
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden select-none bg-[#090b0e]"
      onContextMenu={(e) => e.preventDefault()}
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
      />

      {/* Hover Entity Tooltip (Restrained, Archival Cartographic Badge) */}
      {hoveredEntity && (
        <div
          className="pointer-events-none absolute z-20 px-3 py-2 bg-[#12151b]/90 border border-[#a88e5e]/40 rounded-sm shadow-xl backdrop-blur-sm transform -translate-x-1/2 -translate-y-full mb-3"
          style={{
            left: `${hoveredEntity.screenX}px`,
            top: `${hoveredEntity.screenY - 15}px`,
          }}
        >
          <div className="text-xs font-display tracking-widest text-[#e6decb] font-semibold">
            {hoveredEntity.data.name.toUpperCase()}
          </div>
          <div className="text-[10px] font-archival text-[#a39c8c] italic">
            {hoveredEntity.type === 'SETTLEMENT'
              ? `${(hoveredEntity.data as Settlement).region} — Pop: ${(hoveredEntity.data as Settlement).population.toLocaleString()}`
              : `Host of ${(hoveredEntity.data as Army).commanderName} — ${(hoveredEntity.data as Army).size.toLocaleString()} warriors`}
          </div>
        </div>
      )}
    </div>
  );
};
