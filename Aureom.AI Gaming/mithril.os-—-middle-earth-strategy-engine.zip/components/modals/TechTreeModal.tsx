'use client';

import React from 'react';
import { TechBranch, TechNode } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import { Sparkles, CheckCircle2, Clock, Lock, X } from 'lucide-react';

interface TechTreeModalProps {
  techTree: TechNode[];
  onStartResearch: (techId: string) => void;
  onClose: () => void;
}

export const TechTreeModal: React.FC<TechTreeModalProps> = ({
  techTree,
  onStartResearch,
  onClose,
}) => {
  const branches: TechBranch[] = ['MILITARY', 'CIVIL', 'ARCHITECTURE', 'CRAFT', 'LORE'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-5xl h-[85vh] bg-[#0d0f14] border border-[#a88e5e]/50 shadow-2xl rounded-sm flex flex-col text-[#d8d0c0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#292e3c] bg-[#131720]">
          <div className="flex items-center space-x-3">
            <Sparkles className="w-5 h-5 text-[#a88e5e]" />
            <div>
              <div className="text-base font-display font-bold tracking-widest text-[#f7eedf]">
                ROYAL SCRIPTAL ARCHIVES — ADVANCEMENT OF LEARNING
              </div>
              <div className="text-xs font-archival italic text-[#959fad]">
                Preserving ancient lore, metallurgy, and architectural sciences across the Ages
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#202636] rounded text-[#8690a2] hover:text-[#f7eedf]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tree Container (Parchment grid layout) */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {branches.map((branch) => {
            const nodes = techTree.filter((t) => t.branch === branch);
            return (
              <div key={branch} className="p-4 bg-[#12161f] border border-[#272d3b] rounded-sm">
                <div className="text-xs font-display font-bold tracking-widest text-[#a88e5e] mb-3 pb-1 border-b border-[#272d3b]">
                  {branch} SCIENCES
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {nodes.map((tech) => {
                    const isAvailable =
                      !tech.isResearched &&
                      !tech.isResearching &&
                      tech.prerequisites.every(
                        (prereqId) => techTree.find((t) => t.id === prereqId)?.isResearched
                      );

                    return (
                      <div
                        key={tech.id}
                        className={`p-3.5 rounded-sm border transition-all flex flex-col justify-between ${
                          tech.isResearched
                            ? 'bg-[#15241b] border-[#22c55e]/60 text-[#dcfce7]'
                            : tech.isResearching
                            ? 'bg-[#291f10] border-[#f59e0b] text-[#fef3c7]'
                            : isAvailable
                            ? 'bg-[#161a24] border-[#394155] hover:border-[#a88e5e] text-[#e2d9c8]'
                            : 'bg-[#101217] border-[#20242e] text-[#6b7280] opacity-65'
                        }`}
                      >
                        <div>
                          <div className="flex items-start justify-between">
                            <div className="font-display font-bold text-xs tracking-wide">
                              {tech.name}
                            </div>
                            {tech.isResearched ? (
                              <CheckCircle2 className="w-4 h-4 text-[#22c55e]" />
                            ) : tech.isResearching ? (
                              <Clock className="w-4 h-4 text-[#f59e0b] animate-spin" />
                            ) : !isAvailable ? (
                              <Lock className="w-4 h-4 text-[#6b7280]" />
                            ) : null}
                          </div>

                          <div className="text-[11px] font-archival text-[#a3abb8] mt-1 italic">
                            {tech.description}
                          </div>
                        </div>

                        <div className="mt-3 pt-2 border-t border-white/10">
                          {tech.isResearched ? (
                            <span className="text-[10px] font-display text-[#22c55e] font-bold">
                              MASTERED
                            </span>
                          ) : tech.isResearching ? (
                            <div>
                              <div className="flex justify-between text-[10px] font-data mb-1">
                                <span>RESEARCHING</span>
                                <span>{tech.progressPercent}%</span>
                              </div>
                              <div className="w-full bg-[#0d0f14] h-1.5 rounded-full overflow-hidden">
                                <div
                                  className="bg-[#f59e0b] h-full"
                                  style={{ width: `${tech.progressPercent}%` }}
                                />
                              </div>
                            </div>
                          ) : isAvailable ? (
                            <button
                              onClick={() => {
                                onStartResearch(tech.id);
                                soundEngine.playParchmentPage();
                              }}
                              className="w-full py-1 bg-[#a88e5e]/25 hover:bg-[#a88e5e]/40 text-[#fbf7ee] border border-[#a88e5e]/60 rounded text-[11px] font-display font-semibold transition-colors"
                            >
                              COMMENCE RESEARCH
                            </button>
                          ) : (
                            <span className="text-[10px] font-data text-[#64748b]">
                              Prerequisites Required
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#292e3c] bg-[#121620] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1b202c] hover:bg-[#252c3c] text-xs font-display text-[#f5eedf] border border-[#373e50] rounded"
          >
            CLOSE ARCHIVES
          </button>
        </div>
      </div>
    </div>
  );
};
