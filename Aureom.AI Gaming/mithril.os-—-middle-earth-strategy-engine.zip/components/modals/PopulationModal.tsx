'use client';

import React from 'react';
import { soundEngine } from '@/lib/soundEngine';
import { Users, Shield, Hammer, Sparkles, TrendingUp, AlertCircle, X } from 'lucide-react';

interface PopulationModalProps {
  onClose: () => void;
}

export const PopulationModal: React.FC<PopulationModalProps> = ({ onClose }) => {
  const structure = [
    { role: 'Field Farmers & Agrarians', count: 18500, percent: 48, icon: Hammer, desc: 'Tilling fields of Pelennor & Anórien' },
    { role: 'Royal Soldiers & Guards', count: 9800, percent: 25, icon: Shield, desc: 'Muster hosts, archers, and garrison watch' },
    { role: 'Craftsmen & Stonemasons', count: 6200, percent: 16, icon: Sparkles, desc: 'Forging steel, carving ashlar, trade goods' },
    { role: 'Scholars, Scribes & Priests', count: 2400, percent: 6, icon: Sparkles, desc: 'Archival lore, navigation, heraldry' },
    { role: 'Refugees & Unassigned', count: 1500, percent: 5, icon: Users, desc: 'Displaced families from frontier raids' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-3xl h-[75vh] bg-[#0d0f14] border border-[#a88e5e]/50 shadow-2xl rounded-sm flex flex-col text-[#d8d0c0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#292e3c] bg-[#131720]">
          <div className="flex items-center space-x-3">
            <Users className="w-5 h-5 text-[#a88e5e]" />
            <div>
              <div className="text-base font-display font-bold tracking-widest text-[#f7eedf]">
                DEMOGRAPHICS & CENSUS OF THE REALM
              </div>
              <div className="text-xs font-archival italic text-[#959fad]">
                Population distribution, labor force, migration, and civil order
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#202636] rounded text-[#8690a2] hover:text-[#f7eedf]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Key Metric Blocks */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3.5 bg-[#131720] border border-[#272d3b] rounded-sm">
              <div className="text-[10px] font-display text-[#7e8799] mb-1">TOTAL POPULATION</div>
              <div className="text-lg font-data font-bold text-[#f5eedf]">38,400</div>
              <div className="text-[9px] text-[#717887]">Max Supportable: 50,000</div>
            </div>

            <div className="p-3.5 bg-[#131720] border border-[#272d3b] rounded-sm">
              <div className="text-[10px] font-display text-[#7e8799] mb-1">ANNUAL GROWTH RATE</div>
              <div className="text-lg font-data font-bold text-[#84cc16] flex items-center space-x-1">
                <TrendingUp className="w-4 h-4" />
                <span>+2.4% / yr</span>
              </div>
              <div className="text-[9px] text-[#717887]">Fertile harvest seasons</div>
            </div>

            <div className="p-3.5 bg-[#131720] border border-[#272d3b] rounded-sm">
              <div className="text-[10px] font-display text-[#7e8799] mb-1">PUBLIC ORDER & MORALE</div>
              <div className="text-lg font-display font-bold text-[#22c55e]">HIGH (91%)</div>
              <div className="text-[9px] text-[#717887]">Loyal to High King & Realm</div>
            </div>
          </div>

          {/* Breakdown by Labor Class */}
          <div className="space-y-3">
            <div className="text-xs font-display font-bold tracking-widest text-[#a88e5e]">
              POPULATION STRUCTURE & LABOR DIVISION
            </div>

            <div className="space-y-2">
              {structure.map((item, idx) => (
                <div key={idx} className="p-3 bg-[#13161f] border border-[#262c3b] rounded-sm">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="font-display font-semibold text-[#e8dfcf]">{item.role}</span>
                    <span className="font-data font-bold text-[#f5eedf]">
                      {item.count.toLocaleString()} ({item.percent}%)
                    </span>
                  </div>
                  <div className="w-full bg-[#0c0e12] h-2 rounded-full overflow-hidden border border-[#2b303d]">
                    <div
                      className="bg-[#a88e5e] h-full"
                      style={{ width: `${item.percent}%` }}
                    />
                  </div>
                  <div className="text-[10px] font-archival text-[#8e96a6] mt-1 italic">
                    {item.desc}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#292e3c] bg-[#121620] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1b202c] hover:bg-[#252c3c] text-xs font-display text-[#f5eedf] border border-[#373e50] rounded"
          >
            DISMISS
          </button>
        </div>
      </div>
    </div>
  );
};
