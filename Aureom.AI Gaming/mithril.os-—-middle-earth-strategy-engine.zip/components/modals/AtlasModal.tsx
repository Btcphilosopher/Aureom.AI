'use client';

import React, { useState } from 'react';
import { FACTIONS_DATA, HEROES_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import { Compass, Book, Shield, Crown, MapPin, X, Search } from 'lucide-react';
import { Settlement } from '@/types/game';

interface AtlasModalProps {
  settlements: Settlement[];
  onClose: () => void;
  onJumpToLocation: (x: number, y: number) => void;
}

export const AtlasModal: React.FC<AtlasModalProps> = ({
  settlements,
  onClose,
  onJumpToLocation,
}) => {
  const [activeSection, setActiveSection] = useState<'SETTLEMENTS' | 'FACTIONS' | 'HEROES' | 'RELICS'>(
    'SETTLEMENTS'
  );
  const [searchQuery, setSearchQuery] = useState('');

  const relics = [
    {
      id: 'narsil',
      name: 'Narsil / Andúril, Flame of the West',
      bearer: 'Aragorn son of Arathorn',
      desc: 'The blade that cut the One Ring from Sauron’s hand, reforged in Rivendell with runes of seven stars.',
    },
    {
      id: 'glamdring',
      name: 'Glamdring, the Foe-hammer',
      bearer: 'Gandalf the White',
      desc: 'Ancient elven sword forged in Gondolin for King Turgon, glows cold blue in the presence of orcs.',
    },
    {
      id: 'palantiri',
      name: 'The Palantíri (Seeing Stones)',
      bearer: 'Preserved in Minas Tirith and Orthanc',
      desc: 'Indestructible crystal globes forged by Fëanor in Eldamar to view places and communicate minds across great distances.',
    },
    {
      id: 'nauglamir',
      name: 'The Nauglamír (Necklace of the Dwarves)',
      bearer: 'Lost in the First Age',
      desc: 'Greatest carcanet of gold and gems crafted by the Dwarves of Nogrod, set with a Silmaril of Fëanor.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-5xl h-[85vh] bg-[#0c0c0b] border border-[#a68a53]/20 shadow-2xl rounded-sm flex flex-col text-[#d4c5a9] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#a68a53]/20 bg-[#0c0c0b]/80">
          <div className="flex items-center space-x-3">
            <Compass className="w-5 h-5 text-[#a68a53]" />
            <div>
              <div className="text-base font-serif font-bold tracking-widest text-[#d4c5a9] uppercase">
                The Royal Atlas & Archive of Arda
              </div>
              <div className="text-xs font-serif italic text-[#a68a53]/70">
                A comprehensive compendium of realms, citadels, champions, and sacred relics
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#a68a53]/10 rounded-sm text-[#a68a53]/60 hover:text-[#d4c5a9] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section Navigation & Search */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-[#a68a53]/20 bg-[#0c0c0b]">
          <div className="flex items-center space-x-2 text-xs font-serif uppercase tracking-wider">
            {(['SETTLEMENTS', 'FACTIONS', 'HEROES', 'RELICS'] as const).map((sec) => (
              <button
                key={sec}
                onClick={() => {
                  setActiveSection(sec);
                  soundEngine.playParchmentPage();
                }}
                className={`px-3 py-1.5 rounded-sm transition-colors ${
                  activeSection === sec
                    ? 'bg-[#a68a53]/20 text-[#d4c5a9] border border-[#a68a53] font-bold'
                    : 'text-[#a68a53]/60 hover:text-[#d4c5a9]'
                }`}
              >
                {sec}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-2 bg-[#1a1814] px-2.5 py-1 rounded-sm border border-[#a68a53]/20 text-xs">
            <Search className="w-3.5 h-3.5 text-[#a68a53]/60" />
            <input
              type="text"
              placeholder="Search lore entries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent border-none outline-none text-xs text-[#d4c5a9] placeholder-[#a68a53]/40 w-48 font-serif"
            />
          </div>
        </div>

        {/* Section Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeSection === 'SETTLEMENTS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {settlements
                .filter((s) => s.name.toLowerCase().includes(searchQuery.toLowerCase()))
                .map((s) => (
                  <div
                    key={s.id}
                    className="p-4 bg-[#1a1814] border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-sm font-serif font-bold text-[#d4c5a9]">
                          {s.name}
                        </div>
                        <div className="text-xs font-serif italic text-[#a68a53]">
                          {s.region} • Realm of {s.faction}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          onJumpToLocation(s.x, s.y);
                          onClose();
                          soundEngine.playTacticalClick();
                        }}
                        className="flex items-center space-x-1 px-2 py-1 bg-[#0c0c0b] hover:bg-[#a68a53]/10 text-xs font-serif uppercase tracking-wider text-[#a68a53] border border-[#a68a53]/30 rounded-sm transition-colors"
                      >
                        <MapPin className="w-3 h-3" />
                        <span>View Map</span>
                      </button>
                    </div>
                    <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic mt-2">
                      &ldquo;{s.historicalNotes}&rdquo;
                    </p>
                    <div className="flex space-x-4 mt-3 pt-2 border-t border-[#a68a53]/15 text-[10px] font-mono text-[#a68a53]/70">
                      <span>Population: {s.population.toLocaleString()}</span>
                      <span>Walls: Tier {s.wallsLevel}</span>
                      <span>Garrison: {s.garrisonStrength}</span>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {activeSection === 'FACTIONS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.values(FACTIONS_DATA)
                .filter((f) => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
                .map((f) => (
                  <div
                    key={f.id}
                    className="p-4 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm"
                  >
                    <div className="flex items-center space-x-2.5">
                      <div
                        className="w-3 h-3 rounded-full ring-1 ring-[#a68a53]/40"
                        style={{ backgroundColor: f.accentColor }}
                      />
                      <div className="text-sm font-serif font-bold text-[#d4c5a9]">
                        {f.name}
                      </div>
                    </div>
                    <div className="text-xs font-serif text-[#a68a53] italic mt-0.5">
                      Ruler: {f.leaderTitle} • Capital: {f.capitalName}
                    </div>
                    <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic mt-2">
                      &ldquo;{f.startingDescription}&rdquo;
                    </p>
                  </div>
                ))}
            </div>
          )}

          {activeSection === 'HEROES' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {HEROES_DATA.filter((h) => h.name.toLowerCase().includes(searchQuery.toLowerCase())).map(
                (h) => (
                  <div
                    key={h.id}
                    className="p-4 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm"
                  >
                    <div className="text-sm font-serif font-bold text-[#d4c5a9]">
                      {h.name}
                    </div>
                    <div className="text-xs font-serif text-[#a68a53] italic">
                      {h.title} • {h.faction}
                    </div>
                    <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic mt-2">
                      Weapon: {h.equipment?.weapon} • Relic: {h.equipment?.relic}
                    </p>
                    <div className="grid grid-cols-3 gap-2 mt-3 pt-2 border-t border-[#a68a53]/15 text-[10px] font-mono text-[#a68a53]/70">
                      <div>COMMAND: {h.commandRating * 10}/100</div>
                      <div>COMBAT: {h.combatRating * 10}/100</div>
                      <div>EXPERIENCE: {h.experience} Stars</div>
                    </div>
                  </div>
                )
              )}
            </div>
          )}

          {activeSection === 'RELICS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {relics.map((r) => (
                <div key={r.id} className="p-4 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                  <div className="text-sm font-serif font-bold text-[#d4c5a9]">{r.name}</div>
                  <div className="text-xs font-serif text-[#a68a53] italic">
                    Custody: {r.bearer}
                  </div>
                  <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic mt-2">
                    &ldquo;{r.desc}&rdquo;
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#a68a53]/20 bg-[#0c0c0b]/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm transition-colors"
          >
            Close Atlas
          </button>
        </div>
      </div>
    </div>
  );
};
