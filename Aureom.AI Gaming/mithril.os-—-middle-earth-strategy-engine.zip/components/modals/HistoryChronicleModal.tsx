'use client';

import React, { useState } from 'react';
import { HistoryEvent } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import { BookOpen, Calendar, Swords, Crown, MapPin, X, Filter } from 'lucide-react';

interface HistoryChronicleModalProps {
  events: HistoryEvent[];
  onClose: () => void;
  onJumpToEvent: (x: number, y: number) => void;
}

export const HistoryChronicleModal: React.FC<HistoryChronicleModalProps> = ({
  events,
  onClose,
  onJumpToEvent,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const filteredEvents =
    selectedCategory === 'ALL'
      ? events
      : events.filter((e) => e.category === selectedCategory);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-4xl h-[85vh] bg-[#0c0c0b] border border-[#a68a53]/20 shadow-2xl rounded-sm flex flex-col text-[#d4c5a9] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#a68a53]/20 bg-[#0c0c0b]/80">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-5 h-5 text-[#a68a53]" />
            <div>
              <div className="text-base font-serif font-bold tracking-widest text-[#d4c5a9] uppercase">
                Chronicles of the Ages of Middle-earth
              </div>
              <div className="text-xs font-serif italic text-[#a68a53]/70">
                Recorded deeds, great sieges, kingships, and historical turning points
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#a68a53]/10 rounded-sm text-[#a68a53]/60 hover:text-[#d4c5a9] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center space-x-2 px-6 py-3 border-b border-[#a68a53]/20 bg-[#0c0c0b] text-xs">
          <Filter className="w-3.5 h-3.5 text-[#a68a53]" />
          <span className="font-mono text-[9px] uppercase tracking-widest text-[#a68a53] font-bold mr-2">
            Filter Archives:
          </span>

          {['ALL', 'MILITARY', 'POLITICAL', 'CULTURAL', 'CONSTRUCTION'].map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                soundEngine.playTacticalClick();
              }}
              className={`px-2.5 py-1 rounded-sm text-xs font-serif uppercase tracking-wider transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#a68a53]/20 text-[#d4c5a9] border border-[#a68a53] font-bold'
                  : 'text-[#a68a53]/60 hover:text-[#d4c5a9]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Timeline Events List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {filteredEvents.map((ev) => (
            <div
              key={ev.id}
              className="p-4 bg-[#1a1814] border border-[#a68a53]/20 hover:border-[#a68a53]/50 rounded-sm transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 bg-[#a68a53]/15 text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm text-[10px] font-mono font-bold">
                      {ev.age.replace('_', ' ')} • YEAR {ev.year}
                    </span>
                    <span className="text-[9px] font-mono text-[#a68a53] uppercase tracking-widest">
                      {ev.category}
                    </span>
                  </div>
                  <div className="text-sm font-serif font-bold text-[#d4c5a9] mt-1.5">
                    {ev.title}
                  </div>
                </div>

                {ev.x !== undefined && ev.y !== undefined && (
                  <button
                    onClick={() => {
                      onJumpToEvent(ev.x!, ev.y!);
                      onClose();
                      soundEngine.playTacticalClick();
                    }}
                    className="flex items-center space-x-1 px-2.5 py-1 bg-[#0c0c0b] hover:bg-[#a68a53]/10 text-[#a68a53] hover:text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm text-xs font-serif uppercase tracking-wider transition-colors"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#a68a53]" />
                    <span>View Region</span>
                  </button>
                )}
              </div>

              <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic mt-2">
                &ldquo;{ev.summary || (ev as any).description}&rdquo;
              </p>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#a68a53]/20 bg-[#0c0c0b]/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1a1814] hover:bg-[#a68a53]/10 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] border border-[#a68a53]/30 rounded-sm transition-colors"
          >
            Close Chronicles
          </button>
        </div>
      </div>
    </div>
  );
};
