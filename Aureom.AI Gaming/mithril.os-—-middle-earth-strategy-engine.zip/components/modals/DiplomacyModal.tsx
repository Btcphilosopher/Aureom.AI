'use client';

import React, { useState } from 'react';
import { DiplomacyRelation, FactionId } from '@/types/game';
import { FACTIONS_DATA } from '@/lib/gameData';
import { soundEngine } from '@/lib/soundEngine';
import { Crown, Handshake, Shield, Swords, Gift, X, Scroll } from 'lucide-react';

interface DiplomacyModalProps {
  playerFaction: FactionId;
  diplomacy: DiplomacyRelation[];
  onUpdateRelation: (targetFaction: FactionId, newStatus: any) => void;
  onClose: () => void;
}

export const DiplomacyModal: React.FC<DiplomacyModalProps> = ({
  playerFaction,
  diplomacy,
  onUpdateRelation,
  onClose,
}) => {
  const [selectedFactionId, setSelectedFactionId] = useState<FactionId>('ROHAN');
  const [diplomaticLog, setDiplomaticLog] = useState<string[]>([
    'Emissaries from Edoras pledge mutual riders along the Great West Road.',
    'Envoys sent to Rivendell bearing gifts of silver craft.',
  ]);

  const selectedFaction = FACTIONS_DATA[selectedFactionId];
  const relation: DiplomacyRelation = diplomacy.find(
    (d) =>
      (d.factionA === playerFaction && d.factionB === selectedFactionId) ||
      (d.factionB === playerFaction && d.factionA === selectedFactionId) ||
      d.factionId === selectedFactionId
  ) || {
    factionId: selectedFactionId,
    relationScore: 50,
    status: 'NEUTRAL',
    attitude: 'GUARDED',
    militaryComparison: 'EQUIVALENT',
    economicComparison: 'EQUIVALENT',
    treaties: [],
    tradeAgreements: false,
    historyLog: [],
    trustScore: 50,
    tradeAgreement: false,
    militaryAccess: false,
    warScore: 0,
  };

  const handleAction = (actionName: string, statusChange?: any) => {
    soundEngine.playParchmentPage();
    if (statusChange) {
      onUpdateRelation(selectedFactionId, statusChange);
    }
    setDiplomaticLog((prev) => [
      `Envoys dispatched: [${actionName}] conveyed to ${selectedFaction.name}.`,
      ...prev.slice(0, 4),
    ]);
  };

  const otherFactions = (Object.keys(FACTIONS_DATA) as FactionId[]).filter(
    (f) => f !== playerFaction
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-5xl h-[85vh] bg-[#0c0c0b] border border-[#a68a53]/20 shadow-2xl rounded-sm flex flex-col text-[#d4c5a9] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#a68a53]/20 bg-[#0c0c0b]/80">
          <div className="flex items-center space-x-3">
            <Crown className="w-5 h-5 text-[#a68a53]" />
            <div>
              <div className="text-base font-serif font-bold tracking-widest text-[#d4c5a9] uppercase">
                High Council of Realms — Geopolitical Diplomacy
              </div>
              <div className="text-xs font-serif italic text-[#a68a53]/70">
                Treaties, alliances, embassies, and royal envoys across Middle-earth
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#a68a53]/10 rounded-sm text-[#a68a53]/60 hover:text-[#d4c5a9] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Layout: Left list of factions, Right active embassy */}
        <div className="flex-1 flex overflow-hidden">
          {/* Faction List */}
          <div className="w-72 border-r border-[#a68a53]/20 bg-[#0c0c0b] overflow-y-auto p-2 space-y-1">
            <div className="px-3 py-1.5 text-[9px] font-mono text-[#a68a53] uppercase tracking-widest font-bold">
              Sovereign Realms
            </div>
            {otherFactions.map((fId) => {
              const fac = FACTIONS_DATA[fId];
              const rel = diplomacy.find(
                (d) =>
                  (d.factionA === playerFaction && d.factionB === fId) ||
                  (d.factionB === playerFaction && d.factionA === fId)
              );
              const status = rel ? rel.status : 'NEUTRAL';
              const isSelected = selectedFactionId === fId;

              return (
                <button
                  key={fId}
                  onClick={() => {
                    setSelectedFactionId(fId);
                    soundEngine.playTacticalClick();
                  }}
                  className={`w-full p-2.5 rounded-sm flex items-center justify-between text-left transition-colors ${
                    isSelected
                      ? 'bg-[#1a1814] border border-[#a68a53] text-[#d4c5a9]'
                      : 'hover:bg-[#a68a53]/10 text-[#a68a53]/70'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <div
                      className="w-2.5 h-2.5 rounded-full ring-1 ring-[#a68a53]/40"
                      style={{ backgroundColor: fac.accentColor }}
                    />
                    <div>
                      <div className="text-xs font-serif font-semibold text-[#d4c5a9]">
                        {fac.name}
                      </div>
                      <div className="text-[10px] font-serif italic text-[#a68a53]/60">
                        {fac.leaderTitle}
                      </div>
                    </div>
                  </div>

                  <span
                    className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-sm ${
                      status === 'ALLIED'
                        ? 'bg-[#1a1814] text-[#a68a53] border border-[#a68a53]/40'
                        : status === 'WAR'
                        ? 'bg-[#200e0e] text-red-300 border border-red-800/60'
                        : 'bg-[#1a1814]/60 text-[#a68a53]/60 border border-[#a68a53]/20'
                    }`}
                  >
                    {status}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Detailed Embassy Chamber */}
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            <div className="flex items-start justify-between pb-4 border-b border-[#a68a53]/20">
              <div>
                <h2 className="text-xl font-serif font-bold text-[#d4c5a9] tracking-wider uppercase">
                  {selectedFaction.name}
                </h2>
                <div className="text-xs font-serif italic text-[#a68a53]/70 mt-0.5">
                  Capital: {selectedFaction.capitalName} • Culture: {selectedFaction.culture}
                </div>
              </div>

              <div className="text-right">
                <div className="text-[9px] font-mono text-[#a68a53] uppercase tracking-widest font-bold">Diplomatic Stance</div>
                <div
                  className={`text-sm font-mono font-bold tracking-wider ${
                    relation.status === 'ALLIED' || relation.status === 'ALLIANCE'
                      ? 'text-[#a68a53]'
                      : relation.status === 'WAR'
                      ? 'text-red-400'
                      : 'text-[#d4c5a9]'
                  }`}
                >
                  {relation.status}
                </div>
              </div>
            </div>

            {/* Relations & Trust Bar */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="text-[9px] font-mono uppercase tracking-widest text-[#a68a53] mb-1 font-bold">
                  Trust & Reputation
                </div>
                <div className="text-sm font-mono font-bold text-[#d4c5a9]">
                  {relation.trustScore ?? Math.max(0, relation.relationScore)} / 100
                </div>
                <div className="w-full bg-[#0c0c0b] h-1.5 rounded-none overflow-hidden border border-[#a68a53]/30 mt-1.5">
                  <div
                    className="bg-[#a68a53] h-full"
                    style={{ width: `${relation.trustScore ?? Math.max(0, relation.relationScore)}%` }}
                  />
                </div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="text-[9px] font-mono uppercase tracking-widest text-[#a68a53] mb-1 font-bold">
                  Commercial Status
                </div>
                <div className="text-xs font-mono font-bold text-[#d4c5a9] truncate">
                  {(relation.tradeAgreement || relation.tradeAgreements) ? 'ACTIVE TRADE PACT' : 'NO COMMERCIAL PACT'}
                </div>
                <div className="text-[9px] font-serif italic text-[#a68a53]/60 mt-1">
                  {(relation.tradeAgreement || relation.tradeAgreements) ? '+140 gold/m flows' : 'Taxes apply'}
                </div>
              </div>

              <div className="p-3 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
                <div className="text-[9px] font-mono uppercase tracking-widest text-[#a68a53] mb-1 font-bold">
                  Military Transit
                </div>
                <div className="text-xs font-mono font-bold text-[#d4c5a9] truncate">
                  {relation.militaryAccess ? 'OPEN BORDERS' : 'RESTRICTED'}
                </div>
                <div className="text-[9px] font-serif italic text-[#a68a53]/60 mt-1">Hostile armies trespass at peril</div>
              </div>
            </div>

            {/* Historical Summary / Lore */}
            <div className="p-4 bg-[#1a1814] border border-[#a68a53]/20 rounded-sm">
              <div className="text-[9px] font-mono uppercase tracking-widest text-[#a68a53] mb-1 font-bold">
                Lore of Relations & Alliances
              </div>
              <p className="text-xs font-serif text-[#d4c5a9]/80 leading-relaxed italic">
                &ldquo;{selectedFaction.startingDescription}&rdquo;
              </p>
            </div>

            {/* Diplomatic Actions Grid */}
            <div>
              <div className="text-[9px] font-mono font-bold tracking-widest text-[#a68a53] uppercase mb-3">
                Envoy Initiatives
              </div>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => handleAction('Offer Non-Aggression Pact', 'NON_AGGRESSION')}
                  className="p-3 bg-[#1a1814] hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/60 rounded-sm flex items-center space-x-2 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] transition-colors"
                >
                  <Handshake className="w-4 h-4 text-[#8fb9d4]" />
                  <span>Non-Aggression Pact</span>
                </button>

                <button
                  onClick={() => handleAction('Sign Military Alliance', 'ALLIED')}
                  className="p-3 bg-[#1a1814] hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/60 rounded-sm flex items-center space-x-2 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] transition-colors"
                >
                  <Shield className="w-4 h-4 text-[#a68a53]" />
                  <span>Ratify Alliance</span>
                </button>

                <button
                  onClick={() => handleAction('Send Royal Gift (Gold)', undefined)}
                  className="p-3 bg-[#1a1814] hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/60 rounded-sm flex items-center space-x-2 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] transition-colors"
                >
                  <Gift className="w-4 h-4 text-[#a68a53]" />
                  <span>Dispatch Royal Gift</span>
                </button>

                <button
                  onClick={() => handleAction('Propose Commercial Trade Pact', undefined)}
                  className="p-3 bg-[#1a1814] hover:bg-[#a68a53]/15 border border-[#a68a53]/20 hover:border-[#a68a53]/60 rounded-sm flex items-center space-x-2 text-xs font-serif uppercase tracking-wider text-[#d4c5a9] transition-colors"
                >
                  <Scroll className="w-4 h-4 text-[#a68a53]" />
                  <span>Trade Agreement</span>
                </button>

                <button
                  onClick={() => handleAction('Declare Open War', 'WAR')}
                  className="p-3 bg-[#200e0e] hover:bg-[#2e1212] border border-red-800/80 rounded-sm flex items-center space-x-2 text-xs font-serif uppercase tracking-wider font-bold text-red-300 transition-colors"
                >
                  <Swords className="w-4 h-4 text-red-400" />
                  <span>Declare War</span>
                </button>
              </div>
            </div>

            {/* Envoys Log */}
            <div className="p-3 bg-[#0c0c0b] border border-[#a68a53]/20 rounded-sm">
              <div className="text-[9px] font-mono text-[#a68a53] uppercase tracking-widest mb-1 font-bold">
                Recent Diplomatic Dispatches
              </div>
              <div className="space-y-1 text-xs font-serif text-[#d4c5a9]/70 italic">
                {diplomaticLog.map((log, i) => (
                  <div key={i}>• {log}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
