'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Army, Settlement } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import { Search, MapPin, Swords, Shield, X } from 'lucide-react';

interface CommandPaletteProps {
  settlements: Settlement[];
  armies: Army[];
  isOpen: boolean;
  onClose: () => void;
  onSelectSettlement: (settlement: Settlement) => void;
  onSelectArmy: (army: Army) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  settlements,
  armies,
  isOpen,
  onClose,
  onSelectSettlement,
  onSelectArmy,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleClose = () => {
    setQuery('');
    onClose();
  };

  if (!isOpen) return null;

  const filteredSettlements = settlements.filter(
    (s) =>
      s.name.toLowerCase().includes(query.toLowerCase()) ||
      s.region.toLowerCase().includes(query.toLowerCase())
  );

  const filteredArmies = armies.filter(
    (a) =>
      a.name.toLowerCase().includes(query.toLowerCase()) ||
      a.commanderName.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 bg-black/75 backdrop-blur-sm select-none p-4">
      <div className="relative w-full max-w-xl bg-[#0f1218] border border-[#a88e5e]/60 shadow-2xl rounded-sm text-[#d4cbba] overflow-hidden">
        {/* Input Bar */}
        <div className="flex items-center px-4 py-3 border-b border-[#292f3d] bg-[#141822]">
          <Search className="w-4 h-4 text-[#a88e5e] mr-3" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search settlements, legions, heroes, or provinces..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-sm font-display text-[#f5eedf] placeholder-[#6d7585]"
          />
          <button
            onClick={handleClose}
            className="p-1 hover:bg-[#202534] rounded text-[#818a9c] hover:text-[#f0eae0]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1 text-xs">
          {filteredSettlements.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-display text-[#7e8799] tracking-widest">
                SETTLEMENTS & CITADELS
              </div>
              {filteredSettlements.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    onSelectSettlement(s);
                    onClose();
                    soundEngine.playTacticalClick();
                  }}
                  className="w-full px-3 py-2 rounded-sm hover:bg-[#181d28] flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-3.5 h-3.5 text-[#a88e5e]" />
                    <span className="font-display font-semibold text-[#f5eedf]">{s.name}</span>
                    <span className="text-[10px] font-archival text-[#8992a2] italic">
                      ({s.region})
                    </span>
                  </div>
                  <span className="text-[10px] font-data text-[#8992a2]">
                    Pop: {s.population.toLocaleString()}
                  </span>
                </button>
              ))}
            </div>
          )}

          {filteredArmies.length > 0 && (
            <div className="mt-2">
              <div className="px-3 py-1 text-[10px] font-display text-[#7e8799] tracking-widest">
                MILITARY HOSTS & WAR BANDS
              </div>
              {filteredArmies.map((a) => (
                <button
                  key={a.id}
                  onClick={() => {
                    onSelectArmy(a);
                    onClose();
                    soundEngine.playTacticalClick();
                  }}
                  className="w-full px-3 py-2 rounded-sm hover:bg-[#181d28] flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center space-x-2">
                    <Swords className="w-3.5 h-3.5 text-[#ef4444]" />
                    <span className="font-display font-semibold text-[#f5eedf]">{a.name}</span>
                    <span className="text-[10px] font-archival text-[#8992a2] italic">
                      ({a.commanderName})
                    </span>
                  </div>
                  <span className="text-[10px] font-data text-[#8992a2]">
                    {a.size.toLocaleString()} warriors
                  </span>
                </button>
              ))}
            </div>
          )}

          {filteredSettlements.length === 0 && filteredArmies.length === 0 && (
            <div className="py-8 text-center text-xs font-archival text-[#788090] italic">
              No matching citadels, legions, or heroes discovered in the imperial annals.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
