'use client';

import React from 'react';
import { CameraState } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import { Activity, Cpu, Camera, Terminal, X, RefreshCw } from 'lucide-react';

interface DebugModalProps {
  fps: number;
  camera: CameraState;
  entityCount: { settlements: number; armies: number; combats: number };
  tickCount: number;
  onClose: () => void;
  onTriggerEvent: () => void;
}

export const DebugModal: React.FC<DebugModalProps> = ({
  fps,
  camera,
  entityCount,
  tickCount,
  onClose,
  onTriggerEvent,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-2xl bg-[#0b0d12] border border-[#38bdf8]/40 shadow-2xl rounded-sm text-[#d4cbba] font-mono overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#1f2937] bg-[#111827]">
          <div className="flex items-center space-x-2 text-[#38bdf8]">
            <Terminal className="w-4 h-4" />
            <span className="text-xs font-bold tracking-widest">
              MITHRIL.OS // SYSTEM TELEMETRY & ENGINE INSPECTOR
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#1f2937] rounded text-[#9ca3af] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Telemetry Panels */}
        <div className="p-5 space-y-4 text-xs">
          {/* Engine Performance */}
          <div className="p-3 bg-[#111827]/70 border border-[#1f2937] rounded-sm">
            <div className="flex items-center space-x-2 text-[#a88e5e] mb-2 font-bold">
              <Activity className="w-3.5 h-3.5" />
              <span>GRAPHICS & FRAMETIME</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-[11px] text-[#9ca3af]">
              <div>
                FPS:{' '}
                <span className={fps < 30 ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {fps}
                </span>
              </div>
              <div>FRAMETIME: {(1000 / Math.max(1, fps)).toFixed(2)} ms</div>
              <div>RENDER ENGINE: Canvas2D / DPR {typeof window !== 'undefined' ? window.devicePixelRatio : 1}</div>
            </div>
          </div>

          {/* Simulation Diagnostics */}
          <div className="p-3 bg-[#111827]/70 border border-[#1f2937] rounded-sm">
            <div className="flex items-center space-x-2 text-[#38bdf8] mb-2 font-bold">
              <Cpu className="w-3.5 h-3.5" />
              <span>SIMULATION CYCLE & ENTITY COUNTS</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-[#9ca3af]">
              <div>ACTIVE SETTLEMENTS: {entityCount.settlements}</div>
              <div>REGISTERED ARMIES: {entityCount.armies}</div>
              <div>ENGAGED COMBATS: {entityCount.combats}</div>
              <div>TOTAL ENGINE TICKS: {tickCount.toLocaleString()}</div>
            </div>
          </div>

          {/* Camera Telemetry */}
          <div className="p-3 bg-[#111827]/70 border border-[#1f2937] rounded-sm">
            <div className="flex items-center space-x-2 text-[#f59e0b] mb-2 font-bold">
              <Camera className="w-3.5 h-3.5" />
              <span>CAMERA COORDINATES & VIEWPORT</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-[11px] text-[#9ca3af]">
              <div>X: {Math.round(camera.x)}</div>
              <div>Y: {Math.round(camera.y)}</div>
              <div>ZOOM: {camera.zoom.toFixed(2)}x</div>
              <div>ROTATION: {camera.rotationDeg}°</div>
              <div>PITCH: {camera.pitchDeg}°</div>
              <div>MODE: ORTHO 2.5D</div>
            </div>
          </div>

          {/* Quick Debug Triggers */}
          <div className="pt-2 border-t border-[#1f2937] flex items-center justify-between">
            <button
              onClick={() => {
                onTriggerEvent();
                soundEngine.playWarHorn();
              }}
              className="px-3 py-1.5 bg-[#374151] hover:bg-[#4b5563] text-white rounded text-xs flex items-center space-x-1 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>DISPATCH RANDOM DISASTER EVENT</span>
            </button>

            <span className="text-[10px] text-[#6b7280]">
              MIDDLE-EARTH STRATEGY ENGINE v3.8.2
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
