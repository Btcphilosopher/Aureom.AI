'use client';

import React, { useState } from 'react';
import { GameResources, ResourceRate, ResourceType } from '@/types/game';
import { soundEngine } from '@/lib/soundEngine';
import {
  Wheat,
  Trees,
  Mountain,
  Flame,
  Coins,
  Gem,
  TrendingUp,
  X,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

interface ResourceOverviewModalProps {
  resources: GameResources;
  resourceRates: ResourceRate;
  onClose: () => void;
  onShowOnMap: (resource: ResourceType) => void;
}

export const ResourceOverviewModal: React.FC<ResourceOverviewModalProps> = ({
  resources,
  resourceRates,
  onClose,
  onShowOnMap,
}) => {
  const [selectedRes, setSelectedRes] = useState<ResourceType>('food');

  const resourceData: Record<
    ResourceType,
    {
      name: string;
      desc: string;
      capacity: number;
      sources: string[];
      destinations: string[];
      risk: 'LOW' | 'MEDIUM' | 'CRITICAL';
      icon: any;
    }
  > = {
    food: {
      name: 'Grain & Provisions',
      desc: 'Wheat from the Pelennor and valley crofts. Consumed continuously by kingdom population and marching armies.',
      capacity: 25000,
      sources: ['Pelennor Valley Farms (+50/m)', 'Anórien Granaries (+30/m)', 'River Fisheries (+15/m)'],
      destinations: ['Kingdom Population (-20/m)', 'Army Hosts Upkeep (-15/m)'],
      risk: 'LOW',
      icon: Wheat,
    },
    wood: {
      name: 'Timber & Lumber',
      desc: 'Hardwood cut from the slopes of the White Mountains and Ithilien groves. Essential for war galleys and siege catapults.',
      capacity: 15000,
      sources: ['White Mountain Sawmills (+35/m)', 'Ithilien Woodcutters (+20/m)'],
      destinations: ['Citadel Expansion (-10/m)', 'Spear & Bow Craft (-10/m)'],
      risk: 'LOW',
      icon: Trees,
    },
    stone: {
      name: 'Ashlar & Granite',
      desc: 'White stone hewn from royal quarries in Mindolluin. High resistance against siege bombardment.',
      capacity: 20000,
      sources: ['Mount Mindolluin Quarries (+40/m)'],
      destinations: ['Outer Wall Repairs (-15/m)'],
      risk: 'LOW',
      icon: Mountain,
    },
    iron: {
      name: 'Iron & Black Ore',
      desc: 'Smelted in royal forges for plate armor, sword blades, and ballista bolts.',
      capacity: 10000,
      sources: ['Anórien Iron Mines (+25/m)', 'Dwarven Ingot Imports (+10/m)'],
      destinations: ['Armoury Forging (-15/m)'],
      risk: 'MEDIUM',
      icon: Flame,
    },
    gold: {
      name: 'Royal Bullion & Coinage',
      desc: 'Taxes on merchant caravans and tithes from the Great Haven of Pelargir.',
      capacity: 50000,
      sources: ['Pelargir Harbor Tolls (+45/m)', 'Crown Sovereign Tax (+30/m)'],
      destinations: ['Diplomatic Envoys (-10/m)', 'Garrison Wages (-20/m)'],
      risk: 'LOW',
      icon: Coins,
    },
    mithril: {
      name: 'Mithril (True-silver)',
      desc: 'The rarest metal in Arda, light as a feather yet hard as dragon scales. Found only in Moria and preserved in ancient vaults.',
      capacity: 1000,
      sources: ['Ancient Vault Reserves (+2/m)'],
      destinations: ['Relic Restoration (-1/m)'],
      risk: 'CRITICAL',
      icon: Gem,
    },
  };

  const curr = resourceData[selectedRes];
  const CurrIcon = curr.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md select-none p-4">
      <div className="relative w-full max-w-4xl h-[78vh] bg-[#0d0f14] border border-[#a88e5e]/50 shadow-2xl rounded-sm flex flex-col text-[#d8d0c0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#292e3c] bg-[#131720]">
          <div className="flex items-center space-x-3">
            <Coins className="w-5 h-5 text-[#f59e0b]" />
            <div>
              <div className="text-base font-display font-bold tracking-widest text-[#f7eedf]">
                CHAMBER OF COMMERCE — RESOURCE & SUPPLY OVERVIEW
              </div>
              <div className="text-xs font-archival italic text-[#959fad]">
                Real-time treasury flows, extraction rates, and supply reserves across Middle-earth
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 hover:bg-[#202636] rounded text-[#8690a2] hover:text-[#f7eedf]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Resource Selector Ribbons */}
        <div className="grid grid-cols-6 border-b border-[#252a37] bg-[#10131b]">
          {(Object.keys(resourceData) as ResourceType[]).map((res) => {
            const data = resourceData[res];
            const ResIcon = data.icon;
            const isSelected = selectedRes === res;

            return (
              <button
                key={res}
                onClick={() => {
                  setSelectedRes(res);
                  soundEngine.playTacticalClick();
                }}
                className={`p-3 text-center flex flex-col items-center justify-center space-y-1 transition-colors border-r border-[#252a37] last:border-r-0 ${
                  isSelected
                    ? 'bg-[#151922] border-b-2 border-b-[#a88e5e] text-[#f5eedf]'
                    : 'text-[#848d9e] hover:text-[#ded5c5]'
                }`}
              >
                <ResIcon className="w-4 h-4" />
                <span className="text-[10px] font-display uppercase tracking-wider">{res}</span>
                <span className="text-xs font-data font-bold text-[#f5eedf]">
                  {resources[res].toLocaleString()}
                </span>
              </button>
            );
          })}
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-[#282e3c]">
            <div className="flex items-center space-x-3">
              <CurrIcon className="w-6 h-6 text-[#a88e5e]" />
              <div>
                <h3 className="text-lg font-display font-bold text-[#f5eedf]">{curr.name}</h3>
                <p className="text-xs font-archival text-[#9ca5b5] italic">{curr.desc}</p>
              </div>
            </div>

            <button
              onClick={() => {
                onShowOnMap(selectedRes);
                onClose();
                soundEngine.playTacticalClick();
              }}
              className="px-3 py-1.5 bg-[#a88e5e]/25 hover:bg-[#a88e5e]/40 text-[#fbf6eb] border border-[#a88e5e]/60 rounded text-xs font-display font-semibold transition-colors"
            >
              SHOW DEPOSITS ON MAP
            </button>
          </div>

          {/* Grid Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="p-3 bg-[#131720] border border-[#272d3b] rounded-sm">
              <div className="text-[10px] font-display text-[#7e8799] mb-1">CURRENT RESERVES</div>
              <div className="text-base font-data font-bold text-[#f5eedf]">
                {resources[selectedRes].toLocaleString()}
              </div>
              <div className="text-[9px] text-[#717887]">
                Cap: {curr.capacity.toLocaleString()}
              </div>
              <div className="w-full bg-[#0c0e12] h-1.5 rounded-full overflow-hidden mt-1.5">
                <div
                  className="bg-[#a88e5e] h-full"
                  style={{ width: `${Math.min(100, (resources[selectedRes] / curr.capacity) * 100)}%` }}
                />
              </div>
            </div>

            <div className="p-3 bg-[#131720] border border-[#272d3b] rounded-sm">
              <div className="text-[10px] font-display text-[#7e8799] mb-1">NET PRODUCTION RATE</div>
              <div className="text-base font-data font-bold text-[#84cc16] flex items-center space-x-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>+{resourceRates[selectedRes]}/min</span>
              </div>
              <div className="text-[9px] text-[#717887]">Surplus added to state storehouses</div>
            </div>

            <div className="p-3 bg-[#131720] border border-[#272d3b] rounded-sm">
              <div className="text-[10px] font-display text-[#7e8799] mb-1">SHORTAGE RISK</div>
              <div
                className={`text-base font-display font-bold ${
                  curr.risk === 'CRITICAL'
                    ? 'text-[#ef4444]'
                    : curr.risk === 'MEDIUM'
                    ? 'text-[#f59e0b]'
                    : 'text-[#22c55e]'
                }`}
              >
                {curr.risk}
              </div>
              <div className="text-[9px] text-[#717887]">Safe for winter season</div>
            </div>
          </div>

          {/* Sources and Sinks */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-[#12161f] border border-[#272d3b] rounded-sm">
              <div className="text-xs font-display font-bold text-[#84cc16] mb-2 flex items-center space-x-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>PRIMARY PRODUCTION SOURCES</span>
              </div>
              <div className="space-y-1.5 text-xs font-archival text-[#b5adb1]">
                {curr.sources.map((src, i) => (
                  <div key={i} className="p-1.5 bg-[#171c26] rounded">
                    • {src}
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-[#12161f] border border-[#272d3b] rounded-sm">
              <div className="text-xs font-display font-bold text-[#ef4444] mb-2 flex items-center space-x-1">
                <ArrowDownRight className="w-4 h-4" />
                <span>CONSUMPTION & SINK DESTINATIONS</span>
              </div>
              <div className="space-y-1.5 text-xs font-archival text-[#b5adb1]">
                {curr.destinations.map((dst, i) => (
                  <div key={i} className="p-1.5 bg-[#171c26] rounded">
                    • {dst}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#292e3c] bg-[#121620] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1b202c] hover:bg-[#252c3c] text-xs font-display text-[#f5eedf] border border-[#373e50] rounded"
          >
            RETURN TO COMMAND TABLE
          </button>
        </div>
      </div>
    </div>
  );
};
