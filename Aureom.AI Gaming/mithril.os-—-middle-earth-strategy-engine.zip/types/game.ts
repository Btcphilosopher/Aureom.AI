export type AgeId = 'FIRST_AGE' | 'SECOND_AGE' | 'THIRD_AGE' | 'FOURTH_AGE';

export type FactionId = 
  | 'GONDOR' 
  | 'ROHAN' 
  | 'RIVENDELL' 
  | 'EREBOR' 
  | 'MORDOR' 
  | 'ISENGARD' 
  | 'HARAD';

export type MapLayerId = 
  | 'TERRAIN' 
  | 'POLITICAL' 
  | 'MILITARY' 
  | 'ECONOMIC' 
  | 'TRADE' 
  | 'POPULATION' 
  | 'RESOURCES' 
  | 'ROADS' 
  | 'DIPLOMACY' 
  | 'WEATHER' 
  | 'HISTORY' 
  | 'CULTURE' 
  | 'TECHNOLOGY';

export type Season = 'SPRING' | 'SUMMER' | 'AUTUMN' | 'WINTER';

export type WeatherType = 'CLEAR' | 'MIST' | 'HEAVY_RAIN' | 'SNOW' | 'ASH_FALL';

export interface GameResources {
  food: number;
  wood: number;
  stone: number;
  iron: number;
  gold: number;
  mithril: number;
}

export type ResourceType = 'food' | 'wood' | 'stone' | 'iron' | 'gold' | 'mithril';
export type TechBranch = 'MILITARY' | 'CIVIL' | 'ARCHITECTURE' | 'CRAFT' | 'LORE' | 'ECONOMY' | 'ENGINEERING' | 'AGRICULTURE' | 'TRADE' | 'FORTIFICATION' | 'CULTURE' | 'SCHOLARSHIP';

export interface ResourceRate {
  food: number;
  wood: number;
  stone: number;
  iron: number;
  gold: number;
  mithril: number;
}

export interface SettlementBuilding {
  id: string;
  name: string;
  category: 'ECONOMY' | 'MILITARY' | 'DEFENCE' | 'CIVIC';
  level: number;
  cost: Partial<GameResources>;
  buildTimeDays: number;
  production: Partial<ResourceRate>;
  bonusDescription: string;
}

export interface ConstructionQueueItem {
  id: string;
  buildingId?: string;
  name: string;
  progressPercent: number;
  daysRemaining: number;
  totalDays: number;
  cost?: Partial<GameResources>;
}

export interface Settlement {
  id: string;
  name: string;
  region: string;
  faction: FactionId;
  x: number;
  y: number;
  population: number;
  maxPopulation: number;
  wealth: number;
  foodSupply: number;
  defence: number;
  wallsLevel: number;
  loyalty: number; // 0-100
  isCapital: boolean;
  garrisonStrength: number;
  buildings: SettlementBuilding[];
  constructionQueue: ConstructionQueueItem[];
  tradePartners: string[];
  historicalNotes: string;
}

export type UnitType = 'INFANTRY' | 'ARCHERS' | 'CAVALRY' | 'SIEGE' | 'SPECIAL';

export interface UnitGroup {
  id: string;
  name: string;
  type: UnitType;
  category?: string;
  tier?: number;
  count: number;
  maxCount: number;
  health: number;
  morale: number;
  experience: number; // 1-5 stars
  attack?: number;
  defence?: number;
  armor?: number;
  veterancy?: number;
  upkeep: Partial<GameResources>;
}

export type ArmyStance = 'DEFENSIVE' | 'AGGRESSIVE' | 'SCOUT' | 'PATROL' | 'RAID' | 'RETREAT';
export type ArmyFormation = 'LINE' | 'SHIELDWALL' | 'WEDGE' | 'LOOSE' | 'SQUARE';

export interface Army {
  id: string;
  name: string;
  faction: FactionId;
  commanderName: string;
  commanderTitle: string;
  x: number;
  y: number;
  targetX?: number;
  targetY?: number;
  targetEntityId?: string;
  size: number;
  maxSize: number;
  morale: number; // 0-100
  supply: number; // 0-100
  supplyDays?: number;
  movementSpeed: number;
  stance: ArmyStance;
  formation: ArmyFormation;
  objective: string;
  units: UnitGroup[];
  isEngaged: boolean;
  engagedWithArmyId?: string;
  isSieging: boolean;
  siegingSettlementId?: string;
}

export interface Hero {
  id: string;
  name: string;
  title: string;
  ageYears: number;
  faction: FactionId;
  location: string;
  commandRating: number; // 1-10
  combatRating: number;  // 1-10
  experience: number;
  traits: string[];
  equipment: {
    weapon: string;
    armor: string;
    relic: string;
  };
  chronicle: {
    year: number;
    event: string;
  }[];
}

export interface TradeRoute {
  id: string;
  name: string;
  originSettlementId: string;
  destinationSettlementId: string;
  good: string;
  volumeTons: number;
  monthlyValueGold: number;
  securityRating: number; // 0-100%
  travelTimeDays: number;
  raidRiskPercent: number;
  isRerouted?: boolean;
}

export interface TechNode {
  id: string;
  name: string;
  branch: TechBranch;
  description: string;
  costPoints: number;
  prerequisites: string[];
  isResearched: boolean;
  isResearching: boolean;
  progressPercent: number;
  effects: string[];
  tier: number;
}

export interface DiplomaticRelation {
  factionId: FactionId;
  relationScore: number; // -100 to +100
  status: 'ALLIANCE' | 'NON_AGGRESSION' | 'NEUTRAL' | 'WAR' | 'TRIBUTARY' | 'ALLIED';
  attitude: 'HONORABLE' | 'CORDIAL' | 'GUARDED' | 'HOSTILE' | 'TREACHEROUS';
  militaryComparison: 'SUPERIOR' | 'EQUIVALENT' | 'INFERIOR';
  economicComparison: 'SUPERIOR' | 'EQUIVALENT' | 'INFERIOR';
  treaties: string[];
  tradeAgreements: boolean;
  historyLog: string[];
  // Optional convenience fields for matrix and pairings
  factionA?: FactionId;
  factionB?: FactionId;
  trustScore?: number;
  tradeAgreement?: boolean;
  militaryAccess?: boolean;
  warScore?: number;
}

export type DiplomacyRelation = DiplomaticRelation;

export interface HistoryEvent {
  id: string;
  year: number;
  age: AgeId;
  title: string;
  category: 'BATTLE' | 'KINGDOM' | 'CITY' | 'HERO' | 'DISASTER';
  locationName: string;
  x: number;
  y: number;
  summary: string;
  factionsInvolved: FactionId[];
}

export type NotificationPriority = 'CRITICAL' | 'IMPORTANT' | 'INFORMATION' | 'BACKGROUND';

export interface GameNotification {
  id: string;
  timestamp: string;
  priority: NotificationPriority;
  title: string;
  message: string;
  entityId?: string;
  entityType?: 'SETTLEMENT' | 'ARMY' | 'HERO' | 'TECH' | 'DIPLOMACY';
  x?: number;
  y?: number;
}

export interface CameraState {
  x: number;
  y: number;
  zoom: number; // 0.4 to 3.0
  rotationDeg: number;
  tiltDeg?: number;
  pitchDeg?: number;
  isCinematic?: boolean;
}

export interface FactionData {
  id: FactionId;
  name: string;
  subtitle: string;
  leader: string;
  leaderTitle: string;
  capitalName: string;
  culture: string;
  heraldryIcon: string;
  accentColor: string;
  secondaryColor: string;
  militaryRating: number;
  economicRating: number;
  startingUnitsSummary: string;
  startingDescription: string;
  traits: string[];
}

export interface AgeData {
  id: AgeId;
  name: string;
  subtitle: string;
  dateRange: string;
  defaultStartingYear: number;
  historicalDescription: string;
  worldState: string;
  majorFactions: FactionId[];
  majorRegions: string[];
  technologyEra: string;
  militaryCharacteristics: string;
}

export interface ActiveCombat {
  id: string;
  attackerArmyId?: string;
  defenderArmyId?: string;
  locationName?: string;
  name?: string;
  attackerArmyName?: string;
  defenderArmyName?: string;
  x: number;
  y: number;
  durationTicks: number;
  terrain?: string;
  terrainType?: string;
  weather?: WeatherType;
  attackerMorale: number;
  defenderMorale: number;
  attackerCasualties: number;
  defenderCasualties: number;
}

export interface ActiveSiege {
  id: string;
  armyId: string;
  settlementId: string;
  wallIntegrity: number; // 0-100
  gateIntegrity: number; // 0-100
  garrisonFoodSupplyMonths: number;
  siegeProgressPercent: number;
  action: 'ASSAULT' | 'BOMBARD' | 'BREACH' | 'STARVE' | 'WAIT' | 'NEGOTIATE';
}
