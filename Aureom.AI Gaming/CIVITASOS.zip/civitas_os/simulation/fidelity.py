"""Multi-fidelity population simulation (spec #19-#21, #83): not every
citizen needs full behavioural simulation every tick. Citizens near the
camera/selected buildings/events get high fidelity; everyone else keeps
existing and advancing through cheaper, vectorised aggregate updates.
Background citizens never disappear — they simply update at lower cost.
"""
from __future__ import annotations

from enum import IntEnum

import numpy as np


class PopulationSimulationLevel(IntEnum):
    LEVEL_0_AGGREGATE = 0     # statistical aggregate only
    LEVEL_1_HOUSEHOLD = 1     # household-level simulation
    LEVEL_2_INDIVIDUAL = 2    # individual citizen simulation
    LEVEL_3_HIGH_FIDELITY = 3 # high-fidelity local simulation
    LEVEL_4_VISIBLE = 4       # visible/rendered citizen


def assign_fidelity(citizens, active_idx: np.ndarray, focus_points: list[tuple[float, float]],
                      radii: dict[PopulationSimulationLevel, float]) -> None:
    """focus_points: camera position, selected buildings, active construction,
    transport hubs, etc. (spec #20). Citizens within radii[LEVEL_4] get the
    highest fidelity, radii[LEVEL_3] the next ring, etc.; everyone else is
    LEVEL_1/0 depending on whether their household has any active member."""
    if len(active_idx) == 0:
        return
    xs = citizens.location_x[active_idx]
    ys = citizens.location_y[active_idx]
    level = np.full(len(active_idx), int(PopulationSimulationLevel.LEVEL_1_HOUSEHOLD), dtype=np.int8)

    if focus_points:
        min_dist2 = np.full(len(active_idx), np.inf)
        for fx, fy in focus_points:
            d2 = (xs - fx) ** 2 + (ys - fy) ** 2
            min_dist2 = np.minimum(min_dist2, d2)
        for lvl in sorted(radii, reverse=True):  # widest radius first, then overwrite with tighter/higher levels
            r2 = radii[lvl] ** 2
            level[min_dist2 <= r2] = int(lvl)

    citizens.fidelity_level[active_idx] = level


def fidelity_counts(citizens, active_idx: np.ndarray) -> dict[str, int]:
    levels = citizens.fidelity_level[active_idx]
    return {
        PopulationSimulationLevel(lvl).name: int((levels == lvl).sum())
        for lvl in np.unique(levels)
    }
