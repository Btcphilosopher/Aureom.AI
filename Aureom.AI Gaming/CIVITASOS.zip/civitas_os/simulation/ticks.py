"""Small helpers for reasoning about tick boundaries used across the engine."""
from __future__ import annotations

from core.clock import TICKS_PER_DAY, TICKS_PER_HOUR, TICKS_PER_MONTH, TICKS_PER_YEAR


def hours_elapsed_today(tick: int) -> int:
    return (tick % TICKS_PER_DAY) // TICKS_PER_HOUR


def is_hour_boundary(tick: int) -> bool:
    return tick % TICKS_PER_HOUR == 0


def is_day_boundary(tick: int) -> bool:
    return tick % TICKS_PER_DAY == 0


def is_month_boundary(tick: int) -> bool:
    return tick % TICKS_PER_MONTH == 0


def is_year_boundary(tick: int) -> bool:
    return tick % TICKS_PER_YEAR == 0
