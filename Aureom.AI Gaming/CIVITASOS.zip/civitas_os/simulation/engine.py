"""SimulationEngine (spec #100): the closed loop tying every subsystem
together — planning -> construction -> population -> households -> jobs ->
economy -> activities -> travel -> transport -> services -> utilities ->
land value -> migration -> demographics -> statistics -> (render, external).

setup() performs the "first playable city" bring-up (spec #122): generate
a real population + households, build enough real housing + workplaces to
hold them, wire up a routable road network, then hand control to run_day/
run_year for the ongoing simulation.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass

import numpy as np

from behaviour.needs import apply_relief, decay_needs
from behaviour.schedules import build_daily_activity_matrix
from city.buildings import Building, BuildingRegistry, BuildingType, RESIDENTIAL_TYPES
from city.construction import ConstructionQueue, DEFAULT_TEMPLATES
from city.land_value import compute_land_value, rent_from_land_value
from city.neighbourhoods import NeighbourhoodRegistry
from city.parcels import CityGrid
from city.zoning import ZoneType, default_zone_assigner
from core.clock import SimulationClock, TICKS_PER_DAY, TICKS_PER_HOUR
from core.config import CityConfig
from core.events import EventBus, EventType
from core.random import CityRandom
from core.state import CityState
from core.weather import WeatherSystem
from economy.economy import CityEconomy
from economy.labour import OCCUPATION_PROFILE
from households.housing import HousingMarket, Tenure
from population.births import BirthModel
from population.citizen import Activity, EmploymentState, HousingState, TravelMode
from population.generator import PopulationGenerator
from population.migration import MigrationModel
from population.mortality import MortalityModel
from services import energy as energy_svc
from services import waste as waste_svc
from services import water as water_svc
from simulation.aggregation import population_statistics
from transport.network import build_network_from_grid
from transport.routing import RouteCache
from transport.traffic import TrafficModel

WORKPLACE_ZONE_TYPES = {
    BuildingType.OFFICE: ZoneType.COMMERCIAL,
    BuildingType.SHOP: ZoneType.COMMERCIAL,
    BuildingType.RESTAURANT: ZoneType.MIXED_USE,
    BuildingType.CAFE: ZoneType.MIXED_USE,
    BuildingType.FACTORY: ZoneType.INDUSTRIAL,
    BuildingType.WAREHOUSE: ZoneType.INDUSTRIAL,
    BuildingType.SCHOOL: ZoneType.CIVIC,
    BuildingType.HOSPITAL: ZoneType.CIVIC,
    BuildingType.GOVERNMENT: ZoneType.CIVIC,
    BuildingType.CULTURAL: ZoneType.CIVIC,
}

OCCUPATION_TO_BUILDING = {
    "retail": BuildingType.SHOP, "hospitality": BuildingType.RESTAURANT,
    "manufacturing": BuildingType.FACTORY, "logistics": BuildingType.WAREHOUSE,
    "construction": BuildingType.WAREHOUSE, "education": BuildingType.SCHOOL,
    "healthcare": BuildingType.HOSPITAL, "public_admin": BuildingType.GOVERNMENT,
    "professional_services": BuildingType.OFFICE, "technology": BuildingType.OFFICE,
    "creative": BuildingType.CULTURAL, "management": BuildingType.OFFICE,
}


@dataclass
class BenchmarkReport:
    citizens_generated: int
    households_generated: int
    housing_units_built: int
    jobs_created: int
    days_simulated: int
    wall_seconds: float
    ticks_simulated: int


class SimulationEngine:
    def __init__(self, config: CityConfig):
        self.config = config
        self.random = CityRandom(config.seed)
        self.state = CityState(city_id=f"city-{config.seed}", name=config.name,
                                config=config, random=self.random)
        self.state.weather = WeatherSystem(self.random.stream("weather"))
        self._block_lookup_cache: dict | None = None

    # ------------------------------------------------------------------
    # PHASE 1-9ish: bring-up of one real, populated, employed, housed city
    # ------------------------------------------------------------------
    def setup(self) -> None:
        s = self.state
        cfg = self.config
        width = height = math.sqrt(cfg.target_population / 20_000) * 5000 or 5000
        city_bounds = (width, height)

        s.grid = CityGrid(width, height, block_size_m=cfg.planning.get("block_size_m", 250),
                            plots_per_block_side=cfg.planning.get("plots_per_block_side", 4),
                            rng=self.random.stream("grid"))
        s.grid.generate(default_zone_assigner)

        s.neighbourhoods = NeighbourhoodRegistry()
        s.neighbourhoods.partition_grid(s.grid, [f"District {i+1}" for i in range(9)])

        s.buildings = BuildingRegistry()
        s.housing_market = HousingMarket(self.random.stream("housing"))
        s.construction = ConstructionQueue(s.buildings, s.housing_market, TICKS_PER_DAY)

        generator = PopulationGenerator(self.random, cfg.population)
        gen_result = generator.generate_city_population(cfg.target_population, city_bounds)
        s.citizens = gen_result.citizens
        s.households = gen_result.households

        self._build_housing_for_households(city_bounds)
        self._build_workplaces_and_jobs(city_bounds)

        s.transport_network = build_network_from_grid(s.grid)
        s.route_cache = RouteCache(s.transport_network)
        s.economy = CityEconomy(self.random.stream("economy"))
        s.economy.labour = self._labour_market  # share the labour market populated above

        self._assign_commute_modes()
        self.births = BirthModel(self.random, s.events)
        self.mortality = MortalityModel(self.random, s.events)
        self.migration = MigrationModel(self.random, s.events, generator)
        self.traffic = TrafficModel(s.transport_network, s.route_cache)

    def _build_housing_for_households(self, city_bounds) -> None:
        s = self.state
        rng = self.random.stream("initial_construction")
        households = list(s.households.active())
        rng.shuffle(households)

        residential_parcels = s.grid.buildable_parcels(ZoneType.RESIDENTIAL)
        rng.shuffle(residential_parcels)
        parcel_iter = iter(residential_parcels)

        units_built = 0
        parcel = next(parcel_iter, None)
        while households and parcel is not None:
            # taller buildings nearer the centre (mixed-use ring), houses further out
            dist = s.grid.distance_to_center(parcel.location) / max(city_bounds[0], 1)
            if dist < 0.2:
                b_type = BuildingType.TOWER
            elif dist < 0.4:
                b_type = BuildingType.APARTMENT
            elif dist < 0.6:
                b_type = BuildingType.TOWNHOUSE
            else:
                b_type = BuildingType.HOUSE

            project = s.construction.start_project(b_type, parcel, tick=0)
            project.duration_ticks = 0  # instant bring-up for the initial city
            parcel.building_id = -2  # mark reserved
            completed = s.construction.advance(0, land_value_lookup=lambda loc: 40.0)
            for building in completed:
                parcel.building_id = building.building_id
                for unit_id in building.housing_unit_ids:
                    units_built += 1
                    unit = s.housing_market.units[unit_id]
                    if not households:
                        break
                    hh = households.pop()
                    s.housing_market.assign(unit, hh.household_id)
                    hh.home_id = unit.unit_id
                    for member in hh.member_slots:
                        s.citizens.home_id[member] = unit.unit_id
                        s.citizens.location_x[member] = unit.location[0]
                        s.citizens.location_y[member] = unit.location[1]
                        s.citizens.destination_x[member] = unit.location[0]
                        s.citizens.destination_y[member] = unit.location[1]
                        s.citizens.housing_state[member] = HousingState.HOUSED
            parcel = next(parcel_iter, None)

        # anyone left unhoused becomes homeless (an honest emergent outcome
        # if the residential land supply was too small — spec #15)
        for hh in households:
            for member in hh.member_slots:
                s.citizens.housing_state[member] = HousingState.HOMELESS
            s.housing_market.homeless_households.add(hh.household_id)

    def _build_workplaces_and_jobs(self, city_bounds) -> None:
        s = self.state
        rng = self.random.stream("initial_jobs")
        from economy.labour import LabourMarket
        self._labour_market = LabourMarket(rng)

        active = s.citizens.active_mask()
        employed_slots = np.nonzero(active & (s.citizens.employment_state[: s.citizens.n] == EmploymentState.EMPLOYED))[0]
        n_jobs_needed = len(employed_slots)
        if n_jobs_needed == 0:
            return

        occ_names = list(OCCUPATION_PROFILE.keys())
        occ_weights = np.array([1.0] * len(occ_names))  # flat distribution over occupations; swappable via config
        occ_weights /= occ_weights.sum()
        occupation_draw = rng.choice(occ_names, size=n_jobs_needed, p=occ_weights)
        occ_counts = {occ: int((occupation_draw == occ).sum()) for occ in occ_names}

        non_residential_parcels = [p for p in s.grid.parcels.values()
                                     if p.zone != ZoneType.RESIDENTIAL and p.is_buildable]
        rng.shuffle(non_residential_parcels)
        parcel_iter = iter(non_residential_parcels)

        for occ, count in occ_counts.items():
            remaining = count
            b_type = OCCUPATION_TO_BUILDING.get(occ, BuildingType.OFFICE)
            template = DEFAULT_TEMPLATES.get(b_type, {"capacity": 30})
            jobs_per_building = max(4, template["capacity"] // 8)
            while remaining > 0:
                parcel = next(parcel_iter, None)
                if parcel is None:
                    break
                building = s.buildings.create(b_type, parcel.location, template["capacity"],
                                                parcel_id=parcel.parcel_id, built_tick=0)
                parcel.building_id = building.building_id
                n_here = min(jobs_per_building, remaining)
                jobs = self._labour_market.create_jobs(building.building_id, building.location, occ, n_here)
                building.job_ids.extend(j.job_id for j in jobs)
                remaining -= n_here

        # match employed citizens to created jobs (spec #31)
        for slot in employed_slots:
            slot = int(slot)
            home = (float(s.citizens.location_x[slot]), float(s.citizens.location_y[slot]))
            job = self._labour_market.best_match(int(s.citizens.education_level[slot]), home)
            if job is None:
                s.citizens.employment_state[slot] = EmploymentState.UNEMPLOYED
                continue
            self._labour_market.hire(job, slot)
            s.citizens.job_id[slot] = job.job_id
            s.citizens.workplace_id[slot] = job.building_id
            s.citizens.occupation_code[slot] = occ_names.index(job.occupation)

    def _assign_commute_modes(self) -> None:
        s = self.state
        rng = self.random.stream("mode_choice")
        active_idx = s.citizens.active_indices()
        commuters = active_idx[s.citizens.workplace_id[active_idx] >= 0]
        if len(commuters) == 0:
            return
        dx = s.citizens.location_x[commuters]
        dy = s.citizens.location_y[commuters]
        home_ids = s.citizens.home_id[commuters]
        workplace_ids = s.citizens.workplace_id[commuters]
        dist = np.zeros(len(commuters))
        for i, wid in enumerate(workplace_ids):
            b = s.buildings.buildings.get(int(wid))
            if b:
                dist[i] = math.dist((dx[i], dy[i]), b.location)
        modes = np.empty(len(commuters), dtype=np.int8)
        for i, d in enumerate(dist):
            if d < 800:
                probs = {"WALK": 0.55, "BICYCLE": 0.2, "BUS": 0.15, "CAR": 0.1}
            elif d < 3000:
                probs = {"WALK": 0.05, "BICYCLE": 0.15, "BUS": 0.35, "CAR": 0.4, "METRO": 0.05}
            else:
                probs = {"BUS": 0.2, "TRAIN": 0.15, "METRO": 0.15, "CAR": 0.45, "TAXI": 0.05}
            names = list(probs.keys())
            weights = np.array(list(probs.values()))
            weights /= weights.sum()
            choice = rng.choice(names, p=weights)
            modes[i] = int(TravelMode[choice])
        s.citizens.commute_mode[commuters] = modes

    # ------------------------------------------------------------------
    # ongoing simulation loop (spec #100-#101)
    # ------------------------------------------------------------------
    def run_day(self) -> dict:
        s = self.state
        for _ in range(TICKS_PER_HOUR * 24 // TICKS_PER_HOUR):  # 24 hourly steps per day
            self._run_hour()
        self._daily_systems()
        if s.clock.is_new_month:
            self._monthly_systems()
        if s.clock.is_new_year:
            self._yearly_systems()
        return population_statistics(s.citizens)

    def _run_hour(self) -> None:
        s = self.state
        active_idx = s.citizens.active_indices()
        if len(active_idx) == 0:
            s.clock.advance(TICKS_PER_HOUR)
            return

        is_weekend = np.full(len(active_idx), s.clock.is_weekend)
        employment_states = s.citizens.employment_state[active_idx]
        activity_matrix = build_daily_activity_matrix(employment_states, is_weekend)
        hour = s.clock.hour_of_day
        activities = activity_matrix[:, hour]
        s.citizens.current_activity[active_idx] = activities

        travelling = activities == int(Activity.TRAVEL)
        going_to_work = travelling & (s.citizens.workplace_id[active_idx] >= 0) & (hour < 12)
        going_home = travelling & (hour >= 12)

        work_targets = active_idx[going_to_work]
        for slot in work_targets:
            b = s.buildings.buildings.get(int(s.citizens.workplace_id[slot]))
            if b:
                s.citizens.destination_x[slot], s.citizens.destination_y[slot] = b.location
                s.citizens.location_x[slot], s.citizens.location_y[slot] = b.location

        home_targets = active_idx[going_home]
        for slot in home_targets:
            unit = s.housing_market.units.get(int(s.citizens.home_id[slot]))
            if unit:
                s.citizens.destination_x[slot], s.citizens.destination_y[slot] = unit.location
                s.citizens.location_x[slot], s.citizens.location_y[slot] = unit.location

        decay_needs(s.citizens, active_idx, dt_hours=1.0)
        apply_relief(s.citizens, active_idx)

        s.clock.advance(TICKS_PER_HOUR)

    def _daily_systems(self) -> None:
        s = self.state
        active_idx = s.citizens.active_indices()

        def block_of_location(x, y):
            col = int(x // s.grid.block_size_m)
            row = int(y // s.grid.block_size_m)
            n_cols = max(1, round(s.grid.width_m / s.grid.block_size_m))
            return row * n_cols + col

        traffic_report = self.traffic.simulate_commute_wave(s.citizens, active_idx, block_of_location)

        n_pop = len(active_idx)
        n_industrial = len(s.buildings.of_type(BuildingType.FACTORY)) + len(s.buildings.of_type(BuildingType.WAREHOUSE))
        n_businesses = len(s.buildings.workplaces())
        s.last_daily_report = {
            "traffic": traffic_report,
            "waste_kg": waste_svc.daily_waste_kg(n_pop, n_businesses),
            "water_litres": water_svc.total_demand_litres(n_pop, n_industrial),
        }

        avg_land_value = self._estimate_avg_land_value()
        s.economy.daily_update(s.clock.tick, s.citizens, s.households, avg_land_value)
        stats = population_statistics(s.citizens)
        stats["tick"] = s.clock.tick
        stats["land_value"] = avg_land_value
        s.statistics_history.append(stats)

    def _monthly_systems(self) -> None:
        s = self.state
        vacancy_rate = s.housing_market.vacancy_rate
        unemployment = s.economy.labour.unemployment_rate
        avg_wage = s.economy.indicators.total_wages / max(int(s.citizens.active_mask().sum()), 1)
        score = self.migration.attractiveness_score(vacancy_rate, unemployment, self._estimate_avg_land_value(), avg_wage)
        city_bounds = (s.grid.width_m, s.grid.height_m)
        self.migration.monthly_migration(s.citizens, s.households, s.housing_market, score,
                                          base_rate=0.01, city_bounds=city_bounds, tick=s.clock.tick)

    def _yearly_systems(self) -> None:
        s = self.state
        active_idx = s.citizens.active_indices()
        s.citizens.age_years[active_idx] += 1.0
        self.births.apply_annual_births(s.citizens, s.households, s.clock.tick)
        self.mortality.apply_annual_deaths(s.citizens, s.households, s.housing_market, s.clock.tick)

    def _estimate_avg_land_value(self) -> float:
        s = self.state
        jobs_total = len(self._labour_market.jobs)
        n_pop = int(s.citizens.active_mask().sum())
        density = n_pop / max((s.grid.width_m * s.grid.height_m) / 1_000_000, 1)  # per km^2 proxy
        return compute_land_value(
            accessibility=0.6, jobs_nearby=jobs_total, amenities_nearby=len(s.buildings.of_type(BuildingType.SHOP)),
            density=density / 5000, transit_access=0.5, school_quality=0.6, safety=0.7,
            commercial_activity=min(len(s.buildings.workplaces()) / max(n_pop / 20, 1), 1.0),
        )

    # ------------------------------------------------------------------
    def run_years(self, n_years: int, progress_every_days: int | None = None) -> None:
        for day in range(n_years * 365):
            self.run_day()
            if progress_every_days and day % progress_every_days == 0:
                yield_stats = population_statistics(self.state.citizens)
                print(f"  day {day:>5}  pop={yield_stats.get('population')}  "
                      f"employment={yield_stats.get('employment_rate', 0):.2%}  "
                      f"homeless={yield_stats.get('homeless_count')}")

    def benchmark(self, days: int = 365) -> BenchmarkReport:
        start = time.perf_counter()
        for _ in range(days):
            self.run_day()
        elapsed = time.perf_counter() - start
        s = self.state
        return BenchmarkReport(
            citizens_generated=int(s.citizens.n),
            households_generated=len(s.households.households),
            housing_units_built=len(s.housing_market.units),
            jobs_created=len(self._labour_market.jobs),
            days_simulated=days,
            wall_seconds=elapsed,
            ticks_simulated=s.clock.tick,
        )
