"""Vectorised city-wide statistics (spec #79, #96) — batch NumPy reductions
over the whole citizen population instead of Python-level loops.
"""
from __future__ import annotations

import numpy as np

from population.citizen import EmploymentState, HousingState, TravelMode


def population_statistics(citizens) -> dict:
    active = citizens.active_mask()
    n = int(active.sum())
    if n == 0:
        return {"population": 0}

    ages = citizens.age_years[: citizens.n][active]
    incomes = citizens.income[: citizens.n][active]
    employment = citizens.employment_state[: citizens.n][active]
    housing = citizens.housing_state[: citizens.n][active]
    happiness = citizens.happiness[: citizens.n][active]
    health = citizens.health_state[: citizens.n][active]
    modes = citizens.commute_mode[: citizens.n][active]

    employed = int((employment == EmploymentState.EMPLOYED).sum())
    labour_force = employed + int((employment == EmploymentState.UNEMPLOYED).sum())

    mode_share = {}
    for mode in TravelMode:
        count = int((modes == mode).sum())
        if count:
            mode_share[mode.name] = count / n

    return {
        "population": n,
        "avg_age": float(ages.mean()),
        "median_income": float(np.median(incomes)),
        "avg_income": float(incomes.mean()),
        "income_gini": _gini(incomes),
        "employment_rate": employed / labour_force if labour_force else 0.0,
        "unemployment_count": int((employment == EmploymentState.UNEMPLOYED).sum()),
        "homeless_count": int((housing == HousingState.HOMELESS).sum()),
        "overcrowded_count": int((housing == HousingState.OVERCROWDED).sum()),
        "avg_happiness": float(happiness.mean()),
        "avg_health": float(health.mean()),
        "commute_mode_share": mode_share,
    }


def _gini(values: np.ndarray) -> float:
    if len(values) == 0:
        return 0.0
    sorted_vals = np.sort(values)
    n = len(sorted_vals)
    cum = np.cumsum(sorted_vals)
    if cum[-1] == 0:
        return 0.0
    return float((n + 1 - 2 * (cum.sum() / cum[-1])) / n)


def age_pyramid(citizens, bin_size: int = 5) -> dict[str, dict[str, int]]:
    active = citizens.active_mask()
    ages = citizens.age_years[: citizens.n][active]
    sexes = citizens.sex[: citizens.n][active]
    max_age = int(ages.max()) + bin_size if len(ages) else bin_size
    bins = np.arange(0, max_age + bin_size, bin_size)
    result: dict[str, dict[str, int]] = {}
    for lo, hi in zip(bins[:-1], bins[1:]):
        mask = (ages >= lo) & (ages < hi)
        label = f"{lo}-{hi-1}"
        result[label] = {
            "female": int((mask & (sexes == 0)).sum()),
            "male": int((mask & (sexes == 1)).sum()),
        }
    return result
