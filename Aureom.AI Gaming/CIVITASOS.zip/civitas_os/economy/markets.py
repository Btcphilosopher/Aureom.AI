"""Aggregate city-wide economic indicators (spec #33)."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class EconomicIndicators:
    gdp: float = 0.0
    total_wages: float = 0.0
    total_household_income: float = 0.0
    business_revenue: float = 0.0
    total_consumption: float = 0.0
    savings: float = 0.0
    tax_revenue: float = 0.0
    unemployment_rate: float = 0.0
    avg_land_value: float = 0.0
    history: list[dict] = field(default_factory=list)

    def snapshot(self, tick: int) -> dict:
        record = {"tick": tick, **{k: v for k, v in self.__dict__.items() if k != "history"}}
        self.history.append(record)
        return record
