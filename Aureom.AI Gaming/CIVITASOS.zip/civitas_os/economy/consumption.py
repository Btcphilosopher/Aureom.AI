"""Household consumption model: food/energy/housing/transport/services
spend derived from income, household size/age composition, and prices
(spec #35), computed vectorised over all households at once.
"""
from __future__ import annotations

import numpy as np


def compute_consumption(income: np.ndarray, household_size: np.ndarray,
                          price_index: float = 1.0) -> dict[str, np.ndarray]:
    """All arrays aligned by household index. Returns per-category annual
    spend arrays. Engel-curve-like shares: poorer/larger households spend a
    higher share of income on food/housing, richer ones more on
    discretionary categories."""
    income = np.maximum(income, 1.0)
    size_factor = np.sqrt(np.maximum(household_size, 1))

    food_share = np.clip(0.35 - 0.02 * np.log1p(income / 20000), 0.12, 0.35)
    housing_share = 0.30
    energy_share = np.clip(0.10 * size_factor / np.sqrt(2), 0.04, 0.18)
    transport_share = 0.12
    services_share = np.clip(0.08 + 0.03 * np.log1p(income / 30000), 0.05, 0.20)
    discretionary_share = np.clip(1 - (food_share + housing_share + energy_share +
                                         transport_share + services_share), 0.0, 0.4)

    return {
        "food": income * food_share * price_index,
        "housing": income * housing_share,
        "energy": income * energy_share * price_index,
        "transport": income * transport_share * price_index,
        "services": income * services_share * price_index,
        "discretionary": income * discretionary_share * price_index,
    }
