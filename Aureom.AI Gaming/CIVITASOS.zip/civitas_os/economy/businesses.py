"""Businesses occupy workplace buildings, employ citizens via LabourMarket
jobs, and generate revenue from consumer demand nearby (spec #36-#37).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .labour import Job


@dataclass
class Business:
    business_id: int
    building_id: int
    sector: str
    employee_job_ids: list[int] = field(default_factory=list)
    revenue: float = 0.0
    costs: float = 0.0
    inventory: float = 100.0
    customers_per_day: float = 0.0

    @property
    def profit(self) -> float:
        return self.revenue - self.costs


class BusinessRegistry:
    def __init__(self):
        self._next_id = 0
        self.businesses: dict[int, Business] = {}

    def open_business(self, building_id: int, sector: str, jobs: list[Job]) -> Business:
        bid = self._next_id
        self._next_id += 1
        biz = Business(bid, building_id, sector, employee_job_ids=[j.job_id for j in jobs])
        self.businesses[bid] = biz
        return biz

    def close_business(self, business_id: int, labour_market) -> None:
        biz = self.businesses.pop(business_id, None)
        if not biz:
            return
        for jid in biz.employee_job_ids:
            labour_market.fire(jid)

    def daily_tick(self, biz: Business, local_demand: float, wage_bill: float) -> None:
        """Very simplified P&L: revenue tracks nearby consumer demand,
        costs track wages + a fixed overhead."""
        biz.customers_per_day = local_demand
        biz.revenue = local_demand * 18.0  # avg spend per customer
        biz.costs = wage_bill + 0.15 * biz.revenue

    def should_open_new(self, sector: str, unmet_demand: float, threshold: float) -> bool:
        return unmet_demand > threshold
