"""Jobs and the labour market: supply (unemployed citizens) matched against
demand (vacancies) by salary, distance, qualification and preference
(spec #29-#32).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

OCCUPATIONS = [
    "retail", "hospitality", "manufacturing", "logistics", "construction",
    "education", "healthcare", "professional_services", "public_admin",
    "technology", "creative", "management",
]

# Minimum education level index (see population.citizen.EDUCATION_LEVELS) and
# base salary band per occupation. Overridable via economic_parameters.yaml.
OCCUPATION_PROFILE = {
    "retail":               {"min_education": 1, "salary": (18000, 26000)},
    "hospitality":          {"min_education": 1, "salary": (17000, 25000)},
    "manufacturing":        {"min_education": 1, "salary": (22000, 32000)},
    "logistics":            {"min_education": 1, "salary": (20000, 30000)},
    "construction":         {"min_education": 1, "salary": (23000, 35000)},
    "education":            {"min_education": 4, "salary": (28000, 45000)},
    "healthcare":           {"min_education": 3, "salary": (25000, 55000)},
    "public_admin":         {"min_education": 2, "salary": (24000, 38000)},
    "professional_services":{"min_education": 4, "salary": (30000, 65000)},
    "technology":           {"min_education": 4, "salary": (35000, 80000)},
    "creative":             {"min_education": 2, "salary": (20000, 42000)},
    "management":           {"min_education": 3, "salary": (32000, 70000)},
}


@dataclass
class Job:
    job_id: int
    building_id: int
    occupation: str
    salary: float
    hours_per_week: int
    location: tuple[float, float]
    filled_by: int = -1  # citizen slot, -1 = vacant

    @property
    def is_vacant(self) -> bool:
        return self.filled_by < 0


class LabourMarket:
    def __init__(self, rng):
        self.rng = rng
        self._next_id = 0
        self.jobs: dict[int, Job] = {}

    def create_jobs(self, building_id: int, location: tuple[float, float],
                     occupation: str, n: int, hours_per_week: int = 37) -> list[Job]:
        lo, hi = OCCUPATION_PROFILE[occupation]["salary"]
        created = []
        for _ in range(n):
            salary = float(self.rng.uniform(lo, hi))
            jid = self._next_id
            self._next_id += 1
            job = Job(jid, building_id, occupation, salary, hours_per_week, location)
            self.jobs[jid] = job
            created.append(job)
        return created

    def vacancies(self, occupation: str | None = None) -> list[Job]:
        jobs = [j for j in self.jobs.values() if j.is_vacant]
        if occupation:
            jobs = [j for j in jobs if j.occupation == occupation]
        return jobs

    @property
    def unemployment_rate(self) -> float:
        if not self.jobs:
            return 0.0
        filled = sum(1 for j in self.jobs.values() if not j.is_vacant)
        return 1.0 - filled / len(self.jobs)

    def best_match(self, education_level: int, home_location: tuple[float, float],
                    n_candidates: int = 20) -> Job | None:
        eligible_occs = [o for o, prof in OCCUPATION_PROFILE.items() if prof["min_education"] <= education_level]
        candidates = [j for j in self.jobs.values() if j.is_vacant and j.occupation in eligible_occs]
        if not candidates:
            return None
        sample = self.rng.choice(candidates, size=min(n_candidates, len(candidates)), replace=False)

        def score(job: Job) -> float:
            dist = math.dist(home_location, job.location)
            distance_penalty = -0.02 * dist
            salary_term = job.salary / 10000.0
            noise = self.rng.normal(0, 0.5)
            return salary_term + distance_penalty + noise

        return max(sample, key=score)

    def hire(self, job: Job, citizen_slot: int) -> None:
        job.filled_by = citizen_slot

    def fire(self, job_id: int) -> None:
        job = self.jobs.get(job_id)
        if job:
            job.filled_by = -1
