"""CityEconomy: orchestrates labour market, businesses, consumption and
rolls it all up into EconomicIndicators each tick (spec #33).
"""
from __future__ import annotations

import numpy as np

from .businesses import BusinessRegistry
from .consumption import compute_consumption
from .labour import LabourMarket
from .markets import EconomicIndicators


class CityEconomy:
    def __init__(self, rng, tax_rate: float = 0.22):
        self.rng = rng
        self.labour = LabourMarket(rng)
        self.businesses = BusinessRegistry()
        self.indicators = EconomicIndicators()
        self.tax_rate = tax_rate

    def daily_update(self, tick: int, citizens, household_registry, land_value_index: float) -> EconomicIndicators:
        active = citizens.active_mask()
        incomes = citizens.income[: citizens.n][active]
        total_wages = float(incomes.sum())

        household_incomes = []
        household_sizes = []
        for hh in household_registry.active():
            income = sum(citizens.income[s] for s in hh.member_slots if citizens.alive[s])
            household_incomes.append(income)
            household_sizes.append(max(hh.size, 1))

        if household_incomes:
            hh_income_arr = np.array(household_incomes, dtype=np.float64)
            hh_size_arr = np.array(household_sizes, dtype=np.float64)
            consumption = compute_consumption(hh_income_arr, hh_size_arr)
            total_consumption = float(sum(arr.sum() for arr in consumption.values()))
            total_household_income = float(hh_income_arr.sum())
        else:
            total_consumption = 0.0
            total_household_income = 0.0

        business_revenue = sum(b.revenue for b in self.businesses.businesses.values())
        tax_revenue = self.tax_rate * (total_wages + business_revenue) / 365.0

        ind = self.indicators
        ind.total_wages = total_wages
        ind.total_household_income = total_household_income
        ind.business_revenue = business_revenue
        ind.total_consumption = total_consumption / 365.0
        ind.savings = max(0.0, (total_household_income - total_consumption) / 365.0)
        ind.tax_revenue = tax_revenue
        ind.unemployment_rate = self.labour.unemployment_rate
        ind.gdp = (total_wages + business_revenue) / 365.0
        ind.avg_land_value = land_value_index
        ind.snapshot(tick)
        return ind
