"""Fire service coverage/response, game-level (spec #47)."""
from __future__ import annotations


def response_time_estimate(distance_to_nearest_station_m: float, avg_speed_kmh: float = 45.0) -> float:
    """Minutes to respond, simple distance/speed model."""
    return (distance_to_nearest_station_m / 1000) / avg_speed_kmh * 60


def coverage_adequate(response_minutes: float, target_minutes: float = 8.0) -> bool:
    return response_minutes <= target_minutes
