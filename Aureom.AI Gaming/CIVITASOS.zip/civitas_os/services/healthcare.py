"""Healthcare demand: an abstract, game-level model (spec #50) driven by
age, income, environment, and access — never a medical simulator.
"""
from __future__ import annotations

import numpy as np


def healthcare_demand_index(citizens) -> np.ndarray:
    """Per-citizen abstract healthcare need score (0..1), vectorised."""
    active = citizens.active_mask()
    n = citizens.n
    age = citizens.age_years[:n]
    income = citizens.income[:n]
    age_factor = np.clip((age - 40) / 60, 0, 1) * 0.6 + np.clip((5 - age) / 5, 0, 1) * 0.3
    income_factor = np.clip(1 - income / 40000, 0, 1) * 0.2
    demand = np.clip(age_factor + income_factor, 0, 1)
    demand[~active] = 0.0
    return demand


def hospital_capacity_gap(citizens, hospital_buildings) -> float:
    total_demand = healthcare_demand_index(citizens).sum()
    capacity = sum(b.capacity for b in hospital_buildings)
    served = min(total_demand, capacity)
    return total_demand - served


def update_health_state(citizens, access_ratio: float, dt_years: float) -> None:
    """access_ratio: served/demand (1.0 = fully served). Health drifts
    toward a target based on access, ageing slowly erodes baseline."""
    active_idx = citizens.active_indices()
    if len(active_idx) == 0:
        return
    target = 0.5 + 0.5 * np.clip(access_ratio, 0, 1)
    age_penalty = np.clip((citizens.age_years[active_idx] - 60) / 100, 0, 0.3)
    target = np.clip(target - age_penalty, 0.05, 1.0)
    citizens.health_state[active_idx] += (target - citizens.health_state[active_idx]) * min(dt_years * 2, 1.0)
