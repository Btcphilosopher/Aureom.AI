"""Education service demand and pipeline (spec #47-#49).

School-age population -> real demand for school capacity; citizens flow
through primary/secondary/vocational/university stages as they age, which
in turn affects skills, employment eligibility, and income (see
economy/labour.py OCCUPATION_PROFILE.min_education).
"""
from __future__ import annotations

import numpy as np

STAGE_AGE_BANDS = {
    "primary": (5, 11),
    "secondary": (11, 18),
    "vocational": (16, 20),
    "university": (18, 23),
}


def school_age_population(citizens, stage: str) -> np.ndarray:
    lo, hi = STAGE_AGE_BANDS[stage]
    active = citizens.active_mask()
    ages = citizens.age_years[: citizens.n]
    mask = active & (ages >= lo) & (ages < hi)
    return np.nonzero(mask)[0]


def education_capacity_gap(citizens, school_buildings, stage: str) -> int:
    """Positive => under-capacity (spec #48: demand generated from actual
    population, not an assumed ratio)."""
    demand = len(school_age_population(citizens, stage))
    capacity = sum(b.capacity for b in school_buildings)
    return demand - capacity


def advance_education(citizens, slot: int, education_levels_index_by_stage: dict[str, int]) -> None:
    """Promote a citizen's education_level as they complete a stage; called
    from the yearly demographic update."""
    age = citizens.age_years[slot]
    if age >= 23:
        citizens.education_level[slot] = max(citizens.education_level[slot], education_levels_index_by_stage.get("university", 4))
    elif age >= 18:
        citizens.education_level[slot] = max(citizens.education_level[slot], education_levels_index_by_stage.get("secondary", 2))
    elif age >= 11:
        citizens.education_level[slot] = max(citizens.education_level[slot], education_levels_index_by_stage.get("primary", 1))
