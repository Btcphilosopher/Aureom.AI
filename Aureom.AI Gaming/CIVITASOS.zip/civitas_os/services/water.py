"""Water demand from population and buildings (spec #53)."""
from __future__ import annotations

LITRES_PER_PERSON_PER_DAY = 145.0


def residential_demand_litres(n_population: int) -> float:
    return n_population * LITRES_PER_PERSON_PER_DAY


def industrial_demand_litres(n_industrial_buildings: int, litres_per_building: float = 4000.0) -> float:
    return n_industrial_buildings * litres_per_building


def total_demand_litres(n_population: int, n_industrial_buildings: int) -> float:
    return residential_demand_litres(n_population) + industrial_demand_litres(n_industrial_buildings)
