"""Waste generation from real population and businesses (spec #52)."""
from __future__ import annotations

KG_PER_PERSON_PER_DAY = 1.1
KG_PER_BUSINESS_PER_DAY = 18.0


def daily_waste_kg(n_population: int, n_businesses: int) -> float:
    return n_population * KG_PER_PERSON_PER_DAY + n_businesses * KG_PER_BUSINESS_PER_DAY


def collection_trucks_required(daily_waste_kg_total: float, truck_capacity_kg: float = 8000.0,
                                 trips_per_truck_per_day: int = 2) -> int:
    import math
    return max(1, math.ceil(daily_waste_kg_total / (truck_capacity_kg * trips_per_truck_per_day)))
