"""Public safety: fictional/game-level incident and response modelling
(spec #51), driven by density, lighting/amenity proxies, and policing
coverage rather than anything resembling real crime prediction."""
from __future__ import annotations


def safety_index(density: float, policing_coverage: float, lighting: float = 0.7) -> float:
    """0..1 safety score for a neighbourhood."""
    base = 0.8 - 0.15 * min(density, 3.0)
    base += 0.25 * policing_coverage
    base += 0.1 * lighting
    return max(0.05, min(base, 1.0))


def expected_incidents_per_1000(safety: float) -> float:
    return max(0.0, (1.0 - safety) * 12.0)
