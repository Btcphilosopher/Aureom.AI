"""Building energy demand: population, building type, time-of-day, and
weather all matter (spec #54)."""
from __future__ import annotations

from city.buildings import Building, BuildingType

BASE_KWH_PER_DAY = {
    BuildingType.HOUSE: 25, BuildingType.TOWNHOUSE: 20, BuildingType.APARTMENT: 12,
    BuildingType.TOWER: 10, BuildingType.OFFICE: 60, BuildingType.SHOP: 40,
    BuildingType.FACTORY: 400, BuildingType.WAREHOUSE: 90, BuildingType.SCHOOL: 150,
    BuildingType.HOSPITAL: 600, BuildingType.UNIVERSITY: 300, BuildingType.RESTAURANT: 70,
    BuildingType.CAFE: 25, BuildingType.GOVERNMENT: 120, BuildingType.CULTURAL: 80,
    BuildingType.INDUSTRIAL: 350,
}


def building_energy_kwh(building: Building, temperature_c: float = 15.0) -> float:
    base = BASE_KWH_PER_DAY.get(building.building_type, 15)
    occupancy_factor = 0.4 + 0.6 * (building.occupancy / max(building.capacity, 1))
    hvac_load = max(0.0, (18 - temperature_c)) * 0.8 + max(0.0, (temperature_c - 24)) * 1.1
    return base * occupancy_factor + hvac_load
