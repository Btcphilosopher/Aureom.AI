"""Top-level view-model assembly for a renderer (spec #88: zoom levels
CITY/DISTRICT/NEIGHBOURHOOD/STREET/BUILDING/ROOM all read the same
underlying simulation state, just at different aggregation)."""
from __future__ import annotations

from simulation.aggregation import population_statistics


def city_level_view(city_state) -> dict:
    return {
        "name": city_state.name,
        "clock": str(city_state.clock),
        "statistics": population_statistics(city_state.citizens),
        "n_buildings": len(city_state.buildings.buildings) if city_state.buildings else 0,
        "n_neighbourhoods": len(city_state.neighbourhoods.neighbourhoods) if city_state.neighbourhoods else 0,
    }


def neighbourhood_level_view(city_state, neighbourhood_id: int) -> dict:
    n = city_state.neighbourhoods.neighbourhoods[neighbourhood_id]
    return {
        "name": n.name,
        "population": n.population,
        "density": n.density,
        "avg_income": n.avg_income,
        "housing_units": n.housing_units,
        "jobs": n.jobs,
    }
