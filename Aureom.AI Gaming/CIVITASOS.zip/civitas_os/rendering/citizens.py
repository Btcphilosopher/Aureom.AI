"""Data extraction for rendering citizens: visible citizens are always
drawn from real Citizen entities (spec #85-#87), never a decorative crowd,
with LOD picked from spec #87's ladder."""
from __future__ import annotations

import numpy as np

from population.citizen import Activity


LOD_BY_FIDELITY = {
    0: "LOD4_SIMULATION_ONLY",
    1: "LOD3_CROWD",
    2: "LOD2_IMPOSTOR",
    3: "LOD1_SIMPLIFIED",
    4: "LOD0_FULL",
}


def visible_citizens_payload(citizens, slots: np.ndarray) -> list[dict]:
    """Compact per-citizen dicts a renderer can instance from directly —
    appearance derived from age/occupation/activity/weather, never a random
    unique mesh per citizen (spec #86)."""
    payload = []
    for slot in slots:
        slot = int(slot)
        payload.append({
            "citizen_id": citizens.citizen_id[slot],
            "x": float(citizens.location_x[slot]),
            "y": float(citizens.location_y[slot]),
            "age": float(citizens.age_years[slot]),
            "sex": int(citizens.sex[slot]),
            "activity": Activity(citizens.current_activity[slot]).name,
            "lod": LOD_BY_FIDELITY.get(int(citizens.fidelity_level[slot]), "LOD3_CROWD"),
        })
    return payload
