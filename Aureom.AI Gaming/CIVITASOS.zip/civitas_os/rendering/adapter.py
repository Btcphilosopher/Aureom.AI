"""RenderAdapter: the boundary between simulation truth and visual
representation (spec #84, #128). The engine runs identically with or
without a renderer attached; a real renderer (Unity/Unreal/Godot/WebGPU)
implements this interface and pulls data through it every frame.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class RenderAdapter(ABC):
    @abstractmethod
    def on_tick(self, city_state) -> None:
        """Called once per simulation tick with the current CityState."""

    @abstractmethod
    def on_event(self, event) -> None:
        """Called for each published EventBus event (spec #74-#75)."""


class NullRenderAdapter(RenderAdapter):
    """No-op adapter — proves the simulation runs headless (spec #84)."""

    def on_tick(self, city_state) -> None:
        pass

    def on_event(self, event) -> None:
        pass


class ConsoleRenderAdapter(RenderAdapter):
    """Minimal adapter useful for debugging/demoing without any real engine
    attached: prints a one-line summary on day boundaries."""

    def __init__(self):
        from simulation.aggregation import population_statistics
        self._stats_fn = population_statistics

    def on_tick(self, city_state) -> None:
        if city_state.clock.is_new_day:
            stats = self._stats_fn(city_state.citizens)
            print(f"[{city_state.clock}] pop={stats.get('population')} "
                  f"employment={stats.get('employment_rate', 0):.1%}")

    def on_event(self, event) -> None:
        print(f"  event: {event.type.name} @ tick {event.tick} {event.payload}")
