"""Data extraction for rendering buildings (spec #90: building-level
inspector — residents, income, occupancy, employment, history)."""
from __future__ import annotations


def building_payload(building, housing_market=None) -> dict:
    payload = {
        "building_id": building.building_id,
        "type": building.building_type.value,
        "location": building.location,
        "capacity": building.capacity,
        "occupancy": building.occupancy,
        "workers": building.workers,
    }
    if housing_market and building.housing_unit_ids:
        units = [housing_market.units[uid] for uid in building.housing_unit_ids if uid in housing_market.units]
        payload["units"] = [
            {"unit_id": u.unit_id, "occupied": u.occupied, "rent": u.rent, "household_id": u.household_id}
            for u in units
        ]
    return payload


def buildings_in_bounds(building_registry, bounds: tuple[float, float, float, float]) -> list:
    x0, y0, x1, y1 = bounds
    return [b for b in building_registry.buildings.values()
            if x0 <= b.location[0] <= x1 and y0 <= b.location[1] <= y1]
