"""Housing stock and the housing market.

HousingUnit is the physical dwelling. HousingMarket matches households to
units by affordability/preference, tracks vacancy, drives rent, and
produces overcrowding/homelessness as emergent consequences rather than
scripted states (spec #11-#15).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Tenure(str, Enum):
    OWNER = "OWNER"
    RENTER = "RENTER"
    SOCIAL = "SOCIAL"


@dataclass
class HousingUnit:
    unit_id: int
    building_id: int
    capacity: int
    bedrooms: int
    floor_area: float
    rent: float
    sale_price: float
    tenure: Tenure
    location: tuple[float, float]
    quality: float = 0.7          # 0..1
    household_id: int = -1        # -1 = vacant

    @property
    def occupied(self) -> bool:
        return self.household_id >= 0


class HousingMarket:
    def __init__(self, rng):
        self.rng = rng
        self.units: dict[int, HousingUnit] = {}
        self._next_id = 0
        self.homeless_households: set[int] = set()

    def add_unit(self, building_id: int, capacity: int, bedrooms: int, floor_area: float,
                 rent: float, sale_price: float, tenure: Tenure, location: tuple[float, float],
                 quality: float = 0.7) -> HousingUnit:
        uid = self._next_id
        self._next_id += 1
        unit = HousingUnit(uid, building_id, capacity, bedrooms, floor_area, rent,
                            sale_price, tenure, location, quality)
        self.units[uid] = unit
        return unit

    def vacant_units(self) -> list[HousingUnit]:
        return [u for u in self.units.values() if not u.occupied]

    @property
    def vacancy_rate(self) -> float:
        if not self.units:
            return 0.0
        vacant = sum(1 for u in self.units.values() if not u.occupied)
        return vacant / len(self.units)

    def score_unit(self, unit: HousingUnit, household_income: float, household_size: int,
                    preferences: dict) -> float:
        """Household utility for a candidate unit: affordability, space fit,
        quality, and a mild preference/randomness term (spec #14, #27)."""
        if unit.occupied:
            return -1e9
        affordability = household_income * 0.35  # rent-to-income ceiling ~35%
        if unit.rent > affordability:
            price_penalty = -3.0 * (unit.rent - affordability) / max(affordability, 1.0)
        else:
            price_penalty = 0.5 * (affordability - unit.rent) / max(affordability, 1.0)
        space_fit = -abs(unit.capacity - household_size) * 0.4
        quality_term = unit.quality * 1.5
        pref_term = preferences.get("space_weight", 1.0) * (unit.bedrooms >= max(1, household_size - 1))
        noise = self.rng.normal(0, 0.15)
        return price_penalty + space_fit + quality_term + pref_term + noise

    def find_home(self, household_income: float, household_size: int,
                   preferences: dict | None = None, n_candidates: int = 12) -> HousingUnit | None:
        preferences = preferences or {}
        vacant = self.vacant_units()
        if not vacant:
            return None
        sample = self.rng.choice(vacant, size=min(n_candidates, len(vacant)), replace=False)
        scored = [(self.score_unit(u, household_income, household_size, preferences), u) for u in sample]
        scored.sort(key=lambda t: t[0], reverse=True)
        best_score, best_unit = scored[0]
        return best_unit if best_score > -1e8 else None

    def assign(self, unit: HousingUnit, household_id: int) -> None:
        unit.household_id = household_id
        self.homeless_households.discard(household_id)

    def vacate(self, unit_id: int) -> None:
        unit = self.units.get(unit_id)
        if unit:
            unit.household_id = -1

    def occupancy_ratio(self, unit: HousingUnit, actual_occupants: int) -> float:
        return actual_occupants / max(unit.capacity, 1)
