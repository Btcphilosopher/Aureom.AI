"""Household model.

Citizens are not simulated as isolated atoms: they live inside households,
which pool income, share housing cost, and are the unit that actually
searches the housing market (spec #04-#05).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class HouseholdType(str, Enum):
    SINGLE = "SINGLE"
    COUPLE = "COUPLE"
    FAMILY = "FAMILY"
    SHARED = "SHARED"
    MULTIGENERATIONAL = "MULTIGENERATIONAL"
    STUDENT = "STUDENT"
    ELDERLY = "ELDERLY"
    SINGLE_PARENT = "SINGLE_PARENT"


@dataclass
class Household:
    household_id: int
    household_type: HouseholdType
    member_slots: list[int] = field(default_factory=list)   # citizen slot indices
    home_id: int = -1                                         # HousingUnit id, -1 = unhoused
    wealth: float = 0.0
    preferences: dict = field(default_factory=dict)
    formed_tick: int = 0
    dissolved: bool = False

    def add_member(self, slot: int) -> None:
        if slot not in self.member_slots:
            self.member_slots.append(slot)

    def remove_member(self, slot: int) -> None:
        if slot in self.member_slots:
            self.member_slots.remove(slot)

    @property
    def size(self) -> int:
        return len(self.member_slots)


class HouseholdRegistry:
    """Owns all Household objects. Households are few enough (~city_pop/2.5)
    that plain Python objects (not SoA) are fine and much easier to read."""

    def __init__(self):
        self._next_id = 0
        self.households: dict[int, Household] = {}

    def create(self, household_type: HouseholdType, formed_tick: int = 0) -> Household:
        hid = self._next_id
        self._next_id += 1
        hh = Household(household_id=hid, household_type=household_type, formed_tick=formed_tick)
        self.households[hid] = hh
        return hh

    def get(self, household_id: int) -> Household | None:
        return self.households.get(household_id)

    def total_income(self, household_id: int, citizens) -> float:
        hh = self.households[household_id]
        return float(sum(citizens.income[s] for s in hh.member_slots))

    def housing_cost(self, household_id: int, housing_units: dict) -> float:
        hh = self.households[household_id]
        if hh.home_id < 0:
            return 0.0
        unit = housing_units.get(hh.home_id)
        return unit.rent if unit else 0.0

    def dissolve(self, household_id: int) -> None:
        hh = self.households.get(household_id)
        if hh:
            hh.dissolved = True

    def active(self):
        return (hh for hh in self.households.values() if not hh.dissolved)
