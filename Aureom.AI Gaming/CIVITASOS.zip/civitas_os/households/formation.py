"""Household formation, splitting, and merging as ongoing simulation systems
(spec #05), not one-off scripted events.
"""
from __future__ import annotations

from .household import Household, HouseholdRegistry, HouseholdType


def form_household(registry: HouseholdRegistry, household_type: HouseholdType,
                    member_slots: list[int], tick: int) -> Household:
    hh = registry.create(household_type, formed_tick=tick)
    for s in member_slots:
        hh.add_member(s)
    return hh


def split_household(registry: HouseholdRegistry, household: Household,
                     departing_slots: list[int], new_type: HouseholdType, tick: int) -> Household:
    """A subset of members leaves to form (or join) a new household."""
    for s in departing_slots:
        household.remove_member(s)
    new_hh = form_household(registry, new_type, departing_slots, tick)
    if household.size == 0:
        registry.dissolve(household.household_id)
    return new_hh


def merge_households(registry: HouseholdRegistry, primary: Household, secondary: Household,
                       new_type: HouseholdType | None = None) -> Household:
    for s in list(secondary.member_slots):
        primary.add_member(s)
    if new_type:
        primary.household_type = new_type
    registry.dissolve(secondary.household_id)
    return primary
