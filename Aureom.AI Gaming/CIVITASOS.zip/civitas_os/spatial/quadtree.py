"""A minimal region quadtree — alternative spatial index for very uneven
density (e.g. a dense mixed-use core vs. sparse periphery), spec #80."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class QuadNode:
    bounds: tuple[float, float, float, float]  # x0, y0, x1, y1
    capacity: int = 16
    items: list[tuple[int, float, float]] = field(default_factory=list)
    children: list["QuadNode"] | None = None

    def _contains(self, x: float, y: float) -> bool:
        x0, y0, x1, y1 = self.bounds
        return x0 <= x < x1 and y0 <= y < y1

    def insert(self, entity_id: int, x: float, y: float) -> bool:
        if not self._contains(x, y):
            return False
        if self.children is None:
            if len(self.items) < self.capacity:
                self.items.append((entity_id, x, y))
                return True
            self._subdivide()
        for child in self.children:
            if child.insert(entity_id, x, y):
                return True
        return False

    def _subdivide(self) -> None:
        x0, y0, x1, y1 = self.bounds
        mx, my = (x0 + x1) / 2, (y0 + y1) / 2
        self.children = [
            QuadNode((x0, y0, mx, my), self.capacity),
            QuadNode((mx, y0, x1, my), self.capacity),
            QuadNode((x0, my, mx, y1), self.capacity),
            QuadNode((mx, my, x1, y1), self.capacity),
        ]
        for entity_id, x, y in self.items:
            for child in self.children:
                if child.insert(entity_id, x, y):
                    break
        self.items = []

    def query_range(self, qx0: float, qy0: float, qx1: float, qy1: float, out: list | None = None) -> list[int]:
        if out is None:
            out = []
        x0, y0, x1, y1 = self.bounds
        if x1 <= qx0 or x0 >= qx1 or y1 <= qy0 or y0 >= qy1:
            return out
        if self.children is None:
            for entity_id, x, y in self.items:
                if qx0 <= x < qx1 and qy0 <= y < qy1:
                    out.append(entity_id)
        else:
            for child in self.children:
                child.query_range(qx0, qy0, qx1, qy1, out)
        return out
