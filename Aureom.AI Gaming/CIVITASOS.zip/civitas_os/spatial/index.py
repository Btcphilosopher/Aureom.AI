"""Spatial index for nearby-entity queries (spec #80): buildings, citizens,
services, events. Uses a uniform grid (fast to build/query at this scale
and dependency-free); spatial/quadtree.py offers a hierarchical
alternative for non-uniform density.
"""
from __future__ import annotations

import math
from collections import defaultdict


class GridSpatialIndex:
    def __init__(self, cell_size_m: float = 200.0):
        self.cell_size_m = cell_size_m
        self._cells: dict[tuple[int, int], list[int]] = defaultdict(list)
        self._locations: dict[int, tuple[float, float]] = {}

    def _cell(self, x: float, y: float) -> tuple[int, int]:
        return (int(x // self.cell_size_m), int(y // self.cell_size_m))

    def insert(self, entity_id: int, location: tuple[float, float]) -> None:
        self.remove(entity_id)
        cell = self._cell(*location)
        self._cells[cell].append(entity_id)
        self._locations[entity_id] = location

    def remove(self, entity_id: int) -> None:
        loc = self._locations.pop(entity_id, None)
        if loc is not None:
            cell = self._cell(*loc)
            if entity_id in self._cells[cell]:
                self._cells[cell].remove(entity_id)

    def query_radius(self, centre: tuple[float, float], radius_m: float) -> list[int]:
        cx, cy = self._cell(*centre)
        cell_radius = math.ceil(radius_m / self.cell_size_m)
        results = []
        for dx in range(-cell_radius, cell_radius + 1):
            for dy in range(-cell_radius, cell_radius + 1):
                for entity_id in self._cells.get((cx + dx, cy + dy), ()):
                    loc = self._locations[entity_id]
                    dist = math.dist(loc, centre)
                    if dist <= radius_m:
                        results.append(entity_id)
        return results

    def nearest(self, centre: tuple[float, float], k: int = 1) -> list[int]:
        radius = self.cell_size_m
        found: list[int] = []
        while radius < self.cell_size_m * 64 and len(found) < k:
            found = self.query_radius(centre, radius)
            radius *= 2
        found.sort(key=lambda eid: math.dist(self._locations[eid], centre))
        return found[:k]

    def rebuild(self, id_location_pairs) -> None:
        self._cells.clear()
        self._locations.clear()
        for entity_id, location in id_location_pairs:
            self.insert(entity_id, location)
