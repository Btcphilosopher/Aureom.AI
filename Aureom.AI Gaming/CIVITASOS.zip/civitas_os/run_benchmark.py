#!/usr/bin/env python3
"""CLI entry point for the CIVITAS-20K test (spec #102) and the citizen
trace / inspector demo (spec #91, #113-#114) — run without pytest:

    python run_benchmark.py --population 20000 --days 365
    python run_benchmark.py --population 2000 --days 30 --trace
"""
from __future__ import annotations

import argparse
import time

from core.config import CityConfig
from simulation.aggregation import population_statistics
from simulation.engine import SimulationEngine
from tools.inspector import CitizenInspector
from tools.trace import format_trace, trace_day


def main() -> None:
    parser = argparse.ArgumentParser(description="CIVITAS.OS benchmark / demo runner")
    parser.add_argument("--population", type=int, default=20_000)
    parser.add_argument("--days", type=int, default=365)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--trace", action="store_true", help="print one citizen's daily trace + inspector output")
    parser.add_argument("--progress-every", type=int, default=30, help="print progress every N days (0 = silent)")
    args = parser.parse_args()

    print(f"CIVITAS.OS — building a city for {args.population:,} citizens (seed={args.seed})...")
    cfg = CityConfig.load({"seed": args.seed, "target_population": args.population, "name": "CIVITAS-CITY"})

    t0 = time.perf_counter()
    engine = SimulationEngine(cfg)
    engine.setup()
    setup_time = time.perf_counter() - t0

    s = engine.state
    n_citizens = int(s.citizens.active_mask().sum())
    print(f"Setup complete in {setup_time:.2f}s:")
    print(f"  citizens : {n_citizens:,}")
    print(f"  households: {len(s.households.households):,}")
    print(f"  housing units: {len(s.housing_market.units):,} (vacancy {s.housing_market.vacancy_rate:.1%})")
    print(f"  jobs created: {len(engine._labour_market.jobs):,} "
          f"(unemployment {engine._labour_market.unemployment_rate:.1%})")
    print(f"  road network: {len(s.transport_network.node_location)} nodes, "
          f"{len(set(s.transport_network.edges.values()))} edges")

    if args.trace:
        sample_slot = int(s.citizens.active_indices()[0])
        sample_id = s.citizens.citizen_id[sample_slot]
        inspector = CitizenInspector(s)
        print("\nSample citizen inspector:")
        print(inspector.inspect(sample_id))
        print("\nSample daily trace:")
        print(format_trace(sample_id, trace_day(s.citizens, sample_slot)))

    print(f"\nRunning {args.days} simulated day(s)...")
    t1 = time.perf_counter()
    for day in range(args.days):
        stats = engine.run_day()
        if args.progress_every and day % args.progress_every == 0:
            print(f"  day {day:>5}  pop={stats.get('population'):,}  "
                  f"employment={stats.get('employment_rate', 0):.1%}  "
                  f"homeless={stats.get('homeless_count')}  "
                  f"avg_happiness={stats.get('avg_happiness', 0):.2f}")
    elapsed = time.perf_counter() - t1
    final_stats = population_statistics(s.citizens)

    print(f"\nDone. {args.days} days simulated in {elapsed:.2f}s "
          f"({args.days / elapsed:.2f} days/sec, {n_citizens:,} citizens).")
    print("Final statistics:", final_stats)


if __name__ == "__main__":
    main()
