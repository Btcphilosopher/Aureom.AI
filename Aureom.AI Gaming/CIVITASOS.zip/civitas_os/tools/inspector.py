"""CitizenInspector (spec #91, #113): click/query any citizen by id or
slot and get the full picture — identity, home, work, income, schedule,
current activity, household, travel mode, history."""
from __future__ import annotations


class CitizenInspector:
    def __init__(self, city_state):
        self.state = city_state

    def inspect(self, citizen_id: str) -> dict | None:
        view = self.state.citizens.find_by_id(citizen_id)
        if view is None:
            return None
        info = view.to_dict()
        hh = self.state.households.get(info["household_id"])
        if hh:
            info["household"] = {
                "type": hh.household_type.value,
                "size": hh.size,
                "members": [self.state.citizens.citizen_id[s] for s in hh.member_slots],
            }
        if info["workplace_id"] >= 0 and self.state.buildings:
            b = self.state.buildings.buildings.get(info["workplace_id"])
            if b:
                info["workplace"] = {"type": b.building_type.value, "location": b.location}
        return info

    def inspect_slot(self, slot: int) -> dict:
        return self.state.citizens.view(slot).to_dict()
