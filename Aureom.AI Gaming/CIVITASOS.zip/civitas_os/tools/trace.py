"""CitizenTrace (spec #114): reconstruct a citizen's day from their
schedule template — e.g. "06:55 wake, 07:30 leave home, ... 23:00 sleep" —
straight from the same activity template the simulation itself runs on."""
from __future__ import annotations

from behaviour.schedules import TEMPLATES
from population.citizen import EmploymentState


def trace_day(citizens, slot: int, is_weekend: bool = False) -> list[str]:
    state = EmploymentState(citizens.employment_state[slot])
    template = TEMPLATES[state]
    lines = []
    last_activity = None
    for hour, activity in enumerate(template):
        if activity != last_activity:
            lines.append(f"{hour:02d}:00  {activity.name}")
            last_activity = activity
    return lines


def format_trace(citizen_id: str, lines: list[str]) -> str:
    header = f"Trace for {citizen_id}:"
    return "\n".join([header] + [f"  {line}" for line in lines])
