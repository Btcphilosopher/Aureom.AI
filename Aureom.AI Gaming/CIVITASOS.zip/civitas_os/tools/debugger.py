"""Causal debugging (spec #115-#117): every major metric should be
traceable back to the population/economy/transport state that produced
it — the UrbanAdvisorAI must read actual simulation state, never invent
an explanation.
"""
from __future__ import annotations


def why_is_rent_rising(city_state) -> dict:
    vacancy = city_state.housing_market.vacancy_rate
    homeless = len(city_state.housing_market.homeless_households)
    return {
        "housing_vacancy_rate": vacancy,
        "homeless_households": homeless,
        "explanation": (
            f"Vacancy rate is {vacancy:.1%}. "
            + ("Housing supply is tight, which is pushing rents up." if vacancy < 0.05
               else "Vacancy is healthy; rent pressure is likely coming from income growth or land value, not scarcity.")
        ),
    }


def why_congested(city_state, edge_key: tuple[int, int]) -> dict:
    edge = city_state.transport_network.edges.get(edge_key)
    if edge is None:
        return {"error": "no such road edge"}
    congestion = city_state.transport_network.congestion(edge)
    return {
        "edge": edge_key,
        "trip_count": edge.trip_count,
        "capacity_veh_hr": edge.capacity_veh_hr,
        "congestion_ratio": congestion,
        "explanation": (
            f"{edge.trip_count} trips were assigned to this {edge.road_class.value} segment "
            f"against a capacity of {edge.capacity_veh_hr}/hr ({congestion:.0%} of capacity)."
        ),
    }


def why_population_changed(history: list[dict]) -> dict:
    if len(history) < 2:
        return {"explanation": "not enough history yet"}
    before, after = history[-2], history[-1]
    delta = after.get("population", 0) - before.get("population", 0)
    return {
        "delta": delta,
        "before": before.get("population"),
        "after": after.get("population"),
        "explanation": (
            f"Population changed by {delta:+d} between the last two recorded periods "
            f"(homeless: {before.get('homeless_count')} -> {after.get('homeless_count')}, "
            f"employment rate: {before.get('employment_rate', 0):.1%} -> {after.get('employment_rate', 0):.1%})."
        ),
    }
