"""Monte Carlo runner (spec #111): same city plan under many random seeds
to measure outcome distributions rather than a single deterministic run."""
from __future__ import annotations

import numpy as np

from core.config import CityConfig
from simulation.aggregation import population_statistics
from simulation.engine import SimulationEngine


def run_monte_carlo(base_config: CityConfig, n_runs: int, days: int, metric: str = "avg_happiness") -> dict:
    values = []
    for i in range(n_runs):
        cfg = base_config.merged({"seed": base_config.seed + i})
        engine = SimulationEngine(cfg)
        engine.setup()
        for _ in range(days):
            engine.run_day()
        stats = population_statistics(engine.state.citizens)
        values.append(stats.get(metric, 0.0))
    arr = np.array(values, dtype=float)
    return {
        "metric": metric, "n_runs": n_runs, "mean": float(arr.mean()),
        "std": float(arr.std()), "min": float(arr.min()), "max": float(arr.max()),
        "values": values,
    }
