"""MetricsRecorder: turns a simulation run's statistics history into a
DataFrame and exports it (spec #109) for downstream analysis/plotting."""
from __future__ import annotations

import json
from pathlib import Path

try:
    import pandas as pd
except ImportError:  # pragma: no cover
    pd = None


class MetricsRecorder:
    def __init__(self, statistics_history: list[dict]):
        self.history = statistics_history

    def to_dataframe(self):
        if pd is None:
            raise ImportError("pandas is required for to_dataframe(); pip install pandas")
        rows = []
        for record in self.history:
            flat = {k: v for k, v in record.items() if not isinstance(v, dict)}
            for k, v in record.get("commute_mode_share", {}).items():
                flat[f"mode_share_{k}"] = v
            rows.append(flat)
        return pd.DataFrame(rows)

    def export_csv(self, path: str | Path) -> None:
        df = self.to_dataframe()
        df.to_csv(path, index=False)

    def export_parquet(self, path: str | Path) -> None:
        df = self.to_dataframe()
        df.to_parquet(path, index=False)

    def export_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.history, indent=2, default=str))
