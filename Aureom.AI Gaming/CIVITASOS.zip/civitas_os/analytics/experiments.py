"""ExperimentRunner (spec #110): run the same city under varied config/
planning decisions and compare outcomes — the basis of the counterfactual
mode (spec #94) and urban policy simulator (spec #95).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.config import CityConfig
from simulation.aggregation import population_statistics
from simulation.engine import SimulationEngine


@dataclass
class ExperimentResult:
    label: str
    seed: int
    final_stats: dict
    history: list = field(default_factory=list)


class ExperimentRunner:
    def __init__(self, base_config: CityConfig):
        self.base_config = base_config

    def run_scenario(self, label: str, overrides: dict, days: int) -> ExperimentResult:
        cfg = self.base_config.merged(overrides)
        engine = SimulationEngine(cfg)
        engine.setup()
        for _ in range(days):
            engine.run_day()
        final_stats = population_statistics(engine.state.citizens)
        return ExperimentResult(label=label, seed=cfg.seed, final_stats=final_stats,
                                  history=engine.state.statistics_history)

    def compare(self, scenarios: dict[str, dict], days: int) -> dict[str, ExperimentResult]:
        return {label: self.run_scenario(label, overrides, days) for label, overrides in scenarios.items()}
