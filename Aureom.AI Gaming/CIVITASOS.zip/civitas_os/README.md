# CIVITAS.OS

A city-building simulation engine where the population is **real**: build
housing for 20,000 people and the engine creates 20,000 individual
`Citizen` entities — each with an age, sex, household, home, job (or
unemployment), income, education, needs, a daily schedule, a commute mode,
and a persistent history — not a headcount and not a crowd of visual
extras standing in for a bigger number.

This delivery is the **first playable core** described in the master
prompt's own phased build plan (`FINAL PRODUCT DEFINITION`, sections
100–102, 121–123): a working, tested, benchmarked simulation of Phases
1–20 (clock → citizens → population generator → households → housing →
jobs → daily routines → movement → road network → transport demand →
economy → services → demographics → migration → land value → construction
→ urban planning → population LOD → spatial indexing → performance), with
a proven 20,000-citizen / one-year benchmark. It is not the full 132-item
specification (a photoreal renderer, a production-grade irregular street
network, and Rust/Numba-level scaling to 500K+ citizens are each their own
project) — see **What's stubbed / what's next** below for the honest gap
list.

## Quickstart

```bash
pip install -r requirements.txt

# Build a 20,000-citizen city and simulate one year (~10s setup + ~25s sim)
python run_benchmark.py --population 20000 --days 365

# Smaller, with a sample citizen inspector + daily trace printed
python run_benchmark.py --population 2000 --days 30 --trace

# Run the test suite (fast tests only; the 20K benchmark test is marked slow)
pytest -m "not slow"
pytest tests/test_benchmark_20k.py -m slow -s
```

## The 20,000-person test (spec §123), actually run

```
citizens              : 20,000
households            : 7,859
housing units built   : 7,867  (vacancy 0.1% at bring-up)
jobs created          : 8,965  (unemployment 6.1%)
road network          : 400 nodes, 760 edges

setup time            : ~9.6s  (generating 20,000 real citizens + 7,859
                                 households + housing + jobs + road graph)
1 simulated year       : ~26s   (13.7 simulated days/second)
```

Over that simulated year, births and migration created genuinely new
citizen entities (population moved from 20,000 to 20,111), and 5 citizens
ended up in `HOMELESS` housing_state — an emergent consequence of housing
supply vs. demand, not a scripted event. See `benchmark_report.txt` for
the full run log. Re-running `pytest tests/test_benchmark_20k.py -m slow -s`
reproduces this end to end.

Pick any citizen and they persist: `CitizenInspector` and `CitizenTrace`
(see `tools/`) can pull up any `CIT-########` by id — home, job, income,
household, current activity, full life history — at any point in the run,
and `test_citizen_still_exists_after_a_week` proves a sampled citizen's
identity survives a week of simulation.

## Architecture

```
civitas_os/
  core/         clock, config, events, random, weather, CityState
  population/   Citizen (Structure-of-Arrays), generator, demographics,
                migration, births, mortality
  households/   Household, formation/splitting/merging, HousingMarket
  economy/      LabourMarket & Jobs, Businesses, consumption, CityEconomy
  city/         Buildings, procedural block/parcel grid, zoning, land
                value, ConstructionQueue
  transport/    Road network graph, OD-cached routing, traffic/congestion,
                transit (routes/vehicles/stops), pedestrians
  services/     School/healthcare/safety/waste/water/energy demand from
                real population counts
  behaviour/    Needs, CitizenUtilityModel, daily-schedule templates,
                the OBSERVE→...→ACT decision engine
  simulation/   SimulationEngine (the closed loop), fidelity/LOD,
                vectorised aggregation, tick helpers
  spatial/      Grid + quadtree spatial indices
  analytics/    MetricsRecorder, ExperimentRunner, Monte Carlo runner
  rendering/    RenderAdapter interface + citizen/building/city view-model
                extraction — simulation truth is fully decoupled from any
                renderer (spec §84, §128)
  tools/        CitizenInspector, CitizenTrace, causal debugger
  config/       *.yaml — every distribution/parameter is data, not code
  tests/        generator + engine smoke tests, the CIVITAS-20K benchmark
```

### Why it performs at 20K+

- **Structure-of-Arrays citizens** (`population/citizen.py`): all 20,000+
  citizens' ages, incomes, needs, locations etc. live in flat NumPy
  arrays, so ageing/needs-decay/statistics are one vectorised call across
  the whole population instead of 20,000 Python attribute writes per tick.
  `CitizenView` gives the ergonomic single-citizen API on top of the same
  arrays for the inspector/trace tools.
- **Fixed-timestep clock, hourly activity resolution**: daily schedules
  are looked up from a small template matrix (`behaviour/schedules.py`)
  and applied to every active citizen in one NumPy indexing operation per
  simulated hour.
- **OD-pair route caching** (`transport/routing.py`): commute traffic is
  aggregated by (origin block, destination block) before any shortest-path
  call, so thousands of citizens sharing a commute corridor cost one
  cached route lookup, not one pathfind each (spec §81–82).
- **Multi-fidelity population** (`simulation/fidelity.py`): a
  `PopulationSimulationLevel` ladder (aggregate → household → individual →
  high-fidelity → visible/rendered) exists so a future renderer can spend
  its per-frame budget near the camera while background citizens keep
  advancing cheaply — nobody disappears (spec §19–21).
- **Dead ≠ deleted**: citizens who die or emigrate are masked out
  (`alive = False`), never removed, so household/relationship/history
  consequences remain queryable (spec §59).

### Determinism

Every city is `(seed, config)` → same outcome. `core/random.py` hands out
named, independently-seeded RNG streams (population, housing, jobs, mode
choice, migration, births, mortality, …) derived from one root seed, so
adding/removing a draw in one subsystem doesn't perturb another's sequence.
`tests/test_generator.py::test_deterministic_with_same_seed` checks this.

## What's implemented vs. stubbed

**Fully real, tested, load-bearing:**
Citizen/Household/HousingUnit/Building/Job models; population generation
from configurable distributions (not clones); household formation with
plausible age/role composition; a housing market with affordability-based
matching, vacancy, and emergent homelessness; a labour market matching
unemployed citizens to vacancies by education/salary/distance; procedural
block/parcel/zoning generation with a monocentric land-value model driving
rent; a routable road graph derived from that procedural layout with a
real (if simplified) road hierarchy and OD-cached shortest-path routing;
daily-schedule-driven hourly activity simulation with a needs system;
births/deaths/migration that create and retire real citizen entities;
vectorised city-wide statistics; save/load of the full `CityState`; a
citizen inspector, a citizen day-trace tool, and causal-debugging helpers
for "why did rent rise / why is this road congested / why did population
change".

**Deliberately simplified (flagged in code comments), natural next
phases:**
- **Road/parcel layout** is a clean procedural grid, not an irregular
  organic street network (`city/parcels.py` says so explicitly).
- **Traffic assignment** aggregates trips by origin/destination block
  rather than simulating individual vehicles turn-by-turn — real demand
  from real commuters, but not per-vehicle physics (`transport/traffic.py`).
- **Rendering** is a documented adapter interface
  (`rendering/adapter.py`) with a no-op and a console implementation; a
  real 2D/3D front end (Unity/Unreal/Godot/WebGPU) is a separate project
  that consumes this interface.
- **Businesses/consumption** use simplified P&L and Engel-curve-style
  spending shares rather than a full input-output economic model.
- **Health/safety** are explicitly abstract, game-level scores, per the
  spec's own instruction not to build a medical/crime simulator.
- **Scaling past ~50K–100K citizens** with this pure-Python/NumPy core
  will need the Numba/Rust-extension work flagged in the spec
  (§104–105) — the SoA design is chosen specifically so that path stays
  open without a data-model rewrite.
- **UrbanAdvisorAI / natural-language planner assistant** (§117–118): the
  causal-debugging primitives it would sit on top of
  (`tools/debugger.py`) are implemented; the NL layer itself isn't.

None of the above are silently faked — each is a real, inspectable
subsystem operating at a stated level of simplification, following the
engine's own founding rule: population, jobs, housing and demand are
never a multiplier on a UI number.
