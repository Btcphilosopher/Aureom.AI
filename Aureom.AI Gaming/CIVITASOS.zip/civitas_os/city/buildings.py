"""Buildings: the physical containers population, jobs, and services live in."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class BuildingType(str, Enum):
    HOUSE = "HOUSE"
    APARTMENT = "APARTMENT"
    TOWNHOUSE = "TOWNHOUSE"
    TOWER = "TOWER"
    OFFICE = "OFFICE"
    SHOP = "SHOP"
    FACTORY = "FACTORY"
    WAREHOUSE = "WAREHOUSE"
    SCHOOL = "SCHOOL"
    HOSPITAL = "HOSPITAL"
    UNIVERSITY = "UNIVERSITY"
    STATION = "STATION"
    BUS_DEPOT = "BUS_DEPOT"
    RESTAURANT = "RESTAURANT"
    CAFE = "CAFE"
    PARK = "PARK"
    SPORTS_FACILITY = "SPORTS_FACILITY"
    GOVERNMENT = "GOVERNMENT"
    CULTURAL = "CULTURAL"
    INDUSTRIAL = "INDUSTRIAL"


RESIDENTIAL_TYPES = {BuildingType.HOUSE, BuildingType.APARTMENT, BuildingType.TOWNHOUSE, BuildingType.TOWER}
EMPLOYMENT_TYPES = {BuildingType.OFFICE, BuildingType.SHOP, BuildingType.FACTORY, BuildingType.WAREHOUSE,
                    BuildingType.SCHOOL, BuildingType.HOSPITAL, BuildingType.UNIVERSITY, BuildingType.RESTAURANT,
                    BuildingType.CAFE, BuildingType.GOVERNMENT, BuildingType.CULTURAL, BuildingType.INDUSTRIAL}


@dataclass
class Building:
    building_id: int
    building_type: BuildingType
    location: tuple[float, float]
    capacity: int
    parcel_id: int = -1
    occupancy: int = 0
    workers: int = 0
    residents: int = 0
    operating_cost: float = 0.0
    energy_use: float = 0.0
    water_use: float = 0.0
    built_tick: int = 0
    housing_unit_ids: list[int] = field(default_factory=list)
    job_ids: list[int] = field(default_factory=list)

    @property
    def is_residential(self) -> bool:
        return self.building_type in RESIDENTIAL_TYPES

    @property
    def is_workplace(self) -> bool:
        return self.building_type in EMPLOYMENT_TYPES


class BuildingRegistry:
    def __init__(self):
        self._next_id = 0
        self.buildings: dict[int, Building] = {}

    def create(self, building_type: BuildingType, location: tuple[float, float],
               capacity: int, parcel_id: int = -1, built_tick: int = 0) -> Building:
        bid = self._next_id
        self._next_id += 1
        b = Building(bid, building_type, location, capacity, parcel_id=parcel_id, built_tick=built_tick)
        self.buildings[bid] = b
        return b

    def of_type(self, building_type: BuildingType):
        return [b for b in self.buildings.values() if b.building_type == building_type]

    def residential(self):
        return [b for b in self.buildings.values() if b.is_residential]

    def workplaces(self):
        return [b for b in self.buildings.values() if b.is_workplace]

    def total_energy_use(self) -> float:
        return sum(b.energy_use for b in self.buildings.values())

    def total_water_use(self) -> float:
        return sum(b.water_use for b in self.buildings.values())
