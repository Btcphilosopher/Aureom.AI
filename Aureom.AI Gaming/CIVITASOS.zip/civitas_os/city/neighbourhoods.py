"""Neighbourhoods aggregate blocks into named areas with their own identity
and statistics (spec #61), computed from the buildings/citizens inside them
rather than hand-authored.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Neighbourhood:
    neighbourhood_id: int
    name: str
    block_ids: set[int] = field(default_factory=set)
    population: int = 0
    density: float = 0.0
    avg_income: float = 0.0
    avg_land_value: float = 0.0
    housing_units: int = 0
    jobs: int = 0


class NeighbourhoodRegistry:
    def __init__(self):
        self._next_id = 0
        self.neighbourhoods: dict[int, Neighbourhood] = {}

    def create(self, name: str, block_ids: set[int]) -> Neighbourhood:
        nid = self._next_id
        self._next_id += 1
        n = Neighbourhood(nid, name, block_ids)
        self.neighbourhoods[nid] = n
        return n

    def partition_grid(self, grid, names: list[str]) -> None:
        """Split the CityGrid's blocks evenly into len(names) neighbourhoods
        (a simple k-means-free spatial partition: chunk by block id order,
        which — for the generated grid's row-major layout — yields
        contiguous districts)."""
        block_ids = sorted(grid.blocks.keys())
        chunks = _chunk(block_ids, len(names))
        for name, chunk in zip(names, chunks):
            self.create(name, set(chunk))

    def find_for_block(self, block_id: int) -> Neighbourhood | None:
        for n in self.neighbourhoods.values():
            if block_id in n.block_ids:
                return n
        return None


def _chunk(items: list, n: int) -> list[list]:
    if n <= 0:
        return [items]
    size = max(1, len(items) // n)
    return [items[i:i + size] for i in range(0, len(items), size)][:n] or [items]
