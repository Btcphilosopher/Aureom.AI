"""Procedural block/parcel generation.

A simplified but genuine procedural city layout: a road hierarchy carves
the city area into blocks, blocks are subdivided into buildable plots, and
buildings occupy actual plots (spec #65-#67). This favours a clean,
extensible grid model over a full irregular street-network generator,
which is flagged in the README as a natural next phase.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .zoning import ZoneType


@dataclass
class Parcel:
    parcel_id: int
    location: tuple[float, float]
    block_id: int
    zone: ZoneType
    area_sqm: float
    building_id: int | None = None

    @property
    def is_buildable(self) -> bool:
        return self.building_id is None


@dataclass
class Block:
    block_id: int
    bounds: tuple[float, float, float, float]  # x0, y0, x1, y1
    parcel_ids: list[int] = field(default_factory=list)


class CityGrid:
    """A simple, deterministic grid of blocks -> plots covering the city area.

    Grid cell size and plot subdivision are configurable; this keeps
    procedural generation genuinely data-driven (spec #119) rather than an
    arbitrary hard-coded layout.
    """

    def __init__(self, width_m: float, height_m: float, block_size_m: float,
                 plots_per_block_side: int, rng):
        self.width_m = width_m
        self.height_m = height_m
        self.block_size_m = block_size_m
        self.plots_per_block_side = plots_per_block_side
        self.rng = rng
        self.blocks: dict[int, Block] = {}
        self.parcels: dict[int, Parcel] = {}
        self._next_block_id = 0
        self._next_parcel_id = 0
        self.zoning: dict[int, ZoneType] = {}  # block_id -> zone (set by city.zoning)

    def generate(self, zone_assigner) -> None:
        n_cols = max(1, int(self.width_m // self.block_size_m))
        n_rows = max(1, int(self.height_m // self.block_size_m))
        plot_size = self.block_size_m / self.plots_per_block_side
        for row in range(n_rows):
            for col in range(n_cols):
                x0, y0 = col * self.block_size_m, row * self.block_size_m
                x1, y1 = x0 + self.block_size_m, y0 + self.block_size_m
                block = Block(self._next_block_id, (x0, y0, x1, y1))
                self._next_block_id += 1
                zone = zone_assigner(col, row, n_cols, n_rows)
                self.zoning[block.block_id] = zone
                for pr in range(self.plots_per_block_side):
                    for pc in range(self.plots_per_block_side):
                        px = x0 + pc * plot_size + plot_size / 2
                        py = y0 + pr * plot_size + plot_size / 2
                        parcel = Parcel(
                            parcel_id=self._next_parcel_id,
                            location=(px, py),
                            block_id=block.block_id,
                            zone=zone,
                            area_sqm=plot_size * plot_size,
                        )
                        self._next_parcel_id += 1
                        self.parcels[parcel.parcel_id] = parcel
                        block.parcel_ids.append(parcel.parcel_id)
                self.blocks[block.block_id] = block

    def buildable_parcels(self, zone: ZoneType | None = None) -> list[Parcel]:
        parcels = [p for p in self.parcels.values() if p.is_buildable]
        if zone is not None:
            parcels = [p for p in parcels if p.zone == zone]
        return parcels

    def distance_to_center(self, location: tuple[float, float]) -> float:
        cx, cy = self.width_m / 2, self.height_m / 2
        return ((location[0] - cx) ** 2 + (location[1] - cy) ** 2) ** 0.5
