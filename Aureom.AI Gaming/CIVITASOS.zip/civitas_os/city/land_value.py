"""Land value: an emergent function of accessibility, jobs, amenities,
density, transport, schools, safety, and commercial activity (spec #38),
not an author-set number. Feeds forward into construction/rents (#70, #97).
"""
from __future__ import annotations


def compute_land_value(*, accessibility: float, jobs_nearby: int, amenities_nearby: int,
                        density: float, transit_access: float, school_quality: float,
                        safety: float, commercial_activity: float) -> float:
    """Returns a land value index (roughly 0..100+, unbounded above for very
    desirable locations) from normalised inputs. Each term is intentionally
    simple and swappable so it stays inspectable/tunable rather than a black
    box regression."""
    value = 10.0
    value += 25.0 * accessibility               # 0..1: inverse avg travel time to jobs/amenities
    value += 0.004 * jobs_nearby                # raw count within catchment
    value += 0.6 * amenities_nearby
    value += 8.0 * min(density, 3.0)            # diminishing returns above 3x baseline density
    value += 15.0 * transit_access               # 0..1
    value += 10.0 * school_quality                # 0..1
    value += 12.0 * safety                        # 0..1
    value += 6.0 * commercial_activity            # 0..1
    return max(value, 1.0)


def rent_from_land_value(land_value: float, floor_area: float, quality: float) -> float:
    """Monthly rent estimate for a unit given the land value under it."""
    base_per_sqm = 4.0 + 0.35 * land_value
    return base_per_sqm * floor_area * (0.7 + 0.6 * quality)
