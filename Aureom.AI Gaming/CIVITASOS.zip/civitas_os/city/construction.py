"""Construction: player-initiated projects that take land + time to
resolve into real Buildings and HousingUnits, generating construction jobs
and material demand while underway (spec #68).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .buildings import Building, BuildingRegistry, BuildingType, RESIDENTIAL_TYPES
from .land_value import rent_from_land_value
from .zoning import ZoneType
from households.housing import HousingMarket, Tenure

# Rough capacity/area templates per building type; overridable via buildings.yaml.
DEFAULT_TEMPLATES = {
    BuildingType.HOUSE: {"capacity": 4, "bedrooms": 3, "floor_area": 110, "duration_days": 90},
    BuildingType.TOWNHOUSE: {"capacity": 4, "bedrooms": 3, "floor_area": 90, "duration_days": 75},
    BuildingType.APARTMENT: {"capacity": 60, "bedrooms": 2, "floor_area": 65, "duration_days": 180, "units_per_building": 24},
    BuildingType.TOWER: {"capacity": 240, "bedrooms": 2, "floor_area": 60, "duration_days": 365, "units_per_building": 96},
    BuildingType.OFFICE: {"capacity": 300, "duration_days": 240},
    BuildingType.SHOP: {"capacity": 15, "duration_days": 60},
    BuildingType.FACTORY: {"capacity": 150, "duration_days": 200},
    BuildingType.WAREHOUSE: {"capacity": 40, "duration_days": 120},
    BuildingType.SCHOOL: {"capacity": 500, "duration_days": 300},
    BuildingType.HOSPITAL: {"capacity": 400, "duration_days": 400},
    BuildingType.RESTAURANT: {"capacity": 20, "duration_days": 90},
    BuildingType.CAFE: {"capacity": 8, "duration_days": 45},
    BuildingType.GOVERNMENT: {"capacity": 100, "duration_days": 300},
    BuildingType.CULTURAL: {"capacity": 80, "duration_days": 180},
    BuildingType.PARK: {"capacity": 0, "duration_days": 60},
}


@dataclass
class ConstructionProject:
    project_id: int
    building_type: BuildingType
    parcel_id: int
    location: tuple[float, float]
    start_tick: int
    duration_ticks: int
    jobs_generated: int = 0
    completed: bool = False

    def is_complete(self, tick: int) -> bool:
        return tick - self.start_tick >= self.duration_ticks


class ConstructionQueue:
    def __init__(self, buildings: BuildingRegistry, housing: HousingMarket, ticks_per_day: int):
        self.buildings = buildings
        self.housing = housing
        self.ticks_per_day = ticks_per_day
        self._next_id = 0
        self.projects: dict[int, ConstructionProject] = {}

    def start_project(self, building_type: BuildingType, parcel, tick: int) -> ConstructionProject:
        template = DEFAULT_TEMPLATES.get(building_type, {"capacity": 20, "duration_days": 90})
        duration_ticks = template["duration_days"] * self.ticks_per_day
        pid = self._next_id
        self._next_id += 1
        project = ConstructionProject(
            project_id=pid, building_type=building_type, parcel_id=parcel.parcel_id,
            location=parcel.location, start_tick=tick, duration_ticks=duration_ticks,
            jobs_generated=max(2, template["capacity"] // 10),
        )
        self.projects[pid] = project
        return project

    def advance(self, tick: int, land_value_lookup=None) -> list[Building]:
        """Advance all in-progress projects; return newly completed Buildings."""
        completed_buildings = []
        for project in list(self.projects.values()):
            if project.completed:
                continue
            if project.is_complete(tick):
                building = self._materialise(project, tick, land_value_lookup)
                project.completed = True
                completed_buildings.append(building)
        return completed_buildings

    def _materialise(self, project: ConstructionProject, tick: int, land_value_lookup) -> Building:
        template = DEFAULT_TEMPLATES.get(project.building_type, {"capacity": 20})
        building = self.buildings.create(project.building_type, project.location,
                                          template["capacity"], parcel_id=project.parcel_id, built_tick=tick)
        if project.building_type in RESIDENTIAL_TYPES:
            self._create_housing_units(building, project.building_type, template, land_value_lookup)
        return building

    def _create_housing_units(self, building: Building, building_type: BuildingType,
                                template: dict, land_value_lookup) -> None:
        land_value = land_value_lookup(building.location) if land_value_lookup else 40.0
        n_units = template.get("units_per_building", 1)
        tenure = Tenure.RENTER if building_type in (BuildingType.APARTMENT, BuildingType.TOWER) else Tenure.OWNER
        for _ in range(n_units):
            rent = rent_from_land_value(land_value, template["floor_area"], quality=0.7)
            unit = self.housing.add_unit(
                building_id=building.building_id,
                capacity=max(1, template["capacity"] // max(n_units, 1)),
                bedrooms=template["bedrooms"],
                floor_area=template["floor_area"],
                rent=rent,
                sale_price=rent * 12 * 18,
                tenure=tenure,
                location=building.location,
                quality=0.7,
            )
            building.housing_unit_ids.append(unit.unit_id)
