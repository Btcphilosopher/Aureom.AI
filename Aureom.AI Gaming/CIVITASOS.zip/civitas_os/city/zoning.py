"""Zoning types and a simple monocentric-city zone assignment function."""
from __future__ import annotations

from enum import Enum


class ZoneType(str, Enum):
    RESIDENTIAL = "RESIDENTIAL"
    COMMERCIAL = "COMMERCIAL"
    INDUSTRIAL = "INDUSTRIAL"
    MIXED_USE = "MIXED_USE"
    CIVIC = "CIVIC"
    RECREATIONAL = "RECREATIONAL"
    TRANSPORT = "TRANSPORT"


def default_zone_assigner(col: int, row: int, n_cols: int, n_rows: int) -> ZoneType:
    """A simple monocentric layout: commercial/mixed core, residential ring,
    industrial on the periphery, scattered civic/recreational. Deterministic
    given (col, row) so it composes cleanly with the seeded RNG elsewhere."""
    cx, cy = n_cols / 2, n_rows / 2
    dist = ((col - cx) ** 2 + (row - cy) ** 2) ** 0.5
    max_dist = ((n_cols / 2) ** 2 + (n_rows / 2) ** 2) ** 0.5
    ratio = dist / max_dist if max_dist else 0

    if ratio < 0.12:
        return ZoneType.MIXED_USE
    if ratio < 0.3:
        return ZoneType.COMMERCIAL if (col + row) % 5 == 0 else ZoneType.RESIDENTIAL
    if ratio > 0.85:
        return ZoneType.INDUSTRIAL
    if (col * 7 + row * 3) % 23 == 0:
        return ZoneType.RECREATIONAL
    if (col * 5 + row * 11) % 29 == 0:
        return ZoneType.CIVIC
    return ZoneType.RESIDENTIAL


def planning_limits(zone: ZoneType, planning_cfg: dict) -> dict:
    """Height/FAR/coverage/parking limits for a zone, from data-driven config
    (spec #64), with sane fallback defaults."""
    defaults = {
        ZoneType.RESIDENTIAL: {"max_height_m": 24, "far": 1.5, "coverage": 0.5, "min_parking_ratio": 0.5},
        ZoneType.COMMERCIAL: {"max_height_m": 60, "far": 3.0, "coverage": 0.8, "min_parking_ratio": 0.3},
        ZoneType.INDUSTRIAL: {"max_height_m": 18, "far": 1.0, "coverage": 0.7, "min_parking_ratio": 0.2},
        ZoneType.MIXED_USE: {"max_height_m": 80, "far": 4.0, "coverage": 0.85, "min_parking_ratio": 0.2},
        ZoneType.CIVIC: {"max_height_m": 30, "far": 1.2, "coverage": 0.4, "min_parking_ratio": 0.3},
        ZoneType.RECREATIONAL: {"max_height_m": 0, "far": 0.0, "coverage": 0.05, "min_parking_ratio": 0.0},
        ZoneType.TRANSPORT: {"max_height_m": 40, "far": 2.0, "coverage": 0.6, "min_parking_ratio": 0.1},
    }
    override = planning_cfg.get(zone.value, {}) if planning_cfg else {}
    limits = dict(defaults[zone])
    limits.update(override)
    return limits
