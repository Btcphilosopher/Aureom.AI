"""Sanity tests for population generation: real distinct citizens, not
clones; households actually contain their members; ids are stable."""
from core.config import CityConfig
from population.generator import PopulationGenerator
from core.random import CityRandom


def _make_generator(population=500, seed=7):
    cfg = CityConfig.load({"seed": seed, "target_population": population})
    rng = CityRandom(seed)
    gen = PopulationGenerator(rng, cfg.population)
    return gen, cfg


def test_generates_requested_population_closely():
    gen, cfg = _make_generator(500)
    result = gen.generate_city_population(500, city_bounds=(2000, 2000))
    active = result.citizens.active_mask().sum()
    assert 480 <= active <= 520


def test_citizens_are_not_clones():
    gen, cfg = _make_generator(300)
    result = gen.generate_city_population(300, city_bounds=(2000, 2000))
    citizens = result.citizens
    active_idx = citizens.active_indices()
    ages = set(round(a, 1) for a in citizens.age_years[active_idx][:50])
    incomes = set(round(i, -2) for i in citizens.income[active_idx][:50])
    assert len(ages) > 5
    assert len(incomes) > 5


def test_household_membership_consistent():
    gen, cfg = _make_generator(300)
    result = gen.generate_city_population(300, city_bounds=(2000, 2000))
    for hh in result.households.active():
        for slot in hh.member_slots:
            assert int(result.citizens.household_id[slot]) == hh.household_id


def test_citizen_ids_are_stable_format():
    gen, cfg = _make_generator(50)
    result = gen.generate_city_population(50, city_bounds=(1000, 1000))
    for slot in result.citizens.active_indices()[:10]:
        cid = result.citizens.citizen_id[slot]
        assert cid.startswith("CIT-")
        assert len(cid) == 12


def test_deterministic_with_same_seed():
    gen1, _ = _make_generator(200, seed=99)
    gen2, _ = _make_generator(200, seed=99)
    r1 = gen1.generate_city_population(200, city_bounds=(1500, 1500))
    r2 = gen2.generate_city_population(200, city_bounds=(1500, 1500))
    import numpy as np
    assert np.allclose(r1.citizens.age_years[: r1.citizens.n], r2.citizens.age_years[: r2.citizens.n])
