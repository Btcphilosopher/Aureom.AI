"""CIVITAS-20K (spec #102): generate a real 20,000-citizen city and run
one simulated year, measuring wall-clock performance. Marked slow — run
explicitly with:  pytest tests/test_benchmark_20k.py -m slow -s
"""
import pytest

from core.config import CityConfig
from simulation.engine import SimulationEngine


@pytest.mark.slow
def test_civitas_20k_one_year():
    cfg = CityConfig.load({"seed": 2026, "target_population": 20_000, "name": "CIVITAS-20K"})
    engine = SimulationEngine(cfg)
    engine.setup()

    s = engine.state
    initial_pop = int(s.citizens.active_mask().sum())
    assert initial_pop >= 19_000

    report = engine.benchmark(days=365)

    print(f"\nCIVITAS-20K benchmark report:")
    print(f"  citizens generated : {report.citizens_generated}")
    print(f"  households          : {report.households_generated}")
    print(f"  housing units built : {report.housing_units_built}")
    print(f"  jobs created        : {report.jobs_created}")
    print(f"  days simulated      : {report.days_simulated}")
    print(f"  wall-clock seconds  : {report.wall_seconds:.2f}")
    print(f"  days/sec            : {report.days_simulated / report.wall_seconds:.2f}")

    assert report.days_simulated == 365
    assert report.wall_seconds > 0
