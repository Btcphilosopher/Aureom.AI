"""Small end-to-end smoke test of the full setup() + run_day() loop at a
size that runs fast in CI; the real 20K benchmark lives in
test_benchmark_20k.py and is opt-in (slow)."""
from core.config import CityConfig
from simulation.engine import SimulationEngine


def _build(pop=800, seed=3):
    cfg = CityConfig.load({"seed": seed, "target_population": pop})
    engine = SimulationEngine(cfg)
    engine.setup()
    return engine


def test_setup_creates_real_population_and_housing():
    engine = _build(800)
    s = engine.state
    active = int(s.citizens.active_mask().sum())
    assert active > 700
    assert len(s.households.households) > 0
    assert len(s.housing_market.units) > 0


def test_run_day_advances_clock_and_returns_stats():
    engine = _build(300)
    before_tick = engine.state.clock.tick
    stats = engine.run_day()
    assert engine.state.clock.tick > before_tick
    assert stats["population"] > 0


def test_citizen_still_exists_after_a_week():
    engine = _build(300)
    citizens = engine.state.citizens
    sample_id = citizens.citizen_id[citizens.active_indices()[0]]
    for _ in range(7):
        engine.run_day()
    found = citizens.find_by_id(sample_id)
    assert found is not None
    assert found.alive


def test_jobs_and_housing_are_real_entities():
    engine = _build(600)
    s = engine.state
    employed = int((s.citizens.employment_state[: s.citizens.n] == 0).sum())
    filled_jobs = sum(1 for j in engine._labour_market.jobs.values() if not j.is_vacant)
    assert filled_jobs > 0
    assert filled_jobs <= employed + 5  # small slack for unmatched citizens
