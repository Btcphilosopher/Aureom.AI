"""The individual citizen model — Structure-of-Arrays backed.

CIVITAS.OS's founding rule: 20,000 housed people means 20,000 individual
Citizen entities, not a UI number. To make that actually perform at scale
in Python, citizen *identity* (a stable CIT-######## id) is separated from
citizen *simulation data*, which lives in flat NumPy arrays ("Structure of
Arrays") indexed by a dense integer slot. Vectorised NumPy operations (see
simulation/aggregation.py, behaviour/schedules.py) then update ageing,
needs, income, location etc. for all 20,000+ citizens in one call instead
of 20,000 Python-level attribute writes per tick.

CitizenView gives the ergonomic, "one citizen as an object" read/write API
(used by the inspector, trace tool, and anywhere a single citizen matters)
on top of the same arrays, so nothing is duplicated.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Optional

import numpy as np


class Sex(IntEnum):
    FEMALE = 0
    MALE = 1


class EmploymentState(IntEnum):
    EMPLOYED = 0
    UNEMPLOYED = 1
    STUDENT = 2
    RETIRED = 3
    CHILD = 4
    CARE_GIVER = 5


class HousingState(IntEnum):
    HOUSED = 0
    OVERCROWDED = 1
    HOMELESS = 2
    TEMPORARY = 3


class Activity(IntEnum):
    SLEEP = 0
    EAT = 1
    WORK = 2
    STUDY = 3
    SHOP = 4
    TRAVEL = 5
    EXERCISE = 6
    SOCIALISE = 7
    ENTERTAINMENT = 8
    RELIGION = 9
    HEALTHCARE = 10
    CHILDCARE = 11
    HOME = 12


class TravelMode(IntEnum):
    NONE = 0
    WALK = 1
    BICYCLE = 2
    BUS = 3
    TRAIN = 4
    METRO = 5
    CAR = 6
    TAXI = 7
    OTHER = 8


EDUCATION_LEVELS = ["none", "primary", "secondary", "vocational", "university", "postgraduate"]


class CitizenPopulation:
    """Structure-of-Arrays store for every citizen who has ever existed.

    Dead citizens are not removed (history/relationships/household
    consequences must persist per spec #59); `alive` masks them out of
    active simulation and aggregation.
    """

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.n = 0  # number of slots actually used (including dead)

        # --- identity -----------------------------------------------------
        self.citizen_id = np.empty(capacity, dtype=object)   # "CIT-00000001"
        self.alive = np.zeros(capacity, dtype=bool)
        self.birth_tick = np.zeros(capacity, dtype=np.int64)
        self.death_tick = np.full(capacity, -1, dtype=np.int64)

        # --- demographics ---------------------------------------------------
        self.age_years = np.zeros(capacity, dtype=np.float32)
        self.sex = np.zeros(capacity, dtype=np.int8)
        self.education_level = np.zeros(capacity, dtype=np.int8)  # index into EDUCATION_LEVELS

        # --- social / economic ------------------------------------------
        self.household_id = np.full(capacity, -1, dtype=np.int64)
        self.home_id = np.full(capacity, -1, dtype=np.int64)         # HousingUnit id
        self.workplace_id = np.full(capacity, -1, dtype=np.int64)    # Building id
        self.job_id = np.full(capacity, -1, dtype=np.int64)
        self.occupation_code = np.full(capacity, -1, dtype=np.int32)
        self.income = np.zeros(capacity, dtype=np.float64)           # annual
        self.wealth = np.zeros(capacity, dtype=np.float64)
        self.employment_state = np.full(capacity, EmploymentState.CHILD, dtype=np.int8)
        self.housing_state = np.full(capacity, HousingState.HOUSED, dtype=np.int8)

        # --- wellbeing ------------------------------------------------------
        self.health_state = np.full(capacity, 1.0, dtype=np.float32)   # 0..1
        self.happiness = np.full(capacity, 0.6, dtype=np.float32)      # 0..1

        # --- needs (0 = fully satisfied urgency, 1 = critical) ------------
        self.need_food = np.zeros(capacity, dtype=np.float32)
        self.need_sleep = np.zeros(capacity, dtype=np.float32)
        self.need_social = np.zeros(capacity, dtype=np.float32)
        self.need_health = np.zeros(capacity, dtype=np.float32)
        self.need_leisure = np.zeros(capacity, dtype=np.float32)

        # --- location / activity ------------------------------------------
        self.location_x = np.zeros(capacity, dtype=np.float32)
        self.location_y = np.zeros(capacity, dtype=np.float32)
        self.destination_x = np.zeros(capacity, dtype=np.float32)
        self.destination_y = np.zeros(capacity, dtype=np.float32)
        self.current_activity = np.full(capacity, Activity.HOME, dtype=np.int8)
        self.commute_mode = np.full(capacity, TravelMode.NONE, dtype=np.int8)

        # --- simulation fidelity (see simulation/fidelity.py) --------------
        self.fidelity_level = np.zeros(capacity, dtype=np.int8)

        # sparse per-citizen extras that don't vectorise well (rare mutation)
        self.life_history: dict[int, list[str]] = {}
        self.relationships: dict[int, dict[str, list[int]]] = {}  # slot -> {"family":[...], "friends":[...]}

    # -- slot allocation ----------------------------------------------------
    def allocate(self, n_new: int) -> np.ndarray:
        """Reserve n_new fresh slots (growing storage if needed). Returns slot indices."""
        if self.n + n_new > self.capacity:
            self._grow(max(self.capacity * 2, self.n + n_new))
        slots = np.arange(self.n, self.n + n_new)
        self.n += n_new
        return slots

    def _grow(self, new_capacity: int) -> None:
        old_capacity = self.capacity
        for attr, arr in list(self.__dict__.items()):
            if isinstance(arr, np.ndarray) and arr.shape[0] == old_capacity:
                pad_shape = (new_capacity - old_capacity,) + arr.shape[1:]
                pad = np.zeros(pad_shape, dtype=arr.dtype) if arr.dtype != object else np.empty(pad_shape, dtype=object)
                setattr(self, attr, np.concatenate([arr, pad]))
        self.capacity = new_capacity

    def active_mask(self) -> np.ndarray:
        return self.alive[: self.n]

    def active_indices(self) -> np.ndarray:
        return np.nonzero(self.active_mask())[0]

    def next_sequence(self) -> int:
        return int(self.n)

    @staticmethod
    def format_id(slot: int) -> str:
        return f"CIT-{slot + 1:08d}"

    # -- single-citizen ergonomic view ---------------------------------------
    def view(self, slot: int) -> "CitizenView":
        return CitizenView(self, slot)

    def find_by_id(self, citizen_id: str) -> Optional["CitizenView"]:
        idx = np.where(self.citizen_id[: self.n] == citizen_id)[0]
        if len(idx) == 0:
            return None
        return self.view(int(idx[0]))

    def log(self, slot: int, message: str) -> None:
        self.life_history.setdefault(slot, []).append(message)


@dataclass
class CitizenView:
    """Convenience read/write facade over one SoA slot."""

    pop: CitizenPopulation
    slot: int

    def __getattr__(self, item):
        arr = getattr(self.pop, item, None)
        if isinstance(arr, np.ndarray):
            return arr[self.slot]
        raise AttributeError(item)

    def to_dict(self) -> dict:
        p, s = self.pop, self.slot
        return {
            "citizen_id": p.citizen_id[s],
            "alive": bool(p.alive[s]),
            "age": float(p.age_years[s]),
            "sex": Sex(p.sex[s]).name,
            "education_level": EDUCATION_LEVELS[p.education_level[s]],
            "household_id": int(p.household_id[s]),
            "home_id": int(p.home_id[s]),
            "workplace_id": int(p.workplace_id[s]),
            "occupation_code": int(p.occupation_code[s]),
            "income": float(p.income[s]),
            "wealth": float(p.wealth[s]),
            "employment_state": EmploymentState(p.employment_state[s]).name,
            "housing_state": HousingState(p.housing_state[s]).name,
            "health_state": float(p.health_state[s]),
            "happiness": float(p.happiness[s]),
            "current_activity": Activity(p.current_activity[s]).name,
            "commute_mode": TravelMode(p.commute_mode[s]).name,
            "location": (float(p.location_x[s]), float(p.location_y[s])),
            "history": p.life_history.get(s, []),
        }
