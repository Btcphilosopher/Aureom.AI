"""MigrationModel (spec #57): citizens enter/leave the city based on
housing availability, job vacancies, wages, amenities and cost of living —
an emergent push/pull model, not a scripted population target.
"""
from __future__ import annotations

import numpy as np

from core.events import EventBus, EventType
from households.household import HouseholdType
from population.citizen import CitizenPopulation, EmploymentState, HousingState
from population.generator import DEFAULT_INCOME_LOGNORMAL, PopulationGenerator


class MigrationModel:
    def __init__(self, random_source, event_bus: EventBus, generator: PopulationGenerator):
        self.rng = random_source.stream("population.migration")
        self.events = event_bus
        self.generator = generator

    def attractiveness_score(self, vacancy_rate: float, unemployment_rate: float,
                               avg_land_value: float, avg_wage: float) -> float:
        """0..1-ish pull score: available housing and jobs attract migrants;
        high unemployment and expensive land repel them (spec #57, #97)."""
        score = 0.0
        score += 0.4 * np.clip(vacancy_rate * 5, 0, 1)
        score += 0.3 * np.clip(1 - unemployment_rate * 4, 0, 1)
        score += 0.2 * np.clip(avg_wage / 40000, 0, 1)
        score -= 0.2 * np.clip((avg_land_value - 40) / 100, 0, 1)
        return float(np.clip(score, -1, 1))

    def monthly_migration(self, citizens: CitizenPopulation, household_registry, housing_market,
                            score: float, base_rate: float, city_bounds, tick: int) -> dict:
        """Positive score -> net in-migration; negative -> net out-migration.
        Both create/remove REAL households and citizens (spec #72: no magic
        population +=)."""
        current_pop = int(citizens.active_mask().sum())
        net_rate = base_rate * score
        target_change = int(current_pop * net_rate)

        result = {"in": 0, "out": 0}
        if target_change > 0:
            result["in"] = self._migrate_in(citizens, household_registry, housing_market, target_change, city_bounds, tick)
        elif target_change < 0:
            result["out"] = self._migrate_out(citizens, household_registry, housing_market, -target_change, tick)
        return result

    def _migrate_in(self, citizens, household_registry, housing_market, n_target, city_bounds, tick) -> int:
        if not housing_market.vacant_units():
            return 0
        n_target = min(n_target, len(housing_market.vacant_units()) * 3)
        if n_target <= 0:
            return 0
        gen = self.generator
        moved_in = 0
        household_types = list(HouseholdType)
        while moved_in < n_target:
            household_type = household_types[int(self.rng.integers(0, len(household_types)))]
            from population.generator import HOUSEHOLD_TEMPLATES
            template = HOUSEHOLD_TEMPLATES[household_type]
            n_adults = int(self.rng.integers(template["adults"][0], template["adults"][1] + 1))
            hh = household_registry.create(household_type, formed_tick=tick)
            location = (float(self.rng.uniform(0, city_bounds[0])), float(self.rng.uniform(0, city_bounds[1])))
            for _ in range(min(n_adults, n_target - moved_in)):
                slot = gen._spawn_citizen(
                    citizens, age_range=template["adult_age"], household_id=hh.household_id,
                    education_weights=gen.config.get("education_weights", [0.05, 0.15, 0.30, 0.20, 0.25, 0.05]),
                    employment_rate=gen.config.get("employment_rate_working_age", 0.72),
                    income_params=gen.config.get("income_lognormal", DEFAULT_INCOME_LOGNORMAL),
                    location=location,
                )
                hh.add_member(slot)
                moved_in += 1
                self.events.publish(EventType.MIGRATION_IN, tick, citizen_id=citizens.citizen_id[slot], slot=slot)
            unit = housing_market.find_home(sum(citizens.income[s] for s in hh.member_slots), hh.size)
            if unit:
                housing_market.assign(unit, hh.household_id)
                hh.home_id = unit.unit_id
                for s in hh.member_slots:
                    citizens.home_id[s] = unit.unit_id
                    citizens.housing_state[s] = HousingState.HOUSED
            else:
                for s in hh.member_slots:
                    citizens.housing_state[s] = HousingState.HOMELESS
                housing_market.homeless_households.add(hh.household_id)
            if moved_in >= n_target:
                break
        return moved_in

    def _migrate_out(self, citizens, household_registry, housing_market, n_target, tick) -> int:
        candidates = [hh for hh in household_registry.active() if hh.size > 0]
        self.rng.shuffle(candidates)
        moved_out = 0
        for hh in candidates:
            if moved_out >= n_target:
                break
            for s in list(hh.member_slots):
                citizens.alive[s] = False
                citizens.death_tick[s] = tick  # slot retired from active sim; history preserved
                citizens.log(s, "emigrated from the city")
                self.events.publish(EventType.MIGRATION_OUT, tick, citizen_id=citizens.citizen_id[s], slot=s)
                moved_out += 1
            if hh.home_id >= 0:
                housing_market.vacate(hh.home_id)
            household_registry.dissolve(hh.household_id)
        return moved_out
