"""PopulationGenerator (spec #08-#10): turns target_population + configured
distributions into real Citizen and Household entities — not a headcount.

generate_city_population(population=20000) must produce 20,000 individual
citizens grouped into realistic households, each with distinct age, sex,
education, occupation, income and employment state drawn from
configurable statistical distributions (never 20,000 identical clones).
The whole process is driven off CityRandom, so (seed, config) fully
determines the output (spec #10 replay/determinism).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from core.random import CityRandom
from households.household import Household, HouseholdRegistry, HouseholdType
from population.citizen import CitizenPopulation, EDUCATION_LEVELS, EmploymentState, HousingState, Sex
from population.demographics import DEFAULT_AGE_BRACKETS

# Household-type composition templates: how many adults/children a household
# of this type has, and the plausible age bands for each role.
HOUSEHOLD_TEMPLATES: dict[HouseholdType, dict] = {
    HouseholdType.SINGLE:             {"adults": (1, 1), "adult_age": (25, 75), "children": (0, 0)},
    HouseholdType.COUPLE:             {"adults": (2, 2), "adult_age": (22, 75), "children": (0, 0)},
    HouseholdType.FAMILY:             {"adults": (2, 2), "adult_age": (25, 55), "children": (1, 3), "child_age": (0, 17)},
    HouseholdType.SHARED:             {"adults": (2, 5), "adult_age": (20, 40), "children": (0, 0)},
    HouseholdType.MULTIGENERATIONAL:  {"adults": (3, 5), "adult_age": (20, 80), "children": (0, 2), "child_age": (0, 17)},
    HouseholdType.STUDENT:            {"adults": (1, 4), "adult_age": (18, 25), "children": (0, 0)},
    HouseholdType.ELDERLY:            {"adults": (1, 2), "adult_age": (65, 95), "children": (0, 0)},
    HouseholdType.SINGLE_PARENT:      {"adults": (1, 1), "adult_age": (22, 55), "children": (1, 3), "child_age": (0, 17)},
}

DEFAULT_HOUSEHOLD_TYPE_WEIGHTS = {
    HouseholdType.SINGLE: 0.24, HouseholdType.COUPLE: 0.22, HouseholdType.FAMILY: 0.24,
    HouseholdType.SHARED: 0.08, HouseholdType.MULTIGENERATIONAL: 0.05, HouseholdType.STUDENT: 0.06,
    HouseholdType.ELDERLY: 0.06, HouseholdType.SINGLE_PARENT: 0.05,
}

DEFAULT_EDUCATION_WEIGHTS = [0.05, 0.15, 0.30, 0.20, 0.25, 0.05]  # aligns w/ EDUCATION_LEVELS
DEFAULT_EMPLOYMENT_RATE_WORKING_AGE = 0.72
DEFAULT_INCOME_LOGNORMAL = {"mean_log": 10.1, "sigma_log": 0.55}  # ~ median income ~24k


@dataclass
class PopulationGenerationResult:
    citizens: CitizenPopulation
    households: HouseholdRegistry


class PopulationGenerator:
    def __init__(self, random_source: CityRandom, config: dict | None = None):
        self.rng = random_source.stream("population.generator")
        self.config = config or {}

    def _weights(self, key: str, default: dict) -> dict:
        cfg = self.config.get(key)
        return cfg if cfg else default

    def generate_city_population(self, population: int, city_bounds: tuple[float, float] = (5000, 5000)) -> PopulationGenerationResult:
        household_weights = self._weights("household_type_weights", DEFAULT_HOUSEHOLD_TYPE_WEIGHTS)
        education_weights = self.config.get("education_weights", DEFAULT_EDUCATION_WEIGHTS)
        employment_rate = self.config.get("employment_rate_working_age", DEFAULT_EMPLOYMENT_RATE_WORKING_AGE)
        income_params = self.config.get("income_lognormal", DEFAULT_INCOME_LOGNORMAL)

        citizens = CitizenPopulation(capacity=max(int(population * 1.3), 1024))
        households = HouseholdRegistry()

        types = [HouseholdType(t) if not isinstance(t, HouseholdType) else t for t in household_weights.keys()]
        probs = np.array(list(household_weights.values()), dtype=np.float64)
        probs /= probs.sum()

        generated = 0
        width, height = city_bounds
        while generated < population:
            remaining = population - generated
            household_type = types[int(self.rng.choice(len(types), p=probs))]
            template = HOUSEHOLD_TEMPLATES[household_type]

            n_adults = int(self.rng.integers(template["adults"][0], template["adults"][1] + 1))
            n_children = 0
            if template.get("children", (0, 0))[1] > 0:
                n_children = int(self.rng.integers(template["children"][0], template["children"][1] + 1))
            n_members = min(n_adults + n_children, max(remaining, 1))
            if n_members == 0:
                continue
            # keep the last household from overshooting wildly
            if remaining < 2 and n_members > remaining:
                n_members = remaining

            hh = households.create(household_type, formed_tick=0)
            home_location = (float(self.rng.uniform(0, width)), float(self.rng.uniform(0, height)))

            members_placed = 0
            adults_to_place = min(n_adults, n_members)
            for _ in range(adults_to_place):
                slot = self._spawn_citizen(
                    citizens, age_range=template["adult_age"], household_id=hh.household_id,
                    education_weights=education_weights, employment_rate=employment_rate,
                    income_params=income_params, location=home_location,
                )
                hh.add_member(slot)
                members_placed += 1

            children_to_place = max(0, n_members - members_placed)
            child_age_range = template.get("child_age", (0, 17))
            for _ in range(children_to_place):
                slot = self._spawn_citizen(
                    citizens, age_range=child_age_range, household_id=hh.household_id,
                    education_weights=education_weights, employment_rate=employment_rate,
                    income_params=income_params, location=home_location, force_child=True,
                )
                hh.add_member(slot)
                members_placed += 1

            generated += members_placed

        return PopulationGenerationResult(citizens=citizens, households=households)

    def _spawn_citizen(self, citizens: CitizenPopulation, *, age_range: tuple[float, float],
                         household_id: int, education_weights, employment_rate: float,
                         income_params: dict, location: tuple[float, float],
                         force_child: bool = False) -> int:
        slot = int(citizens.allocate(1)[0])
        age = float(self.rng.uniform(age_range[0], age_range[1] + 1))
        if force_child:
            age = min(age, 17.0)

        citizens.citizen_id[slot] = CitizenPopulation.format_id(slot)
        citizens.alive[slot] = True
        citizens.birth_tick[slot] = 0
        citizens.age_years[slot] = age
        citizens.sex[slot] = int(self.rng.integers(0, 2))
        citizens.household_id[slot] = household_id
        citizens.location_x[slot], citizens.location_y[slot] = location
        citizens.destination_x[slot], citizens.destination_y[slot] = location
        citizens.health_state[slot] = float(np.clip(self.rng.normal(0.85, 0.1), 0.2, 1.0))
        citizens.happiness[slot] = float(np.clip(self.rng.normal(0.6, 0.15), 0.05, 1.0))
        citizens.wealth[slot] = 0.0

        if age < 5:
            citizens.education_level[slot] = 0
            citizens.employment_state[slot] = EmploymentState.CHILD
            citizens.income[slot] = 0.0
        elif age < 18:
            citizens.education_level[slot] = min(2, EDUCATION_LEVELS.index("secondary"))
            citizens.employment_state[slot] = EmploymentState.CHILD
            citizens.income[slot] = 0.0
        elif age < 24 and self.rng.random() < 0.4:
            citizens.education_level[slot] = self._sample_education(education_weights)
            citizens.employment_state[slot] = EmploymentState.STUDENT
            citizens.income[slot] = 0.0
        elif age >= 66:
            citizens.education_level[slot] = self._sample_education(education_weights)
            citizens.employment_state[slot] = EmploymentState.RETIRED
            citizens.income[slot] = float(max(self.rng.normal(14000, 4000), 6000))
        else:
            citizens.education_level[slot] = self._sample_education(education_weights)
            if self.rng.random() < employment_rate:
                citizens.employment_state[slot] = EmploymentState.EMPLOYED
                citizens.income[slot] = float(self.rng.lognormal(income_params["mean_log"], income_params["sigma_log"]))
            else:
                citizens.employment_state[slot] = EmploymentState.UNEMPLOYED
                citizens.income[slot] = float(max(self.rng.normal(6000, 1500), 0))

        citizens.housing_state[slot] = HousingState.HOUSED
        citizens.log(slot, f"born/generated at age {age:.1f}")
        return slot

    def _sample_education(self, weights) -> int:
        probs = np.array(weights, dtype=np.float64)
        probs /= probs.sum()
        return int(self.rng.choice(len(EDUCATION_LEVELS), p=probs))
