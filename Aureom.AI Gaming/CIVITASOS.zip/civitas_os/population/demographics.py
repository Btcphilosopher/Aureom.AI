"""Demographic distributions and helpers (spec #06, #09).

All distributions are configurable (loaded from population_distributions.yaml
via core/config.py) with sane defaults here so the module works standalone.
"""
from __future__ import annotations

import numpy as np

DEFAULT_AGE_BRACKETS = [
    # (min_age, max_age, weight)
    (0, 4, 0.06), (5, 10, 0.06), (11, 17, 0.08), (18, 24, 0.09),
    (25, 34, 0.16), (35, 44, 0.15), (45, 54, 0.13), (55, 64, 0.11),
    (65, 74, 0.09), (75, 95, 0.07),
]

# Simplified annual mortality probability by age bracket (game-level, not
# actuarial-grade — spec #50 explicitly calls for an abstract model).
DEFAULT_MORTALITY = [
    (0, 4, 0.001), (5, 17, 0.0003), (18, 34, 0.0008), (35, 54, 0.002),
    (55, 64, 0.006), (65, 74, 0.018), (75, 84, 0.045), (85, 120, 0.12),
]

DEFAULT_FERTILITY_RATE_PER_WOMAN_PER_YEAR = 0.045  # ages 18-40


def sample_ages(rng, n: int, brackets: list[tuple[int, int, float]] | None = None) -> np.ndarray:
    brackets = brackets or DEFAULT_AGE_BRACKETS
    weights = np.array([b[2] for b in brackets], dtype=np.float64)
    weights /= weights.sum()
    chosen = rng.choice(len(brackets), size=n, p=weights)
    ages = np.empty(n, dtype=np.float32)
    for i, bracket_idx in enumerate(chosen):
        lo, hi, _ = brackets[bracket_idx]
        ages[i] = rng.uniform(lo, hi + 1)
    return ages


def mortality_probability(age: float, table: list[tuple[int, int, float]] | None = None) -> float:
    table = table or DEFAULT_MORTALITY
    for lo, hi, p in table:
        if lo <= age <= hi:
            return p
    return table[-1][2]


def annual_deaths_mask(rng, ages: np.ndarray, alive_mask: np.ndarray,
                         table: list[tuple[int, int, float]] | None = None) -> np.ndarray:
    """Vectorised: returns boolean mask of citizens who die this year."""
    table = table or DEFAULT_MORTALITY
    probs = np.zeros_like(ages, dtype=np.float64)
    for lo, hi, p in table:
        band = (ages >= lo) & (ages <= hi)
        probs[band] = p
    draws = rng.random(len(ages))
    return alive_mask & (draws < probs)


def expected_births(rng, female_ages: np.ndarray, fertility_rate: float = DEFAULT_FERTILITY_RATE_PER_WOMAN_PER_YEAR) -> int:
    fertile = (female_ages >= 18) & (female_ages <= 40)
    n_fertile = int(fertile.sum())
    if n_fertile == 0:
        return 0
    return int(rng.binomial(n_fertile, fertility_rate))
