"""Births (spec #58): new citizens receive a unique, stable ID, parents,
household, and birth date — generated from statistical fertility rates,
not scripted."""
from __future__ import annotations

import numpy as np

from core.events import EventBus, EventType
from population.citizen import CitizenPopulation, EmploymentState, HousingState, Sex
from population.demographics import expected_births


class BirthModel:
    def __init__(self, random_source, event_bus: EventBus, fertility_rate: float = 0.045):
        self.rng = random_source.stream("population.births")
        self.events = event_bus
        self.fertility_rate = fertility_rate

    def apply_annual_births(self, citizens: CitizenPopulation, household_registry, tick: int) -> list[int]:
        active = citizens.active_mask()
        n = citizens.n
        is_female = citizens.sex[:n] == Sex.FEMALE
        eligible_mask = active & is_female
        female_ages = citizens.age_years[:n][eligible_mask]
        eligible_slots = np.nonzero(eligible_mask)[0]

        n_births_target = expected_births(self.rng, female_ages, self.fertility_rate)
        if n_births_target == 0 or len(eligible_slots) == 0:
            return []

        fertile_mask = (female_ages >= 18) & (female_ages <= 40)
        fertile_mothers = eligible_slots[fertile_mask]
        if len(fertile_mothers) == 0:
            return []

        chosen_mothers = self.rng.choice(fertile_mothers, size=min(n_births_target, len(fertile_mothers)), replace=False)
        new_slots = []
        for mother_slot in chosen_mothers:
            mother_slot = int(mother_slot)
            hh_id = int(citizens.household_id[mother_slot])
            slot = self._spawn_infant(citizens, mother_slot, hh_id, tick)
            hh = household_registry.get(hh_id)
            if hh:
                hh.add_member(slot)
            new_slots.append(slot)
            self.events.publish(EventType.PERSON_BORN, tick, citizen_id=citizens.citizen_id[slot],
                                 slot=slot, mother_slot=mother_slot)
        return new_slots

    def _spawn_infant(self, citizens: CitizenPopulation, mother_slot: int, household_id: int, tick: int) -> int:
        slot = int(citizens.allocate(1)[0])
        citizens.citizen_id[slot] = CitizenPopulation.format_id(slot)
        citizens.alive[slot] = True
        citizens.birth_tick[slot] = tick
        citizens.age_years[slot] = 0.0
        citizens.sex[slot] = int(self.rng.integers(0, 2))
        citizens.household_id[slot] = household_id
        citizens.home_id[slot] = citizens.home_id[mother_slot]
        citizens.location_x[slot] = citizens.location_x[mother_slot]
        citizens.location_y[slot] = citizens.location_y[mother_slot]
        citizens.destination_x[slot] = citizens.location_x[mother_slot]
        citizens.destination_y[slot] = citizens.location_y[mother_slot]
        citizens.education_level[slot] = 0
        citizens.employment_state[slot] = EmploymentState.CHILD
        citizens.housing_state[slot] = citizens.housing_state[mother_slot]
        citizens.health_state[slot] = 1.0
        citizens.happiness[slot] = 0.8
        citizens.income[slot] = 0.0
        citizens.wealth[slot] = 0.0
        citizens.log(slot, f"born to {citizens.citizen_id[mother_slot]}")
        return slot
