"""Death (spec #59): removes a citizen from the ACTIVE population while
preserving history/household/relationship consequences — the slot is
never reused or deleted, `alive` just flips false."""
from __future__ import annotations

import numpy as np

from core.events import EventBus, EventType
from population.citizen import CitizenPopulation
from population.demographics import annual_deaths_mask


class MortalityModel:
    def __init__(self, random_source, event_bus: EventBus):
        self.rng = random_source.stream("population.mortality")
        self.events = event_bus

    def apply_annual_deaths(self, citizens: CitizenPopulation, household_registry, housing_market, tick: int) -> list[int]:
        active = citizens.active_mask()
        ages = citizens.age_years[: citizens.n]
        dies = annual_deaths_mask(self.rng, ages, active)
        dead_slots = np.nonzero(dies)[0]

        for slot in dead_slots:
            slot = int(slot)
            citizens.alive[slot] = False
            citizens.death_tick[slot] = tick
            citizens.log(slot, f"died at age {citizens.age_years[slot]:.1f}")
            self._handle_household_consequences(slot, citizens, household_registry, housing_market)
            self.events.publish(EventType.PERSON_DIED, tick, citizen_id=citizens.citizen_id[slot], slot=slot)
        return dead_slots.tolist()

    def _handle_household_consequences(self, slot: int, citizens, household_registry, housing_market) -> None:
        hh_id = int(citizens.household_id[slot])
        hh = household_registry.get(hh_id)
        if not hh:
            return
        hh.remove_member(slot)
        if hh.size == 0:
            if hh.home_id >= 0:
                housing_market.vacate(hh.home_id)
            household_registry.dissolve(hh_id)
