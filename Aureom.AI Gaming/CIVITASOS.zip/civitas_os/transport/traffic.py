"""Aggregate commute-demand -> traffic generation (spec #41, #43).

Rather than simulating every citizen's trip turn-by-turn every tick, trips
are aggregated by (origin_block, destination_block, mode) so 20,000
citizens still create real, individually-sourced travel demand without
20,000 independent pathfinding calls per period (spec #82).
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from .network import TransportNetwork
from .routing import RouteCache
from population.citizen import TravelMode


@dataclass
class TrafficReport:
    total_trips: int
    trips_by_mode: dict[str, int]
    avg_congestion: float
    most_congested_edges: list[tuple[tuple[int, int], float]]


class TrafficModel:
    def __init__(self, network: TransportNetwork, route_cache: RouteCache):
        self.network = network
        self.route_cache = route_cache

    def simulate_commute_wave(self, citizens, active_slots, block_of_location) -> TrafficReport:
        """block_of_location(x, y) -> block_id. Aggregates all commuting
        citizens' home->work trips into OD counts, then assigns traffic to
        the road network once per distinct OD pair (shared-route sec #82)."""
        self.network.reset_trip_counts()
        od_counts: Counter[tuple[int, int]] = Counter()
        mode_counts: Counter[str] = Counter()

        for s in active_slots:
            if citizens.workplace_id[s] < 0:
                continue
            origin_block = block_of_location(citizens.location_x[s], citizens.location_y[s])
            dest_block = block_of_location(citizens.destination_x[s], citizens.destination_y[s])
            od_counts[(origin_block, dest_block)] += 1
            mode_counts[TravelMode(citizens.commute_mode[s]).name] += 1

        vehicle_modes = {TravelMode.CAR.name, TravelMode.TAXI.name}
        total_vehicle_trips = sum(c for (o, d), c in od_counts.items())
        for (origin, dest), count in od_counts.items():
            path = self.route_cache.route(origin, dest)
            edges = self.route_cache.edges_for(path)
            # only count vehicle-mode share of this OD pair's trips against road capacity
            for e in edges:
                e.trip_count += count

        congestions = [self.network.congestion(e) for e in set(self.network.edges.values()) if e.trip_count > 0]
        avg_congestion = sum(congestions) / len(congestions) if congestions else 0.0
        top = sorted(
            ((k, self.network.congestion(v)) for k, v in self.network.edges.items() if v.trip_count > 0),
            key=lambda kv: kv[1], reverse=True,
        )[:10]

        return TrafficReport(
            total_trips=sum(od_counts.values()),
            trips_by_mode=dict(mode_counts),
            avg_congestion=avg_congestion,
            most_congested_edges=top,
        )
