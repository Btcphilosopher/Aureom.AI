"""Routing with OD-pair caching and shared routes (spec #81-#82).

We deliberately do NOT run a fresh shortest-path search per citizen per
tick. Instead:
  - routes are cached by (origin_node, destination_node) since huge numbers
    of citizens share the same home-block/work-block pair
  - the cache is invalidated periodically (not every tick) to let routing
    respond to sustained congestion without recomputing constantly
"""
from __future__ import annotations

from .network import TransportNetwork, RoadEdge, HAS_NETWORKX

if HAS_NETWORKX:
    import networkx as nx


class RouteCache:
    def __init__(self, network: TransportNetwork, max_entries: int = 200_000):
        self.network = network
        self.max_entries = max_entries
        self._cache: dict[tuple[int, int], list[int]] = {}

    def clear(self) -> None:
        self._cache.clear()

    def route(self, origin: int, destination: int) -> list[int]:
        key = (origin, destination)
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        path = self._compute(origin, destination)
        if len(self._cache) < self.max_entries:
            self._cache[key] = path
        return path

    def _compute(self, origin: int, destination: int) -> list[int]:
        if origin == destination:
            return [origin]
        if HAS_NETWORKX:
            try:
                return nx.shortest_path(self.network.graph, origin, destination, weight="weight")
            except Exception:
                return [origin, destination]
        return self._dijkstra(origin, destination)

    def _dijkstra(self, origin: int, destination: int) -> list[int]:
        import heapq
        dist = {origin: 0.0}
        prev: dict[int, int] = {}
        heap = [(0.0, origin)]
        visited = set()
        while heap:
            d, u = heapq.heappop(heap)
            if u in visited:
                continue
            visited.add(u)
            if u == destination:
                break
            for v, edge in self.network.neighbours(u):
                travel_time = edge.length_m / (edge.free_flow_speed_kmh * 1000 / 3600)
                nd = d + travel_time
                if nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(heap, (nd, v))
        if destination not in prev and destination != origin:
            return [origin, destination]
        path = [destination]
        while path[-1] != origin:
            path.append(prev[path[-1]])
        path.reverse()
        return path

    def edges_for(self, path: list[int]) -> list[RoadEdge]:
        edges = []
        for a, b in zip(path, path[1:]):
            edge = self.network.edges.get((a, b))
            if edge:
                edges.append(edge)
        return edges
