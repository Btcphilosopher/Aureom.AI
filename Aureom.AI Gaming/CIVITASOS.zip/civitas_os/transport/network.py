"""Transport network graph: roads, stations, stops as nodes/edges with a
real road hierarchy (spec #39, #66). Backed by networkx when available so
routing.py can use proven shortest-path algorithms; falls back to a small
built-in adjacency graph otherwise so the engine never hard-depends on an
optional package.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

try:
    import networkx as nx
    HAS_NETWORKX = True
except ImportError:  # pragma: no cover
    HAS_NETWORKX = False


class RoadClass(str, Enum):
    HIGHWAY = "HIGHWAY"
    ARTERIAL = "ARTERIAL"
    COLLECTOR = "COLLECTOR"
    LOCAL = "LOCAL"
    LANE = "LANE"


ROAD_PROFILE = {
    RoadClass.HIGHWAY:   {"capacity_veh_hr": 4000, "speed_kmh": 100},
    RoadClass.ARTERIAL:  {"capacity_veh_hr": 1800, "speed_kmh": 60},
    RoadClass.COLLECTOR: {"capacity_veh_hr": 900,  "speed_kmh": 45},
    RoadClass.LOCAL:     {"capacity_veh_hr": 400,  "speed_kmh": 30},
    RoadClass.LANE:      {"capacity_veh_hr": 150,  "speed_kmh": 20},
}


@dataclass(eq=False)
class RoadEdge:
    u: int
    v: int
    road_class: RoadClass
    length_m: float
    trip_count: int = 0

    @property
    def capacity_veh_hr(self) -> int:
        return ROAD_PROFILE[self.road_class]["capacity_veh_hr"]

    @property
    def free_flow_speed_kmh(self) -> float:
        return ROAD_PROFILE[self.road_class]["speed_kmh"]


class TransportNetwork:
    """Graph of intersections/stations connected by roads/rail (spec #69)."""

    def __init__(self):
        self._simple_adj: dict[int, list[tuple[int, RoadEdge]]] = {}
        self.node_location: dict[int, tuple[float, float]] = {}
        self.edges: dict[tuple[int, int], RoadEdge] = {}
        if HAS_NETWORKX:
            self.graph = nx.Graph()

    def add_node(self, node_id: int, location: tuple[float, float]) -> None:
        self.node_location[node_id] = location
        self._simple_adj.setdefault(node_id, [])
        if HAS_NETWORKX:
            self.graph.add_node(node_id, pos=location)

    def add_edge(self, u: int, v: int, road_class: RoadClass, length_m: float) -> RoadEdge:
        edge = RoadEdge(u, v, road_class, length_m)
        self.edges[(u, v)] = edge
        self.edges[(v, u)] = edge
        self._simple_adj.setdefault(u, []).append((v, edge))
        self._simple_adj.setdefault(v, []).append((u, edge))
        if HAS_NETWORKX:
            travel_time_s = length_m / (edge.free_flow_speed_kmh * 1000 / 3600)
            self.graph.add_edge(u, v, weight=travel_time_s, edge=edge)
        return edge

    def neighbours(self, node_id: int):
        return self._simple_adj.get(node_id, [])

    def reset_trip_counts(self) -> None:
        for edge in set(self.edges.values()):
            edge.trip_count = 0

    def record_trip(self, path_edges: list[RoadEdge]) -> None:
        for e in path_edges:
            e.trip_count += 1

    def congestion(self, edge: RoadEdge) -> float:
        """Volume/capacity ratio for the current period (hourly capacity vs
        trips recorded this period) — spec #43."""
        return edge.trip_count / max(edge.capacity_veh_hr, 1)


def build_network_from_grid(grid) -> TransportNetwork:
    """Derive a routable road graph from a CityGrid: one node per block
    centre, arterials linking blocks along the primary rows/columns near the
    centre, local roads/lanes filling the rest — a real (if simplified) road
    hierarchy grown from the procedurally generated layout (spec #65-#66)."""
    net = TransportNetwork()
    n_cols = max(1, round(grid.width_m / grid.block_size_m))
    n_rows = max(1, round(grid.height_m / grid.block_size_m))

    def block_id(col, row):
        return row * n_cols + col

    for block in grid.blocks.values():
        x0, y0, x1, y1 = block.bounds
        centre = ((x0 + x1) / 2, (y0 + y1) / 2)
        net.add_node(block.block_id, centre)

    for row in range(n_rows):
        for col in range(n_cols):
            bid = block_id(col, row)
            if bid not in grid.blocks:
                continue
            for dcol, drow in ((1, 0), (0, 1)):
                ncol, nrow = col + dcol, row + drow
                nbid = block_id(ncol, nrow)
                if ncol >= n_cols or nrow >= n_rows or nbid not in grid.blocks:
                    continue
                cx, cy = n_cols / 2, n_rows / 2
                dist_ratio = (((col - cx) ** 2 + (row - cy) ** 2) ** 0.5) / max(n_cols, n_rows)
                if dist_ratio < 0.15:
                    road_class = RoadClass.ARTERIAL
                elif row == round(cy) or col == round(cx):
                    road_class = RoadClass.COLLECTOR
                else:
                    road_class = RoadClass.LOCAL
                length_m = grid.block_size_m
                net.add_edge(bid, nbid, road_class, length_m)
    return net
