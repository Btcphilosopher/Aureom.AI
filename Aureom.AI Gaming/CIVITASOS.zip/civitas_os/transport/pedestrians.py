"""Walking-mode citizens use the pedestrian network directly; visible
pedestrians at street level are drawn from real Citizen objects, never
random decorative extras (spec #46, #85).
"""
from __future__ import annotations

import numpy as np

from population.citizen import Activity, TravelMode


def pedestrians_near(citizens, active_slots: np.ndarray, centre: tuple[float, float],
                       radius_m: float) -> np.ndarray:
    """Return citizen slots currently walking/travelling within radius_m of
    centre — this is what a street-level renderer should draw, sourced
    straight from simulation state (never a decorative crowd layer unless
    explicitly flagged NON_SIMULATED_VISUAL_CROWD, spec #85)."""
    if len(active_slots) == 0:
        return active_slots
    xs = citizens.location_x[active_slots]
    ys = citizens.location_y[active_slots]
    dist2 = (xs - centre[0]) ** 2 + (ys - centre[1]) ** 2
    walking = (citizens.commute_mode[active_slots] == TravelMode.WALK) | \
              (citizens.current_activity[active_slots] == Activity.TRAVEL)
    mask = walking & (dist2 <= radius_m ** 2)
    return active_slots[mask]
