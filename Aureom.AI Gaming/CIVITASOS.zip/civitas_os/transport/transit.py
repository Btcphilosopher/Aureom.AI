"""Public transport: routes, vehicles, stops/stations, and passenger flow
made up of actual citizens (spec #44), not abstract ridership numbers.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Stop:
    stop_id: int
    location: tuple[float, float]
    name: str = ""


@dataclass
class Vehicle:
    vehicle_id: int
    route_id: int
    capacity: int
    onboard_slots: list[int] = field(default_factory=list)

    @property
    def load_factor(self) -> float:
        return len(self.onboard_slots) / max(self.capacity, 1)


@dataclass
class Route:
    route_id: int
    name: str
    mode: str  # "BUS" | "TRAIN" | "METRO"
    stop_ids: list[int]
    vehicle_ids: list[int] = field(default_factory=list)


class TransitNetwork:
    def __init__(self):
        self._next_stop_id = 0
        self._next_route_id = 0
        self._next_vehicle_id = 0
        self.stops: dict[int, Stop] = {}
        self.routes: dict[int, Route] = {}
        self.vehicles: dict[int, Vehicle] = {}

    def add_stop(self, location: tuple[float, float], name: str = "") -> Stop:
        sid = self._next_stop_id
        self._next_stop_id += 1
        stop = Stop(sid, location, name)
        self.stops[sid] = stop
        return stop

    def add_route(self, name: str, mode: str, stop_ids: list[int],
                   n_vehicles: int, capacity: int) -> Route:
        rid = self._next_route_id
        self._next_route_id += 1
        route = Route(rid, name, mode, stop_ids)
        for _ in range(n_vehicles):
            vid = self._next_vehicle_id
            self._next_vehicle_id += 1
            vehicle = Vehicle(vid, rid, capacity)
            self.vehicles[vid] = vehicle
            route.vehicle_ids.append(vid)
        self.routes[rid] = route
        return route

    def board(self, vehicle_id: int, citizen_slot: int) -> bool:
        vehicle = self.vehicles[vehicle_id]
        if len(vehicle.onboard_slots) >= vehicle.capacity:
            return False
        vehicle.onboard_slots.append(citizen_slot)
        return True

    def alight(self, vehicle_id: int, citizen_slot: int) -> None:
        vehicle = self.vehicles[vehicle_id]
        if citizen_slot in vehicle.onboard_slots:
            vehicle.onboard_slots.remove(citizen_slot)

    def route_ridership(self, route_id: int) -> int:
        route = self.routes[route_id]
        return sum(len(self.vehicles[vid].onboard_slots) for vid in route.vehicle_ids)

    def average_load_factor(self, route_id: int) -> float:
        route = self.routes[route_id]
        if not route.vehicle_ids:
            return 0.0
        return sum(self.vehicles[vid].load_factor for vid in route.vehicle_ids) / len(route.vehicle_ids)
