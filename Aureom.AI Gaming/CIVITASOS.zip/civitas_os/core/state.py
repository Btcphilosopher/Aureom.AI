"""CityState (spec #76): the canonical, serialisable state of one city.

Holds references to every subsystem's state so the whole simulation can be
saved/loaded as a unit (spec #107: citizens, households, buildings, jobs,
economy, transport, relationships, events, random state — not just
aggregate statistics).
"""
from __future__ import annotations

import pickle
from dataclasses import dataclass, field
from pathlib import Path

from core.clock import SimulationClock
from core.config import CityConfig
from core.events import EventBus
from core.random import CityRandom


@dataclass
class CityState:
    city_id: str
    name: str
    config: CityConfig
    random: CityRandom
    clock: SimulationClock = field(default_factory=SimulationClock)
    events: EventBus = field(default_factory=EventBus)

    # subsystem state — populated by SimulationEngine.setup()
    citizens: object = None
    households: object = None
    housing_market: object = None
    buildings: object = None
    grid: object = None
    zoning_map: dict = field(default_factory=dict)
    neighbourhoods: object = None
    transport_network: object = None
    route_cache: object = None
    transit: object = None
    economy: object = None
    construction: object = None
    weather: object = None
    statistics_history: list = field(default_factory=list)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls, path: str | Path) -> "CityState":
        with open(path, "rb") as f:
            return pickle.load(f)
