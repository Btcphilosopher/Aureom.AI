"""Data-driven configuration.

All tunable numbers (age/income/household distributions, building types,
planning rules, economic parameters, transport speeds) live in YAML under
civitas_os/config/ and load into typed dataclasses here. Nothing about
population size, distributions, or building catalogues is hard-coded in
simulation logic.
"""
from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


def _load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    text = path.read_text()
    if yaml is not None:
        return yaml.safe_load(text) or {}
    # Minimal fallback JSON-compatible YAML subset if PyYAML isn't installed.
    return json.loads(text)


@dataclass
class CityConfig:
    """Root configuration object for a single city instance."""

    name: str = "Unnamed City"
    seed: int = 42
    target_population: int = 20_000

    population: dict = field(default_factory=dict)
    households: dict = field(default_factory=dict)
    economy: dict = field(default_factory=dict)
    buildings: dict = field(default_factory=dict)
    transport: dict = field(default_factory=dict)
    planning: dict = field(default_factory=dict)

    @classmethod
    def load(cls, overrides: dict | None = None) -> "CityConfig":
        cfg = cls(
            population=_load_yaml(CONFIG_DIR / "population_distributions.yaml"),
            households=_load_yaml(CONFIG_DIR / "household_distributions.yaml"),
            economy=_load_yaml(CONFIG_DIR / "economic_parameters.yaml"),
            buildings=_load_yaml(CONFIG_DIR / "buildings.yaml"),
            transport=_load_yaml(CONFIG_DIR / "transport.yaml"),
            planning=_load_yaml(CONFIG_DIR / "planning_rules.yaml"),
        )
        if overrides:
            cfg = cfg.merged(overrides)
        return cfg

    def merged(self, overrides: dict) -> "CityConfig":
        new = copy.deepcopy(self)
        for key, value in overrides.items():
            if hasattr(new, key):
                setattr(new, key, value)
        return new

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "seed": self.seed,
            "target_population": self.target_population,
            "population": self.population,
            "households": self.households,
            "economy": self.economy,
            "buildings": self.buildings,
            "transport": self.transport,
            "planning": self.planning,
        }
