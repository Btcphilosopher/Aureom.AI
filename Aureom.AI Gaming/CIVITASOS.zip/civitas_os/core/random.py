"""Deterministic randomness for CIVITAS.OS.

Every city carries a single root seed. All subsystems draw from named,
derived sub-streams (via numpy SeedSequence.spawn) so that:
  - the same (seed, config, player actions) always reproduces the same city
  - subsystems don't perturb each other's draw sequences by drawing in a
    different order from run to run
"""
from __future__ import annotations

import numpy as np


class CityRandom:
    """Holds the master seed and hands out named, reproducible RNG streams."""

    def __init__(self, seed: int):
        self.seed = int(seed)
        self._root = np.random.SeedSequence(self.seed)
        self._streams: dict[str, np.random.Generator] = {}
        self._child_counter = 0

    def stream(self, name: str) -> np.random.Generator:
        """Return (creating if needed) a named, deterministic RNG stream.

        Streams are derived by hashing the name into a stable index so the
        same name always yields the same child SeedSequence regardless of
        call order.
        """
        if name not in self._streams:
            idx = self._stable_index(name)
            child = self._root.spawn(idx + 1)[idx]
            self._streams[name] = np.random.default_rng(child)
        return self._streams[name]

    @staticmethod
    def _stable_index(name: str) -> int:
        # Stable (non-salted) hash -> small non-negative int used purely to
        # pick a deterministic position in the spawn tree.
        h = 0
        for ch in name:
            h = (h * 131 + ord(ch)) % 1_000_003
        return h % 4096

    def __repr__(self) -> str:
        return f"CityRandom(seed={self.seed})"
