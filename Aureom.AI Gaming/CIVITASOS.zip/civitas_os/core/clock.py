"""Fixed-timestep simulation clock.

Ticks are the base unit. Everything else (minute/hour/day/week/month/year)
is derived arithmetic on top of the tick counter, so the whole engine can
run deterministically regardless of wall-clock/render frame rate.
"""
from __future__ import annotations

from dataclasses import dataclass, field

TICKS_PER_HOUR = 4          # 15 simulated minutes per tick (tune for fidelity vs. speed)
HOURS_PER_DAY = 24
DAYS_PER_WEEK = 7
DAYS_PER_MONTH = 30
DAYS_PER_YEAR = 365

TICKS_PER_DAY = TICKS_PER_HOUR * HOURS_PER_DAY
TICKS_PER_WEEK = TICKS_PER_DAY * DAYS_PER_WEEK
TICKS_PER_MONTH = TICKS_PER_DAY * DAYS_PER_MONTH
TICKS_PER_YEAR = TICKS_PER_DAY * DAYS_PER_YEAR


@dataclass
class SimulationClock:
    tick: int = 0
    speed_multiplier: float = 1.0  # 1x, 2x, 5x, 10x, 50x, 100x, 1000x etc.
    _day_boundary_hooks: list = field(default_factory=list, repr=False)

    def advance(self, n_ticks: int = 1) -> None:
        self.tick += n_ticks

    # --- derived time ---------------------------------------------------
    @property
    def hour_of_day(self) -> int:
        return (self.tick // TICKS_PER_HOUR) % HOURS_PER_DAY

    @property
    def minute_of_hour(self) -> int:
        ticks_into_hour = self.tick % TICKS_PER_HOUR
        return int(ticks_into_hour * (60 // TICKS_PER_HOUR))

    @property
    def day(self) -> int:
        return self.tick // TICKS_PER_DAY

    @property
    def day_of_week(self) -> int:
        return self.day % DAYS_PER_WEEK

    @property
    def is_weekend(self) -> bool:
        return self.day_of_week >= 5

    @property
    def week(self) -> int:
        return self.tick // TICKS_PER_WEEK

    @property
    def month(self) -> int:
        return self.tick // TICKS_PER_MONTH

    @property
    def year(self) -> int:
        return self.tick // TICKS_PER_YEAR

    @property
    def is_new_day(self) -> bool:
        return self.tick % TICKS_PER_DAY == 0

    @property
    def is_new_month(self) -> bool:
        return self.tick % TICKS_PER_MONTH == 0

    @property
    def is_new_year(self) -> bool:
        return self.tick % TICKS_PER_YEAR == 0

    def __str__(self) -> str:
        return (f"Y{self.year} D{self.day % DAYS_PER_YEAR} "
                f"{self.hour_of_day:02d}:{self.minute_of_hour:02d}")
