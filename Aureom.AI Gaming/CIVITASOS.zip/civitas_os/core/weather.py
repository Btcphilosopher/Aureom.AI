"""Simple deterministic weather system (spec #55): seasonal temperature
curve plus stochastic rain/wind, affecting energy, transport, and leisure.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class WeatherState:
    temperature_c: float
    rain_mm: float
    snow: bool
    wind_kmh: float
    sunlight_hours: float


class WeatherSystem:
    def __init__(self, rng, base_temp_c: float = 11.0, amplitude_c: float = 9.0):
        self.rng = rng
        self.base_temp_c = base_temp_c
        self.amplitude_c = amplitude_c

    def sample(self, day_of_year: int) -> WeatherState:
        seasonal = self.base_temp_c + self.amplitude_c * math.sin(2 * math.pi * (day_of_year - 100) / 365)
        temp = seasonal + float(self.rng.normal(0, 2.5))
        rain = max(0.0, float(self.rng.normal(2.0 if temp < 15 else 1.0, 2.0)))
        snow = temp < 1.0 and rain > 0.5
        wind = max(0.0, float(self.rng.normal(14, 6)))
        sunlight = max(0.0, 12 + 4 * math.sin(2 * math.pi * (day_of_year - 80) / 365) - rain * 0.3)
        return WeatherState(temp, rain, snow, wind, sunlight)
