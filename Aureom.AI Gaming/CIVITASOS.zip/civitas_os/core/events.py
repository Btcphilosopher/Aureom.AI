"""Simulation-wide event bus so subsystems stay decoupled.

Buildings, population, economy, transport, etc. publish typed events;
anything (analytics, the UrbanAdvisorAI, a renderer, tests) can subscribe
without the publisher knowing or caring who's listening.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable


class EventType(Enum):
    BUILDING_COMPLETED = auto()
    BUILDING_DEMOLISHED = auto()
    HOUSEHOLD_FORMED = auto()
    HOUSEHOLD_MOVED = auto()
    HOUSEHOLD_DISSOLVED = auto()
    PERSON_BORN = auto()
    PERSON_DIED = auto()
    JOB_CREATED = auto()
    JOB_LOST = auto()
    JOB_FILLED = auto()
    BUSINESS_OPENED = auto()
    BUSINESS_CLOSED = auto()
    ROAD_OPENED = auto()
    TRANSIT_OPENED = auto()
    SCHOOL_OPENED = auto()
    HOSPITAL_OPENED = auto()
    MIGRATION_IN = auto()
    MIGRATION_OUT = auto()
    HOMELESSNESS_ENTERED = auto()
    HOMELESSNESS_EXITED = auto()


@dataclass
class Event:
    type: EventType
    tick: int
    payload: dict = field(default_factory=dict)


class EventBus:
    def __init__(self, history_limit: int = 50_000):
        self._subscribers: dict[EventType, list[Callable[[Event], None]]] = defaultdict(list)
        self._history: deque[Event] = deque(maxlen=history_limit)

    def subscribe(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        self._subscribers[event_type].append(callback)

    def publish(self, event_type: EventType, tick: int, **payload: Any) -> None:
        evt = Event(type=event_type, tick=tick, payload=payload)
        self._history.append(evt)
        for cb in self._subscribers.get(event_type, ()):
            cb(evt)

    def history(self, event_type: EventType | None = None, limit: int | None = None) -> list[Event]:
        items = list(self._history)
        if event_type is not None:
            items = [e for e in items if e.type == event_type]
        if limit is not None:
            items = items[-limit:]
        return items
