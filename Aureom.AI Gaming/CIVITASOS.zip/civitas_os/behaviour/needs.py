"""Needs system (spec #26): vectorised decay/replenishment of citizen
needs, which feed the utility model's option scoring."""
from __future__ import annotations

import numpy as np

from population.citizen import Activity

# Per-hour decay rate for each need when not being addressed.
DECAY_RATE = {
    "need_food": 0.12,
    "need_sleep": 0.09,
    "need_social": 0.03,
    "need_health": 0.01,
    "need_leisure": 0.05,
}

# Activities that relieve a given need, and how fast.
RELIEF = {
    Activity.EAT: {"need_food": 0.9},
    Activity.SLEEP: {"need_sleep": 0.85},
    Activity.SOCIALISE: {"need_social": 0.6},
    Activity.ENTERTAINMENT: {"need_leisure": 0.7, "need_social": 0.2},
    Activity.EXERCISE: {"need_leisure": 0.3, "need_health": 0.1},
    Activity.HEALTHCARE: {"need_health": 0.8},
    Activity.SHOP: {"need_food": 0.2, "need_leisure": 0.1},
}


def decay_needs(citizens, active_idx: np.ndarray, dt_hours: float = 1.0) -> None:
    for attr, rate in DECAY_RATE.items():
        arr = getattr(citizens, attr)
        arr[active_idx] = np.clip(arr[active_idx] + rate * dt_hours, 0.0, 1.0)


def apply_relief(citizens, active_idx: np.ndarray) -> None:
    activities = citizens.current_activity[active_idx]
    for activity, relief_map in RELIEF.items():
        mask = activities == activity
        if not mask.any():
            continue
        idx = active_idx[mask]
        for attr, amount in relief_map.items():
            arr = getattr(citizens, attr)
            arr[idx] = np.clip(arr[idx] - amount, 0.0, 1.0)


def most_urgent_need(citizens, slot: int) -> str:
    needs = {attr: float(getattr(citizens, attr)[slot]) for attr in DECAY_RATE}
    return max(needs, key=needs.get)
