"""Decision engine for non-routine choices (spec #28): job search, moving
house, etc. — OBSERVE -> IDENTIFY NEED -> GENERATE OPTIONS -> EVALUATE ->
CHOOSE -> TRAVEL -> ACT -> UPDATE STATE.

Routine minute-to-minute activity comes from behaviour/schedules.py
(cheap, vectorised); this module is for the comparatively rare, higher-
stakes decisions where the full utility-model deliberation is worth the
extra cost.
"""
from __future__ import annotations

from dataclasses import dataclass

from .needs import most_urgent_need
from .utility import CitizenUtilityModel, Option


@dataclass
class DecisionResult:
    decision: str
    chosen: Option | None
    reason: str


def consider_job_search(citizens, slot: int, labour_market, utility_model: CitizenUtilityModel) -> DecisionResult:
    """OBSERVE current employment -> IDENTIFY need (income) -> GENERATE
    candidate jobs -> EVALUATE -> CHOOSE."""
    from population.citizen import EmploymentState
    if citizens.employment_state[slot] != EmploymentState.UNEMPLOYED:
        return DecisionResult("job_search", None, "not seeking")

    home = (float(citizens.location_x[slot]), float(citizens.location_y[slot]))
    job = labour_market.best_match(int(citizens.education_level[slot]), home)
    if job is None:
        return DecisionResult("job_search", None, "no suitable vacancy")

    option = Option(label=f"job:{job.job_id}", cost=0.0, distance_m=((job.location[0]-home[0])**2 + (job.location[1]-home[1])**2) ** 0.5,
                     time_min=15, quality=min(job.salary / 60000, 1.0))
    urgency = 0.7  # unemployed -> high urgency for income
    chosen = utility_model.choose([option], urgency)
    return DecisionResult("job_search", chosen, "accepted best available match")


def consider_moving(citizens, household, housing_market, utility_model: CitizenUtilityModel) -> DecisionResult:
    """A household evaluates whether to search for a new home based on
    overcrowding/affordability stress (needs feed the urgency term)."""
    total_income = sum(citizens.income[s] for s in household.member_slots)
    candidate = housing_market.find_home(total_income, household.size)
    if candidate is None:
        return DecisionResult("move", None, "no vacancy available")
    option = Option(label=f"unit:{candidate.unit_id}", cost=candidate.rent, quality=candidate.quality)
    urgency = 0.5
    chosen = utility_model.choose([option], urgency)
    return DecisionResult("move", chosen, "found acceptable unit")
