"""Daily routine generation (spec #24-#25), vectorised.

Rather than scripting one fixed routine, each citizen gets a 24-hour
activity-code array generated from templates keyed by employment_state,
with per-citizen jitter (wake time, lunch timing, evening leisure) so
20,000 citizens do not all move in lockstep.
"""
from __future__ import annotations

import numpy as np

from population.citizen import Activity, EmploymentState

# Base hourly template per employment state: list of 24 Activity values.
_H = Activity  # alias for compact tables


def _template(pattern: dict[int, Activity], default: Activity = Activity.HOME) -> list:
    hours = [default] * 24
    for hour, act in pattern.items():
        hours[hour] = act
    return hours


TEMPLATES = {
    EmploymentState.EMPLOYED: _template({
        0: _H.SLEEP, 1: _H.SLEEP, 2: _H.SLEEP, 3: _H.SLEEP, 4: _H.SLEEP, 5: _H.SLEEP,
        6: _H.EAT, 7: _H.TRAVEL, 8: _H.WORK, 9: _H.WORK, 10: _H.WORK, 11: _H.WORK,
        12: _H.EAT, 13: _H.WORK, 14: _H.WORK, 15: _H.WORK, 16: _H.WORK, 17: _H.TRAVEL,
        18: _H.SHOP, 19: _H.EAT, 20: _H.SOCIALISE, 21: _H.ENTERTAINMENT,
        22: _H.SLEEP, 23: _H.SLEEP,
    }),
    EmploymentState.UNEMPLOYED: _template({
        0: _H.SLEEP, 1: _H.SLEEP, 2: _H.SLEEP, 3: _H.SLEEP, 4: _H.SLEEP, 5: _H.SLEEP,
        6: _H.EAT, 7: _H.HOME, 8: _H.HOME, 9: _H.SHOP, 10: _H.HOME, 11: _H.SOCIALISE,
        12: _H.EAT, 13: _H.HOME, 14: _H.EXERCISE, 15: _H.HOME, 16: _H.HOME,
        17: _H.SHOP, 18: _H.EAT, 19: _H.SOCIALISE, 20: _H.ENTERTAINMENT,
        21: _H.HOME, 22: _H.SLEEP, 23: _H.SLEEP,
    }),
    EmploymentState.STUDENT: _template({
        0: _H.SLEEP, 1: _H.SLEEP, 2: _H.SLEEP, 3: _H.SLEEP, 4: _H.SLEEP, 5: _H.SLEEP,
        6: _H.EAT, 7: _H.TRAVEL, 8: _H.STUDY, 9: _H.STUDY, 10: _H.STUDY, 11: _H.STUDY,
        12: _H.EAT, 13: _H.STUDY, 14: _H.STUDY, 15: _H.STUDY, 16: _H.TRAVEL,
        17: _H.EXERCISE, 18: _H.EAT, 19: _H.SOCIALISE, 20: _H.ENTERTAINMENT,
        21: _H.HOME, 22: _H.SLEEP, 23: _H.SLEEP,
    }),
    EmploymentState.RETIRED: _template({
        0: _H.SLEEP, 1: _H.SLEEP, 2: _H.SLEEP, 3: _H.SLEEP, 4: _H.SLEEP, 5: _H.SLEEP,
        6: _H.EAT, 7: _H.HOME, 8: _H.EXERCISE, 9: _H.SHOP, 10: _H.SOCIALISE,
        11: _H.HOME, 12: _H.EAT, 13: _H.HOME, 14: _H.HEALTHCARE, 15: _H.SOCIALISE,
        16: _H.HOME, 17: _H.HOME, 18: _H.EAT, 19: _H.ENTERTAINMENT,
        20: _H.HOME, 21: _H.HOME, 22: _H.SLEEP, 23: _H.SLEEP,
    }),
    EmploymentState.CHILD: _template({
        0: _H.SLEEP, 1: _H.SLEEP, 2: _H.SLEEP, 3: _H.SLEEP, 4: _H.SLEEP, 5: _H.SLEEP,
        6: _H.EAT, 7: _H.TRAVEL, 8: _H.STUDY, 9: _H.STUDY, 10: _H.STUDY, 11: _H.STUDY,
        12: _H.EAT, 13: _H.STUDY, 14: _H.STUDY, 15: _H.TRAVEL, 16: _H.EXERCISE,
        17: _H.CHILDCARE, 18: _H.EAT, 19: _H.ENTERTAINMENT, 20: _H.HOME,
        21: _H.SLEEP, 22: _H.SLEEP, 23: _H.SLEEP,
    }),
    EmploymentState.CARE_GIVER: _template({
        0: _H.SLEEP, 1: _H.SLEEP, 2: _H.SLEEP, 3: _H.SLEEP, 4: _H.SLEEP, 5: _H.SLEEP,
        6: _H.EAT, 7: _H.CHILDCARE, 8: _H.CHILDCARE, 9: _H.SHOP, 10: _H.HOME,
        11: _H.CHILDCARE, 12: _H.EAT, 13: _H.HOME, 14: _H.CHILDCARE, 15: _H.CHILDCARE,
        16: _H.HOME, 17: _H.CHILDCARE, 18: _H.EAT, 19: _H.HOME, 20: _H.SOCIALISE,
        21: _H.HOME, 22: _H.SLEEP, 23: _H.SLEEP,
    }),
}

_TEMPLATE_MATRIX = np.array(
    [[int(a) for a in TEMPLATES[state]] for state in EmploymentState],
    dtype=np.int8,
)  # shape (n_states, 24), row index == EmploymentState value


def build_daily_activity_matrix(employment_state: np.ndarray, is_weekend: np.ndarray) -> np.ndarray:
    """Vectorised: returns shape (n, 24) int8 activity codes for every
    citizen in one call. Weekend citizens who would otherwise be at
    WORK/STUDY get HOME/leisure substituted instead."""
    base = _TEMPLATE_MATRIX[employment_state]  # (n, 24) via fancy indexing
    weekend_rows = is_weekend
    if weekend_rows.any():
        working_hours_mask = (base == int(Activity.WORK)) | (base == int(Activity.STUDY))
        replacement = np.where(np.arange(24) < 12, int(Activity.HOME), int(Activity.ENTERTAINMENT))
        swap_mask = weekend_rows[:, None] & working_hours_mask
        base = np.where(swap_mask, replacement[None, :], base)
    return base


def jitter_wake_hour(rng, n: int, spread: int = 1) -> np.ndarray:
    """Per-citizen offset (in hours) applied when reading the schedule, so
    not everyone transitions activities at exactly the same minute."""
    return rng.integers(-spread, spread + 1, size=n)
