"""CitizenUtilityModel (spec #27): citizens evaluate options on cost,
distance, time, quality, preference, urgency and habit — with randomness
and inertia so 20,000 citizens don't all behave like identical rational
agents.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Option:
    label: str
    cost: float = 0.0
    distance_m: float = 0.0
    time_min: float = 0.0
    quality: float = 0.5      # 0..1
    habitual: bool = False


class CitizenUtilityModel:
    def __init__(self, rng, rationality: float = 0.75, inertia: float = 0.2):
        """rationality in (0,1]: 1 = always pick best-scoring option;
        lower values inject more noise (spec: 'do not make every citizen
        perfectly rational'). inertia: bonus toward the habitual option."""
        self.rng = rng
        self.rationality = rationality
        self.inertia = inertia

    def score(self, option: Option, urgency: float, preference_weight: float = 1.0) -> float:
        cost_term = -0.0008 * option.cost
        distance_term = -0.0015 * option.distance_m
        time_term = -0.02 * option.time_min
        quality_term = 1.5 * option.quality * preference_weight
        urgency_term = 2.0 * urgency
        habit_term = self.inertia if option.habitual else 0.0
        noise = self.rng.normal(0, 1.0 - self.rationality + 0.05)
        return cost_term + distance_term + time_term + quality_term + urgency_term + habit_term + noise

    def choose(self, options: list[Option], urgency: float, preference_weight: float = 1.0) -> Option:
        if not options:
            raise ValueError("no options to choose from")
        scored = [(self.score(o, urgency, preference_weight), o) for o in options]
        scored.sort(key=lambda t: t[0], reverse=True)
        return scored[0][1]
