'use client';

import React from 'react';
import { DeliveryOutcome, MatchState, TimingCategory } from '@/lib/cricket/types';

interface ScoreboardHUDProps {
  match: MatchState;
  lastOutcome: DeliveryOutcome | null;
  timingNotice: { category: TimingCategory; speedMph: number; text: string } | null;
}

export const ScoreboardHUD: React.FC<ScoreboardHUDProps> = ({
  match,
  lastOutcome,
  timingNotice,
}) => {
  const currentInnings = match.inningsList[match.currentInningsIndex];
  const battingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.homeCounty : match.awayCounty;
  const bowlingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.awayCounty : match.homeCounty;

  const striker = battingTeam.squad[currentInnings.currentStrikerIndex];
  const nonStriker = battingTeam.squad[currentInnings.currentNonStrikerIndex];
  const bowler = bowlingTeam.squad[currentInnings.currentBowlerIndex];

  const strikerScore = currentInnings.batterScores[currentInnings.currentStrikerIndex];
  const nonStrikerScore = currentInnings.batterScores[currentInnings.currentNonStrikerIndex];
  const bowlerFigure = currentInnings.bowlerFigures[currentInnings.currentBowlerIndex];

  // Current Run Rate (CRR)
  const totalOversDec = currentInnings.overs + currentInnings.ballsThisOver / 6;
  const crr = totalOversDec > 0 ? (currentInnings.totalRuns / totalOversDec).toFixed(2) : '0.00';

  // Required Run Rate (RRR)
  let rrr = '-';
  if (match.targetRuns !== null && match.maxOversPerInnings > 0) {
    const ballsRemaining = Math.max(0, match.maxOversPerInnings * 6 - (currentInnings.overs * 6 + currentInnings.ballsThisOver));
    const runsNeeded = Math.max(0, match.targetRuns - currentInnings.totalRuns);
    rrr = ballsRemaining > 0 ? ((runsNeeded / ballsRemaining) * 6).toFixed(2) : '0.00';
  }

  // Recent balls in the over
  const recentDeliveries = currentInnings.history.slice(-6);

  return (
    <div className="w-full pointer-events-none select-none flex flex-col gap-2">
      {/* Top Banner: Television Broadcast Match Bar */}
      <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white px-4 py-2.5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        {/* Teams & Current Score */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span
              className="w-3.5 h-3.5 rounded-full inline-block shadow-sm"
              style={{ backgroundColor: battingTeam.primaryColor }}
            />
            <span className="font-black tracking-wider text-base uppercase text-slate-100">
              {battingTeam.code}
            </span>
          </div>

          <div className="flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-black text-amber-400">
              {currentInnings.totalRuns}
            </span>
            <span className="text-slate-400 text-lg">/</span>
            <span className="text-2xl font-black text-slate-100">
              {currentInnings.wickets}
            </span>
          </div>

          <div className="text-xs font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
            {currentInnings.overs}.{currentInnings.ballsThisOver}{' '}
            {match.maxOversPerInnings > 0 ? `(${match.maxOversPerInnings} ov)` : 'ov'}
          </div>

          {match.targetRuns !== null && (
            <div className="text-xs bg-amber-950/70 border border-amber-500/30 text-amber-300 font-semibold px-2 py-0.5 rounded">
              Target: {match.targetRuns} (Need {Math.max(0, match.targetRuns - currentInnings.totalRuns)})
            </div>
          )}
        </div>

        {/* Batters On Crease */}
        <div className="hidden md:flex items-center gap-6 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-bold">★</span>
            <span className="font-semibold text-slate-200">{striker?.name || 'Striker'}</span>
            <span className="font-bold text-amber-300">
              {strikerScore?.runs || 0}
            </span>
            <span className="text-slate-500 text-[11px]">({strikerScore?.balls || 0})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-semibold">{nonStriker?.name || 'Non-Striker'}</span>
            <span className="font-medium text-slate-300">
              {nonStrikerScore?.runs || 0}
            </span>
            <span className="text-slate-500 text-[11px]">({nonStrikerScore?.balls || 0})</span>
          </div>
        </div>

        {/* Bowler Figures */}
        <div className="hidden lg:flex items-center gap-3 text-xs font-mono">
          <span className="text-slate-400">Bowler:</span>
          <span className="font-semibold text-slate-200">{bowler?.name || 'Bowler'}</span>
          <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold">
            {bowlerFigure?.wickets || 0} - {bowlerFigure?.runsConceded || 0}
          </span>
          <span className="text-slate-500 text-[11px]">({bowlerFigure?.oversBowled || 0} ov)</span>
        </div>

        {/* Rates & Venue */}
        <div className="flex items-center gap-3 text-xs">
          <div className="text-slate-400">
            CRR <span className="text-slate-200 font-bold font-mono">{crr}</span>
          </div>
          {match.targetRuns !== null && (
            <div className="text-slate-400">
              RRR <span className="text-amber-400 font-bold font-mono">{rrr}</span>
            </div>
          )}
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="text-slate-400 hidden sm:inline">{match.venue}</span>
        </div>
      </div>

      {/* Over Ball Tracker & Timing Toast */}
      <div className="px-4 flex items-center justify-between gap-3">
        {/* Ball-by-ball pills */}
        <div className="flex items-center gap-1.5 bg-slate-900/80 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-slate-800/80 shadow-md">
          <span className="text-[11px] font-semibold uppercase text-slate-400 mr-1">Over:</span>
          {recentDeliveries.length === 0 ? (
            <span className="text-[11px] text-slate-500 italic">Start of over</span>
          ) : (
            recentDeliveries.map((item, idx) => {
              const out = item.outcome;
              const isW = out.isWicket;
              const is4 = out.runs === 4;
              const is6 = out.runs === 6;

              return (
                <span
                  key={idx}
                  className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                    isW
                      ? 'bg-rose-600 text-white'
                      : is6
                      ? 'bg-purple-600 text-white'
                      : is4
                      ? 'bg-blue-600 text-white'
                      : out.runs === 0
                      ? 'bg-slate-800 text-slate-400'
                      : 'bg-emerald-700 text-white'
                  }`}
                >
                  {isW ? 'W' : out.runs}
                </span>
              );
            })
          )}
        </div>

        {/* Timing Feedback Banner */}
        {timingNotice && (
          <div className="bg-slate-900/90 border border-amber-500/40 px-3 py-1 rounded-lg shadow-lg flex items-center gap-2 animate-bounce">
            <span
              className={`text-xs font-extrabold uppercase ${
                timingNotice.category === 'PERFECT'
                  ? 'text-emerald-400'
                  : timingNotice.category === 'GOOD'
                  ? 'text-cyan-400'
                  : 'text-amber-400'
              }`}
            >
              {timingNotice.category} TIMING
            </span>
            <span className="text-[11px] text-slate-300 font-mono">
              ({timingNotice.speedMph} mph)
            </span>
          </div>
        )}

        {/* Match Result Overlay if complete */}
        {match.isMatchComplete && (
          <div className="bg-emerald-900/90 border border-emerald-400 text-emerald-200 px-4 py-1.5 rounded-lg shadow-xl font-bold text-sm">
            🏆 {match.resultMessage}
          </div>
        )}
      </div>
    </div>
  );
};
