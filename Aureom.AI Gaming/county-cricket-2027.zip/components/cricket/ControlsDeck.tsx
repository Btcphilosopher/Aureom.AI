'use client';

import React, { useState } from 'react';
import {
  BowlingLengthZone,
  DeliveryOutcome,
  DeliveryVariation,
  MatchState,
  ShotType,
} from '@/lib/cricket/types';
import { FieldPreset } from '@/lib/cricket/engine/fielding';
import { inputManager } from '@/lib/cricket/input/controls';

interface ControlsDeckProps {
  match: MatchState;
  selectedShot: ShotType;
  onSelectShot: (shot: ShotType) => void;
  isLofted: boolean;
  onToggleLofted: (lofted: boolean) => void;
  fieldPreset: FieldPreset;
  onSelectFieldPreset: (preset: FieldPreset) => void;
  lastOutcome: DeliveryOutcome | null;
  onAppeal: () => void;
}

export const ControlsDeck: React.FC<ControlsDeckProps> = ({
  match,
  selectedShot,
  onSelectShot,
  isLofted,
  onToggleLofted,
  fieldPreset,
  onSelectFieldPreset,
  lastOutcome,
  onAppeal,
}) => {
  const [activeTab, setActiveTab] = useState<'BATTING' | 'BOWLING' | 'FIELDING' | 'STATS' | 'SCORECARD'>('BATTING');

  const currentInnings = match.inningsList[match.currentInningsIndex];
  const battingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.homeCounty : match.awayCounty;
  const bowlingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.awayCounty : match.homeCounty;

  const shotsList: { id: ShotType; name: string; tag: string }[] = [
    { id: 'STRAIGHT_DRIVE', name: 'Straight Drive', tag: 'V' },
    { id: 'COVER_DRIVE', name: 'Cover Drive', tag: 'Off' },
    { id: 'ON_DRIVE', name: 'On Drive', tag: 'Leg' },
    { id: 'SQUARE_CUT', name: 'Square Cut', tag: 'Off' },
    { id: 'PULL_SHOT', name: 'Pull Shot', tag: 'Leg' },
    { id: 'HOOK_SHOT', name: 'Hook Shot', tag: 'Leg' },
    { id: 'LEG_GLANCE', name: 'Leg Glance', tag: 'Leg' },
    { id: 'SWEEP', name: 'Sweep Shot', tag: 'Spin' },
    { id: 'RAMP_SCOOP', name: 'Ramp / Scoop', tag: 'T20' },
    { id: 'FORWARD_DEFENCE', name: 'Forward Defence', tag: 'Def' },
    { id: 'BACK_FOOT_DEFENCE', name: 'Back Foot Defence', tag: 'Def' },
    { id: 'LEAVE', name: 'Leave Alone', tag: 'Patience' },
  ];

  return (
    <div className="w-full bg-slate-900 border-t border-slate-800 text-slate-200 shadow-2xl flex flex-col select-none">
      {/* Tab Navigation */}
      <div className="flex border-b border-slate-800 px-4 bg-slate-950/60 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveTab('BATTING')}
          className={`py-3 px-4 border-b-2 transition whitespace-nowrap ${
            activeTab === 'BATTING'
              ? 'border-amber-500 text-amber-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          🏏 Batting Tactics
        </button>
        <button
          onClick={() => setActiveTab('BOWLING')}
          className={`py-3 px-4 border-b-2 transition whitespace-nowrap ${
            activeTab === 'BOWLING'
              ? 'border-amber-500 text-amber-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          🎯 Bowling Controls
        </button>
        <button
          onClick={() => setActiveTab('FIELDING')}
          className={`py-3 px-4 border-b-2 transition whitespace-nowrap ${
            activeTab === 'FIELDING'
              ? 'border-amber-500 text-amber-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          🛡️ Field Setting
        </button>
        <button
          onClick={() => setActiveTab('STATS')}
          className={`py-3 px-4 border-b-2 transition whitespace-nowrap ${
            activeTab === 'STATS'
              ? 'border-amber-500 text-amber-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          📊 Hawk-Eye & Wagon Wheel
        </button>
        <button
          onClick={() => setActiveTab('SCORECARD')}
          className={`py-3 px-4 border-b-2 transition whitespace-nowrap ${
            activeTab === 'SCORECARD'
              ? 'border-amber-500 text-amber-400 bg-slate-900'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          📋 Match Scorecard
        </button>
      </div>

      {/* Tab Panels */}
      <div className="p-4">
        {/* 1. BATTING TAB */}
        {activeTab === 'BATTING' && (
          <div className="flex flex-col md:flex-row gap-6">
            {/* Shot Grid */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Select Shot Type:
                </span>
                <label className="flex items-center gap-2 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={isLofted}
                    onChange={(e) => onToggleLofted(e.target.checked)}
                    className="rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                  />
                  <span className={isLofted ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                    Lofted / Aerial Intent
                  </span>
                </label>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                {shotsList.map((shot) => (
                  <button
                    key={shot.id}
                    onClick={() => onSelectShot(shot.id)}
                    className={`p-2 rounded-lg text-left border text-xs font-medium transition flex items-center justify-between ${
                      selectedShot === shot.id
                        ? 'bg-amber-500/20 border-amber-500 text-amber-200 shadow-md'
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{shot.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 font-mono">
                      {shot.tag}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Controls Cheat Sheet */}
            <div className="w-full md:w-64 bg-slate-950/60 rounded-xl p-3.5 border border-slate-800 text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider text-[11px] block mb-2">
                🎮 Keyboard & Gamepad Guide
              </span>
              <div className="space-y-1.5 text-slate-400 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-amber-400">A / D (Left/Right)</span>
                  <span>Aim Off / Leg</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-400">W / S (Up/Down)</span>
                  <span>Front / Back Foot</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-400">J or [1]</span>
                  <span>Ground Shot</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-400">K or [2]</span>
                  <span>Lofted Shot</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-400">L or [3]</span>
                  <span>Defensive Block</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-400">Spacebar</span>
                  <span>Run Between Wickets</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-400">H</span>
                  <span>Appeal &quot;HOWZZAT!&quot;</span>
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800 flex justify-end">
                <button
                  onClick={onAppeal}
                  className="w-full py-1.5 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-lg text-xs transition"
                >
                  📢 Appeal to Umpire!
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 2. BOWLING TAB */}
        {activeTab === 'BOWLING' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Bowling Length Selector */}
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Target Length
              </span>
              <div className="space-y-1.5">
                {(['YORKER', 'FULL_LENGTH', 'GOOD_LENGTH', 'SHORT_OF_LENGTH', 'BOUNCER'] as BowlingLengthZone[]).map((len) => (
                  <button
                    key={len}
                    onClick={() => {
                      const z = len === 'YORKER' ? 1.6 : len === 'FULL_LENGTH' ? 4.5 : len === 'GOOD_LENGTH' ? 6.5 : len === 'SHORT_OF_LENGTH' ? 8.5 : 12.0;
                      inputManager.state.bowlLengthZ = z;
                    }}
                    className="w-full py-1.5 px-3 rounded text-left text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition font-medium flex justify-between"
                  >
                    <span>{len.replace(/_/g, ' ')}</span>
                    <span className="text-slate-500 font-mono text-[10px]">
                      {len === 'YORKER' ? 'Base of stumps' : len === 'GOOD_LENGTH' ? '6.5m (Top of off)' : 'Enforcer'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Delivery Variations */}
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Seam & Spin Variations
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                {(['STOCK_FAST', 'OUTSWINGER', 'INSWINGER', 'SLOWER_BALL', 'OFF_BREAK', 'LEG_BREAK', 'GOOGLY'] as DeliveryVariation[]).map((v) => (
                  <button
                    key={v}
                    onClick={() => {
                      if (v === 'OUTSWINGER') inputManager.state.bowlLineX = 0.25;
                      else if (v === 'INSWINGER') inputManager.state.bowlLineX = -0.15;
                    }}
                    className="p-1.5 rounded text-left text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition font-medium"
                  >
                    {v.replace(/_/g, ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Bowling Controls Action */}
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                  Pace & Delivery Release
                </span>
                <p className="text-xs text-slate-400 mb-3">
                  Set your line and length, then trigger the delivery stride. Fast bowlers will reach 90+ mph in English conditions.
                </p>
              </div>
              <button
                onClick={() => {
                  inputManager.state.bowlTrigger = true;
                }}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs transition shadow-lg"
              >
                ⚡ Trigger Bowler Run-Up
              </button>
            </div>
          </div>
        )}

        {/* 3. FIELDING TAB */}
        {activeTab === 'FIELDING' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                County Field Presets:
              </span>
              <span className="text-xs text-slate-500">9 Outfielders + Wicketkeeper + Bowler</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {[
                { id: 'ATTACKING_SLIPS', name: 'Attacking Slips', desc: 'Championship 3 Slips & Gully' },
                { id: 'STANDARD_BALANCED', name: 'Standard Balanced', desc: 'Balanced 5-4 field ring' },
                { id: 'DEFENSIVE_RING', name: 'Defensive Ring', desc: 'Boundary riders saving boundaries' },
                { id: 'DEATH_OVERS_T20', name: 'T20 Death Overs', desc: 'Deep protection down ground' },
                { id: 'SPIN_WEB', name: 'Spin Web', desc: 'Silly point & Short leg close in' },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => onSelectFieldPreset(p.id as FieldPreset)}
                  className={`p-3 rounded-xl border text-left transition ${
                    fieldPreset === p.id
                      ? 'bg-amber-500/20 border-amber-500 text-amber-200'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="font-bold text-xs block mb-1">{p.name}</span>
                  <span className="text-[11px] text-slate-400 block">{p.desc}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 4. HAWK-EYE & WAGON WHEEL TAB */}
        {activeTab === 'STATS' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Wagon Wheel Visualizer */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-col items-center">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                360° Wagon Wheel (Scoring Sectors)
              </span>
              <svg width="240" height="240" viewBox="-120 -120 240 240" className="my-2">
                {/* Outfield Oval */}
                <circle cx="0" cy="0" r="105" fill="#1b4d24" stroke="#ffffff" strokeWidth="2" strokeDasharray="4 4" />
                <circle cx="0" cy="0" r="45" fill="#245d2f" stroke="#ffffff" strokeWidth="1" strokeOpacity="0.4" />
                <rect x="-6" y="-12" width="12" height="24" fill="#c4a470" rx="2" />
                {/* Recent shot rays */}
                {currentInnings.history.map((h, idx) => {
                  const out = h.outcome;
                  if (out.runs === 0) return null;
                  const rad = ((out.wagonWheelAngle - 90) * Math.PI) / 180;
                  const len = out.isSix ? 105 : out.isFour ? 95 : 35 + out.runs * 16;
                  const x2 = Math.cos(rad) * len;
                  const y2 = Math.sin(rad) * len;
                  const strokeColor = out.isSix ? '#c084fc' : out.isFour ? '#60a5fa' : '#34d399';

                  return (
                    <line
                      key={idx}
                      x1="0"
                      y1="0"
                      x2={x2}
                      y2={y2}
                      stroke={strokeColor}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                    />
                  );
                })}
              </svg>
              <div className="flex items-center gap-4 text-[11px] text-slate-400 font-mono mt-1">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> 1-3 Runs</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-blue-400" /> 4 (Boundary)</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-purple-400" /> 6 (Maximum)</span>
              </div>
            </div>

            {/* Hawk-Eye Ball Tracking Summary */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-3">
                  Hawk-Eye DRS Trajectory Review
                </span>
                {lastOutcome ? (
                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Release Speed:</span>
                      <span className="text-amber-400 font-bold">{lastOutcome.speedMph} mph</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Shot Played:</span>
                      <span className="text-slate-200">{lastOutcome.shotType ? lastOutcome.shotType.replace(/_/g, ' ') : 'None'}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Timing Quality:</span>
                      <span className="text-emerald-400 font-bold">{lastOutcome.timing || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Distance Traveled:</span>
                      <span className="text-slate-200">{lastOutcome.distance} m</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">Outcome:</span>
                      <span className="text-slate-100 font-bold">{lastOutcome.description}</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">No delivery recorded yet. Bowl to see Hawk-Eye tracking.</p>
                )}
              </div>

              <div className="mt-4 p-2.5 bg-slate-900 rounded-lg border border-slate-800 text-[11px] text-slate-400">
                Switch camera mode to <span className="text-amber-400 font-semibold">HawkEye</span> to inspect the continuous 3D arc, pitch point, and projected path to stumps in the main canvas.
              </div>
            </div>
          </div>
        )}

        {/* 5. SCORECARD TAB */}
        {activeTab === 'SCORECARD' && (
          <div className="space-y-4 text-xs font-mono">
            <div>
              <h4 className="font-bold text-slate-300 uppercase tracking-wider mb-2 font-sans">
                {battingTeam.name} — Innings Batting Card
              </h4>
              <div className="overflow-x-auto bg-slate-950/60 rounded-xl border border-slate-800">
                <table className="w-full text-left">
                  <thead className="bg-slate-900/80 text-slate-400 text-[11px]">
                    <tr>
                      <th className="p-2.5">Batter</th>
                      <th className="p-2.5">Status</th>
                      <th className="p-2.5 text-right">R</th>
                      <th className="p-2.5 text-right">B</th>
                      <th className="p-2.5 text-right">4s</th>
                      <th className="p-2.5 text-right">6s</th>
                      <th className="p-2.5 text-right">SR</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {battingTeam.squad.map((p, idx) => {
                      const score = currentInnings.batterScores[idx];
                      if (!score) return null;
                      const sr = score.balls > 0 ? ((score.runs / score.balls) * 100).toFixed(1) : '-';
                      return (
                        <tr key={p.id} className={idx === currentInnings.currentStrikerIndex ? 'bg-amber-950/20' : ''}>
                          <td className="p-2.5 font-sans font-semibold text-slate-200">
                            {p.name} {idx === currentInnings.currentStrikerIndex && '★'}
                          </td>
                          <td className="p-2.5 text-slate-400 text-[11px]">{score.dismissal}</td>
                          <td className="p-2.5 text-right font-bold text-amber-300">{score.runs}</td>
                          <td className="p-2.5 text-right text-slate-400">{score.balls}</td>
                          <td className="p-2.5 text-right">{score.fours}</td>
                          <td className="p-2.5 text-right">{score.sixes}</td>
                          <td className="p-2.5 text-right text-slate-400">{sr}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
