'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import {
  BallState,
  BatSwingState,
  BowlingDeliveryInput,
  CameraViewMode,
  CompetitionType,
  DeliveryOutcome,
  DismissalType,
  DRSReview,
  MatchState,
  PitchCondition,
  ShotType,
  TimingCategory,
  WeatherCondition,
} from '@/lib/cricket/types';
import { createNewMatch, recordDeliveryInMatch } from '@/lib/cricket/engine/match';
import { createInitialBallState, stepBallPhysics } from '@/lib/cricket/physics/ball';
import { checkBatBallCollision } from '@/lib/cricket/physics/bat';
import { FielderPosition, getFieldPresetPositions, updateFieldersAI, FieldPreset } from '@/lib/cricket/engine/fielding';
import { chooseAIBowlingDelivery, chooseAIBattingShot } from '@/lib/cricket/engine/ai';
import { cricketAudio } from '@/lib/cricket/audio/cricketAudio';
import { inputManager } from '@/lib/cricket/input/controls';
import { createStadiumScene, Stadium3DScene, applyWeatherLighting } from '@/lib/cricket/render/stadium3d';
import {
  animateBatter,
  animateBowler,
  animateFielder,
  animateKeeper,
  createPlayerMesh,
  Player3DMesh,
} from '@/lib/cricket/render/characters3d';
import {
  createBallTrailFX,
  updateBallTrailFX,
  createPitchDustFX,
  triggerPitchDust,
  updatePitchDust,
  createWillowImpactFX,
  triggerWillowImpact,
  updateWillowImpact,
  initStumpPhysics,
  triggerStumpShatter,
  updateStumpPhysics,
  resetStumpPhysics,
  createCameraDirector,
  triggerCameraShake,
  updateBroadcastCamera,
  BallTrailFX,
  PitchDustFX,
  WillowImpactFX,
  StumpPhysicsState,
  BroadcastCameraDirector,
} from '@/lib/cricket/render/matchplayFX';
import { createHawkEyeGroup, HawkEyeVisuals, updateHawkEyeTrajectory } from '@/lib/cricket/render/hawkeye3d';
import { COUNTIES_DATA } from '@/lib/cricket/data/counties';

interface CricketCanvasProps {
  homeCountyId: string;
  awayCountyId: string;
  competition: CompetitionType;
  weather: WeatherCondition;
  pitch: PitchCondition;
  cameraMode: CameraViewMode;
  onCameraChange: (cam: CameraViewMode) => void;
  showDebug: boolean;
  onMatchUpdate: (match: MatchState) => void;
  onNewDeliveryOutcome: (outcome: DeliveryOutcome) => void;
  onTimingFeedback: (category: TimingCategory, shot: ShotType, speedMph: number) => void;
  selectedShotType: ShotType;
  selectedIsLofted: boolean;
  onTriggerShot: () => void;
  fieldPreset: FieldPreset;
}

export const CricketCanvas: React.FC<CricketCanvasProps> = ({
  homeCountyId,
  awayCountyId,
  competition,
  weather,
  pitch,
  cameraMode,
  onCameraChange,
  showDebug,
  onMatchUpdate,
  onNewDeliveryOutcome,
  onTimingFeedback,
  selectedShotType,
  selectedIsLofted,
  fieldPreset,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Simulation State Refs
  const stadiumRef = useRef<Stadium3DScene | null>(null);
  const ballMeshRef = useRef<THREE.Mesh | null>(null);
  const hawkEyeRef = useRef<HawkEyeVisuals | null>(null);

  // Matchplay FX & Physics Refs
  const ballTrailRef = useRef<BallTrailFX | null>(null);
  const pitchDustRef = useRef<PitchDustFX | null>(null);
  const willowImpactRef = useRef<WillowImpactFX | null>(null);
  const stumpPhysicsRef = useRef<StumpPhysicsState | null>(null);
  const cameraDirectorRef = useRef<BroadcastCameraDirector | null>(null);
  const idleTimeRef = useRef<number>(0);
  const cameraModeRef = useRef<CameraViewMode>(cameraMode);

  const strikerMeshRef = useRef<Player3DMesh | null>(null);
  const nonStrikerMeshRef = useRef<Player3DMesh | null>(null);
  const bowlerMeshRef = useRef<Player3DMesh | null>(null);
  const keeperMeshRef = useRef<Player3DMesh | null>(null);
  const fieldersMeshesRef = useRef<Player3DMesh[]>([]);

  const matchStateRef = useRef<MatchState>(createNewMatch(homeCountyId, awayCountyId, competition, weather, pitch));
  const fieldersStateRef = useRef<FielderPosition[]>([]);
  const ballStateRef = useRef<BallState | null>(null);

  // Delivery Loop State
  const deliveryPhaseRef = useRef<'IDLE' | 'RUNUP' | 'IN_FLIGHT' | 'FIELDING' | 'REPLAY'>('IDLE');
  const bowlerRunupProgressRef = useRef<number>(0);
  const batterSwingRef = useRef<BatSwingState>({
    type: 'STRAIGHT_DRIVE',
    isLofted: false,
    isDefensive: false,
    footwork: 'FRONT_FOOT',
    aimAngle: 0,
    power: 0.8,
    timingScore: 0,
    timingCategory: 'GOOD',
    swingProgress: 0,
    active: false,
  });

  // Running State
  const isRunningRef = useRef<boolean>(false);
  const strikerRunZRef = useRef<number>(1.22);
  const nonStrikerRunZRef = useRef<number>(18.9);
  const currentRunsAttemptedRef = useRef<number>(0);

  // Telemetry state for debug overlay
  const [telemetry, setTelemetry] = useState({
    fps: 60,
    ballSpeedMph: 0,
    ballZ: 0,
    ballY: 0,
    ballX: 0,
    phase: 'IDLE',
  });

  // Delivery completion callback ref
  const handleDeliveryCompletionRef = useRef<(runs: number, dismissal: DismissalType, desc: string) => void>(() => {});
  const updateDeliveryCycleRef = useRef<(dt: number) => void>(() => {});

  // Complete Delivery
  const handleDeliveryCompletion = useCallback((runs: number, dismissal: DismissalType, desc: string) => {
    deliveryPhaseRef.current = 'REPLAY';
    const match = matchStateRef.current;
    const currentInnings = match.inningsList[match.currentInningsIndex];
    const bowlingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.awayCounty : match.homeCounty;
    const bowler = bowlingTeam.squad[currentInnings.currentBowlerIndex];

    const outcome: DeliveryOutcome = {
      runs,
      extras: 0,
      isFour: runs === 4,
      isSix: runs === 6,
      isWicket: dismissal !== 'NOT_OUT',
      dismissalType: dismissal,
      bowlerName: bowler.name,
      shotType: batterSwingRef.current.type,
      timing: batterSwingRef.current.timingCategory,
      description: desc,
      wagonWheelAngle: Math.round((batterSwingRef.current.aimAngle * 180) / Math.PI + 180),
      distance: ballStateRef.current ? Math.round(ballStateRef.current.traveledDistance) : 0,
      speedMph: 84,
      trajectory: ballStateRef.current ? [...ballStateRef.current.trajectoryHistory] : [],
    };

    // Update Hawk-Eye 3D visualizer
    if (hawkEyeRef.current && ballStateRef.current) {
      updateHawkEyeTrajectory(
        hawkEyeRef.current,
        ballStateRef.current.trajectoryHistory,
        ballStateRef.current.bouncePoint,
        ballStateRef.current.position,
        dismissal === 'BOWLED' || dismissal === 'LBW'
      );
    }

    // Record in match state machine
    const { match: updatedMatch } = recordDeliveryInMatch(match, outcome);
    matchStateRef.current = updatedMatch;
    onMatchUpdate({ ...updatedMatch });
    onNewDeliveryOutcome(outcome);

    // Reset running positions
    currentRunsAttemptedRef.current = 0;
    strikerRunZRef.current = 1.22;
    nonStrikerRunZRef.current = 18.9;
    if (strikerMeshRef.current) strikerMeshRef.current.root.position.set(0.1, 0, 1.22);
    if (nonStrikerMeshRef.current) nonStrikerMeshRef.current.root.position.set(-0.9, 0, 18.9);

    // Transition back to IDLE after 2.2 seconds
    setTimeout(() => {
      deliveryPhaseRef.current = 'IDLE';
      if (strikerMeshRef.current) animateBatter(strikerMeshRef.current, 0, false);
      if (bowlerMeshRef.current) animateBowler(bowlerMeshRef.current, 0, false);
      if (ballMeshRef.current) ballMeshRef.current.visible = false;
    }, 2200);
  }, [onMatchUpdate, onNewDeliveryOutcome]);

  useEffect(() => {
    handleDeliveryCompletionRef.current = handleDeliveryCompletion;
  }, [handleDeliveryCompletion]);

  // Core Delivery Simulation Step
  const updateDeliveryCycle = useCallback((dt: number) => {
    const phase = deliveryPhaseRef.current;
    const match = matchStateRef.current;
    const currentInnings = match.inningsList[match.currentInningsIndex];
    const battingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.homeCounty : match.awayCounty;
    const bowlingTeam = currentInnings.battingTeamId === match.homeCounty.id ? match.awayCounty : match.homeCounty;

    const strikerPlayer = battingTeam.squad[currentInnings.currentStrikerIndex];
    const bowlerPlayer = bowlingTeam.squad[currentInnings.currentBowlerIndex];

    // Check user bat swing trigger from controller or prop
    if (inputManager.state.shotAction && !batterSwingRef.current.active) {
      batterSwingRef.current = {
        type: selectedShotType,
        isLofted: selectedIsLofted || inputManager.state.shotAction === 'LOFTED',
        isDefensive: inputManager.state.shotAction === 'DEFENSIVE',
        footwork: inputManager.state.isBackFoot ? 'BACK_FOOT' : 'FRONT_FOOT',
        aimAngle: inputManager.state.battingAimAngle,
        power: inputManager.state.shotPower,
        timingScore: 0,
        timingCategory: 'GOOD',
        swingProgress: 0,
        active: true,
      };
    }

    // 1. PHASE: IDLE (Crease Routine & Bowler Prep)
    if (phase === 'IDLE') {
      idleTimeRef.current += dt;

      // Reset stump physics if dislodged from previous delivery
      if (stumpPhysicsRef.current && stumpPhysicsRef.current.isShattered) {
        resetStumpPhysics(stumpPhysicsRef.current);
      }

      // Animate Batter in authentic stance with pitch-tapping routine & head tracking
      if (strikerMeshRef.current) {
        animateBatter(
          strikerMeshRef.current,
          0,
          false,
          0,
          selectedIsLofted,
          selectedShotType,
          inputManager.state.isBackFoot ? 'BACK_FOOT' : 'FRONT_FOOT',
          idleTimeRef.current
        );
      }

      // Animate Wicketkeeper in alert athletic crouch
      if (keeperMeshRef.current) {
        animateKeeper(keeperMeshRef.current, null, 25, false);
      }

      // Bowler waiting poised at top of mark
      if (bowlerMeshRef.current) {
        bowlerMeshRef.current.root.position.set(0.4, 0, 32.0);
        animateBowler(bowlerMeshRef.current, 0, false);
      }

      // Automatic delivery trigger or user manual trigger
      if (Math.random() < 0.03 || inputManager.state.bowlTrigger) {
        inputManager.state.bowlTrigger = false;
        deliveryPhaseRef.current = 'RUNUP';
        bowlerRunupProgressRef.current = 0;
      }
    }

    // 2. PHASE: RUNUP (Kinetic Delivery Chain & Fielders Walking In)
    else if (phase === 'RUNUP') {
      bowlerRunupProgressRef.current += dt * 0.95;
      const progress = Math.min(1.0, bowlerRunupProgressRef.current);

      if (bowlerMeshRef.current) {
        // Move bowler along runup (z from 32m down to 20m)
        const bZ = 32.0 - progress * 12.0;
        bowlerMeshRef.current.root.position.set(0.4, 0, bZ);
        animateBowler(bowlerMeshRef.current, progress, true);
      }

      // Batter trigger press as bowler nears crease
      if (strikerMeshRef.current) {
        animateBatter(
          strikerMeshRef.current,
          0,
          false,
          0,
          selectedIsLofted,
          selectedShotType,
          inputManager.state.isBackFoot ? 'BACK_FOOT' : 'FRONT_FOOT',
          idleTimeRef.current + progress * 2.0
        );
      }

      // Fielders walking in 2-3 steps with the bowler (authentic cricket rhythm)
      fieldersMeshesRef.current.forEach((mesh, idx) => {
        const state = fieldersStateRef.current[idx + 2];
        if (state) {
          const walkInZ = state.basePosition.z > 10 ? -progress * 1.5 : progress * 1.5;
          const walkInX = state.basePosition.x > 0 ? -progress * 0.6 : progress * 0.6;
          mesh.root.position.set(state.basePosition.x + walkInX, 0, state.basePosition.z + walkInZ);
          animateFielder(mesh, 'IDLE', 1.0);
        }
      });

      // Ball released at delivery stride peak
      if (bowlerRunupProgressRef.current >= 0.98) {
        deliveryPhaseRef.current = 'IN_FLIGHT';

        // Calculate authoritative release parameters
        const deliveryInput = chooseAIBowlingDelivery(bowlerPlayer, strikerPlayer, match, currentInnings.ballsThisOver + 1);
        const releasePos = { x: 0.35, y: 2.1, z: 20.0 };

        // Velocity vector pointing toward target bounce point
        const speedMps = deliveryInput.releaseSpeedMph * 0.44704;
        const targetZ = deliveryInput.targetZ;
        const targetX = deliveryInput.targetLine;
        const timeToBounce = Math.max(0.2, (releasePos.z - targetZ) / (speedMps * 0.96));

        const vz = -(releasePos.z - targetZ) / timeToBounce;
        const vx = (targetX - releasePos.x) / timeToBounce;
        const vy = (0 - releasePos.y - 0.5 * -9.81 * timeToBounce * timeToBounce) / timeToBounce;

        ballStateRef.current = createInitialBallState(
          releasePos,
          { x: vx, y: vy, z: vz },
          { x: 0, y: deliveryInput.spinRate, z: 0 },
          deliveryInput.swingAmount * 0.15
        );

        if (ballMeshRef.current) {
          ballMeshRef.current.visible = true;
          ballMeshRef.current.position.set(releasePos.x, releasePos.y, releasePos.z);
        }
      }
    }

    // 3. PHASE: IN_FLIGHT (Dust Puff on Pitch Bounce, Flying Bails on Bowled, Bat Contact Flash)
    else if (phase === 'IN_FLIGHT') {
      const ball = ballStateRef.current;
      if (ball) {
        const stepResult = stepBallPhysics(ball, dt, pitch, weather);

        // Sound & pitch dust puff upon pitch bounce
        if (stepResult.bouncedThisStep) {
          cricketAudio.playPitchBounce(Math.hypot(ball.velocity.x, ball.velocity.y, ball.velocity.z) / 35);
          if (pitchDustRef.current && ball.bouncePoint) {
            triggerPitchDust(pitchDustRef.current, ball.bouncePoint, 1.2);
          }
        }

        // Timber Shatter (Bowled!) with dislodged flying bails and camera shake
        if (stepResult.hitStumpsThisStep) {
          cricketAudio.playStumpShatter();
          cricketAudio.playCrowdCheer('WICKET');
          if (stumpPhysicsRef.current) {
            triggerStumpShatter(stumpPhysicsRef.current, ball.velocity);
          }
          if (cameraDirectorRef.current) {
            triggerCameraShake(cameraDirectorRef.current, 0.15, 0.35);
          }
          handleDeliveryCompletionRef.current(0, 'BOWLED', 'BOWLED! Disturbs the timber with a peach of a delivery!');
          return;
        }

        // Update ball 3D mesh & spin
        if (ballMeshRef.current) {
          ballMeshRef.current.position.set(ball.position.x, ball.position.y, ball.position.z);
          ballMeshRef.current.rotation.x += ball.velocity.z * dt * 5;
          ballMeshRef.current.rotation.y += (ball.spin.y / 60) * dt;
        }

        // Animate Wicketkeeper rising with bounce and glove tracking
        if (keeperMeshRef.current) {
          animateKeeper(keeperMeshRef.current, ball.position, ball.position.z, false);
        }

        // Progress batter swing
        if (batterSwingRef.current.active) {
          batterSwingRef.current.swingProgress += dt * 3.6;
          if (strikerMeshRef.current) {
            animateBatter(
              strikerMeshRef.current,
              batterSwingRef.current.swingProgress,
              true,
              batterSwingRef.current.aimAngle,
              batterSwingRef.current.isLofted,
              batterSwingRef.current.type,
              batterSwingRef.current.footwork,
              idleTimeRef.current
            );
          }

          // Check Bat / Ball Collision
          const batterPos = { x: 0.1, y: 0, z: 1.22 };
          const contact = checkBatBallCollision(ball, batterPos, batterSwingRef.current, strikerPlayer);

          if (contact) {
            if (contact.hitBat) {
              cricketAudio.playBatHit(contact.contactQuality, contact.isEdge);
              onTimingFeedback(
                contact.timingCategory,
                contact.shotType,
                Math.round(Math.hypot(contact.exitVelocity.x, contact.exitVelocity.y, contact.exitVelocity.z) * 2.237)
              );

              // Sweet spot flash ring & camera shake on heavy strikes
              if (willowImpactRef.current) {
                triggerWillowImpact(willowImpactRef.current, ball.position);
              }
              if (contact.contactQuality > 0.75 && cameraDirectorRef.current) {
                triggerCameraShake(cameraDirectorRef.current, 0.07, 0.15);
              }

              if (contact.contactQuality > 0.8) {
                cricketAudio.playCrowdCheer('BOUNDARY');
              }
              deliveryPhaseRef.current = 'FIELDING';
            } else if (contact.hitPad) {
              // Appeal for LBW
              cricketAudio.playPitchBounce(0.5);
              cricketAudio.playAppeal();

              // Check LBW criteria
              const pitchingInLine = ball.bouncePoint ? Math.abs(ball.bouncePoint.x) <= 0.25 : true;
              const impactInLine = Math.abs(ball.position.x) <= 0.15;
              const hittingStumps = Math.abs(ball.velocity.x) < 2.5;

              if (pitchingInLine && impactInLine && hittingStumps) {
                cricketAudio.playCrowdCheer('WICKET');
                handleDeliveryCompletionRef.current(0, 'LBW', 'Loud appeal from bowler and fielders... OUT! Given LBW!');
              } else {
                handleDeliveryCompletionRef.current(0, 'NOT_OUT', 'Stifled appeal for leg before wicket... Not Out!');
              }
              return;
            }
          }

          if (batterSwingRef.current.swingProgress >= 1.0) {
            batterSwingRef.current.active = false;
          }
        }

        // Ball passed wicketkeeper into gloves
        if (ball.position.z < -4.8 && !ball.hitBat) {
          ball.isDead = true;
          handleDeliveryCompletionRef.current(0, 'NOT_OUT', 'Beaten outside off! Wicketkeeper gathers cleanly.');
        }
      }
    }

    // 4. PHASE: FIELDING & RUNNING (Dynamic Diving, Slides, Throws, Bat Grounding)
    else if (phase === 'FIELDING') {
      const ball = ballStateRef.current;
      if (ball) {
        const stepResult = stepBallPhysics(ball, dt, pitch, weather);

        if (ballMeshRef.current) {
          ballMeshRef.current.position.set(ball.position.x, ball.position.y, ball.position.z);
        }

        // Check Boundary
        if (stepResult.hitBoundaryThisStep) {
          if (stepResult.boundaryRuns === 6) {
            cricketAudio.playCrowdCheer('SIX');
            handleDeliveryCompletionRef.current(6, 'NOT_OUT', 'MASSIVE! Clears the ropes into the county pavilion for SIX!');
          } else {
            cricketAudio.playCrowdCheer('BOUNDARY');
            handleDeliveryCompletionRef.current(4, 'NOT_OUT', 'Racing across the lush outfield... FOUR runs!');
          }
          return;
        }

        // Animate Keeper watching ball
        if (keeperMeshRef.current) {
          animateKeeper(keeperMeshRef.current, ball.position, ball.position.z, true);
        }

        // AI Fielders tracking ball
        const fieldingResult = updateFieldersAI(
          fieldersStateRef.current,
          ball,
          dt,
          bowlingTeam.squad
        );

        // Update Fielder 3D Meshes
        fieldersMeshesRef.current.forEach((mesh, idx) => {
          const state = fieldersStateRef.current[idx + 2];
          if (state) {
            mesh.root.position.set(state.currentPosition.x, 0, state.currentPosition.z);
            animateFielder(mesh, state.state, Math.hypot(state.velocity.x, state.velocity.z));
          }
        });

        // Check Catch
        if (fieldingResult.catchAttempt) {
          if (fieldingResult.catchAttempt.successful) {
            cricketAudio.playCrowdCheer('WICKET');
            fieldersMeshesRef.current.forEach((m) => animateFielder(m, 'CELEBRATING', 1.0));
            handleDeliveryCompletionRef.current(
              0,
              fieldingResult.catchAttempt.dismissalType,
              `CAUGHT! Sensational grab by ${fieldingResult.catchAttempt.fielderName}!`
            );
            return;
          } else {
            cricketAudio.playCalling('WAIT');
          }
        }

        // Running Between Wickets with running gait and bat-slide over crease
        if (inputManager.state.runAction === 'RUN') {
          isRunningRef.current = true;
          cricketAudio.playCalling('YES');
        } else if (inputManager.state.runAction === 'CANCEL') {
          isRunningRef.current = false;
          cricketAudio.playCalling('NO');
        }

        if (isRunningRef.current) {
          strikerRunZRef.current += dt * 6.8;
          nonStrikerRunZRef.current -= dt * 6.8;

          if (strikerMeshRef.current) {
            strikerMeshRef.current.root.position.z = strikerRunZRef.current;
            const cycle = strikerRunZRef.current * 3.5;
            strikerMeshRef.current.leftLeg.rotation.x = Math.sin(cycle) * 0.7;
            strikerMeshRef.current.rightLeg.rotation.x = -Math.sin(cycle) * 0.7;
            strikerMeshRef.current.leftArm.rotation.x = -Math.sin(cycle) * 0.7;
            strikerMeshRef.current.rightArm.rotation.x = Math.sin(cycle) * 0.7;
            // Grounding bat over popping crease
            if (strikerRunZRef.current >= 17.5 && strikerMeshRef.current.bat) {
              strikerMeshRef.current.bat.rotation.x = 0.8;
            }
          }

          if (nonStrikerMeshRef.current) {
            nonStrikerMeshRef.current.root.position.z = nonStrikerRunZRef.current;
            const cycle = nonStrikerRunZRef.current * 3.5;
            nonStrikerMeshRef.current.leftLeg.rotation.x = Math.sin(cycle) * 0.7;
            nonStrikerMeshRef.current.rightLeg.rotation.x = -Math.sin(cycle) * 0.7;
            nonStrikerMeshRef.current.leftArm.rotation.x = -Math.sin(cycle) * 0.7;
            nonStrikerMeshRef.current.rightArm.rotation.x = Math.sin(cycle) * 0.7;
          }

          if (strikerRunZRef.current >= 18.9) {
            // Completed 1 single run!
            currentRunsAttemptedRef.current++;
            strikerRunZRef.current = 1.22;
            nonStrikerRunZRef.current = 18.9;
            isRunningRef.current = false;
            if (strikerMeshRef.current) {
              strikerMeshRef.current.root.position.z = 1.22;
              strikerMeshRef.current.leftLeg.rotation.set(0, 0, 0);
              strikerMeshRef.current.rightLeg.rotation.set(0, 0, 0);
            }
            if (nonStrikerMeshRef.current) {
              nonStrikerMeshRef.current.root.position.z = 18.9;
              nonStrikerMeshRef.current.leftLeg.rotation.set(0, 0, 0);
              nonStrikerMeshRef.current.rightLeg.rotation.set(0, 0, 0);
            }
          }
        }

        // Ball secured by fielder -> return to bowler
        if (fieldingResult.ballSecured || ball.isDead) {
          const runsScored = Math.max(currentRunsAttemptedRef.current, 0);
          handleDeliveryCompletionRef.current(
            runsScored,
            'NOT_OUT',
            runsScored > 0 ? `Good running between the wickets, taking ${runsScored} run(s).` : 'Fielded cleanly on the bounce, no run.'
          );
        }
      }
    }
  }, [pitch, weather, onTimingFeedback, selectedShotType, selectedIsLofted]);

  useEffect(() => {
    updateDeliveryCycleRef.current = updateDeliveryCycle;
  }, [updateDeliveryCycle]);

  // Initialize Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    inputManager.init();

    // 1. Build Stadium
    const stadium = createStadiumScene(container, weather);
    stadiumRef.current = stadium;

    // 2. Ball 3D Mesh
    const ballGeo = new THREE.SphereGeometry(0.036, 24, 24);
    const ballMat = new THREE.MeshStandardMaterial({
      color: competition === 'COUNTY_CHAMPIONSHIP' ? 0x8b0000 : 0xffffff, // Red Duke ball for Championship, White ball for T20/OneDay
      roughness: 0.35,
      metalness: 0.1,
    });
    const ballMesh = new THREE.Mesh(ballGeo, ballMat);
    ballMesh.castShadow = true;
    stadium.scene.add(ballMesh);
    ballMeshRef.current = ballMesh;

    // Seam line around ball
    const seamGeo = new THREE.TorusGeometry(0.0365, 0.002, 8, 32);
    const seamMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const seam = new THREE.Mesh(seamGeo, seamMat);
    ballMesh.add(seam);

    // 3. DRS Hawk-Eye Visualizer
    const hawkEye = createHawkEyeGroup(stadium.scene);
    hawkEyeRef.current = hawkEye;

    // 4. Create Players
    const homeTeam = COUNTIES_DATA.find((c) => c.id === homeCountyId) || COUNTIES_DATA[0];
    const awayTeam = COUNTIES_DATA.find((c) => c.id === awayCountyId) || COUNTIES_DATA[1];

    const kitColor = competition === 'COUNTY_CHAMPIONSHIP' ? '#fdfbf7' : homeTeam.primaryColor;
    const awayKitColor = competition === 'COUNTY_CHAMPIONSHIP' ? '#fdfbf7' : awayTeam.primaryColor;

    // Striker (Batting Crease z = 1.22m)
    const striker = createPlayerMesh(homeTeam.squad[0], kitColor, homeTeam.secondaryColor, true, false, false);
    striker.root.position.set(0.1, 0, 1.22);
    stadium.scene.add(striker.root);
    strikerMeshRef.current = striker;

    // Non-Striker (Bowling Crease z = 18.9m)
    const nonStriker = createPlayerMesh(homeTeam.squad[1], kitColor, homeTeam.secondaryColor, true, false, false);
    nonStriker.root.position.set(-0.9, 0, 18.9);
    stadium.scene.add(nonStriker.root);
    nonStrikerMeshRef.current = nonStriker;

    // Bowler (Top of mark z = 32m)
    const bowler = createPlayerMesh(awayTeam.squad[9], awayKitColor, awayTeam.secondaryColor, false, false, true);
    bowler.root.position.set(0.4, 0, 32.0);
    stadium.scene.add(bowler.root);
    bowlerMeshRef.current = bowler;

    // Wicketkeeper (z = -4.5m)
    const keeper = createPlayerMesh(awayTeam.squad[4], awayKitColor, awayTeam.secondaryColor, false, true, false);
    keeper.root.position.set(0, 0, -4.5);
    stadium.scene.add(keeper.root);
    keeperMeshRef.current = keeper;

    // 9 Outfielders
    const initialField = getFieldPresetPositions(fieldPreset);
    fieldersStateRef.current = initialField.map((f, idx) => ({ ...f, playerIndex: idx }));

    const fielderMeshes: Player3DMesh[] = [];
    initialField.slice(2).forEach((f, idx) => {
      const pMesh = createPlayerMesh(awayTeam.squad[idx + 1] || awayTeam.squad[0], awayKitColor, awayTeam.secondaryColor);
      pMesh.root.position.set(f.basePosition.x, 0, f.basePosition.z);
      stadium.scene.add(pMesh.root);
      fielderMeshes.push(pMesh);
    });
    fieldersMeshesRef.current = fielderMeshes;

    // Initialize Matchplay Visual Effects, Stump Physics & Broadcast Camera Director
    ballTrailRef.current = createBallTrailFX(stadium.scene);
    pitchDustRef.current = createPitchDustFX(stadium.scene);
    willowImpactRef.current = createWillowImpactFX(stadium.scene);
    stumpPhysicsRef.current = initStumpPhysics(stadium.battingStumps);
    cameraDirectorRef.current = createCameraDirector(stadium.camera);

    // Animation & Physics Loop
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = 0;
    let animId: number;

    const gameLoop = (currentTime: number) => {
      animId = requestAnimationFrame(gameLoop);
      const dt = Math.min((currentTime - lastTime) / 1000, 0.05); // cap at 50ms
      lastTime = currentTime;

      frameCount++;
      fpsTimer += dt;
      if (fpsTimer >= 0.5) {
        const fps = Math.round(frameCount / fpsTimer);
        frameCount = 0;
        fpsTimer = 0;

        const currentBall = ballStateRef.current;
        setTelemetry({
          fps,
          ballSpeedMph: currentBall ? Math.round(Math.hypot(currentBall.velocity.x, currentBall.velocity.y, currentBall.velocity.z) * 2.237) : 0,
          ballX: currentBall ? Math.round(currentBall.position.x * 100) / 100 : 0,
          ballY: currentBall ? Math.round(currentBall.position.y * 100) / 100 : 0,
          ballZ: currentBall ? Math.round(currentBall.position.z * 100) / 100 : 0,
          phase: deliveryPhaseRef.current,
        });
      }

      // 1. Poll Gamepads and Keyboard
      inputManager.pollGamepads();

      // 2. State Machine Update
      updateDeliveryCycleRef.current(dt);

      // 3. Matchplay Visual Effects & Stump Rigid-Body Physics Update
      const curBall = ballStateRef.current;
      const speedMps = curBall ? Math.hypot(curBall.velocity.x, curBall.velocity.y, curBall.velocity.z) : 0;
      if (ballTrailRef.current) {
        updateBallTrailFX(
          ballTrailRef.current,
          curBall ? curBall.position : null,
          speedMps,
          deliveryPhaseRef.current === 'IN_FLIGHT' || deliveryPhaseRef.current === 'FIELDING'
        );
      }
      if (pitchDustRef.current) {
        updatePitchDust(pitchDustRef.current, dt);
      }
      if (willowImpactRef.current) {
        updateWillowImpact(willowImpactRef.current, dt);
      }
      if (stumpPhysicsRef.current) {
        updateStumpPhysics(stumpPhysicsRef.current, dt);
      }

      // 4. Dynamic Broadcast Camera Update
      if (cameraDirectorRef.current && stadiumRef.current) {
        updateBroadcastCamera(
          cameraDirectorRef.current,
          stadiumRef.current.camera,
          cameraModeRef.current,
          deliveryPhaseRef.current,
          curBall ? curBall.position : null,
          curBall ? curBall.velocity : null,
          batterSwingRef.current.isLofted,
          dt
        );
      }

      // 5. Render
      stadium.renderer.render(stadium.scene, stadium.camera);
    };

    animId = requestAnimationFrame(gameLoop);

    // Resize Handler
    const handleResize = () => {
      if (!container || !stadiumRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      stadiumRef.current.camera.aspect = w / h;
      stadiumRef.current.camera.updateProjectionMatrix();
      stadiumRef.current.renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      inputManager.destroy();
      window.removeEventListener('resize', handleResize);
      if (container && stadium.renderer.domElement) {
        container.removeChild(stadium.renderer.domElement);
      }
    };
  }, [homeCountyId, awayCountyId, competition, weather, pitch, fieldPreset]);

  // Update Field Positions when Field Preset changes
  useEffect(() => {
    const updated = getFieldPresetPositions(fieldPreset);
    fieldersStateRef.current = updated.map((f, idx) => ({ ...f, playerIndex: idx }));

    fieldersMeshesRef.current.forEach((mesh, idx) => {
      const pos = updated[idx + 2];
      if (pos) {
        mesh.root.position.set(pos.basePosition.x, 0, pos.basePosition.z);
      }
    });
  }, [fieldPreset]);

  // Update Weather
  useEffect(() => {
    if (stadiumRef.current) {
      applyWeatherLighting(
        weather,
        stadiumRef.current.scene,
        stadiumRef.current.sunLight,
        stadiumRef.current.ambientLight,
        stadiumRef.current.floodlights
      );
    }
  }, [weather]);

  // Update Camera View
  useEffect(() => {
    cameraModeRef.current = cameraMode;
    if (!stadiumRef.current) return;
    const cam = stadiumRef.current.camera;

    switch (cameraMode) {
      case 'BATSMAN':
        // Classic broadcast camera behind batsman looking down the pitch
        cam.position.set(0, 2.3, -4.5);
        cam.lookAt(0, 1.2, 14);
        break;
      case 'BOWLER':
        // Behind bowler
        cam.position.set(0.6, 2.5, 26);
        cam.lookAt(0, 0.8, 0);
        break;
      case 'BROADCAST':
        // Elevated television grandstand view
        cam.position.set(22, 14, 10);
        cam.lookAt(0, 0.5, 10);
        break;
      case 'WICKET_CAM':
        // Ground-level stump camera
        cam.position.set(0, 0.45, 0.2);
        cam.lookAt(0, 1.4, 20);
        break;
      case 'FIELDING':
        // Dynamic tracking camera
        cam.position.set(12, 6, -2);
        cam.lookAt(0, 0.8, 8);
        break;
      case 'DRS_HAWKEYE':
        // Side pitch hawk-eye angle
        cam.position.set(8.5, 2.2, 5.0);
        cam.lookAt(0, 0.5, 0);
        break;
    }

    if (cameraDirectorRef.current) {
      cameraDirectorRef.current.currentPos.copy(cam.position);
      cameraDirectorRef.current.desiredPos.copy(cam.position);
    }
  }, [cameraMode]);

  // Manual Trigger to Bowl next delivery
  const handleBowlNext = () => {
    if (deliveryPhaseRef.current === 'IDLE') {
      deliveryPhaseRef.current = 'RUNUP';
      bowlerRunupProgressRef.current = 0;
    }
  };

  return (
    <div className="relative w-full h-full min-h-[520px] bg-slate-950 overflow-hidden select-none">
      {/* 3D Three.js Container */}
      <div ref={containerRef} className="w-full h-full cursor-crosshair" />

      {/* On-Screen Action Overlay Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        {/* Left: Quick Batting & Running Triggers */}
        <div className="flex items-center gap-2 pointer-events-auto bg-slate-900/80 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/60 shadow-xl">
          <button
            onClick={() => {
              inputManager.state.shotAction = 'GROUND';
              setTimeout(() => (inputManager.state.shotAction = null), 200);
            }}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-medium text-xs rounded-lg transition"
            title="Press [J] or [1]"
          >
            Ground Shot [J]
          </button>
          <button
            onClick={() => {
              inputManager.state.shotAction = 'LOFTED';
              setTimeout(() => (inputManager.state.shotAction = null), 200);
            }}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 active:scale-95 text-white font-medium text-xs rounded-lg transition"
            title="Press [K] or [2]"
          >
            Lofted Shot [K]
          </button>
          <button
            onClick={() => {
              inputManager.state.shotAction = 'DEFENSIVE';
              setTimeout(() => (inputManager.state.shotAction = null), 200);
            }}
            className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-100 font-medium text-xs rounded-lg transition"
            title="Press [L] or [3]"
          >
            Defend [L]
          </button>
          <div className="h-4 w-px bg-slate-700" />
          <button
            onClick={() => {
              inputManager.state.runAction = 'RUN';
              setTimeout(() => (inputManager.state.runAction = null), 300);
            }}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-medium text-xs rounded-lg transition"
            title="Press [Space]"
          >
            Run [Space]
          </button>
        </div>

        {/* Right: Camera Cycle & Manual Bowl Button */}
        <div className="flex items-center gap-2 pointer-events-auto bg-slate-900/80 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/60 shadow-xl">
          <button
            onClick={handleBowlNext}
            disabled={telemetry.phase !== 'IDLE'}
            className={`px-4 py-1.5 font-semibold text-xs rounded-lg transition ${
              telemetry.phase === 'IDLE'
                ? 'bg-rose-600 hover:bg-rose-500 text-white cursor-pointer active:scale-95 shadow-md shadow-rose-900/40'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {telemetry.phase === 'IDLE' ? '⚡ Bowl Delivery' : 'In Play...'}
          </button>

          <div className="h-4 w-px bg-slate-700" />

          {(['BATSMAN', 'BOWLER', 'BROADCAST', 'WICKET_CAM', 'DRS_HAWKEYE'] as CameraViewMode[]).map((cam) => (
            <button
              key={cam}
              onClick={() => onCameraChange(cam)}
              className={`px-2.5 py-1 text-xs rounded-md font-medium transition ${
                cameraMode === cam ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cam === 'BATSMAN' ? 'Bat' : cam === 'BOWLER' ? 'Bowl' : cam === 'BROADCAST' ? 'TV' : cam === 'WICKET_CAM' ? 'Wkt' : 'HawkEye'}
            </button>
          ))}
        </div>
      </div>

      {/* Engineering Telemetry Overlay */}
      {showDebug && (
        <div className="absolute top-4 left-4 bg-slate-950/90 border border-emerald-500/40 rounded-lg p-3 text-emerald-400 font-mono text-[11px] leading-relaxed shadow-2xl pointer-events-none backdrop-blur-md">
          <div className="text-emerald-300 font-bold border-b border-emerald-500/30 pb-1 mb-1.5 flex justify-between gap-4">
            <span>PHYSICS ENGINE 60Hz</span>
            <span>{telemetry.fps} FPS</span>
          </div>
          <div>BALL SPEED: {telemetry.ballSpeedMph} MPH</div>
          <div>POSITION X: {telemetry.ballX} m</div>
          <div>POSITION Y: {telemetry.ballY} m (Height)</div>
          <div>POSITION Z: {telemetry.ballZ} m (Pitch Length)</div>
          <div>PITCH STATE: {pitch.replace(/_/g, ' ')}</div>
          <div>WEATHER: {weather.replace(/_/g, ' ')}</div>
          <div>PHASE: {telemetry.phase}</div>
        </div>
      )}
    </div>
  );
};
