'use client';

import React, { useState } from 'react';
import { CompetitionType, PitchCondition, WeatherCondition } from '@/lib/cricket/types';
import { COUNTIES_DATA } from '@/lib/cricket/data/counties';

interface MatchSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartMatch: (config: {
    homeCountyId: string;
    awayCountyId: string;
    competition: CompetitionType;
    weather: WeatherCondition;
    pitch: PitchCondition;
  }) => void;
  currentHome: string;
  currentAway: string;
  currentComp: CompetitionType;
  currentWeather: WeatherCondition;
  currentPitch: PitchCondition;
}

export const MatchSetupModal: React.FC<MatchSetupModalProps> = ({
  isOpen,
  onClose,
  onStartMatch,
  currentHome,
  currentAway,
  currentComp,
  currentWeather,
  currentPitch,
}) => {
  const [homeCountyId, setHomeCountyId] = useState(currentHome);
  const [awayCountyId, setAwayCountyId] = useState(currentAway);
  const [competition, setCompetition] = useState<CompetitionType>(currentComp);
  const [weather, setWeather] = useState<WeatherCondition>(currentWeather);
  const [pitch, setPitch] = useState<PitchCondition>(currentPitch);

  if (!isOpen) return null;

  const selectedHome = COUNTIES_DATA.find((c) => c.id === homeCountyId) || COUNTIES_DATA[0];
  const selectedAway = COUNTIES_DATA.find((c) => c.id === awayCountyId) || COUNTIES_DATA[1];

  const handleStart = () => {
    onStartMatch({
      homeCountyId,
      awayCountyId,
      competition,
      weather,
      pitch,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏆</span>
            <div>
              <h3 className="text-base font-bold text-slate-100">County Cricket 2027 — Match Fixture</h3>
              <p className="text-xs text-slate-400">Select English counties, match format, and atmospheric conditions</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100 p-1.5 rounded-lg hover:bg-slate-800 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-200">
          {/* 1. Team Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 font-bold uppercase tracking-wider mb-2">
                Home County (Batting 1st)
              </label>
              <select
                value={homeCountyId}
                onChange={(e) => setHomeCountyId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-slate-100 font-semibold focus:outline-none focus:border-amber-500"
              >
                {COUNTIES_DATA.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.homeVenue})
                  </option>
                ))}
              </select>
              <p className="mt-1.5 text-[11px] text-slate-400">
                Venue: <span className="text-amber-400">{selectedHome.homeVenue}</span>
              </p>
            </div>

            <div>
              <label className="block text-slate-400 font-bold uppercase tracking-wider mb-2">
                Away County (Bowling 1st)
              </label>
              <select
                value={awayCountyId}
                onChange={(e) => setAwayCountyId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-slate-100 font-semibold focus:outline-none focus:border-amber-500"
              >
                {COUNTIES_DATA.filter((c) => c.id !== homeCountyId).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <p className="mt-1.5 text-[11px] text-slate-400">
                Captain: <span className="text-amber-400">{selectedAway.squad[0].name}</span>
              </p>
            </div>
          </div>

          {/* 2. Competition Format */}
          <div>
            <label className="block text-slate-400 font-bold uppercase tracking-wider mb-2">
              Competition Format
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: 'QUICK_MATCH', name: 'Quick Match', desc: '5 Overs Blast' },
                { id: 'COUNTY_T20', name: 'County T20', desc: '20 Overs Night' },
                { id: 'ONE_DAY', name: 'One-Day Trophy', desc: '50 Overs' },
                { id: 'COUNTY_CHAMPIONSHIP', name: 'Championship', desc: '4-Day Red Ball' },
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCompetition(c.id as CompetitionType)}
                  className={`p-3 rounded-xl border text-left transition ${
                    competition === c.id
                      ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <span className="block text-xs text-slate-100">{c.name}</span>
                  <span className="text-[10px] text-slate-400">{c.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Weather & Atmosphere */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 font-bold uppercase tracking-wider mb-2">
                Weather & Atmosphere
              </label>
              <select
                value={weather}
                onChange={(e) => setWeather(e.target.value as WeatherCondition)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-slate-100 font-semibold focus:outline-none focus:border-amber-500"
              >
                <option value="ENGLISH_SUMMER">English Summer (Sun & Warm Breeze)</option>
                <option value="OVERCAST">Overcast (High Duke Ball Swing)</option>
                <option value="SUNNY">Bright Sunny Afternoon</option>
                <option value="FLOODLIT_EVENING">Floodlit Evening (T20 Lights)</option>
                <option value="DRIZZLE">English Drizzle / Damp Air</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-bold uppercase tracking-wider mb-2">
                Pitch Surface Condition
              </label>
              <select
                value={pitch}
                onChange={(e) => setPitch(e.target.value as PitchCondition)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-slate-100 font-semibold focus:outline-none focus:border-amber-500"
              >
                <option value="FRESH_GREEN">Fresh Green (Seam Movement)</option>
                <option value="HARD_TRUE">Hard & True (Good Bounce & Carry)</option>
                <option value="DRY_DUSTY">Dry & Dusty (Turning Surface)</option>
                <option value="WORN_DAY4">Worn Day 4 (Uneven Bounce)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Playing at <span className="font-semibold text-slate-200">{selectedHome.homeVenue}</span>
          </div>
          <button
            onClick={handleStart}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider transition active:scale-95 shadow-lg shadow-amber-500/20"
          >
            Start Match ➔
          </button>
        </div>
      </div>
    </div>
  );
};
