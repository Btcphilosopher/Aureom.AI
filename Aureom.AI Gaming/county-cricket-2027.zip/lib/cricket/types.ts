// County Cricket 2027 - Core Engine Types & Interfaces

export type CompetitionType = 'COUNTY_CHAMPIONSHIP' | 'ONE_DAY' | 'COUNTY_T20' | 'TRAINING' | 'QUICK_MATCH';

export type WeatherCondition = 'SUNNY' | 'OVERCAST' | 'DRIZZLE' | 'ENGLISH_SUMMER' | 'FLOODLIT_EVENING';

export type PitchCondition = 'FRESH_GREEN' | 'HARD_FLAT' | 'DRY_DUSTY' | 'DAMP_SEAMING' | 'WORN_DAY4';

export type BattingMode = 'SIMPLE' | 'PROFESSIONAL';

export type TimingCategory = 'TOO_EARLY' | 'EARLY' | 'GOOD' | 'PERFECT' | 'LATE' | 'TOO_LATE';

export type ShotType =
  | 'FORWARD_DEFENCE'
  | 'BACK_FOOT_DEFENCE'
  | 'LEAVE'
  | 'STRAIGHT_DRIVE'
  | 'COVER_DRIVE'
  | 'ON_DRIVE'
  | 'SQUARE_CUT'
  | 'LATE_CUT'
  | 'LEG_GLANCE'
  | 'PULL_SHOT'
  | 'HOOK_SHOT'
  | 'SWEEP'
  | 'SLOG_SWEEP'
  | 'RAMP_SCOOP'
  | 'LOFTED_DRIVE'
  | 'AERIAL_SLOG';

export type BowlingType = 'PACE' | 'FAST_MEDIUM' | 'OFF_SPIN' | 'LEG_SPIN' | 'LEFT_ARM_ORTHODOX' | 'LEFT_ARM_SEAM';

export type DeliveryVariation =
  | 'STOCK_FAST'
  | 'OUTSWINGER'
  | 'INSWINGER'
  | 'OFF_CUTTER'
  | 'LEG_CUTTER'
  | 'SLOWER_BALL'
  | 'YORKER'
  | 'BOUNCER'
  | 'OFF_BREAK'
  | 'LEG_BREAK'
  | 'GOOGLY'
  | 'TOP_SPINNER'
  | 'ARM_BALL'
  | 'FLIGHTED';

export type BowlingLengthZone = 'YORKER' | 'FULL' | 'FULL_LENGTH' | 'GOOD_LENGTH' | 'SHORT_OF_LENGTH' | 'SHORT' | 'BOUNCER';

export type DismissalType =
  | 'NOT_OUT'
  | 'BOWLED'
  | 'CAUGHT_BEHIND'
  | 'CAUGHT_SLIPS'
  | 'CAUGHT_INFIELD'
  | 'CAUGHT_OUTFIELD'
  | 'CAUGHT_AND_BOWLED'
  | 'LBW'
  | 'RUN_OUT'
  | 'STUMPED'
  | 'HIT_WICKET';

export type CameraViewMode = 'BATSMAN' | 'BOWLER' | 'BROADCAST' | 'FIELDING' | 'WICKET_CAM' | 'DRS_HAWKEYE';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface PlayerAttributes {
  battingSkill: number; // 50-99
  timing: number; // 50-99
  power: number; // 50-99
  defence: number; // 50-99
  shotSelection: number; // 50-99

  bowlingSkill: number; // 50-99
  pace: number; // km/h potential (110 - 150)
  swing: number; // 50-99
  seam: number; // 50-99
  spin: number; // 50-99
  accuracy: number; // 50-99

  fieldingSpeed: number; // 50-99
  reaction: number; // 50-99
  catching: number; // 50-99
  throwing: number; // 50-99
  wicketkeeping: number; // 50-99

  stamina: number; // 50-99
  form: number; // 50-99
}

export interface CricketPlayer {
  id: string;
  name: string;
  shortName: string;
  role: 'BATSMAN' | 'BOWLER' | 'ALL_ROUNDER' | 'WICKET_KEEPER';
  battingStyle: 'RIGHT_HAND' | 'LEFT_HAND';
  bowlingStyle: BowlingType;
  attributes: PlayerAttributes;
  stats: {
    matches: number;
    runs: number;
    highestScore: number;
    battingAverage: number;
    centuries: number;
    wickets: number;
    bestBowling: string;
    bowlingAverage: number;
    economy: number;
    catches: number;
  };
}

export interface CountyTeam {
  id: string;
  name: string;
  nickname: string;
  code: string;
  primaryColor: string;
  secondaryColor: string;
  whitesTrimColor: string;
  homeVenue: string;
  countyChampionshipTitles: number;
  squad: CricketPlayer[];
  tactic: {
    aggression: number;
    preferredLength: BowlingLengthZone;
    spinFocus: boolean;
  };
}

export interface BallState {
  position: Vector3D; // relative to batting crease center (x: left/right, y: height, z: distance from stumps)
  velocity: Vector3D;
  spin: Vector3D;
  seamAngle: number;
  hasBounced: boolean;
  bouncePoint: Vector3D | null;
  bounceCount: number;
  hitBat: boolean;
  hitPad: boolean;
  isDead: boolean;
  isBoundaryFour: boolean;
  isBoundarySix: boolean;
  traveledDistance: number;
  trajectoryHistory: Vector3D[];
}

export interface BatSwingState {
  type: ShotType;
  isLofted: boolean;
  isDefensive: boolean;
  footwork: 'FRONT_FOOT' | 'BACK_FOOT' | 'ADVANCE' | 'RETREAT' | 'NEUTRAL';
  aimAngle: number; // radians (-PI to PI)
  power: number; // 0 to 1
  timingScore: number; // -1 (too late) to +1 (too early), 0 is perfect
  timingCategory: TimingCategory;
  swingProgress: number; // 0 to 1
  active: boolean;
}

export interface BowlingDeliveryInput {
  bowlerId: string;
  type: DeliveryVariation;
  targetLine: number; // x offset (-0.5 off to +0.5 leg)
  targetLength: BowlingLengthZone;
  targetZ: number; // distance from bowler (10 to 18m)
  power: number; // 0 to 1
  swingAmount: number; // -1 (outswing) to +1 (inswing)
  spinRate: number; // rpm
  releaseSpeedMph: number;
}

export interface DeliveryOutcome {
  runs: number;
  extras: number;
  isFour: boolean;
  isSix: boolean;
  isWicket: boolean;
  dismissalType: DismissalType;
  dismissedPlayerName?: string;
  bowlerName: string;
  shotType?: ShotType;
  timing?: TimingCategory;
  description: string;
  wagonWheelAngle: number; // 0 to 360 deg
  distance: number;
  bouncePoint?: Vector3D;
  speedMph: number;
  trajectory: Vector3D[];
}

export interface OverDeliveryRecord {
  ballNumber: number;
  legalBall: boolean;
  outcome: DeliveryOutcome;
}

export interface InningsState {
  battingTeamId: string;
  bowlingTeamId: string;
  totalRuns: number;
  wickets: number;
  overs: number; // e.g. 3.4 overs
  ballsThisOver: number;
  currentStrikerIndex: number;
  currentNonStrikerIndex: number;
  currentBowlerIndex: number;
  declared: boolean;
  allOut: boolean;
  extras: {
    wides: number;
    noBalls: number;
    byes: number;
    legByes: number;
  };
  batterScores: {
    playerId: string;
    runs: number;
    balls: number;
    fours: number;
    sixes: number;
    dismissal: string;
    isOut: boolean;
  }[];
  bowlerFigures: {
    playerId: string;
    oversBowled: number;
    maidens: number;
    runsConceded: number;
    wickets: number;
  }[];
  partnerships: {
    batter1Id: string;
    batter2Id: string;
    runs: number;
    balls: number;
  }[];
  history: OverDeliveryRecord[];
}

export interface MatchState {
  competition: CompetitionType;
  homeCounty: CountyTeam;
  awayCounty: CountyTeam;
  playerCountyId: string;
  venue: string;
  weather: WeatherCondition;
  pitch: PitchCondition;
  currentInningsIndex: number;
  maxOversPerInnings: number; // e.g. 20 for T20, 50 for One-Day, 0 for 4-Day unlimited
  targetRuns: number | null;
  inningsList: InningsState[];
  isMatchComplete: boolean;
  resultMessage: string;
}

export interface DRSReview {
  active: boolean;
  appealedBy: string;
  decision: 'OUT' | 'NOT_OUT';
  originalDecision: 'OUT' | 'NOT_OUT';
  reason: string;
  pitching: 'IN_LINE' | 'OUTSIDE_OFF' | 'OUTSIDE_LEG';
  impact: 'IN_LINE' | 'OUTSIDE';
  wickets: 'HITTING' | 'MISSING' | 'UMPIRES_CALL';
  ballTrajectory: Vector3D[];
  edgeDetected: boolean;
}

export type FieldPreset = 'ATTACKING_SLIPS' | 'STANDARD_BALANCED' | 'DEFENSIVE_RING' | 'DEATH_OVERS_T20' | 'SPIN_WEB';

export interface FielderPosition {
  id: string;
  name: string;
  basePosition: Vector3D;
  currentPosition: Vector3D;
  velocity: Vector3D;
  isWicketkeeper?: boolean;
  isBowler?: boolean;
  state: 'IDLE' | 'CHASING' | 'INTERCEPTING' | 'PICKING_UP' | 'DIVING' | 'THROWING' | 'CELEBRATING';
  playerIndex: number;
}
