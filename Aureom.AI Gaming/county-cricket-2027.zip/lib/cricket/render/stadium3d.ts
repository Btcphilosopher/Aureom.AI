import * as THREE from 'three';
import { WeatherCondition } from '../types';

export interface Stadium3DScene {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  pitchMesh: THREE.Mesh;
  battingStumps: THREE.Group;
  bowlingStumps: THREE.Group;
  bailsBatting: THREE.Mesh[];
  lightsGroup: THREE.Group;
  sunLight: THREE.DirectionalLight;
  ambientLight: THREE.AmbientLight;
  floodlights: THREE.SpotLight[];
}

export function createStadiumScene(
  container: HTMLDivElement,
  weather: WeatherCondition = 'ENGLISH_SUMMER'
): Stadium3DScene {
  const width = container.clientWidth || 800;
  const height = container.clientHeight || 500;

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0xd6e5f0, 0.0035);

  const camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 600);
  // Default Batsman camera: behind batting crease looking toward bowler
  camera.position.set(0, 2.4, -4.5);
  camera.lookAt(0, 1.2, 12);

  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  // 1. Lighting Setup
  const lightsGroup = new THREE.Group();
  scene.add(lightsGroup);

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
  lightsGroup.add(ambientLight);

  const sunLight = new THREE.DirectionalLight(0xfffaed, 1.3);
  sunLight.position.set(35, 60, 25);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.width = 2048;
  sunLight.shadow.mapSize.height = 2048;
  sunLight.shadow.camera.near = 10;
  sunLight.shadow.camera.far = 150;
  sunLight.shadow.camera.left = -50;
  sunLight.shadow.camera.right = 50;
  sunLight.shadow.camera.top = 50;
  sunLight.shadow.camera.bottom = -50;
  sunLight.shadow.bias = -0.0005;
  lightsGroup.add(sunLight);

  // Floodlights for night matches
  const floodlights: THREE.SpotLight[] = [];
  const floodlightPositions = [
    { x: 55, y: 35, z: 55 },
    { x: -55, y: 35, z: 55 },
    { x: 55, y: 35, z: -45 },
    { x: -55, y: 35, z: -45 },
  ];
  floodlightPositions.forEach((pos) => {
    const spot = new THREE.SpotLight(0xffffff, 0, 140, Math.PI / 4, 0.4);
    spot.position.set(pos.x, pos.y, pos.z);
    spot.target.position.set(0, 0, 10);
    lightsGroup.add(spot);
    lightsGroup.add(spot.target);
    floodlights.push(spot);
  });

  applyWeatherLighting(weather, scene, sunLight, ambientLight, floodlights);

  // 2. Outfield & Grass with Mowing Rings
  const outfieldRadius = 72;
  const outfieldGeo = new THREE.CircleGeometry(outfieldRadius, 64);
  const outfieldMat = new THREE.MeshStandardMaterial({
    color: 0x3d7e35,
    roughness: 0.9,
    metalness: 0.05,
  });
  const outfield = new THREE.Mesh(outfieldGeo, outfieldMat);
  outfield.rotation.x = -Math.PI / 2;
  outfield.position.set(0, 0, 10);
  outfield.receiveShadow = true;
  scene.add(outfield);

  // Striped mowing lawn rings
  for (let r = 10; r < outfieldRadius; r += 7) {
    const ringGeo = new THREE.RingGeometry(r, r + 3.5, 64);
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0x488d3e,
      roughness: 0.92,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(0, 0.002, 10);
    ring.receiveShadow = true;
    scene.add(ring);
  }

  // 3. Pitch Square & Main Pitch Strip
  // Pitch dimensions: 22 yards (20.12m) long, 3.05m wide
  const pitchGeo = new THREE.PlaneGeometry(3.2, 22.5);
  const pitchMat = new THREE.MeshStandardMaterial({
    color: 0xd3b88c, // Authentic golden-brown English turf
    roughness: 0.96,
  });
  const pitchMesh = new THREE.Mesh(pitchGeo, pitchMat);
  pitchMesh.rotation.x = -Math.PI / 2;
  pitchMesh.position.set(0, 0.005, 10.06);
  pitchMesh.receiveShadow = true;
  scene.add(pitchMesh);

  // Crease Markings (White painted lines)
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

  // Batting end popping crease (z = 1.22m, width 3.66m)
  const battingPopping = new THREE.Mesh(new THREE.PlaneGeometry(3.66, 0.08), lineMat);
  battingPopping.rotation.x = -Math.PI / 2;
  battingPopping.position.set(0, 0.008, 1.22);
  scene.add(battingPopping);

  // Batting bowling crease (z = 0, width 2.64m)
  const battingBowlingCrease = new THREE.Mesh(new THREE.PlaneGeometry(2.64, 0.06), lineMat);
  battingBowlingCrease.rotation.x = -Math.PI / 2;
  battingBowlingCrease.position.set(0, 0.008, 0);
  scene.add(battingBowlingCrease);

  // Bowling end popping crease (z = 18.9m)
  const bowlingPopping = new THREE.Mesh(new THREE.PlaneGeometry(3.66, 0.08), lineMat);
  bowlingPopping.rotation.x = -Math.PI / 2;
  bowlingPopping.position.set(0, 0.008, 18.9);
  scene.add(bowlingPopping);

  // Bowling end bowling crease (z = 20.12m)
  const bowlingBowlingCrease = new THREE.Mesh(new THREE.PlaneGeometry(2.64, 0.06), lineMat);
  bowlingBowlingCrease.rotation.x = -Math.PI / 2;
  bowlingBowlingCrease.position.set(0, 0.008, 20.12);
  scene.add(bowlingBowlingCrease);

  // 4. Stumps & Bails at both ends
  const battingStumps = createStumpsGroup();
  battingStumps.position.set(0, 0, 0);
  scene.add(battingStumps);

  const bowlingStumps = createStumpsGroup();
  bowlingStumps.position.set(0, 0, 20.12);
  bowlingStumps.rotation.y = Math.PI;
  scene.add(bowlingStumps);

  const bailsBatting = (battingStumps.userData.bails as THREE.Mesh[]) || [];

  // 5. Boundary Rope & Foam Wedges
  const ropeCurve = new THREE.EllipseCurve(0, 10, outfieldRadius - 2.5, outfieldRadius - 2.5, 0, 2 * Math.PI, false, 0);
  const points = ropeCurve.getPoints(120);
  const ropeGeo = new THREE.BufferGeometry().setFromPoints(points.map((p) => new THREE.Vector3(p.x, 0.06, p.y)));
  const ropeMat = new THREE.LineBasicMaterial({ color: 0xffffff, linewidth: 3 });
  const boundaryLine = new THREE.Line(ropeGeo, ropeMat);
  scene.add(boundaryLine);

  // Foam boundary wedge boards around circumference
  const numBoards = 36;
  const boardGeo = new THREE.BoxGeometry(3.0, 0.35, 0.35);
  const boardMat1 = new THREE.MeshStandardMaterial({ color: 0x002244 });
  const boardMat2 = new THREE.MeshStandardMaterial({ color: 0x880015 });

  for (let i = 0; i < numBoards; i++) {
    const angle = (i / numBoards) * Math.PI * 2;
    const bx = Math.sin(angle) * (outfieldRadius - 1.8);
    const bz = 10 + Math.cos(angle) * (outfieldRadius - 1.8);
    const board = new THREE.Mesh(boardGeo, i % 2 === 0 ? boardMat1 : boardMat2);
    board.position.set(bx, 0.18, bz);
    board.rotation.y = angle + Math.PI / 2;
    board.castShadow = true;
    scene.add(board);
  }

  // 6. English County Pavilion (Historic Red Brick facade & Clock Tower)
  const pavilion = createEnglishPavilion();
  pavilion.position.set(0, 0, outfieldRadius + 14);
  scene.add(pavilion);

  // 7. White Sight Screens behind bowler & batter
  const sightScreenBowler = createSightScreen();
  sightScreenBowler.position.set(0, 0, outfieldRadius - 4);
  scene.add(sightScreenBowler);

  const sightScreenBatter = createSightScreen();
  sightScreenBatter.position.set(0, 0, -outfieldRadius + 22);
  sightScreenBatter.rotation.y = Math.PI;
  scene.add(sightScreenBatter);

  // 8. Electronic Stadium Scoreboard
  const scoreboard = createScoreboardMesh();
  scoreboard.position.set(-outfieldRadius + 14, 0, 25);
  scoreboard.rotation.y = Math.PI / 3;
  scene.add(scoreboard);

  // 9. Grandstand tiers around perimeter
  createSpectatorStands(scene, outfieldRadius);

  return {
    scene,
    camera,
    renderer,
    pitchMesh,
    battingStumps,
    bowlingStumps,
    bailsBatting,
    lightsGroup,
    sunLight,
    ambientLight,
    floodlights,
  };
}

function createStumpsGroup(): THREE.Group {
  const group = new THREE.Group();
  const stumpMat = new THREE.MeshStandardMaterial({ color: 0xdeb887, roughness: 0.6 });
  const stumpRadius = 0.018;
  const stumpHeight = 0.71;

  // 3 Stumps: Off (+0.11m), Middle (0), Leg (-0.11m)
  const stumpMeshes: THREE.Mesh[] = [];
  [-0.11, 0, 0.11].forEach((xOffset) => {
    const stumpGeo = new THREE.CylinderGeometry(stumpRadius, stumpRadius, stumpHeight, 16);
    const stump = new THREE.Mesh(stumpGeo, stumpMat);
    stump.position.set(xOffset, stumpHeight / 2, 0);
    stump.castShadow = true;
    group.add(stump);
    stumpMeshes.push(stump);
  });

  // 2 Bails resting on top
  const bailGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.11, 8);
  const bailMat = new THREE.MeshStandardMaterial({ color: 0xedd59e, roughness: 0.5 });

  const bail1 = new THREE.Mesh(bailGeo, bailMat);
  bail1.rotation.z = Math.PI / 2;
  bail1.position.set(-0.055, stumpHeight + 0.009, 0);
  bail1.castShadow = true;
  group.add(bail1);

  const bail2 = new THREE.Mesh(bailGeo, bailMat);
  bail2.rotation.z = Math.PI / 2;
  bail2.position.set(0.055, stumpHeight + 0.009, 0);
  bail2.castShadow = true;
  group.add(bail2);

  group.userData = { bails: [bail1, bail2], stumps: stumpMeshes };
  return group;
}

function createEnglishPavilion(): THREE.Group {
  const pav = new THREE.Group();

  // Brick body
  const bodyGeo = new THREE.BoxGeometry(32, 12, 14);
  const brickMat = new THREE.MeshStandardMaterial({ color: 0x8a3324, roughness: 0.9 });
  const body = new THREE.Mesh(bodyGeo, brickMat);
  body.position.set(0, 6, 0);
  body.castShadow = true;
  pav.add(body);

  // White Balcony
  const balconyGeo = new THREE.BoxGeometry(26, 1.2, 4);
  const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf5f5f5, roughness: 0.5 });
  const balcony = new THREE.Mesh(balconyGeo, whiteMat);
  balcony.position.set(0, 7.5, -6);
  balcony.castShadow = true;
  pav.add(balcony);

  // Clock Tower on top
  const towerGeo = new THREE.BoxGeometry(6, 7, 6);
  const tower = new THREE.Mesh(towerGeo, brickMat);
  tower.position.set(0, 15.5, 0);
  tower.castShadow = true;
  pav.add(tower);

  // Clock face
  const clockGeo = new THREE.CircleGeometry(1.6, 24);
  const clockMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const clock = new THREE.Mesh(clockGeo, clockMat);
  clock.position.set(0, 16.5, -3.05);
  pav.add(clock);

  // Roof slate
  const roofGeo = new THREE.ConeGeometry(4.5, 3.5, 4);
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.set(0, 20.5, 0);
  roof.rotation.y = Math.PI / 4;
  pav.add(roof);

  return pav;
}

function createSightScreen(): THREE.Group {
  const group = new THREE.Group();
  const screenGeo = new THREE.BoxGeometry(8.5, 4.5, 0.25);
  const whiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
  const screen = new THREE.Mesh(screenGeo, whiteMat);
  screen.position.set(0, 2.3, 0);
  screen.castShadow = true;
  group.add(screen);

  // Wheels / legs
  const legGeo = new THREE.CylinderGeometry(0.12, 0.12, 1.5);
  const legMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
  [-3.5, 3.5].forEach((x) => {
    const leg = new THREE.Mesh(legGeo, legMat);
    leg.position.set(x, 0.75, 0);
    group.add(leg);
  });

  return group;
}

function createScoreboardMesh(): THREE.Group {
  const group = new THREE.Group();

  const boardGeo = new THREE.BoxGeometry(14, 8, 1.2);
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x111827 });
  const board = new THREE.Mesh(boardGeo, darkMat);
  board.position.set(0, 6, 0);
  board.castShadow = true;
  group.add(board);

  // Screen display LED background
  const ledGeo = new THREE.PlaneGeometry(12.8, 6.8);
  const ledMat = new THREE.MeshBasicMaterial({ color: 0x050c18 });
  const led = new THREE.Mesh(ledGeo, ledMat);
  led.position.set(0, 6, 0.62);
  group.add(led);

  return group;
}

function createSpectatorStands(scene: THREE.Scene, radius: number) {
  const standAngles = [
    Math.PI * 0.25,
    Math.PI * 0.45,
    Math.PI * 0.75,
    Math.PI * 1.25,
    Math.PI * 1.55,
    Math.PI * 1.75,
  ];

  const standGeo = new THREE.BoxGeometry(28, 9, 12);
  const standMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
  const seatMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.6 });

  standAngles.forEach((angle) => {
    const group = new THREE.Group();
    const bx = Math.sin(angle) * (radius + 10);
    const bz = 10 + Math.cos(angle) * (radius + 10);

    const base = new THREE.Mesh(standGeo, standMat);
    base.position.set(0, 4.5, 0);
    base.castShadow = true;
    group.add(base);

    // Tiered colorful seats
    const tierGeo = new THREE.BoxGeometry(26, 0.8, 2.5);
    for (let t = 0; t < 3; t++) {
      const tier = new THREE.Mesh(tierGeo, seatMat);
      tier.position.set(0, 4.5 + t * 2, -3.5 + t * 3.5);
      group.add(tier);
    }

    group.position.set(bx, 0, bz);
    group.rotation.y = angle + Math.PI;
    scene.add(group);
  });
}

export function applyWeatherLighting(
  weather: WeatherCondition,
  scene: THREE.Scene,
  sun: THREE.DirectionalLight,
  ambient: THREE.AmbientLight,
  floodlights: THREE.SpotLight[]
) {
  if (weather === 'SUNNY') {
    scene.background = new THREE.Color(0x87ceeb); // Clear Blue English sky
    sun.color.setHex(0xfffaed);
    sun.intensity = 1.45;
    ambient.intensity = 0.65;
    floodlights.forEach((f) => (f.intensity = 0));
  } else if (weather === 'OVERCAST') {
    scene.background = new THREE.Color(0xa8b8c8); // Classic gray/silver English cloud cover
    sun.color.setHex(0xe8edf2);
    sun.intensity = 0.85;
    ambient.intensity = 0.8;
    floodlights.forEach((f) => (f.intensity = 0));
  } else if (weather === 'DRIZZLE') {
    scene.background = new THREE.Color(0x8c9ea8);
    sun.intensity = 0.55;
    ambient.intensity = 0.85;
    floodlights.forEach((f) => (f.intensity = 0));
  } else if (weather === 'FLOODLIT_EVENING') {
    scene.background = new THREE.Color(0x0a1428); // Twilight dark blue
    sun.intensity = 0.2;
    ambient.intensity = 0.4;
    floodlights.forEach((f) => (f.intensity = 1.8)); // Blaze floodlight pylons!
  } else {
    // ENGLISH_SUMMER (warm sun with soft clouds)
    scene.background = new THREE.Color(0x99d4f0);
    sun.color.setHex(0xfff7e6);
    sun.intensity = 1.35;
    ambient.intensity = 0.68;
    floodlights.forEach((f) => (f.intensity = 0));
  }
}
