import * as THREE from 'three';
import { CameraViewMode, Vector3D } from '../types';
import { Player3DMesh } from './characters3d';

// ==========================================
// 1. DYNAMIC BALL MOTION TRAIL (HIGH-SPEED BLUR)
// ==========================================

export interface BallTrailFX {
  mesh: THREE.Line;
  geometry: THREE.BufferGeometry;
  positions: Float32Array;
  colors: Float32Array;
  maxPoints: number;
  currentPoints: number;
}

export function createBallTrailFX(scene: THREE.Scene, maxPoints = 16): BallTrailFX {
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(maxPoints * 3);
  const colors = new Float32Array(maxPoints * 4); // RGBA

  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 4));

  const material = new THREE.LineBasicMaterial({
    vertexColors: true,
    transparent: true,
    blending: THREE.AdditiveBlending,
    linewidth: 2,
    depthWrite: false,
  });

  const mesh = new THREE.Line(geometry, material);
  mesh.frustumCulled = false;
  scene.add(mesh);

  return { mesh, geometry, positions, colors, maxPoints, currentPoints: 0 };
}

export function updateBallTrailFX(trail: BallTrailFX, ballPos: Vector3D | null, speedMps: number, active: boolean) {
  if (!active || !ballPos || speedMps < 12) {
    // Fade out trail when slow or inactive
    trail.currentPoints = 0;
    trail.mesh.visible = false;
    return;
  }

  trail.mesh.visible = true;

  // Shift existing positions back
  const pos = trail.positions;
  const col = trail.colors;
  const n = Math.min(trail.currentPoints + 1, trail.maxPoints);
  trail.currentPoints = n;

  for (let i = n - 1; i > 0; i--) {
    pos[i * 3] = pos[(i - 1) * 3];
    pos[i * 3 + 1] = pos[(i - 1) * 3 + 1];
    pos[i * 3 + 2] = pos[(i - 1) * 3 + 2];

    const alpha = Math.max(0, 1 - i / n) * 0.8;
    col[i * 4] = 1.0; // R
    col[i * 4 + 1] = 0.85; // G
    col[i * 4 + 2] = 0.5; // B (Golden-white streak)
    col[i * 4 + 3] = alpha;
  }

  // Set head at current ball position
  pos[0] = ballPos.x;
  pos[1] = ballPos.y;
  pos[2] = ballPos.z;
  col[0] = 1.0;
  col[1] = 0.95;
  col[2] = 0.8;
  col[3] = 0.95;

  trail.geometry.attributes.position.needsUpdate = true;
  trail.geometry.attributes.color.needsUpdate = true;
  trail.geometry.setDrawRange(0, n);
}

// ==========================================
// 2. PITCH DUST PUFF PARTICLES
// ==========================================

interface DustParticle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
}

export interface PitchDustFX {
  group: THREE.Group;
  particles: DustParticle[];
  meshPool: THREE.Mesh[];
}

export function createPitchDustFX(scene: THREE.Scene, poolSize = 24): PitchDustFX {
  const group = new THREE.Group();
  scene.add(group);

  const geo = new THREE.SphereGeometry(0.045, 6, 6);
  const mat = new THREE.MeshBasicMaterial({
    color: 0xc4a470, // Chalk / dry turf dust color
    transparent: true,
    opacity: 0.8,
    depthWrite: false,
  });

  const meshPool: THREE.Mesh[] = [];
  for (let i = 0; i < poolSize; i++) {
    const m = new THREE.Mesh(geo, mat.clone());
    m.visible = false;
    group.add(m);
    meshPool.push(m);
  }

  return { group, particles: [], meshPool };
}

export function triggerPitchDust(dust: PitchDustFX, pos: Vector3D, intensity = 1.0) {
  const count = Math.min(8, Math.round(5 * intensity));
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 0.4 + Math.random() * 0.8;
    dust.particles.push({
      x: pos.x + (Math.random() - 0.5) * 0.05,
      y: Math.max(0.02, pos.y),
      z: pos.z + (Math.random() - 0.5) * 0.05,
      vx: Math.cos(angle) * speed,
      vy: 0.6 + Math.random() * 0.8,
      vz: Math.sin(angle) * speed,
      life: 0,
      maxLife: 0.35 + Math.random() * 0.25,
      size: 0.04 + Math.random() * 0.03,
    });
  }
}

export function updatePitchDust(dust: PitchDustFX, dt: number) {
  for (let i = dust.particles.length - 1; i >= 0; i--) {
    const p = dust.particles[i];
    p.life += dt;
    if (p.life >= p.maxLife) {
      dust.particles.splice(i, 1);
      continue;
    }

    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;
    p.vy -= 4.0 * dt; // gravity deceleration
    p.vx *= 0.94; // air resistance
    p.vz *= 0.94;
  }

  // Update mesh pool
  for (let i = 0; i < dust.meshPool.length; i++) {
    const m = dust.meshPool[i];
    if (i < dust.particles.length) {
      const p = dust.particles[i];
      m.position.set(p.x, p.y, p.z);
      const progress = p.life / p.maxLife;
      const scale = 1.0 + progress * 2.2;
      m.scale.set(scale, scale, scale);
      (m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.75 * (1 - progress));
      m.visible = true;
    } else {
      m.visible = false;
    }
  }
}

// ==========================================
// 3. WILLOW IMPACT SPARK / FLASH
// ==========================================

export interface WillowImpactFX {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  active: boolean;
}

export function createWillowImpactFX(scene: THREE.Scene): WillowImpactFX {
  const geo = new THREE.RingGeometry(0.02, 0.14, 16);
  const mat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.9,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.visible = false;
  scene.add(mesh);

  return { mesh, life: 0, maxLife: 0.18, active: false };
}

export function triggerWillowImpact(fx: WillowImpactFX, pos: Vector3D) {
  fx.mesh.position.set(pos.x, pos.y, pos.z);
  fx.mesh.scale.set(0.5, 0.5, 0.5);
  fx.life = 0;
  fx.active = true;
  fx.mesh.visible = true;
}

export function updateWillowImpact(fx: WillowImpactFX, dt: number) {
  if (!fx.active) return;
  fx.life += dt;
  if (fx.life >= fx.maxLife) {
    fx.active = false;
    fx.mesh.visible = false;
    return;
  }
  const progress = fx.life / fx.maxLife;
  const s = 0.5 + progress * 2.5;
  fx.mesh.scale.set(s, s, s);
  (fx.mesh.material as THREE.MeshBasicMaterial).opacity = 0.9 * (1 - progress);
}

// ==========================================
// 4. PHYSICAL FLYING BAILS & CARTWHEELING STUMPS
// ==========================================

export interface BailPhysicsState {
  mesh: THREE.Mesh;
  initialPos: THREE.Vector3;
  initialRot: THREE.Euler;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  rotVel: THREE.Vector3;
  isDislodged: boolean;
}

export interface StumpPhysicsState {
  stumpsGroup: THREE.Group;
  bails: BailPhysicsState[];
  stumpMeshes: {
    mesh: THREE.Mesh;
    initialRot: THREE.Euler;
    targetRotX: number;
    currentRotX: number;
  }[];
  isShattered: boolean;
}

export function initStumpPhysics(stumpsGroup: THREE.Group): StumpPhysicsState {
  const bails: BailPhysicsState[] = [];
  const rawBails = (stumpsGroup.userData.bails as THREE.Mesh[]) || [];

  rawBails.forEach((mesh) => {
    bails.push({
      mesh,
      initialPos: mesh.position.clone(),
      initialRot: mesh.rotation.clone(),
      pos: mesh.position.clone(),
      vel: new THREE.Vector3(0, 0, 0),
      rotVel: new THREE.Vector3(0, 0, 0),
      isDislodged: false,
    });
  });

  const stumpMeshes: {
    mesh: THREE.Mesh;
    initialRot: THREE.Euler;
    targetRotX: number;
    currentRotX: number;
  }[] = [];

  const rawStumps = (stumpsGroup.userData.stumps as THREE.Mesh[]) || [];
  rawStumps.forEach((mesh) => {
    stumpMeshes.push({
      mesh,
      initialRot: mesh.rotation.clone(),
      targetRotX: 0,
      currentRotX: 0,
    });
  });

  return {
    stumpsGroup,
    bails,
    stumpMeshes,
    isShattered: false,
  };
}

export function triggerStumpShatter(state: StumpPhysicsState, ballVelocity?: Vector3D) {
  if (state.isShattered) return;
  state.isShattered = true;

  const bvx = ballVelocity ? ballVelocity.x * 0.2 : 0;
  const bvz = ballVelocity ? Math.min(-2, ballVelocity.z * 0.18) : -3.5;

  // Launch bails high into the air!
  state.bails.forEach((bail, idx) => {
    bail.isDislodged = true;
    bail.pos.copy(bail.mesh.position);
    bail.vel.set(
      (idx === 0 ? -1.2 : 1.2) + (Math.random() - 0.5) * 1.5 + bvx,
      3.2 + Math.random() * 2.0, // Launch up!
      bvz - Math.random() * 1.8
    );
    bail.rotVel.set(
      15 + Math.random() * 20,
      12 + Math.random() * 15,
      18 + Math.random() * 15
    );
  });

  // Tilt middle or off stump back
  state.stumpMeshes.forEach((stump, idx) => {
    if (idx === 1) {
      // Middle stump knocked hard backwards
      stump.targetRotX = -0.55 - Math.random() * 0.25;
    } else if (idx === 0) {
      // Off stump tilted slightly outward
      stump.targetRotX = -0.28 - Math.random() * 0.15;
    }
  });
}

export function updateStumpPhysics(state: StumpPhysicsState, dt: number) {
  if (!state.isShattered) return;

  // Animate bails flying and bouncing on pitch
  state.bails.forEach((bail) => {
    if (!bail.isDislodged) return;

    // Gravity
    bail.vel.y -= 9.81 * dt;
    bail.pos.addScaledVector(bail.vel, dt);

    // Ground collision
    if (bail.pos.y <= 0.02) {
      bail.pos.y = 0.02;
      bail.vel.y = -bail.vel.y * 0.35; // bounce restitution
      bail.vel.x *= 0.65;
      bail.vel.z *= 0.65;
      bail.rotVel.multiplyScalar(0.7);
    }

    bail.mesh.position.copy(bail.pos);
    bail.mesh.rotation.x += bail.rotVel.x * dt;
    bail.mesh.rotation.y += bail.rotVel.y * dt;
    bail.mesh.rotation.z += bail.rotVel.z * dt;
  });

  // Smoothly tilt stumps
  state.stumpMeshes.forEach((stump) => {
    if (Math.abs(stump.currentRotX - stump.targetRotX) > 0.01) {
      stump.currentRotX += (stump.targetRotX - stump.currentRotX) * dt * 8.0;
      stump.mesh.rotation.x = stump.currentRotX;
    }
  });
}

export function resetStumpPhysics(state: StumpPhysicsState) {
  state.isShattered = false;
  state.bails.forEach((bail) => {
    bail.isDislodged = false;
    bail.pos.copy(bail.initialPos);
    bail.mesh.position.copy(bail.initialPos);
    bail.mesh.rotation.copy(bail.initialRot);
    bail.vel.set(0, 0, 0);
    bail.rotVel.set(0, 0, 0);
  });

  state.stumpMeshes.forEach((stump) => {
    stump.targetRotX = 0;
    stump.currentRotX = 0;
    stump.mesh.rotation.copy(stump.initialRot);
  });
}

// ==========================================
// 5. DYNAMIC BROADCAST CAMERA DIRECTOR
// ==========================================

export interface BroadcastCameraDirector {
  currentPos: THREE.Vector3;
  currentTarget: THREE.Vector3;
  desiredPos: THREE.Vector3;
  desiredTarget: THREE.Vector3;
  shakeTime: number;
  shakeIntensity: number;
}

export function createCameraDirector(cam: THREE.PerspectiveCamera): BroadcastCameraDirector {
  return {
    currentPos: cam.position.clone(),
    currentTarget: new THREE.Vector3(0, 1.2, 10),
    desiredPos: cam.position.clone(),
    desiredTarget: new THREE.Vector3(0, 1.2, 10),
    shakeTime: 0,
    shakeIntensity: 0,
  };
}

export function triggerCameraShake(director: BroadcastCameraDirector, intensity = 0.08, duration = 0.25) {
  director.shakeIntensity = intensity;
  director.shakeTime = duration;
}

export function updateBroadcastCamera(
  director: BroadcastCameraDirector,
  cam: THREE.PerspectiveCamera,
  mode: CameraViewMode,
  phase: string,
  ballPos: Vector3D | null,
  ballVel: Vector3D | null,
  isLofted: boolean,
  dt: number
) {
  // Compute desired camera and target based on mode & phase
  if (mode === 'BATSMAN') {
    if (phase === 'RUNUP') {
      // Dynamic zoom-in tracking the bowler approaching
      director.desiredPos.set(0, 2.35, -4.8);
      director.desiredTarget.set(0, 1.4, 18);
    } else if (phase === 'IN_FLIGHT') {
      // Focused tight on the delivery corridor
      director.desiredPos.set(0, 2.2, -4.4);
      director.desiredTarget.set(0, 1.1, 10);
    } else if (phase === 'FIELDING' && ballPos) {
      // Smoothly pan with the ball as it travels across the outfield!
      const ballDist = Math.hypot(ballPos.x, ballPos.z);
      const camElev = isLofted ? Math.max(3.2, ballPos.y + 1.8) : 2.6;

      director.desiredPos.set(
        ballPos.x * 0.35,
        camElev,
        -4.0 + Math.min(6.0, ballPos.z * 0.15)
      );
      director.desiredTarget.set(ballPos.x, Math.max(0.4, ballPos.y), ballPos.z);
    } else if (phase === 'REPLAY') {
      // Cinematic low hero angle
      director.desiredPos.set(1.6, 1.2, -1.8);
      director.desiredTarget.set(0.1, 1.1, 1.22);
    } else {
      // IDLE
      director.desiredPos.set(0, 2.3, -4.5);
      director.desiredTarget.set(0, 1.2, 14);
    }
  } else if (mode === 'BOWLER') {
    if (phase === 'IN_FLIGHT' || phase === 'FIELDING') {
      if (ballPos) {
        director.desiredPos.set(0.6 + ballPos.x * 0.1, 2.6, 25);
        director.desiredTarget.set(ballPos.x * 0.8, Math.max(0.5, ballPos.y), ballPos.z);
      }
    } else {
      director.desiredPos.set(0.6, 2.5, 26);
      director.desiredTarget.set(0, 0.8, 0);
    }
  } else if (mode === 'BROADCAST') {
    if (ballPos && (phase === 'IN_FLIGHT' || phase === 'FIELDING')) {
      // Grandstand TV camera tracking
      director.desiredPos.set(24, 15, 10);
      director.desiredTarget.set(ballPos.x * 0.7, ballPos.y * 0.5, ballPos.z);
    } else {
      director.desiredPos.set(22, 14, 10);
      director.desiredTarget.set(0, 0.5, 10);
    }
  } else if (mode === 'WICKET_CAM') {
    director.desiredPos.set(0, 0.45, 0.2);
    if (ballPos && phase === 'IN_FLIGHT') {
      director.desiredTarget.set(ballPos.x, ballPos.y, ballPos.z);
    } else {
      director.desiredTarget.set(0, 1.4, 20);
    }
  } else if (mode === 'FIELDING') {
    if (ballPos) {
      director.desiredPos.set(ballPos.x + 8, 5.5, ballPos.z - 6);
      director.desiredTarget.set(ballPos.x, ballPos.y, ballPos.z);
    } else {
      director.desiredPos.set(12, 6, -2);
      director.desiredTarget.set(0, 0.8, 8);
    }
  } else if (mode === 'DRS_HAWKEYE') {
    director.desiredPos.set(8.5, 2.2, 5.0);
    director.desiredTarget.set(0, 0.5, 0);
  }

  // Smooth lerp towards desired position & target (Broadcast camera dampening)
  const lerpSpeed = phase === 'FIELDING' ? 6.0 : 4.5;
  director.currentPos.lerp(director.desiredPos, Math.min(1.0, dt * lerpSpeed));
  director.currentTarget.lerp(director.desiredTarget, Math.min(1.0, dt * (lerpSpeed + 1.0)));

  // Camera shake (e.g. stump timber shatter)
  let shakeX = 0;
  let shakeY = 0;
  if (director.shakeTime > 0) {
    director.shakeTime -= dt;
    const progress = director.shakeTime / 0.25;
    const s = director.shakeIntensity * progress;
    shakeX = (Math.random() - 0.5) * s;
    shakeY = (Math.random() - 0.5) * s;
  }

  cam.position.set(
    director.currentPos.x + shakeX,
    director.currentPos.y + shakeY,
    director.currentPos.z
  );
  cam.lookAt(director.currentTarget);
}
