import * as THREE from 'three';
import { CricketPlayer, FielderPosition, ShotType, Vector3D } from '../types';

export interface Player3DMesh {
  root: THREE.Group;
  torso: THREE.Mesh;
  head: THREE.Mesh;
  leftArm: THREE.Group;
  lowerLeftArm?: THREE.Group;
  rightArm: THREE.Group;
  lowerRightArm?: THREE.Group;
  leftLeg: THREE.Group;
  lowerLeftLeg?: THREE.Group;
  rightLeg: THREE.Group;
  lowerRightLeg?: THREE.Group;
  bat?: THREE.Group;
  isBatter?: boolean;
  isBowler?: boolean;
  isKeeper?: boolean;
}

export function createPlayerMesh(
  player: CricketPlayer,
  kitColor: string = '#ffffff',
  trimColor: string = '#1e3a8a',
  isBatter: boolean = false,
  isKeeper: boolean = false,
  isBowler: boolean = false
): Player3DMesh {
  const root = new THREE.Group();

  const kitMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(kitColor), roughness: 0.7 });
  const trimMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(trimColor), roughness: 0.6 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xd29a73, roughness: 0.8 });
  const padMat = new THREE.MeshStandardMaterial({ color: kitColor === '#ffffff' ? 0xf0f0f0 : trimColor, roughness: 0.7 });
  const gloveMat = new THREE.MeshStandardMaterial({ color: kitColor === '#ffffff' ? 0xffffff : trimColor, roughness: 0.5 });

  // 1. Torso
  const torsoGeo = new THREE.BoxGeometry(0.42, 0.58, 0.24);
  const torso = new THREE.Mesh(torsoGeo, kitMat);
  torso.position.y = 1.15;
  torso.castShadow = true;
  root.add(torso);

  // Collar/V-neck trim
  const collarGeo = new THREE.BoxGeometry(0.24, 0.08, 0.25);
  const collar = new THREE.Mesh(collarGeo, trimMat);
  collar.position.set(0, 0.26, 0);
  torso.add(collar);

  // 2. Head & Helmet / Cap
  const headGeo = new THREE.SphereGeometry(0.12, 16, 16);
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 1.56;
  head.castShadow = true;
  root.add(head);

  if (isBatter || isKeeper) {
    // English County Batting/Keeping Helmet with grill
    const helmetGeo = new THREE.SphereGeometry(0.135, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.65);
    const helmetMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(trimColor), roughness: 0.4 });
    const helmet = new THREE.Mesh(helmetGeo, helmetMat);
    helmet.position.set(0, 0.02, 0);
    head.add(helmet);

    // Peak
    const peakGeo = new THREE.BoxGeometry(0.16, 0.02, 0.12);
    const peak = new THREE.Mesh(peakGeo, helmetMat);
    peak.position.set(0, -0.02, 0.12);
    head.add(peak);
  } else {
    // Traditional County Cap
    const capGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.04, 16);
    const capMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(trimColor) });
    const cap = new THREE.Mesh(capGeo, capMat);
    cap.position.set(0, 0.1, 0);
    head.add(cap);

    const peakGeo = new THREE.BoxGeometry(0.14, 0.015, 0.09);
    const peak = new THREE.Mesh(peakGeo, capMat);
    peak.position.set(0, 0.08, 0.1);
    head.add(peak);
  }

  // 3. Legs & Pads with Articulated Knee Joints
  const leftLegData = createLegGroup(kitMat, padMat, isBatter || isKeeper);
  leftLegData.group.position.set(-0.13, 0.86, 0);
  root.add(leftLegData.group);

  const rightLegData = createLegGroup(kitMat, padMat, isBatter || isKeeper);
  rightLegData.group.position.set(0.13, 0.86, 0);
  root.add(rightLegData.group);

  // 4. Arms with Articulated Elbow Joints
  const leftArmData = createArmGroup(kitMat, skinMat, gloveMat, isBatter, isKeeper);
  leftArmData.group.position.set(-0.25, 1.38, 0);
  root.add(leftArmData.group);

  const rightArmData = createArmGroup(kitMat, skinMat, gloveMat, isBatter, isKeeper);
  rightArmData.group.position.set(0.25, 1.38, 0);
  root.add(rightArmData.group);

  // 5. Cricket Bat (attached to right lower arm / wrists for authentic batting pivot)
  let bat: THREE.Group | undefined;
  if (isBatter) {
    bat = createBatMesh();
    rightArmData.lowerArm.add(bat);
    bat.position.set(0.04, -0.28, 0.06);
    bat.rotation.x = -Math.PI * 0.25;
  }

  return {
    root,
    torso,
    head,
    leftArm: leftArmData.group,
    lowerLeftArm: leftArmData.lowerArm,
    rightArm: rightArmData.group,
    lowerRightArm: rightArmData.lowerArm,
    leftLeg: leftLegData.group,
    lowerLeftLeg: leftLegData.lowerLeg,
    rightLeg: rightLegData.group,
    lowerRightLeg: rightLegData.lowerLeg,
    bat,
    isBatter,
    isBowler,
    isKeeper,
  };
}

function createLegGroup(kitMat: THREE.Material, padMat: THREE.Material, hasPads: boolean): { group: THREE.Group; lowerLeg: THREE.Group } {
  const group = new THREE.Group();

  // Thigh (Upper Leg)
  const thighGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.44, 12);
  const thigh = new THREE.Mesh(thighGeo, kitMat);
  thigh.position.y = -0.22;
  thigh.castShadow = true;
  group.add(thigh);

  // Knee Pivot Group
  const lowerLeg = new THREE.Group();
  lowerLeg.position.y = -0.44;
  group.add(lowerLeg);

  // Shin & Cricket Pad
  const shinGeo = new THREE.CylinderGeometry(0.065, 0.06, 0.44, 12);
  const shin = new THREE.Mesh(shinGeo, hasPads ? padMat : kitMat);
  shin.position.y = -0.22;
  shin.castShadow = true;
  lowerLeg.add(shin);

  if (hasPads) {
    // Bulky front batting pad face
    const padFaceGeo = new THREE.BoxGeometry(0.18, 0.52, 0.08);
    const padFace = new THREE.Mesh(padFaceGeo, padMat);
    padFace.position.set(0, -0.18, 0.06);
    padFace.castShadow = true;
    lowerLeg.add(padFace);
  }

  // Shoe/Spikes
  const shoeGeo = new THREE.BoxGeometry(0.12, 0.08, 0.22);
  const shoeMat = new THREE.MeshStandardMaterial({ color: 0xfafafa, roughness: 0.6 });
  const shoe = new THREE.Mesh(shoeGeo, shoeMat);
  shoe.position.set(0, -0.44, 0.04);
  shoe.castShadow = true;
  lowerLeg.add(shoe);

  return { group, lowerLeg };
}

function createArmGroup(
  kitMat: THREE.Material,
  skinMat: THREE.Material,
  gloveMat: THREE.Material,
  isBatter: boolean,
  isKeeper: boolean
): { group: THREE.Group; lowerArm: THREE.Group } {
  const group = new THREE.Group();

  // Upper Arm
  const upperGeo = new THREE.CylinderGeometry(0.065, 0.055, 0.32, 12);
  const upper = new THREE.Mesh(upperGeo, kitMat);
  upper.position.y = -0.16;
  upper.castShadow = true;
  group.add(upper);

  // Elbow Pivot Group
  const lowerArm = new THREE.Group();
  lowerArm.position.y = -0.32;
  group.add(lowerArm);

  // Forearm
  const foreGeo = new THREE.CylinderGeometry(0.05, 0.045, 0.3, 12);
  const fore = new THREE.Mesh(foreGeo, skinMat);
  fore.position.y = -0.15;
  fore.castShadow = true;
  lowerArm.add(fore);

  // Hand / Glove
  const gloveGeo = new THREE.BoxGeometry(0.09, 0.12, 0.09);
  const hand = new THREE.Mesh(gloveGeo, isBatter || isKeeper ? gloveMat : skinMat);
  hand.position.y = -0.31;
  hand.castShadow = true;
  lowerArm.add(hand);

  return { group, lowerArm };
}

function createBatMesh(): THREE.Group {
  const group = new THREE.Group();

  // Cane Handle with colored rubber grip
  const handleGeo = new THREE.CylinderGeometry(0.016, 0.016, 0.28, 12);
  const handleMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
  const handle = new THREE.Mesh(handleGeo, handleMat);
  handle.position.y = 0.14;
  handle.castShadow = true;
  group.add(handle);

  // English Willow Blade (approx 0.85m long, 0.108m wide)
  const bladeGeo = new THREE.BoxGeometry(0.11, 0.72, 0.045);
  const willowMat = new THREE.MeshStandardMaterial({ color: 0xdeb887, roughness: 0.65 });
  const blade = new THREE.Mesh(bladeGeo, willowMat);
  blade.position.y = -0.34;
  blade.castShadow = true;
  group.add(blade);

  // Manufacturer sticker on front & back
  const stickerGeo = new THREE.PlaneGeometry(0.08, 0.22);
  const stickerMat = new THREE.MeshBasicMaterial({ color: 0xb91c1c });
  const sticker = new THREE.Mesh(stickerGeo, stickerMat);
  sticker.position.set(0, -0.22, 0.024);
  group.add(sticker);

  return group;
}

// =========================================================
// BATTER ANIMATION: AUTHENTIC CREASE ROUTINE & SHOT ACTIONS
// =========================================================

export function animateBatter(
  mesh: Player3DMesh,
  swingProgress: number,
  isSwinging: boolean,
  shotAngle: number = 0,
  isLofted: boolean = false,
  shotType: ShotType = 'STRAIGHT_DRIVE',
  footwork: 'FRONT_FOOT' | 'BACK_FOOT' | 'ADVANCE' | 'RETREAT' | 'NEUTRAL' = 'FRONT_FOOT',
  idleTime: number = 0
) {
  if (!mesh.bat) return;

  const lla = mesh.lowerLeftArm;
  const lra = mesh.lowerRightArm;
  const lll = mesh.lowerLeftLeg;
  const lrl = mesh.lowerRightLeg;

  if (isSwinging) {
    // -----------------------------------------------------------
    // A. DRIVES (Straight Drive, Cover Drive, On Drive, Lofted)
    // -----------------------------------------------------------
    if (
      shotType === 'STRAIGHT_DRIVE' ||
      shotType === 'COVER_DRIVE' ||
      shotType === 'ON_DRIVE' ||
      shotType === 'LOFTED_DRIVE'
    ) {
      if (swingProgress < 0.32) {
        // High backlift & front-foot stride forward
        const p = swingProgress / 0.32;
        mesh.leftLeg.rotation.x = 0.15 + 0.45 * p; // front foot forward
        if (lll) lll.rotation.x = -0.55 * p; // front knee flex
        mesh.rightLeg.rotation.x = -0.15 * p; // back leg on toe
        if (lrl) lrl.rotation.x = -0.1 * p;

        mesh.torso.rotation.set(0.12 * p, 0.25 - 0.15 * p, 0);
        mesh.rightArm.rotation.set(-Math.PI * 0.4 - 0.7 * p, 0.3 * p, 0.1);
        if (lra) lra.rotation.x = -0.3 * p;

        mesh.leftArm.rotation.set(-Math.PI * 0.3 - 0.6 * p, -0.4 * p, 0.3);
        if (lla) lla.rotation.x = -0.8 * p; // high top elbow!

        mesh.bat.rotation.set(-Math.PI * 0.5 - 0.6 * p, 0.2 * p, 0);
      } else if (swingProgress < 0.68) {
        // Impact & downswing along the line
        const p = (swingProgress - 0.32) / 0.36;
        const angleOffset = shotType === 'COVER_DRIVE' ? -0.45 : shotType === 'ON_DRIVE' ? 0.35 : shotAngle * 0.5;
        const loftPitch = isLofted ? 0.42 : -0.12;

        mesh.leftLeg.rotation.x = 0.6;
        if (lll) lll.rotation.x = -0.55;
        mesh.rightLeg.rotation.x = -0.2;

        mesh.torso.rotation.set(0.18, angleOffset * 0.6, 0);

        mesh.rightArm.rotation.set(-Math.PI * 0.65 * (1 - p) + (loftPitch + 0.2) * p, angleOffset * p, 0);
        if (lra) lra.rotation.x = -0.2 * (1 - p);

        // Famous high left elbow pointing down ground
        mesh.leftArm.rotation.set(-Math.PI * 0.5 * (1 - p) + (loftPitch + 0.4) * p, -0.3 + angleOffset * 0.4, 0.4);
        if (lla) lla.rotation.x = -0.85;

        mesh.bat.rotation.set(-Math.PI * 0.8 * (1 - p) + loftPitch * p, angleOffset * 0.5, 0);
      } else {
        // Aristocratic High Follow-Through held in pose
        const p = (swingProgress - 0.68) / 0.32;
        const angleOffset = shotType === 'COVER_DRIVE' ? -0.45 : shotType === 'ON_DRIVE' ? 0.35 : shotAngle * 0.5;
        const loftPitch = isLofted ? 0.6 : 0.25;

        mesh.leftLeg.rotation.x = 0.6;
        if (lll) lll.rotation.x = -0.55;
        mesh.rightLeg.rotation.x = -0.2;

        mesh.torso.rotation.set(0.12 * (1 - p), angleOffset * 0.6, 0);
        mesh.rightArm.rotation.set(loftPitch + 0.35 * p, angleOffset, -0.3 * p);
        mesh.leftArm.rotation.set(loftPitch + 0.5 * p, -0.2, 0.45);
        if (lla) lla.rotation.x = -0.85 * (1 - p * 0.3);

        mesh.bat.rotation.set(0.4 + 0.7 * p, angleOffset * 0.6, 0);
      }
    }

    // -----------------------------------------------------------
    // B. CUTS (Square Cut, Late Cut)
    // -----------------------------------------------------------
    else if (shotType === 'SQUARE_CUT' || shotType === 'LATE_CUT') {
      const isLate = shotType === 'LATE_CUT';
      if (swingProgress < 0.35) {
        // Back foot steps back and across
        const p = swingProgress / 0.35;
        mesh.rightLeg.rotation.x = -0.35 * p;
        if (lrl) lrl.rotation.x = -0.25 * p;
        mesh.leftLeg.rotation.x = 0.1 * p;

        mesh.torso.rotation.set(-0.08 * p, 0.45 * p, 0);
        mesh.rightArm.rotation.set(-Math.PI * 0.75 * p, 0.5 * p, -0.4 * p);
        mesh.leftArm.rotation.set(-Math.PI * 0.5 * p, 0.2 * p, 0.3);
        mesh.bat.rotation.set(-Math.PI * 0.9 * p, 0.4 * p, 0);
      } else if (swingProgress < 0.7) {
        // Downward horizontal blade chop across the ball
        const p = (swingProgress - 0.35) / 0.35;
        mesh.torso.rotation.set(0.1 * p, 0.5 - 0.3 * p, 0);
        mesh.rightArm.rotation.set(-Math.PI * 0.75 * (1 - p) + (isLate ? -0.2 : 0.1) * p, 0.6, -0.4);
        mesh.bat.rotation.set(-Math.PI * 0.9 * (1 - p) + (isLate ? -0.1 : 0.3) * p, isLate ? 0.6 : 0.2, 0.4 * p);
      } else {
        // Rolling wrists follow-through past point / third man
        const p = (swingProgress - 0.7) / 0.3;
        mesh.rightArm.rotation.set(0.1 + 0.3 * p, 0.5, -0.5 * p);
        mesh.bat.rotation.set(0.3 + 0.4 * p, 0.3, 0.5);
      }
    }

    // -----------------------------------------------------------
    // C. PULL & HOOK SHOTS
    // -----------------------------------------------------------
    else if (shotType === 'PULL_SHOT' || shotType === 'HOOK_SHOT' || shotType === 'AERIAL_SLOG') {
      if (swingProgress < 0.35) {
        // Weight rocks back, bat lifted high above right shoulder
        const p = swingProgress / 0.35;
        mesh.rightLeg.rotation.x = -0.3 * p;
        if (lrl) lrl.rotation.x = -0.35 * p;
        mesh.leftLeg.rotation.x = 0.15 * p;

        mesh.torso.rotation.set(-0.1 * p, 0.35 + 0.2 * p, 0);
        mesh.rightArm.rotation.set(-Math.PI * 0.85 * p, 0.4 * p, -0.3);
        mesh.leftArm.rotation.set(-Math.PI * 0.65 * p, 0.1, 0.2);
        mesh.bat.rotation.set(-Math.PI * 0.95 * p, 0.2, 0);
      } else if (swingProgress < 0.7) {
        // Powerful 90-degree body swivel to mid-wicket
        const p = (swingProgress - 0.35) / 0.35;
        const swivel = -Math.PI * 0.45 * p;
        mesh.torso.rotation.y = 0.55 + swivel;
        mesh.rightArm.rotation.set(-Math.PI * 0.85 * (1 - p) + 0.15 * p, swivel * 0.6, -0.2);
        mesh.leftArm.rotation.set(-Math.PI * 0.65 * (1 - p) + 0.2 * p, swivel * 0.6, 0.3);
        mesh.bat.rotation.set(-Math.PI * 0.95 * (1 - p) + 0.25 * p, 0.5 * p, 0);
      } else {
        // High swirling follow-through wrapping around left shoulder
        const p = (swingProgress - 0.7) / 0.3;
        mesh.torso.rotation.y = 0.55 - Math.PI * 0.45;
        mesh.rightArm.rotation.set(0.15 + 0.45 * p, -Math.PI * 0.3, -0.6 * p);
        mesh.leftArm.rotation.set(0.2 + 0.35 * p, -Math.PI * 0.2, 0.4);
        mesh.bat.rotation.set(0.25 + 0.6 * p, -0.3, -0.5 * p);
      }
    }

    // -----------------------------------------------------------
    // D. SWEEP & SLOG SWEEP
    // -----------------------------------------------------------
    else if (shotType === 'SWEEP' || shotType === 'SLOG_SWEEP') {
      if (swingProgress < 0.4) {
        // Dropping onto front knee
        const p = swingProgress / 0.4;
        mesh.leftLeg.rotation.x = 0.35 * p;
        if (lll) lll.rotation.x = -1.15 * p; // knee flat on turf
        mesh.rightLeg.rotation.x = -0.5 * p; // trailing back leg
        mesh.torso.position.y = 1.15 - 0.38 * p; // drop height
        mesh.torso.rotation.x = 0.22 * p;

        mesh.rightArm.rotation.set(-Math.PI * 0.6 * p, 0.3 * p, 0);
        mesh.bat.rotation.set(-Math.PI * 0.7 * p, 0, 0);
      } else {
        // Horizontal broom sweep across the turf
        const p = (swingProgress - 0.4) / 0.6;
        mesh.torso.position.y = 1.15 - 0.38;
        mesh.torso.rotation.y = 0.25 - 0.9 * p; // sweep to leg side
        mesh.rightArm.rotation.set(-Math.PI * 0.6 * (1 - p) + 0.2 * p, -0.8 * p, 0);
        mesh.bat.rotation.set(-Math.PI * 0.7 * (1 - p) + 0.4 * p, -0.7 * p, 0);
      }
    }

    // -----------------------------------------------------------
    // E. FORWARD DEFENCE & BACK FOOT DEFENCE
    // -----------------------------------------------------------
    else if (shotType === 'FORWARD_DEFENCE') {
      const p = Math.min(1.0, swingProgress / 0.5);
      mesh.leftLeg.rotation.x = 0.5 * p;
      if (lll) lll.rotation.x = -0.6 * p;
      mesh.torso.rotation.set(0.18 * p, 0.2, 0);

      // Bat and pad pressed flush together, soft hands angled downward
      mesh.rightArm.rotation.set(-Math.PI * 0.35 * (1 - p) - 0.18 * p, 0.1, 0);
      if (lra) lra.rotation.x = -0.35 * p;
      mesh.leftArm.rotation.set(-Math.PI * 0.3 * (1 - p) - 0.22 * p, -0.15, 0.2);
      if (lla) lla.rotation.x = -0.65 * p;

      mesh.bat.rotation.set(-Math.PI * 0.45 * (1 - p) - 0.28 * p, 0.05, 0);
    } else if (shotType === 'BACK_FOOT_DEFENCE') {
      const p = Math.min(1.0, swingProgress / 0.5);
      mesh.rightLeg.rotation.x = -0.25 * p;
      mesh.torso.position.y = 1.15 + 0.05 * p; // rise tall on toes
      mesh.torso.rotation.set(0.05, 0.25, 0);
      mesh.rightArm.rotation.set(-0.25 * p, 0.1, 0);
      mesh.bat.rotation.set(-0.15 * p, 0.05, 0);
    }

    // -----------------------------------------------------------
    // F. LEAVE ALONE
    // -----------------------------------------------------------
    else if (shotType === 'LEAVE') {
      const p = Math.min(1.0, swingProgress / 0.4);
      mesh.torso.rotation.set(-0.12 * p, 0.38, 0); // arch shoulders back
      mesh.rightArm.rotation.set(-Math.PI * 0.85 * p, 0.2, -0.35 * p); // hoist bat under armpit
      mesh.leftArm.rotation.set(-Math.PI * 0.6 * p, -0.2, 0.3);
      mesh.bat.rotation.set(-Math.PI * 0.9 * p, 0, 0);
    }

    // -----------------------------------------------------------
    // G. RAMP / SCOOP
    // -----------------------------------------------------------
    else if (shotType === 'RAMP_SCOOP') {
      const p = Math.min(1.0, swingProgress / 0.6);
      mesh.torso.position.y = 1.15 - 0.35 * p;
      mesh.leftLeg.rotation.x = 0.45 * p;
      if (lll) lll.rotation.x = -0.8 * p;
      mesh.rightArm.rotation.set(0.6 * p, 0.2, 0);
      mesh.bat.rotation.set(0.85 * p, 0.4 * p, 0); // ramp face angled back
    }
  }

  // -----------------------------------------------------------
  // 2. CLASSIC BALANCED BATTING STANCE & CREASE ROUTINE (IDLE)
  // -----------------------------------------------------------
  else {
    mesh.torso.position.y = 1.15;
    mesh.torso.rotation.set(0.04, 0.28, 0); // Traditional side-on stance

    // Natural knee flex
    mesh.leftLeg.rotation.x = 0.1;
    if (lll) lll.rotation.x = -0.16;
    mesh.rightLeg.rotation.x = -0.06;
    if (lrl) lrl.rotation.x = -0.12;

    // Bat tapping rhythm (every 1.25 seconds, batsman taps bat twice on the pitch)
    const tapPeriod = 1.25;
    const tapPhase = (idleTime % tapPeriod) / tapPeriod;
    let batTapAngle = 0;

    if (tapPhase < 0.15) {
      // First tap
      batTapAngle = Math.sin((tapPhase / 0.15) * Math.PI) * 0.18;
    } else if (tapPhase > 0.22 && tapPhase < 0.37) {
      // Second tap
      batTapAngle = Math.sin(((tapPhase - 0.22) / 0.15) * Math.PI) * 0.18;
    }

    mesh.rightArm.rotation.set(-Math.PI * 0.35 + batTapAngle, 0.22, -0.12);
    if (lra) lra.rotation.x = -0.15 + batTapAngle * 0.5;

    mesh.leftArm.rotation.set(-Math.PI * 0.28, -0.2, 0.22);
    if (lla) lla.rotation.x = -0.3;

    mesh.bat.rotation.set(-Math.PI * 0.45 + batTapAngle, 0.1, 0);

    // Head turned watchful down the pitch toward bowler
    mesh.head.rotation.set(0, -0.32, 0);
  }
}

// =========================================================
// BOWLER ANIMATION: 5-PHASE ATHLETIC KINETIC DELIVERY CHAIN
// =========================================================

export function animateBowler(
  mesh: Player3DMesh,
  runupProgress: number, // 0 to 1
  isBowling: boolean,
  bowlerType: string = 'FAST'
) {
  const lll = mesh.lowerLeftLeg;
  const lrl = mesh.lowerRightLeg;
  const lla = mesh.lowerLeftArm;
  const lra = mesh.lowerRightArm;

  if (!isBowling) {
    // Standing poised at top of mark
    mesh.root.position.y = 0;
    mesh.torso.position.y = 1.15;
    mesh.torso.rotation.set(0.08, 0, 0);
    mesh.rightArm.rotation.set(0.2, 0, -0.1);
    mesh.leftArm.rotation.set(0.2, 0, 0.1);
    mesh.leftLeg.rotation.set(0, 0, 0);
    mesh.rightLeg.rotation.set(0, 0, 0);
    if (lll) lll.rotation.x = 0;
    if (lrl) lrl.rotation.x = 0;
    return;
  }

  // Phase 1: Accelerating Runup Strides (0.0 to 0.72)
  if (runupProgress < 0.72) {
    const cycle = (runupProgress / 0.72) * Math.PI * 10;
    const legSwing = Math.sin(cycle) * 0.7;
    const armSwing = Math.sin(cycle) * 0.85;

    mesh.leftLeg.rotation.x = legSwing;
    mesh.rightLeg.rotation.x = -legSwing;

    // Knee flex on kickback
    if (lll) lll.rotation.x = legSwing < 0 ? -Math.abs(legSwing) * 1.2 : 0;
    if (lrl) lrl.rotation.x = legSwing > 0 ? -Math.abs(legSwing) * 1.2 : 0;

    mesh.leftArm.rotation.x = -armSwing;
    mesh.rightArm.rotation.x = armSwing;
    if (lla) lla.rotation.x = -0.5;
    if (lra) lra.rotation.x = -0.5;

    // Running bounce & forward tilt
    mesh.torso.position.y = 1.15 + Math.abs(Math.sin(cycle)) * 0.08;
    mesh.torso.rotation.set(0.18, 0, 0);
  }

  // Phase 2: The Bound & Gather (0.72 to 0.86)
  else if (runupProgress < 0.86) {
    const p = (runupProgress - 0.72) / 0.14;
    // Airborne leap
    mesh.torso.position.y = 1.15 + Math.sin(p * Math.PI) * 0.22;
    mesh.torso.rotation.set(0.1, 0.35 * p, 0); // Coil side-on

    mesh.leftLeg.rotation.x = 0.5 * (1 - p) + 0.2 * p;
    mesh.rightLeg.rotation.x = -0.4 * (1 - p);
    if (lll) lll.rotation.x = -0.6;
    if (lrl) lrl.rotation.x = -0.8;

    // Hands gather near chest
    mesh.leftArm.rotation.set(0.4, 0.3, 0.2);
    mesh.rightArm.rotation.set(0.3, -0.2, -0.2);
    if (lla) lla.rotation.x = -1.2;
    if (lra) lra.rotation.x = -1.2;
  }

  // Phase 3 & 4: Delivery Stride, Front-Foot Brace & 360-degree High-Arm Whip (0.86 to 0.98)
  else if (runupProgress < 0.98) {
    const p = (runupProgress - 0.86) / 0.12;
    mesh.torso.position.y = 1.15;

    // Front foot plants hard on popping crease, front knee braced
    mesh.leftLeg.rotation.x = 0.55;
    if (lll) lll.rotation.x = -0.15; // braced knee!
    mesh.rightLeg.rotation.x = -0.55;
    if (lrl) lrl.rotation.x = -0.7;

    // Non-bowling arm (left) reaches high to 12 o'clock, then pulls down hard to hip
    if (p < 0.4) {
      mesh.leftArm.rotation.set(-Math.PI * 0.95, -0.2, 0.2);
    } else {
      mesh.leftArm.rotation.set(Math.PI * 0.35, -0.2, 0.2);
    }

    // Bowling arm (right) completes full circular windmill whip
    const armAngle = -Math.PI * 2.1 * p;
    mesh.rightArm.rotation.set(armAngle, 0.1, 0);
    if (lra) lra.rotation.x = -0.1;

    // Torso flexes forward violently over braced front knee
    mesh.torso.rotation.set(0.52 * p, -0.15 * p, 0);
  }

  // Phase 5: Natural Follow-Through (0.98 to 1.00+)
  else {
    const p = (runupProgress - 0.98) / 0.02;
    mesh.torso.position.y = 1.15;
    mesh.torso.rotation.set(0.45 - 0.2 * p, 0.2 * p, 0);

    // Cross-crease deceleration stride
    mesh.rightLeg.rotation.x = 0.4;
    mesh.leftLeg.rotation.x = -0.3;
    mesh.rightArm.rotation.set(0.4, 0.2, -0.3);
    mesh.leftArm.rotation.set(0.2, -0.2, 0.3);
  }
}

// =========================================================
// WICKETKEEPER ANIMATION: DYNAMIC CROUCH, RISE & GLOVE TAKE
// =========================================================

export function animateKeeper(
  mesh: Player3DMesh,
  ballPos: Vector3D | null,
  ballZ: number,
  isCollected: boolean = false
) {
  const lll = mesh.lowerLeftLeg;
  const lrl = mesh.lowerRightLeg;
  const lla = mesh.lowerLeftArm;
  const lra = mesh.lowerRightArm;

  if (!ballPos || ballZ > 12) {
    // Athletic deep squat crouch (eyes level with bails)
    mesh.torso.position.y = 0.88;
    mesh.torso.rotation.set(0.35, 0, 0);

    mesh.leftLeg.rotation.x = 0.65;
    if (lll) lll.rotation.x = -1.15;
    mesh.rightLeg.rotation.x = 0.65;
    if (lrl) lrl.rotation.x = -1.15;

    // Gloves cupped ready at knee height
    mesh.leftArm.rotation.set(0.25, 0.15, 0.2);
    mesh.rightArm.rotation.set(0.25, -0.15, -0.2);
    if (lla) lla.rotation.x = -0.9;
    if (lra) lra.rotation.x = -0.9;
  } else {
    // Rising with the bounce as ball nears keeper
    const riseProgress = Math.min(1.0, Math.max(0, (12 - ballZ) / 10));
    const targetY = 0.88 + riseProgress * 0.32;
    mesh.torso.position.y = targetY;
    mesh.torso.rotation.set(0.35 - riseProgress * 0.2, 0, 0);

    mesh.leftLeg.rotation.x = 0.65 - riseProgress * 0.45;
    if (lll) lll.rotation.x = -1.15 + riseProgress * 0.85;
    mesh.rightLeg.rotation.x = 0.65 - riseProgress * 0.45;
    if (lrl) lrl.rotation.x = -1.15 + riseProgress * 0.85;

    // Glove tracking ball position (X and Y)
    const glovePitch = ballPos.y > 1.2 ? -0.4 : 0.2;
    mesh.leftArm.rotation.set(glovePitch, ballPos.x * 0.4, 0.2);
    mesh.rightArm.rotation.set(glovePitch, ballPos.x * 0.4, -0.2);
    if (lla) lla.rotation.x = -0.7;
    if (lra) lra.rotation.x = -0.7;
  }
}

// =========================================================
// FIELDER ANIMATION: SPRINTS, DIVING SLIDES, THROWS & CHEERS
// =========================================================

export function animateFielder(
  mesh: Player3DMesh,
  state: FielderPosition['state'],
  speed: number,
  aimTarget?: Vector3D
) {
  const lll = mesh.lowerLeftLeg;
  const lrl = mesh.lowerRightLeg;
  const lla = mesh.lowerLeftArm;
  const lra = mesh.lowerRightArm;

  if (state === 'CHASING' || state === 'INTERCEPTING') {
    const cycle = Date.now() * 0.014;
    const legSwing = Math.sin(cycle) * 0.75;
    mesh.leftLeg.rotation.x = legSwing;
    mesh.rightLeg.rotation.x = -legSwing;

    if (lll) lll.rotation.x = legSwing < 0 ? -Math.abs(legSwing) * 1.3 : 0;
    if (lrl) lrl.rotation.x = legSwing > 0 ? -Math.abs(legSwing) * 1.3 : 0;

    mesh.leftArm.rotation.x = -Math.sin(cycle) * 0.85;
    mesh.rightArm.rotation.x = Math.sin(cycle) * 0.85;
    if (lla) lla.rotation.x = -0.6;
    if (lra) lra.rotation.x = -0.6;

    mesh.torso.position.y = 1.15 + Math.abs(Math.sin(cycle)) * 0.06;
    mesh.torso.rotation.set(0.24, 0, 0); // forward sprint lean
  } else if (state === 'DIVING') {
    // Authentic knee/thigh sliding boundary cutoff stop
    mesh.torso.position.y = 0.45;
    mesh.torso.rotation.set(Math.PI * 0.42, 0.2, 0);

    mesh.leftLeg.rotation.x = -0.55;
    if (lll) lll.rotation.x = -1.2;
    mesh.rightLeg.rotation.x = 0.65;
    if (lrl) lrl.rotation.x = -0.2;

    // Outstretched arm sweeping to stop boundary
    mesh.leftArm.rotation.set(-Math.PI * 0.5, 0.2, 0.5);
    mesh.rightArm.rotation.set(-Math.PI * 0.5, -0.2, -0.5);
  } else if (state === 'PICKING_UP') {
    // One-handed scoop pickup on the move
    mesh.torso.position.y = 0.75;
    mesh.torso.rotation.set(0.65, 0, 0);
    mesh.leftLeg.rotation.x = 0.4;
    mesh.rightLeg.rotation.x = -0.3;
    mesh.rightArm.rotation.set(0.85, 0, 0); // Reach for ball
  } else if (state === 'THROWING') {
    // Planted stance and powerful arm whip throw
    mesh.torso.position.y = 1.15;
    mesh.torso.rotation.set(0.1, -0.3, 0);
    mesh.leftLeg.rotation.x = 0.4;
    mesh.rightLeg.rotation.x = -0.35;

    mesh.rightArm.rotation.set(-Math.PI * 0.75, 0.2, 0); // Wind up
    mesh.leftArm.rotation.set(0.4, 0.5, 0); // Aiming arm
  } else if (state === 'CELEBRATING') {
    // Arms aloft in joy, jumping
    const jumpCycle = Math.sin(Date.now() * 0.008);
    mesh.torso.position.y = 1.15 + Math.max(0, jumpCycle * 0.2);
    mesh.torso.rotation.set(0, 0, 0);

    mesh.rightArm.rotation.set(Math.PI * 0.85, 0, -0.4);
    mesh.leftArm.rotation.set(Math.PI * 0.85, 0, 0.4);
    if (lra) lra.rotation.x = 0;
    if (lla) lla.rotation.x = 0;

    mesh.leftLeg.rotation.x = jumpCycle * 0.2;
    mesh.rightLeg.rotation.x = -jumpCycle * 0.2;
  } else {
    // Athletic ready crouch (hands on knees, watching batsman)
    mesh.torso.position.y = 1.12;
    mesh.torso.rotation.set(0.18, 0, 0);
    mesh.leftLeg.rotation.x = 0.12;
    if (lll) lll.rotation.x = -0.2;
    mesh.rightLeg.rotation.x = -0.08;
    if (lrl) lrl.rotation.x = -0.15;

    mesh.leftArm.rotation.set(0.32, 0.15, 0.25);
    mesh.rightArm.rotation.set(0.32, -0.15, -0.25);
    if (lla) lla.rotation.x = -0.7;
    if (lra) lra.rotation.x = -0.7;
  }
}
