import * as THREE from 'three';
import { Vector3D } from '../types';

export interface HawkEyeVisuals {
  group: THREE.Group;
  trajectoryLine: THREE.Line;
  projectedLine: THREE.Line;
  bounceMarker: THREE.Mesh;
  impactMarker: THREE.Mesh;
  stumpTargetPlane: THREE.Mesh;
}

export function createHawkEyeGroup(scene: THREE.Scene): HawkEyeVisuals {
  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  // 1. Measured Trajectory Line (Fluorescent Cyan / Neon Yellow)
  const lineGeo = new THREE.BufferGeometry();
  const lineMat = new THREE.LineBasicMaterial({
    color: 0x00f3ff,
    linewidth: 4,
    transparent: true,
    opacity: 0.9,
  });
  const trajectoryLine = new THREE.Line(lineGeo, lineMat);
  group.add(trajectoryLine);

  // 2. Projected Hawk-Eye Trajectory Line (Red if hitting stumps, Grey if missing)
  const projGeo = new THREE.BufferGeometry();
  const projMat = new THREE.LineBasicMaterial({
    color: 0xff0055,
    linewidth: 5,
    transparent: true,
    opacity: 0.95,
  });
  const projectedLine = new THREE.Line(projGeo, projMat);
  group.add(projectedLine);

  // 3. Pitch Mat Bounce Disc
  const bounceGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.02, 24);
  const bounceMat = new THREE.MeshBasicMaterial({ color: 0x39ff14, transparent: true, opacity: 0.85 });
  const bounceMarker = new THREE.Mesh(bounceGeo, bounceMat);
  bounceMarker.visible = false;
  group.add(bounceMarker);

  // 4. Pad / Bat Impact Disc
  const impactGeo = new THREE.SphereGeometry(0.09, 16, 16);
  const impactMat = new THREE.MeshBasicMaterial({ color: 0xffea00 });
  const impactMarker = new THREE.Mesh(impactGeo, impactMat);
  impactMarker.visible = false;
  group.add(impactMarker);

  // 5. Stumps Target Virtual Plane (Wickets zone)
  const stumpTargetGeo = new THREE.PlaneGeometry(0.24, 0.72);
  const stumpTargetMat = new THREE.MeshBasicMaterial({
    color: 0xff0044,
    wireframe: true,
    transparent: true,
    opacity: 0.6,
  });
  const stumpTargetPlane = new THREE.Mesh(stumpTargetGeo, stumpTargetMat);
  stumpTargetPlane.position.set(0, 0.36, 0);
  group.add(stumpTargetPlane);

  return {
    group,
    trajectoryLine,
    projectedLine,
    bounceMarker,
    impactMarker,
    stumpTargetPlane,
  };
}

export function updateHawkEyeTrajectory(
  visuals: HawkEyeVisuals,
  history: Vector3D[],
  bouncePoint: Vector3D | null,
  impactPoint: Vector3D | null,
  projectedStumpHit: boolean
) {
  if (!history || history.length < 2) {
    visuals.group.visible = false;
    return;
  }

  visuals.group.visible = true;

  // Set historical line points
  const points = history.map((p) => new THREE.Vector3(p.x, Math.max(0.02, p.y), p.z));
  visuals.trajectoryLine.geometry.dispose();
  visuals.trajectoryLine.geometry = new THREE.BufferGeometry().setFromPoints(points);

  // Bounce Marker
  if (bouncePoint) {
    visuals.bounceMarker.visible = true;
    visuals.bounceMarker.position.set(bouncePoint.x, 0.02, bouncePoint.z);
  } else {
    visuals.bounceMarker.visible = false;
  }

  // Impact Marker
  if (impactPoint) {
    visuals.impactMarker.visible = true;
    visuals.impactMarker.position.set(impactPoint.x, impactPoint.y, impactPoint.z);
  } else {
    visuals.impactMarker.visible = false;
  }

  // Projected line straight toward stumps (z = 0)
  if (impactPoint) {
    const lastP = history[history.length - 1];
    const prevP = history[Math.max(0, history.length - 5)];
    const dz = lastP.z - prevP.z;
    const dy = lastP.y - prevP.y;
    const dx = lastP.x - prevP.x;

    if (Math.abs(dz) > 0.001) {
      const stepsToStumps = (0 - lastP.z) / dz;
      const projX = lastP.x + dx * stepsToStumps;
      const projY = Math.max(0.04, lastP.y + dy * stepsToStumps);

      const projPoints = [
        new THREE.Vector3(lastP.x, lastP.y, lastP.z),
        new THREE.Vector3(projX, projY, 0),
      ];

      visuals.projectedLine.geometry.dispose();
      visuals.projectedLine.geometry = new THREE.BufferGeometry().setFromPoints(projPoints);
      visuals.projectedLine.visible = true;

      // Color red if hitting, gray if missing
      (visuals.projectedLine.material as THREE.LineBasicMaterial).color.setHex(
        projectedStumpHit ? 0xff0055 : 0x94a3b8
      );
    }
  } else {
    visuals.projectedLine.visible = false;
  }
}
