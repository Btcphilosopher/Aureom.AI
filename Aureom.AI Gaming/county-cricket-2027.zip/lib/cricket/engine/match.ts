import {
  CompetitionType,
  CountyTeam,
  DeliveryOutcome,
  DismissalType,
  InningsState,
  MatchState,
  PitchCondition,
  WeatherCondition,
} from '../types';
import { COUNTIES_DATA } from '../data/counties';

export function createNewMatch(
  homeCountyId: string = 'SURREY',
  awayCountyId: string = 'YORKSHIRE',
  competition: CompetitionType = 'COUNTY_T20',
  weather: WeatherCondition = 'ENGLISH_SUMMER',
  pitch: PitchCondition = 'FRESH_GREEN',
  playerCountyId: string = 'SURREY'
): MatchState {
  const homeCounty = COUNTIES_DATA.find((c) => c.id === homeCountyId) || COUNTIES_DATA[0];
  const awayCounty = COUNTIES_DATA.find((c) => c.id === awayCountyId) || COUNTIES_DATA[1];

  let maxOvers = 20;
  if (competition === 'ONE_DAY') maxOvers = 50;
  else if (competition === 'COUNTY_CHAMPIONSHIP') maxOvers = 0; // unlimited
  else if (competition === 'TRAINING') maxOvers = 999;
  else if (competition === 'QUICK_MATCH') maxOvers = 5;

  const firstInnings: InningsState = {
    battingTeamId: homeCounty.id,
    bowlingTeamId: awayCounty.id,
    totalRuns: 0,
    wickets: 0,
    overs: 0,
    ballsThisOver: 0,
    currentStrikerIndex: 0,
    currentNonStrikerIndex: 1,
    currentBowlerIndex: 9, // opening bowler
    declared: false,
    allOut: false,
    extras: { wides: 0, noBalls: 0, byes: 0, legByes: 0 },
    batterScores: homeCounty.squad.map((p) => ({
      playerId: p.id,
      runs: 0,
      balls: 0,
      fours: 0,
      sixes: 0,
      dismissal: 'not out',
      isOut: false,
    })),
    bowlerFigures: awayCounty.squad.map((p) => ({
      playerId: p.id,
      oversBowled: 0,
      maidens: 0,
      runsConceded: 0,
      wickets: 0,
    })),
    partnerships: [
      {
        batter1Id: homeCounty.squad[0].id,
        batter2Id: homeCounty.squad[1].id,
        runs: 0,
        balls: 0,
      },
    ],
    history: [],
  };

  return {
    competition,
    homeCounty,
    awayCounty,
    playerCountyId,
    venue: homeCounty.homeVenue,
    weather,
    pitch,
    currentInningsIndex: 0,
    maxOversPerInnings: maxOvers,
    targetRuns: null,
    inningsList: [firstInnings],
    isMatchComplete: false,
    resultMessage: '',
  };
}

export function recordDeliveryInMatch(
  match: MatchState,
  outcome: DeliveryOutcome
): {
  match: MatchState;
  overCompleted: boolean;
  inningsCompleted: boolean;
  matchCompleted: boolean;
} {
  const innings = match.inningsList[match.currentInningsIndex];
  if (!innings || innings.allOut || innings.declared || match.isMatchComplete) {
    return {
      match,
      overCompleted: false,
      inningsCompleted: false,
      matchCompleted: match.isMatchComplete,
    };
  }

  const battingTeam = innings.battingTeamId === match.homeCounty.id ? match.homeCounty : match.awayCounty;
  const strikerScore = innings.batterScores[innings.currentStrikerIndex];
  const bowlerFig = innings.bowlerFigures[innings.currentBowlerIndex];

  // Update runs
  const totalRunsThisBall = outcome.runs + outcome.extras;
  innings.totalRuns += totalRunsThisBall;

  if (strikerScore) {
    strikerScore.balls++;
    strikerScore.runs += outcome.runs;
    if (outcome.isFour) strikerScore.fours++;
    if (outcome.isSix) strikerScore.sixes++;
  }

  if (bowlerFig) {
    bowlerFig.runsConceded += totalRunsThisBall;
  }

  // Update partnership
  const currentPartnership = innings.partnerships[innings.partnerships.length - 1];
  if (currentPartnership) {
    currentPartnership.runs += outcome.runs;
    currentPartnership.balls++;
  }

  // Check wicket
  if (outcome.isWicket && outcome.dismissalType !== 'NOT_OUT') {
    innings.wickets++;
    if (bowlerFig && outcome.dismissalType !== 'RUN_OUT') {
      bowlerFig.wickets++;
    }

    if (strikerScore) {
      strikerScore.isOut = true;
      strikerScore.dismissal = formatDismissal(outcome.dismissalType, outcome.bowlerName);
    }

    // Bring in next batsman
    const nextBatterIndex = Math.max(innings.currentStrikerIndex, innings.currentNonStrikerIndex) + 1;
    if (nextBatterIndex < battingTeam.squad.length && innings.wickets < 10) {
      innings.currentStrikerIndex = nextBatterIndex;
      innings.partnerships.push({
        batter1Id: battingTeam.squad[nextBatterIndex].id,
        batter2Id: battingTeam.squad[innings.currentNonStrikerIndex].id,
        runs: 0,
        balls: 0,
      });
    } else {
      innings.allOut = true;
    }
  } else {
    // Rotate strike on odd runs
    if (outcome.runs % 2 === 1) {
      const temp = innings.currentStrikerIndex;
      innings.currentStrikerIndex = innings.currentNonStrikerIndex;
      innings.currentNonStrikerIndex = temp;
    }
  }

  // Legal ball counted
  innings.ballsThisOver++;
  innings.history.push({
    ballNumber: innings.ballsThisOver,
    legalBall: true,
    outcome,
  });

  let overCompleted = false;
  if (innings.ballsThisOver >= 6) {
    overCompleted = true;
    innings.overs++;
    innings.ballsThisOver = 0;
    if (bowlerFig) {
      bowlerFig.oversBowled++;
    }
    // Change strike at end of over
    const temp = innings.currentStrikerIndex;
    innings.currentStrikerIndex = innings.currentNonStrikerIndex;
    innings.currentNonStrikerIndex = temp;

    // Rotate bowler (cycle opening/change bowlers)
    innings.currentBowlerIndex = innings.currentBowlerIndex === 9 ? 10 : innings.currentBowlerIndex === 10 ? 8 : innings.currentBowlerIndex === 8 ? 7 : 9;
  }

  // Check innings / target completion
  let inningsCompleted = false;
  let matchCompleted = false;

  // Has chasing team reached target?
  if (match.targetRuns !== null && innings.totalRuns >= match.targetRuns) {
    inningsCompleted = true;
    matchCompleted = true;
    match.isMatchComplete = true;
    match.resultMessage = `${battingTeam.name} won by ${10 - innings.wickets} wickets!`;
  } else if (innings.allOut || (match.maxOversPerInnings > 0 && innings.overs >= match.maxOversPerInnings)) {
    inningsCompleted = true;
    if (match.currentInningsIndex === 0) {
      // Setup second innings chase
      const target = innings.totalRuns + 1;
      match.targetRuns = target;
      match.currentInningsIndex = 1;

      const bowlingTeam = innings.battingTeamId === match.homeCounty.id ? match.awayCounty : match.homeCounty;
      const defendingTeam = innings.battingTeamId === match.homeCounty.id ? match.homeCounty : match.awayCounty;

      const secondInnings: InningsState = {
        battingTeamId: bowlingTeam.id,
        bowlingTeamId: defendingTeam.id,
        totalRuns: 0,
        wickets: 0,
        overs: 0,
        ballsThisOver: 0,
        currentStrikerIndex: 0,
        currentNonStrikerIndex: 1,
        currentBowlerIndex: 9,
        declared: false,
        allOut: false,
        extras: { wides: 0, noBalls: 0, byes: 0, legByes: 0 },
        batterScores: bowlingTeam.squad.map((p) => ({
          playerId: p.id,
          runs: 0,
          balls: 0,
          fours: 0,
          sixes: 0,
          dismissal: 'not out',
          isOut: false,
        })),
        bowlerFigures: defendingTeam.squad.map((p) => ({
          playerId: p.id,
          oversBowled: 0,
          maidens: 0,
          runsConceded: 0,
          wickets: 0,
        })),
        partnerships: [
          {
            batter1Id: bowlingTeam.squad[0].id,
            batter2Id: bowlingTeam.squad[1].id,
            runs: 0,
            balls: 0,
          },
        ],
        history: [],
      };
      match.inningsList.push(secondInnings);
    } else {
      // Second innings concluded
      matchCompleted = true;
      match.isMatchComplete = true;
      const firstInnings = match.inningsList[0];
      if (innings.totalRuns === firstInnings.totalRuns) {
        match.resultMessage = 'Match Tied! A thrilling domestic clash!';
      } else if (innings.totalRuns < firstInnings.totalRuns) {
        const winningTeam = firstInnings.battingTeamId === match.homeCounty.id ? match.homeCounty : match.awayCounty;
        match.resultMessage = `${winningTeam.name} won by ${firstInnings.totalRuns - innings.totalRuns} runs!`;
      }
    }
  }

  return { match, overCompleted, inningsCompleted, matchCompleted };
}

function formatDismissal(type: DismissalType, bowler: string): string {
  switch (type) {
    case 'BOWLED':
      return `b ${bowler}`;
    case 'LBW':
      return `lbw b ${bowler}`;
    case 'CAUGHT_BEHIND':
      return `c †wk b ${bowler}`;
    case 'CAUGHT_SLIPS':
      return `c slip b ${bowler}`;
    case 'CAUGHT_INFIELD':
    case 'CAUGHT_OUTFIELD':
      return `c fielder b ${bowler}`;
    case 'CAUGHT_AND_BOWLED':
      return `c & b ${bowler}`;
    case 'RUN_OUT':
      return `run out`;
    case 'STUMPED':
      return `st †wk b ${bowler}`;
    case 'HIT_WICKET':
      return `hit wicket b ${bowler}`;
    default:
      return 'out';
  }
}
