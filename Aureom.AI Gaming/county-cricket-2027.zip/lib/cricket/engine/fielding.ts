import { BallState, CricketPlayer, DismissalType, FielderPosition, FieldPreset, Vector3D } from '../types';

export type { FielderPosition, FieldPreset };

export function getFieldPresetPositions(preset: FieldPreset): Omit<FielderPosition, 'playerIndex'>[] {
  // Batting stumps at (0, 0, 0), pitch center at (0, 0, 10), bowling stumps at (0, 0, 20.12)
  // Positive X is Off-Side for right hander (Point/Cover), Negative X is Leg-Side (Square Leg/Midwicket)
  // Positive Z is down the ground towards bowler (Long On/Long Off), Negative Z is behind batter (Slips/Wicketkeeper)

  const keeper: Omit<FielderPosition, 'playerIndex'> = {
    id: 'wk',
    name: 'Wicketkeeper',
    basePosition: { x: 0, y: 0, z: -4.5 },
    currentPosition: { x: 0, y: 0, z: -4.5 },
    velocity: { x: 0, y: 0, z: 0 },
    isWicketkeeper: true,
    state: 'IDLE',
  };

  const bowler: Omit<FielderPosition, 'playerIndex'> = {
    id: 'bowler',
    name: 'Bowler',
    basePosition: { x: 0.5, y: 0, z: 21.0 },
    currentPosition: { x: 0.5, y: 0, z: 21.0 },
    velocity: { x: 0, y: 0, z: 0 },
    isBowler: true,
    state: 'IDLE',
  };

  let fielders: { id: string; name: string; pos: Vector3D }[] = [];

  switch (preset) {
    case 'ATTACKING_SLIPS':
      fielders = [
        { id: 'slip1', name: '1st Slip', pos: { x: 3.2, y: 0, z: -5.0 } },
        { id: 'slip2', name: '2nd Slip', pos: { x: 4.8, y: 0, z: -4.5 } },
        { id: 'gully', name: 'Gully', pos: { x: 9.5, y: 0, z: -2.0 } },
        { id: 'point', name: 'Backward Point', pos: { x: 18.0, y: 0, z: 4.0 } },
        { id: 'cover', name: 'Cover', pos: { x: 22.0, y: 0, z: 14.0 } },
        { id: 'midoff', name: 'Mid Off', pos: { x: 9.0, y: 0, z: 22.0 } },
        { id: 'midon', name: 'Mid On', pos: { x: -9.0, y: 0, z: 22.0 } },
        { id: 'midwicket', name: 'Mid Wicket', pos: { x: -20.0, y: 0, z: 12.0 } },
        { id: 'fineleg', name: 'Fine Leg', pos: { x: -18.0, y: 0, z: -14.0 } },
      ];
      break;

    case 'DEFENSIVE_RING':
      fielders = [
        { id: 'slip1', name: 'Slip', pos: { x: 3.5, y: 0, z: -4.5 } },
        { id: 'thirdman', name: 'Deep Third Man', pos: { x: 38.0, y: 0, z: -30.0 } },
        { id: 'point', name: 'Point', pos: { x: 20.0, y: 0, z: 5.0 } },
        { id: 'deepcover', name: 'Deep Cover', pos: { x: 45.0, y: 0, z: 22.0 } },
        { id: 'longoff', name: 'Long Off', pos: { x: 18.0, y: 0, z: 55.0 } },
        { id: 'longon', name: 'Long On', pos: { x: -18.0, y: 0, z: 55.0 } },
        { id: 'deepmidwicket', name: 'Deep Mid Wicket', pos: { x: -44.0, y: 0, z: 24.0 } },
        { id: 'squareleg', name: 'Square Leg', pos: { x: -22.0, y: 0, z: 4.0 } },
        { id: 'deepfineleg', name: 'Deep Fine Leg', pos: { x: -36.0, y: 0, z: -28.0 } },
      ];
      break;

    case 'DEATH_OVERS_T20':
      fielders = [
        { id: 'thirdman', name: 'Deep Third Man', pos: { x: 40.0, y: 0, z: -32.0 } },
        { id: 'point', name: 'Backward Point', pos: { x: 19.0, y: 0, z: 4.0 } },
        { id: 'deepcover', name: 'Deep Extra Cover', pos: { x: 48.0, y: 0, z: 20.0 } },
        { id: 'longoff', name: 'Long Off', pos: { x: 16.0, y: 0, z: 58.0 } },
        { id: 'longon', name: 'Long On', pos: { x: -16.0, y: 0, z: 58.0 } },
        { id: 'deepmidwicket', name: 'Deep Mid Wicket', pos: { x: -48.0, y: 0, z: 20.0 } },
        { id: 'deepsqleg', name: 'Deep Square Leg', pos: { x: -50.0, y: 0, z: 2.0 } },
        { id: 'midoff', name: 'Short Extra Cover', pos: { x: 12.0, y: 0, z: 12.0 } },
        { id: 'fineleg', name: 'Short Fine Leg', pos: { x: -14.0, y: 0, z: -8.0 } },
      ];
      break;

    case 'SPIN_WEB':
      fielders = [
        { id: 'slip1', name: '1st Slip', pos: { x: 3.0, y: 0, z: -4.0 } },
        { id: 'slip2', name: '2nd Slip', pos: { x: 4.5, y: 0, z: -3.5 } },
        { id: 'shortleg', name: 'Short Leg', pos: { x: -3.0, y: 0, z: 2.5 } },
        { id: 'sillypoint', name: 'Silly Point', pos: { x: 3.5, y: 0, z: 2.5 } },
        { id: 'cover', name: 'Cover', pos: { x: 18.0, y: 0, z: 12.0 } },
        { id: 'midon', name: 'Mid On', pos: { x: -10.0, y: 0, z: 20.0 } },
        { id: 'midoff', name: 'Mid Off', pos: { x: 10.0, y: 0, z: 20.0 } },
        { id: 'deepmidwicket', name: 'Deep Mid Wicket', pos: { x: -45.0, y: 0, z: 20.0 } },
        { id: 'longoff', name: 'Long Off', pos: { x: 20.0, y: 0, z: 54.0 } },
      ];
      break;

    case 'STANDARD_BALANCED':
    default:
      fielders = [
        { id: 'slip1', name: '1st Slip', pos: { x: 3.5, y: 0, z: -4.8 } },
        { id: 'point', name: 'Backward Point', pos: { x: 18.0, y: 0, z: 3.5 } },
        { id: 'cover', name: 'Cover', pos: { x: 24.0, y: 0, z: 12.0 } },
        { id: 'midoff', name: 'Mid Off', pos: { x: 9.0, y: 0, z: 21.0 } },
        { id: 'midon', name: 'Mid On', pos: { x: -9.0, y: 0, z: 21.0 } },
        { id: 'midwicket', name: 'Mid Wicket', pos: { x: -22.0, y: 0, z: 10.0 } },
        { id: 'squareleg', name: 'Square Leg', pos: { x: -18.0, y: 0, z: 3.0 } },
        { id: 'fineleg', name: 'Fine Leg', pos: { x: -22.0, y: 0, z: -18.0 } },
        { id: 'thirdman', name: 'Third Man', pos: { x: 26.0, y: 0, z: -20.0 } },
      ];
      break;
  }

  const result: Omit<FielderPosition, 'playerIndex'>[] = [keeper, bowler];
  fielders.forEach((f) => {
    result.push({
      id: f.id,
      name: f.name,
      basePosition: { ...f.pos },
      currentPosition: { ...f.pos },
      velocity: { x: 0, y: 0, z: 0 },
      state: 'IDLE',
    });
  });

  return result;
}

export function updateFieldersAI(
  fielders: FielderPosition[],
  ball: BallState,
  dt: number,
  fieldingPlayers: CricketPlayer[]
): {
  closestFielder: FielderPosition | null;
  ballSecured: boolean;
  catchAttempt: {
    occurred: boolean;
    successful: boolean;
    fielderName: string;
    dismissalType: DismissalType;
    difficulty: 'EASY' | 'COMFORTABLE' | 'DIFFICULT' | 'DIVING' | 'BOUNDARY';
  } | null;
} {
  let closestFielder: FielderPosition | null = null;
  let minDistance = Infinity;
  let ballSecured = false;
  let catchAttempt: {
    occurred: boolean;
    successful: boolean;
    fielderName: string;
    dismissalType: DismissalType;
    difficulty: 'EASY' | 'COMFORTABLE' | 'DIFFICULT' | 'DIVING' | 'BOUNDARY';
  } | null = null;

  // Ball position on ground plane
  const bx = ball.position.x;
  const bz = ball.position.z;
  const by = ball.position.y;
  const ballSpeed = Math.hypot(ball.velocity.x, ball.velocity.z);

  for (const f of fielders) {
    const distToBall = Math.hypot(f.currentPosition.x - bx, f.currentPosition.z - bz);
    if (distToBall < minDistance) {
      minDistance = distToBall;
      closestFielder = f;
    }

    const player = fieldingPlayers[f.playerIndex] || fieldingPlayers[0];
    const maxSpeed = (player?.attributes?.fieldingSpeed || 75) * 0.088; // 6.6 - 8.2 m/s

    if (ball.hitBat && !ball.isDead) {
      // Chase or intercept ball
      const dx = bx - f.currentPosition.x;
      const dz = bz - f.currentPosition.z;
      const angle = Math.atan2(dz, dx);

      if (distToBall > 1.2) {
        f.state = distToBall < 5 ? 'INTERCEPTING' : 'CHASING';
        f.velocity.x = Math.cos(angle) * maxSpeed;
        f.velocity.z = Math.sin(angle) * maxSpeed;
      } else {
        // Within pickup / catch range!
        f.velocity.x = 0;
        f.velocity.z = 0;
        f.state = distToBall < 0.6 ? 'PICKING_UP' : 'DIVING';

        // Check if ball is in the air: CATCH OPPORTUNITY!
        if (ball.bounceCount === 0 && by > 0.35 && by < 2.3 && distToBall < 1.4) {
          // Catch test based on catching skill and ball velocity
          const catchSkill = player?.attributes?.catching || 80;
          let difficulty: 'EASY' | 'COMFORTABLE' | 'DIFFICULT' | 'DIVING' = 'COMFORTABLE';

          if (distToBall > 1.0) difficulty = 'DIVING';
          else if (ballSpeed > 28 || by > 1.8) difficulty = 'DIFFICULT';
          else if (ballSpeed < 15 && by < 1.3) difficulty = 'EASY';
          else difficulty = 'COMFORTABLE';

          const rateMap: Record<'EASY' | 'COMFORTABLE' | 'DIFFICULT' | 'DIVING', number> = {
            EASY: 0.95,
            COMFORTABLE: 0.88,
            DIFFICULT: 0.72,
            DIVING: 0.65,
          };
          const successRate = rateMap[difficulty];

          const rolled = Math.random();
          const caught = rolled < successRate * (catchSkill / 80);

          let dismissal: DismissalType = 'CAUGHT_INFIELD';
          if (f.isWicketkeeper) dismissal = 'CAUGHT_BEHIND';
          else if (f.name.includes('Slip') || f.name.includes('Gully')) dismissal = 'CAUGHT_SLIPS';
          else if (Math.hypot(f.currentPosition.x, f.currentPosition.z - 10) > 40) dismissal = 'CAUGHT_OUTFIELD';
          else if (f.isBowler) dismissal = 'CAUGHT_AND_BOWLED';

          catchAttempt = {
            occurred: true,
            successful: caught,
            fielderName: player.name,
            dismissalType: dismissal,
            difficulty,
          };

          if (caught) {
            ball.isDead = true;
            ballSecured = true;
            f.state = 'CELEBRATING';
          }
        } else if (ball.bounceCount > 0 && distToBall < 0.8 && ballSpeed < 12) {
          // Clean ground fielding pickup
          ballSecured = true;
          ball.velocity.x = 0;
          ball.velocity.y = 0;
          ball.velocity.z = 0;
          f.state = 'PICKING_UP';
        }
      }
    } else {
      // Return to base position smoothly
      const dx = f.basePosition.x - f.currentPosition.x;
      const dz = f.basePosition.z - f.currentPosition.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 0.5) {
        const angle = Math.atan2(dz, dx);
        f.velocity.x = Math.cos(angle) * (maxSpeed * 0.4);
        f.velocity.z = Math.sin(angle) * (maxSpeed * 0.4);
      } else {
        f.velocity.x = 0;
        f.velocity.z = 0;
        f.state = 'IDLE';
      }
    }

    f.currentPosition.x += f.velocity.x * dt;
    f.currentPosition.z += f.velocity.z * dt;
  }

  return { closestFielder, ballSecured, catchAttempt };
}
