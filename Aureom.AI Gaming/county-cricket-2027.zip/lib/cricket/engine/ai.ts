import {
  BallState,
  BatSwingState,
  BowlingDeliveryInput,
  BowlingLengthZone,
  CricketPlayer,
  DeliveryVariation,
  MatchState,
  ShotType,
} from '../types';

export function chooseAIBowlingDelivery(
  bowler: CricketPlayer,
  striker: CricketPlayer,
  match: MatchState,
  overBallNum: number
): BowlingDeliveryInput {
  const isSpinner = bowler.bowlingStyle.includes('SPIN');
  const paceRating = bowler.attributes.pace || 135;
  const swingRating = bowler.attributes.swing || 75;

  let length: BowlingLengthZone = 'GOOD_LENGTH';
  let variation: DeliveryVariation = isSpinner ? 'OFF_BREAK' : 'STOCK_FAST';
  let targetLine = 0.05; // slightly outside off stump for RHB
  let swingAmount = 0;
  let spinRate = 0;
  let speedMph = 82;

  const roll = Math.random();

  if (isSpinner) {
    speedMph = 52 + Math.random() * 8;
    if (bowler.bowlingStyle === 'LEG_SPIN') {
      if (roll < 0.6) {
        variation = 'LEG_BREAK';
        spinRate = 1800 + Math.random() * 400;
      } else if (roll < 0.8) {
        variation = 'GOOGLY';
        spinRate = -1600 - Math.random() * 300;
      } else {
        variation = 'TOP_SPINNER';
        spinRate = 800;
        speedMph += 4;
      }
    } else {
      // Off spin / SLA
      if (roll < 0.7) {
        variation = 'OFF_BREAK';
        spinRate = 1600 + Math.random() * 400;
      } else if (roll < 0.85) {
        variation = 'ARM_BALL';
        spinRate = 400;
        speedMph += 5;
      } else {
        variation = 'FLIGHTED';
        speedMph -= 4;
        spinRate = 2200;
      }
    }

    // Length variation
    if (roll < 0.2) length = 'FULL_LENGTH';
    else if (roll < 0.75) length = 'GOOD_LENGTH';
    else length = 'SHORT_OF_LENGTH';
  } else {
    // Pace bowler
    speedMph = (paceRating * 0.62) + (Math.random() - 0.5) * 6; // convert km/h base to mph (e.g. 84-91 mph)

    if (overBallNum === 6 && roll < 0.45) {
      // Death / end of over Yorker surprise
      length = 'YORKER';
      variation = 'YORKER';
      targetLine = (Math.random() - 0.5) * 0.15; // aimed at base of stumps
    } else if (roll < 0.35) {
      // Outswinger outside off
      variation = 'OUTSWINGER';
      targetLine = 0.15 + Math.random() * 0.12;
      swingAmount = (swingRating / 100) * 0.8;
      length = 'GOOD_LENGTH';
    } else if (roll < 0.6) {
      // Inswinger targeting stumps / pads
      variation = 'INSWINGER';
      targetLine = -0.05 + Math.random() * 0.1;
      swingAmount = -(swingRating / 100) * 0.7;
      length = 'FULL_LENGTH';
    } else if (roll < 0.8) {
      // Bouncer / Short ball
      variation = 'BOUNCER';
      length = 'BOUNCER';
      targetLine = -0.08 + Math.random() * 0.16;
      speedMph += 2;
    } else {
      // Slower ball cutter
      variation = 'SLOWER_BALL';
      length = 'GOOD_LENGTH';
      speedMph -= 14;
      swingAmount = 0.2;
    }
  }

  // Calculate target bounce distance (z) based on length
  const lengthToZ: Record<BowlingLengthZone, number> = {
    YORKER: 1.6,
    FULL: 3.5,
    FULL_LENGTH: 4.8,
    GOOD_LENGTH: 6.5,
    SHORT_OF_LENGTH: 8.5,
    SHORT: 10.5,
    BOUNCER: 12.0,
  };
  const targetZ = lengthToZ[length] ?? 6.5;

  return {
    bowlerId: bowler.id,
    type: variation,
    targetLine,
    targetLength: length,
    targetZ,
    power: 0.85,
    swingAmount,
    spinRate,
    releaseSpeedMph: Math.round(speedMph),
  };
}

export function chooseAIBattingShot(
  ball: BallState,
  batter: CricketPlayer,
  match: MatchState,
  bowler: CricketPlayer
): BatSwingState {
  const isT20 = match.competition === 'COUNTY_T20';
  const isChasing = match.targetRuns !== null;
  const currentInnings = match.inningsList[match.currentInningsIndex];
  const reqRate = match.targetRuns
    ? ((match.targetRuns - currentInnings.totalRuns) / Math.max(1, (match.maxOversPerInnings - currentInnings.overs)))
    : 0;

  const aggressiveIntent = isT20 || reqRate > 8;
  const ballLineX = ball.position.x;
  const ballHeight = ball.position.y;
  const hasBounced = ball.hasBounced;

  let shot: ShotType = 'STRAIGHT_DRIVE';
  let isLofted = false;
  let isDefensive = false;
  let aimAngle = 0;

  // Read pitch line and bounce
  if (ball.bounceCount === 0 && ball.position.z < 6) {
    // Ball on the rise / approaching
    if (ballLineX > 0.25) {
      // Outside off
      if (ballHeight > 0.6) {
        shot = 'SQUARE_CUT';
        aimAngle = Math.PI * 0.52;
      } else {
        shot = 'COVER_DRIVE';
        aimAngle = Math.PI * 0.28;
      }
    } else if (ballLineX < -0.15) {
      // Leg side
      if (ballHeight > 0.7) {
        shot = 'PULL_SHOT';
        aimAngle = -Math.PI * 0.55;
      } else {
        shot = 'LEG_GLANCE';
        aimAngle = -Math.PI * 0.8;
      }
    } else {
      // Straight on the stumps
      if (aggressiveIntent && Math.random() < 0.45) {
        shot = 'LOFTED_DRIVE';
        isLofted = true;
        aimAngle = 0.1;
      } else if (ballHeight > 0.8) {
        shot = 'PULL_SHOT';
        aimAngle = -Math.PI * 0.5;
      } else {
        shot = aggressiveIntent ? 'STRAIGHT_DRIVE' : 'FORWARD_DEFENCE';
        isDefensive = !aggressiveIntent;
        aimAngle = 0;
      }
    }
  }

  // Calculate timing based on batter's skill
  const skill = batter.attributes.timing || 80;
  const variance = (100 - skill) * 0.003;
  const timingScore = (Math.random() - 0.5) * variance;

  return {
    type: shot,
    isLofted,
    isDefensive,
    footwork: ball.bouncePoint && ball.bouncePoint.z > 8 ? 'BACK_FOOT' : 'FRONT_FOOT',
    aimAngle,
    power: aggressiveIntent ? 0.9 : 0.65,
    timingScore,
    timingCategory: Math.abs(timingScore) < 0.03 ? 'PERFECT' : Math.abs(timingScore) < 0.08 ? 'GOOD' : 'EARLY',
    swingProgress: 0.52,
    active: true,
  };
}
