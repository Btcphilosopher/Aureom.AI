// Keyboard & Gamepad Controller Manager for County Cricket 2027

export interface ControlState {
  // Batting
  battingAimAngle: number; // radians
  isFrontFoot: boolean;
  isBackFoot: boolean;
  isAdvance: boolean;
  shotPower: number; // 0 to 1
  shotAction: 'DEFENSIVE' | 'GROUND' | 'LOFTED' | 'LEAVE' | null;

  // Bowling
  bowlLineX: number; // -0.5 to 0.5
  bowlLengthZ: number; // 2 to 14
  bowlPower: number; // 0 to 1
  bowlTrigger: boolean;

  // Running
  runAction: 'RUN' | 'STOP' | 'CANCEL' | null;

  // Fielding
  fielderMoveX: number;
  fielderMoveZ: number;
  fielderSprint: boolean;
  fielderDive: boolean;
  fielderThrowTarget: 'KEEPER' | 'BOWLER' | null;

  // General
  appealPressed: boolean;
  drsPressed: boolean;
  cameraToggle: boolean;
}

export class InputManager {
  public state: ControlState = {
    battingAimAngle: 0,
    isFrontFoot: true,
    isBackFoot: false,
    isAdvance: false,
    shotPower: 0.8,
    shotAction: null,

    bowlLineX: 0.08,
    bowlLengthZ: 6.5,
    bowlPower: 0.85,
    bowlTrigger: false,

    runAction: null,

    fielderMoveX: 0,
    fielderMoveZ: 0,
    fielderSprint: false,
    fielderDive: false,
    fielderThrowTarget: null,

    appealPressed: false,
    drsPressed: false,
    cameraToggle: false,
  };

  private keysDown: Set<string> = new Set();

  public init() {
    if (typeof window === 'undefined') return;

    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
  }

  public destroy() {
    if (typeof window === 'undefined') return;
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    this.keysDown.add(e.code);

    // Batting Footwork
    if (e.code === 'KeyW' || e.code === 'ArrowUp') {
      this.state.isFrontFoot = true;
      this.state.isBackFoot = false;
    } else if (e.code === 'KeyS' || e.code === 'ArrowDown') {
      this.state.isBackFoot = true;
      this.state.isFrontFoot = false;
    }

    // Batting Aim Angle (Left/Right arrow or A/D)
    if (e.code === 'KeyA' || e.code === 'ArrowLeft') {
      this.state.battingAimAngle = -Math.PI * 0.45; // Leg side
    } else if (e.code === 'KeyD' || e.code === 'ArrowRight') {
      this.state.battingAimAngle = Math.PI * 0.45; // Off side
    }

    // Shot triggers
    if (e.code === 'KeyJ' || e.code === 'Digit1') {
      this.state.shotAction = 'GROUND'; // Drive / Cut
    } else if (e.code === 'KeyK' || e.code === 'Digit2') {
      this.state.shotAction = 'LOFTED'; // Aerial
    } else if (e.code === 'KeyL' || e.code === 'Digit3') {
      this.state.shotAction = 'DEFENSIVE'; // Block
    } else if (e.code === 'KeyU' || e.code === 'Digit4') {
      this.state.shotAction = 'LEAVE';
    }

    // Running controls (Space = Run, Escape = Cancel)
    if (e.code === 'Space') {
      this.state.runAction = 'RUN';
    } else if (e.code === 'KeyX') {
      this.state.runAction = 'CANCEL';
    }

    // Appeal (Key H)
    if (e.code === 'KeyH') {
      this.state.appealPressed = true;
    }

    // Camera cycle (Key C)
    if (e.code === 'KeyC') {
      this.state.cameraToggle = true;
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keysDown.delete(e.code);

    if (e.code === 'KeyA' || e.code === 'KeyD' || e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
      this.state.battingAimAngle = 0;
    }
    if (e.code === 'KeyJ' || e.code === 'KeyK' || e.code === 'KeyL' || e.code === 'KeyU' || e.code === 'Digit1' || e.code === 'Digit2') {
      this.state.shotAction = null;
    }
    if (e.code === 'Space' || e.code === 'KeyX') {
      this.state.runAction = null;
    }
    if (e.code === 'KeyH') {
      this.state.appealPressed = false;
    }
    if (e.code === 'KeyC') {
      this.state.cameraToggle = false;
    }
  };

  // Poll Gamepad API if available (Xbox, PlayStation, USB controller)
  public pollGamepads() {
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return;
    const gamepads = navigator.getGamepads();
    if (!gamepads) return;

    for (const gp of gamepads) {
      if (!gp) continue;

      // Left stick for batting aim or fielder movement
      const lx = gp.axes[0] || 0;
      const ly = gp.axes[1] || 0;
      if (Math.abs(lx) > 0.15 || Math.abs(ly) > 0.15) {
        this.state.battingAimAngle = Math.atan2(-lx, -ly);
        this.state.fielderMoveX = lx;
        this.state.fielderMoveZ = ly;
      }

      // Buttons (Xbox: A=0, B=1, X=2, Y=3, LB=4, RB=5, LT=6, RT=7)
      if (gp.buttons[0]?.pressed) {
        // A / Cross: Ground shot or Run
        this.state.shotAction = 'GROUND';
        this.state.runAction = 'RUN';
      }
      if (gp.buttons[1]?.pressed) {
        // B / Circle: Defensive or Cancel run
        this.state.shotAction = 'DEFENSIVE';
        this.state.runAction = 'CANCEL';
      }
      if (gp.buttons[2]?.pressed) {
        // X / Square: Appeal / Throw
        this.state.appealPressed = true;
      }
      if (gp.buttons[3]?.pressed) {
        // Y / Triangle: Lofted shot
        this.state.shotAction = 'LOFTED';
      }
      if (gp.buttons[7]?.pressed) {
        // RT: Power
        this.state.shotPower = 1.0;
      }
    }
  }
}

export const inputManager = new InputManager();
