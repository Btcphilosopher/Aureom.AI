import { BallState, BatSwingState, CricketPlayer, ShotType, TimingCategory, Vector3D } from '../types';

export interface BatContactResult {
  hitBat: boolean;
  hitPad: boolean;
  contactQuality: number; // 0 to 1
  timingCategory: TimingCategory;
  timingErrorMs: number;
  shotType: ShotType;
  exitVelocity: Vector3D;
  isEdge: boolean;
  edgeType?: 'THICK_OUTSIDE' | 'THIN_OUTSIDE' | 'INSIDE_EDGE' | 'LEADING_EDGE';
  launchAngleDeg: number;
  horizontalAngleDeg: number;
  description: string;
}

// Shot angle profiles (in radians relative to straight down the ground, where 0 is straight back past bowler)
export const SHOT_SPECS: Record<
  ShotType,
  {
    targetAngleRad: number; // 0 = straight back towards bowler (+z), +PI/2 = covers/point (off side for RHB), -PI/2 = mid-wicket (leg side)
    launchAngleDeg: number; // vertical loft angle
    powerMultiplier: number;
    sweetSpotHeight: number; // optimal ball height (m)
    bestLength: 'FULL' | 'GOOD' | 'SHORT' | 'ANY';
    preferredFoot: 'FRONT_FOOT' | 'BACK_FOOT' | 'ANY';
  }
> = {
  STRAIGHT_DRIVE: {
    targetAngleRad: 0,
    launchAngleDeg: 4,
    powerMultiplier: 1.15,
    sweetSpotHeight: 0.35,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  COVER_DRIVE: {
    targetAngleRad: Math.PI / 4, // 45 deg to off-side
    launchAngleDeg: 5,
    powerMultiplier: 1.2,
    sweetSpotHeight: 0.4,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  ON_DRIVE: {
    targetAngleRad: -Math.PI / 5, // -36 deg to leg-side
    launchAngleDeg: 5,
    powerMultiplier: 1.1,
    sweetSpotHeight: 0.35,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  SQUARE_CUT: {
    targetAngleRad: Math.PI / 2 + 0.1, // square off-side / backward point
    launchAngleDeg: 8,
    powerMultiplier: 1.25,
    sweetSpotHeight: 0.75,
    bestLength: 'SHORT',
    preferredFoot: 'BACK_FOOT',
  },
  LATE_CUT: {
    targetAngleRad: (3 * Math.PI) / 4, // third man
    launchAngleDeg: 6,
    powerMultiplier: 0.85,
    sweetSpotHeight: 0.7,
    bestLength: 'SHORT',
    preferredFoot: 'BACK_FOOT',
  },
  PULL_SHOT: {
    targetAngleRad: -Math.PI / 2 - 0.2, // square leg / mid-wicket
    launchAngleDeg: 14,
    powerMultiplier: 1.3,
    sweetSpotHeight: 0.85,
    bestLength: 'SHORT',
    preferredFoot: 'BACK_FOOT',
  },
  HOOK_SHOT: {
    targetAngleRad: (-3 * Math.PI) / 4, // fine leg
    launchAngleDeg: 25,
    powerMultiplier: 1.35,
    sweetSpotHeight: 1.1,
    bestLength: 'SHORT',
    preferredFoot: 'BACK_FOOT',
  },
  LEG_GLANCE: {
    targetAngleRad: (-4 * Math.PI) / 5, // fine leg
    launchAngleDeg: 4,
    powerMultiplier: 0.75,
    sweetSpotHeight: 0.35,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  SWEEP: {
    targetAngleRad: -Math.PI / 2 - 0.3,
    launchAngleDeg: 8,
    powerMultiplier: 1.1,
    sweetSpotHeight: 0.3,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  SLOG_SWEEP: {
    targetAngleRad: -Math.PI / 3,
    launchAngleDeg: 34,
    powerMultiplier: 1.45,
    sweetSpotHeight: 0.4,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  RAMP_SCOOP: {
    targetAngleRad: Math.PI, // right behind keeper
    launchAngleDeg: 45,
    powerMultiplier: 1.1,
    sweetSpotHeight: 0.6,
    bestLength: 'ANY',
    preferredFoot: 'ANY',
  },
  LOFTED_DRIVE: {
    targetAngleRad: Math.PI / 6,
    launchAngleDeg: 32,
    powerMultiplier: 1.4,
    sweetSpotHeight: 0.45,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  AERIAL_SLOG: {
    targetAngleRad: -Math.PI / 4,
    launchAngleDeg: 38,
    powerMultiplier: 1.5,
    sweetSpotHeight: 0.6,
    bestLength: 'ANY',
    preferredFoot: 'FRONT_FOOT',
  },
  FORWARD_DEFENCE: {
    targetAngleRad: 0.1,
    launchAngleDeg: 1,
    powerMultiplier: 0.25,
    sweetSpotHeight: 0.35,
    bestLength: 'FULL',
    preferredFoot: 'FRONT_FOOT',
  },
  BACK_FOOT_DEFENCE: {
    targetAngleRad: 0.1,
    launchAngleDeg: 1,
    powerMultiplier: 0.2,
    sweetSpotHeight: 0.65,
    bestLength: 'GOOD',
    preferredFoot: 'BACK_FOOT',
  },
  LEAVE: {
    targetAngleRad: 0,
    launchAngleDeg: 0,
    powerMultiplier: 0,
    sweetSpotHeight: 0,
    bestLength: 'ANY',
    preferredFoot: 'ANY',
  },
};

export function checkBatBallCollision(
  ball: BallState,
  batterPos: Vector3D,
  swing: BatSwingState,
  player: CricketPlayer
): BatContactResult | null {
  if (ball.hitBat || ball.isDead) return null;
  if (swing.type === 'LEAVE') return null;

  // Bat contact plane is around batter's position (z approx 1.0 to 1.6m)
  const distZ = Math.abs(ball.position.z - batterPos.z);
  const distX = Math.abs(ball.position.x - batterPos.x);

  // If ball is within hitting reach
  const batReachX = 0.65;
  const batReachZ = 0.55;
  const batReachY = 1.35;

  if (distZ > batReachZ || distX > batReachX || ball.position.y > batReachY || ball.position.y < 0.05) {
    return null;
  }

  // Calculate timing accuracy
  // Ideal contact time is when swingProgress is between 0.45 and 0.65
  const idealSwingProgress = 0.55;
  const progressDiff = swing.swingProgress - idealSwingProgress;
  const timingErrorMs = progressDiff * 350; // milliseconds off

  let timingCategory: TimingCategory = 'GOOD';
  if (Math.abs(timingErrorMs) < 25) {
    timingCategory = 'PERFECT';
  } else if (timingErrorMs > 60) {
    timingCategory = timingErrorMs > 120 ? 'TOO_LATE' : 'LATE';
  } else if (timingErrorMs < -60) {
    timingCategory = timingErrorMs < -120 ? 'TOO_EARLY' : 'EARLY';
  }

  // Check Pad collision if player missed with bat or defensive shot misjudged
  if (timingCategory === 'TOO_LATE' || timingCategory === 'TOO_EARLY') {
    // If ball is hitting pads (height 0.2 to 0.7m and close to stumps line)
    if (ball.position.y >= 0.15 && ball.position.y <= 0.65 && distX < 0.22) {
      ball.hitPad = true;
      ball.velocity.x *= 0.25;
      ball.velocity.y *= 0.2;
      ball.velocity.z *= 0.3;
      return {
        hitBat: false,
        hitPad: true,
        contactQuality: 0.1,
        timingCategory,
        timingErrorMs,
        shotType: swing.type,
        exitVelocity: { ...ball.velocity },
        isEdge: false,
        launchAngleDeg: 5,
        horizontalAngleDeg: 0,
        description: 'Thump! Ball strikes the front pad in line with the stumps!',
      };
    }
  }

  // Contact quality based on timing, player timing skill, and alignment
  const spec = SHOT_SPECS[swing.type] || SHOT_SPECS.STRAIGHT_DRIVE;
  const timingFactor = timingCategory === 'PERFECT' ? 1.0 : timingCategory === 'GOOD' ? 0.82 : timingCategory === 'EARLY' || timingCategory === 'LATE' ? 0.52 : 0.22;
  const skillFactor = player.attributes.timing / 100;
  const heightMatch = Math.max(0, 1 - Math.abs(ball.position.y - spec.sweetSpotHeight) * 1.5);

  let contactQuality = timingFactor * (0.6 + 0.4 * skillFactor) * (0.7 + 0.3 * heightMatch);
  contactQuality = Math.min(1.0, Math.max(0.1, contactQuality));

  // Determine if it's an edge
  let isEdge = false;
  let edgeType: BatContactResult['edgeType'] = undefined;

  if (contactQuality < 0.38) {
    isEdge = true;
    if (ball.position.x > batterPos.x + 0.15) {
      edgeType = 'THICK_OUTSIDE';
    } else if (ball.position.x < batterPos.x - 0.12) {
      edgeType = 'INSIDE_EDGE';
    } else {
      edgeType = timingErrorMs < 0 ? 'LEADING_EDGE' : 'THIN_OUTSIDE';
    }
  }

  // Exit velocity calculation
  const incomingSpeed = Math.hypot(ball.velocity.x, ball.velocity.y, ball.velocity.z);
  const batSpeedMps = (18 + swing.power * 16) * (player.attributes.power / 100);

  // Coefficient of restitution for willow bat: 0.55 sweet spot, 0.2 edge
  const restitution = isEdge ? 0.22 : 0.58;
  let exitSpeed = incomingSpeed * restitution + batSpeedMps * contactQuality * spec.powerMultiplier;
  if (swing.isDefensive) {
    exitSpeed = Math.min(exitSpeed, 8 + Math.random() * 6);
  }

  // Direction: player aim + shot target angle + edge deflection
  let shotAngle = swing.aimAngle;
  if (Math.abs(shotAngle) < 0.01) {
    // If not manually aiming with stick, default to shot spec
    shotAngle = spec.targetAngleRad;
    if (player.battingStyle === 'LEFT_HAND') {
      shotAngle = -shotAngle; // mirror for left handers
    }
  }

  // Adjust launch angle
  let launchDeg = spec.launchAngleDeg;
  if (swing.isLofted) {
    launchDeg = Math.max(26, launchDeg + 18);
  }
  if (isEdge) {
    launchDeg = 12 + Math.random() * 25;
    // Edge deflections: thick edge goes fine to slips/gully
    if (edgeType === 'THICK_OUTSIDE' || edgeType === 'THIN_OUTSIDE') {
      shotAngle = player.battingStyle === 'RIGHT_HAND' ? (Math.PI * 0.65) : (-Math.PI * 0.65);
      exitSpeed *= 0.65;
    } else if (edgeType === 'INSIDE_EDGE') {
      shotAngle = player.battingStyle === 'RIGHT_HAND' ? (-Math.PI * 0.7) : (Math.PI * 0.7);
      launchDeg = 3;
      exitSpeed *= 0.5;
    }
  }

  // Convert angles into 3D velocity vector
  // shotAngle: 0 is toward +Z (bowler), +PI/2 is +X (off-side/covers), -PI/2 is -X (leg-side)
  const launchRad = (launchDeg * Math.PI) / 180;
  const horizontalSpeed = exitSpeed * Math.cos(launchRad);
  const vy = exitSpeed * Math.sin(launchRad);
  const vz = horizontalSpeed * Math.cos(shotAngle);
  const vx = horizontalSpeed * Math.sin(shotAngle);

  ball.hitBat = true;
  ball.velocity = { x: vx, y: vy, z: vz };

  let description = `${swing.type.replace(/_/g, ' ')} (${timingCategory})`;
  if (isEdge) {
    description = `EDGE! ${edgeType?.replace(/_/g, ' ')} off the willow!`;
  } else if (timingCategory === 'PERFECT') {
    description = `PURE CRACK! Sublime timing on that ${swing.type.replace(/_/g, ' ').toLowerCase()}!`;
  } else if (contactQuality > 0.75) {
    description = `Well-timed ${swing.type.replace(/_/g, ' ').toLowerCase()} through the field!`;
  }

  return {
    hitBat: true,
    hitPad: false,
    contactQuality,
    timingCategory,
    timingErrorMs,
    shotType: swing.type,
    exitVelocity: { x: vx, y: vy, z: vz },
    isEdge,
    edgeType,
    launchAngleDeg: launchDeg,
    horizontalAngleDeg: (shotAngle * 180) / Math.PI,
    description,
  };
}
