import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'County Cricket 2027 | 3D English County Cricket Engine',
  description: 'Fully playable 3D English County Cricket game engine featuring real physical ball and bat simulation, 18 county teams, interactive batting, bowling, running, fielding, hawk-eye reviews, and domestic competitions.',
  openGraph: {
    title: 'County Cricket 2027 | 3D English County Cricket Engine',
    description: 'Fully playable 3D English County Cricket game engine featuring real physical ball and bat simulation, 18 county teams, interactive batting, bowling, running, fielding, hawk-eye reviews, and domestic competitions.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'County Cricket 2027 | 3D English County Cricket Engine',
    description: 'Fully playable 3D English County Cricket game engine featuring real physical ball and bat simulation, 18 county teams, interactive batting, bowling, running, fielding, hawk-eye reviews, and domestic competitions.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
