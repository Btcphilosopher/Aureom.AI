'use client';

import React, { useState } from 'react';
import {
  CameraViewMode,
  CompetitionType,
  DeliveryOutcome,
  MatchState,
  PitchCondition,
  ShotType,
  TimingCategory,
  WeatherCondition,
} from '@/lib/cricket/types';
import { CricketCanvas } from '@/components/cricket/CricketCanvas';
import { ScoreboardHUD } from '@/components/cricket/ScoreboardHUD';
import { ControlsDeck } from '@/components/cricket/ControlsDeck';
import { MatchSetupModal } from '@/components/cricket/MatchSetupModal';
import { FieldPreset } from '@/lib/cricket/engine/fielding';
import { cricketAudio } from '@/lib/cricket/audio/cricketAudio';
import { createNewMatch } from '@/lib/cricket/engine/match';

export default function CountyCricketPage() {
  // Match Configuration State
  const [homeCountyId, setHomeCountyId] = useState<string>('SURREY');
  const [awayCountyId, setAwayCountyId] = useState<string>('YORKSHIRE');
  const [competition, setCompetition] = useState<CompetitionType>('COUNTY_T20');
  const [weather, setWeather] = useState<WeatherCondition>('ENGLISH_SUMMER');
  const [pitch, setPitch] = useState<PitchCondition>('FRESH_GREEN');

  // Match Engine State
  const [matchState, setMatchState] = useState<MatchState>(() =>
    createNewMatch('SURREY', 'YORKSHIRE', 'COUNTY_T20', 'ENGLISH_SUMMER', 'FRESH_GREEN')
  );

  // Gameplay Settings & Selection
  const [cameraMode, setCameraMode] = useState<CameraViewMode>('BATSMAN');
  const [selectedShotType, setSelectedShotType] = useState<ShotType>('STRAIGHT_DRIVE');
  const [selectedIsLofted, setSelectedIsLofted] = useState<boolean>(false);
  const [fieldPreset, setFieldPreset] = useState<FieldPreset>('STANDARD_BALANCED');
  const [showDebug, setShowDebug] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Delivery Feedback & Reviews
  const [lastOutcome, setLastOutcome] = useState<DeliveryOutcome | null>(null);
  const [timingNotice, setTimingNotice] = useState<{
    category: TimingCategory;
    speedMph: number;
    text: string;
  } | null>(null);

  // Modal State
  const [isSetupOpen, setIsSetupOpen] = useState<boolean>(false);

  const handleTimingFeedback = (category: TimingCategory, shot: ShotType, speedMph: number) => {
    setTimingNotice({ category, speedMph, text: `${category} Timing on ${shot.replace(/_/g, ' ')}` });
    setTimeout(() => {
      setTimingNotice(null);
    }, 2800);
  };

  const handleNewDeliveryOutcome = (outcome: DeliveryOutcome) => {
    setLastOutcome(outcome);
  };

  const handleSoundToggle = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    cricketAudio.setMuted(nextMute);
  };

  const handleAppeal = () => {
    cricketAudio.playAppeal();
  };

  const handleStartNewMatch = (config: {
    homeCountyId: string;
    awayCountyId: string;
    competition: CompetitionType;
    weather: WeatherCondition;
    pitch: PitchCondition;
  }) => {
    setHomeCountyId(config.homeCountyId);
    setAwayCountyId(config.awayCountyId);
    setCompetition(config.competition);
    setWeather(config.weather);
    setPitch(config.pitch);
    setMatchState(
      createNewMatch(
        config.homeCountyId,
        config.awayCountyId,
        config.competition,
        config.weather,
        config.pitch
      )
    );
    setLastOutcome(null);
  };

  return (
    <main className="flex flex-col h-screen w-screen bg-slate-950 overflow-hidden font-sans">
      {/* Top Application Bar */}
      <header className="h-12 bg-slate-950 border-b border-slate-800 px-4 flex items-center justify-between z-20 shrink-0 select-none">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏏</span>
            <h1 className="text-sm font-black tracking-wider text-slate-100 uppercase">
              County Cricket <span className="text-amber-500 font-mono">2027</span>
            </h1>
          </div>
          <span className="hidden sm:inline text-slate-700">|</span>
          <span className="hidden sm:inline text-[11px] font-bold text-amber-400/90 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/20">
            {competition.replace(/_/g, ' ')}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Sound Mute Button */}
          <button
            onClick={handleSoundToggle}
            className={`p-1.5 rounded-lg border text-xs font-semibold transition ${
              isMuted
                ? 'bg-rose-950/40 border-rose-800/80 text-rose-300'
                : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
            }`}
            title="Toggle Sound FX"
          >
            {isMuted ? '🔇 Audio Muted' : '🔊 Audio ON'}
          </button>

          {/* Telemetry Toggle */}
          <button
            onClick={() => setShowDebug(!showDebug)}
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition ${
              showDebug
                ? 'bg-emerald-950 border-emerald-500 text-emerald-400'
                : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle Physics Engine Telemetry"
          >
            60Hz Engine {showDebug ? 'ON' : 'OFF'}
          </button>

          {/* Match Setup Button */}
          <button
            onClick={() => setIsSetupOpen(true)}
            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs uppercase tracking-wider transition active:scale-95 shadow-md shadow-amber-500/20"
          >
            Match Fixtures ⚙️
          </button>
        </div>
      </header>

      {/* Main 3D Cricket Ground Canvas + Broadcast Overlay */}
      <div className="relative flex-1 w-full bg-slate-950 overflow-hidden flex flex-col">
        {/* Real-time Broadcast Scoreboard & Over Tracker */}
        <div className="absolute top-0 left-0 right-0 z-10">
          <ScoreboardHUD
            match={matchState}
            lastOutcome={lastOutcome}
            timingNotice={timingNotice}
          />
        </div>

        {/* 3D Physical Simulation Stage */}
        <CricketCanvas
          homeCountyId={homeCountyId}
          awayCountyId={awayCountyId}
          competition={competition}
          weather={weather}
          pitch={pitch}
          cameraMode={cameraMode}
          onCameraChange={setCameraMode}
          showDebug={showDebug}
          onMatchUpdate={setMatchState}
          onNewDeliveryOutcome={handleNewDeliveryOutcome}
          onTimingFeedback={handleTimingFeedback}
          selectedShotType={selectedShotType}
          selectedIsLofted={selectedIsLofted}
          onTriggerShot={() => {}}
          fieldPreset={fieldPreset}
        />
      </div>

      {/* Interactive Bottom Tactics Deck & Controller */}
      <div className="z-20 shrink-0">
        <ControlsDeck
          match={matchState}
          selectedShot={selectedShotType}
          onSelectShot={setSelectedShotType}
          isLofted={selectedIsLofted}
          onToggleLofted={setSelectedIsLofted}
          fieldPreset={fieldPreset}
          onSelectFieldPreset={setFieldPreset}
          lastOutcome={lastOutcome}
          onAppeal={handleAppeal}
        />
      </div>

      {/* Match Setup Modal */}
      <MatchSetupModal
        isOpen={isSetupOpen}
        onClose={() => setIsSetupOpen(false)}
        onStartMatch={handleStartNewMatch}
        currentHome={homeCountyId}
        currentAway={awayCountyId}
        currentComp={competition}
        currentWeather={weather}
        currentPitch={pitch}
      />
    </main>
  );
}
