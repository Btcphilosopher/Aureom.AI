/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Digital Twin Runtime, Telemetry Calibration, Degradation & MPC
 */

import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  Cpu, 
  TrendingDown, 
  Sliders, 
  AlertTriangle, 
  CheckCircle, 
  Layers, 
  Play,
  RotateCcw
} from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { 
  DigitalTwinEngine, 
  DigitalTwinMode, 
  PlantMeasuredTelemetry, 
  CalibrationResult,
  DegradationStep,
  MPCDecisionStep
} from '../thermo/digital_twin';

interface DigitalTwinLabProps {
  solvedCycle: SolvedCycleResult;
}

export const DigitalTwinLab: React.FC<DigitalTwinLabProps> = ({ solvedCycle }) => {
  const [twinMode, setTwinMode] = useState<DigitalTwinMode>('CALIBRATION_MODE');
  
  const digitalTwin = useMemo(() => {
    return new DigitalTwinEngine(solvedCycle.params);
  }, [solvedCycle.params]);

  // Synthetic Plant Telemetry
  const [telemetry, setTelemetry] = useState<PlantMeasuredTelemetry>({
    timestamp: new Date().toISOString(),
    boilerPressureMPa: solvedCycle.params.boilerPressureMPa * 0.98,
    superheatTempC: solvedCycle.params.superheatTemperatureC - 8.0,
    throttleSteamFlowKgs: solvedCycle.params.throttleMassFlowKgs * 0.96,
    reheatPressureMPa: solvedCycle.params.reheatPressureMPa * 0.97,
    reheatTempC: solvedCycle.params.reheatTemperatureC - 6.0,
    condenserPressureKPa: solvedCycle.params.condenserPressureKPa * 1.18, // degraded vacuum
    generatorGrossPowerMW: solvedCycle.summary.grossTurbinePowerMW * 0.935, // -6.5% power
    coolingWaterInletTempC: solvedCycle.params.coolingWaterInletTempC + 2.0,
    coolingWaterOutletTempC: solvedCycle.params.coolingWaterInletTempC + solvedCycle.params.coolingWaterDeltaTC + 1.5,
    feedwaterTempC: 215.0,
  });

  const calibrationResult: CalibrationResult = useMemo(() => {
    return digitalTwin.calibrateFromTelemetry(telemetry);
  }, [digitalTwin, telemetry]);

  const degradationProfile: DegradationStep[] = useMemo(() => {
    return digitalTwin.simulateDegradationProfile();
  }, [digitalTwin]);

  const mpcSchedule: MPCDecisionStep[] = useMemo(() => {
    return digitalTwin.runMPCSimulation();
  }, [digitalTwin]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Thermodynamic Digital Twin & Supervisory Controller
          </h1>
          <p className="text-xs text-slate-400">
            Bidirectional state estimation from DCS sensors, equipment health degradation tracking (Year 0 → 20), and 24-hr Model Predictive Control (MPC).
          </p>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded">
          {(['CALIBRATION_MODE', 'DEGRADATION_MODE', 'MPC_MODE'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setTwinMode(mode as any)}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                twinMode === mode ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
              }`}
            >
              {mode.replace('_MODE', '')}
            </button>
          ))}
        </div>
      </div>

      {/* 1. CALIBRATION & ANOMALY DETECTION */}
      {twinMode === 'CALIBRATION_MODE' && (
        <div className="space-y-6">
          
          {/* Anomaly Banners */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
            <div className="text-amber-400 font-bold uppercase mb-2 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>Plant Telemetry Health & Anomaly Inversion</span>
            </div>
            <div className="space-y-1 text-slate-300">
              {calibrationResult.identifiedAnomalies.map((anom, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-amber-400">▶</span>
                  <span>{anom}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Calibrated Parameter Inversion Table */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
                Estimated Internal Degradation Parameters
              </h2>

              <div className="space-y-3 text-xs font-mono">
                <div className="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-400">Calibrated HP Turbine Isentropic Eff:</span>
                  <span className="text-cyan-400 font-bold">
                    {(calibrationResult.estimatedHpTurbineEff * 100).toFixed(2)}% (Design: {(solvedCycle.params.hpTurbineEfficiency * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-400">Calibrated LP Turbine Isentropic Eff:</span>
                  <span className="text-cyan-400 font-bold">
                    {(calibrationResult.estimatedLpTurbineEff * 100).toFixed(2)}% (Design: {(solvedCycle.params.lpTurbineEfficiency * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-400">Condenser Heat Transfer UA:</span>
                  <span className="text-blue-400 font-bold">{calibrationResult.estimatedCondenserUAMWK.toFixed(1)} MW/K</span>
                </div>
                <div className="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-400">Turbine Blade Roughness Degradation:</span>
                  <span className="text-rose-400 font-bold">+{calibrationResult.turbineBladeRoughnessDegradationPct.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span className="text-slate-400">Least-Squares Fit Residual RMSE:</span>
                  <span className="text-emerald-400 font-bold">{calibrationResult.fittingResidualRMSE.toFixed(4)}</span>
                </div>
              </div>
            </div>

            {/* Live Telemetry Inputs */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
              <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
                DCS Telemetry Feed (Live Stream)
              </h2>

              <div className="space-y-3 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Measured Gross Generator Power:</span>
                  <span className="text-white font-bold tabular-nums">{telemetry.generatorGrossPowerMW.toFixed(1)} MW</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Measured Throttle Pressure:</span>
                  <span className="text-white font-bold tabular-nums">{telemetry.boilerPressureMPa.toFixed(2)} MPa</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Measured Superheat Temp:</span>
                  <span className="text-white font-bold tabular-nums">{telemetry.superheatTempC.toFixed(1)} °C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Measured Condenser Vacuum:</span>
                  <span className="text-white font-bold tabular-nums">{telemetry.condenserPressureKPa.toFixed(2)} kPa</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* 2. 20-YEAR LIFECYCLE DEGRADATION */}
      {twinMode === 'DEGRADATION_MODE' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
            20-Year Lifecycle Thermal Degradation & Economic Forecast
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800">
                <tr>
                  <th className="px-3 py-3">Plant Age</th>
                  <th className="px-3 py-3 text-right">HP Turb Eff (%)</th>
                  <th className="px-3 py-3 text-right">LP Turb Eff (%)</th>
                  <th className="px-3 py-3 text-right">Boiler Eff (%)</th>
                  <th className="px-3 py-3 text-right">Net Power (MW)</th>
                  <th className="px-3 py-3 text-right">Thermal Eff (%)</th>
                  <th className="px-3 py-3 text-right">Heat Rate (kJ/kWh)</th>
                  <th className="px-3 py-3 text-right">Annual Fuel ($M)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 tabular-nums">
                {degradationProfile.map((step) => (
                  <tr key={step.year} className="hover:bg-slate-800/50">
                    <td className="px-3 py-3 font-bold text-cyan-300">
                      {step.year === 0 ? 'Year 0 (Commissioning)' : `Year ${step.year}`}
                    </td>
                    <td className="px-3 py-3 text-right text-slate-200">{step.hpTurbineEffPct}%</td>
                    <td className="px-3 py-3 text-right text-slate-200">{step.lpTurbineEffPct}%</td>
                    <td className="px-3 py-3 text-right text-slate-200">{step.boilerEffPct}%</td>
                    <td className="px-3 py-3 text-right font-bold text-white">{step.netPowerMW}</td>
                    <td className="px-3 py-3 text-right font-bold text-cyan-400">{step.thermalEfficiencyPct}%</td>
                    <td className="px-3 py-3 text-right text-amber-400">{step.heatRateKjKwh}</td>
                    <td className="px-3 py-3 text-right font-bold text-emerald-400">${step.annualFuelCostMUSD}M</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. 24-HOUR MPC DISPATCH */}
      {twinMode === 'MPC_MODE' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
            Model Predictive Control (MPC) 24-Hour Load-Following Dispatch
          </h2>

          <div className="overflow-x-auto max-h-96">
            <table className="w-full text-xs text-left font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800 sticky top-0">
                <tr>
                  <th className="px-3 py-2">Hour</th>
                  <th className="px-3 py-2 text-right">Grid Demand (MW)</th>
                  <th className="px-3 py-2 text-right">Actual Power (MW)</th>
                  <th className="px-3 py-2 text-right">Boiler P Setpoint (MPa)</th>
                  <th className="px-3 py-2 text-right">Steam Flow (kg/s)</th>
                  <th className="px-3 py-2 text-right">Ramp Rate (MW/min)</th>
                  <th className="px-3 py-2 text-right">Tracking Error (MW)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 tabular-nums">
                {mpcSchedule.map((step) => (
                  <tr key={step.timeStep} className="hover:bg-slate-800/50">
                    <td className="px-3 py-2 font-bold text-cyan-300">{step.timeStep}:00</td>
                    <td className="px-3 py-2 text-right text-slate-300">{step.gridDemandMW}</td>
                    <td className="px-3 py-2 text-right font-bold text-white">{step.actualNetPowerMW}</td>
                    <td className="px-3 py-2 text-right text-cyan-400">{step.boilerPressureSetpointMPa}</td>
                    <td className="px-3 py-2 text-right text-slate-200">{step.steamFlowSetpointKgs}</td>
                    <td className="px-3 py-2 text-right text-amber-400">{step.rampRateMWperMin}</td>
                    <td className="px-3 py-2 text-right font-bold text-emerald-400">{step.trackingErrorMW}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
