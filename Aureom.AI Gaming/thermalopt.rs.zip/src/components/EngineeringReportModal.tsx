/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Comprehensive Engineering Performance Report Modal
 */

import React, { useState } from 'react';
import { X, Download, Copy, CheckCircle, Printer, FileText } from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';

interface EngineeringReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  solvedCycle: SolvedCycleResult;
}

export const EngineeringReportModal: React.FC<EngineeringReportModalProps> = ({
  isOpen,
  onClose,
  solvedCycle,
}) => {
  if (!isOpen) return null;

  const [copied, setCopied] = useState(false);
  const { summary, states, components, exergyLossBreakdown, params, provenance } = solvedCycle;

  const generateMarkdownReport = () => {
    return `# THERMALOPT.RS — THERMODYNAMIC AUDIT & PERFORMANCE REPORT
Run ID: ${provenance.runId}
Timestamp: ${provenance.timestamp}
Engine: ${provenance.engineVersion}
Cycle Name: ${params.cycleName}
Working Fluid: ${params.workingFluid}

================================================================================
1. EXECUTIVE PERFORMANCE SUMMARY
================================================================================
Net Electrical Output (W_net)       : ${summary.netPowerMW.toFixed(2)} MW
Gross Turbine Power (W_gross)       : ${summary.grossTurbinePowerMW.toFixed(2)} MW
Total Pump Power (W_pumps)          : ${summary.totalPumpPowerMW.toFixed(2)} MW
First-Law Thermal Efficiency (η_th) : ${summary.thermalEfficiencyPct.toFixed(2)} %
Ideal Carnot Efficiency (η_carnot)  : ${summary.carnotEfficiencyPct.toFixed(2)} %
Second-Law Exergy Efficiency (η_ex) : ${summary.exergyEfficiencyPct.toFixed(2)} %
Net Plant Heat Rate (HR)            : ${summary.heatRateKjKwh.toFixed(1)} kJ/kWh (${(summary.heatRateKjKwh * 0.9478).toFixed(1)} Btu/kWh)
Total Thermal Heat Input (Q_in)     : ${summary.totalHeatInputMW.toFixed(2)} MWth
Condenser Heat Rejection (Q_cond)   : ${summary.condenserHeatRejectionMW.toFixed(2)} MWth
Cooling Water Mass Flow             : ${summary.coolingWaterFlowKgs.toFixed(1)} kg/s
LP Turbine Exhaust Steam Quality    : ${(summary.turbineExhaustQuality * 100).toFixed(2)} %
Total Exergy Destruction Rate (İ)   : ${summary.totalExergyDestructionMW.toFixed(2)} MW
Energy Balance Closure Residual     : ${summary.energyBalanceClosureErrorMW.toFixed(6)} MW [VERIFIED]

================================================================================
2. THERMODYNAMIC STATE VECTORS (IAPWS-IF97)
================================================================================
${states.map(s => `[${s.id}] ${s.name.padEnd(28)} | P = ${s.pressureMPa.toFixed(3).padStart(6)} MPa | T = ${s.temperatureC.toFixed(1).padStart(6)} °C | h = ${s.specificEnthalpy.toFixed(1).padStart(7)} kJ/kg | s = ${s.specificEntropy.toFixed(4).padStart(7)} kJ/kg·K | x = ${(s.quality >= 0 ? (s.quality * 100).toFixed(1) + '%' : 'N/A').padStart(6)} | Prov: ${s.source}`).join('\n')}

================================================================================
3. SECOND-LAW EXERGY DESTRUCTION BREAKDOWN
================================================================================
${exergyLossBreakdown.map(e => `${e.component.padEnd(36)} : ${e.exergyDestroyedMW.toFixed(2).padStart(6)} MW (${e.pctOfTotal.toFixed(1)}% of cycle losses)`).join('\n')}

================================================================================
4. ECONOMIC & CARBON EMISSION DISPATCH
================================================================================
Fuel Cost                          : $${params.heatSource.fuelCostPerGJ.toFixed(2)} / GJ
Levelised Operating Energy Cost    : $${summary.operatingCostPerMWh.toFixed(2)} / MWh
Hourly CO2 Emission Rate           : ${summary.co2EmissionsTonsPerHour.toFixed(2)} tonnes/hr
`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateMarkdownReport());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const text = generateMarkdownReport();
    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `THERMALOPT_Audit_Report_${provenance.runId}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-[#0f141e] border border-slate-700 rounded-lg max-w-3xl w-full p-6 shadow-2xl text-slate-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-base font-bold text-white font-mono uppercase">
                Thermodynamic Audit & Performance Report
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Run ID: {provenance.runId} · Engine: {provenance.engineVersion}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-mono flex items-center gap-1 transition-colors"
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-2.5 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-black font-bold rounded text-xs font-mono flex items-center gap-1 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download (.md)</span>
            </button>

            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Content Box */}
        <pre className="flex-1 w-full bg-slate-950 border border-slate-800 rounded p-4 font-mono text-xs text-slate-200 overflow-y-auto whitespace-pre leading-relaxed">
          {generateMarkdownReport()}
        </pre>

      </div>
    </div>
  );
};
