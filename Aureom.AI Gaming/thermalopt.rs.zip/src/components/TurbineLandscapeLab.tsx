/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Turbine & Thermodynamic Performance Landscape Lab
 */

import React, { useState, useMemo } from 'react';
import { Layers, Grid, Play, Zap } from 'lucide-react';
import { CycleDesignParameters } from '../thermo/components';
import { solveRankineCycle } from '../thermo/cycle_solver';

interface TurbineLandscapeLabProps {
  baseParams: CycleDesignParameters;
}

export const TurbineLandscapeLab: React.FC<TurbineLandscapeLabProps> = ({ baseParams }) => {
  const [metricTarget, setMetricTarget] = useState<'EFFICIENCY' | 'NET_POWER' | 'HEAT_RATE' | 'EXERGY_EFFICIENCY'>('EFFICIENCY');
  const [reheatPressureVal, setReheatPressureVal] = useState(baseParams.reheatPressureMPa);

  // Discrete 2D sweep grid: Boiler Pressure [10 to 28 MPa] (8 steps) x Superheat Temp [480 to 620 °C] (8 steps)
  const pBoilerSteps = [10, 12.5, 15, 17.5, 20, 23, 26, 28];
  const tShSteps = [480, 500, 520, 540, 560, 580, 600, 620];

  const gridData = useMemo(() => {
    const matrix: { p: number; t: number; val: number; quality: number }[][] = [];

    for (let i = 0; i < pBoilerSteps.length; i++) {
      const row: { p: number; t: number; val: number; quality: number }[] = [];
      const p = pBoilerSteps[i];
      for (let j = 0; j < tShSteps.length; j++) {
        const t = tShSteps[j];
        const res = solveRankineCycle({
          ...baseParams,
          boilerPressureMPa: p,
          superheatTemperatureC: t,
          reheatPressureMPa: reheatPressureVal,
        }, 'SIMULATED');

        let val = 0;
        if (metricTarget === 'EFFICIENCY') val = res.summary.thermalEfficiencyPct;
        else if (metricTarget === 'NET_POWER') val = res.summary.netPowerMW;
        else if (metricTarget === 'EXERGY_EFFICIENCY') val = res.summary.exergyEfficiencyPct;
        else val = res.summary.heatRateKjKwh;

        row.push({ p, t, val: +val.toFixed(2), quality: res.summary.turbineExhaustQuality });
      }
      matrix.push(row);
    }
    return matrix;
  }, [baseParams, metricTarget, reheatPressureVal]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Turbine Thermodynamic Landscape & Parametric Field
          </h1>
          <p className="text-xs text-slate-400">
            2D/3D performance surface map across Boiler Main Steam Pressure (10–28 MPa) and Superheat Temperature (480–620 °C).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={metricTarget}
            onChange={(e) => setMetricTarget(e.target.value as any)}
            className="bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-cyan-300"
          >
            <option value="EFFICIENCY">First-Law Thermal Efficiency (%)</option>
            <option value="NET_POWER">Net Electrical Power (MW)</option>
            <option value="EXERGY_EFFICIENCY">Second-Law Exergy Efficiency (%)</option>
            <option value="HEAT_RATE">Net Heat Rate (kJ/kWh)</option>
          </select>
        </div>
      </div>

      {/* Heatmap Grid View */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
          Response Surface Contour Grid (64 Discrete Thermodynamic Cycle Evaluations)
        </h2>

        <div className="overflow-x-auto">
          <div className="min-w-[650px] font-mono text-xs">
            {/* Column Headers (Superheat Temps) */}
            <div className="grid grid-cols-9 gap-1 mb-1 text-center font-bold text-slate-400">
              <div className="text-left text-slate-500 text-[10px]">P_boiler \ T_sh</div>
              {tShSteps.map(t => (
                <div key={t} className="p-1 bg-slate-950 rounded border border-slate-800 text-slate-300">
                  {t}°C
                </div>
              ))}
            </div>

            {/* Rows (Boiler Pressures) */}
            {gridData.map((row, rIdx) => (
              <div key={rIdx} className="grid grid-cols-9 gap-1 mb-1">
                <div className="p-2 bg-slate-950 rounded border border-slate-800 text-slate-300 font-bold flex items-center">
                  {pBoilerSteps[rIdx]} MPa
                </div>
                {row.map((cell, cIdx) => {
                  // Color interpolation: higher is cyan/emerald
                  const isErosion = cell.quality < 0.86;
                  return (
                    <div
                      key={cIdx}
                      className={`p-2 rounded text-center font-bold transition-transform hover:scale-105 cursor-pointer ${
                        isErosion
                          ? 'bg-rose-950/70 border border-rose-700/60 text-rose-300'
                          : 'bg-cyan-950/50 border border-cyan-800/40 text-cyan-300'
                      }`}
                      title={`P = ${cell.p} MPa, T = ${cell.t} °C -> ${cell.val} (x = ${(cell.quality * 100).toFixed(1)}%)`}
                    >
                      <div>{cell.val}</div>
                      <div className="text-[9px] text-slate-400 font-normal">
                        x: {(cell.quality * 100).toFixed(0)}%
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between text-xs font-mono text-slate-400 border-t border-slate-800 pt-3">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-cyan-900 border border-cyan-700" />
              <span>Normal Operation Domain</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-rose-950 border border-rose-700" />
              <span>Wilson Line Moisture Violation (&lt;86% Quality)</span>
            </span>
          </div>
          <span>IAPWS-IF97 Surface Mesh</span>
        </div>
      </div>

    </div>
  );
};
