/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Multi-Objective & Single-Objective Optimization Lab (Pareto / DE)
 */

import React, { useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  Check, 
  TrendingUp, 
  Zap, 
  Sliders, 
  Award, 
  ArrowRight,
  Layers
} from 'lucide-react';
import { CycleDesignParameters } from '../thermo/components';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { 
  runOptimization, 
  OptimizationObjective, 
  OptimizationMethod, 
  OptimizationResult,
  ParetoCandidate 
} from '../thermo/optimisation';

interface OptimizationLabProps {
  currentParams: CycleDesignParameters;
  solvedCycle: SolvedCycleResult;
  onApplyOptimalParams: (optimal: CycleDesignParameters) => void;
}

export const OptimizationLab: React.FC<OptimizationLabProps> = ({
  currentParams,
  solvedCycle,
  onApplyOptimalParams,
}) => {
  const [objective, setObjective] = useState<OptimizationObjective>('MAX_THERMAL_EFFICIENCY');
  const [method, setMethod] = useState<OptimizationMethod>('DIFFERENTIAL_EVOLUTION');
  const [populationSize, setPopulationSize] = useState(40);
  const [generations, setGenerations] = useState(25);
  
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optResult, setOptResult] = useState<OptimizationResult | null>(null);
  const [selectedParetoPoint, setSelectedParetoPoint] = useState<ParetoCandidate | null>(null);
  const [applied, setApplied] = useState(false);

  const handleStartOptimization = () => {
    setIsOptimizing(true);
    setApplied(false);
    
    // Defer slightly for smooth UI render
    setTimeout(() => {
      const res = runOptimization(currentParams, objective, method, populationSize, generations);
      setOptResult(res);
      if (res.paretoFrontier.length > 0) {
        setSelectedParetoPoint(res.paretoFrontier[0]);
      }
      setIsOptimizing(false);
    }, 100);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Thermodynamic Optimization & Pareto Search Engine
          </h1>
          <p className="text-xs text-slate-400">
            Parallel evolutionary metaheuristics searching high-dimensional thermodynamic state spaces under strict physical and metallurgical constraints.
          </p>
        </div>

        <button
          onClick={handleStartOptimization}
          disabled={isOptimizing}
          className="flex items-center gap-2 px-5 py-2 text-xs font-bold font-mono text-black bg-cyan-400 hover:bg-cyan-300 disabled:bg-slate-700 disabled:text-slate-400 rounded transition-colors shadow-lg"
        >
          {isOptimizing ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
              <span>SEARCHING STATE SPACE...</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>RUN OPTIMIZER</span>
            </>
          )}
        </button>
      </div>

      {/* Configuration Controls */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-900 border border-slate-800 rounded-lg p-4 text-xs font-mono">
        <div>
          <label className="block text-slate-400 mb-1">Primary Objective:</label>
          <select
            value={objective}
            onChange={(e) => setObjective(e.target.value as OptimizationObjective)}
            className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
          >
            <option value="MAX_THERMAL_EFFICIENCY">Max Thermal Efficiency (η_th)</option>
            <option value="MAX_NET_POWER">Max Net Electrical Power (W_net)</option>
            <option value="MAX_EXERGY_EFFICIENCY">Max Second-Law Exergy Efficiency</option>
            <option value="MIN_HEAT_RATE">Min Net Heat Rate (kJ/kWh)</option>
            <option value="MIN_OPERATING_COST">Min Levelised Operating Cost ($/MWh)</option>
            <option value="MIN_EXERGY_DESTRUCTION">Min Exergy Destruction (MW)</option>
            <option value="MULTI_OBJECTIVE_PARETO">Multi-Objective Pareto Trade-Off</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Numerical Algorithm:</label>
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value as OptimizationMethod)}
            className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
          >
            <option value="DIFFERENTIAL_EVOLUTION">Differential Evolution (DE/rand/1/bin)</option>
            <option value="NSGA_II">NSGA-II Non-Dominated Sorting</option>
            <option value="LATIN_HYPERCUBE">Latin Hypercube Design of Experiments (LHS)</option>
            <option value="NELDER_MEAD">Nelder-Mead Simplex (Constrained)</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Population Size (N_pop):</label>
          <input
            type="number"
            min="10"
            max="200"
            value={populationSize}
            onChange={(e) => setPopulationSize(+e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
          />
        </div>

        <div>
          <label className="block text-slate-400 mb-1">Generations / Iterations:</label>
          <input
            type="number"
            min="5"
            max="100"
            value={generations}
            onChange={(e) => setGenerations(+e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
          />
        </div>
      </div>

      {/* Optimization Results */}
      {optResult ? (
        <div className="space-y-6">
          
          {/* Improvements Scorecard */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 font-mono block">Efficiency Gain:</span>
              <span className="text-xl font-bold font-mono text-emerald-400">
                +{optResult.improvements.efficiencyGainPctPts} %pts
              </span>
              <span className="text-[10px] text-slate-500 font-mono block">
                {optResult.baseline.summary.thermalEfficiencyPct.toFixed(2)}% → {optResult.bestSolution.summary.thermalEfficiencyPct.toFixed(2)}%
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 font-mono block">Net Power Gain:</span>
              <span className="text-xl font-bold font-mono text-cyan-400">
                +{optResult.improvements.powerGainMW} MW
              </span>
              <span className="text-[10px] text-slate-500 font-mono block">
                {optResult.bestSolution.summary.netPowerMW.toFixed(1)} MW total
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 font-mono block">Heat Rate Reduction:</span>
              <span className="text-xl font-bold font-mono text-white">
                -{optResult.improvements.heatRateReductionKjKwh} kJ/kWh
              </span>
              <span className="text-[10px] text-slate-500 font-mono block">
                {optResult.bestSolution.summary.heatRateKjKwh.toFixed(0)} kJ/kWh
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 font-mono block">Operating Cost Reduction:</span>
              <span className="text-xl font-bold font-mono text-amber-400">
                -{optResult.improvements.costReductionPct} %
              </span>
              <span className="text-[10px] text-slate-500 font-mono block">
                ${optResult.bestSolution.summary.operatingCostPerMWh.toFixed(2)} / MWh
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 font-mono block">Evaluations / Speed:</span>
              <span className="text-xl font-bold font-mono text-purple-400">
                {optResult.evaluationsCount} evals
              </span>
              <span className="text-[10px] text-slate-500 font-mono block">
                in {optResult.executionTimeMs} ms
              </span>
            </div>
          </div>

          {/* Pareto Frontier & Trade-off Explorer */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Pareto Scatter Plot Canvas */}
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                <h3 className="text-sm font-bold text-white font-mono uppercase">
                  Multi-Objective Non-Dominated Pareto Frontier (η_th vs Cost)
                </h3>
                <span className="text-xs font-mono text-slate-400">
                  {optResult.paretoFrontier.length} Non-Dominated Solutions
                </span>
              </div>

              <div className="relative w-full h-72 bg-slate-950 rounded border border-slate-800 p-2 overflow-hidden flex items-center justify-center">
                <svg viewBox="0 0 600 260" className="w-full h-full font-mono text-[10px]">
                  <line x1="50" y1="220" x2="550" y2="220" stroke="#334155" />
                  <line x1="50" y1="30" x2="50" y2="220" stroke="#334155" />

                  <text x="300" y="248" textAnchor="middle" fill="#94a3b8">Thermal Efficiency (%)</text>
                  <text x="15" y="130" textAnchor="middle" fill="#94a3b8" transform="rotate(-90 15,130)">Cost ($/MWh)</text>

                  {/* Scatter Pareto Points */}
                  {optResult.paretoFrontier.map((p, idx) => {
                    // Map x: 35% - 48% -> [70, 530]
                    const cx = 70 + ((p.thermalEfficiencyPct - 35) / 13) * 460;
                    // Map y: 40 - 70 $/MWh -> [200, 50]
                    const cy = 200 - ((p.operatingCostPerMWh - 35) / 35) * 150;
                    const isSelected = selectedParetoPoint?.id === p.id;

                    return (
                      <g
                        key={p.id}
                        className="cursor-pointer"
                        onClick={() => setSelectedParetoPoint(p)}
                      >
                        <circle
                          cx={cx}
                          cy={cy}
                          r={isSelected ? 6 : 4}
                          fill={isSelected ? '#f59e0b' : '#06b6d4'}
                          stroke={isSelected ? '#ffffff' : '#0891b2'}
                          strokeWidth="1.5"
                        />
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>

            {/* Selected Pareto Point Parameters */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-3">
                  Optimal Operating Setpoint
                </h3>

                {selectedParetoPoint ? (
                  <div className="space-y-2.5 text-xs font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Boiler Pressure:</span>
                      <span className="text-cyan-400 font-bold">{selectedParetoPoint.params.boilerPressureMPa.toFixed(2)} MPa</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Superheat Temp:</span>
                      <span className="text-cyan-400 font-bold">{selectedParetoPoint.params.superheatTemperatureC.toFixed(1)} °C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Reheat Pressure:</span>
                      <span className="text-amber-400 font-bold">{selectedParetoPoint.params.reheatPressureMPa.toFixed(2)} MPa</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Reheat Temp:</span>
                      <span className="text-amber-400 font-bold">{selectedParetoPoint.params.reheatTemperatureC.toFixed(1)} °C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Condenser Vacuum:</span>
                      <span className="text-blue-400 font-bold">{selectedParetoPoint.params.condenserPressureKPa.toFixed(2)} kPa</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Exhaust Quality:</span>
                      <span className="text-slate-200 font-bold">{(selectedParetoPoint.exhaustQuality * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 font-mono">Select a candidate on the Pareto plot.</p>
                )}
              </div>

              <button
                onClick={() => {
                  if (selectedParetoPoint) {
                    onApplyOptimalParams(selectedParetoPoint.params);
                    setApplied(true);
                  }
                }}
                disabled={applied || !selectedParetoPoint}
                className="mt-6 w-full py-2.5 bg-cyan-400 hover:bg-cyan-300 disabled:bg-slate-800 disabled:text-emerald-400 text-black font-bold font-mono rounded text-xs transition-colors flex items-center justify-center gap-1.5 shadow"
              >
                {applied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">APPLIED TO ACTIVE CYCLE</span>
                  </>
                ) : (
                  <>
                    <Award className="w-4 h-4" />
                    <span>APPLY THIS OPTIMAL SETPOINT</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>
      ) : (
        <div className="bg-slate-900 border border-dashed border-slate-800 rounded-lg p-12 text-center text-xs font-mono text-slate-400">
          Click <strong className="text-cyan-400">RUN OPTIMIZER</strong> to execute the numerical search across thermodynamic parameter bounds.
        </div>
      )}

    </div>
  );
};
