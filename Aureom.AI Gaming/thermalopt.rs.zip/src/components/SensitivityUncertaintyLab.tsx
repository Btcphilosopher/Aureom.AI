/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Sensitivity Engine & Monte Carlo Uncertainty Laboratory
 */

import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  BarChart2, 
  Sliders, 
  Layers, 
  Play, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { computeSensitivityMatrix, SensitivityMatrixResult } from '../thermo/sensitivity';
import { runUncertaintyAnalysis, UncertaintyQuantificationResult } from '../thermo/uncertainty';

interface SensitivityUncertaintyLabProps {
  solvedCycle: SolvedCycleResult;
}

export const SensitivityUncertaintyLab: React.FC<SensitivityUncertaintyLabProps> = ({ solvedCycle }) => {
  const [activeSubTab, setActiveSubTab] = useState<'SENSITIVITY' | 'MONTE_CARLO' | 'SOBOL'>('SENSITIVITY');
  const [sampleCount, setSampleCount] = useState(200);
  const [isSimulating, setIsSimulating] = useState(false);

  // Compute sensitivity matrix
  const sensitivityResult: SensitivityMatrixResult = useMemo(() => {
    return computeSensitivityMatrix(solvedCycle.params);
  }, [solvedCycle.params]);

  // Uncertainty analysis state
  const [uncertaintyResult, setUncertaintyResult] = useState<UncertaintyQuantificationResult | null>(() => {
    return runUncertaintyAnalysis(solvedCycle.params, 200);
  });

  const handleRunMonteCarlo = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = runUncertaintyAnalysis(solvedCycle.params, sampleCount);
      setUncertaintyResult(res);
      setIsSimulating(false);
    }, 50);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Sensitivity Analysis & Uncertainty Quantification
          </h1>
          <p className="text-xs text-slate-400">
            Jacobian partial derivatives (∂η/∂x), normalized elasticity, Tornado rankings, Monte Carlo P5/P50/P95 confidence intervals, and Sobol global variance decomposition.
          </p>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded">
          <button
            onClick={() => setActiveSubTab('SENSITIVITY')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              activeSubTab === 'SENSITIVITY' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
            }`}
          >
            Jacobian Matrix & Tornado
          </button>
          <button
            onClick={() => setActiveSubTab('MONTE_CARLO')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              activeSubTab === 'MONTE_CARLO' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
            }`}
          >
            Monte Carlo UQ
          </button>
          <button
            onClick={() => setActiveSubTab('SOBOL')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              activeSubTab === 'SOBOL' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
            }`}
          >
            Sobol Global Variance
          </button>
        </div>
      </div>

      {/* 1. SENSITIVITY MATRIX & TORNADO */}
      {activeSubTab === 'SENSITIVITY' && (
        <div className="space-y-6">
          
          {/* Tornado Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
              Tornado Diagram: Impact of ±5% Parameter Perturbations on Thermal Efficiency
            </h2>

            <div className="space-y-3">
              {sensitivityResult.tornadoChartData.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-300">{item.parameter}</span>
                    <span className="text-cyan-400 font-bold tabular-nums">
                      Δη = ±{item.rangePct.toFixed(3)} %pts ({item.lowEfficiency.toFixed(2)}% → {item.highEfficiency.toFixed(2)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden flex items-center">
                    <div
                      className="bg-cyan-500 h-full rounded-full"
                      style={{ width: `${Math.min(100, item.rangePct * 45)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Jacobian Matrix Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
              First-Order Partial Derivative & Dimensionless Elasticity Matrix
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800">
                  <tr>
                    <th className="px-3 py-3">Rank</th>
                    <th className="px-3 py-3">Physical Variable (x_i)</th>
                    <th className="px-3 py-3 text-right">Nominal Value</th>
                    <th className="px-3 py-3 text-right">∂η/∂x (% per unit)</th>
                    <th className="px-3 py-3 text-right">∂W/∂x (MW per unit)</th>
                    <th className="px-3 py-3 text-right">∂HR/∂x (kJ/kWh per unit)</th>
                    <th className="px-3 py-3 text-right font-bold text-cyan-400">Elasticity (∂ln η / ∂ln x)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 tabular-nums">
                  {sensitivityResult.sensitivities.map((s) => (
                    <tr key={s.parameterKey} className="hover:bg-slate-800/50">
                      <td className="px-3 py-3 font-bold text-slate-400">#{s.importanceRank}</td>
                      <td className="px-3 py-3 font-semibold text-slate-200">{s.parameterName}</td>
                      <td className="px-3 py-3 text-right text-slate-300">{s.nominalValue.toFixed(2)} {s.unit}</td>
                      <td className="px-3 py-3 text-right font-bold text-white">{s.dEta_dParam > 0 ? `+${s.dEta_dParam}` : s.dEta_dParam}</td>
                      <td className="px-3 py-3 text-right text-emerald-400">{s.dPower_dParam > 0 ? `+${s.dPower_dParam}` : s.dPower_dParam}</td>
                      <td className="px-3 py-3 text-right text-amber-400">{s.dHeatRate_dParam}</td>
                      <td className="px-3 py-3 text-right font-bold text-cyan-300">{s.efficiencyElasticity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* 2. MONTE CARLO UQ */}
      {activeSubTab === 'MONTE_CARLO' && uncertaintyResult && (
        <div className="space-y-6">
          
          {/* Controls & Metrics */}
          <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
            <div className="flex items-center gap-3">
              <span className="text-slate-400">Sample Count:</span>
              <select
                value={sampleCount}
                onChange={(e) => setSampleCount(+e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
              >
                <option value="100">100 Samples</option>
                <option value="200">200 Samples</option>
                <option value="500">500 Samples</option>
                <option value="1000">1,000 Samples</option>
              </select>
            </div>

            <button
              onClick={handleRunMonteCarlo}
              disabled={isSimulating}
              className="px-4 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-black font-bold rounded flex items-center gap-1.5 transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>RUN MONTE CARLO</span>
            </button>
          </div>

          {/* Statistical Metrics Scorecard */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-xs text-slate-400 block uppercase">P50 (Median) Efficiency</span>
              <span className="text-2xl font-bold text-cyan-400 tabular-nums">
                {uncertaintyResult.thermalEfficiency.p50.toFixed(2)}%
              </span>
              <span className="text-[11px] text-slate-500 block mt-1">
                Mean: {uncertaintyResult.thermalEfficiency.mean.toFixed(2)}% (σ = ±{uncertaintyResult.thermalEfficiency.stdDev.toFixed(2)}%)
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-xs text-slate-400 block uppercase">90% Confidence Interval</span>
              <span className="text-2xl font-bold text-white tabular-nums">
                [{uncertaintyResult.thermalEfficiency.p5.toFixed(2)}% – {uncertaintyResult.thermalEfficiency.p95.toFixed(2)}%]
              </span>
              <span className="text-[11px] text-slate-500 block mt-1">P5 lower to P95 upper bound</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-xs text-slate-400 block uppercase">P50 Net Power</span>
              <span className="text-2xl font-bold text-emerald-400 tabular-nums">
                {uncertaintyResult.netPower.p50.toFixed(1)} MW
              </span>
              <span className="text-[11px] text-slate-500 block mt-1">
                90% CI: [{uncertaintyResult.netPower.p5.toFixed(1)} – {uncertaintyResult.netPower.p95.toFixed(1)} MW]
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
              <span className="text-xs text-slate-400 block uppercase">Distribution Skewness</span>
              <span className="text-2xl font-bold text-amber-400 tabular-nums">
                {uncertaintyResult.thermalEfficiency.skewness.toFixed(3)}
              </span>
              <span className="text-[11px] text-slate-500 block mt-1">Near-Gaussian distribution</span>
            </div>
          </div>

          {/* Histogram Canvas */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
              Monte Carlo Probability Density Histogram ({uncertaintyResult.sampleCount} Evaluated Thermodynamic Cycles)
            </h2>

            <div className="relative w-full h-64 bg-slate-950 rounded border border-slate-800 p-2 overflow-hidden flex items-end justify-between gap-1.5">
              {uncertaintyResult.histogramBins.map((bin, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <div
                    className="w-full bg-cyan-500/80 hover:bg-cyan-400 transition-all rounded-t"
                    style={{ height: `${Math.max(6, (bin.count / uncertaintyResult.sampleCount) * 350)}%` }}
                  />
                  <span className="text-[9px] font-mono text-slate-500 mt-1 truncate">
                    {bin.binMid.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* 3. SOBOL VARIANCE DECOMPOSITION */}
      {activeSubTab === 'SOBOL' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3">
            Sobol Global Variance Decomposition Indices
          </h2>

          <div className="space-y-4 font-mono text-xs">
            {uncertaintyResult?.sobolIndices.map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-200 font-semibold">{item.parameterName}</span>
                  <span className="text-cyan-400 font-bold tabular-nums">
                    S_i = {item.firstOrderIndex.toFixed(3)} | S_Ti = {item.totalOrderIndex.toFixed(3)}
                  </span>
                </div>
                <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden flex">
                  <div className="bg-cyan-400 h-full" style={{ width: `${item.firstOrderIndex * 100}%` }} />
                  <div className="bg-cyan-800 h-full" style={{ width: `${(item.totalOrderIndex - item.firstOrderIndex) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
