/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — What-If Disturbance & Scenario Exploration Lab
 */

import React, { useState } from 'react';
import { Sliders, RotateCcw, AlertTriangle, ArrowRight } from 'lucide-react';
import { CycleDesignParameters } from '../thermo/components';
import { solveRankineCycle, SolvedCycleResult } from '../thermo/cycle_solver';

interface WhatIfLabProps {
  baseParams: CycleDesignParameters;
  baseCycle: SolvedCycleResult;
}

export const WhatIfLab: React.FC<WhatIfLabProps> = ({ baseParams, baseCycle }) => {
  const [disturbedParams, setDisturbedParams] = useState<CycleDesignParameters>({ ...baseParams });
  
  const disturbedCycle = solveRankineCycle(disturbedParams, 'SIMULATED');

  const deltaEff = +(disturbedCycle.summary.thermalEfficiencyPct - baseCycle.summary.thermalEfficiencyPct).toFixed(2);
  const deltaPower = +(disturbedCycle.summary.netPowerMW - baseCycle.summary.netPowerMW).toFixed(1);
  const deltaHR = +(disturbedCycle.summary.heatRateKjKwh - baseCycle.summary.heatRateKjKwh).toFixed(0);

  const applyPresetDisturbance = (type: string) => {
    switch (type) {
      case 'SUMMER_HEATWAVE':
        setDisturbedParams({
          ...baseParams,
          coolingWaterInletTempC: baseParams.coolingWaterInletTempC + 10.0,
          condenserPressureKPa: baseParams.condenserPressureKPa * 1.45,
        });
        break;
      case 'BOILER_PRESSURE_BOOST':
        setDisturbedParams({
          ...baseParams,
          boilerPressureMPa: Math.min(30, baseParams.boilerPressureMPa * 1.2),
        });
        break;
      case 'TURBINE_EROSION':
        setDisturbedParams({
          ...baseParams,
          hpTurbineEfficiency: baseParams.hpTurbineEfficiency * 0.94,
          lpTurbineEfficiency: baseParams.lpTurbineEfficiency * 0.92,
        });
        break;
      case 'HIGH_SUPERHEAT':
        setDisturbedParams({
          ...baseParams,
          superheatTemperatureC: Math.min(620, baseParams.superheatTemperatureC + 40),
          reheatTemperatureC: Math.min(620, baseParams.reheatTemperatureC + 40),
        });
        break;
      default:
        setDisturbedParams({ ...baseParams });
        break;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            What-If Scenario & Disturbance Laboratory
          </h1>
          <p className="text-xs text-slate-400">
            Real-time interactive disturbance testing: simulate seasonal cooling water temperature swings, condenser tube fouling, steam throttling and turbine blade erosion.
          </p>
        </div>

        <button
          onClick={() => setDisturbedParams({ ...baseParams })}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Disturbances</span>
        </button>
      </div>

      {/* Preset Scenario Buttons */}
      <div className="flex flex-wrap gap-2 text-xs font-mono">
        <button
          onClick={() => applyPresetDisturbance('SUMMER_HEATWAVE')}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-amber-400 rounded transition-colors"
        >
          Scenario: +10°C Summer Heatwave (High Backpressure)
        </button>
        <button
          onClick={() => applyPresetDisturbance('BOILER_PRESSURE_BOOST')}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 rounded transition-colors"
        >
          Scenario: +20% Main Steam Pressure Boost
        </button>
        <button
          onClick={() => applyPresetDisturbance('TURBINE_EROSION')}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-rose-400 rounded transition-colors"
        >
          Scenario: -6% Turbine Blade Aerodynamic Wear
        </button>
        <button
          onClick={() => applyPresetDisturbance('HIGH_SUPERHEAT')}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-400 rounded transition-colors"
        >
          Scenario: +40°C Advanced Superheat & Reheat
        </button>
      </div>

      {/* Impact Scorecard Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-xs text-slate-400 block uppercase">Efficiency Impact (Δη)</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className={`text-2xl font-bold ${deltaEff >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {deltaEff >= 0 ? `+${deltaEff}` : deltaEff} %pts
            </span>
          </div>
          <span className="text-[11px] text-slate-500 block mt-1">
            Base: {baseCycle.summary.thermalEfficiencyPct.toFixed(2)}% → New: {disturbedCycle.summary.thermalEfficiencyPct.toFixed(2)}%
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-xs text-slate-400 block uppercase">Net Power Impact (ΔW)</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className={`text-2xl font-bold ${deltaPower >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {deltaPower >= 0 ? `+${deltaPower}` : deltaPower} MW
            </span>
          </div>
          <span className="text-[11px] text-slate-500 block mt-1">
            Base: {baseCycle.summary.netPowerMW.toFixed(1)} MW → New: {disturbedCycle.summary.netPowerMW.toFixed(1)} MW
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <span className="text-xs text-slate-400 block uppercase">Heat Rate Impact (ΔHR)</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className={`text-2xl font-bold ${deltaHR <= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {deltaHR > 0 ? `+${deltaHR}` : deltaHR} kJ/kWh
            </span>
          </div>
          <span className="text-[11px] text-slate-500 block mt-1">
            Base: {baseCycle.summary.heatRateKjKwh.toFixed(0)} → New: {disturbedCycle.summary.heatRateKjKwh.toFixed(0)} kJ/kWh
          </span>
        </div>
      </div>

      {/* Real-time perturbation sliders */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono text-xs">
        <div>
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Boiler Pressure:</span>
            <span className="text-cyan-400 font-bold">{disturbedParams.boilerPressureMPa.toFixed(1)} MPa</span>
          </div>
          <input
            type="range"
            min="5.0"
            max="30.0"
            step="0.5"
            value={disturbedParams.boilerPressureMPa}
            onChange={(e) => setDisturbedParams({ ...disturbedParams, boilerPressureMPa: +e.target.value })}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Condenser Pressure:</span>
            <span className="text-blue-400 font-bold">{disturbedParams.condenserPressureKPa.toFixed(1)} kPa</span>
          </div>
          <input
            type="range"
            min="2.5"
            max="25.0"
            step="0.5"
            value={disturbedParams.condenserPressureKPa}
            onChange={(e) => setDisturbedParams({ ...disturbedParams, condenserPressureKPa: +e.target.value })}
            className="w-full accent-blue-400 cursor-pointer"
          />
        </div>

        <div>
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Cooling Water Inlet Temp:</span>
            <span className="text-amber-400 font-bold">{disturbedParams.coolingWaterInletTempC.toFixed(1)} °C</span>
          </div>
          <input
            type="range"
            min="5.0"
            max="40.0"
            step="1.0"
            value={disturbedParams.coolingWaterInletTempC}
            onChange={(e) => setDisturbedParams({ ...disturbedParams, coolingWaterInletTempC: +e.target.value })}
            className="w-full accent-amber-400 cursor-pointer"
          />
        </div>
      </div>

    </div>
  );
};
