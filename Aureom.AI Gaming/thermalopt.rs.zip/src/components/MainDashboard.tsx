/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Authoritative Main Engineering Workstation Dashboard
 */

import React, { useState } from 'react';
import { 
  Zap, 
  Flame, 
  Gauge, 
  Droplets, 
  Activity, 
  Layers, 
  Calculator, 
  ChevronRight, 
  ShieldCheck, 
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { NavigationTab } from './Navbar';
import { CalculationProofModal } from './CalculationProofModal';

interface MainDashboardProps {
  solvedCycle: SolvedCycleResult;
  setActiveTab: (tab: NavigationTab) => void;
}

export const MainDashboard: React.FC<MainDashboardProps> = ({
  solvedCycle,
  setActiveTab,
}) => {
  const [proofMetric, setProofMetric] = useState<string | null>(null);
  const { summary, states, components, exergyLossBreakdown, params } = solvedCycle;

  // Selected component in schematic
  const [selectedComponent, setSelectedComponent] = useState<string | null>('HP_TURBINE');

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* 1. TOP TELEMETRY / KPI RIBBON */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        
        {/* Net Power */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <span>Net Output</span>
            <button 
              onClick={() => setProofMetric('THERMAL_EFFICIENCY')}
              className="text-slate-500 hover:text-cyan-400 p-0.5"
              title="Inspect Calculation Proof"
            >
              <Calculator className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">
              {summary.netPowerMW.toFixed(1)}
            </span>
            <span className="text-xs font-mono text-slate-400">MW</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            Gross: {summary.grossTurbinePowerMW.toFixed(1)} MW
          </div>
        </div>

        {/* First-Law Thermal Efficiency */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <span>Thermal Eff (η_th)</span>
            <button 
              onClick={() => setProofMetric('THERMAL_EFFICIENCY')}
              className="text-slate-500 hover:text-cyan-400 p-0.5"
              title="Inspect Formula"
            >
              <Calculator className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {summary.thermalEfficiencyPct.toFixed(2)}
            </span>
            <span className="text-xs font-mono text-slate-400">%</span>
          </div>
          <div className="mt-1 text-[11px] text-emerald-400 font-mono flex items-center gap-1">
            <span>Carnot: {summary.carnotEfficiencyPct.toFixed(1)}%</span>
          </div>
        </div>

        {/* Second-Law Exergy Efficiency */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <span>Exergy Eff (η_ex)</span>
            <button 
              onClick={() => setProofMetric('EXERGY_EFFICIENCY')}
              className="text-slate-500 hover:text-cyan-400 p-0.5"
              title="Inspect Formula"
            >
              <Calculator className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              {summary.exergyEfficiencyPct.toFixed(2)}
            </span>
            <span className="text-xs font-mono text-slate-400">%</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            Destr: {summary.totalExergyDestructionMW.toFixed(1)} MW
          </div>
        </div>

        {/* Heat Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <span>Net Heat Rate</span>
            <button 
              onClick={() => setProofMetric('HEAT_RATE')}
              className="text-slate-500 hover:text-cyan-400 p-0.5"
            >
              <Calculator className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {summary.heatRateKjKwh.toFixed(0)}
            </span>
            <span className="text-xs font-mono text-slate-400">kJ/kWh</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            {(summary.heatRateKjKwh * 0.9478).toFixed(0)} Btu/kWh
          </div>
        </div>

        {/* Boiler Heat Input */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <span>Thermal Input (Q_in)</span>
            <button 
              onClick={() => setProofMetric('ENERGY_CLOSURE')}
              className="text-slate-500 hover:text-cyan-400 p-0.5"
            >
              <Calculator className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              {summary.totalHeatInputMW.toFixed(1)}
            </span>
            <span className="text-xs font-mono text-slate-400">MWth</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            Boiler: {summary.heatInputBoilerMW.toFixed(1)} MW
          </div>
        </div>

        {/* Exhaust Quality & Condenser */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <span>Exhaust Quality (x)</span>
            <span className="text-[10px] text-cyan-400 font-mono">LP Exit</span>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-cyan-300 tabular-nums">
              {(summary.turbineExhaustQuality * 100).toFixed(1)}
            </span>
            <span className="text-xs font-mono text-slate-400">%</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 font-mono">
            Cond P: {params.condenserPressureKPa.toFixed(1)} kPa
          </div>
        </div>

      </div>

      {/* 2. MAIN SCHEMATIC & SYNOPTIC VIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Interactive Directed Thermodynamic Schematic */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div>
              <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
                Directed Thermodynamic Machine Graph
              </h2>
              <p className="text-xs text-slate-400">
                Live mass & energy interconnected topology ({states.length} states · {components.length} components)
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>NOMINAL · CLOSURE RESIDUAL: {summary.energyBalanceClosureErrorMW.toFixed(4)} MW</span>
            </div>
          </div>

          {/* SVG Plant Synoptic Diagram */}
          <div className="relative w-full h-80 bg-slate-950 rounded-lg border border-slate-800/80 p-2 overflow-hidden flex items-center justify-center bg-grid-pattern">
            <svg viewBox="0 0 800 360" className="w-full h-full">
              <defs>
                <linearGradient id="steamFlowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#f59e0b" />
                  <stop offset="50%" stopColor="#06b6d4" />
                  <stop offset="100%" stopColor="#3b82f6" />
                </linearGradient>
                <linearGradient id="waterFlowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>

              {/* Piping Connections */}
              {/* Boiler to HP Turbine */}
              <path d="M 170 110 L 280 110" stroke="#f59e0b" strokeWidth="4" fill="none" strokeDasharray="6,3" />
              {/* HP Turbine to Reheater */}
              <path d="M 330 130 L 330 190 L 170 190" stroke="#fbbf24" strokeWidth="3" fill="none" />
              {/* Reheater to IP/LP Turbine */}
              <path d="M 170 210 L 420 210 L 420 110 L 460 110" stroke="#f59e0b" strokeWidth="4" fill="none" />
              {/* LP Turbine to Condenser */}
              <path d="M 530 150 L 530 250 L 600 250" stroke="#06b6d4" strokeWidth="3" fill="none" />
              {/* Condenser to CP Pump */}
              <path d="M 660 280 L 660 310 L 520 310" stroke="#3b82f6" strokeWidth="3" fill="none" />
              {/* Feedwater line through FWH to Boiler */}
              <path d="M 480 310 L 360 310 L 240 310 L 130 310 L 130 150" stroke="#10b981" strokeWidth="3" fill="none" />

              {/* COMPONENT 1: BOILER / SUPERHEATER */}
              <g 
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() => { setSelectedComponent('BOILER_SUPERHEATER'); setActiveTab('BOILER_CONDENSER'); }}
              >
                <rect x="70" y="80" width="100" height="150" rx="6" fill="#1e293b" stroke="#f59e0b" strokeWidth="2" />
                <text x="120" y="110" textAnchor="middle" fill="#f59e0b" fontSize="11" fontWeight="bold" fontFamily="monospace">BOILER</text>
                <text x="120" y="130" textAnchor="middle" fill="#ffffff" fontSize="10" fontFamily="monospace">SUPERHEATER</text>
                <text x="120" y="150" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">{params.boilerPressureMPa} MPa</text>
                <text x="120" y="165" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">{params.superheatTemperatureC} °C</text>
                <text x="120" y="205" textAnchor="middle" fill="#f59e0b" fontSize="9" fontWeight="bold" fontFamily="monospace">REHEATER</text>
              </g>

              {/* COMPONENT 2: HP TURBINE */}
              <g 
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() => { setSelectedComponent('HP_TURBINE'); setActiveTab('TURBINE_LAB'); }}
              >
                <polygon points="280,90 340,105 340,145 280,160" fill="#1e293b" stroke="#06b6d4" strokeWidth="2" />
                <text x="310" y="130" textAnchor="middle" fill="#06b6d4" fontSize="10" fontWeight="bold" fontFamily="monospace">HP</text>
              </g>

              {/* COMPONENT 3: IP/LP TURBINE */}
              <g 
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() => { setSelectedComponent('LP_TURBINE'); setActiveTab('TURBINE_LAB'); }}
              >
                <polygon points="460,80 540,65 540,165 460,150" fill="#1e293b" stroke="#06b6d4" strokeWidth="2" />
                <text x="500" y="115" textAnchor="middle" fill="#06b6d4" fontSize="11" fontWeight="bold" fontFamily="monospace">IP / LP</text>
                <text x="500" y="130" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">TURBINE</text>
              </g>

              {/* COMPONENT 4: CONDENSER */}
              <g 
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() => { setSelectedComponent('CONDENSER'); setActiveTab('BOILER_CONDENSER'); }}
              >
                <rect x="600" y="220" width="100" height="70" rx="6" fill="#1e293b" stroke="#3b82f6" strokeWidth="2" />
                <text x="650" y="245" textAnchor="middle" fill="#3b82f6" fontSize="10" fontWeight="bold" fontFamily="monospace">CONDENSER</text>
                <text x="650" y="260" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">{params.condenserPressureKPa} kPa</text>
                <text x="650" y="275" textAnchor="middle" fill="#94a3b8" fontSize="9" fontFamily="monospace">{params.coolingWaterInletTempC} °C CW</text>
              </g>

              {/* COMPONENT 5: FEEDWATER HEATERS */}
              <g 
                className="cursor-pointer transition-transform hover:opacity-90"
                onClick={() => { setSelectedComponent('FWH'); setActiveTab('REGENERATION'); }}
              >
                <circle cx="360" cy="310" r="22" fill="#1e293b" stroke="#10b981" strokeWidth="2" />
                <text x="360" y="314" textAnchor="middle" fill="#10b981" fontSize="9" fontWeight="bold" fontFamily="monospace">FWH</text>

                <circle cx="240" cy="310" r="22" fill="#1e293b" stroke="#10b981" strokeWidth="2" />
                <text x="240" y="314" textAnchor="middle" fill="#10b981" fontSize="8" fontWeight="bold" fontFamily="monospace">BFP</text>
              </g>

              {/* State Annotations */}
              <circle cx="210" cy="110" r="10" fill="#0b0e14" stroke="#f59e0b" strokeWidth="1.5" />
              <text x="210" y="113" textAnchor="middle" fill="#f59e0b" fontSize="8" fontFamily="monospace" fontWeight="bold">1</text>

              <circle cx="330" cy="160" r="10" fill="#0b0e14" stroke="#f59e0b" strokeWidth="1.5" />
              <text x="330" y="163" textAnchor="middle" fill="#f59e0b" fontSize="8" fontFamily="monospace" fontWeight="bold">2</text>

              <circle cx="390" cy="210" r="10" fill="#0b0e14" stroke="#f59e0b" strokeWidth="1.5" />
              <text x="390" y="213" textAnchor="middle" fill="#f59e0b" fontSize="8" fontFamily="monospace" fontWeight="bold">3</text>

              <circle cx="560" cy="250" r="10" fill="#0b0e14" stroke="#06b6d4" strokeWidth="1.5" />
              <text x="560" y="253" textAnchor="middle" fill="#06b6d4" fontSize="8" fontFamily="monospace" fontWeight="bold">4</text>
            </svg>
          </div>

          {/* Quick Component Inspector Summary */}
          <div className="mt-4 grid grid-cols-3 gap-3 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block">Main Steam (State 1)</span>
              <span className="font-bold text-cyan-300">
                {states[0]?.pressureMPa.toFixed(1)} MPa · {states[0]?.temperatureC.toFixed(0)} °C
              </span>
              <span className="text-slate-400 block text-[11px]">h = {states[0]?.specificEnthalpy.toFixed(1)} kJ/kg</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block">Reheat Steam (State 3)</span>
              <span className="font-bold text-amber-300">
                {states[2]?.pressureMPa.toFixed(2)} MPa · {states[2]?.temperatureC.toFixed(0)} °C
              </span>
              <span className="text-slate-400 block text-[11px]">h = {states[2]?.specificEnthalpy.toFixed(1)} kJ/kg</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-400 block">LP Turbine Exhaust (State 4)</span>
              <span className="font-bold text-blue-300">
                {states[3]?.pressureKPa.toFixed(1)} kPa · x = {(states[3]?.quality * 100).toFixed(1)}%
              </span>
              <span className="text-slate-400 block text-[11px]">s = {states[3]?.specificEntropy.toFixed(3)} kJ/kg·K</span>
            </div>
          </div>
        </div>

        {/* Right Col: Second-Law Exergy Loss Map & Fuel Economics */}
        <div className="space-y-6">
          
          {/* Exergy Destruction Breakdown */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white font-mono uppercase">
                  Exergy.OS Loss Map
                </h3>
              </div>
              <button 
                onClick={() => setActiveTab('EXERGY_LAB')}
                className="text-xs text-cyan-400 hover:underline flex items-center gap-0.5"
              >
                <span>Full Audit</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {exergyLossBreakdown.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-300 truncate max-w-[170px]">{item.component}</span>
                    <span className="font-bold text-slate-100 tabular-nums">
                      {item.exergyDestroyedMW.toFixed(1)} MW <span className="text-slate-400 font-normal">({item.pctOfTotal.toFixed(0)}%)</span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        idx === 0 ? 'bg-amber-500' : idx === 1 ? 'bg-cyan-500' : 'bg-blue-500'
                      }`}
                      style={{ width: `${Math.max(4, item.pctOfTotal)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-xs font-mono">
              <span className="text-slate-400">Total Second-Law Destruction:</span>
              <span className="font-bold text-amber-400 tabular-nums">
                {summary.totalExergyDestructionMW.toFixed(1)} MW
              </span>
            </div>
          </div>

          {/* Plant Economics & Fuel Metric */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <h3 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-3">
              Economic & Fuel Dispatch
            </h3>
            
            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Fuel Supply Source:</span>
                <span className="text-slate-200 font-medium">{params.heatSource.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Fuel Unit Cost:</span>
                <span className="text-slate-200">${params.heatSource.fuelCostPerGJ.toFixed(2)} / GJ</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Levelised Operating Cost:</span>
                <span className="text-cyan-400 font-bold tabular-nums">
                  ${summary.operatingCostPerMWh.toFixed(2)} / MWh
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">CO₂ Emission Rate:</span>
                <span className="text-slate-300 tabular-nums">{summary.co2EmissionsTonsPerHour.toFixed(1)} t/hr</span>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('OPTIMIZATION')}
              className="mt-4 w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded text-xs font-mono font-medium flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Explore Multi-Objective Pareto Frontier</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

      </div>

      {/* Proof Explorer Modal */}
      {proofMetric && (
        <CalculationProofModal
          isOpen={true}
          onClose={() => setProofMetric(null)}
          metricType={proofMetric}
          solvedCycle={solvedCycle}
        />
      )}
    </div>
  );
};
