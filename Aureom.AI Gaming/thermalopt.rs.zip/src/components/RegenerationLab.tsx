/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Feedwater Regeneration & Extraction Optimizer Lab
 */

import React from 'react';
import { Layers, Plus, Trash2, ArrowRight } from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';

interface RegenerationLabProps {
  solvedCycle: SolvedCycleResult;
}

export const RegenerationLab: React.FC<RegenerationLabProps> = ({ solvedCycle }) => {
  const { params, states } = solvedCycle;
  const fwhList = params.feedwaterHeaters;

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
          Regenerative Feedwater Heating Laboratory
        </h1>
        <p className="text-xs text-slate-400">
          Extraction bleed fractions, cascade drain thermodynamics, terminal temperature differences (TTD), and deaerator stage optimization.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
          Configured Feedwater Heater Train ({fwhList.length} Stages)
        </h2>

        {fwhList.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800">
                <tr>
                  <th className="px-3 py-3">Heater Tag</th>
                  <th className="px-3 py-3">Heater Type</th>
                  <th className="px-3 py-3 text-right">Extraction Pressure (MPa)</th>
                  <th className="px-3 py-3 text-right">Terminal Temp Diff (°C)</th>
                  <th className="px-3 py-3 text-right">Drain Cooling Approach (°C)</th>
                  <th className="px-3 py-3 text-right">Thermal Efficiency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 tabular-nums">
                {fwhList.map((fwh, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/50">
                    <td className="px-3 py-3 font-semibold text-cyan-300">{fwh.name}</td>
                    <td className="px-3 py-3 text-slate-200">
                      {fwh.type === 'OPEN_CONTACT_DEAERATOR' ? 'Open Direct Contact Deaerator' : 'Closed Shell & Tube'}
                    </td>
                    <td className="px-3 py-3 text-right font-bold text-white">
                      {fwh.extractionPressureMPa.toFixed(2)}
                    </td>
                    <td className="px-3 py-3 text-right text-slate-300">
                      {fwh.terminalTemperatureDifferenceC.toFixed(1)}
                    </td>
                    <td className="px-3 py-3 text-right text-slate-300">
                      {fwh.drainCoolingApproachC.toFixed(1)}
                    </td>
                    <td className="px-3 py-3 text-right text-emerald-400 font-bold">
                      {(fwh.efficiency * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-xs text-slate-500 font-mono">
            No regenerative heaters configured.
          </div>
        )}
      </div>

    </div>
  );
};
