/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Cycle Designer & Directed Thermodynamic Graph Configurator
 */

import React from 'react';
import { 
  Sliders, 
  Plus, 
  Trash2, 
  Flame, 
  Zap, 
  RefreshCw, 
  CheckCircle, 
  AlertCircle,
  HelpCircle,
  Cpu
} from 'lucide-react';
import { CycleDesignParameters, FeedwaterHeaterConfig } from '../thermo/components';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { WORKING_FLUIDS, WorkingFluidType } from '../thermo/fluids';

interface CycleDesignerProps {
  params: CycleDesignParameters;
  onChangeParams: (updated: CycleDesignParameters) => void;
  solvedCycle: SolvedCycleResult;
}

export const CycleDesigner: React.FC<CycleDesignerProps> = ({
  params,
  onChangeParams,
  solvedCycle,
}) => {
  const updateParam = <K extends keyof CycleDesignParameters>(key: K, value: CycleDesignParameters[K]) => {
    onChangeParams({ ...params, [key]: value });
  };

  const handleAddFWH = () => {
    const nextIdx = params.feedwaterHeaters.length + 1;
    const newFWH: FeedwaterHeaterConfig = {
      id: `FWH_${nextIdx}_CUSTOM`,
      name: `Feedwater Heater #${nextIdx}`,
      type: nextIdx % 2 === 0 ? 'OPEN_CONTACT_DEAERATOR' : 'CLOSED_SHELL_TUBE',
      extractionPressureMPa: 1.5 / nextIdx,
      terminalTemperatureDifferenceC: 2.8,
      drainCoolingApproachC: 5.6,
      efficiency: 0.985,
    };
    onChangeParams({
      ...params,
      feedwaterHeaters: [...params.feedwaterHeaters, newFWH],
    });
  };

  const handleRemoveFWH = (index: number) => {
    const updated = [...params.feedwaterHeaters];
    updated.splice(index, 1);
    onChangeParams({ ...params, feedwaterHeaters: updated });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Rankine Cycle Topology & Equipment Designer
          </h1>
          <p className="text-xs text-slate-400">
            Configure working fluids, thermodynamic boundary pressures, heat sources, multi-stage expansion paths, and regenerative bleed lines.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs font-mono px-3 py-1.5 bg-slate-900 border border-slate-800 rounded">
            <span className="text-slate-400">Status:</span>
            {solvedCycle.summary.isBalanceClosed ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Physically Admissible</span>
              </span>
            ) : (
              <span className="text-rose-400 font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Unbalanced State</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Grid of Equipment Modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* MODULE 1: Working Fluid & Heat Source */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white font-mono uppercase">
              1. Working Fluid & Primary Heat Source
            </h3>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <label className="block text-slate-400 mb-1">Working Fluid Medium:</label>
              <select
                value={params.workingFluid}
                onChange={(e) => updateParam('workingFluid', e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {Object.values(WORKING_FLUIDS).map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.chemicalFormula})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Primary Heat Source:</label>
              <input
                type="text"
                value={params.heatSource.name}
                onChange={(e) => updateParam('heatSource', { ...params.heatSource, name: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 mb-1">Flame / Max Temp (°C):</label>
                <input
                  type="number"
                  value={params.heatSource.maximumTemperatureC}
                  onChange={(e) => updateParam('heatSource', { ...params.heatSource, maximumTemperatureC: +e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Fuel Price ($/GJ):</label>
                <input
                  type="number"
                  step="0.1"
                  value={params.heatSource.fuelCostPerGJ}
                  onChange={(e) => updateParam('heatSource', { ...params.heatSource, fuelCostPerGJ: +e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
                />
              </div>
            </div>
          </div>
        </div>

        {/* MODULE 2: Boiler & Main Steam (Superheater) */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-white font-mono uppercase">
              2. Boiler & Superheater Throttle
            </h3>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Boiler Pressure (P_boiler):</span>
                <span className="text-cyan-400 font-bold">{params.boilerPressureMPa.toFixed(1)} MPa</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="32.0"
                step="0.5"
                value={params.boilerPressureMPa}
                onChange={(e) => updateParam('boilerPressureMPa', +e.target.value)}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Superheat Temperature (T_sh):</span>
                <span className="text-cyan-400 font-bold">{params.superheatTemperatureC.toFixed(0)} °C</span>
              </div>
              <input
                type="range"
                min="250"
                max="650"
                step="5"
                value={params.superheatTemperatureC}
                onChange={(e) => updateParam('superheatTemperatureC', +e.target.value)}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Throttle Steam Flow (m_dot):</span>
                <span className="text-slate-200 font-bold">{params.throttleMassFlowKgs.toFixed(0)} kg/s</span>
              </div>
              <input
                type="range"
                min="10"
                max="800"
                step="5"
                value={params.throttleMassFlowKgs}
                onChange={(e) => updateParam('throttleMassFlowKgs', +e.target.value)}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800">
              <div>
                <label className="text-slate-400 block text-[11px]">Boiler Thermal Eff:</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.7"
                  max="0.99"
                  value={params.boilerThermalEfficiency}
                  onChange={(e) => updateParam('boilerThermalEfficiency', +e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200 text-xs"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[11px]">Boiler P-Drop (%):</label>
                <input
                  type="number"
                  step="0.5"
                  value={params.boilerPressureDropPct}
                  onChange={(e) => updateParam('boilerPressureDropPct', +e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200 text-xs"
                />
              </div>
            </div>
          </div>
        </div>

        {/* MODULE 3: Steam Reheater */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-white font-mono uppercase">
                3. Steam Reheat Stage
              </h3>
            </div>
            <label className="flex items-center gap-2 text-xs font-mono text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={params.hasReheat}
                onChange={(e) => updateParam('hasReheat', e.target.checked)}
                className="rounded accent-cyan-400"
              />
              <span>Enable Reheat</span>
            </label>
          </div>

          {params.hasReheat ? (
            <div className="space-y-3 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Reheat Pressure (P_rh):</span>
                  <span className="text-amber-400 font-bold">{params.reheatPressureMPa.toFixed(2)} MPa</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max={params.boilerPressureMPa * 0.5}
                  step="0.1"
                  value={params.reheatPressureMPa}
                  onChange={(e) => updateParam('reheatPressureMPa', +e.target.value)}
                  className="w-full accent-amber-400 cursor-pointer"
                />
                <span className="text-[10px] text-slate-500">
                  Optimal is ~20–25% of Boiler Pressure ({(params.boilerPressureMPa * 0.23).toFixed(1)} MPa)
                </span>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Reheat Temperature (T_rh):</span>
                  <span className="text-amber-400 font-bold">{params.reheatTemperatureC.toFixed(0)} °C</span>
                </div>
                <input
                  type="range"
                  min="300"
                  max="650"
                  step="5"
                  value={params.reheatTemperatureC}
                  onChange={(e) => updateParam('reheatTemperatureC', +e.target.value)}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-xs text-slate-500 font-mono">
              Single-expansion Rankine cycle (Reheat disabled).
            </div>
          )}
        </div>

        {/* MODULE 4: Multi-Stage Turbines */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-white font-mono uppercase">
              4. Multi-Stage Turbine Expansions
            </h3>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>HP Turbine Isentropic Eff:</span>
                <span className="text-cyan-400 font-bold">{(params.hpTurbineEfficiency * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="0.95"
                step="0.005"
                value={params.hpTurbineEfficiency}
                onChange={(e) => updateParam('hpTurbineEfficiency', +e.target.value)}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>IP / LP Turbine Isentropic Eff:</span>
                <span className="text-cyan-400 font-bold">{(params.lpTurbineEfficiency * 100).toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="0.95"
                step="0.005"
                value={params.lpTurbineEfficiency}
                onChange={(e) => updateParam('lpTurbineEfficiency', +e.target.value)}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800">
              <div>
                <label className="text-slate-400 block text-[11px]">Mechanical Eff:</label>
                <input
                  type="number"
                  step="0.001"
                  value={params.mechanicalEfficiency}
                  onChange={(e) => updateParam('mechanicalEfficiency', +e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200 text-xs"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[11px]">Generator Eff:</label>
                <input
                  type="number"
                  step="0.001"
                  value={params.generatorEfficiency}
                  onChange={(e) => updateParam('generatorEfficiency', +e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200 text-xs"
                />
              </div>
            </div>
          </div>
        </div>

        {/* MODULE 5: Condenser & Cooling Water */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <Zap className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-bold text-white font-mono uppercase">
              5. Condenser & Vacuum Cooling Loop
            </h3>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Condenser Pressure (P_cond):</span>
                <span className="text-blue-400 font-bold">{params.condenserPressureKPa.toFixed(1)} kPa</span>
              </div>
              <input
                type="range"
                min="2.5"
                max="20.0"
                step="0.2"
                value={params.condenserPressureKPa}
                onChange={(e) => updateParam('condenserPressureKPa', +e.target.value)}
                className="w-full accent-blue-400 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block text-[11px]">CW Inlet Temp (°C):</label>
                <input
                  type="number"
                  step="0.5"
                  value={params.coolingWaterInletTempC}
                  onChange={(e) => updateParam('coolingWaterInletTempC', +e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[11px]">CW Temp Rise ΔT (°C):</label>
                <input
                  type="number"
                  step="0.5"
                  value={params.coolingWaterDeltaTC}
                  onChange={(e) => updateParam('coolingWaterDeltaTC', +e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
                />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
              Cooling Water Mass Flow: <span className="text-slate-200 font-bold">{solvedCycle.summary.coolingWaterFlowKgs.toFixed(0)} kg/s</span>
            </div>
          </div>
        </div>

        {/* MODULE 6: Regenerative Feedwater Heaters */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-white font-mono uppercase">
              6. Regenerative Feedwater Heaters ({params.feedwaterHeaters.length})
            </h3>
            <button
              onClick={handleAddFWH}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-[11px] font-mono flex items-center gap-1 border border-slate-700"
            >
              <Plus className="w-3 h-3" />
              <span>Add Heater</span>
            </button>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {params.feedwaterHeaters.map((fwh, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800 text-xs font-mono">
                <div>
                  <div className="font-semibold text-slate-200">{fwh.name}</div>
                  <div className="text-[11px] text-slate-400">
                    P_ext: {fwh.extractionPressureMPa.toFixed(2)} MPa · {fwh.type === 'OPEN_CONTACT_DEAERATOR' ? 'Open Deaerator' : 'Closed Shell-Tube'}
                  </div>
                </div>
                <button
                  onClick={() => handleRemoveFWH(idx)}
                  className="text-slate-500 hover:text-rose-400 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {params.feedwaterHeaters.length === 0 && (
              <div className="text-center py-6 text-xs text-slate-500 font-mono">
                No regenerative feedwater heaters configured.
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
