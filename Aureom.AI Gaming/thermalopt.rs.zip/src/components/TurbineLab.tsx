/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Multi-Stage Turbine Laboratory & Aerodynamic Expansion Suite
 */

import React from 'react';
import { Zap, ShieldAlert, CheckCircle, TrendingDown, Layers, HelpCircle } from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';

interface TurbineLabProps {
  solvedCycle: SolvedCycleResult;
}

export const TurbineLab: React.FC<TurbineLabProps> = ({ solvedCycle }) => {
  const { summary, states, params } = solvedCycle;

  // Enthalpy drops
  const h1 = states[0]?.specificEnthalpy || 0;
  const h2 = states[1]?.specificEnthalpy || 0;
  const h3 = states[2]?.specificEnthalpy || h2;
  const h4 = states[3]?.specificEnthalpy || 0;

  const deltaH_hp = h1 - h2;
  const deltaH_ip_lp = h3 - h4;
  const totalDeltaH = deltaH_hp + deltaH_ip_lp;

  const moistureFraction = 1.0 - summary.turbineExhaustQuality;
  const wilsonLimit = 0.14; // Max 14% moisture allowed before blade erosion
  const isWilsonSafe = moistureFraction <= wilsonLimit;

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
          Multi-Stage Turbine Aerodynamics & Expansion Laboratory
        </h1>
        <p className="text-xs text-slate-400">
          High-pressure (HP), Intermediate-pressure (IP), and Low-pressure (LP) expansions, stage enthalpy drops, wet-steam moisture formation, and Wilson line blade erosion integrity.
        </p>
      </div>

      {/* Top 3 Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase text-slate-400">Gross Turbine Power</div>
          <div className="mt-1 flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-bold text-cyan-400 tabular-nums">{summary.grossTurbinePowerMW.toFixed(1)}</span>
            <span className="text-xs text-slate-400">MW</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            HP: {((states[0]?.massFlow * deltaH_hp) / 1000).toFixed(1)} MW | LP: {((states[3]?.massFlow * deltaH_ip_lp) / 1000).toFixed(1)} MW
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase text-slate-400">Total Enthalpy Drop (Δh)</div>
          <div className="mt-1 flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-bold text-white tabular-nums">{totalDeltaH.toFixed(1)}</span>
            <span className="text-xs text-slate-400">kJ/kg</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            HP: {deltaH_hp.toFixed(1)} kJ/kg | LP: {deltaH_ip_lp.toFixed(1)} kJ/kg
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase text-slate-400">LP Exhaust Quality (x)</div>
          <div className="mt-1 flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-bold text-cyan-300 tabular-nums">{(summary.turbineExhaustQuality * 100).toFixed(1)}</span>
            <span className="text-xs text-slate-400">%</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Moisture Content: {(moistureFraction * 100).toFixed(1)}%
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase text-slate-400">Wilson Line Integrity</div>
          <div className="mt-1 flex items-center gap-1.5 font-mono">
            {isWilsonSafe ? (
              <span className="text-lg font-bold text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-5 h-5" />
                <span>SAFE (&lt;14%)</span>
              </span>
            ) : (
              <span className="text-lg font-bold text-rose-400 flex items-center gap-1">
                <ShieldAlert className="w-5 h-5" />
                <span>EROSION RISK</span>
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Margin to threshold: {((wilsonLimit - moistureFraction) * 100).toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Expansion Stages Breakdown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
          Turbine Stage Expansion Ledger
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800">
              <tr>
                <th className="px-3 py-3">Turbine Stage Section</th>
                <th className="px-3 py-3 text-right">Inlet State (P, T)</th>
                <th className="px-3 py-3 text-right">Outlet State (P, T)</th>
                <th className="px-3 py-3 text-right">Enthalpy Drop Δh (kJ/kg)</th>
                <th className="px-3 py-3 text-right">Isentropic Eff (η_is)</th>
                <th className="px-3 py-3 text-right">Stage Shaft Power (MW)</th>
                <th className="px-3 py-3 text-right">Exhaust Steam Quality</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 tabular-nums">
              <tr className="hover:bg-slate-800/50">
                <td className="px-3 py-3 font-semibold text-cyan-300">High-Pressure (HP) Cylinder</td>
                <td className="px-3 py-3 text-right text-slate-200">
                  {states[0]?.pressureMPa.toFixed(1)} MPa · {states[0]?.temperatureC.toFixed(0)} °C
                </td>
                <td className="px-3 py-3 text-right text-slate-200">
                  {states[1]?.pressureMPa.toFixed(2)} MPa · {states[1]?.temperatureC.toFixed(0)} °C
                </td>
                <td className="px-3 py-3 text-right font-bold text-white">{deltaH_hp.toFixed(1)}</td>
                <td className="px-3 py-3 text-right text-cyan-400 font-bold">{(params.hpTurbineEfficiency * 100).toFixed(1)}%</td>
                <td className="px-3 py-3 text-right text-emerald-400 font-bold">
                  {((states[0]?.massFlow * deltaH_hp) / 1000).toFixed(1)}
                </td>
                <td className="px-3 py-3 text-right text-slate-400">Superheated (x = 1.0)</td>
              </tr>

              <tr className="hover:bg-slate-800/50">
                <td className="px-3 py-3 font-semibold text-cyan-300">IP & Low-Pressure (LP) Cylinder</td>
                <td className="px-3 py-3 text-right text-slate-200">
                  {states[2]?.pressureMPa.toFixed(2)} MPa · {states[2]?.temperatureC.toFixed(0)} °C
                </td>
                <td className="px-3 py-3 text-right text-slate-200">
                  {states[3]?.pressureKPa.toFixed(1)} kPa · {states[3]?.temperatureC.toFixed(0)} °C
                </td>
                <td className="px-3 py-3 text-right font-bold text-white">{deltaH_ip_lp.toFixed(1)}</td>
                <td className="px-3 py-3 text-right text-cyan-400 font-bold">{(params.lpTurbineEfficiency * 100).toFixed(1)}%</td>
                <td className="px-3 py-3 text-right text-emerald-400 font-bold">
                  {((states[3]?.massFlow * deltaH_ip_lp) / 1000).toFixed(1)}
                </td>
                <td className="px-3 py-3 text-right font-bold text-cyan-300">
                  {(summary.turbineExhaustQuality * 100).toFixed(1)}% (Wet Steam)
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
