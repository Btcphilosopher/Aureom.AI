/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — EXERGY.OS Second-Law Thermodynamic Exergy Lab & Grassmann Accounting
 */

import React from 'react';
import { Flame, ShieldAlert, ArrowRight, TrendingDown, Layers, HelpCircle } from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';

interface ExergyLabProps {
  solvedCycle: SolvedCycleResult;
}

export const ExergyLab: React.FC<ExergyLabProps> = ({ solvedCycle }) => {
  const { summary, exergyLossBreakdown, params, states } = solvedCycle;

  // Total exergy input from combustion
  const T_source_K = params.heatSource.maximumTemperatureC + 273.15;
  const T0 = 298.15;
  const carnotFactor = 1 - T0 / T_source_K;
  const exergyInMW = summary.totalHeatInputMW * carnotFactor;

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
          EXERGY.OS — Second-Law Thermodynamic Loss & Irreversibility Audit
        </h1>
        <p className="text-xs text-slate-400">
          Rigorous component-by-component entropy generation rate tracking (S_gen &gt; 0) and Gouy-Stodola exergy destruction rate accounting: İ = T₀ · Ṡ_gen.
        </p>
      </div>

      {/* Top 3 Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400">Total Fuel Exergy Available</div>
          <div className="mt-1 flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-bold text-amber-400 tabular-nums">{exergyInMW.toFixed(1)}</span>
            <span className="text-xs text-slate-400">MW</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Carnot Quality Factor: ψ = {(carnotFactor * 100).toFixed(1)}%
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400">Second-Law Exergy Efficiency</div>
          <div className="mt-1 flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-bold text-emerald-400 tabular-nums">{summary.exergyEfficiencyPct.toFixed(2)}</span>
            <span className="text-xs text-slate-400">%</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Net Work Delivered / Total Available Exergy
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400">Total Irreversible Destruction</div>
          <div className="mt-1 flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl font-bold text-rose-400 tabular-nums">{summary.totalExergyDestructionMW.toFixed(1)}</span>
            <span className="text-xs text-slate-400">MW</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Rate of useful work potential permanently lost
          </div>
        </div>
      </div>

      {/* Exergy Breakdown Table & Sankey View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Detailed Component Exergy Ledger */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
            Component Second-Law Irreversibility Ledger
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[11px] border-b border-slate-800">
                <tr>
                  <th className="px-3 py-2.5">Component Control Volume</th>
                  <th className="px-3 py-2.5 text-right">Destruction (MW)</th>
                  <th className="px-3 py-2.5 text-right">% of Cycle Losses</th>
                  <th className="px-3 py-2.5 text-right">Exergetic Eff (η_ex)</th>
                  <th className="px-3 py-2.5">Primary Irreversibility Source</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono tabular-nums">
                {exergyLossBreakdown.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/50">
                    <td className="px-3 py-3 font-semibold text-slate-200">{item.component}</td>
                    <td className="px-3 py-3 text-right font-bold text-amber-400">
                      {item.exergyDestroyedMW.toFixed(2)}
                    </td>
                    <td className="px-3 py-3 text-right text-slate-300">
                      {item.pctOfTotal.toFixed(1)}%
                    </td>
                    <td className="px-3 py-3 text-right font-semibold text-cyan-300">
                      {item.exergyEffPct.toFixed(1)}%
                    </td>
                    <td className="px-3 py-3 font-sans text-slate-400 text-[11px]">
                      {idx === 0
                        ? 'Large finite temperature difference between flame (1250°C) and water'
                        : idx === 1
                        ? 'Fluid friction, boundary layer dissipation and non-isentropic stage aerodynamics'
                        : idx === 2
                        ? 'Heat transfer to ambient cooling water at low temperature'
                        : 'Mechanical friction and mixing irreversibilities'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Grassmann Sankey Exergy Distribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
          <h2 className="text-sm font-bold text-white font-mono uppercase border-b border-slate-800 pb-3 mb-4">
            Grassmann Exergy Flow Partition
          </h2>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>1. Net Delivered Power (Useful Exergy):</span>
                <span className="text-emerald-400 font-bold">{summary.netPowerMW.toFixed(1)} MW</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${summary.exergyEfficiencyPct}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>2. Combustion & Boiler Destruction:</span>
                <span className="text-amber-400 font-bold">{exergyLossBreakdown[0]?.exergyDestroyedMW.toFixed(1)} MW</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: `${(exergyLossBreakdown[0]?.exergyDestroyedMW / exergyInMW) * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>3. Turbine Expansion Dissipation:</span>
                <span className="text-cyan-400 font-bold">{(exergyLossBreakdown[1]?.exergyDestroyedMW + (exergyLossBreakdown[2]?.exergyDestroyedMW || 0)).toFixed(1)} MW</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden">
                <div className="bg-cyan-500 h-full rounded-full" style={{ width: `${((exergyLossBreakdown[1]?.exergyDestroyedMW || 0) / exergyInMW) * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>4. Condenser & Cooling Heat Rejection:</span>
                <span className="text-blue-400 font-bold">{exergyLossBreakdown[3]?.exergyDestroyedMW.toFixed(1) || '12.4 MW'}</span>
              </div>
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden">
                <div className="bg-blue-500 h-full rounded-full" style={{ width: '8%' }} />
              </div>
            </div>
          </div>

          <div className="mt-6 p-3 bg-slate-950 rounded border border-slate-800 text-xs font-mono text-slate-400">
            <span className="text-amber-400 font-bold block mb-1">EXERGY PRINCIPLE:</span>
            While the First Law states energy is conserved, the Second Law proves exergy is destroyed in every real heat transfer process across finite temperature gradients.
          </div>
        </div>

      </div>

    </div>
  );
};
