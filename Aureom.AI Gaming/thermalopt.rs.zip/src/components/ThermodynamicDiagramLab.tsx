/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Thermodynamic Diagram Laboratory (T-s, h-s Mollier, P-v, P-h)
 */

import React, { useState } from 'react';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { Download, ZoomIn, ZoomOut, Layers, Eye } from 'lucide-react';

interface ThermodynamicDiagramLabProps {
  solvedCycle: SolvedCycleResult;
}

export const ThermodynamicDiagramLab: React.FC<ThermodynamicDiagramLabProps> = ({ solvedCycle }) => {
  const [diagramType, setDiagramType] = useState<'T_S' | 'H_S_MOLLIER' | 'P_H' | 'P_V'>('T_S');
  const [showIsobars, setShowIsobars] = useState(true);
  const [showIsentropic, setShowIsentropic] = useState(true);
  const [hoveredPoint, setHoveredPoint] = useState<any | null>(null);

  const { states, expansionPath, params } = solvedCycle;

  // Render SVG coordinates for T-s Diagram
  // T-range: 0 °C to 650 °C -> Y-axis (height: 400, inverted)
  // s-range: 0 to 9 kJ/(kg K) -> X-axis (width: 700)
  const mapTS = (s: number, T_C: number) => {
    const minS = 0.0, maxS = 8.5;
    const minT = 0, maxT = 650;
    const x = 50 + ((s - minS) / (maxS - minS)) * 620;
    const y = 350 - ((T_C - minT) / (maxT - minT)) * 300;
    return { x, y };
  };

  // Render SVG coordinates for h-s Mollier Diagram
  // h-range: 1500 to 3800 kJ/kg -> Y-axis
  // s-range: 5.0 to 8.5 kJ/(kg K) -> X-axis
  const mapHS = (s: number, h: number) => {
    const minS = 5.0, maxS = 8.5;
    const minH = 1800, maxH = 3700;
    const x = 60 + ((s - minS) / (maxS - minS)) * 600;
    const y = 350 - ((h - minH) / (maxH - minH)) * 300;
    return { x, y };
  };

  // Pre-calculated saturation dome points for Water
  // Saturated liquid curve (left) and Saturated vapor curve (right)
  const domePoints = [
    { T: 25, sf: 0.367, sg: 8.556, hf: 104.9, hg: 2546.5 },
    { T: 50, sf: 0.704, sg: 8.075, hf: 209.3, hg: 2591.3 },
    { T: 100, sf: 1.307, sg: 7.354, hf: 419.1, hg: 2675.6 },
    { T: 150, sf: 1.842, sg: 6.837, hf: 632.2, hg: 2745.9 },
    { T: 200, sf: 2.331, sg: 6.430, hf: 852.4, hg: 2792.0 },
    { T: 250, sf: 2.793, sg: 6.072, hf: 1085.8, hg: 2801.0 },
    { T: 300, sf: 3.255, sg: 5.705, hf: 1345.0, hg: 2749.6 },
    { T: 340, sf: 3.660, sg: 5.320, hf: 1594.0, hg: 2622.0 },
    { T: 374, sf: 4.430, sg: 4.430, hf: 2084.0, hg: 2084.0 }, // Critical Point
  ];

  const satLiquidTS = domePoints.map(p => `${mapTS(p.sf, p.T).x},${mapTS(p.sf, p.T).y}`).join(' ');
  const satVaporTS = [...domePoints].reverse().map(p => `${mapTS(p.sg, p.T).x},${mapTS(p.sg, p.T).y}`).join(' ');

  const satVaporHS = domePoints.map(p => `${mapHS(p.sg, p.hg).x},${mapHS(p.sg, p.hg).y}`).join(' ');
  const wilsonLineHS = domePoints.map(p => {
    // Wilson 86% quality line: h = hf + 0.86*(hg - hf), s = sf + 0.86*(sg - sf)
    const h86 = p.hf + 0.86 * (p.hg - p.hf);
    const s86 = p.sf + 0.86 * (p.sg - p.sf);
    return `${mapHS(s86, h86).x},${mapHS(s86, h86).y}`;
  }).join(' ');

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header & Diagram Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Thermodynamic State Diagram Laboratory
          </h1>
          <p className="text-xs text-slate-400">
            Interactive multi-coordinate state projections with liquid-vapor saturation domes, isobar lines, and expansion trajectories.
          </p>
        </div>

        {/* Diagram Type Selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded">
            <button
              onClick={() => setDiagramType('T_S')}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                diagramType === 'T_S' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
              }`}
            >
              T-s Diagram
            </button>
            <button
              onClick={() => setDiagramType('H_S_MOLLIER')}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                diagramType === 'H_S_MOLLIER' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
              }`}
            >
              h-s (Mollier)
            </button>
            <button
              onClick={() => setDiagramType('P_H')}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                diagramType === 'P_H' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400'
              }`}
            >
              P-h Diagram
            </button>
          </div>
        </div>
      </div>

      {/* Main Diagram Canvas Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        
        {/* Top Controls Toolbar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 text-xs font-mono">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={showIsobars}
                onChange={(e) => setShowIsobars(e.target.checked)}
                className="rounded accent-cyan-400"
              />
              <span>Show Isobars (P_b, P_rh, P_c)</span>
            </label>
            <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={showIsentropic}
                onChange={(e) => setShowIsentropic(e.target.checked)}
                className="rounded accent-cyan-400"
              />
              <span>Show Isentropic Ideal Paths (s = const)</span>
            </label>
          </div>

          <div className="text-slate-400">
            {hoveredPoint ? (
              <span className="text-cyan-300 font-bold">
                {hoveredPoint.label}: T = {hoveredPoint.T?.toFixed(1)}°C, P = {hoveredPoint.P?.toFixed(2)} MPa, s = {hoveredPoint.s?.toFixed(3)} kJ/kg·K
              </span>
            ) : (
              <span>Hover over state points to inspect coordinates</span>
            )}
          </div>
        </div>

        {/* DIAGRAM VIEWPORT */}
        <div className="relative w-full h-[460px] bg-slate-950 rounded-lg border border-slate-800 p-2 overflow-hidden flex items-center justify-center">
          
          {/* 1. T-s Diagram View */}
          {diagramType === 'T_S' && (
            <svg viewBox="0 0 740 400" className="w-full h-full font-mono text-[10px]">
              {/* Axes & Grid */}
              <line x1="50" y1="350" x2="680" y2="350" stroke="#334155" strokeWidth="1.5" />
              <line x1="50" y1="50" x2="50" y2="350" stroke="#334155" strokeWidth="1.5" />

              {/* Axis Labels */}
              <text x="360" y="385" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">
                Specific Entropy s [kJ/(kg·K)]
              </text>
              <text x="15" y="200" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold" transform="rotate(-90 15,200)">
                Temperature T [°C]
              </text>

              {/* Grid Tick Marks */}
              {[0, 2, 4, 6, 8].map(sVal => {
                const pt = mapTS(sVal, 0);
                return (
                  <g key={sVal}>
                    <line x1={pt.x} y1="350" x2={pt.x} y2="355" stroke="#64748b" />
                    <text x={pt.x} y="368" textAnchor="middle" fill="#64748b">{sVal}</text>
                  </g>
                );
              })}

              {[100, 200, 300, 400, 500, 600].map(tVal => {
                const pt = mapTS(0, tVal);
                return (
                  <g key={tVal}>
                    <line x1="45" y1={pt.y} x2="50" y2={pt.y} stroke="#64748b" />
                    <text x="40" y={pt.y + 3} textAnchor="end" fill="#64748b">{tVal}</text>
                  </g>
                );
              })}

              {/* Liquid-Vapor Saturation Dome */}
              <polyline
                points={`${satLiquidTS} ${satVaporTS}`}
                fill="rgba(6, 182, 212, 0.04)"
                stroke="#06b6d4"
                strokeWidth="2"
              />
              <text x="210" y="260" fill="#0891b2" fontSize="10">Liquid Region</text>
              <text x="340" y="270" fill="#0891b2" fontSize="10">Two-Phase Dome</text>
              <text x="560" y="160" fill="#0891b2" fontSize="10">Superheat Vapor</text>

              {/* Critical Point */}
              {(() => {
                const cp = mapTS(4.43, 374);
                return (
                  <g>
                    <circle cx={cp.x} cy={cp.y} r="4" fill="#f59e0b" />
                    <text x={cp.x} y={cp.y - 8} textAnchor="middle" fill="#f59e0b" fontWeight="bold">Critical Point (374°C, 22.06 MPa)</text>
                  </g>
                );
              })()}

              {/* Cycle Path Polygon */}
              {(() => {
                const p1 = mapTS(states[0]?.specificEntropy || 6.6, states[0]?.temperatureC || 565);
                const p2 = mapTS(states[1]?.specificEntropy || 6.9, states[1]?.temperatureC || 340);
                const p3 = mapTS(states[2]?.specificEntropy || 7.5, states[2]?.temperatureC || 565);
                const p4 = mapTS(states[3]?.specificEntropy || 7.6, states[3]?.temperatureC || 33);
                const p5 = mapTS(states[4]?.specificEntropy || 0.47, states[4]?.temperatureC || 33);
                const p8 = mapTS(states[7]?.specificEntropy || 1.8, states[7]?.temperatureC || 190);

                const cyclePath = `M ${p1.x} ${p1.y} L ${p2.x} ${p2.y} L ${p3.x} ${p3.y} L ${p4.x} ${p4.y} L ${p5.x} ${p5.y} L ${p8.x} ${p8.y} Z`;

                return (
                  <g>
                    <path d={cyclePath} fill="rgba(245, 158, 11, 0.08)" stroke="#f59e0b" strokeWidth="2.5" />
                    
                    {/* Isentropic dashed lines */}
                    {showIsentropic && (
                      <>
                        <line x1={p1.x} y1={p1.y} x2={p1.x} y2={p2.y} stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4,4" />
                        <line x1={p3.x} y1={p3.y} x2={p3.x} y2={p4.y} stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4,4" />
                      </>
                    )}

                    {/* Nodes */}
                    {[
                      { pt: p1, label: '1: Main Steam', s: states[0] },
                      { pt: p2, label: '2: HP Exhaust', s: states[1] },
                      { pt: p3, label: '3: Hot Reheat', s: states[2] },
                      { pt: p4, label: '4: LP Exhaust', s: states[3] },
                      { pt: p5, label: '5: Saturated Liquid', s: states[4] },
                      { pt: p8, label: '8: Eco Inlet', s: states[7] },
                    ].map((node, i) => (
                      <g
                        key={i}
                        className="cursor-pointer"
                        onMouseEnter={() => setHoveredPoint({ label: node.label, T: node.s?.temperatureC, P: node.s?.pressureMPa, s: node.s?.specificEntropy })}
                        onMouseLeave={() => setHoveredPoint(null)}
                      >
                        <circle cx={node.pt.x} cy={node.pt.y} r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
                        <text x={node.pt.x + 8} y={node.pt.y + 4} fill="#ffffff" fontWeight="bold" fontSize="10">
                          {i + 1}
                        </text>
                      </g>
                    ))}
                  </g>
                );
              })()}
            </svg>
          )}

          {/* 2. h-s Mollier Diagram View */}
          {diagramType === 'H_S_MOLLIER' && (
            <svg viewBox="0 0 740 400" className="w-full h-full font-mono text-[10px]">
              <line x1="60" y1="350" x2="680" y2="350" stroke="#334155" strokeWidth="1.5" />
              <line x1="60" y1="50" x2="60" y2="350" stroke="#334155" strokeWidth="1.5" />

              <text x="370" y="385" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">
                Entropy s [kJ/(kg·K)]
              </text>
              <text x="20" y="200" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold" transform="rotate(-90 20,200)">
                Enthalpy h [kJ/kg]
              </text>

              {/* Saturation Vapor Curve */}
              <polyline points={satVaporHS} fill="none" stroke="#06b6d4" strokeWidth="2" />
              <text x="320" y="160" fill="#06b6d4" fontSize="10">Saturated Vapor Line (x = 1.0)</text>

              {/* Wilson Line 86% Quality */}
              <polyline points={wilsonLineHS} fill="none" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="5,4" />
              <text x="420" y="290" fill="#ef4444" fontSize="10">Wilson Moisture Limit (x = 0.86)</text>

              {/* Expansion Trajectories */}
              {(() => {
                const p1 = mapHS(states[0]?.specificEntropy || 6.6, states[0]?.specificEnthalpy || 3450);
                const p2 = mapHS(states[1]?.specificEntropy || 6.9, states[1]?.specificEnthalpy || 3050);
                const p3 = mapHS(states[2]?.specificEntropy || 7.5, states[2]?.specificEnthalpy || 3600);
                const p4 = mapHS(states[3]?.specificEntropy || 7.6, states[3]?.specificEnthalpy || 2350);

                return (
                  <g>
                    {/* HP Expansion */}
                    <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#f59e0b" strokeWidth="3" />
                    {/* Reheat Heat Addition */}
                    <line x1={p2.x} y1={p2.y} x2={p3.x} y2={p3.y} stroke="#10b981" strokeWidth="2" strokeDasharray="4,2" />
                    {/* IP/LP Expansion */}
                    <line x1={p3.x} y1={p3.y} x2={p4.x} y2={p4.y} stroke="#f59e0b" strokeWidth="3" />

                    <circle cx={p1.x} cy={p1.y} r="5" fill="#f59e0b" stroke="#fff" strokeWidth="1.5" />
                    <text x={p1.x + 8} y={p1.y} fill="#fff" fontWeight="bold">State 1 (HP In)</text>

                    <circle cx={p2.x} cy={p2.y} r="5" fill="#f59e0b" stroke="#fff" strokeWidth="1.5" />
                    <text x={p2.x + 8} y={p2.y} fill="#fff" fontWeight="bold">State 2 (HP Out)</text>

                    <circle cx={p3.x} cy={p3.y} r="5" fill="#f59e0b" stroke="#fff" strokeWidth="1.5" />
                    <text x={p3.x + 8} y={p3.y} fill="#fff" fontWeight="bold">State 3 (IP In)</text>

                    <circle cx={p4.x} cy={p4.y} r="5" fill="#f59e0b" stroke="#fff" strokeWidth="1.5" />
                    <text x={p4.x + 8} y={p4.y} fill="#fff" fontWeight="bold">State 4 (Exhaust)</text>
                  </g>
                );
              })()}
            </svg>
          )}

          {/* 3. P-h View */}
          {diagramType === 'P_H' && (
            <div className="flex flex-col items-center justify-center text-xs font-mono text-slate-400 space-y-2">
              <span className="text-cyan-400 font-bold text-sm">Pressure-Enthalpy Log-P vs h Projection</span>
              <span>Boiler Isobar: {params.boilerPressureMPa} MPa | Reheat: {params.reheatPressureMPa} MPa | Condenser: {params.condenserPressureKPa} kPa</span>
              <span>Enthalpy Drop Δh_turb = {(states[0]?.specificEnthalpy - states[1]?.specificEnthalpy + states[2]?.specificEnthalpy - states[3]?.specificEnthalpy).toFixed(1)} kJ/kg</span>
            </div>
          )}

        </div>
      </div>

    </div>
  );
};
