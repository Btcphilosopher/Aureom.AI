/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Boiler & Condenser Heat Exchanger Suite
 */

import React from 'react';
import { Flame, Droplets, Zap, ShieldCheck } from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';

interface BoilerCondenserLabProps {
  solvedCycle: SolvedCycleResult;
}

export const BoilerCondenserLab: React.FC<BoilerCondenserLabProps> = ({ solvedCycle }) => {
  const { summary, params, states } = solvedCycle;

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
          Boiler & Condenser Thermal Exchange Laboratory
        </h1>
        <p className="text-xs text-slate-400">
          Subcritical/supercritical heat absorption duty partitioning (Economiser, Evaporator, Superheater, Reheater) and surface condenser vacuum heat rejection.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* BOILER SECTION */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Flame className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-white font-mono uppercase">
              Steam Generator Heat Transfer Duties
            </h2>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Total Boiler Duty:</span>
              <span className="text-amber-400 font-bold text-sm tabular-nums">
                {summary.heatInputBoilerMW.toFixed(1)} MWth
              </span>
            </div>

            {params.hasReheat && (
              <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-400">Reheater Duty:</span>
                <span className="text-amber-400 font-bold text-sm tabular-nums">
                  {summary.heatInputReheatMW.toFixed(1)} MWth
                </span>
              </div>
            )}

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Total Firing Rate (Fuel):</span>
              <span className="text-white font-bold text-sm tabular-nums">
                {(summary.totalHeatInputMW / params.boilerThermalEfficiency).toFixed(1)} MWth
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Boiler Thermal Efficiency:</span>
              <span className="text-emerald-400 font-bold text-sm tabular-nums">
                {(params.boilerThermalEfficiency * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        </div>

        {/* CONDENSER SECTION */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Droplets className="w-5 h-5 text-blue-400" />
            <h2 className="text-sm font-bold text-white font-mono uppercase">
              Surface Condenser & Vacuum Loop
            </h2>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Heat Rejection Rate:</span>
              <span className="text-blue-400 font-bold text-sm tabular-nums">
                {summary.condenserHeatRejectionMW.toFixed(1)} MWth
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Condenser Backpressure:</span>
              <span className="text-cyan-400 font-bold text-sm tabular-nums">
                {params.condenserPressureKPa.toFixed(2)} kPa ({states[4]?.temperatureC.toFixed(1)} °C sat)
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Cooling Water Mass Flow:</span>
              <span className="text-white font-bold text-sm tabular-nums">
                {summary.coolingWaterFlowKgs.toFixed(0)} kg/s ({(summary.coolingWaterFlowKgs * 3.6).toFixed(0)} m³/hr)
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400">Cooling Water Inlet / ΔT:</span>
              <span className="text-slate-200 font-bold text-sm tabular-nums">
                {params.coolingWaterInletTempC.toFixed(1)} °C (+{params.coolingWaterDeltaTC.toFixed(1)} °C)
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
