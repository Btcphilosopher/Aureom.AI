/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Top Navigation Bar (Adhering to strict 3-zone contract)
 */

import React from 'react';
import { Play, RotateCcw, FileText, Cpu, Database, Sliders, ChevronDown } from 'lucide-react';
import { PresetCycleDefinition, SIGNATURE_PRESETS } from '../thermo/presets';
import { SolvedCycleResult } from '../thermo/cycle_solver';

export type NavigationTab = 
  | 'DASHBOARD'
  | 'CYCLE_DESIGNER'
  | 'STATES'
  | 'DIAGRAMS'
  | 'TURBINE_LAB'
  | 'BOILER_CONDENSER'
  | 'REGENERATION'
  | 'EXERGY_LAB'
  | 'OPTIMIZATION'
  | 'LANDSCAPE'
  | 'SENSITIVITY'
  | 'DIGITAL_TWIN'
  | 'WHAT_IF'
  | 'R_LAB'
  | 'RUST_CORE';

interface NavbarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  currentPreset: PresetCycleDefinition;
  onSelectPreset: (preset: PresetCycleDefinition) => void;
  solvedCycle: SolvedCycleResult;
  onOpenReport: () => void;
  onResetDefaults: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentPreset,
  onSelectPreset,
  solvedCycle,
  onOpenReport,
  onResetDefaults,
}) => {
  const [presetDropdownOpen, setPresetDropdownOpen] = React.useState(false);

  const navLinks: { id: NavigationTab; label: string }[] = [
    { id: 'DASHBOARD', label: 'Overview' },
    { id: 'CYCLE_DESIGNER', label: 'Cycle Designer' },
    { id: 'STATES', label: 'States' },
    { id: 'DIAGRAMS', label: 'Diagrams' },
    { id: 'TURBINE_LAB', label: 'Turbines' },
    { id: 'EXERGY_LAB', label: 'Exergy.OS' },
    { id: 'OPTIMIZATION', label: 'Optimisation' },
    { id: 'LANDSCAPE', label: 'Landscape' },
    { id: 'SENSITIVITY', label: 'Sensitivity' },
    { id: 'DIGITAL_TWIN', label: 'Digital Twin' },
    { id: 'WHAT_IF', label: 'What-If' },
    { id: 'R_LAB', label: 'R Lab' },
    { id: 'RUST_CORE', label: 'Rust Core' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0b0e14]/95 backdrop-blur border-b border-slate-800 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          
          {/* ZONE 1: Brand Wordmark (Single text element) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('DASHBOARD')}
              className="flex items-center gap-2 text-left focus:outline-none"
            >
              <div className="w-7 h-7 rounded bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center font-mono font-bold text-xs text-white shadow-sm">
                θ
              </div>
              <span className="text-base font-bold tracking-tight text-white font-mono">
                THERMALOPT<span className="text-cyan-400">.RS</span>
              </span>
            </button>

            {/* Benchmark Preset Selector Dropdown */}
            <div className="relative ml-2">
              <button
                onClick={() => setPresetDropdownOpen(!presetDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono bg-slate-900 border border-slate-700 rounded text-slate-300 hover:text-white hover:border-slate-600 transition-colors whitespace-nowrap"
              >
                <span className="text-slate-500">Preset:</span>
                <span className="text-cyan-400 font-semibold">{currentPreset.name}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {presetDropdownOpen && (
                <div className="absolute left-0 mt-1.5 w-80 bg-slate-900 border border-slate-700 rounded shadow-xl py-1.5 z-50">
                  <div className="px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-slate-400 border-b border-slate-800">
                    Signature Engineering Benchmarks
                  </div>
                  {SIGNATURE_PRESETS.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        onSelectPreset(p);
                        setPresetDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-800 transition-colors ${
                        p.id === currentPreset.id ? 'bg-slate-800/80 text-cyan-300 font-semibold' : 'text-slate-300'
                      }`}
                    >
                      <div className="font-medium">{p.name}</div>
                      <div className="text-[11px] text-slate-400 truncate">{p.shortSubtitle}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ZONE 2: Clean Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1">
            {navLinks.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-800 text-cyan-300 border border-slate-700/80'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* ZONE 3: Primary Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={onResetDefaults}
              title="Reset parameters to benchmark defaults"
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenReport}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors whitespace-nowrap"
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>Report</span>
            </button>

            <button
              onClick={() => setActiveTab('OPTIMIZATION')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-black bg-cyan-400 hover:bg-cyan-300 font-mono rounded transition-colors shadow-sm whitespace-nowrap font-bold"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>OPTIMISE</span>
            </button>
          </div>
        </div>

        {/* Sub-menu on smaller viewports */}
        <div className="xl:hidden flex items-center gap-1 overflow-x-auto py-1.5 border-t border-slate-800/80 no-scrollbar">
          {navLinks.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-2 py-0.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-cyan-300'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
