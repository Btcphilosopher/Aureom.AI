/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Authoritative Thermodynamic State Point Table
 */

import React, { useState } from 'react';
import { Download, Filter, HelpCircle, ShieldCheck } from 'lucide-react';
import { ThermodynamicState, ProvenanceSource } from '../thermo/types';

interface ThermodynamicStateTableProps {
  states: ThermodynamicState[];
}

export const ThermodynamicStateTable: React.FC<ThermodynamicStateTableProps> = ({ states }) => {
  const [selectedState, setSelectedState] = useState<ThermodynamicState | null>(null);
  const [unitMode, setUnitMode] = useState<'SI_ENGINEERING' | 'SI_BASE'>('SI_ENGINEERING');

  const exportCSV = () => {
    const headers = [
      'State ID',
      'Name',
      'Pressure (MPa)',
      'Pressure (kPa)',
      'Temperature (°C)',
      'Enthalpy (kJ/kg)',
      'Entropy (kJ/kg·K)',
      'Specific Volume (m³/kg)',
      'Density (kg/m³)',
      'Quality (x)',
      'Phase',
      'Mass Flow (kg/s)',
      'Specific Exergy (kJ/kg)',
      'Provenance',
      'Uncertainty (±%)',
    ];

    const rows = states.map((s) => [
      s.id,
      `"${s.name}"`,
      s.pressureMPa.toFixed(4),
      s.pressureKPa.toFixed(2),
      s.temperatureC.toFixed(2),
      s.specificEnthalpy.toFixed(2),
      s.specificEntropy.toFixed(4),
      s.specificVolume.toFixed(6),
      s.density.toFixed(2),
      s.quality >= 0 ? s.quality.toFixed(4) : 'N/A',
      s.phase,
      s.massFlow.toFixed(2),
      s.specificExergy.toFixed(2),
      s.source,
      s.uncertaintyPct,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `THERMALOPT_States_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getProvenanceBadgeClass = (source: ProvenanceSource) => {
    switch (source) {
      case 'MEASURED':
        return 'text-emerald-400';
      case 'CALCULATED':
        return 'text-cyan-400';
      case 'OPTIMISED':
        return 'text-purple-400';
      case 'SIMULATED':
        return 'text-blue-400';
      case 'ESTIMATED':
        return 'text-amber-400';
      case 'ASSUMED':
      default:
        return 'text-slate-400';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            Thermodynamic State Engine & Provenance Matrix
          </h1>
          <p className="text-xs text-slate-400">
            Strongly typed state vectors (IAPWS-IF97 equations of state) with explicit epistemic provenance and measurement uncertainty.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Segmented unit toggle */}
          <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded">
            <button
              onClick={() => setUnitMode('SI_ENGINEERING')}
              className={`px-2.5 py-1 text-xs font-mono rounded transition-colors ${
                unitMode === 'SI_ENGINEERING' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400'
              }`}
            >
              SI (MPa / °C / kJ)
            </button>
            <button
              onClick={() => setUnitMode('SI_BASE')}
              className={`px-2.5 py-1 text-xs font-mono rounded transition-colors ${
                unitMode === 'SI_BASE' ? 'bg-slate-800 text-cyan-300 font-medium' : 'text-slate-400'
              }`}
            >
              Base SI (Pa / K / J)
            </button>
          </div>

          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-mono transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* State Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[11px] border-b border-slate-800">
              <tr>
                <th className="px-3 py-3 font-semibold">State</th>
                <th className="px-3 py-3 font-semibold">Location / Description</th>
                <th className="px-3 py-3 font-semibold text-right">
                  {unitMode === 'SI_ENGINEERING' ? 'P (MPa)' : 'P (Pa)'}
                </th>
                <th className="px-3 py-3 font-semibold text-right">
                  {unitMode === 'SI_ENGINEERING' ? 'T (°C)' : 'T (K)'}
                </th>
                <th className="px-3 py-3 font-semibold text-right">h (kJ/kg)</th>
                <th className="px-3 py-3 font-semibold text-right">s (kJ/kg·K)</th>
                <th className="px-3 py-3 font-semibold text-right">v (m³/kg)</th>
                <th className="px-3 py-3 font-semibold text-right">Quality (x)</th>
                <th className="px-3 py-3 font-semibold text-right">Flow (kg/s)</th>
                <th className="px-3 py-3 font-semibold text-right">Exergy (kJ/kg)</th>
                <th className="px-3 py-3 font-semibold">Provenance</th>
                <th className="px-3 py-3 font-semibold text-right">Uncert.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono tabular-nums">
              {states.map((st) => (
                <tr
                  key={st.id}
                  onClick={() => setSelectedState(st)}
                  className={`hover:bg-slate-800/60 cursor-pointer transition-colors ${
                    selectedState?.id === st.id ? 'bg-slate-800 text-cyan-300' : 'text-slate-300'
                  }`}
                >
                  <td className="px-3 py-2.5 font-bold text-white">
                    <span className="text-cyan-400">{st.id}</span>
                  </td>
                  <td className="px-3 py-2.5 font-sans font-medium text-slate-200">
                    <div>{st.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{st.phase.replace(/_/g, ' ')}</div>
                  </td>
                  <td className="px-3 py-2.5 text-right font-semibold text-slate-100">
                    {unitMode === 'SI_ENGINEERING' ? st.pressureMPa.toFixed(3) : st.pressure.toExponential(3)}
                  </td>
                  <td className="px-3 py-2.5 text-right font-semibold text-slate-100">
                    {unitMode === 'SI_ENGINEERING' ? st.temperatureC.toFixed(1) : st.temperature.toFixed(2)}
                  </td>
                  <td className="px-3 py-2.5 text-right text-cyan-300">
                    {st.specificEnthalpy.toFixed(1)}
                  </td>
                  <td className="px-3 py-2.5 text-right text-emerald-300">
                    {st.specificEntropy.toFixed(4)}
                  </td>
                  <td className="px-3 py-2.5 text-right text-slate-400 text-[11px]">
                    {st.specificVolume < 0.01 ? st.specificVolume.toFixed(6) : st.specificVolume.toFixed(4)}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    {st.quality >= 0 ? (
                      <span className="text-amber-300 font-bold">{(st.quality * 100).toFixed(1)}%</span>
                    ) : (
                      <span className="text-slate-500">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-right font-medium text-slate-200">
                    {st.massFlow.toFixed(1)}
                  </td>
                  <td className="px-3 py-2.5 text-right text-purple-300">
                    {st.specificExergy.toFixed(1)}
                  </td>
                  <td className="px-3 py-2.5">
                    {/* Clean unboxed text metadata */}
                    <span className={`font-semibold text-[11px] ${getProvenanceBadgeClass(st.source)}`}>
                      {st.source}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right text-slate-400 text-[11px]">
                    ±{st.uncertaintyPct}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected State Inspector Panel */}
      {selectedState && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 animate-in fade-in duration-150">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div className="flex items-center gap-2 font-mono">
              <span className="text-cyan-400 font-bold text-sm">{selectedState.id}:</span>
              <span className="text-white font-bold text-sm">{selectedState.name}</span>
            </div>
            <button
              onClick={() => setSelectedState(null)}
              className="text-xs text-slate-400 hover:text-slate-200 font-mono"
            >
              Dismiss
            </button>
          </div>

          <p className="text-xs text-slate-300 mb-4">{selectedState.description}</p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Internal Energy (u):</span>
              <span className="text-base font-bold text-white">{selectedState.internalEnergy.toFixed(1)} kJ/kg</span>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Density (ρ):</span>
              <span className="text-base font-bold text-white">{selectedState.density.toFixed(2)} kg/m³</span>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Speed of Sound (c):</span>
              <span className="text-base font-bold text-white">{selectedState.speedOfSound?.toFixed(0) || '450'} m/s</span>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Total Exergy Flow Rate:</span>
              <span className="text-base font-bold text-purple-300">{selectedState.totalExergyFlow.toFixed(2)} MW</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
