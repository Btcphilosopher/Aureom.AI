/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — thermaloptR Interactive R Research & Analytics Sandbox
 */

import React, { useState } from 'react';
import { Play, FileCode, Terminal, CheckCircle, Database, Download } from 'lucide-react';
import { SolvedCycleResult } from '../thermo/cycle_solver';
import { 
  THERMALOPT_R_SCRIPTS, 
  RScriptTemplate, 
  executeRScript, 
  RExecutionLog 
} from '../thermo/r_lab_engine';

interface RLabWorkspaceProps {
  solvedCycle: SolvedCycleResult;
}

export const RLabWorkspace: React.FC<RLabWorkspaceProps> = ({ solvedCycle }) => {
  const [selectedScript, setSelectedScript] = useState<RScriptTemplate>(THERMALOPT_R_SCRIPTS[0]);
  const [editableCode, setEditableCode] = useState<string>(THERMALOPT_R_SCRIPTS[0].rCode);
  const [executionLog, setExecutionLog] = useState<RExecutionLog | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  const handleSelectScript = (s: RScriptTemplate) => {
    setSelectedScript(s);
    setEditableCode(s.rCode);
    setExecutionLog(null);
  };

  const handleRunR = () => {
    setIsExecuting(true);
    setTimeout(() => {
      const log = executeRScript(selectedScript.id, solvedCycle);
      setExecutionLog(log);
      setIsExecuting(false);
    }, 150);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <h1 className="text-lg font-bold text-white font-mono uppercase tracking-wide">
            thermaloptR — R Research & Statistical Analytics Laboratory
          </h1>
          <p className="text-xs text-slate-400">
            Statistical computing layer interfacing with the authoritative Rust physics core: Gaussian Process surrogates, Latin Hypercube DoE, and Sobol sensitivity decomposition.
          </p>
        </div>

        <button
          onClick={handleRunR}
          disabled={isExecuting}
          className="flex items-center gap-2 px-5 py-2 text-xs font-bold font-mono text-black bg-cyan-400 hover:bg-cyan-300 disabled:bg-slate-700 disabled:text-slate-400 rounded transition-colors shadow-lg"
        >
          {isExecuting ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
              <span>EXECUTING R REPL...</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>EXECUTE R SCRIPT</span>
            </>
          )}
        </button>
      </div>

      {/* Script Selector Tabs */}
      <div className="flex gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        {THERMALOPT_R_SCRIPTS.map((script) => (
          <button
            key={script.id}
            onClick={() => handleSelectScript(script)}
            className={`px-3 py-1.5 text-xs font-mono rounded transition-colors whitespace-nowrap ${
              selectedScript.id === script.id
                ? 'bg-slate-800 text-cyan-300 font-semibold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {script.title}
          </button>
        ))}
      </div>

      {/* 2-Column Code Editor & Console Output */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left: Interactive R Script Editor */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-[520px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span>{selectedScript.title} (script.R)</span>
            </div>
            <span className="text-[10px] font-mono text-slate-500">R 4.4.2 Environment</span>
          </div>

          <textarea
            value={editableCode}
            onChange={(e) => setEditableCode(e.target.value)}
            spellCheck={false}
            className="flex-1 w-full bg-slate-950 border border-slate-800 rounded p-3 font-mono text-xs text-slate-100 focus:outline-none focus:border-cyan-500 resize-none"
          />
        </div>

        {/* Right: R REPL Console Output */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col h-[520px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>R Console Stdout / Session Logs</span>
            </div>
            {executionLog && (
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                <span>Execution Finished at {executionLog.timestamp}</span>
              </span>
            )}
          </div>

          <div className="flex-1 w-full bg-slate-950 border border-slate-800 rounded p-3 font-mono text-xs text-emerald-400 overflow-y-auto whitespace-pre-wrap">
            {executionLog ? (
              executionLog.output
            ) : (
              <span className="text-slate-600">
                Click "EXECUTE R SCRIPT" to connect to the Rust backend and run statistical estimation.
              </span>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
