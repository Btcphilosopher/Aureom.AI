/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Main Engineering Workstation Entry Point
 */

import React, { useState, useMemo } from 'react';
import { Navbar, NavigationTab } from './components/Navbar';
import { MainDashboard } from './components/MainDashboard';
import { CycleDesigner } from './components/CycleDesigner';
import { ThermodynamicStateTable } from './components/ThermodynamicStateTable';
import { ThermodynamicDiagramLab } from './components/ThermodynamicDiagramLab';
import { TurbineLab } from './components/TurbineLab';
import { BoilerCondenserLab } from './components/BoilerCondenserLab';
import { RegenerationLab } from './components/RegenerationLab';
import { ExergyLab } from './components/ExergyLab';
import { OptimizationLab } from './components/OptimizationLab';
import { TurbineLandscapeLab } from './components/TurbineLandscapeLab';
import { SensitivityUncertaintyLab } from './components/SensitivityUncertaintyLab';
import { DigitalTwinLab } from './components/DigitalTwinLab';
import { WhatIfLab } from './components/WhatIfLab';
import { RLabWorkspace } from './components/RLabWorkspace';
import { RustArchitectureViewer } from './components/RustArchitectureViewer';
import { EngineeringReportModal } from './components/EngineeringReportModal';

import { SIGNATURE_PRESETS, PresetCycleDefinition } from './thermo/presets';
import { CycleDesignParameters } from './thermo/components';
import { solveRankineCycle, SolvedCycleResult } from './thermo/cycle_solver';

export function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('DASHBOARD');
  const [currentPreset, setCurrentPreset] = useState<PresetCycleDefinition>(SIGNATURE_PRESETS[0]);
  const [cycleParams, setCycleParams] = useState<CycleDesignParameters>(SIGNATURE_PRESETS[0].params);
  const [isReportOpen, setIsReportOpen] = useState(false);

  // Authoritative directed thermodynamic cycle solution
  const solvedCycle: SolvedCycleResult = useMemo(() => {
    return solveRankineCycle(cycleParams, 'CALCULATED');
  }, [cycleParams]);

  const handleSelectPreset = (preset: PresetCycleDefinition) => {
    setCurrentPreset(preset);
    setCycleParams({ ...preset.params });
  };

  const handleResetDefaults = () => {
    setCycleParams({ ...currentPreset.params });
  };

  const handleApplyOptimalParams = (optimal: CycleDesignParameters) => {
    setCycleParams(optimal);
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 font-sans selection:bg-cyan-500 selection:text-black">
      
      {/* 3-Zone Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentPreset={currentPreset}
        onSelectPreset={handleSelectPreset}
        solvedCycle={solvedCycle}
        onOpenReport={() => setIsReportOpen(true)}
        onResetDefaults={handleResetDefaults}
      />

      {/* Main Workspace Content Area */}
      <main className="pb-16">
        {activeTab === 'DASHBOARD' && (
          <MainDashboard
            solvedCycle={solvedCycle}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'CYCLE_DESIGNER' && (
          <CycleDesigner
            params={cycleParams}
            onChangeParams={setCycleParams}
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'STATES' && (
          <ThermodynamicStateTable
            states={solvedCycle.states}
          />
        )}

        {activeTab === 'DIAGRAMS' && (
          <ThermodynamicDiagramLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'TURBINE_LAB' && (
          <TurbineLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'BOILER_CONDENSER' && (
          <BoilerCondenserLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'REGENERATION' && (
          <RegenerationLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'EXERGY_LAB' && (
          <ExergyLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'OPTIMIZATION' && (
          <OptimizationLab
            currentParams={cycleParams}
            solvedCycle={solvedCycle}
            onApplyOptimalParams={handleApplyOptimalParams}
          />
        )}

        {activeTab === 'LANDSCAPE' && (
          <TurbineLandscapeLab
            baseParams={cycleParams}
          />
        )}

        {activeTab === 'SENSITIVITY' && (
          <SensitivityUncertaintyLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'DIGITAL_TWIN' && (
          <DigitalTwinLab
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'WHAT_IF' && (
          <WhatIfLab
            baseParams={cycleParams}
            baseCycle={solvedCycle}
          />
        )}

        {activeTab === 'R_LAB' && (
          <RLabWorkspace
            solvedCycle={solvedCycle}
          />
        )}

        {activeTab === 'RUST_CORE' && (
          <RustArchitectureViewer />
        )}
      </main>

      {/* Engineering Audit Report Modal */}
      <EngineeringReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        solvedCycle={solvedCycle}
      />

    </div>
  );
}

export default App;
