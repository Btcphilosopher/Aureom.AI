/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Rust Workspace Structure & Code Generator
 */

export interface RustCrateFile {
  path: string;
  crate: string;
  description: string;
  code: string;
}

export const RUST_WORKSPACE_CRATES: RustCrateFile[] = [
  {
    path: 'Cargo.toml',
    crate: 'workspace',
    description: 'Root Cargo Workspace configuration for thermalopt-rs',
    code: `[workspace]
resolver = "2"
members = [
    "crates/thermo-core",
    "crates/steam",
    "crates/fluids",
    "crates/units",
    "crates/state",
    "crates/cycle",
    "crates/components",
    "crates/turbine",
    "crates/pump",
    "crates/boiler",
    "crates/condenser",
    "crates/feedwater",
    "crates/exergy",
    "crates/solver",
    "crates/constraints",
    "crates/optimisation",
    "crates/sensitivity",
    "crates/uncertainty",
    "crates/digital-twin",
    "crates/calibration",
    "crates/mpc",
    "crates/economics",
    "crates/provenance",
    "crates/cli",
]

[workspace.package]
version = "2.4.0"
authors = ["THERMALOPT Engineering Consortium <eng@thermalopt.rs>"]
edition = "2024"
license = "Apache-2.0"
repository = "https://github.com/thermalopt/thermalopt-rs"

[workspace.dependencies]
nalgebra = { version = "0.33", features = ["serde-serialize"] }
ndarray = { version = "0.16", features = ["rayon", "serde"] }
rayon = "1.10"
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
thiserror = "2.0"
anyhow = "1.0"
tracing = "0.1"
arrow = { version = "53.0", features = ["ipc", "prettyprint"] }
parquet = "53.0"
criterion = { version = "0.5", features = ["html_reports"] }
approx = "0.5"
`,
  },
  {
    path: 'crates/units/src/lib.rs',
    crate: 'units',
    description: 'Strongly typed SI physical units with zero-cost dimensional analysis',
    code: `//! Dimensionally typed physical quantities preventing unit conversion errors.

use std::fmt;
use std::ops::{Add, Sub, Mul, Div};
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct Pressure(pub f64); // Pascals (Pa)

impl Pressure {
    #[inline] pub fn from_bar(bar: f64) -> Self { Self(bar * 1e5) }
    #[inline] pub fn from_mpa(mpa: f64) -> Self { Self(mpa * 1e6) }
    #[inline] pub fn from_kpa(kpa: f64) -> Self { Self(kpa * 1e3) }
    #[inline] pub fn as_bar(&self) -> f64 { self.0 / 1e5 }
    #[inline] pub fn as_mpa(&self) -> f64 { self.0 / 1e6 }
    #[inline] pub fn as_kpa(&self) -> f64 { self.0 / 1e3 }
    #[inline] pub fn as_pa(&self) -> f64 { self.0 }
}

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct Temperature(pub f64); // Kelvin (K)

impl Temperature {
    #[inline] pub fn from_celsius(c: f64) -> Self { Self(c + 273.15) }
    #[inline] pub fn from_kelvin(k: f64) -> Self { Self(k) }
    #[inline] pub fn as_celsius(&self) -> f64 { self.0 - 273.15 }
    #[inline] pub fn as_kelvin(&self) -> f64 { self.0 }
}

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct SpecificEnthalpy(pub f64); // kJ/kg

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct SpecificEntropy(pub f64); // kJ/(kg·K)

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct MassFlow(pub f64); // kg/s

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct Power(pub f64); // MW (Megawatts)

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Serialize, Deserialize)]
pub struct Efficiency(pub f64); // 0.0 .. 1.0
`,
  },
  {
    path: 'crates/state/src/lib.rs',
    crate: 'state',
    description: 'Strongly typed ThermodynamicState struct with provenance and uncertainty',
    code: `//! Authoritative ThermodynamicState representation in Rust

use serde::{Serialize, Deserialize};
use units::{Pressure, Temperature, SpecificEnthalpy, SpecificEntropy, MassFlow};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Phase {
    CompressedLiquid,
    SaturatedLiquid,
    TwoPhaseWetSteam,
    SaturatedVapor,
    SuperheatedVapor,
    Supercritical,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Provenance {
    Measured,
    Calculated,
    Estimated,
    Simulated,
    Optimised,
    Assumed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThermodynamicState {
    pub id: String,
    pub name: String,
    pub pressure: Pressure,
    pub temperature: Temperature,
    pub enthalpy: SpecificEnthalpy,
    pub entropy: SpecificEntropy,
    pub specific_volume: f64, // m³/kg
    pub density: f64,         // kg/m³
    pub internal_energy: f64, // kJ/kg
    pub quality: Option<f64>, // 0.0 .. 1.0 if two-phase
    pub phase: Phase,
    pub mass_flow: MassFlow,
    pub specific_exergy: f64, // kJ/kg
    pub provenance: Provenance,
    pub uncertainty_pct: f64,
}
`,
  },
  {
    path: 'crates/steam/src/lib.rs',
    crate: 'steam',
    description: 'IAPWS-IF97 Water & Steam formulation with region boundaries',
    code: `//! High-accuracy IAPWS-IF97 formulation for industrial water/steam properties.

use state::{Phase, ThermodynamicState, Provenance};
use units::{Pressure, Temperature, SpecificEnthalpy, SpecificEntropy, MassFlow};
use thiserror::Error;

pub const CRITICAL_TEMP_K: f64 = 647.096;
pub const CRITICAL_PRESSURE_PA: f64 = 22.064e6;
pub const T0_DEAD_STATE_K: f64 = 298.15; // 25 °C
pub const P0_DEAD_STATE_PA: f64 = 101325.0;

#[derive(Error, Debug)]
pub enum SteamPropertyError {
    #[error("Temperature {0} K is outside IAPWS-IF97 validity range [273.15, 1073.15] K")]
    TemperatureOutOfRange(f64),
    #[error("Pressure {0} Pa is outside IAPWS-IF97 validity range [611.657, 100.0e6] Pa")]
    PressureOutOfRange(f64),
    #[error("Newton-Raphson convergence failed for property inversion")]
    ConvergenceFailure,
}

pub trait SteamPropertyProvider: Send + Sync {
    fn from_pt(&self, p: Pressure, t: Temperature) -> Result<ThermodynamicState, SteamPropertyError>;
    fn from_ph(&self, p: Pressure, h: SpecificEnthalpy) -> Result<ThermodynamicState, SteamPropertyError>;
    fn from_ps(&self, p: Pressure, s: SpecificEntropy) -> Result<ThermodynamicState, SteamPropertyError>;
    fn saturation_pressure(&self, t: Temperature) -> Pressure;
    fn saturation_temperature(&self, p: Pressure) -> Temperature;
}
`,
  },
  {
    path: 'crates/solver/src/lib.rs',
    crate: 'solver',
    description: 'Directed Thermodynamic Graph Solver & Exergy Loss Accounting',
    code: `//! Rankine Cycle Graph Solver with mass & energy balances and 2nd law exergy destruction.

use state::ThermodynamicState;
use units::{Pressure, Temperature, SpecificEnthalpy, SpecificEntropy, MassFlow, Power, Efficiency};
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SolvedCycle {
    pub states: Vec<ThermodynamicState>,
    pub net_power: Power,
    pub gross_turbine_power: Power,
    pub total_pump_power: Power,
    pub heat_input_boiler: Power,
    pub heat_input_reheat: Power,
    pub total_heat_input: Power,
    pub condenser_rejection: Power,
    pub thermal_efficiency: Efficiency,
    pub exergy_efficiency: Efficiency,
    pub heat_rate_kj_kwh: f64,
    pub total_exergy_destruction: Power,
    pub closure_error_mw: f64,
}
`,
  },
  {
    path: 'crates/optimisation/src/lib.rs',
    crate: 'optimisation',
    description: 'Differential Evolution, Latin Hypercube & NSGA-II Pareto multi-objective solver',
    code: `//! High-performance Rust optimization framework for thermodynamic cycle search spaces.

use rayon::prelude::*;
use serde::{Serialize, Deserialize};

pub trait ObjectiveFunction: Send + Sync {
    fn evaluate(&self, x: &[f64]) -> Result<f64, String>;
}

pub struct DifferentialEvolution {
    pub pop_size: usize,
    pub max_generations: usize,
    pub f_weight: f64,
    pub cr_prob: f64,
}

impl DifferentialEvolution {
    pub fn optimize<F: ObjectiveFunction>(&self, obj: &F, bounds: &[(f64, f64)]) -> (Vec<f64>, f64) {
        // Parallel population evaluation using Rayon
        // ...
        (vec![], 0.0)
    }
}
`,
  },
  {
    path: 'crates/cli/src/main.rs',
    crate: 'cli',
    description: 'THERMALOPT CLI command-line interface',
    code: `//! THERMALOPT.RS Command-Line Tool

use clap::{Parser, Subcommand};

#[derive(Parser)]
#[command(name = "thermalopt")]
#[command(about = "THERMALOPT.RS — Thermodynamic Digital Twin & Rankine Optimization Engine")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Solve a Rankine cycle topology
    Solve {
        #[arg(short, long, default_value = "500mw-benchmark")]
        preset: String,
    },
    /// Optimise cycle parameters for target objective
    Optimise {
        #[arg(long, default_value = "max-efficiency")]
        objective: String,
        #[arg(long, default_value = "10:28")]
        boiler_pressure_range: String,
        #[arg(long, default_value = "500:620")]
        superheat_range: String,
    },
    /// Run Monte Carlo uncertainty quantification
    MonteCarlo {
        #[arg(short, long, default_value_t = 10000)]
        samples: usize,
    },
    /// Benchmark thermodynamic evaluations per second
    Benchmark,
}

fn main() {
    let cli = Cli::parse();
    println!("THERMALOPT.RS [Authoritative Numerical Engine Initialized]");
}
`,
  },
];
