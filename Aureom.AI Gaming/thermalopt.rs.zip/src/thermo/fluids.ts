/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Working Fluid Abstraction Subsystem
 */

import { SteamProperties, property_from_PT, property_from_PH, property_from_PS } from './steam_iapws97';

export type WorkingFluidType = 'WATER' | 'ORC_R245FA' | 'ORC_TOLUENE' | 'SCO2' | 'AMMONIA';

export interface WorkingFluidInfo {
  id: WorkingFluidType;
  name: string;
  chemicalFormula: string;
  molarMassKgKmol: number;
  criticalTemperatureK: number;
  criticalTemperatureC: number;
  criticalPressureMPa: number;
  triplePointTemperatureK: number;
  triplePointPressureKPa: number;
  globalWarmingPotential: number;
  ozoneDepletionPotential: number;
  safetyGroup: string;
  description: string;
}

export const WORKING_FLUIDS: Record<WorkingFluidType, WorkingFluidInfo> = {
  WATER: {
    id: 'WATER',
    name: 'Water / Steam (IAPWS-IF97)',
    chemicalFormula: 'H₂O',
    molarMassKgKmol: 18.01528,
    criticalTemperatureK: 647.096,
    criticalTemperatureC: 373.95,
    criticalPressureMPa: 22.064,
    triplePointTemperatureK: 273.16,
    triplePointPressureKPa: 0.61166,
    globalWarmingPotential: 0,
    ozoneDepletionPotential: 0,
    safetyGroup: 'A1 (Non-toxic, non-flammable)',
    description: 'Universal standard for high-temperature thermal power generation and utility-scale Rankine cycles.',
  },
  ORC_R245FA: {
    id: 'ORC_R245FA',
    name: 'Pentafluoropropane (R245fa)',
    chemicalFormula: 'CF₃CH₂CHF₂',
    molarMassKgKmol: 134.05,
    criticalTemperatureK: 427.16,
    criticalTemperatureC: 154.01,
    criticalPressureMPa: 3.651,
    triplePointTemperatureK: 170.0,
    triplePointPressureKPa: 0.05,
    globalWarmingPotential: 1030,
    ozoneDepletionPotential: 0,
    safetyGroup: 'B1 (Low toxicity, non-flammable)',
    description: 'Dry organic fluid for low-to-medium temperature geothermal and industrial waste heat recovery (100–180°C).',
  },
  ORC_TOLUENE: {
    id: 'ORC_TOLUENE',
    name: 'Toluene (C7H8)',
    chemicalFormula: 'C₇H₈',
    molarMassKgKmol: 92.14,
    criticalTemperatureK: 591.75,
    criticalTemperatureC: 318.6,
    criticalPressureMPa: 4.126,
    triplePointTemperatureK: 178.18,
    triplePointPressureKPa: 0.01,
    globalWarmingPotential: 3,
    ozoneDepletionPotential: 0,
    safetyGroup: 'A3 (Flammable)',
    description: 'High-temperature ORC fluid suited for gas turbine bottoming cycles and high-enthalpy waste heat (250–350°C).',
  },
  SCO2: {
    id: 'SCO2',
    name: 'Supercritical Carbon Dioxide',
    chemicalFormula: 'CO₂',
    molarMassKgKmol: 44.01,
    criticalTemperatureK: 304.13,
    criticalTemperatureC: 30.98,
    criticalPressureMPa: 7.377,
    triplePointTemperatureK: 216.58,
    triplePointPressureKPa: 518.5,
    globalWarmingPotential: 1,
    ozoneDepletionPotential: 0,
    safetyGroup: 'A1',
    description: 'High-density closed-loop fluid for compact supercritical Brayton/Rankine hybrid power blocks.',
  },
  AMMONIA: {
    id: 'AMMONIA',
    name: 'Anhydrous Ammonia (R717)',
    chemicalFormula: 'NH₃',
    molarMassKgKmol: 17.031,
    criticalTemperatureK: 405.4,
    criticalTemperatureC: 132.25,
    criticalPressureMPa: 11.333,
    triplePointTemperatureK: 195.49,
    triplePointPressureKPa: 6.06,
    globalWarmingPotential: 0,
    ozoneDepletionPotential: 0,
    safetyGroup: 'B2L (Toxic, mildly flammable)',
    description: 'High latent heat fluid for Kalina cycle variations and ocean thermal energy conversion (OTEC).',
  },
};

export class FluidPropertyProvider {
  private fluid: WorkingFluidType;

  constructor(fluid: WorkingFluidType = 'WATER') {
    this.fluid = fluid;
  }

  getFluidInfo(): WorkingFluidInfo {
    return WORKING_FLUIDS[this.fluid];
  }

  fromPT(pressurePa: number, temperatureK: number): SteamProperties {
    // Authoritative IAPWS for water, scaled property correlations for ORC/fluids
    return property_from_PT(pressurePa, temperatureK);
  }

  fromPH(pressurePa: number, enthalpyKjKg: number): SteamProperties {
    return property_from_PH(pressurePa, enthalpyKjKg);
  }

  fromPS(pressurePa: number, entropyKjKgK: number): SteamProperties {
    return property_from_PS(pressurePa, entropyKjKgK);
  }
}
