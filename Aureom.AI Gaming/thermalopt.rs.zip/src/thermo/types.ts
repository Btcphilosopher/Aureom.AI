/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Thermodynamic Type System & SI Physical Quantities
 */

export type ProvenanceSource = 
  | 'MEASURED'
  | 'CALCULATED'
  | 'ESTIMATED'
  | 'SIMULATED'
  | 'OPTIMISED'
  | 'ASSUMED';

export type FluidPhase = 
  | 'COMPRESSED_LIQUID'
  | 'SATURATED_LIQUID'
  | 'TWO_PHASE_WET_STEAM'
  | 'SATURATED_VAPOR'
  | 'SUPERHEATED_VAPOR'
  | 'SUPERCRITICAL';

export interface UncertaintyValue {
  mean: number;
  stdDev: number;
  p5: number;
  p50: number;
  p95: number;
  unit: string;
}

export interface ThermodynamicQuantity<T = number> {
  value: T;
  unit: string;
  source: ProvenanceSource;
  uncertainty?: number; // relative uncertainty percentage (e.g., 0.005 for 0.5%)
  provenanceNote?: string;
}

export interface ThermodynamicState {
  id: string;
  name: string;
  description: string;
  
  // Primary State Variables (SI Units)
  pressure: number;          // Pa (Pascals)
  temperature: number;       // K (Kelvin)
  temperatureC: number;      // °C
  pressureBar: number;       // bar
  pressureKPa: number;       // kPa
  pressureMPa: number;       // MPa
  
  // Derived Specific Thermodynamic Properties
  specificEnthalpy: number;  // kJ/kg (h)
  specificEntropy: number;   // kJ/(kg·K) (s)
  specificVolume: number;    // m³/kg (v)
  density: number;           // kg/m³ (ρ)
  internalEnergy: number;    // kJ/kg (u = h - Pv)
  
  // Two-Phase & Quality
  quality: number;           // 0.0 (sat liq) to 1.0 (sat vap), or -1 if single phase
  phase: FluidPhase;
  speedOfSound?: number;     // m/s
  
  // Flow & Exergy
  massFlow: number;          // kg/s
  flowFraction: number;      // fraction of primary throttle flow (1.0 = 100%)
  specificExergy: number;    // kJ/kg (ex = (h - h0) - T0*(s - s0))
  totalExergyFlow: number;   // MW
  
  // Metadata & Provenance
  source: ProvenanceSource;
  uncertaintyPct: number;
  timestamp: string;
}

export interface ComponentBalance {
  componentId: string;
  componentName: string;
  type: string;
  
  inletStates: string[];
  outletStates: string[];
  
  massFlowIn: number;   // kg/s
  massFlowOut: number;  // kg/s
  massClosureError: number; // kg/s
  
  heatTransferRate: number; // MW (positive = heat added to fluid)
  power: number;            // MW (positive = power produced by turbine, negative = pump power)
  
  entropyGenRate: number;   // kW/K
  exergyDestructionRate: number; // MW
  exergyEfficiency: number;      // 0.0 to 1.0 (or percentage)
  
  firstLawEfficiency?: number;  // isentropic or thermal efficiency
  pressureDropBar: number;      // bar
  temperatureChangeC: number;   // °C
  
  balanceClosureError: number;  // MW (Energy in - Energy out)
  isPhysicallyValid: boolean;
  validationFlags: string[];
}

export interface CyclePerformanceSummary {
  netPowerMW: number;
  grossTurbinePowerMW: number;
  totalPumpPowerMW: number;
  auxiliaryPowerMW: number;
  
  heatInputBoilerMW: number;
  heatInputReheatMW: number;
  totalHeatInputMW: number;
  
  condenserHeatRejectionMW: number;
  coolingWaterFlowKgs: number;
  
  thermalEfficiencyPct: number;     // First-Law: W_net / Q_in
  carnotEfficiencyPct: number;      // 1 - Tc / Th
  exergyEfficiencyPct: number;      // Second-Law: W_net / Ex_in
  
  heatRateKjKwh: number;            // 3600 / η_th
  steamFlowRateKgs: number;         // Primary mass flow
  turbineExhaustQuality: number;    // Steam quality at LP exit
  
  totalExergyDestructionMW: number;
  energyBalanceClosureErrorMW: number;
  isBalanceClosed: boolean;
  
  specificWorkKjKg: number;
  coolingDutyMW: number;
  co2EmissionsTonsPerHour: number;
  operatingCostPerMWh: number;
}
