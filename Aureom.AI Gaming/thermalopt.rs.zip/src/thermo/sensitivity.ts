/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Sensitivity Engine & Jacobian Partial Derivative Matrix
 */

import { CycleDesignParameters } from './components';
import { solveRankineCycle } from './cycle_solver';

export interface ParameterSensitivity {
  parameterName: string;
  parameterKey: keyof CycleDesignParameters;
  nominalValue: number;
  unit: string;
  deltaUnit: string;
  
  // First-order Partial Derivatives
  dEta_dParam: number;      // % efficiency change per unit parameter change
  dPower_dParam: number;    // MW change per unit parameter change
  dExergy_dParam: number;   // MW change in exergy destruction
  dHeatRate_dParam: number; // kJ/kWh change per unit
  
  // Normalized Dimensionless Elasticity: (dY/Y) / (dX/X)
  efficiencyElasticity: number;
  powerElasticity: number;
  importanceRank: number;
}

export interface SensitivityMatrixResult {
  baseEfficiencyPct: number;
  baseNetPowerMW: number;
  baseHeatRateKjKwh: number;
  sensitivities: ParameterSensitivity[];
  tornadoChartData: { parameter: string; lowEfficiency: number; highEfficiency: number; rangePct: number }[];
}

export function computeSensitivityMatrix(params: CycleDesignParameters): SensitivityMatrixResult {
  const baseRes = solveRankineCycle(params, 'CALCULATED');
  const baseEta = baseRes.summary.thermalEfficiencyPct;
  const basePower = baseRes.summary.netPowerMW;
  const baseHR = baseRes.summary.heatRateKjKwh;

  const targetParams: { key: keyof CycleDesignParameters; name: string; unit: string; deltaUnit: string; step: number }[] = [
    { key: 'boilerPressureMPa', name: 'Boiler Pressure (P_boiler)', unit: 'MPa', deltaUnit: 'per MPa', step: 0.2 },
    { key: 'superheatTemperatureC', name: 'Superheat Temperature (T_sh)', unit: '°C', deltaUnit: 'per 10°C', step: 5.0 },
    { key: 'reheatPressureMPa', name: 'Reheat Pressure (P_rh)', unit: 'MPa', deltaUnit: 'per MPa', step: 0.2 },
    { key: 'reheatTemperatureC', name: 'Reheat Temperature (T_rh)', unit: '°C', deltaUnit: 'per 10°C', step: 5.0 },
    { key: 'condenserPressureKPa', name: 'Condenser Pressure (P_cond)', unit: 'kPa', deltaUnit: 'per kPa', step: 0.2 },
    { key: 'hpTurbineEfficiency', name: 'HP Turbine Isentropic Eff', unit: '-', deltaUnit: 'per +1%', step: 0.01 },
    { key: 'lpTurbineEfficiency', name: 'LP Turbine Isentropic Eff', unit: '-', deltaUnit: 'per +1%', step: 0.01 },
    { key: 'boilerThermalEfficiency', name: 'Boiler Thermal Eff', unit: '-', deltaUnit: 'per +1%', step: 0.01 },
    { key: 'throttleMassFlowKgs', name: 'Throttle Steam Flow', unit: 'kg/s', deltaUnit: 'per 10 kg/s', step: 5.0 },
    { key: 'coolingWaterInletTempC', name: 'Cooling Water Inlet Temp', unit: '°C', deltaUnit: 'per °C', step: 1.0 },
  ];

  const sensitivities: ParameterSensitivity[] = [];
  const tornado: { parameter: string; lowEfficiency: number; highEfficiency: number; rangePct: number }[] = [];

  for (const item of targetParams) {
    const nominal = (params as any)[item.key] as number;
    if (nominal === undefined) continue;

    // Perturbations for central difference: (f(x+h) - f(x-h)) / (2h)
    const h = item.step;
    const pPlus = { ...params, [item.key]: nominal + h };
    const pMinus = { ...params, [item.key]: nominal - h };

    const resPlus = solveRankineCycle(pPlus, 'SIMULATED');
    const resMinus = solveRankineCycle(pMinus, 'SIMULATED');

    const dEta = (resPlus.summary.thermalEfficiencyPct - resMinus.summary.thermalEfficiencyPct) / (2 * h);
    const dPower = (resPlus.summary.netPowerMW - resMinus.summary.netPowerMW) / (2 * h);
    const dEx = (resPlus.summary.totalExergyDestructionMW - resMinus.summary.totalExergyDestructionMW) / (2 * h);
    const dHR = (resPlus.summary.heatRateKjKwh - resMinus.summary.heatRateKjKwh) / (2 * h);

    // Elasticity: (dEta / baseEta) / (h / nominal)
    const effElasticity = (dEta * nominal) / baseEta;
    const powerElasticity = (dPower * nominal) / basePower;

    sensitivities.push({
      parameterName: item.name,
      parameterKey: item.key,
      nominalValue: nominal,
      unit: item.unit,
      deltaUnit: item.deltaUnit,
      dEta_dParam: +dEta.toFixed(4),
      dPower_dParam: +dPower.toFixed(4),
      dExergy_dParam: +dEx.toFixed(4),
      dHeatRate_dParam: +dHR.toFixed(4),
      efficiencyElasticity: +effElasticity.toFixed(4),
      powerElasticity: +powerElasticity.toFixed(4),
      importanceRank: 0,
    });

    // Tornado Range for +/- 5% variation
    const lowVal = (params as any)[item.key] * 0.95;
    const highVal = (params as any)[item.key] * 1.05;
    const resLow = solveRankineCycle({ ...params, [item.key]: lowVal }, 'SIMULATED');
    const resHigh = solveRankineCycle({ ...params, [item.key]: highVal }, 'SIMULATED');
    
    tornado.push({
      parameter: item.name,
      lowEfficiency: Math.min(resLow.summary.thermalEfficiencyPct, resHigh.summary.thermalEfficiencyPct),
      highEfficiency: Math.max(resLow.summary.thermalEfficiencyPct, resHigh.summary.thermalEfficiencyPct),
      rangePct: Math.abs(resHigh.summary.thermalEfficiencyPct - resLow.summary.thermalEfficiencyPct),
    });
  }

  // Sort sensitivities by absolute elasticity
  sensitivities.sort((a, b) => Math.abs(b.efficiencyElasticity) - Math.abs(a.efficiencyElasticity));
  sensitivities.forEach((s, i) => s.importanceRank = i + 1);

  tornado.sort((a, b) => b.rangePct - a.rangePct);

  return {
    baseEfficiencyPct: baseEta,
    baseNetPowerMW: basePower,
    baseHeatRateKjKwh: baseHR,
    sensitivities,
    tornadoChartData: tornado,
  };
}
