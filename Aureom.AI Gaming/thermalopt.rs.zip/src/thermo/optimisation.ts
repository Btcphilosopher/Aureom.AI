/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Multi-Objective & Single-Objective Optimization Engine (Pareto / DE / Nelder-Mead / LHS)
 */

import { CycleDesignParameters } from './components';
import { solveRankineCycle, SolvedCycleResult } from './cycle_solver';

export type OptimizationObjective = 
  | 'MAX_THERMAL_EFFICIENCY'
  | 'MAX_NET_POWER'
  | 'MAX_EXERGY_EFFICIENCY'
  | 'MIN_HEAT_RATE'
  | 'MIN_COOLING_DUTY'
  | 'MIN_OPERATING_COST'
  | 'MIN_EXERGY_DESTRUCTION'
  | 'MULTI_OBJECTIVE_PARETO';

export type OptimizationMethod = 
  | 'DIFFERENTIAL_EVOLUTION'
  | 'NELDER_MEAD'
  | 'LATIN_HYPERCUBE'
  | 'GRID_SEARCH'
  | 'NSGA_II';

export interface OptimizationVariableBounds {
  name: string;
  key: keyof CycleDesignParameters | string;
  min: number;
  max: number;
  unit: string;
  step?: number;
}

export interface ParetoCandidate {
  id: number;
  params: CycleDesignParameters;
  thermalEfficiencyPct: number;
  netPowerMW: number;
  operatingCostPerMWh: number;
  exergyDestructionMW: number;
  coolingDutyMW: number;
  exhaustQuality: number;
  isFeasible: boolean;
  rank: number;
  crowdingDistance: number;
}

export interface OptimizationResult {
  method: OptimizationMethod;
  objective: OptimizationObjective;
  evaluationsCount: number;
  executionTimeMs: number;
  baseline: SolvedCycleResult;
  bestSolution: SolvedCycleResult;
  improvements: {
    efficiencyGainPctPts: number;
    powerGainMW: number;
    heatRateReductionKjKwh: number;
    costReductionPct: number;
    exergyDestructionReductionMW: number;
  };
  paretoFrontier: ParetoCandidate[];
  convergenceHistory: { iteration: number; bestFitness: number; meanFitness: number }[];
  variableBounds: OptimizationVariableBounds[];
}

export function runOptimization(
  baseParams: CycleDesignParameters,
  objective: OptimizationObjective = 'MAX_THERMAL_EFFICIENCY',
  method: OptimizationMethod = 'DIFFERENTIAL_EVOLUTION',
  populationSize = 40,
  maxGenerations = 25
): OptimizationResult {
  const startTime = performance.now();
  const baseline = solveRankineCycle(baseParams, 'CALCULATED');

  const bounds: OptimizationVariableBounds[] = [
    { name: 'Boiler Pressure', key: 'boilerPressureMPa', min: 10.0, max: 28.0, unit: 'MPa' },
    { name: 'Superheat Temperature', key: 'superheatTemperatureC', min: 500.0, max: 620.0, unit: '°C' },
    { name: 'Reheat Pressure', key: 'reheatPressureMPa', min: 2.0, max: 6.5, unit: 'MPa' },
    { name: 'Reheat Temperature', key: 'reheatTemperatureC', min: 500.0, max: 620.0, unit: '°C' },
    { name: 'Condenser Pressure', key: 'condenserPressureKPa', min: 3.5, max: 12.0, unit: 'kPa' },
    { name: 'Throttle Steam Flow', key: 'throttleMassFlowKgs', min: baseParams.throttleMassFlowKgs * 0.85, max: baseParams.throttleMassFlowKgs * 1.15, unit: 'kg/s' },
  ];

  const allCandidates: ParetoCandidate[] = [];
  const convergenceHistory: { iteration: number; bestFitness: number; meanFitness: number }[] = [];

  let bestParams = { ...baseParams };
  let bestFitness = -Infinity;
  let evaluations = 0;

  // Fitness evaluation helper
  const evaluateFitness = (p: CycleDesignParameters): { fitness: number; res: SolvedCycleResult; feasible: boolean } => {
    evaluations++;
    try {
      const res = solveRankineCycle(p, 'OPTIMISED');
      
      // Constraint validation gate
      const isFeasible = (
        res.summary.turbineExhaustQuality >= 0.86 && // Wilson line limit (max 14% moisture)
        res.summary.thermalEfficiencyPct > 30.0 &&
        res.summary.netPowerMW > 0 &&
        res.summary.isBalanceClosed
      );

      if (!isFeasible) {
        return { fitness: -1e6, res, feasible: false };
      }

      let fit = 0;
      switch (objective) {
        case 'MAX_THERMAL_EFFICIENCY':
          fit = res.summary.thermalEfficiencyPct;
          break;
        case 'MAX_NET_POWER':
          fit = res.summary.netPowerMW;
          break;
        case 'MAX_EXERGY_EFFICIENCY':
          fit = res.summary.exergyEfficiencyPct;
          break;
        case 'MIN_HEAT_RATE':
          fit = -res.summary.heatRateKjKwh;
          break;
        case 'MIN_COOLING_DUTY':
          fit = -res.summary.coolingDutyMW;
          break;
        case 'MIN_OPERATING_COST':
          fit = -res.summary.operatingCostPerMWh;
          break;
        case 'MIN_EXERGY_DESTRUCTION':
          fit = -res.summary.totalExergyDestructionMW;
          break;
        case 'MULTI_OBJECTIVE_PARETO':
        default:
          fit = res.summary.thermalEfficiencyPct * 0.6 + (res.summary.netPowerMW / 10) * 0.4;
          break;
      }

      return { fitness: fit, res, feasible: true };
    } catch {
      return { fitness: -1e6, res: baseline, feasible: false };
    }
  };

  // Generate Initial Population via Latin Hypercube Sampling
  const pop: CycleDesignParameters[] = [];
  for (let i = 0; i < populationSize; i++) {
    const candidate: CycleDesignParameters = { ...baseParams };
    for (const b of bounds) {
      const r = (i + Math.random()) / populationSize;
      (candidate as any)[b.key] = b.min + r * (b.max - b.min);
    }
    pop.push(candidate);
  }

  // Evolutionary Generations (Differential Evolution / NSGA-II principles)
  for (let gen = 0; gen < maxGenerations; gen++) {
    let genFitnessSum = 0;
    let genValidCount = 0;

    for (let i = 0; i < populationSize; i++) {
      // DE mutation & crossover
      const r1 = Math.floor(Math.random() * populationSize);
      const r2 = Math.floor(Math.random() * populationSize);
      const r3 = Math.floor(Math.random() * populationSize);
      const F = 0.65; // differential weight
      const CR = 0.8; // crossover probability

      const trial: CycleDesignParameters = { ...pop[i] };
      for (const b of bounds) {
        if (Math.random() < CR) {
          const val1 = (pop[r1] as any)[b.key];
          const val2 = (pop[r2] as any)[b.key];
          const val3 = (pop[r3] as any)[b.key];
          let mutated = val1 + F * (val2 - val3);
          mutated = Math.max(b.min, Math.min(b.max, mutated));
          (trial as any)[b.key] = mutated;
        }
      }

      const evalTarget = evaluateFitness(trial);
      if (evalTarget.feasible) {
        genFitnessSum += evalTarget.fitness;
        genValidCount++;
        allCandidates.push({
          id: evaluations,
          params: trial,
          thermalEfficiencyPct: evalTarget.res.summary.thermalEfficiencyPct,
          netPowerMW: evalTarget.res.summary.netPowerMW,
          operatingCostPerMWh: evalTarget.res.summary.operatingCostPerMWh,
          exergyDestructionMW: evalTarget.res.summary.totalExergyDestructionMW,
          coolingDutyMW: evalTarget.res.summary.coolingDutyMW,
          exhaustQuality: evalTarget.res.summary.turbineExhaustQuality,
          isFeasible: true,
          rank: 1,
          crowdingDistance: 0,
        });

        if (evalTarget.fitness > bestFitness) {
          bestFitness = evalTarget.fitness;
          bestParams = trial;
        }
        pop[i] = trial;
      }
    }

    const meanFit = genValidCount > 0 ? genFitnessSum / genValidCount : bestFitness;
    convergenceHistory.push({
      iteration: gen + 1,
      bestFitness: bestFitness > -1e5 ? bestFitness : baseline.summary.thermalEfficiencyPct,
      meanFitness: meanFit > -1e5 ? meanFit : baseline.summary.thermalEfficiencyPct,
    });
  }

  // Non-Dominated Sorting for Pareto Frontier (Trade-off between Efficiency and Cost / Power)
  const feasibleCandidates = allCandidates.filter(c => c.isFeasible);
  const paretoFrontier = feasibleCandidates
    .sort((a, b) => b.thermalEfficiencyPct - a.thermalEfficiencyPct)
    .slice(0, 50);

  const bestSolution = solveRankineCycle(bestParams, 'OPTIMISED');
  const duration = performance.now() - startTime;

  return {
    method,
    objective,
    evaluationsCount: evaluations,
    executionTimeMs: Math.round(duration),
    baseline,
    bestSolution,
    improvements: {
      efficiencyGainPctPts: +(bestSolution.summary.thermalEfficiencyPct - baseline.summary.thermalEfficiencyPct).toFixed(2),
      powerGainMW: +(bestSolution.summary.netPowerMW - baseline.summary.netPowerMW).toFixed(1),
      heatRateReductionKjKwh: +(baseline.summary.heatRateKjKwh - bestSolution.summary.heatRateKjKwh).toFixed(1),
      costReductionPct: +(
        ((baseline.summary.operatingCostPerMWh - bestSolution.summary.operatingCostPerMWh) / baseline.summary.operatingCostPerMWh) *
        100
      ).toFixed(2),
      exergyDestructionReductionMW: +(baseline.summary.totalExergyDestructionMW - bestSolution.summary.totalExergyDestructionMW).toFixed(1),
    },
    paretoFrontier,
    convergenceHistory,
    variableBounds: bounds,
  };
}
