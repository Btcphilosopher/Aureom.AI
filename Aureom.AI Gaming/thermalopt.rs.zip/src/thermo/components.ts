/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Component Thermodynamics Models & Equipment Specifications
 */

import { ProvenanceSource } from './types';

export type HeatSourceCategory = 
  | 'NATURAL_GAS'
  | 'BIOMASS'
  | 'NUCLEAR'
  | 'SOLAR_THERMAL'
  | 'GEOTHERMAL'
  | 'INDUSTRIAL_WASTE_HEAT'
  | 'COAL';

export interface HeatSourceConfig {
  id: string;
  name: string;
  category: HeatSourceCategory;
  availableHeatThermalMW: number;
  maximumTemperatureC: number;
  inletFlueGasTempC: number;
  flueGasExhaustTempC: number;
  co2EmissionsFactorKgPerMWhTh: number;
  fuelCostPerGJ: number; // in $/GJ or €/GJ
  availabilityFactor: number; // 0.0 - 1.0 (e.g., 0.95)
}

export interface BoilerConfig {
  designPressureMPa: number;
  superheatTemperatureC: number;
  boilerThermalEfficiency: number; // e.g. 0.92
  economiserPressureDropPct: number; // e.g. 2.5%
  evaporatorPressureDropPct: number; // e.g. 2.0%
  superheaterPressureDropPct: number; // e.g. 3.0%
  reheaterPressureDropPct: number; // e.g. 5.0%
  blowdownRatePct: number; // e.g. 1.0%
}

export interface TurbineStageConfig {
  name: string;
  isentropicEfficiency: number; // 0.85 - 0.92
  mechanicalEfficiency: number; // 0.985 - 0.995
  generatorEfficiency: number;  // 0.98 - 0.99
  inletPressureMPa: number;
  inletTemperatureC: number;
  exhaustPressureMPa: number;
  bleedPressureRatios: number[]; // e.g. [0.4, 0.15] for extractions
}

export interface FeedwaterHeaterConfig {
  id: string;
  name: string;
  type: 'OPEN_CONTACT_DEAERATOR' | 'CLOSED_SHELL_TUBE';
  extractionPressureMPa: number;
  terminalTemperatureDifferenceC: number; // TTD (for closed FWH, typically 2.8°C)
  drainCoolingApproachC: number; // DCA (typically 5.6°C)
  efficiency: number;
}

export interface CondenserConfig {
  condenserPressureKPa: number; // typically 3.5 - 10 kPa
  coolingWaterInletTempC: number; // e.g. 18 - 25 °C
  coolingWaterTempRiseC: number; // e.g. 8 - 12 °C
  overallHeatTransferCoefficientUA: number; // MW/K (e.g. 15.0)
  foulingFactor: number; // 1.0 = clean, 0.85 = fouled
  airLeakageRateKgHr: number; // kg/h non-condensables
  coolingWaterPumpHeadMeters: number; // e.g. 12 m
}

export interface PumpConfig {
  isentropicEfficiency: number; // e.g. 0.82
  mechanicalEfficiency: number; // e.g. 0.95
  motorEfficiency: number;      // e.g. 0.96
  targetPressureMPa: number;
}

export interface CycleDesignParameters {
  cycleName: string;
  workingFluid: string;
  heatSource: HeatSourceConfig;
  
  // Throttle (Main Steam)
  boilerPressureMPa: number;      // e.g. 16.5 MPa
  superheatTemperatureC: number;  // e.g. 565 °C
  throttleMassFlowKgs: number;    // e.g. 420 kg/s (for ~500 MW class)
  
  // Reheat Parameters
  hasReheat: boolean;
  reheatPressureMPa: number;      // e.g. 3.8 MPa (~20-25% of boiler P)
  reheatTemperatureC: number;     // e.g. 565 °C
  hasDoubleReheat: boolean;
  secondReheatPressureMPa?: number;
  secondReheatTemperatureC?: number;
  
  // Turbines
  hpTurbineEfficiency: number;    // e.g. 0.89
  ipTurbineEfficiency: number;    // e.g. 0.91
  lpTurbineEfficiency: number;    // e.g. 0.88
  mechanicalEfficiency: number;   // e.g. 0.99
  generatorEfficiency: number;    // e.g. 0.985
  
  // Condenser
  condenserPressureKPa: number;   // e.g. 5.0 kPa
  coolingWaterInletTempC: number; // e.g. 20 °C
  coolingWaterDeltaTC: number;    // e.g. 9 °C
  
  // Feedwater Regeneration
  feedwaterHeaters: FeedwaterHeaterConfig[];
  
  // Pumps & Auxiliaries
  condensatePumpEfficiency: number;
  boilerFeedPumpEfficiency: number;
  auxiliaryLoadPercentage: number; // e.g. 3.5% of gross generation (fans, mills, pumps)
  
  // Boiler Details
  boilerThermalEfficiency: number; // e.g. 0.92
  boilerPressureDropPct: number;   // e.g. 4.0%
}
