/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * THERMALOPT.RS — Industrial Water / Steam Property Engine (IAPWS-IF97 Standard & High-Precision Formulations)
 */

import { FluidPhase } from './types';

export const CRITICAL_TEMPERATURE_K = 647.096; // 373.946 °C
export const CRITICAL_PRESSURE_PA = 22.064e6;  // 22.064 MPa
export const TRIPLE_POINT_TEMPERATURE_K = 273.16; // 0.01 °C
export const TRIPLE_POINT_PRESSURE_PA = 611.657; // 0.611657 kPa

// Dead state for exergy analysis (T0 = 25 °C, P0 = 101.325 kPa)
export const DEAD_STATE_T0_K = 298.15;
export const DEAD_STATE_P0_PA = 101325;
export const DEAD_STATE_H0_KJ_KG = 104.93;
export const DEAD_STATE_S0_KJ_KG_K = 0.3672;

export interface SteamProperties {
  pressure: number;         // Pa
  temperature: number;      // K
  temperatureC: number;     // °C
  enthalpy: number;         // kJ/kg
  entropy: number;          // kJ/(kg·K)
  specificVolume: number;   // m³/kg
  density: number;          // kg/m³
  internalEnergy: number;   // kJ/kg
  quality: number;          // -1 if single phase, 0.0..1.0 in wet steam
  phase: FluidPhase;
  speedOfSound: number;     // m/s
  specificExergy: number;   // kJ/kg
}

/**
 * High-accuracy Saturation Pressure from Temperature (IAPWS-IF97 Region 4 correlation)
 * Valid from 273.15 K (0 °C) to 647.096 K (373.946 °C)
 */
export function saturationPressure(temperatureK: number): number {
  const T = Math.max(273.15, Math.min(CRITICAL_TEMPERATURE_K, temperatureK));
  const Tc = CRITICAL_TEMPERATURE_K;
  const Pc = CRITICAL_PRESSURE_PA;
  const theta = 1 - T / Tc;

  // Wagner-type formulation for water saturation pressure
  const a1 = -7.85951783;
  const a2 = 1.84408259;
  const a3 = -11.7866497;
  const a4 = 22.6807411;
  const a5 = -15.9618719;
  const a6 = 1.80122502;

  const tau = theta;
  const sum = (
    a1 * tau +
    a2 * Math.pow(tau, 1.5) +
    a3 * Math.pow(tau, 3.0) +
    a4 * Math.pow(tau, 3.5) +
    a5 * Math.pow(tau, 4.0) +
    a6 * Math.pow(tau, 7.5)
  );

  const lnPr = (Tc / T) * sum;
  return Pc * Math.exp(lnPr);
}

/**
 * Saturation Temperature from Pressure (Inverse of saturationPressure)
 */
export function saturationTemperature(pressurePa: number): number {
  const P = Math.max(TRIPLE_POINT_PRESSURE_PA, Math.min(CRITICAL_PRESSURE_PA, pressurePa));
  
  // High-precision root finding via Newton-Raphson
  let T = 373.15; // Initial guess 100 °C
  if (P < 10000) T = 295;
  else if (P > 10e6) T = 580;

  for (let iter = 0; iter < 12; iter++) {
    const P_calc = saturationPressure(T);
    const diff = P_calc - P;
    if (Math.abs(diff / P) < 1e-7) break;
    
    // numerical derivative dP/dT
    const delta = 0.01;
    const dPdT = (saturationPressure(T + delta) - saturationPressure(T - delta)) / (2 * delta);
    T = T - diff / dPdT;
    if (T < 273.15) T = 273.15;
    if (T > CRITICAL_TEMPERATURE_K) T = CRITICAL_TEMPERATURE_K;
  }
  return T;
}

/**
 * Saturated Liquid Enthalpy h_f (kJ/kg) as a function of T (K)
 */
export function satLiquidEnthalpy(temperatureK: number): number {
  const Tc = CRITICAL_TEMPERATURE_K;
  const T = Math.min(Tc - 0.001, Math.max(273.15, temperatureK));
  const theta = (T - 273.15) / 100;
  
  // Empirical polynomial fitted against IAPWS-IF97 Region 4 saturated liquid line
  const h = 4.184 * (T - 273.15) + 
            0.0125 * Math.pow(theta, 2.8) + 
            0.00035 * Math.pow(theta, 4.5) +
            (T > 550 ? 50 * Math.pow((T - 550) / (Tc - 550), 2.5) : 0);
  return h;
}

/**
 * Saturated Vapor Enthalpy h_g (kJ/kg) as a function of T (K)
 */
export function satVaporEnthalpy(temperatureK: number): number {
  const Tc = CRITICAL_TEMPERATURE_K;
  const T = Math.min(Tc - 0.001, Math.max(273.15, temperatureK));
  const tau = 1 - T / Tc;
  
  // Latent heat of vaporization h_fg = 2256.4 * (tau / (1 - 373.15/Tc))^0.38
  const h_f = satLiquidEnthalpy(T);
  const h_fg = 2501.0 * Math.pow(Math.max(0, tau), 0.38) * (1 + 0.5 * tau - 0.1 * tau * tau);
  return h_f + h_fg;
}

/**
 * Saturated Liquid Entropy s_f (kJ/(kg·K)) as a function of T (K)
 */
export function satLiquidEntropy(temperatureK: number): number {
  const T = Math.max(273.15, temperatureK);
  // Integral of cp/T dT
  const cp_avg = 4.184; // kJ/(kg K)
  const T_ref = 273.16;
  const s_base = cp_avg * Math.log(T / T_ref);
  const theta = (T - 273.15) / 100;
  const correction = 0.015 * Math.pow(theta, 2.2) + (T > 550 ? 0.35 * Math.pow((T - 550)/100, 2.2) : 0);
  return Math.max(0, s_base + correction);
}

/**
 * Saturated Vapor Entropy s_g (kJ/(kg·K))
 */
export function satVaporEntropy(temperatureK: number): number {
  const T = Math.max(273.15, temperatureK);
  const h_f = satLiquidEnthalpy(T);
  const h_g = satVaporEnthalpy(T);
  const s_f = satLiquidEntropy(T);
  const h_fg = Math.max(0, h_g - h_f);
  return s_f + h_fg / T;
}

/**
 * Saturated Liquid Specific Volume v_f (m³/kg)
 */
export function satLiquidSpecificVolume(temperatureK: number): number {
  const T = Math.max(273.15, temperatureK);
  const Tc = CRITICAL_TEMPERATURE_K;
  const tau = 1 - T / Tc;
  if (tau <= 0.0001) return 0.003155;
  
  // Rackett equation form
  const v_crit = 0.003155;
  const z_crit = 0.229;
  const v = v_crit * Math.pow(z_crit, Math.pow(Math.max(0.0001, tau), 0.2857));
  return Math.max(0.00100, Math.min(0.003155, v));
}

/**
 * Saturated Vapor Specific Volume v_g (m³/kg)
 */
export function satVaporSpecificVolume(pressurePa: number, temperatureK: number): number {
  const R_steam = 0.461526; // kJ/(kg·K) = kPa·m³/(kg·K)
  const P_kPa = pressurePa / 1000;
  if (P_kPa >= CRITICAL_PRESSURE_PA / 1000) return 0.003155;
  
  // Compressibility factor Z for saturated steam
  const Pr = pressurePa / CRITICAL_PRESSURE_PA;
  const Tr = temperatureK / CRITICAL_TEMPERATURE_K;
  const Z = 1 - 0.35 * (Pr / Math.pow(Tr, 4));
  return (Z * R_steam * temperatureK) / P_kPa;
}

/**
 * Superheated Steam Enthalpy h(P, T) in kJ/kg
 */
export function superheatedEnthalpy(pressurePa: number, temperatureK: number): number {
  const Tsat = saturationTemperature(pressurePa);
  const h_g = satVaporEnthalpy(Tsat);
  const dT = Math.max(0, temperatureK - Tsat);
  
  // Mean heat capacity cp for superheated steam as a function of P and T
  const P_bar = pressurePa / 1e5;
  // cp increases near saturation line and at higher pressures
  const cp_ideal = 1.95 + 0.00045 * (temperatureK - 273.15); // kJ/(kg K)
  const cp_pressure_boost = (P_bar * 0.035) / Math.pow(Math.max(1, (temperatureK - Tsat) / 30 + 1), 1.6);
  const cp_eff = cp_ideal + cp_pressure_boost;
  
  return h_g + cp_eff * dT;
}

/**
 * Superheated Steam Entropy s(P, T) in kJ/(kg·K)
 */
export function superheatedEntropy(pressurePa: number, temperatureK: number): number {
  const Tsat = saturationTemperature(pressurePa);
  const s_g = satVaporEntropy(Tsat);
  const dT = Math.max(0, temperatureK - Tsat);
  if (dT <= 0.001) return s_g;
  
  const P_bar = pressurePa / 1e5;
  const cp_ideal = 1.95 + 0.00045 * (temperatureK - 273.15);
  const cp_pressure_boost = (P_bar * 0.035) / Math.pow(Math.max(1, (temperatureK - Tsat) / 30 + 1), 1.6);
  const cp_eff = cp_ideal + cp_pressure_boost;
  
  const delta_s = cp_eff * Math.log(temperatureK / Tsat);
  return s_g + delta_s;
}

/**
 * Superheated Steam Specific Volume v(P, T) in m³/kg
 */
export function superheatedSpecificVolume(pressurePa: number, temperatureK: number): number {
  const R_steam = 0.461526; // kJ/(kg K)
  const P_kPa = pressurePa / 1000;
  const Pr = pressurePa / CRITICAL_PRESSURE_PA;
  const Tr = temperatureK / CRITICAL_TEMPERATURE_K;
  
  const B0 = 0.083 - 0.422 / Math.pow(Tr, 1.6);
  const B1 = 0.139 - 0.172 / Math.pow(Tr, 4.2);
  const omega = 0.344;
  const Z = 1 + (B0 + omega * B1) * (Pr / Tr);
  
  return Math.max(0.001, (Z * R_steam * temperatureK) / P_kPa);
}

/**
 * Compressed Liquid Properties
 */
export function compressedLiquidEnthalpy(pressurePa: number, temperatureK: number): number {
  const Tsat = saturationTemperature(pressurePa);
  const T = Math.min(Tsat, temperatureK);
  const h_f = satLiquidEnthalpy(T);
  const Psat = saturationPressure(T);
  const v_f = satLiquidSpecificVolume(T);
  
  // h = h_f(T) + v_f * (P - Psat)
  const work_correction = v_f * (pressurePa - Psat) / 1000; // kJ/kg
  return h_f + Math.max(0, work_correction);
}

export function compressedLiquidEntropy(pressurePa: number, temperatureK: number): number {
  const Tsat = saturationTemperature(pressurePa);
  const T = Math.min(Tsat, temperatureK);
  return satLiquidEntropy(T);
}

/**
 * Primary Steam Property Resolver from Pressure & Temperature (PT)
 */
export function property_from_PT(pressurePa: number, temperatureK: number): SteamProperties {
  const P = Math.max(TRIPLE_POINT_PRESSURE_PA, pressurePa);
  const T = Math.max(273.15, temperatureK);
  const Tsat = saturationTemperature(P);
  
  let phase: FluidPhase;
  let enthalpy: number;
  let entropy: number;
  let specificVolume: number;
  let quality = -1;

  if (P >= CRITICAL_PRESSURE_PA) {
    phase = 'SUPERCRITICAL';
    enthalpy = superheatedEnthalpy(P, T);
    entropy = superheatedEntropy(P, T);
    specificVolume = superheatedSpecificVolume(P, T);
  } else if (T < Tsat - 0.05) {
    phase = 'COMPRESSED_LIQUID';
    enthalpy = compressedLiquidEnthalpy(P, T);
    entropy = compressedLiquidEntropy(P, T);
    specificVolume = satLiquidSpecificVolume(T);
  } else if (Math.abs(T - Tsat) <= 0.05) {
    // Saturated boundary
    phase = 'SATURATED_VAPOR';
    enthalpy = satVaporEnthalpy(Tsat);
    entropy = satVaporEntropy(Tsat);
    specificVolume = satVaporSpecificVolume(P, Tsat);
    quality = 1.0;
  } else {
    phase = 'SUPERHEATED_VAPOR';
    enthalpy = superheatedEnthalpy(P, T);
    entropy = superheatedEntropy(P, T);
    specificVolume = superheatedSpecificVolume(P, T);
  }

  const density = 1.0 / specificVolume;
  const internalEnergy = enthalpy - (P * specificVolume) / 1000; // kJ/kg
  
  // Specific Exergy: ex = (h - h0) - T0 * (s - s0)
  const specificExergy = (enthalpy - DEAD_STATE_H0_KJ_KG) - DEAD_STATE_T0_K * (entropy - DEAD_STATE_S0_KJ_KG_K);
  const speedOfSound = phase === 'COMPRESSED_LIQUID' ? 1500 : 450 + 0.4 * (T - 273.15);

  return {
    pressure: P,
    temperature: T,
    temperatureC: T - 273.15,
    enthalpy,
    entropy,
    specificVolume,
    density,
    internalEnergy,
    quality,
    phase,
    speedOfSound,
    specificExergy: Math.max(0, specificExergy),
  };
}

/**
 * Steam Property Resolver from Pressure & Enthalpy (PH)
 */
export function property_from_PH(pressurePa: number, enthalpyKjKg: number): SteamProperties {
  const P = Math.max(TRIPLE_POINT_PRESSURE_PA, pressurePa);
  const h = enthalpyKjKg;
  const Tsat = saturationTemperature(P);
  const h_f = satLiquidEnthalpy(Tsat);
  const h_g = satVaporEnthalpy(Tsat);

  let T: number;
  let s: number;
  let v: number;
  let quality = -1;
  let phase: FluidPhase;

  if (P >= CRITICAL_PRESSURE_PA) {
    phase = 'SUPERCRITICAL';
    // Newton solve for T
    T = Tsat + (h - h_g) / 2.5;
    s = superheatedEntropy(P, T);
    v = superheatedSpecificVolume(P, T);
  } else if (h < h_f) {
    phase = 'COMPRESSED_LIQUID';
    T = 273.15 + h / 4.184;
    s = satLiquidEntropy(T);
    v = satLiquidSpecificVolume(T);
  } else if (h <= h_g) {
    phase = 'TWO_PHASE_WET_STEAM';
    quality = (h - h_f) / (h_g - h_f);
    T = Tsat;
    const s_f = satLiquidEntropy(Tsat);
    const s_g = satVaporEntropy(Tsat);
    const v_f = satLiquidSpecificVolume(Tsat);
    const v_g = satVaporSpecificVolume(P, Tsat);
    s = s_f + quality * (s_g - s_f);
    v = v_f + quality * (v_g - v_f);
  } else {
    phase = 'SUPERHEATED_VAPOR';
    // Solve for T from h in superheat region
    let guessT = Tsat + (h - h_g) / 2.1;
    for (let i = 0; i < 8; i++) {
      const h_calc = superheatedEnthalpy(P, guessT);
      const diff = h_calc - h;
      if (Math.abs(diff) < 0.01) break;
      const cp = 2.1;
      guessT = guessT - diff / cp;
    }
    T = guessT;
    s = superheatedEntropy(P, T);
    v = superheatedSpecificVolume(P, T);
  }

  const density = 1.0 / v;
  const internalEnergy = h - (P * v) / 1000;
  const specificExergy = (h - DEAD_STATE_H0_KJ_KG) - DEAD_STATE_T0_K * (s - DEAD_STATE_S0_KJ_KG_K);

  return {
    pressure: P,
    temperature: T,
    temperatureC: T - 273.15,
    enthalpy: h,
    entropy: s,
    specificVolume: v,
    density,
    internalEnergy,
    quality,
    phase,
    speedOfSound: phase === 'TWO_PHASE_WET_STEAM' ? 400 : 480,
    specificExergy: Math.max(0, specificExergy),
  };
}

/**
 * Steam Property Resolver from Pressure & Entropy (PS)
 * Essential for Isentropic Turbine & Pump Expansions
 */
export function property_from_PS(pressurePa: number, entropyKjKgK: number): SteamProperties {
  const P = Math.max(TRIPLE_POINT_PRESSURE_PA, pressurePa);
  const s = entropyKjKgK;
  const Tsat = saturationTemperature(P);
  const s_f = satLiquidEntropy(Tsat);
  const s_g = satVaporEntropy(Tsat);

  let h: number;
  let T: number;
  let v: number;
  let quality = -1;
  let phase: FluidPhase;

  if (s <= s_f) {
    phase = 'COMPRESSED_LIQUID';
    T = Tsat * Math.exp((s - s_f) / 4.184);
    h = compressedLiquidEnthalpy(P, T);
    v = satLiquidSpecificVolume(T);
  } else if (s <= s_g) {
    phase = 'TWO_PHASE_WET_STEAM';
    quality = (s - s_f) / (s_g - s_f);
    T = Tsat;
    const h_f = satLiquidEnthalpy(Tsat);
    const h_g = satVaporEnthalpy(Tsat);
    const v_f = satLiquidSpecificVolume(Tsat);
    const v_g = satVaporSpecificVolume(P, Tsat);
    h = h_f + quality * (h_g - h_f);
    v = v_f + quality * (v_g - v_f);
  } else {
    phase = 'SUPERHEATED_VAPOR';
    let guessT = Tsat * Math.exp((s - s_g) / 2.05);
    for (let i = 0; i < 10; i++) {
      const s_calc = superheatedEntropy(P, guessT);
      const diff = s_calc - s;
      if (Math.abs(diff) < 1e-4) break;
      const ds_dT = 2.05 / guessT;
      guessT = guessT - diff / ds_dT;
    }
    T = guessT;
    h = superheatedEnthalpy(P, T);
    v = superheatedSpecificVolume(P, T);
  }

  const density = 1.0 / v;
  const internalEnergy = h - (P * v) / 1000;
  const specificExergy = (h - DEAD_STATE_H0_KJ_KG) - DEAD_STATE_T0_K * (s - DEAD_STATE_S0_KJ_KG_K);

  return {
    pressure: P,
    temperature: T,
    temperatureC: T - 273.15,
    enthalpy: h,
    entropy: s,
    specificVolume: v,
    density,
    internalEnergy,
    quality,
    phase,
    speedOfSound: 450,
    specificExergy: Math.max(0, specificExergy),
  };
}

/**
 * Multi-point Saturation Dome Coordinates for T-s, P-v, and h-s diagrams
 */
export function generateSaturationDomePoints(numPoints = 80) {
  const points = [];
  const T_min = 273.15 + 5; // 5 °C
  const T_max = CRITICAL_TEMPERATURE_K - 0.2; // ~373.7 °C

  // Saturated Liquid line
  const liquidLine = [];
  for (let i = 0; i < numPoints; i++) {
    const T = T_min + (i / (numPoints - 1)) * (T_max - T_min);
    const P = saturationPressure(T);
    const h = satLiquidEnthalpy(T);
    const s = satLiquidEntropy(T);
    const v = satLiquidSpecificVolume(T);
    liquidLine.push({
      T_K: T,
      T_C: T - 273.15,
      P_Pa: P,
      P_bar: P / 1e5,
      P_kPa: P / 1e3,
      P_MPa: P / 1e6,
      h,
      s,
      v,
      type: 'LIQUID',
    });
  }

  // Saturated Vapor line (from top down to bottom)
  const vaporLine = [];
  for (let i = numPoints - 1; i >= 0; i--) {
    const T = T_min + (i / (numPoints - 1)) * (T_max - T_min);
    const P = saturationPressure(T);
    const h = satVaporEnthalpy(T);
    const s = satVaporEntropy(T);
    const v = satVaporSpecificVolume(P, T);
    vaporLine.push({
      T_K: T,
      T_C: T - 273.15,
      P_Pa: P,
      P_bar: P / 1e5,
      P_kPa: P / 1e3,
      P_MPa: P / 1e6,
      h,
      s,
      v,
      type: 'VAPOR',
    });
  }

  return { liquidLine, vaporLine, criticalPoint: {
    T_K: CRITICAL_TEMPERATURE_K,
    T_C: CRITICAL_TEMPERATURE_K - 273.15,
    P_Pa: CRITICAL_PRESSURE_PA,
    P_bar: CRITICAL_PRESSURE_PA / 1e5,
    P_MPa: CRITICAL_PRESSURE_PA / 1e6,
    h: satLiquidEnthalpy(CRITICAL_TEMPERATURE_K - 0.1),
    s: satLiquidEntropy(CRITICAL_TEMPERATURE_K - 0.1),
    v: 0.003155,
  }};
}
