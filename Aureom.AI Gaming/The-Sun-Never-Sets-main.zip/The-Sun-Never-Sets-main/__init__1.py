"""brass_and_crown.ai — AI subsystems for The Sun Never Sets."""
