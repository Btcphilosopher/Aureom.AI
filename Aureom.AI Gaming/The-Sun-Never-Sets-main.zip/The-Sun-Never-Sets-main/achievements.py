"""
achievements.py — Achievement, Milestone and Title System.

Achievements are checked each turn against a predicate function.
When first triggered they fire the EventBus "achievement_unlocked" event
and grant a title, bonus, or simply record the milestone.

Categories:
  SOCIAL     — influence, reputation, relationships
  ECONOMIC   — gold, investments, factories
  INTRIGUE   — secrets, duels, espionage
  EXPLORATION — districts visited
  RESEARCH   — completed research nodes
  STORY      — quest completions
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, TYPE_CHECKING

from brass_and_crown.utils import EventBus, log

if TYPE_CHECKING:
    from brass_and_crown.core import GameState


# ── Achievement ───────────────────────────────────────────────────────────────

@dataclass
class Achievement:
    ach_id: str
    name: str
    description: str
    category: str
    hidden: bool = False        # hidden achievements don't appear until unlocked
    title_granted: Optional[str] = None
    reward_influence: float = 0.0
    reward_gold: int = 0
    unlocked: bool = False
    _unlock_turn: int = -1

    def to_dict(self) -> dict:
        return {"ach_id": self.ach_id, "unlocked": self.unlocked,
                "_unlock_turn": self._unlock_turn}

    @classmethod
    def from_partial(cls, ach: "Achievement", d: dict) -> None:
        ach.unlocked = d.get("unlocked", False)
        ach._unlock_turn = d.get("_unlock_turn", -1)


# ── Predicate helpers ─────────────────────────────────────────────────────────

def _p(fn: Callable) -> Callable:
    """Wrap a lambda so it only receives the GameState."""
    return fn


# ── Achievement catalogue ─────────────────────────────────────────────────────

def build_achievements() -> list[Achievement]:
    return [
        # ── Social ────────────────────────────────────────────────────────────
        Achievement(
            "soc_first_gala", "A Season Begins",
            "Attend your first society event.",
            category="SOCIAL",
            title_granted="Socialite",
            reward_influence=5.0,
        ),
        Achievement(
            "soc_influence_50", "A Name Worth Knowing",
            "Reach 50 influence.",
            category="SOCIAL",
            title_granted="Person of Consequence",
            reward_influence=5.0,
        ),
        Achievement(
            "soc_influence_80", "The Talk of the Town",
            "Reach 80 influence.",
            category="SOCIAL",
            title_granted="The Illustrious",
            reward_influence=10.0,
        ),
        Achievement(
            "soc_reputation_75", "Beyond Reproach",
            "Reach 75 reputation.",
            category="SOCIAL",
            reward_influence=8.0,
        ),
        Achievement(
            "soc_five_allies", "A Man of Connections",
            "Have five NPCs with relationship > 40.",
            category="SOCIAL",
            title_granted="Pillar of Society",
            reward_influence=10.0,
        ),

        # ── Economic ──────────────────────────────────────────────────────────
        Achievement(
            "eco_gold_10k", "A Comfortable Position",
            "Accumulate 10,000 shillings.",
            category="ECONOMIC",
            reward_gold=500,
        ),
        Achievement(
            "eco_gold_50k", "Robber Baron",
            "Accumulate 50,000 shillings.",
            category="ECONOMIC",
            title_granted="The Magnate",
            reward_gold=2_000,
        ),
        Achievement(
            "eco_factory_owner", "Means of Production",
            "Own your first factory.",
            category="ECONOMIC",
            reward_gold=500,
        ),
        Achievement(
            "eco_three_investments", "Diversified Portfolio",
            "Hold three investments simultaneously.",
            category="ECONOMIC",
            reward_gold=1_000,
        ),

        # ── Intrigue ──────────────────────────────────────────────────────────
        Achievement(
            "int_first_secret", "A Whisper in the Dark",
            "Learn your first NPC secret.",
            category="INTRIGUE",
            reward_influence=5.0,
        ),
        Achievement(
            "int_all_secrets", "Keeper of Secrets",
            "Learn at least one secret about every NPC.",
            category="INTRIGUE",
            title_granted="The Archivist",
            reward_influence=15.0,
        ),
        Achievement(
            "int_win_duel", "Satisfaction",
            "Win your first duel.",
            category="INTRIGUE",
            title_granted="Duelist",
            reward_influence=8.0,
        ),
        Achievement(
            "int_win_three_duels", "Undefeated",
            "Win three duels without losing one.",
            category="INTRIGUE",
            title_granted="Champion of Honour",
            reward_influence=15.0,
            hidden=True,
        ),
        Achievement(
            "int_shadow_network", "In the Shadows",
            "Join the Shadow Network.",
            category="INTRIGUE",
            hidden=True,
            reward_influence=10.0,
        ),
        Achievement(
            "int_blackmail", "The Art of Leverage",
            "Successfully blackmail an NPC.",
            category="INTRIGUE",
            hidden=True,
            reward_influence=5.0,
        ),

        # ── Exploration ───────────────────────────────────────────────────────
        Achievement(
            "exp_five_districts", "The City is My Estate",
            "Visit five distinct districts.",
            category="EXPLORATION",
            reward_influence=5.0,
        ),
        Achievement(
            "exp_all_districts", "Master of London",
            "Visit every district in London.",
            category="EXPLORATION",
            title_granted="Explorer Extraordinaire",
            reward_influence=10.0,
        ),
        Achievement(
            "exp_limehouse", "Into the Abyss",
            "Survive a visit to Limehouse.",
            category="EXPLORATION",
            hidden=True,
            reward_influence=5.0,
        ),

        # ── Research ──────────────────────────────────────────────────────────
        Achievement(
            "res_first_complete", "Student of the Age",
            "Complete your first research.",
            category="RESEARCH",
            reward_influence=5.0,
        ),
        Achievement(
            "res_discipline_complete", "Doctor of Philosophy",
            "Complete an entire research discipline.",
            category="RESEARCH",
            title_granted="Doctor",
            reward_influence=10.0,
        ),
        Achievement(
            "res_all_complete", "Polymath",
            "Complete every research node.",
            category="RESEARCH",
            title_granted="Savant of the Empire",
            reward_influence=20.0,
            hidden=True,
        ),

        # ── Story ─────────────────────────────────────────────────────────────
        Achievement(
            "sto_first_quest", "A Purpose Emerges",
            "Complete your first quest.",
            category="STORY",
            reward_influence=5.0,
        ),
        Achievement(
            "sto_railway_scandal", "The Truth Will Out",
            "Expose Lord Ashworth's railway embezzlement.",
            category="STORY",
            title_granted="Enemy of Corruption",
            reward_influence=15.0,
        ),
        Achievement(
            "sto_all_quests", "The Grand Intriguer",
            "Complete all available quests.",
            category="STORY",
            title_granted="The Sun Never Sets",
            reward_influence=25.0,
            hidden=True,
        ),

        # ── Secret / funny ────────────────────────────────────────────────────
        Achievement(
            "sec_turns_100", "A Century of Scheming",
            "Survive 100 turns.",
            category="SOCIAL",
            hidden=True,
            reward_gold=1_000,
        ),
        Achievement(
            "sec_bankrupt", "Reduced Circumstances",
            "Have your gold fall below 100 shillings.",
            category="ECONOMIC",
            hidden=True,
        ),
        Achievement(
            "sec_reputation_10", "Quite the Reputation",
            "Let your reputation fall below 10.",
            category="SOCIAL",
            hidden=True,
            title_granted="The Notorious",
        ),
    ]


# ── Predicate map ─────────────────────────────────────────────────────────────

def _build_predicates() -> dict[str, Callable]:
    """
    Returns {ach_id: predicate(game) → bool} mapping.
    Predicates must be side-effect-free; effects are applied by the manager.
    """
    return {
        # Social
        "soc_first_gala":       lambda g: "gala_attended" in g.world.flags,
        "soc_influence_50":     lambda g: g.player.influence >= 50,
        "soc_influence_80":     lambda g: g.player.influence >= 80,
        "soc_reputation_75":    lambda g: g.player.reputation >= 75,
        "soc_five_allies": lambda g: sum(
            1 for v in g.player.relationships.values() if v >= 40) >= 5,
        # Economic
        "eco_gold_10k":         lambda g: g.player.gold >= 10_000,
        "eco_gold_50k":         lambda g: g.player.gold >= 50_000,
        "eco_factory_owner": lambda g: any(
            f.owner_id == "player" for f in g.market.factories),
        "eco_three_investments": lambda g: len(
            [i for i in g.estate.investments if i.active]) >= 3,
        # Intrigue
        "int_first_secret":     lambda g: len(g.player.known_secrets) >= 1,
        "int_all_secrets": lambda g: len(
            {nid for nid, _ in g.player.known_secrets}) >= 5,
        "int_win_duel": lambda g: "won_duel" in g.world.flags,
        "int_win_three_duels": lambda g: g.world.flags.get("duel_wins", 0) >= 3,
        "int_shadow_network": lambda g: "shadow_network_member" in g.world.flags,
        "int_blackmail": lambda g: "blackmailed_npc" in g.world.flags,
        # Exploration
        "exp_five_districts": lambda g: len(
            [k for k in g.world.flags if k.startswith("visited_")]) >= 5,
        "exp_all_districts": lambda g: len(
            [k for k in g.world.flags if k.startswith("visited_")]) >= 7,
        "exp_limehouse": lambda g: g.world.flags.get("visited_limehouse", False),
        # Research
        "res_first_complete": lambda g: len(g.research.completed_nodes()) >= 1,
        "res_discipline_complete": lambda g: any(
            sum(1 for n in g.research.completed_nodes() if n.discipline == d) >= 3
            for d in ("natural_philosophy", "social", "intelligence", "medicine")),
        "res_all_complete": lambda g: len(g.research.completed_nodes()) == len(g.research.tree),
        # Story
        "sto_first_quest": lambda g: len(g.player.completed_quests) >= 1,
        "sto_railway_scandal": lambda g: "q_railway_scandal" in g.player.completed_quests,
        "sto_all_quests": lambda g: len(g.player.completed_quests) >= 7,
        # Secret
        "sec_turns_100":    lambda g: g.turn >= 100,
        "sec_bankrupt":     lambda g: g.player.gold < 100,
        "sec_reputation_10": lambda g: g.player.reputation < 10,
    }


# ── Achievement manager ───────────────────────────────────────────────────────

class AchievementManager:
    """Checks predicates each turn and awards unlocked achievements."""

    def __init__(self) -> None:
        self.achievements: list[Achievement] = build_achievements()
        self._predicates: dict[str, Callable] = _build_predicates()
        self._duel_win_streak: int = 0

    def tick(self, game: "GameState") -> list[str]:
        """Check all locked achievements. Returns notification strings."""
        messages = []
        for ach in self.achievements:
            if ach.unlocked:
                continue
            pred = self._predicates.get(ach.ach_id)
            if pred and pred(game):
                ach.unlocked = True
                ach._unlock_turn = game.turn
                msgs = self._grant(ach, game)
                messages.extend(msgs)
        return messages

    def _grant(self, ach: Achievement, game: "GameState") -> list[str]:
        messages = [f"🏆 Achievement: '{ach.name}' — {ach.description}"]
        if ach.title_granted:
            game.player.log_event(f"New title: {ach.title_granted}")
            messages.append(f"  Title granted: {ach.title_granted}")
        if ach.reward_influence:
            game.player.gain_influence(ach.reward_influence, f"achievement: {ach.name}")
            messages.append(f"  +{ach.reward_influence:.0f} influence")
        if ach.reward_gold:
            game.player.earn_gold(ach.reward_gold, f"achievement: {ach.name}")
            messages.append(f"  +{ach.reward_gold} shillings")
        EventBus.emit("achievement_unlocked", {"achievement": ach})
        log.info("Achievement unlocked: %s", ach.ach_id)
        return messages

    def record_duel_win(self, game: "GameState") -> None:
        """Call externally when a duel is won to track win streak."""
        game.world.flags["won_duel"] = True
        game.world.flags["duel_wins"] = game.world.flags.get("duel_wins", 0) + 1
        self._duel_win_streak += 1

    def record_duel_loss(self) -> None:
        self._duel_win_streak = 0

    def unlocked(self) -> list[Achievement]:
        return [a for a in self.achievements if a.unlocked]

    def by_category(self) -> dict[str, list[Achievement]]:
        result: dict[str, list[Achievement]] = {}
        for a in self.achievements:
            result.setdefault(a.category, []).append(a)
        return result

    def all_titles(self, game: "GameState") -> list[str]:
        """Aggregate titles from achievements and factions."""
        titles = [a.title_granted for a in self.unlocked() if a.title_granted]
        titles.extend(game.factions.player_titles())
        return titles

    def to_dict(self) -> dict:
        return {
            "achievements": [a.to_dict() for a in self.achievements],
        }

    def from_dict(self, d: dict) -> None:
        ach_map = {a["ach_id"]: a for a in d.get("achievements", [])}
        for ach in self.achievements:
            if ach.ach_id in ach_map:
                Achievement.from_partial(ach, ach_map[ach.ach_id])
