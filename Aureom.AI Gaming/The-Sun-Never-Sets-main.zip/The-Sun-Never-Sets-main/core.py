"""
core.py — Central game state, turn loop, and persistence (SQLite).

The GameState object owns all subsystems and coordinates them each turn.
Persistence uses SQLite via json-serialised blobs; this keeps the save format
simple while allowing future migration to a full relational schema.
"""
from __future__ import annotations

import json
import sqlite3
import os
from pathlib import Path
from typing import Optional

from brass_and_crown.utils import VictorianDate, EventBus, log
from brass_and_crown.player import Player
from brass_and_crown.estate import Estate
from brass_and_crown.world import World
from brass_and_crown.quests import QuestManager
from brass_and_crown.ai.characters import NPC, create_seed_npcs
from brass_and_crown.ai.social_ai import SocialAI
from brass_and_crown.ai.economy_ai import Market
from brass_and_crown.newspaper import GazettePress
from brass_and_crown.factions import FactionManager
from brass_and_crown.duels import (
    Duel, DuelType, Tactic, build_player_combatant,
    build_npc_combatant, challenge_stakes
)
from brass_and_crown.dialogue import start_conversation, Conversation
from brass_and_crown.research import ResearchManager
from brass_and_crown.achievements import AchievementManager
from brass_and_crown.conditions import ConditionsManager

DB_PATH = Path.home() / ".the_sun_never_sets" / "save.db"


class GameState:
    """
    Master game state.  All subsystems are accessed through this object.

    Turn sequence each call to advance_turn():
      1. Estate tick          (income, repairs, events)
      2. Player tick          (apply income, crafting)
      3. Economy AI step      (market prices, factory production)
      4. Social AI run_turn   (NPC actions, gossip)
      5. Quest manager tick   (check completions, timeouts)
      6. Random event roll    (pickpockets, newspaper mentions, etc.)
      7. Advance date
      8. Emit "turn_complete" event (GUI subscribes to refresh)
    """

    def __init__(self) -> None:
        self.date: VictorianDate = VictorianDate()
        self.player: Player = Player()
        self.estate: Estate = Estate()
        self.world: World = World()
        self.market: Market = Market()
        self.quest_manager: QuestManager = QuestManager()

        # NPC registry
        self.npcs: list[NPC] = create_seed_npcs()
        self.npc_map: dict[str, NPC] = {n.npc_id: n for n in self.npcs}

        self.social_ai: SocialAI = SocialAI(self.npcs)

        self.gazette: GazettePress = GazettePress()
        self.factions: FactionManager = FactionManager()
        self.research: ResearchManager = ResearchManager()
        self.achievements: AchievementManager = AchievementManager()
        self.conditions: ConditionsManager = ConditionsManager()
        self._active_duel: Optional[Duel] = None
        self._active_conversation: Optional[Conversation] = None
        self._gala_count_this_week: int = 0

        self.turn: int = 0
        self.notifications: list[str] = []   # pending messages for GUI

        self._ensure_db()

    # ── Turn advancement ──────────────────────────────────────────────────────

    def advance_turn(self) -> list[str]:
        """
        Advance the game by one turn.
        Returns a list of narrative messages produced this turn.
        """
        self.turn += 1
        messages: list[str] = []

        # 1. Estate
        estate_income = self.estate.calculate_income()
        estate_msgs = self.estate.tick()
        messages.extend(estate_msgs)

        # 2. Player (income, crafting)
        self.player.tick(estate_income)
        messages.append(
            f"📋 Estate income: {estate_income['net']:+d} shillings "
            f"(land {estate_income['land']}, rooms {estate_income['rooms']}, "
            f"investments {estate_income['investments']}, wages {estate_income['wages']})"
        )

        # 3. Economy
        self.market.step()
        factory_results = self.market.produce_all()
        player_factories = [r for r in factory_results
                            if self.market.get_factory(
                                next((f.factory_id for f in self.market.factories
                                      if f.name == r["factory"]), "")
                            ) and
                            self.market.get_factory(
                                next((f.factory_id for f in self.market.factories
                                      if f.name == r["factory"]), "")
                            ).owner_id == "player"]
        for r in player_factories:
            if r["profit"] > 0:
                self.player.earn_gold(int(r["profit"]),
                                      f"factory dividends: {r['factory']}")
            if r["accident"]:
                messages.append(f"⚠ ACCIDENT at {r['factory']}! Output reduced.")

        # 4. Social AI
        social_msgs = self.social_ai.run_turn(self.turn, self.player.influence)
        messages.extend(social_msgs)

        # 5. Quest manager
        quest_msgs = self.quest_manager.tick(self.player, self.world.flags)
        messages.extend(quest_msgs)

        # 5b. Faction tick
        faction_msgs = self.factions.tick(self.turn)
        messages.extend(faction_msgs)
        # Apply faction income bonus
        faction_bonus = self.factions.total_income_bonus()
        if faction_bonus:
            self.player.earn_gold(faction_bonus, "faction standing bonus")

        # 5c. Weekly Gazette (every 7 turns)
        if self.turn % 7 == 0:
            issue = self.gazette.publish(self)
            messages.append("\n📰 THE VICTORIAN GAZETTE has been published!")
            self._gala_count_this_week = 0  # reset gala counter
            EventBus.emit("gazette_published", issue)

        # 6. Research tick
        research_msgs = self.research.tick(self.player)
        messages.extend(research_msgs)

        # 7. Conditions tick
        context = {
            "visited_danger": self.world.current_district.danger_level,
            "gala_count": self._gala_count_this_week,
            "aether_exposure": any(
                g.gadget_id.startswith("bp_aether") or g.gadget_id.startswith("bp_persuasion")
                for g in self.player.inventory.gadgets if g.equipped
            ),
        }
        cond_trigger_msgs = self.conditions.check_triggers(self.player, context)
        messages.extend(cond_trigger_msgs)
        cond_tick_msgs = self.conditions.tick(self.player)
        messages.extend(cond_tick_msgs)

        # 8. Achievements check
        ach_msgs = self.achievements.tick(self)
        messages.extend(ach_msgs)

        # 9. Random event
        rand_event = self.quest_manager.roll_random_event()
        if rand_event:
            messages.append(f"\n🎲 Event: {rand_event['title']}\n{rand_event['description']}")
            self.notifications.append(rand_event["id"])  # GUI can prompt choices

        # 10. Date
        self.date.advance()

        # 11. Influence decay (aristocratic life requires constant maintenance)
        self.player.influence = max(0, self.player.influence - 0.3)
        self.player.influence += self.estate.calculate_influence_bonus() * 0.1

        # Emit turn complete
        EventBus.emit("turn_complete", {"turn": self.turn, "messages": messages})
        log.info("Turn %d complete — %s", self.turn, self.date)

        return messages

    # ── Actions (called by GUI) ───────────────────────────────────────────────

    def attend_social_event(self, event_id: str) -> dict:
        from brass_and_crown.ai.social_ai import SOCIAL_EVENTS
        event = next((e for e in SOCIAL_EVENTS if e.event_id == event_id), None)
        if not event:
            return {"error": "Event not found"}
        if self.player.influence < event.required_influence:
            return {"error": f"Requires {event.required_influence:.0f} influence."}
        if not self.player.spend_gold(event.gold_cost):
            return {"error": "Insufficient gold for attendance."}

        npcs_present = self.world.get_district_npcs(self.npc_map)
        result = self.social_ai.attend_event(event, self.player, npcs_present)

        self.player.gain_influence(result["influence_delta"], f"attended {event.name}")
        # Track gala attendance for achievements and conditions
        if "gala" in event_id or "ball" in event_id or "dinner" in event_id:
            self._gala_count_this_week += 1
            self.world.flags["gala_attended"] = True
        if "secret_learned" in result:
            npc_id, secret = result["secret_learned"]
            self.player.learn_secret(npc_id, secret)
        if "ally_gained" in result:
            npc = self.npc_map.get(result["ally_gained"])
            if npc:
                self.player.adjust_relationship(npc.npc_id, 15)

        return result

    def travel_to(self, district_id: str) -> tuple[bool, str]:
        has_fast = "fast_travel" in self.estate.unlocked_features()
        ok, msg, cost = self.world.travel_to(district_id, self.player.gold, has_fast)
        if ok and cost > 0:
            self.player.spend_gold(cost)
        return ok, msg

    def accept_quest(self, quest_id: str) -> Optional[str]:
        return self.quest_manager.accept_quest(quest_id, self.player)

    def invest_in_factory(self, factory_id: str) -> tuple[bool, str]:
        ok, msg = self.market.invest_in_factory(factory_id, "player", self.player.gold)
        if ok:
            factory = self.market.get_factory(factory_id)
            if factory:
                self.player.spend_gold(factory.upgrade_level * 5_000)
        return ok, msg

    def buy_investment(self, investment_id: str) -> tuple[bool, str]:
        ok, msg, cost = self.estate.buy_investment(investment_id, self.player.gold)
        if ok:
            self.player.spend_gold(cost)
        return ok, msg

    def start_crafting(self, blueprint_id: str) -> tuple[bool, str]:
        return self.player.inventory.start_crafting(blueprint_id)

    def explore_district(self) -> Optional[str]:
        discovery = self.world.explore_current()
        if discovery:
            self.player.log_event(f"Exploration: {discovery}")
            # Check if it's a secret-related discovery
            for npc_id in self.npc_map:
                if npc_id.replace("_", " ") in discovery.lower():
                    self.world.flags[f"visited_{self.world.current_district_id}"] = True
        return discovery

    def interact_with_npc(self, npc_id: str) -> str:
        npc = self.npc_map.get(npc_id)
        if not npc:
            return "That person is not here."
        # Ensure the NPC is actually in this district
        district = self.world.current_district
        if npc_id not in district.npc_ids:
            return f"{npc.title} {npc.name} is not in {district.name}."
        greeting = npc.generate_greeting(self.player.name)
        # Small relationship boost from interaction
        npc.adjust_relationship("player", 1)
        self.player.adjust_relationship(npc_id, 1)
        return greeting

    def apply_random_event_choice(self, event_id: str, choice_index: int) -> str:
        from brass_and_crown.quests import RANDOM_EVENTS
        event = next((e for e in RANDOM_EVENTS if e["id"] == event_id), None)
        if not event:
            return "Event not found."
        if event_id in self.notifications:
            self.notifications.remove(event_id)
        return self.quest_manager.apply_event_choice(event, choice_index, self.player)

    # ── Duel actions ──────────────────────────────────────────────────────────

    def challenge_npc_to_duel(self, npc_id: str,
                               duel_type: DuelType) -> tuple[bool, str]:
        """Initiate a duel against an NPC.  Returns (ok, message)."""
        npc = self.npc_map.get(npc_id)
        if not npc:
            return False, "That person cannot be found."
        # Must be in same district
        if npc_id not in self.world.current_district.npc_ids:
            return False, f"{npc.title} {npc.name} is not here."

        player_comb = build_player_combatant(self.player, duel_type)
        npc_comb    = build_npc_combatant(npc, duel_type)
        stakes      = challenge_stakes(npc, duel_type)
        self._active_duel = Duel(duel_type, player_comb, npc_comb, stakes)

        msg = (f"{npc.title} {npc.name} accepts your challenge! "
               f"A {duel_type.value} begins.\n"
               f"Stakes: {', '.join(f'{k}={v}' for k, v in stakes.items())}")
        self.player.log_event(msg)
        EventBus.emit("duel_started", {"npc": npc, "duel_type": duel_type.value})
        return True, msg

    def play_duel_round(self, tactic: Tactic) -> tuple[dict, bool]:
        """
        Resolve one round of the active duel.
        Returns (round_result_dict, duel_is_over).
        """
        if not self._active_duel:
            return {}, True
        result = self._active_duel.resolve_round(tactic)
        over = self._active_duel.is_over()
        if over:
            outcome = self._active_duel.outcome()
            self._apply_duel_outcome(outcome)
            self._active_duel = None
            return {"round": result, "outcome": outcome}, True
        return {"round": result}, False

    def _apply_duel_outcome(self, outcome: dict) -> None:
        if outcome.get("gold_delta"):
            delta = outcome["gold_delta"]
            if delta > 0:
                self.player.earn_gold(delta, "duel winnings")
            else:
                self.player.spend_gold(abs(delta))
                self.player.log_event(f"Duel loss: paid {abs(delta)} shillings.")
        if outcome.get("influence_delta"):
            self.player.gain_influence(outcome["influence_delta"], "duel outcome")
        if outcome.get("reputation_delta"):
            self.player.adjust_reputation(outcome["reputation_delta"])
        if outcome.get("secret"):
            npc_id, secret = outcome["secret"]
            self.player.learn_secret(npc_id, secret)
        # Track wins/losses for achievements
        if outcome.get("victory"):
            self.achievements.record_duel_win(self)
            # Apply duelling wound sometimes even in victory
            if roll(0.2):
                msg = self.conditions.apply("duelling_wound", self.player)
                if msg:
                    self.player.log_event(msg)
        else:
            self.achievements.record_duel_loss()
            msg = self.conditions.apply("duelling_wound", self.player)
            if msg:
                self.player.log_event(msg)

    @property
    def active_duel(self) -> Optional[Duel]:
        return self._active_duel

    # ── Faction actions ───────────────────────────────────────────────────────

    def perform_faction_action(self, faction_id: str,
                               action: str) -> tuple[bool, str]:
        """
        Player performs an action to improve standing with a faction.
        action: "donate" | "attend" | "spy_for"
        """
        faction = self.factions.get(faction_id)
        if not faction:
            return False, "Unknown faction."

        cost_gold   = 0
        delta       = 0.0
        narrative   = ""

        if action == "donate":
            cost_gold = 300
            delta     = 8.0
            narrative = f"You make a generous donation to {faction.name}."
        elif action == "attend":
            cost_gold = 100
            delta     = 5.0
            narrative = f"You attend a {faction.name} gathering."
        elif action == "spy_for":
            # Spy for the Shadow Network — risky
            from brass_and_crown.utils import roll
            cost_gold = 0
            if roll(0.6):
                delta     = 12.0
                narrative = "Your intelligence proves invaluable to the Network."
            else:
                delta     = -5.0
                self.player.adjust_reputation(-10)
                narrative = "Your cover is nearly blown. Reputation suffers."
        else:
            return False, "Unknown action."

        if cost_gold and not self.player.spend_gold(cost_gold):
            return False, f"Insufficient gold ({cost_gold} shillings required)."

        msgs = self.factions.adjust(faction_id, delta, narrative)
        self.player.log_event("\n".join(msgs))
        return True, narrative

    # ── Dialogue actions ──────────────────────────────────────────────────────

    def start_dialogue(self, npc_id: str) -> tuple[bool, str]:
        """
        Start a branching dialogue with an NPC.
        Returns (success, first NPC speech or error message).
        """
        npc = self.npc_map.get(npc_id)
        if not npc:
            return False, "Person not found."
        if npc_id not in self.world.current_district.npc_ids:
            return False, f"{npc.title} {npc.name} is not here."
        conv = start_conversation(npc, self.player)
        if not conv:
            # Fall back to simple greeting
            return True, npc.generate_greeting(self.player.name)
        self._active_conversation = conv
        return True, conv.current_npc_text()

    def dialogue_choose(self, option_index: int) -> tuple[dict, bool]:
        """
        Player selects a dialogue option.
        Returns (effects_dict, conversation_is_over).
        """
        if not self._active_conversation:
            return {}, True
        effects = self._active_conversation.choose(option_index, self.player)
        over = self._active_conversation.is_over()
        # Apply world flags from dialogue effects
        if "flag" in effects:
            self.world.flags[effects["flag"]] = True
        if over:
            self._active_conversation = None
        return effects, over

    @property
    def active_conversation(self) -> Optional[Conversation]:
        return self._active_conversation

    # ── Research actions ──────────────────────────────────────────────────────

    def start_research(self, node_id: str) -> tuple[bool, str]:
        ok, msg = self.research.start_research(node_id, self.player.gold)
        if ok:
            cost = self.research.tree[node_id].gold_cost
            self.player.spend_gold(cost)
        return ok, msg

    def cancel_research(self) -> None:
        self.research.cancel_research()

    # ── Conditions actions ────────────────────────────────────────────────────

    def cure_condition(self, condition_id: str) -> tuple[bool, str]:
        return self.conditions.cure(condition_id, self.player)

    def apply_condition(self, condition_id: str) -> Optional[str]:
        return self.conditions.apply(condition_id, self.player)

    # ── Persistence ───────────────────────────────────────────────────────────

    def _ensure_db(self) -> None:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS saves (
                    slot INTEGER PRIMARY KEY,
                    save_date TEXT,
                    data TEXT
                )
            """)

    def save(self, slot: int = 1) -> None:
        data = {
            "turn": self.turn,
            "date": self.date.to_dict(),
            "player": self.player.to_dict(),
            "estate": self.estate.to_dict(),
            "world": self.world.to_dict(),
            "npcs": [n.to_dict() for n in self.npcs],
            "gazette": self.gazette.to_dict(),
            "factions": self.factions.to_dict(),
            "research": self.research.to_dict(),
            "achievements": self.achievements.to_dict(),
            "conditions": self.conditions.to_dict(),
        }
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO saves (slot, save_date, data) VALUES (?,?,?)",
                (slot, str(self.date), json.dumps(data))
            )
        log.info("Game saved to slot %d.", slot)

    def load(self, slot: int = 1) -> bool:
        with sqlite3.connect(DB_PATH) as conn:
            row = conn.execute(
                "SELECT data FROM saves WHERE slot=?", (slot,)
            ).fetchone()
        if not row:
            log.warning("No save in slot %d.", slot)
            return False
        data = json.loads(row[0])
        self.turn = data["turn"]
        self.date = VictorianDate.from_dict(data["date"])
        self.player.from_dict(data["player"])
        self.estate.from_dict(data["estate"])
        self.world.from_dict(data["world"])
        # Restore NPCs
        npc_data = {n["npc_id"]: n for n in data.get("npcs", [])}
        for npc in self.npcs:
            if npc.npc_id in npc_data:
                npc.relationships = npc_data[npc.npc_id].get("relationships", {})
                npc.mood = npc_data[npc.npc_id].get("mood", "composed")
                npc.influence = npc_data[npc.npc_id].get("influence", npc.influence)
        self.gazette.from_dict(data.get("gazette", {}))
        self.factions.from_dict(data.get("factions", {}))
        self.research.from_dict(data.get("research", {}))
        self.achievements.from_dict(data.get("achievements", {}))
        self.conditions.from_dict(data.get("conditions", {}))
        log.info("Game loaded from slot %d.", slot)
        return True

    def save_exists(self, slot: int = 1) -> bool:
        with sqlite3.connect(DB_PATH) as conn:
            row = conn.execute(
                "SELECT 1 FROM saves WHERE slot=?", (slot,)
            ).fetchone()
        return row is not None
