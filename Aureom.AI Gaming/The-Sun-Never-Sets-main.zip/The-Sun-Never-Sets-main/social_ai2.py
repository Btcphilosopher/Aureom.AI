"""
ai/social_ai.py — Social event engine and gossip simulation.

The SocialAI runs every turn to:
  1. Process scheduled social events (galas, dinners, political debates).
  2. Generate spontaneous gossip chains based on NPC volatility and secrets.
  3. Cascade relationship changes across the NPC graph when events occur.
  4. Emit EventBus events so the GUI can show pop-up notifications.

Probability model:
  P(gossip fires) = (volatility / 200) + 0.05  per NPC per turn
  P(secret exposed) = P(gossip) * (100 - loyalty) / 150
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from brass_and_crown.utils import EventBus, roll, weighted_choice, log

if TYPE_CHECKING:
    from brass_and_crown.ai.characters import NPC


# ── NPC district scheduling ───────────────────────────────────────────────────
# Maps NPC id → preferred district schedule.
# Each entry is a list of (district_id, weight) pairs.
# SocialAI rolls from this each turn to move NPCs around the city.

NPC_DISTRICT_PREFERENCES: dict[str, list[tuple[str, float]]] = {
    "lord_ashworth": [
        ("mayfair", 0.50), ("westminster", 0.30), ("clerkenwell", 0.10), ("kensington", 0.10),
    ],
    "lady_fairfax": [
        ("mayfair", 0.40), ("kensington", 0.30), ("westminster", 0.20), ("southwark", 0.10),
    ],
    "dr_cogsworth": [
        ("clerkenwell", 0.55), ("kensington", 0.25), ("whitechapel", 0.15), ("southwark", 0.05),
    ],
    "vivienne_blackthorn": [
        ("limehouse", 0.40), ("whitechapel", 0.25), ("mayfair", 0.20), ("southwark", 0.15),
    ],
    "reverend_holt": [
        ("westminster", 0.35), ("whitechapel", 0.30), ("southwark", 0.20), ("mayfair", 0.15),
    ],
}


# ── Social event definitions ──────────────────────────────────────────────────

@dataclass
class SocialEvent:
    event_id: str
    name: str
    description: str
    influence_delta: float   # how much player influence changes
    gold_cost: int           # optional attendance cost
    required_influence: float = 0.0
    outcomes: list[str] = field(default_factory=list)  # possible outcome strings

    def roll_outcome(self) -> str:
        if not self.outcomes:
            return "uneventful"
        return random.choice(self.outcomes)


SOCIAL_EVENTS: list[SocialEvent] = [
    SocialEvent(
        "gala_season",
        "Mayfair Season Gala",
        "The cream of London society gathers for dancing and intrigue.",
        influence_delta=8.0,
        gold_cost=200,
        outcomes=["scandal_overheard", "alliance_formed", "rival_encountered", "nothing"],
    ),
    SocialEvent(
        "parliamentary_dinner",
        "Parliamentary Dinner",
        "Dine with members of Parliament — politics and port wine flow freely.",
        influence_delta=12.0,
        gold_cost=350,
        required_influence=30.0,
        outcomes=["political_favour", "blackmail_opportunity", "nothing"],
    ),
    SocialEvent(
        "inventors_exposition",
        "Great Exhibition of Inventions",
        "Showcase your gadgets to investors and the curious public.",
        influence_delta=6.0,
        gold_cost=100,
        outcomes=["patent_interest", "industrial_spy_spotted", "press_coverage"],
    ),
    SocialEvent(
        "charity_ball",
        "Charity Ball for the Working Poor",
        "Be seen doing good — or at least be seen.",
        influence_delta=5.0,
        gold_cost=150,
        outcomes=["reputation_boost", "reformer_contact", "nothing"],
    ),
]


# ── SocialAI engine ───────────────────────────────────────────────────────────

class SocialAI:
    """
    Drives the social simulation each game turn.

    Parameters
    ----------
    npcs : list[NPC]
        All active NPCs in the world.
    """

    def __init__(self, npcs: list["NPC"]) -> None:
        self.npcs = npcs
        self._turn_log: list[str] = []

    # ── Main per-turn update ──────────────────────────────────────────────────

    def run_turn(self, turn: int, player_influence: float) -> list[str]:
        """
        Execute one turn of social simulation.
        Returns a list of narrative strings for the journal.
        """
        self._turn_log = []
        context = {"turn": turn, "player_influence": player_influence}

        for npc in self.npcs:
            action = npc.decide_action(context)
            self._process_npc_action(npc, action, turn)

        self._process_gossip_chains()
        self._cascade_mood_changes()
        self._move_npcs()

        return list(self._turn_log)

    def _move_npcs(self) -> None:
        """
        Each turn, NPCs have a 20 % chance of moving to a new district according
        to their preference weights.  The world.py District.npc_ids lists are
        updated accordingly so travel and interaction queries stay accurate.
        """
        from brass_and_crown.world import DISTRICT_INDEX

        # Build reverse map: npc_id → current district_id
        current_location: dict[str, str] = {}
        for did, district in DISTRICT_INDEX.items():
            for nid in district.npc_ids:
                current_location[nid] = did

        for npc in self.npcs:
            if not roll(0.20):
                continue
            prefs = NPC_DISTRICT_PREFERENCES.get(npc.npc_id)
            if not prefs:
                continue
            new_district_id = weighted_choice(prefs)
            old_district_id = current_location.get(npc.npc_id)

            if new_district_id == old_district_id:
                continue

            # Remove from old district
            if old_district_id and old_district_id in DISTRICT_INDEX:
                try:
                    DISTRICT_INDEX[old_district_id].npc_ids.remove(npc.npc_id)
                except ValueError:
                    pass

            # Add to new district
            if new_district_id in DISTRICT_INDEX:
                if npc.npc_id not in DISTRICT_INDEX[new_district_id].npc_ids:
                    DISTRICT_INDEX[new_district_id].npc_ids.append(npc.npc_id)
                current_location[npc.npc_id] = new_district_id

    # ── NPC action processing ─────────────────────────────────────────────────

    def _process_npc_action(self, npc: "NPC", action: str, turn: int) -> None:
        if action == "spread_gossip":
            self._spread_gossip(npc)
        elif action == "scheme":
            self._scheme(npc)
        elif action == "seek_alliance":
            self._seek_alliance(npc)
        # socialise / idle — no special processing needed

    def _spread_gossip(self, source: "NPC") -> None:
        """
        Gossip propagation: source NPC shares a secret (their own or another's)
        with a random other NPC.  Probability of secret exposure depends on
        (100 - loyalty) / 150 for the secret-holder.
        """
        if not source.secrets:
            return  # nothing to gossip about themselves

        # Pick a target NPC to gossip to
        targets = [n for n in self.npcs if n.npc_id != source.npc_id]
        if not targets:
            return
        target = random.choice(targets)

        p_expose = (100 - source.traits["loyalty"]) / 150
        if roll(p_expose):
            secret = random.choice(source.secrets)
            msg = (f"{source.title} {source.name} whispers to {target.title} {target.name}: "
                   f"'{secret}'")
            self._turn_log.append(msg)
            # Relationship damage: source's loyalty drops toward player if player hears it
            source.adjust_relationship("player", -3)
            target.adjust_relationship(source.npc_id, -5)  # trust drops
            EventBus.emit("gossip_spread", {"source": source, "target": target,
                                             "secret": secret})

    def _scheme(self, npc: "NPC") -> None:
        """
        A scheming NPC attempts to gain influence at another's expense.
        Success probability = cunning / 200.
        """
        rivals = [n for n in self.npcs if n.npc_id != npc.npc_id and
                  npc.get_relationship(n.npc_id) < 10]
        if not rivals:
            return
        target = random.choice(rivals)
        p_success = npc.traits["cunning"] / 200.0
        if roll(p_success):
            delta = random.uniform(3, 10)
            npc.influence = min(100, npc.influence + delta)
            target.influence = max(0, target.influence - delta * 0.5)
            msg = (f"{npc.title} {npc.name} manoeuvres against {target.title} {target.name} "
                   f"(+{delta:.1f} influence).")
            self._turn_log.append(msg)
            EventBus.emit("npc_scheme", {"schemer": npc, "target": target, "delta": delta})

    def _seek_alliance(self, npc: "NPC") -> None:
        """
        An NPC with high loyalty tries to strengthen ties with the player.
        """
        npc.adjust_relationship("player", random.uniform(1, 4))
        msg = f"{npc.title} {npc.name} sends a cordial note, seeking closer ties."
        self._turn_log.append(msg)

    # ── Gossip chain propagation ──────────────────────────────────────────────

    def _process_gossip_chains(self) -> None:
        """
        Second-order gossip: already-informed NPCs forward rumours to neighbours.
        Simplified: each volatile NPC has a 15 % chance of cascading any secret
        they hold to one more NPC.
        """
        for npc in self.npcs:
            if npc.traits["volatility"] > 60 and roll(0.15):
                other = random.choice([n for n in self.npcs if n.npc_id != npc.npc_id])
                if npc.secrets:
                    EventBus.emit("gossip_chain", {
                        "carrier": npc,
                        "listener": other,
                        "secret": random.choice(npc.secrets)
                    })

    # ── Mood cascades ─────────────────────────────────────────────────────────

    def _cascade_mood_changes(self) -> None:
        """
        NPCs in the same faction slightly sync their moods (social contagion).
        """
        factions: dict[str, list["NPC"]] = {}
        for npc in self.npcs:
            factions.setdefault(npc.faction, []).append(npc)

        for members in factions.values():
            moods = [n.mood for n in members]
            dominant = max(set(moods), key=moods.count)
            for npc in members:
                if roll(0.2):
                    npc.mood = dominant

    # ── Player-triggered social events ───────────────────────────────────────

    def attend_event(self, event: SocialEvent, player: "any",
                     npcs_present: list["NPC"]) -> dict:
        """
        Called when the player attends a social event.
        Returns a result dict with narrative and stat changes.
        """
        result = {
            "event": event.name,
            "outcome": event.roll_outcome(),
            "influence_delta": event.influence_delta,
            "gold_cost": event.gold_cost,
            "narrative": [],
        }

        narrative = result["narrative"]
        narrative.append(f"You attend the {event.name}.")
        narrative.append(event.description)

        # Process NPC reactions
        for npc in npcs_present:
            reaction = npc.reaction_to_event("gala")
            npc.adjust_relationship("player", random.uniform(2, 6))
            narrative.append(f"{npc.title} {npc.name} seems {reaction}.")

        # Handle specific outcomes
        outcome = result["outcome"]
        if outcome == "scandal_overheard":
            victim = random.choice(npcs_present) if npcs_present else None
            if victim and victim.secrets:
                secret = random.choice(victim.secrets)
                narrative.append(f"You overhear a shocking secret about {victim.title} {victim.name}: {secret}!")
                result["secret_learned"] = (victim.npc_id, secret)
        elif outcome == "alliance_formed":
            ally = random.choice(npcs_present) if npcs_present else None
            if ally:
                ally.adjust_relationship("player", 15)
                narrative.append(f"{ally.title} {ally.name} proposes a discreet alliance.")
                result["ally_gained"] = ally.npc_id
        elif outcome == "rival_encountered":
            rival = random.choice(npcs_present) if npcs_present else None
            if rival:
                rival.adjust_relationship("player", -10)
                narrative.append(f"{rival.title} {rival.name} makes a cutting remark about your family.")
                result["influence_delta"] *= 0.5

        EventBus.emit("social_event_complete", result)
        return result
