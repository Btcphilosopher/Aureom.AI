"""
gui.py — The Sun Never Sets — Victorian steampunk GUI.

Built with tkinter (stdlib — no extra install needed) for maximum portability.
If tkinter is unavailable the game falls back to a text console loop.

Aesthetic: dark charcoal panels, gold/amber accents, copper highlights,
           ornamental dividers, Victorian serif-inspired bold labels.

Layout (single window, tabbed):
  ┌──────────────────────────────────────────────────────┐
  │  THE SUN NEVER SETS    [date]  [gold]  [influence]   │  ← header
  ├──────────┬────────────────────────┬──────────────────┤
  │ DISTRICT │   MAIN PANEL           │  JOURNAL / LOG   │
  │  SIDEBAR │   (tab-switched)       │                  │
  └──────────┴────────────────────────┴──────────────────┘
  │  [ADVANCE TURN]  [SAVE]  [LOAD]  status bar          │
  └──────────────────────────────────────────────────────┘

Tabs: Estate | Market | Quests | Inventory | Society | Map |
      Duels | Factions | Gazette | Research | Achievements | Conditions
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from brass_and_crown.core import GameState


# ── Colour palette ────────────────────────────────────────────────────────────
C = {
    "bg":        "#1A1610",
    "panel":     "#231F18",
    "panel2":    "#2C2720",
    "border":    "#5C4A20",
    "gold":      "#C9A84C",
    "gold_dim":  "#8A6E30",
    "copper":    "#B87333",
    "amber":     "#FFBE00",
    "text":      "#E8D8B0",
    "text_dim":  "#9A8A60",
    "green":     "#4CAF65",
    "red":       "#C0392B",
    "cyan":      "#4BB8C9",
    "header_bg": "#0F0D09",
    "toast_bg":  "#2A2015",
}

FONT_TITLE  = ("Georgia", 18, "bold")
FONT_HEAD   = ("Georgia", 11, "bold")
FONT_BODY   = ("Courier", 9)
FONT_LABEL  = ("Georgia", 9, "bold")
FONT_SMALL  = ("Courier", 8)
FONT_MONO   = ("Courier", 9)


def _style_widget(w: tk.Widget, **kw) -> None:
    try:
        w.configure(**kw)
    except tk.TclError:
        pass


def ornament(parent: tk.Frame, row: int, col: int, span: int = 1) -> None:
    """Draw a horizontal ornamental divider line."""
    line = tk.Frame(parent, bg=C["border"], height=1)
    line.grid(row=row, column=col, columnspan=span, sticky="ew", pady=2)


class SteampunkApp:
    """
    The main application window.
    """

    def __init__(self, game: "GameState") -> None:
        self.game = game
        self.pending_event: Optional[dict] = None

        self.root = tk.Tk()
        self.root.title("The Sun Never Sets")
        self.root.configure(bg=C["bg"])
        self.root.geometry("1200x780")
        self.root.minsize(900, 640)

        self._apply_ttk_style()
        self._build_ui()
        self._subscribe_events()
        self.refresh_all()

    # ── Style ─────────────────────────────────────────────────────────────────

    def _apply_ttk_style(self) -> None:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook",
                        background=C["panel"], borderwidth=0)
        style.configure("TNotebook.Tab",
                        background=C["panel2"], foreground=C["text_dim"],
                        font=FONT_LABEL, padding=[12, 4],
                        borderwidth=1)
        style.map("TNotebook.Tab",
                  background=[("selected", C["border"]),
                               ("active",  C["panel2"])],
                  foreground=[("selected", C["gold"]),
                               ("active",  C["text"])])
        style.configure("TScrollbar",
                        background=C["panel2"], troughcolor=C["bg"],
                        arrowcolor=C["gold_dim"], borderwidth=0)
        style.configure("Vertical.TScrollbar", width=10)

    # ── Build UI ──────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        # ── Header ────────────────────────────────────────────────────────────
        self.header = tk.Frame(self.root, bg=C["header_bg"], height=64)
        self.header.pack(fill="x", side="top")
        self.header.pack_propagate(False)

        tk.Label(self.header, text="✦  THE SUN NEVER SETS  ✦",
                 font=("Georgia", 16, "bold"),
                 bg=C["header_bg"], fg=C["gold"]).pack(side="left", padx=20)

        self.lbl_date = tk.Label(self.header, text="", font=FONT_LABEL,
                                 bg=C["header_bg"], fg=C["text_dim"])
        self.lbl_date.pack(side="left", padx=10)

        # Stat badges on right
        right = tk.Frame(self.header, bg=C["header_bg"])
        right.pack(side="right", padx=20)

        self.badge_gold = self._stat_badge(right, "GOLD", "0", C["amber"])
        self.badge_influence = self._stat_badge(right, "INFLUENCE", "0", C["cyan"])
        self.badge_reputation = self._stat_badge(right, "REPUTATION", "0", C["copper"])
        self.badge_health = self._stat_badge(right, "HEALTH", "0", C["green"])

        # ── Main body ─────────────────────────────────────────────────────────
        body = tk.Frame(self.root, bg=C["bg"])
        body.pack(fill="both", expand=True, padx=4, pady=4)
        body.columnconfigure(1, weight=1)
        body.columnconfigure(2, weight=0)
        body.rowconfigure(0, weight=1)

        # Left sidebar — district navigation
        self.sidebar = self._build_sidebar(body)
        self.sidebar.grid(row=0, column=0, sticky="ns", padx=(0, 4))

        # Centre panel — tabs
        self.notebook = ttk.Notebook(body)
        self.notebook.grid(row=0, column=1, sticky="nsew", padx=2)

        self.tab_estate    = self._build_tab_estate()
        self.tab_market    = self._build_tab_market()
        self.tab_quests    = self._build_tab_quests()
        self.tab_inventory = self._build_tab_inventory()
        self.tab_society   = self._build_tab_society()
        self.tab_map       = self._build_tab_map()
        self.tab_duels     = self._build_tab_duels()
        self.tab_factions  = self._build_tab_factions()
        self.tab_gazette   = self._build_tab_gazette()
        self.tab_research  = self._build_tab_research()
        self.tab_achieve   = self._build_tab_achievements()
        self.tab_conditions = self._build_tab_conditions()

        self.notebook.add(self.tab_estate,     text="  Estate  ")
        self.notebook.add(self.tab_market,     text="  Market  ")
        self.notebook.add(self.tab_quests,     text="  Quests  ")
        self.notebook.add(self.tab_inventory,  text=" Inventory ")
        self.notebook.add(self.tab_society,    text="  Society  ")
        self.notebook.add(self.tab_map,        text="    Map    ")
        self.notebook.add(self.tab_duels,      text="   Duels   ")
        self.notebook.add(self.tab_factions,   text=" Factions  ")
        self.notebook.add(self.tab_gazette,    text="  Gazette  ")
        self.notebook.add(self.tab_research,   text=" Research  ")
        self.notebook.add(self.tab_achieve,    text="Achievements")
        self.notebook.add(self.tab_conditions, text=" Conditions")

        # Right panel — journal
        self.journal_frame = self._build_journal(body)
        self.journal_frame.grid(row=0, column=2, sticky="ns", padx=(4, 0))

        # ── Footer ────────────────────────────────────────────────────────────
        footer = tk.Frame(self.root, bg=C["header_bg"], height=42)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)

        self._btn(footer, "⚙  ADVANCE TURN", self._on_advance_turn,
                  bg=C["gold"], fg=C["bg"]).pack(side="left", padx=8, pady=6)
        self._btn(footer, "💾 SAVE", self._on_save).pack(side="left", padx=4, pady=6)
        self._btn(footer, "📂 LOAD", self._on_load).pack(side="left", padx=4, pady=6)

        self.status_var = tk.StringVar(value="Welcome to London, 1887.")
        tk.Label(footer, textvariable=self.status_var, font=FONT_SMALL,
                 bg=C["header_bg"], fg=C["text_dim"]).pack(side="left", padx=12)

    # ── Sidebar ───────────────────────────────────────────────────────────────

    def _build_sidebar(self, parent: tk.Frame) -> tk.Frame:
        from brass_and_crown.world import DISTRICTS

        frame = tk.Frame(parent, bg=C["panel"], width=170)
        frame.pack_propagate(False)

        tk.Label(frame, text="◈ DISTRICTS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold"]).pack(pady=(10, 4))

        self._draw_line(frame)

        self._district_btns: dict[str, tk.Button] = {}
        for d in DISTRICTS:
            btn = tk.Button(frame, text=d.name, font=FONT_SMALL,
                            bg=C["panel2"], fg=C["text"], relief="flat",
                            activebackground=C["border"], activeforeground=C["gold"],
                            cursor="hand2", padx=8, pady=4,
                            command=lambda did=d.district_id: self._on_travel(did))
            btn.pack(fill="x", padx=6, pady=1)
            self._district_btns[d.district_id] = btn

        self._draw_line(frame)
        tk.Label(frame, text="◈ ACTIONS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold"]).pack(pady=(8, 4))

        self._btn(frame, "🔍 Explore Area",
                  self._on_explore).pack(fill="x", padx=6, pady=2)
        self._btn(frame, "🗣  Interact",
                  self._on_interact_prompt).pack(fill="x", padx=6, pady=2)

        return frame

    # ── Estate tab ────────────────────────────────────────────────────────────

    def _build_tab_estate(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.columnconfigure(1, weight=1)

        tk.Label(f, text="◈ ASHFORD MANOR", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        # Income summary
        self.estate_income_var = tk.StringVar()
        tk.Label(f, textvariable=self.estate_income_var, font=FONT_MONO,
                 bg=C["panel"], fg=C["text"], justify="left"
                 ).grid(row=1, column=0, sticky="nw", padx=10)

        ornament(f, 2, 0, 2)

        # Rooms
        tk.Label(f, text="ROOMS & UPGRADES", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=3, column=0, sticky="w", padx=10)

        self.rooms_frame = tk.Frame(f, bg=C["panel"])
        self.rooms_frame.grid(row=4, column=0, columnspan=2, sticky="ew", padx=10, pady=4)

        ornament(f, 5, 0, 2)

        # Investments
        tk.Label(f, text="INVESTMENTS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=6, column=0, sticky="w", padx=10)
        self.invest_frame = tk.Frame(f, bg=C["panel"])
        self.invest_frame.grid(row=7, column=0, columnspan=2, sticky="ew", padx=10, pady=4)
        self._btn(f, "+ New Investment", self._on_buy_investment
                  ).grid(row=8, column=0, padx=10, pady=6, sticky="w")

        return f

    # ── Market tab ────────────────────────────────────────────────────────────

    def _build_tab_market(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.columnconfigure(1, weight=1)

        tk.Label(f, text="◈ COMMODITY EXCHANGE", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        # Prices table
        self.market_text = self._scrolled_text(f, height=14)
        self.market_text.grid(row=1, column=0, columnspan=2, padx=10, sticky="ew")

        ornament(f, 2, 0, 2)
        tk.Label(f, text="FACTORIES", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=3, column=0, sticky="w", padx=10)

        self.factory_frame = tk.Frame(f, bg=C["panel"])
        self.factory_frame.grid(row=4, column=0, columnspan=2, sticky="ew", padx=10)

        return f

    # ── Quests tab ────────────────────────────────────────────────────────────

    def _build_tab_quests(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)

        tk.Label(f, text="◈ QUESTS & INTRIGUES", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        tk.Label(f, text="ACTIVE", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=1, column=0, sticky="w", padx=10)
        self.active_quests_frame = tk.Frame(f, bg=C["panel"])
        self.active_quests_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=4)

        ornament(f, 3, 0)
        tk.Label(f, text="AVAILABLE", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=4, column=0, sticky="w", padx=10)
        self.avail_quests_frame = tk.Frame(f, bg=C["panel"])
        self.avail_quests_frame.grid(row=5, column=0, sticky="ew", padx=10, pady=4)

        return f

    # ── Inventory tab ─────────────────────────────────────────────────────────

    def _build_tab_inventory(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.columnconfigure(1, weight=1)

        tk.Label(f, text="◈ INVENTORY & WORKSHOP", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        tk.Label(f, text="RESOURCES", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=1, column=0, sticky="w", padx=10)
        self.resources_text = self._scrolled_text(f, height=6)
        self.resources_text.grid(row=2, column=0, padx=10, sticky="ew")

        tk.Label(f, text="BLUEPRINTS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=1, column=1, sticky="w", padx=10)
        self.blueprints_frame = tk.Frame(f, bg=C["panel"])
        self.blueprints_frame.grid(row=2, column=1, padx=10, sticky="new")

        ornament(f, 3, 0, 2)
        tk.Label(f, text="GADGETS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=4, column=0, sticky="w", padx=10)
        self.gadgets_frame = tk.Frame(f, bg=C["panel"])
        self.gadgets_frame.grid(row=5, column=0, columnspan=2, sticky="ew", padx=10, pady=4)

        ornament(f, 6, 0, 2)
        tk.Label(f, text="CRAFTING QUEUE", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=7, column=0, sticky="w", padx=10)
        self.crafting_text = self._scrolled_text(f, height=4)
        self.crafting_text.grid(row=8, column=0, columnspan=2, padx=10, sticky="ew")

        return f

    # ── Society tab ──────────────────────────────────────────────────────────

    def _build_tab_society(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)

        tk.Label(f, text="◈ SOCIETY & RELATIONS", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        tk.Label(f, text="SOCIAL EVENTS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=1, column=0, sticky="w", padx=10)
        self.events_frame = tk.Frame(f, bg=C["panel"])
        self.events_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=4)

        ornament(f, 3, 0)
        tk.Label(f, text="KNOWN FIGURES", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=4, column=0, sticky="w", padx=10)
        self.npc_frame = tk.Frame(f, bg=C["panel"])
        self.npc_frame.grid(row=5, column=0, sticky="ew", padx=10, pady=4)

        ornament(f, 6, 0)
        tk.Label(f, text="SECRETS KNOWN", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=7, column=0, sticky="w", padx=10)
        self.secrets_text = self._scrolled_text(f, height=5)
        self.secrets_text.grid(row=8, column=0, padx=10, sticky="ew")

        return f

    # ── Duels tab ─────────────────────────────────────────────────────────────

    def _build_tab_duels(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)

        tk.Label(f, text="◈ AFFAIRS OF HONOUR", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        tk.Label(f, text="CHALLENGE AN NPC", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=1, column=0, sticky="w", padx=10)
        self.duel_challenge_frame = tk.Frame(f, bg=C["panel"])
        self.duel_challenge_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=4)

        ornament(f, 3, 0)
        tk.Label(f, text="ACTIVE DUEL", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=4, column=0, sticky="w", padx=10)
        self.duel_active_frame = tk.Frame(f, bg=C["panel"])
        self.duel_active_frame.grid(row=5, column=0, sticky="ew", padx=10, pady=4)

        ornament(f, 6, 0)
        self.duel_log_text = self._scrolled_text(f, height=8)
        self.duel_log_text.grid(row=7, column=0, padx=10, sticky="ew")

        return f

    def _refresh_duels(self) -> None:
        from brass_and_crown.duels import DuelType, Tactic, TACTIC_LABELS

        for w in self.duel_challenge_frame.winfo_children():
            w.destroy()

        # NPCs in current district
        npcs_here = self.game.world.get_district_npcs(self.game.npc_map)
        if not npcs_here:
            tk.Label(self.duel_challenge_frame, text="No notable persons here to challenge.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text_dim"]).pack(anchor="w")
        for npc in npcs_here:
            row = tk.Frame(self.duel_challenge_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            tk.Label(row, text=f"{npc.title} {npc.name}",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text"], width=22, anchor="w"
                     ).pack(side="left")
            for dt in DuelType:
                self._btn(row, dt.value,
                          lambda n=npc.npc_id, d=dt: self._on_challenge_duel(n, d)
                          ).pack(side="left", padx=2)

        # Active duel panel
        for w in self.duel_active_frame.winfo_children():
            w.destroy()

        duel = self.game.active_duel
        if not duel:
            tk.Label(self.duel_active_frame, text="No duel in progress.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text_dim"]).pack(anchor="w")
            return

        score_txt = (f"Score: YOU {duel.player_wins_count} — "
                     f"{duel.npc.name} {duel.npc_wins_count}  "
                     f"(first to {duel.ROUNDS_TO_WIN} wins)")
        tk.Label(self.duel_active_frame, text=score_txt, font=FONT_LABEL,
                 bg=C["panel"], fg=C["amber"]).pack(anchor="w", pady=4)

        tactic_labels = TACTIC_LABELS[duel.duel_type]
        btn_row = tk.Frame(self.duel_active_frame, bg=C["panel"])
        btn_row.pack(fill="x")
        for tactic, label in tactic_labels.items():
            self._btn(btn_row, label,
                      lambda t=tactic: self._on_play_duel_round(t),
                      bg=C["border"], fg=C["text"]
                      ).pack(side="left", padx=4, pady=4)

    def _on_challenge_duel(self, npc_id: str, duel_type) -> None:
        ok, msg = self.game.challenge_npc_to_duel(npc_id, duel_type)
        if not ok:
            self._notify("Duel", msg)
        else:
            self._notify("Challenge Accepted!", msg)
        self._refresh_duels()
        self._append_journal(msg)

    def _on_play_duel_round(self, tactic) -> None:
        result, over = self.game.play_duel_round(tactic)
        round_r = result.get("round")
        if round_r:
            self._text_set(self.duel_log_text,
                           (self.duel_log_text.get("1.0", "end").rstrip() + "\n" +
                            round_r.narrative).strip())
            self._append_journal(round_r.narrative)
        if over:
            outcome = result.get("outcome", {})
            self._notify("Duel Concluded",
                         "\n".join(outcome.get("consequences", ["Duel over."])))
        self._refresh_duels()
        self._refresh_header()

    # ── Factions tab ──────────────────────────────────────────────────────────

    def _build_tab_factions(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)

        tk.Label(f, text="◈ FACTIONS OF LONDON", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        self.factions_inner = tk.Frame(f, bg=C["panel"])
        self.factions_inner.grid(row=1, column=0, sticky="ew", padx=10)

        ornament(f, 2, 0)
        tk.Label(f, text="EARNED TITLES", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(row=3, column=0, sticky="w", padx=10)
        self.titles_text = self._scrolled_text(f, height=3)
        self.titles_text.grid(row=4, column=0, padx=10, sticky="ew")

        return f

    def _refresh_factions(self) -> None:
        for w in self.factions_inner.winfo_children():
            w.destroy()

        for fid, faction in self.game.factions.factions.items():
            block = tk.Frame(self.factions_inner, bg=C["panel2"],
                             relief="flat", bd=1)
            block.pack(fill="x", pady=3, padx=2)

            # Header row
            hrow = tk.Frame(block, bg=C["panel2"])
            hrow.pack(fill="x", padx=8, pady=(6, 2))

            tier_col = faction.tier_colour
            tk.Label(hrow, text=f"◆ {faction.name}",
                     font=FONT_LABEL, bg=C["panel2"], fg=C["gold"]
                     ).pack(side="left")
            tk.Label(hrow, text=faction.tier.upper(),
                     font=FONT_SMALL, bg=C["panel2"], fg=tier_col
                     ).pack(side="right")

            # Standing bar (simple canvas bar)
            bar_frame = tk.Frame(block, bg=C["panel2"])
            bar_frame.pack(fill="x", padx=8, pady=2)
            bar_w = 300
            filled = int((faction.standing + 100) / 200 * bar_w)
            canvas = tk.Canvas(bar_frame, bg=C["bg"], height=8,
                                width=bar_w, highlightthickness=0)
            canvas.pack(side="left")
            canvas.create_rectangle(0, 0, filled, 8, fill=tier_col, outline="")
            tk.Label(bar_frame, text=f"{faction.standing:+.0f}",
                     font=FONT_SMALL, bg=C["panel2"], fg=C["text_dim"]
                     ).pack(side="left", padx=6)

            # Action buttons
            arow = tk.Frame(block, bg=C["panel2"])
            arow.pack(fill="x", padx=8, pady=(2, 6))
            self._btn(arow, "Donate (300sh)",
                      lambda fid_=fid: self._on_faction_action(fid_, "donate")
                      ).pack(side="left", padx=2)
            self._btn(arow, "Attend (100sh)",
                      lambda fid_=fid: self._on_faction_action(fid_, "attend")
                      ).pack(side="left", padx=2)
            if fid == "neutral":
                self._btn(arow, "Spy For Network",
                          lambda fid_=fid: self._on_faction_action(fid_, "spy_for"),
                          bg=C["gold_dim"]
                          ).pack(side="left", padx=2)

        # Titles
        titles = self.game.factions.player_titles()
        self._text_set(self.titles_text,
                       "\n".join(titles) if titles else "No faction titles earned yet.")

    def _on_faction_action(self, faction_id: str, action: str) -> None:
        ok, msg = self.game.perform_faction_action(faction_id, action)
        if not ok:
            self._notify("Faction", msg)
        else:
            self.status_var.set(msg[:80])
            self._append_journal(msg)
        self._refresh_factions()
        self._refresh_header()

    # ── Gazette tab ───────────────────────────────────────────────────────────

    def _build_tab_gazette(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        tk.Label(f, text="◈ THE VICTORIAN GAZETTE", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        self.gazette_text = tk.Text(
            f, bg=C["bg"], fg=C["text"], font=("Courier", 9),
            relief="flat", wrap="word", state="disabled",
            insertbackground=C["gold"], padx=8, pady=8,
        )
        sb = ttk.Scrollbar(f, orient="vertical", command=self.gazette_text.yview)
        self.gazette_text.configure(yscrollcommand=sb.set)
        self.gazette_text.grid(row=1, column=0, sticky="nsew", padx=(10, 0))
        sb.grid(row=1, column=1, sticky="ns", pady=4)

        self._btn(f, "Read Latest Issue", self._on_read_gazette
                  ).grid(row=2, column=0, padx=10, pady=6, sticky="w")

        return f

    def _refresh_gazette(self) -> None:
        issue = self.game.gazette.latest_issue
        if issue:
            self._text_set(self.gazette_text, issue.full_text())
        else:
            self._text_set(self.gazette_text,
                           "  The Gazette has not yet been published.\n"
                           "  Advance turns to receive the first issue (every 7 days).")

    def _on_read_gazette(self) -> None:
        # Force-publish an issue for the player to read immediately
        issue = self.game.gazette.publish(self.game)
        self._text_set(self.gazette_text, issue.full_text())
        self._refresh_header()

    def _on_gazette_published(self, issue) -> None:
        self._append_journal("📰 New Gazette issue published!")
        self._refresh_gazette()

    # ── Map tab ───────────────────────────────────────────────────────────────

    def _build_tab_map(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        tk.Label(f, text="◈ MAP OF LONDON", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(row=0, column=0, sticky="w", padx=10, pady=8)

        self.map_canvas = tk.Canvas(f, bg=C["bg"], highlightthickness=0,
                                    width=580, height=400)
        self.map_canvas.grid(row=1, column=0, padx=10, pady=4)
        self._draw_map()

        return f

    def _draw_map(self) -> None:
        canvas = self.map_canvas
        canvas.delete("all")

        from brass_and_crown.world import DISTRICTS

        CELL = 90
        OFFSET_X, OFFSET_Y = 20, 20

        # Grid background lines
        for i in range(7):
            canvas.create_line(OFFSET_X + i * CELL, OFFSET_Y,
                                OFFSET_X + i * CELL, OFFSET_Y + 6 * CELL,
                                fill=C["border"], dash=(2, 8))
            canvas.create_line(OFFSET_X, OFFSET_Y + i * CELL,
                                OFFSET_X + 6 * CELL, OFFSET_Y + i * CELL,
                                fill=C["border"], dash=(2, 8))

        current = self.game.world.current_district_id

        for d in DISTRICTS:
            x = OFFSET_X + d.grid_x * CELL
            y = OFFSET_Y + d.grid_y * CELL
            colour = C["gold"] if d.district_id == current else C["copper"]
            border = C["amber"] if d.district_id == current else C["border"]

            canvas.create_rectangle(x - 35, y - 18, x + 35, y + 18,
                                     fill=C["panel2"], outline=border, width=2)
            canvas.create_text(x, y, text=d.name, font=FONT_SMALL,
                                fill=colour)

        # Legend
        canvas.create_text(OFFSET_X, OFFSET_Y + 7 * CELL - 10,
                            text="◈ = Current Location", font=FONT_SMALL,
                            fill=C["gold"], anchor="w")

    # ── Journal ───────────────────────────────────────────────────────────────

    def _build_journal(self, parent: tk.Frame) -> tk.Frame:
        frame = tk.Frame(parent, bg=C["panel"], width=250)
        frame.pack_propagate(False)

        tk.Label(frame, text="◈ JOURNAL", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold"]).pack(pady=(10, 4))
        self._draw_line(frame)

        self.journal_text = tk.Text(
            frame, bg=C["bg"], fg=C["text"], font=FONT_SMALL,
            relief="flat", wrap="word", state="disabled",
            insertbackground=C["gold"], width=32, height=36,
        )
        sb = ttk.Scrollbar(frame, orient="vertical",
                           command=self.journal_text.yview)
        self.journal_text.configure(yscrollcommand=sb.set)
        self.journal_text.pack(side="left", fill="both", expand=True, padx=(6, 0))
        sb.pack(side="right", fill="y")

        return frame

    # ── Refresh methods ───────────────────────────────────────────────────────

    def refresh_all(self) -> None:
        self._refresh_header()
        self._refresh_estate()
        self._refresh_market()
        self._refresh_quests()
        self._refresh_inventory()
        self._refresh_society()
        self._refresh_map()
        self._refresh_journal()
        self._refresh_duels()
        self._refresh_factions()
        self._refresh_gazette()
        self._refresh_research()
        self._refresh_achievements()
        self._refresh_conditions()
        self._highlight_current_district()

    def _refresh_header(self) -> None:
        p = self.game.player
        self.lbl_date.config(text=str(self.game.date))
        self.badge_gold[1].set(f"£{p.gold // 100}.{p.gold % 100:02d}")
        self.badge_influence[1].set(f"{p.influence:.0f}")
        self.badge_reputation[1].set(f"{p.reputation:.0f}")
        self.badge_health[1].set(f"{p.health:.0f}")

    def _refresh_estate(self) -> None:
        inc = self.game.estate.calculate_income()
        self.estate_income_var.set(
            f"Land rents:    {inc['land']:>6d} sh\n"
            f"Room income:   {inc['rooms']:>6d} sh\n"
            f"Investments:   {inc['investments']:>6d} sh\n"
            f"Staff wages:   {inc['wages']:>6d} sh\n"
            f"─────────────────────\n"
            f"Net per turn:  {inc['net']:>+6d} sh"
        )

        # Rooms
        for w in self.rooms_frame.winfo_children():
            w.destroy()
        for i, room in enumerate(self.game.estate.rooms):
            row_f = tk.Frame(self.rooms_frame, bg=C["panel"])
            row_f.pack(fill="x", pady=1)
            tk.Label(row_f, text=f"{room.name} [Lv{room.level}]",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text"], width=28,
                     anchor="w").pack(side="left")
            if room.level < room.max_level:
                cost = room.upgrade_cost * room.level
                self._btn(row_f, f"Upgrade ({cost}sh)",
                          lambda r=room.room_id: self._on_upgrade_room(r)
                          ).pack(side="right")

        # Investments
        for w in self.invest_frame.winfo_children():
            w.destroy()
        if not self.game.estate.investments:
            tk.Label(self.invest_frame, text="No investments held.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text_dim"]).pack(anchor="w")
        for inv in self.game.estate.investments:
            status = "ACTIVE" if inv.active else "DEFAULTED"
            colour = C["green"] if inv.active else C["red"]
            row_f = tk.Frame(self.invest_frame, bg=C["panel"])
            row_f.pack(fill="x", pady=1)
            tk.Label(row_f, text=inv.name, font=FONT_SMALL,
                     bg=C["panel"], fg=C["text"], width=35, anchor="w").pack(side="left")
            tk.Label(row_f, text=status, font=FONT_SMALL,
                     bg=C["panel"], fg=colour).pack(side="right")

    def _refresh_market(self) -> None:
        self._text_set(self.market_text,
                       self._build_market_text())

        for w in self.factory_frame.winfo_children():
            w.destroy()
        for factory in self.game.market.factories:
            owned = factory.owner_id == "player"
            row = tk.Frame(self.factory_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            colour = C["gold"] if owned else C["text"]
            tag = " [OWNED]" if owned else ""
            tk.Label(row, text=f"{factory.name}{tag} | Lv{factory.upgrade_level} | "
                               f"cap {factory.capacity:.0%} | workers {factory.workers}",
                     font=FONT_SMALL, bg=C["panel"], fg=colour, anchor="w"
                     ).pack(side="left")
            if not owned:
                price = factory.upgrade_level * 5_000
                self._btn(row, f"Buy ({price}sh)",
                          lambda fid=factory.factory_id: self._on_buy_factory(fid)
                          ).pack(side="right")
            else:
                self._btn(row, "Upgrade",
                          lambda fid=factory.factory_id: self._on_upgrade_factory(fid)
                          ).pack(side="right")

    def _build_market_text(self) -> str:
        lines = [f"{'COMMODITY':<18} {'PRICE':>8}  {'TREND':>8}"]
        lines.append("─" * 40)
        for name, c in self.game.market.commodities.items():
            arrow = {"rising": "↑", "falling": "↓", "stable": "→"}[c.trend]
            lines.append(f"{c.name:<18} {c.price:>7.1f}sh  {arrow}")
        return "\n".join(lines)

    def _refresh_quests(self) -> None:
        for w in self.active_quests_frame.winfo_children():
            w.destroy()
        if not self.game.quest_manager.active_quests:
            tk.Label(self.active_quests_frame, text="No active quests.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text_dim"]).pack(anchor="w")
        for q in self.game.quest_manager.active_quests:
            stage = q.stages[q.current_stage] if q.current_stage < len(q.stages) else None
            hint = f"\n  → {stage.description}" if stage else ""
            tk.Label(self.active_quests_frame,
                     text=f"◆ {q.title}{hint}",
                     font=FONT_SMALL, bg=C["panel"], fg=C["gold"],
                     justify="left", anchor="w"
                     ).pack(fill="x", pady=1)

        for w in self.avail_quests_frame.winfo_children():
            w.destroy()
        for q in self.game.quest_manager.available_quests(self.game.player):
            row = tk.Frame(self.avail_quests_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            tk.Label(row, text=f"◇ {q.title}", font=FONT_SMALL,
                     bg=C["panel"], fg=C["text_dim"], anchor="w", width=40
                     ).pack(side="left")
            self._btn(row, "Accept",
                      lambda qid=q.quest_id: self._on_accept_quest(qid)
                      ).pack(side="right")

    def _refresh_inventory(self) -> None:
        inv = self.game.player.inventory
        lines = []
        for name, res in inv.resources.items():
            if res.quantity > 0:
                lines.append(f"{name.capitalize():<12} {res.quantity:>5}")
        self._text_set(self.resources_text,
                       "\n".join(lines) if lines else "No resources.")

        for w in self.blueprints_frame.winfo_children():
            w.destroy()
        if not inv.blueprints:
            tk.Label(self.blueprints_frame, text="No blueprints.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text_dim"]).pack(anchor="w")
        for bp in inv.blueprints:
            row = tk.Frame(self.blueprints_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            tk.Label(row, text=bp.name, font=FONT_SMALL,
                     bg=C["panel"], fg=C["text"], width=22, anchor="w").pack(side="left")
            in_queue = any(j["blueprint_id"] == bp.blueprint_id
                           for j in inv._crafting_queue)
            if not in_queue:
                self._btn(row, "Craft",
                          lambda bid=bp.blueprint_id: self._on_craft(bid)
                          ).pack(side="right")

        for w in self.gadgets_frame.winfo_children():
            w.destroy()
        if not inv.gadgets:
            tk.Label(self.gadgets_frame, text="No gadgets constructed.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text_dim"]).pack(anchor="w")
        for g in inv.gadgets:
            row = tk.Frame(self.gadgets_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            tag = " [EQUIPPED]" if g.equipped else ""
            tk.Label(row, text=f"{g.name}{tag}", font=FONT_SMALL,
                     bg=C["panel"], fg=C["copper"], anchor="w", width=30
                     ).pack(side="left")
            label = "Unequip" if g.equipped else "Equip"
            self._btn(row, label,
                      lambda gid=g.gadget_id: self._on_toggle_equip(gid)
                      ).pack(side="right")

        queue_lines = []
        for job in inv._crafting_queue:
            from brass_and_crown.inventory import BLUEPRINT_INDEX
            bp = BLUEPRINT_INDEX.get(job["blueprint_id"])
            name = bp.name if bp else job["blueprint_id"]
            queue_lines.append(f"{name} — {job['turns_remaining']} turns remaining")
        self._text_set(self.crafting_text,
                       "\n".join(queue_lines) if queue_lines else "Nothing crafting.")

    def _refresh_society(self) -> None:
        from brass_and_crown.ai.social_ai import SOCIAL_EVENTS

        for w in self.events_frame.winfo_children():
            w.destroy()
        for ev in SOCIAL_EVENTS:
            can_afford = self.game.player.gold >= ev.gold_cost
            has_inf = self.game.player.influence >= ev.required_influence
            enabled = can_afford and has_inf
            colour = C["text"] if enabled else C["text_dim"]
            row = tk.Frame(self.events_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            tk.Label(row, text=ev.name, font=FONT_SMALL,
                     bg=C["panel"], fg=colour, width=35, anchor="w"
                     ).pack(side="left")
            cost_txt = f"({ev.gold_cost}sh)"
            if not can_afford:
                cost_txt += " ✗ gold"
            elif not has_inf:
                cost_txt += " ✗ influence"
            state = "normal" if enabled else "disabled"
            self._btn(row, f"Attend {cost_txt}",
                      lambda eid=ev.event_id: self._on_attend_event(eid),
                      state=state).pack(side="right")

        for w in self.npc_frame.winfo_children():
            w.destroy()
        for npc in self.game.npcs:
            rel = self.game.player.get_relationship(npc.npc_id)
            rel_colour = C["green"] if rel > 20 else (C["red"] if rel < -20 else C["text_dim"])
            row = tk.Frame(self.npc_frame, bg=C["panel"])
            row.pack(fill="x", pady=1)
            tk.Label(row, text=f"{npc.title} {npc.name}",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text"], width=22, anchor="w"
                     ).pack(side="left")
            tk.Label(row, text=f"{npc.mood:<12} rel:{rel:+.0f}",
                     font=FONT_SMALL, bg=C["panel"], fg=rel_colour
                     ).pack(side="left", padx=10)

        lines = [f"{nid}: {secret}"
                 for nid, secret in self.game.player.known_secrets]
        self._text_set(self.secrets_text,
                       "\n".join(lines) if lines else "No secrets known.")

    def _refresh_map(self) -> None:
        self._draw_map()

    def _refresh_journal(self) -> None:
        self.journal_text.config(state="normal")
        self.journal_text.delete("1.0", "end")
        for line in self.game.player.journal[-60:]:
            self.journal_text.insert("end", line + "\n")
        self.journal_text.see("end")
        self.journal_text.config(state="disabled")

    def _highlight_current_district(self) -> None:
        current = self.game.world.current_district_id
        for did, btn in self._district_btns.items():
            if did == current:
                btn.configure(bg=C["border"], fg=C["amber"])
            else:
                btn.configure(bg=C["panel2"], fg=C["text"])

    # ── Event handlers ────────────────────────────────────────────────────────

    def _on_advance_turn(self) -> None:
        messages = self.game.advance_turn()

        # Check for pending random events
        if self.game.notifications:
            event_id = self.game.notifications[0]
            from brass_and_crown.quests import RANDOM_EVENTS
            ev = next((e for e in RANDOM_EVENTS if e["id"] == event_id), None)
            if ev and ev.get("choices"):
                self._show_event_dialog(ev)

        # Show turn summary
        summary = "\n".join(messages[:12])
        self._notify("Turn Complete", summary)
        self.refresh_all()

    def _show_event_dialog(self, event: dict) -> None:
        win = tk.Toplevel(self.root)
        win.title(event["title"])
        win.configure(bg=C["bg"])
        win.grab_set()

        tk.Label(win, text=f"◈ {event['title'].upper()}",
                 font=FONT_HEAD, bg=C["bg"], fg=C["gold"]).pack(padx=20, pady=(16, 4))
        tk.Label(win, text=event["description"], font=FONT_BODY,
                 bg=C["bg"], fg=C["text"], wraplength=340, justify="left"
                 ).pack(padx=20, pady=8)

        ornament_frame = tk.Frame(win, bg=C["border"], height=1)
        ornament_frame.pack(fill="x", padx=20)

        for idx, (choice_text, _) in enumerate(event.get("choices", [])):
            def choose(i=idx, w=win):
                result = self.game.apply_random_event_choice(event["id"], i)
                self._notify("Outcome", result)
                self.refresh_all()
                w.destroy()

            self._btn(win, choice_text, choose).pack(fill="x", padx=20, pady=3)

        self._btn(win, "Dismiss", win.destroy,
                  bg=C["panel2"], fg=C["text_dim"]).pack(padx=20, pady=(4, 16))

    def _on_travel(self, district_id: str) -> None:
        ok, msg = self.game.travel_to(district_id)
        self.status_var.set(msg[:80])
        self.refresh_all()

    def _on_explore(self) -> None:
        discovery = self.game.explore_district()
        if discovery:
            self._notify("Discovery!", discovery)
        else:
            self.status_var.set("You find nothing of note.")
        self.refresh_all()

    def _on_interact_prompt(self) -> None:
        district = self.game.world.current_district
        npcs = self.game.world.get_district_npcs(self.game.npc_map)
        if not npcs:
            self.status_var.set(f"No notable figures in {district.name}.")
            return
        win = tk.Toplevel(self.root)
        win.title("Interact")
        win.configure(bg=C["bg"])
        win.grab_set()
        tk.Label(win, text="Choose a person to approach:",
                 font=FONT_LABEL, bg=C["bg"], fg=C["gold"]).pack(padx=16, pady=8)
        for npc in npcs:
            def interact(nid=npc.npc_id, w=win):
                msg = self.game.interact_with_npc(nid)
                self._notify("Interaction", msg)
                self.refresh_all()
                w.destroy()
            self._btn(win, f"{npc.title} {npc.name}", interact
                      ).pack(fill="x", padx=16, pady=2)
        self._btn(win, "Cancel", win.destroy,
                  bg=C["panel2"], fg=C["text_dim"]).pack(padx=16, pady=8)

    def _on_attend_event(self, event_id: str) -> None:
        result = self.game.attend_social_event(event_id)
        if "error" in result:
            self._notify("Cannot Attend", result["error"])
        else:
            narrative = "\n".join(result.get("narrative", []))
            self._notify(f"Event: {result['event']}", narrative)
        self.refresh_all()

    def _on_accept_quest(self, quest_id: str) -> None:
        err = self.game.accept_quest(quest_id)
        if err:
            self._notify("Quest", err)
        else:
            self.status_var.set("Quest accepted.")
        self._refresh_quests()

    def _on_upgrade_room(self, room_id: str) -> None:
        from brass_and_crown.estate import STARTING_ROOMS
        room = next((r for r in self.game.estate.rooms if r.room_id == room_id), None)
        if not room:
            return
        cost = room.upgrade_cost * room.level
        if not self.game.player.spend_gold(cost):
            self._notify("Insufficient Funds", f"Upgrade costs {cost} shillings.")
            return
        ok, msg = self.game.estate.upgrade_room(room_id)
        self._notify("Estate", msg)
        self.refresh_all()

    def _on_buy_factory(self, factory_id: str) -> None:
        ok, msg = self.game.invest_in_factory(factory_id)
        self._notify("Factory", msg)
        self.refresh_all()

    def _on_upgrade_factory(self, factory_id: str) -> None:
        factory = self.game.market.get_factory(factory_id)
        if factory:
            cost = factory.upgrade()
            if not self.game.player.spend_gold(cost):
                self._notify("Factory", "Insufficient funds for upgrade.")
            else:
                self._notify("Factory", f"Upgraded to level {factory.upgrade_level}.")
        self.refresh_all()

    def _on_buy_investment(self) -> None:
        from brass_and_crown.estate import AVAILABLE_INVESTMENTS
        win = tk.Toplevel(self.root)
        win.title("Investments")
        win.configure(bg=C["bg"])
        win.grab_set()
        tk.Label(win, text="Select an investment:", font=FONT_LABEL,
                 bg=C["bg"], fg=C["gold"]).pack(padx=16, pady=8)
        for inv in AVAILABLE_INVESTMENTS:
            txt = (f"{inv['name']}\n"
                   f"  Cost: {inv['initial_cost']} sh  |  "
                   f"Yield: {inv['annual_yield_pct']}%  |  "
                   f"Risk: {'Low' if inv['risk'] < 0.03 else 'Medium' if inv['risk'] < 0.1 else 'High'}")
            def buy(iid=inv["investment_id"], w=win):
                ok, msg = self.game.buy_investment(iid)
                self._notify("Investment", msg)
                self.refresh_all()
                w.destroy()
            self._btn(win, txt, buy).pack(fill="x", padx=12, pady=3)
        self._btn(win, "Cancel", win.destroy,
                  bg=C["panel2"], fg=C["text_dim"]).pack(padx=12, pady=8)

    def _on_craft(self, blueprint_id: str) -> None:
        ok, msg = self.game.start_crafting(blueprint_id)
        self._notify("Workshop", msg)
        self._refresh_inventory()

    def _on_toggle_equip(self, gadget_id: str) -> None:
        for g in self.game.player.inventory.gadgets:
            if g.gadget_id == gadget_id:
                g.equipped = not g.equipped
                break
        self._refresh_inventory()

    def _on_save(self) -> None:
        self.game.save()
        self.status_var.set("Game saved.")

    def _on_load(self) -> None:
        if not self.game.save_exists():
            self._notify("Load", "No save file found.")
            return
        self.game.load()
        self.refresh_all()
        self.status_var.set("Game loaded.")

    # ── EventBus callbacks ────────────────────────────────────────────────────

    def _subscribe_events(self) -> None:
        EventBus.subscribe("gossip_spread",          self._on_gossip_event)
        EventBus.subscribe("market_shock",           self._on_market_shock)
        EventBus.subscribe("factory_accident",       self._on_factory_accident_event)
        EventBus.subscribe("quest_complete",         self._on_quest_complete_event)
        EventBus.subscribe("gazette_published",      self._on_gazette_published)
        EventBus.subscribe("faction_standing_changed", self._on_faction_changed)
        EventBus.subscribe("duel_complete",          self._on_duel_complete_event)
        EventBus.subscribe("achievement_unlocked",   self._on_achievement_unlocked)
        EventBus.subscribe("research_complete",      self._on_research_complete)
        EventBus.subscribe("condition_applied",      self._on_condition_applied)

    def _on_gossip_event(self, data: dict) -> None:
        src = data["source"]
        msg = f"{src.title} {src.name} is spreading gossip…"
        self._append_journal(msg)

    def _on_market_shock(self, data: dict) -> None:
        self._append_journal(f"Market: {data['message']}")

    def _on_factory_accident_event(self, data: dict) -> None:
        self._append_journal(f"⚠ Accident at {data['factory'].name}!")

    def _on_quest_complete_event(self, data: dict) -> None:
        self._notify("Quest Complete!", f"✦ {data['quest'].title}")

    def _on_faction_changed(self, data: dict) -> None:
        self._append_journal(
            f"Faction: {data['faction_id']} standing → {data['new_standing']:.0f} ({data['tier']})")

    def _on_duel_complete_event(self, data: dict) -> None:
        result = "Victory!" if data.get("victory") else "Defeat."
        self._append_journal(f"Duel concluded — {result}")

    def _append_journal(self, line: str) -> None:
        self.journal_text.config(state="normal")
        self.journal_text.insert("end", line + "\n")
        self.journal_text.see("end")
        self.journal_text.config(state="disabled")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _stat_badge(self, parent: tk.Frame, label: str, value: str,
                    colour: str) -> tuple[tk.Label, tk.StringVar]:
        frame = tk.Frame(parent, bg=C["header_bg"])
        frame.pack(side="right", padx=8)
        tk.Label(frame, text=label, font=("Courier", 7, "bold"),
                 bg=C["header_bg"], fg=C["text_dim"]).pack()
        var = tk.StringVar(value=value)
        tk.Label(frame, textvariable=var, font=("Georgia", 13, "bold"),
                 bg=C["header_bg"], fg=colour).pack()
        return None, var  # type: ignore

    def _btn(self, parent: tk.Widget, text: str, command=None,
             bg: str = C["panel2"], fg: str = C["gold"],
             state: str = "normal") -> tk.Button:
        b = tk.Button(parent, text=text, command=command or (lambda: None),
                      bg=bg, fg=fg, font=FONT_SMALL, relief="flat",
                      activebackground=C["border"], activeforeground=C["amber"],
                      cursor="hand2", padx=6, pady=3, state=state)
        return b

    def _panel_frame(self) -> tk.Frame:
        return tk.Frame(self.notebook, bg=C["panel"])

    def _scrolled_text(self, parent: tk.Widget, height: int = 10) -> tk.Text:
        t = tk.Text(parent, bg=C["bg"], fg=C["text"], font=FONT_MONO,
                    relief="flat", wrap="none", state="disabled",
                    height=height, insertbackground=C["gold"])
        return t

    def _text_set(self, widget: tk.Text, content: str) -> None:
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.insert("end", content)
        widget.config(state="disabled")

    def _draw_line(self, parent: tk.Widget) -> None:
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x", padx=8, pady=2)

    # ── Toast notification system ─────────────────────────────────────────────
    # Non-blocking, auto-dismissing toasts appear bottom-right.
    # Critical events use a modal dialog instead.

    def _notify(self, title: str, message: str, critical: bool = False) -> None:
        """Show a toast (non-blocking) or modal dialog for critical events."""
        if critical:
            messagebox.showinfo(title, message)
        else:
            self._show_toast(title, message)

    def _show_toast(self, title: str, message: str,
                    duration_ms: int = 4500) -> None:
        """Overlay a small toast card bottom-right; auto-dismiss after duration_ms."""
        toast = tk.Toplevel(self.root)
        toast.overrideredirect(True)   # no title bar
        toast.attributes("-topmost", True)
        toast.configure(bg=C["toast_bg"])

        # Border frame
        border = tk.Frame(toast, bg=C["border"], padx=1, pady=1)
        border.pack(fill="both", expand=True)
        inner = tk.Frame(border, bg=C["toast_bg"], padx=12, pady=8)
        inner.pack(fill="both", expand=True)

        tk.Label(inner, text=f"✦ {title}", font=FONT_LABEL,
                 bg=C["toast_bg"], fg=C["gold"]).pack(anchor="w")
        # Truncate long messages
        short = message[:200] + ("…" if len(message) > 200 else "")
        tk.Label(inner, text=short, font=FONT_SMALL,
                 bg=C["toast_bg"], fg=C["text"],
                 wraplength=280, justify="left").pack(anchor="w", pady=(2, 0))
        tk.Button(inner, text="✕", font=FONT_SMALL,
                  bg=C["toast_bg"], fg=C["text_dim"], relief="flat",
                  cursor="hand2", command=toast.destroy).pack(anchor="e")

        # Position bottom-right
        self.root.update_idletasks()
        rw = self.root.winfo_width()
        rh = self.root.winfo_height()
        rx = self.root.winfo_rootx()
        ry = self.root.winfo_rooty()
        toast.update_idletasks()
        tw = toast.winfo_reqwidth()
        th = toast.winfo_reqheight()
        toast.geometry(f"+{rx + rw - tw - 16}+{ry + rh - th - 48}")

        toast.after(duration_ms, lambda: toast.destroy() if toast.winfo_exists() else None)

    # ── Dialogue window ───────────────────────────────────────────────────────

    def _open_dialogue_window(self, npc_id: str) -> None:
        """Open full branching dialogue window for an NPC."""
        ok, first_speech = self.game.start_dialogue(npc_id)
        if not ok:
            self._notify("Cannot Speak", first_speech)
            return

        npc = self.game.npc_map.get(npc_id)
        npc_name = f"{npc.title} {npc.name}" if npc else npc_id

        win = tk.Toplevel(self.root)
        win.title(f"Conversation — {npc_name}")
        win.configure(bg=C["bg"])
        win.geometry("580x460")
        win.grab_set()

        # NPC portrait area
        top = tk.Frame(win, bg=C["panel"], height=56)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(top, text=f"◆ {npc_name.upper()}", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).pack(side="left", padx=16, pady=12)
        if npc:
            rel = self.game.player.get_relationship(npc_id)
            rel_col = C["green"] if rel > 20 else C["red"] if rel < -20 else C["text_dim"]
            tk.Label(top, text=f"rel: {rel:+.0f}  mood: {npc.mood}",
                     font=FONT_SMALL, bg=C["panel"], fg=rel_col
                     ).pack(side="right", padx=16)

        # Conversation log
        log_frame = tk.Frame(win, bg=C["bg"])
        log_frame.pack(fill="both", expand=True, padx=12, pady=8)

        conv_log = tk.Text(log_frame, bg=C["bg"], fg=C["text"], font=FONT_BODY,
                           relief="flat", wrap="word", state="disabled",
                           height=12, padx=8, pady=8)
        sb2 = ttk.Scrollbar(log_frame, orient="vertical", command=conv_log.yview)
        conv_log.configure(yscrollcommand=sb2.set)
        conv_log.pack(side="left", fill="both", expand=True)
        sb2.pack(side="right", fill="y")

        # Options area
        opt_frame = tk.Frame(win, bg=C["panel2"])
        opt_frame.pack(fill="x", padx=12, pady=(0, 12))

        def _append_log(speaker: str, text: str, colour: str = C["text"]) -> None:
            conv_log.config(state="normal")
            conv_log.insert("end", f"\n{speaker}:\n", "speaker")
            conv_log.insert("end", f"  {text}\n")
            conv_log.tag_config("speaker", foreground=C["gold_dim"],
                                font=FONT_LABEL)
            conv_log.see("end")
            conv_log.config(state="disabled")

        def _render_options() -> None:
            for w in opt_frame.winfo_children():
                w.destroy()

            if not self.game.active_conversation:
                tk.Label(opt_frame, text="[Conversation ended]", font=FONT_SMALL,
                         bg=C["panel2"], fg=C["text_dim"]).pack(padx=8, pady=6)
                self._btn(opt_frame, "Close", win.destroy).pack(pady=4)
                return

            available = self.game.active_conversation.available_options(
                self.game.player)

            if not available:
                tk.Label(opt_frame, text="[No options available]", font=FONT_SMALL,
                         bg=C["panel2"], fg=C["text_dim"]).pack(padx=8, pady=6)
                self._btn(opt_frame, "Close", win.destroy).pack(pady=4)
                return

            for idx, opt in available:
                def choose(i=idx):
                    effects, over = self.game.dialogue_choose(i)
                    if effects.get("error"):
                        self._show_toast("Cannot", effects["error"])
                        return
                    _append_log("You", available[0][1].text if i == available[0][0]
                                else next(o.text for ii, o in available if ii == i))
                    if not over:
                        npc_text = self.game.active_conversation.current_npc_text() \
                            if self.game.active_conversation else ""
                        _append_log(npc_name, npc_text, C["text"])
                    else:
                        _append_log("—", "[The conversation concludes.]", C["text_dim"])
                    # Show notable effects
                    effect_notes = []
                    if effects.get("relationship_delta"):
                        effect_notes.append(f"Relationship {effects['relationship_delta']:+.0f}")
                    if effects.get("secret_learned"):
                        effect_notes.append(f"Secret: {effects['secret_learned']}")
                    if effects.get("blueprint"):
                        effect_notes.append(f"Blueprint: {effects['blueprint']}")
                    if effect_notes:
                        self._show_toast("Effect", " | ".join(effect_notes))
                    self.refresh_all()
                    _render_options()

                self._btn(opt_frame, f"  {opt.text}", choose,
                          bg=C["panel2"], fg=C["text"]
                          ).pack(fill="x", padx=8, pady=2)

            self._btn(opt_frame, "End Conversation", win.destroy,
                      bg=C["bg"], fg=C["text_dim"]).pack(padx=8, pady=(4, 8))

        # Seed first speech
        _append_log(npc_name, first_speech)
        _render_options()

    # ── Research tab ──────────────────────────────────────────────────────────

    def _build_tab_research(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.columnconfigure(1, weight=1)

        tk.Label(f, text="◈ LIBRARY & RESEARCH", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=10, pady=8)

        # Active research display
        self.research_active_var = tk.StringVar(value="No research in progress.")
        tk.Label(f, textvariable=self.research_active_var, font=FONT_MONO,
                 bg=C["panel"], fg=C["amber"]
                 ).grid(row=1, column=0, columnspan=2, sticky="w", padx=10)

        ornament(f, 2, 0, 2)
        tk.Label(f, text="AVAILABLE RESEARCH", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]
                 ).grid(row=3, column=0, columnspan=2, sticky="w", padx=10)

        self.research_avail_frame = tk.Frame(f, bg=C["panel"])
        self.research_avail_frame.grid(
            row=4, column=0, columnspan=2, sticky="ew", padx=10, pady=4)

        ornament(f, 5, 0, 2)
        tk.Label(f, text="COMPLETED", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]
                 ).grid(row=6, column=0, columnspan=2, sticky="w", padx=10)

        self.research_done_text = self._scrolled_text(f, height=6)
        self.research_done_text.grid(
            row=7, column=0, columnspan=2, padx=10, sticky="ew")

        return f

    def _refresh_research(self) -> None:
        rm = self.game.research
        active = rm.active_node
        if active:
            self.research_active_var.set(
                f"Researching: {active.name} — "
                f"{active.progress_pct:.0f}% ({active.turns_remaining} turns left)")
        else:
            self.research_active_var.set("No research in progress.")

        for w in self.research_avail_frame.winfo_children():
            w.destroy()

        for node in rm.available_nodes():
            row = tk.Frame(self.research_avail_frame, bg=C["panel"])
            row.pack(fill="x", pady=2)
            tk.Label(row,
                     text=f"[{node.discipline[:4].upper()}] {node.name}  "
                          f"({node.turns_required}t / {node.gold_cost}sh)",
                     font=FONT_SMALL, bg=C["panel"], fg=C["text"],
                     width=48, anchor="w").pack(side="left")
            already = active and active.node_id == node.node_id
            lbl = "Studying…" if already else "Study"
            state = "disabled" if (active and not already) else "normal"
            self._btn(row, lbl,
                      lambda nid=node.node_id: self._on_start_research(nid),
                      state=state).pack(side="right")

        done_lines = [f"✦ {n.name} [{n.discipline}]" for n in rm.completed_nodes()]
        self._text_set(self.research_done_text,
                       "\n".join(done_lines) if done_lines else "Nothing completed yet.")

    def _on_start_research(self, node_id: str) -> None:
        ok, msg = self.game.start_research(node_id)
        self._notify("Research", msg)
        self._refresh_research()

    # ── Achievements tab ──────────────────────────────────────────────────────

    def _build_tab_achievements(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        tk.Label(f, text="◈ ACHIEVEMENTS & TITLES", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(
            row=0, column=0, sticky="w", padx=10, pady=8)

        self.ach_text = tk.Text(
            f, bg=C["bg"], fg=C["text"], font=FONT_MONO,
            relief="flat", wrap="word", state="disabled",
            padx=10, pady=8)
        sb = ttk.Scrollbar(f, orient="vertical", command=self.ach_text.yview)
        self.ach_text.configure(yscrollcommand=sb.set)
        self.ach_text.grid(row=1, column=0, sticky="nsew", padx=(10, 0))
        sb.grid(row=1, column=1, sticky="ns", pady=4)

        return f

    def _refresh_achievements(self) -> None:
        am = self.game.achievements
        lines = []

        by_cat = am.by_category()
        for cat, achs in by_cat.items():
            lines.append(f"\n── {cat} ──")
            for a in achs:
                if a.hidden and not a.unlocked:
                    lines.append("  ░ [Hidden]")
                    continue
                mark = "✦" if a.unlocked else "◇"
                title_note = f"  → Title: {a.title_granted}" if (a.unlocked and a.title_granted) else ""
                lines.append(f"  {mark} {a.name}{title_note}")
                if not a.unlocked:
                    lines.append(f"      {a.description}")

        # Titles section
        all_titles = am.all_titles(self.game)
        if all_titles:
            lines.append("\n── YOUR TITLES ──")
            for t in all_titles:
                lines.append(f"  ✦ {t}")

        self._text_set(self.ach_text, "\n".join(lines))

    # ── Conditions tab ────────────────────────────────────────────────────────

    def _build_tab_conditions(self) -> tk.Frame:
        f = self._panel_frame()
        f.columnconfigure(0, weight=1)

        tk.Label(f, text="◈ CONDITIONS & STATUS EFFECTS", font=FONT_HEAD,
                 bg=C["panel"], fg=C["gold"]).grid(
            row=0, column=0, sticky="w", padx=10, pady=8)

        tk.Label(f, text="ACTIVE CONDITIONS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(
            row=1, column=0, sticky="w", padx=10)

        self.conditions_frame = tk.Frame(f, bg=C["panel"])
        self.conditions_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=4)

        ornament(f, 3, 0)
        tk.Label(f, text="STAT MULTIPLIERS", font=FONT_LABEL,
                 bg=C["panel"], fg=C["gold_dim"]).grid(
            row=4, column=0, sticky="w", padx=10)
        self.mult_var = tk.StringVar()
        tk.Label(f, textvariable=self.mult_var, font=FONT_MONO,
                 bg=C["panel"], fg=C["text"], justify="left"
                 ).grid(row=5, column=0, sticky="w", padx=16)

        return f

    def _refresh_conditions(self) -> None:
        cm = self.game.conditions

        for w in self.conditions_frame.winfo_children():
            w.destroy()

        active = cm.active_conditions()
        if not active:
            tk.Label(self.conditions_frame,
                     text="No conditions active. You are in fine health.",
                     font=FONT_SMALL, bg=C["panel"], fg=C["green"]).pack(anchor="w")
        else:
            for cond in active:
                row = tk.Frame(self.conditions_frame, bg=C["panel2"],
                               relief="flat")
                row.pack(fill="x", pady=2, padx=2)
                inner = tk.Frame(row, bg=C["panel2"])
                inner.pack(fill="x", padx=8, pady=4)

                dur = "permanent" if cond.is_permanent else f"{cond.duration} turns"
                cat_col = {
                    "AILMENT":  C["red"],
                    "SOCIAL":   C["cyan"],
                    "MENTAL":   C["copper"],
                    "ECONOMIC": C["amber"],
                }.get(cond.category, C["text"])

                tk.Label(inner, text=f"{cond.icon} {cond.name}",
                         font=FONT_LABEL, bg=C["panel2"], fg=cat_col
                         ).pack(side="left")
                tk.Label(inner, text=f"[{dur}]",
                         font=FONT_SMALL, bg=C["panel2"], fg=C["text_dim"]
                         ).pack(side="left", padx=8)

                # Effects summary
                effs = []
                if cond.health_per_turn:
                    effs.append(f"HP {cond.health_per_turn:+.1f}/t")
                if cond.influence_per_turn:
                    effs.append(f"Inf {cond.influence_per_turn:+.1f}/t")
                if cond.reputation_per_turn:
                    effs.append(f"Rep {cond.reputation_per_turn:+.1f}/t")
                if cond.gold_per_turn:
                    effs.append(f"Gold {cond.gold_per_turn:+d}/t")
                if effs:
                    tk.Label(inner, text=" | ".join(effs),
                             font=FONT_SMALL, bg=C["panel2"], fg=C["text_dim"]
                             ).pack(side="left", padx=8)

                if cond.cure_cost_gold > 0:
                    self._btn(inner, f"Cure ({cond.cure_cost_gold}sh)",
                              lambda cid=cond.condition_id: self._on_cure_condition(cid),
                              bg=C["panel"], fg=C["green"]
                              ).pack(side="right")

        # Multipliers
        charm_m = cm.charm_multiplier()
        cunning_m = cm.cunning_multiplier()
        self.mult_var.set(
            f"Charm multiplier:   ×{charm_m:.2f}\n"
            f"Cunning multiplier: ×{cunning_m:.2f}"
        )

    def _on_cure_condition(self, condition_id: str) -> None:
        ok, msg = self.game.cure_condition(condition_id)
        self._notify("Treatment", msg)
        self._refresh_conditions()
        self._refresh_header()

    # ── Update interact button to use dialogue system ─────────────────────────

    def _on_interact_prompt(self) -> None:
        district = self.game.world.current_district
        npcs = self.game.world.get_district_npcs(self.game.npc_map)
        if not npcs:
            self.status_var.set(f"No notable figures in {district.name}.")
            return
        win = tk.Toplevel(self.root)
        win.title("Interact")
        win.configure(bg=C["bg"])
        win.grab_set()
        tk.Label(win, text="Choose a person to approach:",
                 font=FONT_LABEL, bg=C["bg"], fg=C["gold"]).pack(padx=16, pady=8)
        for npc in npcs:
            def interact(nid=npc.npc_id, w=win):
                w.destroy()
                self._open_dialogue_window(nid)
                self.refresh_all()
            self._btn(win, f"◆ {npc.title} {npc.name}  [{npc.mood}]",
                      interact).pack(fill="x", padx=16, pady=2)
        self._btn(win, "Cancel", win.destroy,
                  bg=C["panel2"], fg=C["text_dim"]).pack(padx=16, pady=8)

    # ── Subscribe to new events ───────────────────────────────────────────────

    def _on_achievement_unlocked(self, data: dict) -> None:
        ach = data["achievement"]
        self._show_toast(f"🏆 {ach.name}", ach.description, duration_ms=6000)

    def _on_research_complete(self, data: dict) -> None:
        node = data["node"]
        self._show_toast(f"✦ Research: {node.name}",
                         f"You have mastered {node.discipline}.", duration_ms=5000)

    def _on_condition_applied(self, data: dict) -> None:
        cond = data["condition"]
        self._show_toast(f"{cond.icon} {cond.name}", cond.description, duration_ms=5000)

    # ── Run ───────────────────────────────────────────────────────────────────

    def run(self) -> None:
        self.root.mainloop()




# ── Text console fallback ─────────────────────────────────────────────────────

class ConsoleUI:
    """Full-featured text REPL for environments without tkinter."""

    COMMANDS = {
        "turn":         "Advance one turn  (turn [n])",
        "travel":       "Travel            (travel <district_id>)",
        "explore":      "Explore current area",
        "attend":       "Social event      (attend <event_id>)",
        "talk":         "Talk to NPC       (talk <npc_id>)",
        "quest":        "Accept quest      (quest <quest_id>)",
        "quests":       "List quests",
        "craft":        "Craft gadget      (craft <blueprint_id>)",
        "research?":    "List research options",
        "research":     "Start research    (research <node_id>)",
        "duel":         "Challenge NPC     (duel <npc_id> wit|neg|honour)",
        "faction":      "Faction action    (faction <id> donate|attend|spy_for)",
        "factions":     "List factions",
        "conditions":   "Show conditions",
        "cure":         "Cure condition    (cure <condition_id>)",
        "achievements": "Show achievements",
        "gazette":      "Read latest Gazette",
        "status":       "Player status",
        "map":          "List districts",
        "market":       "Commodity prices",
        "save":         "Save game",
        "load":         "Load game",
        "help":         "Show help",
        "quit":         "Exit",
    }

    def __init__(self, game: "GameState") -> None:
        self.game = game

    def run(self) -> None:
        print("\n" + "=" * 64)
        print("  * THE SUN NEVER SETS *   London, 1887")
        print("=" * 64)
        print("Type 'help' for commands.\n")
        while True:
            try:
                raw = input(f"\n[{self.game.date} | T{self.game.turn}] > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nFarewell.")
                break
            if not raw:
                continue
            parts = raw.split()
            cmd, *args = parts
            try:
                self._dispatch(cmd, args)
            except SystemExit:
                break
            except Exception as e:
                print(f"  Error: {e}")

    def _dispatch(self, cmd: str, args: list) -> None:  # noqa: C901
        g = self.game
        p = g.player

        if cmd == "quit":
            raise SystemExit(0)

        elif cmd == "help":
            for c, desc in self.COMMANDS.items():
                print(f"  {c:<20} {desc}")

        elif cmd == "turn":
            n = int(args[0]) if args else 1
            for _ in range(n):
                msgs = g.advance_turn()
                for m in msgs[:8]:
                    print(" ", m)
            print(f"  -> {g.date}")

        elif cmd == "status":
            print(f"\n  {p.title} {p.name}")
            print(f"  Gold:       L{p.gold // 100}.{p.gold % 100:02d}")
            print(f"  Influence:  {p.influence:.1f}")
            print(f"  Reputation: {p.reputation:.1f}")
            print(f"  Health:     {p.health:.1f}")
            print(f"  Cunning:    {p.cunning:.1f}  Charm: {p.charm:.1f}")
            print(f"  Location:   {g.world.current_district.name}")
            active_c = g.conditions.active_conditions()
            if active_c:
                print(f"  Conditions: {', '.join(c.name for c in active_c)}")
            titles = g.achievements.all_titles(g)
            if titles:
                print(f"  Titles:     {', '.join(titles)}")

        elif cmd == "map":
            from brass_and_crown.world import DISTRICTS
            current = g.world.current_district_id
            for d in DISTRICTS:
                marker = ">" if d.district_id == current else " "
                npcs = f"  [{', '.join(d.npc_ids)}]" if d.npc_ids else ""
                print(f"  {marker} {d.name:<14} {d.description[:40]}{npcs}")

        elif cmd == "travel" and args:
            ok, msg = g.travel_to(args[0].lower())
            print(" ", msg)

        elif cmd == "explore":
            d = g.explore_district()
            print(" ", d if d else "Nothing of note found.")

        elif cmd == "market":
            print(f"\n  {'COMMODITY':<18} {'PRICE':>8}  TREND")
            print("  " + "-" * 36)
            for name, c in g.market.commodities.items():
                arrow = {"rising": "^", "falling": "v", "stable": "-"}[c.trend]
                print(f"  {c.name:<18} {c.price:>7.1f}sh  {arrow}")

        elif cmd == "quests":
            available = g.quest_manager.available_quests(p)
            active = g.quest_manager.active_quests
            print("\n  ACTIVE:")
            if not active:
                print("    (none)")
            for q in active:
                stage = q.stages[q.current_stage] if q.current_stage < len(q.stages) else None
                hint = f" -> {stage.description}" if stage else ""
                print(f"    * {q.title}{hint}")
            print("  AVAILABLE:")
            if not available:
                print("    (none)")
            for q in available:
                print(f"    o [{q.quest_id}] {q.title}")

        elif cmd == "quest" and args:
            err = g.accept_quest(args[0])
            print(" ", err if err else "Quest accepted.")

        elif cmd == "attend" and args:
            result = g.attend_social_event(args[0])
            if "error" in result:
                print("  Error:", result["error"])
            else:
                for line in result.get("narrative", []):
                    print(" ", line)

        elif cmd == "talk" and args:
            ok, speech = g.start_dialogue(args[0])
            if not ok:
                print(" ", speech)
                return
            npc = g.npc_map.get(args[0])
            npc_name = f"{npc.title} {npc.name}" if npc else args[0]
            print(f"\n  {npc_name}: {speech}")
            self._dialogue_loop(npc_name)

        elif cmd == "craft" and args:
            ok, msg = g.start_crafting(args[0])
            print(" ", msg)

        elif cmd == "research?":
            rm = g.research
            active_n = rm.active_node
            if active_n:
                print(f"  Studying: {active_n.name} ({active_n.progress_pct:.0f}%)")
            print("\n  AVAILABLE:")
            for node in rm.available_nodes():
                print(f"    [{node.node_id}] {node.name} ({node.turns_required}t / {node.gold_cost}sh)")
            print("\n  COMPLETED:")
            for node in rm.completed_nodes():
                print(f"    * {node.name}")

        elif cmd == "research" and args:
            ok, msg = g.start_research(args[0])
            print(" ", msg)

        elif cmd == "duel" and len(args) >= 2:
            from brass_and_crown.duels import DuelType
            dtype_map = {"wit": DuelType.WIT, "neg": DuelType.NEGOTIATION, "honour": DuelType.HONOUR}
            dtype = dtype_map.get(args[1].lower(), DuelType.WIT)
            ok, msg = g.challenge_npc_to_duel(args[0], dtype)
            print(" ", msg)
            if ok:
                self._duel_loop()

        elif cmd == "faction" and len(args) >= 2:
            ok, msg = g.perform_faction_action(args[0], args[1])
            print(" ", msg)

        elif cmd == "factions":
            for fid, faction in g.factions.factions.items():
                bar = "#" * int((faction.standing + 100) / 20)
                print(f"  {faction.name:<30} {bar:<10} {faction.standing:+.0f} [{faction.tier}]")

        elif cmd == "conditions":
            active_c = g.conditions.active_conditions()
            if not active_c:
                print("  No active conditions.")
            for c in active_c:
                dur = "permanent" if c.is_permanent else f"{c.duration}t"
                print(f"  {c.name:<24} [{dur}]  {c.description[:50]}")

        elif cmd == "cure" and args:
            ok, msg = g.cure_condition(args[0])
            print(" ", msg)

        elif cmd == "achievements":
            for cat, achs in g.achievements.by_category().items():
                print(f"\n  {cat}")
                for a in achs:
                    if a.hidden and not a.unlocked:
                        continue
                    mark = "*" if a.unlocked else "o"
                    print(f"    {mark} {a.name}")

        elif cmd == "gazette":
            issue = g.gazette.latest_issue
            if not issue:
                print("  No issue yet. Advance turns.")
            else:
                print(issue.full_text())

        elif cmd == "save":
            g.save()
            print("  Saved.")

        elif cmd == "load":
            ok = g.load()
            print("  Loaded." if ok else "  No save found.")

        else:
            print(f"  Unknown command '{cmd}'. Type 'help'.")

    def _dialogue_loop(self, npc_name: str) -> None:
        while self.game.active_conversation:
            conv = self.game.active_conversation
            options = conv.available_options(self.game.player)
            if not options:
                print("  [No options available.]")
                break
            print("\n  Your options:")
            for i, (idx, opt) in enumerate(options):
                print(f"    {i + 1}. {opt.text}")
            print("    0. End conversation")
            try:
                raw = input("  Choose: ").strip()
                choice = int(raw)
            except (ValueError, EOFError):
                break
            if choice == 0:
                self.game._active_conversation = None
                break
            if not (1 <= choice <= len(options)):
                continue
            real_idx = options[choice - 1][0]
            effects, over = self.game.dialogue_choose(real_idx)
            npc_text = (self.game.active_conversation.current_npc_text()
                        if self.game.active_conversation else "")
            if npc_text:
                print(f"\n  {npc_name}: {npc_text}")
            if effects.get("secret_learned"):
                print(f"  > Secret: {effects['secret_learned']}")
            if over:
                print("  [Conversation ends.]")
                break

    def _duel_loop(self) -> None:
        from brass_and_crown.duels import TACTIC_LABELS
        duel = self.game.active_duel
        if not duel:
            return
        labels = TACTIC_LABELS[duel.duel_type]
        tactic_list = list(labels.items())
        while self.game.active_duel:
            d = self.game.active_duel
            print(f"\n  Score: YOU {d.player_wins_count} -- {d.npc.name} {d.npc_wins_count}"
                  f"  (first to {d.ROUNDS_TO_WIN})")
            for i, (tactic, label) in enumerate(tactic_list):
                print(f"    {i + 1}. {label}")
            try:
                raw = input("  Choose tactic: ").strip()
                idx = int(raw) - 1
            except (ValueError, EOFError):
                break
            if not (0 <= idx < len(tactic_list)):
                continue
            chosen_tactic = tactic_list[idx][0]
            result, over = self.game.play_duel_round(chosen_tactic)
            rnd = result.get("round")
            if rnd:
                print(f"  {rnd.narrative}")
            if over:
                outcome = result.get("outcome", {})
                print("\n  " + "\n  ".join(outcome.get("consequences", ["Duel concluded."])))
                break
