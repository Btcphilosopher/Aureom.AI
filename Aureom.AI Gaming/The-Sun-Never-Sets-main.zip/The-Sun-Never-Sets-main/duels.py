"""
duels.py — Turn-based Duel Engine for The Sun Never Sets.

Three duel modes:
  WIT          — Exchange cutting remarks. Driven by charm + cunning.
  NEGOTIATION  — Compete for the better deal. Driven by cunning + gold.
  HONOUR       — Physical contest of pistols or swords. Driven by health + equipment.

Each duel is a best-of-N rounds.  Each round the player chooses a tactic;
the NPC AI picks one based on their traits.  The tactic matchup produces a
probability matrix (think rock-paper-scissors with weighted outcomes).

Tactic matchup table (attacker row vs defender column → attacker_win_prob):
              riposte  pressure  bluff
  riposte      0.45     0.65     0.30
  pressure     0.35     0.45     0.70
  bluff        0.70     0.30     0.45

The base probability is then modified by the combatant's relevant stat / 100.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, TYPE_CHECKING

from brass_and_crown.utils import roll, log, EventBus, weighted_choice

if TYPE_CHECKING:
    from brass_and_crown.ai.characters import NPC
    from brass_and_crown.player import Player


# ── Duel types and tactics ────────────────────────────────────────────────────

class DuelType(Enum):
    WIT         = "Duel of Wit"
    NEGOTIATION = "Duel of Negotiation"
    HONOUR      = "Duel of Honour"


class Tactic(Enum):
    RIPOSTE  = "riposte"    # counter, defensive
    PRESSURE = "pressure"   # aggressive advance
    BLUFF    = "bluff"      # feint / misdirection

TACTIC_LABELS = {
    DuelType.WIT:         {
        Tactic.RIPOSTE:  "Deliver a razor-sharp comeback",
        Tactic.PRESSURE: "Dominate with withering rhetoric",
        Tactic.BLUFF:    "Feign ignorance, then strike",
    },
    DuelType.NEGOTIATION: {
        Tactic.RIPOSTE:  "Counter their terms with precision",
        Tactic.PRESSURE: "Press for immediate concessions",
        Tactic.BLUFF:    "Imply you have other offers",
    },
    DuelType.HONOUR:      {
        Tactic.RIPOSTE:  "Parry and wait for an opening",
        Tactic.PRESSURE: "Advance with aggressive footwork",
        Tactic.BLUFF:    "Feint left, strike right",
    },
}

# attacker_tactic → {defender_tactic → attacker_base_win_prob}
MATCHUP: dict[Tactic, dict[Tactic, float]] = {
    Tactic.RIPOSTE:  {Tactic.RIPOSTE: 0.45, Tactic.PRESSURE: 0.65, Tactic.BLUFF: 0.30},
    Tactic.PRESSURE: {Tactic.RIPOSTE: 0.35, Tactic.PRESSURE: 0.45, Tactic.BLUFF: 0.70},
    Tactic.BLUFF:    {Tactic.RIPOSTE: 0.70, Tactic.PRESSURE: 0.30, Tactic.BLUFF: 0.45},
}


# ── Combatant wrapper ─────────────────────────────────────────────────────────

@dataclass
class Combatant:
    name: str
    primary_stat: float        # 0–100; charm/cunning/health depending on duel type
    secondary_stat: float      # 0–100; secondary modifier
    cunning: float             # drives tactic choice for AI
    stamina: int = 10          # hit points (rounds lost before forfeit)
    is_player: bool = False
    _tactic_history: list[Tactic] = field(default_factory=list)

    def choose_tactic_ai(self) -> Tactic:
        """
        AI tactic selection.
        High-cunning combatants mix tactics unpredictably.
        Low-cunning combatants favour PRESSURE.
        """
        if self.cunning > 70:
            # Clever: avoid patterns, counter last player tactic
            return random.choice(list(Tactic))
        elif self.cunning > 40:
            options = [
                (Tactic.PRESSURE, 40),
                (Tactic.RIPOSTE,  35),
                (Tactic.BLUFF,    25),
            ]
        else:
            options = [
                (Tactic.PRESSURE, 70),
                (Tactic.RIPOSTE,  20),
                (Tactic.BLUFF,    10),
            ]
        return weighted_choice(options)

    def effective_stat(self) -> float:
        """Combined stat used as a win-probability modifier."""
        return (self.primary_stat * 0.7 + self.secondary_stat * 0.3) / 100.0


# ── Duel round result ─────────────────────────────────────────────────────────

@dataclass
class RoundResult:
    round_num: int
    player_tactic: Tactic
    npc_tactic: Tactic
    player_wins: bool
    narrative: str
    player_stamina: int
    npc_stamina: int


# ── Duel session ──────────────────────────────────────────────────────────────

class Duel:
    """
    A single duel between the player and an NPC.

    Usage:
        duel = Duel(DuelType.WIT, player_combatant, npc_combatant)
        result = duel.resolve_round(Tactic.BLUFF)   # called per round
        if duel.is_over():
            outcome = duel.outcome()
    """

    ROUNDS_TO_WIN = 3   # first to 3 round wins takes the duel

    def __init__(self, duel_type: DuelType,
                 player: Combatant, npc: Combatant,
                 stakes: Optional[dict] = None) -> None:
        self.duel_type = duel_type
        self.player = player
        self.npc = npc
        self.stakes = stakes or {}   # {"gold": 500, "influence": 10, "secret": "..."}
        self.round_num = 0
        self.player_wins_count = 0
        self.npc_wins_count = 0
        self.history: list[RoundResult] = []
        self._over = False

    # ── Core round resolution ─────────────────────────────────────────────────

    def resolve_round(self, player_tactic: Tactic) -> RoundResult:
        """
        Resolve one round.  Returns a RoundResult.
        Call is_over() after each round to check if the duel has ended.
        """
        if self._over:
            raise RuntimeError("Duel is already over.")

        self.round_num += 1
        npc_tactic = self.npc.choose_tactic_ai()

        # Base probability from matchup table (player attacks, NPC defends)
        base_p = MATCHUP[player_tactic][npc_tactic]

        # Modify by stat differential
        stat_mod = (self.player.effective_stat() - self.npc.effective_stat()) * 0.25
        final_p = max(0.05, min(0.95, base_p + stat_mod))

        player_wins_round = roll(final_p)

        # Update stamina
        if player_wins_round:
            self.player_wins_count += 1
            self.npc.stamina -= 1
        else:
            self.npc_wins_count += 1
            self.player.stamina -= 1

        narrative = self._generate_narrative(
            player_tactic, npc_tactic, player_wins_round)

        result = RoundResult(
            round_num=self.round_num,
            player_tactic=player_tactic,
            npc_tactic=npc_tactic,
            player_wins=player_wins_round,
            narrative=narrative,
            player_stamina=self.player.stamina,
            npc_stamina=self.npc.stamina,
        )
        self.history.append(result)

        # Check termination
        if (self.player_wins_count >= self.ROUNDS_TO_WIN or
                self.npc_wins_count >= self.ROUNDS_TO_WIN):
            self._over = True

        return result

    def is_over(self) -> bool:
        return self._over

    def player_victorious(self) -> bool:
        return self.player_wins_count >= self.ROUNDS_TO_WIN

    # ── Narrative generation ──────────────────────────────────────────────────

    def _generate_narrative(self, pt: Tactic, nt: Tactic,
                            player_wins: bool) -> str:
        """Build a flavourful round narrative from the tactic pairing."""
        win_str = "You gain the upper hand" if player_wins else f"{self.npc.name} presses the advantage"
        combos = {
            (Tactic.BLUFF,    Tactic.PRESSURE):  "Your feint catches them completely off-balance.",
            (Tactic.PRESSURE, Tactic.BLUFF):     "You see through the deception and press forward.",
            (Tactic.RIPOSTE,  Tactic.PRESSURE):  "Their aggression is turned against them.",
            (Tactic.PRESSURE, Tactic.RIPOSTE):   "The countermove blunts your advance.",
            (Tactic.BLUFF,    Tactic.RIPOSTE):   "The counter was anticipated — your bluff dissolves.",
            (Tactic.RIPOSTE,  Tactic.BLUFF):     "You see straight through the misdirection.",
        }
        flavour = combos.get((pt, nt), "The exchange is fierce.")
        return f"{flavour} {win_str}. (Score: {self.player_wins_count}–{self.npc_wins_count})"

    # ── Outcome ───────────────────────────────────────────────────────────────

    def outcome(self) -> dict:
        """
        Return the full duel outcome dict.
        Called once is_over() returns True.
        """
        victory = self.player_victorious()
        result = {
            "victory": victory,
            "score": (self.player_wins_count, self.npc_wins_count),
            "duel_type": self.duel_type.value,
            "opponent": self.npc.name,
            "consequences": [],
        }
        if victory:
            result["consequences"].append(f"Victory over {self.npc.name}!")
            if "gold" in self.stakes:
                result["gold_delta"] = self.stakes["gold"]
                result["consequences"].append(f"+{self.stakes['gold']} shillings.")
            if "influence" in self.stakes:
                result["influence_delta"] = self.stakes.get("influence", 0)
                result["consequences"].append(f"+{self.stakes['influence']:.0f} influence.")
            if "secret" in self.stakes:
                result["secret"] = self.stakes["secret"]
                result["consequences"].append("A secret is revealed.")
        else:
            result["consequences"].append(f"Defeat at the hands of {self.npc.name}.")
            if "gold" in self.stakes:
                result["gold_delta"] = -self.stakes["gold"]
                result["consequences"].append(f"−{self.stakes['gold']} shillings lost.")
            result["reputation_delta"] = -8
            result["consequences"].append("−8 reputation.")

        EventBus.emit("duel_complete", result)
        log.info("Duel over: player %s (%d-%d)", "won" if victory else "lost",
                 self.player_wins_count, self.npc_wins_count)
        return result


# ── Factory helpers ───────────────────────────────────────────────────────────

def build_player_combatant(player: "Player", duel_type: DuelType) -> Combatant:
    """Construct a Combatant from the player's stats for a given duel type."""
    bonuses = player.equipment_bonuses
    if duel_type == DuelType.WIT:
        primary   = player.effective_charm
        secondary = player.cunning
    elif duel_type == DuelType.NEGOTIATION:
        primary   = player.cunning
        secondary = player.effective_charm
    else:  # HONOUR
        primary   = player.health
        secondary = bonuses.get("duel_power", 0)

    return Combatant(
        name=f"{player.title} {player.name}",
        primary_stat=primary,
        secondary_stat=secondary,
        cunning=player.cunning,
        stamina=10,
        is_player=True,
    )


def build_npc_combatant(npc: "NPC", duel_type: DuelType) -> Combatant:
    """Construct a Combatant from an NPC for a given duel type."""
    if duel_type == DuelType.WIT:
        primary   = npc.traits["charm"]
        secondary = npc.traits["cunning"]
    elif duel_type == DuelType.NEGOTIATION:
        primary   = npc.traits["cunning"]
        secondary = npc.traits["ambition"]
    else:
        primary   = 60.0  # NPCs are assumed reasonably fit
        secondary = npc.traits["cunning"] * 0.5

    return Combatant(
        name=f"{npc.title} {npc.name}",
        primary_stat=primary,
        secondary_stat=secondary,
        cunning=npc.traits["cunning"],
        stamina=10,
    )


def challenge_stakes(npc: "NPC", duel_type: DuelType) -> dict:
    """
    Compute sensible default stakes for a duel against an NPC.
    High-influence NPCs have higher stakes.
    """
    influence_factor = int(npc.influence / 10)
    if duel_type == DuelType.HONOUR:
        return {
            "gold": 200 * influence_factor,
            "influence": influence_factor * 2,
            "reputation_on_win": 5,
        }
    elif duel_type == DuelType.NEGOTIATION:
        return {
            "gold": 500 * influence_factor,
            "influence": influence_factor,
        }
    else:  # WIT
        if npc.secrets:
            return {
                "influence": influence_factor * 3,
                "secret": (npc.npc_id, npc.secrets[0]),
            }
        return {"influence": influence_factor * 2}
