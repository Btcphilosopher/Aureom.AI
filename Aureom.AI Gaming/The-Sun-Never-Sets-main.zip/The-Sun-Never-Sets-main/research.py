"""
research.py — Technology and Knowledge Research Tree.

The player can spend turns (and occasionally gold) studying topics in
their Library & Study.  Completing a research node unlocks:
  • New blueprint slots in the inventory
  • Stat bonuses (cunning, charm, influence cap)
  • New dialogue options
  • Economic bonuses
  • Faction standing multipliers

Research tree structure:
  NATURAL PHILOSOPHY
    └─ Steam Mechanics        → unlocks advanced factory upgrades
        └─ Aether Theory      → unlocks aether gadgets tier 2
            └─ Automata Design → unlocks self-repairing factories

  SOCIAL SCIENCES
    └─ Rhetoric & Oratory    → +10 charm cap
        └─ Political Economy  → unlocks investment tier 2
            └─ Statecraft      → faction standing gains ×1.5

  INTELLIGENCE CRAFT
    └─ Cryptography          → unlocks coded correspondence
        └─ Disguise & Persona → espionage actions in districts
            └─ Counter-espionage → immunity to blackmail events

  MEDICINE & PHYSIOLOGY
    └─ Anatomy               → +20 health cap
        └─ Pharmacology       → health recovery ×2/turn
            └─ Experimental Surgery → unlock health-for-stat trade
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import log, EventBus


# ── Research node ─────────────────────────────────────────────────────────────

@dataclass
class ResearchNode:
    node_id: str
    name: str
    discipline: str          # "natural_philosophy" | "social" | "intelligence" | "medicine"
    description: str
    turns_required: int      # base research time
    gold_cost: int           # one-time cost to begin
    prerequisites: list[str] # node_ids that must be complete first
    unlocks: dict            # effects granted on completion
    # unlocks keys: blueprints(list), stat_bonus(dict), flag(str),
    #               income_bonus(int), faction_multiplier(float)
    completed: bool = False
    turns_invested: int = 0  # turns spent so far

    @property
    def progress_pct(self) -> float:
        if self.turns_required == 0:
            return 100.0
        return min(100.0, self.turns_invested / self.turns_required * 100)

    @property
    def is_complete(self) -> bool:
        return self.completed

    @property
    def turns_remaining(self) -> int:
        return max(0, self.turns_required - self.turns_invested)

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "completed": self.completed,
            "turns_invested": self.turns_invested,
        }


# ── Research catalogue ────────────────────────────────────────────────────────

def build_research_tree() -> dict[str, ResearchNode]:
    nodes = [
        # ── Natural Philosophy ──────────────────────────────────────────────
        ResearchNode(
            "steam_mechanics", "Steam Mechanics", "natural_philosophy",
            "Master the principles of steam power, pressure, and mechanical advantage.",
            turns_required=10, gold_cost=200,
            prerequisites=[],
            unlocks={"blueprints": ["bp_chronometer"],
                     "stat_bonus": {"cunning": 3},
                     "flag": "research_steam_mechanics",
                     "income_bonus": 20},
        ),
        ResearchNode(
            "aether_theory", "Aether Theory", "natural_philosophy",
            "Study the ethereal substance that powers Victorian super-science.",
            turns_required=15, gold_cost=400,
            prerequisites=["steam_mechanics"],
            unlocks={"blueprints": ["bp_aether_pistol"],
                     "stat_bonus": {"cunning": 5},
                     "flag": "research_aether_theory"},
        ),
        ResearchNode(
            "automata_design", "Automata Design", "natural_philosophy",
            "Construct self-regulating mechanical servants.",
            turns_required=20, gold_cost=800,
            prerequisites=["aether_theory"],
            unlocks={"blueprints": ["bp_analytical_engine"],
                     "stat_bonus": {"cunning": 8},
                     "income_bonus": 80,
                     "flag": "research_automata"},
        ),

        # ── Social Sciences ──────────────────────────────────────────────────
        ResearchNode(
            "rhetoric", "Rhetoric & Oratory", "social",
            "Command a room. Shape opinion. Win debates.",
            turns_required=8, gold_cost=100,
            prerequisites=[],
            unlocks={"stat_bonus": {"charm": 10},
                     "flag": "research_rhetoric"},
        ),
        ResearchNode(
            "political_economy", "Political Economy", "social",
            "Understand the flows of capital, labour, and political power.",
            turns_required=12, gold_cost=300,
            prerequisites=["rhetoric"],
            unlocks={"stat_bonus": {"cunning": 5},
                     "income_bonus": 50,
                     "flag": "research_political_economy"},
        ),
        ResearchNode(
            "statecraft", "Statecraft", "social",
            "The art of governance, alliance, and the exercise of power.",
            turns_required=18, gold_cost=600,
            prerequisites=["political_economy"],
            unlocks={"stat_bonus": {"charm": 5, "cunning": 5},
                     "faction_multiplier": 1.5,
                     "flag": "research_statecraft"},
        ),

        # ── Intelligence Craft ───────────────────────────────────────────────
        ResearchNode(
            "cryptography", "Cryptography", "intelligence",
            "Create and break coded messages. A foundation of espionage.",
            turns_required=10, gold_cost=150,
            prerequisites=[],
            unlocks={"stat_bonus": {"cunning": 5},
                     "flag": "research_cryptography"},
        ),
        ResearchNode(
            "disguise", "Disguise & Persona", "intelligence",
            "Adopt false identities to move through dangerous districts safely.",
            turns_required=14, gold_cost=250,
            prerequisites=["cryptography"],
            unlocks={"stat_bonus": {"cunning": 5, "charm": 3},
                     "flag": "research_disguise"},
        ),
        ResearchNode(
            "counter_espionage", "Counter-Espionage", "intelligence",
            "Detect and neutralise threats to your secrets and reputation.",
            turns_required=18, gold_cost=400,
            prerequisites=["disguise"],
            unlocks={"stat_bonus": {"cunning": 8},
                     "flag": "research_counter_espionage",
                     "immunity": "blackmail"},
        ),

        # ── Medicine & Physiology ────────────────────────────────────────────
        ResearchNode(
            "anatomy", "Anatomy", "medicine",
            "Understanding the human body — its strengths and vulnerabilities.",
            turns_required=8, gold_cost=120,
            prerequisites=[],
            unlocks={"stat_bonus": {"health": 20},
                     "flag": "research_anatomy"},
        ),
        ResearchNode(
            "pharmacology", "Pharmacology", "medicine",
            "Harness the power of medicinal compounds and their effects.",
            turns_required=12, gold_cost=200,
            prerequisites=["anatomy"],
            unlocks={"stat_bonus": {"health": 10},
                     "flag": "research_pharmacology",
                     "health_regen_mult": 2.0},
        ),
        ResearchNode(
            "experimental_surgery", "Experimental Surgery", "medicine",
            "Push the boundaries of what science can do for the body.",
            turns_required=20, gold_cost=1_000,
            prerequisites=["pharmacology"],
            unlocks={"stat_bonus": {"health": 20},
                     "flag": "research_experimental_surgery"},
        ),
    ]
    return {n.node_id: n for n in nodes}


# ── ResearchManager ───────────────────────────────────────────────────────────

class ResearchManager:
    """
    Manages the player's research progress.

    The player can research one node at a time; each turn they are
    studying, that node gains one turn of progress.
    """

    def __init__(self) -> None:
        self.tree: dict[str, ResearchNode] = build_research_tree()
        self._active_node_id: Optional[str] = None
        self._completed_ids: set[str] = set()

    # ── Availability ──────────────────────────────────────────────────────────

    def available_nodes(self) -> list[ResearchNode]:
        """Nodes whose prerequisites are all complete and that aren't done."""
        return [
            n for n in self.tree.values()
            if not n.completed
            and all(p in self._completed_ids for p in n.prerequisites)
        ]

    def completed_nodes(self) -> list[ResearchNode]:
        return [n for n in self.tree.values() if n.completed]

    # ── Start / cancel research ───────────────────────────────────────────────

    def start_research(self, node_id: str, player_gold: int) -> tuple[bool, str]:
        node = self.tree.get(node_id)
        if not node:
            return False, "Unknown research topic."
        if node.completed:
            return False, f"'{node.name}' is already complete."
        if not all(p in self._completed_ids for p in node.prerequisites):
            missing = [p for p in node.prerequisites if p not in self._completed_ids]
            return False, f"Prerequisites not met: {', '.join(missing)}"
        if player_gold < node.gold_cost:
            return False, f"Insufficient gold ({node.gold_cost} shillings required)."
        self._active_node_id = node_id
        return True, (f"Researching '{node.name}' — "
                      f"{node.turns_remaining} turns remaining.")

    def cancel_research(self) -> None:
        self._active_node_id = None

    @property
    def active_node(self) -> Optional[ResearchNode]:
        return self.tree.get(self._active_node_id) if self._active_node_id else None

    # ── Turn tick ─────────────────────────────────────────────────────────────

    def tick(self, player) -> list[str]:
        """
        Advance active research by one turn.
        Applies unlocks when complete.
        Returns list of messages.
        """
        messages = []
        if not self._active_node_id:
            return messages

        node = self.tree.get(self._active_node_id)
        if not node or node.completed:
            self._active_node_id = None
            return messages

        node.turns_invested += 1
        if node.turns_invested >= node.turns_required:
            node.completed = True
            self._completed_ids.add(node.node_id)
            self._active_node_id = None
            msgs = self._apply_unlocks(node, player)
            messages.append(f"✦ Research complete: '{node.name}'!")
            messages.extend(msgs)
            EventBus.emit("research_complete", {"node": node})
            log.info("Research complete: %s", node.name)
        else:
            # Progress notification every 5 turns
            if node.turns_invested % 5 == 0:
                messages.append(
                    f"Research '{node.name}': {node.progress_pct:.0f}% "
                    f"({node.turns_remaining} turns remaining)."
                )
        return messages

    # ── Apply unlocks ─────────────────────────────────────────────────────────

    def _apply_unlocks(self, node: ResearchNode, player) -> list[str]:
        messages = []
        unlocks = node.unlocks

        # Blueprint unlocks
        for bp_id in unlocks.get("blueprints", []):
            if player.inventory.learn_blueprint(bp_id):
                messages.append(f"  Blueprint unlocked: {bp_id}")

        # Stat bonuses
        for stat, bonus in unlocks.get("stat_bonus", {}).items():
            if stat == "cunning":
                player.cunning = min(100, player.cunning + bonus)
                messages.append(f"  Cunning +{bonus}")
            elif stat == "charm":
                player.charm = min(100, player.charm + bonus)
                messages.append(f"  Charm +{bonus}")
            elif stat == "health":
                player.adjust_health(bonus)
                messages.append(f"  Health +{bonus}")

        # Flag
        if "flag" in unlocks:
            player.log_event(f"Research flag set: {unlocks['flag']}")

        # Immunity
        if unlocks.get("immunity") == "blackmail":
            messages.append("  You are now immune to blackmail attempts.")

        return messages

    # ── Persistence ───────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "active_node_id": self._active_node_id,
            "nodes": [n.to_dict() for n in self.tree.values()],
        }

    def from_dict(self, d: dict) -> None:
        self._active_node_id = d.get("active_node_id")
        node_data = {n["node_id"]: n for n in d.get("nodes", [])}
        for node_id, node in self.tree.items():
            if node_id in node_data:
                node.completed = node_data[node_id].get("completed", False)
                node.turns_invested = node_data[node_id].get("turns_invested", 0)
                if node.completed:
                    self._completed_ids.add(node_id)
