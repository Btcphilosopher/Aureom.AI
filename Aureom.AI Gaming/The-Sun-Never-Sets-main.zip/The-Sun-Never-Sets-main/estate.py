"""
estate.py — Manor, estate, workforce, and income management.

The estate generates passive income each turn from:
  • Land rents
  • Owned factories (dividends paid by economy_ai)
  • Investments (bonds, stock in the East India Company, etc.)

Upgrades unlock new gameplay options and increase NPC respect.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import roll, log, EventBus


# ── Estate room / upgrade ──────────────────────────────────────────────────────

@dataclass
class EstateRoom:
    room_id: str
    name: str
    description: str
    upgrade_cost: int
    income_bonus: int = 0          # extra gold per turn
    influence_bonus: float = 0.0   # social bonus while room is active
    unlocks: list[str] = field(default_factory=list)  # feature flags
    level: int = 1
    max_level: int = 3

    def upgrade(self) -> tuple[bool, int]:
        """Returns (success, cost)."""
        if self.level >= self.max_level:
            return False, 0
        cost = self.upgrade_cost * self.level
        self.level += 1
        return True, cost

    @property
    def effective_income(self) -> int:
        return self.income_bonus * self.level

    @property
    def effective_influence(self) -> float:
        return self.influence_bonus * self.level


STARTING_ROOMS: list[EstateRoom] = [
    EstateRoom("drawing_room",   "Drawing Room",
               "Host guests and conduct discreet meetings.",
               upgrade_cost=1_500, influence_bonus=2.0,
               unlocks=["host_private_meeting"]),
    EstateRoom("workshop",       "Inventor's Workshop",
               "Craft gadgets and conduct experiments.",
               upgrade_cost=2_000, income_bonus=20,
               unlocks=["advanced_crafting"]),
    EstateRoom("study",          "Library & Study",
               "Research blueprints and accumulate knowledge.",
               upgrade_cost=1_200, influence_bonus=1.0,
               unlocks=["blueprint_research"]),
    EstateRoom("stables",        "Stables & Carriage House",
               "Maintain horses and steam-carriages for city travel.",
               upgrade_cost=1_800, income_bonus=10,
               unlocks=["fast_travel"]),
    EstateRoom("ballroom",       "Grand Ballroom",
               "Host extravagant parties that boost social standing.",
               upgrade_cost=5_000, influence_bonus=8.0,
               unlocks=["host_gala", "increased_npc_attendance"]),
]


# ── Investment ────────────────────────────────────────────────────────────────

@dataclass
class Investment:
    investment_id: str
    name: str
    description: str
    initial_cost: int
    annual_yield_pct: float    # % of initial cost paid per 30 turns
    risk: float                # probability of default per 30 turns
    _turns_held: int = 0
    active: bool = True

    def advance(self, turns: int = 1) -> int:
        """Returns gold earned this turn (dividends accrued per turn)."""
        if not self.active:
            return 0
        self._turns_held += turns
        income_per_turn = (self.initial_cost * self.annual_yield_pct / 100) / 30
        return int(income_per_turn)

    def check_default(self) -> bool:
        """Call once per 30 turns. Returns True if investment defaults."""
        if roll(self.risk):
            self.active = False
            log.warning("Investment defaulted: %s", self.name)
            EventBus.emit("investment_default", {"investment": self})
            return True
        return False


AVAILABLE_INVESTMENTS: list[dict] = [
    dict(investment_id="railway_bonds", name="Great Western Railway Bonds",
         description="Steady returns from Britain's expanding rail network.",
         initial_cost=2_000, annual_yield_pct=5.0, risk=0.02),
    dict(investment_id="east_india_stock", name="East India Company Stock",
         description="High returns from colonial trade, but politically volatile.",
         initial_cost=5_000, annual_yield_pct=9.0, risk=0.07),
    dict(investment_id="bank_deposit", name="Bank of England Deposit",
         description="The safest investment in the Empire, though modest.",
         initial_cost=1_000, annual_yield_pct=2.5, risk=0.001),
    dict(investment_id="aether_venture", name="Aether Prospecting Syndicate",
         description="Speculative venture — enormous upside if aether fields are found.",
         initial_cost=3_000, annual_yield_pct=15.0, risk=0.15),
]


# ── Estate ────────────────────────────────────────────────────────────────────

class Estate:
    """
    The player's ancestral manor and all associated assets.

    Income sources are totalled each turn and returned to the game core.
    """

    def __init__(self) -> None:
        self.name: str = "Ashford Manor"
        self.location: str = "Mayfair"
        self.rooms: list[EstateRoom] = list(STARTING_ROOMS)  # shallow copy
        self.investments: list[Investment] = []
        self.staff: dict[str, int] = {
            "butler": 1, "footmen": 4, "housemaids": 6,
            "cook": 1, "gardener": 2, "coachman": 1,
        }
        self.land_income: int = 150   # base shillings per turn from tenant rents
        self._turn_counter: int = 0

    # ── Income calculation ────────────────────────────────────────────────────

    def calculate_income(self) -> dict:
        """Return breakdown of income this turn."""
        room_income = sum(r.effective_income for r in self.rooms)
        invest_income = sum(i.advance() for i in self.investments if i.active)
        staff_wages = sum(n * 3 for n in self.staff.values())  # 3 sh / worker
        net = self.land_income + room_income + invest_income - staff_wages
        return {
            "land": self.land_income,
            "rooms": room_income,
            "investments": invest_income,
            "wages": -staff_wages,
            "net": net,
        }

    def calculate_influence_bonus(self) -> float:
        return sum(r.effective_influence for r in self.rooms)

    # ── Upgrades ──────────────────────────────────────────────────────────────

    def upgrade_room(self, room_id: str) -> tuple[bool, str]:
        room = next((r for r in self.rooms if r.room_id == room_id), None)
        if not room:
            return False, "Room not found."
        ok, cost = room.upgrade()
        if ok:
            return True, f"{room.name} upgraded to level {room.level}. Cost: {cost} shillings."
        return False, f"{room.name} is already at maximum level."

    def unlocked_features(self) -> set[str]:
        features = set()
        for room in self.rooms:
            features.update(room.unlocks)
        return features

    # ── Investments ───────────────────────────────────────────────────────────

    def buy_investment(self, investment_id: str, player_gold: int) -> tuple[bool, str, int]:
        """Returns (success, message, cost)."""
        template = next((i for i in AVAILABLE_INVESTMENTS
                         if i["investment_id"] == investment_id), None)
        if not template:
            return False, "Investment not found.", 0
        # Prevent duplicate
        if any(i.investment_id == investment_id for i in self.investments):
            return False, "You already hold this investment.", 0
        cost = template["initial_cost"]
        if player_gold < cost:
            return False, f"Insufficient gold. Required: {cost} shillings.", 0
        inv = Investment(**template)
        self.investments.append(inv)
        return True, f"Purchased {inv.name} for {cost} shillings.", cost

    # ── Turn tick ─────────────────────────────────────────────────────────────

    def tick(self) -> list[str]:
        """Advance estate by one turn. Returns event messages."""
        self._turn_counter += 1
        messages = []

        # Every 30 turns check investment default
        if self._turn_counter % 30 == 0:
            for inv in self.investments:
                if inv.check_default():
                    messages.append(f"⚠ {inv.name} has defaulted! Income lost.")

        # Random estate events
        if roll(0.05):
            event = random.choice([
                "A burst pipe floods the lower cellar — repair costs 200 shillings.",
                "Your gardener discovers an ancient Roman coin — sold for 150 shillings.",
                "A tenant on your Hertfordshire land improves his farm; rents rise slightly.",
                "A London fog delays your coal delivery to the workshop.",
            ])
            messages.append(f"Estate news: {event}")

        return messages

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "location": self.location,
            "rooms": [
                {"room_id": r.room_id, "level": r.level} for r in self.rooms
            ],
            "investments": [
                {k: v for k, v in i.__dict__.items() if not k.startswith("_")}
                for i in self.investments
            ],
            "staff": self.staff,
            "land_income": self.land_income,
        }

    def from_dict(self, d: dict) -> None:
        self.name = d.get("name", self.name)
        self.location = d.get("location", self.location)
        self.staff = d.get("staff", self.staff)
        self.land_income = d.get("land_income", self.land_income)
        level_map = {r["room_id"]: r["level"] for r in d.get("rooms", [])}
        for room in self.rooms:
            if room.room_id in level_map:
                room.level = level_map[room.room_id]
        self.investments = [Investment(**i) for i in d.get("investments", [])]
