# The Sun Never Sets

*A Victorian Steampunk Aristocrat Simulation — London, 1887*

---

## Premise

You are a newly-minted aristocrat in gaslit Victorian London.  
Your fortune is modest, your social standing precarious, and the Empire is at its restless zenith.

Navigate society's razor-edged salons, invest in the thundering ironworks of the East End, craft impossibly clever steampunk gadgets, uncover scandals that could topple lords and ministries — and accumulate enough influence to shape the fate of the British Empire.

---

## Key Mechanics

### Turn System
Each "turn" represents one game-day.  Press **Advance Turn** to:
- Collect estate income (land rents, factories, investments)
- Progress crafting projects in your workshop
- Trigger NPC actions (gossip, schemes, alliances)
- Update market commodity prices
- Roll for random events (scandals, fires, newspaper coverage)

### Social Simulation
Five AI-driven NPCs populate London's society:
| Character | Archetype | Faction |
|---|---|---|
| Lord Ashworth | Schemer | Tories |
| Lady Fairfax | Noble | Moderates |
| Dr Cogsworth | Industrialist | Industrialists |
| Miss Blackthorn | Spy | Neutral |
| Reverend Holt | Reformer | Reformers |

Each NPC has a **trait vector** (ambition, honesty, loyalty, cunning, charm, volatility) that drives:
- Their probabilistic action each turn (scheme, socialise, spread gossip, seek alliance)
- Their reaction to events (galas, scandals, accidents)
- Their greeting when the player interacts with them

### Economy
Commodity prices follow an **Ornstein-Uhlenbeck mean-reversion process**:
```
price(t+1) = price(t) + θ · (μ - price(t)) + σ · N(0,1)
```
This creates realistic-looking price fluctuations that trend back toward a long-run equilibrium, with occasional **market shocks** (strikes, royal contracts, embargoes).

You can buy factories and receive dividends, or invest in railway bonds, colonial stock, or speculative aether ventures.

### Crafting
Blueprints are discovered through quests, social events, or exploration.  Each blueprint specifies:
- Required resources (coal, iron, copper, aether-crystals, etc.)
- Turns to craft (3–14 turns)
- Bonuses when the gadget is equipped (influence, duel power, travel speed, etc.)

Crafted gadgets:
| Gadget | Bonus |
|---|---|
| Precision Chronometer | +5 planning, +2 influence |
| Aether-Pistol | +20 duel power, +10 intimidation |
| Pocket Analytical Engine | +15 economy bonus, +3 influence |
| Personal Ornithopter | Fast travel, +10 exploration |
| Resonance Locket | +15 charm, +5 influence |

### Quests
Three main quest lines are included in the prototype:
1. **Smoke and Mirrors** — Expose Lord Ashworth's railway embezzlement
2. **The Clockwork Disappearance** — Find Dr Cogsworth and recover stolen blueprints
3. **A Gentleman's Conscience** — Support Reverend Holt's reform bill

Quests use a stage-machine system: each stage checks a condition (`influence:60`, `visit:clerkenwell`, `secret:lord_ashworth`, etc.) before the player advances.

### Random Events
Low-probability events fire each turn:
- Pickpocket in Piccadilly
- Featured in The Times (reputation boost)
- Factory fire (pay to help or ignore)
- Blackmail (pay, ignore, or investigate with a cunning check)
- Duel challenge (accept or decline)

---

## Module Structure

```
brass_and_crown/
├── __init__.py
├── core.py           # GameState, turn loop, save/load (SQLite)
├── utils.py          # EventBus, VictorianDate, weighted_choice, roll()
├── player.py         # Player stats, journal, relationships
├── estate.py         # Manor rooms, investments, staff wages
├── inventory.py      # Resources, blueprints, crafting queue, gadgets
├── quests.py         # QuestManager, random events
├── world.py          # Districts, travel, exploration, world flags
├── gui.py            # tkinter GUI (+ console fallback)
├── ai/
│   ├── characters.py # NPC dataclass, trait model, decision engine
│   ├── social_ai.py  # Gossip chains, social events, mood cascades
│   └── economy_ai.py # Commodity market (OU process), factories
└── main.py           # Entry point
```

---

## Installation & Running

### Requirements
- Python 3.11+
- `tkinter` (standard library on most systems)
- No third-party packages required for the core game

### Linux / macOS
```bash
# If tkinter is missing on Debian/Ubuntu:
sudo apt install python3-tk

# Run the game
cd the_sun_never_sets
python main.py

# Or console mode:
python main.py --console

# Fresh game (ignore existing save):
python main.py --no-load
```

### Windows
```cmd
cd the_sun_never_sets
python main.py
```
tkinter is bundled with the official Windows Python installer.

---

## Save System
The game saves to `~/.the_sun_never_sets/save.db` (SQLite).
All NPC states, player stats, estate, quests, market, and world flags are serialised as JSON blobs.

---

## Extending the Game

The codebase is intentionally modular:

| What to add | Where |
|---|---|
| New NPCs | `ai/characters.py` → `create_seed_npcs()` |
| New quests | `quests.py` → `build_quest_catalogue()` |
| New gadgets | `inventory.py` → `BLUEPRINTS` and `GADGET_STATS` |
| New districts | `world.py` → `DISTRICTS` |
| New commodities | `ai/economy_ai.py` → `Market.__init__()` |
| Graphics (Pygame/PyQt5) | Replace `gui.py` entirely — core API unchanged |
| Multiplayer | Add a network layer that calls `GameState` methods remotely |

---

## AI & Probability Design Notes

### NPC Decision Weighting
Each NPC's action probability this turn:
```python
P(scheme)       ∝ cunning × 0.4 + ambition × 0.3 − honesty × 0.2
P(spread_gossip) ∝ (volatility + cunning) × 0.3
P(seek_alliance) ∝ loyalty × 0.5  [only if rel > 20]
P(idle)          = 30.0 (baseline)
```
These are unnormalised weights fed to `random.choices()`.

### Gossip Propagation
```
P(expose_secret per turn) = (100 − loyalty) / 150
P(chain propagation)      = 0.15  [volatile NPCs only]
```

### Market Price Model (Ornstein-Uhlenbeck)
```
Δprice = θ(μ − price) + σε,  ε ~ N(0,1)
θ ∈ [0.05, 0.15]  (reversion speed)
σ ∈ [1.5, 10]     (per-commodity volatility)
```
Random shocks (P = 0.02/turn) apply a price multiplier of ×0.7–×1.6.

---

*"The sun never sets on the British Empire — nor on the ambitions of those who serve it."*
