"""
utils.py — Utility functions, logging, and probability helpers.

All random/weighted choices route through here so the rest of the codebase
stays clean.  The EventBus is a lightweight pub/sub bus that lets every module
fire events without importing each other.
"""
from __future__ import annotations

import logging
import random
from collections import defaultdict
from datetime import datetime
from typing import Any, Callable

# ── Logging ──────────────────────────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter("[%(asctime)s] %(levelname)s %(name)s — %(message)s",
                              datefmt="%H:%M:%S")
        )
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
    return logger

log = get_logger("utils")


# ── Weighted randomness ───────────────────────────────────────────────────────

def weighted_choice(options: list[tuple[Any, float]]) -> Any:
    """
    Pick one item from a list of (value, weight) tuples.
    Weights do NOT need to sum to 1; they are normalised internally.

    Example:
        weighted_choice([("scandal", 0.1), ("gossip", 0.5), ("nothing", 2.0)])
    """
    if not options:
        return None
    items, weights = zip(*options)
    return random.choices(items, weights=weights, k=1)[0]


def clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    """Clamp a float between lo and hi."""
    return max(lo, min(hi, value))


def roll(probability: float) -> bool:
    """Return True with the given probability (0.0–1.0)."""
    return random.random() < probability


def gaussian_stat(mean: float = 50.0, sigma: float = 15.0) -> float:
    """Generate a personality stat from a Gaussian distribution, clamped 0–100."""
    return clamp(random.gauss(mean, sigma))


# ── Simple event bus ─────────────────────────────────────────────────────────

class EventBus:
    """
    Publish/subscribe bus.  Any module can call EventBus.emit("event_name", data)
    and any other module that subscribed with EventBus.subscribe("event_name", fn)
    will receive the call.

    This keeps modules decoupled: ai/social_ai.py can fire "gossip_spread" events
    without knowing that gui.py wants to show a popup.
    """

    _listeners: dict[str, list[Callable]] = defaultdict(list)

    @classmethod
    def subscribe(cls, event: str, fn: Callable) -> None:
        cls._listeners[event].append(fn)

    @classmethod
    def unsubscribe(cls, event: str, fn: Callable) -> None:
        try:
            cls._listeners[event].remove(fn)
        except ValueError:
            pass

    @classmethod
    def emit(cls, event: str, data: Any = None) -> None:
        for fn in list(cls._listeners[event]):
            try:
                fn(data)
            except Exception as exc:
                log.error("EventBus handler error for %s: %s", event, exc)


# ── Victorian date helper ─────────────────────────────────────────────────────

MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]


class VictorianDate:
    """
    In-game calendar.  Each 'turn' represents one game-day.
    The game starts on 1 January 1887.
    """

    def __init__(self, day: int = 1, month: int = 1, year: int = 1887):
        self.day = day
        self.month = month
        self.year = year

    def advance(self, days: int = 1) -> None:
        for _ in range(days):
            self.day += 1
            days_in_month = 30 if self.month in {4, 6, 9, 11} else (
                28 if self.month == 2 else 31)
            if self.day > days_in_month:
                self.day = 1
                self.month += 1
                if self.month > 12:
                    self.month = 1
                    self.year += 1

    def __str__(self) -> str:
        return f"{self.day} {MONTHS[self.month - 1]} {self.year}"

    def to_dict(self) -> dict:
        return {"day": self.day, "month": self.month, "year": self.year}

    @classmethod
    def from_dict(cls, d: dict) -> "VictorianDate":
        return cls(d["day"], d["month"], d["year"])


# ── Misc ─────────────────────────────────────────────────────────────────────

def title_case_name(name: str) -> str:
    """Apply Victorian-style honorific if needed."""
    return name if name.startswith(("Lord", "Lady", "Sir", "Dr", "Prof")) else name


def format_gold(amount: int) -> str:
    """Display gold in pounds-and-shillings style."""
    pounds = amount // 100
    shillings = amount % 100
    return f"£{pounds}.{shillings:02d}"
