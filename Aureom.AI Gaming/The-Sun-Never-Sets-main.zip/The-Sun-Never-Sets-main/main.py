"""
main.py — The Sun Never Sets — Game Launcher.

Usage:
    python main.py            # GUI mode (requires tkinter)
    python main.py --console  # Text console mode

The launcher:
  1. Creates the GameState (initialises all subsystems).
  2. Seeds starter resources and blueprints for the player.
  3. Detects whether tkinter is available and falls back to console mode.
  4. Starts the UI loop.
"""
from __future__ import annotations

import sys
import argparse


def _seed_new_game(game) -> None:
    """Give the player a small starting kit of resources and a free blueprint."""
    p = game.player
    inv = p.inventory

    # Starting resources (modest gentleman's workshop)
    inv.add_resource("coal",   5)
    inv.add_resource("iron",   3)
    inv.add_resource("copper", 4)
    inv.add_resource("aether", 1)

    # First blueprint — free chronometer
    inv.learn_blueprint("bp_chronometer")
    p.log_event("You inherit your grandfather's workshop notes and a set of copper ingots.")
    p.log_event("The year is 1887. London awaits.")


def main() -> None:
    parser = argparse.ArgumentParser(description="The Sun Never Sets")
    parser.add_argument("--console", action="store_true",
                        help="Force text console mode (no GUI)")
    parser.add_argument("--no-load", action="store_true",
                        help="Start a fresh game even if a save exists")
    args = parser.parse_args()

    # ── Initialise game state ─────────────────────────────────────────────────
    from brass_and_crown.core import GameState
    game = GameState()

    # Auto-load existing save unless --no-load
    if not args.no_load and game.save_exists():
        print("► Save file found. Loading…")
        game.load()
    else:
        print("► Starting new game.")
        _seed_new_game(game)

    # ── Launch UI ─────────────────────────────────────────────────────────────
    if args.console:
        _run_console(game)
        return

    try:
        import tkinter as tk  # noqa: F401 — test availability
        _run_gui(game)
    except ImportError:
        print("⚠  tkinter not available — falling back to console mode.")
        _run_console(game)


def _run_gui(game) -> None:
    from brass_and_crown.gui import SteampunkApp
    app = SteampunkApp(game)
    app.run()


def _run_console(game) -> None:
    from brass_and_crown.gui import ConsoleUI
    ConsoleUI(game).run()


if __name__ == "__main__":
    main()
