"""
world.py — Locations, city map, travel logic, and world flags.

London is divided into districts, each with unique properties:
  • NPCs are associated with districts (their preferred haunts).
  • Some quests require visiting specific districts.
  • Travel takes turns unless the player owns an Ornithopter / fast-travel unlock.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import roll, log


@dataclass
class District:
    district_id: str
    name: str
    description: str
    danger_level: float    # 0.0 safe → 1.0 extremely dangerous
    npc_ids: list[str] = field(default_factory=list)
    available_events: list[str] = field(default_factory=list)
    travel_cost: int = 0   # shillings; cab fare etc.
    # x, y grid position (for simple map display)
    grid_x: int = 0
    grid_y: int = 0


DISTRICTS: list[District] = [
    District("mayfair",     "Mayfair",
             "The heart of aristocratic society. Galas, clubs, and carriages.",
             danger_level=0.05, grid_x=2, grid_y=2,
             npc_ids=["lord_ashworth", "lady_fairfax"],
             available_events=["gala_season", "charity_ball"]),

    District("westminster",  "Westminster",
             "Parliament, politics, and protocol.",
             danger_level=0.05, grid_x=2, grid_y=3,
             npc_ids=["reverend_holt"],
             available_events=["parliamentary_dinner"]),

    District("clerkenwell",  "Clerkenwell",
             "The watchmakers' and inventors' quarter.",
             danger_level=0.15, grid_x=3, grid_y=2,
             npc_ids=["dr_cogsworth"],
             available_events=["inventors_exposition"],
             travel_cost=20),

    District("whitechapel",  "Whitechapel",
             "Industrial slums. Dangerous but rich with opportunity.",
             danger_level=0.4, grid_x=4, grid_y=2,
             available_events=[],
             travel_cost=30),

    District("southwark",    "Southwark",
             "Docks and warehouses south of the Thames.",
             danger_level=0.3, grid_x=3, grid_y=4,
             available_events=[],
             travel_cost=25),

    District("kensington",   "Kensington",
             "Museums, exhibitions, and the great park.",
             danger_level=0.05, grid_x=1, grid_y=2,
             available_events=["inventors_exposition"],
             travel_cost=15),

    District("limehouse",    "Limehouse",
             "The East End docks. Opium dens, smugglers, and sailors.",
             danger_level=0.6, grid_x=5, grid_y=2,
             npc_ids=["vivienne_blackthorn"],
             travel_cost=40),
]

DISTRICT_INDEX: dict[str, District] = {d.district_id: d for d in DISTRICTS}


class World:
    """
    The game world state: current player location, visited flags, and exploration log.
    """

    def __init__(self) -> None:
        self.current_district_id: str = "mayfair"  # player starts at home
        self.flags: dict[str, bool] = {}           # e.g. "visited_clerkenwell": True
        self.travel_log: list[str] = []
        self.discovered_opportunities: list[str] = []

    # ── Location helpers ──────────────────────────────────────────────────────

    @property
    def current_district(self) -> District:
        return DISTRICT_INDEX[self.current_district_id]

    def travel_to(self, district_id: str, player_gold: int,
                  has_fast_travel: bool = False) -> tuple[bool, str, int]:
        """
        Attempt to travel to district.
        Returns (success, message, gold_cost).
        """
        dest = DISTRICT_INDEX.get(district_id)
        if not dest:
            return False, "Unknown district.", 0

        if dest.district_id == self.current_district_id:
            return False, f"You are already in {dest.name}.", 0

        cost = 0 if has_fast_travel else dest.travel_cost
        if player_gold < cost:
            return False, f"You lack the cab fare ({cost} shillings).", 0

        self.current_district_id = district_id
        flag_key = f"visited_{district_id}"
        self.flags[flag_key] = True
        self.travel_log.append(f"Travelled to {dest.name}.")

        msg = f"You travel to {dest.name}. {dest.description}"

        # Danger roll
        if roll(dest.danger_level * 0.5):
            msg += "\n⚠ The streets feel dangerous tonight."

        return True, msg, cost

    def explore_current(self) -> Optional[str]:
        """
        Explore the current district.  Small chance of discovering something.
        Returns a discovery string or None.
        """
        district = self.current_district
        discoveries = {
            "whitechapel": [
                "You find a half-burned ledger implicating Ashworth's foreman.",
                "A street preacher warns of a factory explosion plot.",
            ],
            "limehouse": [
                "A foreign sailor offers to sell you a rare aether crystal.",
                "You spot Blackthorn exchanging documents with an unknown figure.",
            ],
            "clerkenwell": [
                "A watchmaker's apprentice points you toward Cogsworth's hidden workshop.",
                "A poster announces a new Analytical Engine design competition.",
            ],
            "southwark": [
                "A dock worker mentions smuggled automata parts arriving tonight.",
            ],
        }
        options = discoveries.get(district.district_id, [])
        if options and roll(0.3):
            discovery = options[0]  # rotate or random in full game
            self.discovered_opportunities.append(discovery)
            return discovery
        return None

    def get_district_npcs(self, npc_map: dict) -> list:
        """Return NPC objects present in current district."""
        ids = self.current_district.npc_ids
        return [npc_map[nid] for nid in ids if nid in npc_map]

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "current_district_id": self.current_district_id,
            "flags": self.flags,
            "travel_log": self.travel_log[-30:],
        }

    def from_dict(self, d: dict) -> None:
        self.current_district_id = d.get("current_district_id", "mayfair")
        self.flags = d.get("flags", {})
        self.travel_log = d.get("travel_log", [])
