"""
conditions.py — Status Conditions / Buffs / Debuffs.

Conditions are temporary or permanent modifiers applied to the player.
They have a duration (turns remaining, or -1 for permanent) and fire
effects each turn via the tick() method.

Condition categories:
  AILMENT    — physical illness, injuries
  SOCIAL     — scandal, fame, stigma
  MENTAL     — obsession, doubt, inspiration
  ECONOMIC   — credit rating changes, trade embargoes

Conditions can stack (multiple active at once) but the same condition_id
can only be active once.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, TYPE_CHECKING

from brass_and_crown.utils import roll, log, EventBus

if TYPE_CHECKING:
    from brass_and_crown.player import Player


# ── Condition definition ──────────────────────────────────────────────────────

@dataclass
class Condition:
    condition_id: str
    name: str
    description: str
    category: str
    duration: int              # turns remaining; -1 = permanent until cured
    # Per-turn stat deltas (applied while condition is active)
    health_per_turn: float = 0.0
    influence_per_turn: float = 0.0
    reputation_per_turn: float = 0.0
    gold_per_turn: int = 0
    # Stat multipliers (on top of flat delta)
    charm_mult: float = 1.0
    cunning_mult: float = 1.0
    # Text shown in UI
    icon: str = "⚠"
    # Cure conditions
    cure_cost_gold: int = 0      # 0 means can't be bought; cures via event
    auto_cure_threshold: float = 0.0  # cures when health exceeds this value

    @property
    def is_permanent(self) -> bool:
        return self.duration == -1

    def tick(self, player: "Player") -> Optional[str]:
        """
        Apply one turn of effects to the player.
        Returns a narrative message if something notable happened,
        or None if uneventful.
        Decrements duration (unless permanent).
        """
        player.adjust_health(self.health_per_turn)
        player.gain_influence(self.influence_per_turn) if self.influence_per_turn else None
        player.adjust_reputation(self.reputation_per_turn)
        if self.gold_per_turn < 0:
            player.spend_gold(abs(self.gold_per_turn))
        elif self.gold_per_turn > 0:
            player.earn_gold(self.gold_per_turn, self.name)

        if not self.is_permanent:
            self.duration -= 1

        # Auto-cure check
        if self.auto_cure_threshold > 0 and player.health >= self.auto_cure_threshold:
            return f"✓ You have recovered from {self.name}."

        if self.duration == 0:
            return f"✓ {self.name} has passed."

        return None

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}

    @classmethod
    def from_dict(cls, d: dict) -> "Condition":
        return cls(**d)


# ── Condition catalogue ───────────────────────────────────────────────────────

CONDITION_CATALOGUE: dict[str, dict] = {
    # ── Ailments ──────────────────────────────────────────────────────────────
    "london_fog_cough": dict(
        condition_id="london_fog_cough",
        name="London Fog Cough",
        description="The perpetual damp has settled in your lungs.",
        category="AILMENT",
        duration=10,
        health_per_turn=-1.0,
        icon="🤧",
        auto_cure_threshold=80.0,
        cure_cost_gold=200,
    ),
    "duelling_wound": dict(
        condition_id="duelling_wound",
        name="Duelling Wound",
        description="A flesh wound from a recent encounter. Painful but survivable.",
        category="AILMENT",
        duration=8,
        health_per_turn=-2.0,
        charm_mult=0.85,
        icon="🩸",
        auto_cure_threshold=90.0,
        cure_cost_gold=300,
    ),
    "aether_poisoning": dict(
        condition_id="aether_poisoning",
        name="Aether Poisoning",
        description="Overexposure to refined aether has unsettling effects.",
        category="AILMENT",
        duration=15,
        health_per_turn=-1.5,
        cunning_mult=1.15,    # bizarre cognitive enhancement while it lasts
        charm_mult=0.9,
        icon="💜",
        cure_cost_gold=500,
    ),

    # ── Social ────────────────────────────────────────────────────────────────
    "minor_scandal": dict(
        condition_id="minor_scandal",
        name="Minor Scandal",
        description="Rumours are circulating. Nothing proven — yet.",
        category="SOCIAL",
        duration=14,
        reputation_per_turn=-0.5,
        influence_per_turn=-0.2,
        icon="📰",
    ),
    "major_scandal": dict(
        condition_id="major_scandal",
        name="Major Scandal",
        description="Your name is on every tongue — and not favourably.",
        category="SOCIAL",
        duration=21,
        reputation_per_turn=-1.5,
        influence_per_turn=-0.5,
        icon="💢",
    ),
    "celebrated": dict(
        condition_id="celebrated",
        name="Celebrated",
        description="Society is talking about you — in the best possible terms.",
        category="SOCIAL",
        duration=7,
        reputation_per_turn=0.5,
        influence_per_turn=0.3,
        charm_mult=1.1,
        icon="✨",
    ),
    "persona_non_grata": dict(
        condition_id="persona_non_grata",
        name="Persona Non Grata",
        description="You have been explicitly blacklisted from certain circles.",
        category="SOCIAL",
        duration=-1,   # permanent until cleared
        influence_per_turn=-0.3,
        charm_mult=0.8,
        icon="🚫",
        cure_cost_gold=2_000,
    ),

    # ── Mental ────────────────────────────────────────────────────────────────
    "inspired": dict(
        condition_id="inspired",
        name="Inspired",
        description="A sudden clarity of thought accelerates your work.",
        category="MENTAL",
        duration=5,
        influence_per_turn=0.5,
        cunning_mult=1.2,
        icon="💡",
    ),
    "social_fatigue": dict(
        condition_id="social_fatigue",
        name="Social Fatigue",
        description="Too many galas, too little sleep. You need rest.",
        category="MENTAL",
        duration=6,
        charm_mult=0.8,
        cunning_mult=0.9,
        health_per_turn=-0.5,
        icon="😴",
    ),
    "paranoid": dict(
        condition_id="paranoid",
        name="Paranoid",
        description="Someone is watching you. Or are they?",
        category="MENTAL",
        duration=10,
        cunning_mult=1.1,    # useful but socially isolating
        charm_mult=0.75,
        influence_per_turn=-0.3,
        icon="👁",
    ),

    # ── Economic ──────────────────────────────────────────────────────────────
    "credit_crisis": dict(
        condition_id="credit_crisis",
        name="Credit Crisis",
        description="Your debts are becoming public knowledge.",
        category="ECONOMIC",
        duration=20,
        gold_per_turn=-50,
        reputation_per_turn=-0.5,
        icon="📉",
    ),
    "fortunate_windfall": dict(
        condition_id="fortunate_windfall",
        name="Fortunate Windfall",
        description="A lucky streak in investments is paying dividends.",
        category="ECONOMIC",
        duration=7,
        gold_per_turn=100,
        icon="💰",
    ),
}


def make_condition(condition_id: str) -> Optional[Condition]:
    template = CONDITION_CATALOGUE.get(condition_id)
    if not template:
        return None
    return Condition(**template)


# ── Conditions manager ────────────────────────────────────────────────────────

class ConditionsManager:
    """Manages all active conditions on the player."""

    def __init__(self) -> None:
        self._active: list[Condition] = []

    def apply(self, condition_id: str, player: "Player") -> Optional[str]:
        """
        Apply a condition by ID.  If the condition is already active, do nothing.
        Returns a narrative string or None.
        """
        if any(c.condition_id == condition_id for c in self._active):
            return None
        cond = make_condition(condition_id)
        if not cond:
            log.warning("Unknown condition: %s", condition_id)
            return None
        self._active.append(cond)
        EventBus.emit("condition_applied", {"condition": cond, "player": player})
        msg = f"{cond.icon} You have contracted: {cond.name} — {cond.description}"
        log.info("Condition applied: %s", condition_id)
        return msg

    def cure(self, condition_id: str, player: "Player") -> tuple[bool, str]:
        """
        Attempt to cure a condition by spending gold.
        Returns (success, message).
        """
        cond = next((c for c in self._active if c.condition_id == condition_id), None)
        if not cond:
            return False, "You do not have that condition."
        if cond.cure_cost_gold == 0:
            return False, "This condition cannot be cured with gold alone."
        if not player.spend_gold(cond.cure_cost_gold):
            return False, f"Insufficient gold ({cond.cure_cost_gold} shillings required)."
        self._active.remove(cond)
        return True, f"You have been treated for {cond.name}."

    def tick(self, player: "Player") -> list[str]:
        """Apply all conditions for one turn. Remove expired ones."""
        messages = []
        expired = []
        for cond in self._active:
            msg = cond.tick(player)
            if msg:
                messages.append(msg)
            if not cond.is_permanent and cond.duration <= 0:
                expired.append(cond)
        for c in expired:
            self._active.remove(c)
        return messages

    def active_conditions(self) -> list[Condition]:
        return list(self._active)

    def charm_multiplier(self) -> float:
        mult = 1.0
        for c in self._active:
            mult *= c.charm_mult
        return mult

    def cunning_multiplier(self) -> float:
        mult = 1.0
        for c in self._active:
            mult *= c.cunning_mult
        return mult

    # ── Probability triggers ──────────────────────────────────────────────────

    def check_triggers(self, player: "Player", context: dict) -> list[str]:
        """
        Roll for conditions that might arise naturally from context.
        context: {"visited_danger": float, "gala_count": int, "turns": int}
        """
        messages = []

        # Danger-zone illness
        if roll(context.get("visited_danger", 0) * 0.15):
            msg = self.apply("london_fog_cough", player)
            if msg:
                messages.append(msg)

        # Social fatigue from too many galas
        if context.get("gala_count", 0) >= 3 and roll(0.25):
            msg = self.apply("social_fatigue", player)
            if msg:
                messages.append(msg)

        # Aether exposure
        if context.get("aether_exposure", False) and roll(0.1):
            msg = self.apply("aether_poisoning", player)
            if msg:
                messages.append(msg)

        return messages

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {"active": [c.to_dict() for c in self._active]}

    def from_dict(self, d: dict) -> None:
        self._active = [Condition.from_dict(c) for c in d.get("active", [])]
