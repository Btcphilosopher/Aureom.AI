"""
inventory.py — Gadgets, inventions, resources, and crafting.

The steampunk crafting system works in two stages:
  1. Blueprint acquisition: player discovers or buys a blueprint.
  2. Crafting: player spends resources + time (turns) to build the gadget.

Each gadget provides bonuses to player stats when equipped or used.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import log, roll


# ── Resource ──────────────────────────────────────────────────────────────────

RESOURCE_TYPES = ["coal", "iron", "copper", "aether", "luxury", "automata", "gold"]


@dataclass
class Resource:
    name: str
    quantity: int = 0

    def add(self, amount: int) -> None:
        self.quantity = max(0, self.quantity + amount)

    def spend(self, amount: int) -> bool:
        if self.quantity >= amount:
            self.quantity -= amount
            return True
        return False


# ── Blueprint / Gadget ────────────────────────────────────────────────────────

@dataclass
class Blueprint:
    blueprint_id: str
    name: str
    description: str
    resource_cost: dict[str, int]   # {resource_name: quantity}
    turns_to_craft: int
    rarity: str = "common"          # common / rare / legendary


@dataclass
class Gadget:
    gadget_id: str
    name: str
    description: str
    bonus: dict[str, float]         # {stat_name: delta}  e.g. {"influence": 5}
    equipped: bool = False
    durability: int = 100

    def use_effect(self) -> str:
        """Describe what happens when this gadget is activated."""
        effects = []
        for stat, val in self.bonus.items():
            effects.append(f"{stat} {'+'  if val >= 0 else ''}{val:.0f}")
        return f"{self.name} activates: {', '.join(effects)}."

    def degrade(self) -> bool:
        """Reduce durability by random wear. Returns True if item breaks."""
        self.durability -= random.randint(1, 5)
        return self.durability <= 0

    def to_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> "Gadget":
        return cls(**d)


# ── Blueprints catalogue ──────────────────────────────────────────────────────

BLUEPRINTS: list[Blueprint] = [
    Blueprint(
        "bp_chronometer",
        "Precision Chronometer",
        "A clockwork timepiece of exceptional accuracy. Grants planning bonuses.",
        resource_cost={"copper": 3, "iron": 2},
        turns_to_craft=3,
        rarity="common",
    ),
    Blueprint(
        "bp_aether_pistol",
        "Aether-Pistol",
        "Fires bolts of condensed aether energy. Useful in duels.",
        resource_cost={"aether": 5, "copper": 4, "iron": 3},
        turns_to_craft=6,
        rarity="rare",
    ),
    Blueprint(
        "bp_analytical_engine",
        "Pocket Analytical Engine",
        "A miniaturised Babbage engine. Boosts economy management.",
        resource_cost={"automata": 4, "copper": 6, "aether": 2},
        turns_to_craft=10,
        rarity="rare",
    ),
    Blueprint(
        "bp_ornithopter",
        "Personal Ornithopter",
        "A steam-powered flying device. Enables faster city travel.",
        resource_cost={"iron": 8, "copper": 5, "aether": 3, "coal": 4},
        turns_to_craft=14,
        rarity="legendary",
    ),
    Blueprint(
        "bp_persuasion_locket",
        "Resonance Locket",
        "Emits subtle aether vibrations that calm and sway the listener.",
        resource_cost={"aether": 6, "copper": 2},
        turns_to_craft=5,
        rarity="rare",
    ),
]

BLUEPRINT_INDEX: dict[str, Blueprint] = {b.blueprint_id: b for b in BLUEPRINTS}

# Final stats for each crafted gadget
GADGET_STATS: dict[str, dict] = {
    "bp_chronometer":      {"influence": 2, "planning_bonus": 5},
    "bp_aether_pistol":    {"duel_power": 20, "intimidation": 10},
    "bp_analytical_engine": {"economy_bonus": 15, "influence": 3},
    "bp_ornithopter":      {"travel_speed": 2, "exploration_bonus": 10},
    "bp_persuasion_locket": {"charm_bonus": 15, "influence": 5},
}


# ── Inventory ─────────────────────────────────────────────────────────────────

class Inventory:
    """Tracks resources, blueprints, gadgets, and crafting progress."""

    def __init__(self) -> None:
        self.resources: dict[str, Resource] = {
            name: Resource(name) for name in RESOURCE_TYPES
        }
        self.blueprints: list[Blueprint] = []
        self.gadgets: list[Gadget] = []
        self._crafting_queue: list[dict] = []  # {blueprint_id, turns_remaining}

    # ── Resources ─────────────────────────────────────────────────────────────

    def add_resource(self, name: str, amount: int) -> None:
        if name in self.resources:
            self.resources[name].add(amount)

    def spend_resource(self, name: str, amount: int) -> bool:
        r = self.resources.get(name)
        return r.spend(amount) if r else False

    def has_resources(self, cost: dict[str, int]) -> bool:
        return all(
            self.resources.get(k, Resource(k)).quantity >= v
            for k, v in cost.items()
        )

    # ── Blueprints ────────────────────────────────────────────────────────────

    def learn_blueprint(self, blueprint_id: str) -> bool:
        bp = BLUEPRINT_INDEX.get(blueprint_id)
        if not bp:
            return False
        if bp in self.blueprints:
            return False
        self.blueprints.append(bp)
        log.info("Blueprint learned: %s", bp.name)
        return True

    # ── Crafting ──────────────────────────────────────────────────────────────

    def start_crafting(self, blueprint_id: str) -> tuple[bool, str]:
        bp = BLUEPRINT_INDEX.get(blueprint_id)
        if not bp:
            return False, "Unknown blueprint."
        if bp not in self.blueprints:
            return False, "You do not have that blueprint."
        if not self.has_resources(bp.resource_cost):
            short = {k: v - self.resources.get(k, Resource(k)).quantity
                     for k, v in bp.resource_cost.items()
                     if self.resources.get(k, Resource(k)).quantity < v}
            return False, f"Insufficient resources: {short}"

        # Deduct resources
        for res, qty in bp.resource_cost.items():
            self.spend_resource(res, qty)

        self._crafting_queue.append({
            "blueprint_id": blueprint_id,
            "turns_remaining": bp.turns_to_craft,
        })
        return True, f"Crafting {bp.name} — {bp.turns_to_craft} turns remaining."

    def advance_crafting(self) -> list[str]:
        """
        Called each turn to tick down crafting timers.
        Returns list of completion messages.
        """
        completed = []
        still_crafting = []
        for job in self._crafting_queue:
            job["turns_remaining"] -= 1
            if job["turns_remaining"] <= 0:
                gadget = self._complete_craft(job["blueprint_id"])
                if gadget:
                    completed.append(f"✦ Your {gadget.name} is complete!")
                    self.gadgets.append(gadget)
            else:
                still_crafting.append(job)
        self._crafting_queue = still_crafting
        return completed

    def _complete_craft(self, blueprint_id: str) -> Optional[Gadget]:
        bp = BLUEPRINT_INDEX.get(blueprint_id)
        if not bp:
            return None
        stats = GADGET_STATS.get(blueprint_id, {})
        gadget = Gadget(
            gadget_id=f"{blueprint_id}_{id(self)}",
            name=bp.name,
            description=bp.description,
            bonus=stats,
        )
        log.info("Gadget crafted: %s", gadget.name)
        return gadget

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "resources": {k: v.quantity for k, v in self.resources.items()},
            "blueprints": [b.blueprint_id for b in self.blueprints],
            "gadgets": [g.to_dict() for g in self.gadgets],
            "crafting_queue": self._crafting_queue,
        }

    def from_dict(self, d: dict) -> None:
        for k, v in d.get("resources", {}).items():
            if k in self.resources:
                self.resources[k].quantity = v
        for bp_id in d.get("blueprints", []):
            self.learn_blueprint(bp_id)
        self.gadgets = [Gadget.from_dict(g) for g in d.get("gadgets", [])]
        self._crafting_queue = d.get("crafting_queue", [])
