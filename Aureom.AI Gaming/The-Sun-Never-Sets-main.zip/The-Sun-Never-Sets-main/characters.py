"""
ai/characters.py — NPC definitions, personality model, and decision engine.

Each NPC has a trait vector (0–100 floats) that drives their probability
distributions for actions, dialogue tone, and social alignment.

Trait model (Big-Five inspired, Victorian-flavoured):
  ambition      — how hard they pursue power/wealth
  honesty       — likelihood of truthful / fair behaviour
  loyalty       — resistance to betrayal
  cunning       — use of indirect/deceptive strategies
  charm         — social persuasion bonus
  volatility    — emotional instability / scandal risk
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import gaussian_stat, weighted_choice, roll, log


# ── Trait helpers ─────────────────────────────────────────────────────────────

TRAIT_NAMES = ["ambition", "honesty", "loyalty", "cunning", "charm", "volatility"]


def random_traits() -> dict[str, float]:
    return {t: gaussian_stat() for t in TRAIT_NAMES}


def archetype_traits(archetype: str) -> dict[str, float]:
    """
    Pre-tuned trait bundles so NPCs feel distinct.
    Values are means fed to gaussian_stat with sigma=10.
    """
    presets = {
        "schemer":     dict(ambition=85, honesty=20, loyalty=25, cunning=90, charm=60, volatility=40),
        "noble":       dict(ambition=55, honesty=60, loyalty=75, cunning=40, charm=70, volatility=20),
        "industrialist": dict(ambition=80, honesty=50, loyalty=50, cunning=65, charm=55, volatility=30),
        "rake":        dict(ambition=40, honesty=35, loyalty=30, cunning=55, charm=90, volatility=75),
        "reformer":    dict(ambition=65, honesty=85, loyalty=70, cunning=40, charm=60, volatility=20),
        "spy":         dict(ambition=70, honesty=10, loyalty=50, cunning=95, charm=65, volatility=35),
    }
    base = presets.get(archetype, {t: 50 for t in TRAIT_NAMES})
    return {t: gaussian_stat(mean=v, sigma=10) for t, v in base.items()}


# ── NPC dataclass ─────────────────────────────────────────────────────────────

@dataclass
class NPC:
    """
    A fully-stateful NPC citizen.

    Relationships is a dict mapping other NPC / player IDs → float (-100 to +100).
    Positive = friendly/allied, negative = rival/hostile.

    secrets is a list of strings that can surface through gossip events.
    """
    npc_id: str
    name: str
    title: str
    archetype: str
    traits: dict[str, float] = field(default_factory=dict)
    relationships: dict[str, float] = field(default_factory=dict)
    secrets: list[str] = field(default_factory=list)
    gold: int = 500
    influence: float = 50.0
    faction: str = "neutral"
    mood: str = "composed"          # composed / pleased / suspicious / hostile
    _memory: list[str] = field(default_factory=list)   # recent interaction log

    # ── Initialisation ────────────────────────────────────────────────────────

    def __post_init__(self) -> None:
        if not self.traits:
            self.traits = archetype_traits(self.archetype)
        log.debug("NPC created: %s (%s)", self.name, self.archetype)

    # ── Relationship helpers ──────────────────────────────────────────────────

    def get_relationship(self, target_id: str) -> float:
        """Return relationship value toward target, defaulting to neutral."""
        return self.relationships.get(target_id, 0.0)

    def adjust_relationship(self, target_id: str, delta: float) -> None:
        current = self.relationships.get(target_id, 0.0)
        self.relationships[target_id] = max(-100, min(100, current + delta))

    # ── Personality-driven decisions ──────────────────────────────────────────

    def decide_action(self, context: dict) -> str:
        """
        Given a context dict (current turn data), return the NPC's most-likely
        action string.  Action probabilities are modulated by traits.

        Context keys expected: 'player_influence', 'current_event', 'turn'
        """
        player_influence = context.get("player_influence", 50)
        rel = self.get_relationship("player")

        # Build weighted action pool
        options: list[tuple[str, float]] = []

        # Socialise — driven by charm & relationship
        options.append(("socialise", max(5, self.traits["charm"] * 0.5 + rel * 0.3)))

        # Scheme — driven by cunning & ambition, dampened by honesty
        scheme_w = self.traits["cunning"] * 0.4 + self.traits["ambition"] * 0.3 - self.traits["honesty"] * 0.2
        if self.traits["ambition"] > 60:
            options.append(("scheme", max(1, scheme_w)))

        # Spread gossip — volatility + cunning
        gossip_w = (self.traits["volatility"] + self.traits["cunning"]) * 0.3
        if roll(0.3):
            options.append(("spread_gossip", max(1, gossip_w)))

        # Seek alliance — loyalty + rel with player
        if rel > 20:
            options.append(("seek_alliance", max(5, self.traits["loyalty"] * 0.5)))

        # Do nothing / attend to own affairs
        options.append(("idle", 30.0))

        choice = weighted_choice(options)
        self._remember(f"Turn {context.get('turn', '?')}: decided to {choice}")
        return choice

    def reaction_to_event(self, event_type: str) -> str:
        """
        Return how this NPC reacts to a game event.
        Returns a mood string and optionally alters internal state.
        """
        reactions = {
            "scandal":     self._react_scandal,
            "gala":        self._react_gala,
            "factory_accident": self._react_accident,
            "gossip":      self._react_gossip,
        }
        fn = reactions.get(event_type)
        if fn:
            return fn()
        return "indifferent"

    def _react_scandal(self) -> str:
        if self.traits["honesty"] > 65:
            self.mood = "hostile"
            return "outraged"
        elif self.traits["cunning"] > 65:
            self.mood = "suspicious"
            return "intrigued"
        return "amused"

    def _react_gala(self) -> str:
        if self.traits["charm"] > 60:
            self.mood = "pleased"
            return "delighted"
        return "composed"

    def _react_accident(self) -> str:
        if self.traits["honesty"] > 70:
            self.mood = "hostile"
            return "concerned"
        return "indifferent"

    def _react_gossip(self) -> str:
        if self.traits["volatility"] > 60:
            self.mood = "suspicious"
            return "agitated"
        return "curious"

    # ── Memory / dialogue ─────────────────────────────────────────────────────

    def _remember(self, event: str) -> None:
        self._memory.append(event)
        if len(self._memory) > 20:
            self._memory.pop(0)

    def generate_greeting(self, player_name: str) -> str:
        """Return a contextual greeting based on mood and relationship."""
        rel = self.get_relationship("player")
        if self.mood == "hostile":
            return f"{self.name} turns away with a cold sneer."
        if rel > 60:
            return f"{self.title} {self.name} smiles warmly. \"A pleasure as always, {player_name}.\""
        if rel < -30:
            return f"{self.title} {self.name} nods curtly. \"You have nerve showing up here.\""
        return f"{self.title} {self.name} acknowledges you with a polite nod."

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "npc_id": self.npc_id,
            "name": self.name,
            "title": self.title,
            "archetype": self.archetype,
            "traits": self.traits,
            "relationships": self.relationships,
            "secrets": self.secrets,
            "gold": self.gold,
            "influence": self.influence,
            "faction": self.faction,
            "mood": self.mood,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "NPC":
        return cls(**{k: v for k, v in d.items() if k != "_memory"})


# ── Seed NPCs ─────────────────────────────────────────────────────────────────

def create_seed_npcs() -> list[NPC]:
    """Return a set of handcrafted NPCs to populate the starting world."""
    npcs = [
        NPC(
            npc_id="lord_ashworth",
            name="Ashworth",
            title="Lord",
            archetype="schemer",
            secrets=["Embezzles railway profits", "Has a bastard heir"],
            gold=12_000,
            influence=78.0,
            faction="tories",
            relationships={"player": -15.0},
        ),
        NPC(
            npc_id="lady_fairfax",
            name="Fairfax",
            title="Lady",
            archetype="noble",
            secrets=["Sympathises with the suffragists"],
            gold=8_000,
            influence=65.0,
            faction="moderates",
            relationships={"player": 20.0},
        ),
        NPC(
            npc_id="dr_cogsworth",
            name="Cogsworth",
            title="Dr",
            archetype="industrialist",
            secrets=["Stole blueprints from the Royal Institute"],
            gold=5_000,
            influence=50.0,
            faction="industrialists",
            relationships={"player": 5.0},
        ),
        NPC(
            npc_id="vivienne_blackthorn",
            name="Blackthorn",
            title="Miss",
            archetype="spy",
            secrets=["Works for a foreign intelligence service"],
            gold=3_000,
            influence=40.0,
            faction="neutral",
            relationships={"player": 0.0, "lord_ashworth": 30.0},
        ),
        NPC(
            npc_id="reverend_holt",
            name="Holt",
            title="Reverend",
            archetype="reformer",
            secrets=["Has gambling debts"],
            gold=800,
            influence=35.0,
            faction="reformers",
            relationships={"player": 10.0},
        ),
    ]
    return npcs
