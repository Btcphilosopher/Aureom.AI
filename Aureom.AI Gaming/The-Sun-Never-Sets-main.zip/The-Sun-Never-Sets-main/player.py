"""
player.py — Player character stats, relationships, journal, and actions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import clamp, log
from brass_and_crown.inventory import Inventory


@dataclass
class Player:
    """
    The player-controlled Victorian aristocrat.

    Stats:
      gold        — wealth in shillings
      influence   — social standing (0–100)
      reputation  — public image (0–100); high rep opens doors, low rep closes them
      health      — physical condition (0–100)
      cunning     — boosts scheming and espionage outcomes
      charm       — boosts social event outcomes
    """
    name: str = "Lord Pembrooke"
    title: str = "Lord"
    gold: int = 5_000
    influence: float = 40.0
    reputation: float = 50.0
    health: float = 80.0
    cunning: float = 45.0
    charm: float = 55.0

    relationships: dict[str, float] = field(default_factory=dict)
    known_secrets: list[tuple[str, str]] = field(default_factory=list)  # (npc_id, secret)
    completed_quests: list[str] = field(default_factory=list)
    active_quest_ids: list[str] = field(default_factory=list)
    journal: list[str] = field(default_factory=list)
    inventory: Inventory = field(default_factory=Inventory)

    # ── Stat helpers ──────────────────────────────────────────────────────────

    def gain_influence(self, delta: float, reason: str = "") -> None:
        self.influence = clamp(self.influence + delta)
        if reason:
            self.log_event(f"Influence {'+' if delta >= 0 else ''}{delta:.1f}: {reason}")

    def spend_gold(self, amount: int) -> bool:
        if self.gold >= amount:
            self.gold -= amount
            return True
        return False

    def earn_gold(self, amount: int, reason: str = "") -> None:
        self.gold += amount
        if reason:
            self.log_event(f"Received {amount} shillings: {reason}")

    def adjust_reputation(self, delta: float) -> None:
        self.reputation = clamp(self.reputation + delta)

    def adjust_health(self, delta: float) -> None:
        self.health = clamp(self.health + delta)

    def get_relationship(self, npc_id: str) -> float:
        return self.relationships.get(npc_id, 0.0)

    def adjust_relationship(self, npc_id: str, delta: float) -> None:
        current = self.relationships.get(npc_id, 0.0)
        self.relationships[npc_id] = max(-100, min(100, current + delta))

    def learn_secret(self, npc_id: str, secret: str) -> None:
        entry = (npc_id, secret)
        if entry not in self.known_secrets:
            self.known_secrets.append(entry)
            self.log_event(f"Secret learned about {npc_id}: {secret}")

    # ── Journal ───────────────────────────────────────────────────────────────

    def log_event(self, message: str) -> None:
        self.journal.append(message)
        if len(self.journal) > 200:
            self.journal.pop(0)
        log.debug("[Journal] %s", message)

    # ── Equipment bonus ───────────────────────────────────────────────────────

    @property
    def equipment_bonuses(self) -> dict[str, float]:
        bonuses: dict[str, float] = {}
        for gadget in self.inventory.gadgets:
            if gadget.equipped:
                for k, v in gadget.bonus.items():
                    bonuses[k] = bonuses.get(k, 0.0) + v
        return bonuses

    @property
    def effective_charm(self) -> float:
        return clamp(self.charm + self.equipment_bonuses.get("charm_bonus", 0))

    @property
    def effective_influence(self) -> float:
        return clamp(self.influence + self.equipment_bonuses.get("influence", 0))

    # ── Turn tick ─────────────────────────────────────────────────────────────

    def tick(self, estate_income: dict) -> None:
        """Apply estate income and advance per-turn crafting."""
        net = estate_income.get("net", 0)
        self.earn_gold(net, "estate income")
        # Advance crafting queue
        completions = self.inventory.advance_crafting()
        for msg in completions:
            self.log_event(msg)
        # Natural health recovery
        self.adjust_health(0.5)

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "title": self.title,
            "gold": self.gold,
            "influence": self.influence,
            "reputation": self.reputation,
            "health": self.health,
            "cunning": self.cunning,
            "charm": self.charm,
            "relationships": self.relationships,
            "known_secrets": self.known_secrets,
            "completed_quests": self.completed_quests,
            "active_quest_ids": self.active_quest_ids,
            "journal": self.journal[-50:],  # persist only recent journal
            "inventory": self.inventory.to_dict(),
        }

    def from_dict(self, d: dict) -> None:
        self.name = d.get("name", self.name)
        self.title = d.get("title", self.title)
        self.gold = d.get("gold", self.gold)
        self.influence = d.get("influence", self.influence)
        self.reputation = d.get("reputation", self.reputation)
        self.health = d.get("health", self.health)
        self.cunning = d.get("cunning", self.cunning)
        self.charm = d.get("charm", self.charm)
        self.relationships = d.get("relationships", {})
        self.known_secrets = [tuple(s) for s in d.get("known_secrets", [])]
        self.completed_quests = d.get("completed_quests", [])
        self.active_quest_ids = d.get("active_quest_ids", [])
        self.journal = d.get("journal", [])
        self.inventory.from_dict(d.get("inventory", {}))
