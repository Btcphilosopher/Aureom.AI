"""
ai/economy_ai.py — Victorian market simulation and factory economics.

Design goals:
  • Prices move via a mean-reverting random walk (Ornstein-Uhlenbeck process).
  • Factory output is affected by labour, resources, and random events.
  • Player can invest in factories and receive dividends each turn.
  • Commodity markets: coal, iron, copper, aether-crystals (fictional steampunk
    resource), luxury goods, and automata components.

Mean-reversion model (per commodity per turn):
  price_t+1 = price_t + θ * (μ - price_t) + σ * N(0,1)
  θ = reversion speed (0.05–0.15)
  μ = long-run mean price
  σ = volatility
"""
from __future__ import annotations

import random
import math
from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import EventBus, roll, log, weighted_choice


# ── Commodity ─────────────────────────────────────────────────────────────────

@dataclass
class Commodity:
    name: str
    price: float          # current price in shillings
    mean_price: float     # long-run equilibrium
    theta: float = 0.08   # mean-reversion speed
    sigma: float = 2.0    # price volatility per turn
    _history: list[float] = field(default_factory=list)

    def step(self) -> None:
        """Advance price by one turn using OU process."""
        drift = self.theta * (self.mean_price - self.price)
        shock = self.sigma * random.gauss(0, 1)
        self.price = max(1.0, self.price + drift + shock)
        self._history.append(round(self.price, 2))
        if len(self._history) > 50:
            self._history.pop(0)

    @property
    def trend(self) -> str:
        if len(self._history) < 3:
            return "stable"
        delta = self._history[-1] - self._history[-3]
        if delta > 1:
            return "rising"
        if delta < -1:
            return "falling"
        return "stable"


# ── Factory ───────────────────────────────────────────────────────────────────

@dataclass
class Factory:
    factory_id: str
    name: str
    commodity_out: str       # what it produces
    commodity_in: str        # primary input resource
    base_output: int = 100   # units per turn at full capacity
    capacity: float = 1.0    # 0.0–1.0 multiplier (labour / maintenance)
    owner_id: Optional[str] = None
    upgrade_level: int = 1
    accident_risk: float = 0.03   # probability of accident per turn
    workers: int = 50
    _profit_log: list[float] = field(default_factory=list)

    def produce(self, market: "Market") -> dict:
        """
        Simulate one turn of production.
        Returns dict with output, profit, and any events.
        """
        output = int(self.base_output * self.capacity * self.upgrade_level
                     * random.uniform(0.85, 1.15))

        # Labour efficiency bonus
        labour_bonus = min(1.2, self.workers / 50)
        output = int(output * labour_bonus)

        revenue = output * market.price(self.commodity_out)
        input_cost = int(output * 0.4) * market.price(self.commodity_in)
        wage_bill = self.workers * 2  # 2 shillings per worker per turn
        profit = revenue - input_cost - wage_bill
        self._profit_log.append(profit)
        if len(self._profit_log) > 20:
            self._profit_log.pop(0)

        result = {"factory": self.name, "output": output, "profit": round(profit, 2),
                  "accident": False}

        # Accident roll
        if roll(self.accident_risk):
            self.capacity = max(0.2, self.capacity - random.uniform(0.1, 0.3))
            result["accident"] = True
            result["profit"] -= 500
            EventBus.emit("factory_accident", {"factory": self})

        return result

    def upgrade(self) -> int:
        """Upgrade factory, increasing output. Returns gold cost."""
        cost = self.upgrade_level * 2_000
        self.upgrade_level += 1
        self.capacity = min(1.0, self.capacity + 0.1)
        self.accident_risk = max(0.01, self.accident_risk - 0.005)
        log.info("Factory %s upgraded to level %d", self.name, self.upgrade_level)
        return cost

    def repair(self) -> int:
        """Repair factory capacity. Returns gold cost."""
        cost = int((1.0 - self.capacity) * 1_000)
        self.capacity = 1.0
        return cost

    def average_profit(self) -> float:
        if not self._profit_log:
            return 0.0
        return sum(self._profit_log) / len(self._profit_log)

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

    @classmethod
    def from_dict(cls, d: dict) -> "Factory":
        return cls(**d)


# ── Market ────────────────────────────────────────────────────────────────────

class Market:
    """
    Central commodity market.  Advances all commodity prices each turn and
    manages factory ownership records.
    """

    def __init__(self) -> None:
        self.commodities: dict[str, Commodity] = {
            "coal":       Commodity("Coal",           price=10, mean_price=10, sigma=1.5),
            "iron":       Commodity("Iron",           price=18, mean_price=18, sigma=2.0),
            "copper":     Commodity("Copper",         price=22, mean_price=22, sigma=2.5),
            "aether":     Commodity("Aether-Crystal", price=80, mean_price=80, sigma=8.0),
            "luxury":     Commodity("Luxury Goods",   price=120, mean_price=120, sigma=10.0),
            "automata":   Commodity("Automata Parts", price=55, mean_price=55, sigma=6.0),
        }
        self.factories: list[Factory] = self._seed_factories()

    def step(self) -> None:
        """Advance market prices by one turn."""
        for c in self.commodities.values():
            c.step()
        self._check_market_events()

    def price(self, commodity: str) -> float:
        c = self.commodities.get(commodity)
        return c.price if c else 0.0

    def produce_all(self) -> list[dict]:
        """Run production for all factories and return results."""
        results = []
        for factory in self.factories:
            results.append(factory.produce(self))
        return results

    def get_factory(self, factory_id: str) -> Optional[Factory]:
        for f in self.factories:
            if f.factory_id == factory_id:
                return f
        return None

    def invest_in_factory(self, factory_id: str, player_id: str,
                          gold: int) -> tuple[bool, str]:
        """Player buys ownership of a factory."""
        factory = self.get_factory(factory_id)
        if not factory:
            return False, "Factory not found."
        purchase_price = factory.upgrade_level * 5_000
        if gold < purchase_price:
            return False, f"Insufficient funds. Asking price: £{purchase_price // 100}."
        factory.owner_id = player_id
        return True, f"You now own {factory.name}. Dividends will be paid each turn."

    def _seed_factories(self) -> list[Factory]:
        return [
            Factory("ironworks_east", "Whitechapel Ironworks",
                    commodity_out="iron", commodity_in="coal",
                    workers=80, base_output=120),
            Factory("copper_mill_south", "Southwark Copper Mill",
                    commodity_out="copper", commodity_in="coal",
                    workers=60, base_output=90),
            Factory("aether_refinery", "Lambeth Aether Refinery",
                    commodity_out="aether", commodity_in="copper",
                    workers=40, base_output=30, accident_risk=0.06),
            Factory("automata_works", "Clerkenwell Automata Works",
                    commodity_out="automata", commodity_in="iron",
                    workers=55, base_output=50),
        ]

    def _check_market_events(self) -> None:
        """
        Random market shocks: supply disruptions, trade news, royal contracts.
        Each has a small probability per turn and creates a price spike.
        """
        shocks = [
            ("coal", "A miners' strike looms in Yorkshire — coal prices spike!", 1.4),
            ("aether", "Royal Navy orders aether-crystal reserves — prices surge!", 1.6),
            ("luxury", "Continental trade embargo threatens luxury imports.", 0.7),
            ("iron", "New vein of iron ore discovered in Wales — prices fall.", 0.75),
        ]
        for commodity, message, multiplier in shocks:
            if roll(0.02):
                c = self.commodities.get(commodity)
                if c:
                    c.price *= multiplier
                    log.info("Market shock: %s", message)
                    EventBus.emit("market_shock", {"commodity": commodity,
                                                   "message": message,
                                                   "multiplier": multiplier})
