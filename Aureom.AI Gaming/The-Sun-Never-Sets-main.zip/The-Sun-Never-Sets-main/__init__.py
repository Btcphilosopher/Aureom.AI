"""brass_and_crown — The Sun Never Sets game engine."""
