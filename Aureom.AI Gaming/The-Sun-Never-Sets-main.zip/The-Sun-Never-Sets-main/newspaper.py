"""
newspaper.py — The Victorian Gazette.

Each week (every 7 turns) the Gazette is published.  Its content is
procedurally generated from the current game state:
  • Market report — biggest movers in commodity prices
  • Society column — gossip about NPCs, relationship shifts, mood changes
  • Parliamentary notices — faction news
  • Personals — player-affecting snippets (reputation changes, quest hooks)
  • Letters to the Editor — random flavour from trait-appropriate NPCs

The newspaper also has mechanical effects:
  • Positive press → +reputation
  • Scandal mentions → -reputation and -relationship with named NPCs
  • Market reports influence commodity demand (price modifier next turn)
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from brass_and_crown.utils import roll, weighted_choice, log

if TYPE_CHECKING:
    from brass_and_crown.core import GameState


# ── Section templates ─────────────────────────────────────────────────────────

MARKET_HEADERS = [
    "EXCHANGE INTELLIGENCE — Prices on the Move",
    "COMMERCIAL INTELLIGENCE",
    "THE CITY: TRADING NOTES",
]

SOCIETY_OPENERS = [
    "Our correspondent at the clubs reports",
    "Whispers from Mayfair suggest",
    "A little bird at the Reform Club confides",
    "We are reliably informed that",
    "It is understood in the best circles that",
]

EDITORIAL_TOPICS = [
    ("the decline of morality among the aristocracy",    "reformers"),
    ("the necessity of expanding the rail network",      "industrialists"),
    ("the threat posed by anarchists in Whitechapel",   "tories"),
    ("the suffragist question and its implications",     "moderates"),
    ("the Empire's duty to civilise the dark continents", "tories"),
    ("the exploitation of factory workers",              "reformers"),
]

PERSONAL_SNIPPETS = [
    "The estate of {player_name} continues to attract favourable comment.",
    "Rumours of ambition surround {player_name} — whether founded or not, time will tell.",
    "A certain {player_title} {player_name} was seen in {district}, drawing curious glances.",
    "The name {player_name} was mentioned approvingly in Parliamentary circles this week.",
]


@dataclass
class GazetteIssue:
    issue_number: int
    date_str: str
    headline: str
    market_section: str
    society_section: str
    parliamentary_section: str
    personals_section: str
    letters_section: str
    # Mechanical effects applied when issue is read
    reputation_delta: float = 0.0
    commodity_modifiers: dict[str, float] = field(default_factory=dict)
    npc_mood_shifts: dict[str, str] = field(default_factory=dict)  # npc_id → new_mood

    def full_text(self) -> str:
        divider = "─" * 64
        return "\n".join([
            f"  ✦ THE VICTORIAN GAZETTE  ✦   Issue {self.issue_number}",
            f"  {self.date_str}",
            divider,
            f"  {self.headline.upper()}",
            divider,
            "",
            "  MARKET INTELLIGENCE",
            self.market_section,
            "",
            divider,
            "  SOCIETY & PERSONS OF NOTE",
            self.society_section,
            "",
            divider,
            "  PARLIAMENTARY & POLITICAL NOTICES",
            self.parliamentary_section,
            "",
            divider,
            "  PERSONAL COLUMNS",
            self.personals_section,
            "",
            divider,
            "  LETTERS TO THE EDITOR",
            self.letters_section,
            divider,
        ])


# ── Gazette generator ─────────────────────────────────────────────────────────

class GazettePress:
    """Generates weekly Gazette issues from live game state."""

    def __init__(self) -> None:
        self._issue_count = 0
        self._history: list[GazetteIssue] = []

    def publish(self, game: "GameState") -> GazetteIssue:
        """Generate and return a new Gazette issue."""
        self._issue_count += 1
        issue = GazetteIssue(
            issue_number=self._issue_count,
            date_str=str(game.date),
            headline=self._generate_headline(game),
            market_section=self._generate_market(game),
            society_section=self._generate_society(game),
            parliamentary_section=self._generate_parliamentary(game),
            personals_section=self._generate_personals(game),
            letters_section=self._generate_letters(game),
        )

        # Apply mechanical effects
        self._apply_effects(issue, game)
        self._history.append(issue)
        log.info("Gazette issue %d published.", self._issue_count)
        return issue

    # ── Section generators ────────────────────────────────────────────────────

    def _generate_headline(self, game: "GameState") -> str:
        """Pick the most newsworthy thing happening this week."""
        candidates = []

        # Big commodity swing?
        for name, c in game.market.commodities.items():
            if c.trend == "rising" and c.price > c.mean_price * 1.15:
                candidates.append(f"AETHER PRICE FRENZY: {c.name} Surges to {c.price:.0f} Shillings")
            elif c.trend == "falling" and c.price < c.mean_price * 0.85:
                candidates.append(f"MARKET PANIC: {c.name} Falls to {c.price:.0f} Shillings")

        # High-volatility NPC did something?
        for npc in game.npcs:
            if npc.mood == "hostile" and npc.traits["volatility"] > 65:
                candidates.append(
                    f"SCANDAL: {npc.title} {npc.name} Behaves Outrageously at Season's Event")
            if npc.mood == "suspicious":
                candidates.append(
                    f"INTRIGUE: {npc.title} {npc.name} Rumoured to Have Secret Dealings")

        # Factory accident?
        for factory in game.market.factories:
            if factory.capacity < 0.6:
                candidates.append(
                    f"TRAGEDY: Accident at {factory.name} Injures Workers")

        if candidates:
            return random.choice(candidates)
        return "LONDON AT PEACE: A Week of Relative Calm in the Capital"

    def _generate_market(self, game: "GameState") -> str:
        lines = [f"  {random.choice(MARKET_HEADERS)}"]
        lines.append("")
        for name, c in game.market.commodities.items():
            arrow = {"rising": "↑", "falling": "↓", "stable": "—"}[c.trend]
            note = ""
            if abs(c.price - c.mean_price) / c.mean_price > 0.15:
                note = "  [NOTABLE MOVEMENT]"
            lines.append(f"    {c.name:<18} {c.price:>7.1f}sh  {arrow}{note}")

        # Pick one commodity for a narrative paragraph
        random_commodity = random.choice(list(game.market.commodities.values()))
        if random_commodity.trend == "rising":
            lines.append(f"\n  Demand for {random_commodity.name} has shown marked strength "
                         f"this week, with buyers competing aggressively.")
        elif random_commodity.trend == "falling":
            lines.append(f"\n  {random_commodity.name} continues its descent, prompting concern "
                         f"among investors in related enterprises.")
        return "\n".join(lines)

    def _generate_society(self, game: "GameState") -> str:
        lines = []
        player = game.player

        # Generate 2–4 social snippets
        snippets_generated = 0
        for npc in random.sample(game.npcs, min(4, len(game.npcs))):
            rel = player.get_relationship(npc.npc_id)
            opener = random.choice(SOCIETY_OPENERS)

            if npc.mood == "hostile":
                snippet = (f"  {opener} {npc.title} {npc.name} has been in an uncommonly "
                           f"disagreeable temper of late.")
            elif npc.mood == "pleased":
                snippet = (f"  {opener} {npc.title} {npc.name} has been conspicuously "
                           f"charming at recent engagements.")
            elif rel < -30:
                snippet = (f"  {opener} there is no love lost between "
                           f"{npc.title} {npc.name} and certain persons in Mayfair.")
            elif rel > 60:
                snippet = (f"  {opener} {npc.title} {npc.name} has been effusively "
                           f"praising the character of {player.title} {player.name}.")
            else:
                # Generic flavour
                flavours = [
                    f"{npc.title} {npc.name} was seen at the Athenaeum.",
                    f"{npc.title} {npc.name} has been spending time in {random.choice(['Kensington','Mayfair','Clerkenwell'])}.",
                    f"A new hat from Paris has been attributed to {npc.title} {npc.name}.",
                ]
                snippet = f"  {random.choice(flavours)}"

            lines.append(snippet)
            snippets_generated += 1
            if snippets_generated >= 3:
                break

        return "\n".join(lines)

    def _generate_parliamentary(self, game: "GameState") -> str:
        lines = []
        faction_news = [
            ("  The Tory backbenches are restless following last week's debate on factory reform.",
             "tories"),
            ("  Moderate voices in the Commons urge calm as industrial unrest spreads.",
             "moderates"),
            ("  The Reformers have tabled a new bill regarding working hours in the mills.",
             "reformers"),
            ("  Industrialists lobby the Board of Trade for relaxed import duties on aether crystals.",
             "industrialists"),
            ("  A vote on the Aether Extraction Licensing Act is expected within the fortnight.",
             "neutral"),
        ]
        chosen = random.sample(faction_news, 2)
        for text, _ in chosen:
            lines.append(text)
        return "\n".join(lines)

    def _generate_personals(self, game: "GameState") -> str:
        lines = []
        p = game.player

        # Player mention
        template = random.choice(PERSONAL_SNIPPETS)
        lines.append("  " + template.format(
            player_name=p.name,
            player_title=p.title,
            district=game.world.current_district.name,
        ))

        # Reputation-driven note
        if p.reputation > 70:
            lines.append("  The name of our subject is spoken with warmth in the better clubs.")
        elif p.reputation < 35:
            lines.append("  Certain uncharitable whispers persist regarding recent conduct.")

        # Quest-hook personal
        if not game.quest_manager.active_quests:
            lines.append("  Several prominent citizens are said to be in search of a trusted confidant.")

        return "\n".join(lines)

    def _generate_letters(self, game: "GameState") -> str:
        """One letter from a randomly chosen NPC, toned by their traits."""
        if not game.npcs:
            return "  No letters received this week."

        author = random.choice(game.npcs)
        topic, _ = random.choice(EDITORIAL_TOPICS)

        if author.traits["honesty"] > 65:
            tone = "with great sincerity"
        elif author.traits["cunning"] > 70:
            tone = "with carefully chosen words"
        else:
            tone = "with considerable passion"

        letter = (f"  Dear Editor,\n"
                  f"  I write {tone} on the matter of {topic}.\n"
                  f"  The present state of affairs demands the attention of all right-thinking persons.\n"
                  f"  Yours faithfully,\n"
                  f"  {author.title} {author.name}")
        return letter

    # ── Mechanical effects ────────────────────────────────────────────────────

    def _apply_effects(self, issue: GazetteIssue, game: "GameState") -> None:
        """
        Apply reputation and commodity modifier effects based on issue content.
        These are small nudges, not dramatic swings.
        """
        player = game.player

        # Positive headline → small rep boost
        if "PEACE" in issue.headline or "praised" in issue.society_section.lower():
            issue.reputation_delta += 1.0

        # Scandal mention → rep dip
        if "SCANDAL" in issue.headline:
            issue.reputation_delta -= 3.0

        # Player mentioned in personals positively
        if player.name in issue.personals_section and player.reputation > 60:
            issue.reputation_delta += 2.0

        player.adjust_reputation(issue.reputation_delta)

        # Commodity modifiers: trending up → slightly more demand next turn
        for name, c in game.market.commodities.items():
            if c.trend == "rising":
                issue.commodity_modifiers[name] = 1.02
            elif c.trend == "falling":
                issue.commodity_modifiers[name] = 0.98

        # Apply commodity mods
        for name, mod in issue.commodity_modifiers.items():
            c = game.market.commodities.get(name)
            if c:
                c.price *= mod

    @property
    def latest_issue(self) -> "GazetteIssue | None":
        return self._history[-1] if self._history else None

    def to_dict(self) -> dict:
        return {"issue_count": self._issue_count}

    def from_dict(self, d: dict) -> None:
        self._issue_count = d.get("issue_count", 0)
