"""
factions.py — London Power-Faction System.

Five factions compete for influence in Victorian London.  The player
accumulates (or loses) standing with each faction through their actions.

Standing tiers and perks:
  < -50   Hostile     — faction NPCs refuse interaction; events penalised
  -50–0   Unfavoured  — no special treatment
   0–30   Acquainted  — minor gossip, occasional tips
  30–60   Favoured    — access to faction events, information, quests
  60–80   Trusted     — exclusive quests, economic bonuses, NPC ally
  80+     Champion    — faction-specific late-game content, unique title

Faction relations — factions have inter-faction standings that affect
whether helping one faction hurts your standing with its rivals.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brass_and_crown.utils import log, EventBus, clamp


# ── Faction definitions ────────────────────────────────────────────────────────

@dataclass
class Faction:
    faction_id: str
    name: str
    description: str
    leader_npc_id: str
    rival_faction_ids: list[str]
    ally_faction_ids: list[str]
    standing: float = 0.0          # player's standing with this faction
    power: float = 50.0            # faction's current political power (0–100)
    _history: list[str] = field(default_factory=list)

    # ── Standing helpers ──────────────────────────────────────────────────────

    def adjust_standing(self, delta: float, reason: str = "") -> None:
        self.standing = clamp(self.standing + delta, -100, 100)
        if reason:
            self._history.append(f"{'+' if delta >= 0 else ''}{delta:.1f}: {reason}")
            if len(self._history) > 30:
                self._history.pop(0)
        log.debug("Faction %s standing: %+.1f → %.1f  (%s)",
                  self.faction_id, delta, self.standing, reason)

    @property
    def tier(self) -> str:
        s = self.standing
        if s < -50:   return "hostile"
        if s < 0:     return "unfavoured"
        if s < 30:    return "acquainted"
        if s < 60:    return "favoured"
        if s < 80:    return "trusted"
        return "champion"

    @property
    def tier_colour(self) -> str:
        """Colour hint for GUI."""
        return {
            "hostile":    "#C0392B",
            "unfavoured": "#888888",
            "acquainted": "#9A8A60",
            "favoured":   "#4BB8C9",
            "trusted":    "#C9A84C",
            "champion":   "#FFD700",
        }[self.tier]

    # ── Perks unlocked by tier ────────────────────────────────────────────────

    def unlocked_perks(self) -> list[str]:
        all_perks = {
            "acquainted": ["faction_gossip"],
            "favoured":   ["faction_events", "faction_quests"],
            "trusted":    ["faction_ally", "economic_bonus"],
            "champion":   ["unique_title", "late_game_content"],
        }
        perks = []
        for tier, tier_perks in all_perks.items():
            if self._tier_rank() >= self._tier_name_to_rank(tier):
                perks.extend(tier_perks)
        return perks

    def _tier_rank(self) -> int:
        return {
            "hostile": 0, "unfavoured": 1, "acquainted": 2,
            "favoured": 3, "trusted": 4, "champion": 5,
        }[self.tier]

    @staticmethod
    def _tier_name_to_rank(name: str) -> int:
        return {
            "hostile": 0, "unfavoured": 1, "acquainted": 2,
            "favoured": 3, "trusted": 4, "champion": 5,
        }[name]

    # ── Economy bonus ─────────────────────────────────────────────────────────

    def income_bonus(self) -> int:
        """Extra shillings per turn at Trusted+ standing."""
        if self.tier in ("trusted", "champion"):
            return int(self.power * 0.5)
        return 0

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

    @classmethod
    def from_dict(cls, d: dict) -> "Faction":
        return cls(**{k: v for k, v in d.items() if k != "_history"})


# ── Faction registry ──────────────────────────────────────────────────────────

def build_factions() -> dict[str, Faction]:
    return {
        "tories": Faction(
            faction_id="tories",
            name="The Conservative Club",
            description=(
                "The Tory grandees: landowners, generals, and old money. "
                "They value tradition, order, and the status quo."
            ),
            leader_npc_id="lord_ashworth",
            rival_faction_ids=["reformers"],
            ally_faction_ids=["industrialists"],
            power=65.0,
        ),
        "reformers": Faction(
            faction_id="reformers",
            name="The Reform League",
            description=(
                "Radicals, Nonconformists, and social crusaders. "
                "They seek better conditions for workers and expanded suffrage."
            ),
            leader_npc_id="reverend_holt",
            rival_faction_ids=["tories"],
            ally_faction_ids=["moderates"],
            power=38.0,
        ),
        "moderates": Faction(
            faction_id="moderates",
            name="The Liberal Alliance",
            description=(
                "Whigs and progressives who seek measured change "
                "without upsetting the fundamentals of society."
            ),
            leader_npc_id="lady_fairfax",
            rival_faction_ids=[],
            ally_faction_ids=["reformers"],
            power=50.0,
        ),
        "industrialists": Faction(
            faction_id="industrialists",
            name="The Industrialists' Guild",
            description=(
                "Factory owners, railway magnates, and inventors. "
                "Profit drives their politics; progress is their religion."
            ),
            leader_npc_id="dr_cogsworth",
            rival_faction_ids=["reformers"],
            ally_faction_ids=["tories"],
            power=58.0,
        ),
        "neutral": Faction(
            faction_id="neutral",
            name="The Shadow Network",
            description=(
                "Spies, information brokers, and those who serve no flag. "
                "Standing here buys secrets and protection — at a price."
            ),
            leader_npc_id="vivienne_blackthorn",
            rival_faction_ids=[],
            ally_faction_ids=[],
            power=30.0,
        ),
    }


# ── Faction manager ────────────────────────────────────────────────────────────

class FactionManager:
    """
    Tracks player standing with all factions and propagates ripple effects.

    When player helps a faction, rival factions lose standing automatically
    (scaled by the inter-faction rivalry strength).
    """
    RIVALRY_BLEED = 0.4    # rivals lose 40 % of the standing gained

    def __init__(self) -> None:
        self.factions: dict[str, Faction] = build_factions()

    # ── Standing adjustments ──────────────────────────────────────────────────

    def adjust(self, faction_id: str, delta: float, reason: str = "") -> list[str]:
        """
        Adjust standing with a faction and propagate rivalry penalties.
        Returns list of narrative messages.
        """
        messages = []
        faction = self.factions.get(faction_id)
        if not faction:
            return messages

        faction.adjust_standing(delta, reason)
        messages.append(
            f"Faction '{faction.name}': {'+' if delta >= 0 else ''}{delta:.1f} "
            f"standing (now {faction.standing:.0f} — {faction.tier})"
        )

        # Ripple: rival factions lose some standing
        if delta > 0:
            bleed = -abs(delta) * self.RIVALRY_BLEED
            for rival_id in faction.rival_faction_ids:
                rival = self.factions.get(rival_id)
                if rival:
                    rival.adjust_standing(bleed, f"rivalry bleed from {faction_id}")
                    messages.append(
                        f"  ↳ Rival '{rival.name}': {bleed:.1f} standing "
                        f"(now {rival.standing:.0f})"
                    )

        # Emit event for GUI
        EventBus.emit("faction_standing_changed", {
            "faction_id": faction_id,
            "delta": delta,
            "new_standing": faction.standing,
            "tier": faction.tier,
        })
        return messages

    def get(self, faction_id: str) -> Optional[Faction]:
        return self.factions.get(faction_id)

    # ── Turn tick ─────────────────────────────────────────────────────────────

    def tick(self, turn: int) -> list[str]:
        """
        Evolve faction powers each turn based on world events.
        Returns narrative messages when power shifts are notable.
        """
        messages = []
        import random

        for faction in self.factions.values():
            # Natural drift toward 50 (mean reversion)
            drift = (50 - faction.power) * 0.01
            shock = random.gauss(0, 0.8)
            faction.power = clamp(faction.power + drift + shock)

        # Periodic power struggle events (every 20 turns)
        if turn % 20 == 0:
            # Pick two rival factions for a clash
            faction_list = list(self.factions.values())
            import random as rng
            a, b = rng.sample(faction_list, 2)
            winner = a if a.power > b.power else b
            loser  = b if winner is a else a
            delta = rng.uniform(3, 8)
            winner.power = clamp(winner.power + delta)
            loser.power  = clamp(loser.power  - delta * 0.5)
            messages.append(
                f"Political shift: {winner.name} gains ground over {loser.name}."
            )

        return messages

    # ── Perks summary ─────────────────────────────────────────────────────────

    def total_income_bonus(self) -> int:
        return sum(f.income_bonus() for f in self.factions.values())

    def player_titles(self) -> list[str]:
        """Return faction-granted titles the player has earned."""
        titles = []
        title_map = {
            "tories":        "Knight Companion of the Conservative Order",
            "reformers":     "Friend of the Working Classes",
            "moderates":     "Patron of the Liberal Alliance",
            "industrialists": "Fellow of the Industrialists' Guild",
            "neutral":       "Associate of the Shadow Network",
        }
        for fid, faction in self.factions.items():
            if faction.tier == "champion":
                titles.append(title_map.get(fid, fid))
        return titles

    # ── Serialisation ─────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {fid: f.to_dict() for fid, f in self.factions.items()}

    def from_dict(self, d: dict) -> None:
        for fid, fdata in d.items():
            if fid in self.factions:
                self.factions[fid].standing = fdata.get("standing", 0)
                self.factions[fid].power    = fdata.get("power", 50)
