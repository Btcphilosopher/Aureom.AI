"""
dialogue.py — Branching NPC Dialogue Engine.

Each conversation is a tree of DialogueNodes.  The player picks from
available options; each option has:
  • A requirement (optional) — trait check, relationship threshold, or item
  • A set of effects applied on selection (relationship delta, flag, item grant)
  • A pointer to the next node

NPC responses are dynamically coloured by:
  • The NPC's current mood
  • Their relationship with the player
  • Their dominant trait (cunning, honesty, charm, etc.)

This keeps every conversation feeling alive rather than canned.

Conversation trees are defined as nested dicts so they can eventually
be loaded from JSON files without code changes.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional, Callable, TYPE_CHECKING

from brass_and_crown.utils import roll, log

if TYPE_CHECKING:
    from brass_and_crown.ai.characters import NPC
    from brass_and_crown.player import Player


# ── Dialogue node ─────────────────────────────────────────────────────────────

@dataclass
class DialogueOption:
    text: str                          # what the player says
    next_node: str                     # node_id to navigate to, or "END"
    requirement: Optional[str] = None  # "influence:50", "relationship:30", "item:bp_chronometer"
    effects: dict = field(default_factory=dict)
    # effects keys: relationship_delta, influence_delta, gold_delta,
    #               set_flag, learn_secret, reputation_delta


@dataclass
class DialogueNode:
    node_id: str
    npc_text: str                      # base NPC speech (may be augmented by mood)
    options: list[DialogueOption] = field(default_factory=list)
    mood_variants: dict[str, str] = field(default_factory=dict)
    # mood_variants: {"hostile": "...", "pleased": "..."} override npc_text

    def get_npc_text(self, mood: str) -> str:
        return self.mood_variants.get(mood, self.npc_text)


# ── Conversation ──────────────────────────────────────────────────────────────

class Conversation:
    """
    Active conversation session between player and one NPC.

    Usage:
        conv = Conversation.build_for(npc, player)
        node = conv.current_node()
        available = conv.available_options(player)
        result = conv.choose(option_index, player)
        # repeat until conv.is_over()
    """

    def __init__(self, npc: "NPC", tree: dict[str, DialogueNode]) -> None:
        self.npc = npc
        self.tree = tree
        self._current_id = "root"
        self._history: list[str] = []
        self._over = False

    def current_node(self) -> Optional[DialogueNode]:
        return self.tree.get(self._current_id)

    def current_npc_text(self) -> str:
        node = self.current_node()
        if not node:
            return ""
        raw = node.get_npc_text(self.npc.mood)
        # Personalise with NPC name/title
        return raw.replace("{name}", self.npc.name).replace(
            "{title}", self.npc.title).replace("{npc}", f"{self.npc.title} {self.npc.name}")

    def available_options(self, player: "Player") -> list[tuple[int, DialogueOption]]:
        """Return (index, option) pairs for options the player currently qualifies for."""
        node = self.current_node()
        if not node:
            return []
        result = []
        for i, opt in enumerate(node.options):
            if self._check_requirement(opt.requirement, player):
                result.append((i, opt))
        return result

    def choose(self, option_index: int, player: "Player") -> dict:
        """
        Player selects option at index.  Returns effects dict and
        the NPC's new speech text.
        """
        node = self.current_node()
        if not node or option_index >= len(node.options):
            return {}
        opt = node.options[option_index]
        if not self._check_requirement(opt.requirement, player):
            return {"error": "Requirement not met."}

        # Apply effects
        effects_applied = self._apply_effects(opt.effects, player)
        self._history.append(f"Player: {opt.text}")

        # Navigate
        next_id = opt.next_node
        if next_id == "END" or next_id not in self.tree:
            self._over = True
            self._current_id = "END"
        else:
            self._current_id = next_id
            self._history.append(f"{self.npc.name}: {self.current_npc_text()}")

        return effects_applied

    def is_over(self) -> bool:
        return self._over

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _check_requirement(self, req: Optional[str], player: "Player") -> bool:
        if not req:
            return True
        key, val = req.split(":", 1)
        if key == "influence":
            return player.influence >= float(val)
        if key == "relationship":
            return player.get_relationship(self.npc.npc_id) >= float(val)
        if key == "reputation":
            return player.reputation >= float(val)
        if key == "gold":
            return player.gold >= int(val)
        if key == "item":
            return any(g.gadget_id.startswith(val)
                       for g in player.inventory.gadgets)
        if key == "cunning":
            return player.cunning >= float(val)
        if key == "secret":
            return any(nid == val for nid, _ in player.known_secrets)
        return True

    def _apply_effects(self, effects: dict, player: "Player") -> dict:
        applied = {}
        if "relationship_delta" in effects:
            delta = effects["relationship_delta"]
            self.npc.adjust_relationship("player", delta)
            player.adjust_relationship(self.npc.npc_id, delta)
            applied["relationship_delta"] = delta
        if "influence_delta" in effects:
            player.gain_influence(effects["influence_delta"],
                                  f"conversation with {self.npc.name}")
            applied["influence_delta"] = effects["influence_delta"]
        if "reputation_delta" in effects:
            player.adjust_reputation(effects["reputation_delta"])
            applied["reputation_delta"] = effects["reputation_delta"]
        if "gold_delta" in effects:
            gd = effects["gold_delta"]
            if gd > 0:
                player.earn_gold(gd, f"conversation with {self.npc.name}")
            else:
                player.spend_gold(abs(gd))
            applied["gold_delta"] = gd
        if "learn_secret" in effects:
            secret_npc, secret_text = effects["learn_secret"]
            player.learn_secret(secret_npc, secret_text)
            applied["secret_learned"] = secret_text
        if "set_flag" in effects:
            applied["flag"] = effects["set_flag"]
        if "blueprint" in effects:
            player.inventory.learn_blueprint(effects["blueprint"])
            applied["blueprint"] = effects["blueprint"]
        return applied

    @property
    def transcript(self) -> list[str]:
        return list(self._history)


# ── Conversation trees ────────────────────────────────────────────────────────

def build_tree_lord_ashworth() -> dict[str, DialogueNode]:
    return {
        "root": DialogueNode(
            "root",
            npc_text="Ah. {title} {name}. Come to admire the décor, have you?",
            mood_variants={
                "pleased":    "{title} {name}! What a pleasant surprise. Come, sit.",
                "hostile":    "You have some nerve approaching me, {name}.",
                "suspicious": "{title} {name}... I wondered when you'd turn up.",
            },
            options=[
                DialogueOption(
                    "I wished to discuss the railway situation.",
                    next_node="railways",
                    effects={"relationship_delta": 2},
                ),
                DialogueOption(
                    "I've heard rumours about your... financial arrangements.",
                    next_node="blackmail_attempt",
                    requirement="secret:lord_ashworth",
                    effects={"relationship_delta": -10},
                ),
                DialogueOption(
                    "I come bearing a proposition that benefits us both.",
                    next_node="alliance_offer",
                    requirement="influence:55",
                    effects={"relationship_delta": 5},
                ),
                DialogueOption(
                    "Forgive me — I shan't take up your time.",
                    next_node="END",
                ),
            ]
        ),
        "railways": DialogueNode(
            "railways",
            npc_text=(
                "The railways? Naturally. The Great Northern is a crown jewel. "
                "Any man with sense has invested. Have you?"
            ),
            options=[
                DialogueOption(
                    "I have. The returns are extraordinary.",
                    next_node="railway_ally",
                    requirement="gold:1000",
                    effects={"relationship_delta": 8, "influence_delta": 3},
                ),
                DialogueOption(
                    "I'm considering it. What do you advise?",
                    next_node="railway_advice",
                    effects={"relationship_delta": 3},
                ),
                DialogueOption(
                    "I've heard the books may not be as clean as they appear.",
                    next_node="confrontation",
                    requirement="secret:lord_ashworth",
                    effects={"relationship_delta": -15},
                ),
            ]
        ),
        "railway_ally": DialogueNode(
            "railway_ally",
            npc_text=(
                "Capital! A man of judgement. We should compare notes over port. "
                "I may have a proposition for you — in confidence, of course."
            ),
            options=[
                DialogueOption(
                    "I would welcome that. When shall we meet?",
                    next_node="END",
                    effects={"relationship_delta": 10, "set_flag": "ashworth_alliance_pending"},
                ),
                DialogueOption(
                    "In confidence? I prefer my dealings in the open.",
                    next_node="END",
                    effects={"relationship_delta": -5, "reputation_delta": 5},
                ),
            ]
        ),
        "railway_advice": DialogueNode(
            "railway_advice",
            npc_text=(
                "Buy the bonds, not the shares. The shares are... complicated. "
                "You did not hear that from me."
            ),
            options=[
                DialogueOption(
                    "Most illuminating. I thank you.",
                    next_node="END",
                    effects={"relationship_delta": 5},
                ),
            ]
        ),
        "confrontation": DialogueNode(
            "confrontation",
            npc_text=(
                "You dare — I would choose your next words with extraordinary care, "
                "{name}. Extraordinary care."
            ),
            mood_variants={
                "hostile": "Get out. Get out before I have you removed.",
            },
            options=[
                DialogueOption(
                    "I merely note what others are saying. I am on your side.",
                    next_node="END",
                    effects={"relationship_delta": 5},
                ),
                DialogueOption(
                    "I will be saying nothing further — unless circumstances change.",
                    next_node="END",
                    effects={"relationship_delta": -20, "influence_delta": 5},
                ),
            ]
        ),
        "blackmail_attempt": DialogueNode(
            "blackmail_attempt",
            npc_text=(
                "...How much do you want? And before you answer — "
                "consider that powerful men make dangerous enemies."
            ),
            options=[
                DialogueOption(
                    "I want nothing. I simply want you to remember I know.",
                    next_node="END",
                    effects={"relationship_delta": -5, "influence_delta": 8},
                ),
                DialogueOption(
                    "Two thousand shillings and your silence on the matter.",
                    next_node="blackmail_accepted",
                    requirement="cunning:50",
                    effects={"relationship_delta": -30, "gold_delta": 2000},
                ),
                DialogueOption(
                    "I apologise. I spoke out of turn.",
                    next_node="END",
                    effects={"relationship_delta": 5},
                ),
            ]
        ),
        "blackmail_accepted": DialogueNode(
            "blackmail_accepted",
            npc_text=(
                "You are either very brave or very foolish. "
                "Perhaps both. The money will be delivered tonight. "
                "Do not mistake my compliance for weakness."
            ),
            options=[
                DialogueOption(
                    "I never do. Good evening, Lord Ashworth.",
                    next_node="END",
                ),
            ]
        ),
        "alliance_offer": DialogueNode(
            "alliance_offer",
            npc_text=(
                "An alliance. You've grown bolder since we last spoke. "
                "What exactly are you proposing?"
            ),
            options=[
                DialogueOption(
                    "Mutual protection of our respective interests in Parliament.",
                    next_node="alliance_sealed",
                    requirement="influence:60",
                    effects={"relationship_delta": 20, "influence_delta": 5,
                             "set_flag": "ashworth_alliance"},
                ),
                DialogueOption(
                    "I propose we share intelligence on our mutual enemies.",
                    next_node="END",
                    effects={"relationship_delta": 10},
                ),
            ]
        ),
        "alliance_sealed": DialogueNode(
            "alliance_sealed",
            npc_text=(
                "Then we have an understanding. Welcome, as it were, to the inner circle. "
                "Do not disappoint me."
            ),
            options=[
                DialogueOption(
                    "I would not dream of it.",
                    next_node="END",
                    effects={"influence_delta": 5},
                ),
            ]
        ),
    }


def build_tree_lady_fairfax() -> dict[str, DialogueNode]:
    return {
        "root": DialogueNode(
            "root",
            npc_text=(
                "How delightful — a friendly face. Tell me, "
                "have you heard the latest from Westminster?"
            ),
            mood_variants={
                "hostile":    "I'm afraid I find myself rather occupied at present, {name}.",
                "suspicious": "You've been making enquiries about Lord Ashworth. Why?",
            },
            options=[
                DialogueOption(
                    "The reform bill, I imagine. What is your view?",
                    next_node="reform_bill",
                    effects={"relationship_delta": 3},
                ),
                DialogueOption(
                    "I'm more interested in your view of Lord Ashworth.",
                    next_node="ashworth_topic",
                    effects={"relationship_delta": -2},
                ),
                DialogueOption(
                    "I wanted to speak to you about the railway scandal.",
                    next_node="railway_scandal",
                    requirement="secret:lord_ashworth",
                    effects={"relationship_delta": 5},
                ),
                DialogueOption(
                    "Merely passing through. Good day, Lady Fairfax.",
                    next_node="END",
                ),
            ]
        ),
        "reform_bill": DialogueNode(
            "reform_bill",
            npc_text=(
                "It is long overdue. The conditions in those factories are unconscionable. "
                "Though I fear Ashworth will strangle it in committee."
            ),
            options=[
                DialogueOption(
                    "I shall lend my voice to the bill's supporters.",
                    next_node="END",
                    effects={"relationship_delta": 12, "reputation_delta": 5,
                             "set_flag": "supports_reform_bill"},
                ),
                DialogueOption(
                    "I sympathise but worry about the economic consequences.",
                    next_node="END",
                    effects={"relationship_delta": 2},
                ),
                DialogueOption(
                    "Progress requires patience. The time is not yet right.",
                    next_node="END",
                    effects={"relationship_delta": -5, "reputation_delta": -3},
                ),
            ]
        ),
        "ashworth_topic": DialogueNode(
            "ashworth_topic",
            npc_text=(
                "Ashworth is dangerous in the way a machine with no governor is dangerous. "
                "Powerful, relentless, and utterly heedless of what it destroys."
            ),
            options=[
                DialogueOption(
                    "I share your concern. I have been gathering information.",
                    next_node="ashworth_evidence",
                    requirement="secret:lord_ashworth",
                    effects={"relationship_delta": 10},
                ),
                DialogueOption(
                    "Perhaps I could help moderate his influence?",
                    next_node="END",
                    effects={"relationship_delta": 5},
                ),
            ]
        ),
        "ashworth_evidence": DialogueNode(
            "ashworth_evidence",
            npc_text=(
                "If what you have is solid, it could change everything. "
                "The Parliamentary Select Committee meets in a fortnight. "
                "That would be the moment to act."
            ),
            options=[
                DialogueOption(
                    "Tell me more about the committee. I will be prepared.",
                    next_node="END",
                    effects={"relationship_delta": 15, "influence_delta": 8,
                             "set_flag": "fairfax_quest_advanced"},
                ),
            ]
        ),
        "railway_scandal": DialogueNode(
            "railway_scandal",
            npc_text=(
                "You know? Then you must be more careful than you have been. "
                "These men protect themselves. But if you are willing to take the risk... "
                "I can open certain doors."
            ),
            options=[
                DialogueOption(
                    "I am willing. What doors?",
                    next_node="END",
                    effects={"relationship_delta": 20, "influence_delta": 10,
                             "set_flag": "fairfax_alliance", "reputation_delta": 5},
                ),
                DialogueOption(
                    "I must think carefully before proceeding.",
                    next_node="END",
                    effects={"relationship_delta": 3},
                ),
            ]
        ),
    }


def build_tree_dr_cogsworth() -> dict[str, DialogueNode]:
    return {
        "root": DialogueNode(
            "root",
            npc_text=(
                "Ah! A visitor. Forgive the disorder — I'm in the middle of something "
                "rather extraordinary. Can I help you?"
            ),
            mood_variants={
                "suspicious": "I'm not sure I should be seen talking to you.",
                "pleased":    "Excellent timing! I've just made a breakthrough!",
            },
            options=[
                DialogueOption(
                    "I'd like to discuss your work on the Analytical Engine.",
                    next_node="analytical_engine",
                    effects={"relationship_delta": 5},
                ),
                DialogueOption(
                    "I've heard you've gone missing recently. Are you all right?",
                    next_node="disappearance",
                    effects={"relationship_delta": 8},
                ),
                DialogueOption(
                    "I'd like to commission a custom gadget.",
                    next_node="commission",
                    requirement="gold:500",
                    effects={"relationship_delta": 3},
                ),
                DialogueOption(
                    "Just browsing. Don't let me interrupt.",
                    next_node="END",
                ),
            ]
        ),
        "analytical_engine": DialogueNode(
            "analytical_engine",
            npc_text=(
                "The Pocket Engine is my masterwork. Babbage dreamed it; "
                "I built it to fit inside a waistcoat pocket. It calculates "
                "instantaneously what would take a clerk three days."
            ),
            options=[
                DialogueOption(
                    "Remarkable. I'd purchase the blueprint if you'd sell it.",
                    next_node="buy_blueprint",
                    requirement="gold:1500",
                    effects={"relationship_delta": 10, "gold_delta": -1500,
                             "blueprint": "bp_analytical_engine"},
                ),
                DialogueOption(
                    "What are the military applications?",
                    next_node="END",
                    effects={"relationship_delta": -5, "reputation_delta": -2},
                ),
                DialogueOption(
                    "Extraordinary. The Royal Society would be fascinated.",
                    next_node="END",
                    effects={"relationship_delta": 7, "influence_delta": 3},
                ),
            ]
        ),
        "buy_blueprint": DialogueNode(
            "buy_blueprint",
            npc_text=(
                "Done! And I'll throw in my calibration notes. "
                "The copper winding is the tricky part — mind the tolerances."
            ),
            options=[
                DialogueOption(
                    "You have my gratitude, Doctor.",
                    next_node="END",
                    effects={"relationship_delta": 5},
                ),
            ]
        ),
        "disappearance": DialogueNode(
            "disappearance",
            npc_text=(
                "I... yes. I was detained. By whom, I am not entirely certain. "
                "My blueprints were taken. If you could help me recover them, "
                "I would be in your debt."
            ),
            options=[
                DialogueOption(
                    "I will find your blueprints. You have my word.",
                    next_node="END",
                    effects={"relationship_delta": 20, "set_flag": "cogsworth_quest_started",
                             "influence_delta": 5},
                ),
                DialogueOption(
                    "That sounds dangerous. I recommend involving the police.",
                    next_node="END",
                    effects={"relationship_delta": -3},
                ),
            ]
        ),
        "commission": DialogueNode(
            "commission",
            npc_text=(
                "A commission! Splendid. For five hundred shillings I can adapt "
                "an existing design to your specifications. What do you need?"
            ),
            options=[
                DialogueOption(
                    "Something to enhance my persuasiveness in society.",
                    next_node="commission_charm",
                    effects={"gold_delta": -500, "blueprint": "bp_persuasion_locket"},
                ),
                DialogueOption(
                    "Something for personal protection.",
                    next_node="commission_weapon",
                    effects={"gold_delta": -500, "blueprint": "bp_aether_pistol"},
                ),
            ]
        ),
        "commission_charm": DialogueNode(
            "commission_charm",
            npc_text=(
                "A Resonance Locket! A personal favourite. "
                "The aether vibration affects the limbic system in the most "
                "delightful way. Blueprint's yours. Build it in the workshop."
            ),
            options=[DialogueOption("Excellent. My thanks.", next_node="END")],
        ),
        "commission_weapon": DialogueNode(
            "commission_weapon",
            npc_text=(
                "The Aether-Pistol. Non-lethal, mostly, but quite convincing. "
                "Be careful — the regulator valve has a tendency to stick."
            ),
            options=[DialogueOption("I'll bear that in mind.", next_node="END")],
        ),
    }


def build_tree_blackthorn() -> dict[str, DialogueNode]:
    return {
        "root": DialogueNode(
            "root",
            npc_text=(
                "You found me. Either you're clever or you were followed. "
                "Let's hope it's the former."
            ),
            mood_variants={
                "suspicious": "I don't like unannounced visitors. State your business.",
            },
            options=[
                DialogueOption(
                    "I want to join the Shadow Network.",
                    next_node="join_network",
                    requirement="influence:35",
                    effects={"relationship_delta": 5},
                ),
                DialogueOption(
                    "I need information on Lord Ashworth.",
                    next_node="ashworth_intel",
                    requirement="gold:300",
                    effects={},
                ),
                DialogueOption(
                    "What happened to Dr Cogsworth's blueprints?",
                    next_node="cogsworth_mystery",
                    requirement="relationship:10",
                    effects={"relationship_delta": 3},
                ),
                DialogueOption(
                    "I was merely curious who lived here.",
                    next_node="END",
                    effects={"relationship_delta": -5},
                ),
            ]
        ),
        "join_network": DialogueNode(
            "join_network",
            npc_text=(
                "The Network doesn't recruit — it acquires. "
                "If you're useful, you'll hear from us. "
                "If you're not, this conversation never happened."
            ),
            options=[
                DialogueOption(
                    "I have information about Parliamentary scheming.",
                    next_node="network_entry",
                    requirement="secret:lord_ashworth",
                    effects={"relationship_delta": 25, "influence_delta": 5,
                             "set_flag": "shadow_network_member"},
                ),
                DialogueOption(
                    "I understand. I'll make myself useful.",
                    next_node="END",
                    effects={"relationship_delta": 5},
                ),
            ]
        ),
        "network_entry": DialogueNode(
            "network_entry",
            npc_text=(
                "Now we're talking. Welcome, provisionally. "
                "Don't call on me — I'll find you when I have need."
            ),
            options=[DialogueOption("Understood.", next_node="END",
                                     effects={"influence_delta": 8})],
        ),
        "ashworth_intel": DialogueNode(
            "ashworth_intel",
            npc_text=(
                "Three hundred shillings for what I know about Ashworth? "
                "Insulting. But times are lean. He has a private ledger, "
                "kept at his club under a false name. 'Mr Graves'."
            ),
            options=[
                DialogueOption(
                    "Pay and take the information.",
                    next_node="END",
                    effects={"gold_delta": -300,
                             "learn_secret": ("lord_ashworth",
                                              "Keeps a private ledger under the alias 'Mr Graves'"),
                             "relationship_delta": 8},
                ),
                DialogueOption(
                    "That's hardly worth three hundred shillings.",
                    next_node="END",
                    effects={"relationship_delta": -5},
                ),
            ]
        ),
        "cogsworth_mystery": DialogueNode(
            "cogsworth_mystery",
            npc_text=(
                "The blueprints? I took them. On behalf of a client. "
                "Don't look at me like that — I returned them when the "
                "commission fell through. Check his second workshop, Leather Lane."
            ),
            options=[
                DialogueOption(
                    "You could have told him immediately. You caused him considerable distress.",
                    next_node="END",
                    effects={"relationship_delta": -8, "reputation_delta": 3,
                             "set_flag": "visited_clerkenwell"},
                ),
                DialogueOption(
                    "A professional hazard. I take it your client was Ashworth?",
                    next_node="END",
                    effects={"relationship_delta": 5,
                             "learn_secret": ("lord_ashworth",
                                              "Commissioned theft of Cogsworth's blueprints"),
                             "set_flag": "visited_clerkenwell"},
                ),
            ]
        ),
    }


def build_tree_reverend_holt() -> dict[str, DialogueNode]:
    return {
        "root": DialogueNode(
            "root",
            npc_text=(
                "My friend! I'm glad you've come. The struggle for the working poor "
                "requires allies in every corner of society."
            ),
            mood_variants={
                "hostile": "I'm afraid I cannot speak with you at present.",
            },
            options=[
                DialogueOption(
                    "I wish to support the Reform Bill.",
                    next_node="reform_support",
                    effects={"relationship_delta": 8},
                ),
                DialogueOption(
                    "I hear you have debts. I could help.",
                    next_node="debt_offer",
                    requirement="secret:reverend_holt",
                    effects={"relationship_delta": -5},
                ),
                DialogueOption(
                    "Tell me about the Whitechapel workers.",
                    next_node="workers",
                    effects={"relationship_delta": 5},
                ),
                DialogueOption(
                    "I'm afraid I must be going.",
                    next_node="END",
                ),
            ]
        ),
        "reform_support": DialogueNode(
            "reform_support",
            npc_text=(
                "God bless you. We need people of standing to speak in the Commons. "
                "Would you be willing to make a public endorsement?"
            ),
            options=[
                DialogueOption(
                    "Publicly and unequivocally.",
                    next_node="END",
                    effects={"relationship_delta": 20, "reputation_delta": 8,
                             "influence_delta": 5, "set_flag": "supports_reform_bill"},
                ),
                DialogueOption(
                    "I'll donate to the cause, at least.",
                    next_node="END",
                    effects={"gold_delta": -300, "relationship_delta": 12,
                             "reputation_delta": 5},
                ),
            ]
        ),
        "debt_offer": DialogueNode(
            "debt_offer",
            npc_text=(
                "You know about that. I see. Yes — I owe money. "
                "A foolish indiscretion I shall carry to my grave. "
                "If you're offering help, I will not pretend I don't need it."
            ),
            options=[
                DialogueOption(
                    "Pay his debts (500 shillings).",
                    next_node="debt_cleared",
                    requirement="gold:500",
                    effects={"gold_delta": -500, "relationship_delta": 35},
                ),
                DialogueOption(
                    "I was testing your honesty. I respect that you admitted it.",
                    next_node="END",
                    effects={"relationship_delta": 10},
                ),
            ]
        ),
        "debt_cleared": DialogueNode(
            "debt_cleared",
            npc_text=(
                "I am... speechless. You have removed a stone from my heart "
                "that I have carried for three years. I am in your debt "
                "in every sense that matters."
            ),
            options=[
                DialogueOption(
                    "Think nothing of it. Help me help the workers.",
                    next_node="END",
                    effects={"influence_delta": 8, "reputation_delta": 10},
                ),
            ]
        ),
        "workers": DialogueNode(
            "workers",
            npc_text=(
                "Fourteen-hour days. Children in the steam-vents. "
                "One man lost his arm last Tuesday and was dismissed the same afternoon. "
                "This is not progress. This is barbarism with a brass veneer."
            ),
            options=[
                DialogueOption(
                    "What can be done practically?",
                    next_node="END",
                    effects={"relationship_delta": 5, "set_flag": "visited_whitechapel"},
                ),
                DialogueOption(
                    "I will visit Whitechapel and see for myself.",
                    next_node="END",
                    effects={"relationship_delta": 10, "reputation_delta": 3,
                             "set_flag": "visited_whitechapel"},
                ),
            ]
        ),
    }


# ── Conversation factory ──────────────────────────────────────────────────────

_TREES: dict[str, Callable] = {
    "lord_ashworth":     build_tree_lord_ashworth,
    "lady_fairfax":      build_tree_lady_fairfax,
    "dr_cogsworth":      build_tree_dr_cogsworth,
    "vivienne_blackthorn": build_tree_blackthorn,
    "reverend_holt":     build_tree_reverend_holt,
}


def start_conversation(npc: "NPC", player: "Player") -> Optional[Conversation]:
    """
    Start a new Conversation with an NPC.
    Returns None if no dialogue tree exists for this NPC.
    """
    tree_fn = _TREES.get(npc.npc_id)
    if not tree_fn:
        log.warning("No dialogue tree for NPC: %s", npc.npc_id)
        return None
    tree = tree_fn()
    conv = Conversation(npc, tree)
    log.info("Conversation started with %s", npc.name)
    return conv
