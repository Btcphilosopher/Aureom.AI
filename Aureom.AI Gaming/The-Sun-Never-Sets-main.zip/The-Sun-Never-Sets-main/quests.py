"""
quests.py — Quest definitions, the quest manager, and random event generator.

Quests are state machines with stages.  Each stage has completion conditions
(checked each turn) and rewards.  The QuestManager checks all active quests
per turn and advances them.

Random events are separate: low-probability occurrences fired by the event AI
that the player must react to (or ignore).
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, TYPE_CHECKING

from brass_and_crown.utils import roll, weighted_choice, log, EventBus

if TYPE_CHECKING:
    from brass_and_crown.player import Player
    from brass_and_crown.ai.characters import NPC


# ── Quest ─────────────────────────────────────────────────────────────────────

class QuestStatus(Enum):
    AVAILABLE = auto()
    ACTIVE = auto()
    COMPLETE = auto()
    FAILED = auto()


@dataclass
class QuestStage:
    stage_id: str
    description: str
    requirement: str     # e.g. "visit:whitechapel", "gold:500", "influence:60"
    hint: str = ""


@dataclass
class Quest:
    quest_id: str
    title: str
    description: str
    giver_id: str          # NPC who gives the quest
    stages: list[QuestStage] = field(default_factory=list)
    reward_gold: int = 0
    reward_influence: float = 0.0
    reward_reputation: float = 0.0
    reward_item: Optional[str] = None   # blueprint_id or None
    status: QuestStatus = QuestStatus.AVAILABLE
    current_stage: int = 0
    turns_limit: Optional[int] = None   # None = no time limit
    _turns_active: int = 0

    def start(self) -> None:
        self.status = QuestStatus.ACTIVE
        log.info("Quest started: %s", self.title)

    def is_stage_complete(self, player: "Player", world_flags: dict) -> bool:
        """Check if current stage requirement is satisfied."""
        if self.current_stage >= len(self.stages):
            return True
        req = self.stages[self.current_stage].requirement
        if req.startswith("gold:"):
            return player.gold >= int(req.split(":")[1])
        if req.startswith("influence:"):
            return player.influence >= float(req.split(":")[1])
        if req.startswith("visit:"):
            return world_flags.get(f"visited_{req.split(':')[1]}", False)
        if req.startswith("reputation:"):
            return player.reputation >= float(req.split(":")[1])
        if req.startswith("secret:"):
            target_npc = req.split(":")[1]
            return any(npc_id == target_npc for npc_id, _ in player.known_secrets)
        return False

    def advance_stage(self) -> bool:
        """Move to next stage. Returns True if quest is now complete."""
        self.current_stage += 1
        if self.current_stage >= len(self.stages):
            self.status = QuestStatus.COMPLETE
            return True
        return False

    def tick(self) -> bool:
        """Call once per turn. Returns True if quest has timed out."""
        if self.status != QuestStatus.ACTIVE:
            return False
        self._turns_active += 1
        if self.turns_limit and self._turns_active >= self.turns_limit:
            self.status = QuestStatus.FAILED
            return True
        return False

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items()}
        d["status"] = self.status.name
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Quest":
        stages = [QuestStage(**s) for s in d.pop("stages", [])]
        status = QuestStatus[d.pop("status", "AVAILABLE")]
        obj = cls(**{k: v for k, v in d.items() if k != "_turns_active"})
        obj.stages = stages
        obj.status = status
        return obj


# ── Quest catalogue ───────────────────────────────────────────────────────────

def build_quest_catalogue() -> list[Quest]:
    return [
        Quest(
            quest_id="q_railway_scandal",
            title="Smoke and Mirrors",
            description=(
                "Lord Ashworth is siphoning profits from the Great Northern Railway. "
                "Expose his scheme to embarrass him and gain influence."
            ),
            giver_id="lady_fairfax",
            stages=[
                QuestStage("gather_rumours", "Attend a social event to gather gossip.",
                           "influence:45", hint="Try the Mayfair Gala."),
                QuestStage("find_proof",    "Uncover evidence of embezzlement.",
                           "secret:lord_ashworth"),
                QuestStage("expose",        "Present the evidence at Parliament.",
                           "influence:60"),
            ],
            reward_gold=2_000,
            reward_influence=15.0,
            reward_reputation=10.0,
        ),
        Quest(
            quest_id="q_missing_inventor",
            title="The Clockwork Disappearance",
            description=(
                "Dr Cogsworth has vanished from his laboratory. "
                "Investigate the mystery and recover his stolen blueprints."
            ),
            giver_id="dr_cogsworth",
            stages=[
                QuestStage("visit_lab",   "Visit Cogsworth's laboratory in Clerkenwell.",
                           "visit:clerkenwell"),
                QuestStage("interrogate", "Question Miss Blackthorn about the blueprints.",
                           "secret:vivienne_blackthorn"),
            ],
            reward_gold=1_500,
            reward_influence=8.0,
            reward_item="bp_analytical_engine",
        ),
        Quest(
            quest_id="q_charity_reformer",
            title="A Gentleman's Conscience",
            description=(
                "Reverend Holt needs donations and political support for his "
                "reform bill. Help him — and gain the reformers as allies."
            ),
            giver_id="reverend_holt",
            stages=[
                QuestStage("donate",     "Donate at least 500 shillings to the cause.",
                           "gold:500"),
                QuestStage("reputation", "Raise your reputation to demonstrate sincerity.",
                           "reputation:60"),
            ],
            reward_gold=0,
            reward_influence=10.0,
            reward_reputation=15.0,
        ),
        Quest(
            quest_id="q_aether_monopoly",
            title="The Lambeth Gambit",
            description=(
                "A consortium of industrialists is quietly buying up all aether "
                "refinery contracts. Expose the cartel before the market is cornered."
            ),
            giver_id="lady_fairfax",
            stages=[
                QuestStage("visit_refinery", "Visit the Lambeth Aether Refinery.",
                           "visit:southwark"),
                QuestStage("high_influence", "Build enough influence to be taken seriously.",
                           "influence:55"),
            ],
            reward_gold=3_000,
            reward_influence=12.0,
            reward_item="bp_ornithopter",
            turns_limit=60,
        ),
        Quest(
            quest_id="q_shadow_network",
            title="Whispers in Limehouse",
            description=(
                "Miss Blackthorn has a proposition — work for the Shadow Network "
                "and gain access to secrets no honest man should possess."
            ),
            giver_id="vivienne_blackthorn",
            stages=[
                QuestStage("visit_limehouse", "Find Blackthorn in Limehouse.",
                           "visit:limehouse"),
                QuestStage("prove_cunning",  "Demonstrate your cunning with a Duel of Wit.",
                           "influence:40"),
            ],
            reward_gold=1_000,
            reward_influence=8.0,
            reward_reputation=-5.0,  # reputation cost — disreputable work
            reward_item="bp_persuasion_locket",
        ),
        Quest(
            quest_id="q_factory_workers",
            title="The Human Cost",
            description=(
                "Workers at the Whitechapel Ironworks are organising. "
                "The factory owner wants them broken; Holt wants them supported. "
                "Whose side are you on?"
            ),
            giver_id="reverend_holt",
            stages=[
                QuestStage("investigate", "Visit Whitechapel and hear the workers.",
                           "visit:whitechapel"),
                QuestStage("decide",      "Make your influence felt in the outcome.",
                           "reputation:45"),
            ],
            reward_gold=500,
            reward_influence=6.0,
            reward_reputation=10.0,
        ),
    ]


# ── Random event catalogue ────────────────────────────────────────────────────

RANDOM_EVENTS: list[dict] = [
    {
        "id": "pickpocket",
        "title": "A Deft Hand in Piccadilly",
        "description": "A street urchin makes off with your pocket-watch.",
        "probability": 0.04,
        "gold_delta": -80,
        "reputation_delta": -2,
        "choices": [
            ("Pursue the child", {"reputation_delta": 5, "health_delta": -5}),
            ("Shrug it off",     {"gold_delta": 0}),
        ]
    },
    {
        "id": "newspaper_mention",
        "title": "Featured in The Times",
        "description": "A journalist has written a flattering piece about your philanthropic works.",
        "probability": 0.03,
        "influence_delta": 5,
        "reputation_delta": 8,
        "choices": []   # no choice, just notification
    },
    {
        "id": "factory_fire",
        "title": "Fire at the Ironworks",
        "description": "A fire breaks out at one of the East End ironworks.",
        "probability": 0.02,
        "choices": [
            ("Fund the rebuilding (500 sh)", {"gold_delta": -500, "reputation_delta": 10,
                                               "influence_delta": 5}),
            ("Ignore it",                    {"reputation_delta": -5}),
        ]
    },
    {
        "id": "blackmail",
        "title": "A Sealed Letter",
        "description": "An anonymous letter arrives — someone knows a secret. They want 1,000 shillings.",
        "probability": 0.015,
        "choices": [
            ("Pay the blackmailer",  {"gold_delta": -1_000}),
            ("Ignore the threat",    {"reputation_delta": -10, "influence_delta": -5}),
            ("Investigate (cunning check)", {"_cunning_check": True}),
        ]
    },
    {
        "id": "duel_challenge",
        "title": "A Matter of Honour",
        "description": "A rival aristocrat has insulted your family name and demands satisfaction.",
        "probability": 0.02,
        "choices": [
            ("Accept the duel",  {"_duel": True}),
            ("Decline with wit", {"reputation_delta": -5, "influence_delta": 3}),
        ]
    },
]


# ── Quest manager ─────────────────────────────────────────────────────────────

class QuestManager:
    """Tracks all quests and fires random events each turn."""

    def __init__(self) -> None:
        self.catalogue: list[Quest] = build_quest_catalogue()
        self.active_quests: list[Quest] = []

    def available_quests(self, player: "Player") -> list[Quest]:
        taken = {q.quest_id for q in self.active_quests}
        done = set(player.completed_quests)
        return [q for q in self.catalogue
                if q.status == QuestStatus.AVAILABLE
                and q.quest_id not in taken
                and q.quest_id not in done]

    def accept_quest(self, quest_id: str, player: "Player") -> Optional[str]:
        quest = next((q for q in self.catalogue if q.quest_id == quest_id), None)
        if not quest:
            return "Quest not found."
        quest.start()
        self.active_quests.append(quest)
        player.active_quest_ids.append(quest_id)
        player.log_event(f"Quest accepted: {quest.title}")
        return None  # no error

    def tick(self, player: "Player", world_flags: dict) -> list[str]:
        """
        Advance all active quests, check completions, check timeouts.
        Returns list of narrative messages.
        """
        messages = []
        for quest in list(self.active_quests):
            if quest.tick():  # timed out
                messages.append(f"⏰ Quest failed (time limit): {quest.title}")
                self.active_quests.remove(quest)
                continue

            if quest.is_stage_complete(player, world_flags):
                done = quest.advance_stage()
                if done:
                    messages.append(f"✦ Quest complete: {quest.title}!")
                    self._grant_rewards(quest, player)
                    self.active_quests.remove(quest)
                    player.completed_quests.append(quest.quest_id)
                    EventBus.emit("quest_complete", {"quest": quest, "player": player})
                else:
                    stage = quest.stages[quest.current_stage]
                    messages.append(f"Quest '{quest.title}' — next stage: {stage.description}")

        return messages

    def _grant_rewards(self, quest: Quest, player: "Player") -> None:
        if quest.reward_gold:
            player.earn_gold(quest.reward_gold, f"quest reward: {quest.title}")
        if quest.reward_influence:
            player.gain_influence(quest.reward_influence, f"quest: {quest.title}")
        if quest.reward_reputation:
            player.adjust_reputation(quest.reward_reputation)
        if quest.reward_item:
            player.inventory.learn_blueprint(quest.reward_item)
            player.log_event(f"Blueprint unlocked: {quest.reward_item}")

    # ── Random events ─────────────────────────────────────────────────────────

    def roll_random_event(self) -> Optional[dict]:
        """Roll for a random event this turn. Returns event dict or None."""
        for event in RANDOM_EVENTS:
            if roll(event["probability"]):
                return event
        return None

    def apply_event_choice(self, event: dict, choice_index: int,
                           player: "Player") -> str:
        """Apply the effect of the player's choice in a random event."""
        choices = event.get("choices", [])
        if not choices:
            # Auto-apply baseline deltas
            effects = {k: v for k, v in event.items()
                       if k.endswith("_delta")}
        else:
            if choice_index >= len(choices):
                return "Invalid choice."
            _, effects = choices[choice_index]

        # Handle special effects
        if effects.get("_duel"):
            import random as rng
            won = rng.random() < (player.cunning / 100)
            if won:
                player.gain_influence(10, "won a duel")
                player.adjust_reputation(5)
                return "You win the duel! Your reputation soars."
            else:
                player.adjust_health(-20)
                player.adjust_reputation(-10)
                return "You lose the duel. Your honour is injured — as is your shoulder."

        if effects.get("_cunning_check"):
            won = roll(player.cunning / 100)
            if won:
                player.gain_influence(5, "exposed blackmailer")
                return "Your cunning exposes the blackmailer. They flee."
            else:
                player.spend_gold(500)
                return "The investigation fails. You pay half the demand to keep them quiet."

        # Standard stat deltas
        msg_parts = []
        for key, val in effects.items():
            if key == "gold_delta":
                if val >= 0:
                    player.earn_gold(val)
                else:
                    player.spend_gold(abs(val))
                msg_parts.append(f"Gold: {'+' if val >= 0 else ''}{val}")
            elif key == "influence_delta":
                player.gain_influence(val)
                msg_parts.append(f"Influence: {'+' if val >= 0 else ''}{val}")
            elif key == "reputation_delta":
                player.adjust_reputation(val)
                msg_parts.append(f"Reputation: {'+' if val >= 0 else ''}{val}")
            elif key == "health_delta":
                player.adjust_health(val)
                msg_parts.append(f"Health: {'+' if val >= 0 else ''}{val}")

        return ", ".join(msg_parts) if msg_parts else "Nothing further occurred."
