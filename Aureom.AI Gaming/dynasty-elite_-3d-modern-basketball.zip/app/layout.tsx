import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Dynasty Elite: 3D Modern Basketball',
  description: 'An immersive 3D modern basketball simulation featuring responsive 5v5 gameplay, pro shot meter, tactical sliders, full season career mode, and procedural arena physics.',
  openGraph: {
    title: 'Dynasty Elite: 3D Modern Basketball',
    description: 'An immersive 3D modern basketball simulation featuring responsive 5v5 gameplay, pro shot meter, tactical sliders, full season career mode, and procedural arena physics.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Dynasty Elite: 3D Modern Basketball',
    description: 'An immersive 3D modern basketball simulation featuring responsive 5v5 gameplay, pro shot meter, tactical sliders, full season career mode, and procedural arena physics.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark bg-[#050508]">
      <body suppressHydrationWarning className="overflow-hidden m-0 p-0 bg-[#050508] text-[#e0e0f0] select-none font-sans">
        {children}
      </body>
    </html>
  );
}
