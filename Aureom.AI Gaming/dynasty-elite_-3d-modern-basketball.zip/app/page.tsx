'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { TitleScreen } from '../components/TitleScreen';
import { CareerTeamSelect } from '../components/CareerTeamSelect';
import { CareerHub } from '../components/CareerHub';
import { ExhibitionSelect } from '../components/ExhibitionSelect';
import { PreMatchView } from '../components/PreMatchView';
import { GameCanvas } from '../components/GameCanvas';
import { PostMatchModal } from '../components/PostMatchModal';
import { SeasonEndModal } from '../components/SeasonEndModal';

import { ScreenState, GameMode, Team, Player, Fixture, LeagueRow, TacticalSliders, MatchStats, MediaStory } from '../lib/game-types';
import { TEAMS_DEF, DEFAULT_SLIDERS, generateAllPlayers, generateFreeAgents } from '../lib/teams-data';
import { LeagueEngine } from '../lib/league-engine';
import { sound } from '../lib/sound';

const STORAGE_KEY = 'dynasty_elite_uk_v5_save';

export default function GameShell() {
  const [screen, setScreen] = useState<ScreenState>('title');
  const [gameMode, setGameMode] = useState<GameMode>('career');

  // Load initial saved payload once synchronously during state initialization
  const [savedData] = useState(() => {
    if (typeof window !== 'undefined') {
      try {
        const item = localStorage.getItem(STORAGE_KEY);
        if (item) return JSON.parse(item);
      } catch {
        // Fallback
      }
    }
    return null;
  });

  // Core Game State
  const [allTeams, setAllTeams] = useState<Team[]>(() => savedData?.allTeams || TEAMS_DEF);
  const [userTeamId, setUserTeamId] = useState<number>(() => savedData?.userTeamId ?? 0);
  const [season, setSeason] = useState<number>(() => savedData?.season ?? 1);
  const [currentWeek, setCurrentWeek] = useState<number>(() => savedData?.currentWeek ?? 1);
  const [careerStats, setCareerStats] = useState<{ wins: number; losses: number; titles: number }>(
    () => savedData?.careerStats || { wins: 0, losses: 0, titles: 0 }
  );

  const [players, setPlayers] = useState<Player[]>(() => savedData?.players || generateAllPlayers());
  const [freeAgents, setFreeAgents] = useState<Player[]>(() => savedData?.freeAgents || generateFreeAgents());
  const [fixtures, setFixtures] = useState<Fixture[]>(() => savedData?.fixtures || LeagueEngine.generateFixtures());
  const [sliders, setSliders] = useState<TacticalSliders>(() => savedData?.sliders || { ...DEFAULT_SLIDERS });
  const [selectedTactic, setSelectedTactic] = useState<string>(() => savedData?.selectedTactic || 'MOTION');
  const [mediaStories, setMediaStories] = useState<MediaStory[]>(() => savedData?.mediaStories || []);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Compute standings directly from allTeams and fixtures
  const standings = React.useMemo(() => {
    if (fixtures.length && allTeams.length) {
      return LeagueEngine.computeStandings(allTeams, fixtures);
    }
    return [];
  }, [allTeams, fixtures]);

  // Active Match Context
  const [activeMatchFixture, setActiveMatchFixture] = useState<Fixture | null>(null);
  const [activeHomeTeam, setActiveHomeTeam] = useState<Team>(TEAMS_DEF[0]);
  const [activeAwayTeam, setActiveAwayTeam] = useState<Team>(TEAMS_DEF[1]);
  const [lastMatchResult, setLastMatchResult] = useState<{
    homeScore: number;
    awayScore: number;
    stats: MatchStats;
  } | null>(null);

  // Persist state to LocalStorage
  const saveGameState = useCallback(() => {
    try {
      const dataToSave = {
        allTeams,
        userTeamId,
        season,
        currentWeek,
        careerStats,
        players,
        freeAgents,
        fixtures,
        sliders,
        selectedTactic,
        mediaStories,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    } catch {
      // Storage unavailable
    }
  }, [allTeams, userTeamId, season, currentWeek, careerStats, players, freeAgents, fixtures, sliders, selectedTactic, mediaStories]);

  const userTeam = allTeams.find(t => t.id === userTeamId) || allTeams[0];

  // Actions
  const handleToggleMute = () => {
    const next = sound.toggleMute();
    setIsMuted(next);
  };

  const handleStartCareer = () => {
    setScreen('career_select');
  };

  const handleSelectCareerTeam = (team: Team) => {
    setUserTeamId(team.id);
    setSelectedTactic(team.style || 'MOTION');
    setGameMode('career');
    setScreen('career_hub');
    saveGameState();
  };

  const handleStartExhibition = () => {
    setGameMode('exhibition');
    setScreen('exhibition_select');
  };

  const handleQuickPlay = () => {
    setGameMode('quickplay');
    const home = allTeams[0]; // London Royals
    const away = allTeams[1]; // Manchester Forge
    setActiveHomeTeam(home);
    setActiveAwayTeam(away);
    setActiveMatchFixture({
      week: 0,
      homeId: home.id,
      awayId: away.id,
      played: false,
      homeScore: 0,
      awayScore: 0,
    });
    setScreen('pre_match');
  };

  const handleLaunchExhibition = (home: Team, away: Team) => {
    setActiveHomeTeam(home);
    setActiveAwayTeam(away);
    setActiveMatchFixture({
      week: 0,
      homeId: home.id,
      awayId: away.id,
      played: false,
      homeScore: 0,
      awayScore: 0,
    });
    setScreen('pre_match');
  };

  const handleGoToPreMatch = (fixture: Fixture) => {
    const home = allTeams.find(t => t.id === fixture.homeId) || allTeams[0];
    const away = allTeams.find(t => t.id === fixture.awayId) || allTeams[1];
    setActiveHomeTeam(home);
    setActiveAwayTeam(away);
    setActiveMatchFixture(fixture);
    setScreen('pre_match');
  };

  const handleStart3DMatch = () => {
    setScreen('playing');
  };

  const handleSimulateMatch = () => {
    if (!activeMatchFixture) return;
    const result = LeagueEngine.simulateMatch(
      activeMatchFixture.homeId,
      activeMatchFixture.awayId,
      selectedTactic,
      'MOTION',
      allTeams,
      players
    );

    const dummyStats: MatchStats = {
      home: { shots: 42, made: 22, threes: 16, threesMade: 7, to: 8, steals: 6, blocks: 3, rebounds: 24 },
      away: { shots: 40, made: 19, threes: 14, threesMade: 5, to: 10, steals: 5, blocks: 2, rebounds: 22 },
    };

    handleMatchComplete(result.homeScore, result.awayScore, dummyStats);
  };

  const handleMatchComplete = (homeScore: number, awayScore: number, stats: MatchStats) => {
    setLastMatchResult({ homeScore, awayScore, stats });

    if (gameMode === 'career' && activeMatchFixture) {
      // Mark active fixture as played
      const updatedFixtures = fixtures.map(f => {
        if (f.week === activeMatchFixture.week && f.homeId === activeMatchFixture.homeId && f.awayId === activeMatchFixture.awayId) {
          return { ...f, played: true, homeScore, awayScore };
        }
        return f;
      });

      // Simulate remaining matches for this week
      updatedFixtures.forEach(f => {
        if (f.week === currentWeek && !f.played) {
          const simRes = LeagueEngine.simulateMatch(f.homeId, f.awayId, 'MOTION', 'MOTION', allTeams, players);
          f.played = true;
          f.homeScore = simRes.homeScore;
          f.awayScore = simRes.awayScore;
        }
      });

      setFixtures(updatedFixtures);

      // Update win/loss record
      const isUserHome = activeMatchFixture.homeId === userTeamId;
      const userWon = isUserHome ? homeScore > awayScore : awayScore > homeScore;
      setCareerStats(prev => ({
        ...prev,
        wins: userWon ? prev.wins + 1 : prev.wins,
        losses: userWon ? prev.losses : prev.losses + 1,
      }));

      // Award Matchday Revenue (£300K + £50K win bonus)
      setAllTeams(prevTeams =>
        prevTeams.map(t => {
          if (t.id === userTeamId) {
            return { ...t, funds: t.funds + 300000 + (userWon ? 50000 : 0) };
          }
          return t;
        })
      );

      // Generate weekly news story
      const newStandings = LeagueEngine.computeStandings(allTeams, updatedFixtures);
      const newStory = LeagueEngine.generateWeeklyStory(currentWeek, newStandings);
      setMediaStories(prev => [newStory, ...prev.slice(0, 18)]);

      // Advance week
      const nextWeek = currentWeek + 1;
      setCurrentWeek(nextWeek);
      saveGameState();
    }

    setScreen('post_match');
  };

  const handlePostMatchContinue = () => {
    if (gameMode === 'career') {
      if (currentWeek > 15) {
        setScreen('season_end');
      } else {
        setScreen('career_hub');
      }
    } else {
      setScreen('title');
    }
  };

  const handleStartNextSeason = () => {
    const nextSeasonNum = season + 1;
    setSeason(nextSeasonNum);
    setCurrentWeek(1);

    // Age players and apply skill variance
    setPlayers(prev =>
      prev.map(p => {
        const newAge = p.age + 1;
        let ovrDelta = 0;
        if (newAge <= 25) ovrDelta = Math.random() > 0.4 ? 1 : 2;
        else if (newAge >= 32) ovrDelta = Math.random() > 0.4 ? -1 : -2;

        return {
          ...p,
          age: newAge,
          ovr: Math.max(58, Math.min(99, p.ovr + ovrDelta)),
          morale: 80,
          fatigue: 0,
        };
      })
    );

    const freshFixtures = LeagueEngine.generateFixtures();
    setFixtures(freshFixtures);
    setFreeAgents(generateFreeAgents());
    saveGameState();
    setScreen('career_hub');
  };

  const handleBuyPlayer = (player: Player) => {
    if (userTeam.funds < player.askingPrice) return;
    setAllTeams(prev =>
      prev.map(t => (t.id === userTeamId ? { ...t, funds: t.funds - player.askingPrice } : t))
    );
    setPlayers(prev => [...prev, { ...player, teamId: userTeamId, starter: false }]);
    setFreeAgents(prev => prev.filter(f => f.id !== player.id));
    saveGameState();
  };

  const handleReleasePlayer = (player: Player) => {
    const compensation = Math.round((player.ovr - 60) * 50000);
    setAllTeams(prev =>
      prev.map(t => (t.id === userTeamId ? { ...t, funds: t.funds + compensation } : t))
    );
    setPlayers(prev => prev.filter(p => p.id !== player.id));
    setFreeAgents(prev => [{ ...player, teamId: null, starter: false }, ...prev]);
    saveGameState();
  };

  const handleTrainPlayer = (player: Player, stat: 'shooting' | 'speed' | 'defense' | 'stamina', cost: number) => {
    if (userTeam.funds < cost) return;
    setAllTeams(prev => prev.map(t => (t.id === userTeamId ? { ...t, funds: t.funds - cost } : t)));
    setPlayers(prev =>
      prev.map(p => {
        if (p.id === player.id) {
          const updatedStat = Math.min(99, p[stat] + 1);
          const newOvr = Math.round((p.shooting + p.speed + p.passing + p.defense + p.stamina + 1) / 5);
          return {
            ...p,
            [stat]: updatedStat,
            ovr: Math.max(p.ovr, newOvr),
          };
        }
        return p;
      })
    );
    saveGameState();
  };

  return (
    <main className="w-screen h-screen overflow-hidden bg-[#050508] text-white">
      {screen === 'title' && (
        <TitleScreen
          onStartCareer={handleStartCareer}
          onStartExhibition={handleStartExhibition}
          onQuickPlay={handleQuickPlay}
          onLoadGame={() => {
            if (localStorage.getItem(STORAGE_KEY)) {
              setScreen('career_hub');
            } else {
              handleStartCareer();
            }
          }}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {screen === 'career_select' && (
        <CareerTeamSelect
          onSelectTeam={handleSelectCareerTeam}
          onBack={() => setScreen('title')}
        />
      )}

      {screen === 'career_hub' && (
        <CareerHub
          userTeam={userTeam}
          allTeams={allTeams}
          players={players}
          freeAgents={freeAgents}
          fixtures={fixtures}
          standings={standings}
          currentWeek={currentWeek}
          season={season}
          careerStats={careerStats}
          sliders={sliders}
          selectedTactic={selectedTactic}
          mediaStories={mediaStories}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onGoToPreMatch={handleGoToPreMatch}
          onSimulateCurrentMatch={f => {
            handleGoToPreMatch(f);
            handleSimulateMatch();
          }}
          onUpdateSliders={setSliders}
          onUpdateTactic={setSelectedTactic}
          onBuyPlayer={handleBuyPlayer}
          onReleasePlayer={handleReleasePlayer}
          onTrainPlayer={handleTrainPlayer}
          onExitToMenu={() => setScreen('title')}
        />
      )}

      {screen === 'exhibition_select' && (
        <ExhibitionSelect
          onConfirmTeams={handleLaunchExhibition}
          onBack={() => setScreen('title')}
        />
      )}

      {screen === 'pre_match' && (
        <PreMatchView
          homeTeam={activeHomeTeam}
          awayTeam={activeAwayTeam}
          homePlayers={players.filter(p => p.teamId === activeHomeTeam.id)}
          awayPlayers={players.filter(p => p.teamId === activeAwayTeam.id)}
          homeSliders={sliders}
          onPlay3D={handleStart3DMatch}
          onSimulate={handleSimulateMatch}
          onBack={() => setScreen(gameMode === 'career' ? 'career_hub' : 'title')}
        />
      )}

      {screen === 'playing' && (
        <GameCanvas
          homeTeam={activeHomeTeam}
          awayTeam={activeAwayTeam}
          homePlayers={players.filter(p => p.teamId === activeHomeTeam.id)}
          awayPlayers={players.filter(p => p.teamId === activeAwayTeam.id)}
          homeSliders={sliders}
          awaySliders={DEFAULT_SLIDERS}
          onMatchComplete={handleMatchComplete}
          onExitMatch={() => setScreen(gameMode === 'career' ? 'career_hub' : 'title')}
        />
      )}

      {screen === 'post_match' && lastMatchResult && (
        <PostMatchModal
          homeTeam={activeHomeTeam}
          awayTeam={activeAwayTeam}
          homeScore={lastMatchResult.homeScore}
          awayScore={lastMatchResult.awayScore}
          stats={lastMatchResult.stats}
          isUserHome={activeHomeTeam.id === userTeamId}
          activePlayers={players.filter(p => p.teamId === activeHomeTeam.id)}
          onContinue={handlePostMatchContinue}
          onRematch={handleStart3DMatch}
        />
      )}

      {screen === 'season_end' && (
        <SeasonEndModal
          season={season}
          standings={standings}
          userTeam={userTeam}
          players={players}
          onStartNextSeason={handleStartNextSeason}
          onExitToMenu={() => setScreen('title')}
        />
      )}
    </main>
  );
}
