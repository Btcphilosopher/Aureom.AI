import { Fixture, LeagueRow, Player, Team, MediaStory } from './game-types';
import { TEAMS_DEF, TACTICS_DEF } from './teams-data';

export class LeagueEngine {
  // Generate round-robin tournament for 16 teams (15 rounds, 8 matches per round)
  public static generateFixtures(): Fixture[] {
    const ids = TEAMS_DEF.map(t => t.id);
    const n = ids.length;
    const fixtures: Fixture[] = [];
    const teams = [...ids];

    for (let round = 0; round < n - 1; round++) {
      for (let i = 0; i < n / 2; i++) {
        const home = teams[i];
        const away = teams[n - 1 - i];
        if (round % 2 === 0) {
          fixtures.push({
            week: round + 1,
            homeId: home,
            awayId: away,
            played: false,
            homeScore: 0,
            awayScore: 0,
          });
        } else {
          fixtures.push({
            week: round + 1,
            homeId: away,
            awayId: home,
            played: false,
            homeScore: 0,
            awayScore: 0,
          });
        }
      }
      // Rotate teams except first
      teams.splice(1, 0, teams.pop()!);
    }
    return fixtures;
  }

  // Calculate live average rating for starting five
  public static calculateTeamRating(teamId: number, players: Player[]): number {
    const starters = players.filter(p => p.teamId === teamId && p.starter);
    if (!starters.length) {
      const defaultTeam = TEAMS_DEF.find(t => t.id === teamId);
      return defaultTeam ? defaultTeam.rating : 75;
    }
    const sum = starters.reduce((acc, p) => acc + p.ovr, 0);
    return Math.round(sum / starters.length);
  }

  // Simulate a match between two clubs with tactical multipliers
  public static simulateMatch(
    homeId: number,
    awayId: number,
    homeTactic = 'MOTION',
    awayTactic = 'MOTION',
    teams: Team[],
    players: Player[]
  ): { homeScore: number; awayScore: number } {
    const ht = teams.find(t => t.id === homeId) || TEAMS_DEF[homeId] || TEAMS_DEF[0];
    const at = teams.find(t => t.id === awayId) || TEAMS_DEF[awayId] || TEAMS_DEF[1];

    const hTac = TACTICS_DEF.find(t => t.id === homeTactic) || TACTICS_DEF[0];
    const aTac = TACTICS_DEF.find(t => t.id === awayTactic) || TACTICS_DEF[0];

    const hRat = (ht.avgRating || ht.rating) * hTac.am + 4; // Home court bonus
    const aRat = (at.avgRating || at.rating) * aTac.am;

    const baseScore = 78 + Math.random() * 22;
    const diff = (hRat - aRat) * 0.45;

    let home = Math.round(baseScore + diff + (Math.random() - 0.45) * 16);
    let away = Math.round(baseScore - diff + (Math.random() - 0.45) * 16);

    // Basketball games rarely end in a tie
    if (home === away) {
      if (Math.random() > 0.5) home += 2;
      else away += 2;
    }

    home = Math.max(54, Math.min(138, home));
    away = Math.max(54, Math.min(138, away));

    return { homeScore: home, awayScore: away };
  }

  // Compute standings table sorted by Points > Point Differential > Points For
  public static computeStandings(teams: Team[], fixtures: Fixture[]): LeagueRow[] {
    const table: Record<number, LeagueRow> = {};
    teams.forEach(t => {
      table[t.id] = {
        id: t.id,
        name: t.name,
        abbr: t.abbr,
        col: t.col,
        p: 0,
        w: 0,
        l: 0,
        pts: 0,
        pf: 0,
        pa: 0,
        diff: 0,
        form: [],
      };
    });

    fixtures.filter(f => f.played).forEach(f => {
      const h = table[f.homeId];
      const a = table[f.awayId];
      if (!h || !a) return;

      h.p++;
      a.p++;
      h.pf += f.homeScore;
      h.pa += f.awayScore;
      a.pf += f.awayScore;
      a.pa += f.homeScore;

      h.diff = h.pf - h.pa;
      a.diff = a.pf - a.pa;

      if (f.homeScore > f.awayScore) {
        h.w++;
        h.pts += 2;
        h.form.push('W');
        a.l++;
        a.form.push('L');
      } else {
        a.w++;
        a.pts += 2;
        a.form.push('W');
        h.l++;
        h.form.push('L');
      }
    });

    return Object.values(table).sort((a, b) => {
      if (b.pts !== a.pts) return b.pts - a.pts;
      if (b.diff !== a.diff) return b.diff - a.diff;
      return b.pf - a.pf;
    });
  }

  // Generate newspaper / media headline
  public static generateWeeklyStory(week: number, standings: LeagueRow[]): MediaStory {
    const top = standings[0];
    const types: MediaStory['type'][] = ['LEAGUE', 'PERFORMANCE', 'DRAMA', 'TRANSFER'];
    const chosenType = types[Math.floor(Math.random() * types.length)];

    let headline = '';
    switch (chosenType) {
      case 'LEAGUE':
        headline = top ? `${top.name} tighten grip on #1 spot with ${top.w} wins` : `Championship race heats up in Week ${week}`;
        break;
      case 'PERFORMANCE':
        headline = `Spectacular 40-point clinic sends arena into frenzy`;
        break;
      case 'DRAMA':
        headline = `Head coach benches veteran starter following heated tactical film session`;
        break;
      case 'TRANSFER':
        headline = `League scouts spotted courting marquee free agents ahead of deadline`;
        break;
      default:
        headline = `British Basketball Elite simulation enters Week ${week}`;
    }

    return {
      id: `story-${Date.now()}-${Math.random()}`,
      type: chosenType,
      headline,
      meta: `WEEK ${week} EDITION`,
      week,
    };
  }
}
