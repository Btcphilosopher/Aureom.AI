export type ScreenState = 
  | 'title'
  | 'mode_select'
  | 'career_select'
  | 'career_hub'
  | 'exhibition_select'
  | 'pre_match'
  | 'playing'
  | 'post_match'
  | 'season_end';

export type GameMode = 'career' | 'exhibition' | 'quickplay';

export interface Player {
  id: number;
  teamId: number | null;
  num: number;
  name: string;
  pos: 'PG' | 'SG' | 'SF' | 'PF' | 'C';
  arch: string;
  ovr: number;
  speed: number;
  shooting: number;
  passing: number;
  defense: number;
  stamina: number;
  age: number;
  salary: number;
  morale: number;
  form: number;
  fatigue: number;
  injured: boolean;
  injuryWeeks: number;
  starter: boolean;
  askingPrice: number;
  isStar: boolean;
}

export interface Team {
  id: number;
  name: string;
  city: string;
  abbr: string;
  col: string;
  rating: number;
  avgRating: number;
  funds: number;
  trait: string;
  style: 'MOTION' | 'GRIND' | 'PACE' | 'ISO' | 'PRESS' | 'ZONE' | 'KOTLIN';
}

export interface TacticalSliders {
  tempo: number;      // 0 = Slow grind, 100 = 7 seconds or less
  defense: number;    // 0 = Sag off, 100 = Suffocating full-court press
  spacing: number;    // 0 = Tight post, 100 = 5-out perimeter
  help: number;       // 0 = Strict man-to-man, 100 = Aggressive collapse
  trans: number;      // 0 = Structured half-court, 100 = Fast break blitz
}

export interface Fixture {
  week: number;
  homeId: number;
  awayId: number;
  played: boolean;
  homeScore: number;
  awayScore: number;
}

export interface LeagueRow {
  id: number;
  name: string;
  abbr: string;
  col: string;
  p: number;
  w: number;
  l: number;
  pts: number;
  pf: number;
  pa: number;
  diff: number;
  form: ('W' | 'L')[];
}

export interface MatchStats {
  home: {
    shots: number;
    made: number;
    threes: number;
    threesMade: number;
    to: number;
    steals: number;
    blocks: number;
    rebounds: number;
  };
  away: {
    shots: number;
    made: number;
    threes: number;
    threesMade: number;
    to: number;
    steals: number;
    blocks: number;
    rebounds: number;
  };
}

export interface MediaStory {
  id: string;
  type: 'PERFORMANCE' | 'DRAMA' | 'INJURY' | 'TRANSFER' | 'LEAGUE';
  headline: string;
  meta: string;
  week: number;
}
