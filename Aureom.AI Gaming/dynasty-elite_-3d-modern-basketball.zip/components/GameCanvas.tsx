'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { ThreeBasketballArena } from './three-arena';
import { MatchHUD } from './MatchHUD';
import { Team, Player, TacticalSliders, MatchStats } from '../lib/game-types';
import { sound } from '../lib/sound';

interface GameCanvasProps {
  homeTeam: Team;
  awayTeam: Team;
  homePlayers: Player[];
  awayPlayers: Player[];
  homeSliders: TacticalSliders;
  awaySliders: TacticalSliders;
  onMatchComplete: (homeScore: number, awayScore: number, stats: MatchStats) => void;
  onExitMatch: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  homeTeam,
  awayTeam,
  homePlayers,
  awayPlayers,
  homeSliders,
  awaySliders,
  onMatchComplete,
  onExitMatch,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const arenaRef = useRef<ThreeBasketballArena | null>(null);

  // HUD State (buffered at non-60fps intervals to avoid React thrashing)
  const [homeScore, setHomeScore] = useState(0);
  const [awayScore, setAwayScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(150);
  const [quarter, setQuarter] = useState(1);
  const [shotClock, setShotClock] = useState(24.0);
  const [possession, setPossession] = useState(homeTeam.abbr);
  const [activePlayer, setActivePlayer] = useState<Player | null>(homePlayers[0] || null);
  const [cameraMode, setCameraMode] = useState<'broadcast' | 'follow' | 'tactical'>('broadcast');
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(sound.isMuted);

  const [shotMeter, setShotMeter] = useState<{ power: number; inGreen: boolean; active: boolean }>({
    power: 0,
    inGreen: false,
    active: false,
  });

  const [feedback, setFeedback] = useState<{ text: string; color: string } | null>(null);
  const feedbackTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const [quarterBreakModal, setQuarterBreakModal] = useState<{
    show: boolean;
    quarter: number;
    homeScore: number;
    awayScore: number;
  }>({ show: false, quarter: 1, homeScore: 0, awayScore: 0 });

  const handleFeedback = useCallback((text: string, color: string) => {
    setFeedback({ text, color });
    if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
    feedbackTimeoutRef.current = setTimeout(() => {
      setFeedback(null);
    }, 1200);
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;

    const arena = new ThreeBasketballArena(
      containerRef.current,
      homeTeam,
      awayTeam,
      homePlayers,
      awayPlayers,
      homeSliders,
      awaySliders,
      {
        onScoreUpdate: (h, a) => {
          setHomeScore(h);
          setAwayScore(a);
        },
        onClockTick: (time, q, sc) => {
          setTimeLeft(time);
          setQuarter(q);
          setShotClock(sc);
        },
        onShotMeterChange: (power, inGreen, active) => {
          setShotMeter({ power, inGreen, active });
        },
        onFeedbackText: handleFeedback,
        onQuarterEnd: (q, h, a) => {
          setQuarterBreakModal({ show: true, quarter: q, homeScore: h, awayScore: a });
        },
        onGameEnd: (h, a, stats) => {
          onMatchComplete(h, a, stats);
        },
        onPossessionChange: abbr => {
          setPossession(abbr);
        },
        onActivePlayerChange: p => {
          setActivePlayer(p);
        },
      }
    );

    arenaRef.current = arena;

    return () => {
      arena.dispose();
      arenaRef.current = null;
    };
  }, [homeTeam, awayTeam, homePlayers, awayPlayers, homeSliders, awaySliders, handleFeedback, onMatchComplete]);

  const handleSwitchCamera = (mode: 'broadcast' | 'follow' | 'tactical') => {
    setCameraMode(mode);
    if (arenaRef.current) {
      arenaRef.current.cameraMode = mode;
    }
  };

  const handleTogglePause = () => {
    const next = !isPaused;
    setIsPaused(next);
    if (arenaRef.current) {
      arenaRef.current.isPaused = next;
    }
  };

  const handleToggleMute = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  const handleResumeFromQuarterBreak = () => {
    setQuarterBreakModal(prev => ({ ...prev, show: false }));
    if (arenaRef.current) {
      arenaRef.current.isPaused = false;
    }
  };

  return (
    <div className="relative w-full h-full bg-black overflow-hidden select-none">
      {/* Isolated Three.js WebGL Canvas Mount Container */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />

      {/* Match HUD Overlay */}
      <MatchHUD
        homeTeam={homeTeam}
        awayTeam={awayTeam}
        homeScore={homeScore}
        awayScore={awayScore}
        timeLeft={timeLeft}
        quarter={quarter}
        shotClock={shotClock}
        possession={possession}
        activePlayer={activePlayer}
        cameraMode={cameraMode}
        onSwitchCamera={handleSwitchCamera}
        isPaused={isPaused}
        onTogglePause={handleTogglePause}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        shotMeter={shotMeter}
        feedback={feedback}
      />

      {/* Pause Menu Modal */}
      {isPaused && (
        <div className="absolute inset-0 z-30 bg-black/85 flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-zinc-950 border border-zinc-700 p-8 text-center shadow-2xl">
            <h2 className="font-['Bebas_Neue'] text-4xl text-[#c9a84c] tracking-[0.2em] mb-2">
              GAME PAUSED
            </h2>
            <p className="text-zinc-400 font-mono text-xs tracking-wider mb-6">
              QUARTER {quarter} · {homeTeam.abbr} {homeScore} — {awayScore} {awayTeam.abbr}
            </p>

            <div className="flex flex-col gap-3">
              <button
                onClick={() => { sound.click(); handleTogglePause(); }}
                className="w-full py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-widest font-bold hover:bg-[#ffd700] transition-colors cursor-pointer"
              >
                RESUME MATCH
              </button>

              <button
                onClick={() => {
                  sound.click();
                  handleSwitchCamera(cameraMode === 'broadcast' ? 'follow' : cameraMode === 'follow' ? 'tactical' : 'broadcast');
                }}
                className="w-full py-2.5 bg-zinc-900 border border-zinc-700 text-zinc-200 font-mono text-xs tracking-wider hover:border-[#00d4ff] transition-colors cursor-pointer"
              >
                TOGGLE CAMERA ({cameraMode.toUpperCase()})
              </button>

              <button
                onClick={() => { sound.click(); onExitMatch(); }}
                className="w-full py-2.5 bg-zinc-900/60 border border-red-900/50 text-red-400 font-mono text-xs tracking-wider hover:bg-red-950/40 transition-colors cursor-pointer"
              >
                FORFEIT & EXIT MATCH
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quarter Break / Half Time Modal */}
      {quarterBreakModal.show && (
        <div className="absolute inset-0 z-30 bg-black/90 flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-zinc-950 border border-zinc-700 p-8 text-center shadow-2xl">
            <div className="text-[#00d4ff] font-mono text-[11px] tracking-[0.3em] uppercase mb-1">
              End of Period
            </div>
            <h2 className="font-['Bebas_Neue'] text-5xl text-[#c9a84c] tracking-[0.2em] mb-4">
              {quarterBreakModal.quarter === 2 ? 'HALF TIME' : `QUARTER ${quarterBreakModal.quarter} COMPLETE`}
            </h2>

            <div className="flex items-center justify-center gap-6 my-6 bg-zinc-900/70 p-4 border border-zinc-800">
              <div className="text-center">
                <div className="font-['Bebas_Neue'] text-3xl font-bold" style={{ color: homeTeam.col }}>
                  {homeTeam.abbr}
                </div>
                <div className="font-mono text-4xl font-bold text-white mt-1">
                  {quarterBreakModal.homeScore}
                </div>
              </div>
              <div className="font-['Bebas_Neue'] text-2xl text-zinc-600">VS</div>
              <div className="text-center">
                <div className="font-['Bebas_Neue'] text-3xl font-bold" style={{ color: awayTeam.col }}>
                  {awayTeam.abbr}
                </div>
                <div className="font-mono text-4xl font-bold text-white mt-1">
                  {quarterBreakModal.awayScore}
                </div>
              </div>
            </div>

            <p className="text-zinc-400 font-sans italic text-sm mb-6">
              {quarterBreakModal.homeScore > quarterBreakModal.awayScore
                ? `${homeTeam.name} set the tone with relentless pressure.`
                : `${awayTeam.name} take control behind clinical transition execution.`}
            </p>

            <button
              onClick={() => { sound.click(); handleResumeFromQuarterBreak(); }}
              className="px-8 py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-[0.2em] font-bold hover:bg-[#ffd700] transition-colors cursor-pointer"
            >
              CONTINUE TO NEXT PERIOD →
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
