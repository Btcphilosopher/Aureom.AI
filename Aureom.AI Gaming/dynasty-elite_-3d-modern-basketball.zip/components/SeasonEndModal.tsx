'use client';

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { LeagueRow, Player, Team } from '../lib/game-types';
import { sound } from '../lib/sound';

interface SeasonEndModalProps {
  season: number;
  standings: LeagueRow[];
  userTeam: Team;
  players: Player[];
  onStartNextSeason: () => void;
  onExitToMenu: () => void;
}

export const SeasonEndModal: React.FC<SeasonEndModalProps> = ({
  season,
  standings,
  userTeam,
  players,
  onStartNextSeason,
  onExitToMenu,
}) => {
  const champion = standings[0];
  const userRank = standings.findIndex(s => s.id === userTeam.id) + 1;
  const isChampion = champion?.id === userTeam.id;

  useEffect(() => {
    sound.crowdCheer(true);
    confetti({
      particleCount: 120,
      spread: 90,
      origin: { y: 0.5 },
      colors: ['#c9a84c', '#00d4ff', '#ffffff', '#ffd700', '#3fff7a'],
    });
  }, []);

  const teamPlayers = players.filter(p => p.teamId === userTeam.id);
  const mvp = [...teamPlayers].sort((a, b) => b.ovr - a.ovr)[0];
  const topScorer = [...teamPlayers].sort((a, b) => b.shooting - a.shooting)[0];
  const bestDefender = [...teamPlayers].sort((a, b) => b.defense - a.defense)[0];

  return (
    <div className="w-full h-full flex items-center justify-center p-6 bg-[#050508] select-none overflow-y-auto">
      <div className="max-w-2xl w-full bg-zinc-950 border border-zinc-800 p-8 text-center shadow-2xl my-auto">
        <div className="text-6xl mb-2">🏆</div>
        <div className="text-[#00d4ff] font-mono text-[11px] tracking-[0.3em] uppercase mb-1">
          Season {season} Official Finale
        </div>
        <h1 className="font-['Bebas_Neue'] text-5xl md:text-6xl text-[#ffd700] tracking-[0.2em] mb-2">
          {isChampion ? 'CHAMPIONS OF BRITAIN!' : 'SEASON COMPLETE'}
        </h1>
        <p className="text-zinc-400 font-mono text-xs tracking-wider mb-6">
          {champion?.name.toUpperCase()} LIFT THE DYNASTY ELITE UK TROPHY · {userTeam.name} FINISH #{userRank}
        </p>

        {/* Awards Row */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 bg-zinc-900/50 border border-zinc-800 text-left font-mono">
            <div className="text-[9px] text-zinc-500 uppercase">Season MVP</div>
            <div className="font-bold text-white text-xs mt-0.5 truncate">{mvp?.name || 'Kofi Williams'}</div>
            <div className="text-[10px] text-[#ffd700]">OVR {mvp?.ovr || 96}</div>
          </div>

          <div className="p-3 bg-zinc-900/50 border border-zinc-800 text-left font-mono">
            <div className="text-[9px] text-zinc-500 uppercase">Top Scorer</div>
            <div className="font-bold text-white text-xs mt-0.5 truncate">{topScorer?.name || 'Marcus Reid'}</div>
            <div className="text-[10px] text-[#00d4ff]">SHT {topScorer?.shooting || 92}</div>
          </div>

          <div className="p-3 bg-zinc-900/50 border border-zinc-800 text-left font-mono">
            <div className="text-[9px] text-zinc-500 uppercase">Defensive Anchor</div>
            <div className="font-bold text-white text-xs mt-0.5 truncate">{bestDefender?.name || 'Curtis Hughes'}</div>
            <div className="text-[10px] text-[#3fff7a]">DEF {bestDefender?.defense || 90}</div>
          </div>
        </div>

        {/* Mini Standings Summary */}
        <div className="border border-zinc-800 bg-[#0e0e18] p-3 mb-6 max-h-48 overflow-y-auto">
          <table className="w-full text-center font-mono text-xs">
            <thead className="text-[9px] text-zinc-500 border-b border-zinc-800 pb-1">
              <tr>
                <th className="text-left p-1"># CLUB</th>
                <th className="p-1">W</th>
                <th className="p-1">L</th>
                <th className="p-1">PTS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/40">
              {standings.map((row, idx) => (
                <tr key={row.id} className={row.id === userTeam.id ? 'bg-[#c9a84c]/15 text-[#ffd700] font-bold' : ''}>
                  <td className="text-left p-1">{idx + 1}. {row.name}</td>
                  <td className="p-1 text-[#3fff7a]">{row.w}</td>
                  <td className="p-1 text-[#ff3a3a]">{row.l}</td>
                  <td className="p-1 font-bold text-white">{row.pts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => { sound.click(); onStartNextSeason(); }}
            className="px-8 py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-[0.2em] font-bold hover:bg-[#ffd700] hover:scale-105 transition-all cursor-pointer shadow-lg"
          >
            ADVANCE TO SEASON {season + 1} →
          </button>

          <button
            onClick={() => { sound.click(); onExitToMenu(); }}
            className="px-6 py-3 bg-zinc-900 border border-zinc-700 text-zinc-300 font-['Bebas_Neue'] text-xl tracking-[0.15em] hover:text-white cursor-pointer"
          >
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
};
