'use client';

import React, { useState } from 'react';
import { Team, Player } from '../lib/game-types';
import { TEAMS_DEF, RAW_ROSTERS } from '../lib/teams-data';
import { sound } from '../lib/sound';

interface ExhibitionSelectProps {
  onConfirmTeams: (homeTeam: Team, awayTeam: Team) => void;
  onBack: () => void;
}

export const ExhibitionSelect: React.FC<ExhibitionSelectProps> = ({ onConfirmTeams, onBack }) => {
  const [homeId, setHomeId] = useState<number>(0);
  const [awayId, setAwayId] = useState<number>(1);

  const homeTeam = TEAMS_DEF.find(t => t.id === homeId) || TEAMS_DEF[0];
  const awayTeam = TEAMS_DEF.find(t => t.id === awayId) || TEAMS_DEF[1];

  const getStarPlayer = (teamId: number) => {
    const list = RAW_ROSTERS[teamId];
    return list ? list[0] : null;
  };

  const handleLaunch = () => {
    sound.buzzer();
    onConfirmTeams(homeTeam, awayTeam);
  };

  return (
    <div className="w-full h-full flex flex-col bg-[#050508] p-6 overflow-hidden select-none">
      {/* Header */}
      <div className="flex items-baseline justify-between border-b border-zinc-800 pb-4 mb-4">
        <div>
          <h1 className="font-['Bebas_Neue'] text-4xl text-[#c9a84c] tracking-[0.15em]">
            EXHIBITION MATCHUP
          </h1>
          <p className="text-zinc-400 font-mono text-xs tracking-wider">
            CHOOSE HOME & AWAY CLUBS · ONE-OFF FULL 5v5 3D CLASH
          </p>
        </div>

        <button
          onClick={() => { sound.click(); onBack(); }}
          className="px-4 py-2 border border-zinc-700 text-zinc-400 hover:text-white hover:border-zinc-500 font-mono text-xs tracking-wider cursor-pointer transition-colors"
        >
          ← BACK TO MENU
        </button>
      </div>

      {/* Main Selection Columns */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">
        {/* Left: Home Team Picker */}
        <div className="lg:col-span-5 flex flex-col border border-zinc-800 bg-zinc-950/60 p-4 min-h-0">
          <div className="flex items-center justify-between mb-3 border-b border-zinc-800 pb-2">
            <span className="font-['Bebas_Neue'] text-xl text-[#c9a84c] tracking-wider">
              ● SELECT HOME CLUB
            </span>
            <span className="text-xs font-mono text-zinc-400 font-bold" style={{ color: homeTeam.col }}>
              {homeTeam.name} ({homeTeam.rating} OVR)
            </span>
          </div>

          <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-2 gap-2">
            {TEAMS_DEF.map(t => {
              const isSelected = t.id === homeId;
              const star = getStarPlayer(t.id);
              return (
                <div
                  key={t.id}
                  onClick={() => { sound.click(); setHomeId(t.id); }}
                  className={`p-3 border transition-all cursor-pointer ${isSelected ? 'border-[#c9a84c] bg-[#c9a84c]/10' : 'border-zinc-800 hover:border-zinc-700 bg-zinc-900/40'}`}
                >
                  <div className="flex items-baseline justify-between">
                    <span className="font-['Bebas_Neue'] text-2xl" style={{ color: t.col }}>
                      {t.abbr}
                    </span>
                    <span className="font-mono text-xs text-zinc-300 font-bold">{t.rating}</span>
                  </div>
                  <div className="text-xs text-white font-bold truncate mt-1">{t.name}</div>
                  <div className="text-[10px] text-zinc-500 font-mono tracking-wider">{t.trait}</div>
                  {star && (
                    <div className="text-[9px] text-[#ffd700] font-mono mt-1 truncate">
                      ★ {star[1]} ({star[4]})
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Center: VS Showcase */}
        <div className="lg:col-span-2 flex flex-col items-center justify-center border border-zinc-800 bg-zinc-950 p-6 text-center">
          <div className="font-['Bebas_Neue'] text-5xl text-zinc-700 tracking-widest my-2">
            VS
          </div>

          <div className="w-full my-4 p-3 bg-zinc-900/60 border border-zinc-800">
            <div className="font-['Bebas_Neue'] text-3xl font-bold" style={{ color: homeTeam.col }}>
              {homeTeam.abbr}
            </div>
            <div className="text-xs text-zinc-400 font-mono">{homeTeam.name}</div>
            <div className="text-[10px] text-[#c9a84c] font-mono mt-1">OVR {homeTeam.rating}</div>
          </div>

          <div className="w-full my-2 p-3 bg-zinc-900/60 border border-zinc-800">
            <div className="font-['Bebas_Neue'] text-3xl font-bold" style={{ color: awayTeam.col }}>
              {awayTeam.abbr}
            </div>
            <div className="text-xs text-zinc-400 font-mono">{awayTeam.name}</div>
            <div className="text-[10px] text-[#00d4ff] font-mono mt-1">OVR {awayTeam.rating}</div>
          </div>

          <button
            onClick={handleLaunch}
            className="w-full mt-6 py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-[0.2em] font-bold hover:bg-[#ffd700] hover:scale-105 transition-all shadow-lg cursor-pointer"
          >
            TIP OFF →
          </button>
        </div>

        {/* Right: Away Team Picker */}
        <div className="lg:col-span-5 flex flex-col border border-zinc-800 bg-zinc-950/60 p-4 min-h-0">
          <div className="flex items-center justify-between mb-3 border-b border-zinc-800 pb-2">
            <span className="font-['Bebas_Neue'] text-xl text-[#00d4ff] tracking-wider">
              ● SELECT AWAY CLUB
            </span>
            <span className="text-xs font-mono text-zinc-400 font-bold" style={{ color: awayTeam.col }}>
              {awayTeam.name} ({awayTeam.rating} OVR)
            </span>
          </div>

          <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-2 gap-2">
            {TEAMS_DEF.map(t => {
              const isSelected = t.id === awayId;
              const star = getStarPlayer(t.id);
              return (
                <div
                  key={t.id}
                  onClick={() => { sound.click(); setAwayId(t.id); }}
                  className={`p-3 border transition-all cursor-pointer ${isSelected ? 'border-[#00d4ff] bg-[#00d4ff]/10' : 'border-zinc-800 hover:border-zinc-700 bg-zinc-900/40'}`}
                >
                  <div className="flex items-baseline justify-between">
                    <span className="font-['Bebas_Neue'] text-2xl" style={{ color: t.col }}>
                      {t.abbr}
                    </span>
                    <span className="font-mono text-xs text-zinc-300 font-bold">{t.rating}</span>
                  </div>
                  <div className="text-xs text-white font-bold truncate mt-1">{t.name}</div>
                  <div className="text-[10px] text-zinc-500 font-mono tracking-wider">{t.trait}</div>
                  {star && (
                    <div className="text-[9px] text-[#ffd700] font-mono mt-1 truncate">
                      ★ {star[1]} ({star[4]})
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
