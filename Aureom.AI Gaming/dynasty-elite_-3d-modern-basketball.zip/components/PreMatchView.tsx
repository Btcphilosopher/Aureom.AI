'use client';

import React from 'react';
import { Team, Player, TacticalSliders } from '../lib/game-types';
import { sound } from '../lib/sound';

interface PreMatchViewProps {
  homeTeam: Team;
  awayTeam: Team;
  homePlayers: Player[];
  awayPlayers: Player[];
  homeSliders: TacticalSliders;
  eyebrow?: string;
  onPlay3D: () => void;
  onSimulate: () => void;
  onBack: () => void;
}

export const PreMatchView: React.FC<PreMatchViewProps> = ({
  homeTeam,
  awayTeam,
  homePlayers,
  awayPlayers,
  homeSliders,
  eyebrow = 'UK BASKETBALL PREMIER LEAGUE · MATCH DAY',
  onPlay3D,
  onSimulate,
  onBack,
}) => {
  const homeStarters = homePlayers.filter(p => p.starter).slice(0, 5);
  const awayStarters = awayPlayers.filter(p => p.starter).slice(0, 5);

  const homeAvg = Math.round(homeStarters.reduce((acc, p) => acc + p.ovr, 0) / (homeStarters.length || 1));
  const awayAvg = Math.round(awayStarters.reduce((acc, p) => acc + p.ovr, 0) / (awayStarters.length || 1));

  const total = homeAvg + awayAvg;
  const homeWinPct = Math.round((homeAvg / total) * 100);
  const awayWinPct = 100 - homeWinPct;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-[#050508] select-none relative overflow-hidden">
      {/* Background Graphic Lines */}
      <div 
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            radial-gradient(circle at 50% 50%, rgba(0, 212, 255, 0.12) 0%, transparent 60%),
            repeating-linear-gradient(45deg, rgba(255, 255, 255, 0.04) 0px, rgba(255, 255, 255, 0.04) 1px, transparent 1px, transparent 24px)
          `,
        }}
      />

      <div className="max-w-4xl w-full flex flex-col items-center text-center z-10">
        <div className="text-[#00d4ff] font-mono text-[11px] tracking-[0.35em] uppercase mb-4">
          {eyebrow}
        </div>

        {/* Head-to-Head Club Banners */}
        <div className="w-full grid grid-cols-5 items-center gap-4 my-4 bg-zinc-950/80 border border-zinc-800 p-8 shadow-2xl">
          {/* Home Club */}
          <div className="col-span-2 flex flex-col items-center">
            <div 
              className="font-['Bebas_Neue'] text-7xl md:text-8xl font-black tracking-wider leading-none"
              style={{ color: homeTeam.col }}
            >
              {homeTeam.abbr}
            </div>
            <div className="text-zinc-200 font-bold text-lg tracking-wider mt-2">
              {homeTeam.name}
            </div>
            <div className="text-xs text-[#c9a84c] font-mono tracking-widest mt-1">
              RATING {homeAvg} · {homeTeam.trait}
            </div>
          </div>

          {/* VS Divider */}
          <div className="col-span-1 flex flex-col items-center">
            <span className="font-['Bebas_Neue'] text-4xl text-zinc-600 tracking-widest">
              VS
            </span>
            <span className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase mt-1">
              TIP-OFF
            </span>
          </div>

          {/* Away Club */}
          <div className="col-span-2 flex flex-col items-center">
            <div 
              className="font-['Bebas_Neue'] text-7xl md:text-8xl font-black tracking-wider leading-none"
              style={{ color: awayTeam.col }}
            >
              {awayTeam.abbr}
            </div>
            <div className="text-zinc-200 font-bold text-lg tracking-wider mt-2">
              {awayTeam.name}
            </div>
            <div className="text-xs text-[#00d4ff] font-mono tracking-widest mt-1">
              RATING {awayAvg} · {awayTeam.trait}
            </div>
          </div>
        </div>

        {/* Win Probability Forecast Bar */}
        <div className="w-full bg-zinc-950 border border-zinc-800 p-4 mb-6">
          <div className="flex justify-between items-center text-xs font-mono text-zinc-400 mb-2">
            <span>WIN PROBABILITY: <b className="text-[#ffd700]">{homeWinPct}%</b></span>
            <span>{awayTeam.abbr} WIN PROBABILITY: <b className="text-[#00d4ff]">{awayWinPct}%</b></span>
          </div>
          <div className="w-full h-2 bg-zinc-900 overflow-hidden flex">
            <div className="h-full bg-[#c9a84c] transition-all" style={{ width: `${homeWinPct}%` }} />
            <div className="h-full bg-[#00d4ff] transition-all" style={{ width: `${awayWinPct}%` }} />
          </div>
        </div>

        {/* Starting Lineups Summary */}
        <div className="w-full grid grid-cols-2 gap-4 mb-6 text-left">
          <div className="bg-zinc-950/70 border border-zinc-800 p-3">
            <div className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-800 pb-1 mb-2">
              {homeTeam.name} Starting Five
            </div>
            <div className="space-y-1">
              {homeStarters.map(p => (
                <div key={p.id} className="flex justify-between text-xs font-mono">
                  <span className="text-zinc-300">#{p.num} {p.name} ({p.pos})</span>
                  <span className="text-[#ffd700] font-bold">{p.ovr}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-zinc-950/70 border border-zinc-800 p-3">
            <div className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-800 pb-1 mb-2">
              {awayTeam.name} Starting Five
            </div>
            <div className="space-y-1">
              {awayStarters.map(p => (
                <div key={p.id} className="flex justify-between text-xs font-mono">
                  <span className="text-zinc-300">#{p.num} {p.name} ({p.pos})</span>
                  <span className="text-[#00d4ff] font-bold">{p.ovr}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tactical Sliders Preview */}
        <div className="flex flex-wrap justify-center gap-4 text-[11px] font-mono text-zinc-400 mb-8 bg-zinc-900/40 p-2.5 px-6 border border-zinc-800">
          <span>TEMPO: <b className="text-zinc-200">{homeSliders.tempo}</b></span>
          <span>·</span>
          <span>DEFENSE: <b className="text-zinc-200">{homeSliders.defense}</b></span>
          <span>·</span>
          <span>SPACING: <b className="text-zinc-200">{homeSliders.spacing}</b></span>
          <span>·</span>
          <span>HELP DEF: <b className="text-zinc-200">{homeSliders.help}</b></span>
          <span>·</span>
          <span>TRANSITION: <b className="text-zinc-200">{homeSliders.trans}</b></span>
        </div>

        {/* Action CTAs */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => { sound.click(); onPlay3D(); }}
            className="px-10 py-3.5 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-2xl tracking-[0.2em] font-bold hover:bg-[#ffd700] hover:scale-105 transition-all shadow-[0_0_25px_rgba(201,168,76,0.35)] cursor-pointer"
          >
            ▶ PLAY 3D MATCH
          </button>

          <button
            onClick={() => { sound.click(); onSimulate(); }}
            className="px-8 py-3.5 bg-zinc-900 border border-zinc-700 text-zinc-200 font-['Bebas_Neue'] text-2xl tracking-[0.2em] hover:border-[#00d4ff] hover:text-[#00d4ff] transition-all cursor-pointer"
          >
            ⚡ QUICK SIMULATE
          </button>

          <button
            onClick={() => { sound.click(); onBack(); }}
            className="px-6 py-3.5 bg-zinc-950 border border-zinc-800 text-zinc-400 font-mono text-xs tracking-wider hover:text-white transition-all cursor-pointer"
          >
            ← BACK
          </button>
        </div>
      </div>
    </div>
  );
};
