'use client';

import React, { useState } from 'react';
import { 
  Trophy, 
  Users, 
  Sliders, 
  Calendar, 
  Table as TableIcon, 
  ArrowLeftRight, 
  Dumbbell, 
  Newspaper, 
  Play, 
  Zap, 
  DollarSign,
  TrendingUp,
  Volume2,
  VolumeX,
  Home
} from 'lucide-react';
import { Team, Player, Fixture, LeagueRow, TacticalSliders, MediaStory } from '../lib/game-types';
import { TACTICS_DEF, STYLE_SLIDERS } from '../lib/teams-data';
import { sound } from '../lib/sound';

interface CareerHubProps {
  userTeam: Team;
  allTeams: Team[];
  players: Player[];
  freeAgents: Player[];
  fixtures: Fixture[];
  standings: LeagueRow[];
  currentWeek: number;
  season: number;
  careerStats: { wins: number; losses: number; titles: number };
  sliders: TacticalSliders;
  selectedTactic: string;
  mediaStories: MediaStory[];
  isMuted: boolean;
  onToggleMute: () => void;
  onGoToPreMatch: (fixture: Fixture) => void;
  onSimulateCurrentMatch: (fixture: Fixture) => void;
  onUpdateSliders: (sliders: TacticalSliders) => void;
  onUpdateTactic: (tacticId: string) => void;
  onBuyPlayer: (player: Player) => void;
  onReleasePlayer: (player: Player) => void;
  onTrainPlayer: (player: Player, stat: 'shooting' | 'speed' | 'defense' | 'stamina', cost: number) => void;
  onExitToMenu: () => void;
}

type TabType = 'overview' | 'squad' | 'tactics' | 'fixtures' | 'table' | 'transfers' | 'training' | 'media';

export const CareerHub: React.FC<CareerHubProps> = ({
  userTeam,
  allTeams,
  players,
  freeAgents,
  fixtures,
  standings,
  currentWeek,
  season,
  careerStats,
  sliders,
  selectedTactic,
  mediaStories,
  isMuted,
  onToggleMute,
  onGoToPreMatch,
  onSimulateCurrentMatch,
  onUpdateSliders,
  onUpdateTactic,
  onBuyPlayer,
  onReleasePlayer,
  onTrainPlayer,
  onExitToMenu,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    onConfirm: () => void;
  } | null>(null);

  const userPlayers = players.filter(p => p.teamId === userTeam.id);
  const starters = userPlayers.filter(p => p.starter).slice(0, 5);
  const bench = userPlayers.filter(p => !p.starter);

  const nextFixture = fixtures.find(f => !f.played && (f.homeId === userTeam.id || f.awayId === userTeam.id));
  const opponentTeam = nextFixture
    ? allTeams.find(t => t.id === (nextFixture.homeId === userTeam.id ? nextFixture.awayId : nextFixture.homeId))
    : null;

  const userRank = standings.findIndex(s => s.id === userTeam.id) + 1;
  const userStanding = standings.find(s => s.id === userTeam.id);

  const handleSliderChange = (key: keyof TacticalSliders, value: number) => {
    onUpdateSliders({
      ...sliders,
      [key]: value,
    });
  };

  const handleApplyPreset = (tacticId: string) => {
    const preset = STYLE_SLIDERS[tacticId];
    if (preset) {
      sound.click();
      onUpdateSliders(preset);
      onUpdateTactic(tacticId);
    }
  };

  return (
    <div className="w-full h-full flex flex-col md:flex-row bg-[#050508] text-[#e0e0f0] select-none overflow-hidden">
      {/* ── LEFT SIDEBAR ── */}
      <div className="w-full md:w-64 bg-[#08080e] border-r border-zinc-800 flex flex-col shrink-0">
        {/* Brand Logo */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <div>
            <div className="font-['Bebas_Neue'] text-xl text-[#c9a84c] tracking-[0.18em]">
              DYNASTY ELITE
            </div>
            <div className="font-mono text-[9px] text-zinc-500 tracking-widest">
              UK SEASON ENGINE V5
            </div>
          </div>
          <button
            onClick={() => { sound.click(); onExitToMenu(); }}
            className="p-1.5 text-zinc-500 hover:text-white border border-zinc-800 hover:border-zinc-700 transition-colors"
            title="Main Menu"
          >
            <Home size={14} />
          </button>
        </div>

        {/* Managed Club Badge */}
        <div className="p-4 border-b border-zinc-800 bg-zinc-950/40">
          <div className="flex items-baseline justify-between">
            <span className="font-['Bebas_Neue'] text-3xl tracking-wider" style={{ color: userTeam.col }}>
              {userTeam.abbr}
            </span>
            <span className="font-mono text-xs text-zinc-400 font-bold">
              S{season} · WK {currentWeek}/15
            </span>
          </div>
          <div className="text-xs text-white font-bold truncate mt-0.5">{userTeam.name}</div>
          <div className="text-[10px] text-[#00d4ff] font-mono tracking-wider mt-1">{userTeam.trait}</div>
        </div>

        {/* Tab Navigation Menu */}
        <div className="flex-1 overflow-y-auto py-2 space-y-0.5 font-mono text-xs">
          {[
            { id: 'overview', label: 'OVERVIEW', icon: Trophy },
            { id: 'squad', label: 'SQUAD ROSTER', icon: Users },
            { id: 'tactics', label: 'TACTICS & SLIDERS', icon: Sliders },
            { id: 'fixtures', label: 'SEASON FIXTURES', icon: Calendar },
            { id: 'table', label: 'LEAGUE TABLE', icon: TableIcon },
            { id: 'transfers', label: 'TRANSFERS', icon: ArrowLeftRight },
            { id: 'training', label: 'TRAINING FACILITY', icon: Dumbbell },
            { id: 'media', label: 'LEAGUE INTEL & MEDIA', icon: Newspaper },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => { sound.click(); setActiveTab(tab.id as TabType); }}
                className={`w-full px-4 py-2.5 flex items-center gap-3 text-left transition-colors cursor-pointer border-l-2 ${isActive ? 'bg-[#c9a84c]/10 text-[#c9a84c] border-[#c9a84c] font-bold' : 'text-zinc-400 hover:text-zinc-200 border-transparent hover:bg-zinc-900/40'}`}
              >
                <Icon size={14} className={isActive ? 'text-[#c9a84c]' : 'text-zinc-500'} />
                <span className="tracking-wider">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Club Finances & Record Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950/60 font-mono text-xs space-y-1">
          <div className="flex justify-between">
            <span className="text-zinc-500">LEAGUE POS:</span>
            <span className="text-[#ffd700] font-bold">#{userRank} OF 16</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500">RECORD:</span>
            <span className="text-white font-bold">{careerStats.wins}W — {careerStats.losses}L</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500">BUDGET:</span>
            <span className="text-[#3fff7a] font-bold">£{(userTeam.funds / 1000000).toFixed(2)}M</span>
          </div>
          <div className="pt-2 flex justify-between items-center text-[10px] text-zinc-500">
            <span>SOUND FX</span>
            <button
              onClick={onToggleMute}
              className="p-1 text-zinc-400 hover:text-white"
            >
              {isMuted ? <VolumeX size={12} /> : <Volume2 size={12} />}
            </button>
          </div>
        </div>
      </div>

      {/* ── MAIN CONTENT AREA ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header Bar */}
        <div className="p-4 px-6 border-b border-zinc-800 flex items-center justify-between shrink-0 bg-[#08080e]/60">
          <h2 className="font-['Bebas_Neue'] text-3xl text-white tracking-[0.15em]">
            {activeTab.toUpperCase()}
          </h2>
          <div className="font-mono text-xs text-zinc-400 flex items-center gap-4">
            <span>SEASON {season}</span>
            <span>·</span>
            <span className="text-[#c9a84c]">WEEK {currentWeek} / 15</span>
          </div>
        </div>

        {/* Dynamic Tab Content Container */}
        <div className="flex-1 overflow-y-auto p-6 min-h-0">
          {/* 1. OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <div className="space-y-6 max-w-6xl">
              {/* Stat Cards Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-[#0e0e18] border border-zinc-800 p-4">
                  <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">League Standing</div>
                  <div className="font-['Bebas_Neue'] text-4xl text-[#ffd700] mt-1">
                    {userRank}{userRank === 1 ? 'ST' : userRank === 2 ? 'ND' : userRank === 3 ? 'RD' : 'TH'}
                  </div>
                  <div className="text-[10px] font-mono text-zinc-400 mt-0.5">PTS: {userStanding?.pts || 0}</div>
                </div>

                <div className="bg-[#0e0e18] border border-zinc-800 p-4">
                  <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Season Record</div>
                  <div className="font-['Bebas_Neue'] text-4xl text-white mt-1">
                    {careerStats.wins}W — {careerStats.losses}L
                  </div>
                  <div className="text-[10px] font-mono text-zinc-400 mt-0.5">Win %: {Math.round((careerStats.wins / (careerStats.wins + careerStats.losses || 1)) * 100)}%</div>
                </div>

                <div className="bg-[#0e0e18] border border-zinc-800 p-4">
                  <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Club Treasury</div>
                  <div className="font-['Bebas_Neue'] text-4xl text-[#3fff7a] mt-1">
                    £{(userTeam.funds / 1000000).toFixed(2)}M
                  </div>
                  <div className="text-[10px] font-mono text-zinc-400 mt-0.5">+£300K / Matchday</div>
                </div>

                <div className="bg-[#0e0e18] border border-zinc-800 p-4">
                  <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Starting 5 OVR</div>
                  <div className="font-['Bebas_Neue'] text-4xl text-[#00d4ff] mt-1">
                    {Math.round(starters.reduce((acc, p) => acc + p.ovr, 0) / (starters.length || 1))}
                  </div>
                  <div className="text-[10px] font-mono text-zinc-400 mt-0.5">Style: {selectedTactic}</div>
                </div>
              </div>

              {/* Next Fixture Spotlight Card */}
              {nextFixture && opponentTeam ? (
                <div className="bg-[#0e0e18] border border-zinc-800 p-6 shadow-xl relative overflow-hidden">
                  <div className="text-[10px] font-mono text-zinc-500 tracking-[0.25em] uppercase mb-4">
                    NEXT FIXTURE · WEEK {nextFixture.week} OF 15
                  </div>

                  <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <div className="font-['Bebas_Neue'] text-4xl font-bold" style={{ color: userTeam.col }}>
                          {userTeam.abbr}
                        </div>
                        <div className="text-xs text-zinc-300 font-bold">{userTeam.name}</div>
                      </div>

                      <div className="font-['Bebas_Neue'] text-2xl text-zinc-600">
                        {nextFixture.homeId === userTeam.id ? 'VS' : '@'}
                      </div>

                      <div className="text-center">
                        <div className="font-['Bebas_Neue'] text-4xl font-bold" style={{ color: opponentTeam.col }}>
                          {opponentTeam.abbr}
                        </div>
                        <div className="text-xs text-zinc-300 font-bold">{opponentTeam.name}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => { sound.click(); onGoToPreMatch(nextFixture); }}
                        className="px-6 py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-[0.2em] font-bold hover:bg-[#ffd700] hover:scale-105 transition-all cursor-pointer shadow-lg flex items-center gap-2"
                      >
                        <Play size={16} fill="black" /> PLAY MATCH
                      </button>

                      <button
                        onClick={() => { sound.click(); onSimulateCurrentMatch(nextFixture); }}
                        className="px-5 py-3 bg-zinc-900 border border-zinc-700 text-zinc-300 font-['Bebas_Neue'] text-xl tracking-[0.15em] hover:border-[#00d4ff] hover:text-[#00d4ff] transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Zap size={16} /> QUICK SIM
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-[#0e0e18] border border-zinc-800 p-6 text-center font-mono text-zinc-400">
                  ALL 15 FIXTURES COMPLETED FOR SEASON {season}. HEAD TO STANDINGS FOR CHAMPIONSHIP AUDIT.
                </div>
              )}

              {/* Form & Recent Intel */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#0e0e18] border border-zinc-800 p-4">
                  <div className="font-['Bebas_Neue'] text-lg text-white tracking-wider mb-2">RECENT FORM</div>
                  <div className="flex gap-2">
                    {userStanding?.form.slice(-6).map((res, i) => (
                      <span
                        key={i}
                        className={`w-8 h-8 flex items-center justify-center font-mono text-xs font-bold border ${res === 'W' ? 'border-[#3fff7a] text-[#3fff7a] bg-[#3fff7a]/10' : 'border-[#ff3a3a] text-[#ff3a3a] bg-[#ff3a3a]/10'}`}
                      >
                        {res}
                      </span>
                    )) || <span className="text-xs font-mono text-zinc-500">NO GAMES PLAYED YET</span>}
                  </div>
                </div>

                <div className="bg-[#0e0e18] border border-zinc-800 p-4">
                  <div className="font-['Bebas_Neue'] text-lg text-[#00d4ff] tracking-wider mb-2">LATEST CLUB INTEL</div>
                  <p className="text-xs font-mono text-zinc-300 italic">
                    {mediaStories[0]?.headline || 'Camp is disciplined and focused ahead of matchday.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2. SQUAD ROSTER TAB */}
          {activeTab === 'squad' && (
            <div className="space-y-6 max-w-6xl">
              <div>
                <div className="text-[10px] font-mono text-zinc-500 tracking-widest uppercase mb-2">
                  STARTING FIVE
                </div>
                <div className="overflow-x-auto border border-zinc-800 bg-[#0e0e18]">
                  <table className="w-full text-left font-mono text-xs">
                    <thead className="bg-zinc-950 text-zinc-500 text-[10px] border-b border-zinc-800">
                      <tr>
                        <th className="p-3">POS</th>
                        <th className="p-3">PLAYER</th>
                        <th className="p-3">ARCHETYPE</th>
                        <th className="p-3 text-right">OVR</th>
                        <th className="p-3 text-right">SHT</th>
                        <th className="p-3 text-right">SPD</th>
                        <th className="p-3 text-right">DEF</th>
                        <th className="p-3 text-right">STA</th>
                        <th className="p-3 text-right">AGE</th>
                        <th className="p-3 text-right">SALARY</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/60">
                      {starters.map(p => (
                        <tr key={p.id} className="hover:bg-zinc-900/40">
                          <td className="p-3 text-[#00d4ff] font-bold">{p.pos}</td>
                          <td className="p-3 font-bold text-white flex items-center gap-1.5">
                            #{p.num} {p.name}
                            {p.isStar && <span className="text-[#ffd700]">★</span>}
                          </td>
                          <td className="p-3 text-zinc-400">{p.arch}</td>
                          <td className="p-3 text-right font-bold text-[#ffd700] text-sm">{p.ovr}</td>
                          <td className="p-3 text-right text-zinc-300">{p.shooting}</td>
                          <td className="p-3 text-right text-zinc-300">{p.speed}</td>
                          <td className="p-3 text-right text-zinc-300">{p.defense}</td>
                          <td className="p-3 text-right text-zinc-300">{p.stamina}</td>
                          <td className="p-3 text-right text-zinc-500">{p.age}Y</td>
                          <td className="p-3 text-right text-[#3fff7a]">£{Math.round(p.salary / 1000)}K</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <div className="text-[10px] font-mono text-zinc-500 tracking-widest uppercase mb-2">
                  BENCH ROTATION
                </div>
                <div className="overflow-x-auto border border-zinc-800 bg-[#0e0e18]">
                  <table className="w-full text-left font-mono text-xs">
                    <thead className="bg-zinc-950 text-zinc-500 text-[10px] border-b border-zinc-800">
                      <tr>
                        <th className="p-3">POS</th>
                        <th className="p-3">PLAYER</th>
                        <th className="p-3">ARCHETYPE</th>
                        <th className="p-3 text-right">OVR</th>
                        <th className="p-3 text-right">SHT</th>
                        <th className="p-3 text-right">SPD</th>
                        <th className="p-3 text-right">DEF</th>
                        <th className="p-3 text-right">STA</th>
                        <th className="p-3 text-right">AGE</th>
                        <th className="p-3 text-right">SALARY</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/60">
                      {bench.map(p => (
                        <tr key={p.id} className="hover:bg-zinc-900/40">
                          <td className="p-3 text-zinc-400 font-bold">{p.pos}</td>
                          <td className="p-3 text-zinc-200">#{p.num} {p.name}</td>
                          <td className="p-3 text-zinc-400">{p.arch}</td>
                          <td className="p-3 text-right font-bold text-zinc-300">{p.ovr}</td>
                          <td className="p-3 text-right text-zinc-400">{p.shooting}</td>
                          <td className="p-3 text-right text-zinc-400">{p.speed}</td>
                          <td className="p-3 text-right text-zinc-400">{p.defense}</td>
                          <td className="p-3 text-right text-zinc-400">{p.stamina}</td>
                          <td className="p-3 text-right text-zinc-500">{p.age}Y</td>
                          <td className="p-3 text-right text-zinc-400">£{Math.round(p.salary / 1000)}K</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 3. TACTICS & SLIDERS TAB */}
          {activeTab === 'tactics' && (
            <div className="space-y-6 max-w-6xl">
              {/* Tactical Identity Cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {TACTICS_DEF.map(t => {
                  const isSelected = selectedTactic === t.id;
                  return (
                    <div
                      key={t.id}
                      onClick={() => handleApplyPreset(t.id)}
                      className={`p-4 border transition-all cursor-pointer bg-[#0e0e18] ${isSelected ? 'border-[#c9a84c] shadow-[0_0_15px_rgba(201,168,76,0.2)]' : 'border-zinc-800 hover:border-zinc-700'}`}
                    >
                      <div className="flex justify-between items-baseline mb-1">
                        <span className="font-['Bebas_Neue'] text-xl text-white tracking-wider">
                          {t.name}
                        </span>
                        <span className="text-[10px] font-mono text-[#3fff7a]">{t.boost}</span>
                      </div>
                      <p className="text-[11px] text-zinc-400 font-sans leading-relaxed">
                        {t.desc}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Team Sliders Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#0e0e18] border border-zinc-800 p-6">
                  <div className="font-['Bebas_Neue'] text-xl text-[#00d4ff] tracking-wider mb-4">
                    TEAM PLAYSTYLE SLIDERS
                  </div>

                  <div className="space-y-5 font-mono text-xs">
                    {[
                      { key: 'tempo', label: 'TEMPO', lo: 'SLOW GRIND (0)', hi: 'FAST PACE (100)' },
                      { key: 'defense', label: 'DEFENSIVE PRESSURE', lo: 'SAG OFF (0)', hi: 'FULL PRESS (100)' },
                      { key: 'spacing', label: 'FLOOR SPACING', lo: 'TIGHT POST (0)', hi: '5-OUT PERIMETER (100)' },
                      { key: 'help', label: 'HELP DEFENSE', lo: 'MAN-TO-MAN (0)', hi: 'HEAVY COLLAPSE (100)' },
                      { key: 'trans', label: 'TRANSITION ATTACK', lo: 'SET PLAYS (0)', hi: 'PUSH & GO (100)' },
                    ].map(item => (
                      <div key={item.key} className="space-y-1.5">
                        <div className="flex justify-between text-zinc-300">
                          <span className="font-bold">{item.label}</span>
                          <span className="text-[#ffd700] font-bold">{sliders[item.key as keyof TacticalSliders]}</span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={sliders[item.key as keyof TacticalSliders]}
                          onChange={e => handleSliderChange(item.key as keyof TacticalSliders, parseInt(e.target.value))}
                          className="w-full accent-[#c9a84c] bg-zinc-800 h-1.5 cursor-pointer"
                        />
                        <div className="flex justify-between text-[9px] text-zinc-500">
                          <span>{item.lo}</span>
                          <span>{item.hi}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#0e0e18] border border-zinc-800 p-6 flex flex-col justify-between">
                  <div>
                    <div className="font-['Bebas_Neue'] text-xl text-[#c9a84c] tracking-wider mb-2">
                      COACHING BLUEPRINT
                    </div>
                    <p className="text-xs font-mono text-zinc-400 leading-relaxed mb-4">
                      Sliders directly dictate 3D AI behavior on court. High tempo teams shoot earlier in the shot clock. Wide spacing drags defenders out to open driving lanes for cuts.
                    </p>
                  </div>

                  <div className="p-4 bg-zinc-950 border border-zinc-800/80 font-mono text-xs space-y-2">
                    <div className="text-zinc-500 text-[10px] uppercase">Active Strategic Identity</div>
                    <div className="text-[#ffd700] text-lg font-bold">{selectedTactic}</div>
                    <div className="text-zinc-400 text-[11px]">
                      Recommended for squads with athletic shot-creators and floor generals.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. FIXTURES TAB */}
          {activeTab === 'fixtures' && (
            <div className="max-w-4xl space-y-2">
              {fixtures.filter(f => f.homeId === userTeam.id || f.awayId === userTeam.id).map(f => {
                const isHome = f.homeId === userTeam.id;
                const opponent = allTeams.find(t => t.id === (isHome ? f.awayId : f.homeId));
                const isCurrent = !f.played && f.week === currentWeek;

                return (
                  <div
                    key={`${f.homeId}-${f.awayId}-${f.week}`}
                    className={`p-3.5 border flex items-center justify-between font-mono text-xs ${isCurrent ? 'border-[#c9a84c] bg-[#c9a84c]/10' : 'border-zinc-800 bg-[#0e0e18]'}`}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-zinc-500 font-bold w-12">WK {f.week}</span>
                      <span className="font-['Bebas_Neue'] text-xl" style={{ color: userTeam.col }}>
                        {userTeam.abbr}
                      </span>
                      <span className="text-zinc-600 font-bold">{isHome ? 'vs' : '@'}</span>
                      <span className="font-['Bebas_Neue'] text-xl" style={{ color: opponent?.col }}>
                        {opponent?.abbr}
                      </span>
                      <span className="text-zinc-400 text-xs hidden sm:inline">{opponent?.name}</span>
                    </div>

                    <div className="flex items-center gap-3">
                      {f.played ? (
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">
                            {isHome ? f.homeScore : f.awayScore} — {isHome ? f.awayScore : f.homeScore}
                          </span>
                          <span className={`px-2 py-0.5 text-[10px] font-bold border ${(isHome ? f.homeScore > f.awayScore : f.awayScore > f.homeScore) ? 'border-[#3fff7a] text-[#3fff7a]' : 'border-[#ff3a3a] text-[#ff3a3a]'}`}>
                            {(isHome ? f.homeScore > f.awayScore : f.awayScore > f.homeScore) ? 'WIN' : 'LOSS'}
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="text-zinc-600">PENDING</span>
                          {isCurrent && (
                            <button
                              onClick={() => { sound.click(); onGoToPreMatch(f); }}
                              className="px-3 py-1 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-sm tracking-wider font-bold hover:bg-[#ffd700] transition-colors cursor-pointer"
                            >
                              PLAY
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 5. TABLE TAB */}
          {activeTab === 'table' && (
            <div className="max-w-5xl border border-zinc-800 bg-[#0e0e18] overflow-x-auto">
              <table className="w-full text-center font-mono text-xs">
                <thead className="bg-zinc-950 text-zinc-500 text-[10px] border-b border-zinc-800">
                  <tr>
                    <th className="p-3 text-left">POS & CLUB</th>
                    <th className="p-3">P</th>
                    <th className="p-3">W</th>
                    <th className="p-3">L</th>
                    <th className="p-3">PF</th>
                    <th className="p-3">PA</th>
                    <th className="p-3">DIFF</th>
                    <th className="p-3 font-bold text-white">PTS</th>
                    <th className="p-3">FORM</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60">
                  {standings.map((row, idx) => {
                    const isUser = row.id === userTeam.id;
                    return (
                      <tr key={row.id} className={isUser ? 'bg-[#c9a84c]/10 font-bold' : 'hover:bg-zinc-900/30'}>
                        <td className="p-3 text-left flex items-center gap-2">
                          <span className="text-zinc-500 w-5">#{idx + 1}</span>
                          <span className="font-['Bebas_Neue'] text-lg" style={{ color: row.col }}>
                            {row.abbr}
                          </span>
                          <span className={isUser ? 'text-[#ffd700]' : 'text-zinc-300'}>{row.name}</span>
                        </td>
                        <td className="p-3">{row.p}</td>
                        <td className="p-3 text-[#3fff7a]">{row.w}</td>
                        <td className="p-3 text-[#ff3a3a]">{row.l}</td>
                        <td className="p-3 text-zinc-400">{row.pf}</td>
                        <td className="p-3 text-zinc-400">{row.pa}</td>
                        <td className="p-3 text-zinc-300">{row.diff > 0 ? `+${row.diff}` : row.diff}</td>
                        <td className="p-3 font-bold text-base text-white">{row.pts}</td>
                        <td className="p-3">
                          <div className="flex items-center justify-center gap-1">
                            {row.form.slice(-5).map((f, i) => (
                              <span
                                key={i}
                                className={`w-3.5 h-3.5 flex items-center justify-center text-[9px] font-bold ${f === 'W' ? 'bg-[#3fff7a] text-black' : 'bg-[#ff3a3a] text-white'}`}
                              >
                                {f}
                              </span>
                            ))}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* 6. TRANSFERS TAB */}
          {activeTab === 'transfers' && (
            <div className="space-y-6 max-w-6xl">
              <div className="bg-[#0e0e18] border border-zinc-800 p-4 flex items-center justify-between font-mono text-xs">
                <span>CLUB TREASURY: <b className="text-[#3fff7a]">£{(userTeam.funds / 1000000).toFixed(2)}M</b></span>
                <span>ROSTER CAPACITY: <b className="text-white">{userPlayers.length} / 15 PLAYERS</b></span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Available Free Agents */}
                <div className="border border-zinc-800 bg-[#0e0e18] p-4">
                  <div className="font-['Bebas_Neue'] text-xl text-[#00d4ff] tracking-wider mb-3">
                    FREE AGENTS MARKET ({freeAgents.length})
                  </div>
                  <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                    {freeAgents.map(p => (
                      <div
                        key={p.id}
                        className="p-3 border border-zinc-800 bg-zinc-950/60 flex items-center justify-between font-mono text-xs hover:border-[#00d4ff] transition-colors"
                      >
                        <div>
                          <div className="font-bold text-white text-sm flex items-center gap-1.5">
                            {p.name}
                            <span className="text-[10px] text-[#00d4ff] px-1 border border-[#00d4ff]/40">{p.pos}</span>
                            {p.isStar && <span className="text-[#ffd700]">★</span>}
                          </div>
                          <div className="text-[10px] text-zinc-400 mt-0.5">
                            {p.arch} · OVR <b className="text-[#ffd700]">{p.ovr}</b> · {p.age}Y
                          </div>
                          <div className="text-[10px] text-zinc-500">
                            Fee: £{(p.askingPrice / 1000000).toFixed(2)}M · Salary: £{Math.round(p.salary / 1000)}K/yr
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            sound.click();
                            setConfirmModal({
                              title: `SIGN ${p.name.toUpperCase()}?`,
                              description: `Sign ${p.name} (${p.pos}, OVR ${p.ovr}) for £${(p.askingPrice / 1000000).toFixed(2)}M transfer fee?`,
                              confirmLabel: 'SIGN PLAYER',
                              onConfirm: () => {
                                onBuyPlayer(p);
                                setConfirmModal(null);
                              },
                            });
                          }}
                          className="px-3 py-1.5 bg-[#00d4ff] text-black font-['Bebas_Neue'] text-sm tracking-wider font-bold hover:bg-[#33ddff] cursor-pointer"
                        >
                          SIGN
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Managed Club Roster */}
                <div className="border border-zinc-800 bg-[#0e0e18] p-4">
                  <div className="font-['Bebas_Neue'] text-xl text-[#c9a84c] tracking-wider mb-3">
                    CURRENT SQUAD PLAYERS ({userPlayers.length})
                  </div>
                  <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                    {userPlayers.map(p => (
                      <div
                        key={p.id}
                        className="p-3 border border-zinc-800 bg-zinc-950/60 flex items-center justify-between font-mono text-xs hover:border-zinc-700"
                      >
                        <div>
                          <div className="font-bold text-white text-sm">
                            #{p.num} {p.name} ({p.pos})
                            {p.starter && <span className="ml-1 text-[9px] text-[#c9a84c] px-1 border border-[#c9a84c]/30">STARTER</span>}
                          </div>
                          <div className="text-[10px] text-zinc-400 mt-0.5">
                            {p.arch} · OVR <b className="text-[#ffd700]">{p.ovr}</b> · Salary: £{Math.round(p.salary / 1000)}K/yr
                          </div>
                        </div>

                        {!p.starter && (
                          <button
                            onClick={() => {
                              sound.click();
                              setConfirmModal({
                                title: `RELEASE ${p.name.toUpperCase()}?`,
                                description: `Release ${p.name} to free agency and recover £${Math.round((p.ovr - 60) * 50)}K in compensation?`,
                                confirmLabel: 'RELEASE',
                                onConfirm: () => {
                                  onReleasePlayer(p);
                                  setConfirmModal(null);
                                },
                              });
                            }}
                            className="px-2.5 py-1 text-red-400 hover:text-white border border-red-900 hover:bg-red-900/40 text-[10px] font-mono cursor-pointer"
                          >
                            RELEASE
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 7. TRAINING TAB */}
          {activeTab === 'training' && (
            <div className="space-y-6 max-w-6xl">
              <div className="bg-[#0e0e18] border border-zinc-800 p-4 font-mono text-xs flex justify-between items-center">
                <span>TRAINING BUDGET: <b className="text-[#3fff7a]">£{(userTeam.funds / 1000000).toFixed(2)}M</b></span>
                <span className="text-zinc-400">UPGRADE CORE DRILLS TO ENHANCE PHYSICAL & SHOOTING RATINGS</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {(['shooting', 'speed', 'defense', 'stamina'] as const).map(statKey => {
                  const label = statKey.toUpperCase();
                  const cost = statKey === 'shooting' ? 85000 : statKey === 'defense' ? 80000 : statKey === 'speed' ? 75000 : 60000;
                  return (
                    <div key={statKey} className="border border-zinc-800 bg-[#0e0e18] p-4">
                      <div className="font-['Bebas_Neue'] text-xl text-[#00d4ff] tracking-wider mb-1">
                        {label} CLINIC
                      </div>
                      <div className="text-[10px] font-mono text-zinc-500 mb-3">
                        Cost: £{Math.round(cost / 1000)}K per session
                      </div>

                      <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                        {userPlayers.map(p => (
                          <div
                            key={p.id}
                            className="p-2 border border-zinc-800 bg-zinc-950 flex items-center justify-between font-mono text-xs"
                          >
                            <div>
                              <div className="font-bold text-white truncate max-w-[120px]">{p.name}</div>
                              <div className="text-[10px] text-zinc-400">
                                {label.slice(0, 3)}: <b className="text-[#ffd700]">{p[statKey]}</b>
                              </div>
                            </div>

                            <button
                              disabled={p[statKey] >= 99 || userTeam.funds < cost}
                              onClick={() => {
                                sound.click();
                                onTrainPlayer(p, statKey, cost);
                              }}
                              className={`px-2 py-1 font-['Bebas_Neue'] text-xs tracking-wider cursor-pointer ${p[statKey] >= 99 ? 'bg-zinc-800 text-zinc-600' : 'bg-[#c9a84c] text-black hover:bg-[#ffd700]'}`}
                            >
                              +1 DRILL
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 8. MEDIA TAB */}
          {activeTab === 'media' && (
            <div className="max-w-4xl space-y-3">
              <div className="font-['Bebas_Neue'] text-xl text-[#c9a84c] tracking-wider mb-2">
                BRITISH BASKETBALL PRESS DISPATCHES
              </div>

              {mediaStories.map(story => (
                <div
                  key={story.id}
                  className="p-4 border border-zinc-800 bg-[#0e0e18] flex items-start gap-4 font-mono text-xs"
                >
                  <span className={`px-2 py-0.5 text-[9px] font-bold border tracking-wider ${story.type === 'PERFORMANCE' ? 'border-[#3fff7a] text-[#3fff7a]' : story.type === 'DRAMA' ? 'border-[#ff3a3a] text-[#ff3a3a]' : 'border-[#00d4ff] text-[#00d4ff]'}`}>
                    {story.type}
                  </span>
                  <div>
                    <div className="font-bold text-white text-sm leading-snug">{story.headline}</div>
                    <div className="text-[10px] text-zinc-500 mt-1">{story.meta} · WEEK {story.week}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Dynamic League Ticker */}
        <div className="h-7 bg-[#050508] border-t border-zinc-800 flex items-center px-4 shrink-0 overflow-hidden font-mono text-[10px] text-zinc-400">
          <span className="text-[#c9a84c] font-bold mr-3 shrink-0">LATEST:</span>
          <div className="truncate flex items-center gap-6">
            <span>DYNASTY ELITE UK · 16 CLUBS · WEEK {currentWeek}</span>
            <span>·</span>
            <span>LEAGUE LEADER: {standings[0]?.name || 'London Royals'} ({standings[0]?.pts || 0} PTS)</span>
            <span>·</span>
            <span>NEXT FIXTURE: {opponentTeam ? `${userTeam.abbr} vs ${opponentTeam.abbr}` : 'SEASON FINALE'}</span>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="max-w-sm w-full bg-zinc-950 border border-zinc-700 p-6 shadow-2xl text-center">
            <h3 className="font-['Bebas_Neue'] text-2xl text-[#c9a84c] tracking-wider mb-2">
              {confirmModal.title}
            </h3>
            <p className="text-zinc-400 font-mono text-xs mb-6">
              {confirmModal.description}
            </p>
            <div className="flex justify-center gap-3">
              <button
                onClick={confirmModal.onConfirm}
                className="px-5 py-2 bg-[#3fff7a] text-black font-['Bebas_Neue'] text-base tracking-wider font-bold hover:bg-[#66ff99] cursor-pointer"
              >
                {confirmModal.confirmLabel}
              </button>
              <button
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 border border-zinc-700 text-zinc-400 font-mono text-xs hover:text-white cursor-pointer"
              >
                CANCEL
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
