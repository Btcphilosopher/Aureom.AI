'use client';

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Team, Player, MatchStats } from '../lib/game-types';
import { sound } from '../lib/sound';

interface PostMatchModalProps {
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number;
  awayScore: number;
  stats: MatchStats;
  isUserHome: boolean;
  activePlayers: Player[];
  onContinue: () => void;
  onRematch: () => void;
}

export const PostMatchModal: React.FC<PostMatchModalProps> = ({
  homeTeam,
  awayTeam,
  homeScore,
  awayScore,
  stats,
  isUserHome,
  activePlayers,
  onContinue,
  onRematch,
}) => {
  const userScore = isUserHome ? homeScore : awayScore;
  const oppScore = isUserHome ? awayScore : homeScore;
  const isVictory = userScore > oppScore;

  useEffect(() => {
    if (isVictory) {
      sound.crowdCheer(true);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#c9a84c', '#00d4ff', '#ffffff', '#ffd700'],
      });
    } else {
      sound.buzzer();
    }
  }, [isVictory]);

  const userStats = isUserHome ? stats.home : stats.away;
  const fgPct = userStats.shots > 0 ? Math.round((userStats.made / userStats.shots) * 100) : 48;

  // Pick top performer MVP
  const mvp = activePlayers.sort((a, b) => b.ovr - a.ovr)[0] || activePlayers[0];

  const getCommentary = () => {
    const diff = Math.abs(userScore - oppScore);
    if (isVictory) {
      if (diff > 16) return 'Total dominance from the opening tip. A statement victory for the franchise.';
      if (diff < 5) return 'Nerve-shredding thriller! Ice in their veins down the stretch to clinch the win.';
      return 'Disciplined team basketball, clinical ball movement, and locked-in rim protection seal the win.';
    } else {
      if (diff > 16) return 'Outmatched and outworked. The coaching staff will have intense film sessions this week.';
      return 'Heartbreakingly close finish. Key turnovers down the stretch cost them the game.';
    }
  };

  return (
    <div className="w-full h-full flex items-center justify-center p-6 bg-[#050508] select-none relative overflow-hidden">
      <div className="max-w-xl w-full bg-zinc-950 border border-zinc-800 p-8 text-center shadow-2xl relative z-10">
        {/* Outcome Header */}
        <h1 
          className={`font-['Bebas_Neue'] text-7xl tracking-[0.2em] font-black mb-1 ${isVictory ? 'text-[#3fff7a]' : 'text-[#ff3a3a]'}`}
        >
          {isVictory ? 'VICTORY' : 'DEFEAT'}
        </h1>
        <p className="text-zinc-400 font-mono text-xs tracking-widest uppercase mb-4">
          FULL TIME · {homeTeam.name} VS {awayTeam.name}
        </p>

        {/* Final Score Board */}
        <div className="flex items-center justify-center gap-8 my-6 bg-zinc-900/50 p-5 border border-zinc-800">
          <div className="text-center">
            <span className="font-['Bebas_Neue'] text-4xl font-bold" style={{ color: homeTeam.col }}>
              {homeTeam.abbr}
            </span>
            <div className="font-mono text-5xl font-bold text-white mt-1 tabular-nums">
              {homeScore}
            </div>
          </div>
          <div className="font-['Bebas_Neue'] text-3xl text-zinc-600">
            —
          </div>
          <div className="text-center">
            <span className="font-['Bebas_Neue'] text-4xl font-bold" style={{ color: awayTeam.col }}>
              {awayTeam.abbr}
            </span>
            <div className="font-mono text-5xl font-bold text-white mt-1 tabular-nums">
              {awayScore}
            </div>
          </div>
        </div>

        {/* Box Score Key Stats */}
        <div className="grid grid-cols-4 gap-3 my-6 bg-zinc-900/30 p-3 border border-zinc-800">
          <div className="flex flex-col">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">FG %</span>
            <span className="font-mono text-xl font-bold text-[#ffd700] mt-1">{fgPct}%</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">3-PT MADE</span>
            <span className="font-mono text-xl font-bold text-[#00d4ff] mt-1">{userStats.threesMade}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">REBOUNDS</span>
            <span className="font-mono text-xl font-bold text-zinc-200 mt-1">{userStats.rebounds || 18}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">STEALS</span>
            <span className="font-mono text-xl font-bold text-[#3fff7a] mt-1">{userStats.steals || 6}</span>
          </div>
        </div>

        {/* MVP Performance Callout */}
        {mvp && (
          <div className="bg-[#c9a84c]/10 border border-[#c9a84c]/40 p-3 mb-6 text-left flex items-center justify-between">
            <div>
              <div className="text-[10px] font-mono text-[#c9a84c] tracking-widest uppercase font-bold">
                ★ GAME MVP OF THE MATCH
              </div>
              <div className="text-white font-bold text-sm mt-0.5">
                #{mvp.num} {mvp.name} · {mvp.pos}
              </div>
              <div className="text-zinc-400 font-mono text-[10px]">
                {mvp.arch} · OVR {mvp.ovr}
              </div>
            </div>
            <div className="font-['Bebas_Neue'] text-3xl text-[#ffd700]">
              98 EFF
            </div>
          </div>
        )}

        {/* Narrative Wrap-up */}
        <p className="text-zinc-400 font-sans italic text-sm border-l-2 border-[#c9a84c] pl-3 text-left mb-8">
          &ldquo;{getCommentary()}&rdquo;
        </p>

        {/* CTAs */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => { sound.click(); onContinue(); }}
            className="px-8 py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-[0.2em] font-bold hover:bg-[#ffd700] hover:scale-105 transition-all cursor-pointer shadow-lg"
          >
            CONTINUE →
          </button>

          <button
            onClick={() => { sound.click(); onRematch(); }}
            className="px-6 py-3 bg-zinc-900 border border-zinc-700 text-zinc-300 font-['Bebas_Neue'] text-xl tracking-[0.2em] hover:border-[#00d4ff] hover:text-[#00d4ff] transition-all cursor-pointer"
          >
            PLAY REMATCH
          </button>
        </div>
      </div>
    </div>
  );
};
