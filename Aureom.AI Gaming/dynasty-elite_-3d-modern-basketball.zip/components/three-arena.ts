import * as THREE from 'three';
import { Player, Team, TacticalSliders, MatchStats } from '../lib/game-types';
import { sound } from '../lib/sound';

export interface ArenaCallbacks {
  onScoreUpdate: (homeScore: number, awayScore: number) => void;
  onClockTick: (timeLeft: number, quarter: number, shotClock: number) => void;
  onShotMeterChange: (power: number, inGreen: boolean, active: boolean) => void;
  onFeedbackText: (text: string, color: string) => void;
  onQuarterEnd: (quarter: number, homeScore: number, awayScore: number) => void;
  onGameEnd: (homeScore: number, awayScore: number, stats: MatchStats) => void;
  onPossessionChange: (teamAbbr: string) => void;
  onActivePlayerChange: (player: Player) => void;
}

export class ThreeBasketballArena {
  private container: HTMLElement;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private callbacks: ArenaCallbacks;

  // Arena Geometry dimensions (World units)
  private readonly COURT_WIDTH = 56; // X axis
  private readonly COURT_LENGTH = 94; // Z axis
  private readonly HOOP_HEIGHT = 10;
  private readonly RIM_RADIUS = 1.5;

  // Hoops
  private leftHoopPos = new THREE.Vector3(0, this.HOOP_HEIGHT, -this.COURT_LENGTH / 2 + 5.25);
  private rightHoopPos = new THREE.Vector3(0, this.HOOP_HEIGHT, this.COURT_LENGTH / 2 - 5.25);
  private leftNet!: THREE.Mesh;
  private rightNet!: THREE.Mesh;

  // Match State
  public homeScore = 0;
  public awayScore = 0;
  public quarter = 1;
  public timeLeft = 150; // 2:30 per quarter for engaging arcade pace
  public shotClock = 24.0;
  public isPaused = false;
  public isGameOver = false;

  public matchStats: MatchStats = {
    home: { shots: 0, made: 0, threes: 0, threesMade: 0, to: 0, steals: 0, blocks: 0, rebounds: 0 },
    away: { shots: 0, made: 0, threes: 0, threesMade: 0, to: 0, steals: 0, blocks: 0, rebounds: 0 },
  };

  // Teams & Sliders
  private homeTeam: Team;
  private awayTeam: Team;
  private homeSliders: TacticalSliders;
  private awaySliders: TacticalSliders;

  // Players & Ball
  private homePlayersData: Player[];
  private awayPlayersData: Player[];
  private playerMeshes: {
    group: THREE.Group;
    data: Player;
    teamIndex: number; // 0 = Home, 1 = Away
    jerseyMesh: THREE.Mesh;
    selectionRing: THREE.Mesh;
    leftLeg: THREE.Mesh;
    rightLeg: THREE.Mesh;
    leftArm: THREE.Mesh;
    rightArm: THREE.Mesh;
    targetPos: THREE.Vector3;
    velocity: THREE.Vector3;
    animTime: number;
    hasBall: boolean;
    isUser: boolean;
    stamina: number;
  }[] = [];

  private userPlayerIndex = 0;
  private ballMesh!: THREE.Group;
  private ballPos = new THREE.Vector3(0, 2, 0);
  private ballVel = new THREE.Vector3(0, 0, 0);
  private ballCarrier: number | null = null;
  private isBallInFlight = false;
  private isBallShot = false;
  private shotStartPos = new THREE.Vector3();
  private shotTargetPos = new THREE.Vector3();
  private shotProgress = 0;
  private shotShooterIndex = -1;
  private shotQuality = 0.5;
  private isThreePointer = false;

  // Shot Meter
  public isChargingShot = false;
  private shotMeterPower = 0;
  private shotMeterDir = 1;
  private shotGreenMin = 0.62;
  private shotGreenMax = 0.78;

  // Camera Settings
  public cameraMode: 'broadcast' | 'follow' | 'tactical' = 'broadcast';
  private targetCamPos = new THREE.Vector3(65, 36, 0);
  private targetCamLookAt = new THREE.Vector3(0, 5, 0);
  private cameraShake = 0;

  // Input states
  private keys: Record<string, boolean> = {};
  private comboCooldowns: Record<string, number> = {};
  private hitstopFrames = 0;

  constructor(
    container: HTMLElement,
    homeTeam: Team,
    awayTeam: Team,
    homePlayers: Player[],
    awayPlayers: Player[],
    homeSliders: TacticalSliders,
    awaySliders: TacticalSliders,
    callbacks: ArenaCallbacks
  ) {
    this.container = container;
    this.homeTeam = homeTeam;
    this.awayTeam = awayTeam;
    this.homePlayersData = homePlayers;
    this.awayPlayersData = awayPlayers;
    this.homeSliders = homeSliders;
    this.awaySliders = awaySliders;
    this.callbacks = callbacks;

    this.initThree();
    this.createArena();
    this.createHoops();
    this.createPlayers();
    this.createBall();
    this.setupInputs();

    this.resetPossession(0); // Home starts with ball
    this.startLoop();
  }

  private initThree() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x06060c);
    this.scene.fog = new THREE.FogExp2(0x06060c, 0.007);

    const aspect = this.container.clientWidth / this.container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(46, aspect, 0.1, 300);
    this.camera.position.set(70, 42, 0);
    this.camera.lookAt(0, 5, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.25;

    this.container.innerHTML = '';
    this.container.appendChild(this.renderer.domElement);

    // Lighting rig
    const ambient = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambient);

    const hemiLight = new THREE.HemisphereLight(0xddeeff, 0x111122, 0.9);
    hemiLight.position.set(0, 50, 0);
    this.scene.add(hemiLight);

    // Warm directional arena spotlights
    const keySpot = new THREE.DirectionalLight(0xfffaed, 2.2);
    keySpot.position.set(35, 60, 20);
    keySpot.castShadow = true;
    keySpot.shadow.mapSize.width = 2048;
    keySpot.shadow.mapSize.height = 2048;
    keySpot.shadow.camera.near = 10;
    keySpot.shadow.camera.far = 140;
    const d = 55;
    keySpot.shadow.camera.left = -d;
    keySpot.shadow.camera.right = d;
    keySpot.shadow.camera.top = d;
    keySpot.shadow.camera.bottom = -d;
    keySpot.shadow.bias = -0.0005;
    this.scene.add(keySpot);

    const rimSpot = new THREE.DirectionalLight(0x77ccff, 1.2);
    rimSpot.position.set(-35, 50, -20);
    this.scene.add(rimSpot);

    window.addEventListener('resize', this.onResize);
  }

  private onResize = () => {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  // Procedural Wood Court Canvas Texture
  private createCourtTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 2048;
    const ctx = canvas.getContext('2d')!;

    // Polished Maple wood base
    ctx.fillStyle = '#D6A66A';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Planks
    ctx.fillStyle = '#C89758';
    for (let y = 0; y < canvas.height; y += 14) {
      if (Math.random() > 0.4) {
        ctx.fillStyle = Math.random() > 0.5 ? '#CF9F5F' : '#C18E50';
        ctx.fillRect(0, y, canvas.width, 14);
      }
    }

    // Wood seams
    ctx.strokeStyle = 'rgba(0,0,0,0.06)';
    ctx.lineWidth = 1;
    for (let y = 0; y < canvas.height; y += 14) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;

    // Outer Court Border & Key Colors
    const homeColor = this.homeTeam.col;
    const awayColor = this.awayTeam.col;

    // Keys / Paints
    ctx.fillStyle = homeColor + '33';
    ctx.fillRect(cx - 150, canvas.height - 420, 300, 420);

    ctx.fillStyle = awayColor + '33';
    ctx.fillRect(cx - 150, 0, 300, 420);

    // Court Lines (White)
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 8;

    // Outer Perimeter
    ctx.strokeRect(40, 40, canvas.width - 80, canvas.height - 80);

    // Half court line & circle
    ctx.beginPath();
    ctx.moveTo(40, cy);
    ctx.lineTo(canvas.width - 40, cy);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy, 140, 0, Math.PI * 2);
    ctx.stroke();

    // 3-Point Arcs
    ctx.beginPath();
    ctx.arc(cx, 130, 440, 0.15, Math.PI - 0.15);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, canvas.height - 130, 440, Math.PI + 0.15, -0.15);
    ctx.stroke();

    // Center Court Logo
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 56px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('DYNASTY ELITE', cx, cy - 25);
    ctx.fillStyle = '#C9A84C';
    ctx.font = 'bold 32px monospace';
    ctx.fillText('UK PREMIER LEAGUE', cx, cy + 25);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    return texture;
  }

  private createArena() {
    // 1. Hardwood Court Floor
    const courtTex = this.createCourtTexture();
    const courtGeo = new THREE.PlaneGeometry(this.COURT_WIDTH, this.COURT_LENGTH);
    const courtMat = new THREE.MeshStandardMaterial({
      map: courtTex,
      roughness: 0.18,
      metalness: 0.05,
    });
    const courtMesh = new THREE.Mesh(courtGeo, courtMat);
    courtMesh.rotation.x = -Math.PI / 2;
    courtMesh.receiveShadow = true;
    this.scene.add(courtMesh);

    // 2. Arena Outer Floor / Apron
    const apronGeo = new THREE.PlaneGeometry(this.COURT_WIDTH + 32, this.COURT_LENGTH + 32);
    const apronMat = new THREE.MeshStandardMaterial({
      color: 0x10111a,
      roughness: 0.6,
      metalness: 0.1,
    });
    const apron = new THREE.Mesh(apronGeo, apronMat);
    apron.rotation.x = -Math.PI / 2;
    apron.position.y = -0.05;
    apron.receiveShadow = true;
    this.scene.add(apron);

    // 3. LED Ad Ribbon Perimeter
    const ribbonMat = new THREE.MeshBasicMaterial({ color: 0x00d4ff });
    const ribbonH = 2.4;

    const leftRibbon = new THREE.Mesh(new THREE.BoxGeometry(0.5, ribbonH, this.COURT_LENGTH + 12), ribbonMat);
    leftRibbon.position.set(-this.COURT_WIDTH / 2 - 3, ribbonH / 2, 0);
    this.scene.add(leftRibbon);

    const rightRibbon = new THREE.Mesh(new THREE.BoxGeometry(0.5, ribbonH, this.COURT_LENGTH + 12), ribbonMat);
    rightRibbon.position.set(this.COURT_WIDTH / 2 + 3, ribbonH / 2, 0);
    this.scene.add(rightRibbon);

    // 4. Stadium Grandstand Seating Silhouettes
    const standMat = new THREE.MeshStandardMaterial({ color: 0x0a0c16, roughness: 0.8 });
    for (let i = 0; i < 6; i++) {
      const step = new THREE.Mesh(
        new THREE.BoxGeometry(this.COURT_WIDTH + 60 + i * 8, 3, this.COURT_LENGTH + 40 + i * 8),
        standMat
      );
      step.position.set(0, -3 + (i + 1) * 3, 0);
      this.scene.add(step);
    }
  }

  private createHoops() {
    const makeHoop = (zPos: number, isRight: boolean) => {
      const group = new THREE.Group();
      group.position.set(0, 0, zPos);
      if (isRight) group.rotation.y = Math.PI;

      // Stanchion Base
      const baseMat = new THREE.MeshStandardMaterial({ color: 0x1b1c2b, roughness: 0.4 });
      const base = new THREE.Mesh(new THREE.BoxGeometry(6, 4, 8), baseMat);
      base.position.set(0, 2, -10);
      base.castShadow = true;
      group.add(base);

      // Angled Boom Arm
      const armMat = new THREE.MeshStandardMaterial({ color: 0x24283b, metalness: 0.6, roughness: 0.2 });
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.7, 16), armMat);
      arm.position.set(0, 7.5, -4.5);
      arm.rotation.x = Math.PI / 3.8;
      arm.castShadow = true;
      group.add(arm);

      // Glass Backboard
      const glassMat = new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        transmission: 0.85,
        opacity: 0.85,
        transparent: true,
        roughness: 0.1,
        ior: 1.5,
      });
      const board = new THREE.Mesh(new THREE.BoxGeometry(10, 6, 0.4), glassMat);
      board.position.set(0, this.HOOP_HEIGHT + 1, 0);
      group.add(board);

      // Target Square on backboard
      const targetMat = new THREE.MeshBasicMaterial({ color: 0xff3333 });
      const target = new THREE.Mesh(new THREE.BoxGeometry(4, 3, 0.45), targetMat);
      target.position.set(0, this.HOOP_HEIGHT + 0.5, 0);
      group.add(target);

      // Orange Steel Rim
      const rimMat = new THREE.MeshStandardMaterial({
        color: 0xff5500,
        metalness: 0.7,
        roughness: 0.2,
      });
      const rim = new THREE.Mesh(new THREE.TorusGeometry(this.RIM_RADIUS, 0.15, 12, 28), rimMat);
      rim.rotation.x = Math.PI / 2;
      rim.position.set(0, this.HOOP_HEIGHT, 2.5);
      group.add(rim);

      // Nylon Net
      const netMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.8,
        wireframe: true,
      });
      const net = new THREE.Mesh(new THREE.CylinderGeometry(this.RIM_RADIUS * 0.95, this.RIM_RADIUS * 0.45, 2.8, 14, 4, true), netMat);
      net.position.set(0, this.HOOP_HEIGHT - 1.4, 2.5);
      group.add(net);

      this.scene.add(group);
      return net;
    };

    this.leftNet = makeHoop(-this.COURT_LENGTH / 2 + 5.25, false);
    this.rightNet = makeHoop(this.COURT_LENGTH / 2 - 5.25, true);
  }

  // Composite 3D Player Characters (Head, Jersey, Shorts, Limbs, Shoes, Aura)
  private createPlayers() {
    this.playerMeshes = [];

    const createSinglePlayer = (player: Player, teamIndex: number, slotIndex: number) => {
      const group = new THREE.Group();
      const teamCol = teamIndex === 0 ? this.homeTeam.col : this.awayTeam.col;

      // 1. Torso / Jersey
      const jerseyMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(teamCol),
        roughness: 0.4,
      });
      const torso = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.8, 1.1), jerseyMat);
      torso.position.y = 4.2;
      torso.castShadow = true;
      group.add(torso);

      // 2. Shorts
      const shortsMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(teamCol).multiplyScalar(0.75),
        roughness: 0.4,
      });
      const shorts = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.6, 1.15), shortsMat);
      shorts.position.y = 2.6;
      shorts.castShadow = true;
      group.add(shorts);

      // 3. Head & Hair
      const skinMat = new THREE.MeshStandardMaterial({ color: 0x8d5524, roughness: 0.7 });
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.75, 12, 12), skinMat);
      head.position.y = 6.2;
      group.add(head);

      // Headband for star players
      if (player.isStar) {
        const bandMat = new THREE.MeshBasicMaterial({ color: 0xffd700 });
        const band = new THREE.Mesh(new THREE.CylinderGeometry(0.78, 0.78, 0.25, 12), bandMat);
        band.position.y = 6.4;
        group.add(band);
      }

      // 4. Arms
      const armGeo = new THREE.CylinderGeometry(0.24, 0.22, 2.2, 8);
      const leftArm = new THREE.Mesh(armGeo, skinMat);
      leftArm.position.set(-1.15, 3.8, 0);
      group.add(leftArm);

      const rightArm = new THREE.Mesh(armGeo, skinMat);
      rightArm.position.set(1.15, 3.8, 0);
      group.add(rightArm);

      // 5. Legs
      const legGeo = new THREE.CylinderGeometry(0.28, 0.24, 2.4, 8);
      const leftLeg = new THREE.Mesh(legGeo, skinMat);
      leftLeg.position.set(-0.55, 1.2, 0);
      leftLeg.castShadow = true;
      group.add(leftLeg);

      const rightLeg = new THREE.Mesh(legGeo, skinMat);
      rightLeg.position.set(0.55, 1.2, 0);
      rightLeg.castShadow = true;
      group.add(rightLeg);

      // 6. Selection Highlight Ring
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x00d4ff,
        transparent: true,
        opacity: 0,
      });
      const ring = new THREE.Mesh(new THREE.RingGeometry(1.8, 2.3, 24), ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.04;
      group.add(ring);

      // Initial court positioning
      const startZ = teamIndex === 0 ? 15 + slotIndex * 4 : -15 - slotIndex * 4;
      const startX = (slotIndex - 2) * 8;
      group.position.set(startX, 0, startZ);

      this.scene.add(group);

      this.playerMeshes.push({
        group,
        data: player,
        teamIndex,
        jerseyMesh: torso,
        selectionRing: ring,
        leftLeg,
        rightLeg,
        leftArm,
        rightArm,
        targetPos: group.position.clone(),
        velocity: new THREE.Vector3(),
        animTime: Math.random() * 10,
        hasBall: false,
        isUser: teamIndex === 0 && slotIndex === 0,
        stamina: 100,
      });
    };

    // 5 Starters for Home and Away
    const homeStarters = this.homePlayersData.filter(p => p.starter).slice(0, 5);
    const awayStarters = this.awayPlayersData.filter(p => p.starter).slice(0, 5);

    homeStarters.forEach((p, idx) => createSinglePlayer(p, 0, idx));
    awayStarters.forEach((p, idx) => createSinglePlayer(p, 1, idx));

    this.userPlayerIndex = 0;
    this.updateUserSelection();
  }

  private createBall() {
    this.ballMesh = new THREE.Group();

    // Basketball Sphere
    const ballGeo = new THREE.SphereGeometry(1.1, 24, 24);
    const ballTex = this.createBallTexture();
    const ballMat = new THREE.MeshStandardMaterial({
      map: ballTex,
      roughness: 0.35,
      metalness: 0.05,
    });
    const sphere = new THREE.Mesh(ballGeo, ballMat);
    sphere.castShadow = true;
    this.ballMesh.add(sphere);

    this.scene.add(this.ballMesh);
  }

  private createBallTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#E6631E';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#222222';
    ctx.lineWidth = 6;

    // Basketball black rib seams
    ctx.beginPath();
    ctx.moveTo(0, 64);
    ctx.lineTo(256, 64);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(128, 0);
    ctx.lineTo(128, 128);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(64, 64, 42, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(192, 64, 42, 0, Math.PI * 2);
    ctx.stroke();

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  private setupInputs() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;

    // Sound activation on first key
    sound.click();

    if (e.code === 'KeyP' || e.code === 'Escape') {
      this.isPaused = !this.isPaused;
      return;
    }

    if (this.isPaused || this.isGameOver) return;

    // Camera Modes F1-F3
    if (e.code === 'F1') { this.cameraMode = 'broadcast'; e.preventDefault(); return; }
    if (e.code === 'F2') { this.cameraMode = 'follow'; e.preventDefault(); return; }
    if (e.code === 'F3') { this.cameraMode = 'tactical'; e.preventDefault(); return; }

    const user = this.playerMeshes[this.userPlayerIndex];
    if (!user) return;

    // Shot charging (Hold Enter)
    if (e.code === 'Enter') {
      e.preventDefault();
      if (user.hasBall && !this.isChargingShot) {
        if (e.altKey) {
          this.executePumpFake(user);
        } else {
          this.startShotCharging();
        }
      }
    }

    // Smart Pass / Call For Pass / Steal (Space)
    if (e.code === 'Space') {
      e.preventDefault();
      if (user.hasBall) {
        this.executeSmartPass(user);
      } else {
        const ballCarrierPlayer = this.playerMeshes.find(p => p.hasBall);
        if (ballCarrierPlayer && ballCarrierPlayer.teamIndex === user.teamIndex) {
          // Call for pass
          this.callbacks.onFeedbackText('CALL FOR PASS', '#00D4FF');
          this.passBallTo(ballCarrierPlayer, user);
        } else if (ballCarrierPlayer) {
          // Attempt steal
          this.attemptSteal(user, ballCarrierPlayer);
        }
      }
    }

    // Crossover (Q)
    if (e.code === 'KeyQ' && user.hasBall && !this.comboCooldowns.cross) {
      this.executeCrossover(user);
    }

    // Spin Move (R)
    if (e.code === 'KeyR' && user.hasBall && !this.comboCooldowns.spin) {
      this.executeSpin(user);
    }

    // Step-Back (F)
    if (e.code === 'KeyF' && user.hasBall) {
      this.executeStepBack(user);
    }

    // Defensive Switch (Tab)
    if (e.code === 'Tab') {
      e.preventDefault();
      this.switchDefensivePlayer();
    }

    // Icon Passing (Keys 1 - 5)
    if (user.hasBall) {
      const num = parseInt(e.key);
      if (num >= 1 && num <= 5) {
        const teammates = this.playerMeshes.filter(p => p.teamIndex === 0 && p !== user);
        const target = teammates[num - 1];
        if (target) this.passBallTo(user, target);
      }
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;

    // Release shot on Enter keyup
    if (e.code === 'Enter' && this.isChargingShot) {
      this.releaseShot();
    }
  };

  private startShotCharging() {
    this.isChargingShot = true;
    this.shotMeterPower = 0;
    this.shotMeterDir = 1;

    const user = this.playerMeshes[this.userPlayerIndex];
    const hoop = this.rightHoopPos;
    const dist = user.group.position.distanceTo(hoop);

    // Green window is tighter if contested or far
    const contested = this.getContestLevel(user);
    this.shotGreenMin = contested > 0.4 ? 0.68 : 0.60;
    this.shotGreenMax = contested > 0.4 ? 0.76 : 0.78;
    if (dist > 30) {
      this.shotGreenMin += 0.04;
      this.shotGreenMax -= 0.02;
    }
  }

  private releaseShot() {
    this.isChargingShot = false;
    const user = this.playerMeshes[this.userPlayerIndex];
    if (!user || !user.hasBall) return;

    const inGreen = this.shotMeterPower >= this.shotGreenMin && this.shotMeterPower <= this.shotGreenMax;
    const mid = (this.shotGreenMin + this.shotGreenMax) / 2;
    const diff = Math.abs(this.shotMeterPower - mid);

    let quality = inGreen ? 0.94 : Math.max(0.15, 0.7 - diff * 2.2);

    if (inGreen) {
      sound.greenRelease();
      this.callbacks.onFeedbackText('PERFECT GREEN!', '#3FFF7A');
    } else if (this.shotMeterPower < this.shotGreenMin) {
      this.callbacks.onFeedbackText('EARLY RELEASE', '#FF8C00');
    } else {
      this.callbacks.onFeedbackText('LATE RELEASE', '#FF3A3A');
    }

    this.launchShot(user, quality);
  }

  private launchShot(shooter: typeof this.playerMeshes[0], quality: number) {
    shooter.hasBall = false;
    this.ballCarrier = null;
    this.isBallInFlight = true;
    this.isBallShot = true;

    const targetHoop = shooter.teamIndex === 0 ? this.rightHoopPos : this.leftHoopPos;
    this.shotStartPos.copy(shooter.group.position).add(new THREE.Vector3(0, 5, 0));
    this.shotTargetPos.copy(targetHoop);
    this.shotProgress = 0;
    this.shotShooterIndex = this.playerMeshes.indexOf(shooter);
    this.shotQuality = quality;

    const distToHoop = shooter.group.position.distanceTo(targetHoop);
    this.isThreePointer = distToHoop > 24;

    const statTeam = shooter.teamIndex === 0 ? this.matchStats.home : this.matchStats.away;
    statTeam.shots++;
    if (this.isThreePointer) statTeam.threes++;

    // Shooter arm extension
    shooter.rightArm.rotation.x = -Math.PI / 1.5;
  }

  private executeSmartPass(passer: typeof this.playerMeshes[0]) {
    const teammates = this.playerMeshes.filter(p => p.teamIndex === passer.teamIndex && p !== passer);
    if (!teammates.length) return;

    const hoop = passer.teamIndex === 0 ? this.rightHoopPos : this.leftHoopPos;

    // Score teammates by open space & proximity to hoop
    let best = teammates[0];
    let bestScore = -999;

    teammates.forEach(m => {
      const distToHoop = m.group.position.distanceTo(hoop);
      const nearestDef = this.playerMeshes
        .filter(d => d.teamIndex !== passer.teamIndex)
        .reduce((min, d) => Math.min(min, d.group.position.distanceTo(m.group.position)), 999);

      const score = nearestDef * 1.5 - distToHoop * 0.5 + m.data.shooting * 0.2;
      if (score > bestScore) {
        bestScore = score;
        best = m;
      }
    });

    this.passBallTo(passer, best);
  }

  private passBallTo(passer: typeof this.playerMeshes[0], receiver: typeof this.playerMeshes[0]) {
    passer.hasBall = false;
    this.ballCarrier = null;
    this.isBallInFlight = true;
    this.isBallShot = false;

    this.shotStartPos.copy(passer.group.position).add(new THREE.Vector3(0, 4, 0));
    this.shotTargetPos.copy(receiver.group.position).add(new THREE.Vector3(0, 4, 0));
    this.shotProgress = 0;
    this.shotShooterIndex = this.playerMeshes.indexOf(receiver);

    sound.dribble(0.6);
  }

  private executeCrossover(player: typeof this.playerMeshes[0]) {
    this.comboCooldowns.cross = 0.6;
    player.velocity.x *= -1.5;
    sound.sneakerSqueak();
    this.callbacks.onFeedbackText('CROSSOVER!', '#FFD700');
  }

  private executeSpin(player: typeof this.playerMeshes[0]) {
    this.comboCooldowns.spin = 0.8;
    player.group.rotation.y += Math.PI * 2;
    sound.sneakerSqueak();
    this.callbacks.onFeedbackText('SPIN MOVE!', '#00D4FF');
  }

  private executeStepBack(player: typeof this.playerMeshes[0]) {
    const hoop = player.teamIndex === 0 ? this.rightHoopPos : this.leftHoopPos;
    const dir = new THREE.Vector3().subVectors(player.group.position, hoop).normalize();
    player.velocity.add(dir.multiplyScalar(22));
    sound.sneakerSqueak();
    this.callbacks.onFeedbackText('STEP-BACK', '#C9A84C');
  }

  private executePumpFake(player: typeof this.playerMeshes[0]) {
    this.callbacks.onFeedbackText('PUMP FAKE', '#FF8C00');
    // Defenders jump
    this.playerMeshes.forEach(d => {
      if (d.teamIndex !== player.teamIndex && d.group.position.distanceTo(player.group.position) < 12) {
        d.velocity.y = 12;
      }
    });
  }

  private attemptSteal(defender: typeof this.playerMeshes[0], carrier: typeof this.playerMeshes[0]) {
    if (this.comboCooldowns.steal) return;
    this.comboCooldowns.steal = 0.6;

    const dist = defender.group.position.distanceTo(carrier.group.position);
    if (dist < 7) {
      const stealRate = 0.45 + (defender.data.defense - carrier.data.speed) * 0.005;
      if (Math.random() < stealRate) {
        carrier.hasBall = false;
        defender.hasBall = true;
        this.ballCarrier = this.playerMeshes.indexOf(defender);
        this.shotClock = 24.0;
        sound.whistle();
        this.callbacks.onFeedbackText('BALL STOLEN!', '#3FFF7A');
        this.cameraShake = 4;
        if (defender.teamIndex === 0) {
          this.switchUserTo(defender);
        }
      } else {
        this.callbacks.onFeedbackText('REACH IN', '#FF8C00');
      }
    }
  }

  private switchDefensivePlayer() {
    const defenders = this.playerMeshes.filter(p => p.teamIndex === 0 && p !== this.playerMeshes[this.userPlayerIndex]);
    if (!defenders.length) return;

    // Switch to defender closest to ball
    const closest = defenders.reduce((prev, curr) => {
      return curr.group.position.distanceTo(this.ballPos) < prev.group.position.distanceTo(this.ballPos) ? curr : prev;
    });

    this.switchUserTo(closest);
  }

  private switchUserTo(target: typeof this.playerMeshes[0]) {
    this.playerMeshes[this.userPlayerIndex].isUser = false;
    target.isUser = true;
    this.userPlayerIndex = this.playerMeshes.indexOf(target);
    this.updateUserSelection();
    this.callbacks.onActivePlayerChange(target.data);
  }

  private updateUserSelection() {
    this.playerMeshes.forEach(p => {
      const ringMat = p.selectionRing.material as THREE.MeshBasicMaterial;
      ringMat.opacity = p.isUser ? 0.8 : 0;
    });
  }

  private getContestLevel(shooter: typeof this.playerMeshes[0]): number {
    const defenders = this.playerMeshes.filter(p => p.teamIndex !== shooter.teamIndex);
    const closestDist = defenders.reduce((min, d) => Math.min(min, d.group.position.distanceTo(shooter.group.position)), 999);
    return Math.max(0, 1 - closestDist / 12);
  }

  public resetPossession(teamIndex: number) {
    this.playerMeshes.forEach(p => (p.hasBall = false));
    this.isBallInFlight = false;
    this.shotClock = 24.0;

    const teamPlayers = this.playerMeshes.filter(p => p.teamIndex === teamIndex);
    const pg = teamPlayers[0] || this.playerMeshes[0];
    pg.hasBall = true;
    this.ballCarrier = this.playerMeshes.indexOf(pg);

    if (teamIndex === 0) {
      this.switchUserTo(pg);
    }

    this.callbacks.onPossessionChange(teamIndex === 0 ? this.homeTeam.abbr : this.awayTeam.abbr);
  }

  // 60fps Loop
  private startLoop() {
    let lastTime = performance.now();

    const tick = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTime = now;

      if (!this.isPaused && !this.isGameOver) {
        if (this.hitstopFrames > 0) {
          this.hitstopFrames--;
        } else {
          this.updateGame(dt);
        }
      }

      this.render();
      this.animationFrameId = requestAnimationFrame(tick);
    };

    this.animationFrameId = requestAnimationFrame(tick);
  }

  private updateGame(dt: number) {
    // Clocks
    this.timeLeft -= dt;
    this.shotClock -= dt;

    if (this.shotClock <= 0) {
      sound.buzzer();
      this.callbacks.onFeedbackText('24s VIOLATION', '#FF3A3A');
      const currentPossTeam = this.ballCarrier !== null ? this.playerMeshes[this.ballCarrier].teamIndex : 0;
      this.resetPossession(1 - currentPossTeam);
    }

    if (this.timeLeft <= 0) {
      this.endQuarter();
      return;
    }

    this.callbacks.onClockTick(Math.max(0, this.timeLeft), this.quarter, Math.max(0, this.shotClock));

    // Shot meter update
    if (this.isChargingShot) {
      this.shotMeterPower += this.shotMeterDir * dt * 2.2;
      if (this.shotMeterPower >= 1) {
        this.shotMeterPower = 1;
        this.shotMeterDir = -1;
      } else if (this.shotMeterPower <= 0) {
        this.shotMeterPower = 0;
        this.shotMeterDir = 1;
      }
      const inGreen = this.shotMeterPower >= this.shotGreenMin && this.shotMeterPower <= this.shotGreenMax;
      this.callbacks.onShotMeterChange(this.shotMeterPower, inGreen, true);
    } else {
      this.callbacks.onShotMeterChange(0, false, false);
    }

    // Cooldown timers
    Object.keys(this.comboCooldowns).forEach(k => {
      this.comboCooldowns[k] -= dt;
      if (this.comboCooldowns[k] <= 0) delete this.comboCooldowns[k];
    });

    // Update Player Movement & AI
    this.updatePlayers(dt);

    // Update Ball Physics
    this.updateBall(dt);

    // Camera follow & damping
    this.updateCamera(dt);
  }

  private updatePlayers(dt: number) {
    this.playerMeshes.forEach(p => {
      if (p.isUser) {
        this.updateUserMovement(p, dt);
      } else {
        this.updateAIMovement(p, dt);
      }

      // Physics integration
      p.group.position.addScaledVector(p.velocity, dt);
      p.velocity.multiplyScalar(0.82); // friction

      // Clamp to court boundary
      p.group.position.x = THREE.MathUtils.clamp(p.group.position.x, -this.COURT_WIDTH / 2 + 3, this.COURT_WIDTH / 2 - 3);
      p.group.position.z = THREE.MathUtils.clamp(p.group.position.z, -this.COURT_LENGTH / 2 + 4, this.COURT_LENGTH / 2 - 4);

      // Procedural limb stride animation
      const speed = p.velocity.length();
      if (speed > 1) {
        p.animTime += dt * speed * 0.8;
        const swing = Math.sin(p.animTime) * 0.6;
        p.leftLeg.rotation.x = swing;
        p.rightLeg.rotation.x = -swing;
        p.leftArm.rotation.x = -swing * 0.8;
        if (!p.hasBall) p.rightArm.rotation.x = swing * 0.8;

        // Facing direction
        p.group.rotation.y = Math.atan2(p.velocity.x, p.velocity.z);
      } else {
        p.leftLeg.rotation.x = THREE.MathUtils.damp(p.leftLeg.rotation.x, 0, 10, dt);
        p.rightLeg.rotation.x = THREE.MathUtils.damp(p.rightLeg.rotation.x, 0, 10, dt);
      }
    });
  }

  private updateUserMovement(p: typeof this.playerMeshes[0], dt: number) {
    const move = new THREE.Vector3();
    if (this.keys['KeyW'] || this.keys['ArrowUp']) move.z -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) move.z += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) move.x -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) move.x += 1;

    const isSprinting = (this.keys['ShiftLeft'] || this.keys['ShiftRight']) && p.stamina > 10;
    const speedMult = isSprinting ? 1.55 : 1.0;
    const baseSpeed = (p.data.speed / 100) * 32 * speedMult;

    if (isSprinting && move.lengthSq() > 0) {
      p.stamina = Math.max(0, p.stamina - dt * 20);
    } else {
      p.stamina = Math.min(100, p.stamina + dt * 14);
    }

    if (move.lengthSq() > 0) {
      move.normalize().multiplyScalar(baseSpeed);
      p.velocity.lerp(move, 0.28);
    }
  }

  private updateAIMovement(p: typeof this.playerMeshes[0], dt: number) {
    const sliders = p.teamIndex === 0 ? this.homeSliders : this.awaySliders;
    const hoop = p.teamIndex === 0 ? this.rightHoopPos : this.leftHoopPos;
    const oppHoop = p.teamIndex === 0 ? this.leftHoopPos : this.rightHoopPos;

    if (p.hasBall) {
      // AI Ball handler: drive towards rim, pull up or pass
      const distToHoop = p.group.position.distanceTo(hoop);
      const target = hoop.clone().setY(0);
      const dir = target.sub(p.group.position).normalize();
      p.velocity.lerp(dir.multiplyScalar(22), 0.15);

      // AI shot chance
      if (distToHoop < 22 && Math.random() < 0.018 * (sliders.tempo / 50)) {
        this.launchShot(p, 0.45 + (p.data.shooting / 100) * 0.45);
      }
    } else {
      // Off-ball movement based on Spacing and Defense sliders
      const hasTeamBall = this.playerMeshes.some(teammate => teammate.teamIndex === p.teamIndex && teammate.hasBall);

      if (hasTeamBall) {
        // Offensive floor spacing
        const spreadFactor = (sliders.spacing / 50) * 16;
        const targetZ = p.teamIndex === 0 ? 12 : -12;
        const desiredPos = new THREE.Vector3((p.data.num % 5 - 2) * spreadFactor, 0, targetZ);
        const toSpot = desiredPos.sub(p.group.position);
        if (toSpot.length() > 2) {
          p.velocity.lerp(toSpot.normalize().multiplyScalar(16), 0.1);
        }
      } else {
        // Defense: guard man-to-man or collapse paint
        const ballCarrierPlayer = this.playerMeshes.find(q => q.hasBall);
        if (ballCarrierPlayer) {
          const protectSpot = oppHoop.clone().lerp(ballCarrierPlayer.group.position, 0.5).setY(0);
          const toProtect = protectSpot.sub(p.group.position);
          if (toProtect.length() > 3) {
            p.velocity.lerp(toProtect.normalize().multiplyScalar(20), 0.12);
          }
        }
      }
    }
  }

  private updateBall(dt: number) {
    if (this.isBallInFlight) {
      this.shotProgress += dt * (this.isBallShot ? 1.85 : 2.6);
      const t = Math.min(1, this.shotProgress);

      // Parabolic flight arc
      const arcHeight = this.isBallShot ? 18 : 6;
      this.ballPos.lerpVectors(this.shotStartPos, this.shotTargetPos, t);
      this.ballPos.y += Math.sin(t * Math.PI) * arcHeight;

      this.ballMesh.position.copy(this.ballPos);
      this.ballMesh.rotation.x += dt * 15;

      if (t >= 1) {
        if (this.isBallShot) {
          this.resolveShotOutcome();
        } else {
          this.resolvePassOutcome();
        }
      }
    } else if (this.ballCarrier !== null) {
      const carrier = this.playerMeshes[this.ballCarrier];
      if (carrier) {
        // Dribble bounce animation
        const dribbleY = Math.abs(Math.sin(carrier.animTime * 3)) * 2.8 + 0.9;
        const offset = new THREE.Vector3(1.2, dribbleY, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), carrier.group.rotation.y);
        this.ballPos.copy(carrier.group.position).add(offset);
        this.ballMesh.position.copy(this.ballPos);

        if (dribbleY < 1.1 && Math.random() > 0.6) {
          sound.dribble(0.4);
        }
      }
    }
  }

  private resolveShotOutcome() {
    this.isBallInFlight = false;
    this.isBallShot = false;

    const shooter = this.playerMeshes[this.shotShooterIndex];
    if (!shooter) return;

    const made = Math.random() < this.shotQuality;
    const pts = this.isThreePointer ? 3 : 2;

    if (made) {
      // Made bucket!
      sound.swish();
      sound.crowdCheer(true);
      this.cameraShake = 5;
      this.hitstopFrames = 3;

      if (shooter.teamIndex === 0) {
        this.homeScore += pts;
        this.matchStats.home.made++;
        if (this.isThreePointer) this.matchStats.home.threesMade++;
      } else {
        this.awayScore += pts;
        this.matchStats.away.made++;
        if (this.isThreePointer) this.matchStats.away.threesMade++;
      }

      this.callbacks.onScoreUpdate(this.homeScore, this.awayScore);
      this.callbacks.onFeedbackText(this.isThreePointer ? '+3 FROM DOWNTOWN!' : '+2 BUCKET!', '#3FFF7A');

      // Net swish stretch animation
      const net = shooter.teamIndex === 0 ? this.rightNet : this.leftNet;
      net.scale.set(1.4, 0.7, 1.4);
      setTimeout(() => net.scale.set(1, 1, 1), 250);

      // Switch possession to conceding team
      this.resetPossession(1 - shooter.teamIndex);
    } else {
      // Missed shot off the rim
      sound.rimClank();
      this.cameraShake = 3;
      this.callbacks.onFeedbackText('OFF THE RIM', '#FF3A3A');

      // Rebound battle
      const sorted = [...this.playerMeshes].sort((a, b) => a.group.position.distanceTo(this.ballPos) - b.group.position.distanceTo(this.ballPos));
      const rebounder = sorted[0];
      rebounder.hasBall = true;
      this.ballCarrier = this.playerMeshes.indexOf(rebounder);
      this.shotClock = 24.0;

      const teamStat = rebounder.teamIndex === 0 ? this.matchStats.home : this.matchStats.away;
      teamStat.rebounds++;

      if (rebounder.teamIndex === 0) {
        this.switchUserTo(rebounder);
      }
    }
  }

  private resolvePassOutcome() {
    this.isBallInFlight = false;
    const receiver = this.playerMeshes[this.shotShooterIndex];
    if (receiver) {
      receiver.hasBall = true;
      this.ballCarrier = this.playerMeshes.indexOf(receiver);
      if (receiver.teamIndex === 0) {
        this.switchUserTo(receiver);
      }
    }
  }

  private endQuarter() {
    sound.buzzer();
    this.callbacks.onQuarterEnd(this.quarter, this.homeScore, this.awayScore);

    if (this.quarter >= 4) {
      this.isGameOver = true;
      this.callbacks.onGameEnd(this.homeScore, this.awayScore, this.matchStats);
    } else {
      this.quarter++;
      this.timeLeft = 150;
      this.shotClock = 24.0;
      this.resetPossession((this.quarter % 2 === 0) ? 1 : 0);
    }
  }

  private updateCamera(dt: number) {
    const user = this.playerMeshes[this.userPlayerIndex];
    const ball = this.ballPos;

    if (this.cameraMode === 'broadcast') {
      // Side television broadcast cam following ball Z axis
      this.targetCamPos.set(48, 28, ball.z * 0.75);
      this.targetCamLookAt.set(0, 4, ball.z * 0.85);
    } else if (this.cameraMode === 'follow') {
      // Action cam behind user
      const behind = new THREE.Vector3(0, 16, user.teamIndex === 0 ? -24 : 24);
      this.targetCamPos.copy(user.group.position).add(behind);
      this.targetCamLookAt.copy(user.group.position).add(new THREE.Vector3(0, 4, 0));
    } else {
      // Tactical elevated 45-degree full court perspective
      this.targetCamPos.set(55, 62, 0);
      this.targetCamLookAt.set(0, 0, 0);
    }

    // Smooth exponential damping
    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, this.targetCamPos.x, 6, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, this.targetCamPos.y, 6, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, this.targetCamPos.z, 6, dt);

    if (this.cameraShake > 0) {
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShake;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShake;
      this.cameraShake = Math.max(0, this.cameraShake - dt * 14);
    }

    this.camera.lookAt(this.targetCamLookAt);
  }

  private render() {
    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  }

  public dispose() {
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);

    if (this.renderer) {
      this.renderer.dispose();
      if (this.container && this.renderer.domElement) {
        this.container.removeChild(this.renderer.domElement);
      }
    }
  }
}
