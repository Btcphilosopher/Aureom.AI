'use client';

import React, { useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { sound } from '../lib/sound';

interface TitleScreenProps {
  onStartCareer: () => void;
  onStartExhibition: () => void;
  onQuickPlay: () => void;
  onLoadGame: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartCareer,
  onStartExhibition,
  onQuickPlay,
  onLoadGame,
  isMuted,
  onToggleMute,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        sound.click();
        onQuickPlay();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onQuickPlay]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between p-8 bg-[#050508] select-none overflow-hidden">
      {/* Subtle Background Court Grid lines */}
      <div 
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `
            radial-gradient(circle at 50% 50%, rgba(201, 168, 76, 0.15) 0%, transparent 65%),
            linear-gradient(to right, rgba(255, 255, 255, 0.05) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 60px 60px, 60px 60px',
        }}
      />

      {/* Top Bar with Audio & League Pill */}
      <div className="w-full flex items-center justify-between z-10 max-w-6xl">
        <div className="flex items-center gap-3">
          <span className="px-3 py-1 bg-[#c9a84c]/10 border border-[#c9a84c]/30 text-[#c9a84c] text-[10px] tracking-widest font-mono uppercase rounded-xs">
            UK Basketball Premier League
          </span>
          <span className="text-zinc-500 text-xs font-mono tracking-wider">
            16 CLUBS · 3D ENGINE
          </span>
        </div>

        <button
          onClick={onToggleMute}
          className="p-2 border border-zinc-800 bg-zinc-900/60 hover:border-[#c9a84c] text-zinc-400 hover:text-[#c9a84c] transition-colors rounded-xs cursor-pointer flex items-center gap-2 text-xs font-mono"
        >
          {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
          <span>{isMuted ? 'UNMUTE' : 'MUTE'}</span>
        </button>
      </div>

      {/* Bespoke Inline SVG Title Lockup */}
      <div className="flex flex-col items-center text-center my-auto z-10">
        <div className="mb-4 text-[#00d4ff] font-mono text-[11px] tracking-[0.35em] uppercase">
          Full 5v5 Modern 3D Simulation
        </div>

        <div className="relative">
          <svg
            className="w-[320px] sm:w-[540px] md:w-[680px] h-auto drop-shadow-[0_0_35px_rgba(201,168,76,0.3)]"
            viewBox="0 0 680 160"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* DYNASTY text in bold gold typography */}
            <text
              x="50%"
              y="75"
              textAnchor="middle"
              fill="#C9A84C"
              fontSize="84"
              fontFamily="'Bebas Neue', Impact, sans-serif"
              letterSpacing="6"
              fontWeight="900"
            >
              DYNASTY
            </text>
            {/* ELITE UK in neon cyan & silver */}
            <text
              x="50%"
              y="140"
              textAnchor="middle"
              fill="#00D4FF"
              fontSize="68"
              fontFamily="'Bebas Neue', Impact, sans-serif"
              letterSpacing="10"
              fontWeight="900"
            >
              ELITE <tspan fill="#E0E0F0">UK</tspan>
            </text>
            {/* Decorative Geometric Accent Lines */}
            <line x1="80" y1="92" x2="220" y2="92" stroke="#C9A84C" strokeWidth="2" strokeOpacity="0.4" />
            <line x1="460" y1="92" x2="600" y2="92" stroke="#00D4FF" strokeWidth="2" strokeOpacity="0.4" />
          </svg>
        </div>

        <p className="mt-3 text-zinc-400 font-sans text-sm tracking-widest uppercase">
          Dynamic Arena Lighting · Green Release Timing · Tactical Sliders
        </p>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
          <button
            onClick={() => { sound.click(); onQuickPlay(); }}
            className="px-8 py-3 bg-[#c9a84c] text-black font-['Bebas_Neue'] text-xl tracking-[0.2em] font-bold hover:bg-[#ffd700] hover:scale-105 transition-all shadow-[0_0_20px_rgba(201,168,76,0.4)] cursor-pointer"
          >
            QUICK PLAY (SPACE / ENTER)
          </button>

          <button
            onClick={() => { sound.click(); onStartCareer(); }}
            className="px-7 py-3 bg-zinc-900 border border-[#c9a84c] text-[#c9a84c] font-['Bebas_Neue'] text-xl tracking-[0.2em] hover:bg-[#c9a84c] hover:text-black transition-all cursor-pointer"
          >
            CAREER MODE
          </button>

          <button
            onClick={() => { sound.click(); onStartExhibition(); }}
            className="px-7 py-3 bg-zinc-900 border border-[#00d4ff] text-[#00d4ff] font-['Bebas_Neue'] text-xl tracking-[0.2em] hover:bg-[#00d4ff] hover:text-black transition-all cursor-pointer"
          >
            EXHIBITION MATCH
          </button>

          <button
            onClick={() => { sound.click(); onLoadGame(); }}
            className="px-6 py-3 bg-zinc-900/60 border border-zinc-700 text-zinc-300 font-['Bebas_Neue'] text-lg tracking-[0.15em] hover:border-zinc-400 transition-all cursor-pointer"
          >
            LOAD SAVE
          </button>
        </div>
      </div>

      {/* Flat Control Hint Line required by constitution */}
      <div className="w-full flex justify-center z-10">
        <div className="py-2 px-6 bg-zinc-950/80 border border-zinc-800/80 text-zinc-400 font-mono text-[11px] tracking-wider flex items-center gap-4 rounded-xs shadow-lg">
          <span><kbd className="text-[#ffd700] font-bold">WASD</kbd> Move</span>
          <span>·</span>
          <span><kbd className="text-[#00d4ff] font-bold">SHIFT</kbd> Sprint</span>
          <span>·</span>
          <span><kbd className="text-[#ffd700] font-bold">ENTER</kbd> Shoot (Hold/Release)</span>
          <span>·</span>
          <span><kbd className="text-[#00d4ff] font-bold">SPACE</kbd> Pass / Steal</span>
          <span>·</span>
          <span><kbd className="text-[#3fff7a] font-bold">Q/R/F</kbd> Crossover / Spin / Step-Back</span>
          <span>·</span>
          <span><kbd className="text-zinc-300 font-bold">ESC</kbd> Pause</span>
        </div>
      </div>
    </div>
  );
};
