'use client';

import React from 'react';
import { Team } from '../lib/game-types';
import { TEAMS_DEF, RAW_ROSTERS } from '../lib/teams-data';
import { sound } from '../lib/sound';

interface CareerTeamSelectProps {
  onSelectTeam: (team: Team) => void;
  onBack: () => void;
}

export const CareerTeamSelect: React.FC<CareerTeamSelectProps> = ({ onSelectTeam, onBack }) => {
  return (
    <div className="w-full h-full flex flex-col bg-[#050508] p-6 select-none overflow-hidden">
      {/* Header */}
      <div className="flex items-baseline justify-between border-b border-zinc-800 pb-4 mb-4 shrink-0">
        <div>
          <h1 className="font-['Bebas_Neue'] text-4xl text-[#c9a84c] tracking-[0.15em]">
            CHOOSE YOUR DYNASTY
          </h1>
          <p className="text-zinc-400 font-mono text-xs tracking-wider">
            CAREER MODE · 16 CLUBS · BRITISH BASKETBALL PREMIER LEAGUE
          </p>
        </div>

        <button
          onClick={() => { sound.click(); onBack(); }}
          className="px-4 py-2 border border-zinc-700 text-zinc-400 hover:text-white hover:border-zinc-500 font-mono text-xs tracking-wider cursor-pointer transition-colors"
        >
          ← BACK
        </button>
      </div>

      {/* 4x4 Grid of 16 UK Clubs */}
      <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {TEAMS_DEF.map(team => {
          const star = RAW_ROSTERS[team.id]?.[0];
          return (
            <div
              key={team.id}
              onClick={() => {
                sound.click();
                onSelectTeam(team);
              }}
              className="p-4 border border-zinc-800 hover:border-[#c9a84c] bg-zinc-950/60 hover:bg-[#c9a84c]/5 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-baseline justify-between">
                  <span 
                    className="font-['Bebas_Neue'] text-4xl tracking-wider group-hover:scale-105 transition-transform" 
                    style={{ color: team.col }}
                  >
                    {team.abbr}
                  </span>
                  <div className="text-right">
                    <span className="font-mono text-sm text-[#ffd700] font-bold">{team.rating}</span>
                    <span className="text-[10px] text-zinc-500 font-mono block">OVR</span>
                  </div>
                </div>

                <div className="text-sm font-bold text-white mt-1">{team.name}</div>
                <div className="text-[10px] font-mono text-zinc-400">{team.city}</div>
                <div className="text-[10px] text-[#00d4ff] font-mono tracking-wider mt-2">
                  {team.trait}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-800/80 font-mono text-[10px] text-zinc-400 flex justify-between items-center">
                <span>BUDGET: <b className="text-[#3fff7a]">£{(team.funds / 1000000).toFixed(1)}M</b></span>
                {star && <span className="text-[#ffd700] truncate max-w-[100px]">★ {star[1]}</span>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
