'use client';

import React from 'react';
import { Camera, Volume2, VolumeX, Pause, Play } from 'lucide-react';
import { Team, Player } from '../lib/game-types';
import { sound } from '../lib/sound';

interface MatchHUDProps {
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number;
  awayScore: number;
  timeLeft: number;
  quarter: number;
  shotClock: number;
  possession: string;
  activePlayer: Player | null;
  cameraMode: 'broadcast' | 'follow' | 'tactical';
  onSwitchCamera: (mode: 'broadcast' | 'follow' | 'tactical') => void;
  isPaused: boolean;
  onTogglePause: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  shotMeter: {
    power: number;
    inGreen: boolean;
    active: boolean;
  };
  feedback: { text: string; color: string } | null;
}

export const MatchHUD: React.FC<MatchHUDProps> = ({
  homeTeam,
  awayTeam,
  homeScore,
  awayScore,
  timeLeft,
  quarter,
  shotClock,
  possession,
  activePlayer,
  cameraMode,
  onSwitchCamera,
  isPaused,
  onTogglePause,
  isMuted,
  onToggleMute,
  shotMeter,
  feedback,
}) => {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = Math.floor(timeLeft % 60);
  const timeFormatted = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  const shotClockFormatted = Math.ceil(shotClock);

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-4 z-20">
      {/* ── TOP PERIMETER: SCOREBOARD CLUSTER (Low-Occlusion) ── */}
      <div className="w-full flex items-start justify-between">
        {/* Active Player Status Badge (Top Left) */}
        <div className="pointer-events-auto bg-zinc-950/90 border border-zinc-800 p-2.5 px-3.5 flex items-center gap-3">
          <div 
            className="w-8 h-8 flex items-center justify-center font-['Bebas_Neue'] text-lg font-bold border border-current"
            style={{ color: homeTeam.col }}
          >
            #{activePlayer?.num || '1'}
          </div>
          <div className="flex flex-col">
            <div className="text-zinc-100 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5">
              <span>{activePlayer?.name || 'Kofi Williams'}</span>
              <span className="text-[10px] text-[#00d4ff] font-mono px-1 border border-[#00d4ff]/30">
                {activePlayer?.pos || 'PG'}
              </span>
            </div>
            <div className="text-zinc-400 font-mono text-[10px] tracking-widest mt-0.5">
              OVR <span className="text-[#ffd700] font-bold">{activePlayer?.ovr || 88}</span> · {activePlayer?.arch || 'Floor General'}
            </div>
          </div>
        </div>

        {/* Central Arena Scoreboard */}
        <div className="pointer-events-auto flex items-center bg-zinc-950/95 border border-zinc-800 shadow-2xl px-5 py-2 divide-x divide-zinc-800">
          {/* Home Team */}
          <div className="flex items-center gap-3 pr-4">
            <span className="font-['Bebas_Neue'] text-3xl font-bold tracking-wider" style={{ color: homeTeam.col }}>
              {homeTeam.abbr}
            </span>
            <span className="font-mono text-3xl font-bold text-white tabular-nums tracking-tighter">
              {homeScore}
            </span>
          </div>

          {/* Quarter & Time */}
          <div className="px-5 flex flex-col items-center">
            <div className="text-zinc-400 font-mono text-[10px] tracking-[0.25em] uppercase">
              QUARTER {quarter}
            </div>
            <div className="font-mono text-2xl font-bold text-[#ffd700] tabular-nums tracking-tight">
              {timeFormatted}
            </div>
          </div>

          {/* Shot Clock */}
          <div className="px-4 flex flex-col items-center">
            <div className="text-zinc-400 font-mono text-[9px] tracking-widest uppercase">
              SHOT
            </div>
            <div 
              className={`font-mono text-2xl font-bold tabular-nums ${shotClock <= 5 ? 'text-[#ff3a3a] animate-pulse' : 'text-[#00d4ff]'}`}
            >
              {shotClockFormatted}
            </div>
          </div>

          {/* Away Team */}
          <div className="flex items-center gap-3 pl-4">
            <span className="font-mono text-3xl font-bold text-white tabular-nums tracking-tighter">
              {awayScore}
            </span>
            <span className="font-['Bebas_Neue'] text-3xl font-bold tracking-wider" style={{ color: awayTeam.col }}>
              {awayTeam.abbr}
            </span>
          </div>
        </div>

        {/* Controls & Camera Switcher (Top Right) */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Camera Selector */}
          <div className="flex items-center bg-zinc-950/90 border border-zinc-800 p-1">
            <button
              onClick={() => { sound.click(); onSwitchCamera('broadcast'); }}
              className={`px-2.5 py-1 text-[10px] font-mono tracking-wider transition-colors cursor-pointer ${cameraMode === 'broadcast' ? 'bg-[#c9a84c] text-black font-bold' : 'text-zinc-400 hover:text-white'}`}
            >
              BROADCAST (F1)
            </button>
            <button
              onClick={() => { sound.click(); onSwitchCamera('follow'); }}
              className={`px-2.5 py-1 text-[10px] font-mono tracking-wider transition-colors cursor-pointer ${cameraMode === 'follow' ? 'bg-[#00d4ff] text-black font-bold' : 'text-zinc-400 hover:text-white'}`}
            >
              ACTION (F2)
            </button>
            <button
              onClick={() => { sound.click(); onSwitchCamera('tactical'); }}
              className={`px-2.5 py-1 text-[10px] font-mono tracking-wider transition-colors cursor-pointer ${cameraMode === 'tactical' ? 'bg-zinc-200 text-black font-bold' : 'text-zinc-400 hover:text-white'}`}
            >
              TACTICAL (F3)
            </button>
          </div>

          <button
            onClick={onTogglePause}
            className="p-2 bg-zinc-950/90 border border-zinc-800 text-zinc-300 hover:text-[#c9a84c] hover:border-[#c9a84c] transition-colors cursor-pointer"
            title="Pause (Esc)"
          >
            {isPaused ? <Play size={16} /> : <Pause size={16} />}
          </button>

          <button
            onClick={onToggleMute}
            className="p-2 bg-zinc-950/90 border border-zinc-800 text-zinc-300 hover:text-[#00d4ff] hover:border-[#00d4ff] transition-colors cursor-pointer"
            title="Toggle Audio"
          >
            {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        </div>
      </div>

      {/* ── CENTER: PRO SHOT METER & FEEDBACK NOTIFICATIONS ── */}
      <div className="flex flex-col items-center justify-center my-auto">
        {/* Dynamic Floater Feedback (e.g. PERFECT GREEN, STEAL, CROSSOVER) */}
        {feedback && (
          <div 
            className="animate-bounce font-['Bebas_Neue'] text-2xl tracking-[0.2em] font-bold px-4 py-1.5 bg-black/85 border border-current shadow-xl mb-6"
            style={{ color: feedback.color }}
          >
            {feedback.text}
          </div>
        )}

        {/* Pro Shot Meter with Moving Indicator & Green Window */}
        {shotMeter.active && (
          <div className="flex flex-col items-center gap-1.5 bg-black/80 border border-zinc-700/80 p-3 px-5 shadow-2xl">
            <div className="text-[10px] font-mono text-zinc-300 tracking-widest uppercase">
              Shot Release Meter
            </div>

            {/* Meter Bar */}
            <div className="relative w-52 h-4 bg-zinc-900 border border-zinc-600 overflow-hidden">
              {/* Green Target Zone */}
              <div 
                className="absolute top-0 bottom-0 bg-[#3fff7a]/35 border-x border-[#3fff7a]"
                style={{ left: '60%', width: '18%' }}
              />

              {/* Dynamic Fill Level */}
              <div
                className={`h-full transition-all ${shotMeter.inGreen ? 'bg-[#3fff7a]' : shotMeter.power > 0.85 ? 'bg-[#ff3a3a]' : 'bg-[#c9a84c]'}`}
                style={{ width: `${Math.round(shotMeter.power * 100)}%` }}
              />

              {/* Moving Precision Cursor Line */}
              <div 
                className="absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_8px_#fff]"
                style={{ left: `${Math.round(shotMeter.power * 100)}%` }}
              />
            </div>

            <div className="text-[9px] font-mono tracking-wider text-zinc-400">
              {shotMeter.inGreen ? '✓ RELEASE IN GREEN!' : 'RELEASE IN THE GREEN ZONE'}
            </div>
          </div>
        )}
      </div>

      {/* ── BOTTOM PERIMETER: POSSESSION & CONTROL HELP CLUSTER ── */}
      <div className="w-full flex items-center justify-between">
        <div className="pointer-events-auto bg-zinc-950/90 border border-zinc-800 px-4 py-2 font-mono text-xs text-zinc-400 flex items-center gap-2">
          <span>POSSESSION:</span>
          <span className="font-bold text-[#ffd700]">{possession}</span>
        </div>

        <div className="pointer-events-auto bg-zinc-950/90 border border-zinc-800 px-4 py-2 font-mono text-[11px] text-zinc-400 flex items-center gap-3">
          <span><kbd className="text-[#ffd700] font-bold">WASD</kbd> Move</span>
          <span>·</span>
          <span><kbd className="text-[#00d4ff] font-bold">ENTER</kbd> Shoot</span>
          <span>·</span>
          <span><kbd className="text-[#00d4ff] font-bold">SPACE</kbd> Pass</span>
          <span>·</span>
          <span><kbd className="text-zinc-300 font-bold">1-5</kbd> Icon Pass</span>
          <span>·</span>
          <span><kbd className="text-[#3fff7a] font-bold">TAB</kbd> Switch</span>
        </div>
      </div>
    </div>
  );
};
