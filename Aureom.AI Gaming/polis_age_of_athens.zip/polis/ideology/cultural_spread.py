"""Idea diffusion across cities via trade contact and geographic proximity."""
from typing import Dict, List

from economy.trade import TradeNetwork
from utils.config import SimConfig
from world.city_state import CityState

AXES = ["democracy", "militarism", "trade", "philosophy", "authoritarianism"]


def diffuse(cities: Dict[str, CityState], trade_network: TradeNetwork, config: SimConfig) -> None:
    """Cities in active trade contact pull each other's ideology vectors
    toward one another, weighted by trade volume and blocked entirely
    while at war (cannon fire, not culture, crosses a battle line)."""
    rate = config.ideology_diffusion_rate
    for route in trade_network.routes:
        if not route.active:
            continue
        a = cities[route.origin]
        b = cities[route.destination]
        weight = min(1.0, route.volume / 50.0) * rate
        for axis in AXES:
            va, vb = getattr(a.ideology, axis), getattr(b.ideology, axis)
            pull = (vb - va) * weight
            a.ideology.shift(axis, pull)
