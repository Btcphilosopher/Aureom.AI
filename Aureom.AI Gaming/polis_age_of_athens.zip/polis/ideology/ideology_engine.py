"""Global belief-propagation system: mutates each city's IdeologyVector
from war outcomes, economic performance, and NPC activity."""
from typing import Dict

from utils.config import SimConfig
from world.city_state import CityState


class IdeologyEngine:
    def __init__(self, cities: Dict[str, CityState], config: SimConfig):
        self.cities = cities
        self.config = config

    def _react_to_war(self, city: CityState) -> None:
        if city.is_at_war:
            city.ideology.shift("militarism", 1.2)
            city.ideology.shift("philosophy", -0.3)
        else:
            city.ideology.shift("militarism", -0.4)

    def _react_to_economy(self, city: CityState) -> None:
        if city.treasury > 800:
            city.ideology.shift("trade", 0.8)
        elif city.treasury < 0:
            city.ideology.shift("authoritarianism", 0.6)
            city.ideology.shift("trade", -0.5)

    def _react_to_stability(self, city: CityState) -> None:
        if city.unrest > 60:
            city.ideology.shift("authoritarianism", 0.5)
            city.ideology.shift("democracy", -0.3)
        elif city.happiness > 75:
            city.ideology.shift("democracy", 0.4)

    def update(self) -> None:
        for city in self.cities.values():
            self._react_to_war(city)
            self._react_to_economy(city)
            self._react_to_stability(city)
