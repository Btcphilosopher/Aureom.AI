"""Procedural (but historically-anchored) generator for the Greek world.

Named city-sites are placed at fixed relative coordinates that mirror
real Greek geography, then terrain/fertility/strategic value are rolled
procedurally per-seed so every run's economy differs while the map
'shape' stays recognisably Greece.
"""
import random
from typing import Dict, List

from world.geography import Coordinate, Region, Terrain

# (name, x, y, default terrain) -- coordinates are an abstract grid, not real lat/lon
CITY_SITES = [
    ("Athens", 60, 40, Terrain.COASTAL_PLAIN),
    ("Sparta", 45, 15, Terrain.MOUNTAIN),
    ("Corinth", 50, 35, Terrain.STRAIT),
    ("Thebes", 55, 45, Terrain.HILL),
    ("Argos", 48, 25, Terrain.COASTAL_PLAIN),
    ("Megara", 55, 38, Terrain.COASTAL_PLAIN),
    ("Rhodes", 90, 10, Terrain.ISLAND),
    ("Miletus", 95, 30, Terrain.COASTAL_PLAIN),
    ("Syracuse", 5, 5, Terrain.ISLAND),
    ("Delphi", 50, 55, Terrain.MOUNTAIN),
]


def generate_world(seed: int) -> Dict[str, Region]:
    rng = random.Random(seed)
    regions: Dict[str, Region] = {}
    for name, x, y, terrain in CITY_SITES:
        jitter_x = x + rng.uniform(-2.5, 2.5)
        jitter_y = y + rng.uniform(-2.5, 2.5)
        fertility = round(rng.uniform(0.35, 0.95), 2)
        strategic = round(rng.uniform(0.2, 1.0), 2)
        regions[name] = Region(
            name=name,
            coordinate=Coordinate(jitter_x, jitter_y),
            terrain=terrain,
            fertility=fertility,
            strategic_value=strategic,
        )
    return regions


def neighbors_within(regions: Dict[str, Region], name: str, radius: float) -> List[str]:
    origin = regions[name].coordinate
    out = []
    for other_name, region in regions.items():
        if other_name == name:
            continue
        if origin.distance_to(region.coordinate) <= radius:
            out.append(other_name)
    return out
