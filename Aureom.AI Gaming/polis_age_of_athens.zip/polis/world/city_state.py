"""The Polis: the core unit of the simulation."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from world.geography import Region


class GovernmentType(Enum):
    DEMOCRACY = "democracy"
    OLIGARCHY = "oligarchy"
    TYRANNY = "tyranny"


@dataclass
class Population:
    citizens: int
    slaves: int
    merchants: int
    soldiers: int

    @property
    def total(self) -> int:
        return self.citizens + self.slaves + self.merchants + self.soldiers

    @property
    def free_population(self) -> int:
        return self.citizens + self.merchants + self.soldiers

    def grow(self, rate: float) -> None:
        self.citizens = max(1, int(self.citizens * (1 + rate)))
        self.merchants = max(0, int(self.merchants * (1 + rate * 0.8)))

    def levy_soldiers(self, fraction: float) -> int:
        """Convert a fraction of citizens into soldiers for war footing."""
        levy = int(self.citizens * fraction)
        levy = min(levy, self.citizens)
        self.citizens -= levy
        self.soldiers += levy
        return levy

    def demobilize(self, fraction: float) -> None:
        back = int(self.soldiers * fraction)
        self.soldiers -= back
        self.citizens += back


@dataclass
class IdeologyVector:
    """Each axis is 0..100. These drive politics, warfare posture,
    economic policy and are the substrate the ideology engine mutates."""
    democracy: float = 50.0
    militarism: float = 50.0
    trade: float = 50.0
    philosophy: float = 50.0
    authoritarianism: float = 50.0

    def as_dict(self) -> Dict[str, float]:
        return {
            "democracy": self.democracy,
            "militarism": self.militarism,
            "trade": self.trade,
            "philosophy": self.philosophy,
            "authoritarianism": self.authoritarianism,
        }

    def shift(self, axis: str, delta: float) -> None:
        current = getattr(self, axis)
        setattr(self, axis, min(100.0, max(0.0, current + delta)))

    def dominant(self) -> str:
        return max(self.as_dict(), key=self.as_dict().get)


@dataclass
class Military:
    hoplites: int
    triremes: int
    morale: float = 70.0          # 0..100
    supply_level: float = 100.0   # 0..100, depletes on campaign

    @property
    def land_strength(self) -> float:
        return self.hoplites * (self.morale / 100.0) * (0.5 + self.supply_level / 200.0)

    @property
    def naval_strength(self) -> float:
        return self.triremes * (self.morale / 100.0)


@dataclass
class CityState:
    name: str
    region: Region
    government: GovernmentType
    population: Population
    ideology: IdeologyVector = field(default_factory=IdeologyVector)
    military: Military = field(default_factory=lambda: Military(hoplites=0, triremes=0))

    treasury: float = 500.0
    food_stock: float = 1000.0
    tax_rate: float = 0.15
    happiness: float = 60.0      # 0..100
    unrest: float = 10.0         # 0..100
    corruption: float = 5.0      # 0..100
    at_war_with: set = field(default_factory=set)
    allies: set = field(default_factory=set)
    controlled_territories: List[str] = field(default_factory=list)
    is_capital_of: Optional[str] = None

    def __post_init__(self):
        if not self.controlled_territories:
            self.controlled_territories = [self.name]

    # ---- derived stats -------------------------------------------------
    @property
    def is_at_war(self) -> bool:
        return len(self.at_war_with) > 0

    @property
    def stability(self) -> float:
        return max(0.0, 100.0 - self.unrest - self.corruption * 0.5)

    def summary(self) -> str:
        return (
            f"{self.name} [{self.government.value}] pop={self.population.total} "
            f"treasury={self.treasury:.0f} food={self.food_stock:.0f} "
            f"happiness={self.happiness:.0f} unrest={self.unrest:.0f} "
            f"military(hoplites={self.military.hoplites}, triremes={self.military.triremes}, "
            f"morale={self.military.morale:.0f}) ideology={self.ideology.dominant()}"
        )
