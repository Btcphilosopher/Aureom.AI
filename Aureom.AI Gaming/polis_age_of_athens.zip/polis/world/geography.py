"""Terrain, regions and travel-cost model for the Greek world map."""
from dataclasses import dataclass
from enum import Enum
import math


class Terrain(Enum):
    COASTAL_PLAIN = "coastal_plain"
    MOUNTAIN = "mountain"
    HILL = "hill"
    ISLAND = "island"
    STRAIT = "strait"

    @property
    def land_move_cost(self) -> float:
        return {
            Terrain.COASTAL_PLAIN: 1.0,
            Terrain.HILL: 1.6,
            Terrain.MOUNTAIN: 2.5,
            Terrain.ISLAND: 3.0,   # requires embarkation
            Terrain.STRAIT: 1.2,
        }[self]

    @property
    def is_coastal(self) -> bool:
        return self in (Terrain.COASTAL_PLAIN, Terrain.ISLAND, Terrain.STRAIT)


@dataclass(frozen=True)
class Coordinate:
    x: float
    y: float

    def distance_to(self, other: "Coordinate") -> float:
        return math.hypot(self.x - other.x, self.y - other.y)


@dataclass
class Region:
    name: str
    coordinate: Coordinate
    terrain: Terrain
    fertility: float          # 0..1, drives food production
    strategic_value: float    # 0..1, drives AI targeting priority


def travel_time(a: "Region", b: "Region", naval: bool = False) -> float:
    """Ticks required to move an army/fleet between two regions."""
    dist = a.coordinate.distance_to(b.coordinate)
    if naval:
        if not (a.terrain.is_coastal and b.terrain.is_coastal):
            return math.inf  # cannot sail to landlocked region
        speed = 9.0
    else:
        speed = 4.5 / ((a.terrain.land_move_cost + b.terrain.land_move_cost) / 2)
    return max(0.5, dist / speed)
