"""Trade routes between city-states: dynamic flow of goods and wealth."""
from dataclasses import dataclass
from typing import Dict, List

from utils.config import SimConfig
from world.city_state import CityState
from world.geography import travel_time


@dataclass
class TradeRoute:
    origin: str
    destination: str
    volume: float          # base goods volume
    active: bool = True

    def blocked_by_war(self, cities: Dict[str, CityState]) -> bool:
        return self.destination in cities[self.origin].at_war_with


class TradeNetwork:
    def __init__(self, cities: Dict[str, CityState], config: SimConfig):
        self.cities = cities
        self.config = config
        self.routes: List[TradeRoute] = []

    def establish_routes(self, max_distance: float = 60.0) -> None:
        names = list(self.cities.keys())
        self.routes.clear()
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                ra, rb = self.cities[a].region, self.cities[b].region
                if not (ra.terrain.is_coastal or rb.terrain.is_coastal):
                    continue  # land-locked pairs need very close proximity
                dist = ra.coordinate.distance_to(rb.coordinate)
                if dist <= max_distance:
                    volume = max(5.0, 40.0 - dist * 0.4)
                    self.routes.append(TradeRoute(a, b, volume))
                    self.routes.append(TradeRoute(b, a, volume))

    def update(self, chronicle=None, tick=0, year=0) -> None:
        for route in self.routes:
            if route.blocked_by_war(self.cities):
                if route.active:
                    route.active = False
                    if chronicle:
                        chronicle.record(
                            tick, year,
                            f"TRADE DISRUPTED: route {route.origin}->{route.destination} "
                            f"severed by war.")
                continue
            if not route.active:
                route.active = True
            origin_city = self.cities[route.origin]
            dest_city = self.cities[route.destination]
            flow = route.volume * self.config.trade_efficiency * (origin_city.ideology.trade / 100.0)
            revenue = flow * 0.6
            origin_city.treasury += revenue * 0.5
            dest_city.food_stock += flow * 0.3
            dest_city.treasury += revenue * 0.3

    def total_trade_income(self, city_name: str) -> float:
        return sum(r.volume for r in self.routes if r.active and r.origin == city_name)
