"""Government revenue collection, sensitive to government type and corruption."""
from world.city_state import CityState, GovernmentType

GOV_TAX_EFFICIENCY = {
    GovernmentType.DEMOCRACY: 0.85,   # broad buy-in, modest efficiency
    GovernmentType.OLIGARCHY: 0.95,   # elites extract effectively
    GovernmentType.TYRANNY: 1.05,     # coercive, high extraction, high resentment
}


def collect_taxes(city: CityState) -> float:
    base = city.population.free_population * 2.0 * city.tax_rate
    efficiency = GOV_TAX_EFFICIENCY[city.government]
    leakage = 1.0 - (city.corruption / 200.0)  # corruption eats revenue
    revenue = base * efficiency * leakage
    city.treasury += revenue

    # taxation has a happiness cost proportional to rate and inversely to trust
    burden = city.tax_rate * 30.0
    trust = city.ideology.democracy / 100.0
    city.happiness -= burden * (1.0 - trust * 0.5) * 0.05
    if city.government == GovernmentType.TYRANNY:
        city.unrest += city.tax_rate * 3.0

    return revenue


def set_tax_rate(city: CityState, new_rate: float) -> None:
    city.tax_rate = max(0.0, min(0.6, new_rate))
