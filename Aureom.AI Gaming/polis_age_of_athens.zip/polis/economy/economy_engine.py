"""Per-tick production and consumption for every city-state."""
from typing import Dict

from utils.config import SimConfig
from world.city_state import CityState


class EconomyEngine:
    def __init__(self, cities: Dict[str, CityState], config: SimConfig):
        self.cities = cities
        self.config = config

    def produce_food(self, city: CityState) -> float:
        workers = city.population.citizens + city.population.slaves
        base = workers * city.region.fertility * 0.02
        if city.is_at_war:
            base *= 0.7  # war disrupts farming
        return base

    def consume_food(self, city: CityState) -> float:
        return city.population.total * self.config.base_food_consumption * 0.01

    def wealth_from_trade_goods(self, city: CityState) -> float:
        merchant_output = city.population.merchants * 0.5 * (city.ideology.trade / 100.0)
        return merchant_output

    def update_city(self, city: CityState) -> None:
        produced = self.produce_food(city)
        consumed = self.consume_food(city)
        city.food_stock += produced - consumed

        if city.food_stock < 0:
            # famine: starvation shrinks population and craters happiness
            deficit = -city.food_stock
            starved = min(city.population.citizens, int(deficit))
            city.population.citizens -= starved
            city.happiness -= 8.0
            city.food_stock = 0.0
        else:
            city.happiness += 0.3 if produced > consumed else -0.1

        city.treasury += self.wealth_from_trade_goods(city)

        # upkeep costs
        upkeep = city.military.hoplites * 0.02 + city.military.triremes * 0.5
        city.treasury -= upkeep
        if city.treasury < 0:
            city.happiness -= 2.0  # unpaid soldiers/citizens grow discontent
            city.unrest += 1.5
            city.treasury = max(city.treasury, -200.0)

        city.happiness = max(0.0, min(100.0, city.happiness))

    def update(self) -> None:
        for city in self.cities.values():
            self.update_city(city)
