"""The player: one agent inside the ecosystem, not a scripted protagonist.

The player has no special powers over the simulation's rules -- every
action routes through the exact same systems NPCs use (assembly votes,
combat resolution, trade, persuasion). The only difference is that the
player's actions are chosen explicitly (via player.interaction) instead
of by an AI decide() call.
"""
from dataclasses import dataclass, field
from typing import List, Optional

from npc.ai_agent import AIAgent


@dataclass
class PlayerAgent(AIAgent):
    reputation_with_cities: dict = field(default_factory=dict)
    profession: str = "citizen"   # citizen | philosopher | general | merchant | politician
    action_log: List[str] = field(default_factory=list)

    def __post_init__(self):
        self.role = "player"

    def log(self, text: str) -> None:
        self.action_log.append(text)
        self.memory.remember(text)

    def on_tick(self, world_state) -> None:
        """Passive per-tick upkeep for the player entity (e.g. reputation
        decay toward neutral if they take no action). Called automatically
        by the engine every tick regardless of player input."""
        for city_name in list(self.reputation_with_cities.keys()):
            val = self.reputation_with_cities[city_name]
            self.reputation_with_cities[city_name] = val * 0.995

    def become(self, profession: str) -> None:
        if profession in ("citizen", "philosopher", "general", "merchant", "politician"):
            self.profession = profession
            self.log(f"{self.name} becomes a {profession}")
