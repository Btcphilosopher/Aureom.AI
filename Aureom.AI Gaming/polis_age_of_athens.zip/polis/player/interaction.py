"""Concrete player actions: talk, fight, trade, influence -- each one
reuses the same subsystem logic NPCs use, so the player never gets a
special-cased outcome."""
import random

from politics.assembly import Motion
from ui.dialogue_system import attempt_persuasion
from warfare.combat_engine import resolve_land_battle
from world.city_state import CityState


def talk(player, world_state, target_city_name: str, topic: str = "philosophy") -> str:
    target = world_state.cities[target_city_name]
    success, delta = attempt_persuasion(player, target, topic, world_state.rng)
    outcome = "succeeds" if success else "fails"
    text = f"{player.name} tries to persuade {target_city_name} toward {topic}: {outcome} ({delta:+.1f})"
    player.log(text)
    return text


def fight(player, world_state, enemy_city_name: str) -> str:
    home = world_state.cities[player.home_city]
    enemy = world_state.cities[enemy_city_name]
    if enemy_city_name not in home.at_war_with:
        world_state.diplomacy.declare_war(player.home_city, enemy_city_name,
                                           world_state.chronicle, world_state.time.tick,
                                           world_state.time.year)
    result = resolve_land_battle(home, enemy, world_state.config, world_state.rng)
    text = (f"{player.name} leads troops of {home.name} against {enemy.name}: "
            f"{result.winner} wins ({home.name} losses {result.attacker_losses}, "
            f"{enemy.name} losses {result.defender_losses})")
    player.log(text)
    return text


def trade(player, world_state, dest_city_name: str, amount: float = 30.0) -> str:
    home = world_state.cities[player.home_city]
    dest = world_state.cities[dest_city_name]
    if home.treasury < amount:
        text = f"{player.name} lacks the capital to trade with {dest_city_name}"
        player.log(text)
        return text
    home.treasury -= amount
    profit = amount * world_state.rng.uniform(0.1, 0.6) * (dest.ideology.trade / 100.0)
    home.treasury += amount + profit
    dest.food_stock += amount * 0.2
    text = f"{player.name} trades with {dest_city_name}, netting {profit:.1f} profit"
    player.log(text)
    return text


def influence(player, world_state, motion: Motion) -> str:
    home_name = player.home_city
    assembly = world_state.assemblies[home_name]
    bloc = world_state.rng.choice(assembly.blocs)
    assembly.shift_influence(bloc.name, 5.0)
    passed = assembly.vote(motion, world_state.rng)
    if passed:
        world_state.cities[home_name].happiness += 1.0
    text = f"{player.name} lobbies the {bloc.name} bloc on '{motion.value}': {'passes' if passed else 'fails'}"
    player.log(text)
    return text
