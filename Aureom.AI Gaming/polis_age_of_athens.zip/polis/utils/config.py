"""Global configuration for the POLIS: AGE OF ATHENS simulation."""
from dataclasses import dataclass, field
import random


@dataclass
class SimConfig:
    """Central tunable configuration. Passing a fixed seed makes the
    entire simulation deterministic (same seed -> same emergent history)."""

    seed: int = 1453
    max_ticks: int = 200
    ticks_per_year: int = 4          # one tick == one season
    starting_year: int = -431        # 431 BCE, eve of the Peloponnesian War

    # economy tuning
    base_food_consumption: float = 1.0     # food / citizen / tick
    base_tax_rate: float = 0.15
    trade_efficiency: float = 0.65

    # politics tuning
    unrest_coup_threshold: float = 75.0
    corruption_growth: float = 0.4

    # warfare tuning
    morale_break_threshold: float = 20.0
    naval_supremacy_bonus: float = 0.25

    # ideology tuning
    ideology_diffusion_rate: float = 0.05
    philosopher_influence_strength: float = 0.08

    log_level: str = "INFO"

    def rng(self) -> random.Random:
        """Return a private deterministic RNG derived from the seed."""
        return random.Random(self.seed)


DEFAULT_CONFIG = SimConfig()
