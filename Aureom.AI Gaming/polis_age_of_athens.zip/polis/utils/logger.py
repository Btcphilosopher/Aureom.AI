"""Structured logging + in-memory chronicle for emergent history."""
import logging
import sys
from dataclasses import dataclass, field
from typing import List


def get_logger(name: str = "polis", level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter("[%(name)s] %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    return logger


@dataclass
class Chronicle:
    """Records every emergent historical event so the 'no scripted story'
    principle can be verified after the fact: the run's history is only
    ever what actually happened in the systems."""

    entries: List[str] = field(default_factory=list)

    def record(self, tick: int, year: int, text: str) -> None:
        line = f"Year {year:>5} | Tick {tick:>4} | {text}"
        self.entries.append(line)

    def dump(self) -> str:
        return "\n".join(self.entries)
