"""Main simulation loop. This is the orchestrator described in the spec:

    while running:
        world_state.update()
        economy.update()
        politics.update()
        warfare.update()
        npc.update()
        ideology.update()
        events.update()

World evolves every tick whether or not a player is present.
"""
from typing import Optional

from core.world_state import WorldState
from economy.economy_engine import EconomyEngine
from economy.taxation import collect_taxes
from events.event_engine import EventEngine
from events.historical_emergence import HistoricalEmergenceEngine
from ideology.cultural_spread import diffuse
from ideology.ideology_engine import IdeologyEngine
from politics.assembly import Motion
from politics.governance import evaluate_transition
from utils.logger import get_logger
from warfare.war_state import WarStateManager


class SimulationEngine:
    def __init__(self, world_state: WorldState, player_agent=None):
        self.ws = world_state
        self.player = player_agent
        self.logger = get_logger("engine", world_state.config.log_level)

        self.event_engine = EventEngine()
        self.economy = EconomyEngine(world_state.cities, world_state.config)
        self.ideology_engine = IdeologyEngine(world_state.cities, world_state.config)
        self.war_manager = WarStateManager(world_state.cities, world_state.config, world_state.rng)
        self.emergence = HistoricalEmergenceEngine(world_state, self.event_engine)

        self.running = False

    # -- subsystem phases --------------------------------------------------
    def _economy_phase(self) -> None:
        self.economy.update()
        for city in self.ws.cities.values():
            collect_taxes(city)
        self.ws.trade_network.update(self.ws.chronicle, self.ws.time.tick, self.ws.time.year)

    def _politics_phase(self) -> None:
        for city_name, assembly in self.ws.assemblies.items():
            city = self.ws.cities[city_name]
            evaluate_transition(city)
            # periodic assembly motions -- policy is genuinely voted, not scripted
            if self.ws.time.tick % 2 == 0:
                motion = self.ws.rng.choice(list(Motion))
                passed = assembly.vote(motion, self.ws.rng)
                if passed:
                    self._apply_motion(city, motion)
            city.corruption = min(100.0, city.corruption + self.ws.config.corruption_growth * 0.1)
            city.unrest = max(0.0, city.unrest - 0.5 + (city.corruption / 200.0))

    def _apply_motion(self, city, motion: Motion) -> None:
        if motion == Motion.RAISE_TAXES:
            city.tax_rate = min(0.6, city.tax_rate + 0.03)
        elif motion == Motion.LOWER_TAXES:
            city.tax_rate = max(0.0, city.tax_rate - 0.03)
        elif motion == Motion.FUND_MILITARY:
            spend = min(city.treasury * 0.2, 150.0)
            if spend > 0:
                city.treasury -= spend
                city.military.hoplites += int(spend / 3)
        elif motion == Motion.FUND_PHILOSOPHY:
            city.ideology.shift("philosophy", 2.0)
        elif motion == Motion.DECLARE_WAR:
            others = [n for n in self.ws.cities if n != city.name]
            if others:
                target = max(others, key=lambda n: self.ws.diplomacy.tension(city.name, n))
                self.ws.diplomacy.declare_war(city.name, target, self.ws.chronicle,
                                               self.ws.time.tick, self.ws.time.year)
        elif motion == Motion.SUE_FOR_PEACE:
            for enemy in list(city.at_war_with):
                self.ws.diplomacy.make_peace(city.name, enemy, self.ws.chronicle,
                                              self.ws.time.tick, self.ws.time.year)

    def _warfare_phase(self) -> None:
        self.war_manager.update(self.ws.time, self.ws.chronicle)

    def _npc_phase(self) -> None:
        for agent in self.ws.all_npcs():
            if not agent.alive:
                continue
            result = agent.decide(self.ws, self.ws.rng)
            if result:
                self.logger.debug(result)

    def _ideology_phase(self) -> None:
        self.ideology_engine.update()
        diffuse(self.ws.cities, self.ws.trade_network, self.ws.config)

    def _events_phase(self) -> None:
        self.emergence.update()

    def tick(self) -> None:
        self._economy_phase()
        self._politics_phase()
        self._warfare_phase()
        self._npc_phase()
        self._ideology_phase()
        self._events_phase()

        if self.player is not None:
            self.player.on_tick(self.ws)

        self.ws.time.advance()

    def run(self, max_ticks: Optional[int] = None) -> None:
        self.running = True
        limit = max_ticks or self.ws.config.max_ticks
        for _ in range(limit):
            if not self.running:
                break
            self.tick()
        self.running = False

    def stop(self) -> None:
        self.running = False
