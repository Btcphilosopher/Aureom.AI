"""Global simulation state: the single source of truth every subsystem
reads from and writes to."""
import random
from dataclasses import dataclass, field
from typing import Dict, List

from core.time_system import WorldTime
from economy.trade import TradeNetwork
from factions.diplomacy import DiplomacyManager
from factions.faction import Faction
from politics.assembly import Assembly
from utils.config import SimConfig
from utils.logger import Chronicle
from world.city_state import CityState
from world.geography import Region


@dataclass
class WorldState:
    config: SimConfig
    cities: Dict[str, CityState] = field(default_factory=dict)
    regions: Dict[str, Region] = field(default_factory=dict)
    factions: Dict[str, Faction] = field(default_factory=dict)

    philosophers: List = field(default_factory=list)
    generals: List = field(default_factory=list)
    merchants: List = field(default_factory=list)
    politicians: List = field(default_factory=list)

    assemblies: Dict[str, Assembly] = field(default_factory=dict)
    diplomacy: DiplomacyManager = None
    trade_network: TradeNetwork = None

    time: WorldTime = None
    rng: random.Random = None
    chronicle: Chronicle = field(default_factory=Chronicle)

    def __post_init__(self):
        if self.time is None:
            self.time = WorldTime(self.config.ticks_per_year, self.config.starting_year)
        if self.rng is None:
            self.rng = self.config.rng()

    def register_city(self, city: CityState) -> None:
        self.cities[city.name] = city
        self.assemblies[city.name] = Assembly(city)

    def finalize_setup(self) -> None:
        self.diplomacy = DiplomacyManager(self.cities)
        self.trade_network = TradeNetwork(self.cities, self.config)
        self.trade_network.establish_routes()

    def all_npcs(self) -> List:
        return self.philosophers + self.generals + self.merchants + self.politicians

    def snapshot(self) -> str:
        lines = [f"--- {self.time.label()} ---"]
        for city in self.cities.values():
            lines.append(city.summary())
        return "\n".join(lines)
