"""Tick-based world clock. 1 tick = 1 season; 4 ticks = 1 year."""
from dataclasses import dataclass

SEASONS = ["Spring", "Summer", "Autumn", "Winter"]


@dataclass
class WorldTime:
    ticks_per_year: int
    starting_year: int
    tick: int = 0

    @property
    def year(self) -> int:
        return self.starting_year + self.tick // self.ticks_per_year

    @property
    def season(self) -> str:
        idx = self.tick % self.ticks_per_year
        return SEASONS[idx % len(SEASONS)]

    @property
    def is_campaign_season(self) -> bool:
        """Ancient armies campaigned mainly spring through autumn."""
        return self.season in ("Spring", "Summer", "Autumn")

    def advance(self) -> None:
        self.tick += 1

    def label(self) -> str:
        year = self.year
        era = "BCE" if year < 0 else "CE"
        return f"{self.season} {abs(year)} {era} (tick {self.tick})"
