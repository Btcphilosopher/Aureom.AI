"""NPC interaction system: persuasion, debate, ideological conversion,
political influence, and relationship tracking -- shared by player and
philosopher NPCs alike."""
import random
from typing import Tuple

from world.city_state import CityState

VALID_TOPICS = {"democracy", "militarism", "trade", "philosophy", "authoritarianism"}


def attempt_persuasion(speaker, target_city: CityState, topic: str,
                        rng: random.Random) -> Tuple[bool, float]:
    """A generic persuasion roll: speaker's standing + the city's existing
    openness to the topic determine success; success shifts that
    ideology axis and improves the speaker's standing with the city."""
    if topic not in VALID_TOPICS:
        topic = "philosophy"

    reputation = getattr(speaker, "reputation_with_cities", {}).get(target_city.name, 0.0) \
        if hasattr(speaker, "reputation_with_cities") else 0.0
    openness = getattr(target_city.ideology, topic) / 100.0
    base_chance = 0.35 + openness * 0.3 + max(-0.2, min(0.2, reputation / 250.0))
    success = rng.random() < base_chance

    delta = rng.uniform(1.0, 4.0) if success else -rng.uniform(0.5, 1.5)
    target_city.ideology.shift(topic, delta)

    if hasattr(speaker, "reputation_with_cities"):
        current = speaker.reputation_with_cities.get(target_city.name, 0.0)
        speaker.reputation_with_cities[target_city.name] = current + (5.0 if success else -2.0)

    return success, delta


def debate(agent_a, agent_b, rng: random.Random) -> str:
    """Resolve a rhetorical contest between two NPC/agents holding a
    belief profile (see npc.ideology.BeliefProfile)."""
    conv_a = getattr(getattr(agent_a, "belief", None), "conviction", 50.0)
    conv_b = getattr(getattr(agent_b, "belief", None), "conviction", 50.0)
    win_chance = conv_a / (conv_a + conv_b + 1e-6)
    a_wins = rng.random() < win_chance
    winner, loser = (agent_a, agent_b) if a_wins else (agent_b, agent_a)
    winner.adjust_reputation(loser.agent_id, 4)
    loser.adjust_reputation(winner.agent_id, -4)
    return f"{winner.name} wins the debate against {loser.name}"
