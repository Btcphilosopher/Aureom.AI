"""Text-based polis interface: detailed single-city readout."""
from world.city_state import CityState


def render_city(city: CityState) -> str:
    ideo = city.ideology.as_dict()
    ideo_bar = ", ".join(f"{k}={v:.0f}" for k, v in ideo.items())
    lines = [
        f"===== {city.name} =====",
        f"Government : {city.government.value}",
        f"Population : {city.population.total} "
        f"(citizens={city.population.citizens}, slaves={city.population.slaves}, "
        f"merchants={city.population.merchants}, soldiers={city.population.soldiers})",
        f"Treasury   : {city.treasury:.1f}  | Food: {city.food_stock:.1f} | Tax rate: {city.tax_rate:.2f}",
        f"Happiness  : {city.happiness:.1f} | Unrest: {city.unrest:.1f} | Corruption: {city.corruption:.1f}",
        f"Military   : {city.military.hoplites} hoplites, {city.military.triremes} triremes, "
        f"morale {city.military.morale:.1f}, supply {city.military.supply_level:.1f}",
        f"At war with: {', '.join(city.at_war_with) or 'none'}",
        f"Allies     : {', '.join(city.allies) or 'none'}",
        f"Territories: {', '.join(city.controlled_territories)}",
        f"Ideology   : {ideo_bar}",
    ]
    return "\n".join(lines)
