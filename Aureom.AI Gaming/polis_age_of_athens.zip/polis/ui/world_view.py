"""ASCII map visualization of the Greek world -- no external GUI deps."""
from typing import Dict

from world.city_state import CityState

GRID_W, GRID_H = 100, 60


def render_map(cities: Dict[str, CityState]) -> str:
    grid = [[" "] * (GRID_W // 2) for _ in range(GRID_H // 3)]
    for city in cities.values():
        x = int(city.region.coordinate.x / 2)
        y = int(city.region.coordinate.y / 3)
        x = max(0, min(GRID_W // 2 - 1, x))
        y = max(0, min(GRID_H // 3 - 1, y))
        marker = "!" if city.is_at_war else "o"
        grid[y][x] = marker

    lines = ["".join(row) for row in grid]
    legend = "\nLegend: o = at peace, ! = at war\n"
    labels = ", ".join(f"{c.name}({'war' if c.is_at_war else 'peace'})" for c in cities.values())
    return "\n".join(lines) + legend + labels
