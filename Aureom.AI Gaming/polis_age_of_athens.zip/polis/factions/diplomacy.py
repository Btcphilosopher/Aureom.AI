"""Alliance / war-state management between city-states."""
from dataclasses import dataclass, field
from typing import Dict, List

from factions.reputation import ReputationTable
from world.city_state import CityState


@dataclass
class DiplomacyManager:
    cities: Dict[str, CityState]
    reputation: ReputationTable = field(default_factory=ReputationTable)

    def declare_war(self, attacker: str, defender: str, chronicle=None, tick=0, year=0) -> None:
        a, d = self.cities[attacker], self.cities[defender]
        if defender in a.at_war_with:
            return
        a.at_war_with.add(defender)
        d.at_war_with.add(attacker)
        self.reputation.adjust(attacker, defender, -60)
        # allies get dragged in defensively
        for ally in list(d.allies):
            if ally in self.cities and ally != attacker:
                self.cities[ally].at_war_with.add(attacker)
                self.cities[attacker].at_war_with.add(ally)
        if chronicle:
            chronicle.record(tick, year, f"WAR DECLARED: {attacker} invades {defender}.")

    def make_peace(self, city_a: str, city_b: str, chronicle=None, tick=0, year=0) -> None:
        a, b = self.cities[city_a], self.cities[city_b]
        a.at_war_with.discard(city_b)
        b.at_war_with.discard(city_a)
        self.reputation.adjust(city_a, city_b, 15)
        if chronicle:
            chronicle.record(tick, year, f"PEACE: {city_a} and {city_b} end hostilities.")

    def form_alliance(self, city_a: str, city_b: str, chronicle=None, tick=0, year=0) -> None:
        a, b = self.cities[city_a], self.cities[city_b]
        a.allies.add(city_b)
        b.allies.add(city_a)
        self.reputation.adjust(city_a, city_b, 40)
        if chronicle:
            chronicle.record(tick, year, f"ALLIANCE FORMED: {city_a} and {city_b}.")

    def break_alliance(self, city_a: str, city_b: str, chronicle=None, tick=0, year=0) -> None:
        a, b = self.cities[city_a], self.cities[city_b]
        if city_b in a.allies:
            a.allies.discard(city_b)
            b.allies.discard(city_a)
            self.reputation.adjust(city_a, city_b, -30)
            if chronicle:
                chronicle.record(tick, year, f"ALLIANCE BROKEN: {city_a} abandons {city_b}.")

    def ideological_divergence(self, city_a: str, city_b: str) -> float:
        va = self.cities[city_a].ideology.as_dict()
        vb = self.cities[city_b].ideology.as_dict()
        return sum(abs(va[k] - vb[k]) for k in va) / len(va)

    def tension(self, city_a: str, city_b: str) -> float:
        """0..100 measure of how likely conflict is between two cities."""
        rep = self.reputation.get(city_a, city_b)
        divergence = self.ideological_divergence(city_a, city_b)
        militarism = (self.cities[city_a].ideology.militarism + self.cities[city_b].ideology.militarism) / 2
        return max(0.0, min(100.0, (-rep * 0.4) + divergence * 0.4 + militarism * 0.2))
