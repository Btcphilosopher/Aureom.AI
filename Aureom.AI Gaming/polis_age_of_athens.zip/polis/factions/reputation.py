"""Bilateral inter-city relation scores, -100 (blood enemies) .. +100 (close allies)."""
from collections import defaultdict
from typing import Dict, Tuple


class ReputationTable:
    def __init__(self):
        self._scores: Dict[Tuple[str, str], float] = {}

    @staticmethod
    def _key(a: str, b: str) -> Tuple[str, str]:
        return tuple(sorted((a, b)))  # type: ignore

    def get(self, a: str, b: str) -> float:
        if a == b:
            return 100.0
        return self._scores.get(self._key(a, b), 0.0)

    def adjust(self, a: str, b: str, delta: float) -> float:
        if a == b:
            return 100.0
        key = self._key(a, b)
        new_val = max(-100.0, min(100.0, self._scores.get(key, 0.0) + delta))
        self._scores[key] = new_val
        return new_val

    def stance(self, a: str, b: str) -> str:
        score = self.get(a, b)
        if score >= 60:
            return "close_ally"
        if score >= 20:
            return "friendly"
        if score > -20:
            return "neutral"
        if score > -60:
            return "hostile"
        return "bitter_enemy"
