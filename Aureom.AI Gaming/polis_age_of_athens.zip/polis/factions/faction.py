"""A Faction is the diplomatic/political actor that controls a CityState.
Kept distinct from CityState so the model can later support leagues or
empires controlling multiple poleis without reworking diplomacy."""
from dataclasses import dataclass, field
from typing import List

from world.city_state import CityState


@dataclass
class Faction:
    faction_id: str
    leader_name: str
    home_city: CityState
    doctrine: str = "independent"   # e.g. "delian_league", "peloponnesian_league"
    member_cities: List[str] = field(default_factory=list)

    def __post_init__(self):
        if self.home_city.name not in self.member_cities:
            self.member_cities.append(self.home_city.name)

    @property
    def power_index(self) -> float:
        m = self.home_city.military
        econ = self.home_city.treasury / 100.0
        return m.land_strength + m.naval_strength * 1.5 + econ
