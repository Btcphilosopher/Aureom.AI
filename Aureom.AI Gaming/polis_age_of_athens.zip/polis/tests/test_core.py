import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import random

from core.engine import SimulationEngine
from core.world_state import WorldState
from economy.economy_engine import EconomyEngine
from economy.taxation import collect_taxes
from politics.coups import attempt_coup, coup_probability
from utils.config import SimConfig
from warfare.combat_engine import resolve_land_battle
from world.city_state import CityState, GovernmentType, IdeologyVector, Military, Population
from world.geography import Coordinate, Region, Terrain


def make_region(name="Testopolis"):
    return Region(name=name, coordinate=Coordinate(0, 0), terrain=Terrain.COASTAL_PLAIN,
                  fertility=0.7, strategic_value=0.5)


def make_city(name="Testopolis", **overrides):
    defaults = dict(
        name=name,
        region=make_region(name),
        government=GovernmentType.DEMOCRACY,
        population=Population(citizens=1000, slaves=500, merchants=200, soldiers=100),
        ideology=IdeologyVector(),
        military=Military(hoplites=300, triremes=10),
    )
    defaults.update(overrides)
    return CityState(**defaults)


def test_determinism_same_seed_same_history():
    from main import build_world
    ws1 = build_world(SimConfig(seed=42, max_ticks=20))
    ws2 = build_world(SimConfig(seed=42, max_ticks=20))
    eng1 = SimulationEngine(ws1)
    eng2 = SimulationEngine(ws2)
    eng1.run(15)
    eng2.run(15)
    assert ws1.chronicle.dump() == ws2.chronicle.dump()
    for name in ws1.cities:
        assert round(ws1.cities[name].treasury, 4) == round(ws2.cities[name].treasury, 4)


def test_economy_food_production_and_consumption():
    config = SimConfig()
    city = make_city()
    engine = EconomyEngine({"Testopolis": city}, config)
    starting_food = city.food_stock
    engine.update_city(city)
    assert city.food_stock != starting_food  # something happened


def test_famine_shrinks_population_and_hurts_happiness():
    config = SimConfig()
    city = make_city(food_stock=0.0)
    city.population.citizens = 10
    engine = EconomyEngine({"Testopolis": city}, config)
    happiness_before = city.happiness
    # force a big consumption deficit
    for _ in range(50):
        engine.update_city(city)
    assert city.happiness <= happiness_before


def test_taxation_generates_revenue():
    city = make_city()
    treasury_before = city.treasury
    collect_taxes(city)
    assert city.treasury != treasury_before


def test_land_combat_reduces_forces_on_both_sides():
    config = SimConfig()
    rng = random.Random(7)
    attacker = make_city("Attackia", military=Military(hoplites=500, triremes=5))
    defender = make_city("Defendia", military=Military(hoplites=500, triremes=5))
    attacker.at_war_with.add("Defendia")
    defender.at_war_with.add("Attackia")
    result = resolve_land_battle(attacker, defender, config, rng)
    assert result.attacker_losses >= 0 and result.defender_losses >= 0
    assert attacker.military.hoplites <= 500
    assert defender.military.hoplites <= 500


def test_coup_probability_rises_with_unrest_and_corruption():
    calm_city = make_city(unrest=5.0, corruption=5.0)
    unstable_city = make_city(unrest=90.0, corruption=80.0)
    config = SimConfig()
    assert coup_probability(unstable_city, config) > coup_probability(calm_city, config)


def test_coup_can_fire_under_extreme_unrest():
    config = SimConfig(unrest_coup_threshold=10.0)
    city = make_city(unrest=95.0, corruption=90.0)
    rng = random.Random(1)
    fired_at_least_once = False
    for _ in range(20):
        city.unrest = 95.0
        if attempt_coup(city, config, rng):
            fired_at_least_once = True
            break
    assert fired_at_least_once


def test_ideology_vector_clamped_0_100():
    vec = IdeologyVector(democracy=95.0)
    vec.shift("democracy", 100.0)
    assert vec.democracy == 100.0
    vec.shift("democracy", -1000.0)
    assert vec.democracy == 0.0
