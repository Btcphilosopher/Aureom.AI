"""Assembly voting: policy motions weighted by faction influence."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Tuple

from politics.governance import government_influence_multiplier
from world.city_state import CityState


class Motion(Enum):
    RAISE_TAXES = "raise_taxes"
    LOWER_TAXES = "lower_taxes"
    DECLARE_WAR = "declare_war"
    SUE_FOR_PEACE = "sue_for_peace"
    FUND_MILITARY = "fund_military"
    FUND_PHILOSOPHY = "fund_philosophy"


@dataclass
class PoliticalFaction:
    """A power bloc inside a city (not to be confused with factions.Faction,
    the external diplomatic actor)."""
    name: str
    influence: float           # 0..100, share of political weight
    ideology_lean: str         # which IdeologyVector axis they push


@dataclass
class Assembly:
    city: CityState
    blocs: List[PoliticalFaction] = field(default_factory=list)

    def __post_init__(self):
        if not self.blocs:
            self.blocs = [
                PoliticalFaction("Demos", 40, "democracy"),
                PoliticalFaction("Aristocrats", 30, "authoritarianism"),
                PoliticalFaction("Merchants", 20, "trade"),
                PoliticalFaction("Hawks", 10, "militarism"),
            ]

    def vote(self, motion: Motion, rng) -> bool:
        """Weighted vote; each bloc's support probability is shaped by its
        ideology lean and the current government's willingness to listen."""
        mult = government_influence_multiplier(self.city)
        support_weight = 0.0
        total_weight = 0.0
        for bloc in self.blocs:
            weight = bloc.influence * (mult if bloc.name != "Aristocrats" else 1.0)
            total_weight += weight
            support_weight += weight * self._support_probability(bloc, motion)
        ratio = support_weight / total_weight if total_weight else 0
        passed = rng.random() < ratio
        return passed

    def _support_probability(self, bloc: PoliticalFaction, motion: Motion) -> float:
        lean_value = getattr(self.city.ideology, bloc.ideology_lean)
        base = lean_value / 100.0
        if motion in (Motion.DECLARE_WAR, Motion.FUND_MILITARY):
            return base if bloc.ideology_lean == "militarism" else base * 0.6
        if motion == Motion.SUE_FOR_PEACE:
            return 1.0 - (self.city.ideology.militarism / 100.0)
        if motion == Motion.FUND_PHILOSOPHY:
            return base if bloc.ideology_lean == "democracy" else base * 0.5
        if motion == Motion.RAISE_TAXES:
            return 0.3 if bloc.name == "Merchants" else 0.6
        if motion == Motion.LOWER_TAXES:
            return 0.7 if bloc.name == "Merchants" else 0.4
        return 0.5

    def shift_influence(self, bloc_name: str, delta: float) -> None:
        for bloc in self.blocs:
            if bloc.name == bloc_name:
                bloc.influence = max(0.0, min(100.0, bloc.influence + delta))
