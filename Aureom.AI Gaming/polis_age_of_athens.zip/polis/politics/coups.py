"""Regime-change logic: coups erupt from unrest + corruption, never scripted."""
import random

from utils.config import SimConfig
from world.city_state import CityState, GovernmentType

NEXT_REGIME_ON_COUP = {
    GovernmentType.DEMOCRACY: GovernmentType.OLIGARCHY,
    GovernmentType.OLIGARCHY: GovernmentType.TYRANNY,
    GovernmentType.TYRANNY: GovernmentType.DEMOCRACY,
}


def coup_probability(city: CityState, config: SimConfig) -> float:
    if city.unrest < config.unrest_coup_threshold * 0.5:
        return 0.0
    pressure = (city.unrest / 100.0) * 0.6 + (city.corruption / 100.0) * 0.3
    pressure += 0.1 if city.is_at_war else 0.0
    return min(0.9, pressure)


def attempt_coup(city: CityState, config: SimConfig, rng: random.Random,
                  chronicle=None, tick=0, year=0) -> bool:
    if city.unrest < config.unrest_coup_threshold:
        return False
    prob = coup_probability(city, config)
    if rng.random() > prob:
        return False

    old_gov = city.government
    new_gov = NEXT_REGIME_ON_COUP[old_gov]
    city.government = new_gov
    city.unrest = max(0.0, city.unrest - 40.0)
    city.corruption = max(0.0, city.corruption - 15.0)
    city.happiness -= 10.0
    # a violent transition briefly weakens the military (defections, purges)
    city.military.morale = max(10.0, city.military.morale - 20.0)

    if chronicle:
        chronicle.record(
            tick, year,
            f"COUP: {city.name} overthrows its {old_gov.value} government; "
            f"a {new_gov.value} seizes power.")
    return True
