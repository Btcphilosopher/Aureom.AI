"""Government type transitions driven by stability, ideology and events."""
from world.city_state import CityState, GovernmentType


def evaluate_transition(city: CityState) -> None:
    """Governments are not scripted to change; they drift only when the
    underlying ideology vector has clearly moved past the incumbent
    system's mandate."""
    dem = city.ideology.democracy
    auth = city.ideology.authoritarianism

    if city.government == GovernmentType.DEMOCRACY and auth > dem + 25 and city.stability < 40:
        city.government = GovernmentType.OLIGARCHY
        city.happiness -= 5.0
    elif city.government == GovernmentType.OLIGARCHY:
        if dem > auth + 25 and city.stability > 55:
            city.government = GovernmentType.DEMOCRACY
            city.happiness += 5.0
        elif auth > 80 and city.corruption > 60:
            city.government = GovernmentType.TYRANNY
    elif city.government == GovernmentType.TYRANNY and dem > auth and city.unrest > 60:
        city.government = GovernmentType.OLIGARCHY
        city.unrest -= 20.0


def government_influence_multiplier(city: CityState) -> float:
    """How much an average citizen's voice matters in policy -- feeds assembly.py."""
    return {
        GovernmentType.DEMOCRACY: 1.0,
        GovernmentType.OLIGARCHY: 0.4,
        GovernmentType.TYRANNY: 0.1,
    }[city.government]
