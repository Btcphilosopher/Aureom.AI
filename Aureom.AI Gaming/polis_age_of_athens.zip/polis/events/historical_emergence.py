"""The emergence engine: this is the ONLY place wars, revolutions,
philosophical movements, economic collapses and alliance shifts get
triggered -- and every trigger fires purely off measured world-state
thresholds. There is no scripted timeline anywhere in this module.
"""
import random

from events.event_engine import EventEngine, GameEvent
from politics.coups import attempt_coup
from world.city_state import GovernmentType

WAR_TENSION_THRESHOLD = 55.0
ALLIANCE_REP_THRESHOLD = 55.0
BREAK_ALLIANCE_REP_THRESHOLD = -10.0
ECONOMIC_COLLAPSE_TREASURY = -150.0
PHILOSOPHY_MOVEMENT_THRESHOLD = 85.0


class HistoricalEmergenceEngine:
    def __init__(self, world_state, event_engine: EventEngine):
        self.ws = world_state
        self.events = event_engine

    # -- individual emergent checks --------------------------------------
    def _check_war_outbreaks(self) -> None:
        names = list(self.ws.cities.keys())
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                if b in self.ws.cities[a].at_war_with:
                    continue
                tension = self.ws.diplomacy.tension(a, b)
                if tension >= WAR_TENSION_THRESHOLD and self.ws.rng.random() < (tension - WAR_TENSION_THRESHOLD) / 100.0 + 0.05:
                    self.ws.diplomacy.declare_war(a, b, self.ws.chronicle, self.ws.time.tick, self.ws.time.year)
                    self.events.emit(GameEvent("war_outbreak", self.ws.time.tick, self.ws.time.year,
                                                {"attacker": a, "defender": b}))

    def _check_alliances(self) -> None:
        names = list(self.ws.cities.keys())
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                if b in self.ws.cities[a].at_war_with:
                    continue
                rep = self.ws.diplomacy.reputation.get(a, b)
                already_allied = b in self.ws.cities[a].allies
                if not already_allied and rep >= ALLIANCE_REP_THRESHOLD and self.ws.rng.random() < 0.2:
                    self.ws.diplomacy.form_alliance(a, b, self.ws.chronicle, self.ws.time.tick, self.ws.time.year)
                elif already_allied and rep <= BREAK_ALLIANCE_REP_THRESHOLD:
                    self.ws.diplomacy.break_alliance(a, b, self.ws.chronicle, self.ws.time.tick, self.ws.time.year)

    def _check_revolutions(self) -> None:
        for city in self.ws.cities.values():
            if attempt_coup(city, self.ws.config, self.ws.rng, self.ws.chronicle, self.ws.time.tick, self.ws.time.year):
                self.events.emit(GameEvent("revolution", self.ws.time.tick, self.ws.time.year,
                                            {"city": city.name, "new_government": city.government.value}))

    def _check_economic_collapse(self) -> None:
        for city in self.ws.cities.values():
            if city.treasury <= ECONOMIC_COLLAPSE_TREASURY:
                city.happiness = max(0.0, city.happiness - 15.0)
                city.unrest = min(100.0, city.unrest + 20.0)
                city.tax_rate = min(0.6, city.tax_rate + 0.05)
                self.ws.chronicle.record(
                    self.ws.time.tick, self.ws.time.year,
                    f"ECONOMIC COLLAPSE: {city.name}'s treasury is ruined; unrest spikes.")
                self.events.emit(GameEvent("economic_collapse", self.ws.time.tick, self.ws.time.year,
                                            {"city": city.name}))
                city.treasury = 0.0

    def _check_philosophical_movements(self) -> None:
        for city in self.ws.cities.values():
            dominant_value = getattr(city.ideology, city.ideology.dominant())
            if dominant_value >= PHILOSOPHY_MOVEMENT_THRESHOLD:
                axis = city.ideology.dominant()
                self.ws.chronicle.record(
                    self.ws.time.tick, self.ws.time.year,
                    f"PHILOSOPHICAL MOVEMENT: a school of {axis} sweeps {city.name}, "
                    f"reshaping public life.")
                self.events.emit(GameEvent("philosophical_movement", self.ws.time.tick, self.ws.time.year,
                                            {"city": city.name, "axis": axis}))
                city.ideology.shift(axis, -10.0)  # movement crests then settles

    def _check_famine_and_migration(self) -> None:
        for city in self.ws.cities.values():
            if city.food_stock <= 0 and city.happiness < 25:
                migrants = int(city.population.citizens * 0.03)
                if migrants and len(self.ws.cities) > 1:
                    dest_name = self.ws.rng.choice([n for n in self.ws.cities if n != city.name])
                    dest = self.ws.cities[dest_name]
                    city.population.citizens -= migrants
                    dest.population.citizens += migrants
                    self.ws.chronicle.record(
                        self.ws.time.tick, self.ws.time.year,
                        f"MIGRATION: famine drives {migrants} citizens from {city.name} to {dest_name}.")

    def update(self) -> None:
        self._check_war_outbreaks()
        self._check_alliances()
        self._check_revolutions()
        self._check_economic_collapse()
        self._check_philosophical_movements()
        self._check_famine_and_migration()
