"""Lightweight pub/sub event bus used across all subsystems."""
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Callable, Dict, List


@dataclass
class GameEvent:
    kind: str
    tick: int
    year: int
    payload: dict = field(default_factory=dict)


class EventEngine:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[GameEvent], None]]] = defaultdict(list)
        self.history: List[GameEvent] = []

    def subscribe(self, kind: str, handler: Callable[[GameEvent], None]) -> None:
        self._subscribers[kind].append(handler)

    def emit(self, event: GameEvent) -> None:
        self.history.append(event)
        for handler in self._subscribers.get(event.kind, []):
            handler(event)
        for handler in self._subscribers.get("*", []):
            handler(event)

    def recent(self, n: int = 10) -> List[GameEvent]:
        return self.history[-n:]
