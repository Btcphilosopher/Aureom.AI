"""POLIS: AGE OF ATHENS -- entry point and mandatory demo scenario.

Run with:  python main.py [--ticks N] [--seed N] [--quiet]

Demonstrates, purely through emergent simulation (no scripted events):
  * an Athens vs Sparta conflict chain
  * philosopher NPCs influencing ideology
  * trade disruption between city-states
  * naval war escalation
  * at least one political coup
"""
import argparse
import copy
import sys

from core.engine import SimulationEngine
from core.world_state import WorldState
from npc.generals import GeneralAgent
from npc.merchants import MerchantAgent
from npc.ideology import SCHOOLS, BeliefProfile
from npc.philosophers import PhilosopherAgent
from npc.politicians import PoliticianAgent
from player.player_agent import PlayerAgent
from player import interaction as player_actions
from politics.assembly import Motion
from ui.city_view import render_city
from ui.world_view import render_map
from utils.config import SimConfig
from utils.logger import get_logger
from world.city_state import CityState, GovernmentType, IdeologyVector, Military, Population
from world.map_generator import generate_world

CITY_SEED_DATA = {
    "Athens": dict(government=GovernmentType.DEMOCRACY,
                   population=Population(citizens=4000, slaves=3000, merchants=1200, soldiers=800),
                   ideology=IdeologyVector(democracy=75, militarism=45, trade=70, philosophy=65, authoritarianism=25),
                   military=Military(hoplites=1200, triremes=40)),
    "Sparta": dict(government=GovernmentType.OLIGARCHY,
                   population=Population(citizens=1500, slaves=6000, merchants=200, soldiers=2000),
                   ideology=IdeologyVector(democracy=20, militarism=90, trade=25, philosophy=30, authoritarianism=70),
                   military=Military(hoplites=2200, triremes=10)),
    "Corinth": dict(government=GovernmentType.OLIGARCHY,
                     population=Population(citizens=2500, slaves=1500, merchants=1800, soldiers=500),
                     ideology=IdeologyVector(democracy=40, militarism=40, trade=85, philosophy=40, authoritarianism=45),
                     military=Military(hoplites=700, triremes=35)),
    "Thebes": dict(government=GovernmentType.OLIGARCHY,
                    population=Population(citizens=2200, slaves=1800, merchants=600, soldiers=700),
                    ideology=IdeologyVector(democracy=35, militarism=65, trade=45, philosophy=45, authoritarianism=55),
                    military=Military(hoplites=900, triremes=8)),
    "Argos": dict(government=GovernmentType.DEMOCRACY,
                   population=Population(citizens=1800, slaves=1200, merchants=500, soldiers=400),
                   ideology=IdeologyVector(democracy=60, militarism=50, trade=50, philosophy=40, authoritarianism=35),
                   military=Military(hoplites=500, triremes=12)),
    "Megara": dict(government=GovernmentType.OLIGARCHY,
                    population=Population(citizens=1200, slaves=800, merchants=700, soldiers=250),
                    ideology=IdeologyVector(democracy=30, militarism=35, trade=75, philosophy=35, authoritarianism=50),
                    military=Military(hoplites=300, triremes=18)),
}


def build_world(config: SimConfig) -> WorldState:
    ws = WorldState(config=config)
    ws.regions = generate_world(config.seed)

    for name, data in CITY_SEED_DATA.items():
        # CITY_SEED_DATA holds dataclass instances built once at import time;
        # deep-copy per call so independent simulation runs (e.g. two
        # build_world() calls in the same process, as in the determinism
        # test) never share -- and silently co-mutate -- state.
        region = ws.regions[name]
        city = CityState(name=name, region=region, **copy.deepcopy(data))
        ws.register_city(city)

    ws.finalize_setup()

    # -- seed Athens vs Sparta as the opening emergent flashpoint --------
    ws.diplomacy.reputation.adjust("Athens", "Sparta", -50)
    ws.diplomacy.reputation.adjust("Corinth", "Sparta", 20)
    ws.diplomacy.reputation.adjust("Corinth", "Athens", -15)
    ws.diplomacy.form_alliance("Athens", "Argos", ws.chronicle, 0, ws.time.year)
    ws.diplomacy.form_alliance("Sparta", "Thebes", ws.chronicle, 0, ws.time.year)
    ws.diplomacy.form_alliance("Sparta", "Corinth", ws.chronicle, 0, ws.time.year)

    rng = ws.rng
    # -- populate NPC agents ----------------------------------------------
    philosopher_names = ["Socrates", "Anaxagoras", "Gorgias", "Zeno", "Thales"]
    for i, pname in enumerate(philosopher_names):
        home = rng.choice(list(ws.cities.keys()))
        ws.philosophers.append(PhilosopherAgent(name=pname, home_city=home,
                                                 belief=BeliefProfile(school=rng.choice(SCHOOLS))))

    general_names = ["Pericles", "Brasidas", "Nicias", "Lysander", "Demosthenes"]
    for gname in general_names:
        home = rng.choice(list(ws.cities.keys()))
        ws.generals.append(GeneralAgent(name=gname, home_city=home, aggression=rng.uniform(30, 90)))

    merchant_names = ["Hermon", "Kallias", "Xenon", "Timon", "Phanes"]
    for mname in merchant_names:
        home = rng.choice(list(ws.cities.keys()))
        ws.merchants.append(MerchantAgent(name=mname, home_city=home, capital=rng.uniform(80, 250)))

    politician_names = ["Cleon", "Alcibiades", "Nicostratus"]
    for polname in politician_names:
        home = rng.choice(list(ws.cities.keys()))
        ws.politicians.append(PoliticianAgent(name=polname, home_city=home, ambition=rng.uniform(40, 95)))

    return ws


def build_player(ws: WorldState) -> PlayerAgent:
    player = PlayerAgent(name="The Philosopher", home_city="Athens")
    player.reputation_with_cities = {name: 0.0 for name in ws.cities}
    return player


def run_demo(ticks: int, seed: int, quiet: bool) -> None:
    config = SimConfig(seed=seed, max_ticks=ticks, log_level="WARNING" if quiet else "INFO")
    logger = get_logger("main", config.log_level)

    ws = build_world(config)
    player = build_player(ws)
    engine = SimulationEngine(ws, player_agent=player)

    logger.info("=== POLIS: AGE OF ATHENS -- simulation start ===")
    logger.info(ws.snapshot())

    # A handful of explicit player actions early on, proving the player is
    # just another agent routed through the same systems as the NPCs.
    print(player_actions.talk(player, ws, "Corinth", topic="philosophy"))
    print(player_actions.trade(player, ws, "Argos", amount=40))
    print(player_actions.influence(player, ws, Motion.FUND_PHILOSOPHY))

    for t in range(ticks):
        engine.tick()
        if not quiet and t % 10 == 0:
            print(f"\n{ws.snapshot()}")

    print("\n\n================= FINAL WORLD MAP =================")
    print(render_map(ws.cities))

    print("\n================= FINAL CITY REPORTS =================")
    for name in ("Athens", "Sparta"):
        print(render_city(ws.cities[name]))
        print()

    print("================= CHRONICLE OF EMERGENT HISTORY =================")
    print(ws.chronicle.dump() or "(the world remained at an uneasy peace)")

    print("\n================= PLAYER ACTION LOG =================")
    for line in player.action_log:
        print(line)


def main() -> None:
    parser = argparse.ArgumentParser(description="POLIS: AGE OF ATHENS simulation engine")
    parser.add_argument("--ticks", type=int, default=80, help="number of simulation ticks to run")
    parser.add_argument("--seed", type=int, default=1453, help="deterministic RNG seed")
    parser.add_argument("--quiet", action="store_true", help="suppress periodic snapshots")
    args = parser.parse_args()

    try:
        run_demo(args.ticks, args.seed, args.quiet)
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
