# POLIS: AGE OF ATHENS

A modular, systemic simulation engine of the Ancient Greek world: city-state
economies, politics, ideology and warfare interact through autonomous AI
agents to produce **emergent** history. There is no scripted timeline
anywhere in this codebase — every war, coup, alliance, philosophical
movement and economic collapse fires purely off measured thresholds in the
simulation's own state (see `events/historical_emergence.py`).

## Requirements

* Python 3.11+
* No external services or APIs. `pytest` is the only third-party
  dependency, and only for running the test suite (`pip install -r
  requirements.txt`).

## Running the demo

```bash
cd polis
python3 main.py --ticks 80 --seed 1453
```

Flags:

* `--ticks N` — number of simulation ticks to run (1 tick = 1 season).
* `--seed N` — RNG seed. The same seed always reproduces the exact same
  emergent history (verified by `tests/test_core.py::test_determinism_*`).
* `--quiet` — suppress the periodic world snapshots and only print the
  final report + chronicle.

The demo seeds Athens (democracy) against Sparta (militarist oligarchy)
with a hostile starting reputation, mirroring the eve of the
Peloponnesian War, then lets six city-states, a cast of philosopher /
general / merchant / politician NPCs, and one player agent run freely.
Expect to see, purely as emergent output: war outbreaks, naval battles,
trade routes severed by war, coups, philosophical movements sweeping a
city's ideology, famine-driven migration, and shifting alliances.

## Running the tests

```bash
python3 -m pytest -q
```

## Architecture

```
polis/
├── core/       # engine.py (main tick loop), time_system.py, world_state.py
├── world/      # map_generator.py, geography.py, city_state.py (the Polis model)
├── factions/   # faction.py, diplomacy.py, reputation.py
├── economy/    # economy_engine.py, trade.py, taxation.py
├── politics/   # governance.py, assembly.py, coups.py
├── warfare/    # combat_engine.py, naval_combat.py, morale.py, war_state.py
├── npc/        # ai_agent.py + philosophers/generals/merchants/politicians
├── ideology/   # ideology_engine.py, cultural_spread.py
├── events/     # event_engine.py (pub/sub bus), historical_emergence.py
├── player/     # player_agent.py, interaction.py
├── ui/         # world_view.py (ASCII map), city_view.py, dialogue_system.py
├── utils/      # logger.py, config.py
├── main.py
└── tests/
```

### The main loop (`core/engine.py`)

```python
while running:
    world_state.update()   # implicit: economy/politics/warfare/npc/ideology all mutate world_state
    economy.update()
    politics.update()
    warfare.update()
    npc.update()
    ideology.update()
    events.update()
```

Every phase reads and writes the same shared `WorldState`. The world
advances identically whether or not a player is present — the player is
just another agent whose actions route through the exact same subsystems
(`player/interaction.py` calls the same `resolve_land_battle`,
`Assembly.vote`, and persuasion functions NPCs use).

### Determinism

Pass `--seed N` for a fully reproducible run: the same seed drives world
generation, NPC placement, every dice roll in combat, politics, and
economy. `tests/test_core.py` asserts two independent `WorldState`
builds with the same seed produce byte-identical chronicles.

## Design principle

> No scripted story — only emergent simulation.

Concretely, this means:

* `events/historical_emergence.py` is the **only** place wars,
  revolutions, philosophical movements, economic collapses, and alliance
  shifts get triggered, and every trigger is a threshold check against
  live world state (tension, unrest, corruption, treasury, ideology
  dominance) — never a fixed tick number or hardcoded outcome.
* City governments drift between democracy / oligarchy / tyranny only
  when their ideology vector and stability cross a mandate threshold
  (`politics/governance.py`), not on a schedule.
* NPCs (`npc/*.py`) make goal-driven decisions each tick based on their
  home city's live state, their own memory of past events, and their
  reputation with other agents — never a scripted script of actions.
