"""Army psychology model shared by land and naval combat."""
from world.city_state import CityState, Military


def pre_battle_morale_modifier(city: CityState) -> float:
    """Happiness/unrest at home bleeds into how willing troops are to fight."""
    home_factor = (city.happiness - city.unrest) / 100.0
    return max(-15.0, min(15.0, home_factor * 15.0))


def apply_battle_outcome(military: Military, won: bool, casualties_fraction: float) -> None:
    if won:
        military.morale = min(100.0, military.morale + 8.0)
    else:
        military.morale = max(0.0, military.morale - 18.0)
    military.supply_level = max(0.0, military.supply_level - casualties_fraction * 30.0)


def is_routed(military: Military, threshold: float) -> bool:
    return military.morale <= threshold


def attrition_tick(military: Military, campaigning: bool) -> None:
    if campaigning:
        military.supply_level = max(0.0, military.supply_level - 4.0)
        if military.supply_level < 25.0:
            military.morale = max(0.0, military.morale - 5.0)
    else:
        military.supply_level = min(100.0, military.supply_level + 6.0)
        military.morale = min(100.0, military.morale + 1.5)
