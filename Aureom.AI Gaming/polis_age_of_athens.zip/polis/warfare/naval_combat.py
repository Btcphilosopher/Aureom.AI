"""Trireme naval warfare -- controls sea trade lanes and troop transport."""
import random
from dataclasses import dataclass

from utils.config import SimConfig
from warfare.morale import apply_battle_outcome, is_routed
from world.city_state import CityState


@dataclass
class NavalBattleResult:
    attacker: str
    defender: str
    winner: str
    attacker_ships_lost: int
    defender_ships_lost: int
    naval_supremacy: str


def resolve_naval_battle(attacker: CityState, defender: CityState,
                          config: SimConfig, rng: random.Random) -> NavalBattleResult:
    atk_power = attacker.military.naval_strength * rng.uniform(0.8, 1.2)
    def_power = defender.military.naval_strength * rng.uniform(0.8, 1.2)

    attacker_won = atk_power > def_power
    total = atk_power + def_power + 1e-6
    intensity = min(atk_power, def_power) / total

    atk_lost = int(attacker.military.triremes * intensity * (0.3 if attacker_won else 0.45))
    def_lost = int(defender.military.triremes * intensity * (0.45 if attacker_won else 0.3))

    attacker.military.triremes = max(0, attacker.military.triremes - atk_lost)
    defender.military.triremes = max(0, defender.military.triremes - def_lost)

    apply_battle_outcome(attacker.military, attacker_won, intensity)
    apply_battle_outcome(defender.military, not attacker_won, intensity)

    if attacker.military.triremes > defender.military.triremes * 1.5:
        supremacy = attacker.name
    elif defender.military.triremes > attacker.military.triremes * 1.5:
        supremacy = defender.name
    else:
        supremacy = "contested"

    if supremacy == attacker.name:
        attacker.treasury += config.naval_supremacy_bonus * 100
    elif supremacy == defender.name:
        defender.treasury += config.naval_supremacy_bonus * 100

    winner = attacker.name if attacker_won else defender.name
    return NavalBattleResult(attacker.name, defender.name, winner, atk_lost, def_lost, supremacy)
