"""Tracks active wars and resolves campaign-season engagements each tick."""
import random
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

from core.time_system import WorldTime
from utils.config import SimConfig
from warfare.combat_engine import resolve_land_battle
from warfare.morale import attrition_tick
from warfare.naval_combat import resolve_naval_battle
from world.city_state import CityState


@dataclass
class WarStateManager:
    cities: Dict[str, CityState]
    config: SimConfig
    rng: random.Random
    _resolved_pairs: Set[Tuple[str, str]] = field(default_factory=set)

    def active_war_pairs(self) -> List[Tuple[str, str]]:
        seen = set()
        pairs = []
        for name, city in self.cities.items():
            for enemy in city.at_war_with:
                key = tuple(sorted((name, enemy)))
                if key not in seen:
                    seen.add(key)
                    pairs.append(key)
        return pairs

    def update(self, time: WorldTime, chronicle=None) -> None:
        campaigning = time.is_campaign_season
        for city in self.cities.values():
            attrition_tick(city.military, campaigning and city.is_at_war)

        if not campaigning:
            return

        for a_name, b_name in self.active_war_pairs():
            a, b = self.cities[a_name], self.cities[b_name]
            if a.military.hoplites <= 0 and b.military.hoplites <= 0:
                continue
            # attacker is whichever side currently has more land strength (opportunistic AI)
            attacker, defender = (a, b) if a.military.land_strength >= b.military.land_strength else (b, a)
            if attacker.military.hoplites < 50:
                continue  # too weak to campaign this season

            result = resolve_land_battle(attacker, defender, self.config, self.rng)
            if chronicle:
                chronicle.record(
                    time.tick, time.year,
                    f"BATTLE: {result.attacker} vs {result.defender} -> {result.winner} wins "
                    f"(losses {result.attacker}:{result.attacker_losses}, "
                    f"{result.defender}:{result.defender_losses})"
                    + (f"; {result.routed} routs!" if result.routed else "")
                )

            if attacker.military.triremes > 0 and defender.military.triremes > 0:
                nres = resolve_naval_battle(attacker, defender, self.config, self.rng)
                if chronicle:
                    chronicle.record(
                        time.tick, time.year,
                        f"NAVAL BATTLE: {nres.attacker} vs {nres.defender} -> {nres.winner} wins, "
                        f"supremacy: {nres.naval_supremacy}"
                    )

            self._handle_territory_shift(attacker, defender, result, chronicle, time)

    def _handle_territory_shift(self, attacker, defender, result, chronicle, time) -> None:
        if result.winner == attacker.name and result.routed == defender.name:
            if defender.controlled_territories and len(defender.controlled_territories) > 1:
                lost = defender.controlled_territories.pop()
                attacker.controlled_territories.append(lost)
                if chronicle:
                    chronicle.record(
                        time.tick, time.year,
                        f"TERRITORY CAPTURED: {attacker.name} seizes {lost} from {defender.name}."
                    )
            defender.happiness -= 6.0
            defender.unrest += 8.0
