"""Land combat resolution between two city-states' hoplite armies."""
import random
from dataclasses import dataclass

from utils.config import SimConfig
from warfare.morale import apply_battle_outcome, is_routed, pre_battle_morale_modifier
from world.city_state import CityState


@dataclass
class BattleResult:
    attacker: str
    defender: str
    winner: str
    attacker_losses: int
    defender_losses: int
    routed: str = ""


def resolve_land_battle(attacker: CityState, defender: CityState,
                         config: SimConfig, rng: random.Random) -> BattleResult:
    atk_power = attacker.military.land_strength + pre_battle_morale_modifier(attacker)
    def_power = defender.military.land_strength * 1.15  # home-terrain advantage
    def_power += pre_battle_morale_modifier(defender)

    atk_roll = max(1.0, atk_power * rng.uniform(0.75, 1.25))
    def_roll = max(1.0, def_power * rng.uniform(0.75, 1.25))

    attacker_won = atk_roll > def_roll
    total = atk_roll + def_roll
    intensity = min(atk_roll, def_roll) / total  # closer fights => heavier losses

    atk_losses = int(attacker.military.hoplites * intensity * (0.35 if attacker_won else 0.5))
    def_losses = int(defender.military.hoplites * intensity * (0.5 if attacker_won else 0.35))

    attacker.military.hoplites = max(0, attacker.military.hoplites - atk_losses)
    defender.military.hoplites = max(0, defender.military.hoplites - def_losses)

    atk_frac = atk_losses / max(1, attacker.military.hoplites + atk_losses)
    def_frac = def_losses / max(1, defender.military.hoplites + def_losses)
    apply_battle_outcome(attacker.military, attacker_won, atk_frac)
    apply_battle_outcome(defender.military, not attacker_won, def_frac)

    routed = ""
    if is_routed(attacker.military, config.morale_break_threshold):
        routed = attacker.name
    elif is_routed(defender.military, config.morale_break_threshold):
        routed = defender.name

    winner = attacker.name if attacker_won else defender.name
    return BattleResult(attacker.name, defender.name, winner, atk_losses, def_losses, routed)
