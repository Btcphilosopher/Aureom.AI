"""Merchant agents: economic optimisers who seek out profitable trade."""
import random
from dataclasses import dataclass

from npc.ai_agent import AIAgent


@dataclass
class MerchantAgent(AIAgent):
    capital: float = 100.0
    risk_tolerance: float = 50.0

    def __post_init__(self):
        self.role = "merchant"
        self.goals = ["maximize_profit", "expand_routes", "avoid_warzones"]

    def _best_destination(self, world_state):
        candidates = [c for c in world_state.cities if c != self.home_city]
        if not candidates:
            return None
        home = world_state.cities[self.home_city]

        def score(name):
            city = world_state.cities[name]
            if name in home.at_war_with:
                return -1e9
            dist = home.region.coordinate.distance_to(city.region.coordinate)
            return city.ideology.trade - dist * 0.5

        return max(candidates, key=score)

    def decide(self, world_state, rng: random.Random):
        home = world_state.cities[self.home_city]
        dest_name = self._best_destination(world_state)
        if dest_name is None:
            return None
        dest = world_state.cities[dest_name]

        venture = min(self.capital * 0.4, 50.0)
        if venture < 5:
            return None

        risk = 0.2 if dest_name in home.at_war_with else 0.05
        success = rng.random() > risk
        if success:
            profit = venture * rng.uniform(0.15, 0.5) * (dest.ideology.trade / 100.0)
            self.capital += profit
            home.treasury += profit * 0.2
            dest.food_stock += venture * 0.1
            self.memory.remember(f"Profitable venture to {dest_name} (+{profit:.1f})")
            return f"{self.name} trades with {dest_name}, profits {profit:.1f}"
        else:
            loss = venture * 0.5
            self.capital = max(0.0, self.capital - loss)
            self.memory.remember(f"Lost cargo en route to {dest_name}")
            return f"{self.name}'s cargo is lost en route to {dest_name}"
