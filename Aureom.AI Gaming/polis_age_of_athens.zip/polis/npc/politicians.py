"""Politician agents: power-seekers who manipulate assemblies and corruption."""
import random
from dataclasses import dataclass

from npc.ai_agent import AIAgent


@dataclass
class PoliticianAgent(AIAgent):
    ambition: float = 50.0
    bloc_name: str = "Demos"

    def __post_init__(self):
        self.role = "politician"
        self.goals = ["gain_influence", "enrich_self", "sway_assembly"]

    def decide(self, world_state, rng: random.Random):
        city = world_state.cities[self.home_city]
        assembly = world_state.assemblies[self.home_city]

        action = "corrupt" if (self.ambition > 60 and rng.random() < 0.35) else "campaign"

        if action == "corrupt":
            gain = self.ambition * 0.05
            city.corruption = min(100.0, city.corruption + gain)
            city.treasury -= gain * 2
            self.memory.remember(f"Skimmed public funds in {city.name}")
            return f"{self.name} quietly enriches themselves, corruption rises in {city.name}"

        assembly.shift_influence(self.bloc_name, self.ambition * 0.02)
        self.memory.remember(f"Campaigned for the {self.bloc_name} bloc")
        return f"{self.name} campaigns, boosting the {self.bloc_name} bloc in {city.name}"
