"""Philosopher agents: originate and spread ideology within/across cities."""
import random
from dataclasses import dataclass, field

from npc.ai_agent import AIAgent
from npc.ideology import SCHOOLS, BeliefProfile


@dataclass
class PhilosopherAgent(AIAgent):
    # NOTE: deliberately NOT randomized here. A default_factory that calls
    # the global `random` module would draw from Python's process-wide RNG
    # state instead of the simulation's seeded world_state.rng, silently
    # breaking determinism between separate WorldState builds in the same
    # process. Callers that want a random school must roll it themselves
    # from world_state.rng and pass belief=BeliefProfile(school=...).
    belief: BeliefProfile = field(default_factory=lambda: BeliefProfile(school=SCHOOLS[0]))
    students_recruited: int = 0

    def __post_init__(self):
        self.role = "philosopher"
        self.goals = ["spread_ideology", "recruit_students", "debate_rivals"]

    def decide(self, world_state, rng: random.Random):
        city = world_state.cities[self.home_city]
        action = rng.choice(["teach", "recruit", "debate", "travel"])

        if action == "teach":
            axis = self.belief.target_axis()
            delta = self.belief.persuasion_power() * world_state.config.philosopher_influence_strength * 100
            city.ideology.shift(axis, delta * 0.1)
            self.memory.remember(f"Taught {self.belief.school} in {city.name}")
            self.belief.conviction = min(100.0, self.belief.conviction + 0.5)
            return f"{self.name} teaches {self.belief.school} in {city.name} (+{axis})"

        if action == "recruit":
            gained = rng.randint(0, 3)
            self.students_recruited += gained
            if gained:
                self.memory.remember(f"Recruited {gained} students in {city.name}")
            return f"{self.name} recruits {gained} students"

        if action == "debate":
            rivals = [p for p in world_state.philosophers if p.agent_id != self.agent_id]
            if not rivals:
                return None
            rival = rng.choice(rivals)
            win_chance = self.belief.conviction / (self.belief.conviction + rival.belief.conviction)
            won = rng.random() < win_chance
            if won:
                rival.belief.conviction = max(10.0, rival.belief.conviction - 5.0)
                self.belief.conviction = min(100.0, self.belief.conviction + 3.0)
                self.adjust_reputation(rival.agent_id, 5)
                rival.adjust_reputation(self.agent_id, -5)
            self.memory.remember(f"Debated {rival.name}: {'won' if won else 'lost'}")
            return f"{self.name} debates {rival.name}: {'wins' if won else 'loses'}"

        if action == "travel" and len(world_state.cities) > 1:
            others = [c for c in world_state.cities if c != self.home_city]
            self.home_city = rng.choice(others)
            return f"{self.name} travels to teach in {self.home_city}"

        return None
