"""General agents: plan and execute military campaigns for their city."""
import random
from dataclasses import dataclass, field

from npc.ai_agent import AIAgent


@dataclass
class GeneralAgent(AIAgent):
    aggression: float = 50.0   # 0..100, personal disposition toward war

    def __post_init__(self):
        self.role = "general"
        self.goals = ["build_army", "wage_war", "defend_homeland"]

    def decide(self, world_state, rng: random.Random):
        city = world_state.cities[self.home_city]
        threat = max(
            (world_state.diplomacy.tension(self.home_city, other)
             for other in world_state.cities if other != self.home_city),
            default=0.0,
        )
        want_levy = (self.aggression + threat) / 2.0 > 55 and city.population.citizens > 200

        if want_levy and city.treasury > 100:
            levy = city.population.levy_soldiers(0.05)
            city.military.hoplites += levy
            cost = levy * 0.3
            city.treasury -= cost
            self.memory.remember(f"Levied {levy} hoplites in {city.name}")
            return f"{self.name} levies {levy} new hoplites for {city.name}"

        if city.treasury > 300 and rng.random() < 0.3:
            ships = rng.randint(1, 3)
            city.military.triremes += ships
            city.treasury -= ships * 60
            self.memory.remember(f"Commissioned {ships} triremes")
            return f"{self.name} commissions {ships} triremes for {city.name}"

        if city.is_at_war and city.military.morale < 40 and rng.random() < 0.4:
            city.population.demobilize(0.1)
            city.military.morale = min(100.0, city.military.morale + 5.0)
            return f"{self.name} orders a tactical stand-down to preserve morale"

        return None
