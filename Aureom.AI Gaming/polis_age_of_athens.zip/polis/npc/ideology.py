"""Belief-system profile carried by individual NPC agents.

Distinct from world.city_state.IdeologyVector (a city's aggregate stance):
this is a personal doctrine an NPC preaches, trades, or fights for, which
the ideology engine uses as a 'source' when propagating city-level shifts.
"""
from dataclasses import dataclass, field
from typing import Dict

SCHOOLS = ["stoicism", "sophism", "rationalism", "militarism_cult", "mercantilism"]

SCHOOL_TO_AXIS = {
    "stoicism": "philosophy",
    "sophism": "democracy",
    "rationalism": "philosophy",
    "militarism_cult": "militarism",
    "mercantilism": "trade",
}


@dataclass
class BeliefProfile:
    school: str
    conviction: float = 50.0   # 0..100, how strongly held / persuasively argued

    def target_axis(self) -> str:
        return SCHOOL_TO_AXIS.get(self.school, "philosophy")

    def persuasion_power(self) -> float:
        return self.conviction / 100.0
