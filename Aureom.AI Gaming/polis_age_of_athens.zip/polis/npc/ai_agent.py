"""Base class for all autonomous NPC agents in the simulation."""
import random
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class Memory:
    """A rolling log of events the agent has personally witnessed or heard of."""
    events: List[str] = field(default_factory=list)
    capacity: int = 30

    def remember(self, text: str) -> None:
        self.events.append(text)
        if len(self.events) > self.capacity:
            self.events.pop(0)

    def recall_matching(self, keyword: str) -> List[str]:
        return [e for e in self.events if keyword.lower() in e.lower()]


@dataclass
class AIAgent:
    name: str
    home_city: str
    role: str = "citizen"
    agent_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    memory: Memory = field(default_factory=Memory)
    reputation: Dict[str, float] = field(default_factory=dict)  # per other-agent-id
    goals: List[str] = field(default_factory=list)
    alive: bool = True

    def perceive(self, event_text: str) -> None:
        self.memory.remember(event_text)

    def adjust_reputation(self, other_id: str, delta: float) -> None:
        current = self.reputation.get(other_id, 0.0)
        self.reputation.get(other_id, 0.0)
        self.reputation[other_id] = max(-100.0, min(100.0, current + delta))

    def decide(self, world_state, rng: random.Random) -> Optional[str]:
        """Base goal-driven decision hook. Subclasses override with role logic.
        Returns a short description of the action taken, or None if idle."""
        return None
