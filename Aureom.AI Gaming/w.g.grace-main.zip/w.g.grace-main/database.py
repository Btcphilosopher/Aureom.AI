"""database.py — SQLite persistence layer for W.G.Grace-1"""

import sqlite3
import json
from pathlib import Path
from contextlib import contextmanager
from typing import Any

from .utils import DB_PATH, get_logger

log = get_logger("database")

# ── Schema ─────────────────────────────────────────────────────────────────────
SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS players (
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    nationality   TEXT,
    dob           TEXT,
    role          TEXT,       -- batsman/bowler/allrounder/wicketkeeper
    batting_style TEXT,
    bowling_style TEXT,
    stats_json    TEXT,       -- JSON blob of career stats
    attributes_json TEXT,     -- JSON blob of skill attributes
    personal_json TEXT,       -- JSON blob of morale/fatigue/motivation
    nft_token_id  TEXT,
    team_id       TEXT,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS teams (
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    short_name    TEXT,
    country       TEXT,
    team_type     TEXT,       -- international/county/t20/franchise
    home_ground   TEXT,
    finances_json TEXT,
    squad_json    TEXT,       -- ordered list of player IDs
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS matches (
    id            TEXT PRIMARY KEY,
    home_team_id  TEXT,
    away_team_id  TEXT,
    match_type    TEXT,       -- test/odi/t20/county
    venue         TEXT,
    date          TEXT,
    status        TEXT,       -- scheduled/in_progress/completed/abandoned
    result_json   TEXT,
    innings_json  TEXT,
    events_json   TEXT,
    weather_json  TEXT,
    pitch_json    TEXT,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS seasons (
    id            TEXT PRIMARY KEY,
    year          INTEGER,
    tournaments_json TEXT,
    standings_json   TEXT,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS nft_tokens (
    token_id      TEXT PRIMARY KEY,
    player_id     TEXT,
    owner_address TEXT,
    mint_tx       TEXT,
    metadata_json TEXT,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transactions (
    id            TEXT PRIMARY KEY,
    tx_type       TEXT,       -- nft_trade/transfer/lease
    from_address  TEXT,
    to_address    TEXT,
    amount_sats   INTEGER,
    player_id     TEXT,
    lightning_invoice TEXT,
    status        TEXT,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
    id            TEXT PRIMARY KEY,
    event_type    TEXT,
    related_id    TEXT,       -- player/team/match id
    description   TEXT,
    impact_json   TEXT,
    triggered_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS save_states (
    id            TEXT PRIMARY KEY,
    slot          INTEGER,
    season_year   INTEGER,
    game_state_json TEXT,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


# ── Connection ─────────────────────────────────────────────────────────────────
def _get_connection(path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    return conn

@contextmanager
def get_db(path: Path = DB_PATH):
    conn = _get_connection(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path: Path = DB_PATH):
    """Create all tables if they don't exist."""
    with get_db(path) as conn:
        conn.executescript(SCHEMA)
    log.info(f"Database initialised at {path}")


# ── Generic CRUD ──────────────────────────────────────────────────────────────
def insert(table: str, data: dict[str, Any], path: Path = DB_PATH):
    cols = ", ".join(data.keys())
    placeholders = ", ".join("?" for _ in data)
    sql = f"INSERT OR REPLACE INTO {table} ({cols}) VALUES ({placeholders})"
    with get_db(path) as conn:
        conn.execute(sql, list(data.values()))

def update(table: str, data: dict[str, Any], where: str, params: list, path: Path = DB_PATH):
    sets = ", ".join(f"{k} = ?" for k in data)
    sql = f"UPDATE {table} SET {sets} WHERE {where}"
    with get_db(path) as conn:
        conn.execute(sql, list(data.values()) + params)

def fetch_one(table: str, where: str = "1=1", params: list | None = None, path: Path = DB_PATH) -> dict | None:
    sql = f"SELECT * FROM {table} WHERE {where} LIMIT 1"
    with get_db(path) as conn:
        row = conn.execute(sql, params or []).fetchone()
    return dict(row) if row else None

def fetch_all(table: str, where: str = "1=1", params: list | None = None, path: Path = DB_PATH) -> list[dict]:
    sql = f"SELECT * FROM {table} WHERE {where}"
    with get_db(path) as conn:
        rows = conn.execute(sql, params or []).fetchall()
    return [dict(r) for r in rows]

def delete(table: str, where: str, params: list, path: Path = DB_PATH):
    sql = f"DELETE FROM {table} WHERE {where}"
    with get_db(path) as conn:
        conn.execute(sql, params)

def count(table: str, where: str = "1=1", params: list | None = None, path: Path = DB_PATH) -> int:
    sql = f"SELECT COUNT(*) FROM {table} WHERE {where}"
    with get_db(path) as conn:
        return conn.execute(sql, params or []).fetchone()[0]


# ── JSON column helpers ────────────────────────────────────────────────────────
def encode_json(data: Any) -> str:
    return json.dumps(data, default=str)

def decode_json(s: str | None) -> Any:
    if not s:
        return {}
    try:
        return json.loads(s)
    except (json.JSONDecodeError, TypeError):
        return {}


# ── Player persistence ────────────────────────────────────────────────────────
def save_player(player: "Player"):  # noqa: F821
    insert("players", {
        "id":               player.id,
        "name":             player.name,
        "nationality":      player.nationality,
        "dob":              player.dob,
        "role":             player.role,
        "batting_style":    player.batting_style,
        "bowling_style":    player.bowling_style,
        "stats_json":       encode_json(player.stats),
        "attributes_json":  encode_json(player.attributes),
        "personal_json":    encode_json(player.personal),
        "nft_token_id":     getattr(player, "nft_token_id", None),
        "team_id":          getattr(player, "team_id", None),
    })

def load_player(player_id: str) -> dict | None:
    row = fetch_one("players", "id = ?", [player_id])
    if row:
        row["stats"]      = decode_json(row.pop("stats_json", "{}"))
        row["attributes"] = decode_json(row.pop("attributes_json", "{}"))
        row["personal"]   = decode_json(row.pop("personal_json", "{}"))
    return row

def load_all_players() -> list[dict]:
    rows = fetch_all("players")
    for r in rows:
        r["stats"]      = decode_json(r.pop("stats_json", "{}"))
        r["attributes"] = decode_json(r.pop("attributes_json", "{}"))
        r["personal"]   = decode_json(r.pop("personal_json", "{}"))
    return rows


# ── Team persistence ──────────────────────────────────────────────────────────
def save_team(team: "Team"):  # noqa: F821
    insert("teams", {
        "id":            team.id,
        "name":          team.name,
        "short_name":    team.short_name,
        "country":       team.country,
        "team_type":     team.team_type,
        "home_ground":   team.home_ground,
        "finances_json": encode_json(team.finances),
        "squad_json":    encode_json([p.id for p in team.squad]),
    })

def load_team(team_id: str) -> dict | None:
    row = fetch_one("teams", "id = ?", [team_id])
    if row:
        row["finances"] = decode_json(row.pop("finances_json", "{}"))
        row["squad"]    = decode_json(row.pop("squad_json", "[]"))
    return row


# ── Match persistence ─────────────────────────────────────────────────────────
def save_match(match: "MatchRecord"):  # noqa: F821
    insert("matches", {
        "id":            match["id"],
        "home_team_id":  match.get("home_team_id"),
        "away_team_id":  match.get("away_team_id"),
        "match_type":    match.get("match_type"),
        "venue":         match.get("venue"),
        "date":          match.get("date"),
        "status":        match.get("status", "scheduled"),
        "result_json":   encode_json(match.get("result", {})),
        "innings_json":  encode_json(match.get("innings", [])),
        "events_json":   encode_json(match.get("events", [])),
        "weather_json":  encode_json(match.get("weather", {})),
        "pitch_json":    encode_json(match.get("pitch", {})),
    })

def save_event(event: dict):
    insert("events", {
        "id":           event["id"],
        "event_type":   event.get("type"),
        "related_id":   event.get("related_id"),
        "description":  event.get("description"),
        "impact_json":  encode_json(event.get("impact", {})),
    })
