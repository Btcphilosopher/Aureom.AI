"""main.py — W.G.Grace-1 startup, orchestration, and CLI fallback"""

from __future__ import annotations
import sys
import argparse
import random
from .utils import load_config, get_logger, cfg
from .database import init_db

log = get_logger("main")


def run_cli_demo():
    """Run a comprehensive demo in terminal mode (no GUI required)."""
    print("\n" + "═"*62)
    print("  W . G . G R A C E - 1")
    print("  Cricket Management & Simulation — Anglo-Futurist Edition")
    print("═"*62 + "\n")

    from .data_loader import create_international_teams, create_county_teams, STADIUMS
    from .career import CareerManager
    from .match_sim import MatchEngine
    from .commentary import CommentaryEngine, PodcastEngine, MediaEngine
    from .analytics import build_dashboard_data, Standings
    from .multiplayer import Tournament, InternationalCalendar
    from .events import EventEngine
    from .nft_players import get_registry, is_nft_eligible

    print("⏳ Loading teams and squads...")
    intl_teams = create_international_teams()
    print(f"✓ {len(intl_teams)} international teams loaded")

    england    = intl_teams["England"]
    australia  = intl_teams["Australia"]
    india      = intl_teams["India"]

    career_mgr = CareerManager(england)
    engine     = MatchEngine()
    commentary = CommentaryEngine()
    podcast    = PodcastEngine()
    media      = MediaEngine()
    events_eng = EventEngine()

    # ── 1. Squad overview ─────────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  ENGLAND SQUAD")
    print("─"*50)
    for p in sorted(england.squad, key=lambda p: p.overall_rating, reverse=True)[:11]:
        inj = f" ⚠ {p.personal.injury}" if p.personal.is_injured() else ""
        print(f"  {p.name:<28} {p.role:<12} OVR:{p.overall_rating:>5}{inj}")

    # ── 2. Match simulation ───────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  ASHES TEST MATCH — Lord's Cricket Ground")
    print("─"*50)
    match = engine.simulate_match(england, australia, "test", "Lord's Cricket Ground")

    result = match["result"]
    toss   = match["toss"]
    print(f"\n  Toss: {toss['winner']} elected to {toss['choice']}")
    print(f"  Pitch: {match['pitch']['pitch_type']}  |  Weather: {match['weather']['current']}")
    print()
    for inn in match["innings"]:
        print(f"  {inn['team_name']:<25} {inn['runs']:>4}/{inn['wickets']}"
              f"  ({inn['overs']} ov)  RR: {inn['rr']}")
    print()
    print(f"  ▶ RESULT: {result.get('winner','?')} "
          + (f"win by {result.get('margin')}" if result.get("type") != "draw" else "— DRAW"))

    # Commentary snippet
    print("\n  COMMENTARY EXCERPT:")
    lords = "Lord's"
    print(f"  {commentary.match_opener('England', 'Australia', lords, 'test')}")
    print(f"  {commentary.pitch_comment(match['pitch']['pitch_type'])}")
    if match["innings"]:
        inn = match["innings"][0]
        print(f"  {commentary.end_of_innings(inn['team_name'], inn['runs'], inn['wickets'], inn['overs'])}")
    print(f"  {commentary.match_result(result.get('winner','?'), result.get('margin',''), result.get('type','runs'))}")

    # ── 3. ODI World Cup mini-tournament ──────────────────────────────────
    print("\n" + "─"*50)
    print("  ICC ODI WORLD CUP — GROUP STAGE (8 teams)")
    print("─"*50)
    teams_8 = list(intl_teams.values())[:8]
    cup = Tournament("ICC ODI World Cup 2024", teams_8, "odi", venue="Multiple")
    cup_result = cup.play_all(verbose=False)
    print(f"\n  {'#':<3} {'Team':<22} {'P':>3} {'W':>3} {'L':>3} {'Pts':>4} {'NRR':>7}")
    print("  " + "─"*47)
    for row in cup_result["standings"]:
        print(f"  {row['pos']:<3} {row['name']:<22} {row['p']:>3} "
              f"{row['w']:>3} {row['l']:>3} {row['pts']:>4} {row['nrr']:>7.3f}")

    champ = cup.champion()
    if champ:
        print(f"\n  🏆 CHAMPION: {champ.name}")

    # ── 4. Season events ──────────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  SEASON EVENTS")
    print("─"*50)
    season_events = events_eng.generate_season_events(england.squad, england)
    for ev in season_events:
        print(f"\n  📋 {ev.title}")
        print(f"     {ev.description}")
        if ev.choices:
            for i, ch in enumerate(ev.choices):
                print(f"     [{i}] {ch['label']}")

    # ── 5. Analytics dashboard ────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  ENGLAND ANALYTICS DASHBOARD")
    print("─"*50)
    dash = build_dashboard_data(england, [match], career_mgr.season)
    print(f"\n  Season:  {dash['season']}   |   "
          f"Record: {dash['record']['wins']}W/{dash['record']['losses']}L/{dash['record']['draws']}D")
    print(f"  Budget:  £{dash['finances']['budget']:,}")
    print(f"  Batting depth: {dash['batting']['batting_depth']}   "
          f"Top 6 avg rating: {dash['batting']['top6_avg_rating']}")
    print(f"  Bowling: {dash['bowling']['bowling_balance']}   "
          f"Pace: {dash['bowling']['num_pace']}   Spin: {dash['bowling']['num_spin']}")
    print(f"\n  Top Batters:")
    for p in dash["top_batters"]:
        print(f"    {p['name']:<26} {p['runs']:>5} runs  avg {p['avg']}")
    print(f"\n  Top Bowlers:")
    for p in dash["top_bowlers"]:
        print(f"    {p['name']:<26} {p['wkts']:>4} wkts  bb {p['bb']}")

    # ── 6. NFT marketplace ────────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  NFT MARKETPLACE")
    print("─"*50)
    registry  = get_registry()
    eligible  = [p for p in england.squad + australia.squad if is_nft_eligible(p)]
    for p in eligible[:3]:
        rec = registry.mint(p, "manager_wallet")
        registry.list_for_sale(rec["token_id"], ask_sats=random.randint(50000, 500000))
        print(f"  ✓ Minted: {p.name} (OVR {p.overall_rating}) — "
              f"ask: {rec.get('ask_sats', 0):,} sats")
    summary = registry.summary()
    print(f"\n  Total minted:        {summary['total_minted']}")
    print(f"  For sale:            {summary['for_sale']}")
    print(f"  Total volume (sats): {summary['total_volume_sats']:,}")

    # ── 7. Podcast ────────────────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  POST-MATCH PODCAST")
    print("─"*50)
    top_p = sorted(england.squad, key=lambda p: p.stats.runs, reverse=True)[:3]
    pod_text = podcast.generate_post_match_podcast(
        "England", "Australia", match["result"],
        [p.name for p in top_p], "Lord's Cricket Ground"
    )
    print("\n" + pod_text)

    # ── 8. Media headlines ────────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  MEDIA HEADLINES")
    print("─"*50)
    headlines = media.generate_headlines(england.squad, list(intl_teams.values()), match["result"], n=5)
    for h in headlines:
        print(f"  ◆ {h}")

    # ── 9. Career progression ─────────────────────────────────────────────
    print("\n" + "─"*50)
    print("  OFF-SEASON: DEVELOPING ENGLAND'S SQUAD")
    print("─"*50)
    career_mgr.simulate_off_season()
    summary = career_mgr.season_summary()
    print(f"\n  Season {summary['season']} complete.")
    print(f"  Best bat:   {summary['best_bat']}")
    print(f"  Best bowl:  {summary['best_bowl']}")
    print(f"  Budget:     £{summary['finances']['budget']:,}")

    print("\n" + "═"*62)
    print("  W.G.Grace-1 demo complete. Launch the GUI for the full experience.")
    print("  Run:  python -m wg_grace_1 --gui")
    print("═"*62 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="W.G.Grace-1 — Cricket Management Simulation"
    )
    parser.add_argument("--gui",   action="store_true", help="Launch the PyQt6 GUI")
    parser.add_argument("--demo",  action="store_true", help="Run CLI demo (default)")
    parser.add_argument("--init",  action="store_true", help="Initialise database only")
    parser.add_argument("--config",type=str, default=None, help="Path to config.json")
    args = parser.parse_args()

    load_config(args.config)
    init_db()

    if args.init:
        print("Database initialised.")
        return

    if args.gui:
        from .gui import launch_gui
        launch_gui()
    else:
        run_cli_demo()


if __name__ == "__main__":
    main()
