"""data_loader.py — Seed data: teams, stadiums, tournaments"""

from __future__ import annotations
from .career import Team, Player, generate_player
from .utils import get_logger

log = get_logger("data_loader")

# ── Stadiums ──────────────────────────────────────────────────────────────────
STADIUMS = [
    {"name": "Lord's Cricket Ground",       "city": "London",      "country": "England",     "capacity": 30000},
    {"name": "The Oval",                    "city": "London",      "country": "England",     "capacity": 25500},
    {"name": "Headingley",                  "city": "Leeds",       "country": "England",     "capacity": 17000},
    {"name": "Edgbaston",                   "city": "Birmingham",  "country": "England",     "capacity": 24500},
    {"name": "Old Trafford",                "city": "Manchester",  "country": "England",     "capacity": 19000},
    {"name": "Melbourne Cricket Ground",    "city": "Melbourne",   "country": "Australia",   "capacity": 100024},
    {"name": "Sydney Cricket Ground",       "city": "Sydney",      "country": "Australia",   "capacity": 48000},
    {"name": "Adelaide Oval",               "city": "Adelaide",    "country": "Australia",   "capacity": 53583},
    {"name": "Narendra Modi Stadium",       "city": "Ahmedabad",   "country": "India",       "capacity": 132000},
    {"name": "Eden Gardens",                "city": "Kolkata",     "country": "India",       "capacity": 66349},
    {"name": "Wankhede Stadium",            "city": "Mumbai",      "country": "India",       "capacity": 33108},
    {"name": "MA Chidambaram Stadium",      "city": "Chennai",     "country": "India",       "capacity": 50000},
    {"name": "National Stadium",            "city": "Karachi",     "country": "Pakistan",    "capacity": 34228},
    {"name": "Gaddafi Stadium",             "city": "Lahore",      "country": "Pakistan",    "capacity": 27000},
    {"name": "Newlands",                    "city": "Cape Town",   "country": "South Africa","capacity": 25000},
    {"name": "The Wanderers",               "city": "Johannesburg","country": "South Africa","capacity": 34000},
    {"name": "Kensington Oval",             "city": "Bridgetown",  "country": "Barbados",    "capacity": 28000},
    {"name": "Sabina Park",                 "city": "Kingston",    "country": "Jamaica",     "capacity": 20000},
    {"name": "Basin Reserve",               "city": "Wellington",  "country": "New Zealand", "capacity": 11600},
    {"name": "Eden Park",                   "city": "Auckland",    "country": "New Zealand", "capacity": 50000},
    {"name": "R.Premadasa Stadium",         "city": "Colombo",     "country": "Sri Lanka",   "capacity": 35000},
    {"name": "Sher-e-Bangla National",      "city": "Dhaka",       "country": "Bangladesh",  "capacity": 25000},
]


# ── International team definitions ────────────────────────────────────────────
TEAM_DEFS = [
    ("England",      "ENG", "England",     "international", "Lord's Cricket Ground"),
    ("Australia",    "AUS", "Australia",   "international", "Melbourne Cricket Ground"),
    ("India",        "IND", "India",       "international", "Narendra Modi Stadium"),
    ("Pakistan",     "PAK", "Pakistan",    "international", "National Stadium"),
    ("West Indies",  "WI",  "West Indies", "international", "Kensington Oval"),
    ("South Africa", "SA",  "South Africa","international", "Newlands"),
    ("New Zealand",  "NZ",  "New Zealand", "international", "Basin Reserve"),
    ("Sri Lanka",    "SL",  "Sri Lanka",   "international", "R.Premadasa Stadium"),
    ("Bangladesh",   "BAN", "Bangladesh",  "international", "Sher-e-Bangla National"),
    ("Afghanistan",  "AFG", "Afghanistan", "international", "National Stadium"),
]

COUNTY_TEAMS = [
    ("Yorkshire",      "YOR", "England", "county", "Headingley"),
    ("Surrey",         "SUR", "England", "county",  "The Oval"),
    ("Middlesex",      "MID", "England", "county",  "Lord's Cricket Ground"),
    ("Warwickshire",   "WAR", "England", "county",  "Edgbaston"),
    ("Lancashire",     "LAN", "England", "county",  "Old Trafford"),
    ("Somerset",       "SOM", "England", "county",  "County Ground Taunton"),
    ("Hampshire",      "HAM", "England", "county",  "The Ageas Bowl"),
    ("Kent",           "KNT", "England", "county",  "The Spitfire Ground"),
]


def build_squad(nationality: str, size: int = 16, elite_ratio: float = 0.4) -> list[Player]:
    squad = []
    roles_needed = ["batsman"] * 5 + ["bowler"] * 5 + ["allrounder"] * 3 + ["wicketkeeper"] * 1
    import random
    random.shuffle(roles_needed)
    for i in range(size):
        tier  = "elite" if i < int(size * elite_ratio) else "normal"
        role  = roles_needed[i] if i < len(roles_needed) else random.choice(["batsman", "bowler", "allrounder"])
        squad.append(generate_player(nationality=nationality, role=role, tier=tier))
    return squad


def create_international_teams() -> dict[str, Team]:
    teams = {}
    for name, short, country, ttype, ground in TEAM_DEFS:
        t = Team(name=name, short_name=short, country=country,
                 team_type=ttype, home_ground=ground)
        for p in build_squad(country, size=16):
            t.add_player(p)
        teams[name] = t
        log.info(f"Created team: {t.name} ({len(t.squad)} players)")
    return teams


def create_county_teams() -> dict[str, Team]:
    teams = {}
    for name, short, country, ttype, ground in COUNTY_TEAMS:
        t = Team(name=name, short_name=short, country=country,
                 team_type=ttype, home_ground=ground)
        for p in build_squad("England", size=16, elite_ratio=0.25):
            t.add_player(p)
        teams[name] = t
    return teams


def get_stadium(name: str) -> dict | None:
    return next((s for s in STADIUMS if s["name"] == name), None)


def all_stadiums() -> list[dict]:
    return STADIUMS
