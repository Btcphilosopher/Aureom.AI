"""career.py — Player/team models, career growth, AI progression, youth academies"""

from __future__ import annotations
import random
import math
from dataclasses import dataclass, field
from typing import Optional
from .utils import make_id, clamp, chance, roll, weighted_choice, get_logger, cfg
from .database import save_player, save_team

log = get_logger("career")

# ── Constants ─────────────────────────────────────────────────────────────────
ROLES        = ["batsman", "bowler", "allrounder", "wicketkeeper"]
BAT_STYLES   = ["right-hand", "left-hand"]
BOWL_STYLES  = ["right-arm fast", "right-arm medium", "right-arm off-spin",
                "left-arm fast", "left-arm medium", "left-arm spin"]
NATIONALITIES = [
    "England", "Australia", "India", "Pakistan", "West Indies",
    "South Africa", "New Zealand", "Sri Lanka", "Bangladesh", "Zimbabwe",
    "Afghanistan", "Ireland", "Scotland", "Netherlands",
]
INJURIES = [
    "hamstring strain", "back spasm", "shoulder injury",
    "knee injury", "fractured finger", "side strain", "concussion",
    "calf tear", "ankle sprain", "elbow stress fracture",
]
MOTIVATIONS = [
    "pride", "money", "legacy", "revenge", "family", "patriotism",
    "challenge", "redemption", "records", "team spirit",
]


# ── Attributes (0–100) ────────────────────────────────────────────────────────
@dataclass
class BattingAttributes:
    technique:     float = 50.0
    power:         float = 50.0
    timing:        float = 50.0
    footwork:      float = 50.0
    concentration: float = 50.0
    temperament:   float = 50.0   # big-match ability
    against_pace:  float = 50.0
    against_spin:  float = 50.0

@dataclass
class BowlingAttributes:
    pace:          float = 50.0
    accuracy:      float = 50.0
    movement:      float = 50.0   # swing/seam
    turn:          float = 50.0   # spin
    variations:    float = 50.0
    yorker:        float = 50.0
    death_bowling: float = 50.0

@dataclass
class FieldingAttributes:
    catching:      float = 60.0
    throwing:      float = 60.0
    ground:        float = 60.0
    keeping:       float = 30.0   # only relevant for WK

@dataclass
class PlayerAttributes:
    batting:  BattingAttributes  = field(default_factory=BattingAttributes)
    bowling:  BowlingAttributes  = field(default_factory=BowlingAttributes)
    fielding: FieldingAttributes = field(default_factory=FieldingAttributes)
    fitness:  float = 80.0
    potential: float = 70.0      # ceiling for growth

    def overall_batting(self) -> float:
        b = self.batting
        return (b.technique*1.4 + b.timing*1.2 + b.concentration + b.temperament +
                b.footwork + b.power + b.against_pace + b.against_spin) / 9.4

    def overall_bowling(self) -> float:
        bw = self.bowling
        return (bw.pace + bw.accuracy*1.4 + bw.movement*1.2 + bw.turn +
                bw.variations + bw.yorker + bw.death_bowling) / 8.6

    def as_dict(self) -> dict:
        return {
            "batting":  self.batting.__dict__,
            "bowling":  self.bowling.__dict__,
            "fielding": self.fielding.__dict__,
            "fitness":  self.fitness,
            "potential": self.potential,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PlayerAttributes":
        a = cls()
        a.batting  = BattingAttributes(**d.get("batting", {}))
        a.bowling  = BowlingAttributes(**d.get("bowling", {}))
        a.fielding = FieldingAttributes(**d.get("fielding", {}))
        a.fitness  = d.get("fitness", 80.0)
        a.potential = d.get("potential", 70.0)
        return a


# ── Career stats ──────────────────────────────────────────────────────────────
@dataclass
class CareerStats:
    # batting
    matches:      int   = 0
    innings:      int   = 0
    runs:         int   = 0
    high_score:   int   = 0
    average:      float = 0.0
    strike_rate:  float = 0.0
    centuries:    int   = 0
    fifties:      int   = 0
    not_outs:     int   = 0
    # bowling
    overs_bowled: float = 0.0
    wickets:      int   = 0
    bowl_average: float = 0.0
    economy:      float = 0.0
    five_fers:    int   = 0
    best_bowling: str   = "0/0"
    # fielding
    catches:      int   = 0
    stumpings:    int   = 0
    run_outs:     int   = 0

    def update_batting_average(self):
        denom = self.innings - self.not_outs
        self.average = round(self.runs / denom, 2) if denom > 0 else self.runs

    def as_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> "CareerStats":
        cs = cls()
        for k, v in d.items():
            if hasattr(cs, k):
                setattr(cs, k, v)
        return cs


# ── Personal profile ──────────────────────────────────────────────────────────
@dataclass
class PersonalProfile:
    morale:       float = 75.0      # 0–100
    fatigue:      float = 10.0      # 0–100 (higher = more tired)
    confidence:   float = 70.0      # 0–100
    reputation:   float = 50.0      # 0–100 global reputation
    motivation:   str   = "pride"
    injury:       Optional[str] = None
    injury_weeks: int   = 0
    age:          int   = 22
    retirement_age: int = 38
    salary_per_match: int = 5000    # in USD equivalent
    personality:  str   = "balanced"  # aggressive/defensive/balanced/mercurial
    story_flags:  dict  = field(default_factory=dict)   # narrative flags

    def is_injured(self) -> bool:
        return self.injury is not None and self.injury_weeks > 0

    def apply_fatigue(self, amount: float):
        self.fatigue = clamp(self.fatigue + amount, 0, 100)

    def rest(self, weeks: int = 1):
        self.fatigue = clamp(self.fatigue - weeks * 8, 0, 100)
        if self.injury_weeks > 0:
            self.injury_weeks -= weeks
            if self.injury_weeks <= 0:
                self.injury = None
                self.injury_weeks = 0

    def as_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> "PersonalProfile":
        p = cls()
        for k, v in d.items():
            if hasattr(p, k):
                setattr(p, k, v)
        return p


# ── Player model ──────────────────────────────────────────────────────────────
class Player:
    def __init__(
        self,
        name: str,
        nationality: str,
        role: str,
        batting_style: str = "right-hand",
        bowling_style: str = "right-arm medium",
        dob: str = "1998-01-01",
        attributes: Optional[PlayerAttributes] = None,
        personal: Optional[PersonalProfile] = None,
        stats: Optional[CareerStats] = None,
    ):
        self.id            = make_id("plr")
        self.name          = name
        self.nationality   = nationality
        self.role          = role
        self.batting_style = batting_style
        self.bowling_style = bowling_style
        self.dob           = dob
        self.attributes    = attributes or PlayerAttributes()
        self.personal      = personal or PersonalProfile()
        self.stats         = stats or CareerStats()
        self.team_id: Optional[str] = None
        self.nft_token_id: Optional[str] = None

    # ── Derived properties ────────────────────────────────────────────────────
    @property
    def batting_rating(self) -> float:
        return round(self.attributes.overall_batting(), 1)

    @property
    def bowling_rating(self) -> float:
        return round(self.attributes.overall_bowling(), 1)

    @property
    def overall_rating(self) -> float:
        if self.role == "batsman":
            return round(self.batting_rating * 0.8 + self.bowling_rating * 0.2, 1)
        elif self.role == "bowler":
            return round(self.batting_rating * 0.2 + self.bowling_rating * 0.8, 1)
        elif self.role == "wicketkeeper":
            return round(self.batting_rating * 0.7 + self.attributes.fielding.keeping * 0.3, 1)
        else:  # allrounder
            return round((self.batting_rating + self.bowling_rating) / 2, 1)

    def is_available(self) -> bool:
        return not self.personal.is_injured() and self.personal.fatigue < 90

    # ── Growth engine ─────────────────────────────────────────────────────────
    def develop(self, season_performance: dict | None = None):
        """Apply end-of-season development based on age, potential, and performance."""
        age    = self.personal.age
        pot    = self.attributes.potential
        perf   = season_performance or {}

        # Peak age bands: batsmen 26–31, fast bowlers 22–28, spinners 27–34
        if self.role == "bowler" and "fast" in self.bowling_style:
            peak_lo, peak_hi = 22, 28
        elif "spin" in self.bowling_style:
            peak_lo, peak_hi = 27, 34
        else:
            peak_lo, peak_hi = 26, 31

        if age < peak_lo:
            growth_factor = 0.6 + (age - 18) * 0.1
        elif peak_lo <= age <= peak_hi:
            growth_factor = 0.8
        else:
            growth_factor = max(0, 0.8 - (age - peak_hi) * 0.12)

        # Performance bonus
        perf_bonus = perf.get("bonus", 0.0)
        growth_factor = clamp(growth_factor + perf_bonus, 0.0, 1.2)

        # Apply growth to attributes
        def _grow(attr: float) -> float:
            ceiling = pot
            headroom = ceiling - attr
            delta = headroom * growth_factor * 0.1 * random.uniform(0.5, 1.5)
            return clamp(attr + delta, 0, 100)

        b = self.attributes.batting
        b.technique     = _grow(b.technique)
        b.timing        = _grow(b.timing)
        b.concentration = _grow(b.concentration)
        b.temperament   = _grow(b.temperament)

        bw = self.attributes.bowling
        bw.accuracy   = _grow(bw.accuracy)
        bw.movement   = _grow(bw.movement)
        bw.variations = _grow(bw.variations)

        self.personal.age += 1

        # Fitness decay after prime
        if age > 30:
            self.attributes.fitness = clamp(self.attributes.fitness - random.uniform(1, 4), 40, 100)

        log.debug(f"{self.name} developed: overall={self.overall_rating}")

    def apply_injury(self):
        """Randomly apply an injury based on fatigue and fitness."""
        if self.personal.is_injured():
            return
        fitness_penalty = (100 - self.attributes.fitness) / 100
        fatigue_penalty = self.personal.fatigue / 200
        p = fitness_penalty * 0.3 + fatigue_penalty * 0.2
        if chance(p):
            self.personal.injury       = random.choice(INJURIES)
            self.personal.injury_weeks = random.randint(2, 12)
            log.info(f"{self.name} injured: {self.personal.injury} ({self.personal.injury_weeks}w)")

    # ── Serialisation ─────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id":            self.id,
            "name":          self.name,
            "nationality":   self.nationality,
            "role":          self.role,
            "batting_style": self.batting_style,
            "bowling_style": self.bowling_style,
            "dob":           self.dob,
            "attributes":    self.attributes.as_dict(),
            "personal":      self.personal.as_dict(),
            "stats":         self.stats.as_dict(),
            "team_id":       self.team_id,
            "nft_token_id":  self.nft_token_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Player":
        p = cls(
            name          = d["name"],
            nationality   = d.get("nationality", "England"),
            role          = d.get("role", "batsman"),
            batting_style = d.get("batting_style", "right-hand"),
            bowling_style = d.get("bowling_style", "right-arm medium"),
            dob           = d.get("dob", "1998-01-01"),
            attributes    = PlayerAttributes.from_dict(d.get("attributes", {})),
            personal      = PersonalProfile.from_dict(d.get("personal", {})),
            stats         = CareerStats.from_dict(d.get("stats", {})),
        )
        p.id           = d.get("id", p.id)
        p.team_id      = d.get("team_id")
        p.nft_token_id = d.get("nft_token_id")
        return p

    def __repr__(self):
        return f"<Player {self.name} [{self.nationality}] {self.role} OVR={self.overall_rating}>"


# ── Player factory ────────────────────────────────────────────────────────────
def generate_player(
    name: str | None = None,
    nationality: str | None = None,
    role: str | None = None,
    tier: str = "normal",     # youth / normal / elite / legend
) -> Player:
    """Generate a randomised player with appropriate attributes for their tier."""
    nationality = nationality or random.choice(NATIONALITIES)
    role        = role or weighted_choice(ROLES, [35, 35, 20, 10])

    if role == "bowler":
        bowl_style = random.choice(BOWL_STYLES)
    else:
        bowl_style = random.choice(BOWL_STYLES[:4])

    # Tier → base attribute range
    tier_ranges = {
        "youth":  (30, 58),
        "normal": (45, 72),
        "elite":  (65, 88),
        "legend": (80, 98),
    }
    lo, hi = tier_ranges.get(tier, (45, 72))

    def rand_attr() -> float:
        return round(random.uniform(lo, hi), 1)

    attrs = PlayerAttributes(
        batting=BattingAttributes(
            technique=rand_attr(), power=rand_attr(), timing=rand_attr(),
            footwork=rand_attr(), concentration=rand_attr(), temperament=rand_attr(),
            against_pace=rand_attr(), against_spin=rand_attr(),
        ),
        bowling=BowlingAttributes(
            pace=rand_attr(), accuracy=rand_attr(), movement=rand_attr(),
            turn=rand_attr(), variations=rand_attr(), yorker=rand_attr(),
            death_bowling=rand_attr(),
        ),
        fielding=FieldingAttributes(
            catching=rand_attr(), throwing=rand_attr(), ground=rand_attr(),
            keeping=rand_attr() if role == "wicketkeeper" else 20.0,
        ),
        fitness=random.uniform(70, 95),
        potential=random.uniform(hi - 5, min(hi + 15, 100)),
    )

    age = random.randint(18, 34) if tier != "youth" else random.randint(16, 21)
    personal = PersonalProfile(
        age=age,
        morale=random.uniform(60, 90),
        confidence=random.uniform(50, 90),
        reputation=random.uniform(lo * 0.6, hi * 0.8),
        motivation=random.choice(MOTIVATIONS),
        personality=random.choice(["aggressive", "defensive", "balanced", "mercurial"]),
    )

    if not name:
        name = _random_name(nationality)

    p = Player(
        name=name, nationality=nationality, role=role,
        batting_style=random.choice(BAT_STYLES),
        bowling_style=bowl_style,
        dob=f"{2024 - age}-{random.randint(1,12):02d}-{random.randint(1,28):02d}",
        attributes=attrs, personal=personal,
    )
    return p


def _random_name(nationality: str) -> str:
    """Generate a plausible name for a nationality."""
    pools: dict[str, tuple[list, list]] = {
        "England":     (["James","Oliver","Harry","George","Charlie","Jack","Tom","Joe","Sam","Liam"],
                        ["Anderson","Broad","Root","Stokes","Archer","Wood","Woakes","Ali","Bairstow","Burns"]),
        "Australia":   (["David","Steve","Pat","Mitchell","Travis","Josh","Cameron","Marcus","Usman","Matthew"],
                        ["Warner","Smith","Cummins","Starc","Head","Hazlewood","Green","Stoinis","Khawaja","Wade"]),
        "India":       (["Rohit","Virat","Shubman","KL","Rishabh","Hardik","Ravindra","Jasprit","Mohammed","Suryakumar"],
                        ["Sharma","Kohli","Gill","Rahul","Pant","Pandya","Jadeja","Bumrah","Shami","Yadav"]),
        "Pakistan":    (["Babar","Shaheen","Mohammad","Naseem","Shadab","Imam","Fakhar","Hasan","Iftikhar","Sarfaraz"],
                        ["Azam","Afridi","Rizwan","Shah","Khan","Ul-Haq","Zaman","Ali","Ahmed","Nawaz"]),
        "West Indies": (["Shai","Shimron","Jason","Kyle","Alzarri","Kemar","Roston","Kraigg","Shamarh","Andre"],
                        ["Hope","Hetmyer","Holder","Mayers","Joseph","Roach","Chase","Brathwaite","Brooks","Russell"]),
        "South Africa":([  "Quinton","Temba","Kagiso","Anrich","Aiden","Dean","Marco","Keshav","Lungi","Rassie"],
                        ["de Kock","Bavuma","Rabada","Nortje","Markram","Elgar","Jansen","Maharaj","Ngidi","van der Dussen"]),
    }
    default = (["Alex","Ben","Chris","Dan","Ed","Frank","Gary","Henry","Ian","Jake"],
               ["Smith","Jones","Brown","Taylor","Wilson","Evans","Davies","Thomas","Roberts","Walker"])
    firsts, lasts = pools.get(nationality, default)
    return f"{random.choice(firsts)} {random.choice(lasts)}"


# ── Team model ────────────────────────────────────────────────────────────────
class Team:
    def __init__(
        self,
        name: str,
        short_name: str,
        country: str,
        team_type: str = "international",
        home_ground: str = "TBA",
    ):
        self.id         = make_id("tm")
        self.name       = name
        self.short_name = short_name
        self.country    = country
        self.team_type  = team_type
        self.home_ground = home_ground
        self.squad: list[Player] = []
        self.finances = {
            "budget":       5_000_000,
            "revenue":      2_000_000,
            "wages":        1_500_000,
            "prize_money":  0,
            "sponsorships": 500_000,
        }
        self.morale:    float = 70.0
        self.coach_rating: float = 60.0

    def add_player(self, p: Player):
        p.team_id = self.id
        self.squad.append(p)

    def remove_player(self, player_id: str) -> Optional[Player]:
        for i, p in enumerate(self.squad):
            if p.id == player_id:
                removed = self.squad.pop(i)
                removed.team_id = None
                return removed
        return None

    def best_xi(self) -> list[Player]:
        available = [p for p in self.squad if p.is_available()]
        return sorted(available, key=lambda p: p.overall_rating, reverse=True)[:11]

    def update_finances(self, revenue_delta: int = 0, wage_delta: int = 0):
        self.finances["revenue"]   += revenue_delta
        self.finances["wages"]     += wage_delta
        self.finances["budget"]     = (self.finances["revenue"]
                                       + self.finances["sponsorships"]
                                       + self.finances["prize_money"]
                                       - self.finances["wages"])

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "name":        self.name,
            "short_name":  self.short_name,
            "country":     self.country,
            "team_type":   self.team_type,
            "home_ground": self.home_ground,
            "squad":       [p.to_dict() for p in self.squad],
            "finances":    self.finances,
            "morale":      self.morale,
            "coach_rating": self.coach_rating,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Team":
        t = cls(
            name=d["name"], short_name=d.get("short_name", d["name"][:3].upper()),
            country=d.get("country", "England"), team_type=d.get("team_type", "international"),
            home_ground=d.get("home_ground", "TBA"),
        )
        t.id       = d.get("id", t.id)
        t.finances = d.get("finances", t.finances)
        t.morale   = d.get("morale", 70.0)
        t.squad    = [Player.from_dict(pd) for pd in d.get("squad", [])]
        return t

    def __repr__(self):
        return f"<Team {self.name} [{self.team_type}] {len(self.squad)} players>"


# ── Youth Academy ─────────────────────────────────────────────────────────────
class YouthAcademy:
    def __init__(self, team: Team):
        self.team    = team
        self.prospects: list[Player] = []
        self._generate_intake()

    def _generate_intake(self, n: int = 6):
        for _ in range(n):
            p = generate_player(nationality=self.team.country, tier="youth")
            self.prospects.append(p)

    def promote(self, player_id: str) -> Optional[Player]:
        for i, p in enumerate(self.prospects):
            if p.id == player_id:
                promoted = self.prospects.pop(i)
                self.team.add_player(promoted)
                log.info(f"Promoted {promoted.name} from youth academy to {self.team.name}")
                return promoted
        return None

    def season_progress(self):
        """Develop all prospects and refresh intake."""
        for p in self.prospects:
            p.develop()
        # Replace graduated prospects
        while len(self.prospects) < 3:
            self.prospects.append(generate_player(nationality=self.team.country, tier="youth"))

    def __repr__(self):
        return f"<YouthAcademy {self.team.name}: {len(self.prospects)} prospects>"


# ── Career Manager ────────────────────────────────────────────────────────────
class CareerManager:
    """Top-level orchestrator for career simulation."""

    def __init__(self, managed_team: Team):
        self.team    = managed_team
        self.academy = YouthAcademy(managed_team)
        self.season  = cfg("game.season_start_year", 2024)
        self.history: list[dict] = []

    def simulate_off_season(self):
        """Run end-of-season progression for all players."""
        log.info(f"Off-season processing for {self.team.name} ({self.season})")
        for player in self.team.squad:
            perf = self._derive_perf_bonus(player)
            player.develop(perf)
            player.apply_injury()
            player.personal.rest(weeks=12)
            save_player(player)

        self.academy.season_progress()
        self.season += 1
        log.info(f"Season advanced to {self.season}")

    def _derive_perf_bonus(self, player: Player) -> dict:
        """Calculate performance bonus for development based on last season stats."""
        stats = player.stats
        bonus = 0.0
        if player.role in ("batsman", "allrounder", "wicketkeeper"):
            if stats.average > 50:
                bonus += 0.15
            elif stats.average > 35:
                bonus += 0.08
        if player.role in ("bowler", "allrounder"):
            if stats.wickets > 40:
                bonus += 0.15
            elif stats.wickets > 20:
                bonus += 0.08
        # Consistency bonus
        if stats.matches > 10:
            bonus += 0.05
        return {"bonus": bonus}

    def scout_free_agents(self, n: int = 5) -> list[Player]:
        return [generate_player(nationality=random.choice(NATIONALITIES)) for _ in range(n)]

    def sign_player(self, player: Player):
        self.team.add_player(player)
        save_player(player)
        log.info(f"Signed {player.name} to {self.team.name}")

    def release_player(self, player_id: str) -> Optional[Player]:
        p = self.team.remove_player(player_id)
        if p:
            log.info(f"Released {p.name} from {self.team.name}")
        return p

    def season_summary(self) -> dict:
        best_bat  = max(self.team.squad, key=lambda p: p.stats.runs, default=None)
        best_bowl = max(self.team.squad, key=lambda p: p.stats.wickets, default=None)
        return {
            "season":     self.season - 1,
            "team":       self.team.name,
            "squad_size": len(self.team.squad),
            "best_bat":   best_bat.name if best_bat else "-",
            "best_bowl":  best_bowl.name if best_bowl else "-",
            "finances":   self.team.finances.copy(),
        }
