"""events.py — Hidden dynamic events, sidequests, pitch/weather modifiers"""

from __future__ import annotations
import random
from dataclasses import dataclass, field
from typing import Callable, Optional
from .utils import make_id, chance, weighted_choice, get_logger, cfg

log = get_logger("events")


# ── Weather system ─────────────────────────────────────────────────────────────
WEATHER_TYPES = ["sunny", "overcast", "light_cloud", "rain", "drizzle", "fog", "windy", "humid"]

WEATHER_TRANSITIONS = {
    "sunny":       [("sunny", 0.5), ("light_cloud", 0.3), ("overcast", 0.1), ("windy", 0.1)],
    "light_cloud": [("sunny", 0.3), ("light_cloud", 0.3), ("overcast", 0.2), ("drizzle", 0.2)],
    "overcast":    [("overcast", 0.35), ("rain", 0.25), ("drizzle", 0.2), ("light_cloud", 0.2)],
    "rain":        [("rain", 0.45), ("drizzle", 0.25), ("overcast", 0.3)],
    "drizzle":     [("drizzle", 0.3), ("rain", 0.2), ("overcast", 0.3), ("light_cloud", 0.2)],
    "fog":         [("fog", 0.4), ("overcast", 0.4), ("sunny", 0.2)],
    "windy":       [("windy", 0.35), ("sunny", 0.3), ("overcast", 0.2), ("light_cloud", 0.15)],
    "humid":       [("humid", 0.4), ("overcast", 0.3), ("rain", 0.3)],
}


@dataclass
class WeatherState:
    current:          str   = "sunny"
    temperature_c:    float = 20.0
    wind_speed_kmh:   float = 10.0
    humidity_pct:     float = 50.0
    visibility:       str   = "clear"   # clear/hazy/poor
    play_possible:    bool  = True

    def advance(self):
        transitions = WEATHER_TRANSITIONS.get(self.current, [("sunny", 1.0)])
        types, weights = zip(*transitions)
        self.current = random.choices(list(types), weights=list(weights), k=1)[0]
        self._update_derived()

    def _update_derived(self):
        if self.current in ("rain", "drizzle"):
            self.play_possible = self.current != "rain" or chance(0.25)
        else:
            self.play_possible = True
        self.humidity_pct   = {"sunny": 35, "overcast": 65, "rain": 90,
                                "humid": 80, "fog": 85, "windy": 40,
                                "light_cloud": 50, "drizzle": 75}.get(self.current, 55)
        self.wind_speed_kmh = random.uniform(5, 35) if self.current == "windy" else random.uniform(0, 15)

    # ── Effects on play ───────────────────────────────────────────────────────
    def swing_modifier(self) -> float:
        """Overcast + humid = more swing."""
        base = 1.0
        if self.current in ("overcast", "drizzle"):
            base += 0.30
        if self.humidity_pct > 70:
            base += 0.15
        if self.wind_speed_kmh > 20:
            base += 0.10
        return base

    def spin_modifier(self) -> float:
        """Dry/hot = more spin."""
        if self.current == "sunny" and self.humidity_pct < 40:
            return 1.20
        return 1.0

    def batting_modifier(self) -> float:
        if self.current in ("rain", "fog"):
            return 0.80
        if self.current == "windy":
            return 0.90
        if self.current == "sunny":
            return 1.05
        return 1.0

    def as_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> "WeatherState":
        w = cls()
        for k, v in d.items():
            if hasattr(w, k):
                setattr(w, k, v)
        return w


# ── Pitch system ──────────────────────────────────────────────────────────────
PITCH_TYPES = ["flat", "seaming", "spinning", "bouncy", "dead", "green_top", "crumbling"]

@dataclass
class PitchState:
    pitch_type:   str   = "flat"
    day:          int   = 1           # Day of the Test match (1-5)
    hardness:     float = 8.0         # 0=dust 10=rock
    grass_cover:  float = 0.2         # 0–1
    cracks:       float = 0.0         # 0–1 (more = more spin)
    moisture:     float = 0.3         # 0–1

    def advance_day(self, weather: WeatherState):
        self.day += 1
        # Drying out
        if weather.current == "sunny":
            self.moisture  = max(0, self.moisture - 0.12)
            self.hardness  = max(3, self.hardness - 0.5)
            self.cracks   += 0.08
        elif weather.current in ("rain", "drizzle"):
            self.moisture  = min(1, self.moisture + 0.20)
            self.hardness  = min(10, self.hardness + 0.3)
        self.grass_cover = max(0, self.grass_cover - 0.05)

    def seam_modifier(self) -> float:
        base = 1.0
        if self.pitch_type == "green_top":
            base += 0.40
        if self.pitch_type == "seaming":
            base += 0.25
        if self.grass_cover > 0.3:
            base += 0.20
        if self.moisture > 0.5:
            base += 0.15
        return base

    def spin_modifier(self) -> float:
        base = 1.0
        if self.pitch_type == "spinning":
            base += 0.40
        if self.pitch_type == "crumbling":
            base += 0.30
        if self.day >= 4:
            base += 0.25
        base += self.cracks * 0.50
        return base

    def batting_modifier(self) -> float:
        if self.pitch_type == "flat":
            return 1.25
        if self.pitch_type == "dead":
            return 1.15
        if self.pitch_type in ("seaming", "green_top", "crumbling"):
            return 0.80
        return 1.0

    def as_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> "PitchState":
        p = cls()
        for k, v in d.items():
            if hasattr(p, k):
                setattr(p, k, v)
        return p


def random_pitch(venue: str | None = None) -> PitchState:
    p = PitchState(
        pitch_type  = random.choice(PITCH_TYPES),
        hardness    = random.uniform(5, 10),
        grass_cover = random.uniform(0.05, 0.50),
        cracks      = random.uniform(0.0, 0.1),
        moisture    = random.uniform(0.1, 0.5),
    )
    # Venue biases
    if venue:
        v = venue.lower()
        if any(x in v for x in ["lord's", "headingley", "edgbaston"]):
            p.pitch_type  = random.choice(["seaming", "green_top", "flat"])
            p.grass_cover = random.uniform(0.3, 0.55)
        elif any(x in v for x in ["subcontinent", "chennai", "spin", "pune"]):
            p.pitch_type = random.choice(["spinning", "crumbling", "flat"])
            p.cracks     = random.uniform(0.1, 0.4)
    return p


# ── Sidequest / narrative events ───────────────────────────────────────────────
@dataclass
class GameEvent:
    id:          str
    event_type:  str
    title:       str
    description: str
    choices:     list[dict] = field(default_factory=list)   # [{label, impact}]
    auto_resolve: bool = False
    impact:      dict = field(default_factory=dict)
    related_id:  str  = ""

    def resolve(self, choice_index: int = 0) -> dict:
        if self.choices and choice_index < len(self.choices):
            return self.choices[choice_index].get("impact", {})
        return self.impact


# ── Event generator ────────────────────────────────────────────────────────────
EVENT_TEMPLATES: list[dict] = [
    {
        "type": "player_personal",
        "templates": [
            ("{name}'s Father Passes Away",
             "{name} has had a tragic bereavement. His form may be affected.",
             [{"label": "Give compassionate leave", "impact": {"morale": -15, "fatigue": -10}},
              {"label": "Request he plays on",      "impact": {"morale": -25, "team_morale": +5}}]),
            ("{name} Offered Contract by Rival",
             "A Premier League side has approached {name} for an ambassadorial role.",
             [{"label": "Endorse the move",    "impact": {"morale": +10, "reputation": +5}},
              {"label": "Block negotiation",  "impact": {"morale": -10, "budget": +200000}}]),
            ("{name} Celebrates Record Milestone",
             "{name} just reached a landmark career milestone.",
             [{"label": "Host gala dinner", "impact": {"morale": +20, "team_morale": +10, "budget": -50000}},
              {"label": "Simple announcement", "impact": {"morale": +10, "reputation": +8}}]),
        ]
    },
    {
        "type": "pitch_sidequest",
        "templates": [
            ("Groundsman's Secret Offer",
             "The groundsman offers to over-water the pitch — favoring your seam attack.",
             [{"label": "Accept the offer",    "impact": {"pitch_moisture": +0.25, "risk": "ban_3_matches"}},
              {"label": "Decline honourably",  "impact": {"reputation": +5}}]),
            ("Pitch Covering Malfunction",
             "The rain covers failed overnight. The pitch is wetter than expected.",
             [{"label": "Appeal for re-preparation", "impact": {"pitch_moisture": -0.1}},
              {"label": "Play on",                   "impact": {"swing_bonus": 0.2}}]),
        ]
    },
    {
        "type": "media",
        "templates": [
            ("Tabloid Scandal: {name}",
             "A tabloid has published a controversial story about {name}.",
             [{"label": "Issue full denial",     "impact": {"morale": -5, "reputation": -10}},
              {"label": "Admit minor indiscretion", "impact": {"morale": -15, "reputation": -5}},
              {"label": "No comment",             "impact": {"reputation": -8}}]),
            ("Documentary Film Offer",
             "A streaming platform wants to film your dressing room all season.",
             [{"label": "Accept (morale risk)", "impact": {"budget": +500000, "team_morale": -5}},
              {"label": "Decline",              "impact": {}}]),
        ]
    },
    {
        "type": "injury_crisis",
        "templates": [
            ("Fitness Crisis Before The Ashes",
             "Three key players have reported unfit ahead of the first Test.",
             [{"label": "Rush them back",   "impact": {"injury_weeks": -2, "re_injury_risk": 0.5}},
              {"label": "Pick replacements", "impact": {"team_rating": -10}}]),
        ]
    },
    {
        "type": "fan_unrest",
        "templates": [
            ("Fans Demand Change",
             "After a poor run of form, fans are calling for the manager's head.",
             [{"label": "Address the press",  "impact": {"reputation": +5, "media_pressure": -10}},
              {"label": "Hunker down",        "impact": {"media_pressure": +15}}]),
        ]
    },
    {
        "type": "transfer_rumour",
        "templates": [
            ("{name} Linked to IPL Franchise",
             "Reports link {name} to a lucrative IPL deal.",
             [{"label": "Offer pay rise",     "impact": {"budget": -300000, "player_loyalty": +20}},
              {"label": "Accept departure",   "impact": {"player_loyalty": -999, "transfer_fee": 1000000}},
              {"label": "Deny all rumours",   "impact": {"media_pressure": +10}}]),
        ]
    },
]


class EventEngine:
    def __init__(self):
        self.pending: list[GameEvent] = []
        self.resolved: list[GameEvent] = []

    def generate_match_events(
        self,
        players: list,
        weather: WeatherState,
        pitch: PitchState,
        season: int,
    ) -> list[GameEvent]:
        events: list[GameEvent] = []

        # Injury crisis event
        if chance(0.08):
            events.append(self._build_event("injury_crisis"))

        # Pitch sidequest
        if pitch.pitch_type in ("flat", "dead") and chance(0.12):
            events.append(self._build_event("pitch_sidequest"))

        # Weather drama
        if weather.current in ("rain", "fog") and chance(0.25):
            events.append(GameEvent(
                id=make_id("ev"), event_type="weather_drama",
                title="Play Suspended – Rain Delay",
                description=f"Rain has halted play. Current weather: {weather.current}.",
                auto_resolve=True,
                impact={"overs_lost": random.randint(5, 30)},
            ))

        # Player personal
        if players and chance(0.10):
            p = random.choice(players)
            ev = self._build_event("player_personal", name=p.name if hasattr(p, "name") else "The player")
            ev.related_id = getattr(p, "id", "")
            events.append(ev)

        for ev in events:
            self.pending.append(ev)
        return events

    def generate_season_events(self, players: list, team) -> list[GameEvent]:
        events: list[GameEvent] = []
        if players:
            p = random.choice(players)
            pname = getattr(p, "name", "A player")
            events.append(self._build_event("transfer_rumour", name=pname))
        if chance(0.15):
            events.append(self._build_event("media", name="The team"))
        if chance(0.10):
            events.append(self._build_event("fan_unrest", name="The manager"))
        for ev in events:
            self.pending.append(ev)
        return events

    def _build_event(self, event_type: str, **kwargs) -> GameEvent:
        for group in EVENT_TEMPLATES:
            if group["type"] == event_type:
                tmpl_title, tmpl_desc, choices = random.choice(group["templates"])
                title = tmpl_title.format(**kwargs)
                desc  = tmpl_desc.format(**kwargs)
                return GameEvent(
                    id=make_id("ev"), event_type=event_type,
                    title=title, description=desc, choices=choices,
                )
        return GameEvent(id=make_id("ev"), event_type=event_type,
                         title="Unknown Event", description="Something happened.", auto_resolve=True)

    def resolve_event(self, event_id: str, choice_index: int = 0) -> dict:
        for ev in self.pending:
            if ev.id == event_id:
                impact = ev.resolve(choice_index)
                self.pending.remove(ev)
                self.resolved.append(ev)
                log.info(f"Resolved event '{ev.title}' choice={choice_index} impact={impact}")
                return impact
        return {}

    def auto_resolve_all(self) -> list[dict]:
        impacts = []
        for ev in list(self.pending):
            if ev.auto_resolve:
                impacts.append(ev.resolve(0))
                self.pending.remove(ev)
                self.resolved.append(ev)
        return impacts
