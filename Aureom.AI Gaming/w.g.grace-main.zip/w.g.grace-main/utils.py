"""utils.py — Logging, configuration, and shared utilities for W.G.Grace-1"""

import logging
import json
import os
import random
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Any

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
DATA_DIR   = BASE_DIR / "data"
DB_PATH    = BASE_DIR / "wg_grace.db"
LOG_PATH   = BASE_DIR / "wg_grace.log"
MODS_DIR   = BASE_DIR / "mods"

for _d in (DATA_DIR, MODS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOG_PATH),
    ],
)

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


# ── Config ────────────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "game": {
        "season_start_year": 2024,
        "max_seasons": 30,
        "difficulty": "normal",          # easy / normal / hard / legendary
        "ai_aggression": 0.5,
        "random_events_enabled": True,
        "weather_system": True,
        "pitch_dynamics": True,
    },
    "blockchain": {
        "enabled": False,
        "network": "testnet",
        "lnd_host": "localhost",
        "lnd_port": 10009,
        "nft_mint_fee_sats": 1000,
    },
    "ui": {
        "theme": "anglo_futurist",
        "font_scale": 1.0,
        "animations": True,
        "dashboard_refresh_ms": 2000,
    },
    "multiplayer": {
        "enabled": False,
        "server_host": "localhost",
        "server_port": 9999,
    },
}

_config: dict[str, Any] = {}

def load_config(path: str | None = None) -> dict[str, Any]:
    global _config
    cfg_file = Path(path) if path else BASE_DIR / "config.json"
    if cfg_file.exists():
        with open(cfg_file) as f:
            loaded = json.load(f)
        _config = _deep_merge(DEFAULT_CONFIG, loaded)
    else:
        _config = DEFAULT_CONFIG.copy()
        save_config(cfg_file)
    return _config

def save_config(path: Path | None = None):
    cfg_file = path or BASE_DIR / "config.json"
    with open(cfg_file, "w") as f:
        json.dump(_config or DEFAULT_CONFIG, f, indent=2)

def get_config() -> dict[str, Any]:
    if not _config:
        load_config()
    return _config

def cfg(key_path: str, default: Any = None) -> Any:
    """Dot-separated config access: cfg('game.difficulty')"""
    parts = key_path.split(".")
    node = get_config()
    for p in parts:
        if isinstance(node, dict):
            node = node.get(p, default)
        else:
            return default
    return node

def _deep_merge(base: dict, override: dict) -> dict:
    result = base.copy()
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


# ── Dice / RNG helpers ────────────────────────────────────────────────────────
def roll(sides: int = 100) -> int:
    """Roll a die from 1..sides."""
    return random.randint(1, sides)

def chance(probability: float) -> bool:
    """Return True with the given probability (0–1)."""
    return random.random() < probability

def weighted_choice(items: list, weights: list):
    return random.choices(items, weights=weights, k=1)[0]

def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))

def normalise(value: float, lo: float, hi: float) -> float:
    """Map value to 0–1 range."""
    span = hi - lo
    if span == 0:
        return 0.5
    return clamp((value - lo) / span, 0.0, 1.0)


# ── ID generation ─────────────────────────────────────────────────────────────
def make_id(prefix: str = "obj") -> str:
    h = hashlib.sha1(str(random.random()).encode()).hexdigest()[:8]
    return f"{prefix}_{h}"


# ── Date helpers ──────────────────────────────────────────────────────────────
def current_season() -> int:
    return get_config().get("game", {}).get("season_start_year", 2024)

def format_date(year: int, month: int, day: int) -> str:
    try:
        return datetime(year, month, day).strftime("%d %b %Y")
    except ValueError:
        return f"{day:02d}/{month:02d}/{year}"


# ── Serialisation helpers ─────────────────────────────────────────────────────
def to_dict(obj) -> dict:
    if hasattr(obj, "__dict__"):
        return {k: v for k, v in obj.__dict__.items() if not k.startswith("_")}
    return {}

def load_json(path: str | Path) -> Any:
    with open(path) as f:
        return json.load(f)

def save_json(data: Any, path: str | Path):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# ── Mod support ───────────────────────────────────────────────────────────────
def list_mods() -> list[str]:
    return [p.name for p in MODS_DIR.iterdir() if p.is_dir()]

def load_mod_data(mod_name: str, filename: str) -> Any | None:
    path = MODS_DIR / mod_name / filename
    if path.exists():
        return load_json(path)
    return None


logger = get_logger("utils")
logger.info("W.G.Grace-1 utilities initialised.")
