"""W.G.Grace-1: Anglo-Futurist Cricket Management & Simulation"""
__version__ = "1.0.0"
__author__ = "W.G.Grace-1 Project"
