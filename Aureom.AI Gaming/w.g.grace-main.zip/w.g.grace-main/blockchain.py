"""blockchain.py — Bitcoin/Lightning Network integration for NFT trading"""

from __future__ import annotations
import time
import hashlib
import random
from typing import Optional
from .utils import make_id, get_logger, cfg

log = get_logger("blockchain")


# ── Lightning invoice simulation ───────────────────────────────────────────────
def create_lightning_invoice(
    amount_sats: int,
    memo: str = "W.G.Grace-1 NFT payment",
    expiry_seconds: int = 3600,
) -> dict:
    """Generate a mock Lightning invoice (replace with real LND/CLN call)."""
    if not cfg("blockchain.enabled", False):
        # Demo mode — return a mock invoice
        h = hashlib.sha256(f"{amount_sats}{memo}{time.time()}".encode()).hexdigest()
        return {
            "payment_request": f"lnbc{amount_sats}n1{h[:40]}",
            "payment_hash":    h,
            "amount_sats":     amount_sats,
            "memo":            memo,
            "expiry":          int(time.time()) + expiry_seconds,
            "status":          "open",
            "demo_mode":       True,
        }

    # Production — call your LND/CLN REST API here
    try:
        import httpx
        host    = cfg("blockchain.lnd_host", "localhost")
        port    = cfg("blockchain.lnd_port", 10009)
        r = httpx.post(
            f"https://{host}:{port}/v1/invoices",
            json={"value": amount_sats, "memo": memo, "expiry": expiry_seconds},
            verify=False, timeout=10.0,
        )
        r.raise_for_status()
        data = r.json()
        return {"payment_request": data["payment_request"], "payment_hash": data["r_hash"],
                "amount_sats": amount_sats, "memo": memo, "status": "open", "demo_mode": False}
    except Exception as e:
        log.error(f"Lightning invoice creation failed: {e}")
        return {"error": str(e)}


def check_invoice_paid(payment_hash: str) -> bool:
    """Check if a Lightning invoice has been paid."""
    if cfg("blockchain.enabled", False) is False:
        # Demo: simulate random payment after delay
        return random.random() > 0.3   # 70% chance "paid" in demo
    # Production: query LND/CLN
    return False


# ── Bitcoin address generation (mock) ─────────────────────────────────────────
def generate_wallet_address(seed: str = "") -> str:
    """Return a mock bech32 Bitcoin testnet address."""
    h = hashlib.sha256((seed or str(time.time())).encode()).hexdigest()[:34]
    return f"tb1q{h}"


# ── On-chain transaction (mock) ────────────────────────────────────────────────
def broadcast_transaction(tx_hex: str) -> dict:
    if not cfg("blockchain.enabled", False):
        txid = hashlib.sha256(tx_hex.encode()).hexdigest()
        log.info(f"[DEMO] Broadcast tx: {txid}")
        return {"txid": txid, "status": "accepted", "demo": True}
    # Real broadcast via Bitcoin RPC
    return {"error": "Production broadcast not implemented"}


# ── Payment flow for NFT trade ────────────────────────────────────────────────
class NFTPaymentSession:
    def __init__(self, token_id: str, ask_sats: int, seller_address: str):
        self.session_id    = make_id("pay")
        self.token_id      = token_id
        self.ask_sats      = ask_sats
        self.seller_address = seller_address
        self.invoice       = create_lightning_invoice(ask_sats, memo=f"NFT {token_id}")
        self.status        = "awaiting_payment"
        self.buyer_address: Optional[str] = None

    def poll_payment(self) -> bool:
        if self.status == "paid":
            return True
        ph = self.invoice.get("payment_hash", "")
        if check_invoice_paid(ph):
            self.status        = "paid"
            self.buyer_address = generate_wallet_address(self.session_id)
            log.info(f"Payment confirmed for NFT {self.token_id}: {self.ask_sats} sats")
            return True
        return False

    def as_dict(self) -> dict:
        return {
            "session_id":    self.session_id,
            "token_id":      self.token_id,
            "ask_sats":      self.ask_sats,
            "invoice":       self.invoice.get("payment_request", ""),
            "status":        self.status,
            "buyer_address": self.buyer_address,
        }
