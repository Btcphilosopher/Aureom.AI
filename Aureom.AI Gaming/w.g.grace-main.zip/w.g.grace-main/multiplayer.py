"""multiplayer.py — Leagues, tournaments, inter-team competition, NFT squads"""

from __future__ import annotations
import random
from typing import Optional
from .utils import make_id, get_logger, chance
from .career import Team, Player, generate_player, NATIONALITIES
from .match_sim import MatchEngine
from .analytics import Standings

log = get_logger("multiplayer")


# ── Tournament formats ────────────────────────────────────────────────────────
class Tournament:
    """Generic tournament: round-robin + knockout."""

    def __init__(
        self,
        name: str,
        teams: list[Team],
        match_type: str = "odi",
        format: str = "round_robin",   # round_robin / knockout / group+knockout
        venue: str = "International",
    ):
        self.id         = make_id("tour")
        self.name       = name
        self.teams      = teams
        self.match_type = match_type
        self.format     = format
        self.venue      = venue
        self.matches:   list[dict] = []
        self.standings  = Standings()
        self.engine     = MatchEngine()

        for t in teams:
            self.standings.add_team(t.id, t.name)

    def generate_fixtures(self) -> list[tuple[Team, Team]]:
        """Return list of (home, away) fixture pairs."""
        fixtures = []
        teams = self.teams[:]
        if self.format == "round_robin":
            for i, home in enumerate(teams):
                for away in teams[i+1:]:
                    fixtures.append((home, away))
        elif self.format == "knockout":
            random.shuffle(teams)
            for i in range(0, len(teams) - 1, 2):
                fixtures.append((teams[i], teams[i+1]))
        return fixtures

    def play_all(self, verbose: bool = False) -> dict:
        fixtures = self.generate_fixtures()
        results  = []
        for home, away in fixtures:
            result = self.engine.simulate_match(home, away, self.match_type, self.venue)
            self.matches.append(result)

            home_innings = next((i for i in result["innings"] if i["team_id"] == home.id), {})
            away_innings = next((i for i in result["innings"] if i["team_id"] == away.id), {})

            self.standings.record_result(
                home.id, away.id, result["result"],
                home_innings.get("runs", 0), home_innings.get("overs", 0),
                away_innings.get("runs", 0), away_innings.get("overs", 0),
            )
            if verbose:
                r = result["result"]
                log.info(f"  {home.name} v {away.name} → {r.get('winner')} ({r.get('margin')})")
            results.append(result)
        return {"fixtures_played": len(results), "standings": self.standings.as_list()}

    def champion(self) -> Optional[Team]:
        table = self.standings.sorted_table()
        if not table:
            return None
        top_name = table[0]["name"]
        return next((t for t in self.teams if t.name == top_name), None)

    def summary(self) -> dict:
        champ = self.champion()
        return {
            "tournament": self.name,
            "teams":      len(self.teams),
            "matches":    len(self.matches),
            "champion":   champ.name if champ else "TBD",
            "standings":  self.standings.as_list(),
        }


# ── International calendar ────────────────────────────────────────────────────
class InternationalCalendar:
    """Schedule for a full season of international cricket."""

    SERIES = [
        ("The Ashes",        "England",   "Australia",   "test",  5, "England"),
        ("ICC World Cup",    None,        None,          "odi",   43, "Multiple"),
        ("T20 World Cup",    None,        None,          "t20",   45, "Multiple"),
        ("India Tour of England", "India", "England",    "test",  3, "England"),
        ("West Indies T20 Series", "West Indies", "England", "t20", 5, "West Indies"),
    ]

    def __init__(self, teams: dict[str, Team]):
        self.teams  = teams   # name → Team
        self.season_tournaments: list[Tournament] = []

    def build_season(self, year: int) -> list[Tournament]:
        self.season_tournaments = []

        for name, home_n, away_n, mtype, num_matches, venue in self.SERIES:
            available = list(self.teams.values())
            if home_n and home_n in self.teams:
                home = self.teams[home_n]
            else:
                home = random.choice(available)
            if away_n and away_n in self.teams:
                away = self.teams[away_n]
            else:
                away = random.choice([t for t in available if t != home])

            # For big tournaments use multiple teams
            if num_matches > 10:
                participant_teams = random.sample(available, min(8, len(available)))
            else:
                participant_teams = [home, away]

            tour = Tournament(name=f"{name} {year}", teams=participant_teams,
                              match_type=mtype, venue=venue)
            self.season_tournaments.append(tour)

        return self.season_tournaments

    def play_season(self, verbose: bool = False) -> dict:
        results = {}
        for tour in self.season_tournaments:
            log.info(f"Playing: {tour.name}")
            results[tour.name] = tour.play_all(verbose=verbose)
        return results


# ── NFT Best-XI multiplayer squad ─────────────────────────────────────────────
class NFTSquad:
    """A multiplayer squad assembled from owned NFT players."""

    def __init__(self, owner: str):
        self.id      = make_id("nftsq")
        self.owner   = owner
        self.players: list[Player] = []   # owned NFT players
        self.max_size = 15

    def add_player(self, player: Player) -> bool:
        if len(self.players) >= self.max_size:
            return False
        self.players.append(player)
        return True

    def remove_player(self, player_id: str) -> Optional[Player]:
        for i, p in enumerate(self.players):
            if p.id == player_id:
                return self.players.pop(i)
        return None

    def best_xi(self) -> list[Player]:
        return sorted(self.players, key=lambda p: p.overall_rating, reverse=True)[:11]

    def to_team(self) -> Team:
        """Convert NFT squad to a Team object for match simulation."""
        t = Team(
            name=f"{self.owner}'s XI",
            short_name=self.owner[:3].upper(),
            country="International",
            team_type="nft_squad",
        )
        for p in self.best_xi():
            t.add_player(p)
        return t

    def squad_rating(self) -> float:
        xi = self.best_xi()
        return round(sum(p.overall_rating for p in xi) / max(len(xi), 1), 1) if xi else 0.0

    def summary(self) -> dict:
        return {
            "owner":        self.owner,
            "squad_size":   len(self.players),
            "squad_rating": self.squad_rating(),
            "players":      [{"name": p.name, "rating": p.overall_rating} for p in self.best_xi()],
        }


# ── Multiplayer league ─────────────────────────────────────────────────────────
class MultiplayerLeague:
    """A head-to-head multiplayer league where each player fields their NFT XI."""

    def __init__(self, name: str, match_type: str = "t20"):
        self.id           = make_id("mpl")
        self.name         = name
        self.match_type   = match_type
        self.squads:       dict[str, NFTSquad] = {}   # owner → squad
        self.standings     = Standings()
        self.engine        = MatchEngine()
        self.match_history: list[dict] = []

    def register(self, squad: NFTSquad):
        self.squads[squad.owner] = squad
        self.standings.add_team(squad.id, squad.owner)
        log.info(f"Registered {squad.owner}'s NFT squad in {self.name}")

    def play_round_robin(self) -> dict:
        owners = list(self.squads.values())
        results = []
        for i, sq1 in enumerate(owners):
            for sq2 in owners[i+1:]:
                t1 = sq1.to_team()
                t2 = sq2.to_team()
                r  = self.engine.simulate_match(t1, t2, self.match_type)
                self.match_history.append(r)

                h_inn = next((i for i in r["innings"] if i["team_id"] == t1.id), {})
                a_inn = next((i for i in r["innings"] if i["team_id"] == t2.id), {})

                self.standings.record_result(
                    sq1.id, sq2.id, r["result"],
                    h_inn.get("runs", 0), h_inn.get("overs", 0),
                    a_inn.get("runs", 0), a_inn.get("overs", 0),
                )
                results.append({
                    "home": sq1.owner, "away": sq2.owner,
                    "result": r["result"],
                })
        log.info(f"{self.name}: played {len(results)} matches")
        return {"matches": results, "standings": self.standings.as_list()}

    def champion(self) -> Optional[str]:
        table = self.standings.sorted_table()
        return table[0]["name"] if table else None
