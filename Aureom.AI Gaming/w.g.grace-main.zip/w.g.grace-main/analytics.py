"""analytics.py — Player/team stats, predictive modeling, dashboard data generation"""

from __future__ import annotations
import math
import random
from typing import Optional
from .utils import get_logger, clamp, normalise

log = get_logger("analytics")


# ── Player form calculator ─────────────────────────────────────────────────────
def calculate_batting_form(recent_scores: list[int]) -> float:
    """Weighted recent form — last 5 innings, recency weighted."""
    if not recent_scores:
        return 50.0
    weights = [0.35, 0.25, 0.20, 0.12, 0.08][:len(recent_scores)]
    total_w = sum(weights)
    score = sum(s * w for s, w in zip(recent_scores, weights)) / total_w
    return clamp(score, 0, 100)

def calculate_bowling_form(recent_wickets: list[int], recent_econ: list[float]) -> float:
    """Form based on recent wickets and economy."""
    if not recent_wickets:
        return 50.0
    avg_wkts = sum(recent_wickets) / len(recent_wickets)
    avg_econ  = sum(recent_econ) / len(recent_econ) if recent_econ else 6.0
    # Normalise: 5 wkts = great, 0 = poor; economy 3=great 10=poor
    wkts_score = clamp(avg_wkts * 20, 0, 100)
    econ_score  = clamp(100 - (avg_econ - 3) * 10, 0, 100)
    return round(wkts_score * 0.6 + econ_score * 0.4, 1)


# ── Predictive match model ─────────────────────────────────────────────────────
class MatchPredictor:
    """Simple Elo-like win probability model."""

    ELO_K = 32

    def __init__(self):
        self.elo_ratings: dict[str, float] = {}

    def get_elo(self, team_id: str) -> float:
        return self.elo_ratings.get(team_id, 1500.0)

    def win_probability(
        self,
        home_id: str,
        away_id: str,
        home_advantage: float = 50.0,
    ) -> dict:
        home_elo = self.get_elo(home_id) + home_advantage
        away_elo = self.get_elo(away_id)
        exp_home  = 1 / (1 + 10 ** ((away_elo - home_elo) / 400))
        exp_away  = 1 - exp_home
        return {
            "home_win_pct": round(exp_home * 100, 1),
            "away_win_pct": round(exp_away * 100, 1),
            "home_elo":     round(home_elo, 0),
            "away_elo":     round(away_elo, 0),
        }

    def update_elos(self, winner_id: str, loser_id: str):
        w = self.get_elo(winner_id)
        l = self.get_elo(loser_id)
        exp_w = 1 / (1 + 10 ** ((l - w) / 400))
        self.elo_ratings[winner_id] = round(w + self.ELO_K * (1 - exp_w), 1)
        self.elo_ratings[loser_id]  = round(l + self.ELO_K * (0 - (1 - exp_w)), 1)


# ── Team analytics ────────────────────────────────────────────────────────────
def team_batting_depth(team) -> dict:
    """Analyse batting lineup depth."""
    squad = team.squad
    batters = [p for p in squad if p.role in ("batsman", "allrounder", "wicketkeeper")]
    top6  = sorted(batters, key=lambda p: p.batting_rating, reverse=True)[:6]
    lower = sorted(batters, key=lambda p: p.batting_rating, reverse=True)[6:]
    return {
        "top6_avg_rating":    round(sum(p.batting_rating for p in top6) / max(len(top6), 1), 1),
        "lower_order_rating": round(sum(p.batting_rating for p in lower) / max(len(lower), 1), 1),
        "avg_experience":     round(sum(p.stats.matches for p in batters) / max(len(batters), 1), 1),
        "batting_depth":      "excellent" if len(top6) >= 6 else "adequate" if len(top6) >= 4 else "thin",
    }

def team_bowling_strength(team) -> dict:
    """Analyse bowling attack."""
    squad = team.squad
    bowlers = [p for p in squad if p.role in ("bowler", "allrounder")]
    pace    = [p for p in bowlers if "fast" in p.bowling_style or "medium" in p.bowling_style]
    spin    = [p for p in bowlers if "spin" in p.bowling_style]
    return {
        "num_pace":          len(pace),
        "num_spin":          len(spin),
        "avg_pace_rating":   round(sum(p.bowling_rating for p in pace) / max(len(pace), 1), 1),
        "avg_spin_rating":   round(sum(p.bowling_rating for p in spin) / max(len(spin), 1), 1),
        "total_wickets":     sum(p.stats.wickets for p in bowlers),
        "bowling_balance":   "balanced" if len(pace) >= 2 and len(spin) >= 1 else "lopsided",
    }

def squad_fitness_report(team) -> dict:
    """Summary of squad fitness and injury status."""
    total    = len(team.squad)
    injured  = [p for p in team.squad if p.personal.is_injured()]
    fatigued = [p for p in team.squad if p.personal.fatigue > 70]
    avg_fat  = sum(p.personal.fatigue for p in team.squad) / max(total, 1)
    return {
        "total_players":    total,
        "injured_count":    len(injured),
        "injured_names":    [p.name for p in injured],
        "fatigued_count":   len(fatigued),
        "avg_fatigue_pct":  round(avg_fat, 1),
        "availability_pct": round((total - len(injured)) / max(total, 1) * 100, 1),
    }

def player_value_score(player) -> float:
    """Composite market value score for NFT/trading."""
    base = player.overall_rating
    age_peak = 28
    age_pen  = abs(player.personal.age - age_peak) * 0.8
    rep_bon  = player.personal.reputation * 0.3
    form_bon = player.personal.confidence * 0.2
    return clamp(base + rep_bon + form_bon - age_pen, 0, 100)


# ── Tournament standings ──────────────────────────────────────────────────────
class Standings:
    def __init__(self):
        self.table: dict[str, dict] = {}   # team_id -> row

    def add_team(self, team_id: str, name: str):
        self.table[team_id] = {
            "name": name, "p": 0, "w": 0, "l": 0, "d": 0, "pts": 0,
            "nrr": 0.0, "runs_for": 0, "runs_against": 0, "overs_for": 0.0, "overs_against": 0.0,
        }

    def record_result(
        self,
        home_id: str,
        away_id: str,
        result: dict,
        home_runs: int, home_overs: float,
        away_runs: int, away_overs: float,
    ):
        for tid in (home_id, away_id):
            if tid not in self.table:
                self.table[tid] = {"name": tid, "p": 0, "w": 0, "l": 0, "d": 0,
                                   "pts": 0, "nrr": 0.0,
                                   "runs_for": 0, "runs_against": 0,
                                   "overs_for": 0.0, "overs_against": 0.0}

        h = self.table[home_id]
        a = self.table[away_id]

        h["p"] += 1; a["p"] += 1
        h["runs_for"]     += home_runs;  h["runs_against"] += away_runs
        h["overs_for"]    += home_overs; h["overs_against"] += away_overs
        a["runs_for"]     += away_runs;  a["runs_against"]  += home_runs
        a["overs_for"]    += away_overs; a["overs_against"] += home_overs

        winner = result.get("winner")
        rtype  = result.get("type")

        if rtype in ("draw", "Draw"):
            h["d"] += 1; h["pts"] += 1
            a["d"] += 1; a["pts"] += 1
        elif rtype in ("tie", "Tie"):
            h["d"] += 1; h["pts"] += 1
            a["d"] += 1; a["pts"] += 1
        elif winner and winner not in ("Draw", "Tie", None):
            home_name = self.table[home_id]["name"]
            if winner == home_name or winner == home_id:
                h["w"] += 1; h["pts"] += 2
                a["l"] += 1
            else:
                a["w"] += 1; a["pts"] += 2
                h["l"] += 1

        # Recalculate NRR
        for tid, row in [(home_id, h), (away_id, a)]:
            rr_for     = row["runs_for"]  / max(row["overs_for"], 0.1)
            rr_against = row["runs_against"] / max(row["overs_against"], 0.1)
            row["nrr"] = round(rr_for - rr_against, 3)

    def sorted_table(self) -> list[dict]:
        return sorted(self.table.values(), key=lambda r: (-r["pts"], -r["nrr"]))

    def as_list(self) -> list[dict]:
        return [{"pos": i+1, **row} for i, row in enumerate(self.sorted_table())]


# ── Dashboard data builder ────────────────────────────────────────────────────
def build_dashboard_data(team, matches: list[dict], season: int) -> dict:
    """Compile all analytics into a single dashboard-ready dict."""
    wins   = sum(1 for m in matches if m.get("result", {}).get("winner") == team.name)
    losses = sum(1 for m in matches if m.get("result", {}).get("winner") not in (team.name, "Draw", "Tie", None))
    draws  = len(matches) - wins - losses

    # Player leaderboards
    top_batters = sorted(team.squad, key=lambda p: p.stats.runs, reverse=True)[:5]
    top_bowlers = sorted(team.squad, key=lambda p: p.stats.wickets, reverse=True)[:5]

    return {
        "season":     season,
        "team":       team.name,
        "record":     {"matches": len(matches), "wins": wins, "losses": losses, "draws": draws},
        "finances":   team.finances,
        "batting":    team_batting_depth(team),
        "bowling":    team_bowling_strength(team),
        "fitness":    squad_fitness_report(team),
        "top_batters": [
            {"name": p.name, "runs": p.stats.runs, "avg": p.stats.average,
             "hs": p.stats.high_score, "100s": p.stats.centuries}
            for p in top_batters
        ],
        "top_bowlers": [
            {"name": p.name, "wkts": p.stats.wickets, "avg": p.stats.bowl_average,
             "bb": p.stats.best_bowling, "5fers": p.stats.five_fers}
            for p in top_bowlers
        ],
        "morale":     team.morale,
    }


# ── Career projection ─────────────────────────────────────────────────────────
def project_career(player, seasons_ahead: int = 5) -> list[dict]:
    """Rough multi-season projection for player rating trajectory."""
    projections = []
    rating = player.overall_rating
    age    = player.personal.age
    pot    = player.attributes.potential

    for s in range(seasons_ahead):
        season_age = age + s
        if season_age < 27:
            delta = (pot - rating) * 0.12
        elif season_age <= 31:
            delta = (pot - rating) * 0.04
        else:
            delta = -random.uniform(0.5, 2.5)
        rating = clamp(rating + delta, 30, 99)
        projections.append({
            "season": season_age,
            "age":    season_age,
            "rating": round(rating, 1),
        })
    return projections
