"""commentary.py — AI commentary, podcasts, media trends, fan reactions"""

from __future__ import annotations
import random
from typing import Optional
from .utils import get_logger, chance, weighted_choice

log = get_logger("commentary")

# ── Commentary banks ───────────────────────────────────────────────────────────
DOT_BALL = [
    "Defended stolidly back down the pitch.",
    "Left alone — excellent discipline from the batsman.",
    "Beaten outside off stump! Doesn't trouble the woodwork.",
    "Good dot ball. The pressure is building.",
    "Tight line and length — nothing on offer for the batsman.",
    "Played and missed! The edge missed the slip cordon by inches.",
    "A probing delivery, but the batsman reads it well.",
    "Dot ball. The asking rate keeps creeping up.",
]

SINGLE = [
    "Pushed into the leg side for a comfortable single.",
    "Dabs it fine down to third man — one run.",
    "Worked through midwicket, they scamper through for one.",
    "Clever placement through the covers — single taken.",
]

TWO_RUNS = [
    "Running hard — two taken to deep midwicket!",
    "Driven through the gap, great running — two runs!",
    "That races away, they come back for the second with ease.",
]

FOUR = [
    "FOUR! Driven beautifully through the covers!",
    "FOUR! That's a cracking shot, flat-batted over mid-on!",
    "FOUR! The pull shot — timed to perfection!",
    "FOUR! Edged and through the gap at third man!",
    "FOUR! Glanced elegantly off the pads down to fine leg!",
    "FOUR! Slashed over gully, that was audacious!",
]

SIX = [
    "SIX! That has gone absolutely miles! Incredible power!",
    "SIX! Muscled over long-on, the crowd goes wild!",
    "SIX! Ramp shot over the keeper, what a stroke!",
    "SIX! Hit clean as a whistle into the stands!",
    "SIX! Picked the length early and dispatched it into the crowd!",
]

WICKET = {
    "bowled":        ["{bat} is BOWLED! The stumps are shattered!",
                      "What a delivery! Beats {bat} all ends up — BOWLED!"],
    "caught":        ["{bat} is caught! Taken cleanly at {pos}!",
                      "UP she goes — and CAUGHT! {bat} must go!"],
    "lbw":           ["{bat} is LBW! Dead in front of middle stump!",
                      "Plumb in front! {bat} walks without waiting for the finger."],
    "caught_behind": ["{bat} nicks behind — CAUGHT behind by the keeper!",
                      "Thin edge — {bat} has to go, caught behind!"],
    "stumped":       ["{bat} is STUMPED! Drifted out of the crease and the keeper is lightning fast!"],
    "run_out":       ["{bat} is RUN OUT! A direct hit — no time to dive!",
                      "Direct hit! {bat} is short of the crease — RUN OUT!"],
    "not_out":       ["Not out — the batsman survives!"],
}

BOUNDARY_CALL = [
    "That's going all the way to the boundary rope!",
    "The fielder gives chase but can't cut it off!",
    "Perfectly placed, no chance for the fielder!",
]

PITCH_COMMENTARY = {
    "green_top":  ["This pitch is offering significant movement off the seam.",
                   "The pacers will be licking their lips on this surface."],
    "spinning":   ["This is a belter of a surface for the spinners.",
                   "Plenty of turn available — the off-spinners will be key."],
    "flat":       ["A flat wicket — the batsmen should feast today.",
                   "Run-fest incoming on this road of a pitch!"],
    "crumbling":  ["The pitch is crumbling. Expect fireworks from the spinners.",
                   "Old cracks opening up — could be decisive late in the innings."],
    "bouncy":     ["The extra bounce here will trouble the batsmen.",
                   "Watch out for the short ball on this quick surface."],
    "seaming":    ["The ball is moving prodigiously off the pitch.",
                   "Great conditions for swing and seam — batsmen beware!"],
    "dead":       ["It's a slow, sluggish pitch. Strokeplay will be at a premium.",
                   "Dead surface — spinners will need to flight the ball to beat the bat."],
}

WEATHER_COMMENTARY = {
    "overcast":  ["Overcast skies — ideal for swing bowling.",
                  "The cloud cover should help the seamers today."],
    "rain":      ["Play has been stopped due to rain.", "Covers coming on — rain interrupts play."],
    "sunny":     ["Glorious sunshine — perfect batting conditions.",
                  "Beautiful day at the ground, the outfield will be fast today."],
    "windy":     ["Strong crosswinds could affect the swing bowlers today.",
                  "The wind is swirling — that'll make life difficult."],
    "humid":     ["High humidity — the ball should swing later in the innings.",
                  "Muggy conditions — interesting for the bowling side."],
}

MILESTONES = [
    "And that's a FIFTY for {name}! Fifty up in {balls} balls! Tremendous effort!",
    "ONE HUNDRED! {name} reaches THREE FIGURES! The crowd rises as one!",
    "That's {wkts} wickets in the innings for {name}! A magnificent spell!",
    "FIVE-FOR! {name} takes his five-wicket haul! This is world-class bowling!",
]

PARTNERSHIP = [
    "A fine partnership blossoming here — {runs} runs together.",
    "These two are building something special. {runs} added for this wicket.",
    "The partnership is worth {runs} now — the fielding side needs a breakthrough.",
]

MATCH_OPENING = [
    "Welcome to {venue}! {home} take on {away} in what promises to be a {type} classic!",
    "Good morning from {venue}! {home} v {away} — the toss is in and we're ready for action!",
    "Ladies and gentlemen, welcome! The stage is set at {venue} for {home} vs {away}.",
]

END_OF_INNINGS = [
    "{team} finish on {runs}/{wkts} from {overs} overs — a {adj} total.",
    "{team} are all out for {runs} in {overs} overs. {adj} effort from the batters.",
    "{team} declare on {runs}/{wkts} after {overs} overs — {adj} positioning!",
]

RESULT_LINES = {
    "runs":    "{winner} win by {margin}! A comprehensive victory!",
    "wickets": "{winner} win by {margin}! Chased down with authority!",
    "draw":    "It ends in a DRAW! Both sides will take something from this.",
    "tie":     "An incredible TIE! What a match this has been!",
}


# ── Commentary generator ───────────────────────────────────────────────────────
class CommentaryEngine:

    def delivery_comment(
        self,
        runs: int,
        wicket: bool,
        dismissal: str = "not_out",
        batsman_name: str = "Batsman",
        bowler_name: str = "Bowler",
        beaten: bool = False,
    ) -> str:
        if wicket:
            templates = WICKET.get(dismissal, WICKET["not_out"])
            pos = random.choice(["slip", "gully", "midwicket", "cover", "midoff"])
            return random.choice(templates).format(bat=batsman_name, pos=pos)
        if runs == 0:
            return random.choice(DOT_BALL)
        if runs == 1:
            return random.choice(SINGLE)
        if runs == 2:
            return random.choice(TWO_RUNS)
        if runs == 4:
            return random.choice(FOUR) + " " + random.choice(BOUNDARY_CALL)
        if runs == 6:
            return random.choice(SIX)
        return f"{runs} runs taken."

    def innings_header(self, team_name: str, innings_num: int) -> str:
        ordinal = {1: "1st", 2: "2nd", 3: "3rd", 4: "4th"}
        return f"=== {team_name} — {ordinal.get(innings_num, f'{innings_num}th')} Innings ==="

    def pitch_comment(self, pitch_type: str) -> str:
        lines = PITCH_COMMENTARY.get(pitch_type, ["An interesting surface today."])
        return random.choice(lines)

    def weather_comment(self, weather_type: str) -> str:
        lines = WEATHER_COMMENTARY.get(weather_type, ["Conditions are normal at the ground."])
        return random.choice(lines)

    def match_opener(self, home: str, away: str, venue: str, match_type: str) -> str:
        return random.choice(MATCH_OPENING).format(
            home=home, away=away, venue=venue, type=match_type
        )

    def end_of_innings(self, team: str, runs: int, wkts: int, overs: float) -> str:
        adj = "superb" if runs > 300 else ("decent" if runs > 200 else "modest")
        return random.choice(END_OF_INNINGS).format(
            team=team, runs=runs, wkts=wkts, overs=overs, adj=adj
        )

    def milestone(self, name: str, value: int, kind: str = "runs") -> str:
        if kind == "runs":
            if value >= 100:
                return MILESTONES[1].format(name=name, balls="")
            else:
                return MILESTONES[0].format(name=name, balls="")
        elif kind == "wickets":
            tmpl = MILESTONES[2] if value < 5 else MILESTONES[3]
            return tmpl.format(name=name, wkts=value)
        return f"{name} reaches {value}!"

    def match_result(self, winner: str, margin: str, result_type: str) -> str:
        tmpl = RESULT_LINES.get(result_type, "{winner} win!")
        return tmpl.format(winner=winner, margin=margin)

    def generate_full_scorecard_text(self, innings: dict) -> str:
        lines = [f"\n{innings['team_name']} — {innings['runs']}/{innings['wickets']} "
                 f"({innings['overs']} overs)  RR: {innings['rr']}"]
        lines.append("-" * 50)
        lines.append(f"{'Batsman':<22} {'R':>5} {'B':>5} {'4s':>4} {'6s':>4}")
        for pid, bs in innings.get("batting", {}).items():
            lines.append(f"  {pid[:16]:<20} {bs['runs']:>5} {bs['balls']:>5} "
                         f"{bs['4s']:>4} {bs['6s']:>4}")
        lines.append("-" * 50)
        lines.append(f"{'Bowler':<22} {'O':>5} {'R':>5} {'W':>4}")
        for pid, bws in innings.get("bowling", {}).items():
            lines.append(f"  {pid[:16]:<20} {bws['overs']:>5} {bws['runs']:>5} "
                         f"{bws['wkts']:>4}")
        return "\n".join(lines)


# ── Podcast generator ─────────────────────────────────────────────────────────
PODCAST_INTROS = [
    "Welcome to The Middle Stump Podcast. I'm your host and today we're diving deep into",
    "You're listening to Cricket Decoded — the show where data meets drama. This week:",
    "Hello and welcome back to Stumped! Another action-packed week of cricket to dissect.",
    "Good evening cricket fans, it's the Anglo-Futurist Cricket Hour. Tonight's hot topics:",
]

PODCAST_TOPICS = [
    "the extraordinary batting display by {player} — is he the best in the world right now?",
    "a dramatic collapse from {team} — what went wrong?",
    "the conditions controversy at {venue} — was the pitch fair?",
    "{team}'s injury crisis and how they can cope without their key men.",
    "the tactics debate — did {team} declare too late?",
    "the emergence of {player} as an all-time great.",
    "weather drama costing {team} a crucial session.",
    "the transfer market — who should {team} sign this winter?",
]

PODCAST_ANALYSIS = [
    "The numbers tell an interesting story here — let's dig in.",
    "Looking at the xG metrics and expected delivery outcomes, there's a clear pattern.",
    "The AI prediction model had this one at sixty-two percent before the toss.",
    "Historical data suggests this pitch type suits the chasing side by eight percent.",
    "Morale indices were flagging something unusual in the {team} camp this week.",
]

PODCAST_OUTROS = [
    "That's all for this week's edition. Don't forget to subscribe, and as always — play straight!",
    "Thanks for tuning in. We'll be back next week with more deep dives into the beautiful game.",
    "Keep the conversation going on our Discord. Until next time — stay cricket.",
]


class PodcastEngine:

    def generate_post_match_podcast(
        self,
        home_name: str,
        away_name: str,
        result: dict,
        top_performers: list[str],
        venue: str = "the ground",
    ) -> str:
        lines = []
        lines.append(random.choice(PODCAST_INTROS))
        topic_vars = {
            "player": random.choice(top_performers) if top_performers else "the stars",
            "team":   result.get("winner", home_name),
            "venue":  venue,
        }
        lines.append(random.choice(PODCAST_TOPICS).format(**topic_vars))
        lines.append("")
        lines.append(f"So, {home_name} versus {away_name}. The result: "
                     f"{result.get('winner', 'no winner')} won by {result.get('margin', 'a margin')}.")
        lines.append("")
        lines.append(random.choice(PODCAST_ANALYSIS).format(team=home_name))
        lines.append(random.choice(PODCAST_ANALYSIS).format(team=away_name))
        lines.append("")
        lines.append(random.choice(PODCAST_OUTROS))
        return "\n".join(lines)

    def generate_season_review(self, season: int, team_name: str, stats_summary: dict) -> str:
        return (
            f"SEASON {season} REVIEW — {team_name.upper()}\n"
            + "=" * 50 + "\n"
            + random.choice(PODCAST_INTROS) + "\n"
            + f"What a season it has been for {team_name}!\n"
            + f"  Matches played:  {stats_summary.get('matches', 0)}\n"
            + f"  Wins:            {stats_summary.get('wins', 0)}\n"
            + f"  Top run-scorer:  {stats_summary.get('top_bat', 'Unknown')}\n"
            + f"  Top wicket-taker:{stats_summary.get('top_bowl', 'Unknown')}\n"
            + random.choice(PODCAST_ANALYSIS).format(team=team_name) + "\n"
            + random.choice(PODCAST_OUTROS)
        )


# ── Media / Fan trend engine ───────────────────────────────────────────────────
HEADLINE_TEMPLATES = [
    "{name} IN BRILLIANT FORM — SELECTORS TAKE NOTE",
    "CRISIS AT {team} AS INJURY LIST GROWS",
    "{team} MANAGER UNDER FIRE AFTER SHOCK DEFEAT",
    "{name} LINKED TO BIG-MONEY MOVE — EXCLUSIVE",
    "PITCH CONTROVERSY AT {venue} — ICC TO INVESTIGATE",
    "{name} HITS CENTURY OF CENTURIES — A LEGEND IN HIS TIME",
    "{team}'s GOLDEN GENERATION: ARE THEY THE BEST EVER?",
    "RAIN RUINS THE ASHES: DAY THREE WASHED OUT",
    "{name} RETIRES: END OF AN ERA FOR {team}",
    "SURPRISE CALL-UP: {name} TO MAKE TEST DEBUT",
]

class MediaEngine:

    def generate_headlines(
        self,
        players: list,
        teams: list,
        result: dict | None = None,
        venue: str = "TBA",
        n: int = 5,
    ) -> list[str]:
        headlines = []
        for _ in range(n):
            tmpl = random.choice(HEADLINE_TEMPLATES)
            p_name  = random.choice(players).name  if players else "A Player"
            t_name  = random.choice(teams).name    if teams   else "A Team"
            h = tmpl.format(name=p_name, team=t_name, venue=venue)
            headlines.append(h)
        return headlines

    def fan_sentiment(self, team_morale: float, recent_results: list[str]) -> dict:
        wins    = recent_results.count("win")
        losses  = recent_results.count("loss")
        overall = (wins - losses) / max(len(recent_results), 1)
        mood    = "ecstatic" if overall > 0.6 else (
                  "content"  if overall > 0.2 else (
                  "restless" if overall > -0.2 else "furious"))
        return {
            "mood":         mood,
            "sentiment":    round(overall * 100, 1),
            "stadium_fill": clamp_fan(70 + overall * 20 + random.uniform(-5, 5)),
            "social_trend": random.choice(["trending", "stable", "declining"]),
        }


def clamp_fan(v: float) -> float:
    return max(0, min(100, v))
