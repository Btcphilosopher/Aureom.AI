# W.G.Grace-1
### Cricket Management & Simulation — Anglo-Futurist Edition

```
W . G . G R A C E - 1
Cricket Management & Simulation  |  Anglo-Futurist Edition
```

A full-featured cricket management simulation inspired by International Cricket Captain,
with deep AI career progression, dynamic match simulation, NFT-backed superstar players
trading via Bitcoin Lightning Network, and an Anglo-futurist PyQt6 dashboard.

---

## Features

| System | Details |
|--------|---------|
| **Career Simulation** | Player growth, youth academies, injuries, morale, scouting |
| **Match Engine** | Test/ODI/T20/County with pitch & weather dynamics |
| **AI Tactics** | Adaptive bowling rotations, batting strategies, declarations |
| **Events System** | Hidden sidequests, pitch conspiracies, media scandals |
| **Commentary** | Real-time delivery commentary, end-of-innings reports |
| **Podcast Engine** | AI-generated post-match and season-review podcasts |
| **Analytics** | Elo ratings, NRR standings, player projections, dashboards |
| **Multiplayer** | Tournaments, leagues, round-robin, and knockout formats |
| **NFT Players** | Mint elite players as NFTs; trade via Bitcoin Lightning |
| **GUI** | PyQt6 Anglo-futurist dashboard (dark gold/cyan theme) |
| **Mod Support** | Drop JSON mods in `/mods/` folder |

---

## Installation

### Requirements
- Python 3.11+
- Linux (tested on Ubuntu 22.04+) — macOS/Windows work too

### Install dependencies
```bash
pip install PyQt6 httpx
```

### Clone and run
```bash
git clone https://github.com/yourname/wg-grace-1
cd wg-grace-1

# CLI demo (no GUI needed)
python -m wg_grace_1 --demo

# Full PyQt6 GUI
python -m wg_grace_1 --gui

# Initialise database only
python -m wg_grace_1 --init
```

---

## Project Structure

```
wg_grace_1/
├── __init__.py          Package init
├── __main__.py          Entry point
├── main.py              CLI orchestration & demo
├── utils.py             Logging, config, RNG helpers
├── database.py          SQLite schema and CRUD layer
├── career.py            Player/team models, growth, youth academy
├── match_sim.py         Match engine: pitch/weather, AI tactics, delivery sim
├── events.py            Dynamic events, sidequests, weather/pitch system
├── commentary.py        Commentary, podcasts, media headlines
├── analytics.py         Stats, Elo ratings, standings, projections
├── multiplayer.py       Leagues, tournaments, NFT squads
├── nft_players.py       NFT metadata, registry, eligibility
├── blockchain.py        Bitcoin/Lightning integration
├── gui.py               PyQt6 Anglo-futurist dashboard
├── data_loader.py       Seed data: teams, stadiums, squads
└── data/                Generated SQLite database
```

---

## Gameplay

### Career Mode (Single Player)
1. Launch the GUI: `python -m wg_grace_1 --gui`
2. You manage **England** by default — change via the SQUAD tab team dropdown
3. **DASHBOARD** shows your season record, budget, and squad health
4. **MATCH SIM** — pick home/away teams, format, venue and simulate
5. **ANALYTICS** — see top batters/bowlers and team depth analysis
6. **EVENTS** — respond to season events: injuries, transfers, scandals
7. **CAREER** — advance the off-season to develop your squad
8. **MEDIA** — read generated headlines and podcasts

### Match Formats
| Format | Innings | Overs | Notes |
|--------|---------|-------|-------|
| T20 | 1 each | 20 | Fast-paced, run-chasing |
| ODI | 1 each | 50 | Balanced format |
| Test | 2 each | Unlimited | 5-day pitch dynamics |
| County | 2 each | Unlimited | 4-day, English conditions |

### Pitch & Weather
The pitch and weather system is **hidden** — you see the effects but not the exact numbers.
- **Green top** at Headingley → pace bowlers dominant, early wickets likely
- **Spinning surface** at Chennai → turn available from ball one
- **Overcast** weather → swing and seam movement increases
- Pitches deteriorate over Test days — spinners grow more potent by Day 4–5

### Events & Sidequests
Each season generates random events requiring your decision:
- Transfer bids for your key players
- Pitch preparation controversies
- Media scandals and tabloid stories
- Injury crises before key series
- Fan unrest after poor results

Your choices affect morale, budget, reputation, and team dynamics.

---

## NFT System (Multiplayer only)

Elite international players (OVR 65+, reputation 40+) can be minted as NFTs.

```
NFT Tab → Select player → MINT SELECTED PLAYER
```

- **Mint fee**: 1,000 satoshis (configurable in `config.json`)
- **Trading**: List your NFT for sale; other managers can purchase via Lightning invoice
- **Blockchain mode**: Set `blockchain.enabled: true` in `config.json` and configure your LND node

### Lightning Network Setup (Production)
```json
{
  "blockchain": {
    "enabled": true,
    "network": "mainnet",
    "lnd_host": "your-lnd-host",
    "lnd_port": 10009,
    "nft_mint_fee_sats": 1000
  }
}
```
In demo mode (`enabled: false`), all Lightning operations are simulated locally.

---

## Multiplayer

### NFT Squad Mode
Assemble your best 11 from owned NFT players and compete:
```python
from wg_grace_1.multiplayer import MultiplayerLeague, NFTSquad
from wg_grace_1.nft_players import get_registry

league = MultiplayerLeague("Anglo-Futurist T20 League", "t20")
sq = NFTSquad(owner="your_handle")
# add minted players to sq, then:
league.register(sq)
results = league.play_round_robin()
```

### Tournament API
```python
from wg_grace_1.multiplayer import Tournament
from wg_grace_1.data_loader import create_international_teams

teams = list(create_international_teams().values())
cup   = Tournament("World Cup 2024", teams[:8], match_type="odi")
cup.play_all(verbose=True)
print(cup.summary())
```

---

## Modding

Drop mod folders into `wg_grace_1/mods/`:

```
wg_grace_1/mods/
└── my_mod/
    ├── teams.json         Custom team definitions
    ├── players.json       Custom player roster
    ├── stadiums.json      Custom venue data
    └── events.json        Custom event templates
```

### teams.json format
```json
[
  {
    "name": "Cornwall XI",
    "short_name": "COR",
    "country": "England",
    "team_type": "county",
    "home_ground": "The Rec, Truro"
  }
]
```

### players.json format
```json
[
  {
    "name": "Jack Trevaskis",
    "nationality": "England",
    "role": "bowler",
    "batting_style": "right-hand",
    "bowling_style": "left-arm spin",
    "attributes": {
      "batting": {"technique": 45, "power": 40},
      "bowling": {"accuracy": 78, "turn": 82}
    }
  }
]
```

Load mods via:
```python
from wg_grace_1.utils import load_mod_data
teams = load_mod_data("my_mod", "teams.json")
```

---

## Configuration

Edit `wg_grace_1/config.json` (auto-generated on first run):

```json
{
  "game": {
    "season_start_year": 2024,
    "difficulty": "normal",
    "random_events_enabled": true,
    "weather_system": true,
    "pitch_dynamics": true
  },
  "blockchain": {
    "enabled": false,
    "nft_mint_fee_sats": 1000
  },
  "ui": {
    "theme": "anglo_futurist",
    "animations": true
  }
}
```

Difficulty levels: `easy` / `normal` / `hard` / `legendary`

---

## Architecture Notes

### Match Simulation Pipeline
```
MatchEngine.simulate_match()
  ├── random_pitch()          → PitchState (type, hardness, grass, cracks)
  ├── WeatherState.advance()  → Weather transitions
  ├── EventEngine.generate()  → Pre-match events
  └── _simulate_innings() × N
       ├── AITacticsEngine.choose_bowler()   → Condition-aware selection
       ├── AITacticsEngine.batting_strategy()→ Phase-aware approach
       └── DeliveryEngine.simulate() × 6    → Wicket/runs probability model
            ├── bat_skill × bat_env_modifier
            ├── bowl_skill × seam/spin_modifier
            └── Weighted random outcome
```

### Pitch × Weather interaction
```
Swing = base × pitch.seam_modifier() × weather.swing_modifier()
  - Green top + overcast = up to 1.8× swing
  - Spinning pitch + Day 5 = up to 1.9× turn
  - Flat pitch + sunny = 1.25× batting advantage
```

---

## Licence

Open-source — MIT Licence.  
Contributions welcome: new leagues, AI commentary voices, stadium data, tournament formats.

---

*"Cricket is the greatest game that the wit of man has yet devised."*
*— W.G. Grace*
