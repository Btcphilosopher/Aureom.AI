"""match_sim.py — Match engine: AI tactics, pitch/weather, manager-as-player mode"""

from __future__ import annotations
import random
import math
from dataclasses import dataclass, field
from typing import Optional
from .utils import make_id, chance, clamp, normalise, get_logger, cfg, weighted_choice
from .career import Player, Team
from .events import WeatherState, PitchState, EventEngine, random_pitch

log = get_logger("match_sim")

# ── Match types ────────────────────────────────────────────────────────────────
MATCH_TYPES = {
    "test":   {"innings": 2, "overs": None,  "days": 5},
    "odi":    {"innings": 1, "overs": 50,    "days": 1},
    "t20":    {"innings": 1, "overs": 20,    "days": 1},
    "county": {"innings": 2, "overs": None,  "days": 4},
}

DISMISSAL_TYPES = [
    "bowled", "caught", "lbw", "run_out", "stumped",
    "caught_behind", "hit_wicket", "handled_ball", "not_out",
]


# ── Delivery simulation ────────────────────────────────────────────────────────
@dataclass
class Delivery:
    bowler_id:   str
    batsman_id:  str
    runs:        int     = 0
    extras:      int     = 0
    wicket:      bool    = False
    dismissal:   str     = "not_out"
    ball_type:   str     = "normal"   # normal/bouncer/yorker/swing/spin/variation
    beaten:      bool    = False      # beaten outside edge

    def is_scoring(self):
        return self.runs > 0 or self.extras > 0


@dataclass
class InningsState:
    team_id:    str
    batting_order: list[str]   # player IDs
    batting_pos: int = 0
    runs:        int = 0
    wickets:     int = 0
    overs:       float = 0.0
    balls:       int = 0
    fow:         list[tuple] = field(default_factory=list)   # (wicket, runs, overs)
    batting_stats: dict = field(default_factory=dict)       # player_id -> {runs, balls, 4s, 6s}
    bowling_stats: dict = field(default_factory=dict)       # player_id -> {overs, runs, wkts}
    partnerships: list[dict] = field(default_factory=list)
    current_partnership: dict = field(default_factory=dict)

    def add_delivery(self, d: Delivery):
        self.balls += 1
        self.runs  += d.runs + d.extras
        if self.balls % 6 == 0:
            self.overs += 1
            self.balls  = 0

        # Batting stats
        bs = self.batting_stats.setdefault(d.batsman_id, {"runs": 0, "balls": 0, "4s": 0, "6s": 0})
        bs["runs"]  += d.runs
        bs["balls"] += 1
        if d.runs == 4: bs["4s"] += 1
        if d.runs == 6: bs["6s"] += 1

        # Bowling stats
        bws = self.bowling_stats.setdefault(d.bowler_id, {"overs": 0, "balls": 0, "runs": 0, "wkts": 0})
        bws["runs"]  += d.runs + d.extras
        bws["balls"] += 1
        if bws["balls"] % 6 == 0:
            bws["overs"] += 1
            bws["balls"]  = 0

        if d.wicket:
            bws["wkts"] += 1
            self.wickets += 1
            self.fow.append((self.wickets, self.runs, self.overs + self.balls / 6))
            self.batting_pos += 1

    @property
    def current_rr(self) -> float:
        total_overs = self.overs + self.balls / 6
        return self.runs / total_overs if total_overs > 0 else 0.0

    def is_all_out(self) -> bool:
        return self.wickets >= 10


# ── Delivery engine ────────────────────────────────────────────────────────────
class DeliveryEngine:
    """Simulates a single delivery given player attributes and conditions."""

    def simulate(
        self,
        bowler: Player,
        batsman: Player,
        weather: WeatherState,
        pitch: PitchState,
        innings_num: int,
        over: int,
        required_rr: float = 0.0,
        manager_override: Optional[dict] = None,
    ) -> Delivery:
        d = Delivery(bowler_id=bowler.id, batsman_id=batsman.id)

        # ── Compute base probabilities ────────────────────────────────────────
        bat_skill  = batsman.attributes.overall_batting() / 100
        bowl_skill = bowler.attributes.overall_bowling() / 100

        # Pitch and weather modifiers
        seam_mod = pitch.seam_modifier() * weather.swing_modifier()
        spin_mod = pitch.spin_modifier() * weather.spin_modifier()
        bat_env  = pitch.batting_modifier() * weather.batting_modifier()

        # Choose ball type
        is_spinner = "spin" in bowler.bowling_style
        if is_spinner:
            bowl_skill_adj = clamp(bowl_skill * spin_mod, 0, 1.5)
        else:
            bowl_skill_adj = clamp(bowl_skill * seam_mod, 0, 1.5)

        bat_skill_adj = clamp(bat_skill * bat_env, 0, 1.5)

        # Personal form modifiers
        confidence_mod = batsman.personal.confidence / 100
        fatigue_pen    = 1.0 - (batsman.personal.fatigue / 200)
        pressure_mod   = 1.0 - (bowler.personal.fatigue / 300)

        effective_bat  = bat_skill_adj * confidence_mod * fatigue_pen
        effective_bowl = bowl_skill_adj * pressure_mod

        # Manager override (manager-as-player mode)
        if manager_override:
            if manager_override.get("big_shot"):
                effective_bat *= 1.3
                d.ball_type = "big_shot"
            if manager_override.get("leave"):
                d.runs    = 0
                d.beaten  = chance(0.15)
                return d
            if manager_override.get("play_safely"):
                effective_bat *= 0.8

        # ── Wicket probability ────────────────────────────────────────────────
        matchup = effective_bowl / (effective_bat + 0.001)
        wicket_prob = clamp(matchup * 0.08 + (innings_num - 1) * 0.005, 0.01, 0.30)

        # Over-specific adjustments
        if over < 6:   wicket_prob *= 1.15   # powerplay seam
        if over >= 35: wicket_prob *= 1.10   # pressure overs

        if chance(wicket_prob):
            d.wicket    = True
            d.dismissal = self._choose_dismissal(bowler, batsman, is_spinner)
            d.runs       = 0
            return d

        # ── Runs probability ─────────────────────────────────────────────────
        dot_prob = clamp(effective_bowl * 0.45 - effective_bat * 0.15, 0.20, 0.70)
        six_prob = clamp(effective_bat * 0.04 * (1.2 if required_rr > 10 else 1.0), 0.005, 0.12)
        four_prob = clamp(effective_bat * 0.12, 0.05, 0.22)
        two_prob  = clamp(effective_bat * 0.08, 0.02, 0.15)
        single_prob = 1 - dot_prob - six_prob - four_prob - two_prob

        runs_dist = [0, 1, 2, 3, 4, 6]
        probs     = [dot_prob, single_prob, two_prob, 0.02, four_prob, six_prob]
        probs     = [max(0, p) for p in probs]
        total_p   = sum(probs)
        probs     = [p / total_p for p in probs]

        d.runs = random.choices(runs_dist, weights=probs, k=1)[0]

        # Wide/no-ball extras
        if chance(0.025):
            d.extras = 1

        # Beaten outside edge
        if d.runs == 0 and not d.wicket:
            d.beaten = chance(0.12 * effective_bowl)

        return d

    def _choose_dismissal(self, bowler: Player, batsman: Player, is_spinner: bool) -> str:
        if is_spinner:
            options  = ["bowled", "caught", "lbw", "stumped", "run_out"]
            weights  = [0.20, 0.35, 0.25, 0.10, 0.10]
        else:
            options  = ["bowled", "caught", "lbw", "caught_behind", "run_out"]
            weights  = [0.25, 0.30, 0.25, 0.12, 0.08]
        return random.choices(options, weights=weights, k=1)[0]


# ── AI Tactics ────────────────────────────────────────────────────────────────
class AITacticsEngine:
    """Adapts field placements, bowling changes, batting approach."""

    def choose_bowler(
        self,
        team: Team,
        innings: InningsState,
        pitch: PitchState,
        weather: WeatherState,
        last_bowler_id: Optional[str],
    ) -> Player:
        """Select the best bowler for current conditions."""
        available = [p for p in team.squad if p.is_available()
                     and p.role in ("bowler", "allrounder")
                     and p.id != last_bowler_id]
        if not available:
            available = [p for p in team.squad if p.role in ("bowler", "allrounder")]
        if not available:
            available = team.squad

        def score(p: Player) -> float:
            s = p.bowling_rating
            if "seam" in p.bowling_style or "fast" in p.bowling_style:
                s *= pitch.seam_modifier() * weather.swing_modifier()
            elif "spin" in p.bowling_style:
                s *= pitch.spin_modifier() * weather.spin_modifier()
            # Prefer a fresh bowler
            bowl_stats = innings.bowling_stats.get(p.id, {})
            overs_so_far = bowl_stats.get("overs", 0)
            if overs_so_far > 8:
                s *= 0.7
            return s

        return max(available, key=score)

    def batting_strategy(
        self,
        innings: InningsState,
        match_type: str,
        target: int = 0,
        overs_left: int = 50,
    ) -> str:
        """Return a batting strategy label."""
        if match_type == "t20":
            if innings.overs < 6:
                return "attacking"
            if innings.wickets >= 7:
                return "consolidate"
            return "aggressive"
        elif match_type == "odi":
            required_rr = (target - innings.runs) / max(overs_left, 1)
            if required_rr > 12:
                return "ultra_attacking"
            if required_rr < 5:
                return "steady"
            return "balanced"
        else:  # test
            if innings.wickets < 3 and target == 0:
                return "steady"
            if innings.wickets >= 7:
                return "survival"
            return "balanced"

    def should_declare(self, innings: InningsState, lead: int, overs_remaining: int) -> bool:
        """Decide whether to declare in a Test match."""
        return lead > 200 and overs_remaining > 80 and innings.runs > 350


# ── Match engine ──────────────────────────────────────────────────────────────
class MatchEngine:
    def __init__(self):
        self.delivery_engine = DeliveryEngine()
        self.ai_tactics      = AITacticsEngine()
        self.event_engine    = EventEngine()

    def simulate_match(
        self,
        home: Team,
        away: Team,
        match_type: str,
        venue: str = "TBA",
        manager_team_id: Optional[str] = None,
        manager_as_player_id: Optional[str] = None,
    ) -> dict:
        """Run a complete match simulation. Returns a match record dict."""

        cfg_type = MATCH_TYPES.get(match_type, MATCH_TYPES["odi"])
        max_overs = cfg_type["overs"]
        num_innings = cfg_type["innings"]

        # Pitch and weather setup
        pitch   = random_pitch(venue)
        weather = WeatherState()
        weather.advance()

        # Generate pre-match events
        all_players = home.squad + away.squad
        events = self.event_engine.generate_match_events(all_players, weather, pitch, 2024)

        match_id    = make_id("mt")
        innings_log = []
        result      = {"winner": None, "margin": None, "type": None}
        first_team, second_team = home, away

        # ── Toss ─────────────────────────────────────────────────────────────
        toss_winner = random.choice([home, away])
        toss_choice = "bat" if (pitch.pitch_type == "flat" or
                                pitch.batting_modifier() > 1.1) else "bowl"
        batting_first  = first_team if toss_winner == first_team else second_team
        bowling_first  = second_team if batting_first == first_team else first_team

        innings_teams = ([(batting_first, bowling_first), (bowling_first, batting_first)]
                         if num_innings == 1
                         else [(batting_first, bowling_first), (bowling_first, batting_first),
                               (batting_first, bowling_first), (bowling_first, batting_first)][:num_innings * 2])

        target = 0
        for innings_num, (bat_team, bowl_team) in enumerate(innings_teams, 1):
            if innings_num == 2 and len(innings_log) >= 1:
                target = innings_log[0]["runs"] + 1

            innings = self._simulate_innings(
                bat_team, bowl_team, match_type, pitch, weather,
                innings_num, max_overs, target,
                manager_team_id, manager_as_player_id,
            )
            innings_log.append(innings)
            pitch.advance_day(weather)
            weather.advance()

            # Target for second innings of test match (3rd innings sets target)
            if match_type in ("test", "county") and innings_num == 3 and len(innings_log) >= 2:
                runs_team1 = sum(i["runs"] for i in innings_log[0::2])
                runs_team2 = innings_log[1]["runs"]
                target = runs_team1 - runs_team2 + 1

        # ── Determine result ──────────────────────────────────────────────────
        if num_innings == 1:
            if len(innings_log) >= 2:
                r1, r2 = innings_log[0]["runs"], innings_log[1]["runs"]
                w2     = innings_log[1]["wickets"]
                if r2 > r1:
                    result = {"winner": away.name, "margin": f"{10 - w2} wickets", "type": "wickets"}
                elif r1 > r2:
                    result = {"winner": home.name, "margin": f"{r1 - r2} runs", "type": "runs"}
                else:
                    result = {"winner": "Tie", "margin": "0 runs", "type": "tie"}
        else:
            # Test match
            runs1 = sum(i["runs"] for i in innings_log[0::2])
            runs2 = sum(i["runs"] for i in innings_log[1::2])
            if runs1 > runs2:
                result = {"winner": batting_first.name, "margin": f"{runs1-runs2} runs", "type": "runs"}
            elif runs2 > runs1:
                result = {"winner": bowling_first.name, "margin": f"{10-innings_log[-1]['wickets']} wickets", "type": "wickets"}
            else:
                result = {"winner": "Draw", "margin": "0", "type": "draw"}

        # Update player stats
        self._update_player_stats(home, away, innings_log)

        # Generate match events
        self.event_engine.auto_resolve_all()

        match_record = {
            "id":          match_id,
            "home_team_id": home.id,
            "away_team_id": away.id,
            "match_type":  match_type,
            "venue":       venue,
            "date":        "2024-01-01",
            "status":      "completed",
            "result":      result,
            "innings":     innings_log,
            "events":      [{"id": e.id, "title": e.title, "type": e.event_type}
                            for e in self.event_engine.resolved[-5:]],
            "weather":     weather.as_dict(),
            "pitch":       pitch.as_dict(),
            "toss":        {"winner": toss_winner.name, "choice": toss_choice},
        }

        log.info(f"Match {match_id}: {home.name} v {away.name} [{match_type}] → {result['winner']}")
        return match_record

    def _simulate_innings(
        self,
        bat_team: Team,
        bowl_team: Team,
        match_type: str,
        pitch: PitchState,
        weather: WeatherState,
        innings_num: int,
        max_overs: Optional[int],
        target: int,
        manager_team_id: Optional[str],
        manager_as_player_id: Optional[str],
    ) -> dict:
        xi_bat  = bat_team.best_xi()
        xi_bowl = bowl_team.best_xi()

        innings = InningsState(
            team_id=bat_team.id,
            batting_order=[p.id for p in xi_bat],
        )
        innings.batting_stats = {p.id: {"runs": 0, "balls": 0, "4s": 0, "6s": 0} for p in xi_bat}

        # Build bowler rotation
        bowlers = [p for p in xi_bowl if p.role in ("bowler", "allrounder")]
        if not bowlers:
            bowlers = xi_bowl[:4]

        last_bowler_id: Optional[str] = None
        overs_target = max_overs or (90 * 6)   # Test: ~90 overs per day

        batsmen_by_id = {p.id: p for p in xi_bat}
        bowlers_by_id = {p.id: p for p in xi_bowl}

        current_bat1_idx = 0
        current_bat2_idx = 1
        over = 0

        while (not innings.is_all_out()
               and over < overs_target
               and (target == 0 or innings.runs < target)):

            # Weather interruption
            if not weather.play_possible:
                log.debug("Play suspended due to weather")
                weather.advance()
                continue

            # Choose bowler
            bowler = self.ai_tactics.choose_bowler(
                bowl_team, innings, pitch, weather, last_bowler_id
            )
            last_bowler_id = bowler.id

            # Strategy
            overs_left  = overs_target - over
            strategy    = self.ai_tactics.batting_strategy(innings, match_type, target, overs_left)

            for ball_in_over in range(6):
                if innings.is_all_out():
                    break
                if max_overs and over >= max_overs:
                    break
                if target > 0 and innings.runs >= target:
                    break

                # Current batsmen
                if current_bat1_idx >= len(xi_bat) or current_bat2_idx >= len(xi_bat):
                    break
                batsman = xi_bat[current_bat1_idx]

                # Manager-as-player override
                manager_override = None
                if (manager_as_player_id and
                        batsman.id == manager_as_player_id and
                        bat_team.id == manager_team_id):
                    manager_override = self._get_manager_input(innings, over, strategy)

                d = self.delivery_engine.simulate(
                    bowler, batsman, weather, pitch,
                    innings_num, over,
                    required_rr=(target - innings.runs) / max(overs_left, 1) if target else 0,
                    manager_override=manager_override,
                )
                innings.add_delivery(d)

                if d.wicket:
                    current_bat1_idx = innings.batting_pos
                    if current_bat1_idx >= len(xi_bat) - 1:
                        break

                # Rotate strike (odd runs)
                if d.runs % 2 == 1:
                    current_bat1_idx, current_bat2_idx = current_bat2_idx, current_bat1_idx

                # Apply fatigue
                batsman.personal.apply_fatigue(0.3)
                bowler.personal.apply_fatigue(0.5)

            # Rotate strike at end of over
            current_bat1_idx, current_bat2_idx = current_bat2_idx, current_bat1_idx

            # Declare?
            if match_type in ("test", "county") and innings_num == 1:
                lead = innings.runs - target
                overs_remaining = overs_target - over
                if self.ai_tactics.should_declare(innings, lead, overs_remaining):
                    log.info(f"Declaration: {bat_team.name} {innings.runs}/{innings.wickets}")
                    break

            over += 1
            weather.advance()

        # Build innings summary
        top_scorer_id = max(innings.batting_stats, key=lambda pid: innings.batting_stats[pid]["runs"]) if innings.batting_stats else ""
        top_bowler_id = max(innings.bowling_stats, key=lambda pid: innings.bowling_stats[pid]["wkts"]) if innings.bowling_stats else ""

        return {
            "team_id":    bat_team.id,
            "team_name":  bat_team.name,
            "runs":       innings.runs,
            "wickets":    innings.wickets,
            "overs":      round(innings.overs + innings.balls / 6, 1),
            "rr":         round(innings.current_rr, 2),
            "fow":        innings.fow,
            "batting":    innings.batting_stats,
            "bowling":    innings.bowling_stats,
            "top_scorer": top_scorer_id,
            "top_bowler": top_bowler_id,
        }

    def _get_manager_input(self, innings: InningsState, over: int, strategy: str) -> dict:
        """Return manager decision (console input in non-GUI mode)."""
        # In GUI mode this is driven by the frontend; here we return AI suggestion
        if strategy == "attacking" or innings.wickets < 3:
            return {"big_shot": chance(0.2)}
        if innings.wickets >= 7:
            return {"play_safely": True}
        return {}

    def _update_player_stats(self, home: Team, away: Team, innings_log: list[dict]):
        """Push innings statistics back to player objects."""
        all_players = {p.id: p for p in home.squad + away.squad}
        for innings in innings_log:
            for pid, bstats in innings.get("batting", {}).items():
                if pid in all_players:
                    p = all_players[pid]
                    p.stats.innings    += 1
                    p.stats.runs       += bstats["runs"]
                    p.stats.high_score  = max(p.stats.high_score, bstats["runs"])
                    if bstats["runs"] >= 100:
                        p.stats.centuries += 1
                    elif bstats["runs"] >= 50:
                        p.stats.fifties += 1
                    p.stats.update_batting_average()

            for pid, bwstats in innings.get("bowling", {}).items():
                if pid in all_players:
                    p = all_players[pid]
                    p.stats.wickets      += bwstats["wkts"]
                    p.stats.overs_bowled += bwstats["overs"]
                    runs_this = bwstats.get("runs", 0)
                    if bwstats["wkts"] >= 5:
                        p.stats.five_fers += 1


# ── Convenience function ──────────────────────────────────────────────────────
def quick_match(home: Team, away: Team, match_type: str = "odi", venue: str = "TBA") -> dict:
    engine = MatchEngine()
    return engine.simulate_match(home, away, match_type, venue)
