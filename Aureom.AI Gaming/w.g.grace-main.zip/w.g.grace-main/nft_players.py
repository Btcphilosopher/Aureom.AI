"""nft_players.py — NFT creation, metadata, and blockchain integration stubs"""

from __future__ import annotations
import json
import hashlib
import time
from typing import Optional
from .utils import make_id, get_logger, cfg
from .career import Player

log = get_logger("nft_players")


# ── NFT Metadata schema ────────────────────────────────────────────────────────
def build_nft_metadata(player: Player, minted_by: str = "system") -> dict:
    """Build standard NFT metadata for a superstar player."""
    return {
        "name":        f"W.G.Grace-1 #{player.id} — {player.name}",
        "description": (
            f"{player.name} ({player.nationality}) — {player.role.title()}. "
            f"Overall: {player.overall_rating}. "
            f"Career: {player.stats.runs} runs, {player.stats.wickets} wickets."
        ),
        "image":       f"ipfs://wggrace1/players/{player.id}.png",
        "external_url": f"https://wggrace1.example.com/player/{player.id}",
        "attributes": [
            {"trait_type": "Nationality",    "value": player.nationality},
            {"trait_type": "Role",           "value": player.role.title()},
            {"trait_type": "Overall Rating", "value": player.overall_rating, "display_type": "number"},
            {"trait_type": "Batting",        "value": player.batting_rating, "display_type": "number"},
            {"trait_type": "Bowling",        "value": player.bowling_rating, "display_type": "number"},
            {"trait_type": "Age",            "value": player.personal.age,   "display_type": "number"},
            {"trait_type": "Reputation",     "value": player.personal.reputation, "display_type": "number"},
            {"trait_type": "Career Runs",    "value": player.stats.runs,     "display_type": "number"},
            {"trait_type": "Career Wickets", "value": player.stats.wickets,  "display_type": "number"},
            {"trait_type": "Batting Style",  "value": player.batting_style},
            {"trait_type": "Bowling Style",  "value": player.bowling_style},
            {"trait_type": "Personality",    "value": player.personal.personality.title()},
        ],
        "minted_by":   minted_by,
        "mint_time":   int(time.time()),
        "version":     "1.0",
    }


def compute_token_id(player: Player) -> str:
    """Deterministic token ID from player identity."""
    seed = f"{player.id}{player.name}{player.nationality}{player.personal.age}"
    return "nft_" + hashlib.sha256(seed.encode()).hexdigest()[:16]


# ── NFT Registry ──────────────────────────────────────────────────────────────
class NFTRegistry:
    """In-memory NFT registry (persisted via database.py in production)."""

    def __init__(self):
        self.tokens: dict[str, dict] = {}   # token_id → record

    def mint(self, player: Player, owner_address: str = "manager_wallet") -> dict:
        if player.nft_token_id:
            log.warning(f"{player.name} already has NFT: {player.nft_token_id}")
            return self.tokens.get(player.nft_token_id, {})

        token_id = compute_token_id(player)
        metadata = build_nft_metadata(player, minted_by=owner_address)
        record   = {
            "token_id":      token_id,
            "player_id":     player.id,
            "owner_address": owner_address,
            "metadata":      metadata,
            "mint_tx":       f"mock_tx_{make_id('tx')}",
            "mint_fee_sats": cfg("blockchain.nft_mint_fee_sats", 1000),
            "for_sale":      False,
            "ask_sats":      0,
            "mint_time":     int(time.time()),
        }
        self.tokens[token_id] = record
        player.nft_token_id   = token_id
        log.info(f"Minted NFT {token_id} for {player.name} → owner: {owner_address}")
        return record

    def list_for_sale(self, token_id: str, ask_sats: int) -> bool:
        if token_id not in self.tokens:
            return False
        self.tokens[token_id]["for_sale"] = True
        self.tokens[token_id]["ask_sats"] = ask_sats
        log.info(f"NFT {token_id} listed for {ask_sats} sats")
        return True

    def transfer(self, token_id: str, new_owner: str, paid_sats: int) -> Optional[dict]:
        if token_id not in self.tokens:
            log.error(f"Token {token_id} not found")
            return None
        record = self.tokens[token_id]
        if record.get("ask_sats", 0) > paid_sats:
            log.warning(f"Insufficient payment: need {record['ask_sats']}, got {paid_sats}")
            return None
        record["owner_address"] = new_owner
        record["for_sale"]      = False
        record["last_sale_sats"] = paid_sats
        log.info(f"Transferred NFT {token_id} to {new_owner} for {paid_sats} sats")
        return record

    def get_marketplace(self) -> list[dict]:
        return [r for r in self.tokens.values() if r.get("for_sale")]

    def get_owned(self, owner: str) -> list[dict]:
        return [r for r in self.tokens.values() if r["owner_address"] == owner]

    def get_by_player(self, player_id: str) -> Optional[dict]:
        for r in self.tokens.values():
            if r["player_id"] == player_id:
                return r
        return None

    def summary(self) -> dict:
        sales = [r for r in self.tokens.values() if r.get("last_sale_sats")]
        return {
            "total_minted":    len(self.tokens),
            "for_sale":        len(self.get_marketplace()),
            "total_volume_sats": sum(r.get("last_sale_sats", 0) for r in sales),
            "avg_price_sats":  (sum(r.get("last_sale_sats", 0) for r in sales) //
                                max(len(sales), 1)),
        }


# ── Global registry singleton ─────────────────────────────────────────────────
_registry: Optional[NFTRegistry] = None

def get_registry() -> NFTRegistry:
    global _registry
    if _registry is None:
        _registry = NFTRegistry()
    return _registry


# ── Eligibility check ─────────────────────────────────────────────────────────
def is_nft_eligible(player: Player) -> bool:
    """Only elite international players are NFT-mintable."""
    return player.overall_rating >= 65 and player.personal.reputation >= 40
