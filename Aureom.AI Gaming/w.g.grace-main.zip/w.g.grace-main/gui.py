"""gui.py — Anglo-futurist PyQt6 dashboard for W.G.Grace-1"""

from __future__ import annotations
import sys
import json
import random
from typing import Optional
from .utils import get_logger, cfg
from .career import Team, Player, CareerManager
from .match_sim import MatchEngine
from .analytics import build_dashboard_data, team_batting_depth, team_bowling_strength
from .commentary import CommentaryEngine, PodcastEngine, MediaEngine
from .events import EventEngine
from .data_loader import create_international_teams, create_county_teams

log = get_logger("gui")

# ── Defer PyQt6 import so game still runs without it ─────────────────────────
try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QTabWidget, QTableWidget, QTableWidgetItem,
        QTextEdit, QSplitter, QFrame, QScrollArea, QProgressBar,
        QComboBox, QSpinBox, QGroupBox, QDialog, QDialogButtonBox,
        QListWidget, QListWidgetItem, QStatusBar, QToolBar, QAction,
        QMessageBox, QFileDialog, QGridLayout, QSizePolicy,
    )
    from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QSize
    from PyQt6.QtGui import (
        QFont, QColor, QPalette, QIcon, QPixmap, QBrush,
        QPainter, QLinearGradient,
    )
    HAS_PYQT = True
except ImportError:
    HAS_PYQT = False
    log.warning("PyQt6 not installed — GUI disabled. Install with: pip install PyQt6")


# ── Colour palette (Anglo-Futurist) ───────────────────────────────────────────
PALETTE = {
    "bg_dark":    "#0a0c0f",
    "bg_mid":     "#111418",
    "bg_panel":   "#161b22",
    "accent_gold":"#c9a84c",
    "accent_cyan":"#00e5ff",
    "accent_red": "#e53935",
    "accent_grn": "#00c853",
    "text_main":  "#e8e8e8",
    "text_dim":   "#7a8390",
    "border":     "#2a3140",
    "highlight":  "#1e2840",
}

STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: {PALETTE['bg_dark']};
    color: {PALETTE['text_main']};
    font-family: 'DM Mono', 'Courier New', monospace;
    font-size: 13px;
}}
QTabWidget::pane {{
    border: 1px solid {PALETTE['border']};
    background: {PALETTE['bg_panel']};
}}
QTabBar::tab {{
    background: {PALETTE['bg_mid']};
    color: {PALETTE['text_dim']};
    padding: 8px 20px;
    border: 1px solid {PALETTE['border']};
    font-family: 'Bebas Neue', 'DM Mono', monospace;
    font-size: 14px;
    letter-spacing: 2px;
    text-transform: uppercase;
}}
QTabBar::tab:selected {{
    background: {PALETTE['highlight']};
    color: {PALETTE['accent_gold']};
    border-bottom: 2px solid {PALETTE['accent_gold']};
}}
QPushButton {{
    background: {PALETTE['bg_panel']};
    color: {PALETTE['accent_gold']};
    border: 1px solid {PALETTE['accent_gold']};
    padding: 8px 16px;
    font-family: 'Bebas Neue', monospace;
    font-size: 14px;
    letter-spacing: 2px;
}}
QPushButton:hover {{
    background: {PALETTE['accent_gold']};
    color: {PALETTE['bg_dark']};
}}
QPushButton:pressed {{
    background: #a07830;
}}
QPushButton#danger {{
    color: {PALETTE['accent_red']};
    border-color: {PALETTE['accent_red']};
}}
QPushButton#success {{
    color: {PALETTE['accent_grn']};
    border-color: {PALETTE['accent_grn']};
}}
QTableWidget {{
    background: {PALETTE['bg_panel']};
    gridline-color: {PALETTE['border']};
    color: {PALETTE['text_main']};
    selection-background-color: {PALETTE['highlight']};
    border: 1px solid {PALETTE['border']};
}}
QTableWidget::item:selected {{
    background: {PALETTE['highlight']};
    color: {PALETTE['accent_gold']};
}}
QHeaderView::section {{
    background: {PALETTE['bg_mid']};
    color: {PALETTE['accent_cyan']};
    padding: 6px;
    border: 1px solid {PALETTE['border']};
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    letter-spacing: 1px;
    text-transform: uppercase;
}}
QTextEdit {{
    background: {PALETTE['bg_panel']};
    color: {PALETTE['text_main']};
    border: 1px solid {PALETTE['border']};
    font-family: 'DM Mono', 'Courier New', monospace;
    font-size: 12px;
}}
QLabel#title {{
    color: {PALETTE['accent_gold']};
    font-family: 'Bebas Neue', monospace;
    font-size: 22px;
    letter-spacing: 4px;
}}
QLabel#subtitle {{
    color: {PALETTE['accent_cyan']};
    font-size: 11px;
    letter-spacing: 2px;
}}
QLabel#stat {{
    color: {PALETTE['text_main']};
    font-size: 24px;
    font-family: 'Bebas Neue', monospace;
}}
QGroupBox {{
    border: 1px solid {PALETTE['border']};
    margin-top: 8px;
    padding-top: 10px;
    color: {PALETTE['accent_gold']};
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    letter-spacing: 2px;
    text-transform: uppercase;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
}}
QProgressBar {{
    border: 1px solid {PALETTE['border']};
    background: {PALETTE['bg_mid']};
    text-align: center;
    color: {PALETTE['text_main']};
    height: 14px;
}}
QProgressBar::chunk {{
    background: {PALETTE['accent_gold']};
}}
QScrollBar:vertical {{
    background: {PALETTE['bg_mid']};
    width: 8px;
    border: none;
}}
QScrollBar::handle:vertical {{
    background: {PALETTE['accent_gold']};
    min-height: 20px;
}}
QComboBox {{
    background: {PALETTE['bg_panel']};
    color: {PALETTE['text_main']};
    border: 1px solid {PALETTE['border']};
    padding: 4px 8px;
}}
QComboBox:drop-down {{
    border: none;
}}
QStatusBar {{
    background: {PALETTE['bg_mid']};
    color: {PALETTE['text_dim']};
    border-top: 1px solid {PALETTE['border']};
}}
"""


if HAS_PYQT:

    # ── Stat card widget ──────────────────────────────────────────────────────
    class StatCard(QFrame):
        def __init__(self, label: str, value: str, color: str = PALETTE["accent_gold"]):
            super().__init__()
            self.setFrameShape(QFrame.Shape.StyledPanel)
            self.setStyleSheet(f"QFrame {{ background: {PALETTE['bg_panel']}; "
                               f"border: 1px solid {PALETTE['border']}; padding: 8px; }}")
            layout = QVBoxLayout(self)
            lbl = QLabel(label)
            lbl.setObjectName("subtitle")
            val = QLabel(value)
            val.setObjectName("stat")
            val.setStyleSheet(f"color: {color}; font-size: 28px;")
            layout.addWidget(lbl)
            layout.addWidget(val)

        def set_value(self, v: str):
            self.findChild(QLabel, "").setText(v)


    # ── Squad table ──────────────────────────────────────────────────────────
    class SquadTable(QTableWidget):
        COLUMNS = ["Name", "Nationality", "Role", "Bat", "Bowl", "OVR", "Age", "Form"]

        def __init__(self):
            super().__init__(0, len(self.COLUMNS))
            self.setHorizontalHeaderLabels(self.COLUMNS)
            self.horizontalHeader().setStretchLastSection(True)
            self.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
            self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            self.verticalHeader().setDefaultSectionSize(26)

        def populate(self, squad: list[Player]):
            self.setRowCount(len(squad))
            for row, p in enumerate(squad):
                vals = [
                    p.name, p.nationality, p.role.title(),
                    str(p.batting_rating), str(p.bowling_rating),
                    str(p.overall_rating), str(p.personal.age),
                    f"{p.personal.confidence:.0f}%",
                ]
                for col, v in enumerate(vals):
                    item = QTableWidgetItem(v)
                    item.setData(Qt.ItemDataRole.UserRole, p.id)
                    # Colour OVR column
                    if col == 5:
                        ovr = float(v)
                        c = PALETTE["accent_grn"] if ovr >= 75 else (
                            PALETTE["accent_gold"] if ovr >= 60 else PALETTE["accent_red"])
                        item.setForeground(QBrush(QColor(c)))
                    self.setItem(row, col, item)


    # ── Match result widget ───────────────────────────────────────────────────
    class MatchResultWidget(QFrame):
        def __init__(self):
            super().__init__()
            self.setStyleSheet(f"QFrame {{ background: {PALETTE['bg_panel']}; "
                               f"border: 1px solid {PALETTE['border']}; }}")
            self._layout = QVBoxLayout(self)
            self._title  = QLabel("MATCH RESULT")
            self._title.setObjectName("title")
            self._body   = QTextEdit()
            self._body.setReadOnly(True)
            self._layout.addWidget(self._title)
            self._layout.addWidget(self._body)

        def show_result(self, match: dict):
            result  = match.get("result", {})
            innings = match.get("innings", [])
            lines   = []
            lines.append(f"{'─'*50}")
            lines.append(f"  {match.get('home_team_id','?')} v {match.get('away_team_id','?')}")
            lines.append(f"  Type: {match.get('match_type','?').upper()}  |  Venue: {match.get('venue','?')}")
            lines.append(f"  Toss: {match.get('toss',{}).get('winner','?')} elected to {match.get('toss',{}).get('choice','?')}")
            lines.append(f"{'─'*50}")
            for inn in innings:
                lines.append(f"  {inn.get('team_name','?')}: "
                              f"{inn.get('runs',0)}/{inn.get('wickets',0)} "
                              f"({inn.get('overs',0)} ov)  RR {inn.get('rr',0)}")
            lines.append(f"{'─'*50}")
            winner = result.get("winner","?")
            margin = result.get("margin","")
            lines.append(f"  RESULT: {winner} win by {margin}" if margin else f"  RESULT: {winner}")
            lines.append(f"{'─'*50}")
            lines.append(f"  Weather: {match.get('weather',{}).get('current','?')}")
            lines.append(f"  Pitch:   {match.get('pitch',{}).get('pitch_type','?')}")
            self._body.setText("\n".join(lines))


    # ── Main Window ───────────────────────────────────────────────────────────
    class WGGraceMainWindow(QMainWindow):

        def __init__(self):
            super().__init__()
            self.setWindowTitle("W.G.GRACE-1  ◆  CRICKET MANAGEMENT SIMULATION")
            self.setMinimumSize(1400, 900)
            self.setStyleSheet(STYLESHEET)

            # Game state
            self.teams:   dict[str, Team] = {}
            self.managed: Optional[Team]  = None
            self.career:  Optional[CareerManager] = None
            self.engine   = MatchEngine()
            self.commentary = CommentaryEngine()
            self.media    = MediaEngine()
            self.match_history: list[dict] = []

            self._build_ui()
            self._load_default_game()

        # ── UI construction ────────────────────────────────────────────────
        def _build_ui(self):
            central = QWidget()
            self.setCentralWidget(central)
            root = QVBoxLayout(central)
            root.setContentsMargins(0, 0, 0, 0)
            root.setSpacing(0)

            # Header bar
            header = self._build_header()
            root.addWidget(header)

            # Main tabs
            self.tabs = QTabWidget()
            self.tabs.addTab(self._build_dashboard_tab(), "DASHBOARD")
            self.tabs.addTab(self._build_squad_tab(),     "SQUAD")
            self.tabs.addTab(self._build_match_tab(),     "MATCH SIM")
            self.tabs.addTab(self._build_analytics_tab(),"ANALYTICS")
            self.tabs.addTab(self._build_events_tab(),    "EVENTS")
            self.tabs.addTab(self._build_media_tab(),     "MEDIA")
            self.tabs.addTab(self._build_nft_tab(),       "NFT MARKET")
            self.tabs.addTab(self._build_career_tab(),    "CAREER")
            root.addWidget(self.tabs)

            # Status bar
            self.statusBar().showMessage("W.G.Grace-1 v1.0.0  ◆  Season 2024  ◆  Ready")

        def _build_header(self) -> QWidget:
            w = QWidget()
            w.setFixedHeight(64)
            w.setStyleSheet(f"background: {PALETTE['bg_mid']}; "
                            f"border-bottom: 2px solid {PALETTE['accent_gold']};")
            layout = QHBoxLayout(w)
            layout.setContentsMargins(20, 0, 20, 0)

            title = QLabel("W . G . G R A C E - 1")
            title.setObjectName("title")
            title.setStyleSheet(f"color: {PALETTE['accent_gold']}; "
                                "font-family: 'Bebas Neue', monospace; font-size: 28px; letter-spacing: 8px;")

            subtitle = QLabel("CRICKET MANAGEMENT & SIMULATION  |  ANGLO-FUTURIST EDITION")
            subtitle.setObjectName("subtitle")

            self.season_label = QLabel("SEASON: 2024")
            self.season_label.setStyleSheet(f"color: {PALETTE['accent_cyan']}; font-size: 14px; letter-spacing: 2px;")

            layout.addWidget(title)
            layout.addStretch()
            layout.addWidget(subtitle)
            layout.addStretch()
            layout.addWidget(self.season_label)
            return w

        def _build_dashboard_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)

            # Stat cards row
            self.stat_cards_layout = QHBoxLayout()
            self._stats_widgets: dict[str, QLabel] = {}
            for label, val, col in [
                ("MANAGED TEAM",    "—",    PALETTE["accent_gold"]),
                ("SQUAD SIZE",      "0",    PALETTE["accent_cyan"]),
                ("MATCHES PLAYED",  "0",    PALETTE["text_main"]),
                ("WIN RATE",        "—%",   PALETTE["accent_grn"]),
                ("BUDGET",          "£0",   PALETTE["accent_gold"]),
                ("SEASON",          "2024", PALETTE["accent_cyan"]),
            ]:
                card = QGroupBox(label)
                card_l = QVBoxLayout(card)
                val_lbl = QLabel(val)
                val_lbl.setStyleSheet(f"color: {col}; font-family: 'Bebas Neue', monospace; font-size: 28px;")
                card_l.addWidget(val_lbl, alignment=Qt.AlignmentFlag.AlignCenter)
                self._stats_widgets[label] = val_lbl
                self.stat_cards_layout.addWidget(card)
            layout.addLayout(self.stat_cards_layout)

            # Recent results
            recent_box = QGroupBox("RECENT RESULTS")
            recent_l = QVBoxLayout(recent_box)
            self.recent_results = QTextEdit()
            self.recent_results.setReadOnly(True)
            self.recent_results.setMaximumHeight(180)
            self.recent_results.setPlaceholderText("No matches played yet...")
            recent_l.addWidget(self.recent_results)
            layout.addWidget(recent_box)

            # Quick actions
            actions = QGroupBox("QUICK ACTIONS")
            act_l = QHBoxLayout(actions)
            for txt, handler in [
                ("SIMULATE MATCH",    self._quick_sim_match),
                ("NEXT SEASON",       self._advance_season),
                ("SCOUT PLAYERS",     self._scout_players),
                ("VIEW STANDINGS",    self._show_standings),
            ]:
                btn = QPushButton(txt)
                btn.clicked.connect(handler)
                act_l.addWidget(btn)
            layout.addWidget(actions)
            layout.addStretch()
            return w

        def _build_squad_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)

            # Team selector
            top = QHBoxLayout()
            top.addWidget(QLabel("TEAM:"))
            self.team_combo = QComboBox()
            self.team_combo.currentTextChanged.connect(self._on_team_changed)
            top.addWidget(self.team_combo)
            top.addStretch()

            release_btn = QPushButton("RELEASE PLAYER")
            release_btn.setObjectName("danger")
            release_btn.clicked.connect(self._release_selected_player)
            top.addWidget(release_btn)
            layout.addLayout(top)

            self.squad_table = SquadTable()
            layout.addWidget(self.squad_table)

            # Player detail panel
            detail_box = QGroupBox("PLAYER PROFILE")
            detail_l = QHBoxLayout(detail_box)
            self.player_detail = QTextEdit()
            self.player_detail.setReadOnly(True)
            self.player_detail.setMaximumHeight(160)
            detail_l.addWidget(self.player_detail)
            layout.addWidget(detail_box)

            self.squad_table.itemSelectionChanged.connect(self._show_player_detail)
            return w

        def _build_match_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)

            # Match setup
            setup = QGroupBox("MATCH SETUP")
            setup_l = QGridLayout(setup)
            setup_l.addWidget(QLabel("HOME:"),       0, 0)
            self.home_combo = QComboBox()
            setup_l.addWidget(self.home_combo,        0, 1)
            setup_l.addWidget(QLabel("AWAY:"),       0, 2)
            self.away_combo = QComboBox()
            setup_l.addWidget(self.away_combo,        0, 3)
            setup_l.addWidget(QLabel("TYPE:"),       1, 0)
            self.match_type_combo = QComboBox()
            self.match_type_combo.addItems(["t20", "odi", "test", "county"])
            setup_l.addWidget(self.match_type_combo, 1, 1)
            setup_l.addWidget(QLabel("VENUE:"),      1, 2)
            self.venue_combo = QComboBox()
            setup_l.addWidget(self.venue_combo,       1, 3)
            sim_btn = QPushButton("SIMULATE MATCH")
            sim_btn.clicked.connect(self._sim_match)
            setup_l.addWidget(sim_btn, 2, 0, 1, 4)
            layout.addWidget(setup)

            # Result display
            self.match_result_widget = MatchResultWidget()
            layout.addWidget(self.match_result_widget)

            # Commentary log
            comm_box = QGroupBox("COMMENTARY")
            comm_l = QVBoxLayout(comm_box)
            self.commentary_log = QTextEdit()
            self.commentary_log.setReadOnly(True)
            comm_l.addWidget(self.commentary_log)
            layout.addWidget(comm_box)
            return w

        def _build_analytics_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)

            layout.addWidget(QLabel("TOP BATTERS", objectName="title"))
            self.bat_table = QTableWidget(0, 5)
            self.bat_table.setHorizontalHeaderLabels(["Name", "Runs", "Avg", "HS", "100s"])
            layout.addWidget(self.bat_table)

            layout.addWidget(QLabel("TOP BOWLERS", objectName="title"))
            self.bowl_table = QTableWidget(0, 4)
            self.bowl_table.setHorizontalHeaderLabels(["Name", "Wkts", "Avg", "5-fors"])
            layout.addWidget(self.bowl_table)

            btn = QPushButton("REFRESH ANALYTICS")
            btn.clicked.connect(self._refresh_analytics)
            layout.addWidget(btn)
            return w

        def _build_events_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)
            layout.addWidget(QLabel("PENDING EVENTS", objectName="title"))
            self.events_list = QListWidget()
            layout.addWidget(self.events_list)
            resolve_btn = QPushButton("RESOLVE SELECTED EVENT")
            resolve_btn.clicked.connect(self._resolve_event)
            layout.addWidget(resolve_btn)
            return w

        def _build_media_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)
            layout.addWidget(QLabel("MEDIA HEADLINES", objectName="title"))
            self.headlines_log = QTextEdit()
            self.headlines_log.setReadOnly(True)
            layout.addWidget(self.headlines_log)
            btn = QPushButton("GENERATE PODCAST")
            btn.clicked.connect(self._generate_podcast)
            layout.addWidget(btn)
            return w

        def _build_nft_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)
            layout.addWidget(QLabel("NFT MARKETPLACE", objectName="title"))

            info = QLabel("Only elite international players (OVR 75+, 20+ caps) are NFT-eligible.")
            info.setStyleSheet(f"color: {PALETTE['text_dim']};")
            layout.addWidget(info)

            self.nft_table = QTableWidget(0, 5)
            self.nft_table.setHorizontalHeaderLabels(["Player", "OVR", "Owner", "Ask (sats)", "Status"])
            layout.addWidget(self.nft_table)

            btn_row = QHBoxLayout()
            mint_btn = QPushButton("MINT SELECTED PLAYER")
            mint_btn.clicked.connect(self._mint_nft)
            list_btn  = QPushButton("LIST FOR SALE")
            list_btn.clicked.connect(self._list_nft)
            btn_row.addWidget(mint_btn)
            btn_row.addWidget(list_btn)
            layout.addLayout(btn_row)
            return w

        def _build_career_tab(self) -> QWidget:
            w = QWidget()
            layout = QVBoxLayout(w)
            layout.setContentsMargins(16, 16, 16, 16)
            layout.addWidget(QLabel("CAREER OVERVIEW", objectName="title"))
            self.career_log = QTextEdit()
            self.career_log.setReadOnly(True)
            layout.addWidget(self.career_log)
            adv_btn = QPushButton("ADVANCE SEASON")
            adv_btn.clicked.connect(self._advance_season)
            layout.addWidget(adv_btn)
            return w

        # ── Game loading ──────────────────────────────────────────────────
        def _load_default_game(self):
            self.statusBar().showMessage("Loading game data...")
            self.teams = create_international_teams()
            self.teams.update(create_county_teams())

            # Set managed team
            self.managed = self.teams.get("England")
            if self.managed:
                self.career = CareerManager(self.managed)

            # Populate combos
            team_names = sorted(self.teams.keys())
            self.team_combo.addItems(team_names)
            self.home_combo.addItems(team_names)
            self.away_combo.addItems(team_names)
            if "Australia" in team_names:
                self.away_combo.setCurrentText("Australia")

            from .data_loader import STADIUMS
            self.venue_combo.addItems([s["name"] for s in STADIUMS])

            self._refresh_dashboard()
            self.statusBar().showMessage(
                f"Game loaded — {len(self.teams)} teams, "
                f"{sum(len(t.squad) for t in self.teams.values())} players"
            )

        # ── Handlers ─────────────────────────────────────────────────────
        def _on_team_changed(self, name: str):
            t = self.teams.get(name)
            if t:
                self.squad_table.populate(t.squad)

        def _refresh_dashboard(self):
            if not self.managed:
                return
            wins   = sum(1 for m in self.match_history
                         if m.get("result", {}).get("winner") == self.managed.name)
            total  = len(self.match_history)
            wr     = f"{wins/total*100:.0f}%" if total else "—%"
            budget = f"£{self.managed.finances['budget']:,}"

            labels = {
                "MANAGED TEAM":   self.managed.name,
                "SQUAD SIZE":     str(len(self.managed.squad)),
                "MATCHES PLAYED": str(total),
                "WIN RATE":       wr,
                "BUDGET":         budget,
                "SEASON":         str(self.career.season if self.career else 2024),
            }
            for label, val in labels.items():
                if label in self._stats_widgets:
                    self._stats_widgets[label].setText(val)

        def _quick_sim_match(self):
            if not self.managed:
                return
            opponents = [t for n, t in self.teams.items() if t != self.managed]
            if not opponents:
                return
            opp = random.choice(opponents)
            result = self.engine.simulate_match(
                self.managed, opp, "odi", self.managed.home_ground
            )
            self.match_history.append(result)
            r = result["result"]
            self.recent_results.append(
                f"  {self.managed.name} v {opp.name}: {r.get('winner','?')} ({r.get('margin','')})"
            )
            self._refresh_dashboard()
            self._update_headlines()

        def _sim_match(self):
            home_n = self.home_combo.currentText()
            away_n = self.away_combo.currentText()
            mtype  = self.match_type_combo.currentText()
            venue  = self.venue_combo.currentText()
            if home_n == away_n:
                QMessageBox.warning(self, "Error", "Home and Away teams must differ!")
                return
            home = self.teams.get(home_n)
            away = self.teams.get(away_n)
            if not home or not away:
                return

            match = self.engine.simulate_match(home, away, mtype, venue)
            self.match_history.append(match)
            self.match_result_widget.show_result(match)

            # Commentary
            opener = self.commentary.match_opener(home_n, away_n, venue, mtype)
            for inn in match.get("innings", []):
                opener += "\n" + self.commentary.end_of_innings(
                    inn["team_name"], inn["runs"], inn["wickets"], inn["overs"]
                )
            result = match.get("result", {})
            opener += "\n" + self.commentary.match_result(
                result.get("winner","?"), result.get("margin",""), result.get("type","runs")
            )
            self.commentary_log.setText(opener)
            self._refresh_dashboard()
            self._update_headlines()

        def _advance_season(self):
            if self.career:
                self.career.simulate_off_season()
                summary = self.career.season_summary()
                self.season_label.setText(f"SEASON: {self.career.season}")
                self.career_log.append(
                    f"\n{'─'*40}\nSEASON {summary['season']} COMPLETE\n"
                    f"Best bat: {summary['best_bat']}  |  Best bowl: {summary['best_bowl']}\n"
                    f"Budget: £{summary['finances']['budget']:,}\n"
                )
                self._refresh_dashboard()

        def _scout_players(self):
            if self.career:
                agents = self.career.scout_free_agents(5)
                lines  = ["FREE AGENTS AVAILABLE:"]
                for p in agents:
                    lines.append(f"  {p.name} [{p.nationality}] {p.role.title()} OVR={p.overall_rating}")
                QMessageBox.information(self, "Scouting Report", "\n".join(lines))

        def _show_standings(self):
            from .multiplayer import Tournament
            t_list = list(self.teams.values())[:8]
            tour = Tournament("Quick Tournament", t_list, "odi")
            result = tour.play_all()
            lines = ["STANDINGS:"]
            for row in result["standings"]:
                lines.append(f"  {row['pos']:>2}. {row['name']:<20} P:{row['p']} W:{row['w']} L:{row['l']} Pts:{row['pts']}")
            QMessageBox.information(self, "Standings", "\n".join(lines))

        def _release_selected_player(self):
            rows = self.squad_table.selectedItems()
            if not rows:
                return
            pid = rows[0].data(Qt.ItemDataRole.UserRole)
            team_n = self.team_combo.currentText()
            team   = self.teams.get(team_n)
            if team and pid:
                p = team.remove_player(pid)
                if p:
                    self.squad_table.populate(team.squad)
                    self.statusBar().showMessage(f"Released {p.name}")

        def _show_player_detail(self):
            rows = self.squad_table.selectedItems()
            if not rows:
                return
            pid = rows[0].data(Qt.ItemDataRole.UserRole)
            team_n = self.team_combo.currentText()
            team   = self.teams.get(team_n)
            if not team:
                return
            p = next((pl for pl in team.squad if pl.id == pid), None)
            if not p:
                return
            txt = (
                f"  {p.name}  [{p.nationality}]  Age: {p.personal.age}\n"
                f"  Role: {p.role.title()}  |  {p.batting_style}  |  {p.bowling_style}\n"
                f"  Overall: {p.overall_rating}   Bat: {p.batting_rating}   Bowl: {p.bowling_rating}\n"
                f"  Morale: {p.personal.morale:.0f}%  Fatigue: {p.personal.fatigue:.0f}%  "
                f"Confidence: {p.personal.confidence:.0f}%\n"
                f"  Motivation: {p.personal.motivation}  Personality: {p.personal.personality}\n"
                + (f"  ⚠ INJURED: {p.personal.injury} ({p.personal.injury_weeks}w)\n"
                   if p.personal.is_injured() else "  ✓ Available\n")
                + f"  Career: {p.stats.runs} runs @ {p.stats.average}  |  "
                  f"{p.stats.wickets} wkts  |  {p.stats.matches} matches"
            )
            self.player_detail.setText(txt)

        def _refresh_analytics(self):
            if not self.managed:
                return
            data = build_dashboard_data(self.managed, self.match_history, 2024)
            self.bat_table.setRowCount(len(data["top_batters"]))
            for r, p in enumerate(data["top_batters"]):
                for c, v in enumerate([p["name"], str(p["runs"]), str(p["avg"]),
                                        str(p["hs"]), str(p["100s"])]):
                    self.bat_table.setItem(r, c, QTableWidgetItem(v))
            self.bowl_table.setRowCount(len(data["top_bowlers"]))
            for r, p in enumerate(data["top_bowlers"]):
                for c, v in enumerate([p["name"], str(p["wkts"]), str(p["avg"]), str(p["5fers"])]):
                    self.bowl_table.setItem(r, c, QTableWidgetItem(v))

        def _resolve_event(self):
            item = self.events_list.currentItem()
            if item:
                QMessageBox.information(self, "Event Resolved",
                                        f"Resolved: {item.text()}")
                self.events_list.takeItem(self.events_list.row(item))

        def _update_headlines(self):
            if not self.managed:
                return
            teams  = list(self.teams.values())
            headlines = self.media.generate_headlines(
                self.managed.squad, teams,
                venue=self.managed.home_ground, n=5,
            )
            self.headlines_log.append("\n".join(f"  ◆ {h}" for h in headlines) + "\n")

        def _generate_podcast(self):
            if not self.match_history:
                QMessageBox.information(self, "Podcast", "No matches played yet!")
                return
            last = self.match_history[-1]
            pc   = PodcastEngine()
            text = pc.generate_post_match_podcast(
                last.get("home_team_id", "Home"),
                last.get("away_team_id", "Away"),
                last.get("result", {}),
                top_performers=[],
                venue=last.get("venue", "TBA"),
            )
            self.headlines_log.append("\n" + "─"*50 + "\n🎙 PODCAST\n" + text + "\n" + "─"*50)

        def _mint_nft(self):
            from .nft_players import get_registry, is_nft_eligible
            if not self.managed:
                return
            eligible = [p for p in self.managed.squad if is_nft_eligible(p)]
            if not eligible:
                QMessageBox.warning(self, "NFT", "No eligible players (OVR 75+, 20+ caps required).")
                return
            p   = eligible[0]
            reg = get_registry()
            rec = reg.mint(p, owner_address="manager_wallet")
            self._refresh_nft_table()
            QMessageBox.information(self, "NFT Minted",
                                    f"✓ {p.name} minted!\nToken: {rec['token_id']}")

        def _list_nft(self):
            from .nft_players import get_registry
            reg  = get_registry()
            mkt  = reg.get_marketplace()
            if not mkt:
                QMessageBox.information(self, "NFT", "No NFTs listed for sale.")
            self._refresh_nft_table()

        def _refresh_nft_table(self):
            from .nft_players import get_registry
            reg   = get_registry()
            owned = reg.get_owned("manager_wallet")
            self.nft_table.setRowCount(len(owned))
            for r, rec in enumerate(owned):
                pid  = rec["player_id"]
                p    = next((pl for t in self.teams.values()
                             for pl in t.squad if pl.id == pid), None)
                vals = [
                    p.name if p else pid,
                    str(p.overall_rating) if p else "?",
                    rec["owner_address"],
                    str(rec.get("ask_sats", 0)),
                    "FOR SALE" if rec.get("for_sale") else "OWNED",
                ]
                for c, v in enumerate(vals):
                    self.nft_table.setItem(r, c, QTableWidgetItem(v))


# ── Entry point ────────────────────────────────────────────────────────────────
def launch_gui():
    if not HAS_PYQT:
        log.error("PyQt6 not installed. Run: pip install PyQt6")
        return

    app = QApplication(sys.argv)
    app.setApplicationName("W.G.Grace-1")

    window = WGGraceMainWindow()
    window.show()
    sys.exit(app.exec())
