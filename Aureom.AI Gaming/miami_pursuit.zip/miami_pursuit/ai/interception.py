"""
Interception planning (spec section 14): turn predicted routes into
concrete, plausible interception assignments for available police units.
Never teleports a unit - every plan is validated against real travel time
over the road graph.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ai.prediction import RouteCandidate
from world.roads import RoadNetwork

if TYPE_CHECKING:
    from vehicles.police_vehicle import PoliceVehicle


@dataclass
class InterceptionPlan:
    unit: "PoliceVehicle"
    target_node: int
    probability: float
    arrival_time: float
    distance: float
    confidence: float


def compute_interception_points(
    network: RoadNetwork,
    routes: list[RouteCandidate],
    units: list["PoliceVehicle"],
    player_speed: float,
) -> list[InterceptionPlan]:
    plans: list[InterceptionPlan] = []
    if not routes or not units:
        return plans

    player_speed = max(player_speed, 4.0)

    for route in routes:
        if len(route.nodes) < 2:
            continue
        # Consider intermediate/end nodes along the route as candidate points.
        for node_id in route.nodes[1:]:
            path_from_start = route.nodes[: route.nodes.index(node_id) + 1]
            dist_along = _path_length(network, path_from_start)
            player_arrival = dist_along / player_speed

            for unit in units:
                unit_start = network.nearest_node(unit.position)
                unit_path = network.shortest_path(unit_start, node_id)
                if len(unit_path) < 1:
                    continue
                unit_travel_time = network.path_travel_time(unit_path) / max(unit.pursuit_speed, 0.1)
                unit_distance = _path_length(network, unit_path)

                # Only plausible if the unit can plausibly beat or match the player.
                margin = player_arrival - unit_travel_time
                if margin < -6.0:
                    continue

                timing_confidence = max(0.0, min(1.0, 0.5 + margin / 12.0))
                confidence = timing_confidence * route.probability * unit.prediction_skill

                plans.append(InterceptionPlan(
                    unit=unit, target_node=node_id, probability=route.probability,
                    arrival_time=unit_travel_time, distance=unit_distance, confidence=confidence,
                ))

    plans.sort(key=lambda p: -p.confidence)
    return plans


def _path_length(network: RoadNetwork, path: list[int]) -> float:
    total = 0.0
    for a, b in zip(path, path[1:]):
        total += network.nodes[a].position.distance_to(network.nodes[b].position)
    return total


def assign_best_interceptions(plans: list[InterceptionPlan], max_assignments: int) -> list[InterceptionPlan]:
    """Greedy assignment: best confidence first, one plan per unit."""
    used_units = set()
    chosen: list[InterceptionPlan] = []
    for plan in plans:
        if plan.unit.id in used_units:
            continue
        chosen.append(plan)
        used_units.add(plan.unit.id)
        if len(chosen) >= max_assignments:
            break
    return chosen
