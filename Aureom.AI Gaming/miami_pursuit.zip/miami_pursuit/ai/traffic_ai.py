"""
Traffic orchestration: keeps civilian vehicle population roughly matched to
the district's current traffic density (time-of-day + weather + economy),
and provides the reactive "slow down near police/accidents" behaviour
layered on top of vehicles/vehicle_ai.py's base steering.
"""

from __future__ import annotations

import random

from config import VEHICLE_STATS
from engine.physics import Vector2
from vehicles.civilian_vehicle import CivilianVehicle
from vehicles.vehicle import VehicleClass
from world.roads import RoadNetwork
from world.world import World

_CIVILIAN_CLASS_WEIGHTS = [
    (VehicleClass.SEDAN, 0.45), (VehicleClass.SUV, 0.2), (VehicleClass.VAN, 0.1),
    (VehicleClass.TRUCK, 0.08), (VehicleClass.SPORTS, 0.08), (VehicleClass.MOTORCYCLE, 0.06),
    (VehicleClass.BUS, 0.03),
]


def _weighted_class(rng: random.Random) -> VehicleClass:
    roll = rng.random()
    acc = 0.0
    for cls, weight in _CIVILIAN_CLASS_WEIGHTS:
        acc += weight
        if roll <= acc:
            return cls
    return VehicleClass.SEDAN


def spawn_civilian(world: World, rng: random.Random, near: Vector2 | None = None) -> CivilianVehicle:
    network = world.city.road_network
    if near is not None:
        node_id = network.nearest_node(near)
    else:
        node_id = rng.choice(list(network.nodes.keys()))
    pos = network.nodes[node_id].position.copy()
    vehicle_class = _weighted_class(rng)
    vehicle = CivilianVehicle(vehicle_class=vehicle_class, position=pos, rng=rng)
    vehicle.ensure_route(network)
    return vehicle


def desired_civilian_count(world: World, economy_mult: float, max_population: int = 140) -> int:
    total_density = 0.0
    count = 0
    for district in world.city.districts:
        total_density += world.traffic_density_at(district.name, economy_mult)
        count += 1
    avg_density = total_density / max(count, 1)
    return int(max_population * avg_density)


def rebalance_population(world: World, civilians: list[CivilianVehicle], rng: random.Random,
                          economy_mult: float, focus: Vector2, max_population: int = 140) -> list[CivilianVehicle]:
    target = desired_civilian_count(world, economy_mult, max_population)
    # Despawn distant vehicles first if over target.
    civilians.sort(key=lambda v: -v.position.distance_to(focus))
    while len(civilians) > target and civilians and civilians[0].position.distance_to(focus) > 1600.0:
        civilians.pop(0)
    while len(civilians) < target:
        civilians.append(spawn_civilian(world, rng, near=focus if rng.random() < 0.3 else None))
    return civilians


def apply_reactive_behaviour(vehicle: CivilianVehicle, nearby_police_active: bool, accident_nearby: bool) -> None:
    vehicle.panic = nearby_police_active or accident_nearby
