"""
Predictive pursuit (spec section 13): never point police directly at the
player. Estimate a future position from current velocity, then fan that
estimate out across the road graph's plausible branches (highway exits,
intersections) instead of a single straight-line guess.
"""

from __future__ import annotations

from dataclasses import dataclass

from engine.physics import Vector2
from world.roads import RoadNetwork


@dataclass
class RouteCandidate:
    nodes: list[int]
    probability: float
    end_position: Vector2


def predict_future_position(position: Vector2, velocity: Vector2, prediction_time: float) -> Vector2:
    return position + velocity * prediction_time


def predict_candidate_routes(
    network: RoadNetwork,
    position: Vector2,
    heading: float,
    velocity: Vector2,
    *,
    depth: int = 3,
    branch_limit: int = 2,
    prediction_quality: float = 0.6,
) -> list[RouteCandidate]:
    """Enumerate a small tree of plausible routes the player might take from
    their current node, weighting by heading-alignment at each branch.
    `prediction_quality` (0..1, tied to wanted level) narrows or widens how
    many branches are considered "plausible" - poor prediction quality
    considers more (noisier) options."""
    start_node = network.nearest_node(position)
    branch_limit = max(1, min(3, branch_limit + (1 if prediction_quality < 0.4 else 0)))

    routes: list[RouteCandidate] = []

    def recurse(node_id: int, path: list[int], prob: float, current_heading: float, remaining: int):
        if remaining == 0 or prob < 0.03:
            routes.append(RouteCandidate(nodes=list(path), probability=prob,
                                          end_position=network.nodes[node_id].position))
            return
        branches = network.candidate_branches(node_id, current_heading, exclude=path[-2] if len(path) > 1 else None)
        if not branches:
            routes.append(RouteCandidate(nodes=list(path), probability=prob,
                                          end_position=network.nodes[node_id].position))
            return
        top = branches[:branch_limit]
        total_alignment = sum(a for _, a in top) or 1.0
        for neighbor, alignment in top:
            branch_prob = prob * (0.25 + 0.75 * (alignment / total_alignment))
            new_heading = (network.nodes[neighbor].position - network.nodes[node_id].position).angle()
            recurse(neighbor, path + [neighbor], branch_prob, new_heading, remaining - 1)

    recurse(start_node, [start_node], 1.0, heading, depth)

    # Normalize so probabilities sum to ~1 across leaves.
    total = sum(r.probability for r in routes) or 1.0
    for r in routes:
        r.probability /= total
    routes.sort(key=lambda r: -r.probability)
    return routes
