"""
Search system (spec section 15): once the player breaks visual contact, the
last known position becomes the centre of a decaying probability field.
Witness sightings inside the field can push confidence back up.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from engine.physics import Vector2
from world.roads import RoadNetwork

# Matches the example decay curve in the spec: 0s->100%, 10s->80%, 30s->45%, 60s->15%.
# Fit as an exponential decay: confidence(t) = exp(-k * t); solved for k ~ 0.0223 at t=10 (0.80)
# giving a reasonably close match across the listed samples.
_DECAY_K = 0.027


@dataclass
class SearchArea:
    center: Vector2
    radius: float
    created_time: float
    last_reinforced: float = 0.0

    def confidence(self, sim_time: float) -> float:
        elapsed = max(0.0, sim_time - self.created_time - self.last_reinforced)
        return math.exp(-_DECAY_K * elapsed)

    def reinforce(self, sim_time: float, new_center: Vector2 | None = None, boost_seconds: float = 20.0) -> None:
        self.last_reinforced = min(self.last_reinforced + boost_seconds, sim_time - self.created_time)
        if new_center is not None:
            self.center = new_center

    def grow(self, dt: float, rate: float = 6.0) -> None:
        self.radius += rate * dt


def generate_search_routes(network: RoadNetwork, area: SearchArea, max_nodes: int = 24) -> list[int]:
    """Nodes within the search radius, closest-first, for units to patrol."""
    candidates = []
    for node_id, node in network.nodes.items():
        d = node.position.distance_to(area.center)
        if d <= area.radius:
            candidates.append((d, node_id))
    candidates.sort(key=lambda t: t[0])
    return [n for _, n in candidates[:max_nodes]]
