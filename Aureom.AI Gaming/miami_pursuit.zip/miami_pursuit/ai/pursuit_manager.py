"""
PursuitManager: the central nervous system of a chase (spec section 11).

It owns the WantedSystem, the CommunicationNetwork, the current SearchArea,
the finite police resource pool, and every currently-spawned PoliceVehicle.
Nothing here ever teleports a unit or gives it the player's exact position
for free - everything is mediated by line-of-sight checks, the
CommunicationNetwork, and decaying SearchArea confidence.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from ai.coordination import CommunicationNetwork, SharedIntel
from ai.interception import assign_best_interceptions, compute_interception_points
from ai.police_ai import DecisionContext, PursuitState, decide
from ai.prediction import predict_candidate_routes, predict_future_position
from ai.search import SearchArea, generate_search_routes
from config import ESCAPE_CONFIDENCE_THRESHOLD, ESCAPE_REQUIRED_SECONDS, POLICE_RESOURCE_POOL
from engine.physics import Vector2, clamp
from gameplay.wanted_system import WantedSystem
from vehicles.police_vehicle import PoliceVehicle, UnitRole
from vehicles.vehicle import VehicleClass
from world.buildings import BuildingIndex
from world.roads import RoadNetwork

_ROLE_POOL_KEY = {
    UnitRole.PATROL: "patrol_units",
    UnitRole.TRAFFIC: "patrol_units",
    UnitRole.INTERCEPTOR: "interceptors",
    UnitRole.SUPERVISOR: "supervisors",
}

_BASE_VIEW_DISTANCE = 320.0
_DECISION_INTERVAL = 1.0 / 8.0  # matches config.FREQ_POLICE_DECISION


@dataclass
class PursuitTelemetry:
    escapes: int = 0
    reports_received: int = 0
    interceptions_attempted: int = 0


class PursuitManager:
    def __init__(self, network: RoadNetwork, buildings: BuildingIndex, rng: random.Random | None = None):
        self.network = network
        self.buildings = buildings
        self.rng = rng or random.Random(99)

        self.wanted = WantedSystem()
        self.comm = CommunicationNetwork(rng=random.Random(self.rng.random()))
        self.units: list[PoliceVehicle] = []
        self.pool: dict[str, int] = dict(POLICE_RESOURCE_POOL)

        self.search_area: SearchArea | None = None
        self.last_known_position: Vector2 | None = None
        self.last_known_direction: float = 0.0

        self.telemetry = PursuitTelemetry()
        self.pursuit_pressure = 0.0
        self._recent_incidents: list[float] = []
        self._escape_timer = 0.0
        self._decision_timer = 0.0
        self._strategy = "STANDBY"

    # ------------------------------------------------------------------
    # Simulation API (spec section 38)
    # ------------------------------------------------------------------
    def start_chase(self, player_id: int = 1) -> None:
        self.telemetry = PursuitTelemetry()

    def stop_chase(self) -> None:
        self.wanted.clear()
        self.search_area = None
        for unit in self.units:
            unit.state = PursuitState.RETURNING.value
        self._escape_timer = 0.0

    def reduce_heat(self, amount: float) -> None:
        self.wanted.reduce(amount)

    def create_search_area(self, position: Vector2, radius: float, sim_time: float) -> SearchArea:
        self.search_area = SearchArea(center=position, radius=radius, created_time=sim_time)
        return self.search_area

    def report_incident(self, *, position: Vector2, direction: float, confidence: float,
                         witness_count: int, severity: float, sim_time: float,
                         vehicle_desc: str = "unknown vehicle") -> None:
        self.wanted.register_report(confidence, witness_count, severity)
        self.last_known_position = position.copy()
        self.last_known_direction = direction
        self._recent_incidents.append(sim_time)
        self._recent_incidents = [t for t in self._recent_incidents if sim_time - t < 60.0]
        self.telemetry.reports_received += 1

        radius = max(80.0, 260.0 * (1.0 - confidence))
        if self.search_area is None:
            self.create_search_area(position, radius, sim_time)
        else:
            self.search_area.reinforce(sim_time, new_center=position)
            self.search_area.radius = max(self.search_area.radius * 0.6, radius)

        intel = SharedIntel(last_known_position=position.copy(), last_known_direction=direction,
                             vehicle_desc=vehicle_desc, confidence=confidence,
                             search_radius=self.search_area.radius, sim_time=sim_time)
        self.comm.broadcast(intel, origin=position, comm_range=2000.0, sim_time=sim_time)

    def calculate_prediction(self, position: Vector2, heading: float, velocity: Vector2, prediction_time: float = 3.0):
        future = predict_future_position(position, velocity, prediction_time)
        routes = predict_candidate_routes(self.network, position, heading, velocity,
                                           prediction_quality=self.wanted.response_params()["prediction_quality"])
        return future, routes

    def calculate_interception(self, routes, player_speed: float):
        available = [u for u in self.units if u.role == UnitRole.INTERCEPTOR
                     and u.state not in (PursuitState.PURSUING.value,)]
        plans = compute_interception_points(self.network, routes, available, player_speed)
        self.telemetry.interceptions_attempted += 1 if plans else 0
        return plans

    def get_pursuit_state(self) -> dict:
        pursuing = [u for u in self.units if u.state == PursuitState.PURSUING.value]
        searching = [u for u in self.units if u.state in (PursuitState.SEARCHING.value, PursuitState.SEARCH_GRID.value)]
        predicted = self.last_known_position
        return {
            "wanted_level": self.wanted.level(),
            "heat": round(self.wanted.heat, 1),
            "police_confidence": round(self.wanted.police_confidence, 2),
            "last_known_position": (round(self.last_known_position.x, 1), round(self.last_known_position.y, 1))
            if self.last_known_position else None,
            "active_police": len(self.units),
            "pursuing": len(pursuing),
            "searching": len(searching),
            "search_radius": round(self.search_area.radius, 1) if self.search_area else 0.0,
            "pursuit_pressure": round(self.pursuit_pressure, 2),
            "strategy": self._strategy,
        }

    # ------------------------------------------------------------------
    # Main tick
    # ------------------------------------------------------------------
    def update(self, dt: float, sim_time: float, *, player_position: Vector2, player_velocity: Vector2,
               player_heading: float, concealed: bool, concealment: float, visibility_modifier: float) -> None:
        self.comm.update(sim_time)
        self.wanted.decay(dt, concealed, concealment)

        if self.search_area is not None:
            self.search_area.grow(dt, rate=4.0)

        self._decision_timer += dt
        if self._decision_timer >= _DECISION_INTERVAL:
            self._decision_timer = 0.0
            self._make_decisions(sim_time, player_position, player_velocity, player_heading, visibility_modifier)

        self._recycle_units()
        self._update_pressure(player_position, player_velocity.length(), sim_time, visibility_modifier)
        self._check_escape(dt, player_position, sim_time)

    # ------------------------------------------------------------------
    def _view_distance(self, visibility_modifier: float) -> float:
        return _BASE_VIEW_DISTANCE * clamp(visibility_modifier, 0.15, 1.5)

    def _unit_can_see_player(self, unit: PoliceVehicle, player_position: Vector2, view_distance: float) -> bool:
        dist = unit.position.distance_to(player_position)
        if dist > view_distance:
            return False
        return not self.buildings.line_of_sight_blocked(unit.position, player_position)

    def _make_decisions(self, sim_time: float, player_position: Vector2, player_velocity: Vector2,
                         player_heading: float, visibility_modifier: float) -> None:
        if self.wanted.level() == 0:
            # Case closed: stand every unit down rather than leaving them
            # loitering forever (spec section 43 - "world returns to normal").
            for unit in self.units:
                if unit.state not in (PursuitState.RETURNING.value, PursuitState.STANDBY.value):
                    unit.state = PursuitState.RETURNING.value
            self._strategy = "STANDBY"
            return

        self._assign_units(sim_time, player_position)

        view_distance = self._view_distance(visibility_modifier)
        any_visible = False

        # Precompute interception plans once per decision tick if warranted.
        intercept_by_unit: dict[int, int] = {}
        level = self.wanted.level()
        if level >= 3 and self.last_known_position is not None:
            _, routes = None, predict_candidate_routes(
                self.network, self.last_known_position, self.last_known_direction, player_velocity,
                prediction_quality=self.wanted.response_params()["prediction_quality"])
            plans = self.calculate_interception(routes, max(player_velocity.length(), 8.0))
            chosen = assign_best_interceptions(plans, max_assignments=3)
            for plan in chosen:
                intercept_by_unit[plan.unit.id] = plan.target_node

        for unit in self.units:
            visible = self._unit_can_see_player(unit, player_position, view_distance)
            any_visible = any_visible or visible
            if visible:
                self.last_known_position = player_position.copy()
                self.last_known_direction = player_velocity.angle() if player_velocity.length() > 0.5 else unit.heading
                intel = SharedIntel(last_known_position=player_position.copy(),
                                     last_known_direction=self.last_known_direction,
                                     vehicle_desc="player_vehicle", confidence=1.0,
                                     search_radius=80.0, sim_time=sim_time)
                self.comm.broadcast(intel, origin=unit.position, comm_range=unit.communication_range, sim_time=sim_time)

            intel = self.comm.intel_within_range(unit.position)
            ctx = DecisionContext(
                sim_time=sim_time, network=self.network, target_visible=visible,
                target_position=player_position if visible else None,
                target_velocity=player_velocity if visible else None,
                intel=intel, search_area=self.search_area,
                intercept_node=intercept_by_unit.get(unit.id),
            )
            decide(unit, ctx)

        self._strategy = self._infer_strategy()

    def _infer_strategy(self) -> str:
        if any(u.state == PursuitState.INTERCEPTING.value for u in self.units):
            return "HIGHWAY INTERCEPTION" if self._on_highway() else "PREDICTIVE INTERCEPTION"
        if any(u.state == PursuitState.PURSUING.value for u in self.units):
            return "ACTIVE PURSUIT"
        if any(u.state in (PursuitState.SEARCHING.value, PursuitState.SEARCH_GRID.value) for u in self.units):
            return "SEARCH GRID"
        if any(u.state == PursuitState.INVESTIGATING.value for u in self.units):
            return "INVESTIGATING REPORT"
        return "STANDBY"

    def _on_highway(self) -> bool:
        if self.last_known_position is None:
            return False
        node = self.network.nodes[self.network.nearest_node(self.last_known_position)]
        return "HIGHWAY" in node.district

    def _assign_units(self, sim_time: float, player_position: Vector2) -> None:
        level = self.wanted.level()
        params = self.wanted.response_params()
        max_units = params["max_units"]
        attempts = 0
        while len(self.units) < max_units and attempts < 3:
            attempts += 1
            role = self._choose_role(level)
            unit = self._spawn_unit(role, player_position, params["response_time"])
            if unit is None:
                break
            self.units.append(unit)

    def _choose_role(self, level: int) -> UnitRole:
        roll = self.rng.random()
        if level >= 4 and roll < 0.12 and not any(u.role == UnitRole.SUPERVISOR for u in self.units):
            return UnitRole.SUPERVISOR
        if level >= 3 and roll < 0.4:
            return UnitRole.INTERCEPTOR
        if roll < 0.5:
            return UnitRole.TRAFFIC
        return UnitRole.PATROL

    def _spawn_unit(self, role: UnitRole, player_position: Vector2, response_time: float) -> PoliceVehicle | None:
        key = _ROLE_POOL_KEY[role]
        if self.pool.get(key, 0) <= 0 or self.pool.get("response_capacity", 0) <= 0:
            return None

        approx_speed = 18.0
        spawn_distance = clamp(response_time * approx_speed, 150.0, 2200.0)
        angle = self.rng.uniform(0, 6.2832)
        spawn_pos = Vector2(player_position.x + spawn_distance * math.cos(angle),
                             player_position.y + spawn_distance * math.sin(angle))
        node_id = self.network.nearest_node(spawn_pos)
        spawn_pos = self.network.nodes[node_id].position.copy()

        self.pool[key] -= 1
        self.pool["response_capacity"] -= 1

        unit = PoliceVehicle(vehicle_class=VehicleClass.POLICE,
                              position=spawn_pos, role=role, rng=self.rng)
        unit.state = PursuitState.UNAWARE.value
        return unit

    def _recycle_units(self) -> None:
        keep = []
        for unit in self.units:
            if unit.state == PursuitState.STANDBY.value:
                key = _ROLE_POOL_KEY[unit.role]
                self.pool[key] = self.pool.get(key, 0) + 1
                self.pool["response_capacity"] = self.pool.get("response_capacity", 0) + 1
                continue
            if unit.state == PursuitState.RETURNING.value and not unit.follower.has_route():
                unit.state = PursuitState.STANDBY.value
            keep.append(unit)
        self.units = keep

    def _update_pressure(self, player_position: Vector2, player_speed: float, sim_time: float, visibility_modifier: float) -> None:
        active_pursuers = [u for u in self.units if u.state in (PursuitState.PURSUING.value, PursuitState.INTERCEPTING.value)]
        if active_pursuers:
            closest = min(u.position.distance_to(player_position) for u in active_pursuers)
            proximity = clamp(1.0 - closest / 600.0, 0.0, 1.0)
        else:
            proximity = 0.0
        unit_factor = clamp(len(active_pursuers) / 4.0, 0.0, 1.0)
        confidence_factor = self.wanted.police_confidence
        recent = len([t for t in self._recent_incidents if sim_time - t < 20.0])
        incident_factor = clamp(recent / 3.0, 0.0, 1.0)
        speed_factor = clamp(player_speed / 55.0, 0.0, 1.0)

        pressure = (0.32 * proximity + 0.22 * confidence_factor + 0.18 * unit_factor
                    + 0.14 * incident_factor + 0.08 * speed_factor + 0.06 * visibility_modifier)
        self.pursuit_pressure = clamp(pressure, 0.0, 1.0)

    def _check_escape(self, dt: float, player_position: Vector2, sim_time: float) -> None:
        if self.wanted.level() == 0:
            self._escape_timer = 0.0
            return

        outside_search = self.search_area is None or player_position.distance_to(self.search_area.center) > self.search_area.radius
        no_recent_witness = self.wanted.time_since_report > 8.0
        confidence_low = self.wanted.police_confidence < ESCAPE_CONFIDENCE_THRESHOLD

        if confidence_low and no_recent_witness and outside_search:
            self._escape_timer += dt
        else:
            self._escape_timer = 0.0

        if self._escape_timer >= ESCAPE_REQUIRED_SECONDS:
            self._trigger_escape()

    def _trigger_escape(self) -> None:
        self.wanted.police_confidence = 0.0
        level_below = self.wanted.level()
        if level_below > 0:
            from config import WANTED_LEVEL_THRESHOLDS
            self.wanted.heat = min(self.wanted.heat, WANTED_LEVEL_THRESHOLDS[max(0, level_below - 1)] * 0.6)
        self.search_area = None
        for unit in self.units:
            if unit.state in (PursuitState.SEARCHING.value, PursuitState.SEARCH_GRID.value,
                               PursuitState.INVESTIGATING.value, PursuitState.LOST_TARGET.value):
                unit.state = PursuitState.RETURNING.value
        self._escape_timer = 0.0
        self.telemetry.escapes += 1
