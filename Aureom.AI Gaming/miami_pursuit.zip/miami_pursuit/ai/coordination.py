"""
Abstract police communication network (spec section 16). Prevents the
entire force from having magical, instantaneous knowledge of the player -
intel propagates with delay, range and reliability.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from engine.physics import Vector2


@dataclass
class SharedIntel:
    last_known_position: Vector2
    last_known_direction: float
    vehicle_desc: str
    confidence: float
    search_radius: float
    sim_time: float


@dataclass
class _PendingMessage:
    intel: SharedIntel
    deliver_at: float
    origin: Vector2
    range_: float


@dataclass
class CommunicationNetwork:
    base_delay: float = 1.2
    reliability: float = 0.9
    rng: random.Random = None  # type: ignore[assignment]
    _queue: list = field(default_factory=list)
    _broadcast_history: list = field(default_factory=list)

    def __post_init__(self):
        if self.rng is None:
            self.rng = random.Random(4242)

    def broadcast(self, intel: SharedIntel, origin: Vector2, comm_range: float, sim_time: float) -> None:
        if self.rng.random() > self.reliability:
            return  # message dropped
        distance_jitter = self.rng.uniform(0.0, 0.6)
        self._queue.append(_PendingMessage(intel=intel, deliver_at=sim_time + self.base_delay + distance_jitter,
                                            origin=origin, range_=comm_range))

    def update(self, sim_time: float) -> None:
        ready = [m for m in self._queue if m.deliver_at <= sim_time]
        self._queue = [m for m in self._queue if m.deliver_at > sim_time]
        self._broadcast_history.extend(ready)
        # keep history bounded
        if len(self._broadcast_history) > 64:
            self._broadcast_history = self._broadcast_history[-64:]

    def intel_within_range(self, position: Vector2) -> SharedIntel | None:
        """Return the most recent intel a unit at `position` could plausibly
        have received (i.e. it was broadcast from within comm range)."""
        best: SharedIntel | None = None
        best_time = -1.0
        for msg in self._broadcast_history:
            if msg.origin.distance_to(position) <= msg.range_ and msg.intel.sim_time > best_time:
                best = msg.intel
                best_time = msg.intel.sim_time
        return best

    def latest_intel(self) -> SharedIntel | None:
        if not self._broadcast_history:
            return None
        return max(self._broadcast_history, key=lambda m: m.intel.sim_time).intel
