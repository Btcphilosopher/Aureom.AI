"""
Per-unit police AI state machine (spec section 10 & 12).

This module makes *decisions* (which state to be in, where to route to) at a
low frequency (see FREQ_POLICE_DECISION in config.py). The resulting route is
then driven every physics tick by vehicles/vehicle_ai.py, so movement stays
smooth even though decisions are cheap and infrequent.

Police never get the player's exact position for free: everything routes
through `ai/coordination.py` SharedIntel, direct line-of-sight, or the
current SearchArea.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Optional

from ai.coordination import SharedIntel
from ai.search import SearchArea, generate_search_routes
from engine.physics import Vector2
from vehicles.vehicle_ai import RouteFollower, make_follower
from world.roads import RoadNetwork

if TYPE_CHECKING:
    from vehicles.police_vehicle import PoliceVehicle


class PursuitState(str, Enum):
    UNAWARE = "UNAWARE"
    INVESTIGATING = "INVESTIGATING"
    SEARCHING = "SEARCHING"
    LOCATING = "LOCATING"
    PURSUING = "PURSUING"
    INTERCEPTING = "INTERCEPTING"
    LOST_TARGET = "LOST_TARGET"
    SEARCH_GRID = "SEARCH_GRID"
    STANDBY = "STANDBY"
    RETURNING = "RETURNING"


@dataclass
class DecisionContext:
    sim_time: float
    network: RoadNetwork
    target_visible: bool
    target_position: Optional[Vector2]
    target_velocity: Optional[Vector2]
    intel: Optional[SharedIntel]
    search_area: Optional[SearchArea]
    intercept_node: Optional[int] = None
    patience_limit: float = 25.0


def decide(unit: "PoliceVehicle", ctx: DecisionContext) -> None:
    """Advance `unit.state` and, when the resulting state implies movement,
    recompute `unit.follower`'s route. Called at the low police-decision
    frequency, not every physics frame."""

    state = PursuitState(unit.state)

    if ctx.target_visible and ctx.target_position is not None:
        # Direct visual contact always wins - transition straight to pursuit.
        if state not in (PursuitState.PURSUING,):
            unit.reaction_timer = 0.0
        state = PursuitState.PURSUING

    elif state == PursuitState.PURSUING:
        # Just lost the target this tick.
        state = PursuitState.LOST_TARGET
        unit.reaction_timer = 0.0

    elif state == PursuitState.UNAWARE and ctx.intel is not None:
        state = PursuitState.INVESTIGATING

    elif state == PursuitState.INVESTIGATING:
        unit.reaction_timer += 0.0  # timing handled by caller via dt accumulation externally
        if ctx.search_area is not None and unit.position.distance_to(ctx.search_area.center) < 40.0:
            state = PursuitState.SEARCHING

    elif state == PursuitState.LOST_TARGET:
        state = PursuitState.SEARCHING

    elif state == PursuitState.SEARCHING:
        if ctx.search_area is not None and ctx.search_area.confidence(ctx.sim_time) < 0.08:
            state = PursuitState.RETURNING
        elif ctx.intercept_node is not None and unit.role == "INTERCEPTOR":
            state = PursuitState.INTERCEPTING

    elif state == PursuitState.SEARCH_GRID:
        if ctx.search_area is not None and ctx.search_area.confidence(ctx.sim_time) < 0.08:
            state = PursuitState.RETURNING

    elif state == PursuitState.INTERCEPTING:
        if ctx.intercept_node is None:
            state = PursuitState.SEARCHING

    elif state == PursuitState.RETURNING:
        if unit.follower.has_route() is False:
            state = PursuitState.STANDBY

    unit.state = state.value
    _route_for_state(unit, state, ctx)


def _route_for_state(unit: "PoliceVehicle", state: PursuitState, ctx: DecisionContext) -> None:
    network = ctx.network

    def route_to(position: Vector2) -> None:
        start = network.nearest_node(unit.position)
        goal = network.nearest_node(position)
        path = network.shortest_path(start, goal)
        if len(path) >= 2:
            unit.follower = make_follower(path)

    if state == PursuitState.PURSUING and ctx.target_position is not None:
        route_to(ctx.target_position)

    elif state == PursuitState.INVESTIGATING and ctx.intel is not None:
        route_to(ctx.intel.last_known_position)

    elif state in (PursuitState.SEARCHING, PursuitState.SEARCH_GRID) and ctx.search_area is not None:
        if not unit.follower.has_route():
            nodes = generate_search_routes(network, ctx.search_area)
            if nodes:
                start = network.nearest_node(unit.position)
                target_node = nodes[hash(unit.id) % len(nodes)]
                path = network.shortest_path(start, target_node)
                if len(path) >= 2:
                    unit.follower = make_follower(path)

    elif state == PursuitState.INTERCEPTING and ctx.intercept_node is not None:
        start = network.nearest_node(unit.position)
        path = network.shortest_path(start, ctx.intercept_node)
        if len(path) >= 2:
            unit.follower = make_follower(path)

    elif state == PursuitState.RETURNING:
        if not unit.follower.has_route():
            # head back toward a patrol node (its own district origin) - simplified
            # to just idle in place once no route remains.
            pass

    elif state == PursuitState.STANDBY:
        pass
