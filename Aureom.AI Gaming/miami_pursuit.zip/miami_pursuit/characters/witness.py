"""
The witness system (spec section 8) - arguably the most important piece of
the whole engine. A crime event does not automatically create a wanted
level; it must first be *observed*.

EVENT -> WITNESS -> DETECTION -> REPORT -> POLICE AWARENESS -> PURSUIT
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum

from characters.pedestrian import Pedestrian
from engine.physics import Vector2, clamp
from gameplay.crimes import CrimeEvent
from world.buildings import BuildingIndex


class DetectionOutcome(str, Enum):
    NONE = "NONE"
    PARTIAL = "PARTIAL"
    IDENTIFIED_VEHICLE = "IDENTIFIED_VEHICLE"
    IDENTIFIED_PLAYER = "IDENTIFIED_PLAYER"


@dataclass
class WitnessReport:
    event: CrimeEvent
    outcome: DetectionOutcome
    confidence: float
    witness_count: int
    position: Vector2


def _detection_probability(*, distance: float, line_of_sight: bool, lighting: float,
                            noise: float, awareness: float, weather_detection: float,
                            crowd_density: float) -> float:
    if not line_of_sight:
        return 0.02 * noise  # can still "hear" something at very close range
    distance_factor = clamp(1.0 - distance / 300.0, 0.0, 1.0)
    crowd_factor = clamp(0.4 + crowd_density * 0.6, 0.0, 1.0)
    prob = distance_factor * lighting * weather_detection * crowd_factor
    prob = prob * (0.4 + 0.6 * awareness) * (0.5 + 0.5 * noise)
    return clamp(prob, 0.0, 0.97)


def evaluate_witnesses(
    *,
    event: CrimeEvent,
    pedestrians: list[Pedestrian],
    buildings: BuildingIndex,
    lighting: float,
    weather_detection: float,
    rng: random.Random,
    search_radius: float = 260.0,
) -> WitnessReport | None:
    """Run every nearby pedestrian through the detection pipeline and, if any
    of them see enough, produce a single aggregated WitnessReport."""
    nearby = [p for p in pedestrians if p.position.distance_to(event.position) <= search_radius]
    if not nearby:
        return None

    crowd_density = clamp(len(nearby) / 8.0, 0.0, 1.0)
    best_outcome = DetectionOutcome.NONE
    best_confidence = 0.0
    witness_count = 0

    for ped in nearby:
        distance = ped.position.distance_to(event.position)
        los_blocked = buildings.line_of_sight_blocked(ped.position, event.position)
        prob = _detection_probability(
            distance=distance, line_of_sight=not los_blocked, lighting=lighting,
            noise=event.noise, awareness=ped.awareness, weather_detection=weather_detection,
            crowd_density=crowd_density,
        )
        roll = rng.random()
        if roll > prob:
            continue

        witness_count += 1
        ped.notice_event(event.position, intensity=event.severity)

        # How *well* they saw it scales with how comfortably prob exceeded the roll.
        clarity = clamp((prob - roll) / max(prob, 1e-6), 0.0, 1.0)
        if clarity < 0.25:
            outcome = DetectionOutcome.PARTIAL
        elif clarity < 0.6:
            outcome = DetectionOutcome.IDENTIFIED_VEHICLE
        else:
            outcome = DetectionOutcome.IDENTIFIED_PLAYER

        confidence = {
            DetectionOutcome.PARTIAL: 0.25,
            DetectionOutcome.IDENTIFIED_VEHICLE: 0.55,
            DetectionOutcome.IDENTIFIED_PLAYER: 0.85,
        }[outcome]

        if _outcome_rank(outcome) > _outcome_rank(best_outcome):
            best_outcome = outcome
            best_confidence = confidence
        elif outcome == best_outcome:
            best_confidence = min(1.0, best_confidence + 0.05)

    if best_outcome == DetectionOutcome.NONE or witness_count == 0:
        return None

    return WitnessReport(event=event, outcome=best_outcome, confidence=best_confidence,
                          witness_count=witness_count, position=event.position)


def _outcome_rank(outcome: DetectionOutcome) -> int:
    return {
        DetectionOutcome.NONE: 0,
        DetectionOutcome.PARTIAL: 1,
        DetectionOutcome.IDENTIFIED_VEHICLE: 2,
        DetectionOutcome.IDENTIFIED_PLAYER: 3,
    }[outcome]
