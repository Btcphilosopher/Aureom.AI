"""The Player character: wraps whichever Vehicle is currently being driven
and tracks simple crime-relevant flags each tick."""

from __future__ import annotations

from dataclasses import dataclass, field

from characters.character import Character
from vehicles.vehicle import Vehicle


@dataclass
class Player(Character):
    vehicle: Vehicle | None = None
    in_vehicle: bool = True
    vehicle_changes: int = 0
    hiding_attempts: int = 0

    def enter_vehicle(self, vehicle: Vehicle) -> None:
        self.vehicle = vehicle
        self.in_vehicle = True
        self.vehicle_changes += 1

    def exit_vehicle(self) -> None:
        if self.vehicle is not None:
            self.position = self.vehicle.position.copy()
        self.in_vehicle = False

    def sync_position(self) -> None:
        if self.in_vehicle and self.vehicle is not None:
            self.position = self.vehicle.position.copy()
