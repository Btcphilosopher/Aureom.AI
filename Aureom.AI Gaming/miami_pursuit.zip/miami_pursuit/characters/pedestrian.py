"""Simple pedestrian agents. Detail is scaled with distance from the player
(spec section 7): nearby pedestrians get full steering behaviour, distant
ones are simplified to a cheap position update."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from characters.character import Character
from engine.physics import Vector2, clamp


@dataclass
class Pedestrian(Character):
    destination: Vector2 = field(default_factory=Vector2)
    walking_speed: float = 1.3
    awareness: float = 0.6      # 0..1, how likely to notice events at all
    fear: float = 0.0           # 0..1, current fear level
    reaction_time: float = 0.4
    fleeing: bool = False
    flee_timer: float = 0.0

    def pick_new_destination(self, rng: random.Random, radius: float = 220.0) -> None:
        angle = rng.uniform(0, 6.2832)
        dist = rng.uniform(30, radius)
        self.destination = Vector2(self.position.x + dist * math.cos(angle),
                                    self.position.y + dist * math.sin(angle))

    def notice_event(self, event_position: Vector2, intensity: float) -> None:
        """intensity in [0,1]: sirens, gunfire, crashes, speeding cars nearby."""
        distance = self.position.distance_to(event_position)
        falloff = clamp(1.0 - distance / 260.0, 0.0, 1.0)
        gain = intensity * falloff * self.awareness
        if gain > 0.05:
            self.fear = clamp(self.fear + gain, 0.0, 1.0)
            if self.fear > 0.5:
                self.fleeing = True
                self.flee_timer = 4.0
                away = (self.position - event_position).normalized()
                self.destination = self.position + away * 200.0

    def update(self, dt: float, detail: str = "high") -> None:
        if self.fleeing:
            self.flee_timer -= dt
            if self.flee_timer <= 0:
                self.fleeing = False
                self.fear = max(0.0, self.fear - dt * 0.2)

        to_dest = self.destination - self.position
        dist = to_dest.length()
        if dist < 1.0:
            return
        speed = self.walking_speed * (2.2 if self.fleeing else 1.0)
        if detail == "low":
            # cheap simplified update for distant pedestrians
            self.position = self.position + to_dest.normalized() * speed * dt * 2.0
        else:
            self.position = self.position + to_dest.normalized() * speed * dt
        self.fear = max(0.0, self.fear - dt * 0.02)
