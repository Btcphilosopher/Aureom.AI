"""Base character: anything with a position that isn't a vehicle."""

from __future__ import annotations

from dataclasses import dataclass, field

from engine.physics import Vector2


@dataclass
class Character:
    position: Vector2 = field(default_factory=Vector2)
