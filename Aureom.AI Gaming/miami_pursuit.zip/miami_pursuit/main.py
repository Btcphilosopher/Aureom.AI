#!/usr/bin/env python3
"""
Miami Pursuit Engine - entry point.

    pip install -r requirements.txt
    python main.py [--seed N] [--scenario NAME]

Available scenarios: downtown_pursuit, highway_pursuit, industrial_pursuit,
airport_pursuit, wetland_escape, night_pursuit, rain_pursuit,
multi_vehicle_pursuit.
"""

from __future__ import annotations

import argparse

from config import RANDOM_SEED
from engine.game_loop import GameLoop
from engine.simulation import PursuitSimulation
from gameplay.missions import get_scenario


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Miami Pursuit Engine")
    parser.add_argument("--seed", type=int, default=RANDOM_SEED, help="deterministic world seed")
    parser.add_argument("--scenario", type=str, default=None, help="named chase scenario to start from")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scenario = get_scenario(args.scenario) if args.scenario else None
    simulation = PursuitSimulation(seed=args.seed, scenario=scenario)
    simulation.start_chase(player_id=1)
    loop = GameLoop(simulation)
    loop.run()


if __name__ == "__main__":
    main()
