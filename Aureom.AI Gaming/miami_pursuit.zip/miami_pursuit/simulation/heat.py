"""Pure math helpers for heat escalation/decay, kept separate from
WantedSystem so they're trivially unit-testable."""

from __future__ import annotations

from engine.physics import clamp


def compute_escalation(report_confidence: float, witness_count: int, severity: float) -> float:
    """Heat gained from a single witness report reaching the police."""
    base = 18.0 * severity
    witness_bonus = 1.0 + 0.25 * min(witness_count - 1, 4)
    return base * clamp(report_confidence, 0.0, 1.0) * witness_bonus


def compute_decay_rate(base_rate: float, confidence: float, concealed: bool, concealment: float,
                        concealed_multiplier: float) -> float:
    """Heat/sec lost. Higher police confidence slows decay; concealment
    (inside a safehouse/garage) accelerates it."""
    confidence_penalty = 1.0 - 0.7 * clamp(confidence, 0.0, 1.0)
    rate = base_rate * confidence_penalty
    if concealed:
        rate *= (1.0 + concealed_multiplier * concealment)
    return max(rate, 0.05)
