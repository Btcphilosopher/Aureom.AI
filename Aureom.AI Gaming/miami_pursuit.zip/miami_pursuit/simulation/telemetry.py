"""
PlayerDrivingProfile (spec section 22): a running record of how the player
actually drives. Feeds adaptive pursuit behaviour (section 23) - it never
grants the AI omniscient knowledge, only statistical bias built up from
observed play.
"""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field

from engine.physics import Vector2, angle_diff


@dataclass
class PlayerDrivingProfile:
    speeds: deque = field(default_factory=lambda: deque(maxlen=600))
    braking_events: int = 0
    collision_events: int = 0
    preferred_roads: Counter = field(default_factory=Counter)
    preferred_districts: Counter = field(default_factory=Counter)
    turn_angle_sum: float = 0.0
    turn_samples: int = 0
    route_length: float = 0.0
    time_in_open_area: float = 0.0
    time_in_dense_area: float = 0.0
    vehicle_changes: int = 0
    hiding_attempts: int = 0

    _last_position: Vector2 | None = None
    _last_heading: float | None = None

    def record_tick(self, dt: float, *, position: Vector2, heading: float, speed: float,
                     braking: bool, district_kind: str, district_density: float,
                     current_road_type: str | None) -> None:
        self.speeds.append(speed)
        if braking and speed > 5.0:
            self.braking_events += 1
        if current_road_type:
            self.preferred_roads[current_road_type] += dt
        self.preferred_districts[district_kind] += dt

        if self._last_heading is not None:
            self.turn_angle_sum += abs(angle_diff(heading, self._last_heading))
            self.turn_samples += 1
        self._last_heading = heading

        if self._last_position is not None:
            self.route_length += self._last_position.distance_to(position)
        self._last_position = position.copy()

        if district_density > 0.55:
            self.time_in_dense_area += dt
        else:
            self.time_in_open_area += dt

    def record_collision(self) -> None:
        self.collision_events += 1

    def record_vehicle_change(self) -> None:
        self.vehicle_changes += 1

    def record_hiding_attempt(self) -> None:
        self.hiding_attempts += 1

    # ------------------------------------------------------------------
    def average_speed(self) -> float:
        return sum(self.speeds) / len(self.speeds) if self.speeds else 0.0

    def max_speed(self) -> float:
        return max(self.speeds) if self.speeds else 0.0

    def average_turn_angle(self) -> float:
        return self.turn_angle_sum / self.turn_samples if self.turn_samples else 0.0

    def highway_bias(self) -> float:
        total = sum(self.preferred_roads.values()) or 1.0
        return self.preferred_roads.get("HIGHWAY", 0.0) / total

    def industrial_bias(self) -> float:
        total = sum(self.preferred_districts.values()) or 1.0
        return self.preferred_districts.get("INDUSTRIAL", 0.0) / total

    def vehicle_change_uncertainty(self) -> float:
        """More frequent vehicle swaps -> police should trust vehicle_desc less."""
        return min(1.0, self.vehicle_changes / 6.0)

    def underground_watch_bias(self) -> float:
        return min(1.0, self.hiding_attempts / 5.0)
