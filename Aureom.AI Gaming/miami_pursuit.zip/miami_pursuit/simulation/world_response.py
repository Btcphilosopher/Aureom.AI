"""
Bridges PlayerDrivingProfile + ReputationTracker into concrete weighting the
PursuitManager can use (spec section 23: adaptive pursuit). All of it is
derived from *observed* behaviour this session - never from hidden
knowledge of the player's plans.
"""

from __future__ import annotations

from world.roads import Road, RoadNetwork, RoadType
from simulation.reputation import ReputationTracker
from simulation.telemetry import PlayerDrivingProfile


def get_route_bias(network: RoadNetwork, profile: PlayerDrivingProfile) -> dict[int, float]:
    """road_id -> weight multiplier for Dijkstra. Lower multiplier = police
    consider that road more strongly (it "costs less" to commit to it)."""
    bias: dict[int, float] = {}
    highway_bias = profile.highway_bias()
    industrial_bias = profile.industrial_bias()
    for road_id, road in network.roads.items():
        multiplier = 1.0
        if road.road_type == RoadType.HIGHWAY:
            multiplier *= max(0.6, 1.0 - highway_bias * 0.5)
        if road.road_type == RoadType.INDUSTRIAL_ROAD:
            multiplier *= max(0.6, 1.0 - industrial_bias * 0.5)
        bias[road_id] = multiplier
    return bias


def get_district_watch(reputation: ReputationTracker, profile: PlayerDrivingProfile, district_kind: str) -> float:
    base = reputation.alertness(district_kind)
    if district_kind == "INDUSTRIAL":
        base += profile.industrial_bias() * 0.2
    return min(1.0, base)
