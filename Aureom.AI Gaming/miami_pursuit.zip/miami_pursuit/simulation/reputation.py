"""Per-district reputation: districts that see repeated incidents get a
slightly more alert baseline (spec section 23 - adaptive, session-scoped,
never omniscient)."""

from __future__ import annotations

from collections import defaultdict


class ReputationTracker:
    def __init__(self) -> None:
        self.incident_counts: dict[str, int] = defaultdict(int)

    def record_incident(self, district_kind: str) -> None:
        self.incident_counts[district_kind] += 1

    def alertness(self, district_kind: str) -> float:
        """0..1 extra alertness bias for a district, saturating slowly."""
        count = self.incident_counts.get(district_kind, 0)
        return min(0.35, count * 0.03)
