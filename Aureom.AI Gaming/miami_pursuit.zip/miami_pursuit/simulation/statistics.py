"""1Hz aggregate statistics + chase scoring (spec sections 22, 29)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SimulationStatistics:
    active_vehicles: int = 0
    active_pedestrians: int = 0
    active_pursuits: int = 0
    average_pursuit_pressure: float = 0.0
    _pressure_samples: list = field(default_factory=list)

    def sample(self, *, active_vehicles: int, active_pedestrians: int, active_pursuits: int, pursuit_pressure: float) -> None:
        self.active_vehicles = active_vehicles
        self.active_pedestrians = active_pedestrians
        self.active_pursuits = active_pursuits
        self._pressure_samples.append(pursuit_pressure)
        if len(self._pressure_samples) > 120:
            self._pressure_samples.pop(0)
        self.average_pursuit_pressure = sum(self._pressure_samples) / len(self._pressure_samples)


@dataclass
class ChaseScore:
    distance_travelled: float = 0.0
    duration: float = 0.0
    evasive_maneuvers: int = 0
    near_misses: int = 0
    route_complexity: float = 0.0
    successful_escape: bool = False
    vehicle_preservation: float = 1.0

    def total(self) -> float:
        score = (
            self.distance_travelled * 0.02
            + self.duration * 1.5
            + self.evasive_maneuvers * 12.0
            + self.near_misses * 8.0
            + self.route_complexity * 5.0
            + (150.0 if self.successful_escape else 0.0)
            + self.vehicle_preservation * 60.0
        )
        return round(score, 1)
