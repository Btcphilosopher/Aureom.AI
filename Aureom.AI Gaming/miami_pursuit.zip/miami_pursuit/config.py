"""
Global tuning constants for the Miami Pursuit Engine.

Nothing in this module imports pygame or any other project module, so it can
be safely imported from anywhere (including headless tests) without pulling
in rendering dependencies.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Display / loop
# ---------------------------------------------------------------------------
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 800
WINDOW_TITLE = "Miami Pursuit Engine"

TARGET_FPS = 60
FIXED_DT = 1.0 / 60.0          # physics / player update rate
MAX_FRAME_DT = 0.25            # clamp huge dt spikes (alt-tab, breakpoints)

RANDOM_SEED = 1337             # deterministic default seed

# ---------------------------------------------------------------------------
# Subsystem update frequencies (Hz) - see spec section 33 (performance)
# ---------------------------------------------------------------------------
FREQ_PLAYER = 60.0
FREQ_PHYSICS = 60.0
FREQ_NEARBY_VEHICLES = 30.0
FREQ_DISTANT_VEHICLES = 10.0
FREQ_POLICE_DECISION = 8.0
FREQ_WORLD_SIM = 2.0
FREQ_STATISTICS = 1.0

# ---------------------------------------------------------------------------
# World scale
# ---------------------------------------------------------------------------
WORLD_WIDTH = 6000.0
WORLD_HEIGHT = 4000.0

ACTIVE_SECTOR_RADIUS = 900.0
WARM_SECTOR_RADIUS = 2200.0
SECTOR_SIZE = 500.0

# ---------------------------------------------------------------------------
# Vehicle stats table: (max_speed m/s, engine_power, mass kg, traction,
# braking, handling[steer rate rad/s @ low speed])
# ---------------------------------------------------------------------------
VEHICLE_STATS = {
    "SPORTS":    dict(max_speed=62.0, engine_power=9200.0,  mass=1250.0, traction=1.05, braking=9.0, handling=3.4),
    "SUPERCAR":  dict(max_speed=78.0, engine_power=12500.0, mass=1350.0, traction=1.10, braking=10.0, handling=3.2),
    "SEDAN":     dict(max_speed=48.0, engine_power=6200.0,  mass=1450.0, traction=0.95, braking=7.5, handling=2.8),
    "SUV":       dict(max_speed=42.0, engine_power=6800.0,  mass=2100.0, traction=0.85, braking=6.5, handling=2.2),
    "VAN":       dict(max_speed=38.0, engine_power=5200.0,  mass=2300.0, traction=0.80, braking=6.0, handling=1.9),
    "TRUCK":     dict(max_speed=34.0, engine_power=7000.0,  mass=4200.0, traction=0.75, braking=5.0, handling=1.4),
    "MOTORCYCLE":dict(max_speed=58.0, engine_power=3800.0,  mass=220.0,  traction=0.90, braking=8.5, handling=4.2),
    "POLICE":    dict(max_speed=54.0, engine_power=7800.0,  mass=1650.0, traction=1.00, braking=8.5, handling=3.0),
    "AMBULANCE": dict(max_speed=44.0, engine_power=6400.0,  mass=2400.0, traction=0.85, braking=6.5, handling=2.0),
    "FIRE":      dict(max_speed=36.0, engine_power=8200.0,  mass=6500.0, traction=0.70, braking=5.0, handling=1.2),
    "BUS":       dict(max_speed=32.0, engine_power=6600.0,  mass=8000.0, traction=0.70, braking=4.5, handling=1.1),
}

# ---------------------------------------------------------------------------
# Surface friction multipliers
# ---------------------------------------------------------------------------
SURFACE_FRICTION = {
    "ASPHALT": 1.00,
    "DIRT": 0.72,
    "SAND": 0.55,
    "GRASS": 0.65,
    "WATER": 0.15,
    "METAL": 0.85,
}

# ---------------------------------------------------------------------------
# Weather modifiers: (visibility, traction, police_detection)
# ---------------------------------------------------------------------------
WEATHER_MODIFIERS = {
    "CLEAR":      dict(visibility=1.00, traction=1.00, detection=1.00),
    "RAIN":       dict(visibility=0.80, traction=0.85, detection=0.90),
    "HEAVY_RAIN": dict(visibility=0.60, traction=0.70, detection=0.75),
    "FOG":        dict(visibility=0.40, traction=0.95, detection=0.55),
    "STORM":      dict(visibility=0.45, traction=0.60, detection=0.65),
}

# ---------------------------------------------------------------------------
# Wanted / heat system
# ---------------------------------------------------------------------------
WANTED_LEVEL_THRESHOLDS = [0.0, 15.0, 40.0, 70.0, 100.0, 140.0]  # heat -> level
MAX_HEAT = 160.0
HEAT_DECAY_BASE = 3.0            # heat/sec when totally unseen
HEAT_DECAY_CONCEALED_MULT = 3.5  # multiplier while inside a safehouse/garage
ESCAPE_CONFIDENCE_THRESHOLD = 0.18
ESCAPE_REQUIRED_SECONDS = 12.0

# Response parameters per wanted level:
# (response_time_sec, coordination 0..1, search_radius_m, prediction_quality 0..1, max_units)
WANTED_RESPONSE_PARAMS = {
    0: dict(response_time=999.0, coordination=0.0, search_radius=0.0, prediction_quality=0.0, max_units=0),
    1: dict(response_time=14.0, coordination=0.25, search_radius=350.0, prediction_quality=0.35, max_units=2),
    2: dict(response_time=9.0, coordination=0.45, search_radius=550.0, prediction_quality=0.55, max_units=4),
    3: dict(response_time=6.0, coordination=0.65, search_radius=800.0, prediction_quality=0.70, max_units=6),
    4: dict(response_time=4.0, coordination=0.80, search_radius=1100.0, prediction_quality=0.82, max_units=9),
    5: dict(response_time=2.5, coordination=0.95, search_radius=1500.0, prediction_quality=0.93, max_units=13),
}

# ---------------------------------------------------------------------------
# Police resource economy (finite abstract resources - section 36)
# ---------------------------------------------------------------------------
POLICE_RESOURCE_POOL = dict(patrol_units=10, interceptors=5, supervisors=2, response_capacity=14)

# ---------------------------------------------------------------------------
# Colors (RGB) - used only by the rendering layer
# ---------------------------------------------------------------------------
COLOR_BG_NIGHT = (10, 14, 26)
COLOR_BG_DAY = (58, 110, 130)
COLOR_ROAD_STREET = (70, 70, 78)
COLOR_ROAD_HIGHWAY = (255, 196, 60)
COLOR_ROAD_INDUSTRIAL = (110, 100, 80)
COLOR_WATER = (32, 90, 140)
COLOR_BUILDING = (60, 62, 70)
COLOR_PLAYER = (60, 220, 255)
COLOR_POLICE = (60, 120, 255)
COLOR_CIVILIAN = (200, 200, 210)
COLOR_PEDESTRIAN = (230, 210, 160)
COLOR_SAFEHOUSE = (60, 220, 120)
COLOR_SEARCH_AREA = (255, 90, 60)
COLOR_HUD_TEXT = (235, 235, 240)

DISTRICT_COLORS = {
    "DOWNTOWN": (46, 50, 66),
    "FINANCIAL": (52, 58, 82),
    "SUBURBS": (58, 74, 56),
    "INDUSTRIAL": (66, 60, 50),
    "AIRPORT": (70, 70, 74),
    "PORT": (48, 62, 74),
    "BEACH": (196, 178, 120),
    "WETLANDS": (52, 78, 60),
    "HIGHWAY_CORRIDOR": (40, 40, 44),
}
