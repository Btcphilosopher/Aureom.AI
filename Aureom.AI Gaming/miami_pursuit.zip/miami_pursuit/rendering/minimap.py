"""Small top-right minimap. Police outside detection/search range are
deliberately not shown, matching spec section 31."""

from __future__ import annotations

import pygame

import config
from ai.police_ai import PursuitState
from engine.physics import Vector2


class Minimap:
    def __init__(self, surface: pygame.Surface, size: int = 190, margin: int = 16, scale: float = 0.045):
        self.surface = surface
        self.size = size
        self.margin = margin
        self.scale = scale

    def _project(self, world_pos: Vector2, center: Vector2, origin: tuple[int, int]) -> tuple[float, float]:
        dx = (world_pos.x - center.x) * self.scale
        dy = (world_pos.y - center.y) * self.scale
        return (origin[0] + self.size / 2 + dx, origin[1] + self.size / 2 + dy)

    def draw(self, world, player_position: Vector2, pursuit_manager, safe_locations) -> None:
        w = self.surface.get_width()
        origin = (w - self.size - self.margin, self.margin)
        panel = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        panel.fill((10, 12, 18, 210))

        network = world.city.road_network
        for road in network.roads.values():
            a = network.nodes[road.node_a].position
            b = network.nodes[road.node_b].position
            pa = self._project(a, player_position, (0, 0))
            pb = self._project(b, player_position, (0, 0))
            if 0 <= pa[0] <= self.size or 0 <= pb[0] <= self.size:
                pygame.draw.line(panel, (90, 90, 100), pa, pb, 1)

        for loc in safe_locations:
            p = self._project(loc.position, player_position, (0, 0))
            if 0 <= p[0] <= self.size and 0 <= p[1] <= self.size:
                pygame.draw.circle(panel, config.COLOR_SAFEHOUSE, p, 3)

        if pursuit_manager.search_area is not None:
            p = self._project(pursuit_manager.search_area.center, player_position, (0, 0))
            r = max(3, int(pursuit_manager.search_area.radius * self.scale))
            pygame.draw.circle(panel, config.COLOR_SEARCH_AREA, p, r, 1)

        detection_range_px = self.size * 0.5
        for unit in pursuit_manager.units:
            visible_state = unit.state in (PursuitState.PURSUING.value, PursuitState.INTERCEPTING.value)
            distance_px = player_position.distance_to(unit.position) * self.scale
            if not visible_state and distance_px > detection_range_px * 0.6:
                continue
            p = self._project(unit.position, player_position, (0, 0))
            if 0 <= p[0] <= self.size and 0 <= p[1] <= self.size:
                pygame.draw.circle(panel, config.COLOR_POLICE, p, 3)

        center = (self.size / 2, self.size / 2)
        pygame.draw.circle(panel, config.COLOR_PLAYER, center, 4)
        pygame.draw.rect(panel, (200, 200, 210), panel.get_rect(), 1)

        self.surface.blit(panel, origin)
