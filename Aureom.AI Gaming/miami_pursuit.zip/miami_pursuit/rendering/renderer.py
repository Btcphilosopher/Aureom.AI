"""Main world renderer: roads, buildings, water, weather overlay, day/night
tint, and every dynamic actor (vehicles, pedestrians)."""

from __future__ import annotations

import math

import pygame

import config
from ai.police_ai import PursuitState
from engine.camera import Camera
from world.roads import RoadType
from world.world import World


def _lerp_color(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


class Renderer:
    def __init__(self, surface: pygame.Surface):
        self.surface = surface
        self._rain_offset = 0.0

    def draw_world(self, world: World, camera: Camera) -> None:
        night_amount = 1.0 - world.time.ambient_visibility()
        bg = _lerp_color(config.COLOR_BG_DAY, config.COLOR_BG_NIGHT, night_amount)
        self.surface.fill(bg)

        for water in world.city.water.bodies:
            self._draw_rect(camera, water.bounds, config.COLOR_WATER)

        for road in world.city.road_network.roads.values():
            a = world.city.road_network.nodes[road.node_a].position
            b = world.city.road_network.nodes[road.node_b].position
            color = config.COLOR_ROAD_HIGHWAY if road.road_type == RoadType.HIGHWAY else (
                config.COLOR_ROAD_INDUSTRIAL if road.road_type == RoadType.INDUSTRIAL_ROAD else config.COLOR_ROAD_STREET)
            width = 5 if road.road_type == RoadType.HIGHWAY else max(2, road.lanes)
            self._draw_line(camera, a, b, color, width)

        for building in world.city.buildings.buildings:
            self._draw_rect(camera, building.bounds, config.COLOR_BUILDING)

        for loc in world.city.safe_locations:
            screen = camera.world_to_screen(loc.position)
            pygame.draw.circle(self.surface, config.COLOR_SAFEHOUSE, screen, max(4, int(loc.radius * camera.zoom * 0.3)), 2)

    def draw_vehicle(self, camera: Camera, vehicle, color, is_police: bool = False) -> None:
        screen = camera.world_to_screen(vehicle.position)
        size = 7 * camera.zoom
        forward = (math.cos(vehicle.heading) * size, math.sin(vehicle.heading) * size)
        right = (-forward[1] * 0.55, forward[0] * 0.55)
        p1 = (screen[0] + forward[0], screen[1] + forward[1])
        p2 = (screen[0] - forward[0] * 0.6 + right[0], screen[1] - forward[1] * 0.6 + right[1])
        p3 = (screen[0] - forward[0] * 0.6 - right[0], screen[1] - forward[1] * 0.6 - right[1])
        pygame.draw.polygon(self.surface, color, [p1, p2, p3])
        if is_police and getattr(vehicle, "state", "") in (PursuitState.PURSUING.value, PursuitState.INTERCEPTING.value):
            flash_color = (255, 60, 60) if int(pygame.time.get_ticks() / 150) % 2 == 0 else (60, 60, 255)
            pygame.draw.circle(self.surface, flash_color, screen, max(2, int(3 * camera.zoom)))

    def draw_pedestrian(self, camera: Camera, pedestrian) -> None:
        screen = camera.world_to_screen(pedestrian.position)
        color = (255, 120, 90) if pedestrian.fleeing else config.COLOR_PEDESTRIAN
        pygame.draw.circle(self.surface, color, screen, max(2, int(3 * camera.zoom)))

    def draw_search_area(self, camera: Camera, search_area) -> None:
        if search_area is None:
            return
        screen = camera.world_to_screen(search_area.center)
        radius = max(4, int(search_area.radius * camera.zoom))
        pygame.draw.circle(self.surface, config.COLOR_SEARCH_AREA, screen, radius, 2)

    def draw_weather_overlay(self, world: World) -> None:
        weather = world.weather.current.value
        if weather in ("RAIN", "HEAVY_RAIN", "STORM"):
            self._rain_offset = (self._rain_offset + 14) % 40
            overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)
            alpha = 70 if weather == "RAIN" else 120
            for x in range(-40, self.surface.get_width(), 40):
                for y in range(-40, self.surface.get_height(), 40):
                    start = (x + self._rain_offset, y)
                    end = (x + self._rain_offset - 8, y + 18)
                    pygame.draw.line(overlay, (170, 190, 220, alpha), start, end, 1)
            self.surface.blit(overlay, (0, 0))
        if weather == "FOG":
            overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)
            overlay.fill((200, 200, 210, 90))
            self.surface.blit(overlay, (0, 0))

    def draw_night_overlay(self, world: World) -> None:
        night_amount = 1.0 - world.time.ambient_visibility()
        if night_amount > 0.05:
            overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)
            overlay.fill((5, 8, 20, int(120 * night_amount)))
            self.surface.blit(overlay, (0, 0))

    # ------------------------------------------------------------------
    def _draw_rect(self, camera: Camera, rect, color) -> None:
        x, y = camera.world_to_screen(_pt(rect.x, rect.y))
        w = rect.w * camera.zoom
        h = rect.h * camera.zoom
        if x + w < 0 or y + h < 0 or x > self.surface.get_width() or y > self.surface.get_height():
            return
        pygame.draw.rect(self.surface, color, pygame.Rect(x, y, max(1, w), max(1, h)))

    def _draw_line(self, camera: Camera, a, b, color, width) -> None:
        pa = camera.world_to_screen(a)
        pb = camera.world_to_screen(b)
        pygame.draw.line(self.surface, color, pa, pb, width)


class _Point:
    __slots__ = ("x", "y")

    def __init__(self, x, y):
        self.x, self.y = x, y


def _pt(x, y):
    return _Point(x, y)
