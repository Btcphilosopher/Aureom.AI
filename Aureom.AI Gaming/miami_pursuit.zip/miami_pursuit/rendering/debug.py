"""TAB debug overlay, formatted to match spec section 32's example output."""

from __future__ import annotations

import pygame


class DebugOverlay:
    def __init__(self, surface: pygame.Surface):
        self.surface = surface
        self.font = pygame.font.SysFont("consolas", 15)

    def draw(self, simulation) -> None:
        vehicle = simulation.player.vehicle
        state = simulation.get_pursuit_state()
        prediction_future, _ = simulation.calculate_prediction()

        lines = [
            "PURSUIT MANAGER",
            "----------------",
            "",
            f"TARGET SPEED: {vehicle.speed():.1f} m/s",
            f"TARGET HEADING: {int((vehicle.heading * 180 / 3.14159) % 360):03d}°",
            "",
            "LAST KNOWN POSITION:",
            f"{state['last_known_position']}" if state["last_known_position"] else "UNKNOWN",
            "",
            "PREDICTED POSITION:",
            f"{prediction_future.x:.0f} / {prediction_future.y:.0f}",
            "",
            f"PREDICTION CONFIDENCE: {state['police_confidence']:.2f}",
            "",
            f"ACTIVE POLICE: {state['active_police']}",
            f"PURSUING: {state['pursuing']}",
            f"SEARCHING: {state['searching']}",
            "",
            f"PURSUIT PRESSURE: {state['pursuit_pressure']:.2f}",
            "",
            "CURRENT STRATEGY:",
            state["strategy"],
            "",
            "WORLD",
            f"TRAFFIC: {len(simulation.civilians)} vehicles",
            f"WEATHER: {simulation.world.weather.current.value}",
            f"TIME: {simulation.world.time.hour:.2f}h",
            "",
            "TELEMETRY",
            f"AVG SPEED: {simulation.telemetry.average_speed():.1f} m/s",
            f"COLLISIONS: {simulation.telemetry.collision_events}",
            f"HIGHWAY BIAS: {simulation.telemetry.highway_bias():.2f}",
        ]

        panel = pygame.Surface((300, 24 + len(lines) * 18), pygame.SRCALPHA)
        panel.fill((8, 10, 16, 215))
        y = 8
        for line in lines:
            surf = self.font.render(line, True, (200, 230, 200))
            panel.blit(surf, (10, y))
            y += 18
        self.surface.blit(panel, (16, 90))
