"""HUD: wanted stars, pursuit pressure bar, speed, district/time/weather."""

from __future__ import annotations

import pygame

import config


class HUD:
    def __init__(self, surface: pygame.Surface):
        self.surface = surface
        self.font = pygame.font.SysFont("consolas", 18)
        self.font_small = pygame.font.SysFont("consolas", 14)

    def draw(self, *, wanted_level: int, pursuit_pressure: float, speed_ms: float,
              district_name: str, hour: float, weather: str, fuel: float) -> None:
        w = self.surface.get_width()

        # Wanted stars
        star_text = "".join("★" for _ in range(wanted_level)) + "".join("☆" for _ in range(5 - wanted_level))
        star_surf = self.font.render(f"WANTED: {star_text}", True, (255, 210, 60))
        self.surface.blit(star_surf, (16, 12))

        # Pursuit pressure bar
        bar_x, bar_y, bar_w, bar_h = 16, 42, 220, 14
        pygame.draw.rect(self.surface, (40, 40, 46), (bar_x, bar_y, bar_w, bar_h))
        fill_w = int(bar_w * pursuit_pressure)
        color = (60, 220, 90) if pursuit_pressure < 0.5 else ((255, 200, 60) if pursuit_pressure < 0.8 else (230, 60, 60))
        pygame.draw.rect(self.surface, color, (bar_x, bar_y, fill_w, bar_h))
        pygame.draw.rect(self.surface, (220, 220, 220), (bar_x, bar_y, bar_w, bar_h), 1)
        label = self.font_small.render(f"PURSUIT PRESSURE: {int(pursuit_pressure * 100)}%", True, config.COLOR_HUD_TEXT)
        self.surface.blit(label, (bar_x, bar_y + bar_h + 2))

        # Speed
        speed_kmh = speed_ms * 3.6
        speed_surf = self.font.render(f"{speed_kmh:5.0f} km/h", True, config.COLOR_HUD_TEXT)
        self.surface.blit(speed_surf, (w - speed_surf.get_width() - 16, 12))

        # District / time / weather
        hh = int(hour)
        mm = int((hour - hh) * 60)
        info = f"{district_name}   {hh:02d}:{mm:02d}   {weather}   FUEL {int(fuel * 100)}%"
        info_surf = self.font_small.render(info, True, config.COLOR_HUD_TEXT)
        self.surface.blit(info_surf, (w - info_surf.get_width() - 16, 40))
