# Miami Pursuit Engine

An original, fictional, GTA-inspired **open-world pursuit simulator**. It
does not reproduce any real map, and it does not copy any proprietary
assets or code. The goal is architectural: build the systemic foundation of
a chase — witnesses, wanted heat, predictive police AI, interception,
search-and-decay, escape — as a genuine simulation rather than a scripted
sequence.

> **THE CHASE IS A DYNAMIC SYSTEM, NOT A SCRIPTED CINEMATIC.**
> Do not script the chase. Simulate the chase.

## Quick start

```bash
pip install -r requirements.txt
python main.py
```

Optional flags:

```bash
python main.py --seed 42 --scenario highway_pursuit
```

Scenarios: `downtown_pursuit`, `highway_pursuit`, `industrial_pursuit`,
`airport_pursuit`, `wetland_escape`, `night_pursuit`, `rain_pursuit`,
`multi_vehicle_pursuit`.

## Controls

| Key | Action |
|---|---|
| W / ↑ | throttle |
| S / ↓ | brake / reverse |
| A / ← | steer left |
| D / → | steer right |
| Space | handbrake |
| Shift | boost |
| E | enter / exit vehicle |
| Tab | debug overlay |
| Esc | pause |

## Architecture

```
miami_pursuit/
├── main.py                  entry point (pygame)
├── config.py                all tuning constants, no dependencies
├── engine/                  loop, physics, collision, camera, input
├── world/                   city graph, districts, weather, time-of-day
├── vehicles/                Vehicle + subclasses, generic route-following AI
├── ai/                      pursuit_manager, police_ai, prediction,
│                            interception, search, coordination, traffic_ai
├── characters/              player, pedestrians, the witness pipeline
├── gameplay/                wanted system, crimes, safehouses, scenarios
├── simulation/               telemetry, reputation, adaptive-bias, stats
├── rendering/                pygame-only: renderer, HUD, minimap, debug
└── tests/                    headless pytest suite (no pygame import)
```

`engine/simulation.py` exposes `PursuitSimulation`, a **pygame-free**
simulation core:

```python
from engine.simulation import PursuitSimulation

sim = PursuitSimulation(seed=42)
sim.start_chase(player_id=1)
for _ in range(600):
    sim.update(1 / 60)
print(sim.get_pursuit_state())
```

`main.py` / `engine/game_loop.py` are the only places pygame is imported for
gameplay logic; input, physics, AI and world simulation are entirely
independent of the renderer, which is why the whole thing later migrates to
a 3D engine without touching the simulation layer.

## The core loop the engine actually simulates

```
DRIVE → CAUSE INCIDENT → WITNESS DETECTS IT → REPORT REACHES POLICE
      → POLICE RESPOND (finite resources, real travel time)
      → PLAYER BREAKS LINE OF SIGHT → SEARCH AREA DECAYS
      → PLAYER CHANGES ROUTE → POLICE PREDICT CANDIDATE ROUTES
      → INTERCEPTION ATTEMPT (never a teleport, always a real path)
      → ESCAPE (confidence low + no witness + outside search zone, held)
      → HEAT DECAYS → WORLD RETURNS TO NORMAL
```

Key systemic guarantees:

- **No crime is automatically known.** `gameplay/crimes.py` only emits an
  event; `characters/witness.py` decides, per nearby pedestrian, whether it
  was actually seen (distance, line-of-sight via `world/buildings.py`,
  lighting, weather, crowd density).
- **Wanted level is derived from continuous heat**, not vice-versa
  (`gameplay/wanted_system.py`). Escalation changes response time,
  coordination, search radius and prediction quality — not just "spawn more
  cars" (`config.WANTED_RESPONSE_PARAMS`).
- **Police never get your exact position for free.** Direct line-of-sight,
  or delayed/rangelimited/reliability-lossy radio traffic
  (`ai/coordination.py`), are the only channels.
- **Prediction fans out across the road graph** (`ai/prediction.py`) instead
  of pointing straight at the player, and **interception plans are only
  accepted if a real shortest-path travel time makes them plausible**
  (`ai/interception.py`) — no teleporting.
- **Search confidence decays on a curve** and can be reinforced by a fresh
  witness sighting (`ai/search.py`).
- **Adaptive pursuit is session-scoped and observational only**
  (`simulation/telemetry.py`, `simulation/world_response.py`): repeated
  highway use nudges route-weighting toward highways, repeated industrial
  hideouts increase watch there — never omniscient.

## Testing

```bash
pytest
```

The suite (`tests/`) drives `PursuitSimulation` and every AI/physics module
directly, with no pygame import anywhere in the test path, covering vehicle
physics, collision, the witness/wanted pipeline, route prediction,
interception plausibility, search decay, police communication delay/range,
escape detection, and traffic AI (lights, yielding, weather).

## Migration path to 3D

Because `engine/`, `world/`, `vehicles/`, `ai/`, `characters/`, `gameplay/`
and `simulation/` never import pygame (only `rendering/`,
`engine/game_loop.py`, and `engine/input.py`'s key-polling do), swapping the
presentation layer for a 3D engine means writing a new `rendering/` module
and a new `engine/game_loop.py` that call the same `PursuitSimulation` API —
the simulation, AI and world-generation code do not change.

## Disclaimer

This is an original prototype inspired by the *systemic* qualities of
modern open-world crime/action games (dynamic pursuit, witnesses, wanted
heat, predictive AI). It is not affiliated with, endorsed by, or a
reproduction of any specific commercial game, map, or asset.
