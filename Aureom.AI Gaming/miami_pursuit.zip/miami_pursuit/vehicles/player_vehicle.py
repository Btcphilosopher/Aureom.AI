"""The vehicle currently driven by the human player. Thin subclass: all the
interesting behaviour lives in Vehicle; this just documents intent and
gives main.py/game_loop.py a clear type to hand raw ControlInput to."""

from __future__ import annotations

from vehicles.vehicle import Vehicle


class PlayerVehicle(Vehicle):
    pass
