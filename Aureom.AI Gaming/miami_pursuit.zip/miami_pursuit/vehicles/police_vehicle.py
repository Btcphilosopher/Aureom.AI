"""Police vehicle: adds unit role, individual skill attributes, and a
reference to its own PoliceUnitAI state (spec section 12)."""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum

from vehicles.vehicle import Vehicle, VehicleClass
from vehicles.vehicle_ai import RouteFollower


class UnitRole(str, Enum):
    PATROL = "PATROL"
    TRAFFIC = "TRAFFIC"
    INTERCEPTOR = "INTERCEPTOR"
    SUPERVISOR = "SUPERVISOR"


_ROLE_SKILL_BIAS = {
    UnitRole.PATROL: dict(pursuit_speed=0.85, aggression=0.5, patience=0.6, navigation_skill=0.6, prediction_skill=0.45, reaction_time=1.0),
    UnitRole.TRAFFIC: dict(pursuit_speed=0.8, aggression=0.4, patience=0.7, navigation_skill=0.85, prediction_skill=0.55, reaction_time=0.9),
    UnitRole.INTERCEPTOR: dict(pursuit_speed=1.15, aggression=0.85, patience=0.35, navigation_skill=0.7, prediction_skill=0.75, reaction_time=0.55),
    UnitRole.SUPERVISOR: dict(pursuit_speed=0.9, aggression=0.55, patience=0.8, navigation_skill=0.75, prediction_skill=0.85, reaction_time=0.7),
}


class PoliceVehicle(Vehicle):
    def __init__(self, *args, role: UnitRole = UnitRole.PATROL, rng: random.Random | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        rng = rng or random.Random()
        self.role = role
        bias = _ROLE_SKILL_BIAS[role]
        jitter = lambda v: max(0.05, min(1.5, v * rng.uniform(0.9, 1.1)))
        self.skill = jitter(0.6)
        self.reaction_time = jitter(bias["reaction_time"])
        self.pursuit_speed = jitter(bias["pursuit_speed"])
        self.aggression = jitter(bias["aggression"])
        self.patience = jitter(bias["patience"])
        self.navigation_skill = jitter(bias["navigation_skill"])
        self.prediction_skill = jitter(bias["prediction_skill"])
        self.communication_range = 900.0 * (1.2 if role == UnitRole.SUPERVISOR else 1.0)

        self.follower = RouteFollower()
        self.state = "UNAWARE"
        self.assigned_target_id: int | None = None
        self.reaction_timer = 0.0
