"""Ambulance / fire vehicles: react to nearby accidents by routing toward
them, otherwise behave like ordinary civilian traffic. Lightweight - not a
core pursuit participant."""

from __future__ import annotations

from vehicles.civilian_vehicle import CivilianVehicle
from vehicles.vehicle_ai import make_follower
from world.roads import RoadNetwork


class EmergencyVehicle(CivilianVehicle):
    def respond_to(self, incident_position, network: RoadNetwork) -> None:
        start = network.nearest_node(self.position)
        goal = network.nearest_node(incident_position)
        path = network.shortest_path(start, goal)
        if len(path) >= 2:
            self.follower = make_follower(path)
