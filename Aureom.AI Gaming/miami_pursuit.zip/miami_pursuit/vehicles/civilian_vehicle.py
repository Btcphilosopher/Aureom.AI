"""Civilian traffic vehicle: wraps a Vehicle with a RouteFollower and simple
re-routing when its path runs out."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from vehicles.vehicle import Vehicle
from vehicles.vehicle_ai import RouteFollower, make_follower
from world.roads import RoadNetwork


class CivilianVehicle(Vehicle):
    def __init__(self, *args, rng: random.Random | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.follower = RouteFollower()
        self.rng = rng or random.Random()
        self.panic = False  # true when fleeing a chase/collision nearby

    def ensure_route(self, network: RoadNetwork) -> None:
        if self.follower.has_route():
            return
        start = network.nearest_node(self.position)
        candidates = network.neighbors(start)
        if not candidates:
            return
        goal = self.rng.choice(list(network.nodes.keys()))
        path = network.shortest_path(start, goal)
        if len(path) < 2:
            path = [start, self.rng.choice(candidates)]
        self.follower = make_follower(path)
