"""Base Vehicle class shared by player, civilian, police and emergency
vehicles. Physics integration is delegated to engine/physics.py; this class
owns state (position, damage, fuel) and applies gradual damage/degradation
rather than instant destruction (spec section 21)."""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum

from config import VEHICLE_STATS
from engine.input import ControlInput
from engine.physics import Vector2, integrate_vehicle_motion, clamp
from world.terrain import Surface

_id_counter = itertools.count(1)


class VehicleClass(str, Enum):
    SPORTS = "SPORTS"
    SUPERCAR = "SUPERCAR"
    SEDAN = "SEDAN"
    SUV = "SUV"
    VAN = "VAN"
    TRUCK = "TRUCK"
    MOTORCYCLE = "MOTORCYCLE"
    POLICE = "POLICE"
    AMBULANCE = "AMBULANCE"
    FIRE = "FIRE"
    BUS = "BUS"


@dataclass
class Vehicle:
    vehicle_class: VehicleClass
    position: Vector2
    heading: float = 0.0
    velocity: Vector2 = field(default_factory=Vector2)
    controls: ControlInput = field(default_factory=ControlInput)

    engine_health: float = 1.0
    body_health: float = 1.0
    tyre_health: float = 1.0
    steering_health: float = 1.0
    fuel: float = 1.0

    lateral_slip: float = 0.0
    last_collision_speed: float = 0.0
    id: int = field(default_factory=lambda: next(_id_counter))

    def __post_init__(self) -> None:
        self._stats = VEHICLE_STATS[self.vehicle_class.value]

    @property
    def max_speed(self) -> float:
        return self._stats["max_speed"] * (0.4 + 0.6 * self.engine_health) * (0.5 + 0.5 * self.tyre_health)

    @property
    def mass(self) -> float:
        return self._stats["mass"]

    def speed(self) -> float:
        return self.velocity.length()

    def is_disabled(self) -> bool:
        return self.engine_health <= 0.05 or self.tyre_health <= 0.03

    def apply_damage(self, impact_speed: float) -> None:
        """Gradual degradation, never instant destruction."""
        if impact_speed <= 0.5:
            return
        severity = clamp(impact_speed / 40.0, 0.0, 1.0)
        self.body_health = max(0.0, self.body_health - severity * 0.22)
        self.engine_health = max(0.0, self.engine_health - severity * 0.12)
        self.steering_health = max(0.0, self.steering_health - severity * 0.10)
        self.tyre_health = max(0.0, self.tyre_health - severity * 0.08)
        self.last_collision_speed = impact_speed

    def repair(self, amount: float = 1.0) -> None:
        self.engine_health = min(1.0, self.engine_health + amount)
        self.body_health = min(1.0, self.body_health + amount)
        self.tyre_health = min(1.0, self.tyre_health + amount)
        self.steering_health = min(1.0, self.steering_health + amount)

    def update(self, dt: float, surface: Surface, weather_traction: float) -> None:
        if self.fuel <= 0.0:
            self.controls = ControlInput(0, 0, 1.0, False, False)

        effective_handling = self._stats["handling"] * (0.3 + 0.7 * self.steering_health)
        result, slip = integrate_vehicle_motion(
            position=self.position,
            velocity=self.velocity,
            heading=self.heading,
            throttle=self.controls.throttle,
            brake=self.controls.brake,
            steer=self.controls.steer,
            handbrake=self.controls.handbrake,
            boost=self.controls.boost,
            dt=dt,
            max_speed=self.max_speed,
            engine_power=self._stats["engine_power"] * (0.25 + 0.75 * self.engine_health),
            mass=self.mass,
            traction=self._stats["traction"] * (0.4 + 0.6 * self.tyre_health),
            braking_power=self._stats["braking"],
            handling=effective_handling,
            surface_friction=surface.friction(),
            weather_traction=weather_traction,
        )
        self.position, self.velocity, self.heading = result.position, result.velocity, result.heading
        self.lateral_slip = slip

        if self.speed() > 0.5:
            self.fuel = max(0.0, self.fuel - dt * 0.0006 * (1.0 + self.controls.boost * 0.8))
