"""Generic route-following steering used by civilian AND police vehicles.
Given a path (list of road-graph node ids), produces ControlInput that
steers the vehicle toward the next waypoint, respects traffic lights, and
yields to a vehicle immediately ahead."""

from __future__ import annotations

from dataclasses import dataclass, field

from engine.input import ControlInput
from engine.physics import Vector2, angle_diff, clamp
from world.roads import RoadNetwork


@dataclass
class RouteFollower:
    path: list[int] = field(default_factory=list)
    waypoint_index: int = 0
    lane_offset: float = 0.0

    def has_route(self) -> bool:
        return self.waypoint_index < len(self.path)

    def current_target(self, network: RoadNetwork) -> Vector2 | None:
        if not self.has_route():
            return None
        node = network.nodes[self.path[self.waypoint_index]]
        pos = node.position
        if self.lane_offset:
            pos = Vector2(pos.x + self.lane_offset, pos.y)
        return pos

    def advance_if_reached(self, position: Vector2, network: RoadNetwork, threshold: float = 20.0) -> None:
        target = self.current_target(network)
        if target is not None and position.distance_to(target) <= threshold:
            self.waypoint_index += 1

    def remaining_nodes(self) -> list[int]:
        return self.path[self.waypoint_index:]


def make_follower(path: list[int]) -> RouteFollower:
    """Build a RouteFollower from a path where path[0] is the node nearest
    the vehicle's current position - that node is already "reached", so the
    first real target is path[1]."""
    start_index = 1 if len(path) > 1 else 0
    return RouteFollower(path=path, waypoint_index=start_index)


def steer_towards(position: Vector2, heading: float, target: Vector2, max_speed_fraction: float) -> ControlInput:
    to_target = target - position
    if to_target.length() < 1e-6:
        return ControlInput(throttle=0.0, steer=0.0, brake=0.5)
    desired_heading = to_target.angle()
    diff = angle_diff(desired_heading, heading)
    steer = clamp(diff * 1.6, -1.0, 1.0)
    throttle = clamp(max_speed_fraction * (1.0 - min(abs(diff), 1.4) * 0.5), -1.0, 1.0)
    return ControlInput(throttle=throttle, steer=steer, brake=0.0)


def compute_traffic_ai_control(
    *,
    position: Vector2,
    heading: float,
    speed: float,
    follower: RouteFollower,
    network: RoadNetwork,
    vehicle_ahead_distance: float | None,
    desired_gap: float = 14.0,
    speed_limit_fraction: float = 0.85,
) -> ControlInput:
    """Core reactive driving loop for a single AI-controlled vehicle."""
    target = follower.current_target(network)
    if target is None:
        return ControlInput(throttle=0.0, brake=1.0)

    # Traffic light check at the node we're approaching.
    node_id = follower.path[follower.waypoint_index] if follower.has_route() else None
    approach_heading = (target - position).angle()
    must_stop_for_light = False
    if node_id is not None:
        node = network.nodes[node_id]
        dist_to_node = position.distance_to(node.position)
        if node.has_light and dist_to_node < 60.0 and not node.light_is_green(approach_heading):
            must_stop_for_light = True

    control = steer_towards(position, heading, target, speed_limit_fraction)

    if must_stop_for_light:
        control.throttle = 0.0
        control.brake = 1.0
        return control

    if vehicle_ahead_distance is not None and vehicle_ahead_distance < desired_gap * 3.0:
        gap_ratio = clamp(vehicle_ahead_distance / desired_gap, 0.0, 3.0)
        if gap_ratio < 1.0:
            control.throttle = 0.0
            control.brake = clamp(1.2 - gap_ratio, 0.0, 1.0)
        else:
            control.throttle *= clamp((gap_ratio - 1.0) / 2.0, 0.15, 1.0)

    return control
