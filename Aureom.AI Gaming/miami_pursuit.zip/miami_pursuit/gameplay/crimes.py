"""Crime detection: watches the player's behaviour and emits CrimeEvent
objects. A crime event does NOT by itself create a wanted level - it must
first be observed by the witness system (see characters/witness.py)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum

from engine.physics import Vector2


class CrimeType(str, Enum):
    SPEEDING = "SPEEDING"
    RECKLESS_DRIVING = "RECKLESS_DRIVING"
    HIT_PEDESTRIAN = "HIT_PEDESTRIAN"
    COLLISION_WITH_POLICE = "COLLISION_WITH_POLICE"
    TRESPASSING = "TRESPASSING"
    VEHICLE_THEFT = "VEHICLE_THEFT"
    RAN_ROADBLOCK = "RAN_ROADBLOCK"


# Base severities feed directly into witness "noise" and wanted heat gain.
CRIME_SEVERITY = {
    CrimeType.SPEEDING: 0.15,
    CrimeType.RECKLESS_DRIVING: 0.35,
    CrimeType.HIT_PEDESTRIAN: 0.9,
    CrimeType.COLLISION_WITH_POLICE: 0.8,
    CrimeType.TRESPASSING: 0.2,
    CrimeType.VEHICLE_THEFT: 0.5,
    CrimeType.RAN_ROADBLOCK: 0.95,
}


@dataclass
class CrimeEvent:
    kind: CrimeType
    position: Vector2
    sim_time: float
    vehicle_class: str
    severity: float
    noise: float  # 0..1, how loud/visible the event itself is (gunfire, crash sound, etc.)


class CrimeDetector:
    """Stateless-ish detector: call `evaluate` every tick with the player's
    current vehicle + road context; returns a list of freshly triggered
    CrimeEvents (may be empty most ticks)."""

    def __init__(self) -> None:
        self._last_speeding_report = -999.0
        self._recent_collisions: list[float] = []

    def evaluate(self, *, sim_time: float, position: Vector2, speed: float,
                 speed_limit: float, vehicle_class: str, hit_pedestrian: bool,
                 collided_with_police: bool, lateral_slip: float) -> list[CrimeEvent]:
        events: list[CrimeEvent] = []

        if speed > speed_limit * 1.6 and sim_time - self._last_speeding_report > 4.0:
            self._last_speeding_report = sim_time
            events.append(CrimeEvent(CrimeType.SPEEDING, position, sim_time, vehicle_class,
                                      CRIME_SEVERITY[CrimeType.SPEEDING], noise=0.2))

        if lateral_slip > 0.55 and speed > speed_limit * 1.2:
            events.append(CrimeEvent(CrimeType.RECKLESS_DRIVING, position, sim_time, vehicle_class,
                                      CRIME_SEVERITY[CrimeType.RECKLESS_DRIVING], noise=0.35))

        if hit_pedestrian:
            events.append(CrimeEvent(CrimeType.HIT_PEDESTRIAN, position, sim_time, vehicle_class,
                                      CRIME_SEVERITY[CrimeType.HIT_PEDESTRIAN], noise=0.8))

        if collided_with_police:
            events.append(CrimeEvent(CrimeType.COLLISION_WITH_POLICE, position, sim_time, vehicle_class,
                                      CRIME_SEVERITY[CrimeType.COLLISION_WITH_POLICE], noise=0.9))

        return events
