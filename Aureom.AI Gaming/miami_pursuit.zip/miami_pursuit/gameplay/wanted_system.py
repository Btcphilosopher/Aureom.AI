"""
Dynamic wanted/heat system (spec section 9).

Heat is a continuous float; the discrete 0-5 wanted level is derived from
threshold bands. Escalating the response does NOT simply spawn more police -
it changes response_time, coordination, search_radius, prediction_quality
and the number of units the PursuitManager is allowed to commit.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from config import (
    MAX_HEAT,
    WANTED_LEVEL_THRESHOLDS,
    WANTED_RESPONSE_PARAMS,
    HEAT_DECAY_BASE,
    HEAT_DECAY_CONCEALED_MULT,
)
from simulation.heat import compute_decay_rate, compute_escalation


def heat_to_level(heat: float) -> int:
    level = 0
    for i, threshold in enumerate(WANTED_LEVEL_THRESHOLDS):
        if heat >= threshold:
            level = i
    return level


@dataclass
class WantedSystem:
    heat: float = 0.0
    police_confidence: float = 0.0   # 0..1, how sure police are of the player's location
    time_since_report: float = 999.0

    def level(self) -> int:
        return heat_to_level(self.heat)

    def register_report(self, confidence: float, witness_count: int, severity: float) -> None:
        gain = compute_escalation(confidence, witness_count, severity)
        self.heat = min(MAX_HEAT, self.heat + gain)
        self.police_confidence = min(1.0, max(self.police_confidence, confidence))
        self.time_since_report = 0.0

    def decay(self, dt: float, concealed: bool, concealment: float) -> None:
        if self.heat <= 0.0:
            return
        rate = compute_decay_rate(HEAT_DECAY_BASE, self.police_confidence, concealed,
                                   concealment, HEAT_DECAY_CONCEALED_MULT)
        self.heat = max(0.0, self.heat - rate * dt)
        self.time_since_report += dt
        # confidence itself fades a little slower than heat once contact is lost
        self.police_confidence = max(0.0, self.police_confidence - dt * 0.02)
        if self.heat <= 0.0:
            self.police_confidence = 0.0

    def reduce(self, amount: float) -> None:
        self.heat = max(0.0, self.heat - amount)

    def clear(self) -> None:
        self.heat = 0.0
        self.police_confidence = 0.0
        self.time_since_report = 999.0

    def response_params(self) -> dict:
        return WANTED_RESPONSE_PARAMS[self.level()]
