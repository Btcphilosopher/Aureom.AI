"""Pre-configured chase SCENARIOS (spec section 28). These are not scripted
cut-scenes - they just seed initial conditions (district, time of day,
weather, starting wanted level) so the emergent systems play out differently
each time. `main.py --scenario NAME` applies one of these at startup."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Scenario:
    name: str
    description: str
    start_district_kind: str
    time_of_day: float
    weather: str
    starting_heat: float = 0.0
    civilian_density_mult: float = 1.0


SCENARIOS: dict[str, Scenario] = {
    "downtown_pursuit": Scenario("downtown_pursuit", "Downtown pursuit", "DOWNTOWN", 14.0, "CLEAR", 20.0),
    "highway_pursuit": Scenario("highway_pursuit", "Highway pursuit", "HIGHWAY_CORRIDOR", 17.5, "CLEAR", 45.0),
    "industrial_pursuit": Scenario("industrial_pursuit", "Industrial pursuit", "INDUSTRIAL", 22.0, "FOG", 40.0),
    "airport_pursuit": Scenario("airport_pursuit", "Airport pursuit", "AIRPORT", 9.0, "CLEAR", 30.0),
    "wetland_escape": Scenario("wetland_escape", "Wetland escape", "WETLANDS", 20.0, "RAIN", 70.0, 0.4),
    "night_pursuit": Scenario("night_pursuit", "Night-time pursuit", "DOWNTOWN", 1.5, "CLEAR", 35.0, 0.5),
    "rain_pursuit": Scenario("rain_pursuit", "Heavy-rain pursuit", "SUBURBS", 18.0, "HEAVY_RAIN", 30.0),
    "multi_vehicle_pursuit": Scenario("multi_vehicle_pursuit", "Multi-vehicle pursuit", "FINANCIAL", 16.0, "STORM", 95.0),
}


def get_scenario(name: str) -> Scenario:
    return SCENARIOS.get(name, SCENARIOS["downtown_pursuit"])
