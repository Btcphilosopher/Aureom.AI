"""Vehicle storage / switching at GARAGE-type safe locations (spec section
26). Deliberately lightweight: a garage just offers a small rotating list of
vehicle classes the player may switch into while parked inside it."""

from __future__ import annotations

from dataclasses import dataclass, field

from config import VEHICLE_STATS


@dataclass
class Garage:
    available_classes: list[str] = field(default_factory=lambda: ["SEDAN", "SPORTS", "SUV"])

    def swap_options(self) -> list[str]:
        return [c for c in self.available_classes if c in VEHICLE_STATS]
