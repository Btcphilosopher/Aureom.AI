"""Safe locations: garages, safehouses, parking structures, industrial
yards and marinas. Standing inside one boosts heat decay (concealment) and,
for garages, allows swapping the player's vehicle (spec sections 21, 26)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from engine.physics import Vector2


class SafeLocationType(str, Enum):
    GARAGE = "GARAGE"
    SAFEHOUSE = "SAFEHOUSE"
    PARKING_STRUCTURE = "PARKING_STRUCTURE"
    INDUSTRIAL_YARD = "INDUSTRIAL_YARD"
    MARINA = "MARINA"


@dataclass
class SafeLocation:
    kind: SafeLocationType
    position: Vector2
    concealment: float       # 0..1, how much this location accelerates heat decay
    accessibility: float     # 0..1, how easy it is to reach
    police_exposure: float   # 0..1, chance police patrol near it anyway
    capacity: int = 1
    radius: float = 45.0

    def contains(self, position: Vector2) -> bool:
        return self.position.distance_to(position) <= self.radius


def find_nearby_safe_location(position: Vector2, locations: list[SafeLocation], radius: float | None = None) -> SafeLocation | None:
    for loc in locations:
        r = radius if radius is not None else loc.radius
        if position.distance_to(loc.position) <= r:
            return loc
    return None
