"""Lightweight abstract economy (spec section 35): fuel/vehicle/repair
prices drift slowly and feed back into civilian traffic spawn rate."""

from __future__ import annotations

import random
from dataclasses import dataclass

VEHICLE_BASE_PRICES = {
    "SEDAN": 18000, "SUV": 26000, "SPORTS": 65000, "SUPERCAR": 190000,
    "VAN": 22000, "TRUCK": 34000, "MOTORCYCLE": 9000,
}


@dataclass
class Economy:
    fuel_price: float = 3.20
    police_budget_factor: float = 1.0
    rng: random.Random = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.rng is None:
            self.rng = random.Random(7)

    def update(self, dt: float) -> None:
        self.fuel_price = max(1.5, min(6.0, self.fuel_price + self.rng.uniform(-0.01, 0.01) * dt))

    def civilian_density_multiplier(self) -> float:
        # Expensive fuel modestly thins out civilian traffic.
        return max(0.6, 1.3 - (self.fuel_price / 6.0))

    def repair_cost(self, damage_fraction: float, vehicle_class: str) -> float:
        base = VEHICLE_BASE_PRICES.get(vehicle_class, 18000)
        return round(base * 0.18 * damage_fraction, 2)
