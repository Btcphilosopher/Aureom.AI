"""Civilian traffic AI: route following, stopping at red lights, yielding to
a vehicle ahead, and weather visibility effects."""

from engine.physics import Vector2
from vehicles.civilian_vehicle import CivilianVehicle
from vehicles.vehicle import VehicleClass
from vehicles.vehicle_ai import RouteFollower, compute_traffic_ai_control, make_follower
from world.roads import RoadNetwork, RoadType
from world.weather import WeatherSystem, WeatherType


def build_line_network():
    net = RoadNetwork()
    a = net.add_node(Vector2(0, 0))
    b = net.add_node(Vector2(200, 0), has_light=True)
    c = net.add_node(Vector2(400, 0))
    net.add_road(a, b, speed_limit=15, lanes=2, road_type=RoadType.STREET)
    net.add_road(b, c, speed_limit=15, lanes=2, road_type=RoadType.STREET)
    return net, a, b, c


def test_civilian_ensures_and_follows_a_route():
    net, a, b, c = build_line_network()
    civ = CivilianVehicle(vehicle_class=VehicleClass.SEDAN, position=net.nodes[a].position.copy())
    civ.ensure_route(net)
    assert civ.follower.has_route()
    assert civ.follower.path[0] == a


def test_traffic_ai_stops_for_red_light():
    net, a, b, c = build_line_network()
    net.nodes[b].traffic_light_phase = 0.0
    net.nodes[b].traffic_light_period = 12.0
    follower = make_follower([a, b, c])  # waypoint_index=1 -> approaching b
    pos = Vector2(180, 0)  # close to the light at b

    control = compute_traffic_ai_control(
        position=pos, heading=0.0, speed=10.0, follower=follower, network=net,
        vehicle_ahead_distance=None,
    )
    # At phase 0.0 the NS approach is green in our simplified model; verify
    # the function at least produces a deterministic stop/go decision
    # without throwing, and that a red phase does force a stop.
    net.nodes[b].traffic_light_phase = 6.0  # flip half the cycle
    control_flipped = compute_traffic_ai_control(
        position=pos, heading=0.0, speed=10.0, follower=follower, network=net,
        vehicle_ahead_distance=None,
    )
    stopped_somewhere = (control.brake == 1.0 and control.throttle == 0.0) or \
                         (control_flipped.brake == 1.0 and control_flipped.throttle == 0.0)
    assert stopped_somewhere


def test_traffic_ai_yields_to_vehicle_ahead():
    net, a, b, c = build_line_network()
    follower = make_follower([a, b, c])
    pos = Vector2(0, 0)

    clear_control = compute_traffic_ai_control(
        position=pos, heading=0.0, speed=10.0, follower=follower, network=net,
        vehicle_ahead_distance=None,
    )
    blocked_control = compute_traffic_ai_control(
        position=pos, heading=0.0, speed=10.0, follower=follower, network=net,
        vehicle_ahead_distance=5.0, desired_gap=14.0,
    )
    assert blocked_control.throttle <= clear_control.throttle


def test_route_follower_advances_on_reaching_waypoint():
    net, a, b, c = build_line_network()
    follower = RouteFollower(path=[a, b, c])
    close_pos = net.nodes[a].position.copy()
    follower.advance_if_reached(close_pos, net, threshold=500.0)
    assert follower.waypoint_index == 1


def test_weather_reduces_visibility_and_traction():
    weather = WeatherSystem()
    weather.set(WeatherType.CLEAR)
    clear_vis = weather.visibility_modifier()
    weather.set(WeatherType.HEAVY_RAIN)
    rain_vis = weather.visibility_modifier()
    rain_traction = weather.traction_modifier()
    assert rain_vis < clear_vis
    assert rain_traction < 1.0
