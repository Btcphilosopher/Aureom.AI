"""Predictive pursuit: future position estimate + candidate route
enumeration + interception plausibility + search decay + road selection."""

import math

from ai.interception import compute_interception_points
from ai.prediction import predict_candidate_routes, predict_future_position
from ai.search import SearchArea, generate_search_routes
from engine.physics import Vector2
from vehicles.police_vehicle import PoliceVehicle, UnitRole
from vehicles.vehicle import VehicleClass
from world.roads import RoadNetwork, RoadType


def build_test_network() -> RoadNetwork:
    net = RoadNetwork()
    # A simple cross: start -> east (highway), start -> north, start -> south
    start = net.add_node(Vector2(0, 0))
    east = net.add_node(Vector2(500, 0))
    far_east = net.add_node(Vector2(1500, 0))
    north = net.add_node(Vector2(0, -500))
    south = net.add_node(Vector2(0, 500))
    net.add_road(start, east, speed_limit=30, lanes=3, road_type=RoadType.HIGHWAY)
    net.add_road(east, far_east, speed_limit=30, lanes=3, road_type=RoadType.HIGHWAY)
    net.add_road(start, north, speed_limit=15, lanes=2, road_type=RoadType.STREET)
    net.add_road(start, south, speed_limit=15, lanes=2, road_type=RoadType.STREET)
    return net


def test_predict_future_position_moves_along_velocity():
    pos = Vector2(0, 0)
    vel = Vector2(10, 0)
    future = predict_future_position(pos, vel, 3.0)
    assert future.x == 30.0
    assert future.y == 0.0


def test_candidate_routes_prefer_heading_alignment():
    net = build_test_network()
    routes = predict_candidate_routes(net, Vector2(0, 0), heading=0.0, velocity=Vector2(20, 0), depth=2, branch_limit=3)
    assert routes
    best = routes[0]
    # heading 0 points along +x, i.e. toward the highway branch (east).
    east_ish = any(net.nodes[n].position.x > 0 for n in best.nodes)
    assert east_ish


def test_shortest_path_prefers_faster_highway_over_slower_street():
    net = build_test_network()
    east = 2  # far_east node id from build order
    path = net.shortest_path(0, east)
    assert path[0] == 0
    assert path[-1] == east


def test_interception_never_assigns_impossible_arrival():
    net = build_test_network()
    routes = predict_candidate_routes(net, Vector2(0, 0), heading=0.0, velocity=Vector2(25, 0), depth=2)
    unit = PoliceVehicle(vehicle_class=VehicleClass.POLICE, position=Vector2(0, 5000), role=UnitRole.INTERCEPTOR)
    plans = compute_interception_points(net, routes, [unit], player_speed=25.0)
    # A unit 5000m away should not produce high-confidence interceptions
    # against a target only ~1500m from the branch point.
    assert all(p.confidence < 0.5 for p in plans)


def test_search_area_confidence_decays_over_time():
    area = SearchArea(center=Vector2(0, 0), radius=200.0, created_time=0.0)
    c0 = area.confidence(0.0)
    c10 = area.confidence(10.0)
    c60 = area.confidence(60.0)
    assert c0 == 1.0
    assert c10 < c0
    assert c60 < c10


def test_search_area_reinforcement_restores_confidence():
    area = SearchArea(center=Vector2(0, 0), radius=200.0, created_time=0.0)
    late_confidence = area.confidence(40.0)
    area.reinforce(40.0)
    reinforced_confidence = area.confidence(40.0)
    assert reinforced_confidence > late_confidence


def test_generate_search_routes_returns_nodes_within_radius():
    net = build_test_network()
    area = SearchArea(center=Vector2(0, 0), radius=600.0, created_time=0.0)
    nodes = generate_search_routes(net, area)
    for n in nodes:
        assert net.nodes[n].position.distance_to(area.center) <= 600.0
