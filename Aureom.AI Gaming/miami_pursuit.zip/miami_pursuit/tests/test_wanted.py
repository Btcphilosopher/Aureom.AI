"""Wanted-level escalation/decay and witness detection pipeline."""

import random

from characters.pedestrian import Pedestrian
from characters.witness import DetectionOutcome, evaluate_witnesses
from engine.physics import Vector2
from gameplay.crimes import CrimeEvent, CrimeType
from gameplay.wanted_system import WantedSystem, heat_to_level
from world.buildings import BuildingIndex


def test_heat_to_level_thresholds():
    assert heat_to_level(0.0) == 0
    assert heat_to_level(20.0) == 1
    assert heat_to_level(45.0) == 2
    assert heat_to_level(150.0) == 5


def test_wanted_escalates_on_report():
    ws = WantedSystem()
    ws.register_report(confidence=0.8, witness_count=2, severity=0.9)
    assert ws.heat > 0
    assert ws.level() >= 1
    assert ws.police_confidence == 0.8


def test_wanted_decays_over_time_when_unseen():
    ws = WantedSystem()
    ws.register_report(confidence=0.9, witness_count=3, severity=1.0)
    heat_after_report = ws.heat
    for _ in range(300):
        ws.decay(1 / 30, concealed=False, concealment=0.0)
    assert ws.heat < heat_after_report


def test_concealment_accelerates_decay():
    ws_hidden = WantedSystem()
    ws_open = WantedSystem()
    ws_hidden.register_report(0.9, 3, 1.0)
    ws_open.register_report(0.9, 3, 1.0)
    for _ in range(60):
        ws_hidden.decay(1 / 30, concealed=True, concealment=0.8)
        ws_open.decay(1 / 30, concealed=False, concealment=0.0)
    assert ws_hidden.heat < ws_open.heat


def test_witness_detects_nearby_crime_with_clear_los():
    rng = random.Random(1)
    buildings = BuildingIndex()
    peds = [Pedestrian(position=Vector2(10, 0), awareness=0.95) for _ in range(3)]
    event = CrimeEvent(kind=CrimeType.HIT_PEDESTRIAN, position=Vector2(0, 0), sim_time=0.0,
                        vehicle_class="SEDAN", severity=0.9, noise=0.8)
    report = evaluate_witnesses(event=event, pedestrians=peds, buildings=buildings,
                                 lighting=1.0, weather_detection=1.0, rng=rng)
    assert report is not None
    assert report.witness_count >= 1
    assert report.outcome != DetectionOutcome.NONE


def test_witness_far_away_rarely_detects():
    rng = random.Random(2)
    buildings = BuildingIndex()
    peds = [Pedestrian(position=Vector2(5000, 5000), awareness=0.3)]
    event = CrimeEvent(kind=CrimeType.SPEEDING, position=Vector2(0, 0), sim_time=0.0,
                        vehicle_class="SEDAN", severity=0.15, noise=0.2)
    report = evaluate_witnesses(event=event, pedestrians=peds, buildings=buildings,
                                 lighting=1.0, weather_detection=1.0, rng=rng)
    assert report is None
