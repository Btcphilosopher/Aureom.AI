"""PursuitManager: escalation, unit assignment, coordination network delay,
and escape detection."""

import random

from ai.coordination import CommunicationNetwork, SharedIntel
from ai.pursuit_manager import PursuitManager
from config import ESCAPE_REQUIRED_SECONDS
from engine.physics import Vector2
from world.buildings import BuildingIndex
from world.roads import RoadNetwork, RoadType


def build_manager() -> PursuitManager:
    net = RoadNetwork()
    a = net.add_node(Vector2(0, 0))
    b = net.add_node(Vector2(400, 0))
    c = net.add_node(Vector2(800, 0))
    net.add_road(a, b, speed_limit=20, lanes=2, road_type=RoadType.STREET)
    net.add_road(b, c, speed_limit=20, lanes=2, road_type=RoadType.STREET)
    buildings = BuildingIndex()
    return PursuitManager(net, buildings, rng=random.Random(5))


def test_report_incident_raises_wanted_level_and_spawns_units():
    pm = build_manager()
    pm.report_incident(position=Vector2(0, 0), direction=0.0, confidence=0.9,
                        witness_count=3, severity=0.9, sim_time=0.0)
    assert pm.wanted.level() >= 1

    for i in range(40):
        pm.update(1 / 60, i / 60, player_position=Vector2(0, 0), player_velocity=Vector2(10, 0),
                   player_heading=0.0, concealed=False, concealment=0.0, visibility_modifier=1.0)
    assert len(pm.units) > 0


def test_pursuit_pressure_rises_with_active_pursuers():
    pm = build_manager()
    pm.report_incident(position=Vector2(0, 0), direction=0.0, confidence=1.0,
                        witness_count=4, severity=1.0, sim_time=0.0)
    sim_time = 0.0
    for _ in range(200):
        sim_time += 1 / 30
        pm.update(1 / 30, sim_time, player_position=Vector2(0, 0), player_velocity=Vector2(15, 0),
                   player_heading=0.0, concealed=False, concealment=0.0, visibility_modifier=1.0)
    assert pm.pursuit_pressure >= 0.0  # never negative / never NaN
    assert pm.pursuit_pressure <= 1.0


def test_escape_triggers_after_losing_contact_long_enough():
    pm = build_manager()
    pm.report_incident(position=Vector2(0, 0), direction=0.0, confidence=0.9,
                        witness_count=3, severity=1.0, sim_time=0.0)
    assert pm.wanted.level() >= 1
    pm.wanted.police_confidence = 0.0  # simulate contact already lost
    pm.wanted.time_since_report = 9.0  # simulate no recent witness sighting
    far_away = Vector2(50000, 50000)  # well outside any search area
    sim_time = 0.0
    dt = 1.0
    for _ in range(int(ESCAPE_REQUIRED_SECONDS) + 5):
        sim_time += dt
        pm._check_escape(dt, far_away, sim_time)
    assert pm.telemetry.escapes >= 1


def test_communication_network_delays_delivery():
    comm = CommunicationNetwork(base_delay=2.0, reliability=1.0, rng=random.Random(1))
    intel = SharedIntel(last_known_position=Vector2(0, 0), last_known_direction=0.0,
                         vehicle_desc="sedan", confidence=0.8, search_radius=100.0, sim_time=0.0)
    comm.broadcast(intel, origin=Vector2(0, 0), comm_range=1000.0, sim_time=0.0)
    comm.update(0.5)
    assert comm.intel_within_range(Vector2(0, 0)) is None  # not delivered yet
    comm.update(3.0)
    assert comm.intel_within_range(Vector2(0, 0)) is not None


def test_communication_network_respects_range():
    comm = CommunicationNetwork(base_delay=0.1, reliability=1.0, rng=random.Random(1))
    intel = SharedIntel(last_known_position=Vector2(0, 0), last_known_direction=0.0,
                         vehicle_desc="sedan", confidence=0.8, search_radius=100.0, sim_time=0.0)
    comm.broadcast(intel, origin=Vector2(0, 0), comm_range=50.0, sim_time=0.0)
    comm.update(1.0)
    assert comm.intel_within_range(Vector2(1000, 1000)) is None
    assert comm.intel_within_range(Vector2(10, 10)) is not None
