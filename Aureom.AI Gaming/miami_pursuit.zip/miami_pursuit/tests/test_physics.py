"""Vehicle acceleration / braking / collision / surface & weather effects."""

from engine.collision import Rect, circles_collide, resolve_circle_collision, resolve_rect_collision
from engine.input import ControlInput
from engine.physics import Vector2
from vehicles.vehicle import Vehicle, VehicleClass
from world.terrain import Surface


def make_vehicle(vc=VehicleClass.SEDAN, pos=None):
    return Vehicle(vehicle_class=vc, position=pos or Vector2(0, 0))


def test_vehicle_accelerates_forward_under_throttle():
    v = make_vehicle()
    v.controls = ControlInput(throttle=1.0)
    for _ in range(30):
        v.update(1 / 60, Surface.ASPHALT, 1.0)
    assert v.speed() > 0.5
    assert v.velocity.x > 0  # heading 0 => +x is forward


def test_vehicle_brakes_to_a_stop():
    v = make_vehicle()
    v.velocity = Vector2(20, 0)
    v.controls = ControlInput(throttle=0.0, brake=1.0)
    for _ in range(120):
        v.update(1 / 60, Surface.ASPHALT, 1.0)
    assert v.speed() < 0.5


def test_surface_friction_reduces_effective_grip_speed():
    asphalt = make_vehicle()
    sand = make_vehicle()
    asphalt.controls = ControlInput(throttle=1.0, steer=1.0)
    sand.controls = ControlInput(throttle=1.0, steer=1.0)
    for _ in range(60):
        asphalt.update(1 / 60, Surface.ASPHALT, 1.0)
        sand.update(1 / 60, Surface.SAND, 1.0)
    # Sand has lower friction -> more lateral slip than asphalt under the same input.
    assert sand.lateral_slip >= asphalt.lateral_slip


def test_weather_traction_modifier_reduces_speed_gain():
    dry = make_vehicle()
    wet = make_vehicle()
    dry.controls = ControlInput(throttle=1.0)
    wet.controls = ControlInput(throttle=1.0)
    for _ in range(60):
        dry.update(1 / 60, Surface.ASPHALT, 1.0)
        wet.update(1 / 60, Surface.ASPHALT, 0.6)
    assert dry.speed() >= wet.speed()


def test_gradual_damage_not_instant_destruction():
    v = make_vehicle()
    assert v.engine_health == 1.0
    v.apply_damage(25.0)
    assert 0.0 < v.engine_health < 1.0
    assert not v.is_disabled()


def test_circle_collision_pushes_bodies_apart():
    a_pos, b_pos = Vector2(0, 0), Vector2(5, 0)
    assert circles_collide(a_pos, 9.0, b_pos, 9.0)
    new_a, va, new_b, vb, impact = resolve_circle_collision(
        a_pos, Vector2(10, 0), 1000.0, b_pos, Vector2(-10, 0), 1000.0, 9.0, 9.0)
    assert new_a.distance_to(new_b) > a_pos.distance_to(b_pos)
    assert impact > 0


def test_rect_collision_stops_inward_velocity():
    rect = Rect(10, -5, 20, 10)
    pos = Vector2(8, 0)  # within radius of the rect's left edge (x=10)
    vel = Vector2(15, 0)
    new_pos, new_vel, hit = resolve_rect_collision(pos, vel, 4.0, rect)
    assert hit is True
    assert new_vel.x <= vel.x
