"""
Input abstraction.

`ControlInput` is a plain dataclass with no pygame dependency so AI and tests
can construct synthetic control inputs. `PlayerInputMapper` is the only piece
that talks to pygame, and it imports pygame lazily so this module can still
be imported in headless contexts.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ControlInput:
    throttle: float = 0.0     # -1 (reverse) .. 1 (forward)
    steer: float = 0.0        # -1 (left) .. 1 (right)
    brake: float = 0.0        # 0 .. 1
    handbrake: bool = False
    boost: bool = False


@dataclass
class DiscreteEvents:
    enter_exit: bool = False
    toggle_debug: bool = False
    toggle_pause: bool = False
    quit: bool = False


class PlayerInputMapper:
    """Reads pygame keyboard state and produces ControlInput / DiscreteEvents."""

    def __init__(self) -> None:
        self._prev_enter = False
        self._prev_debug = False
        self._prev_pause = False

    def poll(self) -> tuple[ControlInput, DiscreteEvents]:
        import pygame  # local import keeps this module importable headlessly

        keys = pygame.key.get_pressed()

        throttle = 0.0
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            throttle += 1.0
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            throttle -= 1.0

        steer = 0.0
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            steer -= 1.0
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            steer += 1.0

        brake = 1.0 if (keys[pygame.K_s] or keys[pygame.K_DOWN]) and throttle <= 0.0 else 0.0
        handbrake = bool(keys[pygame.K_SPACE])
        boost = bool(keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])

        control = ControlInput(throttle=throttle, steer=steer, brake=brake,
                                handbrake=handbrake, boost=boost)

        enter_now = bool(keys[pygame.K_e])
        debug_now = bool(keys[pygame.K_TAB])
        pause_now = bool(keys[pygame.K_ESCAPE])

        events = DiscreteEvents(
            enter_exit=enter_now and not self._prev_enter,
            toggle_debug=debug_now and not self._prev_debug,
            toggle_pause=pause_now and not self._prev_pause,
            quit=False,
        )

        self._prev_enter, self._prev_debug, self._prev_pause = enter_now, debug_now, pause_now
        return control, events
