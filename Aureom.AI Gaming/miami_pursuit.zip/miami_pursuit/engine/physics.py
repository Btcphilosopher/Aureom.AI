"""
Lightweight 2D vector math and arcade-style vehicle physics helpers.

Deliberately free of any pygame dependency so the simulation core can run
headless (see engine/simulation.py and the tests/ package).
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class Vector2:
    x: float = 0.0
    y: float = 0.0

    def __add__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar: float) -> "Vector2":
        return Vector2(self.x * scalar, self.y * scalar)

    __rmul__ = __mul__

    def __truediv__(self, scalar: float) -> "Vector2":
        if scalar == 0:
            return Vector2(0.0, 0.0)
        return Vector2(self.x / scalar, self.y / scalar)

    def length(self) -> float:
        return math.hypot(self.x, self.y)

    def length_sq(self) -> float:
        return self.x * self.x + self.y * self.y

    def normalized(self) -> "Vector2":
        length = self.length()
        if length < 1e-9:
            return Vector2(0.0, 0.0)
        return Vector2(self.x / length, self.y / length)

    def dot(self, other: "Vector2") -> float:
        return self.x * other.x + self.y * other.y

    def distance_to(self, other: "Vector2") -> float:
        return math.hypot(self.x - other.x, self.y - other.y)

    def angle(self) -> float:
        """Heading in radians, 0 = facing +x axis, increases clockwise (screen space)."""
        return math.atan2(self.y, self.x)

    def rotated(self, radians: float) -> "Vector2":
        cos_a, sin_a = math.cos(radians), math.sin(radians)
        return Vector2(self.x * cos_a - self.y * sin_a, self.x * sin_a + self.y * cos_a)

    def as_tuple(self) -> tuple:
        return (self.x, self.y)

    def copy(self) -> "Vector2":
        return Vector2(self.x, self.y)


def vector_from_angle(radians: float, length: float = 1.0) -> Vector2:
    return Vector2(math.cos(radians) * length, math.sin(radians) * length)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * clamp(t, 0.0, 1.0)


def angle_diff(a: float, b: float) -> float:
    """Smallest signed difference between two angles (radians), in (-pi, pi]."""
    diff = (a - b + math.pi) % (2 * math.pi) - math.pi
    return diff


def wrap_angle(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi


@dataclass
class KinematicResult:
    position: Vector2
    velocity: Vector2
    heading: float
    speed: float


def integrate_vehicle_motion(
    *,
    position: Vector2,
    velocity: Vector2,
    heading: float,
    throttle: float,
    brake: float,
    steer: float,
    handbrake: bool,
    boost: bool,
    dt: float,
    max_speed: float,
    engine_power: float,
    mass: float,
    traction: float,
    braking_power: float,
    handling: float,
    surface_friction: float,
    weather_traction: float,
) -> tuple[KinematicResult, float]:
    """
    Arcade-realistic vehicle integrator. Returns (KinematicResult, lateral_slip)
    where lateral_slip in [0, 1] indicates how much the car is drifting
    (useful for telemetry / camera shake / tyre wear).
    """
    speed = velocity.length()
    forward = vector_from_angle(heading)

    # Effective traction is reduced by handbrake, poor surface, and weather.
    effective_traction = traction * surface_friction * weather_traction
    effective_traction = clamp(effective_traction, 0.05, 2.0)
    if handbrake:
        effective_traction *= 0.35

    # Steering: full authority at low speed, progressively less at high speed,
    # and reduced further when traction is poor (car "pushes").
    speed_factor = clamp(1.0 - (speed / max(max_speed, 1.0)) * 0.55, 0.35, 1.0)
    steer_rate = handling * speed_factor * effective_traction
    heading += steer * steer_rate * dt * (1.0 if speed >= -0.5 else -1.0)
    heading = wrap_angle(heading)

    # Longitudinal forces.
    accel_input = throttle * (1.4 if boost else 1.0)
    engine_force = engine_power * accel_input / max(mass, 1.0)
    brake_decel = brake * braking_power

    # Current forward speed component (signed, allows reverse).
    forward_speed = velocity.dot(forward)

    if throttle > 0.0:
        forward_speed += engine_force * dt
    elif throttle < 0.0:
        # reverse gear, weaker than forward drive
        forward_speed += engine_force * 0.6 * dt

    if brake > 0.0:
        if forward_speed > 0:
            forward_speed = max(0.0, forward_speed - brake_decel * dt)
        else:
            forward_speed = min(0.0, forward_speed + brake_decel * dt)

    forward_speed = clamp(forward_speed, -max_speed * 0.5, max_speed * (1.15 if boost else 1.0))

    # Rebuild velocity: blend old lateral component (grip loss => slower blend)
    new_forward_velocity = forward * forward_speed
    lateral = velocity - forward * velocity.dot(forward)
    lateral_grip_retention = clamp(1.0 - effective_traction, 0.0, 0.95)
    lateral = lateral * lateral_grip_retention

    new_velocity = new_forward_velocity + lateral

    # Rolling friction / drag.
    drag = 0.995 - (1.0 - surface_friction) * 0.05
    new_velocity = new_velocity * drag

    new_position = position + new_velocity * dt

    lateral_slip = clamp(lateral.length() / max(abs(forward_speed), 1.0), 0.0, 1.0)

    return KinematicResult(new_position, new_velocity, heading, new_velocity.length()), lateral_slip
