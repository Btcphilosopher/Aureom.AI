"""
Simple, cheap collision detection & resolution for circles (vehicles,
pedestrians) and axis-aligned rectangles (buildings).
"""

from __future__ import annotations

from dataclasses import dataclass

from engine.physics import Vector2, clamp


@dataclass
class Rect:
    x: float
    y: float
    w: float
    h: float

    def contains_point(self, p: Vector2) -> bool:
        return self.x <= p.x <= self.x + self.w and self.y <= p.y <= self.y + self.h

    def closest_point(self, p: Vector2) -> Vector2:
        return Vector2(
            clamp(p.x, self.x, self.x + self.w),
            clamp(p.y, self.y, self.y + self.h),
        )

    def center(self) -> Vector2:
        return Vector2(self.x + self.w / 2, self.y + self.h / 2)

    def intersects_rect(self, other: "Rect") -> bool:
        return not (
            self.x + self.w < other.x
            or other.x + other.w < self.x
            or self.y + self.h < other.y
            or other.y + other.h < self.y
        )

    def intersects_segment(self, a: Vector2, b: Vector2) -> bool:
        """Rough segment/rect intersection test used for line-of-sight blocking."""
        if self.contains_point(a) or self.contains_point(b):
            return True
        edges = [
            (Vector2(self.x, self.y), Vector2(self.x + self.w, self.y)),
            (Vector2(self.x + self.w, self.y), Vector2(self.x + self.w, self.y + self.h)),
            (Vector2(self.x + self.w, self.y + self.h), Vector2(self.x, self.y + self.h)),
            (Vector2(self.x, self.y + self.h), Vector2(self.x, self.y)),
        ]
        for c, d in edges:
            if _segments_intersect(a, b, c, d):
                return True
        return False


def _ccw(a: Vector2, b: Vector2, c: Vector2) -> bool:
    return (c.y - a.y) * (b.x - a.x) > (b.y - a.y) * (c.x - a.x)


def _segments_intersect(a: Vector2, b: Vector2, c: Vector2, d: Vector2) -> bool:
    return _ccw(a, c, d) != _ccw(b, c, d) and _ccw(a, b, c) != _ccw(a, b, d)


def circles_collide(pos_a: Vector2, radius_a: float, pos_b: Vector2, radius_b: float) -> bool:
    return pos_a.distance_to(pos_b) <= (radius_a + radius_b)


def resolve_circle_collision(pos_a: Vector2, vel_a: Vector2, mass_a: float,
                              pos_b: Vector2, vel_b: Vector2, mass_b: float,
                              radius_a: float, radius_b: float):
    """
    Simple elastic-ish impulse resolution + positional separation.
    Returns (new_pos_a, new_vel_a, new_pos_b, new_vel_b, impact_speed).
    """
    delta = pos_a - pos_b
    dist = delta.length()
    min_dist = radius_a + radius_b
    if dist < 1e-6:
        delta = Vector2(1.0, 0.0)
        dist = 1e-6
    normal = delta / dist

    overlap = min_dist - dist
    total_mass = mass_a + mass_b
    if overlap > 0:
        push_a = normal * (overlap * (mass_b / total_mass))
        push_b = normal * (-overlap * (mass_a / total_mass))
        pos_a = pos_a + push_a
        pos_b = pos_b + push_b

    rel_vel = vel_a - vel_b
    vel_along_normal = rel_vel.dot(normal)
    impact_speed = abs(vel_along_normal)

    if vel_along_normal < 0:
        restitution = 0.35
        impulse_mag = -(1 + restitution) * vel_along_normal / (1 / mass_a + 1 / mass_b)
        impulse = normal * impulse_mag
        vel_a = vel_a + impulse / mass_a
        vel_b = vel_b - impulse / mass_b

    return pos_a, vel_a, pos_b, vel_b, impact_speed


def resolve_rect_collision(pos: Vector2, vel: Vector2, radius: float, rect: Rect):
    """Push a circular body out of a rectangle (building) and kill inward velocity."""
    closest = rect.closest_point(pos)
    delta = pos - closest
    dist = delta.length()
    if dist >= radius or dist < 1e-9:
        if dist < 1e-9:
            # Center is inside the rect: push out along shortest axis.
            center = rect.center()
            delta = pos - center
            if abs(delta.x) > abs(delta.y):
                pos = Vector2(rect.x + rect.w + radius if delta.x > 0 else rect.x - radius, pos.y)
            else:
                pos = Vector2(pos.x, rect.y + rect.h + radius if delta.y > 0 else rect.y - radius)
            return pos, Vector2(0.0, 0.0), True
        return pos, vel, False

    normal = delta / dist
    penetration = radius - dist
    pos = pos + normal * penetration
    inward = vel.dot(normal)
    if inward < 0:
        vel = vel - normal * inward
    return pos, vel, True
