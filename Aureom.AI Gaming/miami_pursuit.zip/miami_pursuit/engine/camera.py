"""Dynamic chase camera (spec section 30): pulls back at speed, anticipates
turns, and shakes briefly on collision. No pygame dependency - produces a
world-to-screen transform the renderer applies."""

from __future__ import annotations

import random
from dataclasses import dataclass

from engine.physics import Vector2, clamp, lerp, vector_from_angle


@dataclass
class Camera:
    position: Vector2
    zoom: float = 1.0
    shake_timer: float = 0.0
    shake_magnitude: float = 0.0
    screen_w: int = 1280
    screen_h: int = 800

    def trigger_shake(self, intensity: float) -> None:
        self.shake_timer = 0.25
        self.shake_magnitude = max(self.shake_magnitude, intensity)

    def update(self, dt: float, target_position: Vector2, target_heading: float, speed: float,
               max_speed: float, rng: random.Random | None = None) -> None:
        rng = rng or random
        speed_fraction = clamp(speed / max(max_speed, 1.0), 0.0, 1.0)

        # Pull back and zoom out at high speed.
        target_zoom = lerp(1.15, 0.75, speed_fraction)
        self.zoom = lerp(self.zoom, target_zoom, min(1.0, dt * 2.0))

        # Look slightly ahead in the direction of travel.
        lookahead_distance = lerp(20.0, 110.0, speed_fraction)
        lookahead = vector_from_angle(target_heading, lookahead_distance)
        desired = target_position + lookahead

        follow_speed = 4.0
        self.position = Vector2(
            lerp(self.position.x, desired.x, min(1.0, dt * follow_speed)),
            lerp(self.position.y, desired.y, min(1.0, dt * follow_speed)),
        )

        if self.shake_timer > 0:
            self.shake_timer = max(0.0, self.shake_timer - dt)
            offset = Vector2(rng.uniform(-1, 1), rng.uniform(-1, 1)) * self.shake_magnitude
            self.position = self.position + offset
            if self.shake_timer == 0:
                self.shake_magnitude = 0.0

    def world_to_screen(self, world_pos: Vector2) -> tuple[float, float]:
        dx = (world_pos.x - self.position.x) * self.zoom
        dy = (world_pos.y - self.position.y) * self.zoom
        return (self.screen_w / 2 + dx, self.screen_h / 2 + dy)
