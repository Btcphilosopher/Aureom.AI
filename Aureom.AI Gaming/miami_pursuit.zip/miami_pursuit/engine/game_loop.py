"""Pygame-facing game loop: fixed-timestep simulation updates, input
polling, camera update, and layered rendering (world -> weather/night
overlay -> minimap -> HUD -> debug overlay)."""

from __future__ import annotations

import random

import pygame

import config
from engine.camera import Camera
from engine.input import PlayerInputMapper
from engine.simulation import PursuitSimulation
from rendering.debug import DebugOverlay
from rendering.hud import HUD
from rendering.minimap import Minimap
from rendering.renderer import Renderer


class GameLoop:
    def __init__(self, simulation: PursuitSimulation):
        pygame.init()
        pygame.display.set_caption(config.WINDOW_TITLE)
        self.screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()

        self.simulation = simulation
        self.input_mapper = PlayerInputMapper()
        self.camera = Camera(position=simulation.player.position.copy(),
                              screen_w=config.SCREEN_WIDTH, screen_h=config.SCREEN_HEIGHT)
        self.renderer = Renderer(self.screen)
        self.hud = HUD(self.screen)
        self.minimap = Minimap(self.screen)
        self.debug_overlay = DebugOverlay(self.screen)

        self.paused = False
        self.show_debug = False
        self._rng = random.Random(1)
        self._last_wanted_level = 0

    def run(self) -> None:
        running = True
        while running:
            frame_dt = min(self.clock.tick(config.TARGET_FPS) / 1000.0, config.MAX_FRAME_DT)

            for pg_event in pygame.event.get():
                if pg_event.type == pygame.QUIT:
                    running = False

            control, events = self.input_mapper.poll()
            if events.toggle_pause:
                self.paused = not self.paused
            if events.toggle_debug:
                self.show_debug = not self.show_debug
            if events.enter_exit:
                self._handle_enter_exit()

            if not self.paused:
                vehicle = self.simulation.player.vehicle
                if vehicle is not None:
                    vehicle.controls = control
                self.simulation.update(frame_dt)
                self._detect_collision_shake()

            self._update_camera(frame_dt)
            self._draw()

            pygame.display.flip()

        pygame.quit()

    def _handle_enter_exit(self) -> None:
        player = self.simulation.player
        if player.in_vehicle:
            player.exit_vehicle()
        else:
            nearest = min(self.simulation.civilians, key=lambda c: c.position.distance_to(player.position), default=None)
            if nearest is not None and player.position.distance_to(nearest.position) < 40.0:
                player.enter_vehicle(nearest)
                self.simulation.civilians.remove(nearest)

    def _detect_collision_shake(self) -> None:
        vehicle = self.simulation.player.vehicle
        if vehicle is not None and vehicle.last_collision_speed > 8.0:
            self.camera.trigger_shake(min(14.0, vehicle.last_collision_speed * 0.4))

    def _update_camera(self, dt: float) -> None:
        vehicle = self.simulation.player.vehicle
        if vehicle is None:
            return
        self.camera.update(dt, vehicle.position, vehicle.heading, vehicle.speed(), vehicle.max_speed, rng=self._rng)

    def _draw(self) -> None:
        sim = self.simulation
        self.renderer.draw_world(sim.world, self.camera)

        for civ in sim.civilians:
            self.renderer.draw_vehicle(self.camera, civ, config.COLOR_CIVILIAN)
        for unit in sim.pursuit_manager.units:
            self.renderer.draw_vehicle(self.camera, unit, config.COLOR_POLICE, is_police=True)
        for ped in sim.pedestrians:
            self.renderer.draw_pedestrian(self.camera, ped)

        self.renderer.draw_search_area(self.camera, sim.pursuit_manager.search_area)

        if sim.player.vehicle is not None:
            self.renderer.draw_vehicle(self.camera, sim.player.vehicle, config.COLOR_PLAYER)

        self.renderer.draw_weather_overlay(sim.world)
        self.renderer.draw_night_overlay(sim.world)

        district = sim.world.city.district_at(sim.player.position)
        vehicle = sim.player.vehicle
        self.hud.draw(
            wanted_level=sim.pursuit_manager.wanted.level(),
            pursuit_pressure=sim.pursuit_manager.pursuit_pressure,
            speed_ms=vehicle.speed() if vehicle else 0.0,
            district_name=district.name if district else "UNKNOWN",
            hour=sim.world.time.hour,
            weather=sim.world.weather.current.value,
            fuel=vehicle.fuel if vehicle else 1.0,
        )
        self.minimap.draw(sim.world, sim.player.position, sim.pursuit_manager, sim.world.city.safe_locations)

        if self.show_debug and vehicle is not None:
            self.debug_overlay.draw(sim)

        if self.paused:
            font = pygame.font.SysFont("consolas", 42)
            text = font.render("PAUSED", True, (255, 255, 255))
            self.screen.blit(text, (config.SCREEN_WIDTH / 2 - text.get_width() / 2, config.SCREEN_HEIGHT / 2 - 30))
