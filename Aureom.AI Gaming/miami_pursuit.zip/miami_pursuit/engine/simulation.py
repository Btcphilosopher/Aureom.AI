"""
PursuitSimulation: the headless simulation core (spec section 38). Usable
entirely without pygame - `main.py`/`engine/game_loop.py` layer rendering
and input on top of this, and the tests/ package drives it directly.

    simulation = PursuitSimulation()
    simulation.start_chase(player_id=1)
    for _ in range(600):
        simulation.update(1 / 60)
"""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass, field

from ai.pursuit_manager import PursuitManager
from ai.traffic_ai import rebalance_population, spawn_civilian
from characters.pedestrian import Pedestrian
from characters.player import Player
from characters.witness import evaluate_witnesses
from config import FIXED_DT, MAX_FRAME_DT, RANDOM_SEED
from engine.collision import Rect, circles_collide, resolve_circle_collision, resolve_rect_collision
from engine.input import ControlInput
from engine.physics import Vector2, clamp
from gameplay.crimes import CrimeDetector, CrimeEvent
from gameplay.economy import Economy
from gameplay.garages import Garage
from gameplay.missions import Scenario
from gameplay.safehouses import find_nearby_safe_location
from gameplay.wanted_system import heat_to_level
from simulation.reputation import ReputationTracker
from simulation.statistics import ChaseScore, SimulationStatistics
from simulation.telemetry import PlayerDrivingProfile
from vehicles.civilian_vehicle import CivilianVehicle
from vehicles.player_vehicle import PlayerVehicle
from vehicles.vehicle import Vehicle, VehicleClass
from vehicles.vehicle_ai import compute_traffic_ai_control
from world.districts import DistrictType
from world.world import World

_VEHICLE_RADIUS = 9.0
_PEDESTRIAN_RADIUS = 3.0
_INITIAL_CIVILIANS = 45
_INITIAL_PEDESTRIANS = 35


class PursuitSimulation:
    def __init__(self, seed: int = RANDOM_SEED, scenario: Scenario | None = None):
        self.rng = random.Random(seed)
        self.world = World(seed)
        self.economy = Economy(rng=random.Random(seed + 1))
        self.reputation = ReputationTracker()
        self.telemetry = PlayerDrivingProfile()
        self.stats = SimulationStatistics()
        self.chase_score = ChaseScore()
        self.crime_detector = CrimeDetector()
        self.garage = Garage()
        self.pursuit_manager = PursuitManager(self.world.city.road_network, self.world.city.buildings,
                                               rng=random.Random(seed + 2))

        self.player = Player()
        self._spawn_player(scenario)

        if scenario is not None:
            self.world.time.hour = scenario.time_of_day
            from world.weather import WeatherType
            self.world.weather.set(WeatherType(scenario.weather))
            if scenario.starting_heat > 0:
                self.pursuit_manager.wanted.heat = scenario.starting_heat

        self.civilians: list[CivilianVehicle] = []
        self.pedestrians: list[Pedestrian] = []
        self._spawn_initial_population()

        self.sim_time = 0.0
        self.running = True
        self._stats_accum = 0.0
        self._recent_reports = 0

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------
    def _spawn_player(self, scenario: Scenario | None) -> None:
        network = self.world.city.road_network
        target_kind = scenario.start_district_kind if scenario else DistrictType.DOWNTOWN.value
        district = next((d for d in self.world.city.districts if d.kind.value == target_kind), self.world.city.districts[0])
        center = district.bounds.center()
        node_id = network.nearest_node(center)
        pos = network.nodes[node_id].position.copy()
        vehicle = PlayerVehicle(vehicle_class=VehicleClass.SEDAN, position=pos)
        self.player.enter_vehicle(vehicle)
        self.player.position = pos.copy()

    def _spawn_initial_population(self) -> None:
        for _ in range(_INITIAL_CIVILIANS):
            self.civilians.append(spawn_civilian(self.world, self.rng))
        network = self.world.city.road_network
        for _ in range(_INITIAL_PEDESTRIANS):
            node_id = self.rng.choice(list(network.nodes.keys()))
            pos = network.nodes[node_id].position.copy()
            ped = Pedestrian(position=pos, awareness=self.rng.uniform(0.4, 0.9),
                              reaction_time=self.rng.uniform(0.2, 0.6))
            ped.pick_new_destination(self.rng)
            self.pedestrians.append(ped)

    # ------------------------------------------------------------------
    # Simulation API (spec section 38)
    # ------------------------------------------------------------------
    def start_chase(self, player_id: int = 1) -> None:
        self.pursuit_manager.start_chase(player_id)

    def stop_chase(self) -> None:
        self.pursuit_manager.stop_chase()

    def add_witness(self, pedestrian: Pedestrian) -> None:
        self.pedestrians.append(pedestrian)

    def report_incident(self, event: CrimeEvent) -> None:
        self._process_crime_event(event)

    def spawn_police_unit(self, role: str = "PATROL"):
        from vehicles.police_vehicle import UnitRole
        unit = self.pursuit_manager._spawn_unit(UnitRole(role), self.player.position, response_time=4.0)
        if unit is not None:
            self.pursuit_manager.units.append(unit)
        return unit

    def update_pursuit(self, dt: float) -> None:
        self._update_pursuit_manager(dt)

    def calculate_prediction(self, prediction_time: float = 3.0):
        vehicle = self.player.vehicle
        return self.pursuit_manager.calculate_prediction(vehicle.position, vehicle.heading, vehicle.velocity, prediction_time)

    def calculate_interception(self):
        _, routes = self.calculate_prediction()
        return self.pursuit_manager.calculate_interception(routes, self.player.vehicle.speed())

    def create_search_area(self, position: Vector2, radius: float):
        return self.pursuit_manager.create_search_area(position, radius, self.sim_time)

    def reduce_heat(self, amount: float) -> None:
        self.pursuit_manager.reduce_heat(amount)

    def get_pursuit_state(self) -> dict:
        return self.pursuit_manager.get_pursuit_state()

    def __iter__(self):
        return itertools.count()

    # ------------------------------------------------------------------
    # Main tick
    # ------------------------------------------------------------------
    def update(self, dt: float) -> None:
        dt = min(dt, MAX_FRAME_DT)
        self.sim_time += dt
        self.world.update(dt)
        self.economy.update(dt)

        self._update_player_vehicle(dt)
        self._update_civilians(dt)
        self._update_pedestrians(dt)
        self._handle_collisions(dt)
        self._detect_and_report_crimes(dt)
        self._update_pursuit_manager(dt)
        self._update_telemetry(dt)
        self._update_stats(dt)

        if len(self.civilians) < 200 and int(self.sim_time * 4) % 20 == 0:
            self.civilians = rebalance_population(self.world, self.civilians, self.rng,
                                                   self.economy.civilian_density_multiplier(),
                                                   self.player.position, max_population=_INITIAL_CIVILIANS + 40)

    # ------------------------------------------------------------------
    def _current_district(self):
        return self.world.city.district_at(self.player.position)

    def _update_player_vehicle(self, dt: float) -> None:
        vehicle = self.player.vehicle
        if vehicle is None:
            return
        district = self._current_district()
        from world.terrain import Surface
        surface = Surface.WATER if self.world.city.water.blocks(Rect(vehicle.position.x - 1, vehicle.position.y - 1, 2, 2)) else Surface.ASPHALT
        weather_traction = self.world.weather.traction_modifier()
        vehicle.update(dt, surface, weather_traction)
        self.player.sync_position()
        self.chase_score.distance_travelled += vehicle.speed() * dt
        if self.pursuit_manager.wanted.level() > 0:
            self.chase_score.duration += dt
            if vehicle.lateral_slip > 0.6:
                self.chase_score.evasive_maneuvers += 1

    def _update_civilians(self, dt: float) -> None:
        network = self.world.city.road_network
        from world.terrain import Surface
        for civ in self.civilians:
            civ.ensure_route(network)
            civ.follower.advance_if_reached(civ.position, network)
            ahead_dist = self._distance_to_nearest_ahead(civ)
            civ.controls = compute_traffic_ai_control(
                position=civ.position, heading=civ.heading, speed=civ.speed(),
                follower=civ.follower, network=network, vehicle_ahead_distance=ahead_dist,
                speed_limit_fraction=0.55 if civ.panic else 0.85,
            )
            civ.update(dt, Surface.ASPHALT, self.world.weather.traction_modifier())

    def _distance_to_nearest_ahead(self, civ: CivilianVehicle) -> float | None:
        closest = None
        for other in self.civilians:
            if other is civ:
                continue
            d = civ.position.distance_to(other.position)
            if d < 60.0 and (closest is None or d < closest):
                closest = d
        return closest

    def _update_pedestrians(self, dt: float) -> None:
        for ped in self.pedestrians:
            detail = "high" if ped.position.distance_to(self.player.position) < 500.0 else "low"
            if ped.destination.distance_to(ped.position) < 5.0:
                ped.pick_new_destination(self.rng)
            ped.update(dt, detail=detail)

    def _handle_collisions(self, dt: float) -> None:
        vehicle = self.player.vehicle
        if vehicle is None:
            return

        vehicle.last_collision_speed = 0.0
        self._hit_pedestrian_this_tick = False
        self._collided_with_police_this_tick = False

        for building in self.world.city.buildings.nearby(vehicle.position, 60.0):
            new_pos, new_vel, hit = resolve_rect_collision(vehicle.position, vehicle.velocity, _VEHICLE_RADIUS, building.bounds)
            if hit:
                impact = vehicle.velocity.distance_to(new_vel)
                vehicle.apply_damage(impact)
                vehicle.position, vehicle.velocity = new_pos, new_vel

        for civ in self.civilians:
            if circles_collide(vehicle.position, _VEHICLE_RADIUS, civ.position, _VEHICLE_RADIUS):
                p1, v1, p2, v2, impact = resolve_circle_collision(
                    vehicle.position, vehicle.velocity, vehicle.mass,
                    civ.position, civ.velocity, civ.mass, _VEHICLE_RADIUS, _VEHICLE_RADIUS)
                vehicle.position, vehicle.velocity = p1, v1
                civ.position, civ.velocity = p2, v2
                vehicle.apply_damage(impact)
                civ.apply_damage(impact)
                if impact > 4.0:
                    self.telemetry.record_collision()
                    self.chase_score.vehicle_preservation = max(0.0, self.chase_score.vehicle_preservation - 0.02)

        for unit in self.pursuit_manager.units:
            if circles_collide(vehicle.position, _VEHICLE_RADIUS, unit.position, _VEHICLE_RADIUS):
                p1, v1, p2, v2, impact = resolve_circle_collision(
                    vehicle.position, vehicle.velocity, vehicle.mass,
                    unit.position, unit.velocity, unit.mass, _VEHICLE_RADIUS, _VEHICLE_RADIUS)
                vehicle.position, vehicle.velocity = p1, v1
                unit.position, unit.velocity = p2, v2
                vehicle.apply_damage(impact)
                unit.apply_damage(impact)
                if impact > 3.0:
                    self._collided_with_police_this_tick = True
                    self.telemetry.record_collision()

        for ped in self.pedestrians:
            if circles_collide(vehicle.position, _VEHICLE_RADIUS, ped.position, _PEDESTRIAN_RADIUS) and vehicle.speed() > 4.0:
                self._hit_pedestrian_this_tick = True
                ped.notice_event(vehicle.position, intensity=1.0)

    def _detect_and_report_crimes(self, dt: float) -> None:
        vehicle = self.player.vehicle
        if vehicle is None:
            return
        network = self.world.city.road_network
        node_id = network.nearest_node(vehicle.position)
        nearby_roads = network.roads_at(node_id)
        speed_limit = nearby_roads[0].speed_limit if nearby_roads else 16.0

        events = self.crime_detector.evaluate(
            sim_time=self.sim_time, position=vehicle.position, speed=vehicle.speed(),
            speed_limit=speed_limit, vehicle_class=vehicle.vehicle_class.value,
            hit_pedestrian=getattr(self, "_hit_pedestrian_this_tick", False),
            collided_with_police=getattr(self, "_collided_with_police_this_tick", False),
            lateral_slip=vehicle.lateral_slip,
        )
        for event in events:
            self._process_crime_event(event)

    def _process_crime_event(self, event: CrimeEvent) -> None:
        district = self.world.city.district_at(event.position)
        lighting = self.world.visibility_at(district.name if district else "")
        weather_detection = self.world.weather.detection_modifier()

        report = evaluate_witnesses(
            event=event, pedestrians=self.pedestrians, buildings=self.world.city.buildings,
            lighting=lighting, weather_detection=weather_detection, rng=self.rng,
        )
        if report is None:
            return

        if district is not None:
            self.reputation.record_incident(district.kind.value)

        direction = self.player.vehicle.heading if self.player.vehicle else 0.0
        self.pursuit_manager.report_incident(
            position=report.position, direction=direction, confidence=report.confidence,
            witness_count=report.witness_count, severity=event.severity, sim_time=self.sim_time,
            vehicle_desc=event.vehicle_class,
        )

    def _update_pursuit_manager(self, dt: float) -> None:
        vehicle = self.player.vehicle
        if vehicle is None:
            return
        safehouse = find_nearby_safe_location(vehicle.position, self.world.city.safe_locations)
        concealed = safehouse is not None and vehicle.speed() < 3.0
        concealment = safehouse.concealment if safehouse else 0.0
        if concealed:
            self.player.hiding_attempts += 1

        district = self._current_district()
        visibility = self.world.visibility_at(district.name if district else "")

        self.pursuit_manager.update(
            dt, self.sim_time, player_position=vehicle.position, player_velocity=vehicle.velocity,
            player_heading=vehicle.heading, concealed=concealed, concealment=concealment,
            visibility_modifier=visibility,
        )

        if self.pursuit_manager.telemetry.escapes and not self.chase_score.successful_escape:
            self.chase_score.successful_escape = True

    def _update_telemetry(self, dt: float) -> None:
        vehicle = self.player.vehicle
        if vehicle is None:
            return
        district = self._current_district()
        network = self.world.city.road_network
        node_id = network.nearest_node(vehicle.position)
        roads = network.roads_at(node_id)
        road_type = roads[0].road_type.value if roads else None
        density = self.world.traffic_density_at(district.name if district else "", self.economy.civilian_density_multiplier())

        self.telemetry.record_tick(
            dt, position=vehicle.position, heading=vehicle.heading, speed=vehicle.speed(),
            braking=vehicle.controls.brake > 0.1, district_kind=district.kind.value if district else "UNKNOWN",
            district_density=density, current_road_type=road_type,
        )

    def _update_stats(self, dt: float) -> None:
        self._stats_accum += dt
        if self._stats_accum >= 1.0:
            self._stats_accum = 0.0
            self.stats.sample(
                active_vehicles=len(self.civilians) + len(self.pursuit_manager.units) + 1,
                active_pedestrians=len(self.pedestrians),
                active_pursuits=len(self.pursuit_manager.units),
                pursuit_pressure=self.pursuit_manager.pursuit_pressure,
            )
