"""Traffic-light cycling for intersection nodes. Kept separate from
world/roads.py's Node class so the simulation can update lights at a low
frequency without touching the graph structure itself."""

from __future__ import annotations

from world.roads import RoadNetwork


class IntersectionController:
    def __init__(self, network: RoadNetwork) -> None:
        self.network = network

    def update(self, dt: float) -> None:
        for node in self.network.nodes.values():
            if node.has_light:
                node.traffic_light_phase += dt
