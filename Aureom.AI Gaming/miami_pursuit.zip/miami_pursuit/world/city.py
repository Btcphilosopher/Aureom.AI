"""
Procedural, deterministic (seeded) generator for an original Miami-inspired
fictional city. This does NOT reproduce any real map - district layout,
road topology and points of interest are synthesized from a seed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from config import WORLD_WIDTH, WORLD_HEIGHT
from engine.collision import Rect
from engine.physics import Vector2
from gameplay.safehouses import SafeLocation, SafeLocationType
from world.buildings import Building, BuildingIndex
from world.districts import District, DistrictType, DISTRICT_PRESETS
from world.roads import RoadNetwork, RoadType
from world.terrain import Surface
from world.water import WaterBody, WaterSystem

# Layout grid of the city: a 4 x 3 arrangement of district cells.
# Each cell is (col, row) -> DistrictType. Water occupies the eastern
# coastline column plus a wetlands pocket in the south-west.
_LAYOUT = [
    [DistrictType.SUBURBS, DistrictType.DOWNTOWN, DistrictType.FINANCIAL, DistrictType.BEACH],
    [DistrictType.WETLANDS, DistrictType.DOWNTOWN, DistrictType.HIGHWAY_CORRIDOR, DistrictType.PORT],
    [DistrictType.INDUSTRIAL, DistrictType.INDUSTRIAL, DistrictType.AIRPORT, DistrictType.SUBURBS],
]

_GRID_SPACING = {
    DistrictType.DOWNTOWN: 180.0,
    DistrictType.FINANCIAL: 200.0,
    DistrictType.SUBURBS: 260.0,
    DistrictType.INDUSTRIAL: 320.0,
    DistrictType.AIRPORT: 400.0,
    DistrictType.PORT: 300.0,
    DistrictType.BEACH: 280.0,
    DistrictType.WETLANDS: 520.0,
    DistrictType.HIGHWAY_CORRIDOR: 350.0,
}


@dataclass
class City:
    road_network: RoadNetwork
    districts: list[District]
    buildings: BuildingIndex
    water: WaterSystem
    safe_locations: list[SafeLocation] = field(default_factory=list)
    border_nodes: dict[int, list[int]] = field(default_factory=dict)  # district idx -> node ids

    def district_at(self, position: Vector2) -> District | None:
        for d in self.districts:
            if d.contains(position):
                return d
        return None

    def district_by_name(self, name: str) -> District | None:
        for d in self.districts:
            if d.name == name:
                return d
        return None


class CityGenerator:
    def __init__(self, seed: int = 1337):
        self.rng = random.Random(seed)

    def generate(self) -> City:
        rows, cols = len(_LAYOUT), len(_LAYOUT[0])
        cell_w = WORLD_WIDTH / cols
        cell_h = WORLD_HEIGHT / rows

        network = RoadNetwork()
        districts: list[District] = []
        buildings = BuildingIndex()
        water = WaterSystem()
        safe_locations: list[SafeLocation] = []
        district_grid_nodes: list[list[int]] = []  # flattened per-district node ids
        district_rects: list[Rect] = []

        for r in range(rows):
            for c in range(cols):
                kind = _LAYOUT[r][c]
                bounds = Rect(c * cell_w, r * cell_h, cell_w, cell_h)
                preset = DISTRICT_PRESETS[kind]
                district = District(
                    name=f"{kind.value}_{r}_{c}",
                    kind=kind,
                    bounds=bounds,
                    **preset,
                )
                districts.append(district)
                district_rects.append(bounds)

                node_ids = self._generate_district_grid(network, district)
                district_grid_nodes.append(node_ids)

                if kind in (DistrictType.PORT, DistrictType.BEACH):
                    self._add_water_fringe(water, bounds, kind)
                if kind == DistrictType.WETLANDS:
                    self._add_wetland_pools(water, bounds)
                if kind in (DistrictType.DOWNTOWN, DistrictType.FINANCIAL, DistrictType.SUBURBS, DistrictType.INDUSTRIAL):
                    self._scatter_buildings(buildings, bounds, kind)

                safe_locations.extend(self._place_safe_locations(district))

        # Connect adjacent district grids together at their shared border.
        for r in range(rows):
            for c in range(cols):
                idx = r * cols + c
                if c + 1 < cols:
                    self._connect_districts(network, district_grid_nodes[idx],
                                             district_grid_nodes[idx + 1], horizontal=True)
                if r + 1 < rows:
                    self._connect_districts(network, district_grid_nodes[idx],
                                             district_grid_nodes[idx + cols], horizontal=False)

        # A single ring highway loop touching the outer corners of the city,
        # giving pursuit AI a predictable high-speed backbone (spec section 13).
        self._add_highway_loop(network)

        border_nodes = {i: nodes for i, nodes in enumerate(district_grid_nodes)}

        return City(road_network=network, districts=districts, buildings=buildings,
                    water=water, safe_locations=safe_locations, border_nodes=border_nodes)

    # ------------------------------------------------------------------
    def _generate_district_grid(self, network: RoadNetwork, district: District) -> list[int]:
        spacing = _GRID_SPACING[district.kind]
        bounds = district.bounds
        cols = max(2, int(bounds.w // spacing))
        rows = max(2, int(bounds.h // spacing))
        surface = Surface.DIRT if district.kind == DistrictType.WETLANDS else (
            Surface.METAL if district.kind == DistrictType.PORT else Surface.ASPHALT)
        road_type = RoadType.INDUSTRIAL_ROAD if district.kind == DistrictType.INDUSTRIAL else (
            RoadType.DIRT if district.kind == DistrictType.WETLANDS else RoadType.STREET)
        speed_limit = 12.0 if district.kind == DistrictType.WETLANDS else (
            14.0 if district.kind == DistrictType.DOWNTOWN else 18.0)

        grid: dict[tuple[int, int], int] = {}
        for gy in range(rows + 1):
            for gx in range(cols + 1):
                x = bounds.x + gx * (bounds.w / cols) + self.rng.uniform(-8, 8)
                y = bounds.y + gy * (bounds.h / rows) + self.rng.uniform(-8, 8)
                has_light = district.kind in (DistrictType.DOWNTOWN, DistrictType.FINANCIAL) and self.rng.random() < 0.35
                node_id = network.add_node(Vector2(x, y), district=district.name, has_light=has_light)
                grid[(gx, gy)] = node_id

        for gy in range(rows + 1):
            for gx in range(cols + 1):
                here = grid[(gx, gy)]
                if gx + 1 <= cols:
                    self._link(network, here, grid[(gx + 1, gy)], road_type, speed_limit, surface, district)
                if gy + 1 <= rows:
                    self._link(network, here, grid[(gx, gy + 1)], road_type, speed_limit, surface, district)

        return list(grid.values())

    def _link(self, network, a, b, road_type, speed_limit, surface, district) -> None:
        network.add_road(a, b, speed_limit=speed_limit, lanes=2 if road_type == RoadType.STREET else 1,
                          road_type=road_type, traffic_density=district.base_traffic_density,
                          surface=surface, police_access=district.police_access > 0.3)

    def _connect_districts(self, network: RoadNetwork, nodes_a: list[int], nodes_b: list[int], horizontal: bool) -> None:
        if not nodes_a or not nodes_b:
            return
        # connect the few closest node pairs across the border for redundancy
        pairs = []
        sample_a = self.rng.sample(nodes_a, min(6, len(nodes_a)))
        for na in sample_a:
            pos_a = network.nodes[na].position
            nb = min(nodes_b, key=lambda n: network.nodes[n].position.distance_to(pos_a))
            pairs.append((na, nb))
        for na, nb in pairs[:3]:
            network.add_road(na, nb, speed_limit=16.0, lanes=2, road_type=RoadType.STREET,
                              traffic_density=0.4, surface=Surface.ASPHALT)

    def _add_highway_loop(self, network: RoadNetwork) -> None:
        margin = 220.0
        corners = [
            Vector2(margin, margin),
            Vector2(WORLD_WIDTH - margin, margin),
            Vector2(WORLD_WIDTH - margin, WORLD_HEIGHT - margin),
            Vector2(margin, WORLD_HEIGHT - margin),
        ]
        corner_nodes = []
        for corner in corners:
            nearest = network.nearest_node(corner)
            corner_nodes.append(nearest)
        # subdivide each loop edge with a handful of highway nodes for realism
        loop_nodes = []
        for i in range(4):
            a = network.nodes[corner_nodes[i]].position
            b = network.nodes[corner_nodes[(i + 1) % 4]].position
            segment_nodes = [corner_nodes[i]]
            steps = 4
            for s in range(1, steps):
                t = s / steps
                pos = Vector2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)
                segment_nodes.append(network.add_node(pos, district="HIGHWAY_LOOP"))
            loop_nodes.append(segment_nodes)
        flat = [n for seg in loop_nodes for n in seg]
        for i in range(len(flat)):
            a, b = flat[i], flat[(i + 1) % len(flat)]
            network.add_road(a, b, speed_limit=32.0, lanes=3, road_type=RoadType.HIGHWAY,
                              traffic_density=0.45, surface=Surface.ASPHALT, police_access=True)

    def _add_water_fringe(self, water: WaterSystem, bounds: Rect, kind: DistrictType) -> None:
        strip_w = bounds.w * 0.18
        water.add(WaterBody(name=f"coast_{kind.value}", bounds=Rect(bounds.x + bounds.w - strip_w, bounds.y, strip_w, bounds.h),
                             kind="bay" if kind == DistrictType.PORT else "ocean"))

    def _add_wetland_pools(self, water: WaterSystem, bounds: Rect) -> None:
        for _ in range(4):
            w = self.rng.uniform(120, 260)
            h = self.rng.uniform(120, 260)
            x = self.rng.uniform(bounds.x, bounds.x + bounds.w - w)
            y = self.rng.uniform(bounds.y, bounds.y + bounds.h - h)
            water.add(WaterBody(name="wetland_pool", bounds=Rect(x, y, w, h), kind="wetland_pool"))

    def _scatter_buildings(self, buildings: BuildingIndex, bounds: Rect, kind: DistrictType) -> None:
        count = {DistrictType.DOWNTOWN: 28, DistrictType.FINANCIAL: 24,
                 DistrictType.SUBURBS: 16, DistrictType.INDUSTRIAL: 14}.get(kind, 10)
        height = {DistrictType.DOWNTOWN: 3.0, DistrictType.FINANCIAL: 3.5}.get(kind, 1.0)
        for _ in range(count):
            w = self.rng.uniform(40, 110)
            h = self.rng.uniform(40, 110)
            x = self.rng.uniform(bounds.x + 20, bounds.x + bounds.w - w - 20)
            y = self.rng.uniform(bounds.y + 20, bounds.y + bounds.h - h - 20)
            buildings.add(Building(bounds=Rect(x, y, w, h), height=height))

    def _place_safe_locations(self, district: District) -> list[SafeLocation]:
        out = []
        b = district.bounds
        center = Vector2(b.x + b.w / 2, b.y + b.h / 2)

        def pos(dx, dy):
            return Vector2(b.x + b.w * dx, b.y + b.h * dy)

        if district.kind == DistrictType.DOWNTOWN and self.rng.random() < 0.7:
            out.append(SafeLocation(SafeLocationType.PARKING_STRUCTURE, pos(0.3, 0.4), concealment=0.55,
                                     accessibility=0.9, police_exposure=0.6, capacity=1))
        if district.kind == DistrictType.SUBURBS and self.rng.random() < 0.8:
            out.append(SafeLocation(SafeLocationType.SAFEHOUSE, pos(0.6, 0.6), concealment=0.75,
                                     accessibility=0.6, police_exposure=0.2, capacity=1))
            out.append(SafeLocation(SafeLocationType.GARAGE, pos(0.35, 0.3), concealment=0.5,
                                     accessibility=0.7, police_exposure=0.35, capacity=3))
        if district.kind == DistrictType.INDUSTRIAL and self.rng.random() < 0.85:
            out.append(SafeLocation(SafeLocationType.INDUSTRIAL_YARD, pos(0.5, 0.5), concealment=0.8,
                                     accessibility=0.4, police_exposure=0.15, capacity=2))
        if district.kind == DistrictType.PORT:
            out.append(SafeLocation(SafeLocationType.MARINA, pos(0.7, 0.5), concealment=0.65,
                                     accessibility=0.35, police_exposure=0.2, capacity=1))
        return out
