"""Static building obstacles used for vehicle collision and line-of-sight
occlusion for the witness system."""

from __future__ import annotations

from dataclasses import dataclass

from engine.collision import Rect
from engine.physics import Vector2


@dataclass
class Building:
    bounds: Rect
    height: float = 1.0  # relative height, taller = blocks LOS more reliably


class BuildingIndex:
    """Very small spatial index (grid buckets) over buildings for fast
    nearby-lookup during collision and line-of-sight checks."""

    def __init__(self, cell_size: float = 250.0):
        self.cell_size = cell_size
        self.buildings: list[Building] = []
        self._grid: dict[tuple[int, int], list[Building]] = {}

    def add(self, building: Building) -> None:
        self.buildings.append(building)
        for cell in self._cells_for_rect(building.bounds):
            self._grid.setdefault(cell, []).append(building)

    def _cells_for_rect(self, rect: Rect):
        x0 = int(rect.x // self.cell_size)
        y0 = int(rect.y // self.cell_size)
        x1 = int((rect.x + rect.w) // self.cell_size)
        y1 = int((rect.y + rect.h) // self.cell_size)
        for cx in range(x0, x1 + 1):
            for cy in range(y0, y1 + 1):
                yield (cx, cy)

    def nearby(self, position: Vector2, radius: float) -> list[Building]:
        cx = int(position.x // self.cell_size)
        cy = int(position.y // self.cell_size)
        span = int(radius // self.cell_size) + 1
        found: list[Building] = []
        seen = set()
        for gx in range(cx - span, cx + span + 1):
            for gy in range(cy - span, cy + span + 1):
                for b in self._grid.get((gx, gy), []):
                    if id(b) not in seen:
                        seen.add(id(b))
                        found.append(b)
        return found

    def line_of_sight_blocked(self, a: Vector2, b: Vector2) -> bool:
        mid = Vector2((a.x + b.x) / 2, (a.y + b.y) / 2)
        radius = a.distance_to(b) / 2 + 10.0
        for building in self.nearby(mid, radius):
            if building.bounds.intersects_segment(a, b):
                return True
        return False
