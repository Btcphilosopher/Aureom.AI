"""
The road network is represented as a graph: intersections are nodes, road
segments are weighted edges. This module provides the graph itself plus
pathfinding and route-enumeration utilities used by traffic AI, police AI,
and the prediction/interception systems.
"""

from __future__ import annotations

import heapq
import math
from dataclasses import dataclass, field
from enum import Enum

from engine.physics import Vector2, angle_diff
from world.terrain import Surface


class RoadType(str, Enum):
    STREET = "STREET"
    HIGHWAY = "HIGHWAY"
    BRIDGE = "BRIDGE"
    TUNNEL = "TUNNEL"
    INDUSTRIAL_ROAD = "INDUSTRIAL_ROAD"
    DIRT = "DIRT"
    RAIL_CROSSING = "RAIL_CROSSING"


@dataclass
class Node:
    id: int
    position: Vector2
    district: str = ""
    is_intersection: bool = True
    traffic_light_phase: float = 0.0   # 0..1 progress through cycle
    traffic_light_period: float = 12.0
    has_light: bool = False

    def light_is_green(self, incoming_heading: float) -> bool:
        """Very small deterministic pseudo traffic-light: alternates green
        between the roughly-N/S and roughly-E/W approaches."""
        if not self.has_light:
            return True
        cycle_pos = (self.traffic_light_phase % self.traffic_light_period) / self.traffic_light_period
        axis_ns = abs(math.cos(incoming_heading)) < abs(math.sin(incoming_heading))
        green_window = cycle_pos < 0.5
        return green_window == axis_ns


@dataclass
class Road:
    id: int
    node_a: int
    node_b: int
    speed_limit: float
    lanes: int
    road_type: RoadType
    two_way: bool = True
    traffic_density: float = 0.3
    elevation: float = 0.0
    surface: Surface = Surface.ASPHALT
    police_access: bool = True
    alternate_routes: list = field(default_factory=list)

    def other_end(self, node_id: int) -> int:
        return self.node_b if node_id == self.node_a else self.node_a


class RoadNetwork:
    def __init__(self) -> None:
        self.nodes: dict[int, Node] = {}
        self.roads: dict[int, Road] = {}
        self._adjacency: dict[int, list[int]] = {}
        self._next_node_id = 0
        self._next_road_id = 0

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def add_node(self, position: Vector2, district: str = "", has_light: bool = False) -> int:
        node_id = self._next_node_id
        self._next_node_id += 1
        self.nodes[node_id] = Node(id=node_id, position=position, district=district, has_light=has_light)
        self._adjacency[node_id] = []
        return node_id

    def add_road(self, node_a: int, node_b: int, *, speed_limit: float, lanes: int,
                 road_type: RoadType, two_way: bool = True, traffic_density: float = 0.3,
                 elevation: float = 0.0, surface: Surface = Surface.ASPHALT,
                 police_access: bool = True) -> int:
        road_id = self._next_road_id
        self._next_road_id += 1
        road = Road(id=road_id, node_a=node_a, node_b=node_b, speed_limit=speed_limit,
                     lanes=lanes, road_type=road_type, two_way=two_way,
                     traffic_density=traffic_density, elevation=elevation,
                     surface=surface, police_access=police_access)
        self.roads[road_id] = road
        self._adjacency[node_a].append(road_id)
        if two_way:
            self._adjacency[node_b].append(road_id)
        return road_id

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def roads_at(self, node_id: int) -> list[Road]:
        return [self.roads[rid] for rid in self._adjacency.get(node_id, [])]

    def neighbors(self, node_id: int) -> list[int]:
        return [self.roads[rid].other_end(node_id) for rid in self._adjacency.get(node_id, [])]

    def nearest_node(self, position: Vector2) -> int:
        best_id, best_dist = -1, float("inf")
        for node_id, node in self.nodes.items():
            d = node.position.distance_to(position)
            if d < best_dist:
                best_dist, best_id = d, node_id
        return best_id

    def travel_time(self, road: Road) -> float:
        length = self.nodes[road.node_a].position.distance_to(self.nodes[road.node_b].position)
        effective_speed = max(road.speed_limit * (1.0 - 0.6 * road.traffic_density), 3.0)
        return length / effective_speed

    def road_between(self, a: int, b: int) -> Road | None:
        for rid in self._adjacency.get(a, []):
            r = self.roads[rid]
            if r.other_end(a) == b:
                return r
        return None

    # ------------------------------------------------------------------
    # Pathfinding
    # ------------------------------------------------------------------
    def shortest_path(self, start: int, goal: int, weight_bias: dict[int, float] | None = None) -> list[int]:
        """Dijkstra over travel-time-weighted edges. `weight_bias` optionally
        maps road_id -> multiplier (used by adaptive pursuit to prefer/avoid
        certain roads based on the player's driving profile)."""
        if start == goal:
            return [start]
        weight_bias = weight_bias or {}
        dist = {start: 0.0}
        prev: dict[int, int] = {}
        visited = set()
        queue = [(0.0, start)]
        while queue:
            d, u = heapq.heappop(queue)
            if u in visited:
                continue
            visited.add(u)
            if u == goal:
                break
            for rid in self._adjacency.get(u, []):
                road = self.roads[rid]
                v = road.other_end(u)
                w = self.travel_time(road) * weight_bias.get(rid, 1.0)
                nd = d + w
                if nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(queue, (nd, v))
        if goal not in dist:
            return []
        path = [goal]
        while path[-1] != start:
            path.append(prev[path[-1]])
        path.reverse()
        return path

    def path_travel_time(self, path: list[int]) -> float:
        total = 0.0
        for a, b in zip(path, path[1:]):
            road = self.road_between(a, b)
            if road is None:
                return float("inf")
            total += self.travel_time(road)
        return total

    def path_positions(self, path: list[int]) -> list[Vector2]:
        return [self.nodes[n].position for n in path]

    # ------------------------------------------------------------------
    # Route candidate enumeration (used by ai/prediction.py)
    # ------------------------------------------------------------------
    def candidate_branches(self, node_id: int, heading: float, exclude: int | None = None) -> list[tuple[int, float]]:
        """Return (neighbor_node_id, alignment_score) for every branch out of
        node_id, scored by how closely it continues the given heading.
        alignment_score in [0, 1], 1 = perfectly straight ahead."""
        results = []
        node = self.nodes[node_id]
        for rid in self._adjacency.get(node_id, []):
            road = self.roads[rid]
            other = road.other_end(node_id)
            if other == exclude:
                continue
            direction = (self.nodes[other].position - node.position).angle()
            diff = abs(angle_diff(direction, heading))
            alignment = max(0.0, 1.0 - diff / math.pi)
            # Highways favour continuation more strongly.
            if road.road_type == RoadType.HIGHWAY:
                alignment = min(1.0, alignment * 1.25)
            results.append((other, alignment))
        results.sort(key=lambda t: -t[1])
        return results
