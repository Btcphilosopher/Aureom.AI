"""District definitions: the city is partitioned into rectangular zones,
each with gameplay-relevant properties that ripple into traffic, visibility,
police access and pursuit behaviour."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from engine.collision import Rect
from engine.physics import Vector2


class DistrictType(str, Enum):
    DOWNTOWN = "DOWNTOWN"
    FINANCIAL = "FINANCIAL"
    SUBURBS = "SUBURBS"
    INDUSTRIAL = "INDUSTRIAL"
    AIRPORT = "AIRPORT"
    PORT = "PORT"
    BEACH = "BEACH"
    WETLANDS = "WETLANDS"
    HIGHWAY_CORRIDOR = "HIGHWAY_CORRIDOR"


@dataclass
class District:
    name: str
    kind: DistrictType
    bounds: Rect
    base_traffic_density: float   # 0..1 baseline before time-of-day scaling
    visibility: float             # 0..1, higher = easier for witnesses to see
    police_access: float          # 0..1, how easily police can navigate/respond
    cover: float                  # 0..1, how much concealment the district offers

    def contains(self, position: Vector2) -> bool:
        return self.bounds.contains_point(position)


# Base property presets per district archetype (spec section 3 & 18).
DISTRICT_PRESETS = {
    DistrictType.DOWNTOWN: dict(base_traffic_density=0.85, visibility=0.55, police_access=0.9, cover=0.5),
    DistrictType.FINANCIAL: dict(base_traffic_density=0.75, visibility=0.60, police_access=0.9, cover=0.4),
    DistrictType.SUBURBS: dict(base_traffic_density=0.45, visibility=0.65, police_access=0.75, cover=0.35),
    DistrictType.INDUSTRIAL: dict(base_traffic_density=0.30, visibility=0.35, police_access=0.55, cover=0.75),
    DistrictType.AIRPORT: dict(base_traffic_density=0.40, visibility=0.80, police_access=0.85, cover=0.2),
    DistrictType.PORT: dict(base_traffic_density=0.25, visibility=0.40, police_access=0.5, cover=0.7),
    DistrictType.BEACH: dict(base_traffic_density=0.35, visibility=0.90, police_access=0.6, cover=0.1),
    DistrictType.WETLANDS: dict(base_traffic_density=0.08, visibility=0.30, police_access=0.25, cover=0.85),
    DistrictType.HIGHWAY_CORRIDOR: dict(base_traffic_density=0.55, visibility=0.75, police_access=0.95, cover=0.15),
}
