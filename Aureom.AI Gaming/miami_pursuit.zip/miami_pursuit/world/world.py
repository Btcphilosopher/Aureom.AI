"""
Top-level World object: owns the City (roads/districts/buildings/water),
weather, the 24h clock, and sector streaming state (spec section 34).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from config import ACTIVE_SECTOR_RADIUS, WARM_SECTOR_RADIUS, SECTOR_SIZE
from engine.physics import Vector2
from world.city import City, CityGenerator
from world.intersections import IntersectionController
from world.weather import WeatherSystem


class SectorState(str, Enum):
    ACTIVE = "ACTIVE"
    WARM = "WARM"
    COLD = "COLD"


# Time-of-day traffic multiplier keyframes (hour -> multiplier), per spec section 6.
_TRAFFIC_KEYFRAMES = [
    (0.0, 0.15), (3.0, 0.08), (6.0, 0.35), (8.0, 0.9), (10.0, 0.55),
    (13.0, 0.6), (16.0, 0.75), (17.0, 1.0), (19.0, 0.8), (21.0, 0.5),
    (23.0, 0.25), (24.0, 0.15),
]


def traffic_time_multiplier(hour: float) -> float:
    hour = hour % 24.0
    for (h0, m0), (h1, m1) in zip(_TRAFFIC_KEYFRAMES, _TRAFFIC_KEYFRAMES[1:]):
        if h0 <= hour <= h1:
            t = (hour - h0) / max(h1 - h0, 1e-6)
            return m0 + (m1 - m0) * t
    return 0.2


@dataclass
class TimeOfDay:
    hour: float = 12.0
    day_length_minutes: float = 24.0  # real minutes for a full in-game day

    def update(self, dt: float) -> None:
        hours_per_second = 24.0 / (self.day_length_minutes * 60.0)
        self.hour = (self.hour + dt * hours_per_second) % 24.0

    def is_night(self) -> bool:
        return self.hour < 5.5 or self.hour > 20.0

    def ambient_visibility(self) -> float:
        # Smooth day/night visibility curve, dips at night.
        if 6.0 <= self.hour <= 18.0:
            return 1.0
        if self.hour < 6.0:
            return 0.45 + 0.55 * (self.hour / 6.0)
        return 0.45 + 0.55 * max(0.0, (24.0 - self.hour) / 6.0)


class World:
    def __init__(self, seed: int = 1337):
        self.city: City = CityGenerator(seed).generate()
        self.weather = WeatherSystem()
        self.time = TimeOfDay()
        self.intersections = IntersectionController(self.city.road_network)
        self._sim_time = 0.0

    @property
    def sim_time(self) -> float:
        return self._sim_time

    def traffic_density_at(self, district_name: str, economy_mult: float = 1.0) -> float:
        district = self.city.district_by_name(district_name)
        base = district.base_traffic_density if district else 0.3
        return max(0.02, min(1.0, base * traffic_time_multiplier(self.time.hour) * economy_mult))

    def visibility_at(self, district_name: str) -> float:
        district = self.city.district_by_name(district_name)
        district_vis = district.visibility if district else 0.6
        return district_vis * self.weather.visibility_modifier() * self.time.ambient_visibility()

    def sector_state(self, position: Vector2, focus: Vector2) -> SectorState:
        d = position.distance_to(focus)
        if d <= ACTIVE_SECTOR_RADIUS:
            return SectorState.ACTIVE
        if d <= WARM_SECTOR_RADIUS:
            return SectorState.WARM
        return SectorState.COLD

    def update(self, dt: float) -> None:
        self._sim_time += dt
        self.weather.update(dt)
        self.time.update(dt)
        self.intersections.update(dt)
