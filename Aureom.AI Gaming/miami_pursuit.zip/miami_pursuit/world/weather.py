"""Dynamic weather system: clear / rain / heavy rain / fog / storm, cycling
on a randomized timer and exposing gameplay modifiers."""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum

from config import WEATHER_MODIFIERS


class WeatherType(str, Enum):
    CLEAR = "CLEAR"
    RAIN = "RAIN"
    HEAVY_RAIN = "HEAVY_RAIN"
    FOG = "FOG"
    STORM = "STORM"


_TRANSITIONS = {
    WeatherType.CLEAR: [WeatherType.CLEAR, WeatherType.CLEAR, WeatherType.RAIN, WeatherType.FOG],
    WeatherType.RAIN: [WeatherType.RAIN, WeatherType.CLEAR, WeatherType.HEAVY_RAIN],
    WeatherType.HEAVY_RAIN: [WeatherType.HEAVY_RAIN, WeatherType.RAIN, WeatherType.STORM],
    WeatherType.FOG: [WeatherType.FOG, WeatherType.CLEAR],
    WeatherType.STORM: [WeatherType.STORM, WeatherType.HEAVY_RAIN, WeatherType.RAIN],
}


@dataclass
class WeatherSystem:
    current: WeatherType = WeatherType.CLEAR
    _timer: float = 0.0
    _duration: float = 180.0
    rng: random.Random = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.rng is None:
            self.rng = random.Random(2024)

    def set(self, weather: WeatherType, duration: float = 180.0) -> None:
        self.current = weather
        self._timer = 0.0
        self._duration = duration

    def update(self, dt: float) -> None:
        self._timer += dt
        if self._timer >= self._duration:
            self._timer = 0.0
            self._duration = self.rng.uniform(90.0, 240.0)
            self.current = self.rng.choice(_TRANSITIONS[self.current])

    def visibility_modifier(self) -> float:
        return WEATHER_MODIFIERS[self.current.value]["visibility"]

    def traction_modifier(self) -> float:
        return WEATHER_MODIFIERS[self.current.value]["traction"]

    def detection_modifier(self) -> float:
        return WEATHER_MODIFIERS[self.current.value]["detection"]
