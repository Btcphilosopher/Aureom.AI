"""Water bodies: canals, wetlands, the bay and the ocean fringe.

Represented as impassable rectangles unless a road/bridge segment crosses
them (bridges are just regular Road entries whose polyline happens to span
a water Rect, so no special-casing is needed at the road-graph level).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from engine.collision import Rect


@dataclass
class WaterBody:
    name: str
    bounds: Rect
    kind: str = "canal"  # canal | bay | ocean | wetland_pool


@dataclass
class WaterSystem:
    bodies: list = field(default_factory=list)

    def add(self, body: WaterBody) -> None:
        self.bodies.append(body)

    def blocks(self, rect: Rect) -> bool:
        return any(rect.intersects_rect(b.bounds) for b in self.bodies)
