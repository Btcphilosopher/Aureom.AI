"""Surface types and their friction coefficients."""

from __future__ import annotations

from enum import Enum

from config import SURFACE_FRICTION


class Surface(str, Enum):
    ASPHALT = "ASPHALT"
    DIRT = "DIRT"
    SAND = "SAND"
    GRASS = "GRASS"
    WATER = "WATER"
    METAL = "METAL"

    def friction(self) -> float:
        return SURFACE_FRICTION[self.value]
