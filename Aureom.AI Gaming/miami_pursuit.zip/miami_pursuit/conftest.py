"""Ensures the project root is importable regardless of how pytest is
invoked or which import mode it defaults to."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
