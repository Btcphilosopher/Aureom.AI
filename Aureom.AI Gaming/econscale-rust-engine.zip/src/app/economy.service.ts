import { Injectable, signal, computed } from '@angular/core';
import {
  TransactionType,
  CommodityType,
  Player,
  Npc,
  Business,
  Property,
  Vehicle,
  Market,
  Region,
  LedgerEntry,
  Transaction,
  EconomicShock,
  SandboxScenario
} from './economy-types';

@Injectable({
  providedIn: 'root'
})
export class EconomyService {
  // Seeded Random Helper
  private seedValue = 1337;
  private randomSeed() {
    const x = Math.sin(this.seedValue++) * 10000;
    return x - Math.floor(x);
  }

  // --- World State Signals ---
  regions = signal<Region[]>([]);
  players = signal<Player[]>([]);
  npcs = signal<Npc[]>([]);
  businesses = signal<Business[]>([]);
  properties = signal<Property[]>([]);
  vehicles = signal<Vehicle[]>([]);
  markets = signal<Market[]>([]);
  activeShocks = signal<EconomicShock[]>([]);
  transactions = signal<Transaction[]>([]);
  ledgerEntries = signal<LedgerEntry[]>([]);

  // --- Clock State Signals ---
  ticks = signal<number>(0); // game minutes
  speed = signal<'Slow' | 'Normal' | 'Fast' | 'Extreme'>('Normal');
  isPaused = signal<boolean>(true);

  // --- Selected Scenario Signal ---
  currentScenario = signal<SandboxScenario>(SandboxScenario.BalancedExpansion);

  // --- Computed Clock Timescales ---
  gameTime = computed(() => {
    const mins = this.ticks();
    const minute = mins % 60;
    const hour = Math.floor(mins / 60) % 24;
    const day = Math.floor(mins / 1440) % 30 + 1;
    const month = Math.floor(mins / 43200) + 1;
    return {
      minute,
      hour,
      day,
      month,
      timeString: `Month ${month}, Day ${day} - ${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
    };
  });

  // --- Computed Analytics ---
  gdp = computed(() => {
    // GDP = Sum of all business revenues + wage payments
    const bizRevenue = this.businesses().reduce((sum, b) => sum + b.daily_revenue, 0);
    const wages = this.npcs().reduce((sum, n) => sum + n.income_rate_minor, 0);
    return bizRevenue + wages;
  });

  inflationRate = computed(() => {
    // Compare current average commodity prices to base prices
    const mkts = this.markets();
    if (mkts.length === 0) return 0;
    let currentSum = 0;
    let baseSum = 0;
    mkts.forEach(m => {
      currentSum += m.price_minor;
      baseSum += m.base_price_minor;
    });
    return parseFloat((((currentSum / baseSum) - 1) * 100).toFixed(2));
  });

  unemploymentRate = computed(() => {
    // Simple heuristic: NPCs without employers are unemployed
    const totalNpcs = this.npcs().length;
    if (totalNpcs === 0) return 0;
    const unemployed = this.npcs().filter(n => !n.employer_id).length;
    return parseFloat(((unemployed / totalNpcs) * 100).toFixed(1));
  });

  giniCoefficient = computed(() => {
    // Mathematical wealth inequality calculator
    // Gini = sum_i sum_j |x_i - x_j| / (2 * n * sum_i x_i)
    const balances = this.npcs().map(n => n.wallet_cash_minor + n.savings_minor)
      .concat(this.players().map(p => p.cash_minor + p.bank_minor));
    
    const n = balances.length;
    if (n < 2) return 0;

    const sumBalances = balances.reduce((sum, b) => sum + b, 0);
    if (sumBalances === 0) return 0;

    let sumAbsoluteDiffs = 0;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        sumAbsoluteDiffs += Math.abs(balances[i] - balances[j]);
      }
    }

    return parseFloat((sumAbsoluteDiffs / (2 * n * sumBalances)).toFixed(3));
  });

  playerNetWorth = computed(() => {
    const p = this.players()[0];
    if (!p) return 0;

    // properties value owned by player
    const propsVal = this.properties()
      .filter(pr => pr.owner_id === p.id)
      .reduce((sum, pr) => sum + pr.current_valuation_minor - pr.mortgage_balance_minor, 0);

    // vehicles value owned by player
    const carsVal = this.vehicles()
      .filter(v => v.owner_id === p.id)
      .reduce((sum, v) => sum + v.market_value_minor, 0);

    // business equity value (starting cash/on hand)
    const bizVal = this.businesses()
      .filter(b => b.owner_id === p.id)
      .reduce((sum, b) => sum + b.cash_on_hand_minor + b.inventory_value_minor - b.debt_minor, 0);

    return p.cash_minor + p.bank_minor + p.digital_minor + propsVal + carsVal + bizVal - p.loans_minor;
  });

  constructor() {
    this.resetToSeed(1337);
  }

  // --- Seed & Setup ---
  resetToSeed(seed: number) {
    this.seedValue = seed;
    this.ticks.set(0);
    this.activeShocks.set([]);
    this.transactions.set([]);
    this.ledgerEntries.set([]);

    // 1. Seed Regions
    const seedRegions: Region[] = [
      { id: 'reg-downtown', name: 'Downtown', population: 8500, avg_income_minor: 480000, crime_pressure: 0.15, business_density: 0.85 },
      { id: 'reg-industrial', name: 'Industrial District', population: 2200, avg_income_minor: 320000, crime_pressure: 0.45, business_density: 0.90 },
      { id: 'reg-suburbs', name: 'Suburbs', population: 14000, avg_income_minor: 550000, crime_pressure: 0.08, business_density: 0.35 },
      { id: 'reg-port', name: 'Port District', population: 1800, avg_income_minor: 380000, crime_pressure: 0.50, business_density: 0.60 },
      { id: 'reg-financial', name: 'Financial District', population: 3100, avg_income_minor: 950000, crime_pressure: 0.05, business_density: 0.95 }
    ];
    this.regions.set(seedRegions);

    // 2. Seed Players
    const seedPlayers: Player[] = [
      {
        id: 'ply-michael',
        name: 'Michael De Santa',
        cash_minor: 850000, // $8,500 cash
        bank_minor: 12500000, // $125,000 bank deposits
        digital_minor: 50000, // $500 crypto
        loans_minor: 0,
        net_worth_history: [{ day: 0, net_worth: 13400000 }]
      }
    ];
    this.players.set(seedPlayers);

    // 3. Seed NPCs (Citizens)
    const seedNpcs: Npc[] = [];
    const names = [
      'Franklin Clinton', 'Trevor Philips', 'Lamar Davis', 'Jimmy De Santa', 'Amanda De Santa',
      'Tracey De Santa', 'Lester Crest', 'Dave Norton', 'Steve Haines', 'Devin Weston',
      'Wade Hebert', 'Ron Jakowski', 'Patricia Madrazo', 'Martin Madrazo', 'Simeon Yetarian',
      'Lazlow Jones', 'Tanisha Jackson', 'Stretch', 'Wei Cheng', 'Molly Schultz'
    ];
    const occupations = [
      'Refinery Operator', 'Food Wholesaler', 'Car Salesman', 'Electronics Tech', 'Apparel Stylist',
      'Construction Builder', 'Broker', 'Luxury Jeweler', 'Machinery Mechanic', 'Bodyguard'
    ];

    names.forEach((name, idx) => {
      const income = 25000 + Math.floor(this.randomSeed() * 35000); // $250 - $600 per day
      seedNpcs.push({
        id: `npc-${idx}`,
        name,
        occupation: occupations[idx % occupations.length],
        income_rate_minor: income,
        wallet_cash_minor: 15000 + Math.floor(this.randomSeed() * 45000), // $150 - $600 cash
        savings_minor: 100000 + Math.floor(this.randomSeed() * 900000), // $1,000 - $10,000 savings
        housing_cost_minor: Math.floor(income * 0.28), // 28% housing rent
        transport_cost_minor: Math.floor(income * 0.08), // 8% transport cost
        risk_tolerance: parseFloat((0.1 + this.randomSeed() * 0.8).toFixed(2)),
        employer_id: null,
        isActive: true
      });
    });
    this.npcs.set(seedNpcs);

    // 4. Seed Businesses (Firms)
    const seedBusinesses: Business[] = [
      { id: 'biz-refinery', name: 'Los Santos Oil Refinery', region_id: 'reg-industrial', owner_id: 'State', employees_count: 8, daily_revenue: 120000, daily_cogs: 20000, daily_labor_expense: 35000, daily_rent_expense: 15000, daily_utilities_expense: 10000, daily_taxes_expense: 5000, daily_financing_expense: 0, debt_minor: 0, cash_on_hand_minor: 5000000, inventory_value_minor: 1500000, commodity_type: CommodityType.Fuel },
      { id: 'biz-supermarket', name: 'Cluckin Bell Logistics', region_id: 'reg-port', owner_id: 'State', employees_count: 5, daily_revenue: 85000, daily_cogs: 15000, daily_labor_expense: 20000, daily_rent_expense: 10000, daily_utilities_expense: 5000, daily_taxes_expense: 3000, daily_financing_expense: 0, debt_minor: 0, cash_on_hand_minor: 3000000, inventory_value_minor: 1000000, commodity_type: CommodityType.Food },
      { id: 'biz-dealership', name: 'Premium Deluxe Motorsport', region_id: 'reg-downtown', owner_id: 'npc-14', employees_count: 6, daily_revenue: 450000, daily_cogs: 280000, daily_labor_expense: 30000, daily_rent_expense: 25000, daily_utilities_expense: 8000, daily_taxes_expense: 12000, daily_financing_expense: 5000, debt_minor: 5000000, cash_on_hand_minor: 8000000, inventory_value_minor: 25000000, commodity_type: CommodityType.Vehicles },
      { id: 'biz-electronics', name: 'Fruit Tech Flagship Store', region_id: 'reg-financial', owner_id: 'State', employees_count: 4, daily_revenue: 150000, daily_cogs: 60000, daily_labor_expense: 24000, daily_rent_expense: 30000, daily_utilities_expense: 6000, daily_taxes_expense: 8000, daily_financing_expense: 0, debt_minor: 0, cash_on_hand_minor: 4500000, inventory_value_minor: 5000000, commodity_type: CommodityType.Electronics },
      { id: 'biz-construction', name: 'Schlongberg Sachs Builder', region_id: 'reg-industrial', owner_id: 'State', employees_count: 12, daily_revenue: 550000, daily_cogs: 210000, daily_labor_expense: 60000, daily_rent_expense: 40000, daily_utilities_expense: 15000, daily_taxes_expense: 18000, daily_financing_expense: 0, debt_minor: 0, cash_on_hand_minor: 12000000, inventory_value_minor: 8000000, commodity_type: CommodityType.Construction },
      { id: 'biz-luxury', name: 'Vangelico Fine Jewelry', region_id: 'reg-financial', owner_id: 'State', employees_count: 3, daily_revenue: 350000, daily_cogs: 120000, daily_labor_expense: 18000, daily_rent_expense: 35000, daily_utilities_expense: 5000, daily_taxes_expense: 15000, daily_financing_expense: 0, debt_minor: 0, cash_on_hand_minor: 6000000, inventory_value_minor: 12000000, commodity_type: CommodityType.LuxuryGoods }
    ];
    this.businesses.set(seedBusinesses);

    // Link some NPCs to businesses
    seedNpcs.forEach((n, idx) => {
      const biz = seedBusinesses[idx % seedBusinesses.length];
      n.employer_id = biz.id;
    });

    // 5. Seed Properties
    const seedProperties: Property[] = [
      { id: 'prop-mansion', name: '3671 Whispymound Dr Mansion', region_id: 'reg-suburbs', owner_id: 'ply-michael', purchase_price_minor: 85000000, current_valuation_minor: 85000000, monthly_rent_minor: 450000, size_sqft: 6500, condition_score: 0.98, mortgage_balance_minor: 0 },
      { id: 'prop-apartment', name: 'Eclipse Towers Suite 31', region_id: 'reg-financial', owner_id: 'State', purchase_price_minor: 45000000, current_valuation_minor: 45000000, monthly_rent_minor: 220000, size_sqft: 2800, condition_score: 0.95, mortgage_balance_minor: 0 },
      { id: 'prop-warehouse', name: 'Port of LS Warehouse B', region_id: 'reg-port', owner_id: 'State', purchase_price_minor: 120000000, current_valuation_minor: 120000000, monthly_rent_minor: 650000, size_sqft: 18000, condition_score: 0.72, mortgage_balance_minor: 0 },
      { id: 'prop-garage', name: 'Popular St 10-Car Garage', region_id: 'reg-industrial', owner_id: 'npc-0', purchase_price_minor: 15000000, current_valuation_minor: 15000000, monthly_rent_minor: 95000, size_sqft: 3500, condition_score: 0.85, mortgage_balance_minor: 0 },
      { id: 'prop-suburb-home', name: 'Vespucci Canals Condo', region_id: 'reg-suburbs', owner_id: 'npc-3', purchase_price_minor: 32000000, current_valuation_minor: 32000000, monthly_rent_minor: 160000, size_sqft: 1800, condition_score: 0.90, mortgage_balance_minor: 12000000 }
    ];
    this.properties.set(seedProperties);

    // 6. Seed Vehicles
    const seedVehicles: Vehicle[] = [
      { id: 'veh-obey', model_name: 'Obey Tailgater (Sports Sedan)', owner_id: 'ply-michael', purchase_price_minor: 5500000, market_value_minor: 5200000, depreciation_rate_annual: 0.12, mileage_miles: 12000, condition_score: 0.95 },
      { id: 'veh-cheetah', model_name: 'Grotti Cheetah (Supercar)', owner_id: 'State', purchase_price_minor: 65000000, market_value_minor: 65000000, depreciation_rate_annual: 0.15, mileage_miles: 50, condition_score: 1.00 },
      { id: 'veh-futo', model_name: 'Karin Futo (Drift Coupe)', owner_id: 'npc-2', purchase_price_minor: 900000, market_value_minor: 65000, depreciation_rate_annual: 0.08, mileage_miles: 185000, condition_score: 0.64 },
      { id: 'veh-buffalo', model_name: 'Bravado Buffalo S (Muscle)', owner_id: 'npc-6', purchase_price_minor: 3500000, market_value_minor: 2900000, depreciation_rate_annual: 0.10, mileage_miles: 45000, condition_score: 0.88 }
    ];
    this.vehicles.set(seedVehicles);

    // 7. Seed Dynamic Markets (Each region has its own dynamic prices)
    const seedMarkets: Market[] = [];
    const commodityBases: { type: CommodityType; base: number; vol: number }[] = [
      { type: CommodityType.Fuel, base: 350, vol: 0.04 }, // $3.50 gas
      { type: CommodityType.Food, base: 120, vol: 0.02 }, // $1.20 grocery unit
      { type: CommodityType.Vehicles, base: 4500000, vol: 0.08 }, // $45k standard auto
      { type: CommodityType.Electronics, base: 85000, vol: 0.05 }, // $850 console
      { type: CommodityType.Clothing, base: 4500, vol: 0.03 }, // $45 jacket
      { type: CommodityType.Construction, base: 22000, vol: 0.06 }, // $220 structural beam
      { type: CommodityType.LuxuryGoods, base: 1500000, vol: 0.12 }, // $15,000 fine watch
      { type: CommodityType.BlackMarketNarcotics, base: 18500, vol: 0.25 }, // $185 per block (restricted, high volatility)
      { type: CommodityType.BlackMarketWeapons, base: 1250000, vol: 0.20 } // $12,500 assault weapon (restricted)
    ];

    seedRegions.forEach(reg => {
      commodityBases.forEach(cb => {
        // Shift base price slightly per region based on regional average income & density
        let regionalShift = 1.0;
        if (reg.id === 'reg-financial') regionalShift = 1.15; // +15% pricing
        if (reg.id === 'reg-industrial') regionalShift = 0.90; // -10% pricing

        const adjustedBase = Math.floor(cb.base * regionalShift);

        seedMarkets.push({
          id: `mkt-${reg.id}-${cb.type.toLowerCase()}`,
          region_id: reg.id,
          commodity_type: cb.type,
          supply: 80 + Math.floor(this.randomSeed() * 40), // 80 - 120 supply
          demand: 80 + Math.floor(this.randomSeed() * 40), // 80 - 120 demand
          price_minor: adjustedBase,
          base_price_minor: adjustedBase,
          price_volatility: cb.vol,
          transaction_volume: 0
        });
      });
    });
    this.markets.set(seedMarkets);
  }

  // --- Double-Entry Ledger Bookkeeping Engine ---
  createTransaction(
    type: TransactionType,
    description: string,
    senderId: string,
    receiverId: string,
    amountMinor: number,
    regionId?: string,
    assetId?: string,
    missionId?: string
  ): boolean {
    if (amountMinor <= 0) return false;

    // 1. Deduct from Sender (Player, NPC, or State/Business)
    const hasSufficient = this.adjustLiquidity(senderId, -amountMinor);
    if (!hasSufficient) return false;

    // 2. Deposit to Receiver
    this.adjustLiquidity(receiverId, amountMinor);

    // 3. Document master Transaction
    const txId = `tx-${Math.floor(this.randomSeed() * 1000000)}-${Date.now()}`;
    const newTx: Transaction = {
      id: txId,
      tx_type: type,
      description,
      amount_minor: amountMinor,
      timestamp: new Date().toISOString(),
      region_id: regionId,
      related_asset_id: assetId,
      related_mission_id: missionId
    };

    // 4. Document balanced ledger entries
    const entries: LedgerEntry[] = [
      {
        id: `le-${txId}-dr`,
        transaction_id: txId,
        account_id: receiverId,
        account_name: this.getEntityName(receiverId),
        debit_minor: amountMinor, // money flowing into receiver
        credit_minor: 0,
        created_at: new Date().toISOString()
      },
      {
        id: `le-${txId}-cr`,
        transaction_id: txId,
        account_id: senderId,
        account_name: this.getEntityName(senderId),
        debit_minor: 0,
        credit_minor: amountMinor, // money flowing out of sender
        created_at: new Date().toISOString()
      }
    ];

    // Append to signals atomically
    this.transactions.update(prev => [newTx, ...prev.slice(0, 49)]); // keep last 50
    this.ledgerEntries.update(prev => [...entries, ...prev.slice(0, 98)]);

    return true;
  }

  private adjustLiquidity(id: string, deltaMinor: number): boolean {
    // Determine target actor type
    if (id === 'State') {
      return true; // infinite State Treasury funding for government transactions
    }

    // Is it a Player?
    const pList = this.players();
    const playerIdx = pList.findIndex(p => p.id === id);
    if (playerIdx !== -1) {
      const p = { ...pList[playerIdx] };
      // Deduct from bank by default, cash if bank is dry
      if (deltaMinor < 0) {
        const absDelta = Math.abs(deltaMinor);
        if (p.bank_minor >= absDelta) {
          p.bank_minor += deltaMinor;
        } else if (p.cash_minor + p.bank_minor >= absDelta) {
          const remaining = absDelta - p.bank_minor;
          p.bank_minor = 0;
          p.cash_minor -= remaining;
        } else {
          return false; // Insufficient Funds
        }
      } else {
        p.bank_minor += deltaMinor;
      }
      this.players.update(prev => {
        const next = [...prev];
        next[playerIdx] = p;
        return next;
      });
      return true;
    }

    // Is it an NPC?
    const nList = this.npcs();
    const npcIdx = nList.findIndex(n => n.id === id);
    if (npcIdx !== -1) {
      const n = { ...nList[npcIdx] };
      if (deltaMinor < 0) {
        const absDelta = Math.abs(deltaMinor);
        if (n.savings_minor >= absDelta) {
          n.savings_minor += deltaMinor;
        } else if (n.wallet_cash_minor + n.savings_minor >= absDelta) {
          const remaining = absDelta - n.savings_minor;
          n.savings_minor = 0;
          n.wallet_cash_minor -= remaining;
        } else {
          return false;
        }
      } else {
        n.savings_minor += deltaMinor;
      }
      this.npcs.update(prev => {
        const next = [...prev];
        next[npcIdx] = n;
        return next;
      });
      return true;
    }

    // Is it a Business?
    const bList = this.businesses();
    const bIdx = bList.findIndex(b => b.id === id);
    if (bIdx !== -1) {
      const b = { ...bList[bIdx] };
      if (deltaMinor < 0) {
        const absDelta = Math.abs(deltaMinor);
        if (b.cash_on_hand_minor >= absDelta) {
          b.cash_on_hand_minor += deltaMinor;
        } else {
          return false;
        }
      } else {
        b.cash_on_hand_minor += deltaMinor;
      }
      this.businesses.update(prev => {
        const next = [...prev];
        next[bIdx] = b;
        return next;
      });
      return true;
    }

    return false;
  }

  private getEntityName(id: string): string {
    if (id === 'State') return 'State Treasury';
    const p = this.players().find(pl => pl.id === id);
    if (p) return p.name;
    const n = this.npcs().find(np => np.id === id);
    if (n) return `${n.name} (NPC)`;
    const b = this.businesses().find(bi => bi.id === id);
    if (b) return `${b.name} (Firm)`;
    return 'Unknown Entity';
  }

  // --- Clock Loop Process Ticks ---
  tickSimulation() {
    this.ticks.update(t => t + 1);
    const time = this.gameTime();

    // 1. Hourly market discoveries (every 60 ticks)
    if (time.minute === 0) {
      this.discoverPricesHourly();
    }

    // 2. Daily accounting settlements (every 1440 ticks)
    if (time.minute === 0 && time.hour === 0) {
      this.processDailySettlement();
    }
  }

  private discoverPricesHourly() {
    // Iterate through markets, apply dynamic prices based on supply/demand
    this.markets.update(prev => {
      return prev.map(m => {
        // Let organic market volume decrease slightly as transaction decay
        const newVol = Math.floor(m.transaction_volume * 0.95);

        // Add some noise to supply and demand to represent active game world
        let supplyShift = (this.randomSeed() * 8) - 3.8;
        let demandShift = (this.randomSeed() * 8) - 3.5;

        // Apply any Active Scenario modifiers
        const activeScenario = this.currentScenario();
        if (activeScenario === SandboxScenario.HyperinflationFuelShortage && m.commodity_type === CommodityType.Fuel) {
          supplyShift -= 4.0; // severe oil supply crash
          demandShift += 2.0; // panic buying demand spike
        }
        if (activeScenario === SandboxScenario.RealEstateCollapse && m.commodity_type === CommodityType.Property) {
          demandShift -= 5.0; // housing collapse
          supplyShift += 3.0;
        }
        if (activeScenario === SandboxScenario.CrimeSyndicateBoom && (m.commodity_type === CommodityType.BlackMarketNarcotics || m.commodity_type === CommodityType.BlackMarketWeapons)) {
          demandShift += 6.0; // intense black market activity
          supplyShift -= 2.0;
        }

        const nextSupply = Math.max(10, Math.min(500, m.supply + supplyShift));
        const nextDemand = Math.max(10, Math.min(500, m.demand + demandShift));

        // Discover price: Price(t+1) = Price(t) * (demand/100) * (100/supply)
        const dFactor = nextDemand / 100;
        const sFactor = 100 / nextSupply;

        // Apply price volatility factor
        const volNoise = 1.0 + (this.randomSeed() * 2 - 1) * m.price_volatility;

        const calculatedPrice = Math.round(m.base_price_minor * dFactor * sFactor * volNoise);
        
        // Clamp price within 10% to 1000% of base value to avoid absolute extremes
        const price_minor = Math.max(Math.round(m.base_price_minor * 0.1), Math.min(Math.round(m.base_price_minor * 10), calculatedPrice));

        return {
          ...m,
          supply: parseFloat(nextSupply.toFixed(2)),
          demand: parseFloat(nextDemand.toFixed(2)),
          price_minor,
          transaction_volume: newVol
        };
      });
    });
  }

  private processDailySettlement() {
    const day = this.gameTime().day;

    // 1. Pay Salaries & Wages
    // NPCs receive salary from their employers, or standard welfare if unemployed
    this.npcs().forEach(n => {
      const employer = n.employer_id;
      if (employer) {
        // Business pays NPC salary
        this.createTransaction(
          TransactionType.Salary,
          `Daily Payroll: ${n.name}`,
          employer,
          n.id,
          n.income_rate_minor
        );
      } else {
        // Welfare safety net from State Treasury
        this.createTransaction(
          TransactionType.Salary,
          `Government Welfare: ${n.name}`,
          'State',
          n.id,
          10000 // $100 welfare
        );
      }

      // NPCs spend automatically on Rent & Food
      // Rent paid to properties or state
      this.createTransaction(
        TransactionType.Tax, // housing rent expense
        `Daily Housing Rent & Util: ${n.name}`,
        n.id,
        'State',
        n.housing_cost_minor
      );

      // Food purchase to Cluckin Bell Supermarket
      this.createTransaction(
        TransactionType.Purchase,
        `Grocery Groceries: ${n.name}`,
        n.id,
        'biz-supermarket',
        3000 // $30 grocery
      );
    });

    // 2. Businesses run daily reports & financial calculations
    this.businesses.update(prev => {
      return prev.map(b => {
        // Calculate daily profit summary
        const wagesPaid = this.npcs().filter(n => n.employer_id === b.id).reduce((sum, n) => sum + n.income_rate_minor, 0);
        
        // Accumulate revenue and COGS (Cost of goods sold is 40% of revenue)
        const dailyRevenue = 50000 + Math.floor(this.randomSeed() * 180000); // dynamic business revenue
        const dailyCogs = Math.floor(dailyRevenue * 0.42);
        
        // pay utilities, rent, taxes
        const dailyProfit = dailyRevenue - dailyCogs - wagesPaid - b.daily_utilities_expense - b.daily_rent_expense;

        // Inject into business account
        if (dailyProfit > 0) {
          this.createTransaction(TransactionType.BusinessRevenue, `Daily Business Revenue net: ${b.name}`, 'State', b.id, dailyProfit);
        } else if (dailyProfit < 0) {
          this.createTransaction(TransactionType.BusinessExpense, `Daily Business Net Operating Loss: ${b.name}`, b.id, 'State', Math.abs(dailyProfit));
        }

        return {
          ...b,
          daily_revenue: dailyRevenue,
          daily_cogs: dailyCogs,
          daily_labor_expense: wagesPaid,
          cash_on_hand_minor: b.cash_on_hand_minor + dailyProfit
        };
      });
    });

    // 3. Vehicles tick depreciation
    this.vehicles.update(prev => {
      return prev.map(v => {
        const dailyDepr = v.market_value_minor * (v.depreciation_rate_annual / 365);
        return {
          ...v,
          mileage_miles: v.mileage_miles + Math.floor(this.randomSeed() * 150),
          market_value_minor: Math.max(10000, Math.round(v.market_value_minor - dailyDepr)) // don't depreciate below $100
        };
      });
    });

    // 4. Properties valuation adjustments based on regional economic state
    this.properties.update(prev => {
      return prev.map(p => {
        const reg = this.regions().find(r => r.id === p.region_id);
        const crimeImpact = reg ? reg.crime_pressure * 0.02 : 0;
        const baseGrowth = 0.001; // stable 0.1% daily base growth
        const netAdjustment = baseGrowth - crimeImpact;

        const calculatedVal = Math.round(p.current_valuation_minor * (1.0 + netAdjustment));
        return {
          ...p,
          current_valuation_minor: calculatedVal,
          monthly_rent_minor: Math.round(calculatedVal * 0.005) // rent is 0.5% of value monthly
        };
      });
    });

    // 5. Append Net Worth history for the Player
    this.players.update(prev => {
      return prev.map(p => {
        const history = [...p.net_worth_history];
        const nw = this.playerNetWorth();
        history.push({ day, net_worth: nw });
        return {
          ...p,
          net_worth_history: history.slice(-30) // retain last 30 days
        };
      });
    });
  }

  // --- Interactive Player Operations ---
  executePlayerPurchase(market: Market, quantity: number): boolean {
    const p = this.players()[0];
    if (!p) return false;

    const totalCostMinor = market.price_minor * quantity;

    // Create double entry purchase
    const success = this.createTransaction(
      TransactionType.Purchase,
      `Bought ${quantity} units of ${market.commodity_type} from ${this.getRegionName(market.region_id)} Exchange`,
      p.id,
      market.commodity_type === CommodityType.Fuel ? 'biz-refinery' : 'State',
      totalCostMinor,
      market.region_id
    );

    if (success) {
      // Increase transaction volume of the market, reducing supply and driving prices up!
      this.markets.update(prev => {
        return prev.map(m => {
          if (m.id === market.id) {
            return {
              ...m,
              supply: Math.max(10, m.supply - (quantity * 2.5)),
              demand: Math.min(500, m.demand + (quantity * 1.5)),
              transaction_volume: m.transaction_volume + quantity
            };
          }
          return m;
        });
      });
      return true;
    }

    return false;
  }

  executePlayerSale(market: Market, quantity: number): boolean {
    const p = this.players()[0];
    if (!p) return false;

    const totalRevenueMinor = market.price_minor * quantity;

    // Create double entry sale
    const success = this.createTransaction(
      TransactionType.Sale,
      `Sold ${quantity} units of ${market.commodity_type} to ${this.getRegionName(market.region_id)} Exchange`,
      'State',
      p.id,
      totalRevenueMinor,
      market.region_id
    );

    if (success) {
      // Increase supply and reduce demand of the market, pushing prices down
      this.markets.update(prev => {
        return prev.map(m => {
          if (m.id === market.id) {
            return {
              ...m,
              supply: Math.min(500, m.supply + (quantity * 3.5)),
              demand: Math.max(10, m.demand - (quantity * 1.0)),
              transaction_volume: m.transaction_volume + quantity
            };
          }
          return m;
        });
      });
      return true;
    }

    return false;
  }

  completeRobberyMission(): void {
    const p = this.players()[0];
    if (!p) return;

    const rewardMinor = 5000000; // $50,000

    // Complete robbery mission -> Debit Player, Credit State
    this.createTransaction(
      TransactionType.MissionReward,
      'Mission Completed: Maze Bank Vault Heist (Dynamic Capital Injection)',
      'State',
      p.id,
      rewardMinor,
      'reg-downtown',
      undefined,
      'mis-heist-101'
    );

    // Dynamic Regional Shock: increase downtown crime pressure and suburbs property prices!
    this.regions.update(prev => {
      return prev.map(r => {
        if (r.id === 'reg-downtown') {
          return { ...r, crime_pressure: Math.min(1.0, r.crime_pressure + 0.15) };
        }
        return r;
      });
    });
  }

  applyScenarioChange(scenario: SandboxScenario) {
    this.currentScenario.set(scenario);
    // Force immediate price discover round to propagate the macro shock!
    this.discoverPricesHourly();
  }

  private getRegionName(id: string): string {
    return this.regions().find(r => r.id === id)?.name || 'Local District';
  }
}
