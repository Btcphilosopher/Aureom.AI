export enum Currency {
  USD = 'USD',
  GTC = 'GTC', // Grand Theft Coin (Fictional crypto)
}

export enum TransactionType {
  Purchase = 'Purchase',
  Sale = 'Sale',
  Salary = 'Salary',
  Tax = 'Tax',
  Loan = 'Loan',
  LoanRepayment = 'LoanRepayment',
  Insurance = 'Insurance',
  PropertyPurchase = 'PropertyPurchase',
  PropertySale = 'PropertySale',
  VehiclePurchase = 'VehiclePurchase',
  VehicleSale = 'VehicleSale',
  MissionReward = 'MissionReward',
  BusinessRevenue = 'BusinessRevenue',
  BusinessExpense = 'BusinessExpense',
  GovernmentSpending = 'GovernmentSpending',
  MarketSettlement = 'MarketSettlement'
}

export enum CommodityType {
  Fuel = 'Fuel',
  Food = 'Food',
  Vehicles = 'Vehicles',
  Electronics = 'Electronics',
  Clothing = 'Clothing',
  Construction = 'Construction',
  Property = 'Property',
  LuxuryGoods = 'LuxuryGoods',
  IndustrialGoods = 'IndustrialGoods',
  Services = 'Services',
  BlackMarketNarcotics = 'BlackMarketNarcotics',
  BlackMarketWeapons = 'BlackMarketWeapons',
}

export interface Player {
  id: string;
  name: string;
  cash_minor: number;
  bank_minor: number;
  digital_minor: number;
  loans_minor: number;
  net_worth_history: { day: number; net_worth: number }[];
}

export interface Npc {
  id: string;
  name: string;
  occupation: string;
  income_rate_minor: number; // per day
  wallet_cash_minor: number;
  savings_minor: number;
  housing_cost_minor: number;
  transport_cost_minor: number;
  risk_tolerance: number; // 0.0 to 1.0
  employer_id: string | null;
  isActive: boolean;
}

export interface Business {
  id: string;
  name: string;
  region_id: string;
  owner_id: string; // Player or NPC ID
  employees_count: number;
  daily_revenue: number;
  daily_cogs: number;
  daily_labor_expense: number;
  daily_rent_expense: number;
  daily_utilities_expense: number;
  daily_taxes_expense: number;
  daily_financing_expense: number;
  debt_minor: number;
  cash_on_hand_minor: number;
  inventory_value_minor: number;
  commodity_type: CommodityType;
}

export interface Property {
  id: string;
  name: string;
  region_id: string;
  owner_id: string; // Player, Business, or State
  purchase_price_minor: number;
  current_valuation_minor: number;
  monthly_rent_minor: number;
  size_sqft: number;
  condition_score: number; // 0.0 - 1.0
  mortgage_balance_minor: number;
}

export interface Vehicle {
  id: string;
  model_name: string;
  owner_id: string;
  purchase_price_minor: number;
  market_value_minor: number;
  depreciation_rate_annual: number;
  mileage_miles: number;
  condition_score: number;
}

export interface Market {
  id: string;
  region_id: string;
  commodity_type: CommodityType;
  supply: number; // 10 to 500
  demand: number; // 10 to 500
  price_minor: number;
  base_price_minor: number;
  price_volatility: number;
  transaction_volume: number;
}

export interface Region {
  id: string;
  name: string;
  population: number;
  avg_income_minor: number;
  crime_pressure: number; // 0.0 - 1.0
  business_density: number; // 0.0 - 1.0
}

export interface LedgerEntry {
  id: string;
  transaction_id: string;
  account_id: string;
  account_name: string;
  debit_minor: number;
  credit_minor: number;
  created_at: string;
}

export interface Transaction {
  id: string;
  tx_type: TransactionType;
  description: string;
  amount_minor: number;
  timestamp: string;
  region_id?: string;
  related_asset_id?: string;
  related_mission_id?: string;
}

export interface EconomicShock {
  id: string;
  name: string;
  description: string;
  affected_region_id: string | null;
  multipliers: { commodity: CommodityType; factor: number }[];
  duration_days: number;
  remaining_days: number;
}

export enum SandboxScenario {
  BalancedExpansion = 'BalancedExpansion',
  HyperinflationFuelShortage = 'HyperinflationFuelShortage',
  RealEstateCollapse = 'RealEstateCollapse',
  CrimeSyndicateBoom = 'CrimeSyndicateBoom',
}
