import { ChangeDetectionStrategy, Component, inject, OnInit, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EconomyService } from './economy.service';
import { Market, SandboxScenario } from './economy-types';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  public economy = inject(EconomyService);

  // View States
  activeTab = signal<'Markets' | 'Ledger' | 'Entities' | 'Assets'>('Markets');
  selectedRegionId = signal<string>('reg-downtown');
  selectedNpcId = signal<string | null>(null);

  // Ticking Timer reference
  private timerId: ReturnType<typeof setInterval> | null = null;

  ngOnInit() {
    this.startSimulationLoop();
  }

  ngOnDestroy() {
    this.stopSimulationLoop();
  }

  // --- Core Simulation Controls ---
  togglePlayPause() {
    this.economy.isPaused.update(p => !p);
    if (!this.economy.isPaused()) {
      this.startSimulationLoop();
    } else {
      this.stopSimulationLoop();
    }
  }

  setSpeed(newSpeed: string) {
    if (newSpeed === 'Slow' || newSpeed === 'Normal' || newSpeed === 'Fast' || newSpeed === 'Extreme') {
      this.economy.speed.set(newSpeed);
      if (!this.economy.isPaused()) {
        this.stopSimulationLoop();
        this.startSimulationLoop();
      }
    }
  }

  triggerSingleTick() {
    this.economy.tickSimulation();
  }

  triggerDailyTick() {
    // Jump 1440 ticks directly to complete a simulated daily accounting settlement
    for (let i = 0; i < 1440; i++) {
      this.economy.tickSimulation();
    }
  }

  triggerMonthlyTick() {
    // Jump 43200 ticks directly to complete a simulated macroeconomic month
    for (let i = 0; i < 43200; i++) {
      this.economy.tickSimulation();
    }
  }

  onReset(seed: number) {
    this.economy.resetToSeed(seed);
  }

  onScenarioSelect(event: Event) {
    const select = event.target as HTMLSelectElement;
    this.economy.applyScenarioChange(select.value as SandboxScenario);
  }

  // --- Player Interactive Operations ---
  onPlayerBuy(market: Market) {
    this.economy.executePlayerPurchase(market, 1);
  }

  onPlayerSell(market: Market) {
    this.economy.executePlayerSale(market, 1);
  }

  onTriggerHeist() {
    this.economy.completeRobberyMission();
  }

  onLayOffNpc(npcId: string) {
    this.economy.npcs.update(prev => {
      return prev.map(n => {
        if (n.id === npcId) {
          // Fire NPC, setting employer to null and raising unemployment
          return { ...n, employer_id: null, income_rate_minor: 10000 }; // wages drop to basic welfare
        }
        return n;
      });
    });
  }

  onReAppraiseProperty(propId: string) {
    this.economy.properties.update(prev => {
      return prev.map(p => {
        if (p.id === propId) {
          // appraise property +5% to +15% based on random volatility
          const appraisalModifier = 1.05 + Math.random() * 0.10;
          const nextVal = Math.round(p.current_valuation_minor * appraisalModifier);
          return {
            ...p,
            current_valuation_minor: nextVal,
            monthly_rent_minor: Math.round(nextVal * 0.005)
          };
        }
        return p;
      });
    });
  }

  // --- Background Timed Tickers ---
  private startSimulationLoop() {
    this.stopSimulationLoop();
    if (this.economy.isPaused()) return;

    let intervalMs = 800; // Normal
    if (this.economy.speed() === 'Slow') intervalMs = 1500;
    if (this.economy.speed() === 'Fast') intervalMs = 300;
    if (this.economy.speed() === 'Extreme') intervalMs = 50;

    this.timerId = setInterval(() => {
      this.economy.tickSimulation();
    }, intervalMs);
  }

  private stopSimulationLoop() {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  // --- UI Helpers ---
  getRegionName(id: string): string {
    return this.economy.regions().find(r => r.id === id)?.name || 'Unknown';
  }

  getMarketsForSelectedRegion(): Market[] {
    return this.economy.markets().filter(m => m.region_id === this.selectedRegionId());
  }

  getNpcsForEmployer(bizId: string) {
    return this.economy.npcs().filter(n => n.employer_id === bizId);
  }

  getPropertiesByOwner(ownerId: string) {
    return this.economy.properties().filter(p => p.owner_id === ownerId);
  }

  getVehiclesByOwner(ownerId: string) {
    return this.economy.vehicles().filter(v => v.owner_id === ownerId);
  }

  getBusinessesByOwner(ownerId: string) {
    return this.economy.businesses().filter(b => b.owner_id === ownerId);
  }
}
