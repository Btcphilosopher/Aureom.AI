use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Npc {
    pub id: Uuid,
    pub name: String,
    pub occupation: String,
    pub income_rate_minor: i64, // per game day (accounting period)
    pub wallet_cash_minor: i64,
    pub savings_account_id: Uuid,
    pub housing_cost_minor: i64,
    pub transport_cost_minor: i64,
    pub food_preference_multiplier: f64,
    pub risk_tolerance: f64, // 0.0 (safe) to 1.0 (volatile/black market buyer)
    pub employer_id: Option<Uuid>, // Business ID if employed
}

impl Npc {
    pub fn new(name: String, occupation: String, income: i64, savings_account_id: Uuid) -> Self {
        Self {
            id: Uuid::new_v4(),
            name,
            occupation,
            income_rate_minor: income,
            wallet_cash_minor: 10000, // starts with $100.00 cash
            savings_account_id,
            housing_cost_minor: (income as f64 * 0.3) as i64, // 30% rent
            transport_cost_minor: (income as f64 * 0.1) as i64, // 10% gas/commute
            food_preference_multiplier: 1.0,
            risk_tolerance: 0.5,
            employer_id: None,
        }
    }

    /// Run NPC daily budgeting cycle
    /// Cash inflow: Salary -> Wallet
    /// Outflows: Rent, Utilities, Food, Fuel -> Savings
    pub fn process_daily_budget(&mut self) -> i64 {
        let gross_income = self.income_rate_minor;
        let food_cost = 5000; // base food expense ($50.00)
        let total_outflows = self.housing_cost_minor + self.transport_cost_minor + food_cost;

        // Discretionary spending
        let net_savings = gross_income - total_outflows;
        if net_savings > 0 {
            self.wallet_cash_minor += net_savings;
        } else {
            // Debt / overdraft
            self.wallet_cash_minor += net_savings;
        }

        total_outflows
    }
}
