use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Vehicle {
    pub id: Uuid,
    pub model_name: String,
    pub owner_id: Uuid,
    pub purchase_price_minor: i64,
    pub market_value_minor: i64,
    pub depreciation_rate_annual: f64,
    pub mileage_miles: u32,
    pub condition_score: f64, // 0.0 (totaled) to 1.0 (mint)
    pub insurance_policy_id: Option<Uuid>,
}

impl Vehicle {
    pub fn tick_depreciation(&mut self) {
        // Daily rate is annual rate / 365
        let daily_rate = self.depreciation_rate_annual / 365.0;
        
        // Mileage decay: additional depreciation for every 10,000 miles
        let mileage_decay = (self.mileage_miles as f64 / 10000.0) * 0.02;
        let total_decay_factor = daily_rate + mileage_decay;

        let reduction = self.market_value_minor as f64 * total_decay_factor;
        self.market_value_minor = (self.market_value_minor as f64 - reduction).round() as i64;
    }
}
