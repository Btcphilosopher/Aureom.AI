use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommodityMetadata {
    pub name: String,
    pub is_perishable: bool,
    pub storage_units_required: u32,
    pub wholesale_markup_multiplier: f64,
}

pub fn get_metadata(commodity_type: crate::markets::market::CommodityType) -> CommodityMetadata {
    use crate::markets::market::CommodityType::*;
    match commodity_type {
        Fuel => CommodityMetadata { name: "Fuel".to_string(), is_perishable: false, storage_units_required: 1, wholesale_markup_multiplier: 1.1 },
        Food => CommodityMetadata { name: "Food".to_string(), is_perishable: true, storage_units_required: 1, wholesale_markup_multiplier: 1.2 },
        Vehicles => CommodityMetadata { name: "Vehicles".to_string(), is_perishable: false, storage_units_required: 10, wholesale_markup_multiplier: 1.15 },
        Electronics => CommodityMetadata { name: "Electronics".to_string(), is_perishable: false, storage_units_required: 2, wholesale_markup_multiplier: 1.25 },
        Clothing => CommodityMetadata { name: "Clothing".to_string(), is_perishable: false, storage_units_required: 1, wholesale_markup_multiplier: 1.4 },
        Construction => CommodityMetadata { name: "Construction Materials".to_string(), is_perishable: false, storage_units_required: 5, wholesale_markup_multiplier: 1.08 },
        Property => CommodityMetadata { name: "Real Estate Property".to_string(), is_perishable: false, storage_units_required: 0, wholesale_markup_multiplier: 1.05 },
        LuxuryGoods => CommodityMetadata { name: "Luxury Goods".to_string(), is_perishable: false, storage_units_required: 1, wholesale_markup_multiplier: 1.6 },
        IndustrialGoods => CommodityMetadata { name: "Industrial Equipment".to_string(), is_perishable: false, storage_units_required: 8, wholesale_markup_multiplier: 1.1 },
        Services => CommodityMetadata { name: "Professional Services".to_string(), is_perishable: false, storage_units_required: 0, wholesale_markup_multiplier: 1.3 },
        BlackMarketNarcotics => CommodityMetadata { name: "Fictional Narcotics".to_string(), is_perishable: false, storage_units_required: 1, wholesale_markup_multiplier: 2.0 },
        BlackMarketWeapons => CommodityMetadata { name: "Fictional Heavy Weapons".to_string(), is_perishable: false, storage_units_required: 3, wholesale_markup_multiplier: 1.8 },
    }
}
