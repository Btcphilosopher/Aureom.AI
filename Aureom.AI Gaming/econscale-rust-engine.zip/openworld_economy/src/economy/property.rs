use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Property {
    pub id: Uuid,
    pub name: String,
    pub region_id: Uuid,
    pub owner_id: Uuid,
    pub purchase_price_minor: i64,
    pub current_valuation_minor: i64,
    pub monthly_rent_minor: i64,
    pub maintenance_fee_minor: i64,
    pub annual_tax_minor: i64,
    pub mortgage_balance_minor: i64,
    pub size_sqft: u32,
    pub condition_score: f64, // 0.0 to 1.0 (perfect)
}

impl Property {
    pub fn update_valuation(&mut self, region_growth_pct: f64, crime_level_pct: f64) {
        // Valuation goes up with economic growth, down with crime
        let base_growth = 0.02 + region_growth_pct;
        let decay = crime_level_pct * 0.05;
        let net_pct = base_growth - decay;

        let delta = self.current_valuation_minor as f64 * net_pct;
        self.current_valuation_minor += delta.round() as i64;
        
        // Rent adjusts based on current valuation
        self.monthly_rent_minor = (self.current_valuation_minor as f64 * 0.005).round() as i64; // 0.5% of value monthly
    }
}
