use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Business {
    pub id: Uuid,
    pub name: String,
    pub region_id: Uuid,
    pub corporate_owner_id: Uuid, // can be a Company or Player ID
    pub bank_account_id: Uuid,
    pub employees_count: u32,
    
    // Financial State (Minor Units)
    pub daily_revenue: i64,
    pub daily_cogs: i64,
    pub daily_labor_expense: i64,
    pub daily_rent_expense: i64,
    pub daily_utilities_expense: i64,
    pub daily_taxes_expense: i64,
    pub daily_financing_expense: i64,
    pub debt_minor: i64,
    pub cash_on_hand_minor: i64,
    pub inventory_value_minor: i64,

    // Historical Performance
    pub monthly_profit_history: Vec<i64>,
}

impl Business {
    pub fn new(name: String, region_id: Uuid, owner_id: Uuid, bank_account_id: Uuid) -> Self {
        Self {
            id: Uuid::new_v4(),
            name,
            region_id,
            corporate_owner_id: owner_id,
            bank_account_id,
            employees_count: 5,
            daily_revenue: 0,
            daily_cogs: 0,
            daily_labor_expense: 50000,    // $500.00
            daily_rent_expense: 15000,     // $150.00
            daily_utilities_expense: 5000, // $50.00
            daily_taxes_expense: 0,
            daily_financing_expense: 0,
            debt_minor: 0,
            cash_on_hand_minor: 1000000,   // $10,000.00 start
            inventory_value_minor: 250000, // $2,500.00 start
            monthly_profit_history: Vec::new(),
        }
    }

    // Double-entry Profitability metrics
    pub fn calculate_ebitda(&self) -> i64 {
        self.daily_revenue - self.daily_cogs - self.daily_labor_expense - self.daily_rent_expense - self.daily_utilities_expense
    }

    pub fn calculate_net_profit(&self) -> i64 {
        self.calculate_ebitda() - self.daily_taxes_expense - self.daily_financing_expense
    }

    pub fn gross_margin(&self) -> f64 {
        if self.daily_revenue == 0 { return 0.0; }
        (self.daily_revenue - self.daily_cogs) as f64 / self.daily_revenue as f64
    }

    pub fn net_margin(&self) -> f64 {
        if self.daily_revenue == 0 { return 0.0; }
        self.calculate_net_profit() as f64 / self.daily_revenue as f64
    }
}
