use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EconomicShock {
    pub id: Uuid,
    pub name: String,
    pub description: String,
    pub affected_region_id: Option<Uuid>,
    pub commodity_multipliers: Vec<(crate::markets::market::CommodityType, f64)>, // Commodity -> Price/Supply Multiplier
    pub duration_days: u32,
    pub remaining_days: u32,
}

impl EconomicShock {
    pub fn new_fuel_shortage(region_id: Option<Uuid>) -> Self {
        Self {
            id: Uuid::new_v4(),
            name: "Fuel Shortage".to_string(),
            description: "Port disruption slows oil tankers, spiking dynamic fuel prices".to_string(),
            affected_region_id: region_id,
            commodity_multipliers: vec![
                (crate::markets::market::CommodityType::Fuel, 2.5),
                (crate::markets::market::CommodityType::IndustrialGoods, 1.3),
            ],
            duration_days: 7,
            remaining_days: 7,
        }
    }

    pub fn new_property_boom(region_id: Option<Uuid>) -> Self {
        Self {
            id: Uuid::new_v4(),
            name: "Property Boom".to_string(),
            description: "Financial deregulation triggers massive speculation in regional real estate".to_string(),
            affected_region_id: region_id,
            commodity_multipliers: vec![
                (crate::markets::market::CommodityType::Property, 1.8),
                (crate::markets::market::CommodityType::Construction, 1.4),
            ],
            duration_days: 14,
            remaining_days: 14,
        }
    }
}
