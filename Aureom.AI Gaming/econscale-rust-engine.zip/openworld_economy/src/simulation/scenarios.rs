use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SandboxScenario {
    BalancedExpansion,
    HyperinflationFuelShortage,
    RealEstateCollapse,
    CrimeSyndicateBoom,
}

impl SandboxScenario {
    pub fn description(&self) -> &str {
        match self {
            Self::BalancedExpansion => "Moderate growth, low crime pressure, stable dynamic prices",
            Self::HyperinflationFuelShortage => "Fuel supply falls 70%, prices spike 3x, transportation costs double",
            Self::RealEstateCollapse => "Property valuation drops 50%, rent decreases, construction materials collapse",
            Self::CrimeSyndicateBoom => "Black market premium increases, high risk, high cash velocity",
        }
    }
}
