use std::sync::Arc;
use crate::core::state::WorldState;

pub struct AgentDecisionEngine {
    world_state: Arc<WorldState>,
}

impl AgentDecisionEngine {
    pub fn new(world_state: Arc<WorldState>) -> Self {
        Self { world_state }
    }

    /// Let NPCs check if they can upgrade their residence or purchase vehicles
    pub fn execute_npc_decisions(&self) {
        // High performance simulation using Rayon iterator
        use rayon::prelude::*;

        // Rayon parallel iteration over NPCs
        // For testing/demonstration, we execute simple spending preferences
        self.world_state.npcs.iter_mut().for_each(|mut npc_ref| {
            let npc = npc_ref.value_mut();
            if npc.wallet_cash_minor > 100000 { // If NPC has > $1,000 cash
                // Spend 15% on Luxury Goods or Electronics if high risk tolerance
                if npc.risk_tolerance > 0.7 {
                    let spend = (npc.wallet_cash_minor as f64 * 0.15) as i64;
                    npc.wallet_cash_minor -= spend;
                    // Trigger economic demand index rise
                }
            }
        });
    }

    /// Let businesses optimize their workforce and adjust commodity retail pricing
    pub fn execute_business_decisions(&self) {
        self.world_state.businesses.iter_mut().for_each(|mut biz_ref| {
            let biz = biz_ref.value_mut();
            let profit = biz.calculate_net_profit();
            
            if profit < -50000 { // if losing > $500/day
                if biz.employees_count > 1 {
                    biz.employees_count -= 1; // Lay off a worker to save costs
                    biz.daily_labor_expense -= 10000; // save $100.00/day
                }
            } else if profit > 100000 { // if making > $1,000/day
                biz.employees_count += 1; // Hire more workers to scale up
                biz.daily_labor_expense += 10000;
            }
        });
    }
}
