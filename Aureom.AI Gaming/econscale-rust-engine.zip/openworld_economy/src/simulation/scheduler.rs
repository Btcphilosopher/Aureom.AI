use std::sync::Arc;
use crate::core::engine::EconomicEngine;

pub struct SimulationScheduler {
    engine: Arc<EconomicEngine>,
}

impl SimulationScheduler {
    pub fn new(engine: Arc<EconomicEngine>) -> Self {
        Self { engine }
    }

    /// Triggered every simulated hour
    pub async fn tick_hourly(&self) -> anyhow::Result<()> {
        // 1. Process supply chain nodes production
        // 2. Discover commodity market prices
        self.engine.discover_all_prices().await?;
        Ok(())
    }

    /// Triggered every simulated day (accounting time)
    pub async fn tick_daily(&self) -> anyhow::Result<()> {
        // 1. Process NPC daily salaries and budgets
        // 2. Pay rent and maintenance fees
        // 3. Process business daily payroll, rent, utilities
        // 4. Update property valuations based on regional factors
        // 5. Run vehicle depreciation
        self.engine.process_daily_settlements().await?;
        Ok(())
    }
}
