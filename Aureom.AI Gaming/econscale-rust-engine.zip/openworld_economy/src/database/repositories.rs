use uuid::Uuid;
use sqlx::{Pool, Postgres};

pub struct EconomicRepository {
    pool: Pool<Postgres>,
}

impl EconomicRepository {
    pub fn new(pool: Pool<Postgres>) -> Self {
        Self { pool }
    }

    pub async fn fetch_player_balance_minor(&self, player_id: Uuid) -> sqlx::Result<i64> {
        let rec = sqlx::query!(
            "SELECT bank_minor FROM players WHERE id = $1",
            player_id
        )
        .fetch_one(&self.pool)
        .await?;
        Ok(rec.bank_minor)
    }

    pub async fn update_player_balance_minor(&self, player_id: Uuid, new_balance_minor: i64) -> sqlx::Result<()> {
        sqlx::query!(
            "UPDATE players SET bank_minor = $1, updated_at = NOW() WHERE id = $2",
            new_balance_minor,
            player_id
        )
        .execute(&self.pool)
        .await?;
        Ok(())
    }
}
