use sqlx::{Pool, Postgres};
use tracing::info;

pub async fn run_migrations(pool: &Pool<Postgres>) -> Result<(), sqlx::Error> {
    info!("Running database migrations for openworld_economy...");

    // Create a transaction block
    let mut tx = pool.begin().await?;

    // Create Regions and Players
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS regions (
            id UUID PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            population INT NOT NULL DEFAULT 0,
            avg_income_minor BIGINT NOT NULL DEFAULT 0,
            crime_pressure DOUBLE PRECISION NOT NULL DEFAULT 0.0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS players (
            id UUID PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            cash_minor BIGINT NOT NULL DEFAULT 0,
            bank_minor BIGINT NOT NULL DEFAULT 0,
            digital_minor BIGINT NOT NULL DEFAULT 0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    // Create Accounts and Ledger Entries
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS accounts (
            id UUID PRIMARY KEY,
            owner_id UUID NOT NULL,
            balance_minor BIGINT NOT NULL DEFAULT 0,
            currency VARCHAR(10) NOT NULL,
            is_frozen BOOLEAN NOT NULL DEFAULT FALSE,
            allow_overdraft BOOLEAN NOT NULL DEFAULT FALSE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS transactions (
            id UUID PRIMARY KEY,
            tx_type VARCHAR(50) NOT NULL,
            description TEXT NOT NULL,
            region_id UUID,
            related_asset_id UUID,
            related_mission_id UUID,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS ledger_entries (
            id UUID PRIMARY KEY,
            transaction_id UUID NOT NULL REFERENCES transactions(id),
            account_id UUID NOT NULL,
            debit BIGINT NOT NULL DEFAULT 0,
            credit BIGINT NOT NULL DEFAULT 0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    // Create NPCs and Businesses
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS npcs (
            id UUID PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            occupation VARCHAR(100) NOT NULL,
            income_rate_minor BIGINT NOT NULL,
            wallet_cash_minor BIGINT NOT NULL,
            savings_account_id UUID NOT NULL REFERENCES accounts(id),
            housing_cost_minor BIGINT NOT NULL,
            transport_cost_minor BIGINT NOT NULL,
            risk_tolerance DOUBLE PRECISION NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS businesses (
            id UUID PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            region_id UUID REFERENCES regions(id),
            corporate_owner_id UUID NOT NULL,
            bank_account_id UUID REFERENCES accounts(id),
            employees_count INT NOT NULL DEFAULT 1,
            daily_revenue BIGINT NOT NULL DEFAULT 0,
            daily_cogs BIGINT NOT NULL DEFAULT 0,
            daily_labor_expense BIGINT NOT NULL DEFAULT 0,
            daily_rent_expense BIGINT NOT NULL DEFAULT 0,
            debt_minor BIGINT NOT NULL DEFAULT 0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    // Create Properties, Vehicles, Assets
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS properties (
            id UUID PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            region_id UUID REFERENCES regions(id),
            owner_id UUID NOT NULL,
            purchase_price_minor BIGINT NOT NULL,
            current_valuation_minor BIGINT NOT NULL,
            monthly_rent_minor BIGINT NOT NULL,
            size_sqft INT NOT NULL,
            condition_score DOUBLE PRECISION NOT NULL DEFAULT 1.0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS vehicles (
            id UUID PRIMARY KEY,
            model_name VARCHAR(100) NOT NULL,
            owner_id UUID NOT NULL,
            purchase_price_minor BIGINT NOT NULL,
            market_value_minor BIGINT NOT NULL,
            depreciation_rate_annual DOUBLE PRECISION NOT NULL,
            mileage_miles INT NOT NULL DEFAULT 0,
            condition_score DOUBLE PRECISION NOT NULL DEFAULT 1.0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    // Create Markets and Pricing
    sqlx::query(
        "CREATE TABLE IF NOT EXISTS markets (
            id UUID PRIMARY KEY,
            region_id UUID REFERENCES regions(id),
            commodity_type VARCHAR(50) NOT NULL,
            supply DOUBLE PRECISION NOT NULL DEFAULT 100.0,
            demand DOUBLE PRECISION NOT NULL DEFAULT 100.0,
            price_minor BIGINT NOT NULL,
            base_price_minor BIGINT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    sqlx::query(
        "CREATE TABLE IF NOT EXISTS price_history (
            id UUID PRIMARY KEY,
            market_id UUID NOT NULL REFERENCES markets(id),
            price_minor BIGINT NOT NULL,
            recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );"
    ).execute(&mut *tx).await?;

    tx.commit().await?;
    info!("Database migrations applied successfully.");
    Ok(())
}
