use sqlx::{PgPool, postgres::PgPoolOptions};
use std::time::Duration;

pub async fn create_db_pool(connection_string: &str) -> Result<PgPool, sqlx::Error> {
    PgPoolOptions::new()
        .max_connections(50)
        .min_connections(5)
        .acquire_timeout(Duration::from_secs(3))
        .idle_timeout(Duration::from_secs(600))
        .connect(connection_string)
        .await
}
