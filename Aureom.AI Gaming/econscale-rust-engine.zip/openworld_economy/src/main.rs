use std::net::SocketAddr;
use std::sync::Arc;
use tokio::sync::broadcast;
use tracing::{info, error};

mod core;
mod accounts;
mod transactions;
mod markets;
mod economy;
mod inventory;
mod simulation;
mod database;
mod analytics;
mod api;

use crate::core::engine::EconomicEngine;
use crate::core::clock::SimulationClock;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Initialize tracing
    tracing_subscriber::fmt::init();
    info!("Starting AAA Open-World Game Economic Operating System (Rust Engine)...");

    // Load configuration/environment
    let db_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "postgres://postgres:postgres@localhost:5432/openworld_econ".to_string());

    info!("Connecting to PostgreSQL database...");
    let pool = match sqlx::PgPool::connect(&db_url).await {
        Ok(p) => {
            info!("Successfully connected to database");
            Some(p)
        }
        Err(e) => {
            error!("Database connection failed: {}. Continuing in memory-only mode for simulation simulation.", e);
            None
        }
    };

    // Create a broadcast channel for real-time economic events
    let (event_tx, _event_rx) = broadcast::channel(10000);

    // Initialize the core simulation clock and economic engine
    let clock = Arc::new(SimulationClock::new());
    let engine = Arc::new(EconomicEngine::new(pool, event_tx, clock.clone()));

    // Run migrations if database is connected
    if let Some(ref p) = engine.db_pool {
        if let Err(e) = database::migrations::run_migrations(p).await {
            error!("Migration failure: {:?}", e);
        }
    }

    // Populate a test world/scenario if starting clean
    info!("Initializing system state and populating entities...");
    engine.populate_test_world(1337).await?; // seed 1337

    // Start the simulation background runner
    let engine_clone = engine.clone();
    let clock_clone = clock.clone();
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(tokio::time::Duration::from_millis(1000));
        loop {
            interval.tick().await;
            clock_clone.tick();
            if let Err(e) = engine_clone.step_simulation().await {
                error!("Error during simulation step: {:?}", e);
            }
        }
    });

    // Start Axum REST API
    let app = api::routes::create_router(engine.clone());
    let addr = SocketAddr::from(([0, 0, 0, 0], 8080));
    info!("Economic REST API listening on {}", addr);
    
    // In a real AAA server deployment, we would run:
    // axum::serve(tokio::net::TcpListener::bind(addr).await?, app).await?;
    // For this mock representation, we include the full router and handler logic.

    Ok(())
}
