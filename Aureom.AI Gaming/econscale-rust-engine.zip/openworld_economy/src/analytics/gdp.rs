use crate::economy::business::Business;

pub struct GdpAnalytics;

impl GdpAnalytics {
    /// Calculate Gross Domestic Product (GDP) using the Production/Income method.
    /// Sum of all business revenues plus player wage earnings.
    pub fn calculate_gdp(businesses: &[Business], total_wages_minor: i64) -> i64 {
        let business_total_revenue: i64 = businesses.iter().map(|b| b.daily_revenue).sum();
        business_total_revenue + total_wages_minor
    }
}
