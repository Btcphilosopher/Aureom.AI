use crate::markets::market::Market;

pub struct InflationTracker;

impl InflationTracker {
    /// Calculate CPI (Consumer Price Index) inflation by comparing current average prices of necessities to base prices.
    pub fn calculate_inflation(markets: &[Market]) -> f64 {
        let mut total_current = 0f64;
        let mut total_base = 0f64;

        for m in markets {
            total_current += m.price_minor as f64;
            total_base += m.base_price_minor as f64;
        }

        if total_base == 0.0 { return 0.0; }
        
        let cpi = total_current / total_base;
        (cpi - 1.0) * 100.0 // percentage inflation rate
    }
}
