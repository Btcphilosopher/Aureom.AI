use crate::markets::market::Market;

pub struct MarketAnalytics;

impl MarketAnalytics {
    pub fn total_market_volume(markets: &[Market]) -> u64 {
        markets.iter().map(|m| m.transaction_volume).sum()
    }

    pub fn find_most_volatile_market(markets: &[Market]) -> Option<Market> {
        markets.iter()
            .max_by(|a, b| a.price_volatility.partial_cmp(&b.price_volatility).unwrap())
            .cloned()
    }
}
