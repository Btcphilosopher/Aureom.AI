use crate::accounts::account::Account;

pub struct WealthAnalytics;

impl WealthAnalytics {
    /// Calculate the Gini coefficient representing wealth inequality among a set of accounts.
    /// Gini ranges from 0.0 (perfect equality) to 1.0 (perfect inequality).
    pub fn calculate_gini_coefficient(balances: &mut [i64]) -> f64 {
        let n = balances.len();
        if n < 2 { return 0.0; }

        balances.sort_unstable();
        
        let mut sum_absolute_diffs = 0f64;
        let mut sum_balances = 0f64;

        for i in 0..n {
            sum_balances += balances[i] as f64;
            // Sum differences
            for j in 0..n {
                sum_absolute_diffs += (balances[i] - balances[j]).abs() as f64;
            }
        }

        if sum_balances == 0.0 { return 0.0; }

        sum_absolute_diffs / (2.0 * n as f64 * sum_balances)
    }

    pub fn total_wealth(accounts: &[Account]) -> i64 {
        accounts.iter().map(|a| a.balance_minor).sum()
    }
}
