use std::sync::Arc;
use chrono::Utc;
use uuid::Uuid;
use tokio::sync::broadcast;
use sqlx::{Pool, Postgres, Transaction as DbTransaction};

use crate::core::state::WorldState;
use crate::core::events::EconomicEvent;
use crate::accounts::account::{Account, Money, Currency};
use crate::accounts::ledger::{LedgerEntry, LedgerEngine, Transaction as CoreTransaction, TransactionType};
use crate::transactions::transaction::{TransactionRequest, TransactionReceipt, TransactionStatus};
use crate::transactions::validation::TransactionValidator;

pub struct TransactionProcessor {
    world_state: Arc<WorldState>,
    db_pool: Option<Pool<Postgres>>,
    event_tx: broadcast::Sender<EconomicEvent>,
}

impl TransactionProcessor {
    pub fn new(
        world_state: Arc<WorldState>,
        db_pool: Option<Pool<Postgres>>,
        event_tx: broadcast::Sender<EconomicEvent>,
    ) -> Self {
        Self {
            world_state,
            db_pool,
            event_tx,
        }
    }

    pub async fn process_transaction(
        &self,
        request: TransactionRequest,
    ) -> anyhow::Result<TransactionReceipt> {
        let tx_id = Uuid::new_v4();
        let now = Utc::now();

        // 1. IN-MEMORY STAGE (High-frequency, locked block)
        let mut sender_acct = match self.world_state.accounts.get_mut(&request.sender_account_id) {
            Some(a) => a,
            None => {
                return Ok(TransactionReceipt {
                    transaction_id: tx_id,
                    status: TransactionStatus::Failed,
                    timestamp: now,
                    error_message: Some(format!("Sender account {} not found", request.sender_account_id)),
                });
            }
        };

        let mut receiver_acct = match self.world_state.accounts.get_mut(&request.receiver_account_id) {
            Some(a) => a,
            None => {
                return Ok(TransactionReceipt {
                    transaction_id: tx_id,
                    status: TransactionStatus::Failed,
                    timestamp: now,
                    error_message: Some(format!("Receiver account {} not found", request.receiver_account_id)),
                });
            }
        };

        // Validate
        if let Err(e) = TransactionValidator::validate(&sender_acct, request.amount_minor) {
            return Ok(TransactionReceipt {
                transaction_id: tx_id,
                status: TransactionStatus::Failed,
                timestamp: now,
                error_message: Some(e.to_string()),
            });
        }

        // Apply ledger balance verification
        let ledger_entries = vec![
            LedgerEntry {
                id: Uuid::new_v4(),
                transaction_id: tx_id,
                account_id: request.sender_account_id,
                debit_minor: 0,
                credit_minor: request.amount_minor,
                created_at: now,
            },
            LedgerEntry {
                id: Uuid::new_v4(),
                transaction_id: tx_id,
                account_id: request.receiver_account_id,
                debit_minor: request.amount_minor,
                credit_minor: 0,
                created_at: now,
            },
        ];

        // Double-entry validation
        if let Err(e) = LedgerEngine::validate_entries(&ledger_entries) {
            return Ok(TransactionReceipt {
                transaction_id: tx_id,
                status: TransactionStatus::Failed,
                timestamp: now,
                error_message: Some(format!("Double-entry ledger validation failed: {:?}", e)),
            });
        }

        // Apply in-memory balances
        let withdraw_money = Money::new(request.amount_minor, sender_acct.currency);
        let deposit_money = Money::new(request.amount_minor, receiver_acct.currency);

        if let Err(e) = sender_acct.withdraw(withdraw_money) {
            return Ok(TransactionReceipt {
                transaction_id: tx_id,
                status: TransactionStatus::Failed,
                timestamp: now,
                error_message: Some(format!("Withdrawal error: {:?}", e)),
            });
        }

        if let Err(e) = receiver_acct.deposit(deposit_money) {
            // ROLLBACK sender balance
            let _ = sender_acct.deposit(withdraw_money);
            return Ok(TransactionReceipt {
                transaction_id: tx_id,
                status: TransactionStatus::Failed,
                timestamp: now,
                error_message: Some(format!("Deposit error: {:?}", e)),
            });
        }

        // 2. DATABASE PERSISTENCE STAGE
        if let Some(ref pool) = self.db_pool {
            let mut db_tx = pool.begin().await?;
            if let Err(e) = self.persist_to_db(&mut db_tx, tx_id, &request, &ledger_entries, &sender_acct, &receiver_acct).await {
                // Rollback database, revert in-memory updates
                let _ = db_tx.rollback().await;
                let _ = sender_acct.deposit(withdraw_money);
                let _ = receiver_acct.withdraw(deposit_money);
                return Ok(TransactionReceipt {
                    transaction_id: tx_id,
                    status: TransactionStatus::Failed,
                    timestamp: now,
                    error_message: Some(format!("Database persistence failure, rolled back in-memory: {:?}", e)),
                });
            }
            db_tx.commit().await?;
        }

        // 3. BROADCAST COMPLETED EVENTS
        let _ = self.event_tx.send(EconomicEvent::TransactionCompleted {
            tx_id,
            tx_type: request.tx_type,
            actor_id: sender_acct.owner_id,
            counterparty_id: receiver_acct.owner_id,
            minor_units: request.amount_minor,
            currency: format!("{:?}", sender_acct.currency),
            timestamp: now,
        });

        Ok(TransactionReceipt {
            transaction_id: tx_id,
            status: TransactionStatus::Success,
            timestamp: now,
            error_message: None,
        })
    }

    async fn persist_to_db(
        &self,
        db_tx: &mut DbTransaction<'_, Postgres>,
        tx_id: Uuid,
        req: &TransactionRequest,
        entries: &[LedgerEntry],
        sender: &Account,
        receiver: &Account,
    ) -> sqlx::Result<()> {
        // Record master transaction
        sqlx::query!(
            "INSERT INTO transactions (id, tx_type, description, created_at, region_id, related_asset_id, related_mission_id) \
             VALUES ($1, $2, $3, $4, $5, $6, $7)",
            tx_id,
            format!("{:?}", req.tx_type),
            req.description,
            Utc::now(),
            req.region_id,
            req.related_asset_id,
            req.related_mission_id
        )
        .execute(&mut **db_tx)
        .await?;

        // Record ledger entries
        for entry in entries {
            sqlx::query!(
                "INSERT INTO ledger_entries (id, transaction_id, account_id, debit, credit, created_at) \
                 VALUES ($1, $2, $3, $4, $5, $6)",
                entry.id,
                entry.transaction_id,
                entry.account_id,
                entry.debit_minor,
                entry.credit_minor,
                entry.created_at
            )
            .execute(&mut **db_tx)
            .await?;
        }

        // Update sender account balance
        sqlx::query!(
            "UPDATE accounts SET balance_minor = $1, updated_at = NOW() WHERE id = $2",
            sender.balance_minor,
            sender.id
        )
        .execute(&mut **db_tx)
        .await?;

        // Update receiver account balance
        sqlx::query!(
            "UPDATE accounts SET balance_minor = $1, updated_at = NOW() WHERE id = $2",
            receiver.balance_minor,
            receiver.id
        )
        .execute(&mut **db_tx)
        .await?;

        Ok(())
    }
}
