use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};
use crate::accounts::ledger::TransactionType;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransactionRequest {
    pub tx_type: TransactionType,
    pub sender_account_id: Uuid,
    pub receiver_account_id: Uuid,
    pub amount_minor: i64,
    pub description: String,
    pub region_id: Option<Uuid>,
    pub related_asset_id: Option<Uuid>,
    pub related_mission_id: Option<Uuid>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransactionReceipt {
    pub transaction_id: Uuid,
    pub status: TransactionStatus,
    pub timestamp: DateTime<Utc>,
    pub error_message: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TransactionStatus {
    Success,
    Failed,
    Reversed,
}
