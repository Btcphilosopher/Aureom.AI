use thiserror::Error;
use crate::accounts::account::Account;

#[derive(Error, Debug)]
pub enum ValidationError {
    #[error("Account is frozen and cannot participate in transactions")]
    AccountFrozen,
    #[error("Insufficient funds in sender account: required {required}, found {found}")]
    InsufficientBalance { required: i64, found: i64 },
    #[error("Transaction amount must be positive")]
    NegativeOrZeroAmount,
}

pub struct TransactionValidator;

impl TransactionValidator {
    pub fn validate(sender: &Account, amount: i64) -> Result<(), ValidationError> {
        if amount <= 0 {
            return Err(ValidationError::NegativeOrZeroAmount);
        }
        if sender.is_frozen {
            return Err(ValidationError::AccountFrozen);
        }
        if !sender.allow_overdraft && sender.balance_minor < amount {
            return Err(ValidationError::InsufficientBalance {
                required: amount,
                found: sender.balance_minor,
            });
        }
        Ok(())
    }
}
