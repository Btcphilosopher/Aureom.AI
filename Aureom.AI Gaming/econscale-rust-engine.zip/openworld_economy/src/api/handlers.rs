use axum::{extract::{Path, State}, Json};
use std::sync::Arc;
use uuid::Uuid;
use serde_json::{json, Value};
use crate::core::engine::EconomicEngine;

pub async fn get_player_economy(
    Path(id): Path<Uuid>,
    State(engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    if let Some(player) = engine.world_state.players.get(&id) {
        Json(json!({
            "player_id": player.id,
            "name": player.name,
            "cash_minor": player.cash_minor,
            "bank_minor": player.bank_minor,
            "digital_minor": player.digital_minor,
            "net_worth_minor": player.cash_minor + player.bank_minor + player.digital_minor
        }))
    } else {
        Json(json!({ "error": "Player not found" }))
    }
}

pub async fn get_player_assets(
    Path(_id): Path<Uuid>,
    State(_engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    Json(json!({ "assets": [] }))
}

pub async fn get_player_transactions(
    Path(_id): Path<Uuid>,
    State(_engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    Json(json!({ "transactions": [] }))
}

pub async fn get_market_state(
    Path(id): Path<Uuid>,
    State(engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    if let Some(market) = engine.world_state.markets.get(&id) {
        Json(json!(*market))
    } else {
        Json(json!({ "error": "Market not found" }))
    }
}

pub async fn get_market_prices(
    Path(_id): Path<Uuid>,
    State(_engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    Json(json!({ "prices": [] }))
}

pub async fn get_region_economy(
    Path(id): Path<Uuid>,
    State(engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    if let Some(reg) = engine.world_state.regions.get(&id) {
        Json(json!(*reg))
    } else {
        Json(json!({ "error": "Region not found" }))
    }
}

pub async fn post_transaction(
    State(_engine): State<Arc<EconomicEngine>>,
    Json(_req): Json<Value>,
) -> Json<Value> {
    Json(json!({ "status": "Success", "transaction_id": Uuid::new_v4() }))
}

pub async fn post_purchase(
    State(_engine): State<Arc<EconomicEngine>>,
    Json(_req): Json<Value>,
) -> Json<Value> {
    Json(json!({ "status": "Success" }))
}

pub async fn post_sale(
    State(_engine): State<Arc<EconomicEngine>>,
    Json(_req): Json<Value>,
) -> Json<Value> {
    Json(json!({ "status": "Success" }))
}

pub async fn get_economy_snapshot(
    State(engine): State<Arc<EconomicEngine>>,
) -> Json<Value> {
    let total_players = engine.world_state.players.len();
    let total_npcs = engine.world_state.npcs.len();
    let total_businesses = engine.world_state.businesses.len();
    let total_markets = engine.world_state.markets.len();

    Json(json!({
        "timestamp": chrono::Utc::now(),
        "clock": engine.clock.current_time_string(),
        "players_count": total_players,
        "npcs_count": total_npcs,
        "businesses_count": total_businesses,
        "markets_count": total_markets,
        "gdp_minor_units": 842918000000i64, // sample macro metric
        "inflation_rate": 2.4,
        "unemployment_rate": 4.1
    }))
}
