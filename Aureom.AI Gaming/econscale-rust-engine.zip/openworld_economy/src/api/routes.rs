use axum::{routing::{get, post}, Router};
use std::sync::Arc;
use crate::core::engine::EconomicEngine;
use crate::api::handlers::*;

pub fn create_router(engine: Arc<EconomicEngine>) -> Router {
    Router::new()
        .route("/player/:id/economy", get(get_player_economy))
        .route("/player/:id/assets", get(get_player_assets))
        .route("/player/:id/transactions", get(get_player_transactions))
        .route("/market/:id", get(get_market_state))
        .route("/market/:id/prices", get(get_market_prices))
        .route("/region/:id/economy", get(get_region_economy))
        .route("/transaction", post(post_transaction))
        .route("/purchase", post(post_purchase))
        .route("/sale", post(post_sale))
        .route("/economy/snapshot", get(get_economy_snapshot))
        .with_state(engine)
}
