use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TransactionType {
    Purchase,
    Sale,
    Salary,
    Tax,
    Loan,
    LoanRepayment,
    Insurance,
    PropertyPurchase,
    PropertySale,
    VehiclePurchase,
    VehicleSale,
    MissionReward,
    BusinessRevenue,
    BusinessExpense,
    GovernmentSpending,
    MarketSettlement,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerEntry {
    pub id: Uuid,
    pub transaction_id: Uuid,
    pub account_id: Uuid,
    pub debit_minor: i64,  // money flowing into the account (increase asset or decrease liability)
    pub credit_minor: i64, // money flowing out of the account
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transaction {
    pub id: Uuid,
    pub tx_type: TransactionType,
    pub description: String,
    pub timestamp: DateTime<Utc>,
    pub region_id: Option<Uuid>,
    pub related_asset_id: Option<Uuid>,
    pub related_mission_id: Option<Uuid>,
}

#[derive(Error, Debug)]
pub enum LedgerError {
    #[error("Ledger entries do not balance: sum of debits ({debits}) != sum of credits ({credits})")]
    UnbalancedEntries { debits: i64, credits: i64 },
    #[error("Transaction values must be positive non-zero numbers")]
    InvalidAmounts,
    #[error("Account not found: {0}")]
    AccountNotFound(Uuid),
}

pub struct LedgerEngine;

impl LedgerEngine {
    pub fn validate_entries(entries: &[LedgerEntry]) -> Result<(), LedgerError> {
        let mut total_debit = 0i64;
        let mut total_credit = 0i64;

        for entry in entries {
            if entry.debit_minor < 0 || entry.credit_minor < 0 {
                return Err(LedgerError::InvalidAmounts);
            }
            total_debit = total_debit.checked_add(entry.debit_minor).ok_or(LedgerError::InvalidAmounts)?;
            total_credit = total_credit.checked_add(entry.credit_minor).ok_or(LedgerError::InvalidAmounts)?;
        }

        if total_debit != total_credit {
            return Err(LedgerError::UnbalancedEntries {
                debits: total_debit,
                credits: total_credit,
            });
        }

        Ok(())
    }
}
