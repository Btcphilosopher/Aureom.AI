use serde::{Serialize, Deserialize};
use uuid::Uuid;
use crate::accounts::account::{Money, MoneyError};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Wallet {
    pub owner_id: Uuid,
    pub cash_minor: i64,      // physical cash
    pub bank_minor: i64,      // bank deposits
    pub digital_minor: i64,   // virtual currencies / cards
}

impl Wallet {
    pub fn new(owner_id: Uuid, cash: i64, bank: i64) -> Self {
        Self {
            owner_id,
            cash_minor: cash,
            bank_minor: bank,
            digital_minor: 0,
        }
    }

    pub fn add_cash(&mut self, amount: i64) -> Result<(), MoneyError> {
        self.cash_minor = self.cash_minor.checked_add(amount).ok_or(MoneyError::Overflow)?;
        Ok(())
    }

    pub fn deduct_cash(&mut self, amount: i64) -> Result<(), MoneyError> {
        if self.cash_minor < amount {
            return Err(MoneyError::InsufficientFunds { required: amount, found: self.cash_minor });
        }
        self.cash_minor = self.cash_minor.checked_sub(amount).ok_or(MoneyError::Overflow)?;
        Ok(())
    }
}
