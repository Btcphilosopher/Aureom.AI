use serde::{Serialize, Deserialize};
use uuid::Uuid;
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Currency {
    USD,
    GTC, // Grand Theft Coin - Fictional crypto currency
    VND, // Vice City Dollar - Region specific
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Money {
    pub minor_units: i64, // using cents for USD, e.g. 1000 = $10.00
    pub currency: Currency,
}

#[derive(Error, Debug)]
pub enum MoneyError {
    #[error("Currency mismatch error")]
    CurrencyMismatch,
    #[error("Arithmetic overflow or underflow")]
    Overflow,
    #[error("Insufficient balance: required {required}, found {found}")]
    InsufficientFunds { required: i64, found: i64 },
}

impl Money {
    pub fn new(minor_units: i64, currency: Currency) -> Self {
        Self { minor_units, currency }
    }

    pub fn add(self, other: Self) -> Result<Self, MoneyError> {
        if self.currency != other.currency {
            return Err(MoneyError::CurrencyMismatch);
        }
        let units = self.minor_units.checked_add(other.minor_units).ok_or(MoneyError::Overflow)?;
        Ok(Self::new(units, self.currency))
    }

    pub fn subtract(self, other: Self) -> Result<Self, MoneyError> {
        if self.currency != other.currency {
            return Err(MoneyError::CurrencyMismatch);
        }
        let units = self.minor_units.checked_sub(other.minor_units).ok_or(MoneyError::Overflow)?;
        Ok(Self::new(units, self.currency))
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Account {
    pub id: Uuid,
    pub owner_id: Uuid,
    pub balance_minor: i64,
    pub currency: Currency,
    pub is_frozen: bool,
    pub allow_overdraft: bool,
}

impl Account {
    pub fn new(owner_id: Uuid, currency: Currency) -> Self {
        Self {
            id: Uuid::new_v4(),
            owner_id,
            balance_minor: 0,
            currency,
            is_frozen: false,
            allow_overdraft: false,
        }
    }

    pub fn deposit(&mut self, amount: Money) -> Result<(), MoneyError> {
        if self.is_frozen {
            return Err(MoneyError::Overflow); // placeholder for proper frozen error
        }
        if amount.currency != self.currency {
            return Err(MoneyError::CurrencyMismatch);
        }
        self.balance_minor = self.balance_minor.checked_add(amount.minor_units).ok_or(MoneyError::Overflow)?;
        Ok(())
    }

    pub fn withdraw(&mut self, amount: Money) -> Result<(), MoneyError> {
        if self.is_frozen {
            return Err(MoneyError::Overflow);
        }
        if amount.currency != self.currency {
            return Err(MoneyError::CurrencyMismatch);
        }
        if !self.allow_overdraft && self.balance_minor < amount.minor_units {
            return Err(MoneyError::InsufficientFunds {
                required: amount.minor_units,
                found: self.balance_minor,
            });
        }
        self.balance_minor = self.balance_minor.checked_sub(amount.minor_units).ok_or(MoneyError::Overflow)?;
        Ok(())
    }
}
