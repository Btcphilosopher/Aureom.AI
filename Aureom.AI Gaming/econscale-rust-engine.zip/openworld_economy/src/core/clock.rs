use std::sync::atomic::{AtomicU64, Ordering};

pub struct SimulationClock {
    ticks: AtomicU64, // counts Real-Time Ticks (each tick = 1 game minute)
}

impl SimulationClock {
    pub fn new() -> Self {
        Self {
            ticks: AtomicU64::new(0),
        }
    }

    pub fn tick(&self) {
        self.ticks.fetch_add(1, Ordering::SeqCst);
    }

    pub fn get_ticks(&self) -> u64 {
        self.ticks.load(Ordering::SeqCst)
    }

    // Converters for Timescales
    pub fn game_minutes(&self) -> u64 {
        self.get_ticks()
    }

    pub fn economic_hours(&self) -> u64 {
        self.game_minutes() / 60
    }

    pub fn accounting_days(&self) -> u64 {
        self.economic_hours() / 24
    }

    pub fn macroeconomic_months(&self) -> u64 {
        self.accounting_days() / 30
    }

    pub fn current_time_string(&self) -> String {
        let mins = self.game_minutes();
        let minute = mins % 60;
        let hour = (mins / 60) % 24;
        let day = ((mins / 1440) % 30) + 1;
        let month = (mins / 43200) + 1;
        format!("Month {}, Day {}, {:02}:{:02}", month, day, hour, minute)
    }
}
