use std::sync::Arc;
use tokio::sync::broadcast;
use uuid::Uuid;
use sqlx::{Pool, Postgres};

use crate::core::state::{WorldState, PlayerState, RegionState};
use crate::core::events::EconomicEvent;
use crate::core::clock::SimulationClock;
use crate::accounts::account::{Account, Currency};
use crate::economy::npc::Npc;
use crate::economy::business::Business;
use crate::economy::property::Property;
use crate::economy::vehicles::Vehicle;
use crate::markets::market::{Market, CommodityType};
use crate::markets::pricing::PricingEngine;

pub struct EconomicEngine {
    pub world_state: Arc<WorldState>,
    pub db_pool: Option<Pool<Postgres>>,
    pub event_tx: broadcast::Sender<EconomicEvent>,
    pub clock: Arc<SimulationClock>,
}

impl EconomicEngine {
    pub fn new(
        db_pool: Option<Pool<Postgres>>,
        event_tx: broadcast::Sender<EconomicEvent>,
        clock: Arc<SimulationClock>,
    ) -> Self {
        Self {
            world_state: Arc::new(WorldState::new()),
            db_pool,
            event_tx,
            clock,
        }
    }

    /// Seed mock AAA-grade environment data: Regions, Players, NPCs, Businesses, Properties, Vehicles, Markets.
    pub async fn populate_test_world(&self, _seed: u64) -> anyhow::Result<()> {
        // Create Regions
        let regions = vec![
            ("Downtown", 2500, 0.2, 0.8),
            ("Industrial District", 1000, 0.4, 0.9),
            ("Suburbs", 4500, 0.1, 0.4),
            ("Port", 800, 0.5, 0.7),
            ("Financial District", 1200, 0.05, 0.95),
        ];

        for (name, pop, crime, density) in regions {
            let id = Uuid::new_v4();
            self.world_state.regions.insert(id, RegionState {
                id,
                name: name.to_string(),
                population: pop,
                avg_income_minor: 400000, // $4,000.00
                crime_pressure: crime,
                business_density: density,
            });

            // For each region, insert a set of dynamic commodity markets
            let commodities = vec![
                (CommodityType::Fuel, 350),      // $3.50 base
                (CommodityType::Food, 120),      // $1.20 base
                (CommodityType::Vehicles, 4500000), // $45,000 base
                (CommodityType::Electronics, 80000), // $800 base
                (CommodityType::Property, 85000000), // $850,000 base
                (CommodityType::BlackMarketNarcotics, 15000), // $150.00
            ];

            for (comm_type, base_price) in commodities {
                let market = Market::new(id, format!("{} Market - {}", name, name), comm_type, base_price);
                self.world_state.markets.insert(market.id, market);
            }
        }

        // Add standard Player
        let player_id = Uuid::new_v4();
        self.world_state.players.insert(player_id, PlayerState {
            id: player_id,
            name: "Michael De Santa".to_string(),
            cash_minor: 500000, // $5,000 cash
            bank_minor: 12500000, // $125,000 bank
            digital_minor: 0,
        });

        // Seed 10 sample NPCs
        for i in 1..=10 {
            let acct = Account::new(Uuid::new_v4(), Currency::USD);
            let acct_id = acct.id;
            self.world_state.accounts.insert(acct_id, acct);

            let npc = Npc::new(
                format!("NPC Citizen #{}", i),
                "Clerk".to_string(),
                300000, // $3,000/month salary
                acct_id,
            );
            self.world_state.npcs.insert(npc.id, npc);
        }

        Ok(())
    }

    /// Single simulation step, called on background ticker
    pub async fn step_simulation(&self) -> anyhow::Result<()> {
        let mins = self.clock.game_minutes();
        
        // Every simulated hour (60 game minutes)
        if mins % 60 == 0 {
            self.discover_all_prices().await?;
        }

        // Every simulated day (1440 game minutes / 24 hours)
        if mins % 1440 == 0 {
            self.process_daily_settlements().await?;
        }

        Ok(())
    }

    /// Price discovery round for all dynamic markets
    pub async fn discover_all_prices(&self) -> anyhow::Result<()> {
        for mut market_ref in self.world_state.markets.iter_mut() {
            let market = market_ref.value_mut();
            
            // Generate some dynamic supply and demand adjustments (simulate game activity)
            // In a real AAA server, this is driven by active player and NPC buy/sell orders.
            market.demand += rand::random::<f64>() * 4.0 - 1.8;
            market.supply += rand::random::<f64>() * 4.0 - 2.0;

            market.demand = market.demand.clamp(10.0, 500.0);
            market.supply = market.supply.clamp(10.0, 500.0);

            // Compute dynamic price discovery
            market.price_minor = PricingEngine::discover_price(market, 1.0, 1.0, 1.0);
        }
        Ok(())
    }

    /// Daily settlement loop (Rent, Salaries, Wages, Depreciation)
    pub async fn process_daily_settlements(&self) -> anyhow::Result<()> {
        // Step NPCs budgets
        for mut npc_ref in self.world_state.npcs.iter_mut() {
            let npc = npc_ref.value_mut();
            let _outflows = npc.process_daily_budget();
            
            if let Some(mut acct) = self.world_state.accounts.get_mut(&npc.savings_account_id) {
                acct.balance_minor = npc.wallet_cash_minor;
            }
        }

        // Apply vehicle depreciation
        for mut vehicle_ref in self.world_state.vehicles.iter_mut() {
            let vehicle = vehicle_ref.value_mut();
            vehicle.tick_depreciation();
        }

        Ok(())
    }
}
