use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};
use crate::accounts::ledger::TransactionType;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum EconomicEvent {
    TransactionCompleted {
        tx_id: Uuid,
        tx_type: TransactionType,
        actor_id: Uuid,
        counterparty_id: Uuid,
        minor_units: i64,
        currency: String,
        timestamp: DateTime<Utc>,
    },
    BalanceUpdated {
        account_id: Uuid,
        old_balance: i64,
        new_balance: i64,
    },
    InventoryUpdated {
        owner_id: Uuid,
        item_id: Uuid,
        quantity_change: i64,
        new_quantity: u64,
    },
    MarketUpdated {
        market_id: Uuid,
        supply: f64,
        demand: f64,
        volume: u64,
    },
    PriceUpdated {
        commodity_id: Uuid,
        old_price_minor: i64,
        new_price_minor: i64,
        region_id: Uuid,
    },
    MarketShock {
        event_name: String,
        affected_commodities: Vec<Uuid>,
        supply_multiplier: f64,
        demand_multiplier: f64,
    },
    EconomicMetricsUpdated {
        timestamp: DateTime<Utc>,
        gdp_minor_units: i64,
        inflation_rate: f64,
        unemployment_rate: f64,
        money_supply_minor: i64,
    },
}
