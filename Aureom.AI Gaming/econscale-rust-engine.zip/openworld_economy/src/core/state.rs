use std::sync::Arc;
use dashmap::DashMap;
use uuid::Uuid;
use crate::accounts::account::Account;
use crate::economy::npc::Npc;
use crate::economy::business::Business;
use crate::economy::property::Property;
use crate::economy::vehicles::Vehicle;
use crate::markets::market::Market;
use crate::inventory::inventory::Inventory;

pub struct WorldState {
    pub players: DashMap<Uuid, PlayerState>,
    pub npcs: DashMap<Uuid, Npc>,
    pub accounts: DashMap<Uuid, Account>,
    pub businesses: DashMap<Uuid, Business>,
    pub properties: DashMap<Uuid, Property>,
    pub vehicles: DashMap<Uuid, Vehicle>,
    pub markets: DashMap<Uuid, Market>,
    pub inventories: DashMap<Uuid, Inventory>,
    pub regions: DashMap<Uuid, RegionState>,
}

#[derive(Clone, Debug)]
pub struct PlayerState {
    pub id: Uuid,
    pub name: String,
    pub cash_minor: i64,
    pub bank_minor: i64,
    pub digital_minor: i64,
}

#[derive(Clone, Debug)]
pub struct RegionState {
    pub id: Uuid,
    pub name: String,
    pub population: u32,
    pub avg_income_minor: i64,
    pub crime_pressure: f64, // 0.0 - 1.0
    pub business_density: f64,
}

impl WorldState {
    pub fn new() -> Self {
        Self {
            players: DashMap::new(),
            npcs: DashMap::new(),
            accounts: DashMap::new(),
            businesses: DashMap::new(),
            properties: DashMap::new(),
            vehicles: DashMap::new(),
            markets: DashMap::new(),
            inventories: DashMap::new(),
            regions: DashMap::new(),
        }
    }
}
