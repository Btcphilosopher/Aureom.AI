use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Market {
    pub id: Uuid,
    pub name: String,
    pub region_id: Uuid,
    pub commodity_type: CommodityType,
    pub supply: f64,
    pub demand: f64,
    pub price_minor: i64,
    pub base_price_minor: i64,
    pub price_volatility: f64,
    pub transaction_volume: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum CommodityType {
    Fuel,
    Food,
    Vehicles,
    Electronics,
    Clothing,
    Construction,
    Property,
    LuxuryGoods,
    IndustrialGoods,
    Services,
    BlackMarketNarcotics,
    BlackMarketWeapons,
}

impl Market {
    pub fn new(region_id: Uuid, name: String, commodity_type: CommodityType, base_price: i64) -> Self {
        Self {
            id: Uuid::new_v4(),
            name,
            region_id,
            commodity_type,
            supply: 100.0,
            demand: 100.0,
            price_minor: base_price,
            base_price_minor: base_price,
            price_volatility: 0.05,
            transaction_volume: 0,
        }
    }
}
