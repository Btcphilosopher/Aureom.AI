use crate::markets::market::Market;

pub struct PricingEngine;

impl PricingEngine {
    /// Calculate the new price for a market based on the formula:
    /// Price(t+1) = Price(t) * Demand Factor * Supply Factor * Scarcity Factor * Regional Factor * Event Factor
    pub fn discover_price(
        market: &Market,
        scarcity_factor: f64,
        regional_factor: f64,
        event_factor: f64,
    ) -> i64 {
        let demand_factor = if market.demand > 0.0 {
            (market.demand / 100.0).clamp(0.1, 5.0)
        } else {
            0.1
        };

        let supply_factor = if market.supply > 0.0 {
            (100.0 / market.supply).clamp(0.1, 5.0)
        } else {
            5.0
        };

        // Combine multipliers
        let multiplier = demand_factor * supply_factor * scarcity_factor * regional_factor * event_factor;

        let current_price = market.price_minor as f64;
        let mut new_price = current_price * multiplier;

        // Clamp to prevent complete zero or hyper-inflation in a single tick
        let min_price = (market.base_price_minor as f64 * 0.1) as i64;
        let max_price = (market.base_price_minor as f64 * 10.0) as i64;

        (new_price.round() as i64).clamp(min_price, max_price)
    }
}
