use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SupplyNode {
    pub id: Uuid,
    pub name: String,
    pub node_type: NodeType,
    pub output_commodity: crate::markets::market::CommodityType,
    pub input_commodities: Vec<crate::markets::market::CommodityType>,
    pub production_cost_minor: i64,
    pub transport_cost_minor: i64,
    pub wholesale_price_minor: i64,
    pub retail_price_minor: i64,
    pub inventory_qty: u64,
    pub lead_time_ticks: u32,
    pub disruption_level: f64, // 0.0 (no disruption) to 1.0 (fully blocked)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NodeType {
    RawProducer,
    Manufacturer,
    Distributor,
    Retailer,
}

impl SupplyNode {
    pub fn process_production_tick(&mut self) {
        if self.disruption_level >= 1.0 {
            return; // completely disrupted
        }

        // Production output scales down based on disruption level
        let efficiency = 1.0 - self.disruption_level;
        let batch_size = (10.0 * efficiency) as u64;

        self.inventory_qty += batch_size;
    }
}
