use serde::{Serialize, Deserialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MarketOrder {
    pub id: Uuid,
    pub market_id: Uuid,
    pub trader_id: Uuid,
    pub order_type: OrderType,
    pub quantity: u64,
    pub limit_price_minor: Option<i64>, // None means market order
    pub is_filled: bool,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OrderType {
    Buy,
    Sell,
}
