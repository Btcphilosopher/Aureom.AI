use crate::markets::market::CommodityType;

pub struct DemandEngine;

impl DemandEngine {
    /// Calculate elasticity: demand_change = -price_elasticity * percentage_price_change
    pub fn calculate_demand_change(
        commodity: CommodityType,
        pct_price_change: f64,
    ) -> f64 {
        let elasticity = match commodity {
            CommodityType::Food => 0.2,            // inelastic (necessity)
            CommodityType::Fuel => 0.4,            // inelastic
            CommodityType::Services => 0.8,        // moderate
            CommodityType::Electronics => 1.2,     // elastic (luxury-adjacent)
            CommodityType::Clothing => 0.9,        // moderate
            CommodityType::Construction => 0.6,    // corporate demand
            CommodityType::Property => 1.1,        // speculative/elastic
            CommodityType::Vehicles => 1.5,        // highly elastic
            CommodityType::LuxuryGoods => 2.0,     // extremely elastic
            CommodityType::IndustrialGoods => 0.7, // business demand
            CommodityType::BlackMarketNarcotics => 0.1, // extremely inelastic
            CommodityType::BlackMarketWeapons => 0.3,   // inelastic due to risk
        };

        // Demand change = -elasticity * % price change
        -elasticity * pct_price_change
    }
}
