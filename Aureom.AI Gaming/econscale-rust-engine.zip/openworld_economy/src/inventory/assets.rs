use serde::{Serialize, Deserialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AssetClass {
    RealEstate,
    Equipment,
    CorporateEquity,
    IntellectualProperty,
    FictionalSecurities,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CorporateAsset {
    pub id: Uuid,
    pub name: String,
    pub asset_class: AssetClass,
    pub book_value_minor: i64,
    pub market_value_minor: i64,
}
