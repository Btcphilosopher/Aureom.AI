use serde::{Serialize, Deserialize};
use uuid::Uuid;
use thiserror::Error;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Inventory {
    pub owner_id: Uuid,
    pub items: Vec<InventoryItem>,
    pub max_capacity: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InventoryItem {
    pub id: Uuid,
    pub name: String,
    pub quantity: u64,
    pub average_cost_minor: i64,
}

#[derive(Error, Debug)]
pub enum InventoryError {
    #[error("Inventory is full")]
    CapacityExceeded,
    #[error("Item not found: {0}")]
    ItemNotFound(String),
    #[error("Insufficient quantity: requested {required}, found {found}")]
    InsufficientQuantity { required: u64, found: u64 },
}

impl Inventory {
    pub fn new(owner_id: Uuid, max_capacity: u64) -> Self {
        Self {
            owner_id,
            items: Vec::new(),
            max_capacity,
        }
    }

    pub fn add_item(&mut self, name: &str, qty: u64, cost_minor: i64) -> Result<(), InventoryError> {
        let current_total: u64 = self.items.iter().map(|i| i.quantity).sum();
        if current_total + qty > self.max_capacity {
            return Err(InventoryError::CapacityExceeded);
        }

        if let Some(item) = self.items.iter_mut().find(|i| i.name == name) {
            let old_total_cost = item.quantity as i64 * item.average_cost_minor;
            let new_total_cost = qty as i64 * cost_minor;
            item.quantity += qty;
            item.average_cost_minor = (old_total_cost + new_total_cost) / item.quantity as i64;
        } else {
            self.items.push(InventoryItem {
                id: Uuid::new_v4(),
                name: name.to_string(),
                quantity: qty,
                average_cost_minor: cost_minor,
            });
        }
        Ok(())
    }

    pub fn remove_item(&mut self, name: &str, qty: u64) -> Result<(), InventoryError> {
        if let Some(pos) = self.items.iter().position(|i| i.name == name) {
            let item = &mut self.items[pos];
            if item.quantity < qty {
                return Err(InventoryError::InsufficientQuantity {
                    required: qty,
                    found: item.quantity,
                });
            }
            item.quantity -= qty;
            if item.quantity == 0 {
                self.items.remove(pos);
            }
            Ok(())
        } else {
            Err(InventoryError::ItemNotFound(name.to_string()))
        }
    }
}
