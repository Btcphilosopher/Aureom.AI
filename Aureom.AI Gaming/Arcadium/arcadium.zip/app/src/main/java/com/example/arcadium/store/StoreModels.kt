package com.example.arcadium.store

import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.downloads.DownloadManager
import com.example.arcadium.games.GameCatalogService
import com.example.arcadium.games.InstallationStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

enum class ProductCategory {
    FULL_GAME,
    EXPANSION_DLC,
    SOUNDTRACK,
    CUSTOM_THEME
}

data class StoreProduct(
    val productId: String,
    val gameId: String,
    val title: String,
    val publisher: String,
    val category: ProductCategory,
    val priceGbp: Double,
    val discountPercent: Int = 0,
    val rating: Float = 4.9f,
    val totalReviews: Int = 4280,
    val sizeBytes: Long,
    val description: String,
    val isPurchased: Boolean = false
) {
    val effectivePrice: Double
        get() = if (discountPercent > 0) priceGbp * (1.0 - (discountPercent / 100.0)) else priceGbp
}

data class LicenseEntitlement(
    val entitlementId: String,
    val productId: String,
    val userId: String,
    val grantedTimestamp: Long = System.currentTimeMillis(),
    val digitalSignature: String = "SIG-ARC-RSA4096-VERIFIED"
)

class StoreService(
    private val catalogService: GameCatalogService,
    private val downloadManager: DownloadManager
) : ArcadiumService {

    override val serviceName: String = "ArcadiumStoreService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val products = ConcurrentHashMap<String, StoreProduct>()
    private val entitlements = ConcurrentHashMap<String, LicenseEntitlement>()

    private val _storeProducts = MutableStateFlow<List<StoreProduct>>(emptyList())
    val storeProducts: StateFlow<List<StoreProduct>> = _storeProducts.asStateFlow()

    init {
        val p1 = StoreProduct(
            productId = "prod_albion_full",
            gameId = "game_cybernetic_albion",
            title = "Cybernetic Albion: 2088 (Standard Edition)",
            publisher = "Arcadium Studios",
            category = ProductCategory.FULL_GAME,
            priceGbp = 69.99,
            discountPercent = 0,
            rating = 4.9f,
            totalReviews = 18400,
            sizeBytes = 68L * 1024 * 1024 * 1024,
            description = "Experience the definitive neo-London dystopian tactical adventure in native 4K 120 FPS.",
            isPurchased = true
        )
        val p2 = StoreProduct(
            productId = "prod_vortex_vector",
            gameId = "game_vortex_vector",
            title = "Vortex Vector: Velocity Edition",
            publisher = "Arcadium Digital",
            category = ProductCategory.FULL_GAME,
            priceGbp = 54.99,
            discountPercent = 15,
            rating = 4.8f,
            totalReviews = 9200,
            sizeBytes = 42L * 1024 * 1024 * 1024,
            description = "High speed anti-grav racing featuring 32 dynamic atmospheric tracks.",
            isPurchased = true
        )
        val p3 = StoreProduct(
            productId = "prod_neon_specter",
            gameId = "game_neon_specter",
            title = "Neon Specter",
            publisher = "Arcadium Digital",
            category = ProductCategory.FULL_GAME,
            priceGbp = 49.99,
            discountPercent = 20,
            rating = 4.7f,
            totalReviews = 6300,
            sizeBytes = 54L * 1024 * 1024 * 1024,
            description = "Quantum infiltration stealth thriller with time-warp rewind abilities.",
            isPurchased = false
        )
        val p4 = StoreProduct(
            productId = "prod_albion_dlc_sub",
            gameId = "game_cybernetic_albion",
            title = "Thames Sub-Level Expansion",
            publisher = "Arcadium Studios",
            category = ProductCategory.EXPANSION_DLC,
            priceGbp = 19.99,
            discountPercent = 0,
            rating = 5.0f,
            totalReviews = 3100,
            sizeBytes = 14L * 1024 * 1024 * 1024,
            description = "Explore the subterranean submerged ruins of the Thames flooded metro line with 6 new story operations.",
            isPurchased = true
        )
        val p5 = StoreProduct(
            productId = "prod_ost_albion",
            gameId = "game_cybernetic_albion",
            title = "Cybernetic Albion: Original Orchestral & Synth Soundtrack (Lossless FLAC)",
            publisher = "London Philharmonic & Arcadium Soundworks",
            category = ProductCategory.SOUNDTRACK,
            priceGbp = 12.99,
            discountPercent = 0,
            rating = 4.9f,
            totalReviews = 1200,
            sizeBytes = 1200L * 1024 * 1024,
            description = "Recorded live at Abbey Road Studios, London.",
            isPurchased = false
        )

        listOf(p1, p2, p3, p4, p5).forEach { products[it.productId] = it }
        _storeProducts.value = products.values.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun purchaseProduct(productId: String, userId: String): Boolean {
        val prod = products[productId] ?: return false
        val updated = prod.copy(isPurchased = true)
        products[productId] = updated
        _storeProducts.value = products.values.toList()

        val ent = LicenseEntitlement(
            entitlementId = "ent_${System.currentTimeMillis()}",
            productId = productId,
            userId = userId
        )
        entitlements[productId] = ent

        // If product is a game, trigger download
        if (prod.category == ProductCategory.FULL_GAME) {
            catalogService.updateGameStatus(prod.gameId, InstallationStatus.DOWNLOADING, 0f)
            downloadManager.enqueueDownload(prod.gameId, prod.title, prod.sizeBytes, "Game")
        }
        return true
    }

    fun hasEntitlement(productId: String): Boolean {
        return products[productId]?.isPurchased == true
    }
}
