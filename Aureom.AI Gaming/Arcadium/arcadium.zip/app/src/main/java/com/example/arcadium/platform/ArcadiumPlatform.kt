package com.example.arcadium.platform

import com.example.arcadium.achievements.AchievementManager
import com.example.arcadium.controller.InputManager
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ServiceRegistry
import com.example.arcadium.core.SystemDiagnostics
import com.example.arcadium.demo.CyberneticAlbionDemoGame
import com.example.arcadium.downloads.DownloadManager
import com.example.arcadium.downloads.UpdateManager
import com.example.arcadium.games.GameCatalogService
import com.example.arcadium.games.GameLauncher
import com.example.arcadium.media.MediaService
import com.example.arcadium.nativebridge.MockNativeBridge
import com.example.arcadium.network.MultiplayerService
import com.example.arcadium.network.NetworkService
import com.example.arcadium.notifications.NotificationService
import com.example.arcadium.sdk.Arcadium
import com.example.arcadium.settings.SettingsManager
import com.example.arcadium.social.FriendsService
import com.example.arcadium.storage.ArcadiumStorageService
import com.example.arcadium.storage.SandboxManager
import com.example.arcadium.storage.SaveDataManager
import com.example.arcadium.store.StoreService
import com.example.arcadium.telemetry.TelemetryService
import com.example.arcadium.user.AccountManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * The unified system runtime bootstrap and environment orchestrator for the ARCADIUM console.
 */
class ArcadiumPlatform private constructor(
    val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    val eventBus = ArcadiumEventBus(scope)
    val diagnostics = SystemDiagnostics()
    val nativeBridge = MockNativeBridge()
    val registry = ServiceRegistry()

    // System Services
    val accountManager = AccountManager(eventBus)
    val storageService = ArcadiumStorageService(nativeBridge, eventBus)
    val saveDataManager = SaveDataManager(storageService, eventBus)
    val sandboxManager = SandboxManager(eventBus)
    val inputManager = InputManager(nativeBridge, eventBus, scope)
    val catalogService = GameCatalogService()
    val gameLauncher = GameLauncher(catalogService, accountManager, storageService, saveDataManager, sandboxManager, inputManager, eventBus, scope)
    val downloadManager = DownloadManager(catalogService, eventBus, scope)
    val updateManager = UpdateManager(eventBus)
    val networkService = NetworkService(nativeBridge, eventBus)
    val multiplayerService = MultiplayerService(networkService, eventBus)
    val friendsService = FriendsService(eventBus)
    val achievementManager = AchievementManager(accountManager, eventBus)
    val notificationService = NotificationService(eventBus, scope)
    val storeService = StoreService(catalogService, downloadManager)
    val mediaService = MediaService(eventBus)
    val settingsManager = SettingsManager(nativeBridge)
    val telemetryService = TelemetryService(nativeBridge, eventBus, scope)

    // Demo Game
    val demoGame = CyberneticAlbionDemoGame(scope)

    init {
        // Register all services in dependency order
        scope.launch {
            registry.register(storageService)
            registry.register(sandboxManager)
            registry.register(saveDataManager)
            registry.register(accountManager)
            registry.register(inputManager)
            registry.register(catalogService)
            registry.register(gameLauncher)
            registry.register(downloadManager)
            registry.register(updateManager)
            registry.register(networkService)
            registry.register(multiplayerService)
            registry.register(friendsService)
            registry.register(achievementManager)
            registry.register(notificationService)
            registry.register(storeService)
            registry.register(mediaService)
            registry.register(settingsManager)
            registry.register(telemetryService)

            // Start all services
            registry.startAll()

            diagnostics.info("ArcadiumPlatform", "ArcOS Core Kernel and all 18 Kotlin System Services booted successfully.")
        }

        // Initialize Developer SDK
        Arcadium.initialize(
            accountManager = accountManager,
            inputManager = inputManager,
            storageService = storageService,
            saveDataManager = saveDataManager,
            sandboxManager = sandboxManager,
            achievementManager = achievementManager,
            notificationService = notificationService,
            multiplayerService = multiplayerService,
            networkService = networkService,
            mediaService = mediaService,
            telemetryService = telemetryService,
            gameLauncher = gameLauncher
        )
    }

    companion object {
        @Volatile
        private var instance: ArcadiumPlatform? = null

        fun getInstance(): ArcadiumPlatform {
            return instance ?: synchronized(this) {
                instance ?: ArcadiumPlatform().also { instance = it }
            }
        }
    }
}
