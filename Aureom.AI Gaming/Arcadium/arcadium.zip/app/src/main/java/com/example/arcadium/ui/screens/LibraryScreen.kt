package com.example.arcadium.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.games.GameManifest
import com.example.arcadium.games.InstallationStatus
import com.example.arcadium.platform.ArcadiumPlatform
import com.example.arcadium.ui.components.ArcadiumButton
import com.example.arcadium.ui.components.ArcadiumProgressBar
import com.example.arcadium.ui.components.BadgePill
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCrimson
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurface
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary
import kotlinx.coroutines.launch

@Composable
fun LibraryScreen(
    platform: ArcadiumPlatform,
    onNavigateToGameRunner: () -> Unit
) {
    val games by platform.catalogService.gamesList.collectAsState()
    val activeSession by platform.gameLauncher.activeSession.collectAsState()
    val pipelineStep by platform.gameLauncher.launchPipelineStep.collectAsState()
    val activeUser by platform.accountManager.activeUser.collectAsState()
    val scope = rememberCoroutineScope()

    val featuredGame = games.find { it.gameId == "game_cybernetic_albion" } ?: games.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Launch Pipeline Status Banner (if active)
        if (pipelineStep != "Idle") {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, ArcadiumCyan, RoundedCornerShape(8.dp)),
                    color = ArcadiumSurfaceElevated
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(ArcadiumCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LAUNCH PIPELINE: $pipelineStep",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArcadiumCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Hero Featured Game Banner
        if (featuredGame != null) {
            item {
                FeaturedGameCard(
                    game = featuredGame,
                    isRunning = activeSession?.game?.gameId == featuredGame.gameId,
                    onLaunch = {
                        scope.launch {
                            val user = activeUser?.userId ?: "usr_tom_001"
                            platform.gameLauncher.launch(featuredGame.gameId, user)
                            platform.demoGame.startDemoGame()
                            onNavigateToGameRunner()
                        }
                    },
                    onTerminate = {
                        scope.launch {
                            platform.gameLauncher.terminateGame(featuredGame.gameId)
                            platform.demoGame.stopDemoGame()
                        }
                    }
                )
            }
        }

        // Game Catalog Shelf Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SANDBOXED TITLES (${games.size})",
                    style = MaterialTheme.typography.labelLarge,
                    color = ArcadiumTextPrimary,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "DIRECTSTORAGE NVME",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArcadiumCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }
        }

        // Game Catalog Items
        items(games) { game ->
            val isRunning = activeSession?.game?.gameId == game.gameId
            GameCatalogRow(
                game = game,
                isRunning = isRunning,
                onPlay = {
                    scope.launch {
                        val user = activeUser?.userId ?: "usr_tom_001"
                        platform.gameLauncher.launch(game.gameId, user)
                        if (game.gameId == "game_cybernetic_albion") {
                            platform.demoGame.startDemoGame()
                        }
                        onNavigateToGameRunner()
                    }
                },
                onInstall = {
                    platform.downloadManager.enqueueDownload(game.gameId, game.title, game.sizeBytes, "Game")
                }
            )
        }
    }
}

@Composable
fun FeaturedGameCard(
    game: GameManifest,
    isRunning: Boolean,
    onLaunch: () -> Unit,
    onTerminate: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, ArcadiumBorderSubtle, RoundedCornerShape(14.dp)),
        color = Color.Transparent
    ) {
        Column(
            modifier = Modifier.background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF121214),
                        Color(0xFF0A0A0B)
                    )
                )
            )
        ) {
            // Simulated Artwork banner container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF1E293B),
                                Color(0xFF0D0D0F)
                            )
                        )
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "FLAGSHIP RUNTIME",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArcadiumCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BadgePill("4K 120FPS", ArcadiumEmerald)
                            BadgePill("RAY TRACING", ArcadiumCyan)
                        }
                    }

                    Column {
                        Text(
                            text = game.title,
                            style = MaterialTheme.typography.headlineMedium,
                            color = ArcadiumTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${game.studio} • ${game.publisher}",
                            style = MaterialTheme.typography.bodySmall,
                            color = ArcadiumTextSecondary
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = game.synopsis,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArcadiumTextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Size: ${(game.sizeBytes / (1024 * 1024 * 1024))} GB • ${game.version}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = ArcadiumTextMuted
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (isRunning) {
                            ArcadiumButton(
                                text = "TERMINATE",
                                onClick = onTerminate,
                                isPrimary = false,
                                accentColor = ArcadiumCrimson,
                                icon = Icons.Default.Stop
                            )
                            ArcadiumButton(
                                text = "RUNNING",
                                onClick = onLaunch,
                                isPrimary = true,
                                accentColor = ArcadiumEmerald,
                                icon = Icons.Default.PlayArrow
                            )
                        } else {
                            ArcadiumButton(
                                text = "LAUNCH",
                                onClick = onLaunch,
                                isPrimary = true,
                                accentColor = ArcadiumCyan,
                                icon = Icons.Default.PlayArrow
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GameCatalogRow(
    game: GameManifest,
    isRunning: Boolean,
    onPlay: () -> Unit,
    onInstall: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(
                1.dp,
                if (isRunning) ArcadiumCyan else ArcadiumBorder,
                RoundedCornerShape(8.dp)
            ),
        color = ArcadiumSurfaceCard
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = game.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = ArcadiumTextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (isRunning) {
                        BadgePill("ACTIVE", ArcadiumEmerald)
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${game.genre} • ${(game.sizeBytes / (1024 * 1024 * 1024))} GB",
                    style = MaterialTheme.typography.bodySmall,
                    color = ArcadiumTextSecondary
                )
                if (game.installationStatus == InstallationStatus.DOWNLOADING) {
                    Spacer(modifier = Modifier.height(6.dp))
                    ArcadiumProgressBar(progress = game.downloadProgressPercent / 100f, color = ArcadiumCyan)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            when (game.installationStatus) {
                InstallationStatus.PLAYABLE, InstallationStatus.INSTALLED -> {
                    ArcadiumButton(
                        text = if (isRunning) "SESSION" else "PLAY",
                        onClick = onPlay,
                        isPrimary = isRunning,
                        accentColor = if (isRunning) ArcadiumEmerald else ArcadiumCyan
                    )
                }
                InstallationStatus.DOWNLOADING -> {
                    Text(
                        text = "INSTALLING...",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumCyan,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                InstallationStatus.NOT_INSTALLED -> {
                    ArcadiumButton(
                        text = "INSTALL",
                        onClick = onInstall,
                        isPrimary = false,
                        icon = Icons.Default.Download
                    )
                }
                else -> {}
            }
        }
    }
}
