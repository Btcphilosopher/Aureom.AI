package com.example.arcadium.user

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

enum class AccountType {
    LOCAL,
    ARCADIUM_ONLINE,
    GUEST,
    DEVELOPER
}

data class UserPreferences(
    val language: String = "en-GB",
    val autoSignIn: Boolean = true,
    val themeAccent: String = "AmberGold", // British industrial accent
    val hapticIntensity: Float = 0.85f,
    val invertedYAxis: Boolean = false,
    val privacyOnlineVisibility: Boolean = true
)

data class UserPlayStats(
    val totalGamesPlayed: Int = 14,
    val totalPlayTimeMinutes: Long = 4280,
    val unlockedAchievementsCount: Int = 67,
    val totalGamerScore: Int = 1850,
    val favoriteGenre: String = "Sci-Fi Action / Sim"
)

data class UserProfile(
    val userId: String,
    val username: String,
    val displayName: String,
    val email: String? = null,
    val avatarRes: String = "avatar_commander",
    val accountType: AccountType = AccountType.LOCAL,
    val gamerScore: Int = 1850,
    val level: Int = 24,
    val preferences: UserPreferences = UserPreferences(),
    val stats: UserPlayStats = UserPlayStats(),
    val isOnline: Boolean = true
)

class AccountManager(
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "UserAccountService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val profiles = ConcurrentHashMap<String, UserProfile>()
    private val _activeUser = MutableStateFlow<UserProfile?>(null)
    val activeUser: StateFlow<UserProfile?> = _activeUser.asStateFlow()

    private val _allUsers = MutableStateFlow<List<UserProfile>>(emptyList())
    val allUsers: StateFlow<List<UserProfile>> = _allUsers.asStateFlow()

    init {
        // Create initial default console profiles
        val primaryUser = UserProfile(
            userId = "usr_tom_001",
            username = "TomVanguard",
            displayName = "Tom",
            email = "tom@ahyx.org",
            avatarRes = "avatar_tom",
            accountType = AccountType.DEVELOPER,
            gamerScore = 2450,
            level = 32,
            stats = UserPlayStats(
                totalGamesPlayed = 18,
                totalPlayTimeMinutes = 8940,
                unlockedAchievementsCount = 112,
                totalGamerScore = 2450,
                favoriteGenre = "Tactical Sci-Fi"
            )
        )

        val secondaryUser = UserProfile(
            userId = "usr_elena_002",
            username = "ElenaPulse",
            displayName = "Elena",
            email = "elena.pulse@arcadium.io",
            avatarRes = "avatar_elena",
            accountType = AccountType.ARCADIUM_ONLINE,
            gamerScore = 1820,
            level = 21
        )

        val guestUser = UserProfile(
            userId = "usr_guest_003",
            username = "ArcadiumGuest",
            displayName = "Guest 1",
            avatarRes = "avatar_guest",
            accountType = AccountType.GUEST,
            gamerScore = 0,
            level = 1
        )

        profiles[primaryUser.userId] = primaryUser
        profiles[secondaryUser.userId] = secondaryUser
        profiles[guestUser.userId] = guestUser
        _allUsers.value = profiles.values.toList()
        _activeUser.value = primaryUser
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
        _activeUser.value?.let {
            eventBus.post(ArcadiumEvent.UserSignedIn(it.userId, it.displayName))
        }
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        _activeUser.value?.let {
            eventBus.post(ArcadiumEvent.UserSignedOut(it.userId))
        }
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun getActiveProfile(): UserProfile? = _activeUser.value

    fun switchUser(userId: String): Boolean {
        val target = profiles[userId] ?: return false
        val prev = _activeUser.value?.userId
        _activeUser.value = target
        eventBus.post(ArcadiumEvent.UserProfileSwitched(prev, target.userId))
        return true
    }

    fun createProfile(
        username: String,
        displayName: String,
        accountType: AccountType,
        email: String? = null
    ): UserProfile {
        val newId = "usr_${System.currentTimeMillis().toString().takeLast(6)}"
        val profile = UserProfile(
            userId = newId,
            username = username,
            displayName = displayName,
            email = email,
            accountType = accountType,
            gamerScore = 0,
            level = 1
        )
        profiles[newId] = profile
        _allUsers.value = profiles.values.toList()
        return profile
    }

    fun updateGamerScore(userId: String, deltaPoints: Int) {
        val p = profiles[userId] ?: return
        val updated = p.copy(
            gamerScore = p.gamerScore + deltaPoints,
            level = (p.gamerScore + deltaPoints) / 80 + 1,
            stats = p.stats.copy(
                totalGamerScore = p.stats.totalGamerScore + deltaPoints,
                unlockedAchievementsCount = p.stats.unlockedAchievementsCount + 1
            )
        )
        profiles[userId] = updated
        _allUsers.value = profiles.values.toList()
        if (_activeUser.value?.userId == userId) {
            _activeUser.value = updated
        }
    }

    fun recordPlaySession(userId: String, minutesPlayed: Long) {
        val p = profiles[userId] ?: return
        val updated = p.copy(
            stats = p.stats.copy(
                totalPlayTimeMinutes = p.stats.totalPlayTimeMinutes + minutesPlayed
            )
        )
        profiles[userId] = updated
        _allUsers.value = profiles.values.toList()
        if (_activeUser.value?.userId == userId) {
            _activeUser.value = updated
        }
    }
}
