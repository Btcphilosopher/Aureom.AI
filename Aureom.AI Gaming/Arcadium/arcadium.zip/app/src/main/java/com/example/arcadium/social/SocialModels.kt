package com.example.arcadium.social

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

enum class PresenceState {
    ONLINE,
    AWAY,
    PLAYING,
    DO_NOT_DISTURB,
    OFFLINE
}

data class Friend(
    val userId: String,
    val username: String,
    val displayName: String,
    val avatarRes: String,
    val gamerScore: Int,
    val presence: PresenceState = PresenceState.ONLINE,
    val currentlyPlaying: String? = null,
    val partySize: Int = 1,
    val isFavorite: Boolean = false
)

data class DirectMessage(
    val messageId: String,
    val senderUserId: String,
    val senderDisplayName: String,
    val recipientUserId: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class GameInvitation(
    val invitationId: String,
    val senderUserId: String,
    val senderDisplayName: String,
    val targetGameId: String,
    val targetGameTitle: String,
    val lobbyId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isAccepted: Boolean = false
)

class FriendsService(
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "ArcadiumSocialService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val friends = ConcurrentHashMap<String, Friend>()
    private val messages = CopyOnWriteArrayList<DirectMessage>()
    private val invitations = CopyOnWriteArrayList<GameInvitation>()

    private val _friendsList = MutableStateFlow<List<Friend>>(emptyList())
    val friendsList: StateFlow<List<Friend>> = _friendsList.asStateFlow()

    private val _messagesList = MutableStateFlow<List<DirectMessage>>(emptyList())
    val messagesList: StateFlow<List<DirectMessage>> = _messagesList.asStateFlow()

    private val _invitationsList = MutableStateFlow<List<GameInvitation>>(emptyList())
    val invitationsList: StateFlow<List<GameInvitation>> = _invitationsList.asStateFlow()

    init {
        // Seed initial friend roster
        val friend1 = Friend(
            userId = "usr_elena_002",
            username = "ElenaPulse",
            displayName = "Elena",
            avatarRes = "avatar_elena",
            gamerScore = 1820,
            presence = PresenceState.PLAYING,
            currentlyPlaying = "Cybernetic Albion: 2088",
            partySize = 3,
            isFavorite = true
        )
        val friend2 = Friend(
            userId = "usr_marcus_04",
            username = "MarcusVector",
            displayName = "Marcus",
            avatarRes = "avatar_marcus",
            gamerScore = 3100,
            presence = PresenceState.PLAYING,
            currentlyPlaying = "Vortex Vector",
            partySize = 2,
            isFavorite = true
        )
        val friend3 = Friend(
            userId = "usr_sophie_07",
            username = "SophieStealth",
            displayName = "Sophie",
            avatarRes = "avatar_sophie",
            gamerScore = 1450,
            presence = PresenceState.ONLINE,
            currentlyPlaying = null,
            partySize = 1
        )
        val friend4 = Friend(
            userId = "usr_arthur_99",
            username = "ArthurTitan",
            displayName = "Arthur",
            avatarRes = "avatar_arthur",
            gamerScore = 980,
            presence = PresenceState.OFFLINE,
            currentlyPlaying = null
        )

        friends[friend1.userId] = friend1
        friends[friend2.userId] = friend2
        friends[friend3.userId] = friend3
        friends[friend4.userId] = friend4
        _friendsList.value = friends.values.toList()

        // Seed initial chat & invite
        messages.add(
            DirectMessage(
                messageId = "msg_01",
                senderUserId = "usr_elena_002",
                senderDisplayName = "Elena",
                recipientUserId = "usr_tom_001",
                messageText = "Hey Tom, ready for the Sector 7 co-op raid on Albion?"
            )
        )
        _messagesList.value = messages.toList()

        invitations.add(
            GameInvitation(
                invitationId = "inv_01",
                senderUserId = "usr_elena_002",
                senderDisplayName = "Elena",
                targetGameId = "game_cybernetic_albion",
                targetGameTitle = "Cybernetic Albion: 2088",
                lobbyId = "lob_albion_sq1"
            )
        )
        _invitationsList.value = invitations.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun sendMessage(senderUserId: String, senderDisplayName: String, recipientUserId: String, text: String) {
        val msg = DirectMessage(
            messageId = "msg_${System.currentTimeMillis()}",
            senderUserId = senderUserId,
            senderDisplayName = senderDisplayName,
            recipientUserId = recipientUserId,
            messageText = text
        )
        messages.add(msg)
        _messagesList.value = messages.toList()
    }

    fun sendGameInvite(fromUserId: String, fromName: String, toFriendId: String, gameId: String, gameTitle: String, lobbyId: String) {
        val inv = GameInvitation(
            invitationId = "inv_${System.currentTimeMillis()}",
            senderUserId = fromUserId,
            senderDisplayName = fromName,
            targetGameId = gameId,
            targetGameTitle = gameTitle,
            lobbyId = lobbyId
        )
        invitations.add(inv)
        _invitationsList.value = invitations.toList()
        eventBus.post(ArcadiumEvent.InvitationReceived(inv.invitationId, fromUserId, gameId))
    }

    fun acceptInvite(invitationId: String) {
        val index = invitations.indexOfFirst { it.invitationId == invitationId }
        if (index >= 0) {
            invitations[index] = invitations[index].copy(isAccepted = true)
            _invitationsList.value = invitations.toList()
        }
    }
}
