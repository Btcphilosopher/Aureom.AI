package com.example.arcadium.core

/**
 * Explicit lifecycle states of Arcadium platform system services.
 */
enum class ServiceStatus {
    STARTING,
    RUNNING,
    DEGRADED,
    STOPPING,
    STOPPED,
    FAILED
}

/**
 * Base interface for all system and platform services within the Arcadium console.
 */
interface ArcadiumService {
    val serviceName: String
    suspend fun start()
    suspend fun stop()
    fun status(): ServiceStatus
    fun healthReport(): ServiceHealth = ServiceHealth(
        serviceName = serviceName,
        status = status(),
        timestamp = System.currentTimeMillis(),
        details = "Operational"
    )
}

data class ServiceHealth(
    val serviceName: String,
    val status: ServiceStatus,
    val timestamp: Long,
    val details: String = "Normal"
)
