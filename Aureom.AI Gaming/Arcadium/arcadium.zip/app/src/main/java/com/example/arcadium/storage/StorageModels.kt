package com.example.arcadium.storage

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.nativebridge.NativeStorageBridge
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

enum class StoragePartition {
    INTERNAL_SSD,
    EXTERNAL_STORAGE,
    GAME_INSTALLS,
    SAVE_DATA,
    SYSTEM_STORAGE,
    CACHE
}

enum class SandboxPermission {
    INPUT,
    STORAGE_GAME,
    STORAGE_SAVE,
    NETWORK,
    MULTIPLAYER,
    ACHIEVEMENTS,
    TELEMETRY,
    SCREEN_CAPTURE,
    MICROPHONE,
    CAMERA
}

data class StorageSpaceInfo(
    val partition: StoragePartition,
    val totalBytes: Long,
    val usedBytes: Long,
    val freeBytes: Long
) {
    val usedPercentage: Float
        get() = if (totalBytes > 0) (usedBytes.toFloat() / totalBytes) * 100f else 0f
}

data class GameSaveData(
    val gameId: String,
    val userId: String,
    val slot: Int,
    val version: Int,
    val title: String,
    val subtitle: String,
    val timestamp: Long = System.currentTimeMillis(),
    val playTimeSeconds: Long = 0,
    val data: ByteArray,
    val checksum: String,
    val isCloudSynced: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as GameSaveData
        return gameId == other.gameId && userId == other.userId && slot == other.slot && version == other.version
    }

    override fun hashCode(): Int {
        var result = gameId.hashCode()
        result = 31 * result + userId.hashCode()
        result = 31 * result + slot
        result = 31 * result + version
        return result
    }
}

/**
 * Sandboxed Storage service for games and system components.
 */
class ArcadiumStorageService(
    private val nativeBridge: NativeStorageBridge,
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "ArcadiumStorageService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    // Sandboxed in-memory virtual filesystem for fast, deterministic console operations
    private val virtualFileSystem = ConcurrentHashMap<String, ByteArray>()

    private val _storageOverview = MutableStateFlow<List<StorageSpaceInfo>>(emptyList())
    val storageOverview: StateFlow<List<StorageSpaceInfo>> = _storageOverview.asStateFlow()

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        refreshStorageStats()
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun refreshStorageStats() {
        val internalTotal = nativeBridge.getPartitionTotalSpace("INTERNAL_SSD")
        val internalFree = nativeBridge.getPartitionFreeSpace("INTERNAL_SSD")
        val internalUsed = internalTotal - internalFree

        val saveTotal = nativeBridge.getPartitionTotalSpace("SAVE_STORAGE")
        val saveFree = nativeBridge.getPartitionFreeSpace("SAVE_STORAGE")
        val saveUsed = saveTotal - saveFree

        _storageOverview.value = listOf(
            StorageSpaceInfo(StoragePartition.INTERNAL_SSD, internalTotal, internalUsed, internalFree),
            StorageSpaceInfo(StoragePartition.SAVE_DATA, saveTotal, saveUsed, saveFree),
            StorageSpaceInfo(StoragePartition.SYSTEM_STORAGE, 32L * 1024 * 1024 * 1024, 18L * 1024 * 1024 * 1024, 14L * 1024 * 1024 * 1024)
        )
    }

    suspend fun readSandboxed(gameId: String, path: String): ByteArray {
        val sanitized = sanitizePath(gameId, path)
        return virtualFileSystem[sanitized] ?: throw IllegalArgumentException("File not found in sandbox: $path")
    }

    suspend fun writeSandboxed(gameId: String, path: String, data: ByteArray) {
        val sanitized = sanitizePath(gameId, path)
        virtualFileSystem[sanitized] = data
    }

    suspend fun existsSandboxed(gameId: String, path: String): Boolean {
        val sanitized = sanitizePath(gameId, path)
        return virtualFileSystem.containsKey(sanitized)
    }

    suspend fun deleteSandboxed(gameId: String, path: String): Boolean {
        val sanitized = sanitizePath(gameId, path)
        return virtualFileSystem.remove(sanitized) != null
    }

    fun listSandboxedFiles(gameId: String): List<String> {
        val prefix = "/sandbox/$gameId/"
        return virtualFileSystem.keys.filter { it.startsWith(prefix) }
    }

    private fun sanitizePath(gameId: String, path: String): String {
        val clean = path.replace("..", "").trim('/')
        return "/sandbox/$gameId/$clean"
    }
}

/**
 * Dedicated Save Data Manager with versioning, cryptographic checksums, and slot support.
 */
class SaveDataManager(
    private val storageService: ArcadiumStorageService,
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "SaveDataManager"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    // Key: "$gameId:$userId:$slot"
    private val saveSlots = ConcurrentHashMap<String, GameSaveData>()
    private val _allSaves = MutableStateFlow<List<GameSaveData>>(emptyList())
    val allSaves: StateFlow<List<GameSaveData>> = _allSaves.asStateFlow()

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        // Seed default initial game saves
        createInitialSaves()
        serviceStatus = ServiceStatus.RUNNING
    }

    private fun createInitialSaves() {
        val sampleSaveBytes = "ARCADIUM_SAVE_DATA_v1|LEVEL=Sector_07|AMMO=450|CREDITS=12400|HP=100".toByteArray()
        val checksum = calculateChecksum(sampleSaveBytes)
        val initialSave = GameSaveData(
            gameId = "game_cybernetic_albion",
            userId = "usr_tom_001",
            slot = 1,
            version = 1,
            title = "Westminster Spire Infiltration",
            subtitle = "Act III - Checkpoint 4 (100% Core Intact)",
            playTimeSeconds = 7420,
            data = sampleSaveBytes,
            checksum = checksum,
            isCloudSynced = true
        )
        saveSlots["game_cybernetic_albion:usr_tom_001:1"] = initialSave
        _allSaves.value = saveSlots.values.toList()
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun getSave(gameId: String, userId: String, slot: Int): GameSaveData? {
        return saveSlots["$gameId:$userId:$slot"]
    }

    fun getAllSavesForUser(userId: String): List<GameSaveData> {
        return saveSlots.values.filter { it.userId == userId }
    }

    fun getAllSavesForGame(gameId: String): List<GameSaveData> {
        return saveSlots.values.filter { it.gameId == gameId }
    }

    suspend fun writeSave(
        gameId: String,
        userId: String,
        slot: Int,
        title: String,
        subtitle: String,
        playTimeSeconds: Long,
        data: ByteArray
    ): GameSaveData {
        val existing = getSave(gameId, userId, slot)
        val nextVersion = (existing?.version ?: 0) + 1
        val checksum = calculateChecksum(data)

        val newSave = GameSaveData(
            gameId = gameId,
            userId = userId,
            slot = slot,
            version = nextVersion,
            title = title,
            subtitle = subtitle,
            playTimeSeconds = playTimeSeconds,
            data = data,
            checksum = checksum,
            isCloudSynced = false
        )

        val key = "$gameId:$userId:$slot"
        saveSlots[key] = newSave
        _allSaves.value = saveSlots.values.toList()

        // Also persist into sandboxed storage
        storageService.writeSandboxed(gameId, "saves/slot_$slot.dat", data)

        eventBus.post(ArcadiumEvent.SaveCreated(gameId, userId, slot, nextVersion))
        return newSave
    }

    suspend fun deleteSave(gameId: String, userId: String, slot: Int): Boolean {
        val key = "$gameId:$userId:$slot"
        val removed = saveSlots.remove(key) != null
        if (removed) {
            _allSaves.value = saveSlots.values.toList()
            storageService.deleteSandboxed(gameId, "saves/slot_$slot.dat")
        }
        return removed
    }

    fun verifySaveIntegrity(save: GameSaveData): Boolean {
        return calculateChecksum(save.data) == save.checksum
    }

    private fun calculateChecksum(data: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(data)
        return hash.joinToString("") { "%02x".format(it) }.take(16)
    }
}

/**
 * Sandboxing security policy engine for games and applications.
 */
class SandboxManager(
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "SandboxSecurityManager"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    // Granted permissions map: gameId -> Set<SandboxPermission>
    private val grantedPermissions = ConcurrentHashMap<String, MutableSet<SandboxPermission>>()

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun grantPermissions(gameId: String, permissions: Set<SandboxPermission>) {
        val set = grantedPermissions.getOrPut(gameId) { mutableSetOf() }
        set.addAll(permissions)
    }

    fun checkPermission(gameId: String, permission: SandboxPermission): Boolean {
        val permissions = grantedPermissions[gameId] ?: return false
        return permissions.contains(permission)
    }

    fun getGrantedPermissions(gameId: String): Set<SandboxPermission> {
        return grantedPermissions[gameId]?.toSet() ?: emptySet()
    }

    fun revokePermission(gameId: String, permission: SandboxPermission) {
        grantedPermissions[gameId]?.remove(permission)
    }
}
