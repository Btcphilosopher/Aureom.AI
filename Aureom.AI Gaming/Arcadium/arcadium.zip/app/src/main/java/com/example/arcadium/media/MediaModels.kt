package com.example.arcadium.media

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.CopyOnWriteArrayList

enum class CaptureType {
    SCREENSHOT_4K,
    VIDEO_CLIP_60FPS,
    VIDEO_CLIP_120FPS,
    VOICE_MEMO
}

data class CapturedMedia(
    val captureId: String,
    val gameId: String,
    val gameTitle: String,
    val userId: String,
    val type: CaptureType,
    val resolution: String = "3840x2160 (Native 4K HDR)",
    val timestamp: Long = System.currentTimeMillis(),
    val sizeBytes: Long = 8L * 1024 * 1024,
    val durationSeconds: Int = 0,
    val thumbnailRes: String = "game_cybernetic_albion_1786876143930"
)

class MediaService(
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "ArcadiumMediaService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val mediaGallery = CopyOnWriteArrayList<CapturedMedia>()
    private val _gallery = MutableStateFlow<List<CapturedMedia>>(emptyList())
    val gallery: StateFlow<List<CapturedMedia>> = _gallery.asStateFlow()

    init {
        val initialMedia = CapturedMedia(
            captureId = "cap_01_albion_sunset",
            gameId = "game_cybernetic_albion",
            gameTitle = "Cybernetic Albion: 2088",
            userId = "usr_tom_001",
            type = CaptureType.SCREENSHOT_4K,
            sizeBytes = 12L * 1024 * 1024,
            thumbnailRes = "game_cybernetic_albion_1786876143930"
        )
        val initialVideo = CapturedMedia(
            captureId = "cap_02_vortex_boost",
            gameId = "game_vortex_vector",
            gameTitle = "Vortex Vector",
            userId = "usr_tom_001",
            type = CaptureType.VIDEO_CLIP_120FPS,
            sizeBytes = 85L * 1024 * 1024,
            durationSeconds = 30,
            thumbnailRes = "game_vortex_vector_1786876161360"
        )
        mediaGallery.addAll(listOf(initialMedia, initialVideo))
        _gallery.value = mediaGallery.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    suspend fun captureScreenshot(gameId: String, gameTitle: String, userId: String): CapturedMedia {
        val media = CapturedMedia(
            captureId = "cap_${System.currentTimeMillis()}",
            gameId = gameId,
            gameTitle = gameTitle,
            userId = userId,
            type = CaptureType.SCREENSHOT_4K,
            sizeBytes = 14L * 1024 * 1024,
            thumbnailRes = "game_cybernetic_albion_1786876143930"
        )
        mediaGallery.add(0, media)
        _gallery.value = mediaGallery.toList()
        eventBus.post(ArcadiumEvent.CaptureSaved(media.captureId, "Screenshot", "/media/screenshots/${media.captureId}.png"))
        return media
    }

    suspend fun captureClip(gameId: String, gameTitle: String, userId: String, durationSecs: Int): CapturedMedia {
        val media = CapturedMedia(
            captureId = "cap_vid_${System.currentTimeMillis()}",
            gameId = gameId,
            gameTitle = gameTitle,
            userId = userId,
            type = CaptureType.VIDEO_CLIP_120FPS,
            sizeBytes = durationSecs * 3L * 1024 * 1024,
            durationSeconds = durationSecs,
            thumbnailRes = "game_vortex_vector_1786876161360"
        )
        mediaGallery.add(0, media)
        _gallery.value = mediaGallery.toList()
        eventBus.post(ArcadiumEvent.CaptureSaved(media.captureId, "VideoClip", "/media/clips/${media.captureId}.mp4"))
        return media
    }
}
