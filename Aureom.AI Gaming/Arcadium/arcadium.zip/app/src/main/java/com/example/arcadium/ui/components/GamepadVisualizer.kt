package com.example.arcadium.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.controller.ControllerButton
import com.example.arcadium.controller.ControllerState
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary
import com.example.ui.theme.ArcadiumTrackBg

@Composable
fun GamepadVisualizer(
    controllerState: ControllerState,
    onSimulateInput: (lx: Float, ly: Float, rx: Float, ry: Float, lt: Float, rt: Float, buttons: Set<ControllerButton>) -> Unit,
    modifier: Modifier = Modifier
) {
    var simulatedStickX by remember { mutableStateOf(controllerState.leftStick.x) }
    var simulatedStickY by remember { mutableStateOf(controllerState.leftStick.y) }
    var activeButtons by remember { mutableStateOf(controllerState.pressedButtons) }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ArcadiumSurfaceCard)
            .border(1.dp, ArcadiumBorderSubtle, RoundedCornerShape(10.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Controller Lightbar and Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(controllerState.rgbColorHex))
                        .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TACTILE CONTROLLER [P${controllerState.playerIndex + 1}]",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArcadiumTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Text(
                text = "BATTERY ${controllerState.batteryPercent}%",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = ArcadiumCyan
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Interactive Canvas drawing the Controller body and sticks
        Box(
            modifier = Modifier
                .size(width = 300.dp, height = 140.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(ArcadiumObsidianBg)
                .border(1.dp, ArcadiumBorder, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .size(260.dp, 120.dp)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = {
                                simulatedStickX = 0f
                                simulatedStickY = 0f
                                onSimulateInput(0f, 0f, 0f, 0f, 0f, 0f, activeButtons)
                            }
                        ) { change, dragAmount ->
                            change.consume()
                            simulatedStickX = (simulatedStickX + dragAmount.x / 40f).coerceIn(-1f, 1f)
                            simulatedStickY = (simulatedStickY + dragAmount.y / 40f).coerceIn(-1f, 1f)
                            onSimulateInput(simulatedStickX, simulatedStickY, 0f, 0f, 0f, 0f, activeButtons)
                        }
                    }
            ) {
                val centerLeftStick = Offset(size.width * 0.3f, size.height * 0.55f)
                val centerRightStick = Offset(size.width * 0.7f, size.height * 0.55f)
                val stickRadius = 28.dp.toPx()

                // Stick wells
                drawCircle(
                    color = ArcadiumTrackBg,
                    radius = stickRadius,
                    center = centerLeftStick
                )
                drawCircle(
                    color = ArcadiumBorder,
                    radius = stickRadius,
                    center = centerLeftStick,
                    style = Stroke(width = 1.dp.toPx())
                )

                drawCircle(
                    color = ArcadiumTrackBg,
                    radius = stickRadius,
                    center = centerRightStick
                )
                drawCircle(
                    color = ArcadiumBorder,
                    radius = stickRadius,
                    center = centerRightStick,
                    style = Stroke(width = 1.dp.toPx())
                )

                // Left Stick knob
                val leftStickOffset = Offset(
                    centerLeftStick.x + (simulatedStickX * stickRadius * 0.65f),
                    centerLeftStick.y + (simulatedStickY * stickRadius * 0.65f)
                )
                drawCircle(
                    color = ArcadiumCyan,
                    radius = 14.dp.toPx(),
                    center = leftStickOffset
                )

                // Right Stick knob
                val rightStickOffset = Offset(
                    centerRightStick.x + (controllerState.rightStick.x * stickRadius * 0.65f),
                    centerRightStick.y + (controllerState.rightStick.y * stickRadius * 0.65f)
                )
                drawCircle(
                    color = ArcadiumGold,
                    radius = 14.dp.toPx(),
                    center = rightStickOffset
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Button Matrix Simulator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ControllerButtonChip("X", activeButtons.contains(ControllerButton.BUTTON_X)) {
                val newSet = if (activeButtons.contains(ControllerButton.BUTTON_X)) activeButtons - ControllerButton.BUTTON_X else activeButtons + ControllerButton.BUTTON_X
                activeButtons = newSet
                onSimulateInput(simulatedStickX, simulatedStickY, 0f, 0f, 0f, 0f, newSet)
            }
            ControllerButtonChip("Y", activeButtons.contains(ControllerButton.BUTTON_Y)) {
                val newSet = if (activeButtons.contains(ControllerButton.BUTTON_Y)) activeButtons - ControllerButton.BUTTON_Y else activeButtons + ControllerButton.BUTTON_Y
                activeButtons = newSet
                onSimulateInput(simulatedStickX, simulatedStickY, 0f, 0f, 0f, 0f, newSet)
            }
            ControllerButtonChip("A", activeButtons.contains(ControllerButton.BUTTON_A)) {
                val newSet = if (activeButtons.contains(ControllerButton.BUTTON_A)) activeButtons - ControllerButton.BUTTON_A else activeButtons + ControllerButton.BUTTON_A
                activeButtons = newSet
                onSimulateInput(simulatedStickX, simulatedStickY, 0f, 0f, 0f, 0f, newSet)
            }
            ControllerButtonChip("B", activeButtons.contains(ControllerButton.BUTTON_B)) {
                val newSet = if (activeButtons.contains(ControllerButton.BUTTON_B)) activeButtons - ControllerButton.BUTTON_B else activeButtons + ControllerButton.BUTTON_B
                activeButtons = newSet
                onSimulateInput(simulatedStickX, simulatedStickY, 0f, 0f, 0f, 0f, newSet)
            }
            ControllerButtonChip("RT", controllerState.rightTrigger > 0.5f) {
                val trig = if (controllerState.rightTrigger > 0.5f) 0f else 1.0f
                onSimulateInput(simulatedStickX, simulatedStickY, 0f, 0f, 0f, trig, activeButtons)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Left Stick (X: ${String.format("%.2f", simulatedStickX)}, Y: ${String.format("%.2f", simulatedStickY)}) • Drag circle on canvas to steer",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            color = ArcadiumTextMuted,
            fontSize = 8.5.sp
        )
    }
}

@Composable
fun ControllerButtonChip(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val bg = if (isActive) ArcadiumCyan else ArcadiumObsidianBg
    val textCol = if (isActive) ArcadiumObsidianBg else ArcadiumTextSecondary
    val border = if (isActive) ArcadiumCyan else ArcadiumBorder

    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .border(1.dp, border, RoundedCornerShape(4.dp)),
        color = bg,
        onClick = onClick
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = textCol,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
