package com.example.arcadium.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.platform.ArcadiumPlatform
import com.example.arcadium.ui.components.ArcadiumPanel
import com.example.arcadium.ui.components.BadgePill
import com.example.arcadium.ui.components.ServiceItemCard
import com.example.arcadium.ui.components.TelemetryGauge
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCrimson
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurface
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextDim
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary

@Composable
fun DashboardScreen(
    platform: ArcadiumPlatform,
    onNavigateToGameRunner: () -> Unit = {}
) {
    val telemetry by platform.telemetryService.telemetry.collectAsState()
    val services = platform.registry.getAllServices()
    val recentEvents = platform.eventBus.getRecentEvents()
    val hw = platform.nativeBridge.getHardwareInfo()
    val activeSession by platform.gameLauncher.activeSession.collectAsState()

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Section: "Currently Executing / Cybernetic Albion"
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, ArcadiumBorderSubtle, RoundedCornerShape(16.dp)),
                color = Color.Transparent
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF121214),
                                    Color(0xFF0A0A0B)
                                )
                            )
                        )
                ) {
                    // Ambient Cyan Glow Top-Right
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(100.dp)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        ArcadiumCyan.copy(alpha = 0.12f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "CURRENTLY EXECUTING",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ArcadiumTextMuted,
                                    letterSpacing = 1.2.sp,
                                    fontSize = 9.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = activeSession?.game?.title ?: "Cybernetic Albion",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = ArcadiumTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            BadgePill(
                                text = "PROCESS: ${activeSession?.pid ?: 8842}",
                                color = ArcadiumCyan
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "UPTIME",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ArcadiumTextMuted,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "04:12:33",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    color = ArcadiumTextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.width(20.dp))

                            Column {
                                Text(
                                    text = "ENGINE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ArcadiumTextMuted,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "KOTLIN_RT",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    color = ArcadiumTextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.weight(1f))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .alpha(pulseAlpha)
                                        .clip(CircleShape)
                                        .background(ArcadiumEmerald)
                                )
                                Text(
                                    text = "STABLE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ArcadiumEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Telemetry Grid (CPU & GPU)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TelemetryGauge(
                    label = "CPU",
                    value = "${telemetry.cpuUsagePercent.toInt()}",
                    unit = "%",
                    subValue = "@ 3.8 GHz Clock",
                    percentage = (telemetry.cpuUsagePercent / 100f),
                    color = ArcadiumCyan,
                    modifier = Modifier.weight(1f)
                )
                TelemetryGauge(
                    label = "GPU",
                    value = "${telemetry.gpuUsagePercent.toInt()}",
                    unit = "%",
                    subValue = "${telemetry.fanRpm} RPM Fan",
                    percentage = (telemetry.gpuUsagePercent / 100f),
                    color = if (telemetry.gpuUsagePercent > 80) ArcadiumCrimson else ArcadiumGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Telemetry Grid (Framerate & Thermals)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TelemetryGauge(
                    label = "FPS",
                    value = "${telemetry.currentFps.toInt()}",
                    unit = "FPS",
                    subValue = "${String.format("%.1f", telemetry.frameTimeMs)} ms frame",
                    percentage = (telemetry.currentFps / 120f).coerceIn(0f, 1f),
                    color = ArcadiumEmerald,
                    modifier = Modifier.weight(1f)
                )
                TelemetryGauge(
                    label = "THERMALS",
                    value = "${telemetry.temperatureCelsius.toInt()}",
                    unit = "°C",
                    subValue = "${String.format("%.0f", telemetry.powerWatts)}W Draw",
                    percentage = ((telemetry.temperatureCelsius - 30f) / 60f).coerceIn(0f, 1f),
                    color = if (telemetry.temperatureCelsius > 70) ArcadiumGold else ArcadiumCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Active Kotlin Services (Signature Immersive UI list with left-accent border)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "ACTIVE KOTLIN SERVICES",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArcadiumTextMuted,
                    letterSpacing = 1.4.sp,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
                )

                // Key showcased services matching design layout
                ServiceItemCard(
                    serviceName = "arcadium-core",
                    lifecycleStatus = "RUNNING",
                    latencyMs = "0.4ms",
                    accentColor = ArcadiumCyan
                )

                ServiceItemCard(
                    serviceName = "arcadium-multiplayer",
                    lifecycleStatus = "RUNNING",
                    latencyMs = "1.2ms",
                    accentColor = ArcadiumCyan
                )

                ServiceItemCard(
                    serviceName = "arcadium-downloads",
                    lifecycleStatus = "SUSPENDED",
                    latencyMs = "IDLE",
                    accentColor = ArcadiumGold
                )

                ServiceItemCard(
                    serviceName = "arcadium-telemetry",
                    lifecycleStatus = "RUNNING",
                    latencyMs = "0.8ms",
                    accentColor = ArcadiumEmerald
                )
            }
        }

        // Architecture Summary Card
        item {
            ArcadiumPanel(
                title = "Hardware Architecture",
                badge = hw.firmwareVersion,
                accentColor = ArcadiumCyan
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = hw.modelName,
                            style = MaterialTheme.typography.titleMedium,
                            color = ArcadiumTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "16 GB GDDR6 Unified",
                            style = MaterialTheme.typography.labelMedium,
                            color = ArcadiumCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "${hw.cpuModel} • ${hw.gpuModel}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArcadiumTextSecondary
                    )
                }
            }
        }

        // Event Bus Stream
        item {
            ArcadiumPanel(
                title = "Live Kernel Event Stream",
                badge = "REALTIME",
                accentColor = ArcadiumGold
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    recentEvents.take(5).forEach { event ->
                        val eventName = event::class.simpleName ?: "Event"
                        val detail = when (event) {
                            is ArcadiumEvent.GameStarted -> "Launched ${event.title} for user ${event.userId}"
                            is ArcadiumEvent.GameStopped -> "Game ${event.gameId} stopped (${event.playDurationSeconds}s session)"
                            is ArcadiumEvent.DownloadCompleted -> "Installed ${event.title}"
                            is ArcadiumEvent.AchievementUnlocked -> "Unlocked '${event.title}' (+${event.points}G)"
                            is ArcadiumEvent.UserSignedIn -> "Active session for ${event.displayName}"
                            is ArcadiumEvent.ControllerConnected -> "P${event.playerIndex + 1} controller linked"
                            is ArcadiumEvent.NetworkChanged -> "NAT ${event.natType}, ping ${event.latencyMs}ms"
                            is ArcadiumEvent.SaveCreated -> "Game ${event.gameId} save slot ${event.slot} v${event.version}"
                            else -> event.toString()
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(ArcadiumSurfaceCard)
                                .border(1.dp, ArcadiumBorder, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "[$eventName]",
                                style = MaterialTheme.typography.labelSmall,
                                color = ArcadiumCyan,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = detail,
                                style = MaterialTheme.typography.labelSmall,
                                color = ArcadiumTextSecondary,
                                modifier = Modifier.weight(1f),
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
