package com.example.arcadium.telemetry

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.nativebridge.MockNativeBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue

data class ConsoleTelemetry(
    val currentFps: Float = 119.8f,
    val frameTimeMs: Float = 8.33f,
    val cpuUsagePercent: Float = 34.2f,
    val gpuUsagePercent: Float = 78.4f,
    val memoryUsedGb: Float = 6.4f,
    val memoryTotalGb: Float = 16.0f,
    val temperatureCelsius: Float = 54.2f,
    val fanRpm: Int = 1850,
    val powerWatts: Float = 142.0f,
    val ssdReadIops: Int = 1840,
    val ssdWriteIops: Int = 420,
    val networkLatencyMs: Long = 14
)

data class GameCustomTelemetry(
    val gameId: String,
    val eventName: String,
    val payloadJson: String,
    val timestamp: Long = System.currentTimeMillis()
)

class TelemetryService(
    private val nativeBridge: MockNativeBridge,
    private val eventBus: ArcadiumEventBus,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : ArcadiumService {

    override val serviceName: String = "ArcadiumTelemetryService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val _telemetry = MutableStateFlow(ConsoleTelemetry())
    val telemetry: StateFlow<ConsoleTelemetry> = _telemetry.asStateFlow()

    private val gameTelemetryBuffer = ConcurrentLinkedQueue<GameCustomTelemetry>()
    private var samplingJob: Job? = null

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        startSampler()
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        samplingJob?.cancel()
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    private fun startSampler() {
        samplingJob = scope.launch {
            while (isActive) {
                val hw = nativeBridge.sampleTelemetry()
                val fps = nativeBridge.queryCurrentFps()
                val frameTime = if (fps > 0) (1000f / fps) else 16.6f

                val snapshot = ConsoleTelemetry(
                    currentFps = fps,
                    frameTimeMs = frameTime,
                    cpuUsagePercent = hw.cpuUsagePercent,
                    gpuUsagePercent = hw.gpuUsagePercent,
                    memoryUsedGb = (hw.memoryUsedBytes / (1024f * 1024 * 1024)),
                    memoryTotalGb = (hw.memoryTotalBytes / (1024f * 1024 * 1024)),
                    temperatureCelsius = hw.temperatureCelsius,
                    fanRpm = hw.fanRpm,
                    powerWatts = hw.powerWatts,
                    ssdReadIops = hw.ssdReadIops,
                    ssdWriteIops = hw.ssdWriteIops
                )
                _telemetry.value = snapshot
                delay(400) // Sample at 2.5 Hz for UI gauges
            }
        }
    }

    fun recordGameTelemetry(gameId: String, eventName: String, payloadJson: String) {
        val entry = GameCustomTelemetry(gameId, eventName, payloadJson)
        gameTelemetryBuffer.add(entry)
        while (gameTelemetryBuffer.size > 200) {
            gameTelemetryBuffer.poll()
        }
    }

    fun getGameTelemetryHistory(): List<GameCustomTelemetry> = gameTelemetryBuffer.toList().reversed()
}
