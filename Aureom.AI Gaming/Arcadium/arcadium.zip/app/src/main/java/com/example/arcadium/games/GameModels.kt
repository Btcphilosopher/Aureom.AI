package com.example.arcadium.games

import com.example.arcadium.controller.InputManager
import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.storage.ArcadiumStorageService
import com.example.arcadium.storage.SandboxManager
import com.example.arcadium.storage.SandboxPermission
import com.example.arcadium.storage.SaveDataManager
import com.example.arcadium.user.AccountManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

enum class InstallationStatus {
    INSTALLED,
    NOT_INSTALLED,
    DOWNLOADING,
    UPDATING,
    PLAYABLE,
    UNAVAILABLE
}

enum class GameLifecycleState {
    IDLE,
    PREPARING,
    LAUNCHING,
    RUNNING,
    PAUSED,
    SUSPENDED,
    TERMINATING,
    TERMINATED,
    CRASHED
}

data class GameManifest(
    val gameId: String,
    val title: String,
    val studio: String,
    val publisher: String,
    val synopsis: String,
    val genre: String,
    val releaseDate: String,
    val version: String,
    val sizeBytes: Long,
    val targetResolution: String = "4K (3840x2160)",
    val targetFramerate: Int = 120,
    val supportsHdr: Boolean = true,
    val supportsRayTracing: Boolean = true,
    val supportsMultiplayer: Boolean = true,
    val maxLocalPlayers: Int = 4,
    val coverImageRes: String,
    val requiredPermissions: Set<SandboxPermission> = setOf(
        SandboxPermission.INPUT,
        SandboxPermission.STORAGE_GAME,
        SandboxPermission.STORAGE_SAVE,
        SandboxPermission.ACHIEVEMENTS,
        SandboxPermission.TELEMETRY
    ),
    val installationStatus: InstallationStatus = InstallationStatus.INSTALLED,
    val downloadProgressPercent: Float = 100f
)

data class ActiveGameSession(
    val sessionUuid: String,
    val game: GameManifest,
    val activeUserId: String,
    val startTimeMillis: Long = System.currentTimeMillis(),
    val state: GameLifecycleState = GameLifecycleState.LAUNCHING,
    val assignedControllers: List<Int> = listOf(0),
    val currentFps: Float = 120.0f,
    val frameCount: Long = 0L,
    val statusMessage: String = "Running",
    val pid: Int = 8842,
    val sandboxDir: String = "/sandbox/game_${game.gameId}"
) {
    val userId: String get() = activeUserId
}


sealed class LaunchResult {
    data class Success(val session: ActiveGameSession) : LaunchResult()
    data class LicenseDenied(val reason: String) : LaunchResult()
    data class CorruptedInstallation(val missingFile: String) : LaunchResult()
    data class PermissionError(val missingPermission: SandboxPermission) : LaunchResult()
    data class Error(val message: String) : LaunchResult()
}

/**
 * Game Catalog Service providing game metadata, licenses, and installed packages.
 */
class GameCatalogService : ArcadiumService {
    override val serviceName: String = "GameCatalogService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val catalog = ConcurrentHashMap<String, GameManifest>()
    private val _gamesList = MutableStateFlow<List<GameManifest>>(emptyList())
    val gamesList: StateFlow<List<GameManifest>> = _gamesList.asStateFlow()

    init {
        val games = listOf(
            GameManifest(
                gameId = "game_cybernetic_albion",
                title = "Cybernetic Albion: 2088",
                studio = "Vanguard Interactive (London)",
                publisher = "Arcadium Studios",
                synopsis = "A high-octane tactical cyber-action odyssey through neo-Victorian dystopian London. Utilize advanced neuro-implants and gravity disruptors.",
                genre = "Sci-Fi Action / Immersive Sim",
                releaseDate = "2026-04-12",
                version = "v1.4.2",
                sizeBytes = 68L * 1024 * 1024 * 1024, // 68 GB
                coverImageRes = "game_cybernetic_albion_1786876143930",
                installationStatus = InstallationStatus.PLAYABLE
            ),
            GameManifest(
                gameId = "game_vortex_vector",
                title = "Vortex Vector",
                studio = "Hyperion Dynamics",
                publisher = "Arcadium Digital",
                synopsis = "Zero-gravity anti-magnetic supersonic racing across planetary rings and orbital particle accelerators at 1,800 km/h.",
                genre = "Anti-Grav Racing",
                releaseDate = "2026-02-18",
                version = "v2.0.1",
                sizeBytes = 42L * 1024 * 1024 * 1024, // 42 GB
                coverImageRes = "game_vortex_vector_1786876161360",
                installationStatus = InstallationStatus.PLAYABLE
            ),
            GameManifest(
                gameId = "game_ironclad",
                title = "Ironclad Vanguard",
                studio = "Blackwood Heavy Engineering",
                publisher = "Arcadium Publishing",
                synopsis = "Pilot massive 80-tonne walking dieselpunk biped mechs in brutal siege warfare across rain-swept European battlegrounds.",
                genre = "Tactical Mech Warfare",
                releaseDate = "2025-11-04",
                version = "v1.1.8",
                sizeBytes = 85L * 1024 * 1024 * 1024, // 85 GB
                coverImageRes = "game_ironclad_1786876174551",
                installationStatus = InstallationStatus.PLAYABLE
            ),
            GameManifest(
                gameId = "game_solaris_drift",
                title = "Solaris Drift",
                studio = "Aetherworks UK",
                publisher = "Arcadium Indie",
                synopsis = "Deep-space roguelite orbital salvaging simulator with Newtonian physics and dynamic atmospheric re-entry.",
                genre = "Space Survival / Sim",
                releaseDate = "2026-06-20",
                version = "v1.0.0",
                sizeBytes = 28L * 1024 * 1024 * 1024,
                coverImageRes = "game_cybernetic_albion_1786876143930",
                installationStatus = InstallationStatus.INSTALLED
            ),
            GameManifest(
                gameId = "game_neon_specter",
                title = "Neon Specter",
                studio = "Pulsefield Games",
                publisher = "Arcadium Digital",
                synopsis = "Ghost infiltration stealth thriller with quantum time-reversal mechanics in a rain-drenched megacity.",
                genre = "Stealth / Cyberpunk",
                releaseDate = "2026-07-15",
                version = "v1.0.4",
                sizeBytes = 54L * 1024 * 1024 * 1024,
                coverImageRes = "game_vortex_vector_1786876161360",
                installationStatus = InstallationStatus.NOT_INSTALLED,
                downloadProgressPercent = 0f
            )
        )

        games.forEach { catalog[it.gameId] = it }
        _gamesList.value = catalog.values.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun getGame(gameId: String): GameManifest? = catalog[gameId]

    fun updateGameStatus(gameId: String, status: InstallationStatus, progress: Float = 100f) {
        val g = catalog[gameId] ?: return
        val updated = g.copy(installationStatus = status, downloadProgressPercent = progress)
        catalog[gameId] = updated
        _gamesList.value = catalog.values.toList()
    }
}

/**
 * Game Launcher Orchestrator managing complete sandbox preparation, launch, and teardown.
 */
class GameLauncher(
    private val catalogService: GameCatalogService,
    private val accountManager: AccountManager,
    private val storageService: ArcadiumStorageService,
    private val saveDataManager: SaveDataManager,
    private val sandboxManager: SandboxManager,
    private val inputManager: InputManager,
    private val eventBus: ArcadiumEventBus,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : ArcadiumService {

    override val serviceName: String = "GameLauncherService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val _activeSession = MutableStateFlow<ActiveGameSession?>(null)
    val activeSession: StateFlow<ActiveGameSession?> = _activeSession.asStateFlow()

    private val _launchPipelineStep = MutableStateFlow<String>("Idle")
    val launchPipelineStep: StateFlow<String> = _launchPipelineStep.asStateFlow()

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        _activeSession.value?.let {
            terminateGame(it.game.gameId)
        }
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    /**
     * Executes the strict 8-step Arcadium Console Launch Sequence.
     */
    suspend fun launch(gameId: String, userId: String): LaunchResult {
        val game = catalogService.getGame(gameId)
            ?: return LaunchResult.Error("Game not found in library: $gameId")

        // Step 1: Manifest & Installation Discovery
        _launchPipelineStep.value = "1/8: Discovering game manifest and binary integrity..."
        delay(80)

        // Step 2: License & Entitlement Verification
        _launchPipelineStep.value = "2/8: Validating digital signature and cryptographic license..."
        delay(80)

        // Step 3: Sandbox Preparation & Virtual FS Mount
        _launchPipelineStep.value = "3/8: Initializing security sandbox and storage mount points..."
        sandboxManager.grantPermissions(gameId, game.requiredPermissions)
        delay(80)

        // Step 4: Save Data Association
        _launchPipelineStep.value = "4/8: Mounting save data partition for user $userId..."
        delay(80)

        // Step 5: Controller & Audio Assignment
        _launchPipelineStep.value = "5/8: Binding Player 1 controller hardware and haptics..."
        inputManager.setVibration(0, 0.2f, 0.4f)
        delay(60)
        inputManager.setVibration(0, 0f, 0f)

        // Step 6: Process Creation & Graphics Pipeline
        _launchPipelineStep.value = "6/8: Booting game executable and linking graphics context..."
        val session = ActiveGameSession(
            sessionUuid = "sess_${System.currentTimeMillis().toString().takeLast(6)}",
            game = game,
            activeUserId = userId,
            state = GameLifecycleState.RUNNING,
            currentFps = 120.0f,
            statusMessage = "Active / Running 120 FPS HDR"
        )
        _activeSession.value = session
        delay(80)

        // Step 7: Telemetry & Event Broadcast
        _launchPipelineStep.value = "7/8: Attaching platform telemetry probes..."
        eventBus.post(ArcadiumEvent.GameStarted(game.gameId, game.title, userId))
        delay(50)

        // Step 8: Ready State
        _launchPipelineStep.value = "8/8: Game launched successfully"

        return LaunchResult.Success(session)
    }

    suspend fun pauseGame(gameId: String) {
        val s = _activeSession.value ?: return
        if (s.game.gameId == gameId) {
            _activeSession.value = s.copy(
                state = GameLifecycleState.PAUSED,
                statusMessage = "Paused"
            )
            eventBus.post(ArcadiumEvent.GamePaused(gameId))
        }
    }

    suspend fun resumeGame(gameId: String) {
        val s = _activeSession.value ?: return
        if (s.game.gameId == gameId) {
            _activeSession.value = s.copy(
                state = GameLifecycleState.RUNNING,
                statusMessage = "Active / Running 120 FPS HDR"
            )
            eventBus.post(ArcadiumEvent.GameResumed(gameId))
        }
    }

    suspend fun suspendGame(gameId: String) {
        val s = _activeSession.value ?: return
        if (s.game.gameId == gameId) {
            _activeSession.value = s.copy(
                state = GameLifecycleState.SUSPENDED,
                statusMessage = "Suspended to NVMe Cache (Quick Resume Ready)"
            )
        }
    }

    suspend fun terminateGame(gameId: String) {
        val s = _activeSession.value ?: return
        if (s.game.gameId == gameId) {
            val playTimeSecs = (System.currentTimeMillis() - s.startTimeMillis) / 1000
            accountManager.recordPlaySession(s.activeUserId, playTimeSecs / 60)
            _activeSession.value = null
            _launchPipelineStep.value = "Game session cleanly terminated"
            eventBus.post(ArcadiumEvent.GameStopped(gameId, playTimeSecs))
        }
    }
}
