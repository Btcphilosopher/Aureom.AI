package com.example.arcadium.achievements

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.user.AccountManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

enum class AchievementTier(val defaultPoints: Int, val badgeIcon: String) {
    BRONZE(15, "badge_bronze"),
    SILVER(30, "badge_silver"),
    GOLD(75, "badge_gold"),
    PLATINUM(150, "badge_platinum")
}

data class Achievement(
    val achievementId: String,
    val gameId: String,
    val title: String,
    val description: String,
    val tier: AchievementTier,
    val points: Int = tier.defaultPoints,
    val isSecret: Boolean = false,
    val maxProgress: Int = 100,
    val currentProgress: Int = 0,
    val isUnlocked: Boolean = false,
    val unlockedTimestamp: Long? = null
) {
    val progressPercent: Float
        get() = if (maxProgress > 0) (currentProgress.toFloat() / maxProgress) * 100f else 0f
}

data class GameAchievementSet(
    val gameId: String,
    val gameTitle: String,
    val totalAchievements: Int,
    val unlockedCount: Int,
    val totalPoints: Int,
    val earnedPoints: Int,
    val achievements: List<Achievement>
)

class AchievementManager(
    private val accountManager: AccountManager,
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "AchievementSystem"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    // Key: "$gameId:$achievementId"
    private val achievements = ConcurrentHashMap<String, Achievement>()
    private val _achievementSets = MutableStateFlow<List<GameAchievementSet>>(emptyList())
    val achievementSets: StateFlow<List<GameAchievementSet>> = _achievementSets.asStateFlow()

    init {
        // Seed achievements for Cybernetic Albion
        val a1 = Achievement(
            achievementId = "ach_albion_first_hack",
            gameId = "game_cybernetic_albion",
            title = "Neural Override",
            description = "Successfully breach your first Class-4 security terminal in Westminster Spire.",
            tier = AchievementTier.BRONZE,
            points = 20,
            maxProgress = 1,
            currentProgress = 1,
            isUnlocked = true,
            unlockedTimestamp = System.currentTimeMillis() - 86400000
        )
        val a2 = Achievement(
            achievementId = "ach_albion_sub_level",
            gameId = "game_cybernetic_albion",
            title = "Thames Deep Diver",
            description = "Descend into the submerged Victorian subways beneath Neo-London.",
            tier = AchievementTier.SILVER,
            points = 40,
            maxProgress = 1,
            currentProgress = 1,
            isUnlocked = true,
            unlockedTimestamp = System.currentTimeMillis() - 43200000
        )
        val a3 = Achievement(
            achievementId = "ach_albion_boss_flawless",
            gameId = "game_cybernetic_albion",
            title = "Titan Vanquisher",
            description = "Defeat the Archon Dreadnought without taking shield damage.",
            tier = AchievementTier.GOLD,
            points = 90,
            maxProgress = 1,
            currentProgress = 0,
            isUnlocked = false
        )
        val a4 = Achievement(
            achievementId = "ach_albion_master",
            gameId = "game_cybernetic_albion",
            title = "Crown of Albion",
            description = "Master all tactical contracts and unlock every augment.",
            tier = AchievementTier.PLATINUM,
            points = 200,
            isSecret = true,
            maxProgress = 50,
            currentProgress = 32,
            isUnlocked = false
        )

        // Seed achievements for Vortex Vector
        val v1 = Achievement(
            achievementId = "ach_vortex_soundbarrier",
            gameId = "game_vortex_vector",
            title = "Mach 3 Syndicate",
            description = "Reach 1,500 km/h on the Olympus Particle Accelerator track.",
            tier = AchievementTier.BRONZE,
            points = 25,
            maxProgress = 1500,
            currentProgress = 1500,
            isUnlocked = true,
            unlockedTimestamp = System.currentTimeMillis() - 120000000
        )
        val v2 = Achievement(
            achievementId = "ach_vortex_perfect_lap",
            gameId = "game_vortex_vector",
            title = "Zero-Friction Maestro",
            description = "Complete an entire lap without touching track barriers.",
            tier = AchievementTier.GOLD,
            points = 80,
            maxProgress = 1,
            currentProgress = 0,
            isUnlocked = false
        )

        listOf(a1, a2, a3, a4, v1, v2).forEach {
            achievements["${it.gameId}:${it.achievementId}"] = it
        }
        recalculateSets()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    private fun recalculateSets() {
        val grouped = achievements.values.groupBy { it.gameId }
        val titles = mapOf(
            "game_cybernetic_albion" to "Cybernetic Albion: 2088",
            "game_vortex_vector" to "Vortex Vector",
            "game_ironclad" to "Ironclad Vanguard"
        )
        _achievementSets.value = grouped.map { (gameId, list) ->
            GameAchievementSet(
                gameId = gameId,
                gameTitle = titles[gameId] ?: gameId,
                totalAchievements = list.size,
                unlockedCount = list.count { it.isUnlocked },
                totalPoints = list.sumOf { it.points },
                earnedPoints = list.filter { it.isUnlocked }.sumOf { it.points },
                achievements = list
            )
        }
    }

    suspend fun unlock(gameId: String, achievementId: String, userId: String): Boolean {
        val key = "$gameId:$achievementId"
        val existing = achievements[key] ?: return false
        if (existing.isUnlocked) return true

        val unlocked = existing.copy(
            isUnlocked = true,
            currentProgress = existing.maxProgress,
            unlockedTimestamp = System.currentTimeMillis()
        )
        achievements[key] = unlocked
        recalculateSets()

        // Award gamer score to active user
        accountManager.updateGamerScore(userId, unlocked.points)

        eventBus.post(
            ArcadiumEvent.AchievementUnlocked(
                achievementId = achievementId,
                title = unlocked.title,
                points = unlocked.points,
                userId = userId,
                gameId = gameId
            )
        )
        return true
    }

    fun updateProgress(gameId: String, achievementId: String, userId: String, progress: Int): Boolean {
        val key = "$gameId:$achievementId"
        val existing = achievements[key] ?: return false
        if (existing.isUnlocked) return true

        val newProgress = progress.coerceIn(0, existing.maxProgress)
        if (newProgress >= existing.maxProgress) {
            // Unlock!
            achievements[key] = existing.copy(currentProgress = newProgress)
            recalculateSets()
            return true
        } else {
            achievements[key] = existing.copy(currentProgress = newProgress)
            recalculateSets()
            return false
        }
    }

    fun getAchievementsForGame(gameId: String): List<Achievement> {
        return achievements.values.filter { it.gameId == gameId }
    }
}
