package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ArcadiumDarkColorScheme = darkColorScheme(
    primary = ArcadiumCyan,
    onPrimary = Color.Black,
    primaryContainer = ArcadiumCyanDim,
    onPrimaryContainer = ArcadiumCyan,
    secondary = ArcadiumGold,
    onSecondary = Color.Black,
    secondaryContainer = ArcadiumGoldDark,
    onSecondaryContainer = ArcadiumGoldLight,
    tertiary = ArcadiumEmerald,
    onTertiary = Color.Black,
    background = ArcadiumObsidianBg,
    onBackground = ArcadiumTextPrimary,
    surface = ArcadiumSurface,
    onSurface = ArcadiumTextPrimary,
    surfaceVariant = ArcadiumSurfaceElevated,
    onSurfaceVariant = ArcadiumTextSecondary,
    outline = ArcadiumBorderSubtle,
    outlineVariant = ArcadiumBorder,
    error = ArcadiumCrimson,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ArcadiumDarkColorScheme,
        typography = Typography,
        content = content
    )
}


