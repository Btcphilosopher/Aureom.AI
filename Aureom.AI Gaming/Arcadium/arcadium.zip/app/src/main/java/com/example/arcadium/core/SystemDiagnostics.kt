package com.example.arcadium.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

enum class LogLevel {
    DEBUG,
    INFO,
    WARN,
    ERROR,
    CRITICAL
}

data class DiagnosticLogEntry(
    val id: String = java.util.UUID.randomUUID().toString().take(8),
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel,
    val source: String,
    val message: String,
    val payload: String? = null
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.UK).format(Date(timestamp))
}

class SystemDiagnostics {
    private val logBuffer = ConcurrentLinkedQueue<DiagnosticLogEntry>()
    private val maxLogs = 500

    fun log(level: LogLevel, source: String, message: String, payload: String? = null) {
        val entry = DiagnosticLogEntry(
            level = level,
            source = source,
            message = message,
            payload = payload
        )
        logBuffer.add(entry)
        while (logBuffer.size > maxLogs) {
            logBuffer.poll()
        }
    }

    fun info(source: String, message: String) = log(LogLevel.INFO, source, message)
    fun warn(source: String, message: String) = log(LogLevel.WARN, source, message)
    fun error(source: String, message: String, payload: String? = null) = log(LogLevel.ERROR, source, message, payload)
    fun debug(source: String, message: String) = log(LogLevel.DEBUG, source, message)

    fun getLogs(): List<DiagnosticLogEntry> = logBuffer.toList().reversed()
    fun clear() = logBuffer.clear()
}
