package com.example.arcadium.notifications

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.CopyOnWriteArrayList

enum class NotificationPriority {
    LOW,
    NORMAL,
    HIGH,
    URGENT
}

enum class NotificationCategory {
    SYSTEM,
    ACHIEVEMENT,
    DOWNLOAD,
    SOCIAL,
    CONTROLLER,
    GAME
}

data class ConsoleNotification(
    val id: String = "notif_${System.currentTimeMillis()}_${(100..999).random()}",
    val title: String,
    val message: String,
    val priority: NotificationPriority = NotificationPriority.NORMAL,
    val category: NotificationCategory = NotificationCategory.SYSTEM,
    val timestamp: Long = System.currentTimeMillis(),
    val iconRes: String = "ic_notification_system",
    val actionText: String? = null,
    val isRead: Boolean = false
)

class NotificationService(
    private val eventBus: ArcadiumEventBus,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : ArcadiumService {

    override val serviceName: String = "ArcadiumNotificationService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val notifications = CopyOnWriteArrayList<ConsoleNotification>()
    private val _notificationsFlow = MutableStateFlow<List<ConsoleNotification>>(emptyList())
    val notificationsFlow: StateFlow<List<ConsoleNotification>> = _notificationsFlow.asStateFlow()

    private val _activeToast = MutableStateFlow<ConsoleNotification?>(null)
    val activeToast: StateFlow<ConsoleNotification?> = _activeToast.asStateFlow()

    private var eventListenJob: Job? = null

    init {
        // Seed initial notifications
        notifications.add(
            ConsoleNotification(
                id = "notif_welcome",
                title = "ARCADIUM PLATFORM READY",
                message = "ArcOS v2.4.19 running. 4K 120Hz HDR display profile engaged.",
                priority = NotificationPriority.HIGH,
                category = NotificationCategory.SYSTEM
            )
        )
        notifications.add(
            ConsoleNotification(
                id = "notif_achieve",
                title = "TROPHY UNLOCKED",
                message = "Neural Override (20G) - Cybernetic Albion: 2088",
                priority = NotificationPriority.NORMAL,
                category = NotificationCategory.ACHIEVEMENT
            )
        )
        _notificationsFlow.value = notifications.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        listenToEventBus()
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        eventListenJob?.cancel()
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    private fun listenToEventBus() {
        eventListenJob = scope.launch {
            eventBus.events.collect { event ->
                when (event) {
                    is ArcadiumEvent.AchievementUnlocked -> {
                        postNotification(
                            title = "ACHIEVEMENT UNLOCKED",
                            message = "${event.title} (+${event.points}G)",
                            priority = NotificationPriority.HIGH,
                            category = NotificationCategory.ACHIEVEMENT
                        )
                    }
                    is ArcadiumEvent.DownloadCompleted -> {
                        postNotification(
                            title = "DOWNLOAD COMPLETE",
                            message = "${event.title} is ready to play.",
                            priority = NotificationPriority.HIGH,
                            category = NotificationCategory.DOWNLOAD
                        )
                    }
                    is ArcadiumEvent.FriendOnline -> {
                        postNotification(
                            title = "FRIEND ONLINE",
                            message = "${event.username} is now online.",
                            priority = NotificationPriority.NORMAL,
                            category = NotificationCategory.SOCIAL
                        )
                    }
                    is ArcadiumEvent.ControllerBatteryLow -> {
                        postNotification(
                            title = "CONTROLLER BATTERY LOW",
                            message = "Controller ${event.controllerId} at ${event.levelPercentage}%. Connect USB-C.",
                            priority = NotificationPriority.URGENT,
                            category = NotificationCategory.CONTROLLER
                        )
                    }
                    is ArcadiumEvent.InvitationReceived -> {
                        postNotification(
                            title = "GAME INVITATION",
                            message = "You received an invitation to join ${event.gameId}.",
                            priority = NotificationPriority.HIGH,
                            category = NotificationCategory.SOCIAL
                        )
                    }
                    else -> {}
                }
            }
        }
    }

    fun postNotification(
        title: String,
        message: String,
        priority: NotificationPriority = NotificationPriority.NORMAL,
        category: NotificationCategory = NotificationCategory.SYSTEM,
        actionText: String? = null
    ): ConsoleNotification {
        val notif = ConsoleNotification(
            title = title,
            message = message,
            priority = priority,
            category = category,
            actionText = actionText
        )
        notifications.add(0, notif)
        _notificationsFlow.value = notifications.toList()
        _activeToast.value = notif
        return notif
    }

    fun dismissToast() {
        _activeToast.value = null
    }

    fun clearAll() {
        notifications.clear()
        _notificationsFlow.value = emptyList()
        _activeToast.value = null
    }
}
