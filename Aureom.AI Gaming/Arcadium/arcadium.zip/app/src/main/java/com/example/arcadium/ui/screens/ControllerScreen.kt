package com.example.arcadium.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.platform.ArcadiumPlatform
import com.example.arcadium.ui.components.ArcadiumButton
import com.example.arcadium.ui.components.ArcadiumPanel
import com.example.arcadium.ui.components.GamepadVisualizer
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCrimson
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurface
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary
import kotlinx.coroutines.launch

@Composable
fun ControllerScreen(platform: ArcadiumPlatform) {
    val controllerStates by platform.inputManager.controllerStates.collectAsState()
    var selectedPlayer by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    var leftMotorRumble by remember { mutableFloatStateOf(0.7f) }
    var rightMotorRumble by remember { mutableFloatStateOf(0.5f) }
    var deadzoneValue by remember { mutableFloatStateOf(0.05f) }

    val activeCtrl = controllerStates.find { it.playerIndex == selectedPlayer }
        ?: controllerStates.firstOrNull()
        ?: com.example.arcadium.controller.ControllerState(playerIndex = 0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Player Switcher
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (i in 0..3) {
                    val isSelected = selectedPlayer == i
                    val isConnected = controllerStates.any { it.playerIndex == i && it.isConnected }
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                1.dp,
                                if (isSelected) ArcadiumCyan else ArcadiumBorderSubtle,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedPlayer = i },
                        color = if (isSelected) ArcadiumCyan.copy(alpha = 0.12f) else ArcadiumSurfaceElevated
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "P${i + 1}",
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isSelected) ArcadiumCyan else ArcadiumTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isConnected) "CONNECTED" else "STANDBY",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isConnected) ArcadiumEmerald else ArcadiumTextMuted,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Visual Gamepad Canvas & Tester
        item {
            ArcadiumPanel(
                title = "Tactile Gamepad Live Canvas",
                badge = "POLLING 60Hz",
                accentColor = ArcadiumCyan
            ) {
                GamepadVisualizer(
                    controllerState = activeCtrl,
                    onSimulateInput = { lx, ly, rx, ry, lt, rt, btns ->
                        platform.inputManager.simulateInput(selectedPlayer, lx, ly, rx, ry, lt, rt, btns)
                    }
                )
            }
        }

        // RGB Lightbar Profile Picker
        item {
            ArcadiumPanel(
                title = "RGB Lightbar Aura Synchronization",
                badge = "AURA SYNC",
                accentColor = ArcadiumCyan
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "SELECT COLOR PALETTE FOR CONTROLLER ${selectedPlayer + 1}:",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextSecondary,
                        fontSize = 9.sp
                    )

                    val colors = listOf(
                        "Cyber Cyan" to 0xFF22D3EEL,
                        "Electric Emerald" to 0xFF22C55EL,
                        "Amber Core" to 0xFFF59E0BL,
                        "Crimson Core" to 0xFFEF4444L,
                        "Royal Purple" to 0xFFA855F7L,
                        "Titanium White" to 0xFFF0F0F0L
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        colors.forEach { (_, hex) ->
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        2.dp,
                                        if (activeCtrl.rgbColorHex == hex) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable {
                                        scope.launch {
                                            platform.inputManager.setLightbarColor(selectedPlayer, hex)
                                        }
                                    }
                            )
                        }
                    }
                }
            }
        }

        // Haptic Feedback Rumble Engine
        item {
            ArcadiumPanel(
                title = "Dual Neural Haptic Actuators",
                badge = "DIRECT RUMBLE",
                accentColor = ArcadiumEmerald
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Left Motor (Low-frequency heavy bass rumble): ${(leftMotorRumble * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextSecondary
                    )
                    Slider(
                        value = leftMotorRumble,
                        onValueChange = { leftMotorRumble = it },
                        colors = SliderDefaults.colors(
                            thumbColor = ArcadiumCyan,
                            activeTrackColor = ArcadiumCyan,
                            inactiveTrackColor = ArcadiumBorder
                        )
                    )

                    Text(
                        text = "Right Motor (High-frequency tactile tick): ${(rightMotorRumble * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextSecondary
                    )
                    Slider(
                        value = rightMotorRumble,
                        onValueChange = { rightMotorRumble = it },
                        colors = SliderDefaults.colors(
                            thumbColor = ArcadiumGold,
                            activeTrackColor = ArcadiumGold,
                            inactiveTrackColor = ArcadiumBorder
                        )
                    )

                    ArcadiumButton(
                        text = "TEST DUAL RUMBLE PULSE",
                        onClick = {
                            scope.launch {
                                platform.inputManager.setVibration(selectedPlayer, leftMotorRumble, rightMotorRumble)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = ArcadiumCyan,
                        icon = Icons.Default.Vibration
                    )
                }
            }
        }

        // Stick Calibration & Deadzone Configurator
        item {
            ArcadiumPanel(
                title = "Analog Stick Calibration & Deadzones",
                badge = "PRECISION",
                accentColor = ArcadiumGold
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Inner Deadzone: ${(deadzoneValue * 100).toInt()}% (Zero-Drift compensation)",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextSecondary
                    )
                    Slider(
                        value = deadzoneValue,
                        onValueChange = {
                            deadzoneValue = it
                            platform.inputManager.setStickDeadzone(it)
                        },
                        valueRange = 0.01f..0.25f,
                        colors = SliderDefaults.colors(
                            thumbColor = ArcadiumGold,
                            activeTrackColor = ArcadiumGold,
                            inactiveTrackColor = ArcadiumBorder
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "POLLING INTERVAL: 16.6ms (60Hz Thread)",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = ArcadiumTextMuted
                        )
                        Text(
                            text = "ACCEL CURVE: LINEAR",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = ArcadiumCyan
                        )
                    }
                }
            }
        }
    }
}
