package com.example.arcadium.core

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import kotlin.reflect.KClass

/**
 * Service Registry and Lifecycle Orchestrator for the Arcadium platform.
 */
class ServiceRegistry {
    @PublishedApi
    internal val services = ConcurrentHashMap<KClass<*>, ArcadiumService>()
    private val serviceOrder = mutableListOf<ArcadiumService>()
    private val mutex = Mutex()

    suspend fun register(service: ArcadiumService) = mutex.withLock {
        services[service::class] = service
        if (!serviceOrder.contains(service)) {
            serviceOrder.add(service)
        }
    }

    inline fun <reified T : ArcadiumService> get(): T {
        return services[T::class] as? T
            ?: throw IllegalStateException("Arcadium service ${T::class.simpleName} not registered")
    }

    inline fun <reified T : ArcadiumService> getOrNull(): T? {
        return services[T::class] as? T
    }

    fun getAllServices(): List<ArcadiumService> = serviceOrder.toList()

    suspend fun startAll() = mutex.withLock {
        for (service in serviceOrder) {
            try {
                service.start()
            } catch (e: Exception) {
                // Log and mark as failed
            }
        }
    }

    suspend fun stopAll() = mutex.withLock {
        for (service in serviceOrder.reversed()) {
            try {
                service.stop()
            } catch (e: Exception) {
                // Ignore during shutdown
            }
        }
    }

    fun generateHealthDiagnostics(): Map<String, ServiceHealth> {
        return serviceOrder.associate { it.serviceName to it.healthReport() }
    }
}
