package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Arcadium Immersive UI Palette (Obsidian Void, Electric Cyan, Sleek Slate & High-Tech Accents)
val ArcadiumObsidianBg = Color(0xFF050505)
val ArcadiumSurface = Color(0xFF0A0A0C)
val ArcadiumSurfaceCard = Color(0xFF0D0D0F)
val ArcadiumSurfaceElevated = Color(0xFF121214)
val ArcadiumSurfaceHighlight = Color(0xFF1A1A1E)

val ArcadiumBorder = Color(0xFF1A1A1C)
val ArcadiumBorderSubtle = Color(0xFF222226)
val ArcadiumBorderActive = Color(0xFF22D3EE)

val ArcadiumCyan = Color(0xFF22D3EE) // cyan-400
val ArcadiumCyanGlow = Color(0xFF06B6D4) // cyan-500
val ArcadiumCyanDim = Color(0xFF083344)

val ArcadiumGold = Color(0xFFF59E0B) // amber-500
val ArcadiumGoldLight = Color(0xFFFCD34D)
val ArcadiumGoldDark = Color(0xFF78350F)

val ArcadiumCrimson = Color(0xFFEF4444) // red-500
val ArcadiumEmerald = Color(0xFF22C55E) // green-500

val ArcadiumTextPrimary = Color(0xFFF0F0F0)
val ArcadiumTextSecondary = Color(0xFF94A3B8) // slate-400
val ArcadiumTextMuted = Color(0xFF64748B) // slate-500
val ArcadiumTextDim = Color(0xFF475569) // slate-600

val ArcadiumTrackBg = Color(0xFF1E293B) // slate-800


