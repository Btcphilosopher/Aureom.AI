package com.example.arcadium.downloads

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.games.GameCatalogService
import com.example.arcadium.games.InstallationStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

enum class DownloadPriority {
    LOW,
    NORMAL,
    HIGH,
    CRITICAL_SYSTEM
}

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class DownloadItem(
    val downloadId: String,
    val targetId: String, // e.g. gameId or system_update_id
    val title: String,
    val totalBytes: Long,
    val downloadedBytes: Long = 0,
    val priority: DownloadPriority = DownloadPriority.NORMAL,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val speedMbps: Double = 0.0,
    val etaSeconds: Long = 0,
    val type: String = "Game" // "Game", "DLC", "Patch", "System Update"
) {
    val progressPercent: Float
        get() = if (totalBytes > 0) ((downloadedBytes.toDouble() / totalBytes) * 100.0).toFloat().coerceIn(0f, 100f) else 0f
}

enum class UpdateType {
    OS_FIRMWARE,
    GAME_PATCH,
    CONTROLLER_FIRMWARE,
    GPU_MICROCODE
}

data class SystemUpdateInfo(
    val updateId: String,
    val title: String,
    val version: String,
    val releaseDate: String,
    val sizeBytes: Long,
    val type: UpdateType,
    val checksumSha256: String,
    val releaseNotes: String,
    val isInstalled: Boolean = false
)

/**
 * High-performance console download service with queue priority and background worker.
 */
class DownloadManager(
    private val catalogService: GameCatalogService,
    private val eventBus: ArcadiumEventBus,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : ArcadiumService {

    override val serviceName: String = "DownloadManagerService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val queue = CopyOnWriteArrayList<DownloadItem>()
    private val _downloadQueue = MutableStateFlow<List<DownloadItem>>(emptyList())
    val downloadQueue: StateFlow<List<DownloadItem>> = _downloadQueue.asStateFlow()

    private var workerJob: Job? = null
    private var bandwidthLimitMbps: Double = 350.0 // Default 350 Mbps unthrottled fiber

    init {
        // Seed initial download queue items as described in requirements
        val initialDownload1 = DownloadItem(
            downloadId = "dl_albion_dlc_01",
            targetId = "game_cybernetic_albion",
            title = "Cybernetic Albion: Expansion Pack 1 - Thames Sub-Level",
            totalBytes = 14L * 1024 * 1024 * 1024,
            downloadedBytes = (14L * 1024 * 1024 * 1024 * 0.72).toLong(),
            priority = DownloadPriority.HIGH,
            status = DownloadStatus.DOWNLOADING,
            speedMbps = 240.0,
            type = "Expansion"
        )
        val initialDownload2 = DownloadItem(
            downloadId = "dl_os_update_25",
            targetId = "sys_update_2_5",
            title = "Arcadium OS System Software v2.5.0",
            totalBytes = 2800L * 1024 * 1024,
            downloadedBytes = (2800L * 1024 * 1024 * 0.41).toLong(),
            priority = DownloadPriority.CRITICAL_SYSTEM,
            status = DownloadStatus.DOWNLOADING,
            speedMbps = 180.0,
            type = "System Update"
        )
        val initialDownload3 = DownloadItem(
            downloadId = "dl_neon_specter",
            targetId = "game_neon_specter",
            title = "Neon Specter (Full Game)",
            totalBytes = 54L * 1024 * 1024 * 1024,
            downloadedBytes = 0,
            priority = DownloadPriority.NORMAL,
            status = DownloadStatus.QUEUED,
            type = "Game"
        )
        queue.addAll(listOf(initialDownload1, initialDownload2, initialDownload3))
        _downloadQueue.value = queue.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        startDownloadWorker()
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        workerJob?.cancel()
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    private fun startDownloadWorker() {
        workerJob = scope.launch {
            while (isActive) {
                val activeItems = queue.filter { it.status == DownloadStatus.DOWNLOADING }
                if (activeItems.isNotEmpty()) {
                    for (item in activeItems) {
                        val chunkBytes = (item.speedMbps * 1024 * 1024 / 8 / 2).toLong() // 500ms step
                        val newDownloaded = (item.downloadedBytes + chunkBytes).coerceAtMost(item.totalBytes)
                        val isComplete = newDownloaded >= item.totalBytes

                        val updated = item.copy(
                            downloadedBytes = newDownloaded,
                            status = if (isComplete) DownloadStatus.COMPLETED else DownloadStatus.DOWNLOADING,
                            speedMbps = if (isComplete) 0.0 else item.speedMbps,
                            etaSeconds = if (isComplete) 0 else ((item.totalBytes - newDownloaded) / (item.speedMbps * 1024 * 1024 / 8)).toLong()
                        )

                        val index = queue.indexOfFirst { it.downloadId == item.downloadId }
                        if (index >= 0) {
                            queue[index] = updated
                        }

                        if (isComplete) {
                            catalogService.updateGameStatus(item.targetId, InstallationStatus.PLAYABLE, 100f)
                            eventBus.post(ArcadiumEvent.DownloadCompleted(item.downloadId, item.title))
                        } else {
                            eventBus.post(ArcadiumEvent.DownloadProgress(item.downloadId, newDownloaded, item.totalBytes, item.speedMbps))
                        }
                    }
                    _downloadQueue.value = queue.toList()
                }
                delay(500)
            }
        }
    }

    fun enqueueDownload(
        targetId: String,
        title: String,
        totalBytes: Long,
        type: String = "Game",
        priority: DownloadPriority = DownloadPriority.NORMAL
    ): DownloadItem {
        val item = DownloadItem(
            downloadId = "dl_${System.currentTimeMillis().toString().takeLast(6)}",
            targetId = targetId,
            title = title,
            totalBytes = totalBytes,
            downloadedBytes = 0,
            priority = priority,
            status = DownloadStatus.DOWNLOADING,
            speedMbps = 220.0,
            type = type
        )
        queue.add(item)
        _downloadQueue.value = queue.toList()
        catalogService.updateGameStatus(targetId, InstallationStatus.DOWNLOADING, 0f)
        eventBus.post(ArcadiumEvent.DownloadStarted(item.downloadId, item.title, totalBytes))
        return item
    }

    fun pauseDownload(downloadId: String) {
        val index = queue.indexOfFirst { it.downloadId == downloadId }
        if (index >= 0) {
            queue[index] = queue[index].copy(status = DownloadStatus.PAUSED, speedMbps = 0.0)
            _downloadQueue.value = queue.toList()
        }
    }

    fun resumeDownload(downloadId: String) {
        val index = queue.indexOfFirst { it.downloadId == downloadId }
        if (index >= 0) {
            queue[index] = queue[index].copy(status = DownloadStatus.DOWNLOADING, speedMbps = 220.0)
            _downloadQueue.value = queue.toList()
        }
    }

    fun cancelDownload(downloadId: String) {
        val index = queue.indexOfFirst { it.downloadId == downloadId }
        if (index >= 0) {
            val item = queue.removeAt(index)
            _downloadQueue.value = queue.toList()
            catalogService.updateGameStatus(item.targetId, InstallationStatus.NOT_INSTALLED, 0f)
        }
    }
}

/**
 * System and firmware update manager.
 */
class UpdateManager(
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "SystemUpdateService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val updates = ConcurrentHashMap<String, SystemUpdateInfo>()
    private val _availableUpdates = MutableStateFlow<List<SystemUpdateInfo>>(emptyList())
    val availableUpdates: StateFlow<List<SystemUpdateInfo>> = _availableUpdates.asStateFlow()

    init {
        val osUpdate = SystemUpdateInfo(
            updateId = "sys_update_2_5",
            title = "Arcadium OS v2.5.0 (Vanguard Architecture)",
            version = "2.5.0-LTS",
            releaseDate = "2026-08-14",
            sizeBytes = 2800L * 1024 * 1024,
            type = UpdateType.OS_FIRMWARE,
            checksumSha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            releaseNotes = "Includes Neural Haptic feedback 2.0 driver, 120Hz Variable Refresh Rate calibration, and Ray-Tracing shader pipeline optimizations.",
            isInstalled = false
        )
        val controllerUpdate = SystemUpdateInfo(
            updateId = "ctrl_firmware_1_4",
            title = "Arcadium Tactile Controller Firmware v1.4",
            version = "1.4.0",
            releaseDate = "2026-08-01",
            sizeBytes = 12L * 1024 * 1024,
            type = UpdateType.CONTROLLER_FIRMWARE,
            checksumSha256 = "c2e1f49a888b1238491028340192834019283401928340192834019283401928",
            releaseNotes = "Reduces wireless latency to sub-1.2ms and adds RGB breathing color synchronization.",
            isInstalled = false
        )
        updates[osUpdate.updateId] = osUpdate
        updates[controllerUpdate.updateId] = controllerUpdate
        _availableUpdates.value = updates.values.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun markUpdateInstalled(updateId: String) {
        val up = updates[updateId] ?: return
        updates[updateId] = up.copy(isInstalled = true)
        _availableUpdates.value = updates.values.toList()
    }
}
