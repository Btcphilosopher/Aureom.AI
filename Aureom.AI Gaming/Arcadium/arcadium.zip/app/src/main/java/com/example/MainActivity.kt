package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.platform.ArcadiumPlatform
import com.example.arcadium.ui.screens.ControllerScreen
import com.example.arcadium.ui.screens.DashboardScreen
import com.example.arcadium.ui.screens.GameRunnerScreen
import com.example.arcadium.ui.screens.LibraryScreen
import com.example.arcadium.ui.screens.SocialMultiplayerScreen
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurface
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary
import com.example.ui.theme.MyApplicationTheme

enum class ArcadiumNavScreen(val label: String, val icon: ImageVector) {
    DASHBOARD("Home", Icons.Default.Speed),
    LIBRARY("Library", Icons.Default.GridView),
    CONTROLLER("Gamepad", Icons.Default.Gamepad),
    SOCIAL("Network", Icons.Default.Hub),
    RUNNER("Game Session", Icons.Default.PlayArrow)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val platform = ArcadiumPlatform.getInstance()

        setContent {
            MyApplicationTheme {
                ArcadiumApp(platform)
            }
        }
    }
}

@Composable
fun ArcadiumApp(platform: ArcadiumPlatform) {
    var currentScreen by remember { mutableStateOf(ArcadiumNavScreen.DASHBOARD) }
    val activeSession by platform.gameLauncher.activeSession.collectAsState()
    val activeUser by platform.accountManager.activeUser.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArcadiumObsidianBg,
        topBar = {
            ImmersiveHeader(
                activeUserName = activeUser?.displayName ?: "TOM_ARCHITECT"
            )
        },
        bottomBar = {
            ImmersiveBottomNavigation(
                currentScreen = currentScreen,
                hasActiveGame = activeSession != null,
                onScreenSelected = { currentScreen = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ArcadiumObsidianBg)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { target ->
                when (target) {
                    ArcadiumNavScreen.DASHBOARD -> DashboardScreen(
                        platform = platform,
                        onNavigateToGameRunner = { currentScreen = ArcadiumNavScreen.RUNNER }
                    )
                    ArcadiumNavScreen.LIBRARY -> LibraryScreen(
                        platform = platform,
                        onNavigateToGameRunner = { currentScreen = ArcadiumNavScreen.RUNNER }
                    )
                    ArcadiumNavScreen.CONTROLLER -> ControllerScreen(
                        platform = platform
                    )
                    ArcadiumNavScreen.SOCIAL -> SocialMultiplayerScreen(
                        platform = platform
                    )
                    ArcadiumNavScreen.RUNNER -> GameRunnerScreen(
                        platform = platform,
                        onExitGame = { currentScreen = ArcadiumNavScreen.DASHBOARD }
                    )
                }
            }
        }
    }
}

@Composable
fun ImmersiveHeader(
    activeUserName: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        color = ArcadiumObsidianBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, ArcadiumBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Branding
            Column {
                Text(
                    text = "SYSTEM ACTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArcadiumCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    fontSize = 9.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ARCADIUM ",
                        style = MaterialTheme.typography.titleLarge,
                        color = ArcadiumTextPrimary,
                        fontWeight = FontWeight.Light,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "OS v1.0.4",
                        style = MaterialTheme.typography.titleMedium,
                        color = ArcadiumTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.25).sp
                    )
                }
            }

            // Right Profile Section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "PROFILE",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = ArcadiumTextMuted,
                        fontSize = 9.sp
                    )
                    Text(
                        text = activeUserName.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ArcadiumTextPrimary,
                        fontSize = 11.sp
                    )
                }

                // Glowing Avatar Ring
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF1E293B),
                                    Color(0xFF000000)
                                )
                            )
                        )
                        .border(1.dp, ArcadiumCyan.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Cyan glow dot
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(ArcadiumCyan)
                    )
                }
            }
        }
    }
}

@Composable
fun ImmersiveBottomNavigation(
    currentScreen: ArcadiumNavScreen,
    hasActiveGame: Boolean,
    onScreenSelected: (ArcadiumNavScreen) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF08080A),
        border = androidx.compose.foundation.BorderStroke(1.dp, ArcadiumBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Library Item
            NavTabButton(
                title = "Library",
                isSelected = currentScreen == ArcadiumNavScreen.LIBRARY,
                icon = Icons.Default.GridView,
                onClick = { onScreenSelected(ArcadiumNavScreen.LIBRARY) }
            )

            // Home / Dashboard (Centerpiece)
            NavHomeCenterButton(
                isSelected = currentScreen == ArcadiumNavScreen.DASHBOARD,
                onClick = { onScreenSelected(ArcadiumNavScreen.DASHBOARD) }
            )

            // Gamepad Controller
            NavTabButton(
                title = "Gamepad",
                isSelected = currentScreen == ArcadiumNavScreen.CONTROLLER,
                icon = Icons.Default.Gamepad,
                onClick = { onScreenSelected(ArcadiumNavScreen.CONTROLLER) }
            )

            // Network / System
            NavTabButton(
                title = "System",
                isSelected = currentScreen == ArcadiumNavScreen.SOCIAL,
                icon = Icons.Default.Hub,
                onClick = { onScreenSelected(ArcadiumNavScreen.SOCIAL) }
            )

            // If game is running, show active session shortcut
            if (hasActiveGame) {
                NavTabButton(
                    title = "Session",
                    isSelected = currentScreen == ArcadiumNavScreen.RUNNER,
                    icon = Icons.Default.PlayArrow,
                    activeColor = ArcadiumEmerald,
                    onClick = { onScreenSelected(ArcadiumNavScreen.RUNNER) }
                )
            }
        }
    }
}

@Composable
fun NavTabButton(
    title: String,
    isSelected: Boolean,
    icon: ImageVector,
    activeColor: Color = ArcadiumCyan,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) activeColor else ArcadiumTextMuted,
            modifier = Modifier.size(19.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) activeColor else ArcadiumTextMuted,
            fontSize = 8.5.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun NavHomeCenterButton(
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(if (isSelected) Color(0xFFF0F0F0) else ArcadiumSurfaceElevated)
                .border(
                    1.dp,
                    if (isSelected) ArcadiumCyan else ArcadiumBorderSubtle,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isSelected) Color.Black else ArcadiumCyan)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "HOME",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) ArcadiumTextPrimary else ArcadiumTextMuted,
            fontSize = 8.5.sp,
            letterSpacing = 0.5.sp
        )
    }
}
