package com.example.arcadium.nativebridge

/**
 * Native hardware bridge interfaces representing low-level Arcadium OS C++/Rust drivers.
 */

data class ArcadiumHardwareInfo(
    val modelName: String = "Arcadium Console Gen-1 (DevKit-UK)",
    val architecture: String = "ARM64 / Custom Anglo-Silicon",
    val cpuModel: String = "Octa-Core Octavius Vector-64 @ 3.8 GHz",
    val gpuModel: String = "Arcadium Iris-RTX Custom RDNA-X (12.4 TFLOPs)",
    val totalMemoryBytes: Long = 16L * 1024 * 1024 * 1024, // 16 GB unified GDDR6
    val internalStorageBytes: Long = 1024L * 1024 * 1024 * 1024, // 1 TB Custom NVMe
    val firmwareVersion: String = "ArcOS-v2.4.19-LTS",
    val serialNumber: String = "ARC-GB-8849-REV2"
)

data class HardwareTelemetryData(
    val cpuUsagePercent: Float,
    val gpuUsagePercent: Float,
    val memoryUsedBytes: Long,
    val memoryTotalBytes: Long,
    val temperatureCelsius: Float,
    val fanRpm: Int,
    val powerWatts: Float,
    val ssdReadIops: Int,
    val ssdWriteIops: Int
)

data class NativeDisplayMode(
    val width: Int,
    val height: Int,
    val refreshRateHz: Int,
    val hdrSupported: Boolean,
    val variableRefreshRate: Boolean
)

interface NativeSystemBridge {
    fun getHardwareInfo(): ArcadiumHardwareInfo
    fun sampleTelemetry(): HardwareTelemetryData
    fun setPowerMode(performanceMode: Boolean)
    fun rebootConsole()
}

interface NativeInputBridge {
    fun pollRawController(controllerIndex: Int): RawControllerData?
    fun sendHapticVibration(controllerIndex: Int, leftMotor: Float, rightMotor: Float)
    fun setControllerRgb(controllerIndex: Int, colorHex: Int)
}

data class RawControllerData(
    val controllerIndex: Int,
    val connected: Boolean,
    val batteryPercent: Int,
    val leftStickX: Float,
    val leftStickY: Float,
    val rightStickX: Float,
    val rightStickY: Float,
    val leftTrigger: Float,
    val rightTrigger: Float,
    val buttonsMask: Int
)

interface NativeStorageBridge {
    fun readSector(partition: String, offset: Long, length: Int): ByteArray
    fun writeSector(partition: String, offset: Long, data: ByteArray): Boolean
    fun getPartitionFreeSpace(partition: String): Long
    fun getPartitionTotalSpace(partition: String): Long
}

interface NativeGraphicsBridge {
    fun getCurrentDisplayMode(): NativeDisplayMode
    fun setDisplayMode(mode: NativeDisplayMode): Boolean
    fun queryCurrentFps(): Float
    fun captureFramebuffer(): ByteArray
}

interface NativeAudioBridge {
    fun setMasterVolume(volume: Float)
    fun setSpatialAudioEnabled(enabled: Boolean)
    fun outputChime(frequencyHz: Int, durationMs: Int)
}

interface NativeNetworkBridge {
    fun getPhysicalInterfaceStatus(): PhysicalNetworkStatus
    fun pingHost(host: String): Long
}

data class PhysicalNetworkStatus(
    val interfaceName: String,
    val isUp: Boolean,
    val linkSpeedMbps: Int,
    val macAddress: String,
    val isWireless: Boolean
)
