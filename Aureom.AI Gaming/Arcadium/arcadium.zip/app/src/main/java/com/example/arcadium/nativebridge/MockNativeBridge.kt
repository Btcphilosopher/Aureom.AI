package com.example.arcadium.nativebridge

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sin
import kotlin.random.Random

/**
 * Mock Native Bridge implementation for running and testing Arcadium on standard development hardware.
 */
class MockNativeBridge :
    NativeSystemBridge,
    NativeInputBridge,
    NativeStorageBridge,
    NativeGraphicsBridge,
    NativeAudioBridge,
    NativeNetworkBridge {

    private val hardwareInfo = ArcadiumHardwareInfo()
    private var isPerformanceMode = true
    private var tick = 0L
    private val rawControllers = ConcurrentHashMap<Int, RawControllerData>()
    private val storagePartitions = ConcurrentHashMap<String, MutableMap<Long, ByteArray>>()
    private val partitionSizes = mapOf(
        "INTERNAL_SSD" to (825L * 1024 * 1024 * 1024),
        "SAVE_STORAGE" to (64L * 1024 * 1024 * 1024),
        "SYSTEM_STORAGE" to (32L * 1024 * 1024 * 1024)
    )

    private var currentDisplayMode = NativeDisplayMode(
        width = 3840,
        height = 2160,
        refreshRateHz = 120,
        hdrSupported = true,
        variableRefreshRate = true
    )

    init {
        // Initialize Default Controller 1 connected
        rawControllers[0] = RawControllerData(
            controllerIndex = 0,
            connected = true,
            batteryPercent = 94,
            leftStickX = 0.0f,
            leftStickY = 0.0f,
            rightStickX = 0.0f,
            rightStickY = 0.0f,
            leftTrigger = 0.0f,
            rightTrigger = 0.0f,
            buttonsMask = 0
        )
        // Controller 2 (standby)
        rawControllers[1] = RawControllerData(
            controllerIndex = 1,
            connected = true,
            batteryPercent = 78,
            leftStickX = 0.0f,
            leftStickY = 0.0f,
            rightStickX = 0.0f,
            rightStickY = 0.0f,
            leftTrigger = 0.0f,
            rightTrigger = 0.0f,
            buttonsMask = 0
        )
    }

    // System Bridge
    override fun getHardwareInfo(): ArcadiumHardwareInfo = hardwareInfo

    override fun sampleTelemetry(): HardwareTelemetryData {
        tick++
        val baseCpu = if (isPerformanceMode) 32f else 18f
        val cpuFluctuation = (sin(tick * 0.1) * 8.0).toFloat() + Random.nextFloat() * 4f
        val gpuFluctuation = (sin(tick * 0.08) * 12.0).toFloat() + (if (isPerformanceMode) 45f else 25f)
        val temp = 48f + (cpuFluctuation * 0.4f) + (gpuFluctuation * 0.2f)

        return HardwareTelemetryData(
            cpuUsagePercent = (baseCpu + cpuFluctuation).coerceIn(5f, 98f),
            gpuUsagePercent = gpuFluctuation.coerceIn(10f, 99f),
            memoryUsedBytes = (5.8 * 1024 * 1024 * 1024).toLong() + (tick % 500) * 1024 * 1024,
            memoryTotalBytes = hardwareInfo.totalMemoryBytes,
            temperatureCelsius = temp.coerceIn(40f, 78f),
            fanRpm = (1200 + (temp - 40) * 45).toInt().coerceIn(1000, 3200),
            powerWatts = (95f + (gpuFluctuation * 0.8f)).coerceIn(60f, 185f),
            ssdReadIops = (1400 + Random.nextInt(1200)),
            ssdWriteIops = (450 + Random.nextInt(300))
        )
    }

    override fun setPowerMode(performanceMode: Boolean) {
        this.isPerformanceMode = performanceMode
    }

    override fun rebootConsole() {
        // Simulated reboot trigger
    }

    // Input Bridge
    override fun pollRawController(controllerIndex: Int): RawControllerData? {
        return rawControllers[controllerIndex]
    }

    fun updateMockControllerInput(
        controllerIndex: Int,
        lx: Float,
        ly: Float,
        rx: Float,
        ry: Float,
        lt: Float,
        rt: Float,
        buttons: Int
    ) {
        val prev = rawControllers[controllerIndex] ?: RawControllerData(controllerIndex, true, 90, 0f, 0f, 0f, 0f, 0f, 0f, 0)
        rawControllers[controllerIndex] = prev.copy(
            leftStickX = lx,
            leftStickY = ly,
            rightStickX = rx,
            rightStickY = ry,
            leftTrigger = lt,
            rightTrigger = rt,
            buttonsMask = buttons
        )
    }

    override fun sendHapticVibration(controllerIndex: Int, leftMotor: Float, rightMotor: Float) {
        // Haptic feedback received by controller hardware
    }

    override fun setControllerRgb(controllerIndex: Int, colorHex: Int) {
        // Lightbar color set
    }

    // Storage Bridge
    override fun readSector(partition: String, offset: Long, length: Int): ByteArray {
        val part = storagePartitions.getOrPut(partition) { ConcurrentHashMap() }
        return part[offset] ?: ByteArray(length)
    }

    override fun writeSector(partition: String, offset: Long, data: ByteArray): Boolean {
        val part = storagePartitions.getOrPut(partition) { ConcurrentHashMap() }
        part[offset] = data
        return true
    }

    override fun getPartitionFreeSpace(partition: String): Long {
        val total = partitionSizes[partition] ?: (500L * 1024 * 1024 * 1024)
        return (total * 0.68).toLong()
    }

    override fun getPartitionTotalSpace(partition: String): Long {
        return partitionSizes[partition] ?: (500L * 1024 * 1024 * 1024)
    }

    // Graphics Bridge
    override fun getCurrentDisplayMode(): NativeDisplayMode = currentDisplayMode

    override fun setDisplayMode(mode: NativeDisplayMode): Boolean {
        this.currentDisplayMode = mode
        return true
    }

    override fun queryCurrentFps(): Float {
        return if (currentDisplayMode.refreshRateHz == 120) {
            119.4f + (Random.nextFloat() * 0.6f)
        } else {
            59.8f + (Random.nextFloat() * 0.4f)
        }
    }

    override fun captureFramebuffer(): ByteArray {
        return ByteArray(1024) { (it % 255).toByte() }
    }

    // Audio Bridge
    override fun setMasterVolume(volume: Float) {}
    override fun setSpatialAudioEnabled(enabled: Boolean) {}
    override fun outputChime(frequencyHz: Int, durationMs: Int) {}

    // Network Bridge
    override fun getPhysicalInterfaceStatus(): PhysicalNetworkStatus {
        return PhysicalNetworkStatus(
            interfaceName = "eth0",
            isUp = true,
            linkSpeedMbps = 1000,
            macAddress = "D8:5E:D3:A1:04:19",
            isWireless = false
        )
    }

    override fun pingHost(host: String): Long {
        return 12L + Random.nextLong(10)
    }
}
