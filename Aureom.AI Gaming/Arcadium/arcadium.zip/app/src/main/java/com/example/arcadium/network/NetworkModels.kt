package com.example.arcadium.network

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.nativebridge.NativeNetworkBridge
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

enum class NatType {
    OPEN_TYPE_1,
    MODERATE_TYPE_2,
    STRICT_TYPE_3
}

enum class ConnectionQuality {
    EXCELLENT,
    GOOD,
    FAIR,
    POOR,
    DISCONNECTED
}

data class NetworkStatus(
    val isConnected: Boolean = true,
    val interfaceType: String = "Gigabit Ethernet (Direct)",
    val ipAddress: String = "192.168.1.144",
    val latencyMs: Long = 14,
    val downloadSpeedMbps: Double = 940.0,
    val uploadSpeedMbps: Double = 450.0,
    val natType: NatType = NatType.OPEN_TYPE_1,
    val quality: ConnectionQuality = ConnectionQuality.EXCELLENT,
    val isOfflineModeForced: Boolean = false
)

enum class LobbyPrivacy {
    PUBLIC_MATCHMAKING,
    FRIENDS_ONLY,
    INVITE_ONLY
}

data class MultiplayerLobby(
    val lobbyId: String,
    val gameId: String,
    val hostUserId: String,
    val title: String,
    val maxPlayers: Int = 8,
    val currentPlayers: List<String> = emptyList(),
    val privacy: LobbyPrivacy = LobbyPrivacy.PUBLIC_MATCHMAKING,
    val region: String = "Europe (London - UK)",
    val averagePingMs: Int = 16,
    val isMatchInProgress: Boolean = false
)

data class MatchmakingTicket(
    val ticketId: String,
    val gameId: String,
    val gameMode: String,
    val queueStartTime: Long = System.currentTimeMillis(),
    val status: String = "Searching for ranked opponents in EU-West..."
)

/**
 * Console Network Service providing latency telemetry, NAT detection, and offline mode.
 */
class NetworkService(
    private val nativeBridge: NativeNetworkBridge,
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "ArcadiumNetworkService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val _networkStatus = MutableStateFlow(NetworkStatus())
    val networkStatus: StateFlow<NetworkStatus> = _networkStatus.asStateFlow()

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        refreshNetworkState()
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun refreshNetworkState() {
        if (_networkStatus.value.isOfflineModeForced) return
        val ping = nativeBridge.pingHost("uk-central.arcadium.network")
        _networkStatus.value = _networkStatus.value.copy(
            isConnected = true,
            latencyMs = ping,
            quality = if (ping < 25) ConnectionQuality.EXCELLENT else ConnectionQuality.GOOD
        )
        eventBus.post(ArcadiumEvent.NetworkChanged(true, ping, "OPEN_TYPE_1"))
    }

    fun toggleOfflineMode(forceOffline: Boolean) {
        _networkStatus.value = _networkStatus.value.copy(
            isOfflineModeForced = forceOffline,
            isConnected = !forceOffline,
            quality = if (forceOffline) ConnectionQuality.DISCONNECTED else ConnectionQuality.EXCELLENT
        )
        eventBus.post(ArcadiumEvent.NetworkChanged(!forceOffline, if (forceOffline) 0 else 14, "OFFLINE"))
    }
}

/**
 * Console Multiplayer and Matchmaking Service.
 */
class MultiplayerService(
    private val networkService: NetworkService,
    private val eventBus: ArcadiumEventBus
) : ArcadiumService {

    override val serviceName: String = "MultiplayerService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val activeLobbies = ConcurrentHashMap<String, MultiplayerLobby>()
    private val _lobbies = MutableStateFlow<List<MultiplayerLobby>>(emptyList())
    val lobbies: StateFlow<List<MultiplayerLobby>> = _lobbies.asStateFlow()

    private val _activeTicket = MutableStateFlow<MatchmakingTicket?>(null)
    val activeTicket: StateFlow<MatchmakingTicket?> = _activeTicket.asStateFlow()

    init {
        // Seed initial lobbies
        val lobby1 = MultiplayerLobby(
            lobbyId = "lob_albion_sq1",
            gameId = "game_cybernetic_albion",
            hostUserId = "usr_tom_001",
            title = "Westminster Tactical Siege [Hardcore]",
            maxPlayers = 4,
            currentPlayers = listOf("usr_tom_001", "usr_elena_002", "usr_marcus_04"),
            privacy = LobbyPrivacy.PUBLIC_MATCHMAKING,
            averagePingMs = 12
        )
        val lobby2 = MultiplayerLobby(
            lobbyId = "lob_vortex_cup",
            gameId = "game_vortex_vector",
            hostUserId = "usr_speed_99",
            title = "Orbital Cup Championship 2088",
            maxPlayers = 8,
            currentPlayers = listOf("usr_speed_99", "usr_vector_king", "usr_elena_002"),
            privacy = LobbyPrivacy.PUBLIC_MATCHMAKING,
            averagePingMs = 18
        )
        activeLobbies[lobby1.lobbyId] = lobby1
        activeLobbies[lobby2.lobbyId] = lobby2
        _lobbies.value = activeLobbies.values.toList()
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun createLobby(gameId: String, hostUserId: String, title: String, maxPlayers: Int, privacy: LobbyPrivacy): MultiplayerLobby {
        val lobby = MultiplayerLobby(
            lobbyId = "lob_${System.currentTimeMillis().toString().takeLast(6)}",
            gameId = gameId,
            hostUserId = hostUserId,
            title = title,
            maxPlayers = maxPlayers,
            currentPlayers = listOf(hostUserId),
            privacy = privacy,
            averagePingMs = 15
        )
        activeLobbies[lobby.lobbyId] = lobby
        _lobbies.value = activeLobbies.values.toList()
        return lobby
    }

    fun joinLobby(lobbyId: String, userId: String): Boolean {
        val lob = activeLobbies[lobbyId] ?: return false
        if (lob.currentPlayers.size >= lob.maxPlayers) return false
        if (lob.currentPlayers.contains(userId)) return true

        val updated = lob.copy(currentPlayers = lob.currentPlayers + userId)
        activeLobbies[lobbyId] = updated
        _lobbies.value = activeLobbies.values.toList()
        return true
    }

    fun startMatchmaking(gameId: String, gameMode: String) {
        val ticket = MatchmakingTicket(
            ticketId = "tkt_${System.currentTimeMillis().toString().takeLast(6)}",
            gameId = gameId,
            gameMode = gameMode
        )
        _activeTicket.value = ticket
    }

    fun cancelMatchmaking() {
        _activeTicket.value = null
    }
}
