package com.example.arcadium.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.core.ServiceStatus
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCrimson
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurface
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary
import com.example.ui.theme.ArcadiumTrackBg

@Composable
fun ArcadiumPanel(
    modifier: Modifier = Modifier,
    title: String? = null,
    badge: String? = null,
    accentColor: Color = ArcadiumCyan,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(14.dp)),
        color = ArcadiumSurfaceElevated,
        border = BorderStroke(1.dp, ArcadiumBorderSubtle),
        shape = RoundedCornerShape(14.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF121214),
                            Color(0xFF0A0A0B)
                        )
                    )
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (title != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(13.dp)
                                    .background(accentColor, RoundedCornerShape(1.5.dp))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = title.uppercase(),
                                style = MaterialTheme.typography.labelLarge,
                                color = ArcadiumTextPrimary,
                                letterSpacing = 1.2.sp
                            )
                        }
                        if (badge != null) {
                            BadgePill(text = badge, color = accentColor)
                        }
                    }
                }
                content()
            }
        }
    }
}

@Composable
fun TelemetryGauge(
    label: String,
    value: String,
    unit: String? = null,
    subValue: String? = null,
    percentage: Float? = null,
    color: Color = ArcadiumCyan,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(12.dp)),
        color = ArcadiumSurface,
        border = BorderStroke(1.dp, ArcadiumBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "TELEMETRY: $label".uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = ArcadiumTextMuted,
                fontStyle = FontStyle.Italic,
                letterSpacing = 1.sp,
                fontSize = 9.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Normal,
                    fontFamily = FontFamily.Monospace,
                    color = ArcadiumTextPrimary,
                    fontSize = 24.sp
                )
                if (unit != null) {
                    Text(
                        text = unit,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextMuted,
                        modifier = Modifier.padding(bottom = 2.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            if (subValue != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subValue,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArcadiumTextMuted,
                    fontSize = 9.sp
                )
            }
            if (percentage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                ArcadiumProgressBar(progress = percentage, color = color)
            }
        }
    }
}

@Composable
fun ArcadiumProgressBar(
    progress: Float,
    color: Color = ArcadiumCyan,
    height: Dp = 4.dp,
    modifier: Modifier = Modifier
) {
    val clamped = progress.coerceIn(0f, 1f)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .background(ArcadiumTrackBg, RoundedCornerShape(height / 2))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(clamped)
                .height(height)
                .background(
                    color = color,
                    shape = RoundedCornerShape(height / 2)
                )
        )
    }
}

@Composable
fun ServiceItemCard(
    serviceName: String,
    lifecycleStatus: String,
    latencyMs: String,
    accentColor: Color = ArcadiumCyan,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(8.dp)),
        color = ArcadiumSurfaceCard,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    BorderStroke(1.dp, ArcadiumBorderSubtle),
                    shape = RoundedCornerShape(8.dp)
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Accent Border
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(44.dp)
                    .background(accentColor)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = serviceName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = ArcadiumTextPrimary
                    )
                    Text(
                        text = "Lifecycle: $lifecycleStatus",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextMuted,
                        fontSize = 9.sp
                    )
                }
                Text(
                    text = latencyMs,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = accentColor,
                    fontSize = 9.sp
                )
            }
        }
    }
}

@Composable
fun ServiceStatusBadge(status: ServiceStatus) {
    val (color, text) = when (status) {
        ServiceStatus.RUNNING -> ArcadiumEmerald to "RUNNING"
        ServiceStatus.STARTING -> ArcadiumCyan to "STARTING"
        ServiceStatus.DEGRADED -> ArcadiumGold to "DEGRADED"
        ServiceStatus.STOPPING -> ArcadiumCrimson to "STOPPING"
        ServiceStatus.STOPPED -> ArcadiumTextMuted to "STOPPED"
        ServiceStatus.FAILED -> ArcadiumCrimson to "FAILED"
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 8.5.sp
        )
    }
}

@Composable
fun ArcadiumButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true,
    accentColor: Color = ArcadiumCyan,
    icon: ImageVector? = null
) {
    val bg = if (isPrimary) accentColor else ArcadiumSurfaceElevated
    val contentColor = if (isPrimary) ArcadiumObsidianBg else ArcadiumTextPrimary
    val border = if (isPrimary) null else BorderStroke(1.dp, ArcadiumBorderSubtle)

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable { onClick() },
        color = bg,
        border = border,
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = text.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = contentColor,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }
    }
}

@Composable
fun BadgePill(text: String, color: Color = ArcadiumCyan) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = color,
        fontWeight = FontWeight.Bold,
        fontSize = 9.sp,
        modifier = Modifier
            .background(color.copy(alpha = 0.10f), RoundedCornerShape(3.dp))
            .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}
