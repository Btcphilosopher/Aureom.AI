package com.example.arcadium.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Root sealed class representing all platform events emitted by the Arcadium OS and services.
 */
sealed class ArcadiumEvent {
    val timestamp: Long = System.currentTimeMillis()

    // Game lifecycle events
    data class GameStarted(val gameId: String, val title: String, val userId: String) : ArcadiumEvent()
    data class GameStopped(val gameId: String, val playDurationSeconds: Long) : ArcadiumEvent()
    data class GamePaused(val gameId: String) : ArcadiumEvent()
    data class GameResumed(val gameId: String) : ArcadiumEvent()
    data class GameCrashed(val gameId: String, val exitCode: Int, val reason: String) : ArcadiumEvent()

    // Controller events
    data class ControllerConnected(val controllerId: String, val playerIndex: Int) : ArcadiumEvent()
    data class ControllerDisconnected(val controllerId: String, val playerIndex: Int) : ArcadiumEvent()
    data class ControllerBatteryLow(val controllerId: String, val levelPercentage: Int) : ArcadiumEvent()
    data class ControllerRemapped(val controllerId: String, val profileName: String) : ArcadiumEvent()

    // User & Account events
    data class UserSignedIn(val userId: String, val displayName: String) : ArcadiumEvent()
    data class UserSignedOut(val userId: String) : ArcadiumEvent()
    data class UserProfileSwitched(val previousUserId: String?, val newUserId: String) : ArcadiumEvent()

    // Download & Update events
    data class DownloadStarted(val downloadId: String, val title: String, val totalBytes: Long) : ArcadiumEvent()
    data class DownloadProgress(val downloadId: String, val bytesDownloaded: Long, val totalBytes: Long, val speedMbps: Double) : ArcadiumEvent()
    data class DownloadCompleted(val downloadId: String, val title: String) : ArcadiumEvent()
    data class DownloadFailed(val downloadId: String, val error: String) : ArcadiumEvent()
    data class UpdateAvailable(val targetId: String, val version: String, val sizeBytes: Long) : ArcadiumEvent()

    // Achievements & Social events
    data class AchievementUnlocked(val achievementId: String, val title: String, val points: Int, val userId: String, val gameId: String) : ArcadiumEvent()
    data class FriendOnline(val friendId: String, val username: String, val playingGame: String?) : ArcadiumEvent()
    data class FriendOffline(val friendId: String, val username: String) : ArcadiumEvent()
    data class FriendActivityChanged(val friendId: String, val status: String) : ArcadiumEvent()
    data class InvitationReceived(val invitationId: String, val fromUserId: String, val gameId: String) : ArcadiumEvent()

    // Storage & Save events
    data class SaveCreated(val gameId: String, val userId: String, val slot: Int, val version: Int) : ArcadiumEvent()
    data class SaveRestored(val gameId: String, val userId: String, val slot: Int) : ArcadiumEvent()
    data class StorageLowWarning(val freeBytes: Long, val requiredBytes: Long) : ArcadiumEvent()

    // System & Network events
    data class NetworkChanged(val isConnected: Boolean, val latencyMs: Long, val natType: String) : ArcadiumEvent()
    data class ThermalAlert(val temperatureCelsius: Float, val level: String) : ArcadiumEvent()
    data class NotificationReceived(val id: String, val title: String, val message: String, val priority: String) : ArcadiumEvent()
    data class TelemetrySampled(val fps: Float, val cpuUsage: Float, val gpuUsage: Float, val memoryMb: Long) : ArcadiumEvent()
    data class CaptureSaved(val captureId: String, val type: String, val path: String) : ArcadiumEvent()
}

/**
 * High-performance, strongly typed asynchronous event bus for the Arcadium platform.
 */
class ArcadiumEventBus(private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)) {
    private val _events = MutableSharedFlow<ArcadiumEvent>(replay = 64, extraBufferCapacity = 256)
    val events: Flow<ArcadiumEvent> = _events.asSharedFlow()

    private val eventHistory = ConcurrentLinkedQueue<ArcadiumEvent>()
    private val maxHistorySize = 100

    fun post(event: ArcadiumEvent) {
        eventHistory.add(event)
        while (eventHistory.size > maxHistorySize) {
            eventHistory.poll()
        }
        scope.launch {
            _events.emit(event)
        }
    }

    inline fun <reified T : ArcadiumEvent> subscribe(): Flow<T> {
        return events.filterIsInstance<T>()
    }

    fun getRecentEvents(): List<ArcadiumEvent> {
        return eventHistory.toList().reversed()
    }
}
