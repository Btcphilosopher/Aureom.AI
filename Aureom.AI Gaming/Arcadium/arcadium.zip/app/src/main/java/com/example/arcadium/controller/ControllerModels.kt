package com.example.arcadium.controller

import com.example.arcadium.core.ArcadiumEvent
import com.example.arcadium.core.ArcadiumEventBus
import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.nativebridge.NativeInputBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sqrt

enum class ControllerButton(val mask: Int) {
    BUTTON_A(1 shl 0),      // South (Cross/A)
    BUTTON_B(1 shl 1),      // East (Circle/B)
    BUTTON_X(1 shl 2),      // West (Square/X)
    BUTTON_Y(1 shl 3),      // North (Triangle/Y)
    DPAD_UP(1 shl 4),
    DPAD_DOWN(1 shl 5),
    DPAD_LEFT(1 shl 6),
    DPAD_RIGHT(1 shl 7),
    BUMPER_LEFT(1 shl 8),   // L1 / LB
    BUMPER_RIGHT(1 shl 9),  // R1 / RB
    STICK_CLICK_LEFT(1 shl 10),  // L3
    STICK_CLICK_RIGHT(1 shl 11), // R3
    BUTTON_VIEW(1 shl 12),  // Select/Share
    BUTTON_MENU(1 shl 13),  // Options/Start
    BUTTON_ARCADIUM_HOME(1 shl 14) // Central Console Logo Button
}

data class StickPosition(
    val x: Float = 0f,
    val y: Float = 0f
) {
    val magnitude: Float
        get() = sqrt((x * x) + (y * y)).coerceIn(0f, 1f)
}

data class ControllerState(
    val controllerId: String = "ctrl_arc_p1_881",
    val playerIndex: Int = 0,
    val isConnected: Boolean = true,
    val batteryPercent: Int = 92,
    val leftStick: StickPosition = StickPosition(),
    val rightStick: StickPosition = StickPosition(),
    val leftTrigger: Float = 0f,
    val rightTrigger: Float = 0f,
    val pressedButtons: Set<ControllerButton> = emptySet(),
    val rgbColorHex: Long = 0xFF22D3EEL, // Electric Cyan
    val hapticLeftIntensity: Float = 0f,
    val hapticRightIntensity: Float = 0f,
    val activeProfileName: String = "Default Tactile"
) {
    fun isButtonPressed(button: ControllerButton): Boolean = pressedButtons.contains(button)
}


data class ControllerRemapProfile(
    val profileName: String,
    val deadzoneLeft: Float = 0.08f,
    val deadzoneRight: Float = 0.08f,
    val triggerDeadzone: Float = 0.05f,
    val buttonRemappings: Map<ControllerButton, ControllerButton> = emptyMap(),
    val invertYAxis: Boolean = false
)

class InputManager(
    private val nativeBridge: NativeInputBridge,
    private val eventBus: ArcadiumEventBus,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : ArcadiumService {

    override val serviceName: String = "InputAndControllerService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val controllers = ConcurrentHashMap<Int, ControllerState>()
    private val remapProfiles = ConcurrentHashMap<Int, ControllerRemapProfile>()

    private val _controllerStates = MutableStateFlow<List<ControllerState>>(emptyList())
    val controllerStates: StateFlow<List<ControllerState>> = _controllerStates.asStateFlow()

    private var pollingJob: Job? = null

    init {
        // Player 1 controller setup
        controllers[0] = ControllerState(
            controllerId = "ctrl_arc_p1_881",
            playerIndex = 0,
            isConnected = true,
            batteryPercent = 94,
            rgbColorHex = 0xFFD4AF37L // Gold
        )
        // Player 2 controller setup
        controllers[1] = ControllerState(
            controllerId = "ctrl_arc_p2_442",
            playerIndex = 1,
            isConnected = true,
            batteryPercent = 78,
            rgbColorHex = 0xFF00E5FFL // Cyan
        )
        remapProfiles[0] = ControllerRemapProfile("Tactile Competition")
        remapProfiles[1] = ControllerRemapProfile("Standard Default")
        _controllerStates.value = controllers.values.toList().sortedBy { it.playerIndex }
    }

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        startPollingLoop()
        serviceStatus = ServiceStatus.RUNNING
        eventBus.post(ArcadiumEvent.ControllerConnected("ctrl_arc_p1_881", 0))
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        pollingJob?.cancel()
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    private fun startPollingLoop() {
        pollingJob = scope.launch {
            while (isActive) {
                pollControllers()
                delay(16) // ~60Hz polling
            }
        }
    }

    private fun pollControllers() {
        for (i in 0..1) {
            val raw = nativeBridge.pollRawController(i) ?: continue
            val current = controllers[i] ?: continue
            val profile = remapProfiles[i] ?: ControllerRemapProfile("Default")

            // Process analog sticks with deadzone filter
            val lx = applyDeadzone(raw.leftStickX, profile.deadzoneLeft)
            val ly = applyDeadzone(if (profile.invertYAxis) -raw.leftStickY else raw.leftStickY, profile.deadzoneLeft)
            val rx = applyDeadzone(raw.rightStickX, profile.deadzoneRight)
            val ry = applyDeadzone(if (profile.invertYAxis) -raw.rightStickY else raw.rightStickY, profile.deadzoneRight)

            // Decode button masks
            val pressed = mutableSetOf<ControllerButton>()
            for (btn in ControllerButton.values()) {
                if ((raw.buttonsMask and btn.mask) != 0) {
                    val mapped = profile.buttonRemappings[btn] ?: btn
                    pressed.add(mapped)
                }
            }

            val updated = current.copy(
                isConnected = raw.connected,
                batteryPercent = raw.batteryPercent,
                leftStick = StickPosition(lx, ly),
                rightStick = StickPosition(rx, ry),
                leftTrigger = raw.leftTrigger.coerceIn(0f, 1f),
                rightTrigger = raw.rightTrigger.coerceIn(0f, 1f),
                pressedButtons = pressed
            )
            controllers[i] = updated
        }
        _controllerStates.value = controllers.values.toList().sortedBy { it.playerIndex }
    }

    private fun applyDeadzone(value: Float, deadzone: Float): Float {
        return if (kotlin.math.abs(value) < deadzone) 0f else value
    }

    fun simulateInput(
        playerIndex: Int,
        lx: Float = 0f,
        ly: Float = 0f,
        rx: Float = 0f,
        ry: Float = 0f,
        lt: Float = 0f,
        rt: Float = 0f,
        buttons: Set<ControllerButton> = emptySet()
    ) {
        updateMockInput(playerIndex, lx, ly, rx, ry, lt, rt, buttons)
    }

    fun setStickDeadzone(deadzone: Float) {
        for (i in 0..1) {
            val prof = remapProfiles[i] ?: ControllerRemapProfile("Default")
            remapProfiles[i] = prof.copy(deadzoneLeft = deadzone, deadzoneRight = deadzone)
        }
    }

    fun getController(playerIndex: Int): ControllerState? = controllers[playerIndex]

    fun updateMockInput(
        playerIndex: Int,
        lx: Float = 0f,
        ly: Float = 0f,
        rx: Float = 0f,
        ry: Float = 0f,
        lt: Float = 0f,
        rt: Float = 0f,
        buttons: Set<ControllerButton> = emptySet()
    ) {
        val current = controllers[playerIndex] ?: return
        var mask = 0
        for (b in buttons) {
            mask = mask or b.mask
        }
        val updated = current.copy(
            leftStick = StickPosition(lx, ly),
            rightStick = StickPosition(rx, ry),
            leftTrigger = lt,
            rightTrigger = rt,
            pressedButtons = buttons
        )
        controllers[playerIndex] = updated
        _controllerStates.value = controllers.values.toList().sortedBy { it.playerIndex }
    }

    suspend fun setVibration(playerIndex: Int, leftMotor: Float, rightMotor: Float) {
        val ctrl = controllers[playerIndex] ?: return
        controllers[playerIndex] = ctrl.copy(
            hapticLeftIntensity = leftMotor,
            hapticRightIntensity = rightMotor
        )
        nativeBridge.sendHapticVibration(playerIndex, leftMotor, rightMotor)
    }

    suspend fun setLightbarColor(playerIndex: Int, colorHex: Long) {
        val ctrl = controllers[playerIndex] ?: return
        controllers[playerIndex] = ctrl.copy(rgbColorHex = colorHex)
        nativeBridge.setControllerRgb(playerIndex, colorHex.toInt())
        _controllerStates.value = controllers.values.toList().sortedBy { it.playerIndex }
    }

    fun setRemapProfile(playerIndex: Int, profile: ControllerRemapProfile) {
        remapProfiles[playerIndex] = profile
        val ctrl = controllers[playerIndex] ?: return
        controllers[playerIndex] = ctrl.copy(activeProfileName = profile.profileName)
        _controllerStates.value = controllers.values.toList().sortedBy { it.playerIndex }
        eventBus.post(ArcadiumEvent.ControllerRemapped(ctrl.controllerId, profile.profileName))
    }
}
