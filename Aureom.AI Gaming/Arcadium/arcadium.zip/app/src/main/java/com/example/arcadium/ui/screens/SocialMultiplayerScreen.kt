package com.example.arcadium.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.network.LobbyPrivacy
import com.example.arcadium.platform.ArcadiumPlatform
import com.example.arcadium.social.PresenceState
import com.example.arcadium.ui.components.ArcadiumButton
import com.example.arcadium.ui.components.ArcadiumPanel
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCrimson
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurface
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextDim
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary

@Composable
fun SocialMultiplayerScreen(platform: ArcadiumPlatform) {
    val lobbies by platform.multiplayerService.lobbies.collectAsState()
    val activeTicket by platform.multiplayerService.activeTicket.collectAsState()
    val friends by platform.friendsService.friendsList.collectAsState()
    val messages by platform.friendsService.messagesList.collectAsState()
    val networkStatus by platform.networkService.networkStatus.collectAsState()
    val activeUser by platform.accountManager.activeUser.collectAsState()

    var chatInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Network & Ping Radar Banner
        item {
            ArcadiumPanel(
                title = "Network Connectivity & Multiplayer Radar",
                badge = "${networkStatus.latencyMs}ms PING",
                accentColor = ArcadiumCyan
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = networkStatus.interfaceType,
                            style = MaterialTheme.typography.titleMedium,
                            color = ArcadiumTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "NAT Type: ${networkStatus.natType.name} • IP: ${networkStatus.ipAddress}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = ArcadiumTextSecondary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "DOWN: ${networkStatus.downloadSpeedMbps.toInt()} Mbps",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = ArcadiumCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "UP: ${networkStatus.uploadSpeedMbps.toInt()} Mbps",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = ArcadiumTextMuted
                        )
                    }
                }
            }
        }

        // Active Multiplayer Lobbies & Matchmaking
        item {
            ArcadiumPanel(
                title = "Multiplayer Lobbies (${lobbies.size} Available)",
                badge = "EU-WEST",
                accentColor = ArcadiumCyan
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (activeTicket != null) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, ArcadiumCyan, RoundedCornerShape(8.dp)),
                            color = ArcadiumSurfaceElevated
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "SEARCHING FOR RANKED MATCH...",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = ArcadiumCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Queue Ticket: ${activeTicket?.ticketId} • Cybernetic Albion",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = ArcadiumTextMuted
                                    )
                                }
                                ArcadiumButton(
                                    text = "CANCEL",
                                    onClick = { platform.multiplayerService.cancelMatchmaking() },
                                    isPrimary = false,
                                    accentColor = ArcadiumCrimson
                                )
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ArcadiumButton(
                                text = "START MATCHMAKING",
                                onClick = {
                                    platform.multiplayerService.startMatchmaking("game_cybernetic_albion", "Tactical Raid 4v4")
                                },
                                modifier = Modifier.weight(1f),
                                accentColor = ArcadiumCyan
                            )
                            ArcadiumButton(
                                text = "CREATE LOBBY",
                                onClick = {
                                    val user = activeUser?.userId ?: "usr_tom_001"
                                    platform.multiplayerService.createLobby(
                                        "game_cybernetic_albion",
                                        user,
                                        "Tom's Squad Room",
                                        4,
                                        LobbyPrivacy.PUBLIC_MATCHMAKING
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                isPrimary = false,
                                icon = Icons.Default.Add
                            )
                        }
                    }

                    // Lobby list
                    lobbies.forEach { lobby ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, ArcadiumBorderSubtle, RoundedCornerShape(8.dp)),
                            color = ArcadiumSurfaceCard
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = lobby.title,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = ArcadiumTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Players: ${lobby.currentPlayers.size}/${lobby.maxPlayers} • Ping: ${lobby.averagePingMs}ms • ${lobby.region}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = ArcadiumTextSecondary
                                    )
                                }
                                ArcadiumButton(
                                    text = "JOIN",
                                    onClick = {
                                        val user = activeUser?.userId ?: "usr_tom_001"
                                        platform.multiplayerService.joinLobby(lobby.lobbyId, user)
                                    },
                                    isPrimary = false,
                                    accentColor = ArcadiumCyan
                                )
                            }
                        }
                    }
                }
            }
        }

        // Friends Roster & Rich Presence
        item {
            ArcadiumPanel(
                title = "Friends & Rich Presence (${friends.count { it.presence != PresenceState.OFFLINE }} Online)",
                badge = "COMMUNITY",
                accentColor = ArcadiumEmerald
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    friends.forEach { friend ->
                        val (pColor, pText) = when (friend.presence) {
                            PresenceState.PLAYING -> ArcadiumEmerald to "Playing: ${friend.currentlyPlaying ?: "Game"}"
                            PresenceState.ONLINE -> ArcadiumCyan to "Online (Home Dashboard)"
                            PresenceState.AWAY -> ArcadiumGold to "Away"
                            PresenceState.DO_NOT_DISTURB -> ArcadiumCrimson to "Do Not Disturb"
                            PresenceState.OFFLINE -> ArcadiumTextMuted to "Offline"
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, ArcadiumBorderSubtle, RoundedCornerShape(8.dp)),
                            color = ArcadiumSurfaceCard
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(pColor)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = friend.displayName,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = ArcadiumTextPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${friend.gamerScore}G",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontFamily = FontFamily.Monospace,
                                                color = ArcadiumGold
                                            )
                                        }
                                        Text(
                                            text = pText,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = ArcadiumTextSecondary
                                        )
                                    }
                                }

                                ArcadiumButton(
                                    text = "INVITE",
                                    onClick = {
                                        val me = activeUser?.userId ?: "usr_tom_001"
                                        val myName = activeUser?.displayName ?: "Tom"
                                        platform.friendsService.sendGameInvite(
                                            me,
                                            myName,
                                            friend.userId,
                                            "game_cybernetic_albion",
                                            "Cybernetic Albion: 2088",
                                            "lob_albion_sq1"
                                        )
                                    },
                                    isPrimary = false,
                                    accentColor = ArcadiumCyan
                                )
                            }
                        }
                    }
                }
            }
        }

        // Direct Messaging & Game Chat
        item {
            ArcadiumPanel(
                title = "Direct Messaging & Chat",
                badge = "SECURE PROTOCOL",
                accentColor = ArcadiumGold
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    messages.forEach { msg ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ArcadiumObsidianBg)
                                .border(1.dp, ArcadiumBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = msg.senderDisplayName,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ArcadiumCyan,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Just now",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = ArcadiumTextMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.messageText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ArcadiumTextPrimary
                            )
                        }
                    }

                    // Input row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = chatInput,
                            onValueChange = { chatInput = it },
                            placeholder = { Text("Transmit message to squad...", color = ArcadiumTextMuted, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ArcadiumCyan,
                                unfocusedBorderColor = ArcadiumBorderSubtle,
                                focusedTextColor = ArcadiumTextPrimary,
                                unfocusedTextColor = ArcadiumTextPrimary,
                                focusedContainerColor = ArcadiumObsidianBg,
                                unfocusedContainerColor = ArcadiumObsidianBg
                            ),
                            singleLine = true
                        )
                        ArcadiumButton(
                            text = "SEND",
                            onClick = {
                                if (chatInput.isNotBlank()) {
                                    val user = activeUser?.userId ?: "usr_tom_001"
                                    val name = activeUser?.displayName ?: "Tom"
                                    platform.friendsService.sendMessage(user, name, "usr_elena_002", chatInput)
                                    chatInput = ""
                                }
                            },
                            accentColor = ArcadiumCyan,
                            icon = Icons.Default.Send
                        )
                    }
                }
            }
        }
    }
}
