package com.example.arcadium.settings

import com.example.arcadium.core.ArcadiumService
import com.example.arcadium.core.ServiceStatus
import com.example.arcadium.nativebridge.MockNativeBridge
import com.example.arcadium.nativebridge.NativeDisplayMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PowerProfile {
    PERFORMANCE_TURBO,
    BALANCED_STANDARD,
    QUIET_ECO
}

enum class FanCurveProfile {
    AGGRESSIVE_COOLING,
    BALANCED_INDUSTRIAL,
    WHISPER_SILENT
}

data class DisplaySettings(
    val resolution: String = "3840x2160 (4K UHD)",
    val refreshRateHz: Int = 120,
    val hdrEnabled: Boolean = true,
    val variableRefreshRate: Boolean = true,
    val rayTracingTier: String = "Ultra RT + Path Tracing"
)

data class AudioSettings(
    val masterVolume: Float = 0.85f,
    val spatialAudio3D: Boolean = true,
    val dolbyAtmosOutput: Boolean = true,
    val voiceChatNoiseSuppression: Boolean = true
)

data class SandboxSettings(
    val developerModeEnabled: Boolean = true,
    val strictPermissionEnforcement: Boolean = true,
    val unsignedSideloadAllowed: Boolean = true,
    val simulatedSlowDisk: Boolean = false
)

data class ConsoleSettings(
    val display: DisplaySettings = DisplaySettings(),
    val audio: AudioSettings = AudioSettings(),
    val sandbox: SandboxSettings = SandboxSettings(),
    val powerProfile: PowerProfile = PowerProfile.PERFORMANCE_TURBO,
    val fanProfile: FanCurveProfile = FanCurveProfile.BALANCED_INDUSTRIAL,
    val language: String = "English (UK)",
    val timeZone: String = "GMT / BST (London)"
)

class SettingsManager(
    private val nativeBridge: MockNativeBridge
) : ArcadiumService {

    override val serviceName: String = "ArcadiumSettingsService"
    private var serviceStatus: ServiceStatus = ServiceStatus.STOPPED

    private val _settings = MutableStateFlow(ConsoleSettings())
    val settings: StateFlow<ConsoleSettings> = _settings.asStateFlow()

    override suspend fun start() {
        serviceStatus = ServiceStatus.STARTING
        serviceStatus = ServiceStatus.RUNNING
    }

    override suspend fun stop() {
        serviceStatus = ServiceStatus.STOPPING
        serviceStatus = ServiceStatus.STOPPED
    }

    override fun status(): ServiceStatus = serviceStatus

    fun updateDisplaySettings(display: DisplaySettings) {
        _settings.value = _settings.value.copy(display = display)
        val w = if (display.resolution.contains("3840")) 3840 else 2560
        val h = if (display.resolution.contains("2160")) 2160 else 1440
        nativeBridge.setDisplayMode(
            NativeDisplayMode(
                width = w,
                height = h,
                refreshRateHz = display.refreshRateHz,
                hdrSupported = display.hdrEnabled,
                variableRefreshRate = display.variableRefreshRate
            )
        )
    }

    fun updateAudioSettings(audio: AudioSettings) {
        _settings.value = _settings.value.copy(audio = audio)
        nativeBridge.setMasterVolume(audio.masterVolume)
        nativeBridge.setSpatialAudioEnabled(audio.spatialAudio3D)
    }

    fun updateSandboxSettings(sandbox: SandboxSettings) {
        _settings.value = _settings.value.copy(sandbox = sandbox)
    }

    fun setPowerProfile(profile: PowerProfile) {
        _settings.value = _settings.value.copy(powerProfile = profile)
        nativeBridge.setPowerMode(profile == PowerProfile.PERFORMANCE_TURBO)
    }
}
