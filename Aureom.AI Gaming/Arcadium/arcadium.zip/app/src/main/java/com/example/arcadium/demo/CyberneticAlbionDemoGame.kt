package com.example.arcadium.demo

import com.example.arcadium.controller.ControllerButton
import com.example.arcadium.sdk.Arcadium
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

data class DemoGameState(
    val playerPositionX: Float = 0.0f,
    val playerPositionY: Float = 0.0f,
    val shieldPercent: Int = 100,
    val energyCore: Int = 100,
    val creditsCollected: Int = 4500,
    val activeSector: String = "Sector 07 - Westminster Neural Spire",
    val hostileUnitsEngaged: Int = 12,
    val comboMultiplier: Float = 3.5f,
    val currentMissionObjective: String = "Infiltrate Mainframe & Extract Quantum Core",
    val logMessages: List<String> = emptyList(),
    val isRunning: Boolean = false,
    val lastSaveStatus: String = "Mounted Slot 1 (Synced)"
)

/**
 * Functional Demonstration Game executing against the Arcadium SDK.
 */
class CyberneticAlbionDemoGame(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private val gameId = "game_cybernetic_albion"
    private val gameTitle = "Cybernetic Albion: 2088"

    private val _gameState = MutableStateFlow(DemoGameState())
    val gameState: StateFlow<DemoGameState> = _gameState.asStateFlow()

    private var gameLoopJob: Job? = null

    fun startDemoGame() {
        val sdk = Arcadium.get()
        val user = sdk.users.currentUser()
        addLog("BOOT: Cybernetic Albion Engine initialized for user ${user?.displayName ?: "Commander"}")
        addLog("SDK: Bound to Player 1 Tactile Controller & NVMe Save Partition")

        _gameState.value = _gameState.value.copy(isRunning = true)

        gameLoopJob?.cancel()
        gameLoopJob = scope.launch {
            // Pulse initial haptics on controller
            sdk.input.setHaptics(0, 0.5f, 0.8f)
            delay(120)
            sdk.input.setHaptics(0, 0f, 0f)
            sdk.input.setLightbar(0, 0xFF00FFCCL) // Cyan energy pulse

            var tick = 0
            while (isActive && _gameState.value.isRunning) {
                tick++
                val ctrl = sdk.input.getController(0)
                val lx = ctrl?.leftStick?.x ?: 0f
                val ly = ctrl?.leftStick?.y ?: 0f

                val cur = _gameState.value
                val newX = (cur.playerPositionX + (lx * 3.5f)).coerceIn(-100f, 100f)
                val newY = (cur.playerPositionY + (ly * 3.5f)).coerceIn(-100f, 100f)

                _gameState.value = cur.copy(
                    playerPositionX = newX,
                    playerPositionY = newY,
                    energyCore = (cur.energyCore - (if (tick % 20 == 0) 1 else 0)).coerceAtLeast(20)
                )

                // Send frame telemetry to Arcadium OS
                if (tick % 10 == 0) {
                    sdk.telemetry.recordCustomMetric(
                        gameId,
                        "EngineMetrics",
                        """{"drawCalls": 4210, "gpuParticles": 124000, "rayBounces": 4, "vramMb": 3840}"""
                    )
                }

                delay(50) // 20 FPS game simulation tick
            }
        }
    }

    fun stopDemoGame() {
        _gameState.value = _gameState.value.copy(isRunning = false)
        gameLoopJob?.cancel()
        addLog("SHUTDOWN: Cybernetic Albion session suspended.")
    }

    fun executePlayerAttack() {
        scope.launch {
            val sdk = Arcadium.get()
            val cur = _gameState.value
            val newScore = cur.creditsCollected + 250
            val enemies = cur.hostileUnitsEngaged + 1

            _gameState.value = cur.copy(
                creditsCollected = newScore,
                hostileUnitsEngaged = enemies,
                comboMultiplier = cur.comboMultiplier + 0.5f
            )

            sdk.input.setHaptics(0, 0.7f, 0.9f)
            delay(100)
            sdk.input.setHaptics(0, 0f, 0f)

            addLog("TACTICAL: Neural disruptor discharged. Hostile vanquished! (+250 Credits)")

            if (enemies >= 15) {
                // Unlock achievement via SDK
                val unlocked = sdk.achievements.unlock(gameId, "ach_albion_boss_flawless")
                if (unlocked) {
                    addLog("ACHIEVEMENT: 'Titan Vanquisher' (90G) unlocked via SDK!")
                }
            }
        }
    }

    fun executeSaveGame() {
        scope.launch {
            val sdk = Arcadium.get()
            val user = sdk.users.currentUser() ?: return@launch
            val cur = _gameState.value
            val payload = "SAVEDATA|POS_X=${cur.playerPositionX}|POS_Y=${cur.playerPositionY}|CREDITS=${cur.creditsCollected}|SECTOR=${cur.activeSector}".toByteArray()

            val save = sdk.saves.writeSave(
                gameId = gameId,
                userId = user.userId,
                slot = 1,
                title = "Westminster Spire Infiltration",
                subtitle = "Active Combat: ${cur.creditsCollected} Credits (v2.4)",
                playTimeSeconds = 8200,
                data = payload
            )

            _gameState.value = cur.copy(lastSaveStatus = "Saved Slot 1 (Ver ${save.version}) Checksum: ${save.checksum}")
            addLog("STORAGE: Game state written to sandboxed NVMe. Checksum: ${save.checksum}")
        }
    }

    fun capturePhoto() {
        scope.launch {
            val sdk = Arcadium.get()
            val cap = sdk.capture.takeScreenshot(gameId, gameTitle)
            addLog("CAPTURE: 4K HDR Frame grabbed and stored to /media/screenshots/${cap.captureId}.png")
        }
    }

    private fun addLog(msg: String) {
        val list = _gameState.value.logMessages.toMutableList()
        list.add(0, msg)
        if (list.size > 20) list.removeAt(list.lastIndex)
        _gameState.value = _gameState.value.copy(logMessages = list)
    }
}
