package com.example.arcadium.sdk

import com.example.arcadium.achievements.Achievement
import com.example.arcadium.achievements.AchievementManager
import com.example.arcadium.controller.ControllerButton
import com.example.arcadium.controller.ControllerState
import com.example.arcadium.controller.InputManager
import com.example.arcadium.games.ActiveGameSession
import com.example.arcadium.games.GameLauncher
import com.example.arcadium.media.CapturedMedia
import com.example.arcadium.media.MediaService
import com.example.arcadium.network.MultiplayerLobby
import com.example.arcadium.network.MultiplayerService
import com.example.arcadium.network.NetworkService
import com.example.arcadium.network.NetworkStatus
import com.example.arcadium.notifications.NotificationCategory
import com.example.arcadium.notifications.NotificationPriority
import com.example.arcadium.notifications.NotificationService
import com.example.arcadium.storage.ArcadiumStorageService
import com.example.arcadium.storage.GameSaveData
import com.example.arcadium.storage.SandboxManager
import com.example.arcadium.storage.SandboxPermission
import com.example.arcadium.storage.SaveDataManager
import com.example.arcadium.telemetry.ConsoleTelemetry
import com.example.arcadium.telemetry.TelemetryService
import com.example.arcadium.user.AccountManager
import com.example.arcadium.user.UserProfile
import kotlinx.coroutines.flow.StateFlow

/**
 * ARCADIUM DEVELOPER SDK — Primary Public API for Games and Applications.
 *
 * Game developers write against this unified facade without knowing native platform details.
 */
class Arcadium private constructor(
    private val accountManager: AccountManager,
    private val inputManager: InputManager,
    private val storageService: ArcadiumStorageService,
    private val saveDataManager: SaveDataManager,
    private val sandboxManager: SandboxManager,
    private val achievementManager: AchievementManager,
    private val notificationService: NotificationService,
    private val multiplayerService: MultiplayerService,
    private val networkService: NetworkService,
    private val mediaService: MediaService,
    private val telemetryService: TelemetryService,
    private val gameLauncher: GameLauncher
) {

    val users = UserApi()
    val input = InputApi()
    val storage = StorageApi()
    val saves = SaveApi()
    val achievements = AchievementApi()
    val multiplayer = MultiplayerApi()
    val notifications = NotificationApi()
    val capture = CaptureApi()
    val telemetry = TelemetryApi()
    val lifecycle = LifecycleApi()

    inner class UserApi {
        fun currentUser(): UserProfile? = accountManager.getActiveProfile()
        fun userState(): StateFlow<UserProfile?> = accountManager.activeUser
    }

    inner class InputApi {
        fun getController(playerIndex: Int = 0): ControllerState? = inputManager.getController(playerIndex)
        fun controllerStates(): StateFlow<List<ControllerState>> = inputManager.controllerStates
        suspend fun setHaptics(playerIndex: Int = 0, leftMotor: Float, rightMotor: Float) =
            inputManager.setVibration(playerIndex, leftMotor, rightMotor)
        suspend fun setLightbar(playerIndex: Int = 0, rgbColorHex: Long) =
            inputManager.setLightbarColor(playerIndex, rgbColorHex)
    }

    inner class StorageApi {
        suspend fun read(gameId: String, path: String): ByteArray {
            requirePermission(gameId, SandboxPermission.STORAGE_GAME)
            return storageService.readSandboxed(gameId, path)
        }

        suspend fun write(gameId: String, path: String, data: ByteArray) {
            requirePermission(gameId, SandboxPermission.STORAGE_GAME)
            storageService.writeSandboxed(gameId, path, data)
        }

        suspend fun exists(gameId: String, path: String): Boolean = storageService.existsSandboxed(gameId, path)
    }

    inner class SaveApi {
        suspend fun getSave(gameId: String, userId: String, slot: Int): GameSaveData? {
            requirePermission(gameId, SandboxPermission.STORAGE_SAVE)
            return saveDataManager.getSave(gameId, userId, slot)
        }

        suspend fun writeSave(
            gameId: String,
            userId: String,
            slot: Int,
            title: String,
            subtitle: String,
            playTimeSeconds: Long,
            data: ByteArray
        ): GameSaveData {
            requirePermission(gameId, SandboxPermission.STORAGE_SAVE)
            return saveDataManager.writeSave(gameId, userId, slot, title, subtitle, playTimeSeconds, data)
        }
    }

    inner class AchievementApi {
        suspend fun unlock(gameId: String, achievementId: String): Boolean {
            requirePermission(gameId, SandboxPermission.ACHIEVEMENTS)
            val user = accountManager.getActiveProfile()?.userId ?: "usr_guest"
            return achievementManager.unlock(gameId, achievementId, user)
        }

        fun updateProgress(gameId: String, achievementId: String, progress: Int): Boolean {
            requirePermission(gameId, SandboxPermission.ACHIEVEMENTS)
            val user = accountManager.getActiveProfile()?.userId ?: "usr_guest"
            return achievementManager.updateProgress(gameId, achievementId, user, progress)
        }

        fun getAchievements(gameId: String): List<Achievement> = achievementManager.getAchievementsForGame(gameId)
    }

    inner class MultiplayerApi {
        fun lobbies(): StateFlow<List<MultiplayerLobby>> = multiplayerService.lobbies
        fun networkStatus(): StateFlow<NetworkStatus> = networkService.networkStatus
        fun startMatchmaking(gameId: String, mode: String) {
            requirePermission(gameId, SandboxPermission.MULTIPLAYER)
            multiplayerService.startMatchmaking(gameId, mode)
        }
    }

    inner class NotificationApi {
        fun send(
            title: String,
            message: String,
            priority: NotificationPriority = NotificationPriority.NORMAL
        ) {
            notificationService.postNotification(
                title = title,
                message = message,
                priority = priority,
                category = NotificationCategory.GAME
            )
        }
    }

    inner class CaptureApi {
        suspend fun takeScreenshot(gameId: String, gameTitle: String): CapturedMedia {
            requirePermission(gameId, SandboxPermission.SCREEN_CAPTURE)
            val userId = accountManager.getActiveProfile()?.userId ?: "usr_guest"
            return mediaService.captureScreenshot(gameId, gameTitle, userId)
        }

        suspend fun recordClip(gameId: String, gameTitle: String, durationSecs: Int = 30): CapturedMedia {
            requirePermission(gameId, SandboxPermission.SCREEN_CAPTURE)
            val userId = accountManager.getActiveProfile()?.userId ?: "usr_guest"
            return mediaService.captureClip(gameId, gameTitle, userId, durationSecs)
        }
    }

    inner class TelemetryApi {
        fun stream(): StateFlow<ConsoleTelemetry> = telemetryService.telemetry
        fun recordCustomMetric(gameId: String, metricName: String, dataJson: String) {
            requirePermission(gameId, SandboxPermission.TELEMETRY)
            telemetryService.recordGameTelemetry(gameId, metricName, dataJson)
        }
    }

    inner class LifecycleApi {
        fun currentSession(): StateFlow<ActiveGameSession?> = gameLauncher.activeSession
        suspend fun requestExit(gameId: String) = gameLauncher.terminateGame(gameId)
    }

    private fun requirePermission(gameId: String, permission: SandboxPermission) {
        if (!sandboxManager.checkPermission(gameId, permission)) {
            // In dev mode, auto-grant or report
            sandboxManager.grantPermissions(gameId, setOf(permission))
        }
    }

    companion object {
        @Volatile
        private var instance: Arcadium? = null

        fun initialize(
            accountManager: AccountManager,
            inputManager: InputManager,
            storageService: ArcadiumStorageService,
            saveDataManager: SaveDataManager,
            sandboxManager: SandboxManager,
            achievementManager: AchievementManager,
            notificationService: NotificationService,
            multiplayerService: MultiplayerService,
            networkService: NetworkService,
            mediaService: MediaService,
            telemetryService: TelemetryService,
            gameLauncher: GameLauncher
        ): Arcadium {
            return instance ?: synchronized(this) {
                instance ?: Arcadium(
                    accountManager,
                    inputManager,
                    storageService,
                    saveDataManager,
                    sandboxManager,
                    achievementManager,
                    notificationService,
                    multiplayerService,
                    networkService,
                    mediaService,
                    telemetryService,
                    gameLauncher
                ).also { instance = it }
            }
        }

        fun get(): Arcadium = instance ?: throw IllegalStateException("Arcadium SDK has not been initialized")
    }
}
