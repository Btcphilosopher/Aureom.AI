package com.example.arcadium.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.arcadium.platform.ArcadiumPlatform
import com.example.arcadium.ui.components.ArcadiumButton
import com.example.arcadium.ui.components.ArcadiumPanel
import com.example.ui.theme.ArcadiumBorder
import com.example.ui.theme.ArcadiumBorderSubtle
import com.example.ui.theme.ArcadiumCrimson
import com.example.ui.theme.ArcadiumCyan
import com.example.ui.theme.ArcadiumEmerald
import com.example.ui.theme.ArcadiumGold
import com.example.ui.theme.ArcadiumObsidianBg
import com.example.ui.theme.ArcadiumSurfaceCard
import com.example.ui.theme.ArcadiumSurfaceElevated
import com.example.ui.theme.ArcadiumTextMuted
import com.example.ui.theme.ArcadiumTextPrimary
import com.example.ui.theme.ArcadiumTextSecondary
import kotlinx.coroutines.launch

@Composable
fun GameRunnerScreen(
    platform: ArcadiumPlatform,
    onExitGame: () -> Unit
) {
    val gameState by platform.demoGame.gameState.collectAsState()
    val activeSession by platform.gameLauncher.activeSession.collectAsState()
    val telemetry by platform.telemetryService.telemetry.collectAsState()
    val scope = rememberCoroutineScope()

    var stickDragX by remember { mutableStateOf(0f) }
    var stickDragY by remember { mutableStateOf(0f) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Active Session Status Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, ArcadiumBorderSubtle, RoundedCornerShape(10.dp)),
                color = ArcadiumSurfaceElevated
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(ArcadiumEmerald)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ACTIVE SESSION: ${activeSession?.game?.title ?: "Cybernetic Albion: 2088"}",
                                style = MaterialTheme.typography.labelMedium,
                                color = ArcadiumCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "Sandbox UID: ${activeSession?.sandboxDir ?: "/sandbox/game_cybernetic_albion"} • Profile: ${activeSession?.userId ?: "usr_tom_001"}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = ArcadiumTextMuted
                        )
                    }

                    ArcadiumButton(
                        text = "EXIT",
                        onClick = {
                            scope.launch {
                                platform.demoGame.stopDemoGame()
                                platform.gameLauncher.terminateGame("game_cybernetic_albion")
                                onExitGame()
                            }
                        },
                        isPrimary = false,
                        accentColor = ArcadiumCrimson,
                        icon = Icons.Default.ExitToApp
                    )
                }
            }
        }

        // Live Game Canvas Viewport
        item {
            ArcadiumPanel(
                title = "Cybernetic Albion — Neural Drone Viewport",
                badge = "${String.format("%.0f", telemetry.currentFps)} FPS / 4K HDR",
                accentColor = ArcadiumCyan
            ) {
                Column {
                    // HUD Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "TACTICAL SHIELD",
                                style = MaterialTheme.typography.labelSmall,
                                color = ArcadiumCyan,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "${gameState.shieldPercent}%",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                color = ArcadiumTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "QUANTUM CREDITS",
                                style = MaterialTheme.typography.labelSmall,
                                color = ArcadiumGold,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "${gameState.creditsCollected} CR",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                color = ArcadiumGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "HOSTILES PURGED",
                                style = MaterialTheme.typography.labelSmall,
                                color = ArcadiumCrimson,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "${gameState.hostileUnitsEngaged} (x${String.format("%.1f", gameState.comboMultiplier)})",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                color = ArcadiumTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Interactive Game Canvas (Vector 2D Display)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ArcadiumObsidianBg)
                            .border(1.dp, ArcadiumBorder, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragEnd = {
                                            stickDragX = 0f
                                            stickDragY = 0f
                                            platform.inputManager.simulateInput(
                                                playerIndex = 0,
                                                lx = 0f,
                                                ly = 0f,
                                                rx = 0f,
                                                ry = 0f,
                                                lt = 0f,
                                                rt = 0f,
                                                buttons = emptySet()
                                            )
                                        }
                                    ) { change, dragAmount ->
                                        change.consume()
                                        stickDragX = (stickDragX + dragAmount.x / 50f).coerceIn(-1f, 1f)
                                        stickDragY = (stickDragY + dragAmount.y / 50f).coerceIn(-1f, 1f)
                                        platform.inputManager.simulateInput(
                                            playerIndex = 0,
                                            lx = stickDragX,
                                            ly = stickDragY,
                                            rx = 0f,
                                            ry = 0f,
                                            lt = 0f,
                                            rt = 0f,
                                            buttons = emptySet()
                                        )
                                    }

                                }
                        ) {
                            val centerX = size.width / 2f
                            val centerY = size.height / 2f

                            // Draw radar grid lines
                            for (i in 1..4) {
                                drawCircle(
                                    color = ArcadiumBorder.copy(alpha = 0.5f),
                                    radius = (size.width / 8f) * i,
                                    center = Offset(centerX, centerY),
                                    style = Stroke(width = 1.dp.toPx())
                                )
                            }
                            drawLine(
                                color = ArcadiumBorder.copy(alpha = 0.5f),
                                start = Offset(0f, centerY),
                                end = Offset(size.width, centerY),
                                strokeWidth = 1.dp.toPx()
                            )
                            drawLine(
                                color = ArcadiumBorder.copy(alpha = 0.5f),
                                start = Offset(centerX, 0f),
                                end = Offset(centerX, size.height),
                                strokeWidth = 1.dp.toPx()
                            )

                            // Draw hostile nodes
                            drawCircle(
                                color = ArcadiumCrimson,
                                radius = 6.dp.toPx(),
                                center = Offset(centerX - 90f, centerY - 45f)
                            )
                            drawCircle(
                                color = ArcadiumCrimson,
                                radius = 8.dp.toPx(),
                                center = Offset(centerX + 120f, centerY + 30f)
                            )

                            // Draw Player Drone based on state position
                            val playerPos = Offset(
                                centerX + (gameState.playerPositionX * 1.2f),
                                centerY + (gameState.playerPositionY * 0.8f)
                            )

                            // Drone energy ring
                            drawCircle(
                                color = ArcadiumCyan.copy(alpha = 0.35f),
                                radius = 18.dp.toPx(),
                                center = playerPos
                            )
                            // Drone core
                            drawCircle(
                                color = ArcadiumCyan,
                                radius = 8.dp.toPx(),
                                center = playerPos
                            )
                        }

                        // Overlay instructions
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "TOUCH & DRAG TO STEER DRONE",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = ArcadiumTextMuted,
                                fontSize = 8.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "OBJECTIVE: ${gameState.currentMissionObjective}",
                        style = MaterialTheme.typography.labelMedium,
                        color = ArcadiumCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "SECTOR: ${gameState.activeSector}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArcadiumTextMuted
                    )
                }
            }
        }

        // Live SDK Action Panel
        item {
            ArcadiumPanel(
                title = "SDK Runtime Action Triggers",
                badge = "INTERACTIVE",
                accentColor = ArcadiumGold
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ArcadiumButton(
                            text = "ATTACK",
                            onClick = { platform.demoGame.executePlayerAttack() },
                            modifier = Modifier.weight(1f),
                            accentColor = ArcadiumCrimson,
                            icon = Icons.Default.FlashOn
                        )
                        ArcadiumButton(
                            text = "SAVE TO NVME",
                            onClick = { platform.demoGame.executeSaveGame() },
                            modifier = Modifier.weight(1f),
                            accentColor = ArcadiumEmerald,
                            icon = Icons.Default.Save
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ArcadiumButton(
                            text = "4K CAPTURE",
                            onClick = { platform.demoGame.capturePhoto() },
                            modifier = Modifier.weight(1f),
                            isPrimary = false,
                            icon = Icons.Default.CameraAlt
                        )
                        ArcadiumButton(
                            text = "HAPTICS",
                            onClick = {
                                scope.launch {
                                    platform.inputManager.setVibration(0, 0.8f, 0.9f)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            isPrimary = false,
                            icon = Icons.Default.Vibration
                        )
                    }

                    Text(
                        text = "LAST NVME SAVE STATUS: ${gameState.lastSaveStatus}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = ArcadiumTextSecondary,
                        modifier = Modifier.padding(top = 4.dp),
                        fontSize = 9.sp
                    )
                }
            }
        }

        // Live Console SDK Event Logs
        item {
            ArcadiumPanel(
                title = "In-Game SDK Event Log Stream",
                badge = "REALTIME",
                accentColor = ArcadiumCyan
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    gameState.logMessages.take(6).forEach { log ->
                        Text(
                            text = "> $log",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (log.contains("ACHIEVEMENT")) ArcadiumGold else if (log.contains("TACTICAL")) ArcadiumCyan else ArcadiumTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ArcadiumObsidianBg, RoundedCornerShape(4.dp))
                                .border(1.dp, ArcadiumBorder, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}
