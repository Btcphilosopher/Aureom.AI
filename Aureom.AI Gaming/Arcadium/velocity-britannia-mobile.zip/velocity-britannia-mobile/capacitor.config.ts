import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId:   'com.velocitybritannia.game',
  appName: 'Velocity Britannia',
  webDir:  'www',

  server: {
    androidScheme: 'https',
    cleartext: false,
  },

  // ── iOS ─────────────────────────────────────────────────────────
  ios: {
    contentInset:         'always',     // respect safe-area insets
    backgroundColor:      '#000000',
    preferredContentMode: 'mobile',
    // Landscape lock handled via Info.plist (see README)
    scrollEnabled:        false,
    allowsLinkPreview:    false,
  },

  // ── Android ─────────────────────────────────────────────────────
  android: {
    backgroundColor:       '#000000',
    allowMixedContent:     false,
    captureInput:          true,
    webContentsDebuggingEnabled: false,
    // Landscape lock handled via AndroidManifest.xml (see README)
  },

  plugins: {
    // Optionally add @capacitor/status-bar, @capacitor/screen-orientation
    // after running:  npm install @capacitor/status-bar @capacitor/screen-orientation
    // then: npx cap sync
  },
};

export default config;
