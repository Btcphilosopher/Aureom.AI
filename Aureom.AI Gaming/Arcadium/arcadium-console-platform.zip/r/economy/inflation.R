# Arcadium Econometrics Analysis - Currency Velocity & Gini Coefficient Calculation
# R script executed by Arcadium Analytics Engine

library(stats)

calculate_gini <- function(wallets_df) {
  balances <- sort(wallets_df$arc_balance)
  n <- length(balances)
  if (n == 0) return(0)
  
  index <- 1:n
  2 * sum(index * balances) / (n * sum(balances)) - (n + 1) / n
}

calculate_money_velocity <- function(transactions_df, m1_supply) {
  total_volume <- sum(transactions_df$amount_arc)
  if (m1_supply == 0) return(0)
  return(total_volume / m1_supply)
}

cat("[R-ANALYTICS] Econometrics analysis module ready.\n")
