import React, { useState } from 'react';
import { MatchmakingRequest, MatchSession, UserAccount } from '../types/arcadium';
import { Users, Radio, Globe, Shield, Activity, Plus, Play, RefreshCw } from 'lucide-react';

interface MultiplayerMatchmakerProps {
  users: UserAccount[];
  matches: MatchSession[];
  queue: MatchmakingRequest[];
  onQueuePlayer: (req: Omit<MatchmakingRequest, 'request_id' | 'queued_at'>) => void;
}

export const MultiplayerMatchmaker: React.FC<MultiplayerMatchmakerProps> = ({ users, matches, queue, onQueuePlayer }) => {
  const [selectedUser, setSelectedUser] = useState(users[0]?.user_id || 'usr-001');
  const [gameMode, setGameMode] = useState<'Casual' | 'Ranked' | 'Competitive 5v5'>('Competitive 5v5');
  const [region, setRegion] = useState('US-EAST');

  const handleEnqueue = () => {
    const usr = users.find(u => u.user_id === selectedUser);
    if (!usr) return;

    onQueuePlayer({
      user_id: usr.user_id,
      game_id: 'game-001',
      game_mode: gameMode,
      mmr: usr.mmr,
      region,
      party_size: 1,
      max_acceptable_latency_ms: 60
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Radio className="w-5 h-5 text-amber-400" />
            Multiplayer Matchmaking Engine & Regional Relays
          </h2>
          <p className="text-xs text-slate-400">
            MMR skill-based matching, latency-aware regional routing, dedicated server 128Hz tick rates
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
            Active Queue: <strong className="text-amber-400">{queue.length} players</strong>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
            Active Matches: <strong className="text-emerald-400">{matches.length} matches</strong>
          </div>
        </div>
      </div>

      {/* Main Grid: Matchmaking Queue Simulator & Active Matches */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Control Column: Enqueue Player Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
            <Plus className="w-4 h-4 text-indigo-400" />
            Enqueue Synthetic Match Request
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Select Player</label>
              <select
                value={selectedUser}
                onChange={e => setSelectedUser(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
              >
                {users.map(u => (
                  <option key={u.user_id} value={u.user_id}>
                    {u.display_name} (MMR: {u.mmr} - {u.rank_tier})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Game Mode</label>
              <select
                value={gameMode}
                onChange={e => setGameMode(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
              >
                <option value="Casual">Casual 4v4</option>
                <option value="Ranked">Ranked 3v3</option>
                <option value="Competitive 5v5">Competitive 5v5</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Preferred Data Center Region</label>
              <select
                value={region}
                onChange={e => setRegion(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
              >
                <option value="US-EAST">US-EAST (Virginia) - Ping ~12ms</option>
                <option value="EU-CENTRAL">EU-CENTRAL (Frankfurt) - Ping ~18ms</option>
                <option value="AP-EAST">AP-EAST (Tokyo) - Ping ~34ms</option>
                <option value="SA-EAST">SA-EAST (São Paulo) - Ping ~48ms</option>
              </select>
            </div>

            <button
              onClick={handleEnqueue}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded shadow transition cursor-pointer flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              <span>Submit to Matchmaker Queue</span>
            </button>
          </div>

          {/* Live Queue Inspection */}
          <div className="border-t border-slate-800 pt-4">
            <h4 className="text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">Queue Buffer ({queue.length})</h4>
            {queue.length === 0 ? (
              <p className="text-xs text-slate-500 italic">Queue is currently empty. Enqueue players to auto-form matches.</p>
            ) : (
              <div className="space-y-2 max-h-[200px] overflow-y-auto">
                {queue.map(q => (
                  <div key={q.request_id} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs font-mono flex items-center justify-between">
                    <div>
                      <span className="text-indigo-400 font-bold">{q.user_id}</span>
                      <span className="text-slate-500 text-[10px] block">{q.game_mode} | MMR: {q.mmr}</span>
                    </div>
                    <span className="text-amber-400 text-[10px]">{q.region}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Active Match Sessions Panel */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
              <Globe className="w-4 h-4 text-emerald-400" />
              Active Match Sessions ({matches.length})
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {matches.map(m => (
                <div key={m.session_id} className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200 text-xs font-mono">{m.session_id}</span>
                    <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] px-2 py-0.5 rounded">
                      {m.status}
                    </span>
                  </div>

                  <div className="text-xs text-slate-300 font-semibold">{m.game_title}</div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400 bg-slate-900/60 p-2 rounded">
                    <div>Server: <span className="text-slate-200">{m.server_id}</span></div>
                    <div>Region: <span className="text-amber-400">{m.region}</span></div>
                    <div>Tick Rate: <span className="text-emerald-400">{m.server_tick_rate} Hz</span></div>
                    <div>Avg Ping: <span className="text-cyan-400">{m.avg_latency_ms} ms</span></div>
                  </div>

                  {/* Player Roster */}
                  <div className="space-y-1 pt-1">
                    <div className="text-[10px] uppercase text-slate-500 font-bold">Player Roster ({m.players.length})</div>
                    {m.players.map((p, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs font-mono bg-slate-900 p-1.5 rounded">
                        <span className="text-slate-300">{p.user_id} (Team {p.team_id})</span>
                        <span className="text-emerald-400">{p.score} pts | {p.latency_ms}ms</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
