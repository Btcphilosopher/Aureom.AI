import React from 'react';
import { ShieldCheck, Cpu, Terminal, Radio, Activity, Zap, Play } from 'lucide-react';
import { SimulationStats } from '../types/arcadium';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  simStats: SimulationStats;
  onOpenSimulation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, simStats, onOpenSimulation }) => {
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'consoles', label: 'Console OS & Identity' },
    { id: 'multiplayer', label: 'Multiplayer & Matchmaker' },
    { id: 'economy', label: 'Economy & NFTs' },
    { id: 'catalog', label: 'Catalog & Cloud Saves' },
    { id: 'analytics', label: 'R Analytics Engine' },
    { id: 'anticheat', label: 'Anti-Cheat & Security' },
    { id: 'developer', label: 'Developer SDK & API' },
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-50 text-slate-100">
      {/* Top Banner Status Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between text-xs border-b border-slate-900 bg-slate-950/80">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5 font-bold tracking-wider text-indigo-400">
            <Zap className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
            <span>ARCADIUM PLATFORM OS</span>
            <span className="bg-indigo-950 text-indigo-300 border border-indigo-700/60 px-1.5 py-0.5 rounded text-[10px]">
              v4.2.0-LTS
            </span>
          </div>
          <div className="hidden md:flex items-center space-x-3 text-slate-400 border-l border-slate-800 pl-3">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              Rust Core: <strong className="text-emerald-400">ACTIVE</strong>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cyan-500"></span>
              R Engine: <strong className="text-cyan-400">CONNECTED</strong>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-500"></span>
              PostgreSQL: <strong className="text-purple-300">CLUSTER-OK</strong>
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="hidden lg:flex items-center space-x-3 text-slate-300 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800">
            <span>Latency: <strong className="text-emerald-400">{simStats.avg_latency_ms} ms</strong></span>
            <span className="text-slate-600">|</span>
            <span>Sim Players: <strong className="text-amber-400">{simStats.active_simulated_players.toLocaleString()}</strong></span>
            <span className="text-slate-600">|</span>
            <span>TPS: <strong className="text-cyan-400">{simStats.telemetry_events_per_sec.toLocaleString()}</strong></span>
          </div>

          <button
            onClick={onOpenSimulation}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold px-3 py-1 rounded shadow text-xs transition cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>Load Simulation</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 flex items-center overflow-x-auto no-scrollbar scroll-smooth">
        <nav className="flex space-x-1 py-1">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3.5 py-2.5 text-xs font-medium rounded-t-md whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-amber-400 border-b-2 border-amber-400 font-semibold shadow-inner'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
