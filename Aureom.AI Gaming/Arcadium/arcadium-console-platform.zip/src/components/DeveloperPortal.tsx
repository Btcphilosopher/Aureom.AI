import React, { useState } from 'react';
import { Terminal, Code, Cpu, Play, Copy, Check, FileText, Server, ExternalLink } from 'lucide-react';

export const DeveloperPortal: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'sdk' | 'api' | 'repo'>('sdk');
  const [selectedLanguage, setSelectedLanguage] = useState<'Rust' | 'Cpp' | 'CSharp' | 'Unreal'>('Rust');
  const [copied, setCopied] = useState(false);
  const [apiEndpoint, setApiEndpoint] = useState('/api/v1/health');
  const [apiResult, setApiResult] = useState<string | null>(null);

  const sdkCodeSnippets: Record<string, string> = {
    Rust: `// Arcadium Developer SDK (Rust)
use arcadium_client::{ArcadiumClient, ArcadiumIdentity, ArcadiumMultiplayer};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = ArcadiumClient::builder()
        .api_key("arc_live_99f82a1728c0912")
        .region("US-EAST")
        .build()?;

    // Authenticate Console Session
    let session = client.identity().authenticate_device().await?;
    println!("Console Authenticated: {}", session.console_id);

    // Enqueue for 5v5 Competitive Matchmaking
    let match_req = client.multiplayer().queue_matchmaker("Competitive 5v5").await?;
    println!("Match Request ID: {}", match_req.request_id);

    Ok(())
}`,
    Cpp: `// Arcadium Developer SDK (C++20 Native Engine Integration)
#include <arcadium/arcadium.hpp>

int main() {
    arcadium::Client client("arc_live_99f82a1728c0912", arcadium::Region::US_EAST);
    
    auto session = client.Identity().AuthenticateDevice();
    std::cout << "Console ID: " << session.ConsoleId() << std::endl;

    client.Telemetry().LogEvent("GAME_STARTED", {{"map", "Eclipse_Arena"}, {"fps", 120}});
    return 0;
}`,
    CSharp: `// Arcadium Developer SDK (C# / Unity)
using Arcadium.SDK;
using System.Threading.Tasks;

public class ArcadiumManager : MonoBehaviour {
    private async void Start() {
        var client = new ArcadiumClient("arc_live_99f82a1728c0912");
        var session = await client.Identity.AuthenticateDeviceAsync();
        Debug.Log($"Arcadium Device Authenticated: {session.ConsoleId}");
    }
}`,
    Unreal: `// Arcadium Unreal Engine 5 Plugin C++ Header
#pragma once
#include "CoreMinimal.h"
#include "ArcadiumClient.h"

UCLASS()
class ARCADIUM_API UArcadiumSubsystem : public UGameInstanceSubsystem {
    GENERATED_BODY()
public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    void SubmitMatchTelemetry(FString EventName, float FrameTimeMs);
};`
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(sdkCodeSnippets[selectedLanguage]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTestApi = async () => {
    try {
      const res = await fetch(apiEndpoint);
      const data = await res.json();
      setApiResult(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setApiResult(JSON.stringify({ error: err.message }, null, 2));
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Code className="w-5 h-5 text-indigo-400" />
            Developer Platform & Native SDK Studio
          </h2>
          <p className="text-xs text-slate-400">
            Native game integration SDKs, live REST API reference explorer, and Rust/R workspace code inspect
          </p>
        </div>

        {/* Subtabs */}
        <div className="flex space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setActiveSubTab('sdk')}
            className={`px-3 py-1.5 rounded transition cursor-pointer ${activeSubTab === 'sdk' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            SDK Code Generator
          </button>
          <button
            onClick={() => setActiveSubTab('api')}
            className={`px-3 py-1.5 rounded transition cursor-pointer ${activeSubTab === 'api' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Live REST API Tester
          </button>
          <button
            onClick={() => setActiveSubTab('repo')}
            className={`px-3 py-1.5 rounded transition cursor-pointer ${activeSubTab === 'repo' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Rust / R Source Inspect
          </button>
        </div>
      </div>

      {/* Subtab 1: SDK Code Generator */}
      {activeSubTab === 'sdk' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex space-x-2">
              {(['Rust', 'Cpp', 'CSharp', 'Unreal'] as const).map(lang => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1.5 rounded text-xs font-mono transition cursor-pointer ${
                    selectedLanguage === lang ? 'bg-indigo-900 border border-indigo-500 text-indigo-200' : 'bg-slate-950 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {lang === 'Cpp' ? 'C++' : lang === 'CSharp' ? 'C# / Unity' : lang}
                </button>
              ))}
            </div>

            <button
              onClick={handleCopyCode}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-3 py-1.5 rounded transition flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy SDK Snippet'}</span>
            </button>
          </div>

          <pre className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs text-indigo-300 font-mono overflow-x-auto leading-relaxed">
            <code>{sdkCodeSnippets[selectedLanguage]}</code>
          </pre>
        </div>
      )}

      {/* Subtab 2: Live REST API Tester */}
      {activeSubTab === 'api' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          <div className="flex items-center space-x-2">
            <select
              value={apiEndpoint}
              onChange={e => setApiEndpoint(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 text-xs font-mono rounded px-3 py-2 flex-grow"
            >
              <option value="/api/v1/health">GET /api/v1/health (Platform Health Check)</option>
              <option value="/api/v1/consoles">GET /api/v1/consoles (Registered Consoles)</option>
              <option value="/api/v1/games">GET /api/v1/games (Game Catalog)</option>
              <option value="/api/v1/telemetry">GET /api/v1/telemetry (Live Telemetry Stream)</option>
              <option value="/api/v1/analytics/r">GET /api/v1/analytics/r (R Econometrics & Analytics)</option>
              <option value="/api/v1/simulation">GET /api/v1/simulation (Synthetic Load Metrics)</option>
            </select>

            <button
              onClick={handleTestApi}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2 rounded shadow transition cursor-pointer flex items-center gap-1.5"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Send Request</span>
            </button>
          </div>

          {apiResult && (
            <pre className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs text-emerald-400 font-mono overflow-x-auto max-h-[400px]">
              <code>{apiResult}</code>
            </pre>
          )}
        </div>
      )}

      {/* Subtab 3: Source Code Inspector */}
      {activeSubTab === 'repo' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
            <Server className="w-4 h-4 text-cyan-400" />
            Physical Repository Source Code Directory Structure
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-amber-400 font-bold mb-1">/arcadium/ (Rust Core)</div>
              <div className="text-slate-400">├── Cargo.toml</div>
              <div className="text-slate-400">└── crates/</div>
              <div className="text-slate-500 pl-4">├── arcadium-core</div>
              <div className="text-slate-500 pl-4">├── arcadium-identity</div>
              <div className="text-slate-500 pl-4">├── arcadium-multiplayer</div>
              <div className="text-slate-500 pl-4">├── arcadium-economy</div>
              <div className="text-slate-500 pl-4">└── arcadium-server/main.rs</div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-cyan-400 font-bold mb-1">/r/ (Analytics Engine)</div>
              <div className="text-slate-400">└── analytics/</div>
              <div className="text-slate-500 pl-4">├── retention.R</div>
              <div className="text-slate-500 pl-4">├── inflation.R</div>
              <div className="text-slate-500 pl-4">├── mmr_distribution.R</div>
              <div className="text-slate-500 pl-4">└── anticheat_model.R</div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-purple-400 font-bold mb-1">/database/ & /infrastructure/</div>
              <div className="text-slate-400">├── migrations/</div>
              <div className="text-slate-500 pl-4">└── 0001_initial_schema.sql</div>
              <div className="text-slate-400">└── docker/</div>
              <div className="text-slate-500 pl-4">└── Dockerfile.rust</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
