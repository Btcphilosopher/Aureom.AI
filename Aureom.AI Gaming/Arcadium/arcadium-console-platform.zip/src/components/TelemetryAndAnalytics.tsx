import React, { useState } from 'react';
import { RAnalyticsResult } from '../types/arcadium';
import { Terminal, Activity, TrendingUp, BarChart3, PieChart, ShieldAlert, Play, Code, Cpu } from 'lucide-react';

interface TelemetryAndAnalyticsProps {
  rResult: RAnalyticsResult;
  onExecuteRScript: (script: string) => { output: string; plotData?: any[] };
}

export const TelemetryAndAnalytics: React.FC<TelemetryAndAnalyticsProps> = ({ rResult, onExecuteRScript }) => {
  const [rScriptCode, setRScriptCode] = useState(`# Arcadium R Telemetry & Econometrics Analysis
library(stats)

# 1. Fit Kaplan-Meier Cohort Retention Survival Curve
retention_df <- data.frame(
  day = c(1, 3, 7, 14, 30),
  retention_pct = c(78.4, 68.2, 54.2, 46.1, 38.9)
)

# 2. Calculate Gini Wealth Coefficient for $ARC Currency
calculate_gini(wallets_df)
cat("R Analysis Execution Completed Successfully.\\n")`);

  const [consoleOutput, setConsoleOutput] = useState<string | null>(null);
  const [plotData, setPlotData] = useState<any[] | null>([
    { day: 1, retention: 78.4 },
    { day: 3, retention: 68.2 },
    { day: 7, retention: 54.2 },
    { day: 14, retention: 46.1 },
    { day: 30, retention: 38.9 }
  ]);

  const handleRunR = () => {
    const res = onExecuteRScript(rScriptCode);
    setConsoleOutput(res.output);
    if (res.plotData) setPlotData(res.plotData);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-cyan-400" />
            R Quantitative Analytics Engine & Econometrics
          </h2>
          <p className="text-xs text-slate-400">
            Statistical modeling, retention survival curves, Gini wealth distribution, MMR Gaussian fitting & anomaly detection
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="bg-cyan-950 border border-cyan-800 text-cyan-300 px-3 py-1.5 rounded">
            R Engine Version: <strong>4.3.2-Console-Analytics</strong>
          </span>
        </div>
      </div>

      {/* Analytical KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Gini Wealth Coefficient ($ARC)</div>
          <div className="text-2xl font-extrabold text-amber-400 mt-2 font-mono">{rResult.gini_coefficient}</div>
          <p className="text-[11px] text-slate-500 mt-1">Balanced economy inequality index (&lt; 0.40 optimal)</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">30-Day Player Retention</div>
          <div className="text-2xl font-extrabold text-emerald-400 mt-2 font-mono">{rResult.retention_30d_pct}%</div>
          <p className="text-[11px] text-slate-500 mt-1">Kaplan-Meier cohort survival rate</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Money Velocity ($ARC)</div>
          <div className="text-2xl font-extrabold text-cyan-400 mt-2 font-mono">{rResult.money_velocity} <span className="text-xs font-normal">tx/day</span></div>
          <p className="text-[11px] text-slate-500 mt-1">M1 supply turnover frequency</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Fraud Anomaly Score</div>
          <div className="text-2xl font-extrabold text-rose-400 mt-2 font-mono">{rResult.fraud_anomaly_detection_score}</div>
          <p className="text-[11px] text-slate-500 mt-1">Isolation forest anomaly probability</p>
        </div>
      </div>

      {/* Main R Workbench Split View: Code Editor & Execution Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left R Code Editor Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Code className="w-4 h-4 text-cyan-400" />
              R Script Analytics Workbench
            </h3>
            <button
              onClick={handleRunR}
              className="bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs px-3.5 py-1.5 rounded shadow transition cursor-pointer flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-slate-950" />
              <span>Execute R Script</span>
            </button>
          </div>

          <textarea
            value={rScriptCode}
            onChange={e => setRScriptCode(e.target.value)}
            rows={10}
            className="w-full bg-slate-950 text-cyan-300 font-mono text-xs p-3 rounded border border-slate-800 focus:outline-none focus:border-cyan-500 leading-relaxed"
          />

          {consoleOutput && (
            <div className="bg-slate-950 border border-slate-800 p-3 rounded text-xs font-mono text-slate-300 whitespace-pre-line leading-relaxed">
              {consoleOutput}
            </div>
          )}
        </div>

        {/* Right Plot / Statistical Visualization Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
            <BarChart3 className="w-4 h-4 text-amber-400" />
            Generated R Statistical Plot Output
          </h3>

          {plotData ? (
            <div className="space-y-3">
              <div className="text-xs text-slate-400 font-mono">Statistical Cohort Distribution Plot:</div>
              <div className="space-y-2 bg-slate-950 p-4 rounded border border-slate-800">
                {plotData.map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono text-slate-300">
                      <span>{item.day ? `Day ${item.day}` : item.percentile || item.region}</span>
                      <span className="text-cyan-400 font-bold">{item.retention ? `${item.retention}%` : item.wealth_share ? `${item.wealth_share}%` : `${item.latency_p50}ms`}</span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                      <div
                        className="bg-cyan-500 h-full rounded transition-all duration-500"
                        style={{ width: `${item.retention || item.wealth_share || item.latency_p50}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-500 italic p-6 text-center">Execute R script to render statistical plots.</div>
          )}
        </div>
      </div>
    </div>
  );
};
