import React, { useState } from 'react';
import { SimulationStats } from '../types/arcadium';
import { Play, Activity, Users, Cpu, ShieldCheck, Zap, X } from 'lucide-react';

interface SimulationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  simStats: SimulationStats;
  onSetSimulationTarget: (target: number) => void;
}

export const SimulationPanel: React.FC<SimulationPanelProps> = ({
  isOpen,
  onClose,
  simStats,
  onSetSimulationTarget,
}) => {
  const [selectedTarget, setSelectedTarget] = useState(simStats.active_simulated_players);

  if (!isOpen) return null;

  const handleApply = (target: number) => {
    setSelectedTarget(target);
    onSetSimulationTarget(target);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-2xl shadow-2xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400 fill-amber-400" />
            <h2 className="text-base font-bold text-slate-100">Synthetic Load & High-Concurrency Load Simulator</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preset Load Buttons */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Select Concurrent Player Scale Target</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[1000, 10000, 100000, 1000000].map(scale => (
              <button
                key={scale}
                onClick={() => handleApply(scale)}
                className={`py-3 px-4 rounded-xl border text-xs font-mono font-bold transition cursor-pointer flex flex-col items-center gap-1 ${
                  selectedTarget === scale
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <span>{scale.toLocaleString()} PLAYERS</span>
                <span className="text-[10px] font-normal opacity-80">
                  {scale === 1000 ? 'Local Dev' : scale === 10000 ? 'Mid Surge' : scale === 100000 ? 'Major Launch' : 'Global Peak'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Real-time Telemetry Metrics Output */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-slate-500 text-[10px]">Requests / Sec</div>
            <div className="text-amber-400 font-bold text-base mt-1">{simStats.requests_per_sec.toLocaleString()}</div>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-slate-500 text-[10px]">Matchmaking Matches / Sec</div>
            <div className="text-emerald-400 font-bold text-base mt-1">{simStats.matchmaking_matches_per_sec.toLocaleString()}</div>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-slate-500 text-[10px]">Telemetry Ingest / Sec</div>
            <div className="text-cyan-400 font-bold text-base mt-1">{simStats.telemetry_events_per_sec.toLocaleString()}</div>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-slate-500 text-[10px]">Database Tx / Sec</div>
            <div className="text-indigo-400 font-bold text-base mt-1">{simStats.database_tx_per_sec.toLocaleString()}</div>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-slate-500 text-[10px]">Average Latency</div>
            <div className="text-slate-200 font-bold text-base mt-1">{simStats.avg_latency_ms} ms</div>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-slate-500 text-[10px]">p99 Tail Latency</div>
            <div className="text-purple-400 font-bold text-base mt-1">{simStats.p99_latency_ms} ms</div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-5 py-2 rounded text-xs transition cursor-pointer"
          >
            Close Simulator
          </button>
        </div>
      </div>
    </div>
  );
};
