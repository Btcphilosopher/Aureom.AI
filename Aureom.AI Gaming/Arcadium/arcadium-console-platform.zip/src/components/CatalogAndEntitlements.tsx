import React, { useState } from 'react';
import { CloudSaveData, DigitalEntitlement, GameCatalogItem, UserAccount } from '../types/arcadium';
import { ShoppingBag, Cloud, CheckCircle2, ShieldCheck, FileCode, ArrowUpRight, RotateCcw } from 'lucide-react';

interface CatalogAndEntitlementsProps {
  games: GameCatalogItem[];
  users: UserAccount[];
  entitlements: DigitalEntitlement[];
  onExecutePurchase: (userId: string, gameId: string) => void;
  onSaveCloudData: (userId: string, gameId: string, slotIndex: number, fileName: string, sizeBytes: number) => void;
}

export const CatalogAndEntitlements: React.FC<CatalogAndEntitlementsProps> = ({
  games,
  users,
  entitlements,
  onExecutePurchase,
  onSaveCloudData,
}) => {
  const [selectedUser, setSelectedUser] = useState(users[0]?.user_id || 'usr-001');
  const [purchaseStatus, setPurchaseStatus] = useState<string | null>(null);

  const handleBuy = (gameId: string) => {
    onExecutePurchase(selectedUser, gameId);
    setPurchaseStatus(`[PURCHASE CONFIRMED] Atomic entitlement granted for ${gameId} to user ${selectedUser}. Audit record stored in Postgres transactions ledger.`);
    setTimeout(() => setPurchaseStatus(null), 5000);
  };

  const handleSyncSave = (gameId: string) => {
    onSaveCloudData(selectedUser, gameId, 0, 'game_checkpoint_autosave.sav', 4812900);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-indigo-400" />
            Game Catalog, Digital Entitlements & Cloud Saves
          </h2>
          <p className="text-xs text-slate-400">
            Publisher game registry, atomic purchase fulfillment, SHA-256 cloud save versioning and conflict resolution
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <label className="text-slate-400">Active Test User Account:</label>
          <select
            value={selectedUser}
            onChange={e => setSelectedUser(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-200 font-mono"
          >
            {users.map(u => (
              <option key={u.user_id} value={u.user_id}>{u.display_name} ({u.user_id})</option>
            ))}
          </select>
        </div>
      </div>

      {purchaseStatus && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-300 text-xs p-4 rounded-xl font-mono shadow-lg flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{purchaseStatus}</span>
        </div>
      )}

      {/* Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {games.map(game => {
          const isEntitled = entitlements.some(e => e.user_id === selectedUser && e.game_id === game.game_id);

          return (
            <div key={game.game_id} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg flex flex-col justify-between group hover:border-slate-700 transition">
              <div>
                <div className="h-40 bg-slate-950 relative overflow-hidden">
                  <img src={game.cover_image} alt={game.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                  <div className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur border border-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded font-mono">
                    {game.age_rating}
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="text-sm font-bold text-slate-100">{game.title}</h3>
                  <div className="text-[11px] text-slate-400">
                    Publisher: <span className="text-slate-300">{game.publisher}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Build Version: <span className="text-cyan-400 font-mono">{game.current_version}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 pt-0 border-t border-slate-800/60 mt-2 space-y-3">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-amber-400 font-bold">{game.price_arc} $ARC</span>
                  <span className="text-slate-400">${game.price_usd} USD</span>
                </div>

                {isEntitled ? (
                  <div className="space-y-2">
                    <div className="w-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-xs py-2 rounded text-center flex items-center justify-center gap-1.5">
                      <ShieldCheck className="w-4 h-4" />
                      <span>OWNED (ENTITLEMENT ACTIVE)</span>
                    </div>
                    <button
                      onClick={() => handleSyncSave(game.game_id)}
                      className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs py-1.5 rounded transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Upload Cloud Save Checkpoint</span>
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleBuy(game.game_id)}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2 rounded shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Purchase Entitlement</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
