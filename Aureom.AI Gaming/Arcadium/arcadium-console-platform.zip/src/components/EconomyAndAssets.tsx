import React, { useState } from 'react';
import { DigitalAssetNFT, TransactionRecord, UserAccount, Wallet } from '../types/arcadium';
import { Coins, Wallet as WalletIcon, ShieldCheck, Sparkles, Key, CheckCircle, ExternalLink } from 'lucide-react';

interface EconomyAndAssetsProps {
  users: UserAccount[];
  wallets: Map<string, Wallet>;
  transactions: TransactionRecord[];
  digitalAssets: DigitalAssetNFT[];
  onMintAsset: (asset: Omit<DigitalAssetNFT, 'asset_id' | 'creation_time' | 'on_chain_tx_hash' | 'on_chain_verified'>) => void;
}

export const EconomyAndAssets: React.FC<EconomyAndAssetsProps> = ({
  users,
  transactions,
  digitalAssets,
  onMintAsset,
}) => {
  const [selectedUser, setSelectedUser] = useState(users[0]?.user_id || 'usr-001');
  const [assetName, setAssetName] = useState('Founders Dragon Armour');
  const [rarity, setRarity] = useState<DigitalAssetNFT['rarity']>('LEGENDARY');
  const [chain, setChain] = useState<DigitalAssetNFT['blockchain_network']>('ARCADIUM_SUBNET');

  const handleMint = (e: React.FormEvent) => {
    e.preventDefault();
    onMintAsset({
      game_id: 'game-001',
      collection_name: 'Aetherfall Legendary Relics',
      token_id: Math.floor(Math.random() * 9000 + 1000).toString(),
      metadata_uri: `ipfs://QmArcadiumMintedAsset_${Date.now()}`,
      owner_user_id: selectedUser,
      owner_wallet_address: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
      blockchain_network: chain,
      rarity,
      attributes: { PowerBoost: '+50%', ArmorRating: '120', Effect: 'Void Sparkles' }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400" />
            Digital Economy, Wallets & Blockchain NFT Layer
          </h2>
          <p className="text-xs text-slate-400">
            Atomic $ARC ledger transactions, multi-chain NFT digital assets, and zero-double-spend invariant enforcement
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-xs font-mono text-cyan-300">
          Total On-Chain Assets: <strong>{digitalAssets.length} NFTs</strong>
        </div>
      </div>

      {/* Main Grid: Wallets & Minting Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Player Wallets */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
            <WalletIcon className="w-4 h-4 text-indigo-400" />
            Platform Wallets & Ledger Balances
          </h3>

          <div className="space-y-3">
            {users.map(u => (
              <div key={u.user_id} className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{u.display_name}</span>
                  <span className="text-slate-500 font-mono text-[10px]">{u.user_id}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono pt-1">
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <div className="text-[10px] text-slate-500">$ARC</div>
                    <div className="text-amber-400 font-bold mt-0.5">1,500</div>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <div className="text-[10px] text-slate-500">Gems</div>
                    <div className="text-cyan-400 font-bold mt-0.5">320</div>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <div className="text-[10px] text-slate-500">Gold</div>
                    <div className="text-emerald-400 font-bold mt-0.5">15,000</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Center/Right Column: NFT Assets & Minting Sandbox */}
        <div className="lg:col-span-2 space-y-6">
          {/* Minting Sandbox */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
              <Sparkles className="w-4 h-4 text-amber-400" />
              NFT Digital Asset Minting Sandbox
            </h3>

            <form onSubmit={handleMint} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Target Owner</label>
                <select
                  value={selectedUser}
                  onChange={e => setSelectedUser(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
                >
                  {users.map(u => (
                    <option key={u.user_id} value={u.user_id}>{u.display_name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Rarity Class</label>
                <select
                  value={rarity}
                  onChange={e => setRarity(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
                >
                  <option value="RARE">RARE</option>
                  <option value="EPIC">EPIC</option>
                  <option value="LEGENDARY">LEGENDARY</option>
                  <option value="MYTHIC">MYTHIC</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Blockchain Network</label>
                <select
                  value={chain}
                  onChange={e => setChain(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
                >
                  <option value="ARCADIUM_SUBNET">ARCADIUM Subnet (Zero Gas)</option>
                  <option value="SOLANA_MAINNET">Solana Mainnet</option>
                  <option value="ETHEREUM_L2">Ethereum L2 (Arbitrum/Optimism)</option>
                </select>
              </div>

              <div className="sm:col-span-3 flex justify-end pt-2">
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded shadow transition cursor-pointer flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Execute On-Chain Asset Mint</span>
                </button>
              </div>
            </form>
          </div>

          {/* NFT Asset List */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
              <Key className="w-4 h-4 text-cyan-400" />
              Verified On-Chain Digital Assets ({digitalAssets.length})
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {digitalAssets.map(asset => (
                <div key={asset.asset_id} className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-400 text-xs font-mono">{asset.collection_name} #{asset.token_id}</span>
                    <span className="bg-purple-950 text-purple-300 border border-purple-800 text-[10px] px-2 py-0.5 rounded font-bold">
                      {asset.rarity}
                    </span>
                  </div>

                  <div className="text-xs text-slate-400 font-mono">
                    Owner: <span className="text-slate-200">{asset.owner_user_id}</span>
                  </div>

                  <div className="bg-slate-900 p-2.5 rounded text-[11px] font-mono text-slate-400 space-y-1">
                    <div>Chain: <span className="text-cyan-400">{asset.blockchain_network}</span></div>
                    <div className="truncate">Tx: <span className="text-slate-500">{asset.on_chain_tx_hash}</span></div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-emerald-400 pt-1">
                    <span className="flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Server Authoritative Verification
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
