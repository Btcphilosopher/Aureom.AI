import React from 'react';
import { ConsoleDevice, MatchSession, SimulationStats, TelemetryEvent } from '../types/arcadium';
import { Activity, Server, Users, ShieldCheck, Database, Cpu, Globe, Radio, TrendingUp, Layers, HardDrive } from 'lucide-react';

interface OverviewDashboardProps {
  consoles: ConsoleDevice[];
  matches: MatchSession[];
  telemetry: TelemetryEvent[];
  simStats: SimulationStats;
  onNavigateTab: (tab: string) => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  consoles,
  matches,
  telemetry,
  simStats,
  onNavigateTab,
}) => {
  return (
    <div className="space-y-6">
      {/* Top Banner KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition">
            <Users className="w-16 h-16 text-indigo-400" />
          </div>
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Concurrent Players</div>
          <div className="text-3xl font-extrabold text-slate-100 mt-2 font-mono">
            {simStats.active_simulated_players.toLocaleString()}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-emerald-400">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+14.2% peak surge load</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition">
            <Server className="w-16 h-16 text-emerald-400" />
          </div>
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Registered Consoles</div>
          <div className="text-3xl font-extrabold text-slate-100 mt-2 font-mono">
            {consoles.length * 2050 + 10420}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
            <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
            <span>{consoles.filter(c => c.security_state === 'HEALTHY').length} / {consoles.length} sample nodes healthy</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition">
            <Activity className="w-16 h-16 text-amber-400" />
          </div>
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Telemetry Ingestion Rate</div>
          <div className="text-3xl font-extrabold text-amber-400 mt-2 font-mono">
            {simStats.telemetry_events_per_sec.toLocaleString()} <span className="text-xs font-normal text-slate-400">evt/sec</span>
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
            <span>Lockless Tokio ring buffer</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition">
            <Database className="w-16 h-16 text-cyan-400" />
          </div>
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Database Transaction Rate</div>
          <div className="text-3xl font-extrabold text-cyan-300 mt-2 font-mono">
            {simStats.database_tx_per_sec.toLocaleString()} <span className="text-xs font-normal text-slate-400">tx/sec</span>
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Postgres ACID transactional integrity</span>
          </div>
        </div>
      </div>

      {/* System Architecture Topology Overview */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              ARCADIUM Platform Architecture Topology
            </h2>
            <p className="text-xs text-slate-400">High-performance Rust operational platform with R statistical analytics intelligence</p>
          </div>
          <span className="bg-emerald-950 border border-emerald-700/60 text-emerald-400 text-xs px-2.5 py-1 rounded font-mono">
            Operational Status: 100% ONLINE
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-lg hover:border-indigo-500/50 transition">
            <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-2">1. Console Core & Identity</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Console ID, Hardware Attestation, OAuth Device Sessions, User Account Security & Firmware Update Distribution.
            </p>
            <button
              onClick={() => onNavigateTab('consoles')}
              className="mt-3 text-xs bg-indigo-900/40 text-indigo-300 hover:bg-indigo-800/60 px-3 py-1.5 rounded transition cursor-pointer"
            >
              Manage Console OS
            </button>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-lg hover:border-amber-500/50 transition">
            <div className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">2. Multiplayer & Matchmaking</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              MMR Skill Matrix, Party System, Latency-aware Regional Relays, Dedicated Server Tick Rate Control.
            </p>
            <button
              onClick={() => onNavigateTab('multiplayer')}
              className="mt-3 text-xs bg-amber-900/40 text-amber-300 hover:bg-amber-800/60 px-3 py-1.5 rounded transition cursor-pointer"
            >
              Inspect Matchmaker
            </button>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-lg hover:border-cyan-500/50 transition">
            <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">3. Economy & Blockchain Assets</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Atomic $ARC Currency Ledger, NFT Digital Asset Minting, Multi-chain Indexer & Cloud Saves Content Hash.
            </p>
            <button
              onClick={() => onNavigateTab('economy')}
              className="mt-3 text-xs bg-cyan-900/40 text-cyan-300 hover:bg-cyan-800/60 px-3 py-1.5 rounded transition cursor-pointer"
            >
              Open Digital Economy
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Grid: Active Matches & Real-Time Telemetry Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Matches Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400" />
              Active Game Sessions ({matches.length})
            </h3>
            <button
              onClick={() => onNavigateTab('multiplayer')}
              className="text-xs text-indigo-400 hover:underline"
            >
              View Matchmaker Queue →
            </button>
          </div>

          <div className="space-y-3">
            {matches.map(m => (
              <div key={m.session_id} className="bg-slate-950 p-3.5 rounded-lg border border-slate-800/80 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{m.game_title}</span>
                  <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded text-[10px]">
                    {m.status}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px] text-slate-400 font-mono">
                  <div>Region: <span className="text-slate-200">{m.region}</span></div>
                  <div>Mode: <span className="text-slate-200">{m.game_mode}</span></div>
                  <div>Tick Rate: <span className="text-amber-400">{m.server_tick_rate} Hz</span></div>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                  <span>Players: {m.players.length} / 10</span>
                  <span>Avg Latency: <strong className="text-emerald-400">{m.avg_latency_ms} ms</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Telemetry Event Stream */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Radio className="w-4 h-4 text-amber-400 animate-pulse" />
              Real-Time Telemetry Stream
            </h3>
            <span className="text-xs font-mono text-slate-400">Ingest Buffer: 500 events</span>
          </div>

          <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
            {telemetry.slice(0, 8).map(evt => (
              <div key={evt.event_id} className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs flex items-center justify-between font-mono">
                <div className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${
                    evt.event_type === 'CHEAT_FLAGGED' ? 'bg-rose-500 animate-ping' :
                    evt.event_type === 'MATCH_COMPLETED' ? 'bg-emerald-400' :
                    evt.event_type === 'ACHIEVEMENT_UNLOCKED' ? 'bg-amber-400' : 'bg-indigo-400'
                  }`}></span>
                  <span className="font-bold text-slate-200">{evt.event_type}</span>
                  <span className="text-slate-500 text-[10px]">usr: {evt.user_id}</span>
                </div>
                <span className="text-[10px] text-slate-500">{new Date(evt.timestamp).toLocaleTimeString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
