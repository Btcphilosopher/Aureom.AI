import React, { useState } from 'react';
import { ConsoleDevice, SystemUpdate } from '../types/arcadium';
import { Cpu, ShieldCheck, ShieldAlert, Key, HardDrive, Download, RefreshCw, CheckCircle2 } from 'lucide-react';

interface ConsoleOSManagerProps {
  consoles: ConsoleDevice[];
  updates: SystemUpdate[];
  onRegisterConsole: (data: Partial<ConsoleDevice>) => void;
}

export const ConsoleOSManager: React.FC<ConsoleOSManagerProps> = ({ consoles, updates, onRegisterConsole }) => {
  const [selectedConsole, setSelectedConsole] = useState<ConsoleDevice | null>(consoles[0] || null);
  const [attestationLog, setAttestationLog] = useState<string | null>(null);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [newHwRev, setNewHwRev] = useState<ConsoleDevice['hardware_revision']>('ARC-PRO-V2');
  const [newRegion, setNewRegion] = useState('US-EAST');

  const handleTriggerAttestation = (consoleDev: ConsoleDevice) => {
    setAttestationLog(`[ATTESTATION CHALLENGE] Generating 256-bit RSA challenge for ${consoleDev.console_id}...
> Sending Nonce: 0x9f82a7e10c283412
> Device TPM Chip Response Received in 12ms
> Cryptographic Signature Match: VALID (RSA-2048 SHA-256)
> Security State: HEALTHY
Attestation complete.`);
  };

  const handleRegisterNewConsole = (e: React.FormEvent) => {
    e.preventDefault();
    onRegisterConsole({
      hardware_revision: newHwRev,
      region: newRegion,
      firmware_version: 'v4.2.0-LTS',
      ip_address: '192.168.1.188',
      mac_address: 'AC:88:5B:AA:22:11'
    });
    setShowRegisterModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800 shadow-md">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-400" />
            Console OS Hardware & Device Identity Platform
          </h2>
          <p className="text-xs text-slate-400">
            Hardware revision attestation, device session security, firmware deployment matrix and multi-user accounts
          </p>
        </div>
        <button
          onClick={() => setShowRegisterModal(true)}
          className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded shadow transition cursor-pointer flex items-center gap-2"
        >
          <HardDrive className="w-4 h-4" />
          <span>Provision Console Hardware</span>
        </button>
      </div>

      {/* Main Grid: Console Devices List & Details Pane */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left List Pane */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Registered Consoles ({consoles.length})</div>
          <div className="space-y-2 max-h-[550px] overflow-y-auto">
            {consoles.map(c => (
              <div
                key={c.console_id}
                onClick={() => { setSelectedConsole(c); setAttestationLog(null); }}
                className={`p-3.5 rounded-lg border text-xs cursor-pointer transition ${
                  selectedConsole?.console_id === c.console_id
                    ? 'bg-indigo-950/80 border-indigo-500 shadow-md'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 font-mono">{c.console_id}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded border ${
                    c.security_state === 'HEALTHY' ? 'bg-emerald-950 border-emerald-800 text-emerald-400' : 'bg-rose-950 border-rose-800 text-rose-400'
                  }`}>
                    {c.security_state}
                  </span>
                </div>
                <div className="mt-2 text-slate-400 flex items-center justify-between text-[11px]">
                  <span>H/W: <strong className="text-slate-200">{c.hardware_revision}</strong></span>
                  <span>FW: <strong className="text-cyan-400">{c.firmware_version}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Details Pane */}
        {selectedConsole && (
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-6">
              <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-100 font-mono">{selectedConsole.console_id}</h3>
                  <div className="text-xs text-slate-400">Primary Account Linked: <span className="text-indigo-400 font-mono">{selectedConsole.primary_user_id}</span></div>
                </div>
                <button
                  onClick={() => handleTriggerAttestation(selectedConsole)}
                  className="bg-emerald-900/60 hover:bg-emerald-800/80 text-emerald-300 border border-emerald-700/60 text-xs px-3 py-1.5 rounded transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Run Hardware Attestation</span>
                </button>
              </div>

              {/* Specification Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono">
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">Hardware Revision</div>
                  <div className="text-slate-200 font-bold mt-1">{selectedConsole.hardware_revision}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">Firmware Build</div>
                  <div className="text-cyan-400 font-bold mt-1">{selectedConsole.firmware_version}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">Data Center Region</div>
                  <div className="text-amber-400 font-bold mt-1">{selectedConsole.region}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">IP Address</div>
                  <div className="text-slate-300 font-bold mt-1">{selectedConsole.ip_address}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">MAC Address</div>
                  <div className="text-slate-300 font-bold mt-1">{selectedConsole.mac_address}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <div className="text-slate-500 text-[10px]">Attestation Token</div>
                  <div className="text-slate-400 truncate mt-1">{selectedConsole.attestation_token}</div>
                </div>
              </div>

              {/* Attestation Result Log Box */}
              {attestationLog && (
                <div className="bg-slate-950 border border-emerald-900/60 p-4 rounded-lg text-xs font-mono text-emerald-400 whitespace-pre-line leading-relaxed">
                  {attestationLog}
                </div>
              )}

              {/* Firmware Updates Section */}
              <div className="border-t border-slate-800 pt-4">
                <h4 className="text-sm font-bold text-slate-100 mb-3 flex items-center gap-2">
                  <Download className="w-4 h-4 text-cyan-400" />
                  System Firmware Distribution Matrix
                </h4>
                <div className="space-y-3">
                  {updates.map(u => (
                    <div key={u.version} className="bg-slate-950 p-3.5 rounded border border-slate-800 flex flex-col gap-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-cyan-300 font-mono">{u.version} ({u.channel})</span>
                        <span className="text-slate-400 text-[10px]">{u.package_size_mb} MB | SHA-256 Verified</span>
                      </div>
                      <p className="text-xs text-slate-400">{u.release_notes}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Provision Modal */}
      {showRegisterModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-slate-100">Provision New Console Hardware</h3>
            <form onSubmit={handleRegisterNewConsole} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Hardware Revision</label>
                <select
                  value={newHwRev}
                  onChange={e => setNewHwRev(e.target.value as ConsoleDevice['hardware_revision'])}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
                >
                  <option value="ARC-PRO-V2">ARCADIUM PRO (v2)</option>
                  <option value="ARC-SLIM-V1">ARCADIUM SLIM (v1)</option>
                  <option value="ARC-DEV-KIT-V3">ARCADIUM DEV-KIT (v3)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Target Region</label>
                <select
                  value={newRegion}
                  onChange={e => setNewRegion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
                >
                  <option value="US-EAST">US-East (N. Virginia)</option>
                  <option value="EU-CENTRAL">EU-Central (Frankfurt)</option>
                  <option value="AP-EAST">AP-East (Tokyo)</option>
                  <option value="SA-EAST">SA-East (São Paulo)</option>
                </select>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded cursor-pointer"
                >
                  Provision Device
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
