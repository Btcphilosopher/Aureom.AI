import React, { useState } from 'react';
import { AntiCheatFlag } from '../types/arcadium';
import { ShieldAlert, ShieldCheck, Zap, AlertTriangle, CheckCircle, Lock } from 'lucide-react';

interface AntiCheatAndSecurityProps {
  flags: AntiCheatFlag[];
  onFlagUser: (flag: Omit<AntiCheatFlag, 'flag_id' | 'timestamp'>) => void;
}

export const AntiCheatAndSecurity: React.FC<AntiCheatAndSecurityProps> = ({ flags, onFlagUser }) => {
  const [testUser, setTestUser] = useState('usr-005');
  const [testRule, setTestRule] = useState<AntiCheatFlag['detection_rule']>('IMP_SPEED_MOVEMENT');
  const [testResult, setTestResult] = useState<string | null>(null);

  const handleRunValidation = () => {
    onFlagUser({
      user_id: testUser,
      session_id: 'match-sess-9901',
      detection_rule: testRule,
      severity: 'HIGH',
      auto_banned: true,
      evidence_summary: `Server-authoritative check failed for ${testRule}: Delta movement 580m/s exceeds max velocity threshold.`
    });

    setTestResult(`[ANTI-CHEAT DETECTED] Violation flagged under rule '${testRule}' for player ${testUser}. Automated session disconnection and security flag issued.`);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-500" />
            Anti-Cheat Architecture & Security Operations
          </h2>
          <p className="text-xs text-slate-400">
            Server-authoritative state validation, impossible movement detection, score acceleration checking and automated ban pipeline
          </p>
        </div>

        <div className="bg-rose-950 border border-rose-800 text-rose-400 text-xs px-3 py-1.5 rounded font-mono">
          Security Level: <strong>STRICT SERVER-AUTHORITATIVE</strong>
        </div>
      </div>

      {/* Main Grid: Server Validator Tester & Flags Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Tester Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
            <Zap className="w-4 h-4 text-amber-400" />
            Server Authoritative Validation Tester
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Target Player ID</label>
              <input
                type="text"
                value={testUser}
                onChange={e => setTestUser(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Heuristic Rule Trigger</label>
              <select
                value={testRule}
                onChange={e => setTestRule(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-200"
              >
                <option value="IMP_SPEED_MOVEMENT">Impossible Speed / Teleport Movement</option>
                <option value="ANOMALOUS_SCORE_ACCELERATION">Anomalous Score Acceleration</option>
                <option value="UNAUTHORIZED_MEMORY_MUTATION">Unauthorized Memory Mutation</option>
                <option value="TAMPERED_PACKET_HEADER">Tampered Network Packet Header</option>
                <option value="INVENTORY_DUPLICATION_ATTEMPT">Inventory Duplication Attempt</option>
              </select>
            </div>

            <button
              onClick={handleRunValidation}
              className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 rounded shadow transition cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Trigger Validation Check</span>
            </button>
          </div>

          {testResult && (
            <div className="bg-slate-950 border border-rose-900 p-3 rounded text-xs font-mono text-rose-400 leading-relaxed">
              {testResult}
            </div>
          )}
        </div>

        {/* Right Flags Column */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              Flagged Anti-Cheat Security Audit Logs ({flags.length})
            </h3>

            <div className="space-y-3">
              {flags.map(f => (
                <div key={f.flag_id} className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-rose-400">{f.detection_rule}</span>
                    <span className="bg-rose-950 text-rose-300 border border-rose-800 text-[10px] px-2 py-0.5 rounded">
                      SEVERITY: {f.severity}
                    </span>
                  </div>

                  <div className="text-slate-300">
                    Target User: <span className="text-indigo-400">{f.user_id}</span> | Session: <span className="text-slate-500">{f.session_id || 'GLOBAL'}</span>
                  </div>

                  <div className="bg-slate-900 p-2.5 rounded text-slate-400 text-[11px] leading-relaxed">
                    {f.evidence_summary}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                    <span>Auto Banned: <strong className={f.auto_banned ? 'text-rose-400' : 'text-slate-400'}>{f.auto_banned ? 'YES' : 'NO'}</strong></span>
                    <span>{new Date(f.timestamp).toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
