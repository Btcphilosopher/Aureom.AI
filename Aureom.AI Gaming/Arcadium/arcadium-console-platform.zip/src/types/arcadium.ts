// ARCADIUM Platform Domain Models & Types

export type HardwareRevision = 'ARC-PRO-V2' | 'ARC-SLIM-V1' | 'ARC-DEV-KIT-V3';
export type FirmwareVersion = 'v4.2.0-LTS' | 'v4.3.1-BETA' | 'v4.4.0-DEV';
export type SecurityState = 'HEALTHY' | 'FLAGGED' | 'COMPROMISED' | 'REVOKED';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'BANNED' | 'MFA_REQUIRED';
export type PresenceState = 'ONLINE' | 'OFFLINE' | 'IN_GAME' | 'IN_MENU' | 'AWAY' | 'DND';
export type MatchStatus = 'SEARCHING' | 'FORMING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
export type EntitlementType = 'GAME_OWNERSHIP' | 'DLC_OWNERSHIP' | 'SEASON_PASS' | 'SUBSCRIPTION' | 'DIGITAL_ITEM' | 'BETA_ACCESS';
export type BlockchainNetwork = 'SOLANA_MAINNET' | 'ARCADIUM_SUBNET' | 'ETHEREUM_L2';
export type CheatSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ConsoleDevice {
  console_id: string;
  hardware_revision: HardwareRevision;
  firmware_version: FirmwareVersion;
  region: string;
  registration_date: string;
  last_seen: string;
  security_state: SecurityState;
  ip_address: string;
  mac_address: string;
  primary_user_id: string;
  attestation_token: string;
}

export interface UserAccount {
  user_id: string;
  username: string;
  display_name: string;
  email: string;
  country: string;
  language: string;
  timezone: string;
  account_status: UserStatus;
  created_at: string;
  last_login: string;
  mfa_enabled: boolean;
  avatar_url: string;
  mmr: number;
  rank_tier: string;
}

export interface UserPresence {
  user_id: string;
  state: PresenceState;
  current_game_id?: string;
  current_game_title?: string;
  party_id?: string;
  last_updated: string;
}

export interface Party {
  party_id: string;
  leader_user_id: string;
  members: string[]; // user_ids
  max_size: number;
  game_mode: string;
  created_at: string;
}

export interface MatchmakingRequest {
  request_id: string;
  user_id: string;
  game_id: string;
  game_mode: 'Casual' | 'Ranked' | 'Co-op' | 'Competitive 5v5';
  mmr: number;
  region: string;
  party_size: number;
  max_acceptable_latency_ms: number;
  queued_at: string;
}

export interface MatchSession {
  session_id: string;
  game_id: string;
  game_title: string;
  server_id: string;
  region: string;
  game_mode: string;
  players: {
    user_id: string;
    team_id: number;
    latency_ms: number;
    score: number;
    kills?: number;
    deaths?: number;
  }[];
  start_time: string;
  end_time?: string;
  status: MatchStatus;
  avg_latency_ms: number;
  packet_loss_pct: number;
  server_tick_rate: number;
}

export interface GameCatalogItem {
  game_id: string;
  title: string;
  publisher: string;
  developer: string;
  current_version: string;
  platforms: string[];
  regions: string[];
  age_rating: string;
  price_arc: number;
  price_usd: number;
  cover_image: string;
  dlc_list: { dlc_id: string; title: string; price_arc: number }[];
}

export interface DigitalEntitlement {
  entitlement_id: string;
  user_id: string;
  game_id: string;
  type: EntitlementType;
  item_id?: string;
  granted_at: string;
  source: 'PURCHASE' | 'PROMO' | 'SUBSCRIPTION' | 'ACHIEVEMENT';
  active: boolean;
}

export interface Wallet {
  user_id: string;
  arc_balance: number;
  gems_balance: number;
  gold_balance: number;
  updated_at: string;
}

export interface TransactionRecord {
  transaction_id: string;
  user_id: string;
  type: 'BUY_GAME' | 'BUY_ITEM' | 'P2P_TRADE' | 'REWARD' | 'NFT_MINT' | 'DEPOSIT';
  amount_arc: number;
  item_id?: string;
  item_name?: string;
  timestamp: string;
  status: 'CONFIRMED' | 'PENDING' | 'FAILED';
  hash: string;
}

export interface DigitalAssetNFT {
  asset_id: string;
  game_id: string;
  collection_name: string;
  token_id: string;
  metadata_uri: string;
  owner_user_id: string;
  owner_wallet_address: string;
  creation_time: string;
  blockchain_network: BlockchainNetwork;
  on_chain_tx_hash: string;
  rarity: 'COMMON' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'MYTHIC';
  attributes: Record<string, string | number>;
  on_chain_verified: boolean;
}

export interface CloudSaveData {
  save_id: string;
  user_id: string;
  game_id: string;
  slot_index: number;
  file_name: string;
  file_size_bytes: number;
  content_sha256: string;
  version: number;
  last_synced: string;
  backup_count: number;
}

export interface TelemetryEvent {
  event_id: string;
  event_type: 'GAME_STARTED' | 'MATCH_COMPLETED' | 'ACHIEVEMENT_UNLOCKED' | 'ITEM_PURCHASED' | 'PLAYER_LEVELLED' | 'PLAYER_DISCONNECTED' | 'SERVER_ERROR' | 'CHEAT_FLAGGED';
  user_id: string;
  console_id: string;
  game_id: string;
  timestamp: string;
  payload: Record<string, any>;
  latency_ms?: number;
}

export interface AntiCheatFlag {
  flag_id: string;
  user_id: string;
  session_id?: string;
  detection_rule: 'IMP_SPEED_MOVEMENT' | 'ANOMALOUS_SCORE_ACCELERATION' | 'UNAUTHORIZED_MEMORY_MUTATION' | 'TAMPERED_PACKET_HEADER' | 'INVENTORY_DUPLICATION_ATTEMPT';
  severity: CheatSeverity;
  timestamp: string;
  auto_banned: boolean;
  evidence_summary: string;
}

export interface SystemUpdate {
  version: FirmwareVersion;
  channel: 'STABLE' | 'BETA' | 'DEVELOPER';
  release_notes: string;
  package_size_mb: number;
  download_url: string;
  sha256_hash: string;
  mandatory: boolean;
  min_hardware_revision: HardwareRevision;
}

export interface SimulationStats {
  active_simulated_players: number;
  requests_per_sec: number;
  matchmaking_matches_per_sec: number;
  telemetry_events_per_sec: number;
  database_tx_per_sec: number;
  avg_latency_ms: number;
  p95_latency_ms: number;
  p99_latency_ms: number;
}

export interface RAnalyticsResult {
  retention_30d_pct: number;
  churn_risk_players: number;
  mmr_gaussian_std_dev: number;
  gini_coefficient: number;
  money_velocity: number;
  packet_loss_decay_factor: number;
  fraud_anomaly_detection_score: number;
  generated_at: string;
}
