import React, { useEffect, useState } from 'react';
import {
  ConsoleDevice,
  UserAccount,
  MatchSession,
  MatchmakingRequest,
  GameCatalogItem,
  DigitalEntitlement,
  Wallet,
  TransactionRecord,
  DigitalAssetNFT,
  TelemetryEvent,
  AntiCheatFlag,
  SystemUpdate,
  SimulationStats,
  RAnalyticsResult
} from './types/arcadium';

import { Navbar } from './components/Navbar';
import { OverviewDashboard } from './components/OverviewDashboard';
import { ConsoleOSManager } from './components/ConsoleOSManager';
import { MultiplayerMatchmaker } from './components/MultiplayerMatchmaker';
import { EconomyAndAssets } from './components/EconomyAndAssets';
import { CatalogAndEntitlements } from './components/CatalogAndEntitlements';
import { TelemetryAndAnalytics } from './components/TelemetryAndAnalytics';
import { AntiCheatAndSecurity } from './components/AntiCheatAndSecurity';
import { DeveloperPortal } from './components/DeveloperPortal';
import { SimulationPanel } from './components/SimulationPanel';

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isSimOpen, setIsSimOpen] = useState(false);

  // Platform Data State
  const [consoles, setConsoles] = useState<ConsoleDevice[]>([]);
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [matches, setMatches] = useState<MatchSession[]>([]);
  const [queue, setQueue] = useState<MatchmakingRequest[]>([]);
  const [games, setGames] = useState<GameCatalogItem[]>([]);
  const [entitlements, setEntitlements] = useState<DigitalEntitlement[]>([]);
  const [wallets, setWallets] = useState<Map<string, Wallet>>(new Map());
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [digitalAssets, setDigitalAssets] = useState<DigitalAssetNFT[]>([]);
  const [telemetry, setTelemetry] = useState<TelemetryEvent[]>([]);
  const [anticheatFlags, setAnticheatFlags] = useState<AntiCheatFlag[]>([]);
  const [updates, setUpdates] = useState<SystemUpdate[]>([]);

  const [simStats, setSimStats] = useState<SimulationStats>({
    active_simulated_players: 12450,
    requests_per_sec: 4820,
    matchmaking_matches_per_sec: 184,
    telemetry_events_per_sec: 14200,
    database_tx_per_sec: 2150,
    avg_latency_ms: 18.4,
    p95_latency_ms: 38.2,
    p99_latency_ms: 64.1
  });

  const [rResult, setRResult] = useState<RAnalyticsResult>({
    retention_30d_pct: 38.9,
    churn_risk_players: 980,
    mmr_gaussian_std_dev: 310.5,
    gini_coefficient: 0.382,
    money_velocity: 1.482,
    packet_loss_decay_factor: 0.942,
    fraud_anomaly_detection_score: 0.082,
    generated_at: new Date().toISOString()
  });

  // Fetch initial data from Express API
  const fetchAllPlatformData = async () => {
    try {
      const [
        resConsoles,
        resUsers,
        resMatches,
        resQueue,
        resGames,
        resEntitlements,
        resTx,
        resAssets,
        resTelem,
        resAC,
        resUpdates,
        resSim,
        resR
      ] = await Promise.all([
        fetch('/api/v1/consoles').then(r => r.json()),
        fetch('/api/v1/users').then(r => r.json()),
        fetch('/api/v1/matches').then(r => r.json()),
        fetch('/api/v1/matchmaking/queue').then(r => r.json()),
        fetch('/api/v1/games').then(r => r.json()),
        fetch('/api/v1/entitlements?userId=usr-001').then(r => r.json()),
        fetch('/api/v1/transactions').then(r => r.json()),
        fetch('/api/v1/assets').then(r => r.json()),
        fetch('/api/v1/telemetry').then(r => r.json()),
        fetch('/api/v1/anticheat').then(r => r.json()),
        fetch('/api/v1/updates').then(r => r.json()),
        fetch('/api/v1/simulation').then(r => r.json()),
        fetch('/api/v1/analytics/r').then(r => r.json())
      ]);

      if (Array.isArray(resConsoles)) setConsoles(resConsoles);
      if (Array.isArray(resUsers)) setUsers(resUsers);
      if (Array.isArray(resMatches)) setMatches(resMatches);
      if (Array.isArray(resQueue)) setQueue(resQueue);
      if (Array.isArray(resGames)) setGames(resGames);
      if (Array.isArray(resEntitlements)) setEntitlements(resEntitlements);
      if (Array.isArray(resTx)) setTransactions(resTx);
      if (Array.isArray(resAssets)) setDigitalAssets(resAssets);
      if (Array.isArray(resTelem)) setTelemetry(resTelem);
      if (Array.isArray(resAC)) setAnticheatFlags(resAC);
      if (Array.isArray(resUpdates)) setUpdates(resUpdates);
      if (resSim) setSimStats(resSim);
      if (resR) setRResult(resR);
    } catch (err) {
      console.warn('Backend API polling fallback to mock state:', err);
    }
  };

  useEffect(() => {
    fetchAllPlatformData();
    const interval = setInterval(fetchAllPlatformData, 3000);
    return () => clearInterval(interval);
  }, []);

  // Handlers for mutations via Express API
  const handleRegisterConsole = async (data: Partial<ConsoleDevice>) => {
    const res = await fetch('/api/v1/consoles', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const created = await res.json();
    setConsoles(prev => [...prev, created]);
  };

  const handleQueuePlayer = async (req: Omit<MatchmakingRequest, 'request_id' | 'queued_at'>) => {
    const res = await fetch('/api/v1/matchmaking/queue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req)
    });
    const queued = await res.json();
    setQueue(prev => [...prev, queued]);
    fetchAllPlatformData();
  };

  const handleExecutePurchase = async (userId: string, gameId: string) => {
    const res = await fetch('/api/v1/store/purchase', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, gameId })
    });
    const data = await res.json();
    if (data.success) {
      fetchAllPlatformData();
    }
  };

  const handleMintAsset = async (asset: Omit<DigitalAssetNFT, 'asset_id' | 'creation_time' | 'on_chain_tx_hash' | 'on_chain_verified'>) => {
    const res = await fetch('/api/v1/assets/mint', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(asset)
    });
    const minted = await res.json();
    setDigitalAssets(prev => [minted, ...prev]);
  };

  const handleSaveCloudData = async (userId: string, gameId: string, slotIndex: number, fileName: string, sizeBytes: number) => {
    await fetch('/api/v1/cloud/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, gameId, slotIndex, fileName, sizeBytes })
    });
    fetchAllPlatformData();
  };

  const handleFlagUser = async (flag: Omit<AntiCheatFlag, 'flag_id' | 'timestamp'>) => {
    const res = await fetch('/api/v1/anticheat/flag', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(flag)
    });
    const created = await res.json();
    setAnticheatFlags(prev => [created, ...prev]);
  };

  const handleExecuteRScript = (script: string) => {
    if (script.includes('gini') || script.includes('economy')) {
      return {
        output: `[R-ENGINE] Executing econometrics.R ...\n> Lorenz Curve calculated for ${users.length} active player wallets\n> Gini Coefficient: ${rResult.gini_coefficient}\n> Money Velocity: ${rResult.money_velocity} txs/day\nR Script Execution Complete.`,
        plotData: [
          { percentile: '10%', wealth_share: 2.1 },
          { percentile: '30%', wealth_share: 8.5 },
          { percentile: '50%', wealth_share: 22.0 },
          { percentile: '70%', wealth_share: 45.1 },
          { percentile: '90%', wealth_share: 78.4 },
          { percentile: '100%', wealth_share: 100.0 }
        ]
      };
    } else {
      return {
        output: `[R-ENGINE] Executing survival_retention.R ...\n> Kaplan-Meier survival probability fitted on cohort\n> Day 30 Retention: ${rResult.retention_30d_pct}%\n> Estimated Churn Risk Count: ${rResult.churn_risk_players}\nR Script Execution Complete.`,
        plotData: [
          { day: 1, retention: 78.4 },
          { day: 3, retention: 68.2 },
          { day: 7, retention: 54.2 },
          { day: 14, retention: 46.1 },
          { day: 30, retention: 38.9 }
        ]
      };
    }
  };

  const handleSetSimulationTarget = async (target: number) => {
    const res = await fetch('/api/v1/simulation/target', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetPlayers: target })
    });
    const stats = await res.json();
    setSimStats(stats);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-indigo-500 selection:text-white flex flex-col">
      {/* Navigation Topbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        simStats={simStats}
        onOpenSimulation={() => setIsSimOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 py-6">
        {activeTab === 'overview' && (
          <OverviewDashboard
            consoles={consoles}
            matches={matches}
            telemetry={telemetry}
            simStats={simStats}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'consoles' && (
          <ConsoleOSManager
            consoles={consoles}
            updates={updates}
            onRegisterConsole={handleRegisterConsole}
          />
        )}

        {activeTab === 'multiplayer' && (
          <MultiplayerMatchmaker
            users={users}
            matches={matches}
            queue={queue}
            onQueuePlayer={handleQueuePlayer}
          />
        )}

        {activeTab === 'economy' && (
          <EconomyAndAssets
            users={users}
            wallets={wallets}
            transactions={transactions}
            digitalAssets={digitalAssets}
            onMintAsset={handleMintAsset}
          />
        )}

        {activeTab === 'catalog' && (
          <CatalogAndEntitlements
            games={games}
            users={users}
            entitlements={entitlements}
            onExecutePurchase={handleExecutePurchase}
            onSaveCloudData={handleSaveCloudData}
          />
        )}

        {activeTab === 'analytics' && (
          <TelemetryAndAnalytics
            rResult={rResult}
            onExecuteRScript={handleExecuteRScript}
          />
        )}

        {activeTab === 'anticheat' && (
          <AntiCheatAndSecurity
            flags={anticheatFlags}
            onFlagUser={handleFlagUser}
          />
        )}

        {activeTab === 'developer' && (
          <DeveloperPortal />
        )}
      </main>

      {/* Simulation Modal */}
      <SimulationPanel
        isOpen={isSimOpen}
        onClose={() => setIsSimOpen(false)}
        simStats={simStats}
        onSetSimulationTarget={handleSetSimulationTarget}
      />

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-4 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-2">
          <span>ARCADIUM CONSOLE PLATFORM &copy; 2026. RUST CORE v4.2.0-LTS & R ANALYTICS ENGINE.</span>
          <span>POSTGRESQL ACID TRANSACTIONS | LOCKLESS TOKIO RING BUFFER | SOLANA & SUBNET NFT BRIDGE</span>
        </div>
      </footer>
    </div>
  );
}
