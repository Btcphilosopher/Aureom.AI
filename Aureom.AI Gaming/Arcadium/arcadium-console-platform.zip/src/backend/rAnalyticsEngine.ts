// ARCADIUM R Analytics Engine Integration & Statistical Processing Pipeline

import { RAnalyticsResult } from '../types/arcadium';
import { dbEngine } from './mockDatabase';

export class RAnalyticsEngine {
  /**
   * Executes statistical R models over live platform telemetry and database state.
   */
  public static runRAnalyticsPipeline(): RAnalyticsResult {
    const users = dbEngine.getUsers();
    const telemetry = dbEngine.getTelemetry(200);
    const transactions = dbEngine.getTransactions();

    // 1. Calculate Gini Coefficient for $ARC Wealth Distribution
    const balances = users.map(u => dbEngine.getWallet(u.user_id).arc_balance).sort((a, b) => a - b);
    const n = balances.length;
    let gini = 0;
    if (n > 0) {
      let num = 0;
      let den = 0;
      for (let i = 0; i < n; i++) {
        num += (i + 1) * balances[i];
        den += balances[i];
      }
      gini = den === 0 ? 0 : (2 * num) / (n * den) - (n + 1) / n;
    }

    // 2. Calculate Money Velocity (Total Tx Volume / Total M1 Arc Balance)
    const totalM1Arc = balances.reduce((a, b) => a + b, 0) || 1;
    const totalTxVolumeArc = transactions.reduce((a, b) => a + b.amount_arc, 0);
    const moneyVelocity = +(totalTxVolumeArc / totalM1Arc).toFixed(3);

    // 3. MMR Skill Gaussian Standard Deviation
    const mmrs = users.map(u => u.mmr);
    const meanMmr = mmrs.reduce((a, b) => a + b, 0) / (mmrs.length || 1);
    const variance = mmrs.reduce((a, b) => a + Math.pow(b - meanMmr, 2), 0) / (mmrs.length || 1);
    const mmrStdDev = +Math.sqrt(variance).toFixed(2);

    // 4. Fraud Anomaly Score based on AntiCheat flags & Telemetry spikes
    const acFlags = dbEngine.getAnticheatFlags();
    const highSeverityCount = acFlags.filter(f => f.severity === 'HIGH' || f.severity === 'CRITICAL').length;
    const fraudAnomalyScore = +(Math.min(1.0, 0.05 + highSeverityCount * 0.18 + Math.random() * 0.02)).toFixed(3);

    // 5. Retention & Churn Estimate
    const activeUsersCount = users.filter(u => u.account_status === 'ACTIVE').length;
    const retentionRate30d = +((activeUsersCount / (users.length || 1)) * 100).toFixed(1);
    const churnRiskPlayers = Math.floor(users.length * 0.08);

    return {
      retention_30d_pct: retentionRate30d,
      churn_risk_players: churnRiskPlayers,
      mmr_gaussian_std_dev: mmrStdDev,
      gini_coefficient: +gini.toFixed(3),
      money_velocity: moneyVelocity,
      packet_loss_decay_factor: 0.942,
      fraud_anomaly_detection_score: fraudAnomalyScore,
      generated_at: new Date().toISOString()
    };
  }

  /**
   * Generates R Script execution output for the interactive R Workbench
   */
  public static executeCustomRScript(scriptCode: string): { output: string; plotData?: any[] } {
    if (scriptCode.includes('gini') || scriptCode.includes('economy')) {
      return {
        output: `[R-ENGINE] Executing econometrics.R ...
Running Lorenz Curve fitting on N=12,450 player wallets...
> Gini Coefficient: 0.382
> M1 Arc Money Supply: 18,450,200 $ARC
> M2 Velocity: 1.482 txs/day
> Inflation Rate (YoY): +2.1% [STABLE]
Done in 14.2ms.`,
        plotData: [
          { percentile: '10%', wealth_share: 2.1 },
          { percentile: '30%', wealth_share: 8.5 },
          { percentile: '50%', wealth_share: 22.0 },
          { percentile: '70%', wealth_share: 45.1 },
          { percentile: '90%', wealth_share: 78.4 },
          { percentile: '100%', wealth_share: 100.0 }
        ]
      };
    } else if (scriptCode.includes('retention') || scriptCode.includes('churn')) {
      return {
        output: `[R-ENGINE] Executing retention_survival.R ...
Fitting Kaplan-Meier survival curves for Cohort 2026-Q3...
> Day 1 Retention: 78.4%
> Day 7 Retention: 54.2%
> Day 30 Retention: 38.9%
> Hazard Ratio (MFA Enabled): 0.62 (p < 0.001)
Done in 22.1ms.`,
        plotData: [
          { day: 1, retention: 78.4 },
          { day: 3, retention: 68.2 },
          { day: 7, retention: 54.2 },
          { day: 14, retention: 46.1 },
          { day: 30, retention: 38.9 }
        ]
      };
    } else {
      return {
        output: `[R-ENGINE] Executing custom_script.R ...
Parsed 14,200 telemetry events across 5 regions.
> Kolmogorov-Smirnov Test for Ping Distribution: D=0.042, p-value=0.891
> Residual Variance: 0.012
R Analytics Pipeline execution finished successfully.`,
        plotData: [
          { region: 'US-EAST', latency_p50: 16, latency_p99: 42 },
          { region: 'EU-CENTRAL', latency_p50: 22, latency_p99: 58 },
          { region: 'AP-EAST', latency_p50: 38, latency_p99: 82 },
          { region: 'SA-EAST', latency_p50: 45, latency_p99: 98 }
        ]
      };
    }
  }
}
