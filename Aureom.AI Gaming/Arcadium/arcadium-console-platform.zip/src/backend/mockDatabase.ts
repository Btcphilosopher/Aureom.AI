// ARCADIUM In-Memory Transactional Database & Platform Services Engine

import {
  ConsoleDevice,
  UserAccount,
  UserPresence,
  Party,
  MatchmakingRequest,
  MatchSession,
  GameCatalogItem,
  DigitalEntitlement,
  Wallet,
  TransactionRecord,
  DigitalAssetNFT,
  CloudSaveData,
  TelemetryEvent,
  AntiCheatFlag,
  SystemUpdate,
  SimulationStats
} from '../types/arcadium';

class ArcadiumDatabaseEngine {
  private consoles: Map<string, ConsoleDevice> = new Map();
  private users: Map<string, UserAccount> = new Map();
  private presences: Map<string, UserPresence> = new Map();
  private parties: Map<string, Party> = new Map();
  private matchmakingQueue: MatchmakingRequest[] = [];
  private activeMatches: Map<string, MatchSession> = new Map();
  private gameCatalog: Map<string, GameCatalogItem> = new Map();
  private entitlements: DigitalEntitlement[] = [];
  private wallets: Map<string, Wallet> = new Map();
  private transactions: TransactionRecord[] = [];
  private digitalAssets: Map<string, DigitalAssetNFT> = new Map();
  private cloudSaves: Map<string, CloudSaveData> = new Map();
  private telemetryBuffer: TelemetryEvent[] = [];
  private anticheatFlags: AntiCheatFlag[] = [];
  private systemUpdates: SystemUpdate[] = [];

  // Simulation Metrics
  private simulationActive = false;
  private simTargetPlayers = 1000;
  private simStats: SimulationStats = {
    active_simulated_players: 12450,
    requests_per_sec: 4820,
    matchmaking_matches_per_sec: 184,
    telemetry_events_per_sec: 14200,
    database_tx_per_sec: 2150,
    avg_latency_ms: 18.4,
    p95_latency_ms: 38.2,
    p99_latency_ms: 64.1,
  };

  constructor() {
    this.seedInitialPlatformData();
  }

  private seedInitialPlatformData() {
    // 1. Games Catalog
    const games: GameCatalogItem[] = [
      {
        game_id: 'game-001',
        title: 'Aetherfall Online: Eclipse',
        publisher: 'Arcadium Studios',
        developer: 'Vanguard Interactive',
        current_version: 'v2.8.4',
        platforms: ['ARCADIUM-PRO', 'ARCADIUM-SLIM', 'PC'],
        regions: ['US-EAST', 'EU-CENTRAL', 'AP-EAST', 'SA-EAST'],
        age_rating: 'M (17+)',
        price_arc: 250,
        price_usd: 59.99,
        cover_image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80',
        dlc_list: [
          { dlc_id: 'dlc-001-1', title: 'Aetherfall: Void Expansion Pass', price_arc: 80 },
          { dlc_id: 'dlc-001-2', title: 'Founders Cyber Armour Set', price_arc: 40 }
        ]
      },
      {
        game_id: 'game-002',
        title: 'CyberRift 2099',
        publisher: 'Arcadium Publishing',
        developer: 'Neon Syndicate',
        current_version: 'v1.4.0',
        platforms: ['ARCADIUM-PRO', 'ARCADIUM-SLIM'],
        regions: ['US-EAST', 'EU-CENTRAL', 'AP-EAST'],
        age_rating: 'T (13+)',
        price_arc: 200,
        price_usd: 49.99,
        cover_image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=80',
        dlc_list: [
          { dlc_id: 'dlc-002-1', title: 'Neon Highway Music & Skin Pack', price_arc: 30 }
        ]
      },
      {
        game_id: 'game-003',
        title: 'Galactic Velocity: Nitro Racing',
        publisher: 'HyperDrive Games',
        developer: 'Orbital Vector',
        current_version: 'v3.1.2',
        platforms: ['ARCADIUM-PRO', 'ARCADIUM-SLIM'],
        regions: ['US-EAST', 'EU-CENTRAL', 'AP-EAST', 'SA-EAST', 'US-WEST'],
        age_rating: 'E (Everyone)',
        price_arc: 150,
        price_usd: 39.99,
        cover_image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80',
        dlc_list: []
      },
      {
        game_id: 'game-004',
        title: 'Dungeon Forge: Mythic Legends',
        publisher: 'Arcadium Studios',
        developer: 'DeepRealm Works',
        current_version: 'v1.0.5',
        platforms: ['ARCADIUM-PRO', 'ARCADIUM-SLIM'],
        regions: ['US-EAST', 'EU-CENTRAL'],
        age_rating: 'M (17+)',
        price_arc: 300,
        price_usd: 69.99,
        cover_image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop&q=80',
        dlc_list: []
      }
    ];

    games.forEach(g => this.gameCatalog.set(g.game_id, g));

    // 2. Initial Users & Consoles
    const initialUsers = [
      { id: 'usr-001', username: 'Kaelen_Vanguard', display: 'Kaelen The Unbroken', email: 'kaelen@arcadium.io', mmr: 2150, tier: 'Diamond' },
      { id: 'usr-002', username: 'Sora_CyberX', display: 'Sora Matrix', email: 'sora@arcadium.io', mmr: 1890, tier: 'Platinum' },
      { id: 'usr-003', username: 'Astra_Rift', display: 'Astra Prime', email: 'astra@arcadium.io', mmr: 2420, tier: 'Grandmaster' },
      { id: 'usr-004', username: 'Vortex_Ghost', display: 'Vortex Shadow', email: 'vortex@arcadium.io', mmr: 1550, tier: 'Gold' },
      { id: 'usr-005', username: 'Zenith_Core', display: 'Zenith Operator', email: 'zenith@arcadium.io', mmr: 1210, tier: 'Silver' },
    ];

    initialUsers.forEach((u, idx) => {
      const user: UserAccount = {
        user_id: u.id,
        username: u.username,
        display_name: u.display,
        email: u.email,
        country: idx % 2 === 0 ? 'USA' : 'DEU',
        language: 'en-US',
        timezone: 'UTC-5',
        account_status: 'ACTIVE',
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * (30 + idx * 10)).toISOString(),
        last_login: new Date().toISOString(),
        mfa_enabled: true,
        avatar_url: `https://api.dicebear.com/7.x/bottts/svg?seed=${u.username}`,
        mmr: u.mmr,
        rank_tier: u.tier,
      };
      this.users.set(u.id, user);

      // Console for user
      const consoleDev: ConsoleDevice = {
        console_id: `console-arc-${1000 + idx}`,
        hardware_revision: idx % 2 === 0 ? 'ARC-PRO-V2' : 'ARC-SLIM-V1',
        firmware_version: 'v4.2.0-LTS',
        region: idx % 2 === 0 ? 'US-EAST' : 'EU-CENTRAL',
        registration_date: user.created_at,
        last_seen: new Date().toISOString(),
        security_state: 'HEALTHY',
        ip_address: `192.168.1.${10 + idx}`,
        mac_address: `AC:88:5B:7F:40:0${idx}`,
        primary_user_id: u.id,
        attestation_token: `attest_token_rsa_2048_sig_v2_${u.id}`,
      };
      this.consoles.set(consoleDev.console_id, consoleDev);

      // Presence
      this.presences.set(u.id, {
        user_id: u.id,
        state: idx === 0 ? 'IN_GAME' : idx === 1 ? 'ONLINE' : 'IN_MENU',
        current_game_id: idx === 0 ? 'game-001' : undefined,
        current_game_title: idx === 0 ? 'Aetherfall Online: Eclipse' : undefined,
        last_updated: new Date().toISOString()
      });

      // Wallet
      this.wallets.set(u.id, {
        user_id: u.id,
        arc_balance: 1500 + idx * 500,
        gems_balance: 320 + idx * 100,
        gold_balance: 15000 + idx * 2500,
        updated_at: new Date().toISOString()
      });

      // Entitlements
      this.entitlements.push({
        entitlement_id: `ent-${100 + idx}`,
        user_id: u.id,
        game_id: 'game-001',
        type: 'GAME_OWNERSHIP',
        granted_at: user.created_at,
        source: 'PURCHASE',
        active: true
      });

      // Cloud Save
      this.cloudSaves.set(`${u.id}:game-001:0`, {
        save_id: `csave-${u.id}-g1-s0`,
        user_id: u.id,
        game_id: 'game-001',
        slot_index: 0,
        file_name: 'aetherfall_progress_checkpoint.sav',
        file_size_bytes: 4812900,
        content_sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        version: 12,
        last_synced: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        backup_count: 5
      });
    });

    // 3. Digital Assets (NFTs)
    const nfts: DigitalAssetNFT[] = [
      {
        asset_id: 'asset-nft-001',
        game_id: 'game-001',
        collection_name: 'Aetherfall Prime Relics',
        token_id: '7741',
        metadata_uri: 'ipfs://QmX8aArcadiumPrimeRelic7741',
        owner_user_id: 'usr-001',
        owner_wallet_address: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
        creation_time: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15).toISOString(),
        blockchain_network: 'ARCADIUM_SUBNET',
        on_chain_tx_hash: '0x9a812b48f902cd3818e8d7162bc1294819283746198fcd7e18a937402859182a',
        rarity: 'LEGENDARY',
        attributes: { PhysicalDamage: '+45%', ArcaneResist: '30', GlowEffect: 'Eclipse Aura' },
        on_chain_verified: true
      },
      {
        asset_id: 'asset-nft-002',
        game_id: 'game-002',
        collection_name: 'CyberRift Founders Vehicles',
        token_id: '0102',
        metadata_uri: 'ipfs://QmY9bCyberRiftFounderSpeedster',
        owner_user_id: 'usr-003',
        owner_wallet_address: '0x3A2199F200eA8871A210A8712B2B8599a812001A',
        creation_time: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(),
        blockchain_network: 'SOLANA_MAINNET',
        on_chain_tx_hash: '5K9A8fc19e28d11c82823812740928a9b1c7d2e8f1a23b4c5d6e7f8a9b1c2d3e',
        rarity: 'MYTHIC',
        attributes: { TopSpeedKmH: 420, Acceleration0to100: '1.2s', NitroBoost: 'Dual-Plasma' },
        on_chain_verified: true
      }
    ];
    nfts.forEach(n => this.digitalAssets.set(n.asset_id, n));

    // 4. Active Matches
    const match1: MatchSession = {
      session_id: 'match-sess-9901',
      game_id: 'game-001',
      game_title: 'Aetherfall Online: Eclipse',
      server_id: 'srv-us-east-04',
      region: 'US-EAST',
      game_mode: 'Competitive 5v5',
      players: [
        { user_id: 'usr-001', team_id: 1, latency_ms: 14, score: 2450, kills: 18, deaths: 4 },
        { user_id: 'usr-002', team_id: 1, latency_ms: 22, score: 1820, kills: 12, deaths: 6 },
        { user_id: 'usr-003', team_id: 2, latency_ms: 18, score: 2900, kills: 21, deaths: 3 },
        { user_id: 'usr-004', team_id: 2, latency_ms: 31, score: 1100, kills: 7, deaths: 11 }
      ],
      start_time: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
      status: 'IN_PROGRESS',
      avg_latency_ms: 21.25,
      packet_loss_pct: 0.02,
      server_tick_rate: 128
    };
    this.activeMatches.set(match1.session_id, match1);

    // 5. System Updates
    this.systemUpdates = [
      {
        version: 'v4.2.0-LTS',
        channel: 'STABLE',
        release_notes: 'LTS Core Kernel stability patch, zero-copy socket pipeline optimization, Vulcan graphics shader update.',
        package_size_mb: 1850,
        download_url: 'https://updates.cdn.arcadium.io/firmware/v4.2.0-LTS.pkg',
        sha256_hash: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
        mandatory: true,
        min_hardware_revision: 'ARC-SLIM-V1'
      },
      {
        version: 'v4.3.1-BETA',
        channel: 'BETA',
        release_notes: 'Experimental zero-knowledge proof verification pipeline for instant on-chain NFT ownership checks.',
        package_size_mb: 2100,
        download_url: 'https://updates.cdn.arcadium.io/firmware/v4.3.1-BETA.pkg',
        sha256_hash: '7a192839410298a0c91823a019e83719283749a1823901a823901a283901a823',
        mandatory: false,
        min_hardware_revision: 'ARC-PRO-V2'
      }
    ];

    // 6. AntiCheat Flags
    this.anticheatFlags.push({
      flag_id: 'flag-ac-001',
      user_id: 'usr-005',
      session_id: 'match-sess-9890',
      detection_rule: 'IMP_SPEED_MOVEMENT',
      severity: 'HIGH',
      timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      auto_banned: false,
      evidence_summary: 'Delta displacement 420m in 12ms exceeds physics server boundary threshold by 340%.'
    });

    // 7. Initial Telemetry
    for (let i = 0; i < 25; i++) {
      this.telemetryBuffer.push({
        event_id: `telem-evt-${10000 + i}`,
        event_type: i % 3 === 0 ? 'MATCH_COMPLETED' : i % 2 === 0 ? 'ACHIEVEMENT_UNLOCKED' : 'ITEM_PURCHASED',
        user_id: `usr-00${(i % 5) + 1}`,
        console_id: `console-arc-100${i % 5}`,
        game_id: 'game-001',
        timestamp: new Date(Date.now() - 1000 * 60 * i * 3).toISOString(),
        payload: { tick_rate: 128, frame_time_ms: 7.2, vram_used_mb: 4120 },
        latency_ms: 15 + Math.floor(Math.random() * 20)
      });
    }
  }

  // --- QUERY & MUTATION API HANDLERS ---

  public getConsoles(): ConsoleDevice[] {
    return Array.from(this.consoles.values());
  }

  public getConsole(id: string): ConsoleDevice | undefined {
    return this.consoles.get(id);
  }

  public registerConsole(data: Partial<ConsoleDevice>): ConsoleDevice {
    const id = data.console_id || `console-arc-${Date.now().toString().slice(-4)}`;
    const newConsole: ConsoleDevice = {
      console_id: id,
      hardware_revision: data.hardware_revision || 'ARC-PRO-V2',
      firmware_version: data.firmware_version || 'v4.2.0-LTS',
      region: data.region || 'US-EAST',
      registration_date: new Date().toISOString(),
      last_seen: new Date().toISOString(),
      security_state: 'HEALTHY',
      ip_address: data.ip_address || '192.168.1.150',
      mac_address: data.mac_address || 'AC:88:5B:99:11:22',
      primary_user_id: data.primary_user_id || 'usr-001',
      attestation_token: `attest_token_${Date.now()}`
    };
    this.consoles.set(id, newConsole);
    return newConsole;
  }

  public getUsers(): UserAccount[] {
    return Array.from(this.users.values());
  }

  public getUser(id: string): UserAccount | undefined {
    return this.users.get(id);
  }

  public getPresence(userId: string): UserPresence | undefined {
    return this.presences.get(userId);
  }

  public updatePresence(userId: string, state: UserPresence['state'], gameId?: string, gameTitle?: string): UserPresence {
    const pres: UserPresence = {
      user_id: userId,
      state,
      current_game_id: gameId,
      current_game_title: gameTitle,
      last_updated: new Date().toISOString()
    };
    this.presences.set(userId, pres);
    return pres;
  }

  public getMatches(): MatchSession[] {
    return Array.from(this.activeMatches.values());
  }

  public getMatchmakingQueue(): MatchmakingRequest[] {
    return [...this.matchmakingQueue];
  }

  public queueForMatchmaking(req: Omit<MatchmakingRequest, 'request_id' | 'queued_at'>): MatchmakingRequest {
    const fullReq: MatchmakingRequest = {
      ...req,
      request_id: `mm-req-${Date.now()}`,
      queued_at: new Date().toISOString()
    };
    this.matchmakingQueue.push(fullReq);

    // Try auto-matching if queue size >= 2
    if (this.matchmakingQueue.length >= 2) {
      const p1 = this.matchmakingQueue.shift()!;
      const p2 = this.matchmakingQueue.shift()!;
      const newMatch: MatchSession = {
        session_id: `match-sess-${Date.now().toString().slice(-4)}`,
        game_id: p1.game_id,
        game_title: this.gameCatalog.get(p1.game_id)?.title || 'Arcadium Multiplayer Match',
        server_id: `srv-${p1.region.toLowerCase()}-auto-01`,
        region: p1.region,
        game_mode: p1.game_mode,
        players: [
          { user_id: p1.user_id, team_id: 1, latency_ms: 18, score: 0 },
          { user_id: p2.user_id, team_id: 2, latency_ms: 24, score: 0 }
        ],
        start_time: new Date().toISOString(),
        status: 'IN_PROGRESS',
        avg_latency_ms: 21,
        packet_loss_pct: 0.01,
        server_tick_rate: 128
      };
      this.activeMatches.set(newMatch.session_id, newMatch);
    }

    return fullReq;
  }

  public getGameCatalog(): GameCatalogItem[] {
    return Array.from(this.gameCatalog.values());
  }

  public getWallet(userId: string): Wallet {
    if (!this.wallets.has(userId)) {
      this.wallets.set(userId, {
        user_id: userId,
        arc_balance: 1000,
        gems_balance: 100,
        gold_balance: 5000,
        updated_at: new Date().toISOString()
      });
    }
    return this.wallets.get(userId)!;
  }

  public executePurchase(userId: string, gameId: string): { success: boolean; error?: string; entitlement?: DigitalEntitlement; tx?: TransactionRecord } {
    const game = this.gameCatalog.get(gameId);
    if (!game) return { success: false, error: 'Game not found in catalog' };

    const wallet = this.getWallet(userId);
    if (wallet.arc_balance < game.price_arc) {
      return { success: false, error: `Insufficient $ARC balance. Required: ${game.price_arc}, Available: ${wallet.arc_balance}` };
    }

    // Atomic transaction
    wallet.arc_balance -= game.price_arc;
    wallet.updated_at = new Date().toISOString();

    const entitlement: DigitalEntitlement = {
      entitlement_id: `ent-${Date.now()}`,
      user_id: userId,
      game_id: gameId,
      type: 'GAME_OWNERSHIP',
      granted_at: new Date().toISOString(),
      source: 'PURCHASE',
      active: true
    };
    this.entitlements.push(entitlement);

    const tx: TransactionRecord = {
      transaction_id: `tx-arc-${Date.now()}`,
      user_id: userId,
      type: 'BUY_GAME',
      amount_arc: game.price_arc,
      item_id: gameId,
      item_name: game.title,
      timestamp: new Date().toISOString(),
      status: 'CONFIRMED',
      hash: `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`
    };
    this.transactions.unshift(tx);

    return { success: true, entitlement, tx };
  }

  public getEntitlements(userId: string): DigitalEntitlement[] {
    return this.entitlements.filter(e => e.user_id === userId);
  }

  public getTransactions(userId?: string): TransactionRecord[] {
    if (userId) return this.transactions.filter(t => t.user_id === userId);
    return [...this.transactions];
  }

  public getDigitalAssets(ownerUserId?: string): DigitalAssetNFT[] {
    const list = Array.from(this.digitalAssets.values());
    if (ownerUserId) return list.filter(a => a.owner_user_id === ownerUserId);
    return list;
  }

  public mintDigitalAsset(data: Omit<DigitalAssetNFT, 'asset_id' | 'creation_time' | 'on_chain_tx_hash' | 'on_chain_verified'>): DigitalAssetNFT {
    const id = `asset-nft-${Date.now()}`;
    const nft: DigitalAssetNFT = {
      ...data,
      asset_id: id,
      creation_time: new Date().toISOString(),
      on_chain_tx_hash: `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      on_chain_verified: true
    };
    this.digitalAssets.set(id, nft);
    return nft;
  }

  public getCloudSave(userId: string, gameId: string, slotIndex = 0): CloudSaveData | undefined {
    return this.cloudSaves.get(`${userId}:${gameId}:${slotIndex}`);
  }

  public saveCloudData(userId: string, gameId: string, slotIndex: number, fileName: string, sizeBytes: number): CloudSaveData {
    const key = `${userId}:${gameId}:${slotIndex}`;
    const existing = this.cloudSaves.get(key);
    const version = existing ? existing.version + 1 : 1;
    const backupCount = existing ? existing.backup_count + 1 : 1;

    // Sha256 content signature mock
    const sha256 = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

    const save: CloudSaveData = {
      save_id: `csave-${userId}-${gameId}-s${slotIndex}`,
      user_id: userId,
      game_id: gameId,
      slot_index: slotIndex,
      file_name: fileName,
      file_size_bytes: sizeBytes,
      content_sha256: sha256,
      version,
      last_synced: new Date().toISOString(),
      backup_count: backupCount
    };

    this.cloudSaves.set(key, save);
    return save;
  }

  public ingesteTelemetry(event: Omit<TelemetryEvent, 'event_id' | 'timestamp'>): TelemetryEvent {
    const fullEvent: TelemetryEvent = {
      ...event,
      event_id: `telem-evt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString()
    };
    this.telemetryBuffer.unshift(fullEvent);
    if (this.telemetryBuffer.length > 500) this.telemetryBuffer.pop();
    return fullEvent;
  }

  public getTelemetry(limit = 50): TelemetryEvent[] {
    return this.telemetryBuffer.slice(0, limit);
  }

  public getAnticheatFlags(): AntiCheatFlag[] {
    return [...this.anticheatFlags];
  }

  public flagAnticheat(flag: Omit<AntiCheatFlag, 'flag_id' | 'timestamp'>): AntiCheatFlag {
    const fullFlag: AntiCheatFlag = {
      ...flag,
      flag_id: `flag-ac-${Date.now()}`,
      timestamp: new Date().toISOString()
    };
    this.anticheatFlags.unshift(fullFlag);
    return fullFlag;
  }

  public getSystemUpdates(): SystemUpdate[] {
    return [...this.systemUpdates];
  }

  public getSimulationStats(): SimulationStats {
    // Dynamically fluctuate stats slightly to simulate live traffic
    const jitter = (Math.random() - 0.5) * 0.05;
    return {
      ...this.simStats,
      requests_per_sec: Math.floor(this.simStats.requests_per_sec * (1 + jitter)),
      matchmaking_matches_per_sec: Math.floor(this.simStats.matchmaking_matches_per_sec * (1 + jitter)),
      telemetry_events_per_sec: Math.floor(this.simStats.telemetry_events_per_sec * (1 + jitter)),
      avg_latency_ms: +(this.simStats.avg_latency_ms * (1 + jitter * 0.2)).toFixed(2)
    };
  }

  public setSimulationTarget(players: number): SimulationStats {
    this.simTargetPlayers = players;
    const ratio = players / 10000;
    this.simStats = {
      active_simulated_players: players,
      requests_per_sec: Math.floor(3800 * ratio),
      matchmaking_matches_per_sec: Math.floor(140 * ratio),
      telemetry_events_per_sec: Math.floor(11000 * ratio),
      database_tx_per_sec: Math.floor(1800 * ratio),
      avg_latency_ms: +(16 + ratio * 2.5).toFixed(2),
      p95_latency_ms: +(32 + ratio * 5.0).toFixed(2),
      p99_latency_ms: +(55 + ratio * 8.0).toFixed(2)
    };
    return this.simStats;
  }
}

export const dbEngine = new ArcadiumDatabaseEngine();
