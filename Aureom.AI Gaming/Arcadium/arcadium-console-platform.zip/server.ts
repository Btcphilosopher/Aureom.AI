import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { dbEngine } from './src/backend/mockDatabase';
import { RAnalyticsEngine } from './src/backend/rAnalyticsEngine';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- ARCADIUM CONSOLE BACKEND API V1 ---

  // Health check
  app.get('/api/v1/health', (req, res) => {
    res.json({
      status: 'HEALTHY',
      platform: 'ARCADIUM Console Core v4.2.0',
      uptime_seconds: process.uptime(),
      timestamp: new Date().toISOString()
    });
  });

  // Consoles Management
  app.get('/api/v1/consoles', (req, res) => {
    res.json(dbEngine.getConsoles());
  });

  app.get('/api/v1/consoles/:id', (req, res) => {
    const consoleDev = dbEngine.getConsole(req.params.id);
    if (!consoleDev) return res.status(404).json({ error: 'Console not found' });
    res.json(consoleDev);
  });

  app.post('/api/v1/consoles', (req, res) => {
    const newConsole = dbEngine.registerConsole(req.body);
    res.json(newConsole);
  });

  // User Accounts
  app.get('/api/v1/users', (req, res) => {
    res.json(dbEngine.getUsers());
  });

  app.get('/api/v1/users/:id', (req, res) => {
    const user = dbEngine.getUser(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  });

  // Presence
  app.get('/api/v1/presence/:userId', (req, res) => {
    const presence = dbEngine.getPresence(req.params.userId);
    if (!presence) return res.status(404).json({ error: 'Presence not found' });
    res.json(presence);
  });

  app.post('/api/v1/presence/update', (req, res) => {
    const { userId, state, gameId, gameTitle } = req.body;
    const updated = dbEngine.updatePresence(userId, state, gameId, gameTitle);
    res.json(updated);
  });

  // Games & Store
  app.get('/api/v1/games', (req, res) => {
    res.json(dbEngine.getGameCatalog());
  });

  app.post('/api/v1/store/purchase', (req, res) => {
    const { userId, gameId } = req.body;
    const result = dbEngine.executePurchase(userId, gameId);
    if (!result.success) return res.status(400).json(result);
    res.json(result);
  });

  // Entitlements & Wallets
  app.get('/api/v1/entitlements', (req, res) => {
    const userId = req.query.userId as string || 'usr-001';
    res.json(dbEngine.getEntitlements(userId));
  });

  app.get('/api/v1/wallets/:userId', (req, res) => {
    res.json(dbEngine.getWallet(req.params.userId));
  });

  app.get('/api/v1/transactions', (req, res) => {
    const userId = req.query.userId as string;
    res.json(dbEngine.getTransactions(userId));
  });

  // Multiplayer & Matchmaking
  app.get('/api/v1/matches', (req, res) => {
    res.json(dbEngine.getMatches());
  });

  app.get('/api/v1/matchmaking/queue', (req, res) => {
    res.json(dbEngine.getMatchmakingQueue());
  });

  app.post('/api/v1/matchmaking/queue', (req, res) => {
    const queued = dbEngine.queueForMatchmaking(req.body);
    res.json(queued);
  });

  // Digital Assets & Blockchain
  app.get('/api/v1/assets', (req, res) => {
    const owner = req.query.owner as string;
    res.json(dbEngine.getDigitalAssets(owner));
  });

  app.post('/api/v1/assets/mint', (req, res) => {
    const nft = dbEngine.mintDigitalAsset(req.body);
    res.json(nft);
  });

  // Cloud Saves
  app.get('/api/v1/cloud/:userId/:gameId', (req, res) => {
    const slot = parseInt(req.query.slot as string || '0');
    const save = dbEngine.getCloudSave(req.params.userId, req.params.gameId, slot);
    if (!save) return res.status(404).json({ error: 'Cloud save not found' });
    res.json(save);
  });

  app.post('/api/v1/cloud/save', (req, res) => {
    const { userId, gameId, slotIndex, fileName, sizeBytes } = req.body;
    const save = dbEngine.saveCloudData(userId, gameId, slotIndex || 0, fileName, sizeBytes || 1024);
    res.json(save);
  });

  // Telemetry Pipeline
  app.get('/api/v1/telemetry', (req, res) => {
    const limit = parseInt(req.query.limit as string || '50');
    res.json(dbEngine.getTelemetry(limit));
  });

  app.post('/api/v1/telemetry', (req, res) => {
    const evt = dbEngine.ingesteTelemetry(req.body);
    res.json(evt);
  });

  // Anti-Cheat
  app.get('/api/v1/anticheat', (req, res) => {
    res.json(dbEngine.getAnticheatFlags());
  });

  app.post('/api/v1/anticheat/flag', (req, res) => {
    const flag = dbEngine.flagAnticheat(req.body);
    res.json(flag);
  });

  // Firmware & Updates
  app.get('/api/v1/updates', (req, res) => {
    res.json(dbEngine.getSystemUpdates());
  });

  // R Analytics Engine
  app.get('/api/v1/analytics/r', (req, res) => {
    const result = RAnalyticsEngine.runRAnalyticsPipeline();
    res.json(result);
  });

  app.post('/api/v1/analytics/r/execute', (req, res) => {
    const { script } = req.body;
    const output = RAnalyticsEngine.executeCustomRScript(script || '');
    res.json(output);
  });

  // Synthetic Simulation Engine
  app.get('/api/v1/simulation', (req, res) => {
    res.json(dbEngine.getSimulationStats());
  });

  app.post('/api/v1/simulation/target', (req, res) => {
    const { targetPlayers } = req.body;
    const stats = dbEngine.setSimulationTarget(targetPlayers || 10000);
    res.json(stats);
  });

  // --- VITE MIDDLEWARE FOR DEV / STATIC SERVING FOR PROD ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ARCADIUM] Express backend platform running on http://localhost:${PORT}`);
  });
}

startServer();
