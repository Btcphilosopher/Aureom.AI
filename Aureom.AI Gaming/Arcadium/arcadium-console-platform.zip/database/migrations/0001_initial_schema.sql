-- ARCADIUM Console Platform Production PostgreSQL Schema Migration 0001
-- Strict transactional constraints, explicit foreign keys, indexes and triggers

CREATE TYPE hardware_revision_enum AS ENUM ('ARC-PRO-V2', 'ARC-SLIM-V1', 'ARC-DEV-KIT-V3');
CREATE TYPE security_state_enum AS ENUM ('HEALTHY', 'FLAGGED', 'COMPROMISED', 'REVOKED');
CREATE TYPE account_status_enum AS ENUM ('ACTIVE', 'SUSPENDED', 'BANNED', 'MFA_REQUIRED');
CREATE TYPE entitlement_type_enum AS ENUM ('GAME_OWNERSHIP', 'DLC_OWNERSHIP', 'SEASON_PASS', 'SUBSCRIPTION', 'DIGITAL_ITEM');

CREATE TABLE users (
    user_id VARCHAR(64) PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    display_name VARCHAR(128) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    country VARCHAR(3) NOT NULL,
    language VARCHAR(10) DEFAULT 'en-US',
    account_status account_status_enum DEFAULT 'ACTIVE',
    mfa_enabled BOOLEAN DEFAULT TRUE,
    mmr INTEGER DEFAULT 1000 CHECK (mmr >= 0),
    rank_tier VARCHAR(32) DEFAULT 'Gold',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE consoles (
    console_id VARCHAR(64) PRIMARY KEY,
    hardware_revision hardware_revision_enum NOT NULL,
    firmware_version VARCHAR(32) NOT NULL,
    region VARCHAR(32) NOT NULL,
    registration_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    last_seen TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    security_state security_state_enum DEFAULT 'HEALTHY',
    ip_address VARCHAR(45) NOT NULL,
    mac_address VARCHAR(17) NOT NULL,
    primary_user_id VARCHAR(64) REFERENCES users(user_id) ON DELETE CASCADE,
    attestation_token TEXT NOT NULL
);

CREATE TABLE games (
    game_id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    publisher VARCHAR(128) NOT NULL,
    developer VARCHAR(128) NOT NULL,
    current_version VARCHAR(32) NOT NULL,
    price_arc NUMERIC(12,2) CHECK (price_arc >= 0),
    price_usd NUMERIC(12,2) CHECK (price_usd >= 0),
    age_rating VARCHAR(16) NOT NULL
);

CREATE TABLE game_entitlements (
    entitlement_id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) REFERENCES users(user_id) ON DELETE CASCADE,
    game_id VARCHAR(64) REFERENCES games(game_id) ON DELETE CASCADE,
    type entitlement_type_enum NOT NULL,
    granted_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    CONSTRAINT unique_user_game_entitlement UNIQUE (user_id, game_id, type)
);

CREATE TABLE wallets (
    user_id VARCHAR(64) PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE,
    arc_balance NUMERIC(18,4) DEFAULT 0 CHECK (arc_balance >= 0),
    gems_balance NUMERIC(18,4) DEFAULT 0 CHECK (gems_balance >= 0),
    gold_balance NUMERIC(18,4) DEFAULT 0 CHECK (gold_balance >= 0),
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
    transaction_id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) REFERENCES users(user_id) ON DELETE CASCADE,
    amount_arc NUMERIC(18,4) NOT NULL,
    item_id VARCHAR(64),
    item_name VARCHAR(255),
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(32) DEFAULT 'CONFIRMED',
    hash VARCHAR(128) UNIQUE NOT NULL
);

CREATE TABLE digital_assets (
    asset_id VARCHAR(64) PRIMARY KEY,
    game_id VARCHAR(64) REFERENCES games(game_id),
    collection_name VARCHAR(128) NOT NULL,
    token_id VARCHAR(64) NOT NULL,
    owner_user_id VARCHAR(64) REFERENCES users(user_id),
    blockchain_network VARCHAR(64) NOT NULL,
    on_chain_tx_hash VARCHAR(128) UNIQUE NOT NULL,
    rarity VARCHAR(32) NOT NULL,
    creation_time TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_consoles_user ON consoles(primary_user_id);
CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_entitlements_user ON game_entitlements(user_id);
