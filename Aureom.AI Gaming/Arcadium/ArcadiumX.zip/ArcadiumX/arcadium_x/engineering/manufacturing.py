"""engineering/manufacturing.py -- ManufacturabilityScore & volume economics."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.architecture import nearest_volume_tier
from arcadium_x.engineering.supply_chain import SupplyChainResult
from arcadium_x.thermal.cooling import CoolingResult
from arcadium_x.chassis.industrial_design import ChassisResult


@dataclass
class ManufacturabilityResult:
    component_simplicity_score: float
    assembly_complexity_score: float
    thermal_complexity_score: float
    pcb_complexity_score: float
    test_complexity_score: float
    supply_chain_score: float
    manufacturability_score: float  # 0-100 overall, weighted


@dataclass
class VolumeEconomics:
    manufacturing_volume: int
    tier_floor_units: int
    unit_cost_multiplier: float
    tooling_cost_per_unit_usd: float


def evaluate_volume(manufacturing_volume: int) -> VolumeEconomics:
    tier_units, multiplier, tooling = nearest_volume_tier(manufacturing_volume)
    return VolumeEconomics(
        manufacturing_volume=manufacturing_volume,
        tier_floor_units=tier_units,
        unit_cost_multiplier=multiplier,
        tooling_cost_per_unit_usd=tooling,
    )


def evaluate_manufacturability(
    controller_count: int,
    port_count: int,
    memory_channels: int,
    storage_channels: int,
    gpu_compute_units: int,
    cooling: CoolingResult,
    chassis: ChassisResult,
    supply_chain: SupplyChainResult,
) -> ManufacturabilityResult:
    # Component simplicity: fewer/lower-tier distinct interfaces = simpler
    component_simplicity = max(0.0, 100.0 - (memory_channels + storage_channels) * 1.1)

    # Assembly complexity: more fans/controllers/ports = more assembly steps
    assembly_steps = 6 + controller_count * 0.6 + port_count * 0.4
    assembly_complexity = max(0.0, 100.0 - assembly_steps * 1.6)

    thermal_complexity = cooling.manufacturability_index

    pcb_complexity = max(0.0, 100.0 - (gpu_compute_units / 96.0 * 35 + memory_channels * 1.3))

    test_complexity = max(0.0, 100.0 - (100 - cooling.manufacturability_index) * 0.3
                          - (100 - chassis.manufacturability_index) * 0.3)

    supply_chain_score = max(0.0, 100.0 - supply_chain.risk_score)

    overall = (
        0.18 * component_simplicity
        + 0.16 * assembly_complexity
        + 0.16 * thermal_complexity
        + 0.16 * pcb_complexity
        + 0.14 * test_complexity
        + 0.20 * supply_chain_score
    )

    return ManufacturabilityResult(
        component_simplicity_score=round(component_simplicity, 1),
        assembly_complexity_score=round(assembly_complexity, 1),
        thermal_complexity_score=round(thermal_complexity, 1),
        pcb_complexity_score=round(pcb_complexity, 1),
        test_complexity_score=round(test_complexity, 1),
        supply_chain_score=round(supply_chain_score, 1),
        manufacturability_score=round(overall, 1),
    )
