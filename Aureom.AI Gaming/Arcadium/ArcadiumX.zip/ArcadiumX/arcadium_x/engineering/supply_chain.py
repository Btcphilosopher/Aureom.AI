"""engineering/supply_chain.py -- ComponentSupplyEngine: availability & risk flags."""
from __future__ import annotations

from dataclasses import dataclass, field

# Highest-tier catalogue entries are treated as leading-edge / single-source parts.
HIGH_RISK_GPUS = {"GPU-X4"}
HIGH_RISK_MEMORY = {"MEM-96", "MEM-128"}
HIGH_RISK_STORAGE = {"SSD-8TB"}
HIGH_RISK_COOLING = {"LIQUID_COOLING"}


@dataclass
class SupplyChainResult:
    warnings: list
    risk_score: float  # 0 (safe) - 100 (severe)
    lead_time_weeks: float


class ComponentSupplyEngine:
    def evaluate(self, gpu_name: str, memory_name: str, storage_name: str, cooling_name: str,
                 volume_units: int) -> SupplyChainResult:
        warnings = []
        risk = 8.0  # baseline supply-chain friction

        if gpu_name in HIGH_RISK_GPUS:
            warnings.append("GPU DEPENDENCY: flagship GPU die is leading-edge and effectively single-source")
            risk += 30

        if memory_name in HIGH_RISK_MEMORY:
            warnings.append("MEMORY SHORTAGE RISK: top-tier memory capacity draws on constrained HBM/GDDR7X supply")
            risk += 22

        if storage_name in HIGH_RISK_STORAGE:
            warnings.append("HIGH SUPPLY RISK: 8TB NAND allocation competes with enterprise/datacentre demand")
            risk += 14

        if cooling_name in HIGH_RISK_COOLING:
            warnings.append("SINGLE-SOURCE COMPONENT: liquid-cooling loops rely on a narrow supplier base")
            risk += 18

        if volume_units >= 5_000_000:
            warnings.append("HIGH VOLUME COMMITMENT: component allocation must be locked 12+ months ahead")
            risk += 10

        risk = min(100.0, risk)

        base_lead_time = 6.0
        lead_time = base_lead_time + risk * 0.12

        return SupplyChainResult(
            warnings=warnings,
            risk_score=round(risk, 1),
            lead_time_weeks=round(lead_time, 1),
        )
