"""engineering/reliability.py -- ReliabilityEngine: MTBF, failure probability, serviceability."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.thermal.cooling import CoolingResult
from arcadium_x.thermal.thermal import ThermalResult
from arcadium_x.power.psu import PSUResult
from arcadium_x.controllers.controller import ControllerResult
from arcadium_x.chassis.industrial_design import ChassisResult

HOURS_PER_YEAR = 8760


@dataclass
class ReliabilityResult:
    mtbf_hours: float
    annual_failure_probability_pct: float
    thermal_stress_index: float  # 0-100, higher = more accelerated wear
    serviceability_score: float  # 0-100
    fan_failure_risk_pct: float
    ssd_failure_risk_pct: float
    psu_failure_risk_pct: float


class ReliabilityEngine:
    def evaluate(
        self,
        cooling: CoolingResult,
        thermal_peak: ThermalResult,
        psu: PSUResult,
        controller: ControllerResult,
        chassis: ChassisResult,
        fan_count: int,
    ) -> ReliabilityResult:
        # Thermal stress rises sharply once components run hot / throttle
        hottest = thermal_peak.hottest_temp_c
        thermal_stress = max(0.0, min(100.0, (hottest - 55) * 1.6))
        if thermal_peak.throttling:
            thermal_stress = min(100.0, thermal_stress + 20)

        # Baseline component MTBFs (hours), degraded by thermal stress and improved by
        # cooling/PSU quality indices.
        base_mtbf_system = 55_000
        cooling_bonus = (cooling.reliability_index - 80) * 250
        psu_bonus = (psu.headroom_pct - 15) * 180
        fan_penalty = max(0, fan_count - 1) * 2200  # more moving parts = more failure points

        mtbf = base_mtbf_system + cooling_bonus + psu_bonus - fan_penalty
        mtbf *= (1 - thermal_stress / 260.0)
        mtbf = max(4000.0, mtbf)

        annual_failure_prob = 100.0 * (1 - pow(2.71828, -HOURS_PER_YEAR / mtbf))

        fan_failure_risk = min(60.0, 3.0 + fan_count * 2.2 + thermal_stress * 0.25)
        ssd_failure_risk = min(40.0, 2.0 + (100 - cooling.reliability_index) * 0.15)
        psu_failure_risk = min(40.0, 2.0 + max(0, 20 - psu.headroom_pct) * 0.8)

        serviceability = (chassis.manufacturability_index * 0.5
                           + cooling.manufacturability_index * 0.3
                           + max(0, 100 - fan_count * 5) * 0.2)
        serviceability = round(min(100.0, serviceability), 1)

        return ReliabilityResult(
            mtbf_hours=round(mtbf, 0),
            annual_failure_probability_pct=round(annual_failure_prob, 2),
            thermal_stress_index=round(thermal_stress, 1),
            serviceability_score=serviceability,
            fan_failure_risk_pct=round(fan_failure_risk, 1),
            ssd_failure_risk_pct=round(ssd_failure_risk, 1),
            psu_failure_risk_pct=round(psu_failure_risk, 1),
        )
