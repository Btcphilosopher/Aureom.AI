"""engineering/cost.py -- CostEngineeringEngine & the $1,000 RRP economic model.

Distinguishes BOM from assembly/packaging/logistics/warranty/software/
marketing/margin, and walks the full RRP -> wholesale -> manufacturer
revenue -> manufacturing cost -> gross margin waterfall (spec sections 25-26).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core.specs import EconomicConfig


@dataclass
class BOMBreakdown:
    chip_cost_usd: float          # CPU + GPU + AI silicon
    memory_cost_usd: float
    storage_cost_usd: float
    pcb_cost_usd: float
    psu_cost_usd: float
    cooling_cost_usd: float
    chassis_cost_usd: float
    controller_cost_usd: float
    network_cost_usd: float
    io_cost_usd: float
    security_cost_usd: float
    total_bom_usd: float


@dataclass
class ManufacturingCost:
    bom: BOMBreakdown
    assembly_cost_usd: float
    testing_cost_usd: float
    packaging_cost_usd: float
    shipping_cost_usd: float
    warranty_reserve_usd: float
    software_platform_cost_usd: float
    tooling_amortisation_usd: float
    unit_cost_before_scale_usd: float
    volume_discount_multiplier: float
    manufacturing_cost_usd: float  # final, scale-adjusted


@dataclass
class EconomicsResult:
    rrp_usd: float
    retail_keep_usd: float
    wholesale_price_usd: float
    distributor_keep_usd: float
    manufacturer_gross_receipt_usd: float
    marketing_reserve_usd: float
    manufacturer_net_revenue_usd: float
    manufacturing_cost_usd: float
    gross_profit_usd: float
    gross_margin_pct: float
    cost_to_rrp_ratio_pct: float
    viable: bool
    notes: list = field(default_factory=list)


# PCB complexity cost: base + per memory channel + per storage channel + GPU CU tier
def _pcb_cost(memory_channels: int, storage_channels: int, gpu_compute_units: int) -> float:
    base = 14.0
    base += memory_channels * 1.6
    base += storage_channels * 0.9
    base += (gpu_compute_units / 32.0) * 6.0
    return round(base, 2)


def compute_bom(
    cpu_cost: float, gpu_cost: float, ai_cost: float,
    memory_cost: float, storage_cost: float,
    memory_channels: int, storage_channels: int, gpu_compute_units: int,
    psu_cost: float, cooling_cost: float, chassis_material_cost: float,
    controller_total_cost: float, network_cost: float, io_cost: float, security_cost: float,
) -> BOMBreakdown:
    chip = round(cpu_cost + gpu_cost + ai_cost, 2)
    pcb = _pcb_cost(memory_channels, storage_channels, gpu_compute_units)

    total = round(chip + memory_cost + storage_cost + pcb + psu_cost + cooling_cost
                  + chassis_material_cost + controller_total_cost + network_cost
                  + io_cost + security_cost, 2)

    return BOMBreakdown(
        chip_cost_usd=chip,
        memory_cost_usd=round(memory_cost, 2),
        storage_cost_usd=round(storage_cost, 2),
        pcb_cost_usd=pcb,
        psu_cost_usd=round(psu_cost, 2),
        cooling_cost_usd=round(cooling_cost, 2),
        chassis_cost_usd=round(chassis_material_cost, 2),
        controller_cost_usd=round(controller_total_cost, 2),
        network_cost_usd=round(network_cost, 2),
        io_cost_usd=round(io_cost, 2),
        security_cost_usd=round(security_cost, 2),
        total_bom_usd=total,
    )


def compute_manufacturing_cost(
    bom: BOMBreakdown,
    shipping_cost_usd: float,
    economics: EconomicConfig,
    volume_unit_multiplier: float,
    tooling_per_unit_usd: float,
) -> ManufacturingCost:
    assembly = round(bom.total_bom_usd * 0.055 + 4.20, 2)
    testing = round(bom.total_bom_usd * 0.020 + 1.80, 2)
    packaging = round(2.60 + bom.total_bom_usd * 0.006, 2)
    warranty = round(economics.rrp_usd * economics.warranty_reserve_pct, 2)
    software = economics.software_platform_cost_usd

    unit_cost_before_scale = round(
        bom.total_bom_usd + assembly + testing + packaging + shipping_cost_usd
        + warranty + software + tooling_per_unit_usd, 2
    )

    final_cost = round(
        (bom.total_bom_usd * volume_unit_multiplier)
        + assembly + testing + packaging + shipping_cost_usd
        + warranty + software + tooling_per_unit_usd, 2
    )

    return ManufacturingCost(
        bom=bom,
        assembly_cost_usd=assembly,
        testing_cost_usd=testing,
        packaging_cost_usd=packaging,
        shipping_cost_usd=round(shipping_cost_usd, 2),
        warranty_reserve_usd=warranty,
        software_platform_cost_usd=software,
        tooling_amortisation_usd=round(tooling_per_unit_usd, 2),
        unit_cost_before_scale_usd=unit_cost_before_scale,
        volume_discount_multiplier=volume_unit_multiplier,
        manufacturing_cost_usd=final_cost,
    )


def compute_economics(economics: EconomicConfig, manufacturing_cost_usd: float) -> EconomicsResult:
    rrp = economics.rrp_usd
    retail_keep = rrp * economics.retail_margin_pct
    wholesale = rrp - retail_keep

    distributor_keep = wholesale * economics.distributor_margin_pct
    manufacturer_gross_receipt = wholesale - distributor_keep

    marketing_reserve = rrp * economics.marketing_reserve_pct
    manufacturer_net_revenue = manufacturer_gross_receipt - marketing_reserve

    gross_profit = manufacturer_net_revenue - manufacturing_cost_usd
    gross_margin_pct = (100.0 * gross_profit / manufacturer_net_revenue) if manufacturer_net_revenue else -999.0
    cost_ratio = 100.0 * manufacturing_cost_usd / rrp if rrp else 999.0

    notes = []
    viable = gross_margin_pct >= 0
    if not viable:
        notes.append(f"NOT VIABLE: manufacturing cost (${manufacturing_cost_usd:.2f}) exceeds net "
                      f"manufacturer revenue (${manufacturer_net_revenue:.2f}) at this RRP")
    elif gross_margin_pct < 15:
        notes.append(f"THIN MARGIN: {gross_margin_pct:.1f}% gross margin is below typical premium-hardware target (~20-30%)")
    elif gross_margin_pct > 45:
        notes.append(f"HIGH MARGIN: {gross_margin_pct:.1f}% suggests room to invest more BOM for competitive advantage")

    return EconomicsResult(
        rrp_usd=rrp,
        retail_keep_usd=round(retail_keep, 2),
        wholesale_price_usd=round(wholesale, 2),
        distributor_keep_usd=round(distributor_keep, 2),
        manufacturer_gross_receipt_usd=round(manufacturer_gross_receipt, 2),
        marketing_reserve_usd=round(marketing_reserve, 2),
        manufacturer_net_revenue_usd=round(manufacturer_net_revenue, 2),
        manufacturing_cost_usd=round(manufacturing_cost_usd, 2),
        gross_profit_usd=round(gross_profit, 2),
        gross_margin_pct=round(gross_margin_pct, 2),
        cost_to_rrp_ratio_pct=round(cost_ratio, 1),
        viable=viable,
        notes=notes,
    )
