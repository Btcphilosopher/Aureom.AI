"""controllers/input_latency.py -- end-to-end controller-to-display latency pipeline."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.controllers.controller import ControllerResult
from arcadium_x.io.bus import FabricResult


@dataclass
class LatencyBreakdown:
    controller_ms: float
    transport_ms: float
    input_processor_ms: float
    system_bus_ms: float
    cpu_frame_ms: float
    gpu_render_ms: float
    display_ms: float
    total_ms: float


def evaluate_input_latency(
    controller: ControllerResult,
    fabric: FabricResult,
    cpu_frametime_ms: float,
    gpu_frametime_ms: float,
    refresh_hz: int,
    wireless: bool,
) -> LatencyBreakdown:
    controller_ms = controller.input_latency_ms
    transport_ms = 3.5 if wireless else 0.6
    input_processor_ms = 0.8
    # Fabric congestion adds queueing delay on the system bus
    system_bus_ms = 0.4 * (1 + max(0.0, fabric.congestion_pct - 60) / 100.0)
    display_ms = (1000.0 / refresh_hz) * 0.5  # avg wait for next scan-out, half a frame period

    total = (controller_ms + transport_ms + input_processor_ms + system_bus_ms
             + cpu_frametime_ms + gpu_frametime_ms + display_ms)

    return LatencyBreakdown(
        controller_ms=round(controller_ms, 2),
        transport_ms=round(transport_ms, 2),
        input_processor_ms=round(input_processor_ms, 2),
        system_bus_ms=round(system_bus_ms, 2),
        cpu_frame_ms=round(cpu_frametime_ms, 2),
        gpu_render_ms=round(gpu_frametime_ms, 2),
        display_ms=round(display_ms, 2),
        total_ms=round(total, 2),
    )
