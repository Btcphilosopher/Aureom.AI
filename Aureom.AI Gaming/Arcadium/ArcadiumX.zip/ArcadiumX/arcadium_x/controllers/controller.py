"""controllers/controller.py -- premium controller BOM & durability modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import ControllerSpec


@dataclass
class ControllerResult:
    spec_name: str
    unit_count: int
    bom_per_unit_usd: float
    total_bom_usd: float
    input_latency_ms: float
    total_power_w: float
    durability_score: float


def evaluate_controllers(spec: ControllerSpec, count: int) -> ControllerResult:
    if count not in (1, 2, 3, 4, 8):
        raise ValueError("controller_count must be one of 1, 2, 3, 4, 8")

    bom = spec.cost_usd
    # charging/idle draw per paired controller
    power = 0.35 * count

    durability = spec.durability_index
    if spec.hall_effect:
        durability += 6  # hall-effect sticks eliminate mechanical drift wear
    durability = min(100.0, durability)

    return ControllerResult(
        spec_name=spec.name,
        unit_count=count,
        bom_per_unit_usd=bom,
        total_bom_usd=round(bom * count, 2),
        input_latency_ms=spec.base_latency_ms,
        total_power_w=round(power, 2),
        durability_score=round(durability, 1),
    )
