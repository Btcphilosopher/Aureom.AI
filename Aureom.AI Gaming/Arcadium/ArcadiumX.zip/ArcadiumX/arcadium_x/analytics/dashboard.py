"""analytics/dashboard.py -- the premium engineering dashboard (spec section 37)
plus optional Matplotlib chart generation for Pareto frontiers and revision
history. Charting is best-effort: if matplotlib isn't installed the text
dashboard still works standalone.
"""
from __future__ import annotations

from pathlib import Path

from arcadium_x.simulation.testbench import TestBenchReport

_RULE = "-" * 60


def render_dashboard(tb: TestBenchReport) -> str:
    r = tb.simulation
    d = r.design
    p = tb.performance

    thermal_score = max(0.0, min(100.0, r.thermal_by_state["peak"].thermal_headroom_pct + 40))
    power_score = max(0.0, min(100.0, 100.0 - (r.power.totals_w["peak"] / r.psu.wattage) * 100 + 15))

    lines = [
        _RULE,
        f"{d.name}",
        f"REVISION {d.revision:02d}" + (f"  -- {d.notes}" if d.notes else ""),
        _RULE,
        f"PERFORMANCE       {p.total:>6.1f}",
        f"THERMAL           {thermal_score:>6.1f}",
        f"POWER             {power_score:>6.1f}",
        f"ACOUSTICS         {r.acoustics.silent_performance_index:>6.1f}",
        f"RELIABILITY       {min(100.0, r.reliability.mtbf_hours/1000):>6.1f}",
        f"MANUFACTURING     {r.manufacturability.manufacturability_score:>6.1f}",
        f"COST              ${r.manufacturing_cost.manufacturing_cost_usd:>7.2f}",
        f"MARGIN            {r.economics.gross_margin_pct:>6.1f}%",
        _RULE,
        f"CPU {d.cpu}  GPU {d.gpu}  AI {d.ai}  MEM {d.memory}  SSD {d.storage}",
        f"Cooling {d.cooling}  PSU {d.psu}  Chassis {d.chassis_material}",
        _RULE,
    ]
    if r.warnings:
        lines.append("WARNINGS:")
        for w in r.warnings:
            lines.append(f"  ! {w}")
        lines.append(_RULE)
    return "\n".join(lines)


def plot_pareto_frontier(frontier, out_path: str | Path) -> str | None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None

    xs = [p.cost_usd for p in frontier]
    ys = [p.performance for p in frontier]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(xs, ys, marker="o", color="#2563eb", linewidth=1.6)
    for p in frontier:
        ax.annotate(p.revision_label, (p.cost_usd, p.performance), fontsize=6, rotation=20,
                    xytext=(3, 3), textcoords="offset points")
    ax.set_xlabel("Manufacturing cost (USD)")
    ax.set_ylabel("ARCADIUM Performance Index")
    ax.set_title("ARCADIUM X -- Pareto Frontier (Performance vs Cost)")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return str(out_path)


def plot_revision_history(history_rows: list[dict], out_path: str | Path) -> str | None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None

    revs = [row["revision"] for row in history_rows]
    perf = [row["performance"] for row in history_rows]
    cost = [row["cost"] for row in history_rows]
    margin = [row["margin_pct"] for row in history_rows]

    fig, ax1 = plt.subplots(figsize=(8, 5))
    ax1.plot(revs, perf, marker="o", color="#2563eb", label="Performance index")
    ax1.set_xlabel("Revision")
    ax1.set_ylabel("Performance index", color="#2563eb")
    ax1.tick_params(axis="y", labelcolor="#2563eb")

    ax2 = ax1.twinx()
    ax2.plot(revs, cost, marker="s", color="#dc2626", label="Manufacturing cost ($)")
    ax2.plot(revs, margin, marker="^", color="#16a34a", label="Gross margin (%)")
    ax2.set_ylabel("Cost ($) / Margin (%)")

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", fontsize=8)

    ax1.set_title("ARCADIUM X -- Design Revision History")
    ax1.grid(True, alpha=0.3)
    fig.tight_layout()

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return str(out_path)
