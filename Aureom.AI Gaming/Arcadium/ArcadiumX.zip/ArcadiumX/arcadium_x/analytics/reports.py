"""analytics/reports.py -- engineering report generation (spec section 40)."""
from __future__ import annotations

from arcadium_x.simulation.testbench import TestBenchReport

_RULE = "=" * 72


def _h(title: str) -> str:
    return f"\n{_RULE}\n{title}\n{_RULE}"


def hardware_architecture_report(tb: TestBenchReport) -> str:
    r = tb.simulation
    d = r.design
    lines = [_h(f"{d.name} -- HARDWARE ARCHITECTURE REPORT (Revision {d.revision})")]
    lines.append(f"Generation: {d.generation}   Workload: {d.workload}   Display: {d.display.resolution}@{d.display.refresh_hz}Hz")
    lines.append("")
    lines.append(f"CPU        {r.cpu.spec_name:<10} {r.cpu.effective_clock_ghz:>5.2f} GHz  score {r.cpu.performance_score:>5.1f}  {r.cpu.power_w:>5.1f}W  ${r.cpu.cost_usd:>6.2f}")
    lines.append(f"GPU        {r.gpu.spec_name:<10} {r.gpu.effective_tflops:>5.1f} TFLOPs score {r.gpu.performance_score:>5.1f}  {r.gpu.power_w:>5.1f}W  ${r.gpu.cost_usd:>6.2f}")
    lines.append(f"AI/NPU     {r.ai.spec_name:<10} {r.ai.effective_tops:>5.1f} TOPS   score {r.ai.performance_score:>5.1f}  {r.ai.power_w:>5.1f}W  ${r.ai.cost_usd:>6.2f}")
    lines.append(f"Memory     {r.memory.spec_name:<10} {r.memory.capacity_gb:>4d} GB    bw {r.memory.effective_bandwidth_gbps:>6.1f} GB/s  latency {r.memory.effective_latency_ns:.1f}ns")
    lines.append(f"Storage    {r.storage.spec_name:<10} {r.storage.capacity_tb:>4.0f} TB    read {r.storage.seq_read_gbps:>5.1f} GB/s  write {r.storage.seq_write_gbps:.1f} GB/s")
    lines.append("")
    lines.append(f"System fabric bandwidth: {r.fabric.fabric_bandwidth_gbps:.0f} GB/s   congestion: {r.fabric.congestion_pct:.0f}%   bottleneck link: {r.fabric.bottleneck_link}")
    lines.append(f"Memory diagnosis: {r.memory_diagnosis.diagnosis}  -- {r.memory_diagnosis.recommendation}")
    lines.append("")
    lines.append(f"Networking: {r.network.spec_name} ({r.network.condition}) -- wired {r.network.wired_throughput_gbps:.1f} Gb/s / wireless {r.network.wireless_throughput_gbps:.1f} Gb/s, {r.network.latency_ms:.1f}ms")
    lines.append(f"I/O: {sum(v['count'] for v in r.io.port_breakdown.values())} ports, {r.io.total_bandwidth_gbps:.0f} Gb/s aggregate")
    lines.append(f"Security: {d.security} -- capability {r.security_capability:.0f}/100, {r.security_overhead_pct:.1f}% overhead")
    lines.append(f"Controllers: {r.controller.unit_count}x {r.controller.spec_name}, {r.controller.input_latency_ms:.1f}ms base latency, durability {r.controller.durability_score:.0f}/100")
    lines.append(f"Total input-to-display latency: {r.latency.total_ms:.1f} ms")
    return "\n".join(lines)


def thermal_report(tb: TestBenchReport) -> str:
    r = tb.simulation
    lines = [_h(f"{r.design.name} -- THERMAL REPORT")]
    lines.append(f"Cooling solution: {r.cooling.spec_name}  (capacity {r.cooling.capacity_w:.0f}W)")
    lines.append("")
    for state in ("idle", "typical", "heavy", "peak"):
        t = r.thermal_by_state[state]
        lines.append(f"[{state.upper():<7}] heat {t.total_heat_w:>6.1f}W  headroom {t.thermal_headroom_pct:>6.1f}%  "
                      f"hottest {t.hottest_component:<7}{t.hottest_temp_c:>5.1f}C"
                      f"{'  ** THROTTLING **' if t.throttling else ''}")
    peak = r.thermal_by_state["peak"]
    lines.append("")
    lines.append("Junction temperatures at PEAK load:")
    for comp, temp in peak.junction_temps_c.items():
        lines.append(f"  {comp:<8} {temp:>6.1f} C")
    return "\n".join(lines)


def power_report(tb: TestBenchReport) -> str:
    r = tb.simulation
    lines = [_h(f"{r.design.name} -- POWER REPORT")]
    lines.append(f"PSU: {r.psu.spec_name} ({r.psu.wattage}W, {r.psu.efficiency*100:.0f}% efficient)")
    lines.append(f"Headroom at peak: {r.psu.headroom_pct:.1f}%   Safe: {r.psu.safe}")
    if r.psu.warning:
        lines.append(f"  WARNING: {r.psu.warning}")
    lines.append("")
    for state in ("idle", "typical", "heavy", "peak"):
        total = r.power.totals_w[state]
        lines.append(f"[{state.upper():<7}] {total:>7.1f} W")
    lines.append("")
    lines.append("Per-component breakdown at PEAK:")
    for comp, watts in r.power.by_state["peak"].items():
        lines.append(f"  {comp:<8} {watts:>6.1f} W")
    return "\n".join(lines)


def acoustic_report(tb: TestBenchReport) -> str:
    r = tb.simulation
    a = r.acoustics
    lines = [_h(f"{r.design.name} -- ACOUSTIC REPORT")]
    lines.append(f"Idle:    {a.idle_dba:>5.1f} dBA")
    lines.append(f"Typical: {a.typical_dba:>5.1f} dBA")
    lines.append(f"Heavy:   {a.heavy_dba:>5.1f} dBA")
    lines.append(f"Peak:    {a.peak_dba:>5.1f} dBA   (fan {a.fan_rpm_peak:.0f} RPM)")
    lines.append("")
    lines.append(f"Silent Performance Index: {a.silent_performance_index:.1f} / 100")
    return "\n".join(lines)


def cost_report(tb: TestBenchReport) -> str:
    r = tb.simulation
    b = r.bom
    m = r.manufacturing_cost
    e = r.economics
    lines = [_h(f"{r.design.name} -- COST REPORT")]
    lines.append("Bill of materials:")
    lines.append(f"  Chip (CPU+GPU+AI)   ${b.chip_cost_usd:>8.2f}")
    lines.append(f"  Memory              ${b.memory_cost_usd:>8.2f}")
    lines.append(f"  Storage             ${b.storage_cost_usd:>8.2f}")
    lines.append(f"  PCB                 ${b.pcb_cost_usd:>8.2f}")
    lines.append(f"  PSU                 ${b.psu_cost_usd:>8.2f}")
    lines.append(f"  Cooling             ${b.cooling_cost_usd:>8.2f}")
    lines.append(f"  Chassis             ${b.chassis_cost_usd:>8.2f}")
    lines.append(f"  Controllers         ${b.controller_cost_usd:>8.2f}")
    lines.append(f"  Network             ${b.network_cost_usd:>8.2f}")
    lines.append(f"  I/O                 ${b.io_cost_usd:>8.2f}")
    lines.append(f"  Security            ${b.security_cost_usd:>8.2f}")
    lines.append(f"  ------------------------------")
    lines.append(f"  TOTAL BOM           ${b.total_bom_usd:>8.2f}")
    lines.append("")
    lines.append(f"Assembly    ${m.assembly_cost_usd:>8.2f}")
    lines.append(f"Testing     ${m.testing_cost_usd:>8.2f}")
    lines.append(f"Packaging   ${m.packaging_cost_usd:>8.2f}")
    lines.append(f"Shipping    ${m.shipping_cost_usd:>8.2f}")
    lines.append(f"Warranty    ${m.warranty_reserve_usd:>8.2f}")
    lines.append(f"Software    ${m.software_platform_cost_usd:>8.2f}")
    lines.append(f"Tooling     ${m.tooling_amortisation_usd:>8.2f}  (at {r.volume_economics.manufacturing_volume:,} units)")
    lines.append(f"------------------------------------")
    lines.append(f"MANUFACTURING COST  ${m.manufacturing_cost_usd:>8.2f}")
    lines.append("")
    lines.append(f"RRP                       ${e.rrp_usd:>8.2f}")
    lines.append(f"  Retail keeps            ${e.retail_keep_usd:>8.2f}")
    lines.append(f"  Wholesale price         ${e.wholesale_price_usd:>8.2f}")
    lines.append(f"  Distributor keeps       ${e.distributor_keep_usd:>8.2f}")
    lines.append(f"  Manufacturer receipt    ${e.manufacturer_gross_receipt_usd:>8.2f}")
    lines.append(f"  Marketing reserve       ${e.marketing_reserve_usd:>8.2f}")
    lines.append(f"  Manufacturer net rev.   ${e.manufacturer_net_revenue_usd:>8.2f}")
    lines.append(f"  Manufacturing cost      ${e.manufacturing_cost_usd:>8.2f}")
    lines.append(f"  GROSS PROFIT            ${e.gross_profit_usd:>8.2f}")
    lines.append(f"  GROSS MARGIN            {e.gross_margin_pct:>7.1f}%")
    for note in e.notes:
        lines.append(f"  NOTE: {note}")
    return "\n".join(lines)


def performance_report(tb: TestBenchReport) -> str:
    r = tb.simulation
    p = tb.performance
    lines = [_h(f"{r.design.name} -- PERFORMANCE REPORT")]
    for k, v in p.scores.items():
        lines.append(f"  {k.upper():<8} {v:>6.1f}   (weight {p.weights.get(k, 0)*100:.0f}%)")
    lines.append("")
    lines.append(f"  Bottleneck penalty applied: x{p.bottleneck_penalty:.3f} ({r.memory_diagnosis.diagnosis})")
    lines.append(f"  Security overhead penalty:  x{p.security_overhead_penalty:.4f}")
    lines.append("")
    lines.append(f"  ARCADIUM PERFORMANCE INDEX   {p.total:>6.1f}")
    lines.append("")
    lines.append(f"Bottleneck diagnosis: {tb.bottleneck.diagnosis}")
    lines.append(f"  {tb.bottleneck.detail}")
    lines.append(f"  Recommendation: {tb.bottleneck.recommendation}")
    lines.append("")
    lines.append(f"Input-to-display latency: {r.latency.total_ms:.1f} ms "
                  f"(controller {r.latency.controller_ms} + transport {r.latency.transport_ms} + "
                  f"processor {r.latency.input_processor_ms} + bus {r.latency.system_bus_ms} + "
                  f"cpu {r.latency.cpu_frame_ms} + gpu {r.latency.gpu_render_ms} + display {r.latency.display_ms})")
    return "\n".join(lines)


def full_report(tb: TestBenchReport) -> str:
    return "\n".join([
        hardware_architecture_report(tb),
        thermal_report(tb),
        power_report(tb),
        acoustic_report(tb),
        cost_report(tb),
        performance_report(tb),
    ])
