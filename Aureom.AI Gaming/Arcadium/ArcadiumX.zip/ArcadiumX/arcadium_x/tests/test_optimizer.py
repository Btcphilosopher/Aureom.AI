"""Optimiser smoke tests: deterministic, converges, and respects the scenario contract."""
import unittest

from arcadium_x.tests.test_pipeline import default_design
from arcadium_x.optimisation.optimizer import ArcadiumOptimizer, Constraints, ObjectiveWeights
from arcadium_x.optimisation.pareto import performance_cost_frontier, select_by_preference
from arcadium_x.optimisation.scenarios import SCENARIOS, run_scenario


class TestOptimizer(unittest.TestCase):
    def test_deterministic_with_fixed_seed(self):
        design = default_design()
        r1 = ArcadiumOptimizer(design, seed=7).run(generations=4, population_size=10)
        r2 = ArcadiumOptimizer(design, seed=7).run(generations=4, population_size=10)
        self.assertEqual(r1.best.genes, r2.best.genes)
        self.assertAlmostEqual(r1.best.fitness, r2.best.fitness, places=6)

    def test_all_scenarios_are_registered_and_runnable(self):
        design = default_design(generation="GEN2", workload="MEDIUM")
        for key in SCENARIOS:
            scenario, result = run_scenario(key, design, generations=3, population_size=8, seed=1)
            self.assertEqual(scenario.key, key)
            self.assertGreater(len(result.all_evaluated), 0)

    def test_pareto_frontier_is_non_dominated(self):
        design = default_design(generation="GEN3", workload="MEDIUM")
        result = ArcadiumOptimizer(design, seed=3).run(generations=5, population_size=12)
        frontier = performance_cost_frontier(result.all_evaluated, feasible_only=False)
        for a in frontier:
            for b in frontier:
                if a is b:
                    continue
                dominated = (b.performance >= a.performance and b.cost_usd <= a.cost_usd
                             and (b.performance > a.performance or b.cost_usd < a.cost_usd))
                self.assertFalse(dominated, "frontier point should not be dominated by another frontier point")

    def test_select_by_preference_returns_extreme_of_metric(self):
        design = default_design(generation="GEN3", workload="MEDIUM")
        result = ArcadiumOptimizer(design, seed=5).run(generations=5, population_size=12)
        quietest = select_by_preference(result.all_evaluated, "minimum_noise", feasible_only=False)
        loudest_dba = max(i.testbench.simulation.acoustics.peak_dba for i in result.all_evaluated)
        self.assertLessEqual(quietest.testbench.simulation.acoustics.peak_dba, loudest_dba)


if __name__ == "__main__":
    unittest.main()
