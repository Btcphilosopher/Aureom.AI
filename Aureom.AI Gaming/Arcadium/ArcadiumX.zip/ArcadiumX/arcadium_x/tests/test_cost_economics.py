"""Verifies the $1,000 RRP waterfall arithmetic is internally consistent (spec section 26)."""
import unittest

from arcadium_x.core.specs import EconomicConfig
from arcadium_x.engineering.cost import compute_economics


class TestEconomics(unittest.TestCase):
    def test_waterfall_is_internally_consistent(self):
        econ = EconomicConfig(rrp_usd=1000.0, retail_margin_pct=0.20, distributor_margin_pct=0.08,
                               marketing_reserve_pct=0.05, warranty_reserve_pct=0.02,
                               software_platform_cost_usd=15.0, manufacturing_volume=1_000_000)
        result = compute_economics(econ, manufacturing_cost_usd=550.0)

        self.assertAlmostEqual(result.retail_keep_usd + result.wholesale_price_usd, result.rrp_usd, places=2)
        self.assertAlmostEqual(
            result.distributor_keep_usd + result.manufacturer_gross_receipt_usd, result.wholesale_price_usd, places=2
        )
        self.assertAlmostEqual(
            result.manufacturer_net_revenue_usd + result.marketing_reserve_usd,
            result.manufacturer_gross_receipt_usd, places=2,
        )
        self.assertAlmostEqual(
            result.gross_profit_usd, result.manufacturer_net_revenue_usd - result.manufacturing_cost_usd, places=2
        )
        self.assertTrue(result.viable)

    def test_excess_manufacturing_cost_is_flagged_not_viable(self):
        econ = EconomicConfig(rrp_usd=1000.0)
        result = compute_economics(econ, manufacturing_cost_usd=5000.0)
        self.assertFalse(result.viable)
        self.assertTrue(any("NOT VIABLE" in n for n in result.notes))


if __name__ == "__main__":
    unittest.main()
