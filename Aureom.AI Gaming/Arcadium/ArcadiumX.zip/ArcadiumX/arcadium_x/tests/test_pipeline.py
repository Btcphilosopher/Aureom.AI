"""End-to-end pipeline sanity checks."""
import unittest

from arcadium_x.core.specs import ConsoleDesign
from arcadium_x.core.system import ConsoleSystem
from arcadium_x.simulation.testbench import TestBench


def default_design(**overrides) -> ConsoleDesign:
    base = dict(
        cpu="CPU-A3", gpu="GPU-X3", ai="AI-N2", memory="MEM-64", storage="SSD-4TB",
        cooling="VAPOUR_CHAMBER", psu="PSU-700W", chassis_material="ALUMINIUM",
        controller="PRO_PAD", network="NET-PRO", security="SEC-TPM",
    )
    base.update(overrides)
    return ConsoleDesign(**base)


class TestPipeline(unittest.TestCase):
    def test_simulate_runs_and_returns_bounded_scores(self):
        report = ConsoleSystem(default_design()).simulate()

        self.assertGreaterEqual(report.cpu.performance_score, 0)
        self.assertLessEqual(report.cpu.performance_score, 100)
        self.assertGreaterEqual(report.gpu.performance_score, 0)
        self.assertLessEqual(report.gpu.performance_score, 100)
        self.assertGreaterEqual(report.memory.performance_score, 0)
        self.assertLessEqual(report.memory.performance_score, 100.001)

        self.assertIn("idle", report.thermal_by_state)
        self.assertIn("peak", report.thermal_by_state)
        self.assertGreater(report.power.totals_w["peak"], report.power.totals_w["idle"])

    def test_testbench_produces_all_sections(self):
        tb = TestBench().run(default_design())
        self.assertIsNotNone(tb.performance)
        self.assertIsNotNone(tb.stress)
        self.assertIsNotNone(tb.bottleneck)
        self.assertIsNotNone(tb.assembly)
        self.assertTrue(0 <= tb.performance.total <= 100)

    def test_all_catalogue_combinations_are_at_least_constructible(self):
        """Every generation should simulate without raising for a representative design."""
        for gen in ["GEN1", "GEN2", "GEN3", "GEN4"]:
            report = ConsoleSystem(default_design(generation=gen)).simulate()
            self.assertEqual(report.design.generation, gen)


if __name__ == "__main__":
    unittest.main()
