"""database/models.py persistence smoke tests."""
import tempfile
import unittest
from pathlib import Path

from arcadium_x.core.design_loop import DesignRevisionManager
from arcadium_x.tests.test_pipeline import default_design
from arcadium_x.database import models as db


class TestDatabase(unittest.TestCase):
    def test_revision_manager_records_and_reloads_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "test.sqlite3"
            manager = DesignRevisionManager(default_design(), project_name="TEST PROJECT", db_path=db_path)
            manager.revise(notes="try a bigger GPU", gpu="GPU-X4")
            manager.revise(notes="add cooling", cooling="TRIPLE_FAN")

            self.assertEqual(len(manager.timeline), 3)
            self.assertEqual(manager.current.revision, 3)

            conn = db.get_connection(db_path)
            rows = db.list_revisions(conn, "TEST PROJECT")
            self.assertEqual(len(rows), 3)
            self.assertEqual([r["revision"] for r in rows], [1, 2, 3])

    def test_to_jsonable_handles_nested_models(self):
        design = default_design()
        report = None
        from arcadium_x.core.system import ConsoleSystem
        report = ConsoleSystem(design).simulate()
        payload = db.to_jsonable(report)
        self.assertIsInstance(payload, dict)
        self.assertIn("cpu", payload)
        self.assertIsInstance(payload["cpu"], dict)


if __name__ == "__main__":
    unittest.main()
