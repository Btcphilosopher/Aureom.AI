"""Verifies the second-order engineering interactions required by spec section 46:

    GPU upgrade -> power increase -> thermal increase -> cooling requirement
                -> chassis change -> manufacturing cost -> unit cost -> margin

    memory upgrade -> memory bandwidth -> GPU utilisation/perf -> power -> thermal -> cost
"""
import unittest

from arcadium_x.tests.test_pipeline import default_design
from arcadium_x.core.specs import PortConfig
from arcadium_x.core.system import ConsoleSystem


class TestPropagation(unittest.TestCase):
    def test_gpu_upgrade_propagates_through_power_thermal_cost(self):
        low = ConsoleSystem(default_design(gpu="GPU-X1", cooling="LARGE_HEATSINK")).simulate()
        high = ConsoleSystem(default_design(gpu="GPU-X4", cooling="LARGE_HEATSINK")).simulate()

        self.assertGreater(high.gpu.power_w, low.gpu.power_w)
        self.assertGreater(high.power.totals_w["peak"], low.power.totals_w["peak"])
        self.assertGreater(
            high.thermal_by_state["peak"].total_heat_w,
            low.thermal_by_state["peak"].total_heat_w,
        )
        self.assertGreater(high.bom.chip_cost_usd, low.bom.chip_cost_usd)
        self.assertGreater(high.manufacturing_cost.manufacturing_cost_usd, low.manufacturing_cost.manufacturing_cost_usd)

    def test_bigger_cooling_needs_bigger_chassis_and_costs_more(self):
        small_cooler = ConsoleSystem(default_design(cooling="STANDARD_HEATSINK")).simulate()
        big_cooler = ConsoleSystem(default_design(cooling="LIQUID_COOLING")).simulate()

        self.assertGreater(big_cooler.chassis.volume_l, small_cooler.chassis.volume_l)
        self.assertGreaterEqual(big_cooler.chassis.weight_kg, small_cooler.chassis.weight_kg)
        self.assertGreaterEqual(big_cooler.chassis.shipping_cost_usd, small_cooler.chassis.shipping_cost_usd)

    def test_memory_upgrade_increases_bandwidth_and_reduces_bottleneck_pressure(self):
        low_mem = ConsoleSystem(default_design(memory="MEM-32", gpu="GPU-X4")).simulate()
        high_mem = ConsoleSystem(default_design(memory="MEM-128", gpu="GPU-X4")).simulate()

        self.assertGreater(high_mem.memory.effective_bandwidth_gbps, low_mem.memory.effective_bandwidth_gbps)
        self.assertGreaterEqual(high_mem.bandwidth.supply_gbps, low_mem.bandwidth.supply_gbps)
        # More bandwidth supply for the same GPU demand should never *increase* utilisation.
        self.assertLessEqual(high_mem.bandwidth.utilisation_pct, low_mem.bandwidth.utilisation_pct + 0.01)
        self.assertGreater(high_mem.bom.memory_cost_usd, low_mem.bom.memory_cost_usd)

    def test_psu_flags_unsafe_when_undersized_for_flagship_hardware(self):
        design = default_design(gpu="GPU-X4", cpu="CPU-A4", ai="AI-N3", memory="MEM-128",
                                 storage="SSD-8TB", network="NET-ELITE", psu="PSU-500W", cooling="LIQUID_COOLING")
        design.ports = PortConfig(usb_a=8, usb_c=6, hdmi=2, displayport=2, controller_count=8, optical_drive=True)
        undersized = ConsoleSystem(design).simulate()
        self.assertFalse(undersized.psu.safe)
        self.assertTrue(len(undersized.warnings) > 0)


if __name__ == "__main__":
    unittest.main()
