#!/usr/bin/env python3
"""
main.py -- ARCADIUM X command-line engineering console.

    python main.py baseline
    python main.py simulate --gpu GPU-X3 --memory MEM-64 --cooling VAPOUR_CHAMBER --commit
    python main.py stress --gpu GPU-X4 --cooling DUAL_FAN
    python main.py optimize --scenario no_compromise_1000 --commit
    python main.py history
    python main.py catalogue
    python main.py roadmap

Run `python main.py --help` (or `<command> --help`) for the full option list.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from arcadium_x.core import architecture as cat
from arcadium_x.core.specs import ConsoleDesign, DisplayTarget, EconomicConfig, NetworkCondition, PortConfig, WorkloadLevel
from arcadium_x.core.system import ConsoleSystem
from arcadium_x.core.design_loop import DesignRevisionManager
from arcadium_x.database import models as db
from arcadium_x.analytics import reports as rpt
from arcadium_x.analytics.dashboard import render_dashboard, plot_pareto_frontier, plot_revision_history
from arcadium_x.simulation.testbench import TestBench
from arcadium_x.optimisation.scenarios import SCENARIOS, run_scenario
from arcadium_x.optimisation.pareto import performance_cost_frontier

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "output"

DEFAULTS = dict(
    generation="GEN1", cpu="CPU-A3", gpu="GPU-X3", ai="AI-N2",
    memory="MEM-64", storage="SSD-4TB", cooling="VAPOUR_CHAMBER", psu="PSU-700W",
    chassis_material="ALUMINIUM", controller="PRO_PAD", network="NET-PRO", security="SEC-TPM",
    resolution="4K", refresh_hz=120, workload="HEAVY", network_condition="Good",
    usb_a=3, usb_c=2, hdmi=1, displayport=0, controller_count=2, optical_drive=False,
    rrp=1000.0, retail_margin=0.20, distributor_margin=0.08, marketing_reserve=0.05,
    warranty_reserve=0.02, software_cost=15.0, volume=1_000_000, ambient=23.0,
)


def add_design_args(p: argparse.ArgumentParser):
    p.add_argument("--generation", choices=list(cat.GENERATIONS), default=DEFAULTS["generation"])
    p.add_argument("--cpu", choices=list(cat.CPU_CATALOGUE), default=DEFAULTS["cpu"])
    p.add_argument("--gpu", choices=list(cat.GPU_CATALOGUE), default=DEFAULTS["gpu"])
    p.add_argument("--ai", choices=list(cat.AI_CATALOGUE), default=DEFAULTS["ai"])
    p.add_argument("--memory", choices=list(cat.MEMORY_CATALOGUE), default=DEFAULTS["memory"])
    p.add_argument("--storage", choices=list(cat.STORAGE_CATALOGUE), default=DEFAULTS["storage"])
    p.add_argument("--cooling", choices=list(cat.COOLING_CATALOGUE), default=DEFAULTS["cooling"])
    p.add_argument("--psu", choices=list(cat.PSU_CATALOGUE), default=DEFAULTS["psu"])
    p.add_argument("--chassis-material", choices=list(cat.CHASSIS_MATERIALS), default=DEFAULTS["chassis_material"])
    p.add_argument("--controller", choices=list(cat.CONTROLLER_CATALOGUE), default=DEFAULTS["controller"])
    p.add_argument("--network", choices=list(cat.NETWORK_CATALOGUE), default=DEFAULTS["network"])
    p.add_argument("--security", choices=list(cat.SECURITY_CATALOGUE), default=DEFAULTS["security"])

    p.add_argument("--resolution", choices=["1080p", "1440p", "4K", "8K"], default=DEFAULTS["resolution"])
    p.add_argument("--refresh-hz", type=int, choices=[60, 120, 144, 240], default=DEFAULTS["refresh_hz"])
    p.add_argument("--workload", choices=["LIGHT", "MEDIUM", "HEAVY", "EXTREME"], default=DEFAULTS["workload"])
    p.add_argument("--network-condition", choices=["Excellent", "Good", "Average", "Poor", "Severe"],
                    default=DEFAULTS["network_condition"])

    p.add_argument("--usb-a", type=int, default=DEFAULTS["usb_a"])
    p.add_argument("--usb-c", type=int, default=DEFAULTS["usb_c"])
    p.add_argument("--hdmi", type=int, default=DEFAULTS["hdmi"])
    p.add_argument("--displayport", type=int, default=DEFAULTS["displayport"])
    p.add_argument("--controller-count", type=int, choices=[1, 2, 3, 4, 8], default=DEFAULTS["controller_count"])
    p.add_argument("--optical-drive", action="store_true", default=DEFAULTS["optical_drive"])

    p.add_argument("--rrp", type=float, default=DEFAULTS["rrp"])
    p.add_argument("--retail-margin", type=float, default=DEFAULTS["retail_margin"])
    p.add_argument("--distributor-margin", type=float, default=DEFAULTS["distributor_margin"])
    p.add_argument("--marketing-reserve", type=float, default=DEFAULTS["marketing_reserve"])
    p.add_argument("--warranty-reserve", type=float, default=DEFAULTS["warranty_reserve"])
    p.add_argument("--software-cost", type=float, default=DEFAULTS["software_cost"])
    p.add_argument("--volume", type=int, default=DEFAULTS["volume"])
    p.add_argument("--ambient", type=float, default=DEFAULTS["ambient"])

    p.add_argument("--notes", default="")
    p.add_argument("--project", default="ARCADIUM X")


def design_from_args(args: argparse.Namespace, revision: int = 1) -> ConsoleDesign:
    return ConsoleDesign(
        name=args.project,
        revision=revision,
        notes=args.notes,
        generation=args.generation,
        cpu=args.cpu, gpu=args.gpu, ai=args.ai, memory=args.memory, storage=args.storage,
        cooling=args.cooling, psu=args.psu, chassis_material=args.chassis_material,
        controller=args.controller, network=args.network, security=args.security,
        display=DisplayTarget(resolution=args.resolution, refresh_hz=args.refresh_hz),
        workload=WorkloadLevel(args.workload),
        network_condition=NetworkCondition(args.network_condition),
        ports=PortConfig(usb_a=args.usb_a, usb_c=args.usb_c, hdmi=args.hdmi, displayport=args.displayport,
                          controller_count=args.controller_count, optical_drive=args.optical_drive),
        economics=EconomicConfig(rrp_usd=args.rrp, retail_margin_pct=args.retail_margin,
                                  distributor_margin_pct=args.distributor_margin,
                                  marketing_reserve_pct=args.marketing_reserve,
                                  warranty_reserve_pct=args.warranty_reserve,
                                  software_platform_cost_usd=args.software_cost,
                                  manufacturing_volume=args.volume),
        ambient_temp_c=args.ambient,
    )


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

def cmd_baseline(args):
    conn = db.get_connection()
    revision = db.get_next_revision_number(conn, args.project) if args.commit else 1
    design = design_from_args(args, revision=revision)
    tb = TestBench().run(design)

    print(rpt.full_report(tb))
    print()
    print(render_dashboard(tb))

    if args.commit:
        db.save_revision(conn, args.project, design, tb.simulation, tb)
        print(f"\nSaved as REVISION {revision:02d} for project '{args.project}'.")


def cmd_simulate(args):
    conn = db.get_connection()
    revision = db.get_next_revision_number(conn, args.project) if args.commit else 1
    design = design_from_args(args, revision=revision)
    tb = TestBench().run(design)

    if args.view == "dashboard":
        print(render_dashboard(tb))
    else:
        print(rpt.full_report(tb))
        print()
        print(render_dashboard(tb))

    if not tb.assembly.all_passed:
        print("\nASSEMBLY VALIDATION -- issues found:")
        for c in tb.assembly.checks:
            if not c.passed:
                print(f"  [FAIL] {c.stage}: {c.message}")

    if args.commit:
        db.save_revision(conn, args.project, design, tb.simulation, tb)
        print(f"\nSaved as REVISION {revision:02d} for project '{args.project}'.")

    if args.export:
        out = Path(args.export)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(db.to_jsonable(tb.simulation), indent=2))
        print(f"Exported full simulation JSON to {out}")


def cmd_stress(args):
    design = design_from_args(args, revision=1)
    tb = TestBench().run(design)

    print(f"STRESS TEST -- {design.name}")
    print(f"  Peak system power:      {tb.stress.peak_power_w:.1f} W")
    print(f"  PSU safe:               {tb.stress.psu_safe}  (headroom {tb.stress.psu_headroom_pct:.1f}%)")
    print(f"  Thermal throttling:     {tb.stress.thermal_throttling} "
          f"{tb.stress.throttled_components if tb.stress.throttled_components else ''}")
    print(f"  Hottest component:      {tb.stress.hottest_component} @ {tb.stress.hottest_temp_c:.1f} C")
    print(f"  Fabric congestion:      {tb.stress.fabric_congestion_pct:.1f}%")
    print(f"  Memory bandwidth util:  {tb.stress.bandwidth_utilisation_pct:.1f}%")
    print(f"  RESULT: {'PASS' if tb.stress.passed else 'FAIL'}")
    for f in tb.stress.failures:
        print(f"    - {f}")
    print()
    print(f"Bottleneck diagnosis: {tb.bottleneck.diagnosis}")
    print(f"  {tb.bottleneck.detail}")
    print(f"  Recommendation: {tb.bottleneck.recommendation}")
    print()
    print("Utilisation by subsystem:")
    for k, v in tb.bottleneck.utilisation.items():
        print(f"  {k:<8} {v:>6.1f}%")


def cmd_history(args):
    conn = db.get_connection()
    rows = db.list_revisions(conn, args.project)
    if not rows:
        print(f"No revisions recorded yet for project '{args.project}'.")
        return

    print(f"{'REV':<5}{'PERF':>8}{'COST':>10}{'MARGIN%':>10}{'THERMAL%':>10}{'dBA':>8}{'MFG':>8}{'MTBFh':>10}  NOTES")
    for r in rows:
        print(f"{r['revision']:<5}{r['performance_total'] or 0:>8.1f}{r['manufacturing_cost'] or 0:>10.2f}"
              f"{r['gross_margin_pct'] or 0:>10.1f}{r['thermal_headroom_pct'] or 0:>10.1f}"
              f"{r['acoustic_peak_dba'] or 0:>8.1f}{r['manufacturability_score'] or 0:>8.1f}"
              f"{r['reliability_mtbf_hours'] or 0:>10.0f}  {r['notes'] or ''}")

    if args.plot:
        history_rows = [{
            "revision": r["revision"], "performance": r["performance_total"] or 0,
            "cost": r["manufacturing_cost"] or 0, "margin_pct": r["gross_margin_pct"] or 0,
        } for r in rows]
        out = OUTPUT_DIR / f"{args.project.replace(' ', '_')}_history.png"
        path = plot_revision_history(history_rows, out)
        print(f"\nSaved revision history chart: {path}" if path else "\n(matplotlib not available; skipped chart)")


def cmd_optimize(args):
    design = design_from_args(args, revision=1)
    scenario, result = run_scenario(args.scenario, design, generations=args.generations,
                                     population_size=args.population, seed=args.seed)
    best = result.best

    print(f"{scenario.label}\n  {scenario.description}\n")
    print(f"Evaluated {len(result.all_evaluated)} candidate architectures across {result.generations} generations "
          f"(population {result.population_size}).")
    print(f"Best fitness: {best.fitness:.2f}   Feasible: {best.feasible}")
    if not best.feasible:
        print("  Violations:")
        for v in best.violations:
            print(f"    - {v}")
    print()
    print(render_dashboard(best.testbench))

    frontier = performance_cost_frontier(result.all_evaluated)
    if not frontier:
        # No feasible individuals at all -- fall back to the full (infeasible-inclusive) frontier
        # so the engineer can still see the trade-off space and understand why nothing qualified.
        print("\nNo feasible architectures found under this scenario's constraints; "
              "showing the unconstrained Pareto frontier instead.")
        frontier = performance_cost_frontier(result.all_evaluated, feasible_only=False)

    if frontier:
        print(f"\nPareto frontier: {len(frontier)} non-dominated architectures "
              f"(performance {min(p.performance for p in frontier):.1f}-{max(p.performance for p in frontier):.1f}, "
              f"cost ${min(p.cost_usd for p in frontier):.0f}-${max(p.cost_usd for p in frontier):.0f})")

        out = OUTPUT_DIR / f"{args.project.replace(' ', '_')}_pareto_{args.scenario}.png"
        path = plot_pareto_frontier(frontier, out)
        print(f"Saved Pareto frontier chart: {path}" if path else "(matplotlib not available; skipped chart)")

    if args.commit:
        conn = db.get_connection()
        revision = db.get_next_revision_number(conn, args.project)
        best_design = best.design.model_copy(update={
            "revision": revision, "notes": f"optimiser: {scenario.label}",
        })
        db.save_revision(conn, args.project, best_design, best.testbench.simulation, best.testbench)
        db.save_optimisation_run(conn, args.project, args.scenario, result.generations, result.population_size,
                                  best_design, best.fitness, [p.__dict__ for p in frontier])
        print(f"\nCommitted optimiser result as REVISION {revision:02d}.")


def cmd_catalogue(args):
    tables = {
        "CPU": cat.CPU_CATALOGUE, "GPU": cat.GPU_CATALOGUE, "AI": cat.AI_CATALOGUE,
        "MEMORY": cat.MEMORY_CATALOGUE, "STORAGE": cat.STORAGE_CATALOGUE,
        "COOLING": cat.COOLING_CATALOGUE, "PSU": cat.PSU_CATALOGUE,
        "CHASSIS MATERIAL": cat.CHASSIS_MATERIALS, "CONTROLLER": cat.CONTROLLER_CATALOGUE,
        "NETWORK": cat.NETWORK_CATALOGUE, "SECURITY": cat.SECURITY_CATALOGUE,
    }
    for title, table in tables.items():
        print(f"\n{title}")
        for name, spec in table.items():
            print(f"  {name:<20} {spec}")


def cmd_roadmap(args):
    print(f"{'GEN':<8}{'YEAR':<8}{'PROC.EFF':>10}{'COMP.DENS':>12}{'MEM.EFF':>10}{'PWR.EFF':>10}{'STOR.DENS':>12}{'COST.MULT':>12}")
    for name, g in cat.GENERATIONS.items():
        print(f"{name:<8}{g.year:<8}{g.process_efficiency:>10.2f}{g.compute_density:>12.2f}"
              f"{g.memory_efficiency:>10.2f}{g.power_efficiency:>10.2f}{g.storage_density:>12.2f}{g.cost_multiplier:>12.2f}")


def cmd_scenarios(args):
    for key, s in SCENARIOS.items():
        print(f"{key:<22} {s.label}")
        print(f"  {s.description}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="arcadium_x", description=__doc__,
                                      formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("baseline", help="Simulate the default flagship configuration")
    add_design_args(p)
    p.add_argument("--commit", action="store_true", help="Save as a new revision in the project database")
    p.set_defaults(func=cmd_baseline)

    p = sub.add_parser("simulate", help="Simulate a fully custom configuration")
    add_design_args(p)
    p.add_argument("--view", choices=["full", "dashboard"], default="full")
    p.add_argument("--commit", action="store_true", help="Save as a new revision in the project database")
    p.add_argument("--export", help="Write the full simulation result as JSON to this path")
    p.set_defaults(func=cmd_simulate)

    p = sub.add_parser("stress", help="Run the combined worst-case stress test")
    add_design_args(p)
    p.set_defaults(func=cmd_stress)

    p = sub.add_parser("history", help="Show the revision timeline for a project")
    p.add_argument("--project", default="ARCADIUM X")
    p.add_argument("--plot", action="store_true", help="Also render a revision-history PNG chart")
    p.set_defaults(func=cmd_history)

    p = sub.add_parser("optimize", help="Run the ArcadiumOptimizer against a design scenario")
    add_design_args(p)
    p.add_argument("--scenario", choices=list(SCENARIOS), default="no_compromise_1000")
    p.add_argument("--generations", type=int, default=25)
    p.add_argument("--population", type=int, default=24)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--commit", action="store_true", help="Save the best result as a new revision")
    p.set_defaults(func=cmd_optimize)

    p = sub.add_parser("catalogue", help="List every selectable component and its spec sheet")
    p.set_defaults(func=cmd_catalogue)

    p = sub.add_parser("roadmap", help="Show the GEN1-GEN4 technology roadmap multipliers")
    p.set_defaults(func=cmd_roadmap)

    p = sub.add_parser("scenarios", help="List the six predefined design scenarios")
    p.set_defaults(func=cmd_scenarios)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
