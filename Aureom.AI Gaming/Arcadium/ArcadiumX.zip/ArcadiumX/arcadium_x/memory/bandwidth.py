"""memory/bandwidth.py -- memory bandwidth utilisation & pressure modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.compute.gpu import GPUResult
from arcadium_x.memory.ram import MemoryResult


@dataclass
class BandwidthUtilisation:
    supply_gbps: float
    gpu_demand_gbps: float
    cpu_demand_gbps: float
    ai_demand_gbps: float
    total_demand_gbps: float
    utilisation_pct: float
    gpu_starvation_pct: float
    cpu_starvation_pct: float
    memory_pressure_pct: float  # capacity-side pressure, 0-100


def compute_utilisation(
    memory: MemoryResult,
    gpu: GPUResult,
    ai_bandwidth_demand_gbps: float,
    cpu_bandwidth_demand_gbps: float,
    allocated_gb: float,
) -> BandwidthUtilisation:
    supply = memory.effective_bandwidth_gbps
    gpu_demand = gpu.required_bandwidth_gbps
    total_demand = gpu_demand + cpu_bandwidth_demand_gbps + ai_bandwidth_demand_gbps

    utilisation = min(150.0, 100.0 * total_demand / supply) if supply else 999.0

    # Starvation: how much of *this consumer's* demand goes unmet once bandwidth is shared
    # proportionally to demand when oversubscribed.
    if total_demand > supply and total_demand > 0:
        served_ratio = supply / total_demand
    else:
        served_ratio = 1.0

    gpu_starvation = max(0.0, 100.0 * (1 - served_ratio))
    cpu_starvation = max(0.0, 100.0 * (1 - served_ratio))

    capacity_pressure = min(100.0, 100.0 * allocated_gb / memory.capacity_gb) if memory.capacity_gb else 100.0

    return BandwidthUtilisation(
        supply_gbps=round(supply, 1),
        gpu_demand_gbps=round(gpu_demand, 1),
        cpu_demand_gbps=round(cpu_bandwidth_demand_gbps, 1),
        ai_demand_gbps=round(ai_bandwidth_demand_gbps, 1),
        total_demand_gbps=round(total_demand, 1),
        utilisation_pct=round(utilisation, 1),
        gpu_starvation_pct=round(gpu_starvation, 1),
        cpu_starvation_pct=round(cpu_starvation, 1),
        memory_pressure_pct=round(capacity_pressure, 1),
    )
