"""memory/ram.py -- unified system/GPU memory modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import MemorySpec, TechGeneration


@dataclass
class MemoryResult:
    spec_name: str
    capacity_gb: int
    effective_bandwidth_gbps: float
    effective_latency_ns: float
    performance_score: float  # 0-100
    cost_usd: float


_BW_CEILING = 1100.0  # GB/s of an idealised GEN4 128GB config


def evaluate_memory(spec: MemorySpec, generation: TechGeneration) -> MemoryResult:
    eff_bw = spec.bandwidth_gbps * generation.memory_efficiency
    eff_latency = spec.latency_ns / generation.process_efficiency

    bw_score = min(100.0, 100.0 * eff_bw / _BW_CEILING)
    capacity_score = min(100.0, 100.0 * spec.capacity_gb / 128.0)
    latency_score = max(0.0, min(100.0, 100.0 - (eff_latency - 40.0) * 1.4))

    score = 0.55 * bw_score + 0.25 * capacity_score + 0.20 * latency_score
    cost = spec.cost_usd * generation.cost_multiplier

    return MemoryResult(
        spec_name=spec.name,
        capacity_gb=spec.capacity_gb,
        effective_bandwidth_gbps=round(eff_bw, 1),
        effective_latency_ns=round(eff_latency, 1),
        performance_score=round(max(0.0, score), 2),
        cost_usd=round(cost, 2),
    )
