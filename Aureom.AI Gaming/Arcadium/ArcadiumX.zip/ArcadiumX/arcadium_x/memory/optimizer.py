"""memory/optimizer.py -- MemoryOptimizer: diagnoses the system's limiting factor."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.memory.bandwidth import BandwidthUtilisation
from arcadium_x.memory.ram import MemoryResult


@dataclass
class MemoryDiagnosis:
    gpu_utilisation_pct: float
    bandwidth_utilisation_pct: float
    diagnosis: str
    recommendation: str


class MemoryOptimizer:
    """Determines whether the system is compute-, bandwidth-, latency-, capacity- or
    cache-bound, and produces a one-line engineering recommendation."""

    def diagnose(
        self,
        gpu_utilisation_pct: float,
        bandwidth: BandwidthUtilisation,
        memory: MemoryResult,
        cache_hit_rate_pct: float,
    ) -> MemoryDiagnosis:
        bw_util = bandwidth.utilisation_pct

        if bandwidth.memory_pressure_pct >= 95:
            diagnosis = "CAPACITY LIMITED"
            deficit = bandwidth.memory_pressure_pct - 85
            recommendation = f"Increase installed memory capacity by one tier (~{deficit:.0f}% headroom needed)"
        elif cache_hit_rate_pct < 55:
            diagnosis = "CACHE LIMITED"
            recommendation = "Increase last-level cache size or improve data locality / prefetch policy"
        elif bw_util >= 92 and gpu_utilisation_pct < bw_util - 8:
            diagnosis = "MEMORY-BANDWIDTH LIMITED"
            shortfall = bw_util - 90
            recommendation = f"Increase memory bandwidth by ~{shortfall:.0f}% (wider bus / faster memory tier)"
        elif memory.effective_latency_ns > 70 and gpu_utilisation_pct < 80:
            diagnosis = "LATENCY LIMITED"
            recommendation = "Adopt a lower-latency memory tier or add a larger mid-level cache"
        elif gpu_utilisation_pct >= 90 and bw_util < 85:
            diagnosis = "COMPUTE LIMITED"
            recommendation = "System is compute-bound: memory subsystem has headroom, GPU/CPU is the ceiling"
        else:
            diagnosis = "BALANCED"
            recommendation = "No single subsystem dominates; current configuration is well matched"

        return MemoryDiagnosis(
            gpu_utilisation_pct=round(gpu_utilisation_pct, 1),
            bandwidth_utilisation_pct=round(bw_util, 1),
            diagnosis=diagnosis,
            recommendation=recommendation,
        )
