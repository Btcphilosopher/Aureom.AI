"""core/scheduler.py -- tracks a design's position in the ARCADIUM X lifecycle.

    CONCEPT -> ARCHITECTURE -> COMPONENT SELECTION -> SYSTEM INTEGRATION ->
    THERMAL DESIGN -> POWER DESIGN -> MEMORY/STORAGE DESIGN -> I/O DESIGN ->
    PROTOTYPE -> STRESS TEST -> BENCHMARK -> COST ANALYSIS -> OPTIMISATION ->
    REDESIGN -> FINAL CONSOLE
"""
from __future__ import annotations

from enum import Enum


class LifecycleStage(str, Enum):
    CONCEPT = "CONCEPT"
    ARCHITECTURE = "ARCHITECTURE"
    COMPONENT_SELECTION = "COMPONENT SELECTION"
    SYSTEM_INTEGRATION = "SYSTEM INTEGRATION"
    THERMAL_DESIGN = "THERMAL DESIGN"
    POWER_DESIGN = "POWER DESIGN"
    MEMORY_STORAGE_DESIGN = "MEMORY/STORAGE DESIGN"
    IO_DESIGN = "I/O DESIGN"
    PROTOTYPE = "PROTOTYPE"
    STRESS_TEST = "STRESS TEST"
    BENCHMARK = "BENCHMARK"
    COST_ANALYSIS = "COST ANALYSIS"
    OPTIMISATION = "OPTIMISATION"
    REDESIGN = "REDESIGN"
    FINAL_CONSOLE = "FINAL CONSOLE"


_ORDER = list(LifecycleStage)


class LifecycleScheduler:
    """A simple forward-moving state tracker; a revision can be pushed back to
    REDESIGN from anywhere, but otherwise advances stage-by-stage."""

    def __init__(self):
        self.stage = LifecycleStage.CONCEPT
        self.history: list[LifecycleStage] = [self.stage]

    def advance(self) -> LifecycleStage:
        idx = _ORDER.index(self.stage)
        if idx < len(_ORDER) - 1:
            self.stage = _ORDER[idx + 1]
            self.history.append(self.stage)
        return self.stage

    def redesign(self) -> LifecycleStage:
        self.stage = LifecycleStage.REDESIGN
        self.history.append(self.stage)
        return self.stage

    def finalise(self) -> LifecycleStage:
        self.stage = LifecycleStage.FINAL_CONSOLE
        self.history.append(self.stage)
        return self.stage
