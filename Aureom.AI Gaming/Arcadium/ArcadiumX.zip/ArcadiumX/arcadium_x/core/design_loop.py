"""core/design_loop.py -- DesignRevisionManager: the DESIGN -> SIMULATE -> ...
-> REDESIGN loop (spec section 36).

Every call to `revise()` produces a new numbered revision, runs it through
the full TestBench, records it to SQLite, and keeps an in-memory timeline so
`main.py` can print a REVISION 01 / 02 / 03 ... history at any time.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from arcadium_x.core.scheduler import LifecycleScheduler, LifecycleStage
from arcadium_x.core.specs import ConsoleDesign
from arcadium_x.database import models as db
from arcadium_x.simulation.testbench import TestBench, TestBenchReport


@dataclass
class RevisionEntry:
    revision: int
    design: ConsoleDesign
    testbench: TestBenchReport
    stage: LifecycleStage


class DesignRevisionManager:
    def __init__(self, base_design: ConsoleDesign, project_name: str = "ARCADIUM X",
                 db_path: Path | str = db.DEFAULT_DB_PATH, performance_weights: dict | None = None,
                 commit_base: bool = True):
        self.project_name = project_name
        self.testbench = TestBench(performance_weights)
        self.scheduler = LifecycleScheduler()
        self.conn = db.get_connection(db_path)
        self.timeline: list[RevisionEntry] = []

        if commit_base:
            self._commit(base_design)
        else:
            report = self.testbench.run(base_design)
            self.timeline.append(RevisionEntry(revision=base_design.revision, design=base_design,
                                                testbench=report, stage=self.scheduler.stage))

    @property
    def current(self) -> RevisionEntry:
        return self.timeline[-1]

    def _commit(self, design: ConsoleDesign) -> RevisionEntry:
        report = self.testbench.run(design)
        entry = RevisionEntry(revision=design.revision, design=design, testbench=report, stage=self.scheduler.stage)
        self.timeline.append(entry)
        db.save_revision(self.conn, self.project_name, design, report.simulation, report)
        return entry

    def revise(self, notes: str = "", **overrides) -> RevisionEntry:
        """Create the next numbered revision, applying `overrides` as a
        model_copy(update=...) over the current design."""
        self.scheduler.redesign()
        next_design = self.current.design.model_copy(update=overrides, deep=True)
        next_design.revision = self.current.revision + 1
        next_design.notes = notes
        return self._commit(next_design)

    def replace(self, design: ConsoleDesign, notes: str = "") -> RevisionEntry:
        """Commit an externally constructed design (e.g. from the optimiser) as
        the next revision."""
        design = design.model_copy(deep=True)
        design.revision = self.current.revision + 1
        design.notes = notes or design.notes
        self.scheduler.redesign()
        return self._commit(design)

    def finalise(self) -> RevisionEntry:
        self.scheduler.finalise()
        entry = self.current
        entry.stage = LifecycleStage.FINAL_CONSOLE
        return entry

    def history_table(self) -> list[dict]:
        rows = []
        for e in self.timeline:
            r = e.testbench.simulation
            rows.append({
                "revision": e.revision,
                "notes": e.design.notes,
                "cpu": e.design.cpu,
                "gpu": e.design.gpu,
                "memory": e.design.memory,
                "cooling": e.design.cooling,
                "performance": e.testbench.performance.total,
                "cost": r.manufacturing_cost.manufacturing_cost_usd,
                "margin_pct": r.economics.gross_margin_pct,
                "peak_dba": r.acoustics.peak_dba,
                "mtbf_hours": r.reliability.mtbf_hours,
                "manufacturability": r.manufacturability.manufacturability_score,
            })
        return rows
