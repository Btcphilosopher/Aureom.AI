"""
core/architecture.py
=====================
The component catalogue.

ARCADIUM X never references a real-world chip. Every part is a configurable
synthetic architecture (CPU-A1..A4, GPU-X1..X4, ...) with an internally
consistent performance/cost/power profile, so the simulator can be freely
published and re-used without implying any real vendor's roadmap.

Each catalogue is a dict[name -> Spec] so engines and the optimiser can look
components up by name and iterate the design space.
"""
from __future__ import annotations

from .specs import (
    AISpec,
    ChassisMaterial,
    ControllerSpec,
    CoolingSpec,
    CPUSpec,
    GPUSpec,
    MemorySpec,
    NetworkSpec,
    PSUSpec,
    SecuritySpec,
    StorageSpec,
    TechGeneration,
)

# ---------------------------------------------------------------------------
# Compute
# ---------------------------------------------------------------------------

CPU_CATALOGUE: dict[str, CPUSpec] = {
    "CPU-A1": CPUSpec(name="CPU-A1", cores=6, threads=12, clock_ghz=3.2, ipc_index=1.00,
                       cache_mb=16, arch_efficiency=1.00, mem_latency_ns=95, tdp_w=35, cost_usd=42),
    "CPU-A2": CPUSpec(name="CPU-A2", cores=8, threads=16, clock_ghz=3.6, ipc_index=1.12,
                       cache_mb=24, arch_efficiency=1.10, mem_latency_ns=85, tdp_w=48, cost_usd=64),
    "CPU-A3": CPUSpec(name="CPU-A3", cores=8, threads=16, clock_ghz=4.1, ipc_index=1.28,
                       cache_mb=32, arch_efficiency=1.22, mem_latency_ns=72, tdp_w=62, cost_usd=91),
    "CPU-A4": CPUSpec(name="CPU-A4", cores=12, threads=24, clock_ghz=4.4, ipc_index=1.40,
                       cache_mb=48, arch_efficiency=1.32, mem_latency_ns=60, tdp_w=78, cost_usd=134),
}

GPU_CATALOGUE: dict[str, GPUSpec] = {
    "GPU-X1": GPUSpec(name="GPU-X1", compute_units=32, clock_ghz=2.1, mem_bandwidth_gbps=320,
                       vram_gb=12, cache_mb=24, rt_index=45, ai_index=40, shader_tflops=14.5,
                       tdp_w=110, cost_usd=95),
    "GPU-X2": GPUSpec(name="GPU-X2", compute_units=48, clock_ghz=2.3, mem_bandwidth_gbps=448,
                       vram_gb=16, cache_mb=32, rt_index=64, ai_index=58, shader_tflops=22.8,
                       tdp_w=150, cost_usd=155),
    "GPU-X3": GPUSpec(name="GPU-X3", compute_units=64, clock_ghz=2.5, mem_bandwidth_gbps=576,
                       vram_gb=20, cache_mb=48, rt_index=82, ai_index=76, shader_tflops=33.0,
                       tdp_w=195, cost_usd=235),
    "GPU-X4": GPUSpec(name="GPU-X4", compute_units=96, clock_ghz=2.6, mem_bandwidth_gbps=768,
                       vram_gb=24, cache_mb=64, rt_index=97, ai_index=94, shader_tflops=48.5,
                       tdp_w=260, cost_usd=345),
}

AI_CATALOGUE: dict[str, AISpec] = {
    "NONE":   AISpec(name="NONE", tops=0, precision="-", mem_bandwidth_gbps=0, tdp_w=0, cost_usd=0),
    "AI-N1":  AISpec(name="AI-N1", tops=45, precision="INT8/FP8", mem_bandwidth_gbps=224,
                      tdp_w=12, cost_usd=18),
    "AI-N2":  AISpec(name="AI-N2", tops=90, precision="INT8/FP8", mem_bandwidth_gbps=320,
                      tdp_w=20, cost_usd=32),
    "AI-N3":  AISpec(name="AI-N3", tops=160, precision="INT4/INT8/FP8", mem_bandwidth_gbps=448,
                      tdp_w=30, cost_usd=52),
}

# ---------------------------------------------------------------------------
# Memory / Storage
# ---------------------------------------------------------------------------

MEMORY_CATALOGUE: dict[str, MemorySpec] = {
    "MEM-32":  MemorySpec(name="MEM-32", capacity_gb=32, mem_type="GDDR7-Unified", bandwidth_gbps=384,
                           latency_ns=68, channels=8, cost_per_gb=2.35),
    "MEM-48":  MemorySpec(name="MEM-48", capacity_gb=48, mem_type="GDDR7-Unified", bandwidth_gbps=512,
                           latency_ns=64, channels=10, cost_per_gb=2.40),
    "MEM-64":  MemorySpec(name="MEM-64", capacity_gb=64, mem_type="GDDR7-Unified", bandwidth_gbps=640,
                           latency_ns=60, channels=12, cost_per_gb=2.45),
    "MEM-96":  MemorySpec(name="MEM-96", capacity_gb=96, mem_type="GDDR7X-Unified", bandwidth_gbps=832,
                           latency_ns=56, channels=16, cost_per_gb=2.55),
    "MEM-128": MemorySpec(name="MEM-128", capacity_gb=128, mem_type="HBM3E-Unified", bandwidth_gbps=1024,
                           latency_ns=50, channels=16, cost_per_gb=3.10),
}

STORAGE_CATALOGUE: dict[str, StorageSpec] = {
    "SSD-2TB": StorageSpec(name="SSD-2TB", capacity_tb=2, seq_read_gbps=6.8, seq_write_gbps=5.2,
                            random_iops_k=950, dram_cache_mb=1024, controller_channels=8, cost_usd=88),
    "SSD-4TB": StorageSpec(name="SSD-4TB", capacity_tb=4, seq_read_gbps=8.5, seq_write_gbps=6.6,
                            random_iops_k=1250, dram_cache_mb=2048, controller_channels=8, cost_usd=158),
    "SSD-8TB": StorageSpec(name="SSD-8TB", capacity_tb=8, seq_read_gbps=10.2, seq_write_gbps=7.8,
                            random_iops_k=1600, dram_cache_mb=4096, controller_channels=16, cost_usd=298),
}

# ---------------------------------------------------------------------------
# Thermal / Power
# ---------------------------------------------------------------------------

COOLING_CATALOGUE: dict[str, CoolingSpec] = {
    "STANDARD_HEATSINK": CoolingSpec(name="STANDARD_HEATSINK", capacity_w=140, weight_kg=0.35,
                                      base_noise_dba=28, cost_usd=9, reliability_index=88,
                                      manufacturability_index=98, volume_l=0.6),
    "LARGE_HEATSINK":    CoolingSpec(name="LARGE_HEATSINK", capacity_w=210, weight_kg=0.60,
                                      base_noise_dba=27, cost_usd=15, reliability_index=90,
                                      manufacturability_index=95, volume_l=1.0),
    "HEAT_PIPES":        CoolingSpec(name="HEAT_PIPES", capacity_w=280, weight_kg=0.75,
                                      base_noise_dba=26, cost_usd=24, reliability_index=90,
                                      manufacturability_index=90, volume_l=1.3),
    "VAPOUR_CHAMBER":    CoolingSpec(name="VAPOUR_CHAMBER", capacity_w=360, weight_kg=0.85,
                                      base_noise_dba=24, cost_usd=38, reliability_index=93,
                                      manufacturability_index=84, volume_l=1.5),
    "ADVANCED_AIRFLOW":  CoolingSpec(name="ADVANCED_AIRFLOW", capacity_w=420, weight_kg=1.05,
                                      base_noise_dba=23, cost_usd=52, reliability_index=91,
                                      manufacturability_index=78, volume_l=2.0),
    "DUAL_FAN":          CoolingSpec(name="DUAL_FAN", capacity_w=460, weight_kg=1.15,
                                      base_noise_dba=25, cost_usd=46, reliability_index=87,
                                      manufacturability_index=80, volume_l=2.1),
    "TRIPLE_FAN":        CoolingSpec(name="TRIPLE_FAN", capacity_w=520, weight_kg=1.35,
                                      base_noise_dba=27, cost_usd=61, reliability_index=83,
                                      manufacturability_index=72, volume_l=2.6),
    "LIQUID_COOLING":    CoolingSpec(name="LIQUID_COOLING", capacity_w=600, weight_kg=1.60,
                                      base_noise_dba=22, cost_usd=95, reliability_index=76,
                                      manufacturability_index=55, volume_l=2.9),
}

PSU_CATALOGUE: dict[str, PSUSpec] = {
    "PSU-500W": PSUSpec(name="PSU-500W", wattage=500, efficiency=0.90, cost_usd=22, weight_kg=0.55),
    "PSU-600W": PSUSpec(name="PSU-600W", wattage=600, efficiency=0.91, cost_usd=27, weight_kg=0.65),
    "PSU-700W": PSUSpec(name="PSU-700W", wattage=700, efficiency=0.92, cost_usd=33, weight_kg=0.75),
    "PSU-800W": PSUSpec(name="PSU-800W", wattage=800, efficiency=0.93, cost_usd=40, weight_kg=0.85),
}

# ---------------------------------------------------------------------------
# Chassis materials
# ---------------------------------------------------------------------------

CHASSIS_MATERIALS: dict[str, ChassisMaterial] = {
    "ABS":            ChassisMaterial(name="ABS", density_kg_l=1.05, thermal_conductivity=0.20,
                                       cost_per_kg=2.8, manufacturability_index=98, strength_index=40),
    "POLYCARBONATE":  ChassisMaterial(name="POLYCARBONATE", density_kg_l=1.20, thermal_conductivity=0.22,
                                       cost_per_kg=4.1, manufacturability_index=93, strength_index=55),
    "ALUMINIUM":      ChassisMaterial(name="ALUMINIUM", density_kg_l=2.70, thermal_conductivity=205,
                                       cost_per_kg=6.4, manufacturability_index=78, strength_index=80),
    "STEEL":          ChassisMaterial(name="STEEL", density_kg_l=7.85, thermal_conductivity=45,
                                       cost_per_kg=3.2, manufacturability_index=70, strength_index=95),
    "MAGNESIUM":      ChassisMaterial(name="MAGNESIUM", density_kg_l=1.74, thermal_conductivity=156,
                                       cost_per_kg=11.5, manufacturability_index=60, strength_index=70),
    "COMPOSITE":      ChassisMaterial(name="COMPOSITE", density_kg_l=1.55, thermal_conductivity=12,
                                       cost_per_kg=9.0, manufacturability_index=66, strength_index=88),
}

# ---------------------------------------------------------------------------
# Controllers / Networking / Security
# ---------------------------------------------------------------------------

CONTROLLER_CATALOGUE: dict[str, ControllerSpec] = {
    "STANDARD_PAD": ControllerSpec(name="STANDARD_PAD", hall_effect=False, haptics_level=1,
                                    adaptive_triggers=False, wireless=True, battery_wh=4.0,
                                    cost_usd=14, base_latency_ms=6.5, durability_index=70),
    "PRO_PAD":      ControllerSpec(name="PRO_PAD", hall_effect=True, haptics_level=2,
                                    adaptive_triggers=True, wireless=True, battery_wh=5.5,
                                    cost_usd=27, base_latency_ms=4.2, durability_index=90),
    "ELITE_PAD":    ControllerSpec(name="ELITE_PAD", hall_effect=True, haptics_level=3,
                                    adaptive_triggers=True, wireless=True, battery_wh=7.0,
                                    cost_usd=41, base_latency_ms=2.8, durability_index=97),
}

NETWORK_CATALOGUE: dict[str, NetworkSpec] = {
    "NET-BASE": NetworkSpec(name="NET-BASE", ethernet_gbps=1.0, wifi_standard="Wi-Fi 6",
                             wifi_gbps=1.2, bluetooth_version="5.2", cost_usd=8,
                             idle_power_w=0.6, active_power_w=3.2),
    "NET-PRO":  NetworkSpec(name="NET-PRO", ethernet_gbps=2.5, wifi_standard="Wi-Fi 6E",
                             wifi_gbps=2.4, bluetooth_version="5.3", cost_usd=14,
                             idle_power_w=0.8, active_power_w=4.6),
    "NET-ELITE": NetworkSpec(name="NET-ELITE", ethernet_gbps=10.0, wifi_standard="Wi-Fi 7",
                              wifi_gbps=5.8, bluetooth_version="5.4", cost_usd=24,
                              idle_power_w=1.0, active_power_w=6.5),
}

SECURITY_CATALOGUE: dict[str, SecuritySpec] = {
    "SEC-BASE": SecuritySpec(name="SEC-BASE", capability_index=55, cost_usd=3, overhead_pct=0.5),
    "SEC-TPM":  SecuritySpec(name="SEC-TPM", capability_index=78, cost_usd=6, overhead_pct=0.8),
    "SEC-HSM":  SecuritySpec(name="SEC-HSM", capability_index=96, cost_usd=11, overhead_pct=1.2),
}

# ---------------------------------------------------------------------------
# Technology generations (roadmap simulation)
# ---------------------------------------------------------------------------

GENERATIONS: dict[str, TechGeneration] = {
    "GEN1": TechGeneration(name="GEN1", year=2026, process_efficiency=1.00, compute_density=1.00,
                            memory_efficiency=1.00, power_efficiency=1.00, storage_density=1.00,
                            cost_multiplier=1.00),
    "GEN2": TechGeneration(name="GEN2", year=2027, process_efficiency=1.12, compute_density=1.15,
                            memory_efficiency=1.08, power_efficiency=1.10, storage_density=0.90,
                            cost_multiplier=0.93),
    "GEN3": TechGeneration(name="GEN3", year=2029, process_efficiency=1.27, compute_density=1.32,
                            memory_efficiency=1.18, power_efficiency=1.22, storage_density=0.78,
                            cost_multiplier=0.85),
    "GEN4": TechGeneration(name="GEN4", year=2030, process_efficiency=1.45, compute_density=1.52,
                            memory_efficiency=1.30, power_efficiency=1.38, storage_density=0.65,
                            cost_multiplier=0.76),
}

# Manufacturing volume economies-of-scale curve: (units -> unit-cost multiplier, tooling $/unit)
VOLUME_TIERS: list[tuple[int, float, float]] = [
    (10_000, 1.35, 41.0),
    (100_000, 1.14, 6.8),
    (1_000_000, 1.00, 1.1),
    (5_000_000, 0.91, 0.35),
    (10_000_000, 0.86, 0.19),
]


def nearest_volume_tier(units: int) -> tuple[int, float, float]:
    """Pick the volume tier at-or-below the requested unit count (falls back to the smallest)."""
    eligible = [t for t in VOLUME_TIERS if t[0] <= units]
    return eligible[-1] if eligible else VOLUME_TIERS[0]


# Moving-part count per cooling solution -- feeds reliability & acoustic modelling.
FAN_COUNT: dict[str, int] = {
    "STANDARD_HEATSINK": 1,
    "LARGE_HEATSINK": 1,
    "HEAT_PIPES": 1,
    "VAPOUR_CHAMBER": 1,
    "ADVANCED_AIRFLOW": 2,
    "DUAL_FAN": 2,
    "TRIPLE_FAN": 3,
    "LIQUID_COOLING": 2,  # pump + radiator fan
}

# Fraction of installed memory capacity typically resident under each workload class.
MEMORY_ALLOCATION_FRACTION: dict[str, float] = {
    "LIGHT": 0.45,
    "MEDIUM": 0.60,
    "HEAVY": 0.75,
    "EXTREME": 0.90,
}
