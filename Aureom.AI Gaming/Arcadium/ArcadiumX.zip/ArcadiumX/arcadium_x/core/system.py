"""core/system.py -- ConsoleSystem: the ARCADIUM X digital twin.

This module is the wiring loom. It resolves a ConsoleDesign's component
choices against the catalogue and drives every subsystem engine in
dependency order, so that a single change (e.g. swapping the GPU) propagates
through power -> thermal -> acoustics -> chassis -> cost -> margin exactly as
described in spec section 46 ("no placeholder architecture").
"""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core import architecture as cat
from arcadium_x.core.specs import ConsoleDesign, NetworkCondition, PowerState

from arcadium_x.compute.cpu import evaluate_cpu, CPUResult
from arcadium_x.compute.gpu import evaluate_gpu, GPUResult
from arcadium_x.compute.ai import evaluate_ai, AIResult

from arcadium_x.memory.ram import evaluate_memory, MemoryResult
from arcadium_x.memory.bandwidth import compute_utilisation, BandwidthUtilisation
from arcadium_x.memory.optimizer import MemoryOptimizer, MemoryDiagnosis

from arcadium_x.storage.nvme import evaluate_storage, StorageResult
from arcadium_x.storage.decompression import evaluate_decompression, DecompressionResult

from arcadium_x.io.bus import SystemFabric, FabricResult
from arcadium_x.io.display import evaluate_display, DisplayResult
from arcadium_x.io.networking import evaluate_network, NetworkResult
from arcadium_x.io.peripherals import evaluate_io, IOResult

from arcadium_x.thermal.cooling import evaluate_cooling, CoolingResult
from arcadium_x.thermal.thermal import ThermalEngine, ThermalResult
from arcadium_x.thermal.acoustics import AcousticEngine, AcousticResult

from arcadium_x.power.power import PowerEngine, PowerResult
from arcadium_x.power.psu import evaluate_psu, PSUResult

from arcadium_x.controllers.controller import evaluate_controllers, ControllerResult
from arcadium_x.controllers.input_latency import evaluate_input_latency, LatencyBreakdown

from arcadium_x.chassis.industrial_design import evaluate_chassis, ChassisResult

from arcadium_x.engineering.cost import (
    compute_bom, compute_manufacturing_cost, compute_economics,
    BOMBreakdown, ManufacturingCost, EconomicsResult,
)
from arcadium_x.engineering.manufacturing import (
    evaluate_volume, evaluate_manufacturability, VolumeEconomics, ManufacturabilityResult,
)
from arcadium_x.engineering.supply_chain import ComponentSupplyEngine, SupplyChainResult
from arcadium_x.engineering.reliability import ReliabilityEngine, ReliabilityResult


@dataclass
class SimulationReport:
    design: ConsoleDesign

    cpu: CPUResult
    gpu: GPUResult
    ai: AIResult
    memory: MemoryResult
    storage: StorageResult
    decompression: DecompressionResult
    display: DisplayResult
    fabric: FabricResult
    network: NetworkResult
    io: IOResult
    controller: ControllerResult
    latency: LatencyBreakdown

    bandwidth: BandwidthUtilisation
    memory_diagnosis: MemoryDiagnosis

    cooling: CoolingResult
    thermal_by_state: dict  # state -> ThermalResult
    acoustics: AcousticResult

    power: PowerResult
    psu: PSUResult

    chassis: ChassisResult

    bom: BOMBreakdown
    manufacturing_cost: ManufacturingCost
    economics: EconomicsResult
    volume_economics: VolumeEconomics
    manufacturability: ManufacturabilityResult
    supply_chain: SupplyChainResult
    reliability: ReliabilityResult

    gpu_utilisation_pct: float
    io_performance_score: float
    security_overhead_pct: float
    security_capability: float

    warnings: list = field(default_factory=list)


class ConsoleSystem:
    """Resolves a ConsoleDesign and runs the full simulation pipeline."""

    def __init__(self, design: ConsoleDesign):
        self.design = design
        self.generation = cat.GENERATIONS[design.generation]

        self.cpu_spec = cat.CPU_CATALOGUE[design.cpu]
        self.gpu_spec = cat.GPU_CATALOGUE[design.gpu]
        self.ai_spec = cat.AI_CATALOGUE[design.ai]
        self.memory_spec = cat.MEMORY_CATALOGUE[design.memory]
        self.storage_spec = cat.STORAGE_CATALOGUE[design.storage]
        self.cooling_spec = cat.COOLING_CATALOGUE[design.cooling]
        self.psu_spec = cat.PSU_CATALOGUE[design.psu]
        self.chassis_material = cat.CHASSIS_MATERIALS[design.chassis_material]
        self.controller_spec = cat.CONTROLLER_CATALOGUE[design.controller]
        self.network_spec = cat.NETWORK_CATALOGUE[design.network]
        self.security_spec = cat.SECURITY_CATALOGUE[design.security]

    # -- pipeline ----------------------------------------------------------

    def simulate(self) -> SimulationReport:
        d = self.design
        gen = self.generation
        warnings: list[str] = []

        # 1. COMPUTE ------------------------------------------------------
        cpu = evaluate_cpu(self.cpu_spec, gen)
        gpu = evaluate_gpu(self.gpu_spec, gen)
        ai = evaluate_ai(self.ai_spec, gen)

        # 2. MEMORY ---------------------------------------------------------
        memory = evaluate_memory(self.memory_spec, gen)

        # 3. STORAGE ----------------------------------------------------------
        storage = evaluate_storage(self.storage_spec, gen)
        decompression = evaluate_decompression(storage, self.storage_spec, gen.process_efficiency)

        # 4. DISPLAY / RENDER WORKLOAD -----------------------------------
        display = evaluate_display(d.display, d.workload, gpu.effective_tflops, ai.effective_tops > 0)

        gpu_utilisation_pct = (
            min(100.0, 100.0 * display.render_workload_index / gpu.effective_tflops)
            if gpu.effective_tflops else 100.0
        )

        # 5. NETWORK / IO -----------------------------------------------------
        network = evaluate_network(self.network_spec, d.network_condition, active=True)
        io = evaluate_io(d.ports)

        # 6. SYSTEM FABRIC & MEMORY BANDWIDTH -----------------------------
        cpu_bandwidth_demand = self.cpu_spec.cores * 3.0 * gen.compute_density
        # The AI accelerator's own catalogue bandwidth figure is already generation-appropriate;
        # it is a demand figure, not a supply figure, so generational supply-side multipliers
        # are not re-applied here.
        ai_bandwidth_demand = self.ai_spec.mem_bandwidth_gbps
        allocated_gb = memory.capacity_gb * cat.MEMORY_ALLOCATION_FRACTION[
            d.workload.value if hasattr(d.workload, "value") else str(d.workload)
        ]

        bandwidth = compute_utilisation(memory, gpu, ai_bandwidth_demand, cpu_bandwidth_demand, allocated_gb)

        fabric = SystemFabric(fabric_bandwidth_gbps=memory.effective_bandwidth_gbps * 1.15)
        fabric_result = fabric.evaluate({
            "gpu": (gpu.required_bandwidth_gbps, memory.effective_bandwidth_gbps),
            "cpu": (cpu_bandwidth_demand, memory.effective_bandwidth_gbps),
            "storage": (decompression.hw_decompression_throughput_gbps, 64.0),
            "io": (io.total_bandwidth_gbps, 80.0),
            "network": (network.wired_throughput_gbps + network.wireless_throughput_gbps, 12.0),
            "audio": (0.05, 5.0),
        })

        cache_hit_pct = min(96.0, 55.0 + (self.gpu_spec.cache_mb + self.cpu_spec.cache_mb) / 3.0)
        memory_diagnosis = MemoryOptimizer().diagnose(gpu_utilisation_pct, bandwidth, memory, cache_hit_pct)

        # 7. CONTROLLERS / INPUT LATENCY ----------------------------------
        controller = evaluate_controllers(self.controller_spec, d.ports.controller_count)
        cpu_frametime_ms = max(0.5, 1000.0 / d.display.refresh_hz * 0.22)
        gpu_frametime_ms = max(1.5, (1000.0 / d.display.refresh_hz) * (100.0 / display.native_render_scale_pct))
        latency = evaluate_input_latency(controller, fabric_result, cpu_frametime_ms, gpu_frametime_ms,
                                          d.display.refresh_hz, wireless=self.controller_spec.wireless)

        # 8. COOLING / THERMAL / POWER / ACOUSTICS --------------------------
        cooling = evaluate_cooling(self.cooling_spec)

        memory_power_w = memory.capacity_gb * 0.18
        fan_max_power_w = cooling.capacity_w * 0.035

        power_engine = PowerEngine()
        power = power_engine.evaluate({
            "cpu": cpu.power_w,
            "gpu": gpu.power_w,
            "memory": memory_power_w,
            "storage": storage.power_w,
            "io": io.total_power_w,
            "fan": fan_max_power_w,
            "network": network.power_w,
            "ai": ai.power_w,
        })

        thermal_engine = ThermalEngine(ambient_temp_c=d.ambient_temp_c)
        thermal_by_state: dict[str, ThermalResult] = {}
        for state_name, components in power.by_state.items():
            state_total = power.totals_w[state_name]
            heat_sources = {
                "cpu": components["cpu"],
                "gpu": components["gpu"],
                "memory": components["memory"],
                "vrm": state_total * 0.045,
                "ssd": components["storage"],
                "psu": state_total * (1 - self.psu_spec.efficiency) / self.psu_spec.efficiency,
            }
            thermal_by_state[state_name] = thermal_engine.evaluate(heat_sources, cooling)

        acoustics = AcousticEngine().evaluate(cooling, thermal_by_state)

        peak_thermal = thermal_by_state[PowerState.PEAK.value]
        if peak_thermal.throttling:
            warnings.append(
                f"THERMAL THROTTLE at peak load: {', '.join(peak_thermal.throttled_components)} "
                f"exceed safe junction temperature"
            )

        # 9. POWER SUPPLY --------------------------------------------------
        psu = evaluate_psu(self.psu_spec, power.totals_w[PowerState.PEAK.value])
        if not psu.safe:
            warnings.append(psu.warning)
        elif psu.warning:
            warnings.append(psu.warning)

        # 10. CHASSIS -------------------------------------------------------
        chassis = evaluate_chassis(self.chassis_material, cooling, self.psu_spec.weight_kg)

        # 11. COST / ECONOMICS ------------------------------------------------
        bom = compute_bom(
            cpu.cost_usd, gpu.cost_usd, ai.cost_usd,
            memory.cost_usd, storage.cost_usd,
            self.memory_spec.channels, self.storage_spec.controller_channels, self.gpu_spec.compute_units,
            self.psu_spec.cost_usd, cooling.cost_usd, chassis.material_cost_usd,
            controller.total_bom_usd, network.cost_usd, io.total_cost_usd, self.security_spec.cost_usd,
        )
        volume_econ = evaluate_volume(d.economics.manufacturing_volume)
        manufacturing_cost = compute_manufacturing_cost(
            bom, chassis.shipping_cost_usd, d.economics,
            volume_econ.unit_cost_multiplier, volume_econ.tooling_cost_per_unit_usd,
        )
        economics = compute_economics(d.economics, manufacturing_cost.manufacturing_cost_usd)
        if not economics.viable:
            warnings.append(economics.notes[0] if economics.notes else "Design not economically viable at target RRP")

        # 12. SUPPLY CHAIN / MANUFACTURABILITY / RELIABILITY -----------------
        supply_chain = ComponentSupplyEngine().evaluate(
            self.gpu_spec.name, self.memory_spec.name, self.storage_spec.name,
            self.cooling_spec.name, d.economics.manufacturing_volume,
        )
        warnings.extend(supply_chain.warnings)

        port_count = d.ports.usb_a + d.ports.usb_c + d.ports.hdmi + d.ports.displayport
        manufacturability = evaluate_manufacturability(
            d.ports.controller_count, port_count, self.memory_spec.channels,
            self.storage_spec.controller_channels, self.gpu_spec.compute_units,
            cooling, chassis, supply_chain,
        )

        fan_count = cat.FAN_COUNT[self.cooling_spec.name]
        reliability = ReliabilityEngine().evaluate(cooling, peak_thermal, psu, controller, chassis, fan_count)

        # 13. IO / SECURITY performance side-effects --------------------------
        io_score = (
            0.4 * min(100.0, 100.0 * io.total_bandwidth_gbps / 260.0)
            + 0.35 * min(100.0, 100.0 * (network.wired_throughput_gbps + network.wireless_throughput_gbps) / 12.0)
            + 0.25 * max(0.0, 100.0 - fabric_result.congestion_pct)
        )

        return SimulationReport(
            design=d, cpu=cpu, gpu=gpu, ai=ai, memory=memory, storage=storage,
            decompression=decompression, display=display, fabric=fabric_result,
            network=network, io=io, controller=controller, latency=latency,
            bandwidth=bandwidth, memory_diagnosis=memory_diagnosis,
            cooling=cooling, thermal_by_state=thermal_by_state, acoustics=acoustics,
            power=power, psu=psu, chassis=chassis,
            bom=bom, manufacturing_cost=manufacturing_cost, economics=economics,
            volume_economics=volume_econ, manufacturability=manufacturability,
            supply_chain=supply_chain, reliability=reliability,
            gpu_utilisation_pct=round(gpu_utilisation_pct, 1),
            io_performance_score=round(io_score, 2),
            security_overhead_pct=self.security_spec.overhead_pct,
            security_capability=self.security_spec.capability_index,
            warnings=warnings,
        )
