"""
core/specs.py
==============
Shared Pydantic data models used across every subsystem of ARCADIUM X.

These are the "component spec sheets" -- the raw datasheet numbers for every
selectable part in the catalogue (core/architecture.py), plus the
ConsoleDesign model that captures one complete, buildable console
configuration (the thing a revision actually *is*).

Everything downstream (compute/, memory/, storage/, thermal/, power/,
engineering/, ...) consumes these models and never invents its own copies of
component numbers -- this is the single source of truth for "what a part is
made of".
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class WorkloadLevel(str, Enum):
    LIGHT = "LIGHT"
    MEDIUM = "MEDIUM"
    HEAVY = "HEAVY"
    EXTREME = "EXTREME"


class PowerState(str, Enum):
    IDLE = "idle"
    TYPICAL = "typical"
    HEAVY = "heavy"
    PEAK = "peak"


class NetworkCondition(str, Enum):
    EXCELLENT = "Excellent"
    GOOD = "Good"
    AVERAGE = "Average"
    POOR = "Poor"
    SEVERE = "Severe"


# ---------------------------------------------------------------------------
# Compute
# ---------------------------------------------------------------------------

class CPUSpec(BaseModel):
    name: str
    cores: int
    threads: int
    clock_ghz: float
    ipc_index: float = Field(description="Relative instructions-per-clock index, 1.0 = baseline")
    cache_mb: float
    arch_efficiency: float = Field(description="Perf-per-watt scalar, higher is better")
    mem_latency_ns: float
    tdp_w: float
    cost_usd: float


class GPUSpec(BaseModel):
    name: str
    compute_units: int
    clock_ghz: float
    mem_bandwidth_gbps: float
    vram_gb: float
    cache_mb: float
    rt_index: float = Field(description="Ray tracing capability index, 0-100")
    ai_index: float = Field(description="Matrix/tensor acceleration index, 0-100")
    shader_tflops: float
    tdp_w: float
    cost_usd: float


class AISpec(BaseModel):
    name: str
    tops: float
    precision: str
    mem_bandwidth_gbps: float
    tdp_w: float
    cost_usd: float


# ---------------------------------------------------------------------------
# Memory / Storage
# ---------------------------------------------------------------------------

class MemorySpec(BaseModel):
    name: str
    capacity_gb: int
    mem_type: str
    bandwidth_gbps: float
    latency_ns: float
    channels: int
    cost_per_gb: float

    @property
    def cost_usd(self) -> float:
        return round(self.capacity_gb * self.cost_per_gb, 2)


class StorageSpec(BaseModel):
    name: str
    capacity_tb: float
    seq_read_gbps: float
    seq_write_gbps: float
    random_iops_k: float
    dram_cache_mb: int
    controller_channels: int
    cost_usd: float


# ---------------------------------------------------------------------------
# Thermal / Power
# ---------------------------------------------------------------------------

class CoolingSpec(BaseModel):
    name: str
    capacity_w: float = Field(description="Sustained heat dissipation capacity, watts")
    weight_kg: float
    base_noise_dba: float = Field(description="Fan-curve baseline noise floor")
    cost_usd: float
    reliability_index: float = Field(description="0-100, higher = fewer fan failures")
    manufacturability_index: float = Field(description="0-100, higher = easier to build")
    volume_l: float = Field(description="Physical volume the cooling solution occupies, litres")


class PSUSpec(BaseModel):
    name: str
    wattage: int
    efficiency: float = Field(description="0-1, e.g. 0.92 for 80+ Gold-ish")
    cost_usd: float
    weight_kg: float


# ---------------------------------------------------------------------------
# Chassis
# ---------------------------------------------------------------------------

class ChassisMaterial(BaseModel):
    name: str
    density_kg_l: float
    thermal_conductivity: float = Field(description="W/m*K, relative index")
    cost_per_kg: float
    manufacturability_index: float
    strength_index: float


# ---------------------------------------------------------------------------
# Controllers / I/O / Networking / Security
# ---------------------------------------------------------------------------

class ControllerSpec(BaseModel):
    name: str
    hall_effect: bool
    haptics_level: int = Field(ge=0, le=3)
    adaptive_triggers: bool
    wireless: bool
    battery_wh: float
    cost_usd: float
    base_latency_ms: float
    durability_index: float


class NetworkSpec(BaseModel):
    name: str
    ethernet_gbps: float
    wifi_standard: str
    wifi_gbps: float
    bluetooth_version: str
    cost_usd: float
    idle_power_w: float
    active_power_w: float


class SecuritySpec(BaseModel):
    name: str
    capability_index: float = Field(description="0-100")
    cost_usd: float
    overhead_pct: float = Field(description="Performance overhead, percent of system throughput")


class DisplayTarget(BaseModel):
    resolution: str
    refresh_hz: int

    @property
    def pixels(self) -> int:
        table = {
            "1080p": 1920 * 1080,
            "1440p": 2560 * 1440,
            "4K": 3840 * 2160,
            "8K": 7680 * 4320,
        }
        return table[self.resolution]


class TechGeneration(BaseModel):
    name: str
    year: int
    process_efficiency: float = Field(description="Multiplier on perf-per-watt, 1.0 = baseline")
    compute_density: float = Field(description="Multiplier on raw compute for equivalent die cost")
    memory_efficiency: float = Field(description="Multiplier on effective memory bandwidth")
    power_efficiency: float = Field(description="Multiplier reducing power draw for equal perf")
    storage_density: float = Field(description="Multiplier on storage cost-per-TB, lower is cheaper")
    cost_multiplier: float = Field(description="Multiplier on component cost (process maturity)")


# ---------------------------------------------------------------------------
# Economic / manufacturing configuration
# ---------------------------------------------------------------------------

class EconomicConfig(BaseModel):
    rrp_usd: float = 1000.0
    retail_margin_pct: float = 0.20
    distributor_margin_pct: float = 0.08
    marketing_reserve_pct: float = 0.05
    warranty_reserve_pct: float = 0.02
    software_platform_cost_usd: float = 15.0
    manufacturing_volume: int = 1_000_000

    @model_validator(mode="after")
    def _check_margins(self) -> "EconomicConfig":
        total = self.retail_margin_pct + self.distributor_margin_pct
        if total >= 0.9:
            raise ValueError("retail + distributor margin leaves no room for manufacturer revenue")
        return self


class PortConfig(BaseModel):
    usb_a: int = 3
    usb_c: int = 2
    hdmi: int = 1
    displayport: int = 0
    controller_count: int = 2
    optical_drive: bool = False


class ConsoleDesign(BaseModel):
    """A complete, simulatable console configuration -- one design revision."""

    name: str = "ARCADIUM X"
    revision: int = 1
    notes: str = ""

    generation: str = "GEN1"
    cpu: str
    gpu: str
    ai: str
    memory: str
    storage: str
    cooling: str
    psu: str
    chassis_material: str
    controller: str
    network: str
    security: str

    display: DisplayTarget = DisplayTarget(resolution="4K", refresh_hz=120)
    workload: WorkloadLevel = WorkloadLevel.HEAVY
    network_condition: NetworkCondition = NetworkCondition.GOOD

    ports: PortConfig = PortConfig()
    economics: EconomicConfig = EconomicConfig()

    ambient_temp_c: float = 23.0

    class Config:
        use_enum_values = False
