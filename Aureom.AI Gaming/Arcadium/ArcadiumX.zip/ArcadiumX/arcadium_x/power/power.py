"""power/power.py -- PowerEngine: per-component power across idle/typical/heavy/peak."""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core.specs import PowerState

# State -> fraction of full TDP each subsystem class typically draws
STATE_LOAD_FACTOR = {
    PowerState.IDLE:    {"cpu": 0.06, "gpu": 0.04, "memory": 0.25, "storage": 0.15, "io": 0.20, "fan": 0.15, "network": 0.30, "ai": 0.02},
    PowerState.TYPICAL: {"cpu": 0.45, "gpu": 0.55, "memory": 0.55, "storage": 0.40, "io": 0.55, "fan": 0.45, "network": 0.60, "ai": 0.35},
    PowerState.HEAVY:   {"cpu": 0.78, "gpu": 0.88, "memory": 0.80, "storage": 0.70, "io": 0.80, "fan": 0.80, "network": 0.80, "ai": 0.70},
    PowerState.PEAK:    {"cpu": 1.00, "gpu": 1.00, "memory": 1.00, "storage": 1.00, "io": 1.00, "fan": 1.00, "network": 1.00, "ai": 1.00},
}

STANDBY_POWER_W = 0.5


@dataclass
class PowerResult:
    by_state: dict  # state -> {component: watts}
    totals_w: dict  # state -> total watts
    standby_w: float


class PowerEngine:
    def evaluate(self, max_power_w: dict[str, float]) -> PowerResult:
        by_state = {}
        totals = {}
        for state, factors in STATE_LOAD_FACTOR.items():
            components = {}
            for comp, max_w in max_power_w.items():
                factor = factors.get(comp, 0.6)
                components[comp] = round(max_w * factor, 2)
            by_state[state.value] = components
            totals[state.value] = round(sum(components.values()), 2)

        return PowerResult(by_state=by_state, totals_w=totals, standby_w=STANDBY_POWER_W)
