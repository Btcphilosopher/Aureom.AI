"""power/psu.py -- power-supply sizing, headroom and safety validation."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import PSUSpec

SAFE_LOAD_FACTOR = 0.85  # never plan to sustain peak load above 85% of rated PSU capacity


@dataclass
class PSUResult:
    spec_name: str
    wattage: int
    efficiency: float
    peak_system_w: float
    headroom_pct: float
    thermal_load_w: float  # heat dissipated by the PSU itself (1 - efficiency)
    cost_usd: float
    weight_kg: float
    safe: bool
    warning: str


def evaluate_psu(spec: PSUSpec, peak_system_w: float) -> PSUResult:
    safe_capacity = spec.wattage * SAFE_LOAD_FACTOR
    headroom_pct = 100.0 * (spec.wattage - peak_system_w) / spec.wattage
    thermal_load = peak_system_w * (1 - spec.efficiency) / spec.efficiency

    safe = peak_system_w <= safe_capacity
    if not safe:
        warning = (f"UNSAFE: peak draw {peak_system_w:.0f}W exceeds {int(SAFE_LOAD_FACTOR*100)}% safe "
                   f"capacity of {spec.name} ({safe_capacity:.0f}W) -- select a higher-wattage PSU")
    elif headroom_pct < 20:
        warning = f"CAUTION: only {headroom_pct:.0f}% headroom at peak load; consider next PSU tier"
    else:
        warning = ""

    return PSUResult(
        spec_name=spec.name,
        wattage=spec.wattage,
        efficiency=spec.efficiency,
        peak_system_w=round(peak_system_w, 2),
        headroom_pct=round(headroom_pct, 1),
        thermal_load_w=round(thermal_load, 2),
        cost_usd=spec.cost_usd,
        weight_kg=spec.weight_kg,
        safe=safe,
        warning=warning,
    )
