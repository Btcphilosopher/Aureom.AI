"""io/peripherals.py -- USB / HDMI / DisplayPort / storage-interface / audio port modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import PortConfig

# name -> (bandwidth_gbps, power_w, cost_usd, controller_overhead_index)
PORT_TABLE = {
    "usb_a":       (10.0, 0.9, 1.8, 1.0),
    "usb_c":       (20.0, 1.4, 3.2, 1.3),
    "hdmi":        (48.0, 0.6, 4.5, 0.8),
    "displayport": (54.0, 0.6, 4.8, 0.8),
}


@dataclass
class IOResult:
    total_bandwidth_gbps: float
    total_power_w: float
    total_cost_usd: float
    controller_overhead_index: float
    port_breakdown: dict


def evaluate_io(ports: PortConfig) -> IOResult:
    counts = {
        "usb_a": ports.usb_a,
        "usb_c": ports.usb_c,
        "hdmi": ports.hdmi,
        "displayport": ports.displayport,
    }

    total_bw = total_power = total_cost = overhead = 0.0
    breakdown = {}
    for name, count in counts.items():
        bw, power, cost, oh = PORT_TABLE[name]
        breakdown[name] = {
            "count": count,
            "bandwidth_gbps": round(bw * count, 1),
            "power_w": round(power * count, 2),
            "cost_usd": round(cost * count, 2),
        }
        total_bw += bw * count
        total_power += power * count
        total_cost += cost * count
        overhead += oh * count

    if ports.optical_drive:
        total_power += 6.5
        total_cost += 18.0

    return IOResult(
        total_bandwidth_gbps=round(total_bw, 1),
        total_power_w=round(total_power, 2),
        total_cost_usd=round(total_cost, 2),
        controller_overhead_index=round(overhead, 1),
        port_breakdown=breakdown,
    )
