"""io/networking.py -- Ethernet / Wi-Fi / Bluetooth modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import NetworkCondition, NetworkSpec

# condition -> (throughput retention multiplier, added latency ms, packet loss %)
CONDITION_TABLE = {
    NetworkCondition.EXCELLENT: (1.00, 2, 0.01),
    NetworkCondition.GOOD:      (0.85, 6, 0.10),
    NetworkCondition.AVERAGE:   (0.62, 14, 0.60),
    NetworkCondition.POOR:      (0.35, 32, 2.50),
    NetworkCondition.SEVERE:    (0.12, 80, 9.00),
}


@dataclass
class NetworkResult:
    spec_name: str
    condition: str
    wired_throughput_gbps: float
    wireless_throughput_gbps: float
    latency_ms: float
    packet_loss_pct: float
    power_w: float
    cost_usd: float


def evaluate_network(spec: NetworkSpec, condition: NetworkCondition, active: bool) -> NetworkResult:
    retention, added_latency, loss = CONDITION_TABLE[condition]
    base_latency = 1.2

    return NetworkResult(
        spec_name=spec.name,
        condition=condition.value if hasattr(condition, "value") else str(condition),
        wired_throughput_gbps=round(spec.ethernet_gbps * retention, 2),
        wireless_throughput_gbps=round(spec.wifi_gbps * retention, 2),
        latency_ms=round(base_latency + added_latency, 1),
        packet_loss_pct=loss,
        power_w=spec.active_power_w if active else spec.idle_power_w,
        cost_usd=spec.cost_usd,
    )
