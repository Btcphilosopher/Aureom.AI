"""io/bus.py -- SystemFabric: the interconnect joining CPU, GPU, memory,
storage, I/O, network, audio and security.

Models aggregate fabric bandwidth, arbitration overhead under contention,
and identifies the weakest link automatically.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FabricLink:
    name: str
    demand_gbps: float
    supply_gbps: float

    @property
    def utilisation_pct(self) -> float:
        return round(100.0 * self.demand_gbps / self.supply_gbps, 1) if self.supply_gbps else 999.0


@dataclass
class FabricResult:
    links: list[FabricLink]
    fabric_bandwidth_gbps: float
    total_demand_gbps: float
    congestion_pct: float
    arbitration_latency_ns: float
    bottleneck_link: str
    bottleneck_utilisation_pct: float


class SystemFabric:
    """A shared on-package interconnect with finite aggregate bandwidth.

    Even if every individual link has enough headroom, contention between
    simultaneous consumers adds arbitration latency; when combined demand
    exceeds the fabric ceiling, links are throttled proportionally.
    """

    def __init__(self, fabric_bandwidth_gbps: float, base_arbitration_ns: float = 8.0):
        self.fabric_bandwidth_gbps = fabric_bandwidth_gbps
        self.base_arbitration_ns = base_arbitration_ns

    def evaluate(self, demands: dict[str, tuple[float, float]]) -> FabricResult:
        """demands: name -> (demand_gbps, native_link_supply_gbps)"""
        links = [FabricLink(name=n, demand_gbps=d, supply_gbps=s) for n, (d, s) in demands.items()]
        total_demand = sum(l.demand_gbps for l in links)

        congestion = min(150.0, 100.0 * total_demand / self.fabric_bandwidth_gbps) if self.fabric_bandwidth_gbps else 999.0

        # Arbitration latency grows superlinearly with congestion beyond 70%
        if congestion <= 70:
            arb_latency = self.base_arbitration_ns
        else:
            arb_latency = self.base_arbitration_ns * (1 + ((congestion - 70) / 30) ** 2 * 1.8)

        bottleneck = max(links, key=lambda l: l.utilisation_pct)

        return FabricResult(
            links=links,
            fabric_bandwidth_gbps=self.fabric_bandwidth_gbps,
            total_demand_gbps=round(total_demand, 1),
            congestion_pct=round(congestion, 1),
            arbitration_latency_ns=round(arb_latency, 2),
            bottleneck_link=bottleneck.name,
            bottleneck_utilisation_pct=bottleneck.utilisation_pct,
        )
