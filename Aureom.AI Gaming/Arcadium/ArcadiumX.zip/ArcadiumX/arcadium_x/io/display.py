"""io/display.py -- DisplayEngine: output resolution/refresh -> workload demand."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import DisplayTarget, WorkloadLevel

WORKLOAD_COMPLEXITY = {
    WorkloadLevel.LIGHT: 0.55,
    WorkloadLevel.MEDIUM: 1.0,
    WorkloadLevel.HEAVY: 1.65,
    WorkloadLevel.EXTREME: 2.4,
}

# Baseline "shader-effort units" per pixel per frame at MEDIUM complexity
_EFFORT_PER_PIXEL = 2.6e-6


@dataclass
class DisplayResult:
    resolution: str
    refresh_hz: int
    pixels_per_frame: int
    pixel_throughput_mpixels: float  # megapixels/sec required
    render_workload_index: float  # required shader-TFLOPs equivalent
    display_bandwidth_gbps: float
    framebuffer_memory_gb: float
    upscaling_required: bool
    native_render_scale_pct: float


def evaluate_display(target: DisplayTarget, workload: WorkloadLevel, gpu_tflops_available: float, ai_upscale_available: bool) -> DisplayResult:
    pixels = target.pixels
    throughput_mpix = pixels * target.refresh_hz / 1_000_000

    complexity = WORKLOAD_COMPLEXITY[workload]
    required_tflops = pixels * target.refresh_hz * _EFFORT_PER_PIXEL * complexity / 1000.0

    # HDMI 2.1/DP2.1-class bandwidth model: 24-bit colour, no DSC
    display_bw = pixels * target.refresh_hz * 24 / 1e9 * 1.20  # +20% blanking overhead

    framebuffer_gb = pixels * 4 * 3 / 1e9  # triple-buffered, 4 bytes/pixel (HDR10 + G-buffer approx)

    if required_tflops <= gpu_tflops_available:
        upscaling_required = False
        native_scale = 100.0
    else:
        upscaling_required = True
        native_scale = max(35.0, 100.0 * gpu_tflops_available / required_tflops)
        if not ai_upscale_available:
            native_scale = max(25.0, native_scale * 0.8)  # softer fallback upscale is less efficient

    return DisplayResult(
        resolution=target.resolution,
        refresh_hz=target.refresh_hz,
        pixels_per_frame=pixels,
        pixel_throughput_mpixels=round(throughput_mpix, 1),
        render_workload_index=round(required_tflops, 2),
        display_bandwidth_gbps=round(display_bw, 2),
        framebuffer_memory_gb=round(framebuffer_gb, 3),
        upscaling_required=upscaling_required,
        native_render_scale_pct=round(native_scale, 1),
    )
