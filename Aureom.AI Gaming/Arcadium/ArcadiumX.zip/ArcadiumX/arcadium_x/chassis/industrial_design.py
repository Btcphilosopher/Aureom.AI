"""chassis/industrial_design.py -- physical enclosure modelling.

Demonstrates propagation: a bigger GPU/cooling stack forces a bigger chassis,
which raises material cost, weight, and shipping cost.
"""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import ChassisMaterial
from arcadium_x.thermal.cooling import CoolingResult

# Fixed board + PSU + shielding volume that must fit regardless of cooling size (litres)
BASE_INTERNAL_VOLUME_L = 1.8
CLEARANCE_FACTOR = 1.35  # airflow clearance around the cooling stack


@dataclass
class ChassisResult:
    material_name: str
    volume_l: float
    width_mm: float
    height_mm: float
    depth_mm: float
    weight_kg: float
    material_cost_usd: float
    thermal_conductivity: float
    manufacturability_index: float
    strength_index: float
    shipping_cost_usd: float


def evaluate_chassis(material: ChassisMaterial, cooling: CoolingResult, psu_weight_kg: float) -> ChassisResult:
    internal_volume = (BASE_INTERNAL_VOLUME_L + cooling.volume_l) * CLEARANCE_FACTOR
    shell_volume = internal_volume * 1.12  # wall thickness allowance

    # Assume a roughly console-shaped enclosure: fixed aspect ratio, volume drives scale
    # width:height:depth ratio approximates 3.1 : 1 : 2.4 (slim tower form factor)
    scale = (shell_volume / (3.1 * 1.0 * 2.4)) ** (1 / 3) * 100  # litres -> cm scale factor
    width_mm = round(3.1 * scale * 10, 1)
    height_mm = round(1.0 * scale * 10, 1)
    depth_mm = round(2.4 * scale * 10, 1)

    shell_thickness_l_equiv = shell_volume - internal_volume
    material_mass_kg = shell_thickness_l_equiv * material.density_kg_l
    total_weight = round(material_mass_kg + cooling.weight_kg + psu_weight_kg + 0.9, 2)  # +0.9kg board/misc

    material_cost = round(material_mass_kg * material.cost_per_kg, 2)

    # Shipping cost scales with volumetric weight (industry dim-weight approximation)
    dim_weight_kg = shell_volume * 0.167  # standard air-freight dim divisor approximation
    billed_weight = max(total_weight, dim_weight_kg)
    shipping_cost = round(2.10 + billed_weight * 1.35, 2)

    return ChassisResult(
        material_name=material.name,
        volume_l=round(shell_volume, 2),
        width_mm=width_mm,
        height_mm=height_mm,
        depth_mm=depth_mm,
        weight_kg=total_weight,
        material_cost_usd=material_cost,
        thermal_conductivity=material.thermal_conductivity,
        manufacturability_index=material.manufacturability_index,
        strength_index=material.strength_index,
        shipping_cost_usd=shipping_cost,
    )
