"""optimisation/optimizer.py -- ArcadiumOptimizer: multi-objective genetic search.

Explores the full design space (core/architecture.py catalogues) to solve the
final objective function from spec section 47:

    MAXIMISE performance + efficiency + memory-efficiency + thermal headroom
             + acoustic quality + reliability + manufacturability + profitability
    SUBJECT TO $1,000 RRP viability, safe power, safe temperatures,
               manufacturable design, acceptable weight/volume/noise,
               supply-chain constraints.

A constraint-penalised genetic algorithm keeps this dependency-free (no
scipy/DEAP requirement) while still doing real multi-objective search; the
Pareto frontier of every individual ever evaluated is tracked separately in
optimisation/pareto.py so a user can pick a different trade-off after the
fact without re-running search.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from arcadium_x.core import architecture as cat
from arcadium_x.core.specs import ConsoleDesign
from arcadium_x.simulation.testbench import TestBench, TestBenchReport

GENE_CATALOGUES = {
    "cpu": list(cat.CPU_CATALOGUE.keys()),
    "gpu": list(cat.GPU_CATALOGUE.keys()),
    "ai": list(cat.AI_CATALOGUE.keys()),
    "memory": list(cat.MEMORY_CATALOGUE.keys()),
    "storage": list(cat.STORAGE_CATALOGUE.keys()),
    "cooling": list(cat.COOLING_CATALOGUE.keys()),
    "psu": list(cat.PSU_CATALOGUE.keys()),
    "chassis_material": list(cat.CHASSIS_MATERIALS.keys()),
    "controller": list(cat.CONTROLLER_CATALOGUE.keys()),
    "network": list(cat.NETWORK_CATALOGUE.keys()),
    "security": list(cat.SECURITY_CATALOGUE.keys()),
}


@dataclass
class ObjectiveWeights:
    performance: float = 1.0
    efficiency: float = 0.7
    reliability: float = 0.8
    acoustics: float = 0.8
    manufacturability: float = 0.7
    profitability: float = 0.9
    cost: float = 1.0
    power: float = 0.4
    weight: float = 0.3
    thermal_risk: float = 0.9


@dataclass
class Constraints:
    min_performance: float = 0.0
    min_mtbf_hours: float = 0.0
    max_peak_dba: float = 999.0
    max_weight_kg: float = 999.0
    max_volume_l: float = 999.0
    require_margin_positive: bool = True
    allow_throttling: bool = False


@dataclass
class Individual:
    genes: dict
    design: ConsoleDesign
    testbench: TestBenchReport
    fitness: float
    feasible: bool
    violations: list = field(default_factory=list)


@dataclass
class OptimisationResult:
    best: Individual
    population_history: list  # list[list[Individual]] per generation
    all_evaluated: list  # flat list[Individual] across the whole run
    generations: int
    population_size: int


class ArcadiumOptimizer:
    def __init__(self, base_design: ConsoleDesign, weights: ObjectiveWeights | None = None,
                 constraints: Constraints | None = None, seed: int | None = 42):
        self.base_design = base_design
        self.weights = weights or ObjectiveWeights()
        self.constraints = constraints or Constraints()
        self.rng = random.Random(seed)
        self.testbench = TestBench()

    # -- individual construction --------------------------------------------

    def _random_genes(self) -> dict:
        return {gene: self.rng.choice(options) for gene, options in GENE_CATALOGUES.items()}

    def _design_from_genes(self, genes: dict) -> ConsoleDesign:
        return self.base_design.model_copy(update=genes, deep=True)

    def _evaluate(self, genes: dict) -> Individual:
        design = self._design_from_genes(genes)
        tb = self.testbench.run(design)
        r = tb.simulation
        w = self.weights
        c = self.constraints

        peak_power = r.power.totals_w["peak"]
        efficiency_score = min(100.0, 100.0 * tb.performance.total / max(1.0, peak_power / 100.0))
        cost_penalty = min(150.0, 100.0 * r.manufacturing_cost.manufacturing_cost_usd
                            / max(1.0, r.design.economics.rrp_usd * 0.60))
        power_penalty = min(100.0, peak_power / 6.0)
        weight_penalty = min(100.0, r.chassis.weight_kg * 8.0)
        thermal_risk = r.reliability.thermal_stress_index
        reliability_score = min(100.0, r.reliability.mtbf_hours / 1000.0)
        profitability_score = max(0.0, min(100.0, r.economics.gross_margin_pct * 2.2))

        fitness = (
            w.performance * tb.performance.total
            + w.efficiency * efficiency_score
            + w.reliability * reliability_score
            + w.acoustics * r.acoustics.silent_performance_index
            + w.manufacturability * r.manufacturability.manufacturability_score
            + w.profitability * profitability_score
            - w.cost * cost_penalty
            - w.power * power_penalty
            - w.weight * weight_penalty
            - w.thermal_risk * thermal_risk
        )

        violations = []
        if not r.psu.safe:
            violations.append("PSU unsafe at peak load")
        if tb.performance.total < c.min_performance:
            violations.append(f"performance {tb.performance.total:.1f} below minimum {c.min_performance}")
        if r.reliability.mtbf_hours < c.min_mtbf_hours:
            violations.append(f"MTBF {r.reliability.mtbf_hours:.0f}h below minimum {c.min_mtbf_hours:.0f}h")
        if r.acoustics.peak_dba > c.max_peak_dba:
            violations.append(f"peak noise {r.acoustics.peak_dba:.1f}dBA exceeds {c.max_peak_dba}dBA")
        if r.chassis.weight_kg > c.max_weight_kg:
            violations.append(f"weight {r.chassis.weight_kg:.2f}kg exceeds {c.max_weight_kg}kg")
        if r.chassis.volume_l > c.max_volume_l:
            violations.append(f"volume {r.chassis.volume_l:.1f}L exceeds {c.max_volume_l}L")
        if c.require_margin_positive and not r.economics.viable:
            violations.append("negative gross margin at target RRP")
        if not c.allow_throttling and r.thermal_by_state["peak"].throttling:
            violations.append("thermal throttling at peak load")

        feasible = len(violations) == 0
        if not feasible:
            fitness -= 300.0 * len(violations)

        return Individual(genes=genes, design=design, testbench=tb, fitness=fitness,
                           feasible=feasible, violations=violations)

    # -- genetic operators ----------------------------------------------------

    def _crossover(self, a: dict, b: dict) -> dict:
        return {gene: (a[gene] if self.rng.random() < 0.5 else b[gene]) for gene in GENE_CATALOGUES}

    def _mutate(self, genes: dict, rate: float) -> dict:
        mutated = dict(genes)
        for gene, options in GENE_CATALOGUES.items():
            if self.rng.random() < rate:
                mutated[gene] = self.rng.choice(options)
        return mutated

    def _tournament(self, population: list, k: int = 3) -> Individual:
        contenders = self.rng.sample(population, min(k, len(population)))
        return max(contenders, key=lambda ind: ind.fitness)

    # -- main loop -------------------------------------------------------------

    def run(self, generations: int = 25, population_size: int = 24, mutation_rate: float = 0.18,
            elite_count: int = 2) -> OptimisationResult:
        population = [self._evaluate(self._random_genes()) for _ in range(population_size)]
        # Seed one individual with the current base design's own genes for continuity
        base_genes = {
            "cpu": self.base_design.cpu, "gpu": self.base_design.gpu, "ai": self.base_design.ai,
            "memory": self.base_design.memory, "storage": self.base_design.storage,
            "cooling": self.base_design.cooling, "psu": self.base_design.psu,
            "chassis_material": self.base_design.chassis_material, "controller": self.base_design.controller,
            "network": self.base_design.network, "security": self.base_design.security,
        }
        population[0] = self._evaluate(base_genes)

        history = [population]
        all_evaluated = list(population)

        for _ in range(generations):
            ranked = sorted(population, key=lambda ind: ind.fitness, reverse=True)
            next_pop = ranked[:elite_count]

            while len(next_pop) < population_size:
                parent_a = self._tournament(population)
                parent_b = self._tournament(population)
                child_genes = self._mutate(self._crossover(parent_a.genes, parent_b.genes), mutation_rate)
                next_pop.append(self._evaluate(child_genes))

            population = next_pop
            history.append(population)
            all_evaluated.extend(population)

        best = max(all_evaluated, key=lambda ind: ind.fitness)

        return OptimisationResult(
            best=best, population_history=history, all_evaluated=all_evaluated,
            generations=generations, population_size=population_size,
        )
