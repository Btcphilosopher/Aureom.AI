"""optimisation/scenarios.py -- the six predefined design scenarios (spec section 41)."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import ConsoleDesign
from arcadium_x.optimisation.optimizer import ArcadiumOptimizer, Constraints, ObjectiveWeights, OptimisationResult


@dataclass
class Scenario:
    key: str
    label: str
    description: str
    weights: ObjectiveWeights
    constraints: Constraints


SCENARIOS: dict[str, Scenario] = {
    "balanced_flagship": Scenario(
        key="balanced_flagship",
        label="Scenario 1 -- Balanced Flagship",
        description="Optimise performance, noise, cost and reliability together.",
        weights=ObjectiveWeights(performance=1.0, efficiency=0.8, reliability=1.0, acoustics=1.0,
                                  manufacturability=0.8, profitability=0.8, cost=1.0, power=0.5,
                                  weight=0.4, thermal_risk=0.9),
        constraints=Constraints(require_margin_positive=True, max_peak_dba=46.0),
    ),
    "absolute_performance": Scenario(
        key="absolute_performance",
        label="Scenario 2 -- Absolute Performance",
        description="Maximise CPU/GPU/memory/bandwidth; cost may rise within reasonable limits.",
        weights=ObjectiveWeights(performance=2.2, efficiency=0.5, reliability=0.5, acoustics=0.3,
                                  manufacturability=0.3, profitability=0.3, cost=0.35, power=0.2,
                                  weight=0.15, thermal_risk=0.6),
        constraints=Constraints(require_margin_positive=True, max_peak_dba=52.0),
    ),
    "silent_console": Scenario(
        key="silent_console",
        label="Scenario 3 -- Silent Console",
        description="Prioritise thermal efficiency, large cooling, low fan RPM and acoustics.",
        weights=ObjectiveWeights(performance=0.6, efficiency=0.9, reliability=0.9, acoustics=2.2,
                                  manufacturability=0.6, profitability=0.5, cost=0.6, power=0.5,
                                  weight=0.3, thermal_risk=1.4),
        constraints=Constraints(require_margin_positive=True, max_peak_dba=37.0),
    ),
    "small_form_factor": Scenario(
        key="small_form_factor",
        label="Scenario 4 -- Small Form Factor",
        description="Minimise volume and weight while maintaining performance.",
        weights=ObjectiveWeights(performance=0.9, efficiency=0.9, reliability=0.7, acoustics=0.6,
                                  manufacturability=0.7, profitability=0.6, cost=0.7, power=0.6,
                                  weight=1.8, thermal_risk=1.0),
        constraints=Constraints(require_margin_positive=True, max_volume_l=5.5, max_weight_kg=3.2),
    ),
    "maximum_profit": Scenario(
        key="maximum_profit",
        label="Scenario 5 -- Maximum Profit",
        description="Maximise manufacturer gross margin subject to minimum performance/reliability/thermal targets.",
        weights=ObjectiveWeights(performance=0.4, efficiency=0.5, reliability=0.5, acoustics=0.4,
                                  manufacturability=0.7, profitability=2.2, cost=1.3, power=0.3,
                                  weight=0.2, thermal_risk=0.7),
        constraints=Constraints(require_margin_positive=True, min_performance=28.0,
                                 min_mtbf_hours=30000.0, max_peak_dba=48.0),
    ),
    "no_compromise_1000": Scenario(
        key="no_compromise_1000",
        label="Scenario 6 -- No-Compromise $1,000 Flagship",
        description="Best overall commercially viable architecture at the $1,000 RRP target.",
        weights=ObjectiveWeights(performance=1.3, efficiency=1.0, reliability=1.0, acoustics=1.0,
                                  manufacturability=0.9, profitability=1.1, cost=0.9, power=0.4,
                                  weight=0.3, thermal_risk=1.0),
        constraints=Constraints(require_margin_positive=True, min_performance=32.0, max_peak_dba=44.0),
    ),
}


def run_scenario(name: str, base_design: ConsoleDesign, generations: int = 25,
                  population_size: int = 24, seed: int | None = 42) -> tuple[Scenario, OptimisationResult]:
    if name not in SCENARIOS:
        raise ValueError(f"Unknown scenario '{name}'. Options: {list(SCENARIOS)}")
    scenario = SCENARIOS[name]
    optimizer = ArcadiumOptimizer(base_design, weights=scenario.weights, constraints=scenario.constraints, seed=seed)
    result = optimizer.run(generations=generations, population_size=population_size)
    return scenario, result
