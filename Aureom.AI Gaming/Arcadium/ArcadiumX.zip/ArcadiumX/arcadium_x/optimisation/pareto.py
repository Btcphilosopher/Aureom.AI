"""optimisation/pareto.py -- Pareto frontier extraction & preference-based selection."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.optimisation.optimizer import Individual


@dataclass
class ParetoPoint:
    revision_label: str
    performance: float
    cost_usd: float
    individual: Individual


def performance_cost_frontier(individuals: list[Individual], feasible_only: bool = True) -> list[ParetoPoint]:
    """Pareto frontier on (maximise performance, minimise cost)."""
    pool = [i for i in individuals if (i.feasible or not feasible_only)]
    points = [
        ParetoPoint(
            revision_label=f"{ind.design.gpu}/{ind.design.memory}/{ind.design.cooling}",
            performance=ind.testbench.performance.total,
            cost_usd=ind.testbench.simulation.manufacturing_cost.manufacturing_cost_usd,
            individual=ind,
        )
        for ind in pool
    ]

    frontier = []
    for p in points:
        dominated = any(
            (q.performance >= p.performance and q.cost_usd <= p.cost_usd)
            and (q.performance > p.performance or q.cost_usd < p.cost_usd)
            for q in points
        )
        if not dominated:
            frontier.append(p)

    frontier.sort(key=lambda p: p.cost_usd)
    # de-duplicate identical (cost, performance) pairs
    seen = set()
    unique = []
    for p in frontier:
        key = (round(p.cost_usd, 1), round(p.performance, 1))
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


PREFERENCE_KEYS = {
    "maximum_performance": lambda ind: ind.testbench.performance.total,
    "maximum_margin": lambda ind: ind.testbench.simulation.economics.gross_margin_pct,
    "minimum_noise": lambda ind: -ind.testbench.simulation.acoustics.peak_dba,
    "minimum_power": lambda ind: -ind.testbench.simulation.power.totals_w["peak"],
    "minimum_size": lambda ind: -ind.testbench.simulation.chassis.volume_l,
    "maximum_reliability": lambda ind: ind.testbench.simulation.reliability.mtbf_hours,
}


def select_by_preference(individuals: list[Individual], preference: str, feasible_only: bool = True) -> Individual:
    if preference not in PREFERENCE_KEYS:
        raise ValueError(f"Unknown preference '{preference}'. Options: {list(PREFERENCE_KEYS)}")
    pool = [i for i in individuals if (i.feasible or not feasible_only)] or list(individuals)
    return max(pool, key=PREFERENCE_KEYS[preference])
