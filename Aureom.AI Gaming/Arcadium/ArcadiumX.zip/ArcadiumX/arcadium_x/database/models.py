"""database/models.py -- lightweight SQLite persistence layer.

Stores every design revision, its full simulation/benchmark/cost/thermal/
power/manufacturing output, and optimisation-run history, so the design
timeline in spec section 36 ("REVISION 01 ... REVISION 20 ...") survives
between sessions.
"""
from __future__ import annotations

import dataclasses
import datetime as _dt
import json
import sqlite3
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel

DEFAULT_DB_PATH = Path(__file__).resolve().parent.parent.parent / "output" / "arcadium_x.sqlite3"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name TEXT NOT NULL,
    revision INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    notes TEXT,
    design_json TEXT NOT NULL,
    report_json TEXT NOT NULL,
    performance_total REAL,
    manufacturing_cost REAL,
    gross_margin_pct REAL,
    thermal_headroom_pct REAL,
    acoustic_peak_dba REAL,
    manufacturability_score REAL,
    reliability_mtbf_hours REAL
);

CREATE TABLE IF NOT EXISTS optimisation_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name TEXT NOT NULL,
    scenario TEXT NOT NULL,
    created_at TEXT NOT NULL,
    generations INTEGER,
    population_size INTEGER,
    best_design_json TEXT NOT NULL,
    best_fitness REAL,
    pareto_json TEXT NOT NULL
);
"""


def to_jsonable(obj: Any) -> Any:
    """Recursively convert Pydantic models / dataclasses / enums into plain
    JSON-serialisable structures."""
    if isinstance(obj, BaseModel):
        return to_jsonable(obj.model_dump())
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: to_jsonable(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_jsonable(v) for v in obj]
    return obj


def get_connection(db_path: Path | str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.executescript(_SCHEMA)
    return conn


def save_revision(conn: sqlite3.Connection, project_name: str, design, report, testbench=None) -> int:
    design_json = json.dumps(to_jsonable(design))
    report_json = json.dumps(to_jsonable(report))

    performance_total = None
    if testbench is not None:
        performance_total = testbench.performance.total

    peak_thermal = report.thermal_by_state.get("peak")
    cur = conn.execute(
        """INSERT INTO revisions
           (project_name, revision, created_at, notes, design_json, report_json,
            performance_total, manufacturing_cost, gross_margin_pct, thermal_headroom_pct,
            acoustic_peak_dba, manufacturability_score, reliability_mtbf_hours)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            project_name,
            design.revision,
            _dt.datetime.utcnow().isoformat(),
            design.notes,
            design_json,
            report_json,
            performance_total,
            report.manufacturing_cost.manufacturing_cost_usd,
            report.economics.gross_margin_pct,
            peak_thermal.thermal_headroom_pct if peak_thermal else None,
            report.acoustics.peak_dba,
            report.manufacturability.manufacturability_score,
            report.reliability.mtbf_hours,
        ),
    )
    conn.commit()
    return cur.lastrowid


def get_next_revision_number(conn: sqlite3.Connection, project_name: str) -> int:
    cur = conn.execute(
        "SELECT MAX(revision) FROM revisions WHERE project_name = ?", (project_name,)
    )
    row = cur.fetchone()
    current_max = row[0] if row and row[0] is not None else 0
    return current_max + 1


def list_revisions(conn: sqlite3.Connection, project_name: str) -> list[sqlite3.Row]:
    conn.row_factory = sqlite3.Row
    cur = conn.execute(
        """SELECT id, revision, created_at, notes, performance_total, manufacturing_cost,
                  gross_margin_pct, thermal_headroom_pct, acoustic_peak_dba,
                  manufacturability_score, reliability_mtbf_hours
           FROM revisions WHERE project_name = ? ORDER BY revision ASC""",
        (project_name,),
    )
    return cur.fetchall()


def get_revision(conn: sqlite3.Connection, project_name: str, revision: int) -> Optional[dict]:
    conn.row_factory = sqlite3.Row
    cur = conn.execute(
        """SELECT * FROM revisions WHERE project_name = ? AND revision = ?
           ORDER BY id DESC LIMIT 1""",
        (project_name, revision),
    )
    row = cur.fetchone()
    if row is None:
        return None
    result = dict(row)
    result["design"] = json.loads(result.pop("design_json"))
    result["report"] = json.loads(result.pop("report_json"))
    return result


def save_optimisation_run(conn: sqlite3.Connection, project_name: str, scenario: str,
                           generations: int, population_size: int,
                           best_design, best_fitness: float, pareto_front: list) -> int:
    cur = conn.execute(
        """INSERT INTO optimisation_runs
           (project_name, scenario, created_at, generations, population_size,
            best_design_json, best_fitness, pareto_json)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            project_name, scenario, _dt.datetime.utcnow().isoformat(),
            generations, population_size,
            json.dumps(to_jsonable(best_design)), best_fitness,
            json.dumps(to_jsonable(pareto_front)),
        ),
    )
    conn.commit()
    return cur.lastrowid
