"""thermal/cooling.py -- premium cooling-solution modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import CoolingSpec


@dataclass
class CoolingResult:
    spec_name: str
    capacity_w: float
    weight_kg: float
    cost_usd: float
    reliability_index: float
    manufacturability_index: float
    volume_l: float
    base_noise_dba: float


def evaluate_cooling(spec: CoolingSpec) -> CoolingResult:
    return CoolingResult(
        spec_name=spec.name,
        capacity_w=spec.capacity_w,
        weight_kg=spec.weight_kg,
        cost_usd=spec.cost_usd,
        reliability_index=spec.reliability_index,
        manufacturability_index=spec.manufacturability_index,
        volume_l=spec.volume_l,
        base_noise_dba=spec.base_noise_dba,
    )
