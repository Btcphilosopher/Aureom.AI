"""thermal/acoustics.py -- AcousticEngine: fan-curve driven noise modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.thermal.cooling import CoolingResult
from arcadium_x.thermal.thermal import ThermalResult


@dataclass
class AcousticResult:
    idle_dba: float
    typical_dba: float
    heavy_dba: float
    peak_dba: float
    fan_rpm_peak: float
    silent_performance_index: float  # 0-100, higher = quiet AND capable


class AcousticEngine:
    """Fan noise scales with the cube of RPM (fan-law approximation); RPM itself
    scales with how close total heat load sits to cooling capacity."""

    def __init__(self, case_resonance_db: float = 1.5, psu_noise_db: float = 0.8):
        self.case_resonance_db = case_resonance_db
        self.psu_noise_db = psu_noise_db

    def _dba_for_load(self, load_ratio: float, cooling: CoolingResult) -> tuple[float, float]:
        load_ratio = max(0.05, min(load_ratio, 1.35))
        rpm_frac = load_ratio ** 0.65  # fan-curve response
        # cubic fan-noise law referenced to the cooling solution's base noise floor
        dba = cooling.base_noise_dba + 22.0 * (rpm_frac ** 3) * 0.62
        dba += self.case_resonance_db + self.psu_noise_db
        rpm = 800 + rpm_frac * 3200
        return round(dba, 1), round(rpm, 0)

    def evaluate(self, cooling: CoolingResult, thermal_by_state: dict[str, ThermalResult]) -> AcousticResult:
        dba = {}
        rpm_peak = 0.0
        for state, result in thermal_by_state.items():
            ratio = result.total_heat_w / cooling.capacity_w if cooling.capacity_w else 1.5
            d, rpm = self._dba_for_load(ratio, cooling)
            dba[state] = d
            rpm_peak = max(rpm_peak, rpm)

        # Silent Performance Index: rewards low peak noise relative to how much heat
        # the system is successfully rejecting (bigger, quieter cooler on a hot chip scores well).
        peak = dba.get("peak", max(dba.values()) if dba else 40.0)
        thermal_headroom = thermal_by_state.get("peak")
        headroom_pct = thermal_headroom.thermal_headroom_pct if thermal_headroom else 0.0
        spi = max(0.0, min(100.0, 100.0 - (peak - 22.0) * 3.2 + headroom_pct * 0.15))

        return AcousticResult(
            idle_dba=dba.get("idle", 0.0),
            typical_dba=dba.get("typical", 0.0),
            heavy_dba=dba.get("heavy", 0.0),
            peak_dba=peak,
            fan_rpm_peak=rpm_peak,
            silent_performance_index=round(spi, 1),
        )
