"""thermal/thermal.py -- ThermalEngine: heat load, temperatures, throttling."""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.thermal.cooling import CoolingResult

# Simplified thermal-resistance model. Each heat source has a junction-to-ambient
# resistance (C per Watt) that the cooling solution reduces via its capacity headroom.
BASE_RJA = {
    "cpu": 0.42,
    "gpu": 0.34,
    "memory": 0.55,
    "vrm": 0.60,
    "ssd": 0.75,
    "psu": 0.50,
}

THROTTLE_TEMP_C = {
    "cpu": 95.0,
    "gpu": 92.0,
    "memory": 95.0,
    "vrm": 110.0,
    "ssd": 84.0,
    "psu": 105.0,
}


@dataclass
class ThermalResult:
    heat_sources_w: dict
    total_heat_w: float
    cooling_capacity_w: float
    thermal_headroom_pct: float
    junction_temps_c: dict
    hottest_component: str
    hottest_temp_c: float
    throttling: bool
    throttled_components: list = field(default_factory=list)


class ThermalEngine:
    def __init__(self, ambient_temp_c: float = 23.0):
        self.ambient_temp_c = ambient_temp_c

    def evaluate(self, heat_sources_w: dict[str, float], cooling: CoolingResult) -> ThermalResult:
        total_heat = sum(heat_sources_w.values())

        headroom_pct = 100.0 * (cooling.capacity_w - total_heat) / cooling.capacity_w if cooling.capacity_w else -999.0

        # When total heat approaches/exceeds cooling capacity, thermal resistance degrades
        # (fans can't move enough air, vapour chamber saturates), amplifying junction temps.
        load_ratio = total_heat / cooling.capacity_w if cooling.capacity_w else 9.0
        degradation = 1.0 if load_ratio <= 0.75 else 1.0 + ((load_ratio - 0.75) / 0.25) ** 1.6 * 1.4

        temps = {}
        throttled = []
        for comp, watts in heat_sources_w.items():
            rja = BASE_RJA.get(comp, 0.5) * degradation
            # Cooling capacity beyond baseline reduces effective resistance a little further
            cooling_bonus = max(0.55, 1.0 - (cooling.capacity_w - 200) / 2000.0)
            temp = self.ambient_temp_c + watts * rja * cooling_bonus
            temps[comp] = round(temp, 1)
            if temp >= THROTTLE_TEMP_C.get(comp, 95.0):
                throttled.append(comp)

        if temps:
            hottest = max(temps, key=temps.get)
        else:
            hottest = "-"

        return ThermalResult(
            heat_sources_w={k: round(v, 2) for k, v in heat_sources_w.items()},
            total_heat_w=round(total_heat, 2),
            cooling_capacity_w=cooling.capacity_w,
            thermal_headroom_pct=round(headroom_pct, 1),
            junction_temps_c=temps,
            hottest_component=hottest,
            hottest_temp_c=temps.get(hottest, 0.0),
            throttling=len(throttled) > 0,
            throttled_components=throttled,
        )
