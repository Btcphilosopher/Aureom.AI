"""simulation/benchmark.py -- PerformanceEngine & the ARCADIUM PERFORMANCE INDEX."""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core.system import SimulationReport

DEFAULT_WEIGHTS = {
    "cpu": 0.18,
    "gpu": 0.32,
    "memory": 0.14,
    "ai": 0.10,
    "storage": 0.14,
    "io": 0.12,
}

# Diagnoses that mean *realised* performance falls short of theoretical peak.
PENALISED_DIAGNOSES = {
    "MEMORY-BANDWIDTH LIMITED": 0.90,
    "CAPACITY LIMITED": 0.85,
    "LATENCY LIMITED": 0.93,
    "CACHE LIMITED": 0.94,
}


@dataclass
class PerformanceIndexResult:
    scores: dict
    weights: dict
    bottleneck_penalty: float
    security_overhead_penalty: float
    total: float


class PerformanceEngine:
    """Computes the weighted ARCADIUM PERFORMANCE INDEX from a SimulationReport,
    applying second-order penalties for memory bottlenecks and security overhead
    so the index reflects realised, not theoretical, performance."""

    def __init__(self, weights: dict | None = None):
        w = dict(weights or DEFAULT_WEIGHTS)
        total_w = sum(w.values())
        self.weights = {k: v / total_w for k, v in w.items()}  # normalise to 1.0

    def evaluate(self, report: SimulationReport) -> PerformanceIndexResult:
        scores = {
            "cpu": report.cpu.performance_score,
            "gpu": report.gpu.performance_score,
            "memory": report.memory.performance_score,
            "ai": report.ai.performance_score,
            "storage": report.storage.performance_score,
            "io": report.io_performance_score,
        }

        bottleneck_factor = PENALISED_DIAGNOSES.get(report.memory_diagnosis.diagnosis, 1.0)
        adjusted = dict(scores)
        adjusted["gpu"] = adjusted["gpu"] * bottleneck_factor
        adjusted["memory"] = adjusted["memory"] * (bottleneck_factor if bottleneck_factor < 1.0 else 1.0)

        security_penalty = 1.0 - (report.security_overhead_pct / 100.0)

        total = sum(adjusted[k] * self.weights.get(k, 0.0) for k in adjusted) * security_penalty
        total = max(0.0, min(100.0, total))

        return PerformanceIndexResult(
            scores={k: round(v, 2) for k, v in scores.items()},
            weights={k: round(v, 3) for k, v in self.weights.items()},
            bottleneck_penalty=round(bottleneck_factor, 3),
            security_overhead_penalty=round(security_penalty, 4),
            total=round(total, 2),
        )
