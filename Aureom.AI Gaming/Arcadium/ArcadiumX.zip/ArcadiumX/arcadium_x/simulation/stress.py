"""simulation/stress.py -- StressTestingEngine: combined worst-case load validation."""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core.specs import PowerState
from arcadium_x.core.system import SimulationReport


@dataclass
class StressTestResult:
    peak_power_w: float
    psu_safe: bool
    psu_headroom_pct: float
    thermal_throttling: bool
    throttled_components: list
    hottest_component: str
    hottest_temp_c: float
    fabric_congestion_pct: float
    bandwidth_utilisation_pct: float
    passed: bool
    failures: list = field(default_factory=list)


class StressTestingEngine:
    """Runs the console at 100% CPU / GPU / memory / storage / I/O / network /
    thermal load simultaneously (the PEAK power state already models this
    combined worst case) and checks every safety margin."""

    def run(self, report: SimulationReport) -> StressTestResult:
        peak_thermal = report.thermal_by_state[PowerState.PEAK.value]
        failures = []

        if not report.psu.safe:
            failures.append(report.psu.warning)
        if peak_thermal.throttling:
            failures.append(
                f"Thermal throttling under sustained peak load: {', '.join(peak_thermal.throttled_components)}"
            )
        if report.fabric.congestion_pct > 100:
            failures.append(f"System fabric oversubscribed at {report.fabric.congestion_pct:.0f}% of capacity")
        if report.bandwidth.utilisation_pct > 105:
            failures.append(f"Memory bandwidth oversubscribed at {report.bandwidth.utilisation_pct:.0f}%")

        return StressTestResult(
            peak_power_w=report.power.totals_w[PowerState.PEAK.value],
            psu_safe=report.psu.safe,
            psu_headroom_pct=report.psu.headroom_pct,
            thermal_throttling=peak_thermal.throttling,
            throttled_components=peak_thermal.throttled_components,
            hottest_component=peak_thermal.hottest_component,
            hottest_temp_c=peak_thermal.hottest_temp_c,
            fabric_congestion_pct=report.fabric.congestion_pct,
            bandwidth_utilisation_pct=report.bandwidth.utilisation_pct,
            passed=len(failures) == 0,
            failures=failures,
        )
