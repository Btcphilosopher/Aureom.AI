"""simulation/testbench.py -- bottleneck detection, assembly validation & the full test bench.

Ties PerformanceEngine + StressTestingEngine + bottleneck diagnosis + the
"simulated construction mode" assembly checklist (spec section 39) together
into one call so main.py / the optimiser only need one entry point.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core.specs import PowerState
from arcadium_x.core.system import ConsoleSystem, SimulationReport
from arcadium_x.simulation.benchmark import PerformanceEngine, PerformanceIndexResult
from arcadium_x.simulation.stress import StressTestingEngine, StressTestResult


@dataclass
class BottleneckReport:
    utilisation: dict  # subsystem -> % utilisation
    diagnosis: str
    detail: str
    recommendation: str


def detect_bottleneck(report: SimulationReport) -> BottleneckReport:
    link_util = {l.name: l.utilisation_pct for l in report.fabric.links}

    utilisation = {
        "GPU": report.gpu_utilisation_pct,
        "MEMORY": report.bandwidth.utilisation_pct,
        "CPU": link_util.get("cpu", 0.0),
        "STORAGE": link_util.get("storage", 0.0),
        "IO": link_util.get("io", 0.0),
        "NETWORK": link_util.get("network", 0.0),
    }

    peak_thermal = report.thermal_by_state[PowerState.PEAK.value]
    if peak_thermal.throttling:
        diagnosis = "THERMAL BOTTLENECK"
        detail = f"{', '.join(peak_thermal.throttled_components)} throttling at peak load"
        recommendation = "Upgrade cooling tier or reduce sustained TDP before addressing other subsystems"
    elif report.memory_diagnosis.diagnosis not in ("BALANCED", "COMPUTE LIMITED"):
        diagnosis = f"{report.memory_diagnosis.diagnosis.replace(' LIMITED', '')} BOTTLENECK"
        detail = f"Memory subsystem is the limiter ({report.memory_diagnosis.bandwidth_utilisation_pct:.0f}% bandwidth utilisation)"
        recommendation = report.memory_diagnosis.recommendation
    else:
        weakest = max(utilisation, key=utilisation.get)
        diagnosis = f"{weakest} BOTTLENECK" if utilisation[weakest] >= 85 else "NO DOMINANT BOTTLENECK"
        detail = f"{weakest} utilisation at {utilisation[weakest]:.0f}%"
        if diagnosis == "NO DOMINANT BOTTLENECK":
            recommendation = "System is well balanced; further gains require improving all subsystems together"
        else:
            recommendation = f"Increase {weakest.lower()} capacity/bandwidth to relieve the dominant constraint"

    return BottleneckReport(
        utilisation={k: round(v, 1) for k, v in utilisation.items()},
        diagnosis=diagnosis,
        detail=detail,
        recommendation=recommendation,
    )


@dataclass
class AssemblyCheck:
    stage: str
    passed: bool
    message: str


@dataclass
class AssemblyReport:
    checks: list
    all_passed: bool


_ASSEMBLY_STAGES = [
    "CHASSIS", "PCB", "CPU/GPU", "MEMORY", "VRM", "STORAGE",
    "COOLING", "PSU", "FANS", "CASE", "CONTROLLERS",
]


def validate_assembly(report: SimulationReport) -> AssemblyReport:
    """Walk the physical build order and validate compatibility, thermal
    clearance, power, I/O and cost/manufacturability at each stage."""
    checks: list[AssemblyCheck] = []

    checks.append(AssemblyCheck(
        "CHASSIS", report.chassis.volume_l > 0,
        f"{report.chassis.material_name} shell, {report.chassis.volume_l:.1f}L, {report.chassis.weight_kg:.2f}kg",
    ))

    pcb_ok = report.bom.pcb_cost_usd < report.bom.total_bom_usd * 0.35
    checks.append(AssemblyCheck(
        "PCB", pcb_ok,
        f"PCB cost ${report.bom.pcb_cost_usd:.2f} ({'within' if pcb_ok else 'EXCEEDS'} 35% of BOM budget)",
    ))

    compute_power_ok = (report.cpu.power_w + report.gpu.power_w) <= report.psu.wattage * 0.85
    checks.append(AssemblyCheck(
        "CPU/GPU", compute_power_ok,
        f"CPU+GPU TDP {report.cpu.power_w + report.gpu.power_w:.0f}W against {report.psu.wattage}W PSU",
    ))

    checks.append(AssemblyCheck(
        "MEMORY", report.bandwidth.memory_pressure_pct < 100,
        f"{report.memory.capacity_gb}GB installed, {report.bandwidth.memory_pressure_pct:.0f}% allocated under workload",
    ))

    vrm_temp = report.thermal_by_state[PowerState.PEAK.value].junction_temps_c.get("vrm", 0.0)
    checks.append(AssemblyCheck(
        "VRM", vrm_temp < 110.0,
        f"VRM junction {vrm_temp:.0f}C at peak load",
    ))

    checks.append(AssemblyCheck(
        "STORAGE", report.storage.capacity_tb > 0,
        f"{report.storage.spec_name}: {report.storage.seq_read_gbps:.1f} GB/s sequential read",
    ))

    clearance_ok = report.chassis.volume_l >= report.cooling.volume_l * 1.2
    checks.append(AssemblyCheck(
        "COOLING", clearance_ok,
        f"{report.cooling.spec_name} needs {report.cooling.volume_l:.1f}L clearance, chassis provides "
        f"{report.chassis.volume_l:.1f}L",
    ))

    checks.append(AssemblyCheck(
        "PSU", report.psu.safe,
        report.psu.warning or f"{report.psu.spec_name} safe at {report.psu.headroom_pct:.0f}% headroom",
    ))

    checks.append(AssemblyCheck(
        "FANS", report.acoustics.peak_dba < 48.0,
        f"Peak {report.acoustics.peak_dba:.1f} dBA at {report.acoustics.fan_rpm_peak:.0f} RPM",
    ))

    checks.append(AssemblyCheck(
        "CASE", report.manufacturability.manufacturability_score >= 35,
        f"Manufacturability {report.manufacturability.manufacturability_score:.0f}/100",
    ))

    checks.append(AssemblyCheck(
        "CONTROLLERS", report.controller.unit_count in (1, 2, 3, 4, 8),
        f"{report.controller.unit_count}x {report.controller.spec_name}, "
        f"{report.controller.input_latency_ms:.1f}ms base latency",
    ))

    return AssemblyReport(checks=checks, all_passed=all(c.passed for c in checks))


@dataclass
class TestBenchReport:
    simulation: SimulationReport
    performance: PerformanceIndexResult
    stress: StressTestResult
    bottleneck: BottleneckReport
    assembly: AssemblyReport


class TestBench:
    """One-call entry point: DESIGN -> SIMULATE -> BENCHMARK -> STRESS -> DIAGNOSE -> VALIDATE."""

    def __init__(self, performance_weights: dict | None = None):
        self.performance_engine = PerformanceEngine(performance_weights)
        self.stress_engine = StressTestingEngine()

    def run(self, design) -> TestBenchReport:
        report = ConsoleSystem(design).simulate()
        performance = self.performance_engine.evaluate(report)
        stress = self.stress_engine.run(report)
        bottleneck = detect_bottleneck(report)
        assembly = validate_assembly(report)
        return TestBenchReport(
            simulation=report, performance=performance, stress=stress,
            bottleneck=bottleneck, assembly=assembly,
        )
