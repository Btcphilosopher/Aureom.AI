"""storage/nvme.py -- NVMe SSD subsystem modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import StorageSpec, TechGeneration


@dataclass
class StorageResult:
    spec_name: str
    capacity_tb: float
    seq_read_gbps: float
    seq_write_gbps: float
    random_iops_k: float
    performance_score: float  # 0-100
    cost_usd: float
    power_w: float


_READ_CEILING = 11.5  # GB/s of idealised GEN4 8TB drive


def evaluate_storage(spec: StorageSpec, generation: TechGeneration) -> StorageResult:
    read = spec.seq_read_gbps * generation.process_efficiency
    write = spec.seq_write_gbps * generation.process_efficiency
    iops = spec.random_iops_k * generation.process_efficiency

    read_score = min(100.0, 100.0 * read / _READ_CEILING)
    capacity_score = min(100.0, 100.0 * spec.capacity_tb / 8.0)
    score = 0.65 * read_score + 0.35 * capacity_score

    # storage cost benefits from generational density improvements (cost per TB falls)
    cost = spec.cost_usd * generation.storage_density
    power = 2.2 + spec.controller_channels * 0.35  # watts, rough NVMe controller + NAND draw

    return StorageResult(
        spec_name=spec.name,
        capacity_tb=spec.capacity_tb,
        seq_read_gbps=round(read, 2),
        seq_write_gbps=round(write, 2),
        random_iops_k=round(iops, 1),
        performance_score=round(score, 2),
        cost_usd=round(cost, 2),
        power_w=round(power, 2),
    )
