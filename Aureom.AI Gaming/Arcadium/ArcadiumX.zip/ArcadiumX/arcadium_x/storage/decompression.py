"""storage/decompression.py -- DecompressionEngine: hardware-accelerated streaming.

Models the dedicated decompression block that sits between the SSD controller
and system memory, converting raw NVMe throughput into *effective* streamed
asset bandwidth (the number that actually matters for texture/geometry/audio
streaming and install/patch speed).
"""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import StorageSpec
from arcadium_x.storage.nvme import StorageResult

# Typical compression ratios by stream class (effective-bytes : raw-bytes)
COMPRESSION_RATIOS = {
    "texture_streaming": 2.6,
    "geometry_streaming": 2.1,
    "audio_streaming": 1.8,
    "installation": 2.3,
    "updates": 2.3,
}


@dataclass
class DecompressionResult:
    raw_read_gbps: float
    hw_decompression_throughput_gbps: float
    effective_stream_gbps: dict
    is_decompression_bound: bool


def evaluate_decompression(storage: StorageResult, spec: StorageSpec, generation_process_eff: float) -> DecompressionResult:
    # Fixed-function decompression block scales with controller channel count.
    hw_throughput = spec.controller_channels * 1.35 * generation_process_eff  # GB/s of decompressed output

    effective = {}
    bound = False
    for stream, ratio in COMPRESSION_RATIOS.items():
        raw_limited = storage.seq_read_gbps * ratio
        hw_limited = hw_throughput
        effective_gbps = min(raw_limited, hw_limited)
        if hw_limited < raw_limited:
            bound = True
        effective[stream] = round(effective_gbps, 2)

    return DecompressionResult(
        raw_read_gbps=storage.seq_read_gbps,
        hw_decompression_throughput_gbps=round(hw_throughput, 2),
        effective_stream_gbps=effective,
        is_decompression_bound=bound,
    )
