"""compute/cpu.py -- CPU performance & power modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import CPUSpec, TechGeneration


@dataclass
class CPUResult:
    spec_name: str
    effective_clock_ghz: float
    single_thread_index: float
    multi_thread_index: float
    performance_score: float  # 0-100 normalised index
    power_w: float
    cost_usd: float


# Normalisation ceiling: an idealised top-of-catalogue CPU under GEN4 scores ~100
_PERF_CEILING = 165_000.0


def evaluate_cpu(spec: CPUSpec, generation: TechGeneration) -> CPUResult:
    eff_clock = spec.clock_ghz * generation.process_efficiency
    single_thread = eff_clock * spec.ipc_index * 1000
    multi_thread = single_thread * (spec.threads ** 0.82) * generation.compute_density
    cache_bonus = 1 + (spec.cache_mb / 400.0)
    raw = multi_thread * cache_bonus * spec.arch_efficiency

    score = min(100.0, 100.0 * raw / _PERF_CEILING)

    power = spec.tdp_w / generation.power_efficiency
    cost = spec.cost_usd * generation.cost_multiplier

    return CPUResult(
        spec_name=spec.name,
        effective_clock_ghz=round(eff_clock, 2),
        single_thread_index=round(single_thread, 1),
        multi_thread_index=round(multi_thread, 1),
        performance_score=round(score, 2),
        power_w=round(power, 2),
        cost_usd=round(cost, 2),
    )
