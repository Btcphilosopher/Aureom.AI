"""compute/gpu.py -- GPU performance & power modelling."""
from __future__ import annotations

from dataclasses import dataclass

from arcadium_x.core.specs import GPUSpec, TechGeneration


@dataclass
class GPUResult:
    spec_name: str
    effective_tflops: float
    raster_index: float
    rt_index: float
    ai_index: float
    performance_score: float  # 0-100
    power_w: float
    cost_usd: float
    required_bandwidth_gbps: float  # bandwidth this GPU wants to stay compute-bound


_PERF_CEILING = 62.0  # shader TFLOPs of an idealised GEN4 flagship GPU


def evaluate_gpu(spec: GPUSpec, generation: TechGeneration) -> GPUResult:
    eff_tflops = spec.shader_tflops * generation.compute_density * generation.process_efficiency
    raster = eff_tflops / _PERF_CEILING * 100.0
    rt = min(100.0, spec.rt_index * generation.process_efficiency)
    ai = min(100.0, spec.ai_index * generation.process_efficiency)

    score = min(100.0, 0.65 * raster + 0.20 * rt + 0.15 * ai)

    power = spec.tdp_w / generation.power_efficiency
    cost = spec.cost_usd * generation.cost_multiplier

    # Rule-of-thumb: a well-balanced system needs ~ 10 GB/s of bandwidth per shader-TFLOP
    # (memory-side generational gains are already captured in the memory subsystem's own
    # effective bandwidth -- they are not re-applied to demand here).
    required_bw = eff_tflops * 10.0

    return GPUResult(
        spec_name=spec.name,
        effective_tflops=round(eff_tflops, 2),
        raster_index=round(raster, 2),
        rt_index=round(rt, 2),
        ai_index=round(ai, 2),
        performance_score=round(score, 2),
        power_w=round(power, 2),
        cost_usd=round(cost, 2),
        required_bandwidth_gbps=round(required_bw, 1),
    )
