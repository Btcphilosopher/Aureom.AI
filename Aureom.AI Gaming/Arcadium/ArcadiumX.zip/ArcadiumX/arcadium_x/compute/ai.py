"""compute/ai.py -- AI accelerator (NPU) modelling.

Hardware-only. The simulator never runs an actual model; it estimates
*capability* against representative synthetic workload classes so the rest
of the system (thermal, power, cost) can react to the choice.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from arcadium_x.core.specs import AISpec, TechGeneration

WORKLOAD_TOPS_DEMAND = {
    "upscaling": 18.0,
    "frame_generation": 35.0,
    "image_reconstruction": 22.0,
    "voice_processing": 4.0,
    "npc_inference": 12.0,
    "compression_offload": 8.0,
    "background_workloads": 6.0,
}


@dataclass
class AIResult:
    spec_name: str
    effective_tops: float
    performance_score: float  # 0-100
    power_w: float
    cost_usd: float
    workload_headroom: dict = field(default_factory=dict)  # workload -> % of TOPS budget free


_PERF_CEILING = 220.0  # TOPS of an idealised GEN4 flagship NPU


def evaluate_ai(spec: AISpec, generation: TechGeneration) -> AIResult:
    eff_tops = spec.tops * generation.compute_density
    score = min(100.0, 100.0 * eff_tops / _PERF_CEILING)
    power = spec.tdp_w / generation.power_efficiency if spec.tdp_w else 0.0
    cost = spec.cost_usd * generation.cost_multiplier

    headroom = {}
    for workload, demand in WORKLOAD_TOPS_DEMAND.items():
        if eff_tops <= 0:
            headroom[workload] = -100.0
        else:
            headroom[workload] = round(100.0 * (eff_tops - demand) / eff_tops, 1)

    return AIResult(
        spec_name=spec.name,
        effective_tops=round(eff_tops, 1),
        performance_score=round(score, 2),
        power_w=round(power, 2),
        cost_usd=round(cost, 2),
        workload_headroom=headroom,
    )
