# ARCADIUM X -- Premium Console Systems Laboratory

A Python engineering simulator for designing a fictional **$1,000 RRP flagship
games console**. This is not a game -- it's the engineering operating system
behind building one: a digital twin of the console's compute, memory,
storage, thermal, power, acoustic, chassis, controller, networking, security
and manufacturing subsystems, wired together so that a single component
change propagates through every downstream calculation exactly the way it
would on a real hardware team.

    GPU upgrade -> power increase -> thermal increase -> cooling requirement
                -> chassis change -> manufacturing cost -> unit cost -> margin

    memory upgrade -> memory bandwidth -> GPU utilisation -> performance
                    -> power -> thermal -> cost

No real chip, vendor, or product is referenced anywhere -- every part
(`CPU-A1..A4`, `GPU-X1..X4`, ...) is a configurable synthetic architecture.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt      # pydantic (required); matplotlib (optional, for charts)

cd arcadium_x
python3 main.py baseline                                    # simulate the default flagship config
python3 main.py catalogue                                    # list every selectable component
python3 main.py roadmap                                      # GEN1-GEN4 technology roadmap
python3 main.py scenarios                                    # the 6 predefined design scenarios

python3 main.py simulate --gpu GPU-X3 --memory MEM-64 --cooling VAPOUR_CHAMBER --commit
python3 main.py stress --gpu GPU-X4 --cooling DUAL_FAN        # combined worst-case stress test
python3 main.py optimize --scenario no_compromise_1000 --commit   # genetic multi-objective search
python3 main.py history --plot                                # revision timeline (REVISION 01, 02, ...)
```

Everything is deterministic (fixed RNG seed by default) except when you
change inputs. All simulation runs, revisions and optimiser results persist
to `output/arcadium_x.sqlite3`.

## The lifecycle

```
CONCEPT -> ARCHITECTURE -> COMPONENT SELECTION -> SYSTEM INTEGRATION ->
THERMAL DESIGN -> POWER DESIGN -> MEMORY/STORAGE DESIGN -> I/O DESIGN ->
PROTOTYPE -> STRESS TEST -> BENCHMARK -> COST ANALYSIS -> OPTIMISATION ->
REDESIGN -> FINAL CONSOLE
```

`core/scheduler.py` tracks this state machine; `core/design_loop.py`'s
`DesignRevisionManager` drives DESIGN -> SIMULATE -> BENCHMARK -> STRESS ->
COST -> OPTIMISE -> REDESIGN and records every revision.

## Project layout

```
arcadium_x/
  core/          ConsoleSystem digital twin, component catalogue, design-loop
                 revision manager, lifecycle scheduler, Pydantic data models
  compute/       CPU / GPU / AI accelerator performance & power modelling
  memory/        Unified memory, bandwidth utilisation, MemoryOptimizer
                 bottleneck diagnosis
  storage/       NVMe SSD modelling, hardware DecompressionEngine
  io/            SystemFabric interconnect, display/render workload,
                 networking, USB/HDMI/DP peripherals
  thermal/       ThermalEngine (junction temps, throttling), cooling
                 catalogue, AcousticEngine (fan-curve dBA modelling)
  power/         PowerEngine (idle/typical/heavy/peak), PSU sizing & safety
  controllers/   Premium controller BOM/durability, input-latency pipeline
  chassis/       Physical enclosure sizing, materials, shipping cost
  engineering/   CostEngineeringEngine + $1,000 RRP economic waterfall,
                 ManufacturabilityScore + volume economics,
                 ComponentSupplyEngine, ReliabilityEngine (MTBF)
  simulation/    PerformanceEngine (ARCADIUM PERFORMANCE INDEX),
                 StressTestingEngine, TestBench (bottleneck detection +
                 simulated construction/assembly validation)
  optimisation/  ArcadiumOptimizer (constrained genetic algorithm),
                 Pareto frontier extraction & preference selection,
                 the 6 predefined design scenarios
  analytics/     Text engineering reports + the REVISION dashboard,
                 optional Matplotlib Pareto/history charts
  database/      SQLite persistence for every revision & optimisation run
  tests/         unittest suite (pipeline, propagation, cost, optimiser, DB)
  main.py        CLI entry point
```

## The six design scenarios

| key | what it optimises for |
|---|---|
| `balanced_flagship` | performance, noise, cost and reliability together |
| `absolute_performance` | maximum CPU/GPU/memory/bandwidth; cost may rise |
| `silent_console` | thermal efficiency, large cooling, low noise |
| `small_form_factor` | minimum volume/weight while keeping performance |
| `maximum_profit` | manufacturer gross margin, subject to minimum performance/reliability/thermal targets |
| `no_compromise_1000` | the best overall commercially viable $1,000 architecture |

Run `python3 main.py optimize --scenario <key> --commit` for any of them; it
prints the best architecture found, a feasibility/violations breakdown, and
saves a Pareto-frontier PNG (cost vs. performance) if matplotlib is installed.

## Notes on the economic model

The $1,000 RRP is **not** treated as a $1,000 hardware budget. It flows
through: `RRP -> retail margin -> wholesale price -> distributor margin ->
manufacturer revenue -> marketing/warranty reserves -> net revenue -> minus
manufacturing cost (BOM + assembly + test + packaging + shipping + warranty +
software) -> gross profit / margin`. With realistic retail economics, only
roughly two-thirds of RRP reaches the manufacturer as net revenue -- so a
naive "most powerful parts available" build is deliberately **not** viable
out of the box (see `python3 main.py baseline`). Reaching a positive-margin,
thermally-safe, quiet, manufacturable flagship is the actual design problem,
which is exactly what `optimize` and iterative `simulate --commit` revisions
are for.

## Tests

```bash
python3 -m unittest discover -s arcadium_x/tests -t .
```
