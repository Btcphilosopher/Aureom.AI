package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NexusRepository(private val dao: NexusDao) {

    val playerProfile: Flow<PlayerProfile?> = dao.getPlayerProfileFlow()
    val allGames: Flow<List<GameEntity>> = dao.getAllGamesFlow()
    val allCollectibles: Flow<List<CollectibleItem>> = dao.getAllCollectiblesFlow()
    val allStudios: Flow<List<StudioAnalytics>> = dao.getAllStudiosFlow()
    val allBlogPosts: Flow<List<DevBlogPostEntity>> = dao.getAllBlogPostsFlow()
    val availableSkins: Flow<List<MarketplaceItem>> = dao.getAvailableMarketplaceItemsFlow()

    fun getStudioById(studioId: String): Flow<StudioAnalytics?> = dao.getStudioByIdFlow(studioId)
    fun getStudioBlogs(studioId: String): Flow<List<DevBlogPostEntity>> = dao.getBlogPostsForStudioFlow(studioId)

    // Seed initial data if tables are empty
    suspend fun seedInitialData() = withContext(Dispatchers.IO) {
        val currentProfile = dao.getPlayerProfileDirect()
        if (currentProfile == null) {
            // 1. Insert default player profile
            dao.updatePlayerProfile(
                PlayerProfile(
                    id = 1,
                    username = "NeonPredator_9",
                    level = 16,
                    xp = 3120,
                    totalXpNeeded = 6000,
                    credits = 1450,
                    tokenBalance = 650.0,
                    solBalance = 2.45,
                    guildName = "Aether_Riders_DAO",
                    reputationScore = 96,
                    gamesPlayedCount = 105,
                    rankTitle = "Holographic Enforcer"
                )
            )

            // 2. Insert living games showcase
            val defaultGames = listOf(
                GameEntity(
                    id = "racer",
                    title = "Cyber Racer 2099",
                    subtitle = "Neon Retro Grid Rider",
                    description = "Pilot your magnetic lightcycle across an accelerating electronic vector grid. Evade firewall gate controllers, intercept glowing data packets, and slide under grid sweeps. Play instantly to unlock unique vehicle customization parts!",
                    genre = "Arcade Evasion",
                    instantPlayable = true,
                    hasWeb3Features = true,
                    highScore = 450,
                    timesPlayed = 24,
                    minRequiredRamGbs = 4,
                    blockchainEnabled = false
                ),
                GameEntity(
                    id = "miner",
                    title = "Star Miner Web3",
                    subtitle = "Quantum Mining Exchange",
                    description = "A simulated deep-space fuel harvester. Click to extract Dark Matter, Helium-3, and Nexus crystals. Trade mineral commodities on a volatile off-chain automated order book, or stake tokens to upgrade drills automatically!",
                    genre = "Idle Clicker / Exchange",
                    instantPlayable = true,
                    hasWeb3Features = true,
                    highScore = 8900,
                    timesPlayed = 15,
                    minRequiredRamGbs = 2,
                    blockchainEnabled = true
                ),
                GameEntity(
                    id = "chess",
                    title = "Aether Battles",
                    subtitle = "Grid Tactical Duel Matrix",
                    description = "An immersive turn-based tactical card battle. Engage AI cores on a floating checkerboard field. Trigger energy walls, coordinate data-burst projectiles, and bypass security matrices step by step.",
                    genre = "Strategy / Tactics",
                    instantPlayable = true,
                    hasWeb3Features = false,
                    highScore = 1200,
                    timesPlayed = 42,
                    minRequiredRamGbs = 4,
                    blockchainEnabled = false
                )
            )
            dao.insertGames(defaultGames)

            // 3. Insert initial Collectibles
            val defaultCollectibles = listOf(
                CollectibleItem(
                    name = "Vaporwave Booster Core",
                    description = "Infuses exhaust particles with vibrant magenta and cyan pixel residues.",
                    rarity = "RARE",
                    mintedAsNft = false,
                    marketPriceNexus = 45.0,
                    gameOrigin = "Cyber Racer 2099"
                ),
                CollectibleItem(
                    name = "Solana Dark Diamond",
                    description = "Extremely concentrated energy core extracted from the asteroid belt.",
                    rarity = "LEGENDARY",
                    mintedAsNft = true,
                    nftContractAddress = "SolDrilL92Xkq83mWaS23x9YptM",
                    marketPriceNexus = 850.0,
                    gameOrigin = "Star Miner Web3"
                ),
                CollectibleItem(
                    name = "Opal Hologram Grid Theme",
                    description = "Envelops the tactical combat board with an iridescent opalescent shimmer.",
                    rarity = "HOLOGRAPHIC",
                    mintedAsNft = false,
                    marketPriceNexus = 120.0,
                    gameOrigin = "Aether Battles"
                )
            )
            for (item in defaultCollectibles) {
                dao.insertCollectible(item)
            }

            // 4. Insert Developer Studios Info
            val defaultStudios = listOf(
                StudioAnalytics(
                    studioId = "neon_dynamics",
                    studioName = "Neon Dynamics Studio",
                    followersCount = 4820,
                    publishedGamesCount = 2,
                    totalRevenueNexus = 142090.0,
                    totalPlaySeconds = 8495000L,
                    developerReputation = 4.9,
                    developerBio = "Pushing modern mobile-native WebGL and Jetpack Compose physics limits since 2092. Specializes in hyper-fast synthwave feedback, physics engines, and smooth feedback loops.",
                    currentFundraiserNexus = 7200.0,
                    fundraiserGoalNexus = 12000.0
                ),
                StudioAnalytics(
                    studioId = "aether_labs",
                    studioName = "Aether Blockchain Labs",
                    followersCount = 2150,
                    publishedGamesCount = 1,
                    totalRevenueNexus = 389050.0,
                    totalPlaySeconds = 1248000L,
                    developerReputation = 4.7,
                    developerBio = "Creating fully integrated web3 gaming pipelines. Pioneers in decentralized game state preservation, open-ledger game assets, and automated on-chain exchanges.",
                    currentFundraiserNexus = 25000.0,
                    fundraiserGoalNexus = 50000.0
                ),
                StudioAnalytics(
                    studioId = "cyberforge",
                    studioName = "CyberForge Interactive",
                    followersCount = 1140,
                    publishedGamesCount = 1,
                    totalRevenueNexus = 24500.0,
                    totalPlaySeconds = 612000L,
                    developerReputation = 4.5,
                    developerBio = "Indie collective dedicated to retro-inspired tactical gameplay and organic cyberpunk worlds. Built on community feedback and open-source contributions.",
                    currentFundraiserNexus = 1500.0,
                    fundraiserGoalNexus = 8000.0
                )
            )
            for (studio in defaultStudios) {
                dao.insertStudio(studio)
            }

            // 5. Insert Developer Blogs
            val defaultBlogs = listOf(
                DevBlogPostEntity(
                    studioId = "neon_dynamics",
                    title = "Behind the Scenes: Cyber Racer Particle Engine",
                    summary = "We successfully restructured our vector loop thread pools in Kotlin to render up to 1,000 active sub-ether spark nodes on low-powered Android chips without breaking standard UI threads. Check out our latest dev build!",
                    authorName = "Dev Commander Kira"
                ),
                DevBlogPostEntity(
                    studioId = "aether_labs",
                    title = "Liquidity Exchanges in Star Miner",
                    summary = "Decentralized automated micro-exchanges allow Star Miner players to trade Dark Matter for Nexus tokens in near real-time. We've added mock smart contract locks for off-line security verification.",
                    authorName = "Lead Researcher Vance"
                ),
                DevBlogPostEntity(
                    studioId = "cyberforge",
                    title = "Designing Holographic Interfaces",
                    summary = "How we used Custom Compose Canvas shaders to design organic glass boundaries and dynamic grids that shift gradients under hover grids. Next up: tactile sensory vibration patterns.",
                    authorName = "UX Weaver Mara"
                )
            )
            for (blog in defaultBlogs) {
                dao.insertBlogPost(blog)
            }

            // 6. Insert Creator Marketplace Skins / Mods
            val defaultMarketplace = listOf(
                MarketplaceItem(
                    name = "Vaporwave Neon Core Paint",
                    description = "A customized lightcycle body skin that cycles between glowing pink and azure gradient ripples.",
                    priceNexus = 24.5,
                    rarity = "RARE",
                    category = "Skins",
                    sellerName = "CyberWeaver_99",
                    gameTitle = "Cyber Racer 2099"
                ),
                MarketplaceItem(
                    name = "Quantum Asteroid Drill Head v4",
                    description = "An ultra-durable diamond drill mod increasing click extraction efficiency by 150%.",
                    priceNexus = 135.0,
                    rarity = "LEGENDARY",
                    category = "Mods",
                    sellerName = "CosmicMinerX",
                    gameTitle = "Star Miner Web3"
                ),
                MarketplaceItem(
                    name = "Retro Arcade Grid Backdrop",
                    description = "Imposes a nostalgic grid field background complete with glowing cyber-mountains on the vector playfield.",
                    priceNexus = 45.0,
                    rarity = "HOLOGRAPHIC",
                    category = "Maps",
                    sellerName = "SynthLord",
                    gameTitle = "Cyber Racer 2099"
                ),
                MarketplaceItem(
                    name = "Glitch Overlord Avatar Mod",
                    description = "Overrides default tactical chess models with corrupted, glitch-shifting neon holograms.",
                    priceNexus = 65.0,
                    rarity = "LEGENDARY",
                    category = "Characters",
                    sellerName = "Vance_Labs",
                    gameTitle = "Aether Battles"
                )
            )
            dao.insertMarketplaceItems(defaultMarketplace)
        }
    }

    // Interactive gameplay transactions
    suspend fun recordGamePlayResult(gameId: String, score: Int) = withContext(Dispatchers.IO) {
        dao.updateGamePlayStats(gameId, score)
        
        // Award XP and coins to player
        val profile = dao.getPlayerProfileDirect() ?: return@withContext
        val xpGain = score / 5
        val creditsGain = score / 10
        val tokenGain = if (gameId == "miner") (score / 100.0) else 0.0

        val newXp = profile.xp + xpGain
        val xpNeeded = profile.totalXpNeeded
        val leveledUp = newXp >= xpNeeded
        
        val newLevel = if (leveledUp) profile.level + 1 else profile.level
        val finalXp = if (leveledUp) newXp - xpNeeded else newXp
        val finalXpNeeded = if (leveledUp) (xpNeeded * 1.25).toInt() else xpNeeded

        val updatedProfile = profile.copy(
            level = newLevel,
            xp = finalXp,
            totalXpNeeded = finalXpNeeded,
            credits = profile.credits + creditsGain,
            tokenBalance = profile.tokenBalance + tokenGain,
            gamesPlayedCount = profile.gamesPlayedCount + 1
        )
        dao.updatePlayerProfile(updatedProfile)

        // Award a rare item collectible if they score well!
        if (score > 150) {
            val randomNum = (1..100).random()
            val (name, rarity) = when {
                randomNum > 85 -> Pair("Cosmic Engine Injector", "LEGENDARY")
                randomNum > 50 -> Pair("Vector Fuel Filter", "RARE")
                else -> Pair("Cyber Chassis Fragment", "COMMON")
            }
            dao.insertCollectible(
                CollectibleItem(
                    name = name,
                    description = "A valuable drop item gained isomorphically from achieving ${score} points.",
                    rarity = rarity,
                    mintedAsNft = false,
                    gameOrigin = if (gameId == "racer") "Cyber Racer 2099" else "Star Miner Web3"
                )
            )
        }
    }

    suspend fun mintCollectibleAsNft(itemId: Int) = withContext(Dispatchers.IO) {
        val randomHash = "SolNFT" + (100000..999999).random().toString() + "xNExUs"
        dao.mintItemAsNft(itemId, randomHash)
        
        // Deduct minting cost of 10.0 Nexus tokens from profile
        val profile = dao.getPlayerProfileDirect()
        if (profile != null && profile.tokenBalance >= 10.0) {
            dao.updatePlayerProfile(profile.copy(tokenBalance = profile.tokenBalance - 10.0))
        }
    }

    suspend fun buyMarketplaceSkin(itemId: Int, priceNexus: Double, skinName: String, gameOrigin: String, rarity: String) = withContext(Dispatchers.IO) {
        // Mark as sold in database
        dao.setMarketplaceItemSold(itemId)

        // Deduct custom funds
        val profile = dao.getPlayerProfileDirect()
        if (profile != null && profile.tokenBalance >= priceNexus) {
            dao.updatePlayerProfile(profile.copy(tokenBalance = profile.tokenBalance - priceNexus))
            
            // Add purchased item directly to collectibles list as owned skin!
            dao.insertCollectible(
                CollectibleItem(
                    name = skinName,
                    description = "Developer custom skin bought from standard creators marketplace ecosystem.",
                    rarity = rarity,
                    mintedAsNft = false,
                    gameOrigin = gameOrigin
                )
            )
        }
    }

    suspend fun publishNewMod(name: String, desc: String, price: Double, rarity: String, category: String, gameTitle: String) = withContext(Dispatchers.IO) {
        val newItem = MarketplaceItem(
            name = name,
            description = desc,
            priceNexus = price,
            rarity = rarity,
            category = category,
            sellerName = "You (Creator)",
            gameTitle = gameTitle,
            isSold = false
        )
        dao.insertMarketplaceItems(listOf(newItem))
    }

    suspend fun donateToStudioFundraiser(studioId: String, amount: Double) = withContext(Dispatchers.IO) {
        val profile = dao.getPlayerProfileDirect()
        if (profile != null && profile.tokenBalance >= amount) {
            // Deduct from profile
            dao.updatePlayerProfile(profile.copy(tokenBalance = profile.tokenBalance - amount))
            
            // Update studio details in Room db
            dao.addStudioRevenue(studioId, amount)
            
            // Increment studio fundraiser total
            val updatedStudios = dao.getAllStudiosFlow().firstOrNull() ?: return@withContext
            val targetStudio = updatedStudios.find { it.studioId == studioId } ?: return@withContext
            dao.insertStudio(
                targetStudio.copy(
                    currentFundraiserNexus = targetStudio.currentFundraiserNexus + amount
                )
            )
        }
    }

    suspend fun followStudio(studioId: String) = withContext(Dispatchers.IO) {
        dao.incrementStudioFollowers(studioId)
    }
}
