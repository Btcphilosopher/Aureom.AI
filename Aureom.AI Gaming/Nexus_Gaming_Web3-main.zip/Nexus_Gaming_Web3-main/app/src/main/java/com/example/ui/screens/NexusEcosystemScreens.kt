package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

// ==========================================
// CENTRAL SCREEN SELECTOR / ROUTER
// ==========================================
@Composable
fun NexusMainNavigator(viewModel: NexusViewModel, modifier: Modifier = Modifier) {
    val playerProfile by viewModel.playerProfile.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(CyberBackground, Color(0xFF03010B), Color(0xFF0C0617))
                )
            )
            .drawBehind {
                // Frosted Glass Portal Glow radial gradient in the viewport center
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NeonAqua.copy(alpha = 0.18f), Color.Transparent),
                        center = center,
                        radius = size.maxDimension * 0.48f
                    ),
                    center = center,
                    radius = size.maxDimension * 0.48f
                )
            }
    ) {
        // Aesthetic Star Field background floating across the whole application
        InteractiveStarField(particles = viewModel.particleList)

        Column(modifier = Modifier.fillMaxSize()) {
            // Elegant Header bar
            NexusPlatformHeader(playerProfile = playerProfile, activeTab = viewModel.activeTab) {
                viewModel.activeTab = "wallet"
            }

            // Screen content switcher
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (viewModel.activeTab) {
                    "home" -> EcosystemHomeTab(viewModel)
                    "arcade" -> ArcadeGameplayTab(viewModel)
                    "wallet" -> EcosystemProfileTab(viewModel)
                    "developer" -> DeveloperConsoleTab(viewModel)
                }
            }

            // Beautiful Glow-bar bottom navigation
            NexusBottomNavigationBar(
                activeTab = viewModel.activeTab,
                onTabSelect = { viewModel.activeTab = it }
            )
        }
    }
}

// ==========================================
// 1. PARTICLES VISUAL MATRIX
// ==========================================
@Composable
fun InteractiveStarField(particles: List<StarParticle>) {
    var tick by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(16)
            tick++
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        particles.forEach { particle ->
            val screenX = particle.x * size.width
            val screenY = ((particle.y + (tick * 0.0003f * particle.speed * 8f)) % 1.0f) * size.height
            
            drawCircle(
                color = NeonAqua.copy(alpha = 0.35f),
                radius = 3.5f,
                center = Offset(screenX, screenY)
            )
        }
    }
}

// ==========================================
// UI WIDGET: PLATFORM HEADER
// ==========================================
@Composable
fun NexusPlatformHeader(
    playerProfile: PlayerProfile?,
    activeTab: String,
    onProfileClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(SuccessGreen, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "NEXUS WEB3 CORE",
                    color = NeonAqua,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            }
            Text(
                text = when (activeTab) {
                    "home" -> "LIVING PLATFORM"
                    "arcade" -> "ARCADE MATRIX"
                    "wallet" -> "CRYPTO WALLET"
                    "developer" -> "MOD-STUDIO"
                    else -> "ECOSYSTEM"
                },
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
        }

        // Clickable Player status pill
        Row(
            modifier = Modifier
                .testTag("header_profile_pill")
                .background(CyberGlassBackground, RoundedCornerShape(12.dp))
                .border(1.dp, TranslucentBorder, RoundedCornerShape(12.dp))
                .clickable { onProfileClick() }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 8.dp)) {
                Text(
                    text = playerProfile?.username ?: "Connecting...",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "LVL ${playerProfile?.level ?: 1} | ${playerProfile?.tokenBalance ?: 0.0} NEXUS",
                    color = NeonOrange,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(NeonPink, CircleShape)
                    .border(1.dp, NeonAqua, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = "User",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ==========================================
// 2. ECOSYSTEM HOME TAB (LIVING SHOWCASE)
// ==========================================
@Composable
fun EcosystemHomeTab(viewModel: NexusViewModel) {
    val games by viewModel.allGames.collectAsState()
    val blogPosts by viewModel.allBlogPosts.collectAsState()
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Immersive Platform Banner
        item {
            EcosystemHeroBanner(
                onInstantPlay = {
                    viewModel.selectedGameId = "racer"
                    viewModel.activeTab = "arcade"
                    viewModel.startCyberRacer()
                }
            )
        }

        // Headline section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVING SHOWCASE (ACTIVE PREVIEWS)",
                    color = NeonAqua,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "SWIPE OR SELECT FOR DEMO",
                    color = MatteGrey,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Living Game Cards
        items(games) { game ->
            LivingGameShowcaseItem(
                game = game,
                isSelected = viewModel.selectedGameId == game.id,
                onSelect = { viewModel.selectedGameId = game.id },
                onLaunch = {
                    viewModel.selectedGameId = game.id
                    viewModel.activeTab = "arcade"
                    if (game.id == "racer") {
                        viewModel.startCyberRacer()
                    }
                }
            )
        }

        // Live developer posts bulletin
        item {
            Text(
                text = "COMMUNITY DEV LOGS",
                color = NeonPink,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        items(blogPosts.take(2)) { blog ->
            DevBlogPostWidget(blog = blog, onReadMore = {
                viewModel.selectedStudioId = blog.studioId
                viewModel.activeTab = "developer"
            })
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun EcosystemHeroBanner(onInstantPlay: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(230.dp)
            .background(CyberSurface, RoundedCornerShape(32.dp))
            .border(1.dp, TranslucentBorder, RoundedCornerShape(32.dp))
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF1E0D42), Color(0xFF090622), Color(0xFF050212))
                    )
                )
        ) {
            // Underlay gradient to shade content text at the bottom
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0x4D000000), Color(0xCC050212))
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge row inside banner
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(NeonAqua.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .border(1.dp, NeonAqua.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "LIVE PORTAL",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = NeonAqua
                        )
                    }

                    Text(
                        text = "3,241 Rifting Now",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Middle/bottom game name & CTA row
                Column {
                    Text(
                        text = "NEON RIFT",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        letterSpacing = (-0.5).sp
                    )

                    Text(
                        text = "The boundary between reality and digital chaos has collapsed. Enter the Void.",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onInstantPlay() },
                            modifier = Modifier.weight(1f).height(40.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "INSTANT PLAY",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }

                        Button(
                            onClick = { onInstantPlay() },
                            modifier = Modifier.size(40.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberSurfaceVariant,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, TranslucentBorder),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AddCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LivingGameShowcaseItem(
    game: GameEntity,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onLaunch: () -> Unit
) {
    val scale by animateFloatAsState(targetValue = if (isSelected) 1.02f else 1.0f)
    val borderWidth by animateDpAsState(targetValue = if (isSelected) 2.dp else 1.dp)
    val borderColor by animateColorAsState(targetValue = if (isSelected) NeonPink else TranslucentBorder)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .background(
                if (isSelected) CyberSurfaceVariant else CyberSurface,
                RoundedCornerShape(24.dp)
            )
            .border(borderWidth, borderColor, RoundedCornerShape(24.dp))
            .clickable { onSelect() }
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Game Hologram Circle Avatar with deep background
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            Brush.sweepGradient(listOf(NeonPink, NeonAqua, GlowPurple)),
                            CircleShape
                        )
                        .padding(2.dp)
                        .clip(CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0F0A24), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (game.id) {
                                "racer" -> Icons.Filled.DirectionsRun
                                "miner" -> Icons.Filled.Terrain
                                else -> Icons.Filled.GridView
                            },
                            contentDescription = null,
                            tint = if (isSelected) NeonPink else NeonAqua,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = game.title,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = game.subtitle,
                        color = MatteGrey,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Status chip
                Box(
                    modifier = Modifier
                        .background(
                            if (game.instantPlayable) SuccessGreen.copy(alpha = 0.15f) else MatteGrey.copy(alpha = 0.15f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (game.instantPlayable) "INSTANT" else "CLOSED",
                        color = if (game.instantPlayable) SuccessGreen else MatteGrey,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Expanded interactive features (Characters walking across, trailers, details, specs!)
            if (isSelected) {
                Spacer(modifier = Modifier.height(12.dp))
                
                Divider(color = TranslucentBorder.copy(alpha = 0.3f))
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = game.description,
                    color = DarkOnSurface.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Living metrics elements (Holographic meters)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SpecPill(label = "GENRE", value = game.genre)
                    SpecPill(label = "MEM", value = "${game.minRequiredRamGbs}GB RAM")
                    SpecPill(
                        label = "WEB3 ENABLED", 
                        value = if (game.hasWeb3Features) "YES (OPT)" else "NO"
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Stars, contentDescription = null, tint = NeonOrange, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "HIGH SCORE: ${game.highScore}",
                            fontSize = 11.sp,
                            color = NeonOrange,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Played ${game.timesPlayed} times",
                            fontSize = 11.sp,
                            color = MatteGrey
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Launch Engine
                Button(
                    onClick = { onLaunch() },
                    modifier = Modifier
                        .testTag("launch_game_${game.id}")
                        .fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LAUNCH IMMERSIVE DECK",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SpecPill(label: String, value: String) {
    Column {
        Text(text = label, color = MatteGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = NeonAqua, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun DevBlogPostWidget(blog: DevBlogPostEntity, onReadMore: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onReadMore() },
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, TranslucentBorder),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(GlowPurple, CircleShape)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = blog.authorName, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "5 hrs ago",
                    fontSize = 9.sp,
                    color = MatteGrey,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = blog.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = blog.summary,
                color = DarkOnSurface.copy(alpha = 0.8f),
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ==========================================
// 3. ARCADE MATRIX: TWO PLAYABLE GAMES
// ==========================================
@Composable
fun ArcadeGameplayTab(viewModel: NexusViewModel) {
    var activeArcadeMode by remember { mutableStateOf("racer") } // "racer", "miner"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Multi-option Toggle Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .background(CyberSurfaceVariant.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .border(1.dp, TranslucentBorder.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { activeArcadeMode = "racer" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeArcadeMode == "racer") NeonPink else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .padding(4.dp)
            ) {
                Icon(Icons.Filled.DirectionsCar, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("CYBER RACER 2099", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { activeArcadeMode = "miner" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeArcadeMode == "miner") NeonPink else Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .padding(4.dp)
            ) {
                Icon(Icons.Filled.Terrain, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("STAR MINER WEB3", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Display current game implementation
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (activeArcadeMode == "racer") {
                PlayableCyberRacer(viewModel)
            } else {
                PlayableStarMiner(viewModel)
            }
        }
    }
}

// GAME CORE A: PLAYABLE VIRTUAL RACER ENDLESS CANVAS
@Composable
fun PlayableCyberRacer(viewModel: NexusViewModel) {
    val racerScore = viewModel.racerScore
    val playerX = viewModel.playerX
    val obstacles = viewModel.obstacleList
    val racerState = viewModel.racerState

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF06030F), RoundedCornerShape(16.dp))
            .border(2.dp, NeonAqua, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
    ) {
        if (racerState == "PLAYING") {
            // THE GAMEPLAY FIELD DRAW
            Canvas(modifier = Modifier.fillMaxSize()) {
                val gridWidth = size.width
                val gridHeight = size.height

                // Draw Cyber Perspective Lines
                val perspectiveLineSweep = 8
                for (i in 0..perspectiveLineSweep) {
                    val lineXStart = (i.toFloat() / perspectiveLineSweep) * gridWidth
                    drawLine(
                        color = GlowPurple.copy(alpha = 0.3f),
                        start = Offset(lineXStart, 0f),
                        end = Offset((i.toFloat() / perspectiveLineSweep) * gridWidth, gridHeight),
                        strokeWidth = 2f
                    )
                }

                // Horizontal speed divisions
                val horizCount = 5
                for (i in 1..horizCount) {
                    val progressY = (i.toFloat() / horizCount) * gridHeight
                    drawLine(
                        color = GlowPurple.copy(alpha = 0.25f),
                        start = Offset(0f, progressY),
                        end = Offset(gridWidth, progressY),
                        strokeWidth = 1.5f
                    )
                }

                // Draw items / obstacles
                obstacles.forEach { obs ->
                    val obsX = obs.x * gridWidth
                    val obsY = obs.y * gridHeight
                    
                    if (obs.type == ObstacleType.BARRIER) {
                        // Cyber gate
                        drawRect(
                            color = CriticalRed,
                            topLeft = Offset(obsX - 30f, obsY - 15f),
                            size = androidx.compose.ui.geometry.Size(60f, 30f)
                        )
                        drawRect(
                            color = NeonPink,
                            topLeft = Offset(obsX - 25f, obsY - 10f),
                            size = androidx.compose.ui.geometry.Size(50f, 20f),
                            style = Stroke(width = 3f)
                        )
                    } else {
                        // SUB-ETHER coin chip
                        drawCircle(
                            color = NeonAqua,
                            radius = 16f,
                            center = Offset(obsX, obsY)
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 8f,
                            center = Offset(obsX, obsY)
                        )
                    }
                }

                // Draw Player Lightcycle
                val riderX = playerX * gridWidth
                val riderY = 0.9f * gridHeight
                
                // Trail particle glow
                drawRect(
                    color = NeonPink.copy(alpha = 0.4f),
                    topLeft = Offset(riderX - 8f, riderY),
                    size = androidx.compose.ui.geometry.Size(16f, gridHeight - riderY)
                )

                // Bike chassis
                drawRoundRect(
                    color = NeonAqua,
                    topLeft = Offset(riderX - 16f, riderY - 24f),
                    size = androidx.compose.ui.geometry.Size(32f, 48f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )

                // Neon Wheel core
                drawRect(
                    color = Color.White,
                    topLeft = Offset(riderX - 6f, riderY - 18f),
                    size = androidx.compose.ui.geometry.Size(12f, 36f)
                )
            }

            // High Tech Stats overlays
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .background(CyberGlassBackground, RoundedCornerShape(8.dp))
                            .border(1.dp, NeonAqua, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "SCORE: $racerScore",
                            color = NeonAqua,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(CyberGlassBackground, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "FPS: 60",
                            color = SuccessGreen,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Touch steer triggers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = { viewModel.moveRacerLeft() },
                    modifier = Modifier
                        .testTag("racer_steer_left")
                        .size(64.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant.copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, NeonAqua)
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Steer Left", tint = NeonAqua)
                }

                Button(
                    onClick = { viewModel.moveRacerRight() },
                    modifier = Modifier
                        .testTag("racer_steer_right")
                        .size(64.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant.copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, NeonAqua)
                ) {
                    Icon(Icons.Filled.ArrowForward, contentDescription = "Steer Right", tint = NeonAqua)
                }
            }
        } else {
            // IDLE OR OVER OVERLAYS
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.DirectionsCar,
                    contentDescription = null,
                    tint = NeonPink,
                    modifier = Modifier.size(64.dp)
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = if (racerState == "GAMEOVER") "GRID COLLISION" else "CYBER RACER 2099",
                    color = if (racerState == "GAMEOVER") CriticalRed else Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                Text(
                    text = if (racerState == "GAMEOVER") "Grid walls terminated your lightcycle. Score synced to local db!" 
                           else "Steer your localized lightcycle through cybersecurity virus walls.",
                    color = MatteGrey,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                if (racerState == "GAMEOVER") {
                    Box(
                        modifier = Modifier
                            .padding(vertical = 12.dp)
                            .background(CyberGlassBackground, RoundedCornerShape(8.dp))
                            .border(1.dp, NeonOrange, RoundedCornerShape(8.dp))
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "FINAL SCORE: $racerScore pts",
                            color = NeonOrange,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.startCyberRacer() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("racer_start_button")
                ) {
                    Icon(Icons.Filled.Bolt, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (racerState == "GAMEOVER") "RETRY VECTOR" else "LAUNCH CORE DRIVER",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// GAME CORE B: STAR MINER WEB3 DECENTRALIZED CLICKER
@Composable
fun PlayableStarMiner(viewModel: NexusViewModel) {
    val h3Count = viewModel.minerOreHelium3
    val dmCount = viewModel.minerOreDarkMatter
    val drillCount = viewModel.minerDrillCount
    val drillPrice = viewModel.drillPriceNexus

    var asteroidAngle by remember { mutableStateOf(0f) }
    var buttonScale by remember { mutableStateOf(1f) }

    LaunchedEffect(h3Count) {
        // Animate angle on click
        asteroidAngle += 28f
        buttonScale = 0.95f
        delay(60)
        buttonScale = 1.05f
        delay(60)
        buttonScale = 1f
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF05030B), RoundedCornerShape(16.dp))
            .border(2.dp, NeonPink, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Clickable spin-meter banner
        item {
            Text(
                text = "QUANTUM REFINERY LABS",
                color = NeonPink,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Text(
                text = "Tap block asteroid to quarry crystals offline",
                color = MatteGrey,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }

        // Draggable clicking asteroid element (Drawn via custom canvas representation with infinite rotating loop!)
        item {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .clickable { viewModel.mineAsteroidClick() },
                contentAlignment = Alignment.Center
            ) {
                // Background radial cyber pulse
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(NeonPink.copy(alpha = 0.15f), Color.Transparent)
                                ),
                                radius = size.width / 2
                            )
                        }
                )

                // Drawing Asteroid Custom Canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxSize(0.7f)
                ) {
                    val w = size.width
                    val h = size.height
                    
                    // Rotate and draw standard polygon
                    drawCircle(
                        color = Color(0xFF322849),
                        radius = w / 2,
                        center = Offset(w / 2, h / 2)
                    )
                    
                    // Draw glowing cyber-ore lines inside asteroid
                    drawLine(
                        color = NeonPink,
                        start = Offset(w * 0.2f, h * 0.3f),
                        end = Offset(w * 0.8f, h * 0.4f),
                        strokeWidth = 4f
                    )
                    
                    drawLine(
                        color = NeonAqua,
                        start = Offset(w * 0.3f, h * 0.7f),
                        end = Offset(w * 0.7f, h * 0.8f),
                        strokeWidth = 3f
                    )

                    drawCircle(
                        color = NeonPink,
                        radius = 8f,
                        center = Offset(w * 0.5f, h * 0.4f)
                    )
                }

                Text(
                    text = "MINE",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 16.sp
                )
            }
        }

        // Current raw resources counter
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MineralCounterCard(
                    title = "Helium-3 Gas",
                    amount = String.format("%.1f", h3Count),
                    price = "$${viewModel.priceHelium3} NEX",
                    modifier = Modifier.weight(1f)
                )

                MineralCounterCard(
                    title = "Dark Matter",
                    amount = String.format("%.2f", dmCount),
                    price = "$${viewModel.priceDarkMatter} NEX",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Decentralized Exchange AMM / Drills logic
        item {
            Box(
                modifier = Modifier
                    .fillParentMaxWidth()
                    .background(CyberGlassBackground, RoundedCornerShape(20.dp))
                    .border(1.dp, TranslucentBorder, RoundedCornerShape(20.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "QUANTUM AUTO-DRILLS",
                                fontSize = 11.sp,
                                color = NeonAqua,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "Acquired: $drillCount drills (Harvesting 24/7)",
                                fontSize = 10.sp,
                                color = MatteGrey
                            )
                        }

                        Button(
                            onClick = { viewModel.upgradeDrill() },
                            colors = ButtonDefaults.buttonColors(containerColor = GlowPurple),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Buy [$drillPrice NEX]",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Divider(color = TranslucentBorder.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "AMM DECENTRALIZED EXCHANGE",
                                fontSize = 11.sp,
                                color = NeonOrange,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "Sell materials instantly for NEXUS coins",
                                fontSize = 10.sp,
                                color = MatteGrey
                            )
                        }

                        Button(
                            onClick = { viewModel.sellAllCommodities() },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SELL ALL",
                                fontSize = 10.sp,
                                color = Color.Black,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MineralCounterCard(title: String, amount: String, price: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(CyberSurface, RoundedCornerShape(18.dp))
            .border(1.dp, TranslucentBorder, RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(text = title, color = MatteGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text(text = amount, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            Box(
                modifier = Modifier
                    .padding(top = 4.dp)
                    .background(NeonAqua.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(text = "Price: $price", color = NeonAqua, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

// ==========================================
// 4. PERSISTENT PLAYER PROFILE & WALLET (WEB3)
// ==========================================
@Composable
fun EcosystemProfileTab(viewModel: NexusViewModel) {
    val profile by viewModel.playerProfile.collectAsState()
    val collectibles by viewModel.allCollectibles.collectAsState()
    val marketSkins by viewModel.availableSkins.collectAsState()

    var showMintConfirmDialogForId by remember { mutableStateOf<CollectibleItem?>(null) }
    var activeSubProfileTab by remember { mutableStateOf("inventory") } // "inventory", "market"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Player ID Card
        item {
            profile?.let { PlayerIdCard(profile = it) }
        }

        // Multichain Wallet Balances
        item {
            profile?.let { BalancesWalletGrid(profile = it) }
        }

        // Sub Tab selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { activeSubProfileTab = "inventory" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeSubProfileTab == "inventory") NeonPink else CyberSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("MY PERSISTENT INVENTORY", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { activeSubProfileTab = "market" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeSubProfileTab == "market") NeonPink else CyberSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("CREATOR SKIN SHOP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Inventory assets
        if (activeSubProfileTab == "inventory") {
            if (collectibles.isEmpty()) {
                item {
                    Text(
                        text = "No collectibles acquired yet. Play Cyber Racer in the Arcade to earn loot items!",
                        color = MatteGrey,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(24.dp)
                    )
                }
            } else {
                items(collectibles) { item ->
                    InventoryItemRow(
                        item = item,
                        onMintRequested = {
                            showMintConfirmDialogForId = item
                        }
                    )
                }
            }
        } else {
            // Marketplace store
            if (marketSkins.isEmpty()) {
                item {
                    Text(
                        text = "Everything sold out! Create your own mod in the developer studio to publish skins.",
                        color = MatteGrey,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(24.dp)
                    )
                }
            } else {
                items(marketSkins) { skin ->
                    MarketplaceSkinRow(
                        item = skin,
                        onBuyRequested = {
                            viewModel.purchaseSkinFromMarket(
                                skinId = skin.id,
                                priceNexus = skin.priceNexus,
                                skinName = skin.name,
                                gameOrigin = skin.gameTitle,
                                rarity = skin.rarity
                            )
                        },
                        canAfford = (profile?.tokenBalance ?: 0.0) >= skin.priceNexus
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // NFT Mint confirm Sheet Overlay (Compose dialogue widget)
    showMintConfirmDialogForId?.let { item ->
        AlertDialog(
            onDismissRequest = { showMintConfirmDialogForId = null },
            containerColor = CyberSurface,
            textContentColor = Color.White,
            title = {
                Text(
                    text = "MINT CONTRACT DEPLOYMENT",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = NeonOrange
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "You are deploying a decentralized blockchain contract for your item \"${item.name}\". This transfers metadata off-chain.",
                        fontSize = 11.sp,
                        color = DarkOnSurface
                    )
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("CONTRACT TAX: 10.0 NEXUS", fontSize = 10.sp, color = NeonPink, fontFamily = FontFamily.Monospace)
                            Text("STANDARD: ${item.tokenStandard}", fontSize = 10.sp, color = NeonAqua, fontFamily = FontFamily.Monospace)
                            Text("ORIGIN: ${item.gameOrigin}", fontSize = 10.sp, color = MatteGrey, fontFamily = FontFamily.Monospace)
                        }
                    }

                    if (viewModel.mintingItemId == item.id) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(color = NeonPink, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Mining block and deploying hash...", fontSize = 11.sp, color = NeonPink)
                        }
                    }

                    viewModel.mintingSuccessMessage?.let {
                        Text(
                            text = it,
                            fontSize = 11.sp,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                if (viewModel.mintingItemId != item.id) {
                    Button(
                        onClick = {
                            viewModel.mintNFT(item.id)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                    ) {
                        Text("SIGN & MINT", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            },
            dismissButton = {
                if (viewModel.mintingItemId == null) {
                    Button(
                        onClick = { showMintConfirmDialogForId = null },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                    ) {
                        Text("CANCEL", color = MatteGrey)
                    }
                }
            }
        )
    }
}

@Composable
fun PlayerIdCard(profile: PlayerProfile) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    colors = listOf(CyberSurface, CyberSurfaceVariant)
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .border(1.dp, TranslucentBorder, RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = profile.username.uppercase(),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = profile.rankTitle,
                        color = NeonOrange,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Box(
                    modifier = Modifier
                        .background(SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .border(1.dp, SuccessGreen, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "REP: +${profile.reputationScore}",
                        color = SuccessGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Guild Name
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Group, contentDescription = null, tint = MatteGrey, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ACTIVE GUILD: ${profile.guildName}",
                    color = DarkOnSurface.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // XP Progression Line
            val xpPercentage = profile.xp.toFloat() / profile.totalXpNeeded.toFloat()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "LEVEL EXP", color = MatteGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "${profile.xp}/${profile.totalXpNeeded} XP", color = NeonAqua, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = xpPercentage,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = NeonPink,
                trackColor = Color(0xFF1E1335)
            )
        }
    }
}

@Composable
fun BalancesWalletGrid(profile: PlayerProfile) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        WalletBalanceTile(
            label = "NEXUS COINS",
            amount = "${profile.tokenBalance}",
            symbol = "NEX",
            color = NeonPink,
            modifier = Modifier.weight(1f)
        )

        WalletBalanceTile(
            label = "SOL (METAPLEX)",
            amount = "${profile.solBalance}",
            symbol = "SOL",
            color = NeonAqua,
            modifier = Modifier.weight(1f)
        )

        WalletBalanceTile(
            label = "ARCADE GOLD",
            amount = "${profile.credits}",
            symbol = "GOLD",
            color = NeonOrange,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun WalletBalanceTile(label: String, amount: String, symbol: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(CyberSurface, RoundedCornerShape(18.dp))
            .border(1.dp, TranslucentBorder, RoundedCornerShape(18.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(text = label, color = MatteGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text(text = amount, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            Text(text = symbol, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun InventoryItemRow(item: CollectibleItem, onMintRequested: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberSurface, RoundedCornerShape(20.dp))
            .border(
                1.dp,
                if (item.mintedAsNft) SuccessGreen else TranslucentBorder,
                RoundedCornerShape(20.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (item.mintedAsNft) Icons.Filled.Verified else Icons.Filled.Circle,
                contentDescription = null,
                tint = if (item.mintedAsNft) SuccessGreen else NeonPink,
                modifier = Modifier.size(16.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = item.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = item.description, color = MatteGrey, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Box(
                        modifier = Modifier
                            .background(GlowPurple.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(text = item.rarity, color = GlowPurple, fontSize = 7.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Origin: ${item.gameOrigin}", color = MatteGrey, fontSize = 8.sp)
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (item.mintedAsNft) {
                Column(horizontalAlignment = Alignment.End) {
                    Box(
                        modifier = Modifier
                            .background(SuccessGreen.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("MINTED NFT", color = SuccessGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Text(
                        text = item.nftContractAddress.take(8) + "...",
                        fontSize = 8.sp,
                        color = MatteGrey,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Button(
                    onClick = { onMintRequested() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonOrange),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("MINT TO NFT", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun MarketplaceSkinRow(item: MarketplaceItem, onBuyRequested: () -> Unit, canAfford: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberSurface, RoundedCornerShape(20.dp))
            .border(1.dp, TranslucentBorder, RoundedCornerShape(20.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(NeonPink.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.ShoppingBag, contentDescription = null, tint = NeonPink, modifier = Modifier.size(16.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = item.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = item.description, color = MatteGrey, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Box(
                        modifier = Modifier
                            .background(NeonPink.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = item.category.uppercase(), color = NeonPink, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "By ${item.sellerName}", color = MatteGrey, fontSize = 8.sp)
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = { onBuyRequested() },
                enabled = canAfford,
                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${item.priceNexus} NEX",
                    fontSize = 11.sp,
                    color = Color.Black,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// ==========================================
// 5. DEVELOPER STUDIO CONSOLE & CREATOR LABS
// ==========================================
@Composable
fun DeveloperConsoleTab(viewModel: NexusViewModel) {
    val studios by viewModel.allStudios.collectAsState()
    val blogs by viewModel.allBlogPosts.collectAsState()
    val playerProfile by viewModel.playerProfile.collectAsState()

    var activeDevStudioId by remember { mutableStateOf("neon_dynamics") }
    val currentStudio = studios.find { it.studioId == activeDevStudioId }

    // State parameters for Custom Mod publish form
    var customModName by remember { mutableStateOf("") }
    var customModCategory by remember { mutableStateOf("Skins") }
    var customModPrice by remember { mutableStateOf("15.0") }
    var customModDesc by remember { mutableStateOf("") }
    var publishMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Toggle Studio profiles row
        item {
            Text(
                "SELECT PUBLISHING HOUSE",
                color = NeonAqua,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(studios) { stud ->
                    Box(
                        modifier = Modifier
                            .background(
                                if (activeDevStudioId == stud.studioId) NeonPink else CyberSurface,
                                RoundedCornerShape(8.dp)
                            )
                            .border(1.dp, TranslucentBorder, RoundedCornerShape(8.dp))
                            .clickable { activeDevStudioId = stud.studioId }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = stud.studioName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Active Studio Page
        currentStudio?.let { studio ->
            item {
                StudioProfileCard(
                    studio = studio,
                    onFollowRequested = {
                        viewModel.followStudioAction(studio.studioId)
                    },
                    onPoolRequested = { amount ->
                        viewModel.poolFundraiser(studio.studioId, amount)
                    },
                    userBalance = playerProfile?.tokenBalance ?: 0.0
                )
            }
        }

        // Creator Economy Publish Console
        item {
            Divider(color = TranslucentBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 12.dp))
            Text(
                text = "CREATOR PUBLISH PANEL",
                color = NeonOrange,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Build mods or textures, publish and receive NEXUS on sales.",
                color = MatteGrey,
                fontSize = 10.sp
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillParentMaxWidth()
                    .background(CyberSurface, RoundedCornerShape(20.dp))
                    .border(1.dp, TranslucentBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextField(
                        value = customModName,
                        onValueChange = { customModName = it },
                        label = { Text("Asset Name", color = MatteGrey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextField(
                            value = customModCategory,
                            onValueChange = { customModCategory = it },
                            label = { Text("Category (e.g. Skins, Mods)", color = MatteGrey) },
                            modifier = Modifier.weight(1f),
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )

                        TextField(
                            value = customModPrice,
                            onValueChange = { customModPrice = it },
                            label = { Text("Price (NEX)", color = MatteGrey) },
                            modifier = Modifier.weight(1f),
                            colors = TextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )
                    }

                    TextField(
                        value = customModDesc,
                        onValueChange = { customModDesc = it },
                        label = { Text("Asset Description", color = MatteGrey) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )

                    Button(
                        onClick = {
                            if (customModName.isNotEmpty()) {
                                viewModel.publishCustomCreatorSkin(
                                    name = customModName,
                                    desc = customModDesc,
                                    price = customModPrice.toDoubleOrNull() ?: 10.0,
                                    rarity = "RARE",
                                    category = customModCategory,
                                    gameOrigin = "Cyber Racer 2099"
                                )
                                publishMessage = "Success! Custom model uploaded to the decentralized catalog."
                                customModName = ""
                                customModDesc = ""
                            } else {
                                publishMessage = "Error: Please verify asset properties."
                            }
                        },
                        modifier = Modifier
                            .testTag("publish_mod_button")
                            .fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                    ) {
                        Text("PUBLISH TO CATALYST MARKET", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    publishMessage?.let {
                        Text(
                            text = it,
                            color = SuccessGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun StudioProfileCard(
    studio: StudioAnalytics,
    onFollowRequested: () -> Unit,
    onPoolRequested: (Double) -> Unit,
    userBalance: Double
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberGlassBackground, RoundedCornerShape(24.dp))
            .border(1.dp, TranslucentBorder, RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = studio.studioName,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "${studio.followersCount} Followers",
                        color = NeonAqua,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = { onFollowRequested() },
                    colors = ButtonDefaults.buttonColors(containerColor = GlowPurple),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("FOLLOW STUDIO", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = studio.developerBio,
                color = DarkOnSurface.copy(alpha = 0.9f),
                fontSize = 11.sp
            )

            Divider(color = TranslucentBorder.copy(alpha = 0.2f))

            // Studio revenue counters (Web3 developer analytics representation)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("STUDIO INCOME", color = MatteGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("${studio.totalRevenueNexus} NEXUS", color = SuccessGreen, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("PLAYTIME LOGS", color = MatteGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("${studio.totalPlaySeconds / 60} MINS", color = NeonOrange, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                }
            }

            Divider(color = TranslucentBorder.copy(alpha = 0.2f))

            // Fundraising campaigns block
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("NEXT PROJECT FUNDRAISE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${studio.currentFundraiserNexus}/${studio.fundraiserGoalNexus} NEX", color = NeonPink, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                
                val fundPercentage = (studio.currentFundraiserNexus / studio.fundraiserGoalNexus).toFloat().coerceIn(0f, 1f)
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = fundPercentage,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = NeonPink,
                    trackColor = Color(0xFF1E1335)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onPoolRequested(5.0) },
                        enabled = userBalance >= 5.0,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Pool 5 NEX", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onPoolRequested(25.0) },
                        enabled = userBalance >= 25.0,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Pool 25 NEX", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. GORGEOUS CUSTOM NAVIGATION BAR
// ==========================================
@Composable
fun NexusBottomNavigationBar(
    activeTab: String,
    onTabSelect: (String) -> Unit
) {
    Surface(
        color = CyberSurface.copy(alpha = 0.95f),
        tonalElevation = 8.dp,
        border = BorderStroke(1.dp, TranslucentBorder.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexusNavItem(
                icon = Icons.Filled.GridView,
                label = "Discover",
                isActive = activeTab == "home",
                testTag = "navigation_tab_home",
                onClick = { onTabSelect("home") }
            )

            NexusNavItem(
                icon = Icons.Filled.SportsEsports,
                label = "Arcade",
                isActive = activeTab == "arcade",
                testTag = "navigation_tab_arcade",
                onClick = { onTabSelect("arcade") }
            )

            NexusNavItem(
                icon = Icons.Filled.AccountBalanceWallet,
                label = "Ecosystem",
                isActive = activeTab == "wallet",
                testTag = "navigation_tab_wallet",
                onClick = { onTabSelect("wallet") }
            )

            NexusNavItem(
                icon = Icons.Filled.LiveTv,
                label = "Mod Studio",
                isActive = activeTab == "developer",
                testTag = "navigation_tab_developer",
                onClick = { onTabSelect("developer") }
            )
        }
    }
}

@Composable
fun NexusNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(targetValue = if (isActive) 1.15f else 1.0f)
    val glowColor by animateColorAsState(targetValue = if (isActive) NeonAqua else Color.Transparent)

    Column(
        modifier = Modifier
            .testTag(testTag)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isActive) NeonPink else MatteGrey,
            modifier = Modifier
                .size(24.dp)
                .drawBehind {
                    if (isActive) {
                        drawCircle(
                            color = glowColor.copy(alpha = 0.35f),
                            radius = size.width * 0.9f
                        )
                    }
                }
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = if (isActive) Color.White else MatteGrey,
            fontSize = 9.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
    }
}
