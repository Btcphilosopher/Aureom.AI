package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CollectibleItem
import com.example.data.DevBlogPostEntity
import com.example.data.GameEntity
import com.example.data.MarketplaceItem
import com.example.data.NexusDatabase
import com.example.data.NexusRepository
import com.example.data.PlayerProfile
import com.example.data.StudioAnalytics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class NexusViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NexusRepository
    
    // Core database Flows
    val playerProfile: StateFlow<PlayerProfile?>
    val allGames: StateFlow<List<GameEntity>>
    val allCollectibles: StateFlow<List<CollectibleItem>>
    val allStudios: StateFlow<List<StudioAnalytics>>
    val allBlogPosts: StateFlow<List<DevBlogPostEntity>>
    val availableSkins: StateFlow<List<MarketplaceItem>>

    // Navigation and UI parameters
    var activeTab by mutableStateOf("home") // "home", "arcade", "wallet", "developer"
    var selectedGameId by mutableStateOf<String?>("racer") // Track selected game details
    var selectedStudioId by mutableStateOf<String?>("neon_dynamics") // Track developer studio details
    
    // Minting status tracker
    var mintingItemId by mutableStateOf<Int?>(null)
    var mintingSuccessMessage by mutableStateOf<String?>(null)

    // ==========================================
    // ARCADE GAME 1: CYBER RACER 2099 STATE
    // ==========================================
    var racerState by mutableStateOf("IDLE") // "IDLE", "PLAYING", "GAMEOVER"
    var racerScore by mutableStateOf(0)
    var playerX by mutableStateOf(0.5f) // Player position from 0.0 (left) to 1.0 (right)
    var obstacleList by mutableStateOf(listOf<Obstacle>())
    var particleList by mutableStateOf(listOf<StarParticle>())
    var collisionFlash by mutableStateOf(false)

    // ==========================================
    // ARCADE GAME 2: STAR MINER WEB3 STATE
    // ==========================================
    var minerOreHelium3 by mutableStateOf(12.0)
    var minerOreDarkMatter by mutableStateOf(1.5)
    var minerDrillCount by mutableStateOf(0)
    var drillPriceNexus by mutableStateOf(50.0)

    // Dynamic Commodity Prices (Fluctuate in real-time)
    var priceHelium3 by mutableStateOf(1.8)
    var priceDarkMatter by mutableStateOf(7.4)

    init {
        val database = NexusDatabase.getDatabase(application)
        repository = NexusRepository(database.nexusDao())

        playerProfile = repository.playerProfile.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

        allGames = repository.allGames.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allCollectibles = repository.allCollectibles.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allStudios = repository.allStudios.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allBlogPosts = repository.allBlogPosts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        availableSkins = repository.availableSkins.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Seed details and start loops
        viewModelScope.launch {
            repository.seedInitialData()
        }

        // Start miner drills background thread & commodity fluctuation
        startStarMinerLoops()
    }

    // ==========================================
    // STAR MINER LOGIC
    // ==========================================
    private fun startStarMinerLoops() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                // Auto drills harvest raw materials
                if (minerDrillCount > 0) {
                    minerOreHelium3 += minerDrillCount * 0.2
                    minerOreDarkMatter += minerDrillCount * 0.03
                }
            }
        }

        viewModelScope.launch {
            while (true) {
                delay(5000)
                // Fluctuate prices
                priceHelium3 = (1.1 + Random.nextDouble() * 1.5).roundTo(2)
                priceDarkMatter = (4.5 + Random.nextDouble() * 6.0).roundTo(2)
            }
        }
    }

    fun mineAsteroidClick() {
        // Active click adds resources based on click power
        minerOreHelium3 += 0.5
        if (Random.nextDouble() > 0.85) {
            minerOreDarkMatter += 0.1
        }
    }

    fun upgradeDrill() {
        viewModelScope.launch {
            val prof = playerProfile.value ?: return@launch
            if (prof.tokenBalance >= drillPriceNexus) {
                // Deduct via direct profile modification
                val updatedProf = prof.copy(tokenBalance = prof.tokenBalance - drillPriceNexus)
                repository.seedInitialData() // Make sure DB triggers if needed, but we write:
                NexusDatabase.getDatabase(getApplication()).nexusDao().updatePlayerProfile(updatedProf)
                
                minerDrillCount++
                drillPriceNexus = (drillPriceNexus * 1.4).roundTo(0)
            }
        }
    }

    fun sellAllCommodities() {
        viewModelScope.launch {
            val h3SoldAmount = minerOreHelium3
            val dmSoldAmount = minerOreDarkMatter

            val earnedNexus = (h3SoldAmount * priceHelium3) + (dmSoldAmount * priceDarkMatter)
            if (earnedNexus <= 0.0) return@launch

            val prof = playerProfile.value ?: return@launch
            val updatedProf = prof.copy(
                tokenBalance = prof.tokenBalance + earnedNexus,
                credits = prof.credits + (earnedNexus * 5).toInt()
            )
            NexusDatabase.getDatabase(getApplication()).nexusDao().updatePlayerProfile(updatedProf)

            minerOreHelium3 = 0.0
            minerOreDarkMatter = 0.0

            // If sold amount is massive, trigger an award in database!
            if (earnedNexus > 40.0) {
                repository.recordGamePlayResult("miner", (earnedNexus * 10).toInt())
            }
        }
    }

    // ==========================================
    // CYBER RACER PHYSICS LOOP
    // ==========================================
    fun startCyberRacer() {
        if (racerState == "PLAYING") return
        racerScore = 0
        playerX = 0.5f
        racerState = "PLAYING"
        obstacleList = listOf(
            Obstacle(x = 0.3f, y = -0.2f, type = ObstacleType.BARRIER),
            Obstacle(x = 0.7f, y = -0.6f, type = ObstacleType.CHIP)
        )
        particleList = List(15) {
            StarParticle(
                x = Random.nextFloat(),
                y = Random.nextFloat() * 1.5f,
                speed = 0.01f + Random.nextFloat() * 0.02f
            )
        }
        
        viewModelScope.launch {
            var loopCount = 0
            while (racerState == "PLAYING") {
                delay(16) // ~60fps ticks
                loopCount++

                // Update particle starfields
                particleList = particleList.map {
                    val nextY = it.y + it.speed
                    if (nextY > 1.2f) {
                        StarParticle(x = Random.nextFloat(), y = -0.1f, speed = it.speed)
                    } else {
                        it.copy(y = nextY)
                    }
                }

                // Move and spawn obstacles
                obstacleList = obstacleList.map {
                    it.copy(y = it.y + 0.012f + (racerScore * 0.00005f)) // Accelerating speed
                }.filter { it.y < 1.1f }

                // Periodic spawn
                if (loopCount % 45 == 0) {
                    val obsType = if (Random.nextFloat() > 0.3f) ObstacleType.BARRIER else ObstacleType.CHIP
                    obstacleList = obstacleList + Obstacle(
                        x = 0.15f + Random.nextFloat() * 0.7f,
                        y = -0.1f,
                        type = obsType
                    )
                }

                // Collision Check
                val iterator = obstacleList.iterator()
                val remainingObs = mutableListOf<Obstacle>()
                while (iterator.hasNext()) {
                    val obs = iterator.next()
                    // Check physical proximity in normalized spacing
                    val distY = Math.abs(obs.y - 0.9f) // Player sits at y = 0.9f
                    val distX = Math.abs(obs.x - playerX)
                    
                    if (distY < 0.06f && distX < 0.12f) {
                        if (obs.type == ObstacleType.CHIP) {
                            // Collect chip
                            racerScore += 20
                            // Fluctuate player balance briefly as visual bonus
                            viewModelScope.launch {
                                val prof = playerProfile.value
                                if (prof != null) {
                                    NexusDatabase.getDatabase(getApplication()).nexusDao().updatePlayerProfile(
                                        prof.copy(credits = prof.credits + 5)
                                    )
                                }
                            }
                        } else {
                            // hit wall - GAME OVER
                            collisionFlash = true
                            racerState = "GAMEOVER"
                            endRacerGameAndPersist()
                            break
                        }
                    } else {
                        remainingObs.add(obs)
                        // Score increments just by survival
                        if (obs.y > 0.91f && !obs.scored && obs.type == ObstacleType.BARRIER) {
                            racerScore += 10
                            obs.scored = true
                        }
                    }
                }
                if (racerState == "PLAYING") {
                    obstacleList = remainingObs
                }
            }
        }
    }

    private fun endRacerGameAndPersist() {
        viewModelScope.launch {
            delay(500)
            collisionFlash = false
            repository.recordGamePlayResult("racer", racerScore)
        }
    }

    fun moveRacerLeft() {
        playerX = (playerX - 0.15f).coerceIn(0.1f, 0.9f)
    }

    fun moveRacerRight() {
        playerX = (playerX + 0.15f).coerceIn(0.1f, 0.9f)
    }

    // ==========================================
    // ECOSYSTEM INTERACTIONS
    // ==========================================
    fun mintNFT(itemId: Int) {
        viewModelScope.launch {
            val prof = playerProfile.value
            if (prof != null && prof.tokenBalance < 10.0) {
                mintingSuccessMessage = "Error: Need 10.0 NEXUS gas fee to mint NFT."
                return@launch
            }
            
            mintingItemId = itemId
            // Fake smart contract verification delay
            delay(2000)
            repository.mintCollectibleAsNft(itemId)
            mintingItemId = null
            mintingSuccessMessage = "Success! Asset minted onto the blockchain. Mint log stored in database."
            delay(4000)
            mintingSuccessMessage = null
        }
    }

    fun purchaseSkinFromMarket(skinId: Int, priceNexus: Double, skinName: String, gameOrigin: String, rarity: String) {
        viewModelScope.launch {
            val prof = playerProfile.value ?: return@launch
            if (prof.tokenBalance >= priceNexus) {
                repository.buyMarketplaceSkin(skinId, priceNexus, skinName, gameOrigin, rarity)
            }
        }
    }

    fun publishCustomCreatorSkin(name: String, desc: String, price: Double, rarity: String, category: String, gameOrigin: String) {
        viewModelScope.launch {
            repository.publishNewMod(name, desc, price, rarity, category, gameOrigin)
        }
    }

    fun followStudioAction(studioId: String) {
        viewModelScope.launch {
            repository.followStudio(studioId)
        }
    }

    fun poolFundraiser(studioId: String, amount: Double) {
        viewModelScope.launch {
            repository.donateToStudioFundraiser(studioId, amount)
        }
    }

    // Utilities
    private fun Double.roundTo(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }
}

// Sub state configurations
data class Obstacle(
    val x: Float,
    val y: Float,
    val type: ObstacleType,
    var scored: Boolean = false
)

enum class ObstacleType {
    BARRIER, CHIP
}

data class StarParticle(
    val x: Float,
    val y: Float,
    val speed: Float
)
