package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CyberColorScheme = darkColorScheme(
    primary = NeonPink,
    secondary = NeonAqua,
    tertiary = NeonOrange,
    background = CyberBackground,
    surface = CyberSurface,
    surfaceVariant = CyberSurfaceVariant,
    onBackground = DarkOnBackground,
    onSurface = DarkOnSurface,
    onPrimary = DarkOnBackground,
    onSecondary = CyberBackground,
    onTertiary = CyberBackground,
    error = CriticalRed
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CyberColorScheme,
        typography = Typography,
        content = content
    )
}
