package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.NexusViewModel
import com.example.ui.screens.NexusMainNavigator
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize the central View Model holding the persistent state and game loops
                val nexusViewModel: NexusViewModel = viewModel()
                
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = com.example.ui.theme.CyberBackground
                ) { innerPadding ->
                    NexusMainNavigator(
                        viewModel = nexusViewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
