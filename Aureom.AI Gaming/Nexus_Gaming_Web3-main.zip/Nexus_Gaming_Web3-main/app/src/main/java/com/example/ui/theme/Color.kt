package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Frosted Glass Aesthetic Ambient Neon Palette
val CyberBackground = Color(0xFF050212)      // HTML's exact #050212 deep space dark
val CyberSurface = Color(0x0DFFFFFF)         // glass-bg: rgba(255, 255, 255, 0.05)
val CyberSurfaceVariant = Color(0x1CFFFFFF)  // High-contrast frosted glass plate: rgba(255, 255, 255, 0.11)
val CyberGlassBackground = Color(0x0DFFFFFF) // glass-bg: rgba(255, 255, 255, 0.05)

// Vibrant Neon Lights
val NeonAqua = Color(0xFF00F3FF)             // HTML's exact --neon-cyan: #00f3ff
val NeonPink = Color(0xFFFF00FF)             // HTML's exact --neon-pink: #ff00ff
val NeonOrange = Color(0xFFFFF600)           // Holographic yellow
val GlowPurple = Color(0xFF9E0DF2)           // Cyber-purple accent

// Semantic Material Tokens
val DarkOnBackground = Color(0xFFFFFFFF)     // High-clarity pristine white
val DarkOnSurface = Color(0xFFE2E8F0)        // Frosted Slate body label
val MatteGrey = Color(0xFF94A3B8)            // Muted cool slate for subtitles and shadows (#94a3b8)
val TranslucentBorder = Color(0x26FFFFFF)    // glass-border: rgba(255, 255, 255, 0.15)
val CriticalRed = Color(0xFFFF3366)          // Warning neon-red
val SuccessGreen = Color(0xFF10B981)         // Active emerald-green

