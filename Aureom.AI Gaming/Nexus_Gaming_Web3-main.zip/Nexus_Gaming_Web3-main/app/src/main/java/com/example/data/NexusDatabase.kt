package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ==========================================
// 1. DATABASE ENTITIES
// ==========================================

@Entity(tableName = "player_profile")
data class PlayerProfile(
    @PrimaryKey val id: Int = 1, // Single profile for the current session representation
    val username: String = "CyberNomad_7",
    val level: Int = 12,
    val xp: Int = 2450,
    val totalXpNeeded: Int = 5000,
    val credits: Int = 1250,
    val tokenBalance: Double = 840.50, // NEXUS crypto tokens
    val solBalance: Double = 3.14,      // Optional Solana tokens
    val guildName: String = "Avalanche_X",
    val reputationScore: Int = 98,
    val gamesPlayedCount: Int = 42,
    val rankTitle: String = "Elite Gladiator"
)

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey val id: String,  // "racer", "miner", "chess"
    val title: String,
    val subtitle: String,
    val description: String,
    val genre: String,
    val instantPlayable: Boolean,
    val hasWeb3Features: Boolean,
    val highScore: Int = 0,
    val timesPlayed: Int = 0,
    val minRequiredRamGbs: Int = 4,
    val blockchainEnabled: Boolean = false
)

@Entity(tableName = "collectibles")
data class CollectibleItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val rarity: String, // "COMMON", "RARE", "HOLOGRAPHIC", "LEGENDARY"
    val mintedAsNft: Boolean = false,
    val nftContractAddress: String = "",
    val tokenStandard: String = "SPL-Token",
    val marketPriceNexus: Double = 0.0,
    val gameOrigin: String,
    val dateAcquired: Long = System.currentTimeMillis()
)

@Entity(tableName = "studio_analytics")
data class StudioAnalytics(
    @PrimaryKey val studioId: String, // "neon_dynamics", "aether_labs", "cyberforge"
    val studioName: String,
    val followersCount: Int = 1042,
    val publishedGamesCount: Int = 3,
    val totalRevenueNexus: Double = 14500.0,
    val totalPlaySeconds: Long = 849000L,
    val developerReputation: Double = 4.8,
    val developerBio: String,
    val currentFundraiserNexus: Double = 5000.0,
    val fundraiserGoalNexus: Double = 10000.0
)

@Entity(tableName = "dev_blog_posts")
data class DevBlogPostEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studioId: String,
    val title: String,
    val summary: String,
    val authorName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "marketplace_items")
data class MarketplaceItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val priceNexus: Double,
    val rarity: String,
    val category: String, // "Skins", "Mods", "Maps", "Weapons"
    val sellerName: String,
    val gameTitle: String,
    val isSold: Boolean = false
)

// ==========================================
// 2. DATA ACCESS OBJECT (DAO)
// ==========================================

@Dao
interface NexusDao {
    // Player profile operations
    @Query("SELECT * FROM player_profile WHERE id = 1 LIMIT 1")
    fun getPlayerProfileFlow(): Flow<PlayerProfile?>

    @Query("SELECT * FROM player_profile WHERE id = 1 LIMIT 1")
    suspend fun getPlayerProfileDirect(): PlayerProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updatePlayerProfile(profile: PlayerProfile)

    // Game showcase operations
    @Query("SELECT * FROM games")
    fun getAllGamesFlow(): Flow<List<GameEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGames(games: List<GameEntity>)

    @Query("UPDATE games SET highScore = :score, timesPlayed = timesPlayed + 1 WHERE id = :id")
    suspend fun updateGamePlayStats(id: String, score: Int)

    // Items and collectibles operations (Ecosystem inventory)
    @Query("SELECT * FROM collectibles ORDER BY dateAcquired DESC")
    fun getAllCollectiblesFlow(): Flow<List<CollectibleItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollectible(item: CollectibleItem)

    @Query("UPDATE collectibles SET mintedAsNft = 1, nftContractAddress = :contract WHERE id = :id")
    suspend fun mintItemAsNft(id: Int, contract: String)

    // Developer / Studio analytics
    @Query("SELECT * FROM studio_analytics")
    fun getAllStudiosFlow(): Flow<List<StudioAnalytics>>

    @Query("SELECT * FROM studio_analytics WHERE studioId = :studioId LIMIT 1")
    fun getStudioByIdFlow(studioId: String): Flow<StudioAnalytics?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudio(studio: StudioAnalytics)

    @Query("UPDATE studio_analytics SET followersCount = followersCount + 1 WHERE studioId = :studioId")
    suspend fun incrementStudioFollowers(studioId: String)

    @Query("UPDATE studio_analytics SET totalRevenueNexus = totalRevenueNexus + :revenue WHERE studioId = :studioId")
    suspend fun addStudioRevenue(studioId: String, revenue: Double)

    // Dev blog operations
    @Query("SELECT * FROM dev_blog_posts ORDER BY timestamp DESC")
    fun getAllBlogPostsFlow(): Flow<List<DevBlogPostEntity>>

    @Query("SELECT * FROM dev_blog_posts WHERE studioId = :studioId ORDER BY timestamp DESC")
    fun getBlogPostsForStudioFlow(studioId: String): Flow<List<DevBlogPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlogPost(post: DevBlogPostEntity)

    // Creator Marketplace item operations
    @Query("SELECT * FROM marketplace_items WHERE isSold = 0")
    fun getAvailableMarketplaceItemsFlow(): Flow<List<MarketplaceItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarketplaceItems(items: List<MarketplaceItem>)

    @Query("UPDATE marketplace_items SET isSold = 1 WHERE id = :id")
    suspend fun setMarketplaceItemSold(id: Int)
}

// ==========================================
// 3. DATABASE BASE CLASS
// ==========================================

@Database(
    entities = [
        PlayerProfile::class,
        GameEntity::class,
        CollectibleItem::class,
        StudioAnalytics::class,
        DevBlogPostEntity::class,
        MarketplaceItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NexusDatabase : RoomDatabase() {
    abstract fun nexusDao(): NexusDao

    companion object {
        @Volatile
        private var INSTANCE: NexusDatabase? = null

        fun getDatabase(context: Context): NexusDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NexusDatabase::class.java,
                    "nexus_web3_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
