# CANAL EMPIRE
### Anglo-Industrial Infrastructure Simulator · 1760–2030

> *Build a canal empire. Survive the railways. Rule the logistics age.*

A full-stack, modular Python simulation game spanning 270 years of British
industrial and transport history. Combines infrastructure strategy, economic
modelling, procedural events, AI competitors, and lightweight ML — all
playable through a Streamlit dashboard.

---

## QUICK START

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the headless demo (no UI needed — proves all systems work)
python demo.py

# 3. Launch the full interactive dashboard
streamlit run app.py

# 4. (Optional) Start the FastAPI backend separately
python -m canal_empire.api.server
# → API docs at http://localhost:8000/docs
```

---

## SYSTEM ARCHITECTURE

```
canal_empire/
├── world/
│   └── map_engine.py          Module 1 — UK map, terrain, nodes, pathfinding
├── infrastructure/
│   └── infrastructure.py      Module 2 — Canals, locks, upgrades, degradation
├── economy/
│   └── engine.py              Module 3 — Supply/demand, pricing, trade flows
├── transport/
│   └── logistics.py           Module 4 — Multi-modal routing, efficiency
├── ai/
│   └── competitors.py         Module 5 — AI rivals (rail, road, shipping)
├── events/
│   ├── event_engine.py        Module 6 — Procedural event system (25 events)
│   └── technology.py          Module 7 — Probabilistic tech evolution
├── ml/
│   └── models.py              Module 8 — Demand prediction, event multiplier ML
├── simulation/
│   └── engine.py              Module 9 — Master orchestrator, game loop
├── player/
│   └── player.py              Module 10 — Capital, assets, decisions
└── api/
    └── server.py              FastAPI REST backend

app.py                         Module 11 — Streamlit dashboard
demo.py                        Headless demo runner
requirements.txt
```

---

## MODULES IN DETAIL

### Module 1 · World & Map Engine
18 UK nodes (London → Glasgow) with terrain type, elevation, population,
and resource/demand profiles. Edges carry terrain cost, distance, and
infrastructure flags. Dijkstra pathfinding for route optimisation.
Expansion nodes for Europe, North America, India are pre-seeded.

### Module 2 · Infrastructure System
`CanalSegment` tracks: build cost, capacity, speed, state (planned /
under construction / operational / degraded / derelict), upgrades applied,
and annual maintenance cost. Locks are modelled individually with lift
height and transit time. Six upgrade types: widening, deepening, mechanised
locks, steam towpath, electric pumps, containerisation.

### Module 3 · Economic Engine
Time-stepped annual simulation. Each node has `RegionalMarket` with
supply/demand per good (coal, food, manufactured, raw materials, luxury).
Prices respond to supply/demand ratios. Trade flows are computed each year
across all connected node pairs, selecting best transport mode and
calculating merchantable volume and revenue.

### Module 4 · Transport & Logistics
Five transport modes: canal, coastal, rail, road, air. Each has
speed, cost/tonne-km, capacity, and CO₂ impact. Modes unlock dynamically
as technology advances. Canal routes lose market share to rail once rail
is cheap enough for the goods type in question.

### Module 5 · AI Competitors
10 historically-named rivals (Bridgewater Canal Trust → DHL Logistics)
activate on a historical schedule. Each has aggression and efficiency
parameters. They score routes by profitability, build infrastructure,
and directly target player-held territory when aggressive.

### Module 6 · Event Engine
25 procedural events spanning economic crashes, wars, technological
breakthroughs, regulation, and natural disasters. Fixed historical events
(Railway Mania 1840, WWI 1914, Great Depression 1929) are anchored in
time. Probabilistic events respond to game state: high market share
triggers monopoly inquiries; many canals increase breach probability.
Active effects stack and decay over multiple years.

### Module 7 · Technology Evolution
20 technologies across six categories. Prerequisites form a soft
dependency graph. Most emerge probabilistically within a historical
window; key breakthroughs (Steam Engine 1782, Steam Railway 1825,
Containerisation 1965) are forced on schedule. Player investment
accelerates discovery probability.

### Module 8 · ML Layer
Three lightweight models trained on synthetic first-principles data:
- **DemandPredictor** — OLS regression: pop × pop, price diff, distance,
  year, industrialisation, canal presence → predicted trade volume
- **CompetitorRoutePredictor** — Logistic regression: route
  profitability, player presence, era, aggression → entry probability
- **EventProbabilityModel** — Linear regression: year, GDP growth,
  industrial intensity, market share → event multiplier

All models are pure NumPy — no sklearn dependency, fully interpretable.

### Module 9 · Simulation Engine
`CanalEmpireSimulation` orchestrates all subsystems per annual tick:
events → technology → economy → infrastructure → competitors →
transport → player settlement → victory check. Supports save state,
fast-forward (advance N years), and full state serialisation.

### Module 10 · Player System
Tracks capital, assets, loans, credit rating, market share. Provides
actions: build canal, upgrade canal, set toll, invest in technology,
take/repay loan. Annual settlement computes revenue from trade flows
flowing over player-owned operational canals.

### Module 11 · Streamlit Dashboard
Anglo-futurist dark UI (Bebas Neue · DM Mono · Plotly dark theme).
Five tabs: Map & Network · Economy · Infrastructure · Competitors ·
Technology · Analytics. Sidebar: real-time stats, time control (advance
1–50 years), build canal selector, loan panel.

---

## GAMEPLAY GUIDE

### 1760s — The Canal Age Begins
You start with three operational canals in the Midlands and £200k capital.
Build outward — connect Newcastle's coal to London's demand, or link
Manchester's textiles to Liverpool's docks. Each route generates toll
revenue proportional to trade volume and price differential.

### 1825 — Railways Arrive
The Steam Railway technology fires. GWR and LNWR begin building competing
rail lines. Your canal revenue on short-haul routes will fall. **Widen
your canals and reduce tolls on bulk goods** (coal, raw materials) where
canals hold a natural advantage over rail.

### 1840–1870 — Railway Mania
The most challenging era. Upgrade strategically: mechanised locks and
steam towpaths can keep bulk cargo competitive. Focus on routes where
geography makes rail construction expensive (hilly terrain, river
crossings).

### 1900+ — Road Age
Motor lorries appear. Diversify into warehousing and coastal shipping.
Invest in technology to unlock containerisation early.

### Victory Conditions
Survive to 2030 with the highest net worth (capital + asset book value −
debt). Bonus scoring for: peak market share, total canal km built,
technologies unlocked, events survived.

---

## API REFERENCE (FastAPI)

```
POST /new_game          Start new simulation
GET  /state             Full game state
POST /advance/{years}   Step forward N years
POST /build_canal       Build a new canal
POST /upgrade_canal     Upgrade existing canal
POST /set_toll          Adjust toll rate
POST /invest_tech       Invest in technology
POST /take_loan         Request loan
GET  /buildable_routes  Available construction routes
GET  /history           Year-by-year log
GET  /economy           Markets and trade flows
GET  /ml_insights       ML model outputs
```

---

## TECHNICAL NOTES

- Python 3.11+ required
- All ML models use pure NumPy (no sklearn)
- No external data files — all map/economic data is code-defined
- Simulation state is fully serialisable to JSON
- Random seed support for reproducible runs
- ~2,000 lines of core simulation code across 10 modules

---

*Built with: Python · FastAPI · Streamlit · NumPy · Pandas · Plotly*
