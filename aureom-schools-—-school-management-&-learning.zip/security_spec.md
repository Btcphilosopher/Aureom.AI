# Security Specification — AUREOM SCHOOLS

## 1. Data Invariants
1. **Default-Deny Baseline**: Every unrecognised collection or unauthenticated request fails closed (`allow read, write: if false`).
2. **Email Verification Gate**: All authenticated reads/writes require `request.auth.token.email_verified == true`.
3. **Tenant Separation**: Every school sub-collection resides strictly under `/schools/{schoolId}/...`. Cross-school queries are structurally blocked.
4. **No Self-Privilege Escalation**: Non-admin users cannot set or mutate `role`, `verifiedByOffice`, or `linkedPupilIds` on `/users/{uid}`.
5. **Safeguarding Confidentiality**: `/schools/{schoolId}/safeguardingConcerns/{concernId}` is never readable by parents, pupils, office staff, or general teachers; only `dsl` staff or `admin` may read/update concerns. General staff may only create a concern in `submitted_unacknowledged` state with `reportedByUid == request.auth.uid`.
6. **Emergency Contact Isolation**: `isEmergencyContact == true` never grants portal access, collection permission, or educational record reads unless `hasPortalAccess` and `hasRecordAccess` are explicitly verified by the school office.
7. **Immutable Audit Trail**: `/schools/{schoolId}/auditLogs/{logId}` is append-only (`allow update, delete: if false`).
8. **Parent Absence vs School Authorisation**: Parents can submit `/absenceRequests` with `status == 'pending_review'` and `submittedByUid == request.auth.uid`, but only office/leadership/admin can transition `status` to `authorised` / `unauthorised` or write `/attendanceSessions`.

## 2. Dirty Dozen Adversarial Payloads
1. Unverified email user attempts to read `/schools/pennine-academy/pupils/pup_oliver` -> `PERMISSION_DENIED`.
2. Non-admin parent attempts to update `/users/{uid}` adding `role: "admin"` -> `PERMISSION_DENIED`.
3. Non-admin parent attempts to add another child's ID to `/users/{uid}.linkedPupilIds` -> `PERMISSION_DENIED`.
4. Parent attempts to read `/schools/pennine-academy/safeguardingConcerns/{id}` -> `PERMISSION_DENIED`.
5. General teacher attempts to `list` `/schools/pennine-academy/safeguardingConcerns` -> `PERMISSION_DENIED`.
6. Teacher attempts to create a safeguarding concern spoofing `reportedByUid: "other_uid"` or `status: "closed"` -> `PERMISSION_DENIED`.
7. Parent attempts to read another family's pupil record (`pup_amelia`) not in `linkedPupilIds` -> `PERMISSION_DENIED`.
8. Parent attempts to submit an absence request already marked `status: "authorised"` -> `PERMISSION_DENIED`.
9. User injects a 500-character document ID (`isValidId` violation) -> `PERMISSION_DENIED`.
10. User submits a shadow field (`isSuperAdmin: true`) on `/bookings/{id}` -> `PERMISSION_DENIED`.
11. Staff or user attempts to delete or alter an existing `/schools/pennine-academy/auditLogs/{id}` -> `PERMISSION_DENIED`.
12. Unlinked user attempts to read `/schools/lothian-brae-high/pupils/{id}` across tenant boundary -> `PERMISSION_DENIED`.
