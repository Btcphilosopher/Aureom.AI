import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, { NextFunction, Request, Response } from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';
import { getApp, getApps, initializeApp } from 'firebase-admin/app';
import { DecodedIdToken, getAuth } from 'firebase-admin/auth';
import firebaseConfig from '../firebase-applet-config.json';
import {
  AttendanceSession,
  TimetableEntry,
  UK_JURISDICTIONS,
  UkJurisdiction,
  calculateAttendanceSummary,
  detectTimetableClashes,
  stripPiiForAi,
  validateAdmissionsCsv,
} from './shared/school-domain';

const browserDistFolder = join(import.meta.dirname, '../browser');

const adminApp = getApps().length
  ? getApp()
  : initializeApp({ projectId: firebaseConfig.projectId });
const adminAuth = getAuth(adminApp);

function getAiClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: process.env['GEMINI_API_KEY'] ?? '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

interface AuthRequest extends Request {
  user?: DecodedIdToken;
}

const requireVerifiedUser = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required: missing Bearer token.' });
    return;
  }

  const token = authHeader.slice('Bearer '.length).trim();
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    if (!decoded.email_verified) {
      res.status(403).json({ error: 'Verified email address required.' });
      return;
    }
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired authentication token.' });
  }
};

// Authorised school policy corpus for grounded AI policy search
const PENNINE_POLICIES = [
  {
    id: 'POL-ATT-2025',
    title: 'Pennine Academy Attendance & Punctuality Policy (2025/26)',
    section: 'Section 3.2 — Morning & Afternoon Registration',
    excerpt:
      'Morning registration opens at 08:40 and closes at 09:05. Arrivals between 08:45 and 09:05 receive code L (Late before register closed). Arrivals after 09:05 receive code U (Unauthorised late) unless covered by an approved medical appointment (code M). Parent absence submissions via the Family Portal are logged as notifications and do not automatically authorise absence; authorisation rests solely with the Attendance Officer or Senior Leadership.',
  },
  {
    id: 'POL-SAFE-2025',
    title: 'Pennine Academy Child Protection & Safeguarding Policy (KCSIE 2025)',
    section: 'Section 4.1 — Reporting & Escalation',
    excerpt:
      'All staff must record safeguarding concerns factually on the same school day. Submitting a concern does not establish that the Designated Safeguarding Lead (DSL) has read or acted upon it; the DSL must explicitly acknowledge receipt. Urgent concerns involving immediate risk of harm must be escalated immediately in person or by telephone to the DSL (Ms Hannah Brooks) and West Yorkshire MASH.',
  },
  {
    id: 'POL-SEND-2025',
    title: 'Pennine Academy SEND & Medical Support Policy',
    section: 'Section 2.4 — Classroom Adjustments & Healthcare Plans',
    excerpt:
      'Class teachers receive practical classroom adjustment summaries (e.g. seating, coloured overlays, rest breaks) while sensitive diagnostic histories remain restricted to the SENCO and DSL. Pupils with severe allergies or asthma must have a nurse-verified Individual Healthcare Plan before off-site trips.',
  },
  {
    id: 'POL-TRIPS-2025',
    title: 'Pennine Academy Educational Visits, Allergens & Charging Policy',
    section: 'Section 5.1 — Consent, Allergens & Remissions',
    excerpt:
      'Signed parental consent is mandatory for every off-site visit and is recorded independently of payment status. Catering menus display allergen verification status explicitly; unverified external provider menus must not be treated as guaranteed allergen-free.',
  },
];

// Idempotent payment ledger cache so retries return the original receipt without double-charging
const simulatedPaymentLedger = new Map<
  string,
  {
    receiptRef: string;
    amountPence: number;
    currency: 'GBP';
    paymentStatus: 'simulated_paid';
    processedAt: string;
    duplicatePrevented: boolean;
  }
>();

const app = express();
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'aureom-schools', timestamp: new Date().toISOString() });
});

app.get('/api/jurisdictions', (_req, res) => {
  res.json({ jurisdictions: Object.values(UK_JURISDICTIONS) });
});

app.post('/api/attendance/calculate', requireVerifiedUser, (req: AuthRequest, res) => {
  const body = req.body as {
    sessions?: AttendanceSession[];
    jurisdiction?: UkJurisdiction;
    enrolledFromDate?: string;
  };
  if (!Array.isArray(body.sessions)) {
    res.status(400).json({ error: 'sessions array is required.' });
    return;
  }
  const jurisdiction: UkJurisdiction =
    body.jurisdiction && body.jurisdiction in UK_JURISDICTIONS
      ? body.jurisdiction
      : 'england_dfe';
  const summary = calculateAttendanceSummary(body.sessions, jurisdiction, body.enrolledFromDate);
  res.json(summary);
});

app.post('/api/timetable/validate', requireVerifiedUser, (req: AuthRequest, res) => {
  const body = req.body as { entries?: TimetableEntry[] };
  if (!Array.isArray(body.entries)) {
    res.status(400).json({ error: 'entries array is required.' });
    return;
  }
  const clashes = detectTimetableClashes(body.entries);
  res.json({ valid: clashes.length === 0, clashes });
});

app.post('/api/admissions/validate-csv', requireVerifiedUser, (req: AuthRequest, res) => {
  const body = req.body as {
    csvText?: string;
    existingPupils?: { pupilId: string; firstName: string; lastName: string; dob: string }[];
  };
  if (typeof body.csvText !== 'string') {
    res.status(400).json({ error: 'csvText string is required.' });
    return;
  }
  const result = validateAdmissionsCsv(body.csvText, body.existingPupils ?? []);
  res.json(result);
});

app.post('/api/payments/simulate', requireVerifiedUser, (req: AuthRequest, res) => {
  const body = req.body as {
    idempotencyKey?: string;
    amountPence?: number;
    tripId?: string;
    pupilId?: string;
  };

  if (
    typeof body.idempotencyKey !== 'string' ||
    body.idempotencyKey.trim().length < 4 ||
    typeof body.amountPence !== 'number' ||
    body.amountPence < 0
  ) {
    res.status(400).json({ error: 'Valid idempotencyKey and non-negative amountPence are required.' });
    return;
  }

  const key = `${req.user?.uid ?? 'anon'}:${body.idempotencyKey.trim()}`;
  const existing = simulatedPaymentLedger.get(key);
  if (existing) {
    res.json({ ...existing, duplicatePrevented: true });
    return;
  }

  const receiptRef = `PEN-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const record = {
    receiptRef,
    amountPence: Math.round(body.amountPence),
    currency: 'GBP' as const,
    paymentStatus: 'simulated_paid' as const,
    processedAt: new Date().toISOString(),
    duplicatePrevented: false,
  };
  simulatedPaymentLedger.set(key, record);
  res.json(record);
});

app.post('/api/ai/assist', requireVerifiedUser, async (req: AuthRequest, res) => {
  const body = req.body as {
    mode?: 'lesson_resource' | 'announcement' | 'report_draft' | 'policy_search';
    prompt?: string;
    context?: string;
  };

  if (!body.mode || typeof body.prompt !== 'string' || !body.prompt.trim()) {
    res.status(400).json({ error: 'mode and prompt are required.' });
    return;
  }

  if (!process.env['GEMINI_API_KEY']) {
    res.status(503).json({
      error: 'GEMINI_API_KEY is not configured in server secrets.',
    });
    return;
  }

  const cleanPrompt = stripPiiForAi(body.prompt.trim().slice(0, 1500));
  const cleanContext = stripPiiForAi((body.context ?? '').trim().slice(0, 1500));

  let systemInstruction =
    'You are an assistant for UK school staff at Pennine Academy. Use British English (e.g. pupils, timetable, authorised, colour, programme). Never decide pupil grades, impose disciplinary sanctions, make admissions decisions, or resolve safeguarding concerns. Keep output concise, practical, and ready for staff review before publication.';

  let userContent = cleanPrompt;
  if (body.mode === 'policy_search') {
    systemInstruction =
      'Answer the staff question strictly using ONLY the provided Pennine Academy authorised policy excerpts. Cite the Policy ID and Section title in your answer. If the excerpts do not cover the question, say so clearly.';
    const corpus = PENNINE_POLICIES.map(
      (p) => `[${p.id}] ${p.title} — ${p.section}\n${p.excerpt}`,
    ).join('\n\n');
    userContent = `Authorised Policies:\n${corpus}\n\nStaff Question: ${cleanPrompt}`;
  } else if (body.mode === 'lesson_resource') {
    userContent = `Draft a structured UK curriculum lesson resource and an accessible non-file homework alternative.\nSubject/Context: ${cleanContext || 'General Secondary'}\nRequest: ${cleanPrompt}`;
  } else if (body.mode === 'announcement') {
    userContent = `Draft a calm, clear school announcement for parents/carers in British English.\nContext: ${cleanContext}\nDetails: ${cleanPrompt}`;
  } else if (body.mode === 'report_draft') {
    userContent = `Draft a balanced, factual teacher report comment based only on the anonymised observations below (do not invent marks or grades).\nObservations: ${cleanPrompt}`;
  }

  try {
    const response = await getAiClient().models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: userContent,
      config: {
        systemInstruction,
      },
    });
    res.json({
      draft: response.text ?? '',
      requiresStaffReview: true,
      piiRedacted: cleanPrompt !== body.prompt.trim() || cleanContext !== (body.context ?? '').trim(),
      citations: body.mode === 'policy_search' ? PENNINE_POLICIES.map((p) => `${p.id} (${p.section})`) : [],
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'AI generation failed.';
    res.status(502).json({ error: message });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
const angularApp = new AngularNodeAppEngine();
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) => (response ? writeResponseToNodeResponse(response, res) : next()))
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
