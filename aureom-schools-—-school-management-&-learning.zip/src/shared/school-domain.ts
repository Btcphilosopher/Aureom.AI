export type UkJurisdiction = 'england_dfe' | 'scotland_cfe' | 'wales_cfw' | 'ni_de';

export type UserRole = 'admin' | 'leadership' | 'dsl' | 'teacher' | 'office' | 'parent' | 'pupil';

export interface AttendanceCodeDef {
  code: string;
  label: string;
  category: 'present' | 'approved_educational' | 'authorised_absence' | 'unauthorised_absence' | 'not_required';
  countsAsPresent: boolean;
  countsInPossible: boolean;
}

export interface JurisdictionSpec {
  id: UkJurisdiction;
  name: string;
  authority: string;
  statutoryPupilIdLabel: string;
  safeguardingFramework: string;
  attendanceCodeVersion: string;
  yearGroups: string[];
  attendanceCodes: AttendanceCodeDef[];
  notes: string;
}

export const UK_JURISDICTIONS: Record<UkJurisdiction, JurisdictionSpec> = {
  england_dfe: {
    id: 'england_dfe',
    name: 'England (DfE)',
    authority: 'Department for Education — School Attendance (Pupil Registration) Regulations 2024',
    statutoryPupilIdLabel: 'UPN (Unique Pupil Number)',
    safeguardingFramework: 'Keeping Children Safe in Education (KCSIE) & Working Together to Safeguard Children',
    attendanceCodeVersion: 'DfE-2024-v2',
    yearGroups: ['Reception', 'Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'Year 6', 'Year 7', 'Year 8', 'Year 9', 'Year 10', 'Year 11', 'Year 12', 'Year 13'],
    notes: 'AM and PM statutory sessions; National Code K/B/C1/C2/Y1-Y7 updated August 2024.',
    attendanceCodes: [
      { code: '/', label: 'Present (AM)', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: '\\', label: 'Present (PM)', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'L', label: 'Late before register closed', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'B', label: 'Attending approved off-site educational activity', category: 'approved_educational', countsAsPresent: true, countsInPossible: true },
      { code: 'V', label: 'Educational visit or trip', category: 'approved_educational', countsAsPresent: true, countsInPossible: true },
      { code: 'I', label: 'Illness (not medical/dental appointment)', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'M', label: 'Medical or dental appointment', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'C', label: 'Leave of absence (exceptional circumstances)', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'E', label: 'Suspended or permanently excluded (no alternative provision)', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'G', label: 'Holiday not granted by the school', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'O', label: 'Absent in other or unknown circumstances', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'U', label: 'Arrived after registration closed', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'X', label: 'Non-compulsory school age pupil not required to attend', category: 'not_required', countsAsPresent: false, countsInPossible: false },
      { code: 'Y1', label: 'Unable to attend: transport normally provided not available', category: 'not_required', countsAsPresent: false, countsInPossible: false },
      { code: 'Z', label: 'Prospective pupil not on admission register', category: 'not_required', countsAsPresent: false, countsInPossible: false },
    ],
  },
  scotland_cfe: {
    id: 'scotland_cfe',
    name: 'Scotland (Education Scotland)',
    authority: 'Scottish Government — Included, Engaged and Involved (SEEMiS codes)',
    statutoryPupilIdLabel: 'SCN (Scottish Candidate Number)',
    safeguardingFramework: 'National Guidance for Child Protection in Scotland & GIRFEC',
    attendanceCodeVersion: 'SEEMiS-2024',
    yearGroups: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6'],
    notes: 'Primary (P1–P7) and Secondary (S1–S6) stages under Curriculum for Excellence.',
    attendanceCodes: [
      { code: 'PR', label: 'Present', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'LT', label: 'Late', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'ED', label: 'Educational visit / off-site', category: 'approved_educational', countsAsPresent: true, countsInPossible: true },
      { code: 'SL', label: 'Sickness with parental notification', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'MED', label: 'Medical / dental appointment', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'UN', label: 'Unexplained / Truancy', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'HO', label: 'Unauthorised family holiday', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
    ],
  },
  wales_cfw: {
    id: 'wales_cfw',
    name: 'Wales (Curriculum for Wales)',
    authority: 'Welsh Government — School Attendance Codes Guidance',
    statutoryPupilIdLabel: 'UPN (Welsh Statutory Return)',
    safeguardingFramework: 'Wales Safeguarding Procedures & ALN Code',
    attendanceCodeVersion: 'WG-2024',
    yearGroups: ['Reception', 'Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'Year 6', 'Year 7', 'Year 8', 'Year 9', 'Year 10', 'Year 11', 'Year 12', 'Year 13'],
    notes: 'Progression Steps 1–5; Additional Learning Needs (ALN) statutory terminology.',
    attendanceCodes: [
      { code: '/', label: 'Present (AM)', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: '\\', label: 'Present (PM)', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'L', label: 'Late before register closed', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'I', label: 'Illness', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'M', label: 'Medical appointment', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'O', label: 'Unauthorised absence', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
    ],
  },
  ni_de: {
    id: 'ni_de',
    name: 'Northern Ireland (DE)',
    authority: 'Department of Education Northern Ireland (C2k Attendance)',
    statutoryPupilIdLabel: 'DENI Pupil Reference',
    safeguardingFramework: 'Co-operating to Safeguard Children and Young People in NI (SBNI)',
    attendanceCodeVersion: 'DENI-2024',
    yearGroups: ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'Year 6', 'Year 7', 'Year 8', 'Year 9', 'Year 10', 'Year 11', 'Year 12', 'Year 13', 'Year 14'],
    notes: 'Year 1–7 Primary and Year 8–14 Post-Primary structure.',
    attendanceCodes: [
      { code: '/', label: 'Present', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'L', label: 'Late', category: 'present', countsAsPresent: true, countsInPossible: true },
      { code: 'I', label: 'Illness', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'M', label: 'Medical / dental', category: 'authorised_absence', countsAsPresent: false, countsInPossible: true },
      { code: 'U', label: 'Unauthorised absence', category: 'unauthorised_absence', countsAsPresent: false, countsInPossible: true },
    ],
  },
};

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  schoolId: string;
  role: UserRole;
  activePersonaId?: string;
  linkedPupilIds?: string[];
  verifiedByOffice: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface SchoolConfig {
  schoolId: string;
  name: string;
  crestUrl?: string;
  primaryColour?: string;
  accentColour?: string;
  jurisdiction: UkJurisdiction;
  academicYear: string;
  currentTerm: string;
  weekCycle: 'A' | 'B';
  established?: string;
  ownerUid: string;
}

export interface StaffMember {
  staffId: string;
  uid?: string;
  fullName: string;
  email: string;
  jobTitle: string;
  role: 'admin' | 'leadership' | 'dsl' | 'teacher' | 'office';
  department?: string;
  formGroup?: string;
  house?: string;
  active: boolean;
}

export interface Pupil {
  pupilId: string;
  upn?: string;
  admissionNumber: string;
  firstName: string;
  lastName: string;
  preferredName?: string;
  dob: string;
  yearGroup: string;
  formGroup: string;
  house: string;
  teachingGroups?: string[];
  enrolmentStatus: 'Enrolled' | 'Pending' | 'Transferred' | 'Leaver';
  enrolmentDate?: string;
  enrolmentHistory?: string[];
  medicalSummary?: string;
  allergyFlag?: boolean;
  allergyDetails?: string;
  accessibilitySummary?: string;
  sendSupportLevel?: string;
  sendAdjustments?: string;
  photoConsent?: boolean;
  tripBlanketConsent?: boolean;
  ownerUid: string;
}

export interface ContactRelationship {
  contactId: string;
  pupilId: string;
  fullName: string;
  relationship: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  postcode?: string;
  isEmergencyContact: boolean;
  hasPortalAccess: boolean;
  hasCollectionPermission: boolean;
  hasRecordAccess: boolean;
  isRestrictedContact: boolean;
  sensitiveAddress?: boolean;
  communicationPreference?: 'Email' | 'Portal' | 'SMS' | 'Letter';
  verifiedByOffice: boolean;
  verifiedAt?: string;
  linkedUserUid?: string;
}

export interface AdmissionRecord {
  applicationId: string;
  applicantName: string;
  dob: string;
  targetYearGroup: string;
  stage: 'enquiry' | 'application' | 'offer' | 'accepted' | 'enrolled' | 'transfer' | 'leaver';
  parentName: string;
  parentEmail: string;
  submittedAt?: string;
  duplicateFlag?: boolean;
  notes?: string;
}

export interface AttendanceSession {
  sessionId: string;
  pupilId: string;
  date: string;
  sessionType: 'AM' | 'PM' | 'LESSON';
  classCode?: string;
  code: string;
  codeVersion: string;
  minutesLate?: number;
  isAuthorised?: boolean;
  explanation?: string;
  recordedByUid: string;
  reconciledByOffice?: boolean;
  recordedAt?: string;
}

export interface AbsenceRequest {
  requestId: string;
  pupilId: string;
  submittedByUid: string;
  parentName: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'pending_review' | 'authorised' | 'unauthorised' | 'more_info_needed';
  schoolDecisionCode?: string;
  reviewedByName?: string;
  createdAt?: string;
}

export interface TimetableEntry {
  entryId: string;
  weekCycle: 'A' | 'B' | 'BOTH';
  dayOfWeek: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
  period: number;
  startTime: string;
  endTime: string;
  subject: string;
  classCode: string;
  teacherId?: string;
  teacherName: string;
  roomCode: string;
  roomCapacity?: number;
  pupilCount?: number;
  coverTeacherName?: string;
  roomChangeNote?: string;
  publishedVersion: string;
}

export interface HomeworkTask {
  homeworkId: string;
  classCode: string;
  subject: string;
  title: string;
  description: string;
  accessibleAlternative?: string;
  resourceTitle?: string;
  dueDate: string;
  teacherName: string;
  createdAt?: string;
}

export interface HomeworkSubmission {
  submissionId: string;
  homeworkId: string;
  pupilId: string;
  pupilName: string;
  status: 'not_started' | 'submitted' | 'marked';
  submissionText?: string;
  submissionFormat?: string;
  rawMark?: number;
  maxMark?: number;
  teacherJudgement?: string;
  calculatedGrade?: string;
  feedback?: string;
  moderationNote?: string;
  submittedAt?: string;
  markedAt?: string;
}

export interface BehaviourEvent {
  eventId: string;
  pupilId: string;
  pupilName: string;
  category: 'achievement' | 'behaviour_incident' | 'detention' | 'pastoral_action';
  title: string;
  factualDescription: string;
  location?: string;
  occurredAt?: string;
  authorName: string;
  authorUid: string;
  actionTaken?: string;
  reviewStatus: 'open' | 'reviewed' | 'amended';
  revisionNote?: string;
}

export interface SafeguardingConcern {
  concernId: string;
  pupilId: string;
  pupilInitials: string;
  category: string;
  factualSummary: string;
  chronologyNote?: string;
  reportedByUid: string;
  reportedByName: string;
  assignedDslName?: string;
  status: 'submitted_unacknowledged' | 'acknowledged' | 'assigned' | 'escalated_mash' | 'monitoring' | 'closed';
  reviewDate?: string;
  referralReference?: string;
  accessRestricted: boolean;
  acknowledgedAt?: string;
  createdAt?: string;
}

export interface MedicalPlan {
  planId: string;
  pupilId: string;
  pupilName: string;
  condition: string;
  carePlanSummary: string;
  emergencyProtocol: string;
  allergens?: string;
  verifiedByNurse: boolean;
  reviewDate?: string;
  lastIncidentNote?: string;
}

export interface TripOrActivity {
  tripId: string;
  kind: 'trip' | 'club' | 'meal_menu' | 'consultation';
  title: string;
  date: string;
  capacity: number;
  enrolledCount: number;
  costPence: number;
  currency: 'GBP';
  dietaryNotice?: string;
  allergenStatus?: 'verified' | 'unverified_provider_check_required';
  location?: string;
  leadStaffName?: string;
}

export interface ActivityBooking {
  bookingId: string;
  tripId: string;
  pupilId: string;
  pupilName: string;
  parentUid: string;
  idempotencyKey: string;
  consentGiven: boolean;
  consentSignedBy?: string;
  bookingStatus: 'pending_payment' | 'confirmed' | 'waitlisted' | 'refunded';
  paymentStatus: 'unpaid' | 'simulated_paid' | 'refunded';
  amountPence: number;
  currency: 'GBP';
  receiptRef?: string;
  dietarySelection?: string;
  createdAt?: string;
}

export interface Announcement {
  announcementId: string;
  title: string;
  body: string;
  audienceType: 'whole_school' | 'year_group' | 'class' | 'authorised_parents';
  audienceLabel: string;
  recipientCount: number;
  deliveryState: 'queued' | 'sent' | 'delivered';
  authorName: string;
  publishedAt: string;
  aiDraftReviewed?: boolean;
}

export interface AuditLog {
  logId: string;
  actorUid: string;
  actorName: string;
  actorRole: string;
  module: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  createdAt: string;
}

export interface AttendanceSummaryResult {
  possibleSessions: number;
  presentSessions: number;
  authorisedAbsences: number;
  unauthorisedAbsences: number;
  notRequiredSessions: number;
  unresolvedCount: number;
  percentage: number;
  persistentAbsenceRisk: boolean;
  codeVersion: string;
  formulaText: string;
}

export interface TimetableClash {
  type: 'teacher_clash' | 'room_clash' | 'capacity_overrun';
  severity: 'error' | 'warning';
  message: string;
  entryIds: string[];
}

export function formatGBP(pence: number): string {
  const pounds = (pence / 100).toFixed(2);
  return `£${pounds}`;
}

export function formatUkDate(isoOrDate: string | undefined): string {
  if (!isoOrDate) return '—';
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(isoOrDate);
  if (match) {
    return `${match[3]}/${match[2]}/${match[1]}`;
  }
  return isoOrDate;
}

export function calculateAttendanceSummary(
  sessions: AttendanceSession[],
  jurisdiction: UkJurisdiction,
  enrolledFromDate?: string,
): AttendanceSummaryResult {
  const spec = UK_JURISDICTIONS[jurisdiction] ?? UK_JURISDICTIONS.england_dfe;
  const codeMap = new Map<string, AttendanceCodeDef>();
  for (const def of spec.attendanceCodes) {
    codeMap.set(def.code, def);
  }

  let possibleSessions = 0;
  let presentSessions = 0;
  let authorisedAbsences = 0;
  let unauthorisedAbsences = 0;
  let notRequiredSessions = 0;
  let unresolvedCount = 0;

  for (const s of sessions) {
    if (s.sessionType === 'LESSON') continue; // Statutory roll-up uses AM/PM sessions
    if (enrolledFromDate && s.date < enrolledFromDate) continue;

    if (s.code === '?' || s.code === 'N' || s.code === '') {
      unresolvedCount += 1;
      possibleSessions += 1;
      continue;
    }

    const def = codeMap.get(s.code);
    if (!def) {
      unresolvedCount += 1;
      possibleSessions += 1;
      continue;
    }

    if (!def.countsInPossible) {
      notRequiredSessions += 1;
      continue;
    }

    possibleSessions += 1;
    if (def.countsAsPresent) {
      presentSessions += 1;
    } else if (def.category === 'authorised_absence') {
      authorisedAbsences += 1;
    } else if (def.category === 'unauthorised_absence') {
      unauthorisedAbsences += 1;
    }
  }

  const percentage =
    possibleSessions > 0 ? Math.round((presentSessions / possibleSessions) * 1000) / 10 : 100;

  return {
    possibleSessions,
    presentSessions,
    authorisedAbsences,
    unauthorisedAbsences,
    notRequiredSessions,
    unresolvedCount,
    percentage,
    persistentAbsenceRisk: possibleSessions > 0 && percentage < 90,
    codeVersion: spec.attendanceCodeVersion,
    formulaText: `Numerator (${presentSessions} present/approved AM+PM sessions) / Denominator (${possibleSessions} possible statutory sessions; ${notRequiredSessions} non-required excluded, ${unresolvedCount} unresolved)`,
  };
}

export function detectTimetableClashes(entries: TimetableEntry[]): TimetableClash[] {
  const clashes: TimetableClash[] = [];

  for (let i = 0; i < entries.length; i++) {
    const a = entries[i];
    if (a.roomCapacity && a.pupilCount && a.pupilCount > a.roomCapacity) {
      clashes.push({
        type: 'capacity_overrun',
        severity: 'error',
        message: `${a.classCode} (${a.pupilCount} pupils) exceeds capacity of ${a.roomCode} (${a.roomCapacity} seats) on ${a.dayOfWeek} P${a.period}.`,
        entryIds: [a.entryId],
      });
    }

    for (let j = i + 1; j < entries.length; j++) {
      const b = entries[j];
      if (a.dayOfWeek !== b.dayOfWeek || a.period !== b.period) continue;
      const cyclesOverlap = a.weekCycle === 'BOTH' || b.weekCycle === 'BOTH' || a.weekCycle === b.weekCycle;
      if (!cyclesOverlap) continue;

      const teacherA = a.coverTeacherName || a.teacherName;
      const teacherB = b.coverTeacherName || b.teacherName;
      if (teacherA === teacherB) {
        clashes.push({
          type: 'teacher_clash',
          severity: 'error',
          message: `Teacher clash: ${teacherA} scheduled for both ${a.classCode} and ${b.classCode} on ${a.dayOfWeek} Period ${a.period} (Week ${a.weekCycle}/${b.weekCycle}).`,
          entryIds: [a.entryId, b.entryId],
        });
      }

      if (a.roomCode === b.roomCode) {
        clashes.push({
          type: 'room_clash',
          severity: 'error',
          message: `Room clash: ${a.roomCode} double-booked for ${a.classCode} and ${b.classCode} on ${a.dayOfWeek} Period ${a.period}.`,
          entryIds: [a.entryId, b.entryId],
        });
      }
    }
  }

  return clashes;
}

export interface CsvImportRow {
  rowNumber: number;
  firstName: string;
  lastName: string;
  dob: string;
  targetYearGroup: string;
  parentName: string;
  parentEmail: string;
  errors: string[];
  duplicateMatchPupilId?: string;
}

export function validateAdmissionsCsv(
  csvText: string,
  existingPupils: Pick<Pupil, 'pupilId' | 'firstName' | 'lastName' | 'dob'>[],
): { validRows: CsvImportRow[]; invalidRows: CsvImportRow[]; duplicateCount: number } {
  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) {
    return { validRows: [], invalidRows: [], duplicateCount: 0 };
  }

  const startIndex = lines[0].toLowerCase().includes('firstname') ? 1 : 0;
  const validRows: CsvImportRow[] = [];
  const invalidRows: CsvImportRow[] = [];
  let duplicateCount = 0;

  for (let i = startIndex; i < lines.length; i++) {
    const cols = lines[i].split(',').map((c) => c.trim());
    const [firstName = '', lastName = '', dob = '', targetYearGroup = '', parentName = '', parentEmail = ''] = cols;
    const errors: string[] = [];

    if (!firstName) errors.push('Missing first name');
    if (!lastName) errors.push('Missing surname');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dob)) errors.push('DOB must be YYYY-MM-DD');
    if (!targetYearGroup) errors.push('Missing target year group');
    if (!parentName) errors.push('Missing parent/carer name');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parentEmail)) errors.push('Invalid parent email');

    const dup = existingPupils.find(
      (p) =>
        p.firstName.toLowerCase() === firstName.toLowerCase() &&
        p.lastName.toLowerCase() === lastName.toLowerCase() &&
        p.dob === dob,
    );
    if (dup) duplicateCount += 1;

    const row: CsvImportRow = {
      rowNumber: i + 1,
      firstName,
      lastName,
      dob,
      targetYearGroup,
      parentName,
      parentEmail,
      errors,
      duplicateMatchPupilId: dup?.pupilId,
    };

    if (errors.length === 0) {
      validRows.push(row);
    } else {
      invalidRows.push(row);
    }
  }

  return { validRows, invalidRows, duplicateCount };
}

export function stripPiiForAi(input: string): string {
  return input
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[REDACTED_EMAIL]')
    .replace(/\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b/gi, '[REDACTED_POSTCODE]')
    .replace(/\b(?:\+44|0)\d[\d\s]{8,12}\b/g, '[REDACTED_PHONE]')
    .replace(/\b[A-Z]\d{12}\b/g, '[REDACTED_UPN]');
}
