import { describe, expect, it } from 'vitest';
import {
  AttendanceSession,
  TimetableEntry,
  calculateAttendanceSummary,
  detectTimetableClashes,
  formatGBP,
  formatUkDate,
  stripPiiForAi,
  validateAdmissionsCsv,
} from './school-domain';

describe('AUREOM SCHOOLS Domain Logic', () => {
  it('calculates England DfE attendance with visible numerator, denominator, exclusions, and unresolved marks', () => {
    const sessions: AttendanceSession[] = [
      { sessionId: '1', pupilId: 'p1', date: '2026-11-23', sessionType: 'AM', code: '/', codeVersion: 'DfE-2024-v2', recordedByUid: 'u1' },
      { sessionId: '2', pupilId: 'p1', date: '2026-11-23', sessionType: 'PM', code: 'L', codeVersion: 'DfE-2024-v2', recordedByUid: 'u1' },
      { sessionId: '3', pupilId: 'p1', date: '2026-11-24', sessionType: 'AM', code: 'I', codeVersion: 'DfE-2024-v2', recordedByUid: 'u1' },
      { sessionId: '4', pupilId: 'p1', date: '2026-11-24', sessionType: 'PM', code: '?', codeVersion: 'DfE-2024-v2', recordedByUid: 'u1' },
      { sessionId: '5', pupilId: 'p1', date: '2026-11-25', sessionType: 'AM', code: 'Y1', codeVersion: 'DfE-2024-v2', recordedByUid: 'u1' },
      { sessionId: '6', pupilId: 'p1', date: '2026-11-25', sessionType: 'LESSON', code: '/', codeVersion: 'DfE-2024-v2', recordedByUid: 'u1' },
    ];

    const summary = calculateAttendanceSummary(sessions, 'england_dfe');
    expect(summary.possibleSessions).toBe(4); // Y1 excluded, LESSON excluded from statutory AM/PM denominator
    expect(summary.presentSessions).toBe(2); // '/' and 'L'
    expect(summary.authorisedAbsences).toBe(1); // 'I'
    expect(summary.unresolvedCount).toBe(1); // '?'
    expect(summary.notRequiredSessions).toBe(1); // 'Y1'
    expect(summary.percentage).toBe(50);
  });

  it('detects teacher clashes, room clashes, and room capacity overruns before timetable publish', () => {
    const entries: TimetableEntry[] = [
      {
        entryId: 'e1',
        weekCycle: 'A',
        dayOfWeek: 'Monday',
        period: 1,
        startTime: '09:05',
        endTime: '10:05',
        subject: 'Mathematics',
        classCode: '8B-Ma1',
        teacherName: 'Mr Daniel Greenwood',
        roomCode: 'M204',
        roomCapacity: 30,
        pupilCount: 28,
        publishedVersion: 'v1',
      },
      {
        entryId: 'e2',
        weekCycle: 'BOTH',
        dayOfWeek: 'Monday',
        period: 1,
        startTime: '09:05',
        endTime: '10:05',
        subject: 'Mathematics',
        classCode: '9C-Ma2',
        teacherName: 'Mr Daniel Greenwood',
        roomCode: 'M204',
        roomCapacity: 25,
        pupilCount: 29,
        publishedVersion: 'v1',
      },
    ];

    const clashes = detectTimetableClashes(entries);
    expect(clashes.some((c) => c.type === 'teacher_clash')).toBe(true);
    expect(clashes.some((c) => c.type === 'room_clash')).toBe(true);
    expect(clashes.some((c) => c.type === 'capacity_overrun')).toBe(true);
  });

  it('validates bulk admissions CSV and flags duplicates against existing pupils', () => {
    const csv = [
      'firstName,lastName,dob,targetYearGroup,parentName,parentEmail',
      'Oliver,Thornton,2013-05-14,Year 8,Sarah Thornton,sarah@example.co.uk',
      'Noah,Sutcliffe,2014-03-21,Year 7,Emma Sutcliffe,emma@example.co.uk',
      'Invalid,Row,14-05-2013,Year 7,Bad,bad-email',
    ].join('\n');

    const res = validateAdmissionsCsv(csv, [
      { pupilId: 'pup_oliver', firstName: 'Oliver', lastName: 'Thornton', dob: '2013-05-14' },
    ]);

    expect(res.validRows.length).toBe(2);
    expect(res.invalidRows.length).toBe(1);
    expect(res.duplicateCount).toBe(1);
    expect(res.validRows[0].duplicateMatchPupilId).toBe('pup_oliver');
  });

  it('formats GBP currency and UK dates, and strips pupil PII prior to AI prompts', () => {
    expect(formatGBP(1850)).toBe('£18.50');
    expect(formatUkDate('2026-11-24')).toBe('24/11/2026');
    const redacted = stripPiiForAi('Contact sarah@example.co.uk at LS29 8AW on 07700 900412 UPN U815202104012');
    expect(redacted).not.toContain('sarah@example.co.uk');
    expect(redacted).not.toContain('LS29 8AW');
    expect(redacted).not.toContain('07700 900412');
    expect(redacted).not.toContain('U815202104012');
  });
});
