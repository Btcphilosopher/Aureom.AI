import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HomeworkSubmission, HomeworkTask, formatUkDate } from '../../shared/school-domain';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-learning-assessment',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-lg p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-xl font-semibold text-slate-900">Teaching, Homework &amp; Assessment</h1>
          <p class="text-sm text-slate-600 mt-1">
            Raw marks, teacher judgements, calculated grades, and moderation notes are stored separately. Accessible non-file options are included on every task.
          </p>
        </div>
        @if (isStaff()) {
          <button
            type="button"
            (click)="showCreateHw.set(!showCreateHw())"
            class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer whitespace-nowrap"
          >
            {{ showCreateHw() ? 'Close Task Publisher' : 'Set Homework & Resource' }}
          </button>
        }
      </div>

      @if (showCreateHw() && isStaff()) {
        <section class="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <div class="flex flex-wrap items-center justify-between gap-3">
            <h2 class="font-display text-base font-semibold text-slate-900">Publish Lesson Resource &amp; Homework</h2>
            <button
              type="button"
              (click)="draftLessonWithAi()"
              [disabled]="aiLoading()"
              class="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded text-slate-800 hover:bg-slate-50 cursor-pointer disabled:opacity-60"
            >
              {{ aiLoading() ? 'Drafting...' : 'Optional AI Resource Draft (Staff Review Required)' }}
            </button>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Class Code</span>
              <input [(ngModel)]="hwClassCode" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Subject</span>
              <input [(ngModel)]="hwSubject" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Due Date</span>
              <input type="date" [(ngModel)]="hwDueDate" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded font-mono-tabular" />
            </label>
          </div>
          <label class="block text-sm">
            <span class="text-xs font-medium text-slate-700">Title</span>
            <input [(ngModel)]="hwTitle" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
          </label>
          <label class="block text-sm">
            <span class="text-xs font-medium text-slate-700">Instructions &amp; Lesson Resource Summary</span>
            <textarea [(ngModel)]="hwDescription" rows="3" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded"></textarea>
          </label>
          <label class="block text-sm">
            <span class="text-xs font-medium text-slate-700">Accessible Alternative (Required for non-file access)</span>
            <input [(ngModel)]="hwAccessibleAlt" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
          </label>

          @if (aiDraftBanner()) {
            <p class="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded px-3 py-2">
              {{ aiDraftBanner() }}
            </p>
          }

          <button
            type="button"
            (click)="publishHomework()"
            class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer"
          >
            Publish Homework to Class
          </button>
        </section>
      }

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Homework & Resources List -->
        <section class="lg:col-span-6 bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <h2 class="font-display text-base font-semibold text-slate-900">Homework &amp; Lesson Resources</h2>
          <div class="divide-y divide-slate-200">
            @for (task of store.homework(); track task.homeworkId) {
              <div class="py-4 space-y-2">
                <div class="flex items-start justify-between gap-3">
                  <div>
                    <h3 class="text-sm font-semibold text-slate-900">{{ task.title }}</h3>
                    <p class="text-xs text-slate-500">
                      {{ task.subject }} ({{ task.classCode }}) · Set by {{ task.teacherName }} · Due <span class="font-mono-tabular">{{ formatDate(task.dueDate) }}</span>
                    </p>
                  </div>
                </div>
                <p class="text-sm text-slate-700">{{ task.description }}</p>
                @if (task.accessibleAlternative) {
                  <p class="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded p-2.5">
                    <strong>Accessible Alternative:</strong> {{ task.accessibleAlternative }}
                  </p>
                }

                @if (role() === 'pupil' || role() === 'parent') {
                  <div class="pt-2 space-y-2">
                    <textarea
                      [(ngModel)]="pupilReplyText"
                      rows="2"
                      placeholder="Write text submission or summary of exercise book work..."
                      class="w-full p-2.5 text-xs border border-slate-300 rounded"
                    ></textarea>
                    <button
                      type="button"
                      (click)="submitPupilWork(task)"
                      class="px-3 py-1.5 text-xs font-medium bg-[#0F2744] text-white rounded cursor-pointer"
                    >
                      Submit Homework (Text Option)
                    </button>
                  </div>
                }
              </div>
            }
          </div>
        </section>

        <!-- Marking, Feedback & Pupil Assessment Records -->
        <section class="lg:col-span-6 bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="font-display text-base font-semibold text-slate-900">Submissions, Feedback &amp; Assessment</h2>
            @if (isStaff()) {
              <button
                type="button"
                (click)="draftReportWithAi()"
                [disabled]="aiLoading()"
                class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer"
              >
                AI Report Comment Draft
              </button>
            }
          </div>

          <div class="divide-y divide-slate-200">
            @for (sub of store.visibleSubmissions(); track sub.submissionId) {
              <div class="py-4 space-y-2 text-sm">
                <div class="flex items-center justify-between">
                  <span class="font-semibold text-slate-900">{{ sub.pupilName }}</span>
                  <span class="text-xs font-medium" [class.text-emerald-700]="sub.status === 'marked'" [class.text-amber-700]="sub.status === 'submitted'">
                    {{ sub.status }} ({{ sub.submissionFormat || 'Text' }})
                  </span>
                </div>
                <p class="text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded p-2.5">
                  {{ sub.submissionText }}
                </p>

                @if (sub.status === 'marked') {
                  <div class="grid grid-cols-3 gap-2 text-xs pt-1">
                    <div>
                      <span class="text-slate-500">Raw Mark:</span>
                      <span class="font-mono-tabular font-semibold text-slate-900"> {{ sub.rawMark }}/{{ sub.maxMark }}</span>
                    </div>
                    <div>
                      <span class="text-slate-500">Judgement:</span>
                      <span class="font-medium text-slate-900"> {{ sub.teacherJudgement }}</span>
                    </div>
                    <div>
                      <span class="text-slate-500">Calculated:</span>
                      <span class="font-medium text-slate-900"> {{ sub.calculatedGrade }}</span>
                    </div>
                  </div>
                  <p class="text-xs text-slate-700"><strong>Teacher Feedback:</strong> {{ sub.feedback }}</p>
                  @if (sub.moderationNote) {
                    <p class="text-xs text-slate-500">Moderation: {{ sub.moderationNote }}</p>
                  }
                } @else if (isStaff()) {
                  <div class="pt-2 space-y-2 border-t border-slate-100">
                    <div class="grid grid-cols-3 gap-2 text-xs">
                      <input type="number" [(ngModel)]="markRaw" placeholder="Raw mark" class="px-2 py-1.5 border border-slate-300 rounded font-mono-tabular" />
                      <input [(ngModel)]="markJudgement" placeholder="Judgement (e.g. Secure)" class="px-2 py-1.5 border border-slate-300 rounded" />
                      <input [(ngModel)]="markGrade" placeholder="Calculated band" class="px-2 py-1.5 border border-slate-300 rounded" />
                    </div>
                    <textarea [(ngModel)]="markFeedback" rows="2" placeholder="Constructive written feedback..." class="w-full p-2 text-xs border border-slate-300 rounded"></textarea>
                    <button
                      type="button"
                      (click)="saveMarking(sub)"
                      class="px-3 py-1.5 text-xs font-medium bg-[#0F2744] text-white rounded cursor-pointer"
                    >
                      Save Mark &amp; Feedback
                    </button>
                  </div>
                }
              </div>
            } @empty {
              <p class="text-sm text-slate-500">No submissions recorded yet.</p>
            }
          </div>

          @if (reportDraftOutput()) {
            <div class="mt-4 p-3 bg-slate-50 border border-slate-200 rounded text-xs space-y-1">
              <div class="font-semibold text-slate-900">AI-Assisted Report Draft (Review Before Publishing — PII Redacted)</div>
              <p class="text-slate-700 whitespace-pre-line">{{ reportDraftOutput() }}</p>
            </div>
          }
        </section>
      </div>
    </div>
  `,
})
export class LearningAssessmentComponent {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);
  private readonly api = inject(ApiService);

  readonly role = this.auth.effectiveRole;
  readonly isStaff = computed(() =>
    ['admin', 'leadership', 'dsl', 'teacher', 'office'].includes(this.role()),
  );

  readonly showCreateHw = signal(false);
  readonly aiLoading = signal(false);
  readonly aiDraftBanner = signal('');
  readonly reportDraftOutput = signal('');

  hwClassCode = '8B-Ma1';
  hwSubject = 'Mathematics';
  hwDueDate = '2026-12-02';
  hwTitle = 'Simultaneous Linear Equations — Reasoning Problems';
  hwDescription = 'Solve problems 1–6 using elimination or substitution, showing clear algebraic reasoning.';
  hwAccessibleAlt = 'Write step-by-step plain text explanations for 3 problems or use the digital step template.';

  pupilReplyText = '';
  markRaw = 17;
  markJudgement = 'Secure';
  markGrade = 'Expected Standard (8B)';
  markFeedback = 'Well-structured balancing steps. Check sign inversion on question 4.';

  async draftLessonWithAi(): Promise<void> {
    this.aiLoading.set(true);
    this.aiDraftBanner.set('');
    try {
      const res = await this.api.requestAiAssist({
        mode: 'lesson_resource',
        context: `${this.hwSubject} (${this.hwClassCode})`,
        prompt: this.hwTitle || 'Linear equations practice for Year 8',
      });
      this.hwDescription = res.draft;
      this.aiDraftBanner.set('AI draft inserted above. Staff review and edit is required before publishing.');
    } catch (err) {
      this.aiDraftBanner.set(err instanceof Error ? err.message : 'AI draft unavailable.');
    } finally {
      this.aiLoading.set(false);
    }
  }

  async draftReportWithAi(): Promise<void> {
    this.aiLoading.set(true);
    try {
      const res = await this.api.requestAiAssist({
        mode: 'report_draft',
        prompt: 'Year 8 Mathematics pupil demonstrates strong algebraic fluency, supports peers constructively, and benefits from checking negative sign steps.',
      });
      this.reportDraftOutput.set(res.draft);
    } catch (err) {
      this.reportDraftOutput.set(err instanceof Error ? err.message : 'AI report draft unavailable.');
    } finally {
      this.aiLoading.set(false);
    }
  }

  async publishHomework(): Promise<void> {
    if (!this.hwTitle.trim() || !this.hwDescription.trim()) return;
    const task: HomeworkTask = {
      homeworkId: `hw_${Date.now().toString(36)}`,
      classCode: this.hwClassCode.trim(),
      subject: this.hwSubject.trim(),
      title: this.hwTitle.trim(),
      description: this.hwDescription.trim(),
      accessibleAlternative: this.hwAccessibleAlt.trim(),
      dueDate: this.hwDueDate,
      teacherName: this.auth.effectivePersonName(),
      createdAt: new Date().toISOString(),
    };
    await this.store.publishHomework(task);
    this.showCreateHw.set(false);
  }

  async submitPupilWork(task: HomeworkTask): Promise<void> {
    const pupil = this.store.visiblePupils()[0];
    if (!pupil || !this.pupilReplyText.trim()) return;
    const sub: HomeworkSubmission = {
      submissionId: `sub_${task.homeworkId}_${pupil.pupilId}`,
      homeworkId: task.homeworkId,
      pupilId: pupil.pupilId,
      pupilName: `${pupil.firstName} ${pupil.lastName}`,
      status: 'submitted',
      submissionText: this.pupilReplyText.trim(),
      submissionFormat: 'Accessible Text Entry',
      submittedAt: new Date().toISOString(),
    };
    await this.store.submitHomework(sub);
    this.pupilReplyText = '';
  }

  async saveMarking(sub: HomeworkSubmission): Promise<void> {
    await this.store.markSubmission(sub.submissionId, {
      rawMark: Number(this.markRaw),
      maxMark: 20,
      teacherJudgement: this.markJudgement,
      calculatedGrade: this.markGrade,
      feedback: this.markFeedback,
      moderationNote: `Marked by ${this.auth.effectivePersonName()} on ${formatUkDate(new Date().toISOString())}`,
    });
  }

  formatDate(d?: string): string {
    return formatUkDate(d);
  }
}
