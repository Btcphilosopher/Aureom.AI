import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TimetableClash, TimetableEntry } from '../../shared/school-domain';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-timetable-cover',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-lg p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-xl font-semibold text-slate-900">Timetables &amp; Cover Management</h1>
          <p class="text-sm text-slate-600 mt-1">
            Week A/B cycle · Published version <span class="font-mono-tabular">2026-Aut-v3</span> · Clash detection runs before publishing.
          </p>
        </div>
        <div class="flex items-center gap-2">
          <div class="flex items-center gap-1 p-1 bg-slate-100 rounded">
            <button
              type="button"
              (click)="weekFilter.set('A')"
              class="px-3 py-1.5 text-xs font-medium rounded cursor-pointer"
              [class.bg-white]="weekFilter() === 'A'"
              [class.text-slate-900]="weekFilter() === 'A'"
              [class.shadow-sm]="weekFilter() === 'A'"
            >
              Week A
            </button>
            <button
              type="button"
              (click)="weekFilter.set('B')"
              class="px-3 py-1.5 text-xs font-medium rounded cursor-pointer"
              [class.bg-white]="weekFilter() === 'B'"
              [class.text-slate-900]="weekFilter() === 'B'"
              [class.shadow-sm]="weekFilter() === 'B'"
            >
              Week B
            </button>
          </div>
          @if (canSchedule()) {
            <button
              type="button"
              (click)="showEditor.set(!showEditor())"
              class="px-4 py-2 text-xs font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer whitespace-nowrap"
            >
              {{ showEditor() ? 'Close Scheduler' : 'Schedule Lesson / Cover' }}
            </button>
          }
        </div>
      </div>

      @if (showEditor() && canSchedule()) {
        <section class="bg-white border border-slate-200 rounded-lg p-6">
          <h2 class="font-display text-base font-semibold text-slate-900 mb-4">
            Manual Schedule &amp; Clash Verification
          </h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Day</span>
              <select [(ngModel)]="newDay" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                @for (d of days; track d) {
                  <option [value]="d">{{ d }}</option>
                }
              </select>
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Period (1–5)</span>
              <input type="number" min="1" max="5" [(ngModel)]="newPeriod" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded font-mono-tabular" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Subject &amp; Class</span>
              <input [(ngModel)]="newClassCode" placeholder="8B-Ma1" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Teacher</span>
              <input [(ngModel)]="newTeacher" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Room Code</span>
              <input [(ngModel)]="newRoom" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Room Capacity / Class Size</span>
              <div class="mt-1 flex gap-2">
                <input type="number" [(ngModel)]="newCapacity" class="w-1/2 px-3 py-2 border border-slate-300 rounded font-mono-tabular" />
                <input type="number" [(ngModel)]="newPupilCount" class="w-1/2 px-3 py-2 border border-slate-300 rounded font-mono-tabular" />
              </div>
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Cover Teacher (Optional)</span>
              <input [(ngModel)]="newCover" placeholder="Leave blank if normal teacher" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Room Change Notice</span>
              <input [(ngModel)]="newRoomNote" placeholder="Optional notice to pupils" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
          </div>

          <div class="mt-4 flex flex-wrap items-center gap-3">
            <button
              type="button"
              (click)="validateAndPublish()"
              class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer"
            >
              Check Clashes &amp; Publish Slot
            </button>
            @if (publishStatus()) {
              <span class="text-xs text-emerald-700 font-medium">{{ publishStatus() }}</span>
            }
          </div>

          @if (detectedClashes().length > 0) {
            <div class="mt-4 bg-red-50 border border-red-200 rounded p-4 space-y-1.5 text-xs text-red-800">
              <div class="font-semibold">Publish Blocked — Clashes Detected:</div>
              @for (clash of detectedClashes(); track clash.message) {
                <div>{{ clash.message }}</div>
              }
            </div>
          }
        </section>
      }

      <!-- Timetable Grid -->
      <section class="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
              <tr>
                <th class="px-6 py-3 font-medium">Day &amp; Period</th>
                <th class="px-4 py-3 font-medium">Subject &amp; Class</th>
                <th class="px-4 py-3 font-medium">Teacher / Cover</th>
                <th class="px-4 py-3 font-medium">Room &amp; Capacity</th>
                <th class="px-6 py-3 font-medium">Notices</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
              @for (slot of filteredSlots(); track slot.entryId) {
                <tr class="hover:bg-slate-50">
                  <td class="px-6 py-3.5 font-mono-tabular text-xs text-slate-700">
                    <div class="font-semibold text-slate-900">{{ slot.dayOfWeek }} · P{{ slot.period }}</div>
                    <div>{{ slot.startTime }}–{{ slot.endTime }} (Wk {{ slot.weekCycle }})</div>
                  </td>
                  <td class="px-4 py-3.5">
                    <div class="font-medium text-slate-900">{{ slot.subject }}</div>
                    <div class="text-xs text-slate-500 font-mono-tabular">{{ slot.classCode }}</div>
                  </td>
                  <td class="px-4 py-3.5 text-xs">
                    @if (slot.coverTeacherName) {
                      <div class="text-amber-800 font-medium">{{ slot.coverTeacherName }}</div>
                      <div class="text-slate-500 line-through">{{ slot.teacherName }}</div>
                    } @else {
                      <div class="text-slate-800">{{ slot.teacherName }}</div>
                    }
                  </td>
                  <td class="px-4 py-3.5 font-mono-tabular text-xs text-slate-700">
                    {{ slot.roomCode }} ({{ slot.pupilCount ?? 28 }}/{{ slot.roomCapacity ?? 30 }})
                  </td>
                  <td class="px-6 py-3.5 text-xs text-slate-600">
                    {{ slot.roomChangeNote || 'Published (' + slot.publishedVersion + ')' }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class TimetableCoverComponent {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);
  private readonly api = inject(ApiService);

  readonly weekFilter = signal<'A' | 'B'>('A');
  readonly showEditor = signal(false);
  readonly detectedClashes = signal<TimetableClash[]>([]);
  readonly publishStatus = signal('');

  readonly days: ('Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday')[] = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
  ];

  newDay: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' = 'Monday';
  newPeriod = 1;
  newClassCode = '8B-Ma1';
  newTeacher = 'Mr Daniel Greenwood';
  newRoom = 'M204';
  newCapacity = 30;
  newPupilCount = 28;
  newCover = '';
  newRoomNote = '';

  readonly canSchedule = computed(() =>
    ['admin', 'office', 'leadership'].includes(this.auth.effectiveRole()),
  );

  readonly filteredSlots = computed(() =>
    this.store
      .timetableEntries()
      .filter((t) => t.weekCycle === this.weekFilter() || t.weekCycle === 'BOTH')
      .sort((a, b) => this.days.indexOf(a.dayOfWeek) - this.days.indexOf(b.dayOfWeek) || a.period - b.period),
  );

  async validateAndPublish(): Promise<void> {
    this.detectedClashes.set([]);
    this.publishStatus.set('');
    const candidate: TimetableEntry = {
      entryId: `tt_${Date.now().toString(36)}`,
      weekCycle: this.weekFilter(),
      dayOfWeek: this.newDay,
      period: Number(this.newPeriod),
      startTime: '09:05',
      endTime: '10:05',
      subject: this.newClassCode.includes('Ma') ? 'Mathematics' : 'Curriculum Lesson',
      classCode: this.newClassCode.trim(),
      teacherName: this.newTeacher.trim(),
      roomCode: this.newRoom.trim(),
      roomCapacity: Number(this.newCapacity),
      pupilCount: Number(this.newPupilCount),
      coverTeacherName: this.newCover.trim() || undefined,
      roomChangeNote: this.newRoomNote.trim() || undefined,
      publishedVersion: '2026-Aut-v4',
    };

    const validation = await this.api.validateTimetable([...this.store.timetableEntries(), candidate]);
    if (!validation.valid) {
      this.detectedClashes.set(validation.clashes);
      return;
    }

    await this.store.saveTimetableEntry(candidate);
    this.publishStatus.set(`No clashes detected. Published ${candidate.classCode} on ${candidate.dayOfWeek} P${candidate.period}.`);
  }
}
