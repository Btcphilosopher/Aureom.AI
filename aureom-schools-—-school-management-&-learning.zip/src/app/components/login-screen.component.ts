import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login-screen',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-slate-50 flex flex-col justify-between">
      <header class="bg-[#0F2744] text-white border-b border-slate-800">
        <div class="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <div class="flex items-center gap-3 whitespace-nowrap shrink-0">
            <img
              src="/src/assets/images/pennine_academy_crest_1795509106921.jpg"
              alt="Pennine Academy crest"
              referrerPolicy="no-referrer"
              class="w-9 h-9 rounded object-cover bg-white p-0.5"
            />
            <span class="font-display font-semibold text-base tracking-tight text-white">
              AUREOM SCHOOLS
            </span>
          </div>
          <nav class="hidden md:flex items-center gap-6 text-sm text-slate-200">
            <span class="whitespace-nowrap shrink-0">Pennine Academy</span>
            <span class="text-slate-400" aria-hidden="true">/</span>
            <span class="whitespace-nowrap shrink-0">UK Jurisdictions</span>
            <span class="text-slate-400" aria-hidden="true">/</span>
            <span class="whitespace-nowrap shrink-0">Safeguarding &amp; Governance</span>
          </nav>
          <button
            type="button"
            (click)="auth.signInWithGoogle()"
            [disabled]="auth.signingIn()"
            class="px-4 py-2 text-sm font-medium bg-[#B4832C] hover:bg-[#9c7023] text-white rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
          >
            {{ auth.signingIn() ? 'Signing in...' : 'Sign in with Google' }}
          </button>
        </div>
      </header>

      <main class="max-w-6xl mx-auto w-full px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <section class="lg:col-span-6 bg-white border border-slate-200 rounded-lg p-8 flex flex-col justify-between">
          <div>
            <p class="text-xs font-medium text-slate-500 mb-3">
              Pennine Academy · Yorkshire, England · DfE 2024/26 Regulations
            </p>
            <h1 class="font-display text-3xl lg:text-4xl font-semibold text-slate-900 tracking-tight leading-tight mb-4">
              School management, attendance, safeguarding, and family portal.
            </h1>
            <p class="text-base text-slate-600 leading-relaxed mb-6">
              A unified institutional workspace designed for English schools with configurable support for Scotland (Education Scotland / SEEMiS), Wales (Curriculum for Wales), and Northern Ireland (DE).
            </p>

            <div class="border-t border-slate-200 pt-6 space-y-3 text-sm text-slate-700">
              <div class="flex items-start gap-3">
                <span class="material-icons text-[#0F2744] text-lg mt-0.5" aria-hidden="true">verified_user</span>
                <div>
                  <span class="font-medium text-slate-900">Server-enforced permissions &amp; tenant isolation</span>
                  <p class="text-slate-600">Contact relationships, emergency contacts, parent portals, and safeguarding records are strictly separated.</p>
                </div>
              </div>
              <div class="flex items-start gap-3">
                <span class="material-icons text-[#0F2744] text-lg mt-0.5" aria-hidden="true">rule</span>
                <div>
                  <span class="font-medium text-slate-900">Transparent statutory calculations</span>
                  <p class="text-slate-600">Versioned attendance codes preserve definitions effective on the recorded date with visible numerators and denominators.</p>
                </div>
              </div>
              <div class="flex items-start gap-3">
                <span class="material-icons text-[#0F2744] text-lg mt-0.5" aria-hidden="true">shield</span>
                <div>
                  <span class="font-medium text-slate-900">Separately permissioned safeguarding</span>
                  <p class="text-slate-600">Concerns route directly to the Designated Safeguarding Lead with explicit acknowledgement and access audit logs.</p>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-8 pt-6 border-t border-slate-200">
            @if (auth.authError()) {
              <div class="mb-4 p-3 border border-red-200 bg-red-50 text-red-800 text-sm rounded">
                {{ auth.authError() }}
              </div>
            }
            <button
              type="button"
              (click)="auth.signInWithGoogle()"
              [disabled]="auth.signingIn()"
              class="w-full sm:w-auto px-6 py-3 bg-[#0F2744] hover:bg-[#17365d] text-white font-medium text-sm rounded transition-colors flex items-center justify-center gap-3 cursor-pointer disabled:opacity-60"
            >
              <span class="material-icons text-lg" aria-hidden="true">login</span>
              <span>{{ auth.signingIn() ? 'Connecting account...' : 'Sign in with Organisational / Google Account' }}</span>
            </button>
            <p class="mt-3 text-xs text-slate-500">
              Demonstration environment uses synthetic Pennine Academy &amp; Lothian Brae High records. Authorised administrator accounts can switch across Staff, DSL, Office, Parent, and Pupil portals after sign-in.
            </p>
          </div>
        </section>

        <section class="lg:col-span-6 bg-white border border-slate-200 rounded-lg overflow-hidden flex flex-col">
          <div class="relative h-64 lg:h-80 bg-slate-200">
            <img
              src="/src/assets/images/pennine_campus_banner_1795509109239.jpg"
              alt="Pennine Academy limestone campus courtyard"
              referrerPolicy="no-referrer"
              class="w-full h-full object-cover"
            />
          </div>
          <div class="p-8 flex-1 flex flex-col justify-between">
            <div>
              <h2 class="font-display text-lg font-semibold text-slate-900 mb-2">
                Implemented Controls vs. Independent Statutory Sign-Off
              </h2>
              <p class="text-sm text-slate-600 leading-relaxed mb-4">
                Before production school deployment, governors and Data Protection Officers must complete independent DPIA, KCSIE safeguarding audit, DfE MIS/CTF XML accreditation, and UK GDPR processor agreements.
              </p>
            </div>
            <div class="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200 text-xs text-slate-600">
              <div>
                <div class="font-medium text-slate-900">Primary Jurisdiction</div>
                <div>England (DfE 2024/26)</div>
              </div>
              <div>
                <div class="font-medium text-slate-900">Currency &amp; Locale</div>
                <div>GBP (£) · DD/MM/YYYY</div>
              </div>
              <div>
                <div class="font-medium text-slate-900">Payments Integration</div>
                <div>Simulated Provider (Idempotent)</div>
              </div>
              <div>
                <div class="font-medium text-slate-900">AI Assistance</div>
                <div>Optional Drafts · Staff Review Gate</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer class="border-t border-slate-200 bg-white">
        <div class="max-w-6xl mx-auto px-6 py-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <span>AUREOM SCHOOLS · Synthetic Demonstration Platform (Pennine Academy)</span>
          <span>British English · Server-Verified Role Access</span>
        </div>
      </footer>
    </div>
  `,
})
export class LoginScreenComponent {
  readonly auth = inject(AuthService);
}
