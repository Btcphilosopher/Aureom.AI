import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CsvImportRow, Pupil, formatUkDate } from '../../shared/school-domain';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-admissions-structure',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-lg p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-xl font-semibold text-slate-900">Admissions &amp; Academic Structure</h1>
          <p class="text-sm text-slate-600 mt-1">
            {{ store.currentJurisdiction().name }} · Statutory ID: {{ store.currentJurisdiction().statutoryPupilIdLabel }}
          </p>
        </div>
        <button
          type="button"
          (click)="runTransition()"
          [disabled]="transitioning()"
          class="px-4 py-2 text-sm font-medium border border-slate-300 rounded text-slate-800 hover:bg-slate-50 cursor-pointer whitespace-nowrap disabled:opacity-60"
        >
          {{ transitioning() ? 'Transitioning...' : 'Run Academic Year Transition' }}
        </button>
      </div>

      @if (transitionNote()) {
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-3 rounded text-sm">
          {{ transitionNote() }}
        </div>
      }

      <!-- Pipeline Table -->
      <section class="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 class="font-display text-base font-semibold text-slate-900">
            Admissions, Transfers &amp; Leavers Pipeline
          </h2>
          <span class="text-xs text-slate-500">{{ store.admissions().length }} active records</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
              <tr>
                <th class="px-6 py-3 font-medium">Applicant</th>
                <th class="px-4 py-3 font-medium">DOB</th>
                <th class="px-4 py-3 font-medium">Target Year</th>
                <th class="px-4 py-3 font-medium">Parent / Carer</th>
                <th class="px-4 py-3 font-medium">Stage &amp; Duplicate Check</th>
                <th class="px-6 py-3 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
              @for (adm of store.admissions(); track adm.applicationId) {
                <tr class="hover:bg-slate-50">
                  <td class="px-6 py-3.5 font-medium text-slate-900">{{ adm.applicantName }}</td>
                  <td class="px-4 py-3.5 font-mono-tabular text-slate-600">{{ formatDate(adm.dob) }}</td>
                  <td class="px-4 py-3.5 text-slate-700">{{ adm.targetYearGroup }}</td>
                  <td class="px-4 py-3.5 text-slate-600">
                    <div>{{ adm.parentName }}</div>
                    <div class="text-xs text-slate-500">{{ adm.parentEmail }}</div>
                  </td>
                  <td class="px-4 py-3.5 text-xs">
                    <span class="font-medium text-slate-800">{{ adm.stage }}</span>
                    @if (adm.duplicateFlag) {
                      <div class="text-amber-700 font-medium mt-0.5">Duplicate match flagged</div>
                    }
                  </td>
                  <td class="px-6 py-3.5 text-right">
                    @if (adm.stage !== 'enrolled' && !adm.duplicateFlag) {
                      <button
                        type="button"
                        (click)="enrolFromAdmission(adm.applicationId)"
                        class="px-3 py-1.5 text-xs font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer"
                      >
                        Enrol &amp; Verify Contact
                      </button>
                    } @else if (adm.duplicateFlag) {
                      <span class="text-xs text-amber-700">Hold — Duplicate Review</span>
                    } @else {
                      <span class="text-xs text-emerald-700 font-medium">Enrolled</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Bulk CSV Import with Server-Side Validation & Duplicate Preview -->
      <section class="bg-white border border-slate-200 rounded-lg p-6">
        <h2 class="font-display text-base font-semibold text-slate-900 mb-2">
          Bulk Admissions CSV Import (Validated Preview &amp; Duplicate Check)
        </h2>
        <p class="text-xs text-slate-600 mb-3">
          Format: <span class="font-mono-tabular">firstName,lastName,dob(YYYY-MM-DD),targetYearGroup,parentName,parentEmail</span>
        </p>
        <textarea
          [(ngModel)]="csvInput"
          rows="4"
          class="w-full p-3 text-xs font-mono-tabular border border-slate-300 rounded bg-slate-50"
          aria-label="Bulk admissions CSV input"
        ></textarea>
        <div class="mt-3 flex items-center gap-3">
          <button
            type="button"
            (click)="validateCsv()"
            [disabled]="validatingCsv()"
            class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer disabled:opacity-60"
          >
            {{ validatingCsv() ? 'Validating...' : 'Validate & Preview CSV' }}
          </button>
          @if (csvResult(); as res) {
            <span class="text-xs text-slate-700">
              Valid: <strong class="font-mono-tabular">{{ res.validRows.length }}</strong> ·
              Errors: <strong class="font-mono-tabular text-red-700">{{ res.invalidRows.length }}</strong> ·
              Duplicates Detected: <strong class="font-mono-tabular text-amber-700">{{ res.duplicateCount }}</strong>
            </span>
          }
        </div>

        @if (csvResult(); as res) {
          <div class="mt-4 border-t border-slate-200 pt-4 space-y-2 text-xs">
            @for (row of res.validRows; track row.rowNumber) {
              <div class="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span>Row {{ row.rowNumber }}: {{ row.firstName }} {{ row.lastName }} ({{ row.targetYearGroup }}) · {{ row.parentEmail }}</span>
                @if (row.duplicateMatchPupilId) {
                  <span class="text-amber-700 font-medium">Duplicate of {{ row.duplicateMatchPupilId }}</span>
                } @else {
                  <span class="text-emerald-700 font-medium">Ready to import</span>
                }
              </div>
            }
            @for (row of res.invalidRows; track row.rowNumber) {
              <div class="flex items-center justify-between py-1.5 text-red-700 border-b border-red-100">
                <span>Row {{ row.rowNumber }}: {{ row.firstName }} {{ row.lastName }}</span>
                <span>{{ row.errors.join(', ') }}</span>
              </div>
            }
          </div>
        }
      </section>
    </div>
  `,
})
export class AdmissionsStructureComponent {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);
  private readonly api = inject(ApiService);

  readonly validatingCsv = signal(false);
  readonly transitioning = signal(false);
  readonly transitionNote = signal('');
  readonly csvResult = signal<{
    validRows: CsvImportRow[];
    invalidRows: CsvImportRow[];
    duplicateCount: number;
  } | null>(null);

  csvInput = [
    'firstName,lastName,dob,targetYearGroup,parentName,parentEmail',
    'Oliver,Thornton,2013-05-14,Year 8,Sarah Thornton,sarah.thornton@example.co.uk',
    'Noah,Sutcliffe,2014-03-21,Year 7,Emma Sutcliffe,emma.sutcliffe@example.co.uk',
    'BadRow,MissingEmail,2014-99-99,Year 7,Test Parent,not-an-email',
  ].join('\n');

  async validateCsv(): Promise<void> {
    this.validatingCsv.set(true);
    try {
      const existing = this.store.pupils().map((p) => ({
        pupilId: p.pupilId,
        firstName: p.firstName,
        lastName: p.lastName,
        dob: p.dob,
      }));
      const res = await this.api.validateAdmissionsCsv(this.csvInput, existing);
      this.csvResult.set(res);
    } finally {
      this.validatingCsv.set(false);
    }
  }

  async enrolFromAdmission(applicationId: string): Promise<void> {
    const adm = this.store.admissions().find((a) => a.applicationId === applicationId);
    if (!adm) return;
    const parts = adm.applicantName.split(' ');
    const firstName = parts[0] || adm.applicantName;
    const lastName = parts.slice(1).join(' ') || 'Applicant';
    const ts = Date.now().toString(36);
    const pupil: Pupil = {
      pupilId: `pup_${ts}`,
      upn: `U8152026${Math.floor(10000 + Math.random() * 89999)}`,
      admissionNumber: `PA-${Math.floor(2610 + Math.random() * 290)}`,
      firstName,
      lastName,
      dob: adm.dob,
      yearGroup: adm.targetYearGroup,
      formGroup: '7A',
      house: 'Calder',
      teachingGroups: ['7A-Ma1', '7A-Sc1'],
      enrolmentStatus: 'Enrolled',
      enrolmentDate: new Date().toISOString().slice(0, 10),
      enrolmentHistory: [`${new Date().toISOString().slice(0, 10)}: Enrolled from Admissions (${adm.applicationId})`],
      allergyFlag: false,
      sendSupportLevel: 'None',
      photoConsent: true,
      tripBlanketConsent: false,
      ownerUid: this.auth.firebaseUser()?.uid ?? 'office',
    };
    await this.store.enrolPupilAndVerifyContact({
      applicationId,
      pupil,
      contact: {
        contactId: `con_${ts}`,
        pupilId: pupil.pupilId,
        fullName: adm.parentName,
        relationship: 'Parent (Verified on Enrolment)',
        email: adm.parentEmail,
        isEmergencyContact: true,
        hasPortalAccess: true,
        hasCollectionPermission: true,
        hasRecordAccess: true,
        isRestrictedContact: false,
        communicationPreference: 'Portal',
        verifiedByOffice: true,
        verifiedAt: new Date().toISOString().slice(0, 10),
      },
    });
  }

  async runTransition(): Promise<void> {
    this.transitioning.set(true);
    try {
      const count = await this.store.runAcademicYearTransition();
      this.transitionNote.set(`Promoted ${count} enrolled pupils to the next year group while preserving historical enrolment logs.`);
    } finally {
      this.transitioning.set(false);
    }
  }

  formatDate(d?: string): string {
    return formatUkDate(d);
  }
}
