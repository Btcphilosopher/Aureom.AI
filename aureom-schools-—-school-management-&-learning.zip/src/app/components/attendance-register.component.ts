import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AbsenceRequest, AttendanceSession, formatUkDate } from '../../shared/school-domain';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-attendance-register',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-lg p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-xl font-semibold text-slate-900">Attendance &amp; Registration</h1>
          <p class="text-sm text-slate-600 mt-1">
            {{ store.currentJurisdiction().authority }} · Code Set
            <span class="font-mono-tabular font-medium text-slate-800">{{ store.currentJurisdiction().attendanceCodeVersion }}</span>
          </p>
        </div>

        @if (isStaff()) {
          <div class="flex flex-wrap items-center gap-3 text-xs">
            <span class="text-slate-600 font-mono-tabular">{{ store.registerCacheAgeLabel() }}</span>
            <button
              type="button"
              (click)="toggleOfflineSimulation()"
              class="px-3 py-1.5 border border-slate-300 rounded font-medium cursor-pointer"
              [class.bg-amber-50]="store.simulatedOffline()"
              [class.text-amber-900]="store.simulatedOffline()"
              [class.border-amber-300]="store.simulatedOffline()"
            >
              {{ store.simulatedOffline() ? 'Offline Mode Active (Go Online)' : 'Simulate Offline Register' }}
            </button>
            @if (!store.simulatedOffline() && store.offlineQueue().length > 0) {
              <button
                type="button"
                (click)="store.syncOfflineRegisters()"
                class="px-3 py-1.5 bg-[#0F2744] text-white rounded font-medium cursor-pointer"
              >
                Sync {{ store.offlineQueue().length }} Cached Mark(s)
              </button>
            }
          </div>
        }
      </div>

      <!-- Offline / Conflict Notices -->
      @if (store.simulatedOffline()) {
        <div class="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
          <strong>Disconnected Mode:</strong> Cached registers are active ({{ store.registerCacheAgeLabel() }}). Marks recorded now are queued ({{ store.offlineQueue().length }}) and checked for conflicts on reconnection rather than silently overwriting office records.
        </div>
      }

      @if (store.syncConflicts().length > 0) {
        <section class="bg-red-50 border border-red-200 rounded-lg p-5 space-y-3">
          <h2 class="font-display text-sm font-semibold text-red-900">
            Register Synchronisation Conflicts ({{ store.syncConflicts().length }})
          </h2>
          @for (conflict of store.syncConflicts(); track conflict.sessionId) {
            <div class="bg-white border border-red-200 rounded p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div>
                <div class="font-semibold text-slate-900">{{ conflict.pupilName }} · {{ conflict.date }} ({{ conflict.sessionType }})</div>
                <div class="text-slate-600">
                  Local teacher mark: <strong class="font-mono-tabular">{{ conflict.code }}</strong> · Office reconciled mark: <strong class="font-mono-tabular">{{ conflict.serverCodeAtSync }}</strong>
                </div>
              </div>
              <div class="flex gap-2">
                <button type="button" (click)="store.resolveSyncConflict(conflict.sessionId, 'keep_local')" class="px-3 py-1.5 bg-[#0F2744] text-white rounded cursor-pointer">Keep Teacher Mark</button>
                <button type="button" (click)="store.resolveSyncConflict(conflict.sessionId, 'keep_server')" class="px-3 py-1.5 border border-slate-300 rounded cursor-pointer">Keep Office Mark</button>
              </div>
            </div>
          }
        </section>
      }

      <!-- Transparent Calculation Summary -->
      <section class="bg-white border border-slate-200 rounded-lg p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 class="font-display text-base font-semibold text-slate-900">
              Statutory Attendance Calculation Breakdown
            </h2>
            <p class="text-xs text-slate-600 mt-1">{{ store.schoolAttendanceSummary().formulaText }}</p>
          </div>
          <div class="flex items-center gap-6 font-mono-tabular">
            <div>
              <div class="text-xs text-slate-500">Attendance</div>
              <div class="text-2xl font-semibold text-slate-900">{{ store.schoolAttendanceSummary().percentage }}%</div>
            </div>
            <div>
              <div class="text-xs text-slate-500">Numerator</div>
              <div class="text-lg font-semibold text-emerald-700">{{ store.schoolAttendanceSummary().presentSessions }}</div>
            </div>
            <div>
              <div class="text-xs text-slate-500">Denominator</div>
              <div class="text-lg font-semibold text-slate-900">{{ store.schoolAttendanceSummary().possibleSessions }}</div>
            </div>
            <div>
              <div class="text-xs text-slate-500">Unresolved</div>
              <div class="text-lg font-semibold text-amber-700">{{ store.schoolAttendanceSummary().unresolvedCount }}</div>
            </div>
          </div>
        </div>

        @if (isStaff()) {
          <div class="pt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
            <div>
              Missing-Register Alert: <strong class="text-slate-900">{{ unresolvedList().length }}</strong> pupil session(s) marked <span class="font-mono-tabular">?</span> awaiting first-day office reconciliation.
            </div>
            <button type="button" (click)="verifyWithServer()" class="text-[#0F2744] font-medium hover:underline cursor-pointer">
              Recalculate via Backend Engine
            </button>
          </div>
          @if (serverCheckNote()) {
            <p class="mt-2 text-xs text-emerald-700 font-medium">{{ serverCheckNote() }}</p>
          }
        }
      </section>

      <!-- Staff Fast Register -->
      @if (isStaff()) {
        <section class="bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div class="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 class="font-display text-base font-semibold text-slate-900">Fast Class &amp; Form Register</h2>
              <p class="text-xs text-slate-500">Preserves versioned code definition ({{ store.currentJurisdiction().attendanceCodeVersion }}) on recorded date.</p>
            </div>
            <div class="flex items-center gap-3 text-sm">
              <input type="date" [(ngModel)]="registerDate" class="px-3 py-1.5 border border-slate-300 rounded font-mono-tabular text-xs" aria-label="Register date" />
              <select [(ngModel)]="registerSessionType" class="px-3 py-1.5 border border-slate-300 rounded text-xs bg-white" aria-label="Session type">
                <option value="AM">Morning (AM)</option>
                <option value="PM">Afternoon (PM)</option>
                <option value="LESSON">Lesson (8B-Ma1)</option>
              </select>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead class="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                <tr>
                  <th class="px-6 py-3 font-medium">Pupil</th>
                  <th class="px-4 py-3 font-medium">Form / Year</th>
                  <th class="px-4 py-3 font-medium">Recorded Mark</th>
                  <th class="px-4 py-3 font-medium">Quick Mark</th>
                  <th class="px-6 py-3 font-medium">Full Code Picker</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200">
                @for (pupil of store.visiblePupils(); track pupil.pupilId) {
                  <tr class="hover:bg-slate-50">
                    <td class="px-6 py-3 font-medium text-slate-900">
                      {{ pupil.firstName }} {{ pupil.lastName }}
                      @if (pupil.allergyFlag) {
                        <span class="text-xs text-red-700 font-normal"> · Medical Alert</span>
                      }
                    </td>
                    <td class="px-4 py-3 text-xs text-slate-600">{{ pupil.formGroup }} · {{ pupil.yearGroup }}</td>
                    <td class="px-4 py-3 font-mono-tabular font-semibold text-slate-900">
                      {{ currentMarkFor(pupil.pupilId) || '—' }}
                    </td>
                    <td class="px-4 py-3">
                      <div class="flex items-center gap-1.5">
                        @for (quick of quickCodes(); track quick) {
                          <button
                            type="button"
                            (click)="markPupil(pupil.pupilId, pupil.firstName + ' ' + pupil.lastName, quick)"
                            class="px-2.5 py-1 text-xs font-mono-tabular border rounded cursor-pointer transition-colors"
                            [class.bg-[#0F2744]]="currentMarkFor(pupil.pupilId) === quick"
                            [class.text-white]="currentMarkFor(pupil.pupilId) === quick"
                            [class.border-[#0F2744]]="currentMarkFor(pupil.pupilId) === quick"
                            [class.border-slate-300]="currentMarkFor(pupil.pupilId) !== quick"
                          >
                            {{ quick }}
                          </button>
                        }
                      </div>
                    </td>
                    <td class="px-6 py-3">
                      <select
                        [ngModel]="currentMarkFor(pupil.pupilId)"
                        (ngModelChange)="markPupil(pupil.pupilId, pupil.firstName + ' ' + pupil.lastName, $event)"
                        class="px-2.5 py-1 text-xs border border-slate-300 rounded bg-white max-w-xs"
                        [attr.aria-label]="'Attendance code for ' + pupil.firstName"
                      >
                        <option value="">Select code...</option>
                        @for (c of store.currentJurisdiction().attendanceCodes; track c.code) {
                          <option [value]="c.code">{{ c.code }} — {{ c.label }}</option>
                        }
                      </select>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      }

      <!-- Parent Absence Submission vs School Decision -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        @if (role() === 'parent' || isOfficeOrLeadership()) {
          <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6">
            <h2 class="font-display text-base font-semibold text-slate-900 mb-1">
              Parent / Carer Absence Notification
            </h2>
            <p class="text-xs text-slate-600 mb-4">
              Submitting an absence logs a parent report only. The school’s Attendance Officer records the statutory authorisation decision separately.
            </p>
            <div class="space-y-3 text-sm">
              <label class="block">
                <span class="text-xs font-medium text-slate-700">Child</span>
                <select [(ngModel)]="absencePupilId" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                  @for (p of store.visiblePupils(); track p.pupilId) {
                    <option [value]="p.pupilId">{{ p.firstName }} {{ p.lastName }} ({{ p.formGroup }})</option>
                  }
                </select>
              </label>
              <label class="block">
                <span class="text-xs font-medium text-slate-700">Date of Absence</span>
                <input type="date" [(ngModel)]="absenceDate" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded font-mono-tabular" />
              </label>
              <label class="block">
                <span class="text-xs font-medium text-slate-700">Reason / Explanation</span>
                <textarea [(ngModel)]="absenceReason" rows="3" placeholder="e.g. Viral fever / morning GP appointment" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded"></textarea>
              </label>
              <button
                type="button"
                (click)="submitParentAbsence()"
                class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer"
              >
                Submit Absence Notification
              </button>
              @if (absenceFeedback()) {
                <p class="text-xs text-emerald-700 font-medium">{{ absenceFeedback() }}</p>
              }
            </div>
          </section>
        }

        <section [class.lg:col-span-7]="role() === 'parent' || isOfficeOrLeadership()" [class.lg:col-span-12]="role() !== 'parent' && !isOfficeOrLeadership()" class="bg-white border border-slate-200 rounded-lg p-6">
          <h2 class="font-display text-base font-semibold text-slate-900 mb-4">
            Absence Submissions &amp; Office Decisions
          </h2>
          <div class="divide-y divide-slate-200">
            @for (req of store.visibleAbsenceRequests(); track req.requestId) {
              <div class="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div class="text-sm font-medium text-slate-900">
                    {{ pupilName(req.pupilId) }} · {{ formatDate(req.startDate) }}
                  </div>
                  <p class="text-xs text-slate-600 mt-0.5">{{ req.reason }}</p>
                  <p class="text-xs text-slate-500 mt-1">
                    Reported by {{ req.parentName }} · Decision:
                    <strong class="text-slate-800">{{ req.status.replace('_', ' ') }}</strong>
                    @if (req.schoolDecisionCode) {
                      <span> · Code <span class="font-mono-tabular">{{ req.schoolDecisionCode }}</span> ({{ req.reviewedByName }})</span>
                    }
                  </p>
                </div>

                @if (isOfficeOrLeadership() && req.status === 'pending_review') {
                  <div class="flex flex-wrap gap-2 shrink-0">
                    <button
                      type="button"
                      (click)="store.reviewAbsenceRequest(req, 'authorised', 'I')"
                      class="px-3 py-1.5 text-xs font-medium bg-emerald-700 text-white rounded hover:bg-emerald-800 cursor-pointer"
                    >
                      Authorise (I / M)
                    </button>
                    <button
                      type="button"
                      (click)="store.reviewAbsenceRequest(req, 'unauthorised', 'O')"
                      class="px-3 py-1.5 text-xs font-medium border border-red-300 text-red-700 rounded hover:bg-red-50 cursor-pointer"
                    >
                      Unauthorised (O)
                    </button>
                  </div>
                }
              </div>
            } @empty {
              <p class="text-sm text-slate-500">No absence notifications recorded.</p>
            }
          </div>
        </section>
      </div>
    </div>
  `,
})
export class AttendanceRegisterComponent {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);
  private readonly api = inject(ApiService);

  readonly role = this.auth.effectiveRole;
  readonly isStaff = computed(() =>
    ['admin', 'leadership', 'dsl', 'teacher', 'office'].includes(this.role()),
  );
  readonly isOfficeOrLeadership = computed(() =>
    ['admin', 'office', 'leadership'].includes(this.role()),
  );

  registerDate = new Date().toISOString().slice(0, 10);
  registerSessionType: 'AM' | 'PM' | 'LESSON' = 'AM';

  absencePupilId = 'pup_oliver';
  absenceDate = new Date().toISOString().slice(0, 10);
  absenceReason = '';
  readonly absenceFeedback = signal('');
  readonly serverCheckNote = signal('');

  readonly unresolvedList = computed(() =>
    this.store.attendanceSessions().filter((s) => s.code === '?'),
  );

  readonly quickCodes = computed(() => {
    const j = this.store.currentJurisdiction().id;
    if (j === 'scotland_cfe') return ['PR', 'LT', 'SL', 'UN'];
    return ['/', 'L', 'I', 'O', '?'];
  });

  currentMarkFor(pupilId: string): string {
    const queued = this.store
      .offlineQueue()
      .find(
        (q) =>
          q.pupilId === pupilId &&
          q.date === this.registerDate &&
          q.sessionType === this.registerSessionType,
      );
    if (queued) return queued.code;

    const existing = this.store
      .attendanceSessions()
      .find(
        (s) =>
          s.pupilId === pupilId &&
          s.date === this.registerDate &&
          s.sessionType === this.registerSessionType,
      );
    return existing?.code ?? '';
  }

  async markPupil(pupilId: string, pupilName: string, code: string): Promise<void> {
    if (!code) return;
    const session: AttendanceSession = {
      sessionId: `att_${pupilId}_${this.registerDate}_${this.registerSessionType}`,
      pupilId,
      date: this.registerDate,
      sessionType: this.registerSessionType,
      code,
      codeVersion: this.store.currentJurisdiction().attendanceCodeVersion,
      isAuthorised: code === '/' || code === '\\' || code === 'L' || code === 'I' || code === 'M' || code === 'PR',
      recordedByUid: this.auth.firebaseUser()?.uid ?? 'staff',
      reconciledByOffice: this.isOfficeOrLeadership(),
      recordedAt: new Date().toISOString(),
    };
    await this.store.recordAttendanceMark(session, pupilName);
  }

  toggleOfflineSimulation(): void {
    this.store.simulatedOffline.set(!this.store.simulatedOffline());
  }

  async verifyWithServer(): Promise<void> {
    const res = await this.api.calculateAttendance(
      this.store.visibleAttendance(),
      this.store.currentJurisdiction().id,
    );
    this.serverCheckNote.set(
      `Backend verified (${res.codeVersion}): ${res.percentage}% (${res.presentSessions}/${res.possibleSessions} sessions, ${res.unresolvedCount} unresolved).`,
    );
  }

  async submitParentAbsence(): Promise<void> {
    const targetId = this.absencePupilId || this.store.visiblePupils()[0]?.pupilId;
    if (!targetId || !this.absenceReason.trim()) return;
    const req: AbsenceRequest = {
      requestId: `abs_${Date.now().toString(36)}`,
      pupilId: targetId,
      submittedByUid: this.auth.firebaseUser()?.uid ?? 'parent',
      parentName: this.auth.effectivePersonName(),
      startDate: this.absenceDate,
      endDate: this.absenceDate,
      reason: this.absenceReason.trim(),
      status: 'pending_review',
      createdAt: new Date().toISOString(),
    };
    await this.store.submitAbsenceRequest(req);
    this.absenceReason = '';
    this.absenceFeedback.set('Submitted to School Office for statutory review (status: pending review).');
  }

  pupilName(pupilId: string): string {
    const p = this.store.pupils().find((x) => x.pupilId === pupilId);
    return p ? `${p.firstName} ${p.lastName}` : pupilId;
  }

  formatDate(d?: string): string {
    return formatUkDate(d);
  }
}
