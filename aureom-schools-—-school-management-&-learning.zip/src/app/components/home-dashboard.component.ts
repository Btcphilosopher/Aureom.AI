import { ChangeDetectionStrategy, Component, computed, inject, output } from '@angular/core';
import { formatGBP, formatUkDate } from '../../shared/school-domain';
import { AppModuleId, AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-home-dashboard',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Role Welcome Banner -->
      <section class="bg-white border border-slate-200 rounded-lg p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p class="text-xs font-medium text-slate-500 mb-1">
              {{ store.schoolConfig()?.name ?? 'Pennine Academy' }} · {{ store.schoolConfig()?.academicYear }} · {{ store.schoolConfig()?.currentTerm }} · Week {{ store.schoolConfig()?.weekCycle }}
            </p>
            <h1 class="font-display text-2xl font-semibold text-slate-900">
              Welcome, {{ auth.effectivePersonName() }}
            </h1>
            <p class="text-sm text-slate-600 mt-1">
              {{ roleSubtitle() }}
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-3 shrink-0">
            @if (role() === 'teacher') {
              <button
                type="button"
                (click)="navigate.emit('attendance')"
                class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] transition-colors cursor-pointer whitespace-nowrap"
              >
                Open Form Register
              </button>
            }
            @if (role() === 'office') {
              <button
                type="button"
                (click)="navigate.emit('attendance')"
                class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] transition-colors cursor-pointer whitespace-nowrap"
              >
                Review Absence Queue ({{ pendingAbsences().length }})
              </button>
            }
            @if (role() === 'dsl') {
              <button
                type="button"
                (click)="navigate.emit('safeguarding')"
                class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] transition-colors cursor-pointer whitespace-nowrap"
              >
                Open Safeguarding Triage ({{ unacknowledgedConcerns().length }})
              </button>
            }
            @if (role() === 'parent') {
              <button
                type="button"
                (click)="navigate.emit('attendance')"
                class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] transition-colors cursor-pointer whitespace-nowrap"
              >
                Report Child Absence
              </button>
            }
          </div>
        </div>
      </section>

      <!-- KPI Strip (Role-Specific Metrics with Tabular Numerals) -->
      <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (card of kpiCards(); track card.label) {
          <div class="bg-white border border-slate-200 rounded-lg p-5">
            <div class="text-xs font-medium text-slate-500 mb-2">{{ card.label }}</div>
            <div class="text-2xl font-semibold text-slate-900 font-mono-tabular">{{ card.value }}</div>
            <div class="text-xs text-slate-600 mt-2">{{ card.detail }}</div>
          </div>
        }
      </section>

      <!-- Role-Specific Workspace Grid -->
      @switch (role()) {
        @case ('teacher') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
              <div class="flex items-center justify-between mb-4">
                <h2 class="font-display text-base font-semibold text-slate-900">Today’s Timetable &amp; Registers</h2>
                <button type="button" (click)="navigate.emit('timetable')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                  Full Timetable
                </button>
              </div>
              <div class="divide-y divide-slate-200">
                @for (lesson of store.timetableEntries().slice(0, 4); track lesson.entryId) {
                  <div class="py-3 flex items-center justify-between gap-4">
                    <div>
                      <div class="text-sm font-medium text-slate-900">
                        {{ lesson.subject }} · {{ lesson.classCode }}
                      </div>
                      <div class="text-xs text-slate-500 font-mono-tabular">
                        {{ lesson.dayOfWeek }} · P{{ lesson.period }} ({{ lesson.startTime }}–{{ lesson.endTime }}) · Room {{ lesson.roomCode }}
                      </div>
                    </div>
                    <button
                      type="button"
                      (click)="navigate.emit('attendance')"
                      class="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded text-slate-700 hover:bg-slate-50 cursor-pointer whitespace-nowrap"
                    >
                      Take Register
                    </button>
                  </div>
                }
              </div>
            </section>

            <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 space-y-5">
              <div>
                <div class="flex items-center justify-between mb-3">
                  <h2 class="font-display text-base font-semibold text-slate-900">Marking &amp; Assigned Tasks</h2>
                  <button type="button" (click)="navigate.emit('learning')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                    Open Marking
                  </button>
                </div>
                <div class="divide-y divide-slate-200 text-sm">
                  @for (sub of unmarkedSubmissions(); track sub.submissionId) {
                    <div class="py-2.5 flex items-center justify-between gap-3">
                      <div>
                        <div class="font-medium text-slate-900">{{ sub.pupilName }}</div>
                        <div class="text-xs text-slate-500">Awaiting teacher feedback · {{ sub.submissionFormat }}</div>
                      </div>
                      <button type="button" (click)="navigate.emit('learning')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                        Mark
                      </button>
                    </div>
                  } @empty {
                    <p class="py-2 text-xs text-slate-500">All submitted homework has been marked.</p>
                  }
                </div>
              </div>

              <div class="pt-4 border-t border-slate-200">
                <h3 class="font-display text-sm font-semibold text-slate-900 mb-2">Recent Announcements</h3>
                @for (ann of store.announcements().slice(0, 2); track ann.announcementId) {
                  <div class="py-2">
                    <div class="text-sm font-medium text-slate-800">{{ ann.title }}</div>
                    <div class="text-xs text-slate-500">{{ ann.audienceLabel }} · {{ formatDate(ann.publishedAt) }}</div>
                  </div>
                }
              </div>
            </section>
          </div>
        }

        @case ('office') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
              <div class="flex items-center justify-between mb-4">
                <h2 class="font-display text-base font-semibold text-slate-900">Parent Absence Reconciliation Queue</h2>
                <button type="button" (click)="navigate.emit('attendance')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                  Manage Registers
                </button>
              </div>
              <div class="divide-y divide-slate-200">
                @for (req of pendingAbsences(); track req.requestId) {
                  <div class="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div class="text-sm font-medium text-slate-900">
                        {{ pupilName(req.pupilId) }} · {{ formatDate(req.startDate) }}
                      </div>
                      <div class="text-xs text-slate-600">{{ req.reason }}</div>
                      <div class="text-xs text-slate-500 mt-0.5">Submitted by {{ req.parentName }} (Parent report — pending school decision)</div>
                    </div>
                    <button
                      type="button"
                      (click)="navigate.emit('attendance')"
                      class="px-3 py-1.5 text-xs font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer whitespace-nowrap"
                    >
                      Authorise / Decide
                    </button>
                  </div>
                } @empty {
                  <p class="py-3 text-sm text-slate-500">No pending parent absence submissions.</p>
                }
              </div>
            </section>

            <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6">
              <div class="flex items-center justify-between mb-4">
                <h2 class="font-display text-base font-semibold text-slate-900">Admissions &amp; Contact Checks</h2>
                <button type="button" (click)="navigate.emit('admissions')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                  Open Admissions
                </button>
              </div>
              <div class="divide-y divide-slate-200 text-sm">
                @for (adm of store.admissions(); track adm.applicationId) {
                  <div class="py-2.5 flex items-center justify-between gap-3">
                    <div>
                      <div class="font-medium text-slate-900">{{ adm.applicantName }}</div>
                      <div class="text-xs text-slate-500">
                        {{ adm.targetYearGroup }} · Stage: {{ adm.stage }}
                        @if (adm.duplicateFlag) {
                          <span class="text-amber-700 font-medium"> · Duplicate flag</span>
                        }
                      </div>
                    </div>
                    <button type="button" (click)="navigate.emit('admissions')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                      Review
                    </button>
                  </div>
                }
              </div>
            </section>
          </div>
        }

        @case ('leadership') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
              <h2 class="font-display text-base font-semibold text-slate-900 mb-3">
                Statutory Attendance Calculation Definition
              </h2>
              <p class="text-sm text-slate-700 mb-4">
                {{ store.schoolAttendanceSummary().formulaText }}
              </p>
              <div class="grid grid-cols-3 gap-4 border-t border-slate-200 pt-4 text-sm">
                <div>
                  <div class="text-xs text-slate-500">Code Standard</div>
                  <div class="font-mono-tabular font-medium text-slate-900">{{ store.schoolAttendanceSummary().codeVersion }}</div>
                </div>
                <div>
                  <div class="text-xs text-slate-500">Unresolved Marks</div>
                  <div class="font-mono-tabular font-medium text-amber-700">{{ store.schoolAttendanceSummary().unresolvedCount }}</div>
                </div>
                <div>
                  <div class="text-xs text-slate-500">Cover Lessons Active</div>
                  <div class="font-mono-tabular font-medium text-slate-900">{{ coverCount() }}</div>
                </div>
              </div>
            </section>

            <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6">
              <div class="flex items-center justify-between mb-3">
                <h2 class="font-display text-base font-semibold text-slate-900">Operational Overview</h2>
                <button type="button" (click)="navigate.emit('admin_audit')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                  Full Reports
                </button>
              </div>
              <ul class="space-y-2.5 text-sm text-slate-700">
                <li class="flex justify-between">
                  <span>Active Teaching &amp; Support Staff</span>
                  <span class="font-mono-tabular font-medium">{{ store.staff().length }}</span>
                </li>
                <li class="flex justify-between">
                  <span>Pending Admissions Offers / Accepted</span>
                  <span class="font-mono-tabular font-medium">{{ store.admissions().length }}</span>
                </li>
                <li class="flex justify-between">
                  <span>Open Behaviour Review Items</span>
                  <span class="font-mono-tabular font-medium">{{ openBehaviourCount() }}</span>
                </li>
              </ul>
            </section>
          </div>
        }

        @case ('dsl') {
          <section class="bg-white border border-slate-200 rounded-lg p-6">
            <div class="flex items-center justify-between mb-4">
              <div>
                <h2 class="font-display text-base font-semibold text-slate-900">Restricted Safeguarding Triage</h2>
                <p class="text-xs text-slate-600 mt-0.5">
                  Submitting a concern does not confirm receipt. Acknowledge and assign ownership explicitly.
                </p>
              </div>
              <button
                type="button"
                (click)="navigate.emit('safeguarding')"
                class="px-4 py-2 text-xs font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer"
              >
                Open Full Safeguarding Register
              </button>
            </div>
            <div class="divide-y divide-slate-200">
              @for (c of store.safeguardingConcerns(); track c.concernId) {
                <div class="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div class="text-sm font-medium text-slate-900">{{ c.pupilInitials }} · {{ c.category }}</div>
                    <div class="text-xs text-slate-600">Status: {{ c.status }} · Reported by {{ c.reportedByName }} · Review by {{ formatDate(c.reviewDate) }}</div>
                  </div>
                  <button
                    type="button"
                    (click)="navigate.emit('safeguarding')"
                    class="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded text-slate-800 hover:bg-slate-50 cursor-pointer"
                  >
                    Inspect &amp; Acknowledge
                  </button>
                </div>
              }
            </div>
          </section>
        }

        @case ('parent') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
              <h2 class="font-display text-base font-semibold text-slate-900 mb-3">
                Authorised Child Summary
              </h2>
              @for (child of store.visiblePupils(); track child.pupilId) {
                <div class="border border-slate-200 rounded p-4 space-y-2">
                  <div class="flex items-center justify-between">
                    <div class="text-base font-semibold text-slate-900">
                      {{ child.firstName }} {{ child.lastName }}
                    </div>
                    <span class="text-xs font-mono-tabular text-slate-600">
                      {{ child.yearGroup }} · Form {{ child.formGroup }} · {{ child.house }} House
                    </span>
                  </div>
                  <p class="text-xs text-slate-600">
                    Admission No: <span class="font-mono-tabular">{{ child.admissionNumber }}</span> · Enrolment: {{ child.enrolmentStatus }}
                  </p>
                  <div class="pt-3 flex flex-wrap gap-2">
                    <button type="button" (click)="navigate.emit('attendance')" class="px-3 py-1.5 text-xs font-medium bg-[#0F2744] text-white rounded cursor-pointer">
                      Attendance &amp; Absence
                    </button>
                    <button type="button" (click)="navigate.emit('learning')" class="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded text-slate-700 hover:bg-slate-50 cursor-pointer">
                      Homework &amp; Reports
                    </button>
                    <button type="button" (click)="navigate.emit('trips_payments')" class="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded text-slate-700 hover:bg-slate-50 cursor-pointer">
                      Trips &amp; Consent
                    </button>
                  </div>
                </div>
              } @empty {
                <p class="text-sm text-slate-600">
                  Your account has not yet been linked to a pupil by the School Office.
                </p>
              }
            </section>

            <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6">
              <h2 class="font-display text-base font-semibold text-slate-900 mb-2">
                Parent Portal Access Isolation
              </h2>
              <p class="text-xs text-slate-600 leading-relaxed mb-3">
                Your portal returns only records for your verified child(ren) ({{ store.visiblePupils().length }} linked). Other families’ pupils, emergency-only unverified contacts, internal staff notes, and confidential safeguarding records are excluded by server permissions.
              </p>
              <div class="border-t border-slate-200 pt-3 space-y-2 text-xs text-slate-700">
                <div class="flex justify-between">
                  <span>Other Pupils Visible</span>
                  <span class="font-mono-tabular font-medium text-emerald-700">0 (Isolated)</span>
                </div>
                <div class="flex justify-between">
                  <span>Safeguarding Notes Exposed</span>
                  <span class="font-mono-tabular font-medium text-emerald-700">0 (Restricted)</span>
                </div>
              </div>
            </section>
          </div>
        }

        @case ('pupil') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section class="lg:col-span-6 bg-white border border-slate-200 rounded-lg p-6">
              <div class="flex items-center justify-between mb-3">
                <h2 class="font-display text-base font-semibold text-slate-900">My Homework &amp; Feedback</h2>
                <button type="button" (click)="navigate.emit('learning')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                  Open Learning
                </button>
              </div>
              <div class="divide-y divide-slate-200">
                @for (hw of store.homework(); track hw.homeworkId) {
                  <div class="py-3">
                    <div class="text-sm font-medium text-slate-900">{{ hw.title }}</div>
                    <div class="text-xs text-slate-500">{{ hw.subject }} · Due {{ formatDate(hw.dueDate) }}</div>
                  </div>
                }
              </div>
            </section>
            <section class="lg:col-span-6 bg-white border border-slate-200 rounded-lg p-6">
              <h2 class="font-display text-base font-semibold text-slate-900 mb-3">School Announcements</h2>
              <div class="divide-y divide-slate-200">
                @for (ann of store.announcements(); track ann.announcementId) {
                  <div class="py-3">
                    <div class="text-sm font-medium text-slate-900">{{ ann.title }}</div>
                    <div class="text-xs text-slate-600 mt-1">{{ ann.body }}</div>
                  </div>
                }
              </div>
            </section>
          </div>
        }

        @default {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
              <div class="flex items-center justify-between mb-4">
                <h2 class="font-display text-base font-semibold text-slate-900">Recent Audit Activity</h2>
                <button type="button" (click)="navigate.emit('admin_audit')" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                  Open Audit &amp; Verification Suite
                </button>
              </div>
              <div class="divide-y divide-slate-200 text-sm">
                @for (log of store.auditLogs().slice(0, 5); track log.logId) {
                  <div class="py-2.5">
                    <div class="flex items-center justify-between gap-4">
                      <span class="font-medium text-slate-900">{{ log.action }}</span>
                      <span class="text-xs font-mono-tabular text-slate-500">{{ log.createdAt.slice(0, 16).replace('T', ' ') }}</span>
                    </div>
                    <div class="text-xs text-slate-600 mt-0.5">{{ log.actorName }} ({{ log.actorRole }}) — {{ log.summary }}</div>
                  </div>
                }
              </div>
            </section>

            <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6">
              <h2 class="font-display text-base font-semibold text-slate-900 mb-3">
                9-Step Guided Demonstration
              </h2>
              <ol class="space-y-2 text-xs text-slate-700 list-decimal pl-4">
                <li>Switch to <strong>School Office</strong> -> Enrol pupil &amp; verify contact permissions.</li>
                <li>Switch to <strong>Teacher</strong> -> View timetable &amp; mark 8B register.</li>
                <li>Switch to <strong>Parent</strong> -> Submit absence; review in <strong>School Office</strong>.</li>
                <li>In <strong>Teacher</strong> -> Publish homework &amp; mark Oliver’s submission.</li>
                <li>In <strong>Parent</strong> -> Confirm isolation (only Oliver visible).</li>
                <li>In <strong>Parent</strong> -> Book York trip with consent &amp; simulated GBP payment.</li>
                <li>In <strong>Teacher</strong> -> Submit concern; switch to <strong>DSL</strong> to acknowledge.</li>
                <li>Switch to <strong>Leadership</strong> -> Inspect attendance numerator/denominator.</li>
                <li>In <strong>Administrator</strong> -> Inspect audit trail &amp; run verification tests.</li>
              </ol>
            </section>
          </div>
        }
      }
    </div>
  `,
})
export class HomeDashboardComponent {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);
  readonly navigate = output<AppModuleId>();

  readonly role = this.auth.effectiveRole;

  readonly pendingAbsences = computed(() =>
    this.store.visibleAbsenceRequests().filter((r) => r.status === 'pending_review'),
  );

  readonly unmarkedSubmissions = computed(() =>
    this.store.submissions().filter((s) => s.status === 'submitted'),
  );

  readonly unacknowledgedConcerns = computed(() =>
    this.store.safeguardingConcerns().filter((c) => c.status === 'submitted_unacknowledged'),
  );

  readonly coverCount = computed(
    () => this.store.timetableEntries().filter((t) => Boolean(t.coverTeacherName)).length,
  );

  readonly openBehaviourCount = computed(
    () => this.store.behaviourEvents().filter((b) => b.reviewStatus === 'open').length,
  );

  readonly roleSubtitle = computed(() => {
    switch (this.role()) {
      case 'teacher':
        return 'Today’s lessons, fast registers, homework marking, and school announcements.';
      case 'office':
        return 'Admissions pipeline, parent absence reconciliation, contact verification, and daily administration.';
      case 'leadership':
        return 'Whole-school statutory attendance, staffing cover, assessment moderation, and operations.';
      case 'dsl':
        return 'Restricted safeguarding triage, chronology, acknowledgement, and external escalation.';
      case 'parent':
        return 'Authorised child summary, attendance, homework feedback, trips, consent, and GBP payments.';
      case 'pupil':
        return 'Your timetable, homework tasks, teacher feedback, and school notices.';
      default:
        return 'Multi-school tenant administration, branding, UK jurisdiction rules, and immutable audit history.';
    }
  });

  readonly kpiCards = computed(() => {
    const att = this.store.schoolAttendanceSummary();
    const role = this.role();
    if (role === 'parent' || role === 'pupil') {
      const dueCount = this.store.homework().length;
      const tripCount = this.store.visibleBookings().length;
      return [
        { label: 'Attendance Rate', value: `${att.percentage}%`, detail: `${att.presentSessions}/${att.possibleSessions} sessions` },
        { label: 'Unresolved Marks', value: `${att.unresolvedCount}`, detail: 'Pending office check' },
        { label: 'Active Homework', value: `${dueCount}`, detail: 'Accessible options included' },
        { label: 'Bookings & Consent', value: `${tripCount}`, detail: formatGBP(this.store.visibleBookings().reduce((sum, b) => sum + b.amountPence, 0)) },
      ];
    }
    if (role === 'dsl') {
      return [
        { label: 'Unacknowledged', value: `${this.unacknowledgedConcerns().length}`, detail: 'Requires DSL receipt' },
        { label: 'Total Active Concerns', value: `${this.store.safeguardingConcerns().length}`, detail: 'Strictly restricted to DSL' },
        { label: 'Healthcare Plans', value: `${this.store.medicalPlans().length}`, detail: 'Nurse verified' },
        { label: 'Safeguarding Standard', value: 'KCSIE', detail: this.store.currentJurisdiction().name },
      ];
    }
    return [
      { label: 'Statutory Attendance', value: `${att.percentage}%`, detail: `${att.presentSessions} / ${att.possibleSessions} sessions` },
      { label: 'Active Pupils', value: `${this.store.visiblePupils().length}`, detail: `${this.store.admissions().length} in admissions` },
      { label: 'Pending Absences', value: `${this.pendingAbsences().length}`, detail: 'Awaiting office decision' },
      { label: 'Unmarked Work', value: `${this.unmarkedSubmissions().length}`, detail: `${this.store.announcements().length} active notices` },
    ];
  });

  pupilName(pupilId: string): string {
    const p = this.store.pupils().find((x) => x.pupilId === pupilId);
    return p ? `${p.firstName} ${p.lastName}` : pupilId;
  }

  formatDate(d?: string): string {
    return formatUkDate(d);
  }
}
