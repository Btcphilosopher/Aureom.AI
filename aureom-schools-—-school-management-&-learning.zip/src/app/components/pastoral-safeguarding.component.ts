import { ChangeDetectionStrategy, Component, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  BehaviourEvent,
  MedicalPlan,
  SafeguardingConcern,
  formatUkDate,
} from '../../shared/school-domain';
import { AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-pastoral-safeguarding',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    @switch (mode()) {
      @case ('safeguarding') {
        <div class="space-y-6">
          <div class="bg-white border border-slate-200 rounded-lg p-6">
            <h1 class="font-display text-xl font-semibold text-slate-900">
              Safeguarding &amp; Child Protection
            </h1>
            <p class="text-sm text-slate-600 mt-1">
              {{ store.currentJurisdiction().safeguardingFramework }} · Confidential records are isolated from parent portals, general search, and routine behaviour analytics.
            </p>
            <div class="mt-4 p-3.5 bg-amber-50 border border-amber-200 rounded text-xs text-amber-950">
              <strong>Operational Safeguard:</strong> Recording or sending a concern does NOT establish that the Designated Safeguarding Lead has received and acted upon it. Urgent risk of immediate harm must be reported in person or by telephone to the DSL immediately.
            </div>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Concern Reporting Form (Staff & DSL) -->
            <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 space-y-4">
              <h2 class="font-display text-base font-semibold text-slate-900">Record Confidential Concern</h2>
              <label class="block text-sm">
                <span class="text-xs font-medium text-slate-700">Pupil</span>
                <select [(ngModel)]="sgPupilId" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                  @for (p of store.pupils(); track p.pupilId) {
                    <option [value]="p.pupilId">{{ p.firstName }} {{ p.lastName }} ({{ p.formGroup }})</option>
                  }
                </select>
              </label>
              <label class="block text-sm">
                <span class="text-xs font-medium text-slate-700">Category</span>
                <select [(ngModel)]="sgCategory" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                  <option value="Home Welfare / Emotional Distress">Home Welfare / Emotional Distress</option>
                  <option value="Physical Observation">Physical Observation</option>
                  <option value="Online Safety / Peer Harm">Online Safety / Peer Harm</option>
                  <option value="Child Disclosure (Verbatim)">Child Disclosure (Verbatim)</option>
                </select>
              </label>
              <label class="block text-sm">
                <span class="text-xs font-medium text-slate-700">Factual Account (Observed / Disclosed Only)</span>
                <textarea [(ngModel)]="sgSummary" rows="4" placeholder="Record factual observations and exact words spoken without speculation..." class="mt-1 w-full px-3 py-2 border border-slate-300 rounded"></textarea>
              </label>
              <button
                type="button"
                (click)="submitConcern()"
                class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer"
              >
                Route Confidentially to DSL
              </button>
              @if (sgSubmittedBanner()) {
                <p class="text-xs text-emerald-700 font-medium">{{ sgSubmittedBanner() }}</p>
              }
            </section>

            <!-- Restricted DSL Register -->
            <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
              @if (isDslOrAdmin()) {
                <div class="flex items-center justify-between mb-4">
                  <h2 class="font-display text-base font-semibold text-slate-900">
                    Restricted DSL Case Chronology &amp; Escalation
                  </h2>
                  <span class="text-xs text-slate-500">All views logged in Audit Trail</span>
                </div>
                <div class="divide-y divide-slate-200 space-y-4">
                  @for (c of store.safeguardingConcerns(); track c.concernId) {
                    <div class="pt-4 first:pt-0 space-y-2 text-sm">
                      <div class="flex flex-wrap items-center justify-between gap-2">
                        <div class="font-semibold text-slate-900">
                          {{ c.pupilInitials }} · {{ c.category }}
                        </div>
                        <span class="text-xs font-mono-tabular font-medium" [class.text-red-700]="c.status === 'submitted_unacknowledged'" [class.text-emerald-700]="c.status !== 'submitted_unacknowledged'">
                          {{ c.status }}
                        </span>
                      </div>
                      <p class="text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded p-3">{{ c.factualSummary }}</p>
                      <p class="text-xs text-slate-500">
                        Reported by {{ c.reportedByName }} · Owner: {{ c.assignedDslName || 'Unassigned' }} · Review: {{ formatDate(c.reviewDate) }}
                        @if (c.referralReference) {
                          · Referral: <span class="font-mono-tabular">{{ c.referralReference }}</span>
                        }
                      </p>
                      <div class="flex flex-wrap gap-2 pt-1">
                        @if (c.status === 'submitted_unacknowledged') {
                          <button
                            type="button"
                            (click)="acknowledgeConcern(c)"
                            class="px-3 py-1.5 text-xs font-medium bg-[#0F2744] text-white rounded cursor-pointer"
                          >
                            Acknowledge Receipt
                          </button>
                        }
                        <button
                          type="button"
                          (click)="escalateConcern(c)"
                          class="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                        >
                          Record MASH / External Referral
                        </button>
                      </div>
                    </div>
                  } @empty {
                    <p class="text-sm text-slate-500">No safeguarding concerns recorded.</p>
                  }
                </div>
              } @else {
                <div class="py-8 text-center space-y-2">
                  <span class="material-icons text-slate-400 text-3xl" aria-hidden="true">lock</span>
                  <h2 class="font-display text-base font-semibold text-slate-900">Restricted Register Access</h2>
                  <p class="text-xs text-slate-600 max-w-md mx-auto">
                    Your active role ({{ auth.effectiveRole() }}) can submit new concerns on the left, but existing safeguarding chronologies and referrals are restricted strictly to the Designated Safeguarding Lead (Ms Hannah Brooks) and authorised Safeguarding Admins.
                  </p>
                </div>
              }
            </section>
          </div>
        </div>
      }

      @case ('send_medical') {
        <div class="space-y-6">
          <div class="bg-white border border-slate-200 rounded-lg p-6">
            <h1 class="font-display text-xl font-semibold text-slate-900">SEND, Accessibility &amp; Medical Care Plans</h1>
            <p class="text-sm text-slate-600 mt-1">
              Practical classroom adjustments are surfaced for teachers; clinical care plans and emergency protocols are managed by authorised pastoral/medical staff (no AI medical advice is generated).
            </p>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section class="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
              <h2 class="font-display text-base font-semibold text-slate-900">Classroom SEND Adjustments</h2>
              <div class="divide-y divide-slate-200">
                @for (p of store.visiblePupils(); track p.pupilId) {
                  @if (p.sendSupportLevel && p.sendSupportLevel !== 'None') {
                    <div class="py-3">
                      <div class="text-sm font-semibold text-slate-900">{{ p.firstName }} {{ p.lastName }} ({{ p.formGroup }}) · {{ p.sendSupportLevel }}</div>
                      <p class="text-xs text-slate-700 mt-1">{{ p.sendAdjustments || p.accessibilitySummary }}</p>
                    </div>
                  }
                }
              </div>
            </section>

            <section class="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
              <h2 class="font-display text-base font-semibold text-slate-900">Individual Healthcare Plans</h2>
              <div class="divide-y divide-slate-200">
                @for (mp of store.medicalPlans(); track mp.planId) {
                  <div class="py-3 space-y-1.5">
                    <div class="flex items-center justify-between">
                      <span class="text-sm font-semibold text-slate-900">{{ mp.pupilName }} · {{ mp.condition }}</span>
                      <span class="text-xs font-medium text-emerald-700">{{ mp.verifiedByNurse ? 'Nurse Verified' : 'Pending Review' }}</span>
                    </div>
                    <p class="text-xs text-slate-700"><strong>Care Plan:</strong> {{ mp.carePlanSummary }}</p>
                    <p class="text-xs text-red-800 bg-red-50 border border-red-200 rounded p-2"><strong>Emergency Protocol:</strong> {{ mp.emergencyProtocol }}</p>
                    <p class="text-xs text-slate-500">Allergens: {{ mp.allergens || 'None' }} · Review due: {{ formatDate(mp.reviewDate) }}</p>
                    @if (isOfficeOrLeadership()) {
                      <button type="button" (click)="logMedicalIncident(mp)" class="text-xs font-medium text-[#0F2744] hover:underline cursor-pointer">
                        Log Medical Room Check
                      </button>
                    }
                  </div>
                }
              </div>
            </section>
          </div>
        </div>
      }

      @default {
        <div class="space-y-6">
          <div class="bg-white border border-slate-200 rounded-lg p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 class="font-display text-xl font-semibold text-slate-900">Behaviour &amp; Pastoral Care</h1>
              <p class="text-sm text-slate-600 mt-1">
                Factual routine achievements, incidents, detentions, and pastoral reviews. Disciplinary decisions are made strictly by authorised staff.
              </p>
            </div>
            <button
              type="button"
              (click)="showLogEvent.set(!showLogEvent())"
              class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer whitespace-nowrap"
            >
              {{ showLogEvent() ? 'Close Form' : 'Record Behaviour / Achievement' }}
            </button>
          </div>

          @if (showLogEvent()) {
            <section class="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
              <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <label class="block">
                  <span class="text-xs font-medium text-slate-700">Pupil</span>
                  <select [(ngModel)]="behPupilId" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                    @for (p of store.pupils(); track p.pupilId) {
                      <option [value]="p.pupilId">{{ p.firstName }} {{ p.lastName }} ({{ p.formGroup }})</option>
                    }
                  </select>
                </label>
                <label class="block">
                  <span class="text-xs font-medium text-slate-700">Category</span>
                  <select [(ngModel)]="behCategory" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                    <option value="achievement">Achievement / House Merit</option>
                    <option value="behaviour_incident">Behaviour Incident</option>
                    <option value="detention">Detention</option>
                    <option value="pastoral_action">Pastoral Follow-up</option>
                  </select>
                </label>
                <label class="block">
                  <span class="text-xs font-medium text-slate-700">Location</span>
                  <input [(ngModel)]="behLocation" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
                </label>
              </div>
              <label class="block text-sm">
                <span class="text-xs font-medium text-slate-700">Title</span>
                <input [(ngModel)]="behTitle" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
              </label>
              <label class="block text-sm">
                <span class="text-xs font-medium text-slate-700">Factual Description</span>
                <textarea [(ngModel)]="behDesc" rows="2" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded"></textarea>
              </label>
              <button type="button" (click)="submitBehaviour()" class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded cursor-pointer">
                Save Record
              </button>
            </section>
          }

          <section class="bg-white border border-slate-200 rounded-lg divide-y divide-slate-200">
            @for (ev of store.visibleBehaviour(); track ev.eventId) {
              <div class="p-5 space-y-2 text-sm">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <div class="font-semibold text-slate-900">{{ ev.pupilName }} · {{ ev.title }}</div>
                  <span class="text-xs text-slate-500">{{ ev.category.replace('_', ' ') }} · Status: {{ ev.reviewStatus }}</span>
                </div>
                <p class="text-xs text-slate-700">{{ ev.factualDescription }}</p>
                <p class="text-xs text-slate-500">
                  Location: {{ ev.location || 'Classroom' }} · Author: {{ ev.authorName }} · Action: {{ ev.actionTaken || 'Logged' }}
                </p>
                @if (ev.revisionNote) {
                  <p class="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded p-2">Revision Note: {{ ev.revisionNote }}</p>
                }
                @if (isOfficeOrLeadership() && ev.reviewStatus === 'open') {
                  <button
                    type="button"
                    (click)="store.amendBehaviourEvent(ev.eventId, 'Reviewed and confirmed by Head of Year.', 'reviewed')"
                    class="px-3 py-1 text-xs font-medium border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                  >
                    Mark Reviewed
                  </button>
                }
              </div>
            }
          </section>
        </div>
      }
    }
  `,
})
export class PastoralSafeguardingComponent {
  readonly mode = input<'pastoral' | 'safeguarding' | 'send_medical'>('pastoral');

  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);

  readonly isDslOrAdmin = computed(() =>
    this.auth.isBootstrappedAdmin() ? this.auth.effectiveRole() === 'dsl' || this.auth.effectiveRole() === 'admin' : this.auth.effectiveRole() === 'dsl',
  );
  readonly isOfficeOrLeadership = computed(() =>
    ['admin', 'office', 'leadership', 'dsl'].includes(this.auth.effectiveRole()),
  );

  sgPupilId = 'pup_oliver';
  sgCategory = 'Home Welfare / Emotional Distress';
  sgSummary = '';
  readonly sgSubmittedBanner = signal('');

  readonly showLogEvent = signal(false);
  behPupilId = 'pup_oliver';
  behCategory: BehaviourEvent['category'] = 'achievement';
  behLocation = 'M204';
  behTitle = '';
  behDesc = '';

  async submitConcern(): Promise<void> {
    if (!this.sgSummary.trim()) return;
    const pupil = this.store.pupils().find((p) => p.pupilId === this.sgPupilId);
    const initials = pupil
      ? `${pupil.firstName[0]}.${pupil.lastName[0]}. (${pupil.formGroup})`
      : 'Pupil';
    const concern: SafeguardingConcern = {
      concernId: `sg_${Date.now().toString(36)}`,
      pupilId: this.sgPupilId,
      pupilInitials: initials,
      category: this.sgCategory,
      factualSummary: this.sgSummary.trim(),
      reportedByUid: this.auth.firebaseUser()?.uid ?? 'staff',
      reportedByName: this.auth.effectivePersonName(),
      assignedDslName: 'Ms Hannah Brooks',
      status: 'submitted_unacknowledged',
      reviewDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
      accessRestricted: true,
      createdAt: new Date().toISOString(),
    };
    await this.store.submitSafeguardingConcern(concern);
    this.sgSummary = '';
    this.sgSubmittedBanner.set('Routed to DSL queue (status: submitted_unacknowledged). Note: DSL acknowledgement is still required.');
  }

  async acknowledgeConcern(c: SafeguardingConcern): Promise<void> {
    await this.store.updateSafeguardingConcern(c.concernId, {
      status: 'acknowledged',
      acknowledgedAt: new Date().toISOString(),
      assignedDslName: this.auth.effectivePersonName(),
    });
  }

  async escalateConcern(c: SafeguardingConcern): Promise<void> {
    await this.store.updateSafeguardingConcern(c.concernId, {
      status: 'escalated_mash',
      referralReference: `WY-MASH-${Math.floor(10000 + Math.random() * 89999)}`,
    });
  }

  async logMedicalIncident(mp: MedicalPlan): Promise<void> {
    await this.store.saveMedicalPlan({
      ...mp,
      lastIncidentNote: `Routine medical check recorded by ${this.auth.effectivePersonName()} on ${formatUkDate(new Date().toISOString())}.`,
    });
  }

  async submitBehaviour(): Promise<void> {
    if (!this.behTitle.trim() || !this.behDesc.trim()) return;
    const pupil = this.store.pupils().find((p) => p.pupilId === this.behPupilId);
    await this.store.addBehaviourEvent({
      eventId: `beh_${Date.now().toString(36)}`,
      pupilId: this.behPupilId,
      pupilName: pupil ? `${pupil.firstName} ${pupil.lastName}` : 'Pupil',
      category: this.behCategory,
      title: this.behTitle.trim(),
      factualDescription: this.behDesc.trim(),
      location: this.behLocation.trim(),
      occurredAt: new Date().toISOString(),
      authorName: this.auth.effectivePersonName(),
      authorUid: this.auth.firebaseUser()?.uid ?? 'staff',
      reviewStatus: 'open',
    });
    this.behTitle = '';
    this.behDesc = '';
    this.showLogEvent.set(false);
  }

  formatDate(d?: string): string {
    return formatUkDate(d);
  }
}
