import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ContactRelationship, Pupil, formatUkDate } from '../../shared/school-domain';
import { AuthService } from '../services/auth.service';
import { SchoolStoreService } from '../services/school-store.service';

@Component({
  selector: 'app-pupils-contacts',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  template: `
    <div class="space-y-6">
      <div class="bg-white border border-slate-200 rounded-lg p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-xl font-semibold text-slate-900">Pupil Records &amp; Contact Relationships</h1>
          <p class="text-sm text-slate-600 mt-1">
            Emergency contacts never automatically inherit portal access, collection permission, or educational record access.
          </p>
        </div>
        <div class="flex items-center gap-3">
          <input
            type="search"
            [ngModel]="searchQuery()"
            (ngModelChange)="searchQuery.set($event)"
            placeholder="Search pupil, admission no. or form..."
            class="px-3 py-2 text-sm border border-slate-300 rounded w-64 bg-white"
            aria-label="Search pupils"
          />
          @if (canEditRecords()) {
            <button
              type="button"
              (click)="showEnrolForm.set(!showEnrolForm())"
              class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer whitespace-nowrap"
            >
              {{ showEnrolForm() ? 'Close Form' : 'Enrol Pupil & Verify Contact' }}
            </button>
          }
        </div>
      </div>

      @if (showEnrolForm() && canEditRecords()) {
        <section class="bg-white border border-slate-200 rounded-lg p-6">
          <h2 class="font-display text-base font-semibold text-slate-900 mb-4">
            Enrol New Pupil &amp; Verify Primary Contact Relationship
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <label class="block">
              <span class="text-xs font-medium text-slate-700">First Name</span>
              <input [(ngModel)]="newFirstName" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Surname</span>
              <input [(ngModel)]="newLastName" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Date of Birth</span>
              <input type="date" [(ngModel)]="newDob" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Year Group</span>
              <select [(ngModel)]="newYearGroup" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded bg-white">
                @for (yg of store.currentJurisdiction().yearGroups; track yg) {
                  <option [value]="yg">{{ yg }}</option>
                }
              </select>
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Form &amp; House</span>
              <div class="mt-1 flex gap-2">
                <input [(ngModel)]="newFormGroup" placeholder="8B" class="w-1/2 px-3 py-2 border border-slate-300 rounded" />
                <input [(ngModel)]="newHouse" placeholder="Aire" class="w-1/2 px-3 py-2 border border-slate-300 rounded" />
              </div>
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">{{ store.currentJurisdiction().statutoryPupilIdLabel }}</span>
              <input [(ngModel)]="newUpn" placeholder="U815202600112" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded font-mono-tabular" />
            </label>
          </div>

          <div class="mt-5 pt-5 border-t border-slate-200 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Contact Full Name</span>
              <input [(ngModel)]="newContactName" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Relationship</span>
              <input [(ngModel)]="newContactRel" placeholder="Mother (Parental Responsibility)" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
            <label class="block">
              <span class="text-xs font-medium text-slate-700">Email &amp; Phone</span>
              <input [(ngModel)]="newContactEmail" placeholder="parent@example.co.uk" class="mt-1 w-full px-3 py-2 border border-slate-300 rounded" />
            </label>
          </div>

          <div class="mt-4 flex flex-wrap gap-6 text-xs text-slate-700">
            <label class="flex items-center gap-2"><input type="checkbox" [(ngModel)]="flagEmergency" /> Emergency Contact</label>
            <label class="flex items-center gap-2"><input type="checkbox" [(ngModel)]="flagPortal" /> Portal Access</label>
            <label class="flex items-center gap-2"><input type="checkbox" [(ngModel)]="flagCollection" /> Collection Permission</label>
            <label class="flex items-center gap-2"><input type="checkbox" [(ngModel)]="flagRecords" /> Educational Record Access</label>
          </div>

          <div class="mt-5 flex items-center gap-3">
            <button
              type="button"
              (click)="submitEnrolment()"
              [disabled]="saving()"
              class="px-4 py-2 text-sm font-medium bg-[#0F2744] text-white rounded hover:bg-[#17365d] cursor-pointer disabled:opacity-60"
            >
              {{ saving() ? 'Enrolling...' : 'Confirm Enrolment & Verify Contact' }}
            </button>
            @if (statusMessage()) {
              <span class="text-xs text-emerald-700 font-medium">{{ statusMessage() }}</span>
            }
          </div>
        </section>
      }

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Pupil Roll -->
        <section class="lg:col-span-5 bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div class="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h2 class="font-display text-sm font-semibold text-slate-900">
              Pupil Roll ({{ filteredPupils().length }})
            </h2>
            <span class="text-xs text-slate-500">{{ store.currentJurisdiction().name }}</span>
          </div>
          <div class="divide-y divide-slate-200 max-h-[560px] overflow-y-auto">
            @for (pupil of filteredPupils(); track pupil.pupilId) {
              <button
                type="button"
                (click)="selectedPupilId.set(pupil.pupilId)"
                class="w-full text-left px-5 py-3.5 hover:bg-slate-50 transition-colors cursor-pointer"
                [class.bg-slate-100]="activePupil()?.pupilId === pupil.pupilId"
              >
                <div class="flex items-center justify-between gap-2">
                  <span class="text-sm font-medium text-slate-900">
                    {{ pupil.firstName }} {{ pupil.lastName }}
                    @if (pupil.preferredName) {
                      <span class="text-slate-500 font-normal">({{ pupil.preferredName }})</span>
                    }
                  </span>
                  <span class="text-xs font-mono-tabular text-slate-500">{{ pupil.admissionNumber }}</span>
                </div>
                <div class="text-xs text-slate-500 mt-1">
                  {{ pupil.yearGroup }} · Form {{ pupil.formGroup }} · {{ pupil.house }} House
                  @if (pupil.allergyFlag) {
                    <span class="text-red-700 font-medium"> · Allergy Flag</span>
                  }
                </div>
              </button>
            } @empty {
              <p class="p-6 text-sm text-slate-500">No matching pupil records visible for your account.</p>
            }
          </div>
        </section>

        <!-- Pupil Detailed Record + Individual Contacts -->
        <section class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-6">
          @if (activePupil(); as pupil) {
            <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-200">
              <div>
                <h2 class="font-display text-xl font-semibold text-slate-900">
                  {{ pupil.firstName }} {{ pupil.lastName }}
                </h2>
                <p class="text-xs text-slate-600 mt-1">
                  {{ store.currentJurisdiction().statutoryPupilIdLabel }}:
                  <span class="font-mono-tabular font-medium text-slate-800">{{ pupil.upn || 'Pending' }}</span>
                  · DOB <span class="font-mono-tabular">{{ formatDate(pupil.dob) }}</span>
                  · {{ pupil.enrolmentStatus }}
                </p>
              </div>
              <div class="text-right text-xs text-slate-600">
                <div class="font-medium text-slate-900">{{ pupil.yearGroup }} · {{ pupil.formGroup }}</div>
                <div>{{ pupil.house }} House</div>
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 py-5 border-b border-slate-200 text-sm">
              <div>
                <h3 class="text-xs font-semibold text-slate-700 mb-2">Teaching Groups</h3>
                <p class="text-slate-700 font-mono-tabular text-xs">
                  {{ pupil.teachingGroups?.join(' · ') || 'None assigned' }}
                </p>
              </div>
              <div>
                <h3 class="text-xs font-semibold text-slate-700 mb-2">Permissions &amp; Consents</h3>
                <p class="text-xs text-slate-700">
                  Photography: {{ pupil.photoConsent ? 'Granted' : 'Withheld' }} · Blanket Off-site Trips: {{ pupil.tripBlanketConsent ? 'Granted' : 'Requires per-trip consent' }}
                </p>
              </div>
              <div>
                <h3 class="text-xs font-semibold text-slate-700 mb-2">Medical &amp; Allergy Summary</h3>
                <p class="text-xs text-slate-700">
                  {{ pupil.medicalSummary || 'None recorded' }}
                  @if (pupil.allergyFlag) {
                    <span class="block text-red-700 font-medium mt-1">Allergy Alert: {{ pupil.allergyDetails }}</span>
                  }
                </p>
              </div>
              <div>
                <h3 class="text-xs font-semibold text-slate-700 mb-2">SEND &amp; Classroom Adjustments</h3>
                <p class="text-xs text-slate-700">
                  <span class="font-medium">{{ pupil.sendSupportLevel || 'None' }}</span> — {{ pupil.sendAdjustments || pupil.accessibilitySummary || 'No adjustments recorded.' }}
                </p>
              </div>
            </div>

            <!-- Historical Enrolment Preservation -->
            <div class="py-4 border-b border-slate-200">
              <h3 class="text-xs font-semibold text-slate-700 mb-2">Preserved Enrolment History</h3>
              <ul class="space-y-1 text-xs text-slate-600 font-mono-tabular">
                @for (hist of pupil.enrolmentHistory ?? []; track hist) {
                  <li>{{ hist }}</li>
                } @empty {
                  <li>{{ formatDate(pupil.enrolmentDate) }}: Enrolled {{ pupil.yearGroup }}</li>
                }
              </ul>
            </div>

            <!-- Individual Contact Permissions Matrix -->
            <div class="pt-5">
              <h3 class="font-display text-sm font-semibold text-slate-900 mb-3">
                Individual Contact &amp; Permission Matrix
              </h3>
              <div class="space-y-3">
                @for (contact of pupilContacts(); track contact.contactId) {
                  <div class="border border-slate-200 rounded p-4 text-xs">
                    <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div>
                        <span class="text-sm font-semibold text-slate-900">{{ contact.fullName }}</span>
                        <span class="text-slate-500"> · {{ contact.relationship }}</span>
                      </div>
                      <span class="font-medium" [class.text-emerald-700]="contact.verifiedByOffice" [class.text-amber-700]="!contact.verifiedByOffice">
                        {{ contact.verifiedByOffice ? 'Office Verified' : 'Unverified' }}
                      </span>
                    </div>

                    @if (contact.isRestrictedContact) {
                      <p class="text-red-700 font-medium mb-2">
                        Restricted Contact — Court/Safeguarding Flag Active. Address &amp; pickup strictly prohibited.
                      </p>
                    } @else {
                      <p class="text-slate-600 mb-2">
                        {{ contact.email || 'No email' }} · {{ contact.phone || 'No phone' }} · Prefers {{ contact.communicationPreference || 'Portal' }}
                        @if (!contact.sensitiveAddress && contact.addressLine1) {
                          · {{ contact.addressLine1 }}, {{ contact.postcode }}
                        }
                      </p>
                    }

                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100">
                      <label class="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          [checked]="contact.isEmergencyContact"
                          [disabled]="!canEditRecords()"
                          (change)="toggleContactFlag(contact, 'isEmergencyContact', $event)"
                        />
                        <span>Emergency Only</span>
                      </label>
                      <label class="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          [checked]="contact.hasPortalAccess"
                          [disabled]="!canEditRecords() || contact.isRestrictedContact"
                          (change)="toggleContactFlag(contact, 'hasPortalAccess', $event)"
                        />
                        <span>Portal Access</span>
                      </label>
                      <label class="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          [checked]="contact.hasCollectionPermission"
                          [disabled]="!canEditRecords() || contact.isRestrictedContact"
                          (change)="toggleContactFlag(contact, 'hasCollectionPermission', $event)"
                        />
                        <span>Collection</span>
                      </label>
                      <label class="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          [checked]="contact.hasRecordAccess"
                          [disabled]="!canEditRecords() || contact.isRestrictedContact"
                          (change)="toggleContactFlag(contact, 'hasRecordAccess', $event)"
                        />
                        <span>Record Access</span>
                      </label>
                    </div>
                  </div>
                } @empty {
                  <p class="text-xs text-slate-500">No contacts linked or authorised for display.</p>
                }
              </div>
            </div>
          } @else {
            <p class="text-sm text-slate-500">Select a pupil from the roll to view their educational, contact, and medical record.</p>
          }
        </section>
      </div>
    </div>
  `,
})
export class PupilsContactsComponent {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);

  readonly searchQuery = signal('');
  readonly selectedPupilId = signal<string | null>(null);
  readonly showEnrolForm = signal(false);
  readonly saving = signal(false);
  readonly statusMessage = signal('');

  newFirstName = '';
  newLastName = '';
  newDob = '2014-06-15';
  newYearGroup = 'Year 7';
  newFormGroup = '7A';
  newHouse = 'Aire';
  newUpn = 'U815202600401';
  newContactName = '';
  newContactRel = 'Mother (Parental Responsibility)';
  newContactEmail = '';
  flagEmergency = true;
  flagPortal = true;
  flagCollection = true;
  flagRecords = true;

  readonly canEditRecords = computed(() =>
    ['admin', 'office', 'leadership'].includes(this.auth.effectiveRole()),
  );

  readonly filteredPupils = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const list = this.store.visiblePupils();
    if (!q) return list;
    return list.filter(
      (p) =>
        `${p.firstName} ${p.lastName}`.toLowerCase().includes(q) ||
        p.admissionNumber.toLowerCase().includes(q) ||
        p.formGroup.toLowerCase().includes(q),
    );
  });

  readonly activePupil = computed<Pupil | null>(() => {
    const id = this.selectedPupilId();
    const list = this.filteredPupils();
    return list.find((p) => p.pupilId === id) ?? list[0] ?? null;
  });

  readonly pupilContacts = computed(() => {
    const p = this.activePupil();
    if (!p) return [];
    return this.store.contacts().filter((c) => c.pupilId === p.pupilId);
  });

  async submitEnrolment(): Promise<void> {
    if (!this.newFirstName.trim() || !this.newLastName.trim() || !this.newContactName.trim()) {
      this.statusMessage.set('Please complete pupil name and primary contact name.');
      return;
    }
    this.saving.set(true);
    this.statusMessage.set('');
    const uid = this.auth.firebaseUser()?.uid ?? 'office';
    const ts = Date.now().toString(36);
    const pupilId = `pup_${ts}`;
    const contactId = `con_${ts}`;

    const pupil: Pupil = {
      pupilId,
      upn: this.newUpn.trim(),
      admissionNumber: `PA-${Math.floor(2600 + Math.random() * 399)}`,
      firstName: this.newFirstName.trim(),
      lastName: this.newLastName.trim(),
      dob: this.newDob,
      yearGroup: this.newYearGroup,
      formGroup: this.newFormGroup.trim(),
      house: this.newHouse.trim(),
      teachingGroups: [`${this.newFormGroup.trim()}-Ma1`, `${this.newFormGroup.trim()}-En1`],
      enrolmentStatus: 'Enrolled',
      enrolmentDate: new Date().toISOString().slice(0, 10),
      enrolmentHistory: [`${new Date().toISOString().slice(0, 10)}: Enrolled ${this.newYearGroup} (Form ${this.newFormGroup.trim()})`],
      allergyFlag: false,
      sendSupportLevel: 'None',
      photoConsent: true,
      tripBlanketConsent: false,
      ownerUid: uid,
    };

    const contact: ContactRelationship = {
      contactId,
      pupilId,
      fullName: this.newContactName.trim(),
      relationship: this.newContactRel.trim(),
      email: this.newContactEmail.trim(),
      isEmergencyContact: this.flagEmergency,
      hasPortalAccess: this.flagPortal,
      hasCollectionPermission: this.flagCollection,
      hasRecordAccess: this.flagRecords,
      isRestrictedContact: false,
      sensitiveAddress: false,
      communicationPreference: 'Portal',
      verifiedByOffice: true,
      verifiedAt: new Date().toISOString().slice(0, 10),
    };

    try {
      await this.store.enrolPupilAndVerifyContact({ pupil, contact });
      this.selectedPupilId.set(pupilId);
      this.statusMessage.set(`Enrolled ${pupil.firstName} ${pupil.lastName} and verified ${contact.fullName}.`);
      this.newFirstName = '';
      this.newLastName = '';
      this.newContactName = '';
      this.newContactEmail = '';
    } finally {
      this.saving.set(false);
    }
  }

  async toggleContactFlag(
    contact: ContactRelationship,
    field: 'isEmergencyContact' | 'hasPortalAccess' | 'hasCollectionPermission' | 'hasRecordAccess',
    event: Event,
  ): Promise<void> {
    const checked = (event.target as HTMLInputElement).checked;
    await this.store.updateContactPermissions(contact.contactId, { [field]: checked });
  }

  formatDate(d?: string): string {
    return formatUkDate(d);
  }
}
