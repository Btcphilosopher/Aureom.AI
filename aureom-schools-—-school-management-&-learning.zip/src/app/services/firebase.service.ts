import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FirebaseApp, getApp, getApps, initializeApp } from 'firebase/app';
import { Auth, GoogleAuthProvider, getAuth } from 'firebase/auth';
import { Firestore, doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../../firebase-applet-config.json';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

@Injectable({ providedIn: 'root' })
export class FirebaseService {
  private readonly platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);

  readonly app: FirebaseApp | null = null;
  readonly auth: Auth | null = null;
  readonly db: Firestore | null = null;
  readonly googleProvider = new GoogleAuthProvider();

  constructor() {
    if (this.isBrowser) {
      this.app = getApps().length ? getApp() : initializeApp(firebaseConfig);
      this.auth = getAuth(this.app);
      this.db = getFirestore(this.app, firebaseConfig.firestoreDatabaseId);
      this.googleProvider.setCustomParameters({ prompt: 'select_account' });
    }
  }

  async testConnection(): Promise<{ ok: boolean; offline: boolean }> {
    if (!this.db) return { ok: false, offline: false };
    try {
      await getDocFromServer(doc(this.db, 'test', 'connection'));
      return { ok: true, offline: false };
    } catch (error) {
      if (error instanceof Error && error.message.includes('the client is offline')) {
        console.error('Please check your Firebase configuration.');
        return { ok: false, offline: true };
      }
      return { ok: true, offline: false };
    }
  }

  handleFirestoreError(
    error: unknown,
    operationType: OperationType,
    path: string | null,
  ): never {
    const currentUser = this.auth?.currentUser ?? null;
    const errInfo: FirestoreErrorInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: currentUser?.uid ?? null,
        email: currentUser?.email ?? null,
        emailVerified: currentUser?.emailVerified ?? null,
        isAnonymous: currentUser?.isAnonymous ?? null,
        tenantId: currentUser?.tenantId ?? null,
        providerInfo:
          currentUser?.providerData?.map((provider) => ({
            providerId: provider.providerId,
            email: provider.email,
          })) ?? [],
      },
      operationType,
      path,
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  }
}
