import { Injectable, computed, inject, signal } from '@angular/core';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { UserProfile, UserRole } from '../../shared/school-domain';
import { FirebaseService, OperationType } from './firebase.service';

export interface DemoPersona {
  id: string;
  label: string;
  personName: string;
  jobTitle: string;
  role: UserRole;
  schoolId: string;
  linkedPupilIds: string[];
  classFocus?: string;
}

export const DEMO_PERSONAS: DemoPersona[] = [
  {
    id: 'persona_admin',
    label: 'Administrator',
    personName: 'System Administrator',
    jobTitle: 'Trust MIS & Compliance Administrator',
    role: 'admin',
    schoolId: 'pennine-academy',
    linkedPupilIds: [],
  },
  {
    id: 'persona_office',
    label: 'School Office',
    personName: 'Mrs Claire Whitaker',
    jobTitle: 'School Business & Admissions Officer',
    role: 'office',
    schoolId: 'pennine-academy',
    linkedPupilIds: [],
  },
  {
    id: 'persona_teacher',
    label: 'Teacher',
    personName: 'Mr Daniel Greenwood',
    jobTitle: 'Head of Mathematics · Form Tutor 8B',
    role: 'teacher',
    schoolId: 'pennine-academy',
    linkedPupilIds: [],
    classFocus: '8B-Ma1',
  },
  {
    id: 'persona_leadership',
    label: 'Leadership',
    personName: 'Dr Priya Patel',
    jobTitle: 'Headteacher',
    role: 'leadership',
    schoolId: 'pennine-academy',
    linkedPupilIds: [],
  },
  {
    id: 'persona_dsl',
    label: 'Safeguarding Lead',
    personName: 'Ms Hannah Brooks',
    jobTitle: 'Designated Safeguarding Lead (DSL)',
    role: 'dsl',
    schoolId: 'pennine-academy',
    linkedPupilIds: [],
  },
  {
    id: 'persona_parent',
    label: 'Parent / Carer',
    personName: 'Mrs Sarah Thornton',
    jobTitle: 'Verified Parent (Oliver Thornton · Year 8)',
    role: 'parent',
    schoolId: 'pennine-academy',
    linkedPupilIds: ['pup_oliver'],
  },
  {
    id: 'persona_pupil',
    label: 'Pupil',
    personName: 'Oliver Thornton',
    jobTitle: 'Year 8 · Form 8B · Aire House',
    role: 'pupil',
    schoolId: 'pennine-academy',
    linkedPupilIds: ['pup_oliver'],
  },
];

export type AppModuleId =
  | 'home'
  | 'pupils'
  | 'admissions'
  | 'attendance'
  | 'timetable'
  | 'learning'
  | 'pastoral'
  | 'safeguarding'
  | 'send_medical'
  | 'trips_payments'
  | 'comms'
  | 'admin_audit';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly fb = inject(FirebaseService);

  readonly firebaseUser = signal<User | null>(null);
  readonly authReady = signal(false);
  readonly profile = signal<UserProfile | null>(null);
  readonly activeSchoolId = signal<string>('pennine-academy');
  readonly activePersona = signal<DemoPersona>(DEMO_PERSONAS[0]);
  readonly authError = signal<string | null>(null);
  readonly signingIn = signal(false);
  readonly connectionOffline = signal(false);

  // Kept strictly in JS memory, never localStorage
  private idTokenMemory: string | null = null;

  readonly isBootstrappedAdmin = computed(() => {
    const email = this.firebaseUser()?.email?.toLowerCase();
    return email === 'tom@ahyx.org' || this.profile()?.role === 'admin';
  });

  readonly effectiveRole = computed<UserRole>(() => {
    if (this.isBootstrappedAdmin()) {
      return this.activePersona().role;
    }
    return this.profile()?.role ?? 'parent';
  });

  readonly effectivePersonName = computed(() => {
    if (this.isBootstrappedAdmin()) {
      return this.activePersona().personName;
    }
    return this.profile()?.displayName ?? this.firebaseUser()?.displayName ?? 'Verified User';
  });

  readonly effectiveLinkedPupilIds = computed<string[]>(() => {
    if (this.isBootstrappedAdmin()) {
      return this.activePersona().linkedPupilIds;
    }
    return this.profile()?.linkedPupilIds ?? [];
  });

  readonly allowedModules = computed<AppModuleId[]>(() => {
    const role = this.effectiveRole();
    switch (role) {
      case 'admin':
        return [
          'home',
          'pupils',
          'admissions',
          'attendance',
          'timetable',
          'learning',
          'pastoral',
          'safeguarding',
          'send_medical',
          'trips_payments',
          'comms',
          'admin_audit',
        ];
      case 'leadership':
        return [
          'home',
          'pupils',
          'admissions',
          'attendance',
          'timetable',
          'learning',
          'pastoral',
          'send_medical',
          'trips_payments',
          'comms',
          'admin_audit',
        ];
      case 'dsl':
        return ['home', 'safeguarding', 'pupils', 'pastoral', 'send_medical', 'attendance', 'comms'];
      case 'office':
        return [
          'home',
          'pupils',
          'admissions',
          'attendance',
          'timetable',
          'send_medical',
          'trips_payments',
          'comms',
          'safeguarding',
        ];
      case 'teacher':
        return [
          'home',
          'attendance',
          'timetable',
          'learning',
          'pupils',
          'pastoral',
          'send_medical',
          'safeguarding',
          'comms',
        ];
      case 'parent':
        return ['home', 'attendance', 'timetable', 'learning', 'trips_payments', 'comms'];
      case 'pupil':
        return ['home', 'timetable', 'learning', 'attendance', 'comms'];
    }
  });

  constructor() {
    if (this.fb.isBrowser && this.fb.auth) {
      this.fb.testConnection().then((res) => {
        this.connectionOffline.set(res.offline);
      });

      onAuthStateChanged(this.fb.auth, async (user) => {
        this.firebaseUser.set(user);
        if (user) {
          try {
            this.idTokenMemory = await user.getIdToken();
            await this.ensureUserProfile(user);
          } catch (err) {
            this.authError.set(err instanceof Error ? err.message : 'Unable to load user profile.');
          }
        } else {
          this.idTokenMemory = null;
          this.profile.set(null);
        }
        this.authReady.set(true);
      });
    } else {
      this.authReady.set(true);
    }
  }

  async getBearerToken(): Promise<string | null> {
    const user = this.fb.auth?.currentUser;
    if (!user) return null;
    this.idTokenMemory = await user.getIdToken();
    return this.idTokenMemory;
  }

  async signInWithGoogle(): Promise<void> {
    if (!this.fb.auth) return;
    this.signingIn.set(true);
    this.authError.set(null);
    try {
      await signInWithPopup(this.fb.auth, this.fb.googleProvider);
    } catch (err) {
      this.authError.set(err instanceof Error ? err.message : 'Google sign-in failed.');
    } finally {
      this.signingIn.set(false);
    }
  }

  async signOut(): Promise<void> {
    if (!this.fb.auth) return;
    this.idTokenMemory = null;
    await firebaseSignOut(this.fb.auth);
  }

  setDemoPersona(personaId: string): void {
    if (!this.isBootstrappedAdmin()) return;
    const found = DEMO_PERSONAS.find((p) => p.id === personaId);
    if (found) {
      this.activePersona.set(found);
      if (found.schoolId !== this.activeSchoolId()) {
        this.activeSchoolId.set(found.schoolId);
      }
    }
  }

  setActiveSchool(schoolId: string): void {
    if (!this.isBootstrappedAdmin()) return;
    this.activeSchoolId.set(schoolId);
  }

  canAccessModule(moduleId: AppModuleId): boolean {
    return this.allowedModules().includes(moduleId);
  }

  private async ensureUserProfile(user: User): Promise<void> {
    if (!this.fb.db) return;
    const path = `users/${user.uid}`;
    const ref = doc(this.fb.db, 'users', user.uid);
    try {
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        this.profile.set(data);
        return;
      }

      const isBootstrapAdmin = user.email?.toLowerCase() === 'tom@ahyx.org';
      const newProfile: UserProfile = {
        uid: user.uid,
        email: user.email ?? '',
        displayName: user.displayName ?? user.email ?? 'Authenticated User',
        schoolId: 'pennine-academy',
        role: isBootstrapAdmin ? 'admin' : 'parent',
        activePersonaId: isBootstrapAdmin ? 'persona_admin' : 'persona_parent',
        linkedPupilIds: [],
        verifiedByOffice: isBootstrapAdmin,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await setDoc(ref, newProfile);
      this.profile.set(newProfile);
    } catch (error) {
      this.fb.handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
}
