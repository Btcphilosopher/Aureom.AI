import { Injectable, computed, effect, inject, signal } from '@angular/core';
import {
  Unsubscribe,
  collection,
  doc,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  AbsenceRequest,
  ActivityBooking,
  AdmissionRecord,
  Announcement,
  AttendanceSession,
  AuditLog,
  BehaviourEvent,
  ContactRelationship,
  HomeworkSubmission,
  HomeworkTask,
  MedicalPlan,
  Pupil,
  SafeguardingConcern,
  SchoolConfig,
  StaffMember,
  TimetableEntry,
  TripOrActivity,
  UK_JURISDICTIONS,
  calculateAttendanceSummary,
} from '../../shared/school-domain';
import { AuthService } from './auth.service';
import { FirebaseService, OperationType } from './firebase.service';
import { SeedDataService } from './seed-data.service';

export interface OfflineQueuedMark {
  sessionId: string;
  pupilId: string;
  pupilName: string;
  date: string;
  sessionType: 'AM' | 'PM' | 'LESSON';
  code: string;
  localTimestamp: string;
  serverCodeAtSync?: string;
}

@Injectable({ providedIn: 'root' })
export class SchoolStoreService {
  private readonly fb = inject(FirebaseService);
  private readonly auth = inject(AuthService);
  private readonly seed = inject(SeedDataService);

  readonly loading = signal(true);
  readonly seeding = signal(false);
  readonly lastSyncAt = signal<string | null>(null);
  readonly simulatedOffline = signal(false);
  readonly offlineQueue = signal<OfflineQueuedMark[]>([]);
  readonly syncConflicts = signal<OfflineQueuedMark[]>([]);

  readonly schoolConfig = signal<SchoolConfig | null>(null);
  readonly staff = signal<StaffMember[]>([]);
  readonly pupils = signal<Pupil[]>([]);
  readonly contacts = signal<ContactRelationship[]>([]);
  readonly admissions = signal<AdmissionRecord[]>([]);
  readonly attendanceSessions = signal<AttendanceSession[]>([]);
  readonly absenceRequests = signal<AbsenceRequest[]>([]);
  readonly timetableEntries = signal<TimetableEntry[]>([]);
  readonly homework = signal<HomeworkTask[]>([]);
  readonly submissions = signal<HomeworkSubmission[]>([]);
  readonly behaviourEvents = signal<BehaviourEvent[]>([]);
  readonly safeguardingConcerns = signal<SafeguardingConcern[]>([]);
  readonly medicalPlans = signal<MedicalPlan[]>([]);
  readonly trips = signal<TripOrActivity[]>([]);
  readonly bookings = signal<ActivityBooking[]>([]);
  readonly announcements = signal<Announcement[]>([]);
  readonly auditLogs = signal<AuditLog[]>([]);

  private unsubs: Unsubscribe[] = [];

  // Role-scoped visible pupils: Parents/Pupils see ONLY their verified linked children!
  readonly visiblePupils = computed(() => {
    const role = this.auth.effectiveRole();
    const all = this.pupils();
    if (role === 'parent' || role === 'pupil') {
      const linked = this.auth.effectiveLinkedPupilIds();
      return all.filter((p) => linked.includes(p.pupilId));
    }
    return all;
  });

  readonly visibleAttendance = computed(() => {
    const allowedIds = new Set(this.visiblePupils().map((p) => p.pupilId));
    return this.attendanceSessions().filter((s) => allowedIds.has(s.pupilId));
  });

  readonly visibleAbsenceRequests = computed(() => {
    const allowedIds = new Set(this.visiblePupils().map((p) => p.pupilId));
    return this.absenceRequests().filter((r) => allowedIds.has(r.pupilId));
  });

  readonly visibleSubmissions = computed(() => {
    const allowedIds = new Set(this.visiblePupils().map((p) => p.pupilId));
    return this.submissions().filter((s) => allowedIds.has(s.pupilId));
  });

  readonly visibleBookings = computed(() => {
    const allowedIds = new Set(this.visiblePupils().map((p) => p.pupilId));
    return this.bookings().filter((b) => allowedIds.has(b.pupilId));
  });

  readonly visibleBehaviour = computed(() => {
    const allowedIds = new Set(this.visiblePupils().map((p) => p.pupilId));
    return this.behaviourEvents().filter((b) => allowedIds.has(b.pupilId));
  });

  readonly currentJurisdiction = computed(() => {
    const j = this.schoolConfig()?.jurisdiction ?? 'england_dfe';
    return UK_JURISDICTIONS[j] ?? UK_JURISDICTIONS.england_dfe;
  });

  readonly schoolAttendanceSummary = computed(() => {
    const j = this.schoolConfig()?.jurisdiction ?? 'england_dfe';
    return calculateAttendanceSummary(this.visibleAttendance(), j);
  });

  readonly registerCacheAgeLabel = computed(() => {
    const sync = this.lastSyncAt();
    if (!sync) return 'Not yet synced';
    const diffMs = Date.now() - new Date(sync).getTime();
    const mins = Math.max(0, Math.floor(diffMs / 60000));
    if (mins === 0) return 'Synced less than 1 minute ago';
    return `Cached ${mins} min ago`;
  });

  constructor() {
    if (this.fb.isBrowser) {
      window.addEventListener('offline', () => this.simulatedOffline.set(true));
      window.addEventListener('online', () => this.simulatedOffline.set(false));

      effect(() => {
        const user = this.auth.firebaseUser();
        const ready = this.auth.authReady();
        const schoolId = this.auth.activeSchoolId();
        const role = this.auth.effectiveRole();

        if (!ready) return;
        this.clearListeners();

        if (!user || !user.emailVerified) {
          this.resetState();
          this.loading.set(false);
          return;
        }

        void this.bootSchoolData(user.uid, schoolId, role);
      });
    } else {
      this.loading.set(false);
    }
  }

  private clearListeners(): void {
    for (const u of this.unsubs) u();
    this.unsubs = [];
  }

  private resetState(): void {
    this.schoolConfig.set(null);
    this.staff.set([]);
    this.pupils.set([]);
    this.contacts.set([]);
    this.admissions.set([]);
    this.attendanceSessions.set([]);
    this.absenceRequests.set([]);
    this.timetableEntries.set([]);
    this.homework.set([]);
    this.submissions.set([]);
    this.behaviourEvents.set([]);
    this.safeguardingConcerns.set([]);
    this.medicalPlans.set([]);
    this.trips.set([]);
    this.bookings.set([]);
    this.announcements.set([]);
    this.auditLogs.set([]);
  }

  private async bootSchoolData(uid: string, schoolId: string, role: string): Promise<void> {
    if (!this.fb.db) return;
    this.loading.set(true);

    if (this.auth.isBootstrappedAdmin()) {
      this.seeding.set(true);
      try {
        await this.seed.seedIfEmpty(uid);
      } finally {
        this.seeding.set(false);
      }
    }

    const db = this.fb.db;
    const isAdminOrStaff = this.auth.isBootstrappedAdmin() || ['leadership', 'dsl', 'teacher', 'office'].includes(role);
    const isDslOrAdmin = this.auth.isBootstrappedAdmin() || role === 'dsl';

    const attach = <T>(
      subPath: string,
      setter: (items: T[]) => void,
      queryBuilder?: () => ReturnType<typeof query>,
    ) => {
      const fullPath = `schools/${schoolId}/${subPath}`;
      const target = queryBuilder ? queryBuilder() : collection(db, 'schools', schoolId, subPath);
      const unsub = onSnapshot(
        target,
        (snap) => {
          const items = snap.docs.map((d) => d.data() as T);
          setter(items);
          this.lastSyncAt.set(new Date().toISOString());
        },
        (err) => {
          this.fb.handleFirestoreError(err, OperationType.GET, fullPath);
        },
      );
      this.unsubs.push(unsub);
    };

    // School config
    this.unsubs.push(
      onSnapshot(
        doc(db, 'schools', schoolId),
        (snap) => {
          this.schoolConfig.set(snap.exists() ? (snap.data() as SchoolConfig) : null);
          this.loading.set(false);
        },
        (err) => {
          this.loading.set(false);
          this.fb.handleFirestoreError(err, OperationType.GET, `schools/${schoolId}`);
        },
      ),
    );

    // Public-to-school collections
    attach<TimetableEntry>('timetableEntries', (v) => this.timetableEntries.set(v));
    attach<HomeworkTask>('homework', (v) => this.homework.set(v));
    attach<TripOrActivity>('trips', (v) => this.trips.set(v));
    attach<Announcement>('announcements', (v) => this.announcements.set(v));

    if (isAdminOrStaff) {
      attach<StaffMember>('staff', (v) => this.staff.set(v));
      attach<Pupil>('pupils', (v) => this.pupils.set(v));
      attach<ContactRelationship>('contacts', (v) => this.contacts.set(v));
      attach<AdmissionRecord>('admissions', (v) => this.admissions.set(v));
      attach<AttendanceSession>('attendanceSessions', (v) => this.attendanceSessions.set(v));
      attach<AbsenceRequest>('absenceRequests', (v) => this.absenceRequests.set(v));
      attach<HomeworkSubmission>('submissions', (v) => this.submissions.set(v));
      attach<BehaviourEvent>('behaviourEvents', (v) => this.behaviourEvents.set(v));
      attach<MedicalPlan>('medicalPlans', (v) => this.medicalPlans.set(v));
      attach<ActivityBooking>('bookings', (v) => this.bookings.set(v));
      attach<AuditLog>('auditLogs', (v) =>
        this.auditLogs.set([...v].sort((a, b) => b.createdAt.localeCompare(a.createdAt))),
      );
    } else {
      // Non-admin parents/pupils: strictly scoped queries
      attach<Pupil>('pupils', (v) => this.pupils.set(v), () =>
        query(collection(db, 'schools', schoolId, 'pupils'), where('ownerUid', '==', uid)),
      );
      attach<AbsenceRequest>('absenceRequests', (v) => this.absenceRequests.set(v), () =>
        query(collection(db, 'schools', schoolId, 'absenceRequests'), where('submittedByUid', '==', uid)),
      );
      attach<ActivityBooking>('bookings', (v) => this.bookings.set(v), () =>
        query(collection(db, 'schools', schoolId, 'bookings'), where('parentUid', '==', uid)),
      );
      attach<HomeworkSubmission>('submissions', (v) => this.submissions.set(v), () =>
        query(collection(db, 'schools', schoolId, 'submissions'), where('pupilId', '==', uid)),
      );
    }

    // Safeguarding: NEVER attach listener for Parents, Pupils, Office, or general Teachers!
    if (isDslOrAdmin) {
      attach<SafeguardingConcern>('safeguardingConcerns', (v) => this.safeguardingConcerns.set(v));
    } else {
      this.safeguardingConcerns.set([]);
    }
  }

  async logAudit(
    module: string,
    action: string,
    targetType: string,
    targetId: string,
    summary: string,
  ): Promise<void> {
    if (!this.fb.db || !this.auth.firebaseUser()) return;
    const schoolId = this.auth.activeSchoolId();
    const uid = this.auth.firebaseUser()!.uid;
    const logId = `aud_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
    const entry: AuditLog = {
      logId,
      actorUid: uid,
      actorName: this.auth.effectivePersonName(),
      actorRole: this.auth.effectiveRole(),
      module,
      action,
      targetType,
      targetId,
      summary: summary.slice(0, 295),
      createdAt: new Date().toISOString(),
    };
    const path = `schools/${schoolId}/auditLogs/${logId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'auditLogs', logId), entry);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  // ---------------------------------------------------------------------------
  // Domain Mutations (all persisted to Firestore + Audit Logged)
  // ---------------------------------------------------------------------------
  async updateSchoolBranding(patch: Partial<SchoolConfig>): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}`;
    try {
      await updateDoc(doc(this.fb.db, 'schools', schoolId), patch);
      await this.logAudit('Administration', 'SCHOOL_BRANDING_UPDATED', 'school', schoolId, `Updated school configuration (${Object.keys(patch).join(', ')}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }

  async enrolPupilAndVerifyContact(payload: {
    applicationId?: string;
    pupil: Pupil;
    contact: ContactRelationship;
  }): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const batch = writeBatch(this.fb.db);
    batch.set(doc(this.fb.db, 'schools', schoolId, 'pupils', payload.pupil.pupilId), payload.pupil);
    batch.set(doc(this.fb.db, 'schools', schoolId, 'contacts', payload.contact.contactId), payload.contact);
    if (payload.applicationId) {
      batch.update(doc(this.fb.db, 'schools', schoolId, 'admissions', payload.applicationId), {
        stage: 'enrolled',
      });
    }
    try {
      await batch.commit();
      await this.logAudit(
        'Admissions & Pupils',
        'PUPIL_ENROLLED_CONTACT_VERIFIED',
        'pupil',
        payload.pupil.pupilId,
        `Enrolled ${payload.pupil.firstName} ${payload.pupil.lastName} (${payload.pupil.yearGroup}) and verified ${payload.contact.fullName} permissions.`,
      );
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.WRITE, `schools/${schoolId}/pupils/${payload.pupil.pupilId}`);
    }
  }

  async updateContactPermissions(contactId: string, patch: Partial<ContactRelationship>): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/contacts/${contactId}`;
    try {
      await updateDoc(doc(this.fb.db, 'schools', schoolId, 'contacts', contactId), patch);
      await this.logAudit('Contacts', 'CONTACT_PERMISSIONS_UPDATED', 'contact', contactId, `Updated contact relationship flags (${Object.keys(patch).join(', ')}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }

  async recordAttendanceMark(session: AttendanceSession, pupilName: string): Promise<void> {
    if (this.simulatedOffline()) {
      const queued: OfflineQueuedMark = {
        sessionId: session.sessionId,
        pupilId: session.pupilId,
        pupilName,
        date: session.date,
        sessionType: session.sessionType,
        code: session.code,
        localTimestamp: new Date().toISOString(),
      };
      this.offlineQueue.update((prev) => [
        ...prev.filter((item) => item.sessionId !== session.sessionId),
        queued,
      ]);
      return;
    }

    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/attendanceSessions/${session.sessionId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'attendanceSessions', session.sessionId), session);
      await this.logAudit(
        'Attendance',
        'REGISTER_MARK_RECORDED',
        'attendanceSession',
        session.sessionId,
        `Recorded code ${session.code} (${session.codeVersion}) for ${pupilName} (${session.sessionType} ${session.date}).`,
      );
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  async syncOfflineRegisters(): Promise<void> {
    if (this.simulatedOffline() || !this.fb.db) return;
    const queue = this.offlineQueue();
    const existing = this.attendanceSessions();
    const conflicts: OfflineQueuedMark[] = [];
    const schoolId = this.auth.activeSchoolId();

    for (const item of queue) {
      const serverMatch = existing.find((s) => s.sessionId === item.sessionId);
      if (serverMatch && serverMatch.code !== item.code && serverMatch.reconciledByOffice) {
        conflicts.push({ ...item, serverCodeAtSync: serverMatch.code });
      } else {
        await setDoc(doc(this.fb.db, 'schools', schoolId, 'attendanceSessions', item.sessionId), {
          sessionId: item.sessionId,
          pupilId: item.pupilId,
          date: item.date,
          sessionType: item.sessionType,
          code: item.code,
          codeVersion: this.currentJurisdiction().attendanceCodeVersion,
          isAuthorised: item.code === '/' || item.code === '\\' || item.code === 'L',
          recordedByUid: this.auth.firebaseUser()?.uid ?? 'offline_sync',
          reconciledByOffice: false,
          recordedAt: item.localTimestamp,
        } satisfies AttendanceSession);
      }
    }

    this.offlineQueue.set([]);
    this.syncConflicts.set(conflicts);
    await this.logAudit('Attendance', 'OFFLINE_SYNC_COMPLETED', 'school', schoolId, `Synchronised cached registers (${conflicts.length} conflict(s) flagged for review).`);
  }

  async resolveSyncConflict(sessionId: string, resolution: 'keep_local' | 'keep_server'): Promise<void> {
    const conflict = this.syncConflicts().find((c) => c.sessionId === sessionId);
    if (!conflict || !this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    if (resolution === 'keep_local') {
      await updateDoc(doc(this.fb.db, 'schools', schoolId, 'attendanceSessions', sessionId), {
        code: conflict.code,
        reconciledByOffice: true,
        explanation: 'Resolved offline register conflict in favour of teacher mark',
      });
    }
    this.syncConflicts.update((list) => list.filter((c) => c.sessionId !== sessionId));
    await this.logAudit('Attendance', 'OFFLINE_CONFLICT_RESOLVED', 'attendanceSession', sessionId, `Resolved sync conflict (${resolution}).`);
  }

  async submitAbsenceRequest(req: AbsenceRequest): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/absenceRequests/${req.requestId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'absenceRequests', req.requestId), req);
      await this.logAudit('Attendance', 'PARENT_ABSENCE_SUBMITTED', 'absenceRequest', req.requestId, `Parent absence notification submitted for ${req.startDate}.`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  async reviewAbsenceRequest(
    request: AbsenceRequest,
    decision: 'authorised' | 'unauthorised' | 'more_info_needed',
    code: string,
  ): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const batch = writeBatch(this.fb.db);
    batch.update(doc(this.fb.db, 'schools', schoolId, 'absenceRequests', request.requestId), {
      status: decision,
      schoolDecisionCode: code,
      reviewedByName: this.auth.effectivePersonName(),
    });

    if (decision === 'authorised' || decision === 'unauthorised') {
      const sessionId = `att_${request.pupilId}_${request.startDate}_AM`;
      batch.set(doc(this.fb.db, 'schools', schoolId, 'attendanceSessions', sessionId), {
        sessionId,
        pupilId: request.pupilId,
        date: request.startDate,
        sessionType: 'AM',
        code,
        codeVersion: this.currentJurisdiction().attendanceCodeVersion,
        isAuthorised: decision === 'authorised',
        explanation: `Office decision on parent submission: ${request.reason}`,
        recordedByUid: this.auth.firebaseUser()?.uid ?? 'office',
        reconciledByOffice: true,
        recordedAt: new Date().toISOString(),
      } satisfies AttendanceSession);
    }

    try {
      await batch.commit();
      await this.logAudit('Attendance', 'ABSENCE_REVIEWED', 'absenceRequest', request.requestId, `Office reviewed parent absence -> ${decision} (code ${code}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.UPDATE, `schools/${schoolId}/absenceRequests/${request.requestId}`);
    }
  }

  async saveTimetableEntry(entry: TimetableEntry): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/timetableEntries/${entry.entryId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'timetableEntries', entry.entryId), entry);
      await this.logAudit('Timetable', 'TIMETABLE_UPDATED', 'timetableEntry', entry.entryId, `Published ${entry.classCode} (${entry.dayOfWeek} P${entry.period}, ${entry.roomCode}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  async publishHomework(task: HomeworkTask): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/homework/${task.homeworkId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'homework', task.homeworkId), task);
      await this.logAudit('Learning', 'HOMEWORK_PUBLISHED', 'homework', task.homeworkId, `Set homework "${task.title}" for ${task.classCode} (due ${task.dueDate}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  async submitHomework(sub: HomeworkSubmission): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/submissions/${sub.submissionId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'submissions', sub.submissionId), sub);
      await this.logAudit('Learning', 'HOMEWORK_SUBMITTED', 'submission', sub.submissionId, `${sub.pupilName} submitted work (${sub.submissionFormat}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  async markSubmission(submissionId: string, patch: Partial<HomeworkSubmission>): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/submissions/${submissionId}`;
    try {
      await updateDoc(doc(this.fb.db, 'schools', schoolId, 'submissions', submissionId), {
        ...patch,
        status: 'marked',
        markedAt: new Date().toISOString(),
      });
      await this.logAudit('Learning', 'HOMEWORK_MARKED', 'submission', submissionId, `Recorded mark and feedback (judgement: ${patch.teacherJudgement ?? 'Recorded'}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }

  async addBehaviourEvent(event: BehaviourEvent): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/behaviourEvents/${event.eventId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'behaviourEvents', event.eventId), event);
      await this.logAudit('Pastoral', 'BEHAVIOUR_LOGGED', 'behaviourEvent', event.eventId, `Logged ${event.category} for ${event.pupilName}.`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  async amendBehaviourEvent(eventId: string, revisionNote: string, reviewStatus: 'reviewed' | 'amended'): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/behaviourEvents/${eventId}`;
    try {
      await updateDoc(doc(this.fb.db, 'schools', schoolId, 'behaviourEvents', eventId), {
        revisionNote,
        reviewStatus,
      });
      await this.logAudit('Pastoral', 'BEHAVIOUR_REVIEWED', 'behaviourEvent', eventId, `Behaviour record status updated to ${reviewStatus}.`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }

  async submitSafeguardingConcern(concern: SafeguardingConcern): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/safeguardingConcerns/${concern.concernId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'safeguardingConcerns', concern.concernId), concern);
      await this.logAudit('Safeguarding', 'CONCERN_LOGGED', 'safeguardingConcern', concern.concernId, `Safeguarding concern submitted (status: submitted_unacknowledged; contents redacted from general audit).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  async updateSafeguardingConcern(concernId: string, patch: Partial<SafeguardingConcern>): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/safeguardingConcerns/${concernId}`;
    try {
      await updateDoc(doc(this.fb.db, 'schools', schoolId, 'safeguardingConcerns', concernId), patch);
      await this.logAudit('Safeguarding', 'CONCERN_WORKFLOW_UPDATED', 'safeguardingConcern', concernId, `DSL updated concern workflow to ${patch.status ?? 'updated'}.`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }

  async saveMedicalPlan(plan: MedicalPlan): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/medicalPlans/${plan.planId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'medicalPlans', plan.planId), plan);
      await this.logAudit('SEND & Medical', 'HEALTHCARE_PLAN_SAVED', 'medicalPlan', plan.planId, `Updated Healthcare Plan for ${plan.pupilName}.`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  async saveTripBooking(booking: ActivityBooking, incrementEnrolledBy: number): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const batch = writeBatch(this.fb.db);
    batch.set(doc(this.fb.db, 'schools', schoolId, 'bookings', booking.bookingId), booking);
    const trip = this.trips().find((t) => t.tripId === booking.tripId);
    if (trip && incrementEnrolledBy !== 0) {
      batch.update(doc(this.fb.db, 'schools', schoolId, 'trips', trip.tripId), {
        enrolledCount: Math.max(0, trip.enrolledCount + incrementEnrolledBy),
      });
    }
    try {
      await batch.commit();
      await this.logAudit(
        'Trips & Payments',
        'BOOKING_RECONCILED',
        'booking',
        booking.bookingId,
        `Booking ${booking.bookingStatus} / payment ${booking.paymentStatus} (${booking.receiptRef ?? 'unpaid'}) for ${booking.pupilName}.`,
      );
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.WRITE, `schools/${schoolId}/bookings/${booking.bookingId}`);
    }
  }

  async publishAnnouncement(ann: Announcement): Promise<void> {
    if (!this.fb.db) return;
    const schoolId = this.auth.activeSchoolId();
    const path = `schools/${schoolId}/announcements/${ann.announcementId}`;
    try {
      await setDoc(doc(this.fb.db, 'schools', schoolId, 'announcements', ann.announcementId), ann);
      await this.logAudit('Communications', 'ANNOUNCEMENT_PUBLISHED', 'announcement', ann.announcementId, `Published "${ann.title}" to ${ann.recipientCount} recipients (${ann.deliveryState}).`);
    } catch (err) {
      this.fb.handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  async runAcademicYearTransition(): Promise<number> {
    if (!this.fb.db) return 0;
    const schoolId = this.auth.activeSchoolId();
    const yearOrder = this.currentJurisdiction().yearGroups;
    const batch = writeBatch(this.fb.db);
    let promoted = 0;

    for (const p of this.pupils()) {
      if (p.enrolmentStatus !== 'Enrolled') continue;
      const idx = yearOrder.indexOf(p.yearGroup);
      if (idx >= 0 && idx < yearOrder.length - 1) {
        const nextYear = yearOrder[idx + 1];
        const history = [...(p.enrolmentHistory ?? []), `${new Date().toISOString().slice(0, 10)}: Transitioned ${p.yearGroup} -> ${nextYear}`];
        batch.update(doc(this.fb.db, 'schools', schoolId, 'pupils', p.pupilId), {
          yearGroup: nextYear,
          enrolmentHistory: history.slice(-10),
        });
        promoted += 1;
      }
    }

    await batch.commit();
    await this.logAudit('Academic Structure', 'ACADEMIC_YEAR_TRANSITION', 'school', schoolId, `Promoted ${promoted} enrolled pupils while preserving historical enrolment logs.`);
    return promoted;
  }

  async resetDemoData(): Promise<void> {
    const uid = this.auth.firebaseUser()?.uid;
    if (!uid) return;
    this.seeding.set(true);
    try {
      await this.seed.seedAllTenants(uid);
      await this.logAudit('Administration', 'DEMO_DATA_SEEDED', 'school', this.auth.activeSchoolId(), 'Restored Pennine Academy & Lothian Brae High demonstration records.');
    } finally {
      this.seeding.set(false);
    }
  }
}
