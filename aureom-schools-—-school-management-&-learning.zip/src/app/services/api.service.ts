import { Injectable, inject } from '@angular/core';
import {
  AttendanceSession,
  AttendanceSummaryResult,
  CsvImportRow,
  TimetableClash,
  TimetableEntry,
  UkJurisdiction,
} from '../../shared/school-domain';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly auth = inject(AuthService);

  private async authHeaders(): Promise<Record<string, string>> {
    const token = await this.auth.getBearerToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  async calculateAttendance(
    sessions: AttendanceSession[],
    jurisdiction: UkJurisdiction,
    enrolledFromDate?: string,
  ): Promise<AttendanceSummaryResult> {
    const res = await fetch('/api/attendance/calculate', {
      method: 'POST',
      headers: await this.authHeaders(),
      body: JSON.stringify({ sessions, jurisdiction, enrolledFromDate }),
    });
    if (!res.ok) {
      throw new Error(`Attendance calculation failed (${res.status})`);
    }
    return (await res.json()) as AttendanceSummaryResult;
  }

  async validateTimetable(
    entries: TimetableEntry[],
  ): Promise<{ valid: boolean; clashes: TimetableClash[] }> {
    const res = await fetch('/api/timetable/validate', {
      method: 'POST',
      headers: await this.authHeaders(),
      body: JSON.stringify({ entries }),
    });
    if (!res.ok) {
      throw new Error(`Timetable validation failed (${res.status})`);
    }
    return (await res.json()) as { valid: boolean; clashes: TimetableClash[] };
  }

  async validateAdmissionsCsv(
    csvText: string,
    existingPupils: { pupilId: string; firstName: string; lastName: string; dob: string }[],
  ): Promise<{ validRows: CsvImportRow[]; invalidRows: CsvImportRow[]; duplicateCount: number }> {
    const res = await fetch('/api/admissions/validate-csv', {
      method: 'POST',
      headers: await this.authHeaders(),
      body: JSON.stringify({ csvText, existingPupils }),
    });
    if (!res.ok) {
      throw new Error(`CSV validation failed (${res.status})`);
    }
    return (await res.json()) as {
      validRows: CsvImportRow[];
      invalidRows: CsvImportRow[];
      duplicateCount: number;
    };
  }

  async simulatePayment(payload: {
    idempotencyKey: string;
    amountPence: number;
    tripId: string;
    pupilId: string;
  }): Promise<{
    receiptRef: string;
    amountPence: number;
    currency: 'GBP';
    paymentStatus: 'simulated_paid';
    processedAt: string;
    duplicatePrevented: boolean;
  }> {
    const res = await fetch('/api/payments/simulate', {
      method: 'POST',
      headers: await this.authHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      throw new Error(`Payment simulation failed (${res.status})`);
    }
    return (await res.json()) as {
      receiptRef: string;
      amountPence: number;
      currency: 'GBP';
      paymentStatus: 'simulated_paid';
      processedAt: string;
      duplicatePrevented: boolean;
    };
  }

  async requestAiAssist(payload: {
    mode: 'lesson_resource' | 'announcement' | 'report_draft' | 'policy_search';
    prompt: string;
    context?: string;
  }): Promise<{
    draft: string;
    requiresStaffReview: boolean;
    piiRedacted: boolean;
    citations: string[];
  }> {
    const res = await fetch('/api/ai/assist', {
      method: 'POST',
      headers: await this.authHeaders(),
      body: JSON.stringify(payload),
    });
    const data = (await res.json()) as {
      draft?: string;
      requiresStaffReview?: boolean;
      piiRedacted?: boolean;
      citations?: string[];
      error?: string;
    };
    if (!res.ok) {
      throw new Error(data.error ?? `AI assistant error (${res.status})`);
    }
    return {
      draft: data.draft ?? '',
      requiresStaffReview: data.requiresStaffReview ?? true,
      piiRedacted: data.piiRedacted ?? false,
      citations: data.citations ?? [],
    };
  }
}
