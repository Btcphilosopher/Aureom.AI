import { Injectable, inject } from '@angular/core';
import { doc, getDoc, writeBatch } from 'firebase/firestore';
import {
  AbsenceRequest,
  ActivityBooking,
  AdmissionRecord,
  Announcement,
  AttendanceSession,
  AuditLog,
  BehaviourEvent,
  ContactRelationship,
  HomeworkSubmission,
  HomeworkTask,
  MedicalPlan,
  Pupil,
  SafeguardingConcern,
  SchoolConfig,
  StaffMember,
  TimetableEntry,
  TripOrActivity,
} from '../../shared/school-domain';
import { FirebaseService, OperationType } from './firebase.service';

@Injectable({ providedIn: 'root' })
export class SeedDataService {
  private readonly fb = inject(FirebaseService);

  async seedIfEmpty(ownerUid: string): Promise<boolean> {
    if (!this.fb.db) return false;
    const schoolRef = doc(this.fb.db, 'schools', 'pennine-academy');
    try {
      const snap = await getDoc(schoolRef);
      if (snap.exists()) {
        return false;
      }
      await this.seedAllTenants(ownerUid);
      return true;
    } catch (err) {
      return this.fb.handleFirestoreError(err, OperationType.GET, 'schools/pennine-academy');
    }
  }

  async seedAllTenants(ownerUid: string): Promise<void> {
    if (!this.fb.db) return;
    const db = this.fb.db;
    const batch = writeBatch(db);
    const nowIso = new Date().toISOString();
    const today = nowIso.slice(0, 10);

    // -------------------------------------------------------------------------
    // Tenant 1: Pennine Academy (England - DfE)
    // -------------------------------------------------------------------------
    const pennineConfig: SchoolConfig = {
      schoolId: 'pennine-academy',
      name: 'Pennine Academy',
      crestUrl: '/src/assets/images/pennine_academy_crest_1795509106921.jpg',
      primaryColour: '#0F2744',
      accentColour: '#B4832C',
      jurisdiction: 'england_dfe',
      academicYear: '2026/2027',
      currentTerm: 'Autumn Term (Half Term 2)',
      weekCycle: 'A',
      established: '1873',
      ownerUid,
    };
    batch.set(doc(db, 'schools', 'pennine-academy'), pennineConfig);

    const staffList: StaffMember[] = [
      {
        staffId: 'stf_patel',
        fullName: 'Dr Priya Patel',
        email: 'p.patel@pennineacademy.sch.uk',
        jobTitle: 'Headteacher',
        role: 'leadership',
        department: 'Senior Leadership',
        active: true,
      },
      {
        staffId: 'stf_brooks',
        fullName: 'Ms Hannah Brooks',
        email: 'h.brooks@pennineacademy.sch.uk',
        jobTitle: 'Designated Safeguarding Lead & Assistant Head',
        role: 'dsl',
        department: 'Pastoral & Safeguarding',
        active: true,
      },
      {
        staffId: 'stf_greenwood',
        fullName: 'Mr Daniel Greenwood',
        email: 'd.greenwood@pennineacademy.sch.uk',
        jobTitle: 'Head of Mathematics',
        role: 'teacher',
        department: 'Mathematics',
        formGroup: '8B',
        house: 'Aire',
        active: true,
      },
      {
        staffId: 'stf_whitaker',
        fullName: 'Mrs Claire Whitaker',
        email: 'office@pennineacademy.sch.uk',
        jobTitle: 'School Business & Admissions Officer',
        role: 'office',
        department: 'School Office',
        active: true,
      },
      {
        staffId: 'stf_hollis',
        fullName: 'Mr James Hollis',
        email: 'j.hollis@pennineacademy.sch.uk',
        jobTitle: 'Science Teacher & Form Tutor 7A',
        role: 'teacher',
        department: 'Science',
        formGroup: '7A',
        house: 'Wharfe',
        active: true,
      },
      {
        staffId: 'stf_hussain',
        fullName: 'Mrs Nadia Hussain',
        email: 'n.hussain@pennineacademy.sch.uk',
        jobTitle: 'SENCO & Inclusion Lead',
        role: 'leadership',
        department: 'Inclusion & SEND',
        active: true,
      },
    ];
    for (const stf of staffList) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'staff', stf.staffId), stf);
    }

    const pupils: Pupil[] = [
      {
        pupilId: 'pup_oliver',
        upn: 'U815202104012',
        admissionNumber: 'PA-2401',
        firstName: 'Oliver',
        lastName: 'Thornton',
        preferredName: 'Ollie',
        dob: '2013-05-14',
        yearGroup: 'Year 8',
        formGroup: '8B',
        house: 'Aire',
        teachingGroups: ['8B-Ma1', '8B-En1', '8B-Sc1', '8B-Hi1'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2024-09-02',
        enrolmentHistory: ['2024-09-02: Enrolled Year 7 (Form 7B, Aire House)', '2025-09-01: Promoted Year 8 (Form 8B, Aire House)'],
        medicalSummary: 'Mild hay fever (seasonal antihistamine held in medical room)',
        allergyFlag: false,
        allergyDetails: 'No food allergies recorded',
        accessibilitySummary: 'Standard classroom seating',
        sendSupportLevel: 'None',
        sendAdjustments: 'No classroom adjustments required.',
        photoConsent: true,
        tripBlanketConsent: false,
        ownerUid,
      },
      {
        pupilId: 'pup_amelia',
        upn: 'U815202104019',
        admissionNumber: 'PA-2402',
        firstName: 'Amelia',
        lastName: 'Khan',
        dob: '2013-08-22',
        yearGroup: 'Year 8',
        formGroup: '8B',
        house: 'Calder',
        teachingGroups: ['8B-Ma1', '8B-En1', '8B-Sc1', '8B-Hi1'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2024-09-02',
        enrolmentHistory: ['2024-09-02: Enrolled Year 7 (Form 7B, Calder House)', '2025-09-01: Promoted Year 8 (Form 8B, Calder House)'],
        medicalSummary: 'No chronic conditions recorded',
        allergyFlag: false,
        allergyDetails: 'Vegetarian dietary preference',
        accessibilitySummary: 'Front-row seating for board clarity',
        sendSupportLevel: 'SEN Support (K)',
        sendAdjustments: 'Provide printed lesson vocabulary sheet and 25% extra time in timed assessments.',
        photoConsent: true,
        tripBlanketConsent: true,
        ownerUid,
      },
      {
        pupilId: 'pup_ethan',
        upn: 'U815202209031',
        admissionNumber: 'PA-2504',
        firstName: 'Ethan',
        lastName: 'OConnor',
        dob: '2014-11-03',
        yearGroup: 'Year 7',
        formGroup: '7A',
        house: 'Wharfe',
        teachingGroups: ['7A-Ma1', '7A-Sc1'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2025-09-01',
        enrolmentHistory: ['2025-09-01: Enrolled Year 7 (Form 7A, Wharfe House)'],
        medicalSummary: 'Severe tree nut allergy — carries two EpiPen auto-injectors',
        allergyFlag: true,
        allergyDetails: 'Tree nuts & peanuts (anaphylaxis protocol active)',
        accessibilitySummary: 'Nut-free seating zone in dining hall & Science labs',
        sendSupportLevel: 'Medical Care Plan',
        sendAdjustments: 'Keep EpiPen kit within immediate reach during PE and off-site visits.',
        photoConsent: false,
        tripBlanketConsent: false,
        ownerUid,
      },
      {
        pupilId: 'pup_maya',
        upn: 'U815202003088',
        admissionNumber: 'PA-2311',
        firstName: 'Maya',
        lastName: 'Kowalski',
        dob: '2012-02-19',
        yearGroup: 'Year 9',
        formGroup: '9C',
        house: 'Ribble',
        teachingGroups: ['9C-Ma2', '9C-En1'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2023-09-04',
        enrolmentHistory: ['2023-09-04: Enrolled Year 7 (Form 7C)', '2025-09-01: Promoted Year 9 (Form 9C)'],
        medicalSummary: 'Mild exercise-induced asthma (reliever inhaler in bag)',
        allergyFlag: false,
        allergyDetails: 'No food allergies recorded',
        accessibilitySummary: 'Cream paper / tinted reading overlay (Irlen assessment)',
        sendSupportLevel: 'SEN Support (K)',
        sendAdjustments: 'Print worksheets on cream paper (12pt sans-serif); allow movement break after 30 minutes.',
        photoConsent: true,
        tripBlanketConsent: true,
        ownerUid,
      },
      {
        pupilId: 'pup_leo',
        upn: 'U815202104044',
        admissionNumber: 'PA-2410',
        firstName: 'Leo',
        lastName: 'Bramwell',
        dob: '2013-01-29',
        yearGroup: 'Year 8',
        formGroup: '8B',
        house: 'Wharfe',
        teachingGroups: ['8B-Ma1', '8B-En1'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2024-09-02',
        enrolmentHistory: ['2024-09-02: Enrolled Year 7 (Form 7A)', '2025-09-01: Promoted Year 8 (Form 8B)'],
        medicalSummary: 'None recorded',
        allergyFlag: false,
        sendSupportLevel: 'None',
        photoConsent: true,
        tripBlanketConsent: true,
        ownerUid,
      },
      {
        pupilId: 'pup_sophia',
        upn: 'U815202104077',
        admissionNumber: 'PA-2418',
        firstName: 'Sophia',
        lastName: 'Bateson',
        dob: '2013-09-10',
        yearGroup: 'Year 8',
        formGroup: '8B',
        house: 'Ribble',
        teachingGroups: ['8B-Ma1', '8B-Sc1'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2024-09-02',
        enrolmentHistory: ['2024-09-02: Enrolled Year 7', '2025-09-01: Promoted Year 8 (Form 8B)'],
        medicalSummary: 'Type 1 Diabetes — glucose monitor checked prior to PE',
        allergyFlag: false,
        sendSupportLevel: 'Medical Care Plan',
        sendAdjustments: 'Allow glucose testing and snack access at all times.',
        photoConsent: true,
        tripBlanketConsent: true,
        ownerUid,
      },
    ];
    for (const p of pupils) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'pupils', p.pupilId), p);
    }

    const contacts: ContactRelationship[] = [
      {
        contactId: 'con_sarah_thornton',
        pupilId: 'pup_oliver',
        fullName: 'Mrs Sarah Thornton',
        relationship: 'Mother (Parental Responsibility)',
        email: 'sarah.thornton@example.co.uk',
        phone: '07700 900412',
        addressLine1: '14 Wharfebank Terrace, Ilkley',
        postcode: 'LS29 8AW',
        isEmergencyContact: true,
        hasPortalAccess: true,
        hasCollectionPermission: true,
        hasRecordAccess: true,
        isRestrictedContact: false,
        sensitiveAddress: false,
        communicationPreference: 'Portal',
        verifiedByOffice: true,
        verifiedAt: '2025-09-02',
      },
      {
        contactId: 'con_martin_thornton',
        pupilId: 'pup_oliver',
        fullName: 'Mr Martin Thornton',
        relationship: 'Uncle (Emergency Only)',
        email: 'm.thornton@example.co.uk',
        phone: '07700 900778',
        addressLine1: '8 Station Road, Otley',
        postcode: 'LS21 3HX',
        isEmergencyContact: true,
        hasPortalAccess: false,
        hasCollectionPermission: false,
        hasRecordAccess: false,
        isRestrictedContact: false,
        sensitiveAddress: false,
        communicationPreference: 'SMS',
        verifiedByOffice: true,
        verifiedAt: '2025-09-02',
      },
      {
        contactId: 'con_farah_khan',
        pupilId: 'pup_amelia',
        fullName: 'Dr Farah Khan',
        relationship: 'Mother (Parental Responsibility)',
        email: 'farah.khan@example.co.uk',
        phone: '07700 900215',
        addressLine1: '29 Aireville Drive, Shipley',
        postcode: 'BD18 3QT',
        isEmergencyContact: true,
        hasPortalAccess: true,
        hasCollectionPermission: true,
        hasRecordAccess: true,
        isRestrictedContact: false,
        sensitiveAddress: false,
        communicationPreference: 'Email',
        verifiedByOffice: true,
        verifiedAt: '2025-09-03',
      },
      {
        contactId: 'con_restricted_01',
        pupilId: 'pup_maya',
        fullName: 'Mr Marek Kowalski',
        relationship: 'Non-resident Father (Restricted Court Order)',
        phone: 'Withheld',
        addressLine1: 'Restricted — Do not disclose primary residence',
        postcode: 'RESTRICTED',
        isEmergencyContact: false,
        hasPortalAccess: false,
        hasCollectionPermission: false,
        hasRecordAccess: false,
        isRestrictedContact: true,
        sensitiveAddress: true,
        communicationPreference: 'Letter',
        verifiedByOffice: true,
        verifiedAt: '2025-09-01',
      },
    ];
    for (const c of contacts) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'contacts', c.contactId), c);
    }

    const admissions: AdmissionRecord[] = [
      {
        applicationId: 'adm_01',
        applicantName: 'Freya Greenwood-Shaw',
        dob: '2014-04-12',
        targetYearGroup: 'Year 7',
        stage: 'accepted',
        parentName: 'Mr Alistair Shaw',
        parentEmail: 'a.shaw@example.co.uk',
        submittedAt: '2026-11-10',
        duplicateFlag: false,
        notes: 'In-year transfer from Harrogate Grammar; birth certificate sighted by Office.',
      },
      {
        applicationId: 'adm_02',
        applicantName: 'Zainab Mahmood',
        dob: '2014-07-08',
        targetYearGroup: 'Year 7',
        stage: 'offer',
        parentName: 'Mrs Samina Mahmood',
        parentEmail: 's.mahmood@example.co.uk',
        submittedAt: '2026-11-14',
        duplicateFlag: false,
        notes: 'Offer letter issued; awaiting acceptance slip.',
      },
      {
        applicationId: 'adm_03',
        applicantName: 'Oliver Thornton',
        dob: '2013-05-14',
        targetYearGroup: 'Year 8',
        stage: 'enquiry',
        parentName: 'Sarah Thornton',
        parentEmail: 'sarah.thornton@example.co.uk',
        submittedAt: '2026-11-18',
        duplicateFlag: true,
        notes: 'Potential duplicate detected: matches existing enrolled pupil PA-2401 (Oliver Thornton, DOB 14/05/2013).',
      },
    ];
    for (const adm of admissions) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'admissions', adm.applicationId), adm);
    }

    const sessions: AttendanceSession[] = [
      {
        sessionId: 'att_oliver_mon_am',
        pupilId: 'pup_oliver',
        date: today,
        sessionType: 'AM',
        classCode: '8B',
        code: '/',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: true,
        recordedByUid: ownerUid,
        reconciledByOffice: true,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_oliver_yest_am',
        pupilId: 'pup_oliver',
        date: '2026-11-23',
        sessionType: 'AM',
        classCode: '8B',
        code: '/',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: true,
        recordedByUid: ownerUid,
        reconciledByOffice: true,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_oliver_yest_pm',
        pupilId: 'pup_oliver',
        date: '2026-11-23',
        sessionType: 'PM',
        classCode: '8B',
        code: 'M',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: true,
        explanation: 'Orthodontic appointment (letter verified by office)',
        recordedByUid: ownerUid,
        reconciledByOffice: true,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_amelia_mon_am',
        pupilId: 'pup_amelia',
        date: today,
        sessionType: 'AM',
        classCode: '8B',
        code: 'L',
        minutesLate: 8,
        codeVersion: 'DfE-2024-v2',
        isAuthorised: true,
        explanation: 'Bus delay on A65',
        recordedByUid: ownerUid,
        reconciledByOffice: true,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_leo_mon_am',
        pupilId: 'pup_leo',
        date: today,
        sessionType: 'AM',
        classCode: '8B',
        code: '?',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: false,
        explanation: 'Unresolved — awaiting office first-day call',
        recordedByUid: ownerUid,
        reconciledByOffice: false,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_sophia_mon_am',
        pupilId: 'pup_sophia',
        date: today,
        sessionType: 'AM',
        classCode: '8B',
        code: '/',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: true,
        recordedByUid: ownerUid,
        reconciledByOffice: true,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_ethan_mon_am',
        pupilId: 'pup_ethan',
        date: today,
        sessionType: 'AM',
        classCode: '7A',
        code: 'I',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: true,
        explanation: 'Seasonal viral illness reported by parent',
        recordedByUid: ownerUid,
        reconciledByOffice: true,
        recordedAt: nowIso,
      },
      {
        sessionId: 'att_maya_mon_am',
        pupilId: 'pup_maya',
        date: today,
        sessionType: 'AM',
        classCode: '9C',
        code: 'O',
        codeVersion: 'DfE-2024-v2',
        isAuthorised: false,
        explanation: 'Unexplained absence — attendance officer follow-up open',
        recordedByUid: ownerUid,
        reconciledByOffice: false,
        recordedAt: nowIso,
      },
    ];
    for (const s of sessions) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'attendanceSessions', s.sessionId), s);
    }

    const absenceRequests: AbsenceRequest[] = [
      {
        requestId: 'abs_01',
        pupilId: 'pup_oliver',
        submittedByUid: ownerUid,
        parentName: 'Mrs Sarah Thornton',
        startDate: '2026-11-26',
        endDate: '2026-11-26',
        reason: 'Hospital audiology clinic follow-up at 10:15 (letter available at reception).',
        status: 'pending_review',
        createdAt: nowIso,
      },
    ];
    for (const ar of absenceRequests) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'absenceRequests', ar.requestId), ar);
    }

    const timetable: TimetableEntry[] = [
      {
        entryId: 'tt_mon_p1_8b',
        weekCycle: 'A',
        dayOfWeek: 'Monday',
        period: 1,
        startTime: '09:05',
        endTime: '10:05',
        subject: 'Mathematics',
        classCode: '8B-Ma1',
        teacherId: 'stf_greenwood',
        teacherName: 'Mr Daniel Greenwood',
        roomCode: 'M204',
        roomCapacity: 32,
        pupilCount: 28,
        publishedVersion: '2026-Aut-v3',
      },
      {
        entryId: 'tt_mon_p2_8b',
        weekCycle: 'A',
        dayOfWeek: 'Monday',
        period: 2,
        startTime: '10:05',
        endTime: '11:05',
        subject: 'Combined Science',
        classCode: '8B-Sc1',
        teacherId: 'stf_hollis',
        teacherName: 'Mr James Hollis',
        roomCode: 'Lab 2',
        roomCapacity: 30,
        pupilCount: 28,
        coverTeacherName: 'Dr R. Vance (Cover)',
        roomChangeNote: 'Moved from Lab 1 due to fume cupboard service',
        publishedVersion: '2026-Aut-v3',
      },
      {
        entryId: 'tt_tue_p1_8b',
        weekCycle: 'A',
        dayOfWeek: 'Tuesday',
        period: 1,
        startTime: '09:05',
        endTime: '10:05',
        subject: 'English Literature',
        classCode: '8B-En1',
        teacherName: 'Ms E. Mercer',
        roomCode: 'E102',
        roomCapacity: 30,
        pupilCount: 28,
        publishedVersion: '2026-Aut-v3',
      },
      {
        entryId: 'tt_wed_p3_8b',
        weekCycle: 'BOTH',
        dayOfWeek: 'Wednesday',
        period: 3,
        startTime: '11:25',
        endTime: '12:25',
        subject: 'History',
        classCode: '8B-Hi1',
        teacherName: 'Mr T. Bradshaw',
        roomCode: 'H04',
        roomCapacity: 30,
        pupilCount: 28,
        publishedVersion: '2026-Aut-v3',
      },
      {
        entryId: 'tt_thu_p2_8b',
        weekCycle: 'A',
        dayOfWeek: 'Thursday',
        period: 2,
        startTime: '10:05',
        endTime: '11:05',
        subject: 'Mathematics',
        classCode: '8B-Ma1',
        teacherId: 'stf_greenwood',
        teacherName: 'Mr Daniel Greenwood',
        roomCode: 'M204',
        roomCapacity: 32,
        pupilCount: 28,
        publishedVersion: '2026-Aut-v3',
      },
      {
        entryId: 'tt_fri_p4_7a',
        weekCycle: 'A',
        dayOfWeek: 'Friday',
        period: 4,
        startTime: '13:20',
        endTime: '14:20',
        subject: 'Science',
        classCode: '7A-Sc1',
        teacherId: 'stf_hollis',
        teacherName: 'Mr James Hollis',
        roomCode: 'Lab 1',
        roomCapacity: 30,
        pupilCount: 26,
        publishedVersion: '2026-Aut-v3',
      },
    ];
    for (const tt of timetable) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'timetableEntries', tt.entryId), tt);
    }

    const homework: HomeworkTask[] = [
      {
        homeworkId: 'hw_alg_01',
        classCode: '8B-Ma1',
        subject: 'Mathematics',
        title: 'Linear Equations & Balance Method Practice',
        description: 'Complete Questions 1–8 from Knowledge Booklet Chapter 4, showing full algebraic working.',
        accessibleAlternative: 'Complete the structured digital equation steps or submit a photo/plain-text explanation of 4 worked examples.',
        resourceTitle: 'Y8 Linear Equations Worked Examples (PDF / HTML)',
        dueDate: '2026-11-28',
        teacherName: 'Mr Daniel Greenwood',
        createdAt: nowIso,
      },
      {
        homeworkId: 'hw_hist_02',
        classCode: '8B-Hi1',
        subject: 'History',
        title: 'Yorkshire Woollen Mills Source Evaluation',
        description: 'Compare two 1842 Factory Inspector extracts and explain reliability in two structured paragraphs.',
        accessibleAlternative: 'Use the scaffolded sentence-starter template or submit an audio summary note via the school tablet.',
        resourceTitle: '1842 West Riding Inspector Extracts',
        dueDate: '2026-11-30',
        teacherName: 'Mr T. Bradshaw',
        createdAt: nowIso,
      },
    ];
    for (const hw of homework) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'homework', hw.homeworkId), hw);
    }

    const submissions: HomeworkSubmission[] = [
      {
        submissionId: 'sub_oliver_alg',
        homeworkId: 'hw_alg_01',
        pupilId: 'pup_oliver',
        pupilName: 'Oliver Thornton',
        status: 'submitted',
        submissionText: 'Q1: 3x + 4 = 19 -> 3x = 15 -> x = 5. Q2: 5x - 7 = 18 -> 5x = 25 -> x = 5. Completed all 8 steps in exercise book.',
        submissionFormat: 'Text Summary',
        submittedAt: nowIso,
      },
      {
        submissionId: 'sub_amelia_alg',
        homeworkId: 'hw_alg_01',
        pupilId: 'pup_amelia',
        pupilName: 'Amelia Khan',
        status: 'marked',
        submissionText: 'Completed Questions 1–8 with inverse operations shown clearly.',
        submissionFormat: 'Text Summary',
        rawMark: 18,
        maxMark: 20,
        teacherJudgement: 'Secure +',
        calculatedGrade: 'Developing Mastery (8B)',
        feedback: 'Clear inverse steps throughout. Double-check negative sign distribution on Q7.',
        moderationNote: 'Department moderation sample checked 22/11/2026 (D. Greenwood).',
        submittedAt: '2026-11-22T17:10:00Z',
        markedAt: '2026-11-23T09:15:00Z',
      },
    ];
    for (const sub of submissions) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'submissions', sub.submissionId), sub);
    }

    const behaviour: BehaviourEvent[] = [
      {
        eventId: 'beh_01',
        pupilId: 'pup_oliver',
        pupilName: 'Oliver Thornton',
        category: 'achievement',
        title: 'Aire House Merit — Peer Numeracy Support',
        factualDescription: 'Assisted classmates in 8B-Ma1 with multi-step ratio checks after completing extension tasks.',
        location: 'M204',
        occurredAt: '2026-11-22T10:00:00Z',
        authorName: 'Mr Daniel Greenwood',
        authorUid: ownerUid,
        actionTaken: '+3 House Points awarded',
        reviewStatus: 'reviewed',
      },
      {
        eventId: 'beh_02',
        pupilId: 'pup_leo',
        pupilName: 'Leo Bramwell',
        category: 'behaviour_incident',
        title: 'Repeated disruption during practical instruction',
        factualDescription: 'Spoke over safety briefing twice after one verbal reminder during Bunsen burner setup.',
        location: 'Lab 2',
        occurredAt: '2026-11-21T11:45:00Z',
        authorName: 'Mr James Hollis',
        authorUid: ownerUid,
        actionTaken: '20-minute departmental lunchtime reflection; parent note queued',
        reviewStatus: 'open',
      },
    ];
    for (const b of behaviour) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'behaviourEvents', b.eventId), b);
    }

    const concerns: SafeguardingConcern[] = [
      {
        concernId: 'sg_01',
        pupilId: 'pup_leo',
        pupilInitials: 'L.B. (8B)',
        category: 'Home Welfare / Emotional Distress',
        factualSummary: 'Pupil appeared unusually withdrawn at morning registration and mentioned difficulty sleeping due to ongoing arguments at home. No physical injury observed or disclosed.',
        chronologyNote: '24/11/2026 08:50 — Reported factually by form teacher following quiet check-in.',
        reportedByUid: ownerUid,
        reportedByName: 'Mr Daniel Greenwood',
        assignedDslName: 'Ms Hannah Brooks',
        status: 'submitted_unacknowledged',
        reviewDate: '2026-11-25',
        accessRestricted: true,
        createdAt: nowIso,
      },
    ];
    for (const sg of concerns) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'safeguardingConcerns', sg.concernId), sg);
    }

    const medicalPlans: MedicalPlan[] = [
      {
        planId: 'med_ethan',
        pupilId: 'pup_ethan',
        pupilName: 'Ethan OConnor',
        condition: 'Severe Tree Nut & Peanut Anaphylaxis',
        carePlanSummary: 'Two prescribed EpiPen 0.3mg auto-injectors stored: one carried by pupil, one in Medical Room Locked Cabinet B.',
        emergencyProtocol: 'If wheezing, facial swelling, or collapse occurs: administer EpiPen immediately into outer thigh, call 999 stating anaphylaxis, and notify parent + Headteacher.',
        allergens: 'Peanuts, tree nuts, sesame traces',
        verifiedByNurse: true,
        reviewDate: '2027-03-01',
        lastIncidentNote: 'No incidents in current academic year.',
      },
      {
        planId: 'med_sophia',
        pupilId: 'pup_sophia',
        pupilName: 'Sophia Bateson',
        condition: 'Type 1 Diabetes',
        carePlanSummary: 'Continuous glucose monitor paired with medical room handset. Fast-acting glucose tablets carried at all times.',
        emergencyProtocol: 'If blood glucose < 4.0 mmol/L: give 15g fast-acting carbohydrate immediately, retest in 15 minutes, supervise until > 4.5 mmol/L.',
        allergens: 'None',
        verifiedByNurse: true,
        reviewDate: '2027-02-15',
      },
    ];
    for (const mp of medicalPlans) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'medicalPlans', mp.planId), mp);
    }

    const trips: TripOrActivity[] = [
      {
        tripId: 'trip_york_minster',
        kind: 'trip',
        title: 'Year 8 York Minster & Jorvik History Study Visit',
        date: '2026-12-11',
        capacity: 60,
        enrolledCount: 42,
        costPence: 1850,
        currency: 'GBP',
        dietaryNotice: 'Packed lunches required — strictly nut-free coach policy.',
        allergenStatus: 'verified',
        location: 'York City Centre',
        leadStaffName: 'Mr T. Bradshaw',
      },
      {
        tripId: 'club_robotics',
        kind: 'club',
        title: 'Key Stage 3 Robotics & Coding Club (Thursdays)',
        date: 'Weekly 15:30–16:30',
        capacity: 20,
        enrolledCount: 19,
        costPence: 0,
        currency: 'GBP',
        location: 'IT Suite 1',
        leadStaffName: 'Mr Daniel Greenwood',
      },
      {
        tripId: 'meal_autumn_week2',
        kind: 'meal_menu',
        title: 'Autumn Term Hot Meal — Week A Roast & Plant Option',
        date: '2026-11-27',
        capacity: 400,
        enrolledCount: 218,
        costPence: 285,
        currency: 'GBP',
        dietaryNotice: 'External bakery dessert batch awaiting supplier allergen sheet confirmation — DO NOT select if pupil has sesame/nut allergy.',
        allergenStatus: 'unverified_provider_check_required',
        location: 'Pennine Dining Hall',
        leadStaffName: 'Catering Supervisor',
      },
      {
        tripId: 'cons_y8_parents',
        kind: 'consultation',
        title: 'Year 8 Parents’ Consultation — Mr D. Greenwood (16:40)',
        date: '2026-12-03',
        capacity: 1,
        enrolledCount: 0,
        costPence: 0,
        currency: 'GBP',
        location: 'Main Hall / Video Link',
        leadStaffName: 'Mr Daniel Greenwood',
      },
    ];
    for (const tr of trips) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'trips', tr.tripId), tr);
    }

    const bookings: ActivityBooking[] = [
      {
        bookingId: 'bkg_amelia_york',
        tripId: 'trip_york_minster',
        pupilId: 'pup_amelia',
        pupilName: 'Amelia Khan',
        parentUid: ownerUid,
        idempotencyKey: 'seed-amelia-york-01',
        consentGiven: true,
        consentSignedBy: 'Dr Farah Khan',
        bookingStatus: 'confirmed',
        paymentStatus: 'simulated_paid',
        amountPence: 1850,
        currency: 'GBP',
        receiptRef: 'PEN-SEED-8041',
        dietarySelection: 'Vegetarian packed lunch',
        createdAt: '2026-11-19T12:00:00Z',
      },
    ];
    for (const bk of bookings) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'bookings', bk.bookingId), bk);
    }

    const announcements: Announcement[] = [
      {
        announcementId: 'ann_01',
        title: 'Year 8 York History Visit — Consent & Payment Window',
        body: 'Parents and carers of Year 8 pupils are invited to submit signed educational visit consent and settle the £18.50 contribution via the Family Portal before Friday 4 December.',
        audienceType: 'year_group',
        audienceLabel: 'Year 8 Verified Parents & Carers',
        recipientCount: 112,
        deliveryState: 'delivered',
        authorName: 'Mrs Claire Whitaker',
        publishedAt: '2026-11-22T09:00:00Z',
        aiDraftReviewed: false,
      },
      {
        announcementId: 'ann_02',
        title: 'Week A Timetable & Science Lab 1 Maintenance',
        body: 'Please note Science Lab 1 fume cupboard servicing takes place Monday morning; 8B-Sc1 moves to Lab 2 for Period 2.',
        audienceType: 'whole_school',
        audienceLabel: 'All Pennine Academy Staff & Pupils',
        recipientCount: 845,
        deliveryState: 'sent',
        authorName: 'Dr Priya Patel',
        publishedAt: '2026-11-23T16:15:00Z',
        aiDraftReviewed: false,
      },
    ];
    for (const ann of announcements) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'announcements', ann.announcementId), ann);
    }

    const auditLogs: AuditLog[] = [
      {
        logId: 'aud_01',
        actorUid: ownerUid,
        actorName: 'Mrs Claire Whitaker',
        actorRole: 'office',
        module: 'Contacts & Permissions',
        action: 'CONTACT_VERIFIED',
        targetType: 'contact',
        targetId: 'con_martin_thornton',
        summary: 'Verified Mr Martin Thornton as Emergency Contact ONLY (portal access, collection, and record access explicitly disabled).',
        createdAt: '2026-11-22T10:12:00Z',
      },
      {
        logId: 'aud_02',
        actorUid: ownerUid,
        actorName: 'Mr Daniel Greenwood',
        actorRole: 'teacher',
        module: 'Safeguarding',
        action: 'CONCERN_SUBMITTED',
        targetType: 'safeguardingConcern',
        targetId: 'sg_01',
        summary: 'Confidential concern logged and routed to DSL queue (status: submitted_unacknowledged).',
        createdAt: nowIso,
      },
    ];
    for (const aud of auditLogs) {
      batch.set(doc(db, 'schools', 'pennine-academy', 'auditLogs', aud.logId), aud);
    }

    // -------------------------------------------------------------------------
    // Tenant 2: Lothian Brae High (Scotland - CfE / SEEMiS) for Tenant Isolation Proof
    // -------------------------------------------------------------------------
    const lothianConfig: SchoolConfig = {
      schoolId: 'lothian-brae-high',
      name: 'Lothian Brae High',
      crestUrl: '/src/assets/images/lothian_brae_crest_1795509107833.jpg',
      primaryColour: '#14453D',
      accentColour: '#475569',
      jurisdiction: 'scotland_cfe',
      academicYear: '2026/2027',
      currentTerm: 'Term 2 (Winter)',
      weekCycle: 'A',
      established: '1954',
      ownerUid,
    };
    batch.set(doc(db, 'schools', 'lothian-brae-high'), lothianConfig);

    const scottishPupils: Pupil[] = [
      {
        pupilId: 'pup_scot_01',
        upn: 'SCN-94012281',
        admissionNumber: 'LB-1904',
        firstName: 'Callum',
        lastName: 'MacLeod',
        dob: '2013-03-11',
        yearGroup: 'S2',
        formGroup: '2L1',
        house: 'Pentland',
        teachingGroups: ['2L1-Maths', '2L1-English'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2025-08-14',
        enrolmentHistory: ['2025-08-14: Enrolled S1 (2L1, Pentland)'],
        allergyFlag: false,
        sendSupportLevel: 'GIRFEC Universal',
        photoConsent: true,
        tripBlanketConsent: true,
        ownerUid,
      },
      {
        pupilId: 'pup_scot_02',
        upn: 'SCN-94012304',
        admissionNumber: 'LB-1918',
        firstName: 'Eilidh',
        lastName: 'Fraser',
        dob: '2014-09-18',
        yearGroup: 'S1',
        formGroup: '1B2',
        house: 'Braid',
        teachingGroups: ['1B2-Maths', '1B2-Science'],
        enrolmentStatus: 'Enrolled',
        enrolmentDate: '2026-08-13',
        enrolmentHistory: ['2026-08-13: Enrolled S1 from Canaan Lane Primary'],
        allergyFlag: false,
        sendSupportLevel: 'ASN Plan',
        sendAdjustments: 'Quiet workspace during written assessments.',
        photoConsent: true,
        tripBlanketConsent: true,
        ownerUid,
      },
    ];
    for (const sp of scottishPupils) {
      batch.set(doc(db, 'schools', 'lothian-brae-high', 'pupils', sp.pupilId), sp);
    }

    batch.set(doc(db, 'schools', 'lothian-brae-high', 'attendanceSessions', 'att_scot_01'), {
      sessionId: 'att_scot_01',
      pupilId: 'pup_scot_01',
      date: today,
      sessionType: 'AM',
      classCode: '2L1',
      code: 'PR',
      codeVersion: 'SEEMiS-2024',
      isAuthorised: true,
      recordedByUid: ownerUid,
      reconciledByOffice: true,
      recordedAt: nowIso,
    } satisfies AttendanceSession);

    batch.set(doc(db, 'schools', 'lothian-brae-high', 'auditLogs', 'aud_scot_01'), {
      logId: 'aud_scot_01',
      actorUid: ownerUid,
      actorName: 'System Administrator',
      actorRole: 'admin',
      module: 'Tenant Isolation',
      action: 'TENANT_INITIALISED',
      targetType: 'school',
      targetId: 'lothian-brae-high',
      summary: 'Initialised Scottish CfE / SEEMiS tenant strictly separated from Pennine Academy.',
      createdAt: nowIso,
    } satisfies AuditLog);

    await batch.commit();
  }
}
