import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AdmissionsStructureComponent } from './components/admissions-structure.component';
import { AttendanceRegisterComponent } from './components/attendance-register.component';
import { HomeDashboardComponent } from './components/home-dashboard.component';
import { LearningAssessmentComponent } from './components/learning-assessment.component';
import { LoginScreenComponent } from './components/login-screen.component';
import { PastoralSafeguardingComponent } from './components/pastoral-safeguarding.component';
import { PupilsContactsComponent } from './components/pupils-contacts.component';
import { TimetableCoverComponent } from './components/timetable-cover.component';
import { TripsCommsAdminComponent } from './components/trips-comms-admin.component';
import { AppModuleId, AuthService, DEMO_PERSONAS } from './services/auth.service';
import { SchoolStoreService } from './services/school-store.service';

interface NavItem {
  id: AppModuleId;
  label: string;
  icon: string;
}

const ALL_NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', icon: 'dashboard' },
  { id: 'pupils', label: 'Pupils & Contacts', icon: 'groups' },
  { id: 'admissions', label: 'Admissions', icon: 'how_to_reg' },
  { id: 'attendance', label: 'Attendance', icon: 'fact_check' },
  { id: 'timetable', label: 'Timetable & Cover', icon: 'calendar_view_week' },
  { id: 'learning', label: 'Homework & Marks', icon: 'menu_book' },
  { id: 'pastoral', label: 'Behaviour & Pastoral', icon: 'forum' },
  { id: 'safeguarding', label: 'Safeguarding', icon: 'shield' },
  { id: 'send_medical', label: 'SEND & Medical', icon: 'medical_services' },
  { id: 'trips_payments', label: 'Trips & Payments', icon: 'payments' },
  { id: 'comms', label: 'Communications', icon: 'campaign' },
  { id: 'admin_audit', label: 'Reports & Audit', icon: 'admin_panel_settings' },
];

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    FormsModule,
    LoginScreenComponent,
    HomeDashboardComponent,
    PupilsContactsComponent,
    AdmissionsStructureComponent,
    AttendanceRegisterComponent,
    TimetableCoverComponent,
    LearningAssessmentComponent,
    PastoralSafeguardingComponent,
    TripsCommsAdminComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly auth = inject(AuthService);
  readonly store = inject(SchoolStoreService);

  readonly personas = DEMO_PERSONAS;
  readonly activeModule = signal<AppModuleId>('home');
  readonly mobileMenuOpen = signal(false);

  readonly visibleNavItems = computed(() => {
    const allowed = new Set(this.auth.allowedModules());
    return ALL_NAV_ITEMS.filter((item) => allowed.has(item.id));
  });

  readonly activeNavLabel = computed(() => {
    const found = ALL_NAV_ITEMS.find((i) => i.id === this.activeModule());
    return found?.label ?? 'Home';
  });

  readonly navBackgroundColour = computed(
    () => this.store.schoolConfig()?.primaryColour || '#0F2744',
  );

  readonly schoolCrestUrl = computed(
    () =>
      this.store.schoolConfig()?.crestUrl ||
      '/src/assets/images/pennine_academy_crest_1795509106921.jpg',
  );

  constructor() {
    effect(() => {
      const allowed = this.auth.allowedModules();
      if (!allowed.includes(this.activeModule())) {
        this.activeModule.set('home');
      }
    });
  }

  selectModule(id: AppModuleId): void {
    if (this.auth.canAccessModule(id)) {
      this.activeModule.set(id);
      this.mobileMenuOpen.set(false);
    }
  }

  onPersonaChange(personaId: string): void {
    this.auth.setDemoPersona(personaId);
  }

  onSchoolChange(schoolId: string): void {
    this.auth.setActiveSchool(schoolId);
  }
}
