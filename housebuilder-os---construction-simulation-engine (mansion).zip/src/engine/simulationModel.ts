/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate / Luxury Mansion Edition
 * Construction Simulation Model & Economic Computation Engine
 */

import {
  BimComponent,
  ComponentState,
  ConstructionStage,
  HouseParameters,
  MachineType,
  MaintenanceItem,
  MarginalCostPoint,
  MasterplanPlot,
  MaterialStock,
  ProjectFinancials,
  RoofMaterialType,
  RoomBuildStatus,
  ScheduleMilestone,
  StoneFacadeType,
  TradeType,
  UsRegion,
  ValueEngineUpgrade
} from '../types/simulation';

// Default initial American Stone Estate Specification
export const DEFAULT_PARAMETERS: HouseParameters = {
  livingAreaSqFt: 6000,
  widthFt: 74,
  depthFt: 44,
  floors: 2,
  hasBasement: true,
  basementAreaSqFt: 2200,
  garageBays: 3,
  garageAreaSqFt: 1050,
  siteAreaAcres: 1.25,

  architecturalStyle: 'GEORGIAN_ESTATE',
  stoneFacade: 'INDIANA_LIMESTONE',
  roofMaterial: 'SYNTHETIC_SLATE',
  luxuryTier: 'HIGH_LUXURY',
  usRegion: 'NORTHEAST',

  hvacType: 'GEOTHERMAL_GROUND_LOOP',
  hasSolarPv: true,
  hasBatteryStorage: true,
  hasBackupGenerator: true,
  hasHotWaterRecirc: true,
  hasWholeHouseAutomation: true,

  hasEstatePool: true,
  hasBasementCinema: true,
  hasWellnessGym: true,
  hasWineCellar: true,
  hasLibrary: true,
  hasPrepKitchen: true,
  hasOutdoorKitchen: true,
  hasTennisCourt: false,

  bedroomCount: 5,
  bathroomCount: 7,

  unitSystem: 'IMPERIAL'
};

// Regional Cost Multipliers (2026 US luxury baseline)
export const REGIONAL_MULTIPLIERS: Record<UsRegion, { name: string; multiplier: number; baselineRate: number }> = {
  NORTHEAST: { name: 'Northeast (Greenwich / Westchester / Boston)', multiplier: 1.26, baselineRate: 685 },
  MID_ATLANTIC: { name: 'Mid-Atlantic (Potomac / Main Line / DC)', multiplier: 1.12, baselineRate: 620 },
  PACIFIC: { name: 'Pacific (Bel Air / Atherton / Mercer Island)', multiplier: 1.34, baselineRate: 740 },
  MOUNTAIN: { name: 'Mountain (Aspen / Vail / Scottsdale)', multiplier: 1.14, baselineRate: 630 },
  MIDWEST: { name: 'Midwest (Lake Forest / Bloomfield Hills)', multiplier: 0.96, baselineRate: 540 },
  SOUTH: { name: 'South (Palm Beach / Buckhead / River Oaks)', multiplier: 0.92, baselineRate: 515 }
};

// Facade Cost & Productivity Factors
export const STONE_FACADE_PROPERTIES: Record<StoneFacadeType, { name: string; costPerSqFt: number; embodiedCarbonKgPerSqFt: number; installDaysFactor: number; weightLbsPerSqFt: number }> = {
  INDIANA_LIMESTONE: { name: 'Indiana Bedford Limestone (Cut Ashlar & Quoins)', costPerSqFt: 115, embodiedCarbonKgPerSqFt: 38, installDaysFactor: 1.25, weightLbsPerSqFt: 45 },
  BRIAR_HILL_SANDSTONE: { name: 'Briar Hill Variegated Sandstone', costPerSqFt: 98, embodiedCarbonKgPerSqFt: 32, installDaysFactor: 1.18, weightLbsPerSqFt: 42 },
  VERMONT_GRANITE: { name: 'Vermont Barre Granite Sawn Blocks', costPerSqFt: 145, embodiedCarbonKgPerSqFt: 52, installDaysFactor: 1.40, weightLbsPerSqFt: 58 },
  ANTIQUE_BRICK_STONE: { name: 'Hand-Moulded Brick with Limestone Accents', costPerSqFt: 62, embodiedCarbonKgPerSqFt: 26, installDaysFactor: 0.95, weightLbsPerSqFt: 28 },
  CAST_STONE_STUCCO: { name: 'Architectural Cast Stone & Integral Stucco', costPerSqFt: 48, embodiedCarbonKgPerSqFt: 22, installDaysFactor: 0.80, weightLbsPerSqFt: 20 }
};

// Roof Material Cost & Lifespans
export const ROOF_MATERIAL_PROPERTIES: Record<RoofMaterialType, { name: string; costPerSqFt: number; lifespanYears: number; weightLbsPerSqFt: number }> = {
  ARCHITECTURAL_ASPHALT: { name: 'CertainTeed Grand Manor Asphalt Shingles', costPerSqFt: 16, lifespanYears: 30, weightLbsPerSqFt: 4.5 },
  SYNTHETIC_SLATE: { name: 'DaVinci Multi-Width Synthetic Slate', costPerSqFt: 38, lifespanYears: 50, weightLbsPerSqFt: 3.8 },
  NATURAL_SLATE: { name: 'Vermont S-1 Unfading Green Natural Slate', costPerSqFt: 88, lifespanYears: 100, weightLbsPerSqFt: 11.5 },
  STANDING_SEAM_COPPER: { name: 'Double-Lock Standing Seam Natural Copper', costPerSqFt: 72, lifespanYears: 80, weightLbsPerSqFt: 2.2 }
};

// Schedule Milestones from Day 0 to Day 490 (Realistic American Estate Timeline)
export const SCHEDULE_MILESTONES: ScheduleMilestone[] = [
  {
    day: 0,
    title: 'Site Mobilization & Estate Survey',
    stage: ConstructionStage.SITE,
    description: '1.25-acre estate surveyed, protective tree root barriers erected, heavy silt fencing installed, temporary 3-phase power & site trailers placed.',
    costSpentToDateUsd: 48000,
    materialsDelivered: ['Perimeter Security Fencing', 'Jobsite Management Trailers', 'Geotextile Silt Barrier'],
    activeMachinery: [MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.SITE_SUPERINTENDENT, TradeType.GROUNDWORKER]
  },
  {
    day: 25,
    title: 'Clearing, Mass Grading & Access Drive',
    stage: ConstructionStage.GROUNDWORK,
    description: 'Site stripped of topsoil, 400ft heavy construction access road established with crushed limestone, erosion control swales cut.',
    costSpentToDateUsd: 142000,
    materialsDelivered: ['300 Tons Crushed Limestone Sub-base', 'Culvert Pipes 24"', 'Erosion Control Mattresses'],
    activeMachinery: [MachineType.EXCAVATOR, MachineType.DUMP_TRUCK],
    activeTrades: [TradeType.GROUNDWORKER]
  },
  {
    day: 55,
    title: 'Deep Basement Excavation & Dewatering',
    stage: ConstructionStage.GROUNDWORK,
    description: '10ft deep excavation for 2,200 sq ft basement & 3-car garage footings completed. Sump well points and perimeter drainage shoring placed.',
    costSpentToDateUsd: 265000,
    materialsDelivered: ['Perforated Foundation Drain Tile', 'Washed Crushed Stone #57', 'Well Point Pumps'],
    activeMachinery: [MachineType.EXCAVATOR, MachineType.DUMP_TRUCK],
    activeTrades: [TradeType.GROUNDWORKER, TradeType.FOUNDATION_CREW]
  },
  {
    day: 95,
    title: 'Reinforced Concrete Footings & 10ft Basement Walls',
    stage: ConstructionStage.FOUNDATION,
    description: '10-inch thick 4,000 PSI reinforced concrete foundation walls poured with #5 rebar grid. Exterior spray-applied elastomeric waterproofing & 2" XPS insulation applied.',
    costSpentToDateUsd: 485000,
    materialsDelivered: ['Grade 60 Epoxy Rebar', '4000 PSI Ready-Mix Concrete', 'Tremco Elastomeric Waterproofing', '2" XPS Dimple Board'],
    activeMachinery: [MachineType.CONCRETE_PUMP, MachineType.CONCRETE_MIXER],
    activeTrades: [TradeType.FOUNDATION_CREW]
  },
  {
    day: 135,
    title: 'Basement Slab, Sump Systems & Structural Steel Columns',
    stage: ConstructionStage.BASEMENT,
    description: '5-inch reinforced basement slab power-troweled over 15-mil Stego vapor barrier. Heavy W-flange structural steel girders and lally columns erected to carry wide clear-spans.',
    costSpentToDateUsd: 740000,
    materialsDelivered: ['W12x45 Structural Steel I-Beams', 'Steel Lally Columns', 'Stego Wrap 15 Mil Vapor Barrier'],
    activeMachinery: [MachineType.TELEHANDLER, MachineType.CONCRETE_PUMP],
    activeTrades: [TradeType.STEEL_ERECTOR, TradeType.FOUNDATION_CREW]
  },
  {
    day: 175,
    title: 'Ground Floor LVL Joists & Engineered Decking',
    stage: ConstructionStage.GROUND_FLOOR,
    description: '14-inch deep engineered LVL floor joist systems installed with 3/4" Advantech tongue-and-groove subflooring glued and screw-fastened. 3-car garage slab poured with slope to trench drains.',
    costSpentToDateUsd: 1040000,
    materialsDelivered: ['Weyerhaeuser Microllam LVL Joists', 'Advantech Subfloor Panels', 'Polyurethane Subfloor Adhesive'],
    activeMachinery: [MachineType.TELEHANDLER],
    activeTrades: [TradeType.FRAMING_CARPENTER]
  },
  {
    day: 215,
    title: 'Superstructure Framing & 2nd Floor Ceiling Assemblies',
    stage: ConstructionStage.STRUCTURE,
    description: '2x6 exterior framing at 16" O.C. with ZIP System structural insulated sheathing. 11-foot ground floor and 10-foot upper floor ceiling heights framed with engineered headers.',
    costSpentToDateUsd: 1420000,
    materialsDelivered: ['2x6 Premium Kiln-Dried Douglas Fir', 'Huber ZIP System R-9 Sheathing', 'ZIP Tape & Liquid Flashing'],
    activeMachinery: [MachineType.TOWER_CRANE, MachineType.TELEHANDLER],
    activeTrades: [TradeType.FRAMING_CARPENTER]
  },
  {
    day: 255,
    title: 'Engineered Roof Trusses, Dormers & Timber Decking',
    stage: ConstructionStage.ROOF,
    description: 'Complex multi-plane hipped and gabled roof truss system hoisted by tower crane. 5 classical pedimented dormers, eyebrow roof vents, and 5/8" CDX plywood decking installed.',
    costSpentToDateUsd: 1810000,
    materialsDelivered: ['Custom Engineered Truss Packages', '5/8" CDX Plywood Decking', 'Grace Ice & Water Shield HT'],
    activeMachinery: [MachineType.TOWER_CRANE, MachineType.SCAFFOLDING],
    activeTrades: [TradeType.ROOFER, TradeType.FRAMING_CARPENTER]
  },
  {
    day: 290,
    title: 'Natural Stone Masonry & Architectural Quoins',
    stage: ConstructionStage.STONE_FACADE,
    description: 'Master stone masons lay 4-inch thick Indiana Limestone ashlar veneer over 2-inch drainage cavity and continuous polyiso insulation. Heavy carved corner quoins, stone entrance portico columns & window lintels set.',
    costSpentToDateUsd: 2380000,
    materialsDelivered: ['Indiana Bedford Limestone Ashlar (Crated)', 'Hand-Carved Stone Quoins & Portico Columns', 'Type N Mortar & Stainless Ties', '2" Polyiso Continuous Board'],
    activeMachinery: [MachineType.STONE_FLATBED, MachineType.TELEHANDLER, MachineType.SCAFFOLDING],
    activeTrades: [TradeType.STONE_MASON]
  },
  {
    day: 330,
    title: 'Luxury Windows, French Doors & Weathertight Envelope',
    stage: ConstructionStage.ENVELOPE,
    description: 'Marvin Ultimate triple-glazed wood-clad casement windows, 10-foot French terrace doors, and solid mahogany entrance door set in stone surrounds with flashing airtight seals.',
    costSpentToDateUsd: 2820000,
    materialsDelivered: ['Marvin Ultimate Casement Windows', 'Custom Architectural French Terrace Doors', 'Custom 9ft Solid Mahogany Front Door'],
    activeMachinery: [MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.WINDOW_GLAZIER, TradeType.FINISH_CARPENTER]
  },
  {
    day: 370,
    title: 'Multi-Zone Geothermal HVAC, 400A Electrical & Plumbing Rough-In',
    stage: ConstructionStage.SERVICES,
    description: '6-zone WaterFurnace geothermal heat pumps connected to 8 vertical ground boreholes. 400A dual electrical services, Cat6A structured data, PEX-a manifolds, hot water recirc loops & ERV ducting.',
    costSpentToDateUsd: 3350000,
    materialsDelivered: ['WaterFurnace 7-Series Geothermal Units', '400A Square D QO Panels', 'Uponor AquaPEX Manifold Systems', 'Panasonic ERV Ventilation'],
    activeMachinery: [MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.HVAC_TECHNICIAN, TradeType.ELECTRICIAN, TradeType.PLUMBER]
  },
  {
    day: 410,
    title: 'Spray Foam Insulation, Drywall & Acoustic Plaster',
    stage: ConstructionStage.INTERNAL_FINISH,
    description: 'Open-cell and closed-cell spray foam envelope insulation. Level 5 smooth drywall finish with acoustic sound-isolation clips in home cinema, master suite, and double-height foyer.',
    costSpentToDateUsd: 3790000,
    materialsDelivered: ['Demilec Closed-Cell Spray Foam', '5/8" Type X Firecode Sheetrock', 'Resilient Sound Isolation Clips (RSIC-1)'],
    activeMachinery: [],
    activeTrades: [TradeType.DRYWALL_PLASTERER]
  },
  {
    day: 445,
    title: 'Grand Imperial Staircase, White Oak Flooring & Fireplaces',
    stage: ConstructionStage.INTERNAL_FINISH,
    description: 'Double-height foyer imperial curved staircase installed with custom iron balustrades. 8-inch wide plank European White Oak herringbone floors laid. 4 masonry carved limestone fireplaces fitted.',
    costSpentToDateUsd: 4290000,
    materialsDelivered: ['Custom Curved White Oak Imperial Stair', 'European White Oak Herringbone Parquet', 'Carved Limestone Fireplace Mantels'],
    activeMachinery: [],
    activeTrades: [TradeType.FINISH_CARPENTER, TradeType.STONE_MASON]
  },
  {
    day: 465,
    title: 'Chef Kitchen, Scullery, Luxury Baths & Sommelier Wine Cellar',
    stage: ConstructionStage.INTERNAL_FINISH,
    description: 'Custom inset cabinetry with Sub-Zero, Wolf & Miele appliances, Calacatta Gold marble slabs, Waterworks plumbing brassware, climate-controlled 1,200-bottle glass wine cellar.',
    costSpentToDateUsd: 4720000,
    materialsDelivered: ['Bespoke Cabinetry Units', 'Sub-Zero & Wolf Appliance Suite', 'Calacatta Gold Marble Slabs', 'Waterworks Brassware Fixtures'],
    activeMachinery: [],
    activeTrades: [TradeType.FINISH_CARPENTER, TradeType.PLUMBER, TradeType.ELECTRICIAN]
  },
  {
    day: 480,
    title: 'Estate Landscaping, Circular Paver Court & Swimming Pool',
    stage: ConstructionStage.LANDSCAPE,
    description: 'Granite cobblestone circular motor court, 45x20 heated gunite pool with limestone coping, stone rear loggia with outdoor kitchen, mature specimen oaks, and perimeter security gates.',
    costSpentToDateUsd: 5080000,
    materialsDelivered: ['Granite Belgian Cobblestone Blocks', 'Specimen 20ft Red Oak Trees', 'Pool Equipment & Gas Heater', 'Wrought Iron Estate Gates'],
    activeMachinery: [MachineType.EXCAVATOR, MachineType.DELIVERY_TRUCK],
    activeTrades: [TradeType.ESTATE_LANDSCAPER, TradeType.STONE_MASON]
  },
  {
    day: 490,
    title: 'Commissioning, Air Quality Testing & Digital Twin Handover',
    stage: ConstructionStage.COMPLETE,
    description: 'Blower-door test achieves 0.6 ACH50 (near Passivhaus standard). Smart automation commissioning, balance of plant testing, final occupancy certificate issued.',
    costSpentToDateUsd: 5180000,
    materialsDelivered: ['Digital Twin Homeowner Server & Keypad'],
    activeMachinery: [],
    activeTrades: [TradeType.SITE_SUPERINTENDENT]
  }
];

// Room Matrix for American Mansion
export const ROOMS_CONFIG: RoomBuildStatus[] = [
  { id: 'ROOM-FOYER', name: 'Double-Height Grand Foyer & Imperial Stair', floor: 0, sqFt: 620, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-LIVING', name: 'Formal Living Room & Limestone Fireplace', floor: 0, sqFt: 580, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-DINING', name: 'Formal Dining Room & Butler Pantry', floor: 0, sqFt: 420, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-KITCHEN', name: 'Chef Kitchen & 12ft Marble Island', floor: 0, sqFt: 520, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-SCULLERY', name: 'Secondary Prep Kitchen / Scullery', floor: 0, sqFt: 220, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-FAMILY', name: 'Great Family Room & Loggia Access', floor: 0, sqFt: 680, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-LIBRARY', name: 'Wood-Panelled Executive Library / Study', floor: 0, sqFt: 340, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-GARAGE', name: '3-Car Heated Motor Garage & Workshop', floor: 0, sqFt: 1050, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-PRIMARY_BED', name: 'Primary Suite & Private Morning Terrace', floor: 1, sqFt: 750, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-PRIMARY_BATH', name: 'Primary Spa Bath & Dual Dressing Suites', floor: 1, sqFt: 580, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-BEDROOM_2', name: 'Guest Bedroom Suite 2 (En-Suite)', floor: 1, sqFt: 380, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-BEDROOM_3', name: 'Bedroom Suite 3 (En-Suite)', floor: 1, sqFt: 360, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-BEDROOM_4', name: 'Bedroom Suite 4 (En-Suite)', floor: 1, sqFt: 350, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-UPPER_LOUNGE', name: 'Upper Gallery Lounge & Laundry Suite', floor: 1, sqFt: 460, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-CINEMA', name: 'Dolby Atmos 12-Seat Private Cinema', floor: -1, sqFt: 520, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-WINE_CELLAR', name: 'Sommelier Glass Wine Cellar & Tasting', floor: -1, sqFt: 320, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-GYM', name: 'Wellness Gym & Cedar Sauna', floor: -1, sqFt: 480, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 },
  { id: 'ROOM-PLANT_ROOM', name: 'Geothermal Mechanical & 400A Power Room', floor: -1, sqFt: 380, structure: 0, electrical: 0, plumbing: 0, hvac: 0, drywall: 0, millwork: 0, flooring: 0, decoration: 0, overall: 0 }
];

// Material Stock Ledger (American Estate Scale)
export const INITIAL_MATERIAL_STOCK: MaterialStock[] = [
  { id: 'MAT-STONE', name: 'Indiana Limestone Ashlar (4" Veneer)', unit: 'tons', totalRequired: 185, ordered: 185, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 6.5, unitCostUsd: 680, category: 'StoneFacade' },
  { id: 'MAT-QUOINS', name: 'Dressed Stone Quoins & Portico Columns', unit: 'pieces', totalRequired: 84, ordered: 84, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 2.0, unitCostUsd: 420, category: 'StoneFacade' },
  { id: 'MAT-CONCRETE', name: 'Ready-Mix Concrete 4000 PSI', unit: 'cu yds', totalRequired: 240, ordered: 240, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 4.0, unitCostUsd: 195, category: 'Foundation' },
  { id: 'MAT-REBAR', name: 'Grade 60 Steel Rebar (#5 & #6)', unit: 'tons', totalRequired: 16.5, ordered: 16.5, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 3.5, unitCostUsd: 1850, category: 'Foundation' },
  { id: 'MAT-STEEL', name: 'Structural Steel I-Beams & Columns', unit: 'tons', totalRequired: 14.8, ordered: 14.8, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 1.5, unitCostUsd: 2450, category: 'Structure' },
  { id: 'MAT-LVL', name: 'Engineered LVL Joists & Decking', unit: 'bd ft', totalRequired: 22000, ordered: 22000, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 5.0, unitCostUsd: 3.85, category: 'Structure' },
  { id: 'MAT-SLATE', name: 'DaVinci Synthetic Slate Roof Tiles', unit: 'sqs (100sf)', totalRequired: 78, ordered: 78, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 7.0, unitCostUsd: 850, category: 'Roof' },
  { id: 'MAT-WINDOWS', name: 'Marvin Triple Glazed Wood-Clad Units', unit: 'units', totalRequired: 38, ordered: 38, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 0, unitCostUsd: 2850, category: 'Envelope' },
  { id: 'MAT-GEOTHERMAL', name: 'Geothermal Borehole Pipe & Loop Fluid', unit: 'linear ft', totalRequired: 3600, ordered: 3600, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 2.0, unitCostUsd: 14.50, category: 'MEP' },
  { id: 'MAT-CABINETRY', name: 'Custom Inset Hardwood Millwork', unit: 'lineal ft', totalRequired: 280, ordered: 280, inTransit: 0, deliveredToDate: 0, installedToDate: 0, wastePercent: 1.0, unitCostUsd: 850, category: 'Interior' }
];

/**
 * Generate Dynamic BIM Components for the American Stone Estate
 */
export const GENERATE_BIM_COMPONENTS = (params: HouseParameters = DEFAULT_PARAMETERS): BimComponent[] => {
  const { widthFt, depthFt, livingAreaSqFt, stoneFacade, roofMaterial, hvacType, usRegion, luxuryTier, garageBays } = params;
  const regMult = REGIONAL_MULTIPLIERS[usRegion]?.multiplier || 1.15;
  const luxMult = luxuryTier === 'ULTRA_LUXURY' ? 1.35 : luxuryTier === 'HIGH_LUXURY' ? 1.15 : 1.0;
  const scaleFactor = (livingAreaSqFt / 6000) * regMult * luxMult;

  const stoneProps = STONE_FACADE_PROPERTIES[stoneFacade] || STONE_FACADE_PROPERTIES.INDIANA_LIMESTONE;
  const roofProps = ROOF_MATERIAL_PROPERTIES[roofMaterial] || ROOF_MATERIAL_PROPERTIES.SYNTHETIC_SLATE;

  const widthM = widthFt * 0.3048;
  const depthM = depthFt * 0.3048;

  return [
    // --- FOUNDATIONS & BASEMENT ---
    {
      id: 'FND-001',
      name: 'Reinforced Concrete Spread Footings (4000 PSI)',
      category: 'Foundation',
      startDay: 40,
      endDay: 75,
      stage: ConstructionStage.FOUNDATION,
      material: '4000 PSI Ready-Mix Concrete with #5 Rebar Grid',
      dimensions: { lengthFt: widthFt + 4, widthFt: depthFt + 4, heightFt: 1.5, volumeCuYd: 110 },
      costs: { materials: Math.round(52000 * scaleFactor), labour: Math.round(38000 * scaleFactor), plant: Math.round(18000 * scaleFactor), total: Math.round(108000 * scaleFactor) },
      embodiedCarbonKg: 28500,
      supplier: 'Silvi Concrete Northeast',
      warrantyYears: 100,
      expectedLifeYears: 150,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.FOUNDATION_CREW,
      machineRequired: MachineType.CONCRETE_PUMP,
      position: [0, -2.4, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'foundations'
    },
    {
      id: 'BSM-001',
      name: '10ft Poured Concrete Basement Walls & Elastomeric Waterproofing',
      category: 'Basement',
      startDay: 75,
      endDay: 115,
      stage: ConstructionStage.BASEMENT,
      material: '10" Reinforced Concrete Walls, Tremco Elastomeric Membrane, 2" XPS Drainage Board',
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 10, areaSqFt: 2200 },
      costs: { materials: Math.round(84000 * scaleFactor), labour: Math.round(62000 * scaleFactor), plant: Math.round(24000 * scaleFactor), total: Math.round(170000 * scaleFactor) },
      embodiedCarbonKg: 42000,
      rValue: 10,
      supplier: 'Tremco Commercial Waterproofing',
      warrantyYears: 30,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.FOUNDATION_CREW,
      machineRequired: MachineType.CONCRETE_PUMP,
      position: [0, -1.2, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'basement'
    },
    {
      id: 'BSM-002',
      name: '5" Reinforced Basement Slab with Stego 15-mil Vapor Barrier',
      category: 'Basement',
      startDay: 115,
      endDay: 140,
      stage: ConstructionStage.BASEMENT,
      material: 'Power-Troweled 4000 PSI Concrete with Welded Wire Mesh & Stego 15-mil Under-Slab Barrier',
      dimensions: { lengthFt: widthFt - 2, widthFt: depthFt - 2, heightFt: 0.42, areaSqFt: 2200 },
      costs: { materials: Math.round(38000 * scaleFactor), labour: Math.round(28000 * scaleFactor), plant: Math.round(9000 * scaleFactor), total: Math.round(75000 * scaleFactor) },
      embodiedCarbonKg: 18500,
      supplier: 'Stego Industries & Cemex',
      warrantyYears: 50,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.FOUNDATION_CREW,
      machineRequired: MachineType.CONCRETE_PUMP,
      position: [0, -2.1, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'basement'
    },

    // --- STRUCTURAL STEEL & FRAMING ---
    {
      id: 'STR-001',
      name: 'Heavy W-Flange Structural Steel Girders & Lally Columns',
      category: 'Structure',
      startDay: 135,
      endDay: 165,
      stage: ConstructionStage.STRUCTURE,
      material: 'A992 Structural Steel W12x45 Beams & 4" Concrete-Filled Lally Columns',
      dimensions: { lengthFt: widthFt - 4, widthFt: 1.0, heightFt: 1.0 },
      costs: { materials: Math.round(46000 * scaleFactor), labour: Math.round(34000 * scaleFactor), plant: Math.round(16000 * scaleFactor), total: Math.round(96000 * scaleFactor) },
      embodiedCarbonKg: 14200,
      supplier: 'Nucor Structural Steel Division',
      warrantyYears: 100,
      expectedLifeYears: 150,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.STEEL_ERECTOR,
      machineRequired: MachineType.TELEHANDLER,
      position: [0, 0.1, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'structure'
    },
    {
      id: 'STR-002',
      name: 'Engineered LVL Floor System & 3/4" Advantech Decking',
      category: 'Structure',
      startDay: 160,
      endDay: 195,
      stage: ConstructionStage.GROUND_FLOOR,
      material: '14" Weyerhaeuser Microllam LVLs, 3/4" Advantech OSB Decking with Polyurethane Fastening',
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 1.2, areaSqFt: 3000 },
      costs: { materials: Math.round(62000 * scaleFactor), labour: Math.round(48000 * scaleFactor), plant: Math.round(8000 * scaleFactor), total: Math.round(118000 * scaleFactor) },
      embodiedCarbonKg: 8500,
      supplier: 'Weyerhaeuser / Huber Engineered Woods',
      warrantyYears: 50,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 120,
      tradeRequired: TradeType.FRAMING_CARPENTER,
      machineRequired: MachineType.TELEHANDLER,
      position: [0, 0.3, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'floors'
    },
    {
      id: 'STR-003',
      name: '2x6 Exterior Wall Framing with Huber ZIP System Insulated Sheathing',
      category: 'Structure',
      startDay: 190,
      endDay: 235,
      stage: ConstructionStage.STRUCTURE,
      material: '2x6 #1 Kiln-Dried Douglas Fir at 16" O.C. with Huber ZIP System R-9 Continuous Insulated Panels',
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 22, areaSqFt: 6000 },
      costs: { materials: Math.round(115000 * scaleFactor), labour: Math.round(92000 * scaleFactor), plant: Math.round(15000 * scaleFactor), total: Math.round(222000 * scaleFactor) },
      embodiedCarbonKg: 12400,
      rValue: 24,
      supplier: 'Huber Engineered Woods & 84 Lumber',
      warrantyYears: 30,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.FRAMING_CARPENTER,
      machineRequired: MachineType.TELEHANDLER,
      position: [0, 3.5, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'structure'
    },

    // --- ROOF & DORMERS ---
    {
      id: 'ROOF-001',
      name: 'Engineered Multi-Plane Roof Trusses, Dormers & 5/8" Plywood Decking',
      category: 'Roof',
      startDay: 230,
      endDay: 265,
      stage: ConstructionStage.ROOF,
      material: 'High-Load Engineered Douglas Fir Roof Trusses, 5 Classical Pedimented Dormers, 5/8" CDX Decking',
      dimensions: { lengthFt: widthFt + 6, widthFt: depthFt + 6, heightFt: 14, areaSqFt: 5200 },
      costs: { materials: Math.round(88000 * scaleFactor), labour: Math.round(68000 * scaleFactor), plant: Math.round(28000 * scaleFactor), total: Math.round(184000 * scaleFactor) },
      embodiedCarbonKg: 7800,
      supplier: 'Universal Forest Products Custom Truss Division',
      warrantyYears: 40,
      expectedLifeYears: 80,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.ROOFER,
      machineRequired: MachineType.TOWER_CRANE,
      position: [0, 8.2, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'roof'
    },
    {
      id: 'ROOF-002',
      name: `Premium Roof: ${roofProps.name} & Copper Valleys/Gutters`,
      category: 'Roof',
      startDay: 255,
      endDay: 285,
      stage: ConstructionStage.ROOF,
      material: `${roofProps.name}, Grace Ice & Water Shield HT Full Underlayment, 16oz Copper Flashing & Gutters`,
      dimensions: { lengthFt: widthFt + 8, widthFt: depthFt + 8, heightFt: 15, areaSqFt: 5400 },
      costs: { materials: Math.round(roofProps.costPerSqFt * 54 * 20 * scaleFactor), labour: Math.round(62000 * scaleFactor), plant: Math.round(14000 * scaleFactor), total: Math.round((roofProps.costPerSqFt * 1080 + 76000) * scaleFactor) },
      embodiedCarbonKg: 14500,
      rValue: 38,
      supplier: 'DaVinci Roofscapes / Vermont Slate Co.',
      warrantyYears: roofProps.lifespanYears,
      expectedLifeYears: roofProps.lifespanYears,
      maintenanceIntervalMonths: 24,
      tradeRequired: TradeType.ROOFER,
      machineRequired: MachineType.SCAFFOLDING,
      position: [0, 8.4, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'roof'
    },

    // --- EXTERIOR STONE FACADE ---
    {
      id: 'STN-001',
      name: `Exterior Facade: ${stoneProps.name}`,
      category: 'StoneFacade',
      startDay: 275,
      endDay: 325,
      stage: ConstructionStage.STONE_FACADE,
      material: `4" Split-Face Ashlar ${stoneProps.name}, Stainless Steel Corrugated Wall Ties, 2" Cavity Weep System`,
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 24, areaSqFt: 6200 },
      costs: { materials: Math.round(stoneProps.costPerSqFt * 62 * 30 * scaleFactor), labour: Math.round(145000 * stoneProps.installDaysFactor * scaleFactor), plant: Math.round(32000 * scaleFactor), total: Math.round((stoneProps.costPerSqFt * 1860 + 177000 * stoneProps.installDaysFactor) * scaleFactor) },
      embodiedCarbonKg: Math.round(stoneProps.embodiedCarbonKgPerSqFt * 620),
      supplier: 'Indiana Limestone Company / Rock-it Stone',
      warrantyYears: 100,
      expectedLifeYears: 200,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.STONE_MASON,
      machineRequired: MachineType.STONE_FLATBED,
      position: [0, 4.0, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'stone'
    },
    {
      id: 'STN-002',
      name: 'Carved Classical Stone Portico, Grand Entry Steps & Quoins',
      category: 'StoneFacade',
      startDay: 290,
      endDay: 330,
      stage: ConstructionStage.STONE_FACADE,
      material: 'Solid Sawn Limestone Tuscan Columns, Hand-Carved Corner Quoins, Stone Balustrades',
      dimensions: { lengthFt: 18, widthFt: 10, heightFt: 18, areaSqFt: 480 },
      costs: { materials: Math.round(72000 * scaleFactor), labour: Math.round(54000 * scaleFactor), plant: Math.round(16000 * scaleFactor), total: Math.round(142000 * scaleFactor) },
      embodiedCarbonKg: 12000,
      supplier: 'Bedford Architectural Stone Works',
      warrantyYears: 100,
      expectedLifeYears: 200,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.STONE_MASON,
      machineRequired: MachineType.TELEHANDLER,
      position: [0, 2.5, depthM / 2 + 1.2],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'stone'
    },

    // --- WINDOWS & ENVELOPE ---
    {
      id: 'ENV-001',
      name: 'Marvin Ultimate Triple-Glazed Wood-Clad Sash & Casement Windows (38 Units)',
      category: 'Envelope',
      startDay: 320,
      endDay: 350,
      stage: ConstructionStage.ENVELOPE,
      material: 'Extruded Aluminium Exterior Cladding with Solid White Oak Interior, Argon-Filled Low-E3 Triple Glazing',
      dimensions: { lengthFt: 3.5, widthFt: 0.6, heightFt: 7.0, areaSqFt: 920 },
      costs: { materials: Math.round(112000 * scaleFactor), labour: Math.round(38000 * scaleFactor), plant: Math.round(8000 * scaleFactor), total: Math.round(158000 * scaleFactor) },
      embodiedCarbonKg: 8900,
      uValue: 0.16,
      rValue: 6.2,
      supplier: 'Marvin Signature Ultimate Collection',
      warrantyYears: 20,
      expectedLifeYears: 40,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.WINDOW_GLAZIER,
      machineRequired: MachineType.DELIVERY_TRUCK,
      position: [0, 4.2, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'envelope'
    },
    {
      id: 'ENV-002',
      name: '10ft Architectural French Doors & Solid Mahogany Entrance Suite',
      category: 'Envelope',
      startDay: 335,
      endDay: 360,
      stage: ConstructionStage.ENVELOPE,
      material: 'Custom 10ft Multi-Point French Terrace Doors & 2.5" Thick Honduran Mahogany Front Entry Door',
      dimensions: { lengthFt: 12, widthFt: 0.6, heightFt: 10, areaSqFt: 240 },
      costs: { materials: Math.round(58000 * scaleFactor), labour: Math.round(22000 * scaleFactor), plant: Math.round(4000 * scaleFactor), total: Math.round(84000 * scaleFactor) },
      embodiedCarbonKg: 4200,
      uValue: 0.22,
      supplier: 'Brombal USA / Custom Architectural Millwork',
      warrantyYears: 25,
      expectedLifeYears: 50,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.FINISH_CARPENTER,
      position: [0, 1.8, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'envelope'
    },

    // --- MEP & GEOTHERMAL SERVICES ---
    {
      id: 'MEP-001',
      name: 'Multi-Zone Geothermal Ground Loop (8 Boreholes @ 400ft) & VRF Heat Pumps',
      category: 'MEP_HVAC',
      startDay: 355,
      endDay: 400,
      stage: ConstructionStage.SERVICES,
      material: '8x Vertical Closed-Loop HDPE Geothermal Wells, WaterFurnace 7-Series Variable Capacity Heat Pumps, MERV-16 Filtration',
      dimensions: { lengthFt: 24, widthFt: 12, heightFt: 8 },
      costs: { materials: Math.round(92000 * scaleFactor), labour: Math.round(68000 * scaleFactor), plant: Math.round(26000 * scaleFactor), total: Math.round(186000 * scaleFactor) },
      embodiedCarbonKg: 6400,
      supplier: 'WaterFurnace International / GeoPro Drilling',
      warrantyYears: 25,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.HVAC_TECHNICIAN,
      machineRequired: MachineType.EXCAVATOR,
      position: [0, -1.8, -depthM / 3],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'mep'
    },
    {
      id: 'MEP-002',
      name: '400A Dual Electrical Service, Whole-House Lutron & 48kW Kohler Generator',
      category: 'MEP_Electrical',
      startDay: 360,
      endDay: 405,
      stage: ConstructionStage.SERVICES,
      material: 'Square D 400A Dual Distribution, Lutron HomeWorks QSX Lighting, Cat6A Gigabit Structured Wiring, Kohler 48kW Liquid-Cooled Generator',
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 25 },
      costs: { materials: Math.round(78000 * scaleFactor), labour: Math.round(84000 * scaleFactor), plant: Math.round(8000 * scaleFactor), total: Math.round(170000 * scaleFactor) },
      embodiedCarbonKg: 5200,
      supplier: 'Lutron Electronics / Kohler Power Systems / Schneider Electric',
      warrantyYears: 15,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.ELECTRICIAN,
      position: [widthM / 2 + 1.2, 0.8, -depthM / 4],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'mep'
    },
    {
      id: 'MEP-003',
      name: 'Commercial PEX Plumbing, Recirculating Loops & Twin 120-Gal Heat Pump Water Heaters',
      category: 'MEP_Plumbing',
      startDay: 365,
      endDay: 410,
      stage: ConstructionStage.SERVICES,
      material: 'Uponor ProPEX Flow-Through Loops, Continuous Hot Water Recirculation, Twin Rheem ProTerra 120-Gal Hybrid Heaters',
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 25 },
      costs: { materials: Math.round(54000 * scaleFactor), labour: Math.round(62000 * scaleFactor), plant: Math.round(4000 * scaleFactor), total: Math.round(120000 * scaleFactor) },
      embodiedCarbonKg: 3800,
      supplier: 'Uponor Building Solutions / Rheem Manufacturing',
      warrantyYears: 25,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.PLUMBER,
      position: [0, -1.0, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'mep'
    },

    // --- LUXURY INTERIOR FINISHES ---
    {
      id: 'INT-001',
      name: 'Level 5 Drywall, Sound-Isolation Clips & Acoustic Plaster',
      category: 'Interior',
      startDay: 400,
      endDay: 435,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: '5/8" Type X Drywall on RSIC-1 Isolation Clips, 4-Coat Skim Plaster to Level 5 Mirror Finish',
      dimensions: { lengthFt: widthFt, widthFt: depthFt, heightFt: 25, areaSqFt: 18000 },
      costs: { materials: Math.round(48000 * scaleFactor), labour: Math.round(92000 * scaleFactor), plant: Math.round(6000 * scaleFactor), total: Math.round(146000 * scaleFactor) },
      embodiedCarbonKg: 9200,
      supplier: 'USG Sheetrock / National Gypsum',
      warrantyYears: 20,
      expectedLifeYears: 50,
      maintenanceIntervalMonths: 60,
      tradeRequired: TradeType.DRYWALL_PLASTERER,
      position: [0, 3.5, 0],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },
    {
      id: 'INT-002',
      name: 'Double-Height Foyer Imperial Curved Staircase & Wrought Iron Railings',
      category: 'Interior',
      startDay: 430,
      endDay: 455,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: 'Custom Freestanding Curved White Oak Imperial Stair, Hand-Forged Wrought Iron Balusters, Solid Walnut Handrail',
      dimensions: { lengthFt: 16, widthFt: 14, heightFt: 14 },
      costs: { materials: Math.round(68000 * scaleFactor), labour: Math.round(48000 * scaleFactor), plant: Math.round(4000 * scaleFactor), total: Math.round(120000 * scaleFactor) },
      embodiedCarbonKg: 3400,
      supplier: 'Artistic Stairs / Custom Iron Artisans',
      warrantyYears: 50,
      expectedLifeYears: 100,
      maintenanceIntervalMonths: 24,
      tradeRequired: TradeType.FINISH_CARPENTER,
      position: [0, 2.0, 0.5],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },
    {
      id: 'INT-003',
      name: 'Bespoke Inset Chef Kitchen, Scullery & Calacatta Gold Marble Slabs',
      category: 'Interior',
      startDay: 440,
      endDay: 470,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: 'Custom Inset Hard Maple Cabinetry, 2-Inch Bookmatched Calacatta Gold Marble, Sub-Zero Pro 48, Dual Wolf 48" Ranges',
      dimensions: { lengthFt: 26, widthFt: 18, heightFt: 11, areaSqFt: 468 },
      costs: { materials: Math.round(148000 * scaleFactor), labour: Math.round(46000 * scaleFactor), plant: Math.round(4000 * scaleFactor), total: Math.round(198000 * scaleFactor) },
      embodiedCarbonKg: 6800,
      supplier: 'Peacock Cabinetry / ABC Stone NYC / Sub-Zero Wolf',
      warrantyYears: 20,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.FINISH_CARPENTER,
      position: [-widthM / 3, 1.2, -depthM / 4],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },
    {
      id: 'INT-004',
      name: 'Primary Spa Bathroom & 6 Guest En-Suite Suites',
      category: 'Interior',
      startDay: 445,
      endDay: 475,
      stage: ConstructionStage.INTERNAL_FINISH,
      material: 'Full-Slab Thassos Marble Showers, Waterworks Crystal & Unlacquered Brass Fittings, Victoria+Albert Volcanic Limestone Tub',
      dimensions: { lengthFt: 22, widthFt: 16, heightFt: 10, areaSqFt: 352 },
      costs: { materials: Math.round(128000 * scaleFactor), labour: Math.round(58000 * scaleFactor), plant: Math.round(4000 * scaleFactor), total: Math.round(190000 * scaleFactor) },
      embodiedCarbonKg: 5400,
      supplier: 'Waterworks / Artistic Tile NYC',
      warrantyYears: 25,
      expectedLifeYears: 30,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.PLUMBER,
      position: [widthM / 3, 4.8, depthM / 4],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'interior'
    },

    // --- ESTATE LANDSCAPING & GROUNDS ---
    {
      id: 'LND-001',
      name: 'Circular Granite Cobblestone Motor Court & Heated Gunite Pool',
      category: 'Landscape',
      startDay: 460,
      endDay: 488,
      stage: ConstructionStage.LANDSCAPE,
      material: 'Belgian Granite Hand-Split Cobblestones, 45x20 Gunite Inground Heated Pool with Limestone Coping, Rear Stone Loggia',
      dimensions: { lengthFt: 80, widthFt: 60, heightFt: 1.0, areaSqFt: 4800 },
      costs: { materials: Math.round(125000 * scaleFactor), labour: Math.round(98000 * scaleFactor), plant: Math.round(28000 * scaleFactor), total: Math.round(251000 * scaleFactor) },
      embodiedCarbonKg: 16800,
      supplier: 'Delaware Valley Stone / Anthony & Sylvan Pools',
      warrantyYears: 30,
      expectedLifeYears: 50,
      maintenanceIntervalMonths: 12,
      tradeRequired: TradeType.ESTATE_LANDSCAPER,
      machineRequired: MachineType.EXCAVATOR,
      position: [0, 0.05, depthM / 2 + 6],
      state: ComponentState.NOT_STARTED,
      progress: 0,
      layerGroup: 'landscape'
    }
  ];
};

/**
 * Calculates comprehensive project financials (Hard, Soft, Site, Contingency, Land, Marginal Costs)
 */
export function calculateProjectFinancials(params: HouseParameters, bimComponents?: BimComponent[]): ProjectFinancials {
  const { livingAreaSqFt, basementAreaSqFt, garageAreaSqFt, usRegion, luxuryTier, siteAreaAcres } = params;
  const regInfo = REGIONAL_MULTIPLIERS[usRegion] || REGIONAL_MULTIPLIERS.NORTHEAST;
  const comps = bimComponents || GENERATE_BIM_COMPONENTS(params);

  // 1. Calculate Component-level Hard Construction Cost
  let hardConstructionCost = 0;
  let sitePreparationCost = 0;
  let excavationFoundationCost = 0;
  let basementConcreteCost = 0;
  let structuralSteelFramingCost = 0;
  let roofingAssemblyCost = 0;
  let exteriorStoneFacadeCost = 0;
  let windowsDoorsCost = 0;
  let mepSystemsCost = 0;
  let drywallInsulationCost = 0;
  let luxuryFinishesMillworkCost = 0;
  let estateLandscapePoolCost = 0;
  let embodiedCarbonKg = 0;

  for (const c of comps) {
    hardConstructionCost += c.costs.total;
    embodiedCarbonKg += c.embodiedCarbonKg;

    if (c.category === 'Foundation') excavationFoundationCost += c.costs.total;
    else if (c.category === 'Basement') basementConcreteCost += c.costs.total;
    else if (c.category === 'Structure') structuralSteelFramingCost += c.costs.total;
    else if (c.category === 'Roof') roofingAssemblyCost += c.costs.total;
    else if (c.category === 'StoneFacade') exteriorStoneFacadeCost += c.costs.total;
    else if (c.category === 'Envelope') windowsDoorsCost += c.costs.total;
    else if (c.category === 'MEP_Electrical' || c.category === 'MEP_Plumbing' || c.category === 'MEP_HVAC' || c.category === 'Renewable') mepSystemsCost += c.costs.total;
    else if (c.category === 'Interior') {
      if (c.id === 'INT-001') drywallInsulationCost += c.costs.total;
      else luxuryFinishesMillworkCost += c.costs.total;
    } else if (c.category === 'Landscape') estateLandscapePoolCost += c.costs.total;
  }

  // Site Work
  const siteCivilUtilityCost = Math.round(115000 * regInfo.multiplier);
  const drivewayRetainingWallsCost = Math.round(145000 * regInfo.multiplier);
  const totalSiteCost = siteCivilUtilityCost + drivewayRetainingWallsCost + estateLandscapePoolCost;

  // Soft Costs (14-18% of Hard Cost)
  const architectureEngineeringCost = Math.round(hardConstructionCost * 0.075);
  const permitsInspectionsCost = Math.round(hardConstructionCost * 0.018);
  const projectManagementCost = Math.round(hardConstructionCost * 0.045);
  const interiorDesignCost = Math.round(hardConstructionCost * 0.025);
  const legalSurveyGeotechCost = Math.round(hardConstructionCost * 0.012);
  const softCostsTotal = architectureEngineeringCost + permitsInspectionsCost + projectManagementCost + interiorDesignCost + legalSurveyGeotechCost;

  // Contingency (10% standard luxury buffer)
  const contingencyCost = Math.round((hardConstructionCost + softCostsTotal + siteCivilUtilityCost) * 0.10);

  // Land (Tracked separately!)
  const landAcquisitionCost = Math.round(siteAreaAcres * 1250000 * regInfo.multiplier);

  // Total Project Budget (Hard + Soft + Site + Contingency, excluding land)
  const totalProjectBudget = hardConstructionCost + softCostsTotal + siteCivilUtilityCost + drivewayRetainingWallsCost + contingencyCost;

  // Estimated Market Value (typical 1.25x - 1.45x development multiplier in affluent US enclaves)
  const potentialMarketValue = Math.round((totalProjectBudget + landAcquisitionCost) * 1.32);

  // Per area metrics
  const hardCostPerSqFt = Math.round(hardConstructionCost / livingAreaSqFt);
  const totalCostPerSqFt = Math.round(totalProjectBudget / livingAreaSqFt);
  const hardCostPerM2 = Math.round(hardCostPerSqFt * 10.764);
  const totalCostPerM2 = Math.round(totalCostPerSqFt * 10.764);

  // Marginal Cost calculation for additional sq ft
  // Base increment is ~$420/sq ft, scaling with luxury tier and stone facade
  const marginalCostPerSqFt = Math.round(hardCostPerSqFt * 0.78);
  const marginalCostPerM2 = Math.round(marginalCostPerSqFt * 10.764);

  // Environmental & Lifecycle
  const embodiedCarbonTonnes = Math.round(embodiedCarbonKg / 1000);
  const estimatedAnnualEnergyCostUsd = Math.round((livingAreaSqFt * 0.85) * (params.hvacType === 'GEOTHERMAL_GROUND_LOOP' ? 0.45 : 0.80));
  const lifetime30YearMaintenanceUsd = Math.round(totalProjectBudget * 0.14);

  return {
    hardConstructionCost,
    sitePreparationCost,
    excavationFoundationCost,
    basementConcreteCost,
    structuralSteelFramingCost,
    roofingAssemblyCost,
    exteriorStoneFacadeCost,
    windowsDoorsCost,
    mepSystemsCost,
    drywallInsulationCost,
    luxuryFinishesMillworkCost,
    estateLandscapePoolCost,

    softCostsTotal,
    architectureEngineeringCost,
    permitsInspectionsCost,
    projectManagementCost,
    interiorDesignCost,
    legalSurveyGeotechCost,

    siteCivilUtilityCost,
    drivewayRetainingWallsCost,

    contingencyCost,
    landAcquisitionCost,
    totalProjectBudget,
    potentialMarketValue,

    hardCostPerSqFt,
    totalCostPerSqFt,
    hardCostPerM2,
    totalCostPerM2,
    marginalCostPerSqFt,
    marginalCostPerM2,

    embodiedCarbonTonnes,
    estimatedAnnualEnergyCostUsd,
    lifetime30YearMaintenanceUsd,
    constructionDurationDays: 490
  };
}

/**
 * Generates Marginal Cost Curve Data Points across Area Scale (4,000 to 12,000 sq ft)
 */
export function calculateMarginalCostCurve(params: HouseParameters): MarginalCostPoint[] {
  const points: MarginalCostPoint[] = [];
  const baseRate = REGIONAL_MULTIPLIERS[params.usRegion]?.baselineRate || 650;

  const areas = [4000, 5000, 6000, 7000, 8000, 9000, 10000, 12000];

  for (let i = 0; i < areas.length; i++) {
    const area = areas[i];
    // Economies of scale on fixed site setup, but diseconomies of scale as structural spans & luxury finish complexity grow
    let mc = baseRate * 0.70;
    let driver = 'Baseline living space expansion';

    if (area <= 5000) {
      mc = baseRate * 0.65;
      driver = 'Economies of scale on shared core infrastructure';
    } else if (area === 6000) {
      mc = baseRate * 0.74;
      driver = 'Standard 6,000 sq ft mansion baseline balance';
    } else if (area === 7000) {
      mc = baseRate * 0.82;
      driver = 'Additional HVAC zone + secondary scullery required';
    } else if (area === 8000) {
      mc = baseRate * 0.94;
      driver = 'Longer steel spans, 4th garage bay, larger stone facade area';
    } else if (area >= 10000) {
      mc = baseRate * 1.15;
      driver = 'Diseconomies of scale: commercial VRF, double imperial foyer, high-load foundation';
    }

    const totalHardCost = Math.round(area * (baseRate * 0.90 + (area > 6000 ? (area - 6000) * 0.03 : 0)));

    points.push({
      areaSqFt: area,
      totalHardCostUsd: totalHardCost,
      marginalCostPerSqFt: Math.round(mc),
      driverDescription: driver
    });
  }

  return points;
}

/**
 * Stone Facade Upgrade Marginal Comparison
 */
export function calculateStoneUpgradeCost(params: HouseParameters): {
  currentStoneCost: number;
  brickBaselineCost: number;
  deltaCostUsd: number;
  deltaPercent: number;
} {
  const wallAreaSqFt = 6200 * (params.livingAreaSqFt / 6000);
  const currentRate = STONE_FACADE_PROPERTIES[params.stoneFacade].costPerSqFt;
  const brickRate = STONE_FACADE_PROPERTIES.ANTIQUE_BRICK_STONE.costPerSqFt;

  const currentStoneCost = Math.round(wallAreaSqFt * currentRate);
  const brickBaselineCost = Math.round(wallAreaSqFt * brickRate);
  const deltaCostUsd = currentStoneCost - brickBaselineCost;
  const deltaPercent = Math.round((deltaCostUsd / brickBaselineCost) * 100);

  return { currentStoneCost, brickBaselineCost, deltaCostUsd, deltaPercent };
}

/**
 * Marginal Value Engine Upgrades Ledger
 */
export function GENERATE_VALUE_ENGINE_UPGRADES(params: HouseParameters): ValueEngineUpgrade[] {
  return [
    {
      id: 'UPG-001',
      name: '+500 sq ft Conditioned Living Area (Upper Bedroom Suite)',
      category: 'Space',
      costDeltaUsd: 215000,
      areaDeltaSqFt: 500,
      timeDeltaDays: 14,
      maintenanceDelta30YrUsd: 18000,
      energyImpactKwhPerYr: 1850,
      luxuryScorePoints: 12,
      estimatedValueContributionUsd: 340000,
      valueCostRatio: 1.58,
      verdict: 'HIGH_VALUE',
      description: 'Expands upper floor with en-suite bedroom. Very high appraisal value contribution vs construction cost.'
    },
    {
      id: 'UPG-002',
      name: 'Full Indiana Natural Limestone Facade & Carved Quoins',
      category: 'Exterior',
      costDeltaUsd: 320000,
      areaDeltaSqFt: 0,
      timeDeltaDays: 25,
      maintenanceDelta30YrUsd: -12000, // Reduced maintenance vs painted stucco/wood
      energyImpactKwhPerYr: -450,      // Thermal mass benefit
      luxuryScorePoints: 35,
      estimatedValueContributionUsd: 480000,
      valueCostRatio: 1.50,
      verdict: 'HIGH_VALUE',
      description: 'Transforms aesthetic into premier authentic stone estate. Significant curb-appeal appraisal premium.'
    },
    {
      id: 'UPG-003',
      name: '12-Seat Dolby Atmos Private Cinema & Sommelier Wine Cellar',
      category: 'Amenities',
      costDeltaUsd: 185000,
      areaDeltaSqFt: 0,
      timeDeltaDays: 10,
      maintenanceDelta30YrUsd: 14000,
      energyImpactKwhPerYr: 1200,
      luxuryScorePoints: 28,
      estimatedValueContributionUsd: 240000,
      valueCostRatio: 1.30,
      verdict: 'HIGH_VALUE',
      description: 'Tier-1 luxury entertainment amenity. High perceived emotional value for high-net-worth buyers.'
    },
    {
      id: 'UPG-004',
      name: '45x20 Heated Gunite Estate Pool & Stone Loggia',
      category: 'Amenities',
      costDeltaUsd: 225000,
      areaDeltaSqFt: 0,
      timeDeltaDays: 20,
      maintenanceDelta30YrUsd: 45000,
      energyImpactKwhPerYr: 3800,
      luxuryScorePoints: 30,
      estimatedValueContributionUsd: 260000,
      valueCostRatio: 1.16,
      verdict: 'BALANCED',
      description: 'Essential luxury lifestyle component. Moderate ongoing maintenance expenditure.'
    },
    {
      id: 'UPG-005',
      name: 'Multi-Zone Geothermal Ground Loop HVAC (8 Wells)',
      category: 'MEP',
      costDeltaUsd: 110000,
      areaDeltaSqFt: 0,
      timeDeltaDays: 8,
      maintenanceDelta30YrUsd: -22000,
      energyImpactKwhPerYr: -9500,     // 45% annual energy reduction
      luxuryScorePoints: 18,
      estimatedValueContributionUsd: 135000,
      valueCostRatio: 1.23,
      verdict: 'HIGH_VALUE',
      description: 'Cuts operating costs by 45%, eligible for 30% US Federal IRA Tax Credit, silent operation.'
    },
    {
      id: 'UPG-006',
      name: 'Vermont Natural Slate Roof vs Synthetic Slate',
      category: 'Exterior',
      costDeltaUsd: 270000,
      areaDeltaSqFt: 0,
      timeDeltaDays: 18,
      maintenanceDelta30YrUsd: -8000,
      energyImpactKwhPerYr: 0,
      luxuryScorePoints: 22,
      estimatedValueContributionUsd: 190000,
      valueCostRatio: 0.70,
      verdict: 'PURE_COMPLEXITY',
      description: '100-year longevity, but heavy structural truss reinforcement required. Marginal appraisal return.'
    },
    {
      id: 'UPG-007',
      name: '3-Car to 4-Car Attached Garage Expansion (+350 sq ft)',
      category: 'Space',
      costDeltaUsd: 95000,
      areaDeltaSqFt: 350,
      timeDeltaDays: 6,
      maintenanceDelta30YrUsd: 4000,
      energyImpactKwhPerYr: 300,
      luxuryScorePoints: 15,
      estimatedValueContributionUsd: 140000,
      valueCostRatio: 1.47,
      verdict: 'HIGH_VALUE',
      description: 'High buyer demand in suburban luxury estates for additional collector vehicle or golf cart bay.'
    }
  ];
}

/**
 * Economic Optimiser: computes target parameter set based on user goal & budget constraint
 */
export function OPTIMIZE_ESTATE_CONFIGURATION(
  goal: 'MAX_LUXURY' | 'MAX_AREA' | 'MIN_COST' | 'MAX_ROI',
  targetBudgetUsd: number,
  currentParams: HouseParameters
): HouseParameters {
  const regMult = REGIONAL_MULTIPLIERS[currentParams.usRegion]?.multiplier || 1.15;
  const optimized: HouseParameters = { ...currentParams };

  if (goal === 'MAX_LUXURY') {
    // High perceived luxury: Stone facade, Geothermal, Slate, Cinema, Pool, Scullery
    optimized.stoneFacade = 'INDIANA_LIMESTONE';
    optimized.roofMaterial = 'SYNTHETIC_SLATE';
    optimized.luxuryTier = 'ULTRA_LUXURY';
    optimized.hvacType = 'GEOTHERMAL_GROUND_LOOP';
    optimized.hasEstatePool = true;
    optimized.hasBasementCinema = true;
    optimized.hasWineCellar = true;
    optimized.hasPrepKitchen = true;
    // Scale area to fit budget
    const targetArea = Math.min(8500, Math.max(4800, Math.round(targetBudgetUsd / (780 * regMult))));
    optimized.livingAreaSqFt = targetArea;
    optimized.widthFt = Math.round(Math.sqrt(targetArea * 0.5 * 1.65));
    optimized.depthFt = Math.round(targetArea / (2 * optimized.widthFt));
  } else if (goal === 'MAX_AREA') {
    // Maximise floor area: efficient Brick/Stone mix, Asphalt/Synthetic roof, standard high luxury
    optimized.stoneFacade = 'ANTIQUE_BRICK_STONE';
    optimized.roofMaterial = 'ARCHITECTURAL_ASPHALT';
    optimized.luxuryTier = 'STANDARD_LUXURY';
    optimized.hvacType = 'HIGH_EFFICIENCY_HEAT_PUMP';
    const targetArea = Math.min(10500, Math.max(5500, Math.round(targetBudgetUsd / (480 * regMult))));
    optimized.livingAreaSqFt = targetArea;
    optimized.widthFt = Math.round(Math.sqrt(targetArea * 0.5 * 1.7));
    optimized.depthFt = Math.round(targetArea / (2 * optimized.widthFt));
  } else if (goal === 'MIN_COST') {
    // Minimise cost while preserving American estate elegance
    optimized.stoneFacade = 'CAST_STONE_STUCCO';
    optimized.roofMaterial = 'ARCHITECTURAL_ASPHALT';
    optimized.luxuryTier = 'STANDARD_LUXURY';
    optimized.hvacType = 'HIGH_EFFICIENCY_HEAT_PUMP';
    optimized.hasEstatePool = false;
    optimized.hasBasementCinema = false;
    optimized.hasWineCellar = false;
    optimized.livingAreaSqFt = 5000;
    optimized.widthFt = 68;
    optimized.depthFt = 38;
  } else if (goal === 'MAX_ROI') {
    // Maximise appraisal return: Indiana Limestone front + Antique brick wings, Geothermal, 4-Car Garage
    optimized.stoneFacade = 'INDIANA_LIMESTONE';
    optimized.roofMaterial = 'SYNTHETIC_SLATE';
    optimized.luxuryTier = 'HIGH_LUXURY';
    optimized.hvacType = 'GEOTHERMAL_GROUND_LOOP';
    optimized.garageBays = 4;
    optimized.hasBasementCinema = true;
    optimized.hasEstatePool = true;
    optimized.hasPrepKitchen = true;
    optimized.livingAreaSqFt = 6500;
    optimized.widthFt = 76;
    optimized.depthFt = 44;
  }

  return optimized;
}

// 30-Year Whole-Life Maintenance Schedule
export const WHOLE_LIFE_MAINTENANCE_SCHEDULE: MaintenanceItem[] = [
  { year: 1, componentId: 'MEP-001', componentName: 'Geothermal Heat Pump Loops', actionRequired: 'Annual refrigerant delta-T & closed loop pressure calibration', estimatedCostUsd: 450, urgency: 'ROUTINE', status: 'SCHEDULED' },
  { year: 3, componentId: 'ENV-001', componentName: 'Marvin Wood-Clad Windows', actionRequired: 'Perimeter silicone perimeter joint audit & sash weatherstrip lubrication', estimatedCostUsd: 850, urgency: 'ROUTINE', status: 'SCHEDULED' },
  { year: 5, componentId: 'STN-001', componentName: 'Indiana Limestone Facade', actionRequired: 'Tuckpointing mortar inspection & silicone sealant joint renewal at stone lintels', estimatedCostUsd: 2400, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 7, componentId: 'MEP-002', componentName: '48kW Kohler Backup Generator', actionRequired: 'Coolant flush, battery replacement, governor calibration & transfer switch test', estimatedCostUsd: 1200, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 10, componentId: 'ROOF-002', componentName: 'Copper Valleys & Downspouts', actionRequired: 'Copper soldered seam audit & roof drainage de-icing cable check', estimatedCostUsd: 1800, urgency: 'ROUTINE', status: 'PENDING' },
  { year: 12, componentId: 'LND-001', componentName: 'Heated Gunite Swimming Pool', actionRequired: 'Pool plaster re-marcite resurfacing & variable speed pump replacement', estimatedCostUsd: 12500, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 15, componentId: 'INT-003', componentName: 'Chef Kitchen Appliances', actionRequired: 'Sub-Zero compressor service & commercial range burner calibration', estimatedCostUsd: 4500, urgency: 'ROUTINE', status: 'PENDING' },
  { year: 18, componentId: 'MEP-001', componentName: 'Geothermal Compressors Upgrade', actionRequired: 'Generation-3 compressor module replacement (retaining ground boreholes)', estimatedCostUsd: 14000, urgency: 'CRITICAL', status: 'PENDING' },
  { year: 20, componentId: 'INT-002', componentName: 'White Oak Herringbone Flooring', actionRequired: 'Dustless screen & re-coat with matte commercial polyurethane', estimatedCostUsd: 8200, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 25, componentId: 'MEP-002', componentName: 'Solar PV Inverters & Storage', actionRequired: 'Tesla Powerwall battery capacity test & hybrid inverter renewal', estimatedCostUsd: 9500, urgency: 'RECOMMENDED', status: 'PENDING' },
  { year: 30, componentId: 'LND-001', componentName: 'Granite Cobblestone Motor Court', actionRequired: 'Polymeric sand joint vacuuming & sub-base re-leveling', estimatedCostUsd: 6800, urgency: 'ROUTINE', status: 'PENDING' }
];

// Masterplan Estate Plots (8 Staggered Luxury Mansions)
export const GENERATE_MASTERPLAN_PLOTS = (count: number = 8): MasterplanPlot[] => {
  const plotNames = [
    { estateName: 'The Biltmore Manor', houseType: 'Georgian Limestone Estate (6,800 sq ft)', days: 480, progress: 98, budget: 5120000, area: 6800, stage: ConstructionStage.LANDSCAPE },
    { estateName: 'The Somerset Hall', houseType: 'Colonial Sandstone Manor (6,200 sq ft)', days: 430, progress: 88, budget: 4680000, area: 6200, stage: ConstructionStage.INTERNAL_FINISH },
    { estateName: 'The Ashbourne Estate', houseType: 'Transitional Stone Residence (5,800 sq ft)', days: 360, progress: 73, budget: 3890000, area: 5800, stage: ConstructionStage.SERVICES },
    { estateName: 'The Greenwich Manor', houseType: 'Bedford Limestone Classic (7,400 sq ft)', days: 300, progress: 61, budget: 3240000, area: 7400, stage: ConstructionStage.STONE_FACADE },
    { estateName: 'The Foxborough Hall', houseType: 'Symmetrical Georgian (6,000 sq ft)', days: 240, progress: 49, budget: 2600000, area: 6000, stage: ConstructionStage.ROOF },
    { estateName: 'The Highclere Residence', houseType: 'Granite & Slate Estate (6,500 sq ft)', days: 180, progress: 37, budget: 1980000, area: 6500, stage: ConstructionStage.STRUCTURE },
    { estateName: 'The Windermere Court', houseType: 'American Stone Mansion (5,900 sq ft)', days: 110, progress: 22, budget: 1190000, area: 5900, stage: ConstructionStage.BASEMENT },
    { estateName: 'The Pemberley Manor', houseType: 'Limestone Portico Manor (6,400 sq ft)', days: 40, progress: 8, budget: 420000, area: 6400, stage: ConstructionStage.FOUNDATION }
  ];

  const plots: MasterplanPlot[] = [];
  const cols = 4;
  for (let i = 0; i < count; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const p = plotNames[i % plotNames.length];
    plots.push({
      id: i + 1,
      plotNumber: `ESTATE LOT ${String(i + 1).padStart(2, '0')}`,
      estateName: p.estateName,
      houseType: p.houseType,
      currentDay: p.days,
      stage: p.stage,
      progressPercent: p.progress,
      positionOffset: [(col - 1.5) * 32, 0, (row - 1) * 44],
      targetCompletionDays: 490,
      budgetSpentUsd: p.budget,
      livingAreaSqFt: p.area
    });
  }
  return plots;
};

export function getStageFromDay(day: number): ConstructionStage {
  if (day <= 15) return ConstructionStage.SITE;
  if (day <= 45) return ConstructionStage.GROUNDWORK;
  if (day <= 95) return ConstructionStage.FOUNDATION;
  if (day <= 135) return ConstructionStage.BASEMENT;
  if (day <= 180) return ConstructionStage.GROUND_FLOOR;
  if (day <= 230) return ConstructionStage.STRUCTURE;
  if (day <= 265) return ConstructionStage.ROOF;
  if (day <= 315) return ConstructionStage.STONE_FACADE;
  if (day <= 355) return ConstructionStage.ENVELOPE;
  if (day <= 405) return ConstructionStage.SERVICES;
  if (day <= 455) return ConstructionStage.INTERNAL_FINISH;
  if (day <= 475) return ConstructionStage.EXTERNAL_FINISH;
  if (day <= 489) return ConstructionStage.LANDSCAPE;
  return ConstructionStage.COMPLETE;
}

export function calculateOverallProgress(day: number): number {
  return Math.min(100, Math.max(0, Math.round((day / 490) * 100)));
}

export function getComponentStateAtDay(component: BimComponent, currentDay: number): { state: ComponentState; progress: number } {
  if (currentDay < component.startDay) {
    return { state: ComponentState.NOT_STARTED, progress: 0 };
  }
  if (currentDay >= component.endDay) {
    return { state: ComponentState.COMPLETE, progress: 1.0 };
  }
  const span = component.endDay - component.startDay;
  const elapsed = currentDay - component.startDay;
  const progress = Math.min(1.0, Math.max(0.0, elapsed / span));
  return {
    state: progress >= 0.9 ? ComponentState.INSTALLED : ComponentState.UNDER_CONSTRUCTION,
    progress
  };
}

export function calculateBudgetSpent(day: number, components: BimComponent[]): { spent: number; total: number; remaining: number } {
  let spent = 0;
  let total = 0;
  for (const comp of components) {
    total += comp.costs.total;
    const { progress } = getComponentStateAtDay(comp, day);
    spent += comp.costs.total * progress;
  }
  return {
    spent: Math.round(spent),
    total: Math.round(total),
    remaining: Math.max(0, Math.round(total - spent))
  };
}

export function calculateRoomsProgress(day: number): RoomBuildStatus[] {
  return ROOMS_CONFIG.map(room => {
    // Structure: Day 0 to 230
    const structure = Math.min(100, Math.max(0, Math.round((day / 230) * 100)));
    // Electrical rough & trim: Day 350 to 460
    const electrical = day < 350 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 350) / 110) * 100)));
    // Plumbing rough & trim: Day 360 to 465
    const plumbing = day < 360 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 360) / 105) * 100)));
    // HVAC & ducting: Day 355 to 450
    const hvac = day < 355 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 355) / 95) * 100)));
    // Drywall: Day 400 to 435
    const drywall = day < 400 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 400) / 35) * 100)));
    // Millwork & Cabinetry: Day 435 to 470
    const millwork = day < 435 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 435) / 35) * 100)));
    // Flooring: Day 440 to 475
    const flooring = day < 440 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 440) / 35) * 100)));
    // Paint & Decoration: Day 450 to 485
    const decoration = day < 450 ? 0 : Math.min(100, Math.max(0, Math.round(((day - 450) / 35) * 100)));

    const overall = Math.round(
      (structure * 0.20) + (drywall * 0.15) + (electrical * 0.10) + (plumbing * 0.10) +
      (hvac * 0.10) + (millwork * 0.15) + (flooring * 0.10) + (decoration * 0.10)
    );

    return {
      ...room,
      structure,
      electrical,
      plumbing,
      hvac,
      drywall,
      millwork,
      flooring,
      decoration,
      overall
    };
  });
}

export function calculateMaterialStock(day: number): MaterialStock[] {
  return INITIAL_MATERIAL_STOCK.map(mat => {
    let deliveryFactor = 0;
    let installFactor = 0;

    if (mat.id === 'MAT-CONCRETE' || mat.id === 'MAT-REBAR') {
      deliveryFactor = day > 30 ? Math.min(1, day / 90) : 0;
      installFactor = day > 45 ? Math.min(1, (day - 45) / 75) : 0;
    } else if (mat.id === 'MAT-STEEL' || mat.id === 'MAT-LVL') {
      deliveryFactor = day > 110 ? Math.min(1, (day - 110) / 100) : 0;
      installFactor = day > 135 ? Math.min(1, (day - 135) / 95) : 0;
    } else if (mat.id === 'MAT-SLATE') {
      deliveryFactor = day > 210 ? Math.min(1, (day - 210) / 50) : 0;
      installFactor = day > 235 ? Math.min(1, (day - 235) / 45) : 0;
    } else if (mat.id === 'MAT-STONE' || mat.id === 'MAT-QUOINS') {
      deliveryFactor = day > 240 ? Math.min(1, (day - 240) / 60) : 0;
      installFactor = day > 270 ? Math.min(1, (day - 270) / 55) : 0;
    } else if (mat.id === 'MAT-WINDOWS') {
      deliveryFactor = day > 290 ? Math.min(1, (day - 290) / 40) : 0;
      installFactor = day > 320 ? Math.min(1, (day - 320) / 30) : 0;
    } else if (mat.id === 'MAT-GEOTHERMAL') {
      deliveryFactor = day > 320 ? Math.min(1, (day - 320) / 50) : 0;
      installFactor = day > 350 ? Math.min(1, (day - 350) / 45) : 0;
    } else {
      deliveryFactor = day > 390 ? Math.min(1, (day - 390) / 60) : 0;
      installFactor = day > 430 ? Math.min(1, (day - 430) / 45) : 0;
    }

    return {
      ...mat,
      inTransit: Math.round(mat.totalRequired * Math.max(0, deliveryFactor - installFactor) * 0.4),
      deliveredToDate: Math.round(mat.totalRequired * deliveryFactor),
      installedToDate: Math.round(mat.totalRequired * installFactor)
    };
  });
}
