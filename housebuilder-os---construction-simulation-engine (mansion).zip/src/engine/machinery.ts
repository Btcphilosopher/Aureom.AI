/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Construction Machinery Kinematics Engine
 */

import * as THREE from 'three';
import { MachineType } from '../types/simulation';

export interface MachineryKinematics {
  excavator: {
    cabRotation: number;
    boomAngle: number;
    armAngle: number;
    bucketAngle: number;
    trackPosition: [number, number, number];
  };
  crane: {
    slewingAngle: number;
    trolleyDistance: number;
    hookHeight: number;
    payloadVisible: boolean;
  };
  mixer: {
    drumAngle: number;
    chuteAngle: number;
  };
  telehandler: {
    boomAngle: number;
    boomExtension: number;
    forkTilt: number;
  };
  truck: {
    bedTilt: number;
    wheelRotation: number;
  };
}

/**
 * Creates full 3D machinery meshes using Three.js grouped hierarchies with articulated pivot nodes
 */
export class MachineryEngine {
  public excavatorGroup: THREE.Group;
  public craneGroup: THREE.Group;
  public mixerGroup: THREE.Group;
  public telehandlerGroup: THREE.Group;
  public scaffoldingGroup: THREE.Group;
  public dumpTruckGroup: THREE.Group;

  // Articulation refs
  private excavatorCab!: THREE.Group;
  private excavatorBoom!: THREE.Group;
  private excavatorArm!: THREE.Group;
  private excavatorBucket!: THREE.Group;

  private craneJib!: THREE.Group;
  private craneTrolley!: THREE.Group;
  private craneCable!: THREE.Line;
  private craneHook!: THREE.Group;
  private cranePayload!: THREE.Mesh;

  private mixerDrum!: THREE.Mesh;

  private teleBoomPivot!: THREE.Group;
  private teleBoomTelescope!: THREE.Group;
  private teleForks!: THREE.Group;

  constructor() {
    this.excavatorGroup = this.createExcavator();
    this.craneGroup = this.createTowerCrane();
    this.mixerGroup = this.createConcreteMixer();
    this.telehandlerGroup = this.createTelehandler();
    this.scaffoldingGroup = this.createScaffolding();
    this.dumpTruckGroup = this.createDumpTruck();
  }

  // --- EXCAVATOR (CAT 320 Heavy Excavator) ---
  private createExcavator(): THREE.Group {
    const root = new THREE.Group();
    root.name = 'EXCAVATOR';

    const yellowMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3, metalness: 0.4 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.8, metalness: 0.2 });
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x71717a, roughness: 0.2, metalness: 0.8 });
    const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.6, roughness: 0.1 });

    // Tracks base (Chassis)
    const trackGeo = new THREE.BoxGeometry(0.5, 0.4, 2.6);
    const leftTrack = new THREE.Mesh(trackGeo, darkMat);
    leftTrack.position.set(-0.7, 0.2, 0);
    const rightTrack = new THREE.Mesh(trackGeo, darkMat);
    rightTrack.position.set(0.7, 0.2, 0);

    const undercarriage = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.25, 1.8), darkMat);
    undercarriage.position.set(0, 0.3, 0);

    root.add(leftTrack, rightTrack, undercarriage);

    // Rotating Cab
    this.excavatorCab = new THREE.Group();
    this.excavatorCab.position.set(0, 0.45, 0);

    const cabBody = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.0, 1.8), yellowMat);
    cabBody.position.set(0, 0.5, 0.1);

    const engineCounterweight = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.9, 0.6), darkMat);
    engineCounterweight.position.set(0, 0.45, -0.9);

    const operatorGlass = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.8, 0.9), glassMat);
    operatorGlass.position.set(-0.35, 0.6, 0.4);

    this.excavatorCab.add(cabBody, engineCounterweight, operatorGlass);

    // Main Boom Pivot
    this.excavatorBoom = new THREE.Group();
    this.excavatorBoom.position.set(0.3, 0.6, 0.6);

    const boomMesh = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.3, 2.2), yellowMat);
    boomMesh.position.set(0, 0.8, 0.8);
    boomMesh.rotation.x = -Math.PI / 4;
    this.excavatorBoom.add(boomMesh);

    // Hydraulic cylinder
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.2), steelMat);
    cyl.position.set(0, 0.4, 0.4);
    cyl.rotation.x = -Math.PI / 5;
    this.excavatorBoom.add(cyl);

    // Stick / Dipper Arm Pivot
    this.excavatorArm = new THREE.Group();
    this.excavatorArm.position.set(0, 1.5, 1.5);

    const armMesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.25, 1.8), yellowMat);
    armMesh.position.set(0, -0.6, 0.5);
    armMesh.rotation.x = Math.PI / 3;
    this.excavatorArm.add(armMesh);

    // Bucket Pivot
    this.excavatorBucket = new THREE.Group();
    this.excavatorBucket.position.set(0, -1.3, 1.1);

    const bucketMesh = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.5), steelMat);
    bucketMesh.position.set(0, 0, 0);
    this.excavatorBucket.add(bucketMesh);

    this.excavatorArm.add(this.excavatorBucket);
    this.excavatorBoom.add(this.excavatorArm);
    this.excavatorCab.add(this.excavatorBoom);
    root.add(this.excavatorCab);

    root.position.set(-6.5, 0, 4.5);
    root.rotation.y = Math.PI / 4;
    return root;
  }

  // --- TOWER CRANE (Liebherr 85EC Style) ---
  private createTowerCrane(): THREE.Group {
    const root = new THREE.Group();
    root.name = 'TOWER_CRANE';

    const craneYellow = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.3, metalness: 0.5 });
    const cableMat = new THREE.LineBasicMaterial({ color: 0x18181b, linewidth: 2 });
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4, metalness: 0.7 });

    // Mast Base & Tower (14m height)
    const baseConcrete = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.4, 2.5), new THREE.MeshStandardMaterial({ color: 0x94a3b8 }));
    baseConcrete.position.set(0, 0.2, 0);
    root.add(baseConcrete);

    // Lattice Mast
    const mastHeight = 12.0;
    const mast = new THREE.Mesh(new THREE.BoxGeometry(0.8, mastHeight, 0.8), craneYellow);
    mast.position.set(0, mastHeight / 2 + 0.4, 0);
    root.add(mast);

    // Slewing Jib Assembly
    this.craneJib = new THREE.Group();
    this.craneJib.position.set(0, mastHeight + 0.6, 0);

    // Operator Cab
    const cab = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 0.9), new THREE.MeshStandardMaterial({ color: 0xf8fafc }));
    cab.position.set(0.6, 0.2, 0.5);
    this.craneJib.add(cab);

    // Forward Jib (12m reach)
    const forwardJib = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 12), craneYellow);
    forwardJib.position.set(0, 0.3, 5.5);
    this.craneJib.add(forwardJib);

    // Counter Jib with weights
    const counterJib = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 4), craneYellow);
    counterJib.position.set(0, 0.3, -2.5);
    const counterWeights = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.8, 1.4), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    counterWeights.position.set(0, 0.3, -4.0);
    this.craneJib.add(counterJib, counterWeights);

    // Trolley
    this.craneTrolley = new THREE.Group();
    this.craneTrolley.position.set(0, 0.05, 5.0);
    const trolleyMesh = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.2, 0.6), steelMat);
    this.craneTrolley.add(trolleyMesh);

    // Cable & Hook
    this.craneHook = new THREE.Group();
    this.craneHook.position.set(0, -6.0, 0);

    const hookMesh = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.05, 8, 16), steelMat);
    hookMesh.rotation.x = Math.PI / 2;
    this.craneHook.add(hookMesh);

    // Payload (Prefab Timber Roof Truss / Brick Pallet)
    const trussMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.8 });
    this.cranePayload = new THREE.Mesh(new THREE.ConeGeometry(2.0, 1.0, 3), trussMat);
    this.cranePayload.position.set(0, -0.6, 0);
    this.cranePayload.rotation.z = Math.PI;
    this.craneHook.add(this.cranePayload);

    this.craneTrolley.add(this.craneHook);

    // Cable Line Geometry
    const cablePoints = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, -6.0, 0)];
    const cableGeo = new THREE.BufferGeometry().setFromPoints(cablePoints);
    this.craneCable = new THREE.Line(cableGeo, cableMat);
    this.craneTrolley.add(this.craneCable);

    this.craneJib.add(this.craneTrolley);
    root.add(this.craneJib);

    root.position.set(8.5, 0, -6.0);
    return root;
  }

  // --- CONCRETE MIXER TRUCK ---
  private createConcreteMixer(): THREE.Group {
    const root = new THREE.Group();
    root.name = 'CONCRETE_MIXER';

    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
    const blueMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x18181b });

    // Chassis & Cab
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.4, 5.2), darkMat);
    chassis.position.set(0, 0.4, 0);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.4, 1.5), whiteMat);
    cab.position.set(0, 1.3, 1.6);
    root.add(chassis, cab);

    // Wheels (6 wheels)
    const wheelGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 16);
    [-1.8, 0.2, 1.6].forEach(z => {
      const wL = new THREE.Mesh(wheelGeo, darkMat);
      wL.rotation.z = Math.PI / 2;
      wL.position.set(-1.0, 0.4, z);
      const wR = new THREE.Mesh(wheelGeo, darkMat);
      wR.rotation.z = Math.PI / 2;
      wR.position.set(1.0, 0.4, z);
      root.add(wL, wR);
    });

    // Spinning Drum
    const drumGeo = new THREE.CylinderGeometry(0.6, 1.0, 3.2, 16);
    this.mixerDrum = new THREE.Mesh(drumGeo, blueMat);
    this.mixerDrum.rotation.x = Math.PI / 2 - 0.25;
    this.mixerDrum.position.set(0, 1.5, -0.8);
    root.add(this.mixerDrum);

    // Chute
    const chute = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, 1.4), darkMat);
    chute.position.set(0, 0.7, -2.6);
    chute.rotation.x = -Math.PI / 6;
    root.add(chute);

    root.position.set(-7.5, 0, -3.5);
    root.rotation.y = -Math.PI / 6;
    return root;
  }

  // --- TELEHANDLER (JCB 540 Style) ---
  private createTelehandler(): THREE.Group {
    const root = new THREE.Group();
    root.name = 'TELEHANDLER';

    const yellowMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x27272a });

    // Chassis & 4 Big Offroad Wheels
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.0, 3.4), yellowMat);
    body.position.set(0, 0.9, 0);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.0, 1.4), darkMat);
    cab.position.set(-0.4, 1.7, 0);
    root.add(body, cab);

    const wheelGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.4, 16);
    [-1.2, 1.2].forEach(z => {
      const wL = new THREE.Mesh(wheelGeo, darkMat);
      wL.rotation.z = Math.PI / 2;
      wL.position.set(-0.95, 0.55, z);
      const wR = new THREE.Mesh(wheelGeo, darkMat);
      wR.rotation.z = Math.PI / 2;
      wR.position.set(0.95, 0.55, z);
      root.add(wL, wR);
    });

    // Telescopic Boom Pivot
    this.teleBoomPivot = new THREE.Group();
    this.teleBoomPivot.position.set(0.4, 1.5, -1.2);

    const outerBoom = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 3.2), yellowMat);
    outerBoom.position.set(0, 0, 1.6);
    this.teleBoomPivot.add(outerBoom);

    this.teleBoomTelescope = new THREE.Group();
    this.teleBoomTelescope.position.set(0, 0, 2.8);

    const innerBoom = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.3, 2.6), darkMat);
    innerBoom.position.set(0, 0, 1.3);
    this.teleBoomTelescope.add(innerBoom);

    // Forks & Pallet
    this.teleForks = new THREE.Group();
    this.teleForks.position.set(0, 0, 2.6);
    const carriage = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.4, 0.1), darkMat);
    const leftFork = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.04, 1.0), darkMat);
    leftFork.position.set(-0.3, -0.2, 0.5);
    const rightFork = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.04, 1.0), darkMat);
    rightFork.position.set(0.3, -0.2, 0.5);

    // Brick Pallet
    const brickPallet = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.6, 0.9), new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.9 }));
    brickPallet.position.set(0, 0.1, 0.5);

    this.teleForks.add(carriage, leftFork, rightFork, brickPallet);
    this.teleBoomTelescope.add(this.teleForks);
    this.teleBoomPivot.add(this.teleBoomTelescope);
    root.add(this.teleBoomPivot);

    root.position.set(6.8, 0, 5.2);
    root.rotation.y = -Math.PI / 4;
    return root;
  }

  // --- DUMP TRUCK (Tipper 32t) ---
  private createDumpTruck(): THREE.Group {
    const root = new THREE.Group();
    root.name = 'DUMP_TRUCK';

    const orangeMat = new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.4 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });

    const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.4, 5.5), darkMat);
    chassis.position.set(0, 0.4, 0);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.5, 1.6), orangeMat);
    cab.position.set(0, 1.35, 1.8);
    root.add(chassis, cab);

    // Wheels (8 wheels)
    const wheelGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.35, 16);
    [-2.0, -1.0, 0.0, 1.8].forEach(z => {
      const wL = new THREE.Mesh(wheelGeo, darkMat);
      wL.rotation.z = Math.PI / 2;
      wL.position.set(-1.05, 0.45, z);
      const wR = new THREE.Mesh(wheelGeo, darkMat);
      wR.rotation.z = Math.PI / 2;
      wR.position.set(1.05, 0.45, z);
      root.add(wL, wR);
    });

    // Tipper Bed with Muck / Soil
    const tipperBed = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.0, 3.4), darkMat);
    tipperBed.position.set(0, 1.2, -0.8);
    const soil = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.6, 3.2), new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 1.0 }));
    soil.position.set(0, 1.5, -0.8);
    root.add(tipperBed, soil);

    root.position.set(-8.2, 0, 1.2);
    root.rotation.y = Math.PI / 3;
    return root;
  }

  // --- SCAFFOLDING SYSTEM ---
  private createScaffolding(): THREE.Group {
    const root = new THREE.Group();
    root.name = 'SCAFFOLDING';

    const steelMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.3, metalness: 0.8 });
    const boardMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.8 });
    const netMat = new THREE.MeshStandardMaterial({ color: 0x059669, transparent: true, opacity: 0.35 });

    const w = 11.2;
    const l = 10.0;
    const tiers = [2.6, 5.2];

    // Scaffold poles & platforms around building perimeter
    tiers.forEach(height => {
      // Boards on 4 sides
      const boardFront = new THREE.Mesh(new THREE.BoxGeometry(w, 0.08, 0.9), boardMat);
      boardFront.position.set(0, height, l / 2 + 0.45);
      const boardBack = new THREE.Mesh(new THREE.BoxGeometry(w, 0.08, 0.9), boardMat);
      boardBack.position.set(0, height, -l / 2 - 0.45);
      const boardLeft = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, l), boardMat);
      boardLeft.position.set(-w / 2 - 0.45, height, 0);
      const boardRight = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, l), boardMat);
      boardRight.position.set(w / 2 + 0.45, height, 0);

      // Safety Green Netting & Rails
      const railFront = new THREE.Mesh(new THREE.BoxGeometry(w, 0.9, 0.05), netMat);
      railFront.position.set(0, height + 0.5, l / 2 + 0.9);
      const railBack = new THREE.Mesh(new THREE.BoxGeometry(w, 0.9, 0.05), netMat);
      railBack.position.set(0, height + 0.5, -l / 2 - 0.9);

      root.add(boardFront, boardBack, boardLeft, boardRight, railFront, railBack);
    });

    // Vertical Standard Poles (Cylinders)
    const poleGeo = new THREE.CylinderGeometry(0.04, 0.04, 6.2);
    for (let x = -w / 2 - 0.9; x <= w / 2 + 0.9; x += 2.8) {
      [-l / 2 - 0.9, l / 2 + 0.9].forEach(z => {
        const pole = new THREE.Mesh(poleGeo, steelMat);
        pole.position.set(x, 3.1, z);
        root.add(pole);
      });
    }

    return root;
  }

  /**
   * Updates machinery kinematics per frame and current construction day (490-day American Estate sequence)
   */
  public update(currentDay: number, timeSec: number) {
    // 1. Excavator active in Groundwork, Basement Excavation & Pool Excavation (Day 15 - 90, Day 460 - 485)
    const isDigging = (currentDay >= 15 && currentDay <= 85) || (currentDay >= 460 && currentDay <= 485);
    this.excavatorGroup.visible = isDigging || (currentDay >= 10 && currentDay <= 95);
    if (this.excavatorGroup.visible) {
      if (isDigging) {
        const cycle = (timeSec * 1.5) % (Math.PI * 2);
        this.excavatorCab.rotation.y = Math.sin(cycle * 0.5) * 0.7;
        this.excavatorBoom.rotation.x = -0.2 + Math.sin(cycle) * 0.25;
        this.excavatorArm.rotation.x = 0.4 + Math.cos(cycle) * 0.35;
        this.excavatorBucket.rotation.x = Math.sin(cycle + 0.5) * 0.6;
      }
    }

    // 2. Dump truck (Day 15 - Day 75)
    this.dumpTruckGroup.visible = currentDay >= 15 && currentDay <= 75;

    // 3. Concrete Mixer & Pump (Day 40 - Day 145)
    this.mixerGroup.visible = currentDay >= 38 && currentDay <= 145;
    if (this.mixerGroup.visible) {
      this.mixerDrum.rotation.y += 0.08;
    }

    // 4. Tower Crane (Day 180 - Day 290 for super trusses & stone)
    const isCraneActive = currentDay >= 175 && currentDay <= 285;
    this.craneGroup.visible = isCraneActive;
    if (this.craneGroup.visible) {
      const craneCycle = timeSec * 0.6;
      this.craneJib.rotation.y = Math.sin(craneCycle * 0.4) * 1.2 - 0.5;
      const trolleyZ = 4.0 + Math.sin(craneCycle * 0.8) * 3.5;
      this.craneTrolley.position.z = trolleyZ;
      const hookY = -4.0 + Math.cos(craneCycle * 0.6) * 2.5;
      this.craneHook.position.y = hookY;

      // Update cable line geometry
      const cableGeo = this.craneCable.geometry as THREE.BufferGeometry;
      const positions = cableGeo.attributes.position.array as Float32Array;
      positions[4] = hookY; // endpoint Y
      cableGeo.attributes.position.needsUpdate = true;
    }

    // 5. Telehandler (Day 130 - Day 330 for steel & Indiana stone pallets)
    this.telehandlerGroup.visible = currentDay >= 125 && currentDay <= 330;
    if (this.telehandlerGroup.visible) {
      const teleCycle = timeSec * 0.8;
      this.teleBoomPivot.rotation.x = -0.15 + Math.sin(teleCycle) * 0.2;
      this.teleBoomTelescope.position.z = 2.0 + Math.sin(teleCycle * 0.7) * 1.0;
    }

    // 6. Scaffolding visible during Superstructure, Roof & Stone Facade (Day 185 - Day 360)
    this.scaffoldingGroup.visible = currentDay >= 180 && currentDay <= 360;
  }
}
