/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate / Luxury Mansion Edition
 * Core 3D WebGL Construction Simulation Engine (Three.js)
 */

import * as THREE from 'three';
import {
  BimComponent,
  CameraPreset,
  ComponentState,
  ConstructionStage,
  HouseParameters,
  SimulationState,
  TimeOfDay,
  ViewMode,
  WeatherType
} from '../types/simulation';
import { MachineryEngine } from './machinery';
import { WorkerSimulationEngine } from './workers';
import { GENERATE_MASTERPLAN_PLOTS, STONE_FACADE_PROPERTIES, ROOF_MATERIAL_PROPERTIES } from './simulationModel';

export class ConstructionSceneEngine {
  public container: HTMLElement;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;

  // Camera & Orbit state
  private isMouseDown = false;
  private mousePrev = { x: 0, y: 0 };
  public cameraTarget = new THREE.Vector3(0, 3.5, 0);
  public cameraRadius = 26;
  public cameraTheta = Math.PI / 3.5; // Horizontal angle
  public cameraPhi = Math.PI / 4.2;   // Vertical elevation
  private targetCameraPos = new THREE.Vector3();
  private isCinematicDrone = false;

  // Sub-systems
  public machinery: MachineryEngine;
  public workers: WorkerSimulationEngine;

  // Lighting
  private sunLight: THREE.DirectionalLight;
  private ambientLight: THREE.AmbientLight;
  private siteFloodLights: THREE.Group;
  private houseInteriorLights: THREE.Group;

  // Weather & Particles
  private rainParticles?: THREE.Points;
  private snowParticles?: THREE.Points;
  private mepFlowParticles?: THREE.Points;
  private energyFlowParticles?: THREE.Points;

  // Geometry groups for stages & exploded view
  public groundGroup: THREE.Group;
  public foundationGroup: THREE.Group;
  public basementGroup: THREE.Group;
  public groundFloorGroup: THREE.Group;
  public wallsGroup: THREE.Group;
  public firstFloorGroup: THREE.Group;
  public roofGroup: THREE.Group;
  public envelopeGroup: THREE.Group;
  public stoneFacadeGroup: THREE.Group;
  public mepGroup: THREE.Group;
  public interiorGroup: THREE.Group;
  public landscapeGroup: THREE.Group;
  public masterplanGroup: THREE.Group;
  public poolGroup: THREE.Group;
  public dimensionLineGroup: THREE.Group;

  // Dynamic mesh references
  private poolWaterMesh?: THREE.Mesh;
  private chandelierMesh?: THREE.PointLight;

  // Raycasting & Selection
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  public hoveredComponentId: string | null = null;
  public onSelectComponent?: (id: string | null) => void;
  private componentMeshMap = new Map<string, THREE.Object3D[]>();

  // Dimensioning
  public dimensionPoints: THREE.Vector3[] = [];
  public onDistanceMeasured?: (distanceFt: number) => void;

  // Animation frame tracking
  private clock = new THREE.Clock();
  private animFrameId: number | null = null;
  public isDisposed = false;

  constructor(container: HTMLElement) {
    this.container = container;

    // 1. Scene & Renderer
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0d14); // Dark luxury slate canvas
    this.scene.fog = new THREE.FogExp2(0x0a0d14, 0.012);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;
    container.appendChild(this.renderer.domElement);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 800);
    this.updateCameraTransform();

    // 3. Lighting
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(0xfffdf5, 2.2);
    this.sunLight.position.set(30, 45, 30);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    this.sunLight.shadow.camera.near = 0.5;
    this.sunLight.shadow.camera.far = 160;
    const d = 32;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.scene.add(this.sunLight);

    this.siteFloodLights = new THREE.Group();
    this.scene.add(this.siteFloodLights);

    this.houseInteriorLights = new THREE.Group();
    this.scene.add(this.houseInteriorLights);

    // 4. Geometry Root Groups
    this.groundGroup = new THREE.Group();
    this.foundationGroup = new THREE.Group();
    this.basementGroup = new THREE.Group();
    this.groundFloorGroup = new THREE.Group();
    this.wallsGroup = new THREE.Group();
    this.firstFloorGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.envelopeGroup = new THREE.Group();
    this.stoneFacadeGroup = new THREE.Group();
    this.mepGroup = new THREE.Group();
    this.interiorGroup = new THREE.Group();
    this.landscapeGroup = new THREE.Group();
    this.masterplanGroup = new THREE.Group();
    this.poolGroup = new THREE.Group();
    this.dimensionLineGroup = new THREE.Group();

    this.scene.add(
      this.groundGroup,
      this.foundationGroup,
      this.basementGroup,
      this.groundFloorGroup,
      this.wallsGroup,
      this.firstFloorGroup,
      this.roofGroup,
      this.envelopeGroup,
      this.stoneFacadeGroup,
      this.mepGroup,
      this.interiorGroup,
      this.landscapeGroup,
      this.masterplanGroup,
      this.poolGroup,
      this.dimensionLineGroup
    );

    // 5. Machinery & Workers
    this.machinery = new MachineryEngine();
    this.workers = new WorkerSimulationEngine();
    this.scene.add(
      this.machinery.excavatorGroup,
      this.machinery.craneGroup,
      this.machinery.mixerGroup,
      this.machinery.telehandlerGroup,
      this.machinery.scaffoldingGroup,
      this.machinery.dumpTruckGroup,
      this.workers.rootGroup
    );

    // 6. Build Initial House Meshes
    this.buildGroundAndSite();
    this.buildAmericanMansionGeometry();
    this.initWeatherParticles();
    this.initMepFlowParticles();

    // 7. Event listeners
    this.setupEventListeners();

    // 8. Start Render Loop
    this.animate();
  }

  // --- AMERICAN STONE MANSION PROCEDURAL 3D BUILDER ---
  public buildAmericanMansionGeometry(params?: HouseParameters) {
    // Clear dynamic groups
    [
      this.foundationGroup,
      this.basementGroup,
      this.groundFloorGroup,
      this.wallsGroup,
      this.firstFloorGroup,
      this.roofGroup,
      this.envelopeGroup,
      this.stoneFacadeGroup,
      this.mepGroup,
      this.interiorGroup,
      this.landscapeGroup,
      this.poolGroup
    ].forEach(g => {
      while (g.children.length > 0) {
        g.remove(g.children[0]);
      }
    });

    this.componentMeshMap.clear();

    const wFt = params?.widthFt || 74;
    const dFt = params?.depthFt || 44;
    const livingArea = params?.livingAreaSqFt || 6000;
    const stoneType = params?.stoneFacade || 'INDIANA_LIMESTONE';
    const roofType = params?.roofMaterial || 'SYNTHETIC_SLATE';

    // Metric dimensions for Three.js (scale: 1 unit = 1 meter approx)
    // Main central block: ~13.5m wide x 10.0m deep x 7.8m tall (above grade)
    // Plus East wing: 5.5m wide x 8.0m deep
    // Plus West garage wing: 7.5m wide x 9.0m deep
    const mainW = (wFt * 0.3048) * 0.58;
    const mainD = dFt * 0.3048;
    const wingW = (wFt * 0.3048) * 0.24;
    const garageW = (wFt * 0.3048) * 0.32;
    const bsmH = 2.8; // 9.2 ft basement depth
    const gfH = 3.5;  // 11.5 ft ground ceiling
    const ffH = 3.2;  // 10.5 ft first floor ceiling
    const totalWallH = gfH + ffH;

    // Materials Palette
    const concreteMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.85 });
    const darkConcreteMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.9 });
    const insulationMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.95 });
    const rebarMat = new THREE.MeshStandardMaterial({ color: 0x52525b, metalness: 0.8, roughness: 0.3 });
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, metalness: 0.7, roughness: 0.3 });
    const lvlTimberMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.7 });
    const oakFloorMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.5 });
    const marbleMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.15, metalness: 0.1 });
    const darkWoodMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.6 });

    // Stone facade material
    let stoneColor = 0xdcd3c3; // Indiana Bedford Limestone (Warm buff)
    let stoneRoughness = 0.75;
    if (stoneType === 'BRIAR_HILL_SANDSTONE') {
      stoneColor = 0xd4a373;
    } else if (stoneType === 'VERMONT_GRANITE') {
      stoneColor = 0x9ca3af;
      stoneRoughness = 0.65;
    } else if (stoneType === 'ANTIQUE_BRICK_STONE') {
      stoneColor = 0x881337;
    } else if (stoneType === 'CAST_STONE_STUCCO') {
      stoneColor = 0xe2e8f0;
    }

    const stoneMat = new THREE.MeshStandardMaterial({ color: stoneColor, roughness: stoneRoughness });
    const quoinMat = new THREE.MeshStandardMaterial({ color: 0xeee7db, roughness: 0.6 }); // Dressed limestone trim
    const windowFrameMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.5 });
    const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.45, roughness: 0.05, metalness: 0.1, transmission: 0.6 });

    // Roof material
    let roofColor = 0x1e293b; // DaVinci Slate
    if (roofType === 'NATURAL_SLATE') roofColor = 0x0f172a;
    else if (roofType === 'ARCHITECTURAL_ASPHALT') roofColor = 0x334155;
    else if (roofType === 'STANDING_SEAM_COPPER') roofColor = 0x059669; // Aged copper green patina

    const roofMat = new THREE.MeshStandardMaterial({ color: roofColor, roughness: 0.6 });
    const copperFlashingMat = new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.8, roughness: 0.3 });

    // 1. FOUNDATIONS & FOOTINGS
    const footingMesh = new THREE.Mesh(new THREE.BoxGeometry(mainW + wingW + garageW + 2.0, 0.8, mainD + 2.0), concreteMat);
    footingMesh.position.set(0, -bsmH - 0.4, 0);
    footingMesh.castShadow = true;
    footingMesh.receiveShadow = true;
    this.foundationGroup.add(footingMesh);
    this.registerMeshForBim('FND-001', footingMesh);

    // Rebar Cage
    const rebarCage = new THREE.Mesh(new THREE.BoxGeometry(mainW + wingW + garageW + 1.6, 0.5, mainD + 1.6), rebarMat);
    rebarCage.position.set(0, -bsmH - 0.35, 0);
    this.foundationGroup.add(rebarCage);

    // 2. BASEMENT LEVEL (10ft deep concrete walls, slab, wine cellar, cinema)
    const bsmWalls = new THREE.Mesh(new THREE.BoxGeometry(mainW + wingW + 0.4, bsmH, mainD + 0.4), darkConcreteMat);
    bsmWalls.position.set(-garageW / 3, -bsmH / 2, 0);
    bsmWalls.castShadow = true;
    bsmWalls.receiveShadow = true;
    this.basementGroup.add(bsmWalls);
    this.registerMeshForBim('BSM-001', bsmWalls);

    const bsmSlab = new THREE.Mesh(new THREE.BoxGeometry(mainW + wingW, 0.25, mainD), concreteMat);
    bsmSlab.position.set(-garageW / 3, -bsmH + 0.12, 0);
    this.basementGroup.add(bsmSlab);
    this.registerMeshForBim('BSM-002', bsmSlab);

    // Basement Cinema Screen & Wine Cellar Racks (Visible in Cutaway/Exploded)
    const cinemaScreen = new THREE.Mesh(new THREE.BoxGeometry(4.2, 2.0, 0.08), new THREE.MeshStandardMaterial({ color: 0x000000, roughness: 0.1 }));
    cinemaScreen.position.set(-mainW / 2 - 1.0, -bsmH / 2, -mainD / 4);
    const wineGlassCellar = new THREE.Mesh(new THREE.BoxGeometry(3.0, 2.2, 1.5), glassMat);
    wineGlassCellar.position.set(0, -bsmH / 2, -mainD / 3);
    this.basementGroup.add(cinemaScreen, wineGlassCellar);

    // 3. STRUCTURAL STEEL BEAMS & GROUND FLOOR LVL JOISTS
    const steelBeam = new THREE.Mesh(new THREE.BoxGeometry(mainW + wingW + garageW, 0.35, 0.3), steelMat);
    steelBeam.position.set(0, 0.15, 0);
    this.groundFloorGroup.add(steelBeam);
    this.registerMeshForBim('STR-001', steelBeam);

    const gfSlab = new THREE.Mesh(new THREE.BoxGeometry(mainW + wingW + garageW, 0.28, mainD), lvlTimberMat);
    gfSlab.position.set(0, 0.14, 0);
    gfSlab.receiveShadow = true;
    this.groundFloorGroup.add(gfSlab);
    this.registerMeshForBim('STR-002', gfSlab);

    // 4. SUPERSTRUCTURE WALL FRAMING
    const frameMesh = new THREE.Mesh(new THREE.BoxGeometry(mainW, totalWallH, mainD), new THREE.MeshStandardMaterial({ color: 0xca8a04, roughness: 0.8 }));
    frameMesh.position.set(0, totalWallH / 2 + 0.28, 0);
    this.wallsGroup.add(frameMesh);
    this.registerMeshForBim('STR-003', frameMesh);

    // 5. EXTERIOR STONE FACADE (Central Mansion + Wings + Quoins + Portico)
    // Central Main Block
    const mainStoneBlock = new THREE.Mesh(new THREE.BoxGeometry(mainW, totalWallH, mainD), stoneMat);
    mainStoneBlock.position.set(0, totalWallH / 2 + 0.28, 0);
    mainStoneBlock.castShadow = true;
    mainStoneBlock.receiveShadow = true;
    this.stoneFacadeGroup.add(mainStoneBlock);
    this.registerMeshForBim('STN-001', mainStoneBlock);

    // East Wing (Library / Guest suites)
    const eastWingX = mainW / 2 + wingW / 2;
    const eastWing = new THREE.Mesh(new THREE.BoxGeometry(wingW, totalWallH * 0.9, mainD * 0.85), stoneMat);
    eastWing.position.set(eastWingX, (totalWallH * 0.9) / 2 + 0.28, -mainD * 0.05);
    eastWing.castShadow = true;
    eastWing.receiveShadow = true;
    this.stoneFacadeGroup.add(eastWing);

    // West Garage Wing (3-Car Carriage Garage)
    const westGarageX = -mainW / 2 - garageW / 2;
    const westGarage = new THREE.Mesh(new THREE.BoxGeometry(garageW, totalWallH * 0.82, mainD * 0.95), stoneMat);
    westGarage.position.set(westGarageX, (totalWallH * 0.82) / 2 + 0.28, 0);
    westGarage.castShadow = true;
    westGarage.receiveShadow = true;
    this.stoneFacadeGroup.add(westGarage);

    // Architectural Ashlar Stone Quoins (Corner Blocks)
    const quoinSize = 0.45;
    const corners = [
      { x: mainW / 2, z: mainD / 2 },
      { x: -mainW / 2, z: mainD / 2 },
      { x: mainW / 2, z: -mainD / 2 },
      { x: -mainW / 2, z: -mainD / 2 },
      { x: eastWingX + wingW / 2, z: mainD * 0.4 },
      { x: westGarageX - garageW / 2, z: mainD * 0.48 }
    ];

    for (const c of corners) {
      for (let y = 0.5; y < totalWallH + 0.2; y += 0.7) {
        const qMesh = new THREE.Mesh(new THREE.BoxGeometry(quoinSize, 0.32, quoinSize), quoinMat);
        qMesh.position.set(c.x > 0 ? c.x - 0.1 : c.x + 0.1, y, c.z > 0 ? c.z - 0.1 : c.z + 0.1);
        this.stoneFacadeGroup.add(qMesh);
      }
    }

    // Classical Stone Front Portico with Tuscan Columns & Grand Pediment
    const porticoGroup = new THREE.Group();
    const porticoRoof = new THREE.Mesh(new THREE.ConeGeometry(3.0, 1.2, 4), quoinMat);
    porticoRoof.rotation.y = Math.PI / 4;
    porticoRoof.position.set(0, gfH + 0.6, mainD / 2 + 1.6);

    const colGeo = new THREE.CylinderGeometry(0.24, 0.28, gfH, 16);
    const colLeft = new THREE.Mesh(colGeo, quoinMat);
    colLeft.position.set(-1.8, gfH / 2 + 0.28, mainD / 2 + 1.6);
    const colRight = new THREE.Mesh(colGeo, quoinMat);
    colRight.position.set(1.8, gfH / 2 + 0.28, mainD / 2 + 1.6);

    // Curved Stone Front Steps
    for (let i = 0; i < 4; i++) {
      const step = new THREE.Mesh(new THREE.CylinderGeometry(2.6 + i * 0.4, 2.8 + i * 0.4, 0.18, 16, 1, false, 0, Math.PI), quoinMat);
      step.position.set(0, 0.28 - i * 0.12, mainD / 2 + 1.8 + i * 0.3);
      porticoGroup.add(step);
    }

    porticoGroup.add(porticoRoof, colLeft, colRight);
    this.stoneFacadeGroup.add(porticoGroup);
    this.registerMeshForBim('STN-002', porticoGroup);

    // Twin Carved Stone Chimneys
    const chimney1 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 3.5, 1.2), stoneMat);
    chimney1.position.set(mainW / 2 - 1.2, totalWallH + 3.0, 0);
    const chimney2 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 3.5, 1.2), stoneMat);
    chimney2.position.set(-mainW / 2 + 1.2, totalWallH + 3.0, 0);
    const pot1 = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.8), new THREE.MeshStandardMaterial({ color: 0x9a3412 }));
    pot1.position.set(mainW / 2 - 1.2, totalWallH + 4.9, 0);
    const pot2 = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.8), new THREE.MeshStandardMaterial({ color: 0x9a3412 }));
    pot2.position.set(-mainW / 2 + 1.2, totalWallH + 4.9, 0);
    this.stoneFacadeGroup.add(chimney1, chimney2, pot1, pot2);

    // 6. ROOF & 5 CLASSICAL DORMERS
    const roofY = totalWallH + 0.28;
    const mainRoof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(mainW, mainD) * 0.85, 3.8, 4), roofMat);
    mainRoof.rotation.y = Math.PI / 4;
    mainRoof.scale.set(mainW / mainD, 1.0, 1.0);
    mainRoof.position.set(0, roofY + 1.9, 0);
    mainRoof.castShadow = true;
    this.roofGroup.add(mainRoof);
    this.registerMeshForBim('ROOF-001', mainRoof);

    // Wing Roofs
    const eastRoof = new THREE.Mesh(new THREE.ConeGeometry(wingW * 1.1, 2.6, 4), roofMat);
    eastRoof.rotation.y = Math.PI / 4;
    eastRoof.position.set(eastWingX, totalWallH * 0.9 + 1.3 + 0.28, -mainD * 0.05);
    const westRoof = new THREE.Mesh(new THREE.ConeGeometry(garageW * 1.05, 2.6, 4), roofMat);
    westRoof.rotation.y = Math.PI / 4;
    westRoof.position.set(westGarageX, totalWallH * 0.82 + 1.3 + 0.28, 0);
    this.roofGroup.add(eastRoof, westRoof);

    // 5 Classical Pedimented Dormer Windows
    const dormerPositions = [
      { x: -mainW * 0.3, z: mainD / 2 - 0.2 },
      { x: 0, z: mainD / 2 - 0.2 },
      { x: mainW * 0.3, z: mainD / 2 - 0.2 },
      { x: -mainW * 0.2, z: -mainD / 2 + 0.2 },
      { x: mainW * 0.2, z: -mainD / 2 + 0.2 }
    ];

    dormerPositions.forEach((dPos, idx) => {
      const dormerBox = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.4, 1.2), quoinMat);
      dormerBox.position.set(dPos.x, roofY + 1.0, dPos.z);
      const dormerRoof = new THREE.Mesh(new THREE.ConeGeometry(1.0, 0.7, 3), roofMat);
      dormerRoof.rotation.y = dPos.z > 0 ? 0 : Math.PI;
      dormerRoof.position.set(dPos.x, roofY + 1.85, dPos.z);
      const dormerWindow = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.9, 0.05), glassMat);
      dormerWindow.position.set(dPos.x, roofY + 1.0, dPos.z + (dPos.z > 0 ? 0.62 : -0.62));
      this.roofGroup.add(dormerBox, dormerRoof, dormerWindow);
    });

    // 7. WINDOWS, FRENCH DOORS & CARRIAGE DOORS (Symmetrical Georgian Layout)
    // Symmetrical Front Windows (Ground & Upper)
    const winGeo = new THREE.BoxGeometry(1.4, 2.2, 0.1);
    const winSillGeo = new THREE.BoxGeometry(1.6, 0.12, 0.25);
    const winLintelGeo = new THREE.BoxGeometry(1.7, 0.25, 0.2);

    const winXOffsets = [-mainW * 0.35, -mainW * 0.18, mainW * 0.18, mainW * 0.35];

    // Ground Floor Windows
    winXOffsets.forEach(x => {
      const win = new THREE.Mesh(winGeo, glassMat);
      win.position.set(x, gfH * 0.55 + 0.28, mainD / 2 + 0.05);
      const sill = new THREE.Mesh(winSillGeo, quoinMat);
      sill.position.set(x, gfH * 0.55 - 1.1 + 0.28, mainD / 2 + 0.12);
      const lintel = new THREE.Mesh(winLintelGeo, quoinMat);
      lintel.position.set(x, gfH * 0.55 + 1.2 + 0.28, mainD / 2 + 0.1);
      this.envelopeGroup.add(win, sill, lintel);
    });

    // First Floor Windows
    winXOffsets.concat([0]).forEach(x => {
      const win = new THREE.Mesh(winGeo, glassMat);
      win.position.set(x, gfH + ffH * 0.55 + 0.28, mainD / 2 + 0.05);
      const sill = new THREE.Mesh(winSillGeo, quoinMat);
      sill.position.set(x, gfH + ffH * 0.55 - 1.1 + 0.28, mainD / 2 + 0.12);
      const lintel = new THREE.Mesh(winLintelGeo, quoinMat);
      lintel.position.set(x, gfH + ffH * 0.55 + 1.2 + 0.28, mainD / 2 + 0.1);
      this.envelopeGroup.add(win, sill, lintel);
    });

    // Front Grand Mahogany Door with Fanlight Transom
    const frontDoor = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.6, 0.15), darkWoodMat);
    frontDoor.position.set(0, 1.58, mainD / 2 + 0.08);
    this.envelopeGroup.add(frontDoor);
    this.registerMeshForBim('ENV-001', frontDoor);

    // 3-Car Arched Carriage Garage Doors
    for (let g = 0; g < (params?.garageBays === 4 ? 4 : 3); g++) {
      const gx = westGarageX - garageW / 2 + 1.5 + g * 2.2;
      const gDoor = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2.4, 0.12), darkWoodMat);
      gDoor.position.set(gx, 1.48, mainD * 0.48);
      this.envelopeGroup.add(gDoor);
    }

    // Rear French Terrace Doors
    const frenchDoor1 = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.6, 0.1), glassMat);
    frenchDoor1.position.set(-mainW * 0.25, 1.58, -mainD / 2 - 0.05);
    const frenchDoor2 = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.6, 0.1), glassMat);
    frenchDoor2.position.set(mainW * 0.25, 1.58, -mainD / 2 - 0.05);
    this.envelopeGroup.add(frenchDoor1, frenchDoor2);
    this.registerMeshForBim('ENV-002', frenchDoor1);

    // 8. INTERIOR LUXURY FINISHES (Imperial Staircase, Herringbone, Chef Kitchen, Marble Bath)
    // Grand Imperial Curved Staircase in Double-Height Foyer
    const stairGroup = new THREE.Group();
    for (let s = 0; s < 18; s++) {
      const stepProg = s / 18;
      const stepMesh = new THREE.Mesh(new THREE.BoxGeometry(1.8 - stepProg * 0.4, 0.18, 0.4), oakFloorMat);
      stepMesh.position.set(Math.sin(stepProg * Math.PI) * 1.5, 0.38 + s * 0.19, -mainD * 0.1 + s * 0.22);
      stairGroup.add(stepMesh);
    }
    this.interiorGroup.add(stairGroup);
    this.registerMeshForBim('INT-002', stairGroup);

    // Foyer Crystal Chandelier Point Light
    const chandelier = new THREE.PointLight(0xffedd5, 1.8, 12);
    chandelier.position.set(0, gfH + 1.2, 0);
    this.houseInteriorLights.add(chandelier);

    // Chef Kitchen 14ft Marble Island
    const islandBase = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.95, 1.4), darkWoodMat);
    islandBase.position.set(mainW * 0.28, 0.75, -mainD * 0.25);
    const marbleTop = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.08, 1.5), marbleMat);
    marbleTop.position.set(mainW * 0.28, 1.26, -mainD * 0.25);
    this.interiorGroup.add(islandBase, marbleTop);
    this.registerMeshForBim('INT-003', islandBase);

    // Primary Spa Bath Volcanic Limestone Tub
    const spaTub = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.6, 0.65, 16), marbleMat);
    spaTub.position.set(-mainW * 0.28, gfH + 0.6, mainD * 0.22);
    this.interiorGroup.add(spaTub);
    this.registerMeshForBim('INT-004', spaTub);

    // 9. MEP & GEOTHERMAL SERVICES
    // Geothermal Heat Pump Plant & Borehole Manifold
    const geoUnit = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.8, 1.2), new THREE.MeshStandardMaterial({ color: 0x0284c7 }));
    geoUnit.position.set(westGarageX, -bsmH / 2, -mainD / 3);
    this.mepGroup.add(geoUnit);
    this.registerMeshForBim('MEP-001', geoUnit);

    // 400A Electrical Panels & Kohler 48kW Generator
    const genBody = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.4, 1.0), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    genBody.position.set(westGarageX - garageW / 2 - 1.5, 0.7, -mainD / 3);
    this.mepGroup.add(genBody);
    this.registerMeshForBim('MEP-002', genBody);

    // 10. ESTATE GROUNDS, CIRCULAR MOTOR COURT & 45x20 HEATED POOL
    // Circular Granite Cobblestone Motor Court with Central Fountain
    const courtGeo = new THREE.CylinderGeometry(11.0, 11.0, 0.04, 32);
    const courtMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.85 });
    const courtMesh = new THREE.Mesh(courtGeo, courtMat);
    courtMesh.position.set(0, 0.02, mainD / 2 + 13.0);
    courtMesh.receiveShadow = true;

    // Central Stone Island / Fountain
    const fountainIsland = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.4, 0.4, 24), quoinMat);
    fountainIsland.position.set(0, 0.22, mainD / 2 + 13.0);
    const fountainWater = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 2.8, 0.1, 24), new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1 }));
    fountainWater.position.set(0, 0.4, mainD / 2 + 13.0);
    this.landscapeGroup.add(courtMesh, fountainIsland, fountainWater);

    // Rear Stone Loggia & Terrace
    const rearTerrace = new THREE.Mesh(new THREE.BoxGeometry(mainW + 4.0, 0.15, 6.5), quoinMat);
    rearTerrace.position.set(0, 0.15, -mainD / 2 - 3.4);
    rearTerrace.receiveShadow = true;
    this.landscapeGroup.add(rearTerrace);

    // 45x20 Heated Gunite Swimming Pool with Limestone Coping
    const poolLengthM = 13.7; // 45 ft
    const poolWidthM = 6.1;   // 20 ft
    const poolCoping = new THREE.Mesh(new THREE.BoxGeometry(poolLengthM + 1.2, 0.12, poolWidthM + 1.2), quoinMat);
    poolCoping.position.set(0, 0.06, -mainD / 2 - 12.5);

    const poolWater = new THREE.Mesh(new THREE.BoxGeometry(poolLengthM, 0.08, poolWidthM), new THREE.MeshPhysicalMaterial({ color: 0x0284c7, transparent: true, opacity: 0.75, roughness: 0.05, transmission: 0.8 }));
    poolWater.position.set(0, 0.08, -mainD / 2 - 12.5);
    this.poolWaterMesh = poolWater;
    this.poolGroup.add(poolCoping, poolWater);
    this.registerMeshForBim('LND-001', poolCoping);
  }

  // Register mesh mapping for BIM hover & inspection
  private registerMeshForBim(componentId: string, mesh: THREE.Object3D) {
    mesh.userData = { bimId: componentId };
    const list = this.componentMeshMap.get(componentId) || [];
    list.push(mesh);
    this.componentMeshMap.set(componentId, list);
  }

  // --- SITE GROUND & ESTATE LAWN ---
  private buildGroundAndSite() {
    const siteGroundGeo = new THREE.PlaneGeometry(140, 140);
    const siteGroundMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.95 });
    const siteGround = new THREE.Mesh(siteGroundGeo, siteGroundMat);
    siteGround.rotation.x = -Math.PI / 2;
    siteGround.receiveShadow = true;
    siteGround.position.y = -0.01;
    this.groundGroup.add(siteGround);

    // Lush Estate Turf Grass
    const turfGeo = new THREE.PlaneGeometry(100, 100);
    const turfMat = new THREE.MeshStandardMaterial({ color: 0x14532d, roughness: 0.9 });
    const turfMesh = new THREE.Mesh(turfGeo, turfMat);
    turfMesh.rotation.x = -Math.PI / 2;
    turfMesh.receiveShadow = true;
    turfMesh.position.y = 0.005;
    this.groundGroup.add(turfMesh);

    // Perimeter Wrought Iron Estate Fencing & Stone Pillars
    const fenceMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4, metalness: 0.7 });
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0xdcd3c3, roughness: 0.7 });

    const fW = 65;
    const fL = 60;
    const fenceFront = new THREE.Mesh(new THREE.BoxGeometry(fW, 2.2, 0.1), fenceMat);
    fenceFront.position.set(0, 1.1, fL / 2);
    const fenceBack = new THREE.Mesh(new THREE.BoxGeometry(fW, 2.2, 0.1), fenceMat);
    fenceBack.position.set(0, 1.1, -fL / 2);
    const fenceLeft = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.2, fL), fenceMat);
    fenceLeft.position.set(-fW / 2, 1.1, 0);
    const fenceRight = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.2, fL), fenceMat);
    fenceRight.position.set(fW / 2, 1.1, 0);

    this.groundGroup.add(fenceFront, fenceBack, fenceLeft, fenceRight);
  }

  // --- WEATHER PARTICLE SYSTEMS ---
  private initWeatherParticles() {
    // Rain Particles
    const rainCount = 2400;
    const rainGeo = new THREE.BufferGeometry();
    const rainPositions = new Float32Array(rainCount * 3);
    for (let i = 0; i < rainCount; i++) {
      rainPositions[i * 3] = (Math.random() - 0.5) * 70;
      rainPositions[i * 3 + 1] = Math.random() * 35;
      rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 70;
    }
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({ color: 0x93c5fd, size: 0.18, transparent: true, opacity: 0.6 });
    this.rainParticles = new THREE.Points(rainGeo, rainMat);
    this.rainParticles.visible = false;
    this.scene.add(this.rainParticles);

    // Snow Particles
    const snowCount = 1800;
    const snowGeo = new THREE.BufferGeometry();
    const snowPositions = new Float32Array(snowCount * 3);
    for (let i = 0; i < snowCount; i++) {
      snowPositions[i * 3] = (Math.random() - 0.5) * 70;
      snowPositions[i * 3 + 1] = Math.random() * 35;
      snowPositions[i * 3 + 2] = (Math.random() - 0.5) * 70;
    }
    snowGeo.setAttribute('position', new THREE.BufferAttribute(snowPositions, 3));
    const snowMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.28, transparent: true, opacity: 0.85 });
    this.snowParticles = new THREE.Points(snowGeo, snowMat);
    this.snowParticles.visible = false;
    this.scene.add(this.snowParticles);
  }

  // --- MEP / ENERGY FLOW PARTICLES ---
  private initMepFlowParticles() {
    const count = 180;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 16;
      pos[i * 3 + 1] = 0.5 + Math.random() * 7.5;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 16;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({ color: 0x00f2ff, size: 0.22, transparent: true, opacity: 0.95 });
    this.mepFlowParticles = new THREE.Points(geo, mat);
    this.mepFlowParticles.visible = false;
    this.scene.add(this.mepFlowParticles);
  }

  // --- UPDATE ANIMATION & STATE ---
  public update(simState: SimulationState, bimComponents: BimComponent[]) {
    const dt = this.clock.getDelta();
    const timeSec = this.clock.getElapsedTime();

    const { currentDay, viewMode, cameraPreset, weather, timeOfDay, cutawayHeight, explodedSeparation, showStructuralOnly, masterplanActive } = simState;

    // 1. Lighting & Atmospheric transitions
    this.updateAtmosphericLighting(timeOfDay, weather);

    // 2. Weather particles
    if (this.rainParticles) {
      this.rainParticles.visible = weather === WeatherType.RAIN;
      if (this.rainParticles.visible) {
        const pos = this.rainParticles.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < pos.length; i += 3) {
          pos[i] -= 1.0;
          if (pos[i] < 0) pos[i] = 35;
        }
        this.rainParticles.geometry.attributes.position.needsUpdate = true;
      }
    }

    if (this.snowParticles) {
      this.snowParticles.visible = weather === WeatherType.SNOW;
      if (this.snowParticles.visible) {
        const pos = this.snowParticles.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < pos.length; i += 3) {
          pos[i] -= 0.18;
          if (pos[i] < 0) pos[i] = 35;
        }
        this.snowParticles.geometry.attributes.position.needsUpdate = true;
      }
    }

    // 3. Stage-driven component visibility & progressive assembly
    this.updateStageVisibility(currentDay, viewMode, showStructuralOnly);

    // 4. Cutaway & Exploded View Transforms
    this.updateExplodedAndCutaway(viewMode, cutawayHeight, explodedSeparation);

    // 5. Machinery & Worker Kinematics
    this.machinery.update(currentDay, timeSec);
    this.workers.update(currentDay > 488 ? ConstructionStage.COMPLETE : ConstructionStage.SITE, timeSec);

    // 6. Water animation & Flows
    if (this.poolWaterMesh && this.poolWaterMesh.visible) {
      this.poolWaterMesh.position.y = 0.08 + Math.sin(timeSec * 2.0) * 0.015;
    }

    if (this.mepFlowParticles && (viewMode === ViewMode.SERVICES_MEP || viewMode === ViewMode.ENERGY)) {
      this.mepFlowParticles.visible = true;
      const pos = this.mepFlowParticles.geometry.attributes.position.array as Float32Array;
      for (let i = 1; i < pos.length; i += 3) {
        pos[i] += 0.08;
        if (pos[i] > 8.5) pos[i] = 0.5;
      }
      this.mepFlowParticles.geometry.attributes.position.needsUpdate = true;
    } else if (this.mepFlowParticles) {
      this.mepFlowParticles.visible = false;
    }

    // 7. Masterplan Mode
    this.updateMasterplanMode(masterplanActive || viewMode === ViewMode.MASTERPLAN);

    // 8. Drone Camera Auto-Orbit
    if (cameraPreset === CameraPreset.CINEMATIC_DRONE) {
      this.cameraTheta += 0.0035;
      this.cameraPhi = Math.PI / 4.5 + Math.sin(timeSec * 0.25) * 0.08;
      this.updateCameraTransform();
    }
  }

  private updateStageVisibility(day: number, viewMode: ViewMode, structuralOnly: boolean) {
    // 490-Day Timeline Stage Logic:
    // Foundations: Day 40 - 95
    this.foundationGroup.visible = day >= 35;

    // Basement: Day 75 - 140
    this.basementGroup.visible = day >= 70;

    // Ground Floor & Structural Steel: Day 135+
    this.groundFloorGroup.visible = day >= 130;

    // Superstructure Walls Framing: Day 190+
    this.wallsGroup.visible = day >= 185;
    if (this.wallsGroup.visible && day < 235) {
      const prog = Math.min(1.0, (day - 185) / 50);
      this.wallsGroup.scale.y = Math.max(0.1, prog);
    } else if (this.wallsGroup.visible) {
      this.wallsGroup.scale.y = 1.0;
    }

    // Roof Trusses & Decking: Day 230+
    this.roofGroup.visible = day >= 225 && !structuralOnly && viewMode !== ViewMode.CUTAWAY;
    if (this.roofGroup.visible && day < 285) {
      const rProg = Math.min(1.0, (day - 225) / 60);
      this.roofGroup.scale.y = Math.max(0.1, rProg);
    } else if (this.roofGroup.visible) {
      this.roofGroup.scale.y = 1.0;
    }

    // Natural Stone Facade & Quoins: Day 275+
    this.stoneFacadeGroup.visible = day >= 270 && !structuralOnly;

    // Windows & Weathertight Envelope: Day 320+
    this.envelopeGroup.visible = day >= 315 && !structuralOnly;

    // MEP Services & Geothermal: Day 355+
    this.mepGroup.visible = (day >= 350 || viewMode === ViewMode.SERVICES_MEP || viewMode === ViewMode.ENERGY) && !structuralOnly;

    // Luxury Interior Finishes & Staircase: Day 400+
    this.interiorGroup.visible = day >= 395 && !structuralOnly;

    // Estate Landscaping & Heated Pool: Day 460+
    this.landscapeGroup.visible = day >= 455 && !structuralOnly;
    this.poolGroup.visible = day >= 460 && !structuralOnly;
  }

  private updateExplodedAndCutaway(viewMode: ViewMode, cutawayH: number, explodedSep: number) {
    if (viewMode === ViewMode.EXPLODED) {
      const s = explodedSep * 8.5;
      this.foundationGroup.position.y = -s * 0.7;
      this.basementGroup.position.y = -s * 0.4;
      this.groundFloorGroup.position.y = 0;
      this.wallsGroup.position.y = s * 0.4;
      this.stoneFacadeGroup.position.y = s * 0.7;
      this.envelopeGroup.position.y = s * 1.0;
      this.interiorGroup.position.y = s * 1.3;
      this.mepGroup.position.y = s * 1.7;
      this.roofGroup.position.y = s * 2.5;
      this.landscapeGroup.position.y = -s * 0.2;
      this.poolGroup.position.y = -s * 0.2;
    } else {
      this.foundationGroup.position.y = 0;
      this.basementGroup.position.y = 0;
      this.groundFloorGroup.position.y = 0;
      this.wallsGroup.position.y = 0;
      this.stoneFacadeGroup.position.y = 0;
      this.envelopeGroup.position.y = 0;
      this.interiorGroup.position.y = 0;
      this.mepGroup.position.y = 0;
      this.roofGroup.position.y = 0;
      this.landscapeGroup.position.y = 0;
      this.poolGroup.position.y = 0;
    }

    if (viewMode === ViewMode.CUTAWAY) {
      // Hide roof, lower front stone facade to reveal grand foyer, imperial stairs & basement!
      this.roofGroup.visible = false;
      const targetY = cutawayH * 8.0;
      this.stoneFacadeGroup.position.y = Math.min(0, targetY - 8.0);
      this.envelopeGroup.position.y = Math.min(0, targetY - 8.0);
    }
  }

  private updateMasterplanMode(active: boolean) {
    if (!active) {
      while (this.masterplanGroup.children.length > 0) {
        this.masterplanGroup.remove(this.masterplanGroup.children[0]);
      }
      return;
    }

    if (this.masterplanGroup.children.length === 0) {
      const plots = GENERATE_MASTERPLAN_PLOTS(8);
      plots.forEach(plot => {
        if (plot.id === 1) return; // Main active house
        const pGroup = new THREE.Group();
        pGroup.position.set(plot.positionOffset[0], plot.positionOffset[1], plot.positionOffset[2]);

        const miniMansion = new THREE.Mesh(
          new THREE.BoxGeometry(14, 7.5, 9),
          new THREE.MeshStandardMaterial({ color: 0xdcd3c3, roughness: 0.8 })
        );
        miniMansion.position.set(0, 3.75, 0);

        const miniRoof = new THREE.Mesh(
          new THREE.ConeGeometry(11, 3.5, 4),
          new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 })
        );
        miniRoof.rotation.y = Math.PI / 4;
        miniRoof.position.set(0, 9.25, 0);

        pGroup.add(miniMansion, miniRoof);
        this.masterplanGroup.add(pGroup);
      });
    }
  }

  private updateAtmosphericLighting(time: TimeOfDay, weather: WeatherType) {
    switch (time) {
      case TimeOfDay.SUNRISE:
        this.sunLight.color.setHex(0xfb923c); // Warm amber
        this.sunLight.intensity = 1.6;
        this.sunLight.position.set(35, 12, 35);
        this.ambientLight.color.setHex(0x38bdf8);
        this.ambientLight.intensity = 0.55;
        this.scene.background = new THREE.Color(0x13112b);
        break;
      case TimeOfDay.MIDDAY:
        this.sunLight.color.setHex(0xfffdf5);
        this.sunLight.intensity = 2.4;
        this.sunLight.position.set(10, 48, 15);
        this.ambientLight.color.setHex(0xffffff);
        this.ambientLight.intensity = 0.85;
        this.scene.background = new THREE.Color(0x0a0d14);
        break;
      case TimeOfDay.GOLDEN_HOUR:
        this.sunLight.color.setHex(0xf59e0b);
        this.sunLight.intensity = 1.9;
        this.sunLight.position.set(-35, 14, -28);
        this.ambientLight.color.setHex(0xfdba74);
        this.ambientLight.intensity = 0.65;
        this.scene.background = new THREE.Color(0x210c38);
        break;
      case TimeOfDay.NIGHT:
        this.sunLight.intensity = 0.08;
        this.ambientLight.color.setHex(0x1e293b);
        this.ambientLight.intensity = 0.35;
        this.scene.background = new THREE.Color(0x020408);
        break;
      default:
        this.sunLight.color.setHex(0xfffdf5);
        this.sunLight.intensity = 2.2;
        this.ambientLight.color.setHex(0xffffff);
        this.ambientLight.intensity = 0.75;
        this.scene.background = new THREE.Color(0x0a0d14);
        break;
    }
  }

  // --- CAMERA PRESET CONTROLS ---
  public setCameraPreset(preset: CameraPreset) {
    switch (preset) {
      case CameraPreset.ESTATE_OVERVIEW:
      case CameraPreset.ORBIT:
        this.cameraTarget.set(0, 3.5, 0);
        this.cameraRadius = 32;
        this.cameraTheta = Math.PI / 3.5;
        this.cameraPhi = Math.PI / 4.2;
        break;
      case CameraPreset.FRONT_PORTICO:
        this.cameraTarget.set(0, 2.2, 7.5);
        this.cameraRadius = 12;
        this.cameraTheta = Math.PI / 2;
        this.cameraPhi = Math.PI / 5.5;
        break;
      case CameraPreset.REAR_TERRACE:
        this.cameraTarget.set(0, 1.8, -10.0);
        this.cameraRadius = 18;
        this.cameraTheta = -Math.PI / 2;
        this.cameraPhi = Math.PI / 4.8;
        break;
      case CameraPreset.GRAND_FOYER:
        this.cameraTarget.set(0, 2.5, 0);
        this.cameraRadius = 9;
        this.cameraTheta = Math.PI / 2.2;
        this.cameraPhi = Math.PI / 3.8;
        break;
      case CameraPreset.CHEF_KITCHEN:
        this.cameraTarget.set(4.5, 1.5, -3.0);
        this.cameraRadius = 8;
        this.cameraTheta = -Math.PI / 3;
        this.cameraPhi = Math.PI / 4.0;
        break;
      case CameraPreset.BASEMENT_CINEMA:
        this.cameraTarget.set(-4.5, -1.2, -2.5);
        this.cameraRadius = 7;
        this.cameraTheta = Math.PI / 4;
        this.cameraPhi = Math.PI / 4.5;
        break;
      case CameraPreset.PRIMARY_SUITE:
        this.cameraTarget.set(-4.0, 4.5, 2.5);
        this.cameraRadius = 8;
        this.cameraTheta = Math.PI / 3;
        this.cameraPhi = Math.PI / 4.2;
        break;
      case CameraPreset.ROOF_LEVEL:
        this.cameraTarget.set(0, 8.5, 0);
        this.cameraRadius = 16;
        this.cameraTheta = Math.PI / 4;
        this.cameraPhi = Math.PI / 5.5;
        break;
      case CameraPreset.SECTION_CUT:
        this.cameraTarget.set(0, 3.0, 0);
        this.cameraRadius = 24;
        this.cameraTheta = 0;
        this.cameraPhi = Math.PI / 2.05;
        break;
    }
    this.updateCameraTransform();
  }

  // Orbit camera position calculation
  private updateCameraTransform() {
    const x = this.cameraTarget.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    const y = this.cameraTarget.y + this.cameraRadius * Math.cos(this.cameraPhi);
    const z = this.cameraTarget.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);

    this.camera.position.set(x, Math.max(0.5, y), z);
    this.camera.lookAt(this.cameraTarget);
  }

  // --- EVENT LISTENERS & RAYCASTING ---
  private setupEventListeners() {
    const el = this.container;

    const onMouseDown = (e: MouseEvent) => {
      this.isMouseDown = true;
      this.mousePrev = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      // Raycast Hover
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.scene.children, true);

      let foundId: string | null = null;
      for (const hit of intersects) {
        if (hit.object.userData?.bimId) {
          foundId = hit.object.userData.bimId;
          break;
        }
      }
      this.hoveredComponentId = foundId;

      if (!this.isMouseDown) return;

      const dx = e.clientX - this.mousePrev.x;
      const dy = e.clientY - this.mousePrev.y;
      this.mousePrev = { x: e.clientX, y: e.clientY };

      if (e.shiftKey) {
        // Pan
        const panSpeed = 0.025;
        const right = new THREE.Vector3().crossVectors(this.camera.up, this.camera.position.clone().sub(this.cameraTarget)).normalize();
        this.cameraTarget.addScaledVector(right, -dx * panSpeed);
        this.cameraTarget.y += dy * panSpeed;
      } else {
        // Rotate Orbit
        const rotSpeed = 0.005;
        this.cameraTheta -= dx * rotSpeed;
        this.cameraPhi = Math.max(0.08, Math.min(Math.PI / 2 - 0.04, this.cameraPhi - dy * rotSpeed));
      }
      this.updateCameraTransform();
    };

    const onMouseUp = () => {
      this.isMouseDown = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const zoomFactor = e.deltaY > 0 ? 1.08 : 0.92;
      this.cameraRadius = Math.max(3, Math.min(95, this.cameraRadius * zoomFactor));
      this.updateCameraTransform();
    };

    const onClick = () => {
      if (this.hoveredComponentId && this.onSelectComponent) {
        this.onSelectComponent(this.hoveredComponentId);
      }
    };

    const onResize = () => {
      if (!this.container || !this.renderer || !this.camera) return;
      const w = this.container.clientWidth;
      const h = this.container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    };

    el.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    el.addEventListener('wheel', onWheel, { passive: false });
    el.addEventListener('click', onClick);
    window.addEventListener('resize', onResize);
  }

  // --- RENDER LOOP ---
  private animate = () => {
    if (this.isDisposed) return;
    this.animFrameId = requestAnimationFrame(this.animate);
    this.renderer.render(this.scene, this.camera);
  };

  public dispose() {
    this.isDisposed = true;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    this.renderer.dispose();
    while (this.container.firstChild) {
      this.container.removeChild(this.container.firstChild);
    }
  }
}
