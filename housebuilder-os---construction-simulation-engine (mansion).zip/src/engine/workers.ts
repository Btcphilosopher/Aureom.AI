/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Construction Worker Entities & Trade Crew Simulation
 */

import * as THREE from 'three';
import { ConstructionStage, TradeType } from '../types/simulation';

interface WorkerData {
  trade: TradeType;
  basePos: [number, number, number];
  activeStages: ConstructionStage[];
  vestColor: number;
  hatColor: number;
}

export class WorkerSimulationEngine {
  public rootGroup: THREE.Group;
  private workers: {
    group: THREE.Group;
    data: WorkerData;
    leftArm: THREE.Group;
    rightArm: THREE.Group;
    body: THREE.Mesh;
    tool?: THREE.Mesh;
  }[] = [];

  constructor() {
    this.rootGroup = new THREE.Group();
    this.rootGroup.name = 'CONSTRUCTION_WORKERS';
    this.initWorkers();
  }

  private initWorkers() {
    const workerConfigs: WorkerData[] = [
      {
        trade: TradeType.SITE_SUPERINTENDENT,
        basePos: [-5.5, 0, 8.5],
        activeStages: [
          ConstructionStage.SITE,
          ConstructionStage.GROUNDWORK,
          ConstructionStage.FOUNDATION,
          ConstructionStage.BASEMENT,
          ConstructionStage.GROUND_FLOOR,
          ConstructionStage.STRUCTURE,
          ConstructionStage.ROOF,
          ConstructionStage.STONE_FACADE,
          ConstructionStage.ENVELOPE,
          ConstructionStage.SERVICES,
          ConstructionStage.INTERNAL_FINISH,
          ConstructionStage.LANDSCAPE,
          ConstructionStage.COMPLETE
        ],
        vestColor: 0xffffff, // White superintendent vest
        hatColor: 0xffffff
      },
      {
        trade: TradeType.GROUNDWORKER,
        basePos: [-7.2, 0, 3.5],
        activeStages: [ConstructionStage.SITE, ConstructionStage.GROUNDWORK, ConstructionStage.FOUNDATION],
        vestColor: 0xf97316, // Orange
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.FOUNDATION_CREW,
        basePos: [2.5, -1.8, 3.0],
        activeStages: [ConstructionStage.FOUNDATION, ConstructionStage.BASEMENT],
        vestColor: 0xeab308,
        hatColor: 0xfacc15
      },
      {
        trade: TradeType.STEEL_ERECTOR,
        basePos: [0, 0.4, -2.0],
        activeStages: [ConstructionStage.BASEMENT, ConstructionStage.GROUND_FLOOR, ConstructionStage.STRUCTURE],
        vestColor: 0x3b82f6,
        hatColor: 0xef4444
      },
      {
        trade: TradeType.FRAMING_CARPENTER,
        basePos: [-3.5, 3.8, 1.5],
        activeStages: [ConstructionStage.GROUND_FLOOR, ConstructionStage.STRUCTURE, ConstructionStage.ROOF],
        vestColor: 0xeab308,
        hatColor: 0xef4444
      },
      {
        trade: TradeType.STONE_MASON,
        basePos: [6.8, 2.2, 5.0],
        activeStages: [ConstructionStage.STONE_FACADE, ConstructionStage.EXTERNAL_FINISH, ConstructionStage.LANDSCAPE],
        vestColor: 0xd97706, // Amber
        hatColor: 0xffffff
      },
      {
        trade: TradeType.ROOFER,
        basePos: [2.0, 7.8, 1.0],
        activeStages: [ConstructionStage.ROOF, ConstructionStage.ENVELOPE],
        vestColor: 0xf97316,
        hatColor: 0xef4444
      },
      {
        trade: TradeType.WINDOW_GLAZIER,
        basePos: [-2.0, 2.5, 5.8],
        activeStages: [ConstructionStage.ENVELOPE],
        vestColor: 0x06b6d4,
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.ELECTRICIAN,
        basePos: [-2.2, 1.4, 0.5],
        activeStages: [ConstructionStage.SERVICES, ConstructionStage.INTERNAL_FINISH],
        vestColor: 0x06b6d4, // Cyan
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.PLUMBER,
        basePos: [3.2, 1.4, -2.0],
        activeStages: [ConstructionStage.SERVICES, ConstructionStage.INTERNAL_FINISH],
        vestColor: 0x3b82f6, // Blue
        hatColor: 0x3b82f6
      },
      {
        trade: TradeType.HVAC_TECHNICIAN,
        basePos: [-6.5, 0.5, -4.0],
        activeStages: [ConstructionStage.SERVICES],
        vestColor: 0x0284c7,
        hatColor: 0x38bdf8
      },
      {
        trade: TradeType.FINISH_CARPENTER,
        basePos: [0, 1.2, 1.0],
        activeStages: [ConstructionStage.INTERNAL_FINISH],
        vestColor: 0xeab308,
        hatColor: 0xfacc15
      },
      {
        trade: TradeType.ESTATE_LANDSCAPER,
        basePos: [4.5, 0, 10.0],
        activeStages: [ConstructionStage.LANDSCAPE],
        vestColor: 0x22c55e, // Green
        hatColor: 0xfacc15
      }
    ];

    workerConfigs.forEach(cfg => {
      const workerMesh = this.createWorkerMesh(cfg);
      this.workers.push(workerMesh);
      this.rootGroup.add(workerMesh.group);
    });
  }

  private createWorkerMesh(data: WorkerData) {
    const group = new THREE.Group();
    group.position.set(...data.basePos);

    const skinMat = new THREE.MeshStandardMaterial({ color: 0xfcd34d, roughness: 0.8 });
    const jeansMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.9 });
    const bootsMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
    const vestMat = new THREE.MeshStandardMaterial({ color: data.vestColor, roughness: 0.5 });
    const hatMat = new THREE.MeshStandardMaterial({ color: data.hatColor, roughness: 0.3, metalness: 0.2 });

    // Boots & Legs
    const legGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.75);
    const leftLeg = new THREE.Mesh(legGeo, jeansMat);
    leftLeg.position.set(-0.13, 0.38, 0);
    const rightLeg = new THREE.Mesh(legGeo, jeansMat);
    rightLeg.position.set(0.13, 0.38, 0);

    const bootGeo = new THREE.BoxGeometry(0.13, 0.13, 0.24);
    const leftBoot = new THREE.Mesh(bootGeo, bootsMat);
    leftBoot.position.set(-0.13, 0.07, 0.05);
    const rightBoot = new THREE.Mesh(bootGeo, bootsMat);
    rightBoot.position.set(0.13, 0.07, 0.05);

    group.add(leftLeg, rightLeg, leftBoot, rightBoot);

    // Torso with Hi-Vis Vest
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.54, 0.24), vestMat);
    body.position.set(0, 1.02, 0);
    group.add(body);

    // Head & Hard Hat
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 12), skinMat);
    head.position.set(0, 1.4, 0);

    const hat = new THREE.Mesh(new THREE.ConeGeometry(0.19, 0.15, 12), hatMat);
    hat.position.set(0, 1.5, 0);
    group.add(head, hat);

    // Arms
    const armGeo = new THREE.CylinderGeometry(0.065, 0.065, 0.48);

    const leftArm = new THREE.Group();
    leftArm.position.set(-0.26, 1.22, 0);
    const leftArmMesh = new THREE.Mesh(armGeo, vestMat);
    leftArmMesh.position.set(0, -0.22, 0);
    leftArm.add(leftArmMesh);

    const rightArm = new THREE.Group();
    rightArm.position.set(0.26, 1.22, 0);
    const rightArmMesh = new THREE.Mesh(armGeo, vestMat);
    rightArmMesh.position.set(0, -0.22, 0);
    rightArm.add(rightArmMesh);

    group.add(leftArm, rightArm);

    return {
      group,
      data,
      leftArm,
      rightArm,
      body
    };
  }

  public update(currentStage: ConstructionStage, timeSec: number) {
    this.workers.forEach((w, idx) => {
      const isActive = w.data.activeStages.includes(currentStage);
      w.group.visible = isActive;

      if (isActive) {
        // Natural breathing and hammering / gesturing kinematics
        const offset = idx * 1.2;
        w.leftArm.rotation.x = Math.sin(timeSec * 3.0 + offset) * 0.45;
        w.rightArm.rotation.x = Math.cos(timeSec * 4.0 + offset) * 0.65;
        w.body.position.y = 1.02 + Math.sin(timeSec * 2.0 + offset) * 0.015;
      }
    });
  }
}
