/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate / Luxury Mansion Edition
 * Construction Simulation Engine Types & BIM Schema
 */

export enum ConstructionStage {
  SITE = 'SITE',
  GROUNDWORK = 'GROUNDWORK',
  FOUNDATION = 'FOUNDATION',
  BASEMENT = 'BASEMENT',
  GROUND_FLOOR = 'GROUND_FLOOR',
  STRUCTURE = 'STRUCTURE',
  ROOF = 'ROOF',
  ENVELOPE = 'ENVELOPE',
  STONE_FACADE = 'STONE_FACADE',
  SERVICES = 'SERVICES',
  INTERNAL_FINISH = 'INTERNAL_FINISH',
  EXTERNAL_FINISH = 'EXTERNAL_FINISH',
  LANDSCAPE = 'LANDSCAPE',
  COMPLETE = 'COMPLETE',
  BUILDING_LIFE = 'BUILDING_LIFE'
}

export enum ComponentState {
  NOT_STARTED = 'NOT_STARTED',
  PLANNED = 'PLANNED',
  UNDER_CONSTRUCTION = 'UNDER_CONSTRUCTION',
  INSTALLED = 'INSTALLED',
  INSPECTED = 'INSPECTED',
  COMPLETE = 'COMPLETE'
}

export enum ViewMode {
  CONSTRUCTION = 'CONSTRUCTION',
  CUTAWAY = 'CUTAWAY',
  EXPLODED = 'EXPLODED',
  STRUCTURAL = 'STRUCTURAL',
  SERVICES_MEP = 'SERVICES_MEP',
  ENERGY = 'ENERGY',
  DIGITAL_TWIN = 'DIGITAL_TWIN',
  DIMENSION = 'DIMENSION',
  MASTERPLAN = 'MASTERPLAN',
  MAINTENANCE = 'MAINTENANCE',
  ECONOMIC_ENGINE = 'ECONOMIC_ENGINE'
}

export enum CameraPreset {
  ORBIT = 'ORBIT',
  ESTATE_OVERVIEW = 'ESTATE_OVERVIEW',
  FRONT_PORTICO = 'FRONT_PORTICO',
  REAR_TERRACE = 'REAR_TERRACE',
  GRAND_FOYER = 'GRAND_FOYER',
  CHEF_KITCHEN = 'CHEF_KITCHEN',
  PRIMARY_SUITE = 'PRIMARY_SUITE',
  BASEMENT_CINEMA = 'BASEMENT_CINEMA',
  ROOF_LEVEL = 'ROOF_LEVEL',
  SECTION_CUT = 'SECTION_CUT',
  CINEMATIC_DRONE = 'CINEMATIC_DRONE',
  // Backward compatible presets
  SITE_OVERVIEW = 'ESTATE_OVERVIEW',
  GROUND_LEVEL = 'FRONT_PORTICO',
  INTERIOR_KITCHEN = 'CHEF_KITCHEN',
  INTERIOR_LIVING = 'GRAND_FOYER',
  AERIAL_CRANE = 'ESTATE_OVERVIEW'
}

export enum WeatherType {
  CLEAR_SUNNY = 'CLEAR_SUNNY',
  PARTLY_CLOUDY = 'PARTLY_CLOUDY',
  OVERCAST = 'OVERCAST',
  RAIN = 'RAIN',
  SNOW = 'SNOW'
}

export enum TimeOfDay {
  SUNRISE = 'SUNRISE',
  MORNING = 'MORNING',
  MIDDAY = 'MIDDAY',
  AFTERNOON = 'AFTERNOON',
  GOLDEN_HOUR = 'GOLDEN_HOUR',
  NIGHT = 'NIGHT'
}

export enum TradeType {
  GROUNDWORKER = 'GROUNDWORKER',
  FOUNDATION_CREW = 'FOUNDATION_CREW',
  STEEL_ERECTOR = 'STEEL_ERECTOR',
  FRAMING_CARPENTER = 'FRAMING_CARPENTER',
  STONE_MASON = 'STONE_MASON',
  ROOFER = 'ROOFER',
  WINDOW_GLAZIER = 'WINDOW_GLAZIER',
  ELECTRICIAN = 'ELECTRICIAN',
  PLUMBER = 'PLUMBER',
  HVAC_TECHNICIAN = 'HVAC_TECHNICIAN',
  DRYWALL_PLASTERER = 'DRYWALL_PLASTERER',
  FINISH_CARPENTER = 'FINISH_CARPENTER',
  PAINTER = 'PAINTER',
  ESTATE_LANDSCAPER = 'ESTATE_LANDSCAPER',
  SITE_SUPERINTENDENT = 'SITE_SUPERINTENDENT'
}

export enum MachineType {
  EXCAVATOR = 'EXCAVATOR',
  DUMP_TRUCK = 'DUMP_TRUCK',
  TOWER_CRANE = 'TOWER_CRANE',
  CONCRETE_PUMP = 'CONCRETE_PUMP',
  CONCRETE_MIXER = 'CONCRETE_MIXER',
  TELEHANDLER = 'TELEHANDLER',
  STONE_FLATBED = 'STONE_FLATBED',
  DELIVERY_TRUCK = 'DELIVERY_TRUCK',
  SCAFFOLDING = 'SCAFFOLDING'
}

export type UsRegion = 'NORTHEAST' | 'MID_ATLANTIC' | 'SOUTH' | 'MIDWEST' | 'MOUNTAIN' | 'PACIFIC';

export type ArchitecturalStyle = 'GEORGIAN_ESTATE' | 'COLONIAL_MANOR' | 'MODERN_AMERICAN' | 'TRANSITIONAL_STONE' | 'MOUNTAIN_ESTATE';

export type StoneFacadeType = 'INDIANA_LIMESTONE' | 'BRIAR_HILL_SANDSTONE' | 'VERMONT_GRANITE' | 'ANTIQUE_BRICK_STONE' | 'CAST_STONE_STUCCO';

export type RoofMaterialType = 'ARCHITECTURAL_ASPHALT' | 'SYNTHETIC_SLATE' | 'NATURAL_SLATE' | 'STANDING_SEAM_COPPER';

export type HvacSystemType = 'CONVENTIONAL_VRF' | 'HIGH_EFFICIENCY_HEAT_PUMP' | 'GEOTHERMAL_GROUND_LOOP' | 'VARIABLE_REFRIGERANT_FLOW';

export type LuxuryTier = 'STANDARD_LUXURY' | 'HIGH_LUXURY' | 'ULTRA_LUXURY';

export type UnitSystem = 'IMPERIAL' | 'METRIC';

export type OptimizationGoal = 'VALUE_MAXIMIZATION' | 'SCHEDULE_ACCELERATION' | 'BUDGET_CAP' | 'BALANCED_ESTATE';

export interface BimComponent {
  id: string;
  name: string;
  category: 'Foundation' | 'Basement' | 'Structure' | 'Roof' | 'Envelope' | 'StoneFacade' | 'MEP_Electrical' | 'MEP_Plumbing' | 'MEP_HVAC' | 'Interior' | 'Landscape' | 'Renewable';
  startDay: number;
  endDay: number;
  stage: ConstructionStage;
  material: string;
  dimensions: {
    lengthFt: number;
    widthFt: number;
    heightFt: number;
    areaSqFt?: number;
    volumeCuYd?: number;
  };
  costs: {
    materials: number;
    labour: number;
    plant: number;
    total: number;
  };
  embodiedCarbonKg: number;
  uValue?: number;
  rValue?: number;
  supplier: string;
  warrantyYears: number;
  expectedLifeYears: number;
  maintenanceIntervalMonths: number;
  tradeRequired: TradeType;
  machineRequired?: MachineType;
  position: [number, number, number];
  rotation?: [number, number, number];
  state: ComponentState;
  progress: number;
  meshName?: string;
  layerGroup: 'foundations' | 'basement' | 'structure' | 'floors' | 'roof' | 'envelope' | 'stone' | 'mep' | 'interior' | 'landscape';
}

export interface ScheduleMilestone {
  day: number;
  title: string;
  stage: ConstructionStage;
  description: string;
  costSpentToDateUsd: number;
  materialsDelivered: string[];
  activeMachinery: MachineType[];
  activeTrades: TradeType[];
}

export interface MaterialStock {
  id: string;
  name: string;
  unit: string;
  totalRequired: number;
  ordered: number;
  inTransit: number;
  deliveredToDate: number;
  installedToDate: number;
  wastePercent: number;
  unitCostUsd: number;
  category: string;
}

export interface RoomBuildStatus {
  id: string;
  name: string;
  floor: -1 | 0 | 1;
  sqFt: number;
  structure: number;
  electrical: number;
  plumbing: number;
  hvac: number;
  drywall: number;
  millwork: number;
  flooring: number;
  decoration: number;
  overall: number;
}

export interface EnergyFlowStats {
  solarGenerationKw: number;
  geothermalHeatPumpKw: number;
  batteryStorageKwh: number;
  batteryChargePercent: number;
  gridImportKw: number;
  gridExportKw: number;
  estateLoadKw: number;
  evChargingKw: number;
  backupGeneratorReady: boolean;
  hvacCopEfficiency: number;
}

export interface MasterplanPlot {
  id: number;
  plotNumber: string;
  estateName: string;
  houseType: string;
  currentDay: number;
  stage: ConstructionStage;
  progressPercent: number;
  positionOffset: [number, number, number];
  targetCompletionDays: number;
  budgetSpentUsd: number;
  livingAreaSqFt: number;
}

export interface HouseParameters {
  // Areas & Geometry
  livingAreaSqFt: number;
  widthFt: number;
  depthFt: number;
  widthM?: number;
  lengthM?: number;
  floors: number;
  hasBasement: boolean;
  basementAreaSqFt: number;
  garageBays: number;
  garageAreaSqFt: number;
  siteAreaAcres: number;

  // Architecture & Materials
  architecturalStyle: ArchitecturalStyle;
  stoneFacade: StoneFacadeType;
  claddingMaterial?: string;
  roofMaterial: RoofMaterialType;
  luxuryTier: LuxuryTier;
  usRegion: UsRegion;

  // MEP & Renewables
  hvacType: HvacSystemType;
  hasSolarPv: boolean;
  hasSolarPanels?: boolean;
  hasHeatPump?: boolean;
  hasEVCharger?: boolean;
  hasBatteryStorage: boolean;
  hasBackupGenerator: boolean;
  hasHotWaterRecirc: boolean;
  hasWholeHouseAutomation: boolean;

  // Amenities
  hasEstatePool: boolean;
  hasBasementCinema: boolean;
  hasBasementCinemaWine?: boolean;
  hasWellnessGym: boolean;
  hasWineCellar: boolean;
  hasLibrary: boolean;
  hasPrepKitchen: boolean;
  hasOutdoorKitchen: boolean;
  hasTennisCourt: boolean;

  // Room Counts
  bedroomCount: number;
  bathroomCount: number;

  // Measurement
  unitSystem: UnitSystem;
}

export interface ProjectFinancials {
  // Hard Costs
  hardConstructionCost: number;
  sitePreparationCost: number;
  excavationFoundationCost: number;
  basementConcreteCost: number;
  structuralSteelFramingCost: number;
  roofingAssemblyCost: number;
  exteriorStoneFacadeCost: number;
  windowsDoorsCost: number;
  mepSystemsCost: number;
  drywallInsulationCost: number;
  luxuryFinishesMillworkCost: number;
  estateLandscapePoolCost: number;
  
  // Soft Costs
  softCostsTotal: number;
  architectureEngineeringCost: number;
  permitsInspectionsCost: number;
  projectManagementCost: number;
  interiorDesignCost: number;
  legalSurveyGeotechCost: number;

  // Site Work
  siteCivilUtilityCost: number;
  drivewayRetainingWallsCost: number;

  // Contingency & Land
  contingencyCost: number;
  landAcquisitionCost: number;
  totalProjectBudget: number;
  potentialMarketValue: number;

  // Metrics
  hardCostPerSqFt: number;
  totalCostPerSqFt: number;
  hardCostPerM2: number;
  totalCostPerM2: number;
  marginalCostPerSqFt: number;
  marginalCostPerM2: number;

  // Lifecycle & ESG
  embodiedCarbonTonnes: number;
  estimatedAnnualEnergyCostUsd: number;
  lifetime30YearMaintenanceUsd: number;
  constructionDurationDays: number;
}

export interface MarginalCostPoint {
  areaSqFt: number;
  totalHardCostUsd: number;
  marginalCostPerSqFt: number;
  driverDescription: string;
}

export interface ValueEngineUpgrade {
  id: string;
  name: string;
  category: 'Space' | 'Exterior' | 'Amenities' | 'MEP' | 'Finish';
  costDeltaUsd: number;
  areaDeltaSqFt: number;
  timeDeltaDays: number;
  maintenanceDelta30YrUsd: number;
  energyImpactKwhPerYr: number;
  luxuryScorePoints: number;
  estimatedValueContributionUsd: number;
  valueCostRatio: number;
  verdict: 'HIGH_VALUE' | 'BALANCED' | 'PURE_COMPLEXITY';
  description: string;
}

export interface MaintenanceItem {
  year: number;
  componentId: string;
  componentName: string;
  actionRequired: string;
  estimatedCostUsd: number;
  urgency: 'ROUTINE' | 'RECOMMENDED' | 'CRITICAL';
  status: 'PENDING' | 'SCHEDULED' | 'SERVICED';
}

export interface SimulationState {
  currentDay: number;
  maxDays: number;
  isPlaying: boolean;
  playbackSpeed: number;
  isReverse: boolean;
  viewMode: ViewMode;
  cameraPreset: CameraPreset;
  weather: WeatherType;
  timeOfDay: TimeOfDay;
  weatherDrivenDelay: boolean;
  
  // Cutaway & Exploded
  cutawayHeight: number;
  cutawayWallAlpha: number;
  explodedSeparation: number;
  showStructuralOnly: boolean;
  
  // MEP & Services
  mepElectricalVisible: boolean;
  mepPlumbingVisible: boolean;
  mepHvacVisible: boolean;
  mepDrainageVisible: boolean;
  mepGeothermalVisible?: boolean;
  mepFlowAnimated: boolean;
  
  // Selection
  selectedComponentId: string | null;
  selectedRoomId: string | null;
  
  // Dimension tool
  dimensionModeActive: boolean;
  measuredDistanceFt?: number | null;
  measuredDistanceM?: number | null;
  
  // Parameters
  parameters: HouseParameters;
  
  // Masterplan
  masterplanActive: boolean;
  totalMasterplanPlots: number;
  
  // Whole-life maintenance
  maintenanceYear: number;

  // Modals & Panels
  optimiserOpen?: boolean;
  valueEngineOpen?: boolean;
  handoverOpen?: boolean;
}
