/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Cinematic Construction Camera & Film Director
 */

import React from 'react';
import {
  Camera,
  Clapperboard,
  Compass,
  Film,
  Maximize2,
  Monitor,
  Moon,
  Move3d,
  Play,
  RotateCcw,
  Sparkles,
  Sun,
  Video,
  X
} from 'lucide-react';
import { CameraPreset, SimulationState, TimeOfDay, WeatherType } from '../types/simulation';

interface CinematicDirectorProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  onSetCameraPreset: (preset: CameraPreset) => void;
  onStartCinematicFilm: (durationSec: number) => void;
  onClose: () => void;
}

export const CinematicDirector: React.FC<CinematicDirectorProps> = ({
  simState,
  onUpdateSimState,
  onSetCameraPreset,
  onStartCinematicFilm,
  onClose
}) => {
  const cameraAngles = [
    { key: CameraPreset.ESTATE_OVERVIEW, label: '360° Estate Overview', desc: 'High orbital view of mansion, grounds & motor court' },
    { key: CameraPreset.FRONT_PORTICO, label: 'Front Entrance Portico', desc: 'Limestone Tuscan columns and grand steps' },
    { key: CameraPreset.REAR_TERRACE, label: 'Rear Stone Loggia & Pool', desc: '45ft gunite heated pool and stone balustrade' },
    { key: CameraPreset.GRAND_FOYER, label: 'Double-Height Grand Foyer', desc: 'Imperial curved staircase and crystal chandelier' },
    { key: CameraPreset.CHEF_KITCHEN, label: 'Chef Kitchen & Marble Island', desc: '14ft marble waterfall island and custom millwork' },
    { key: CameraPreset.BASEMENT_CINEMA, label: 'Basement Cinema & Wine Cellar', desc: '10ft deep concrete lower level with Dolby Atmos suite' },
    { key: CameraPreset.PRIMARY_SUITE, label: 'Primary Suite & Dressing Room', desc: 'Upper west wing master sanctuary' },
    { key: CameraPreset.ROOF_LEVEL, label: 'DaVinci Slate & Dormers', desc: '5 classical pedimented dormers & stone chimneys' },
    { key: CameraPreset.CINEMATIC_DRONE, label: 'Autonomous Orbit Drone', desc: 'Smooth continuous rotational cinematics' },
    { key: CameraPreset.SECTION_CUT, label: 'Architectural Section Cut', desc: 'True orthogonal cross-section elevation' }
  ];

  return (
    <div className="absolute top-16 right-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.85)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-right-6 duration-200 font-mono">
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Clapperboard className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Cinematic Camera Director
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Automated Time-Lapse Film Builder */}
        <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
              <Film className="w-4 h-4 text-[#ff7b00]" />
              490-Day Estate Time-Lapse Reel
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#ff7b00]/20 text-[#ff7b00] border border-[#ff7b00]/40 uppercase tracking-wider">
              CINEMATIC
            </span>
          </div>
          <p className="text-slate-400 text-[10px] font-sans">
            Automated drone camera sequence transitioning from Empty Site Day 0 through Indiana Limestone assembly to Finished Estate Handover.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => onStartCinematicFilm(30)}
              className="py-2 px-3 rounded-xl bg-[#ff7b00] hover:bg-[#ff8f24] text-black font-bold flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(255,123,0,0.4)] transition-all uppercase tracking-wider text-[11px]"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>30s Reel</span>
            </button>
            <button
              onClick={() => onStartCinematicFilm(60)}
              className="py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold flex items-center justify-center gap-1.5 border border-white/10 transition-all uppercase tracking-wider text-[11px]"
            >
              <Play className="w-3.5 h-3.5 fill-current text-[#00f2ff]" />
              <span>60s 4K Reel</span>
            </button>
          </div>
        </div>

        {/* Camera Angles Selection */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Camera className="w-3.5 h-3.5 text-[#00f2ff]" />
            Estate Camera POVs & Presets
          </span>

          <div className="space-y-1.5 font-sans">
            {cameraAngles.map((cam) => {
              const isSelected = simState.cameraPreset === cam.key;
              return (
                <button
                  key={cam.key}
                  onClick={() => onSetCameraPreset(cam.key)}
                  className={`w-full p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-[#00f2ff]/15 border-[#00f2ff] ring-1 ring-[#00f2ff]/40 text-white'
                      : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="font-bold text-xs text-white">{cam.label}</div>
                    <div className="text-[10px] text-slate-400">{cam.desc}</div>
                  </div>
                  {isSelected && (
                    <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#00f2ff] text-black font-bold">
                      ACTIVE
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
