/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Parametric House & Material Variant Engine
 */

import React from 'react';
import {
  Building,
  Check,
  Cpu,
  Flame,
  Layers,
  MapPin,
  Palette,
  RotateCcw,
  Ruler,
  Shield,
  Sliders,
  Sparkles,
  Sun,
  Waves,
  Wine,
  X,
  Zap
} from 'lucide-react';
import {
  HouseParameters,
  StoneFacadeType,
  RoofMaterialType,
  HvacSystemType,
  UsRegion
} from '../types/simulation';
import {
  DEFAULT_PARAMETERS,
  REGIONAL_MULTIPLIERS,
  STONE_FACADE_PROPERTIES,
  ROOF_MATERIAL_PROPERTIES
} from '../engine/simulationModel';

interface ParametricConfiguratorProps {
  parameters: HouseParameters;
  onUpdateParameters: (newParams: HouseParameters) => void;
  onClose: () => void;
}

export const ParametricConfigurator: React.FC<ParametricConfiguratorProps> = ({
  parameters,
  onUpdateParameters,
  onClose
}) => {
  const isImperial = parameters.unitSystem === 'IMPERIAL';

  return (
    <div className="absolute top-16 left-4 w-96 max-w-[calc(100vw-2rem)] bg-[#0f1218]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.85)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#ff7b00]" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Estate Parametric Engine
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Footprint Dimensions & Scale */}
        <div className="space-y-3 bg-black/40 p-3 rounded-xl border border-white/10">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
              <Ruler className="w-3.5 h-3.5 text-[#00f2ff]" />
              Living Area & Footprint
            </span>
            <span className="text-[10px] text-[#ff7b00] font-bold">
              {parameters.livingAreaSqFt.toLocaleString()} sq ft ({Math.round(parameters.livingAreaSqFt * 0.092903)} m²)
            </span>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-slate-300 text-[11px]">
              <span>Conditioned Floor Area:</span>
              <span className="font-mono text-[#00f2ff] font-bold">{parameters.livingAreaSqFt} sq ft</span>
            </div>
            <input
              type="range"
              min={4500}
              max={10000}
              step={250}
              value={parameters.livingAreaSqFt}
              onChange={(e) => {
                const area = Number(e.target.value);
                const ratio = Math.sqrt(area / 6000);
                onUpdateParameters({
                  ...parameters,
                  livingAreaSqFt: area,
                  widthFt: Math.round(74 * ratio),
                  depthFt: Math.round(44 * ratio),
                  widthM: Math.round(74 * ratio * 0.3048 * 10) / 10,
                  lengthM: Math.round(44 * ratio * 0.3048 * 10) / 10
                });
              }}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#00f2ff]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400">Frontage Width:</span>
              <div className="font-mono font-bold text-white text-xs">{parameters.widthFt} ft ({parameters.widthM}m)</div>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400">Estate Depth:</span>
              <div className="font-mono font-bold text-white text-xs">{parameters.depthFt} ft ({parameters.lengthM}m)</div>
            </div>
          </div>
        </div>

        {/* Natural Stone Facade Selector */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Building className="w-3.5 h-3.5 text-[#ff7b00]" />
            Natural Stone Facade Cladding
          </span>

          <div className="space-y-1.5">
            {Object.entries(STONE_FACADE_PROPERTIES).map(([key, stone]) => {
              const isSelected = parameters.stoneFacade === key;
              return (
                <button
                  key={key}
                  onClick={() => onUpdateParameters({ ...parameters, stoneFacade: key as StoneFacadeType })}
                  className={`w-full flex items-center justify-between p-2 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-[#ff7b00]/15 border-[#ff7b00] ring-1 ring-[#ff7b00]/40 text-white'
                      : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-amber-400/80" />
                    <div>
                      <div className="font-bold text-xs">{stone.name}</div>
                      <div className="text-[10px] text-slate-400">${stone.costPerSqFt}/sq ft envelope</div>
                    </div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-[#ff7b00]" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Roof Material Selector */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Layers className="w-3.5 h-3.5 text-purple-400" />
            Roofing System
          </span>

          <div className="space-y-1.5">
            {Object.entries(ROOF_MATERIAL_PROPERTIES).map(([key, roof]) => {
              const isSelected = parameters.roofMaterial === key;
              return (
                <button
                  key={key}
                  onClick={() => onUpdateParameters({ ...parameters, roofMaterial: key as RoofMaterialType })}
                  className={`w-full flex items-center justify-between p-2 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-purple-500/15 border-purple-500 ring-1 ring-purple-500/40 text-white'
                      : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="font-bold text-xs">{roof.name}</div>
                    <div className="text-[10px] text-slate-400">{roof.lifespanYears}-Yr Warranty • ${roof.costPerSqFt}/sf</div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-purple-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* HVAC & Energy System */}
        <div className="space-y-2">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            HVAC & Thermal Plant
          </span>

          <div className="grid grid-cols-1 gap-1.5">
            <button
              onClick={() => onUpdateParameters({ ...parameters, hvacType: 'GEOTHERMAL_GROUND_LOOP' })}
              className={`p-2 rounded-xl border text-left flex items-center justify-between ${
                parameters.hvacType === 'GEOTHERMAL_GROUND_LOOP'
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <div>
                <div className="font-bold text-xs">Closed-Loop Geothermal (COP 4.8)</div>
                <div className="text-[10px] text-slate-400">Deep Boreholes + Hydronic Underfloor Heating</div>
              </div>
              {parameters.hvacType === 'GEOTHERMAL_GROUND_LOOP' && <Check className="w-4 h-4 text-emerald-400" />}
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, hvacType: 'VARIABLE_REFRIGERANT_FLOW' })}
              className={`p-2 rounded-xl border text-left flex items-center justify-between ${
                parameters.hvacType === 'VARIABLE_REFRIGERANT_FLOW'
                  ? 'bg-[#00f2ff]/20 border-[#00f2ff] text-[#00f2ff]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <div>
                <div className="font-bold text-xs">Multi-Zone VRF Heat Pump</div>
                <div className="text-[10px] text-slate-400">High-SEER2 Electric Air Inverters</div>
              </div>
              {parameters.hvacType === 'VARIABLE_REFRIGERANT_FLOW' && <Check className="w-4 h-4 text-[#00f2ff]" />}
            </button>
          </div>
        </div>

        {/* Luxury Amenities Toggles */}
        <div className="space-y-2 pt-2 border-t border-white/10">
          <span className="font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 text-[10px]">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Estate Amenities & Features
          </span>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onUpdateParameters({ ...parameters, hasEstatePool: !parameters.hasEstatePool })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasEstatePool
                  ? 'bg-[#00f2ff]/20 border-[#00f2ff]/50 text-[#00f2ff]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <Waves className="w-3.5 h-3.5 mb-1" />
              <div className="font-bold text-xs">45ft Gunite Pool</div>
              <div className="text-[9px] text-slate-400">Heated + Spa</div>
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, hasBasementCinemaWine: !parameters.hasBasementCinemaWine })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasBasementCinemaWine
                  ? 'bg-purple-500/20 border-purple-500/50 text-purple-300'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <Wine className="w-3.5 h-3.5 mb-1" />
              <div className="font-bold text-xs">Cinema & Wine Cellar</div>
              <div className="text-[9px] text-slate-400">Dolby 12-Seat</div>
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, garageBays: parameters.garageBays === 4 ? 3 : 4 })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.garageBays === 4
                  ? 'bg-[#ff7b00]/20 border-[#ff7b00]/50 text-[#ff7b00]'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <Shield className="w-3.5 h-3.5 mb-1" />
              <div className="font-bold text-xs">{parameters.garageBays}-Car Garage</div>
              <div className="text-[9px] text-slate-400">Carriage Doors</div>
            </button>

            <button
              onClick={() => onUpdateParameters({ ...parameters, hasBackupGenerator: !parameters.hasBackupGenerator })}
              className={`p-2 rounded-xl border text-left transition-all ${
                parameters.hasBackupGenerator
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                  : 'bg-black/30 border-white/5 text-slate-400'
              }`}
            >
              <Zap className="w-3.5 h-3.5 mb-1" />
              <div className="font-bold text-xs">48kW Generator</div>
              <div className="text-[9px] text-slate-400">Kohler Auto Transfer</div>
            </button>
          </div>
        </div>

        {/* Reset to Baseline Button */}
        <button
          onClick={() => onUpdateParameters(DEFAULT_PARAMETERS)}
          className="w-full flex items-center justify-center gap-1.5 p-2 rounded-xl bg-black/40 border border-white/10 hover:bg-white/10 text-slate-400 hover:text-white transition-colors text-xs"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset to 6,000 sq ft Stone Estate Baseline
        </button>
      </div>
    </div>
  );
};
