/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Economic Goal-Based Parameter Optimiser Modal
 */

import React, { useState } from 'react';
import {
  Check,
  ChevronRight,
  DollarSign,
  Maximize2,
  Minimize2,
  Percent,
  RotateCcw,
  Scale,
  ShieldCheck,
  Sliders,
  Sparkles,
  TrendingUp,
  X,
  Zap
} from 'lucide-react';
import {
  HouseParameters,
  ProjectFinancials
} from '../types/simulation';
import {
  calculateProjectFinancials,
  OPTIMIZE_ESTATE_CONFIGURATION
} from '../engine/simulationModel';

export type OptimiserGoalType = 'MAX_LUXURY' | 'MAX_AREA' | 'MIN_COST' | 'MAX_ROI';

interface EconomicOptimiserModalProps {
  currentParameters: HouseParameters;
  onApplyPlan: (newParams: HouseParameters) => void;
  onClose: () => void;
}

export const EconomicOptimiserModal: React.FC<EconomicOptimiserModalProps> = ({
  currentParameters,
  onApplyPlan,
  onClose
}) => {
  const currentFinancials = calculateProjectFinancials(currentParameters);
  const [selectedGoal, setSelectedGoal] = useState<OptimiserGoalType>('MAX_LUXURY');
  const [targetBudget, setTargetBudget] = useState<number>(Math.round(currentFinancials.hardConstructionCost));

  // Compute optimized config
  const optimizedParams = OPTIMIZE_ESTATE_CONFIGURATION(selectedGoal, targetBudget, currentParameters);
  const optimizedFinancials = calculateProjectFinancials(optimizedParams);

  const formatCurrency = (v: number) => `$${Math.round(v).toLocaleString()}`;
  const costDelta = optimizedFinancials.hardConstructionCost - currentFinancials.hardConstructionCost;

  const goalDescriptions: { id: OptimiserGoalType; title: string; subtitle: string; icon: React.ReactNode }[] = [
    {
      id: 'MAX_LUXURY',
      title: 'Maximise Perceived Luxury',
      subtitle: 'Locks in Indiana Limestone, DaVinci Slate, Geothermal HVAC & Gunite Pool within target budget.',
      icon: <Sparkles className="w-4 h-4 text-[#ff7b00]" />
    },
    {
      id: 'MAX_AREA',
      title: 'Maximise Floor Area (Sq Ft)',
      subtitle: 'Optimises materials to achieve the maximum possible interior square footage (up to 8,500+ sf).',
      icon: <Maximize2 className="w-4 h-4 text-[#00f2ff]" />
    },
    {
      id: 'MIN_COST',
      title: 'Minimise Cost & Retain Aesthetic',
      subtitle: 'Swaps to Cast Stone & Architectural Slate to trim costs while preserving the classical estate silhouette.',
      icon: <Scale className="w-4 h-4 text-emerald-400" />
    },
    {
      id: 'MAX_ROI',
      title: 'Maximise Equity & Appraisal Multiple',
      subtitle: 'Calculates the optimal trade-off between capex and estimated market valuation.',
      icon: <TrendingUp className="w-4 h-4 text-purple-400" />
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl w-[640px] max-w-full text-slate-100 shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden animate-in fade-in zoom-in-95 duration-200 font-mono">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-black/60 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#ff7b00] to-amber-600 flex items-center justify-center text-black font-bold shadow-md shadow-[#ff7b00]/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Economic Parameter Solver
              </h2>
              <p className="text-[11px] text-slate-400">
                Multi-Variable Goal & Budget Constraint Optimiser
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 text-xs">
          {/* Step 1: Select Optimization Goal */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              1. Select Primary Development Objective
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {goalDescriptions.map((g) => {
                const isSelected = selectedGoal === g.id;
                return (
                  <button
                    key={g.id}
                    onClick={() => setSelectedGoal(g.id)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-[#ff7b00]/15 border-[#ff7b00] ring-1 ring-[#ff7b00]/40 text-white shadow-[0_0_15px_rgba(255,123,0,0.2)]'
                        : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {g.icon}
                      <span className="font-bold text-xs">{g.title}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                      {g.subtitle}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Target Hard Cost Constraint Slider */}
          <div className="space-y-2 bg-black/40 p-4 rounded-xl border border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                2. Target Hard Construction Budget Cap
              </span>
              <span className="font-mono text-sm font-bold text-[#ff7b00]">
                {formatCurrency(targetBudget)}
              </span>
            </div>
            <input
              type="range"
              min={2500000}
              max={6500000}
              step={50000}
              value={targetBudget}
              onChange={(e) => setTargetBudget(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#ff7b00]"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>$2.50M (Value Target)</span>
              <span>$4.50M (Baseline)</span>
              <span>$6.50M (Ultra Estate)</span>
            </div>
          </div>

          {/* Step 3: Optimization Solution Matrix */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              3. Proposed Parameter Configuration & Trade-Offs
            </span>
            <div className="grid grid-cols-2 gap-3 bg-black/30 p-3.5 rounded-xl border border-white/5">
              <div className="space-y-1.5">
                <div className="text-slate-400 text-[11px]">Proposed Floor Area:</div>
                <div className="text-white font-bold text-xs flex items-center gap-1.5">
                  <span>{optimizedParams.livingAreaSqFt.toLocaleString()} sq ft</span>
                  <span className="text-[10px] text-slate-400">
                    ({optimizedParams.livingAreaSqFt >= currentParameters.livingAreaSqFt ? `+${optimizedParams.livingAreaSqFt - currentParameters.livingAreaSqFt}` : `${optimizedParams.livingAreaSqFt - currentParameters.livingAreaSqFt}`} sf)
                  </span>
                </div>

                <div className="text-slate-400 text-[11px] pt-1">Stone Facade Envelope:</div>
                <div className="text-white font-bold text-xs">
                  {optimizedParams.stoneFacade.replace('_', ' ')}
                </div>

                <div className="text-slate-400 text-[11px] pt-1">Roofing System:</div>
                <div className="text-white font-bold text-xs">
                  {optimizedParams.roofMaterial.replace('_', ' ')}
                </div>
              </div>

              <div className="space-y-1.5 border-l border-white/10 pl-3">
                <div className="text-slate-400 text-[11px]">Predicted Hard Cost:</div>
                <div className="text-[#ff7b00] font-bold text-xs">
                  {formatCurrency(optimizedFinancials.hardConstructionCost)} (${optimizedFinancials.hardCostPerSqFt}/sf)
                </div>

                <div className="text-slate-400 text-[11px] pt-1">Projected Total Capex:</div>
                <div className="text-[#00f2ff] font-bold text-xs">
                  {formatCurrency(optimizedFinancials.totalProjectBudget)}
                </div>

                <div className="text-slate-400 text-[11px] pt-1">Potential Appraisal:</div>
                <div className="text-purple-300 font-bold text-xs">
                  {formatCurrency(optimizedFinancials.potentialMarketValue)}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 bg-black/60 border-t border-white/10">
          <div className="text-[11px] text-slate-400">
            Cost Variance: <span className={costDelta >= 0 ? 'text-[#ff7b00] font-bold' : 'text-emerald-400 font-bold'}>
              {costDelta >= 0 ? `+${formatCurrency(costDelta)}` : formatCurrency(costDelta)}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => onApplyPlan(optimizedParams)}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-[#ff7b00] to-amber-600 text-black font-bold text-xs shadow-lg shadow-[#ff7b00]/30 hover:brightness-110 transition-all"
            >
              <Check className="w-4 h-4" />
              Apply Optimized Estate Parameters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
