/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Economic Engine & Marginal Cost Computation Panel
 */

import React, { useState } from 'react';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Building,
  CheckCircle2,
  ChevronRight,
  Coins,
  DollarSign,
  Globe,
  Info,
  Layers,
  MapPin,
  PieChart,
  Ruler,
  Scale,
  Sparkles,
  TrendingDown,
  TrendingUp,
  X,
  Zap
} from 'lucide-react';
import {
  HouseParameters,
  ProjectFinancials,
  UsRegion,
  UnitSystem
} from '../types/simulation';
import {
  calculateMarginalCostCurve,
  calculateProjectFinancials,
  calculateStoneUpgradeCost,
  REGIONAL_MULTIPLIERS,
  STONE_FACADE_PROPERTIES
} from '../engine/simulationModel';

interface EconomicEnginePanelProps {
  parameters: HouseParameters;
  financials: ProjectFinancials;
  onUpdateParameters: (newParams: HouseParameters) => void;
  onOpenOptimiser: () => void;
  onOpenValueEngine: () => void;
  onClose: () => void;
}

export const EconomicEnginePanel: React.FC<EconomicEnginePanelProps> = ({
  parameters,
  financials,
  onUpdateParameters,
  onOpenOptimiser,
  onOpenValueEngine,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'MARGINAL_CURVE' | 'STONE_ANALYSIS' | 'SOFT_SITE_SPLIT'>('OVERVIEW');
  const [hoveredPointIdx, setHoveredPointIdx] = useState<number | null>(null);

  const marginalCurve = calculateMarginalCostCurve(parameters);
  const stoneComparison = calculateStoneUpgradeCost(parameters);

  const formatCurrency = (val: number) => `$${val.toLocaleString()}`;
  const isImperial = parameters.unitSystem === 'IMPERIAL';

  return (
    <div className="absolute top-16 left-4 w-[540px] max-w-[calc(100vw-2rem)] bg-[#0f1218]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.85)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-6 duration-200 font-mono">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-[#ff7b00]/15 border border-[#ff7b00]/40 text-[#ff7b00] shadow-[0_0_10px_rgba(255,123,0,0.3)]">
            <Coins className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
              Economic Engine & Marginal Cost Model
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                TC(Q) = F + V(Q)
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              Northeast Luxury Estate Baseline • True Hard/Soft/Site Decomposition
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1 px-4 pt-2 border-b border-white/10 bg-black/40 text-[11px]">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`px-3 py-1.5 border-b-2 font-semibold transition-colors ${
            activeTab === 'OVERVIEW'
              ? 'border-[#ff7b00] text-[#ff7b00]'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Budget Matrix
        </button>
        <button
          onClick={() => setActiveTab('MARGINAL_CURVE')}
          className={`px-3 py-1.5 border-b-2 font-semibold transition-colors ${
            activeTab === 'MARGINAL_CURVE'
              ? 'border-[#00f2ff] text-[#00f2ff]'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Marginal Curve MC(Q)
        </button>
        <button
          onClick={() => setActiveTab('STONE_ANALYSIS')}
          className={`px-3 py-1.5 border-b-2 font-semibold transition-colors ${
            activeTab === 'STONE_ANALYSIS'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Stone Delta
        </button>
        <button
          onClick={() => setActiveTab('SOFT_SITE_SPLIT')}
          className={`px-3 py-1.5 border-b-2 font-semibold transition-colors ${
            activeTab === 'SOFT_SITE_SPLIT'
              ? 'border-purple-400 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Soft/Site/Contingency
        </button>
      </div>

      {/* Main Content Area */}
      <div className="p-4 space-y-4 max-h-[72vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Top Key Metrics Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-black/40 p-3 rounded-xl border border-white/10">
          <div>
            <div className="text-[10px] uppercase text-slate-400">Total Project</div>
            <div className="text-sm font-bold text-[#00f2ff] drop-shadow-[0_0_8px_rgba(0,242,255,0.3)]">
              {formatCurrency(financials.totalProjectBudget)}
            </div>
            <div className="text-[9px] text-slate-500">${financials.totalCostPerSqFt}/sq ft (${financials.totalCostPerM2}/m²)</div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-slate-400">Hard Construction</div>
            <div className="text-sm font-bold text-[#ff7b00]">
              {formatCurrency(financials.hardConstructionCost)}
            </div>
            <div className="text-[9px] text-slate-500">${financials.hardCostPerSqFt}/sq ft (${financials.hardCostPerM2}/m²)</div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-slate-400">Marginal Rate MC</div>
            <div className="text-sm font-bold text-emerald-400 flex items-center gap-1">
              ${financials.marginalCostPerSqFt}/sf
              <ArrowDownRight className="w-3.5 h-3.5" />
            </div>
            <div className="text-[9px] text-slate-500">ΔCost for +1 sq ft</div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-slate-400">Market Appraisal</div>
            <div className="text-sm font-bold text-purple-300">
              {formatCurrency(financials.potentialMarketValue)}
            </div>
            <div className="text-[9px] text-slate-500">1.32x Dev Value</div>
          </div>
        </div>

        {/* Region & Unit System Switchers */}
        <div className="flex items-center justify-between gap-3 bg-black/30 p-2.5 rounded-xl border border-white/5 flex-wrap">
          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-[#ff7b00]" />
            <span className="text-[10px] text-slate-400 uppercase">US Region:</span>
            <select
              value={parameters.usRegion}
              onChange={(e) => onUpdateParameters({ ...parameters, usRegion: e.target.value as UsRegion })}
              className="bg-slate-900 border border-white/10 text-white text-[11px] rounded-lg px-2 py-1 focus:outline-none focus:border-[#ff7b00]"
            >
              {Object.entries(REGIONAL_MULTIPLIERS).map(([key, info]) => (
                <option key={key} value={key}>
                  {info.name} ({info.multiplier}x)
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onUpdateParameters({ ...parameters, unitSystem: 'IMPERIAL' })}
              className={`px-2 py-0.5 rounded text-[10px] ${
                parameters.unitSystem === 'IMPERIAL'
                  ? 'bg-[#ff7b00] text-black font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sq Ft / Ft
            </button>
            <button
              onClick={() => onUpdateParameters({ ...parameters, unitSystem: 'METRIC' })}
              className={`px-2 py-0.5 rounded text-[10px] ${
                parameters.unitSystem === 'METRIC'
                  ? 'bg-[#00f2ff] text-black font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              m² / Meters
            </button>
          </div>
        </div>

        {/* TAB 1: OVERVIEW & COMPONENT TABLE */}
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-3">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Hard Construction Assemblies Breakdown</span>
              <span className="text-[#ff7b00]">{parameters.livingAreaSqFt.toLocaleString()} sq ft</span>
            </div>

            <div className="space-y-1.5 bg-black/30 p-2 rounded-xl border border-white/5">
              {[
                { name: 'Excavation, Sump & Concrete Footings', cost: financials.excavationFoundationCost, pct: Math.round((financials.excavationFoundationCost / financials.hardConstructionCost) * 100) },
                { name: '10ft Basement Walls & Waterproofing', cost: financials.basementConcreteCost, pct: Math.round((financials.basementConcreteCost / financials.hardConstructionCost) * 100) },
                { name: 'Structural Steel Girders & LVL Joists', cost: financials.structuralSteelFramingCost, pct: Math.round((financials.structuralSteelFramingCost / financials.hardConstructionCost) * 100) },
                { name: 'Superstructure Trusses & Slate Roof', cost: financials.roofingAssemblyCost, pct: Math.round((financials.roofingAssemblyCost / financials.hardConstructionCost) * 100) },
                { name: `Exterior Natural Stone Facade (${parameters.stoneFacade.replace('_', ' ')})`, cost: financials.exteriorStoneFacadeCost, pct: Math.round((financials.exteriorStoneFacadeCost / financials.hardConstructionCost) * 100), highlight: true },
                { name: 'Marvin Triple Glazed Windows & French Doors', cost: financials.windowsDoorsCost, pct: Math.round((financials.windowsDoorsCost / financials.hardConstructionCost) * 100) },
                { name: 'Multi-Zone Geothermal HVAC & 400A MEP', cost: financials.mepSystemsCost, pct: Math.round((financials.mepSystemsCost / financials.hardConstructionCost) * 100) },
                { name: 'Level 5 Drywall & Acoustic Isolation', cost: financials.drywallInsulationCost, pct: Math.round((financials.drywallInsulationCost / financials.hardConstructionCost) * 100) },
                { name: 'Imperial Stair, Chef Kitchen & Marble Baths', cost: financials.luxuryFinishesMillworkCost, pct: Math.round((financials.luxuryFinishesMillworkCost / financials.hardConstructionCost) * 100) },
                { name: 'Cobblestone Court & 45ft Gunite Pool', cost: financials.estateLandscapePoolCost, pct: Math.round((financials.estateLandscapePoolCost / financials.hardConstructionCost) * 100) }
              ].map((item, idx) => (
                <div key={idx} className={`flex items-center justify-between p-1.5 rounded-lg text-[11px] ${item.highlight ? 'bg-[#ff7b00]/10 border border-[#ff7b00]/30' : 'hover:bg-white/5'}`}>
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#00f2ff]" />
                    <span className="truncate text-slate-200">{item.name}</span>
                  </div>
                  <div className="flex items-center gap-3 text-right font-mono flex-shrink-0">
                    <span className="text-slate-400 text-[10px]">{item.pct}%</span>
                    <span className={`font-bold ${item.highlight ? 'text-[#ff7b00]' : 'text-white'}`}>
                      {formatCurrency(item.cost)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick action buttons */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={onOpenOptimiser}
                className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-gradient-to-r from-[#ff7b00] to-amber-600 text-black font-bold text-xs shadow-lg shadow-[#ff7b00]/25 hover:brightness-110 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Launch Economic Optimiser
              </button>
              <button
                onClick={onOpenValueEngine}
                className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-800 border border-white/10 hover:border-[#00f2ff]/50 text-[#00f2ff] font-bold text-xs transition-all"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                Marginal Value Engine
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: MARGINAL COST CURVE GRAPH */}
        {activeTab === 'MARGINAL_CURVE' && (
          <div className="space-y-3">
            <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-[#00f2ff]">Marginal Cost Curve: MC(Q) = ΔTC / ΔQ</span>
                <span className="text-slate-400 text-[10px]">Scale: 4,000 to 12,000 sq ft</span>
              </div>
              <p className="text-[10px] text-slate-400 leading-relaxed font-sans">
                Notice economies of scale up to ~6,000 sq ft where site mobilization is amortized. Above 7,500 sq ft, diseconomies of scale emerge due to commercial VRF, larger structural steel clear spans, and custom masonry volume.
              </p>

              {/* Interactive SVG Chart */}
              <div className="relative w-full h-44 bg-slate-950/80 rounded-lg p-2 border border-white/5 flex flex-col justify-between">
                <svg className="w-full h-32 overflow-visible">
                  {/* Grid Lines */}
                  <line x1="0" y1="20" x2="100%" y2="20" stroke="#334155" strokeDasharray="3 3" strokeWidth="0.5" />
                  <line x1="0" y1="60" x2="100%" y2="60" stroke="#334155" strokeDasharray="3 3" strokeWidth="0.5" />
                  <line x1="0" y1="100" x2="100%" y2="100" stroke="#334155" strokeDasharray="3 3" strokeWidth="0.5" />

                  {/* Curve Path */}
                  <polyline
                    fill="none"
                    stroke="#00f2ff"
                    strokeWidth="2.5"
                    points={marginalCurve.map((pt, i) => {
                      const x = (i / (marginalCurve.length - 1)) * 440 + 20;
                      // map MC $400 to $900 -> y from 110 to 15
                      const y = 120 - ((pt.marginalCostPerSqFt - 400) / 500) * 105;
                      return `${x},${y}`;
                    }).join(' ')}
                  />

                  {/* Data Points */}
                  {marginalCurve.map((pt, i) => {
                    const x = (i / (marginalCurve.length - 1)) * 440 + 20;
                    const y = 120 - ((pt.marginalCostPerSqFt - 400) / 500) * 105;
                    const isSelected = pt.areaSqFt === parameters.livingAreaSqFt || hoveredPointIdx === i;

                    return (
                      <g key={i} onMouseEnter={() => setHoveredPointIdx(i)} onMouseLeave={() => setHoveredPointIdx(null)} className="cursor-pointer">
                        <circle
                          cx={x}
                          cy={y}
                          r={isSelected ? 6 : 4}
                          fill={isSelected ? '#ff7b00' : '#00f2ff'}
                          stroke="#ffffff"
                          strokeWidth="1.5"
                        />
                      </g>
                    );
                  })}
                </svg>

                {/* X Axis labels */}
                <div className="flex justify-between text-[9px] text-slate-500 px-2 font-mono">
                  <span>4k sf</span>
                  <span>6k sf (Baseline)</span>
                  <span>8k sf</span>
                  <span>10k sf</span>
                  <span>12k sf</span>
                </div>
              </div>

              {/* Hovered or Selected Point Detail */}
              {hoveredPointIdx !== null && (
                <div className="bg-slate-900 p-2 rounded-lg border border-[#00f2ff]/40 text-[10px] space-y-1">
                  <div className="flex justify-between font-bold">
                    <span className="text-[#00f2ff]">{marginalCurve[hoveredPointIdx].areaSqFt.toLocaleString()} sq ft</span>
                    <span className="text-[#ff7b00]">MC: ${marginalCurve[hoveredPointIdx].marginalCostPerSqFt}/sq ft</span>
                  </div>
                  <div className="text-slate-300">Total Hard Cost: {formatCurrency(marginalCurve[hoveredPointIdx].totalHardCostUsd)}</div>
                  <div className="text-slate-400 italic font-sans">{marginalCurve[hoveredPointIdx].driverDescription}</div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: STONE FACADE DELTA */}
        {activeTab === 'STONE_ANALYSIS' && (
          <div className="space-y-3">
            <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5" />
                Natural Stone Facade Marginal Economics
              </span>
              <p className="text-[10px] text-slate-400 font-sans">
                Compare exterior cladding materials on the ~6,200 sq ft wall envelope. Stone adds weight, structural reinforcement, and masonry labour, but significantly enhances lifetime durability and appraised value.
              </p>

              <div className="space-y-2 pt-1">
                {Object.entries(STONE_FACADE_PROPERTIES).map(([key, stone]) => {
                  const isCurrent = parameters.stoneFacade === key;
                  const totalFacadeCost = Math.round(stone.costPerSqFt * 6200 * (parameters.livingAreaSqFt / 6000));

                  return (
                    <button
                      key={key}
                      onClick={() => onUpdateParameters({ ...parameters, stoneFacade: key as any })}
                      className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                        isCurrent
                          ? 'bg-[#ff7b00]/15 border-[#ff7b00]/60 ring-1 ring-[#ff7b00]/40 text-white'
                          : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs flex items-center gap-2">
                          {stone.name}
                          {isCurrent && <span className="text-[9px] bg-[#ff7b00] text-black px-1.5 py-0.2 rounded font-bold">ACTIVE</span>}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ${stone.costPerSqFt}/sq ft wall • {stone.weightLbsPerSqFt} lbs/sf • {stone.embodiedCarbonKgPerSqFt} kgCO₂/sf
                        </div>
                      </div>
                      <div className="text-right font-mono font-bold text-xs text-[#00f2ff]">
                        {formatCurrency(totalFacadeCost)}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-[10px] text-amber-200">
                Delta vs Standard Brick: <span className="font-bold font-mono text-white">+{formatCurrency(stoneComparison.deltaCostUsd)} (+{stoneComparison.deltaPercent}%)</span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SOFT COSTS, SITE WORK & CONTINGENCY SPLIT */}
        {activeTab === 'SOFT_SITE_SPLIT' && (
          <div className="space-y-3">
            <div className="bg-black/40 p-3 rounded-xl border border-white/10 space-y-2">
              <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">
                Non-Construction Capital Expenditure
              </span>
              <p className="text-[10px] text-slate-400 font-sans">
                Professional architectural fees, town zoning permits, geotech testing, site utility trenching, driveway civil works, and 10% contingency buffer.
              </p>

              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between p-1.5 bg-black/20 rounded border border-white/5 text-[11px]">
                  <span className="text-slate-300">Architectural & Structural Engineering (7.5%)</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(financials.architectureEngineeringCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-black/20 rounded border border-white/5 text-[11px]">
                  <span className="text-slate-300">Permitting, Zoning & Town Inspections</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(financials.permitsInspectionsCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-black/20 rounded border border-white/5 text-[11px]">
                  <span className="text-slate-300">Construction Project Management (4.5%)</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(financials.projectManagementCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-black/20 rounded border border-white/5 text-[11px]">
                  <span className="text-slate-300">Interior Design & Millwork Detailing</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(financials.interiorDesignCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-black/20 rounded border border-white/5 text-[11px]">
                  <span className="text-slate-300">Site Utilities & Transformer Vault</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(financials.siteCivilUtilityCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-black/20 rounded border border-white/5 text-[11px]">
                  <span className="text-slate-300">Cobblestone Motor Court & Retaining Walls</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(financials.drivewayRetainingWallsCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-purple-500/15 rounded border border-purple-500/30 text-[11px]">
                  <span className="text-purple-200 font-bold">10% Luxury Contingency Reserve</span>
                  <span className="font-mono font-bold text-purple-300">{formatCurrency(financials.contingencyCost)}</span>
                </div>
                <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-white/10 text-[11px] font-bold">
                  <span className="text-slate-300">Land Acquisition (1.25 Acres - Separated)</span>
                  <span className="font-mono text-emerald-400">{formatCurrency(financials.landAcquisitionCost)}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
