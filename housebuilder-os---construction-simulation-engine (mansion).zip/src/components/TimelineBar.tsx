/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - Construction Time Machine & Scrubber Engine
 */

import React, { useEffect, useRef } from 'react';
import {
  ChevronsLeft,
  ChevronsRight,
  Clock,
  FastForward,
  HardHat,
  Pause,
  Play,
  RotateCcw,
  SkipBack,
  SkipForward,
  Sparkles,
  Truck
} from 'lucide-react';
import { SCHEDULE_MILESTONES } from '../engine/simulationModel';
import { ConstructionStage, SimulationState } from '../types/simulation';

interface TimelineBarProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  currentMilestoneTitle: string;
  activeMachinery: string[];
  activeTrades: string[];
  onCompletionCeremony?: () => void;
}

export const TimelineBar: React.FC<TimelineBarProps> = ({
  simState,
  onUpdateSimState,
  currentMilestoneTitle,
  activeMachinery,
  activeTrades,
  onCompletionCeremony
}) => {
  const { currentDay, maxDays, isPlaying, playbackSpeed, isReverse } = simState;
  const timerRef = useRef<number | null>(null);

  // Playback Loop
  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const intervalMs = Math.max(16, 500 / playbackSpeed);

    timerRef.current = window.setInterval(() => {
      onUpdateSimState({
        currentDay: Math.min(
          maxDays,
          Math.max(0, currentDay + (isReverse ? -1 : 1))
        )
      });

      if (!isReverse && currentDay >= maxDays - 1) {
        onUpdateSimState({ isPlaying: false, currentDay: maxDays });
        onCompletionCeremony?.();
      } else if (isReverse && currentDay <= 1) {
        onUpdateSimState({ isPlaying: false, currentDay: 0 });
      }
    }, intervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, currentDay, maxDays, playbackSpeed, isReverse]);

  // Spacebar hotkey for Play/Pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && (e.target as HTMLElement).tagName !== 'INPUT') {
        e.preventDefault();
        onUpdateSimState({ isPlaying: !isPlaying });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, onUpdateSimState]);

  const speedOptions = [0.25, 1, 2, 5, 10, 50, 100];

  return (
    <div className="w-full bg-[#0f1218]/90 backdrop-blur-xl border-t border-white/10 text-slate-100 px-4 py-3 z-30 select-none shadow-2xl flex flex-col gap-2.5">
      {/* Top row: Milestone description & active trade/machinery badges */}
      <div className="flex items-center justify-between gap-4 flex-wrap text-xs">
        <div className="flex items-center gap-2 min-w-0">
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-[#ff7b00]/15 border border-[#ff7b00]/40 text-[#ff7b00] font-mono font-bold shadow-[0_0_10px_rgba(255,123,0,0.25)]">
            <Clock className="w-3.5 h-3.5" />
            <span>DAY {String(currentDay).padStart(3, '0')}</span>
          </div>
          <span className="font-semibold text-white tracking-wide truncate">{currentMilestoneTitle}</span>
        </div>

        {/* Live Site Activity */}
        <div className="flex items-center gap-2 flex-wrap text-[11px] font-mono">
          {activeTrades.length > 0 && (
            <div className="flex items-center gap-1.5 text-slate-300 bg-white/5 px-2.5 py-0.5 rounded border border-white/10 shadow-sm">
              <HardHat className="w-3.5 h-3.5 text-[#ff7b00]" />
              <span className="text-slate-200 font-mono">{activeTrades.slice(0, 2).join(', ')}</span>
            </div>
          )}
          {activeMachinery.length > 0 && (
            <div className="flex items-center gap-1.5 text-slate-300 bg-white/5 px-2.5 py-0.5 rounded border border-white/10 shadow-sm">
              <Truck className="w-3.5 h-3.5 text-[#00f2ff]" />
              <span className="text-slate-200 font-mono">{activeMachinery.slice(0, 2).join(', ')}</span>
            </div>
          )}
        </div>
      </div>

      {/* Scrubber Slider & Milestone markers */}
      <div className="relative w-full pt-1 pb-2">
        <input
          id="timeline-scrubber"
          type="range"
          min={0}
          max={maxDays}
          value={currentDay}
          onChange={(e) => onUpdateSimState({ currentDay: Number(e.target.value) })}
          className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#ff7b00] focus:outline-none focus:ring-2 focus:ring-[#ff7b00]/50"
        />

        {/* Milestone Tick Markers */}
        <div className="relative w-full flex justify-between text-[10px] font-mono text-slate-400 pt-1.5 px-0.5">
          {SCHEDULE_MILESTONES.map((m) => {
            const isPassed = currentDay >= m.day;
            const isCurrent = Math.abs(currentDay - m.day) < 10;
            return (
              <button
                key={m.day}
                id={`milestone-day-${m.day}`}
                onClick={() => onUpdateSimState({ currentDay: m.day })}
                className={`flex flex-col items-center group transition-colors ${
                  isCurrent ? 'text-[#ff7b00] font-bold scale-110' : isPassed ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-400'
                }`}
                title={`Day ${m.day}: ${m.title}`}
              >
                <div
                  className={`w-1.5 h-1.5 rounded-full mb-1 transition-all ${
                    isCurrent ? 'bg-[#ff7b00] ring-4 ring-[#ff7b00]/40 shadow-[0_0_8px_#ff7b00]' : isPassed ? 'bg-[#00f2ff]' : 'bg-slate-700'
                  }`}
                />
                <span className="hidden md:inline">D{m.day}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Controls Bar: Transport & Speed */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        {/* Playback Controls */}
        <div className="flex items-center gap-1.5">
          <button
            id="btn-step-start"
            onClick={() => onUpdateSimState({ currentDay: 0 })}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Reset to Day 0 (Empty Plot)"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            id="btn-step-back"
            onClick={() => onUpdateSimState({ currentDay: Math.max(0, currentDay - 1) })}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Step Back 1 Day"
          >
            <ChevronsLeft className="w-4 h-4" />
          </button>

          {/* Master Play / Pause */}
          <button
            id="btn-play-pause"
            onClick={() => onUpdateSimState({ isPlaying: !isPlaying })}
            className={`flex items-center gap-2 px-5 py-2 rounded-xl font-bold text-xs font-mono tracking-wider shadow-lg transition-all ${
              isPlaying
                ? 'bg-[#ff7b00] text-black hover:bg-orange-400 shadow-[0_0_20px_rgba(255,123,0,0.5)]'
                : 'bg-[#00f2ff] text-black hover:bg-cyan-300 shadow-[0_0_20px_rgba(0,242,255,0.4)]'
            }`}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isPlaying ? 'PAUSE' : 'BUILD HOUSE'}</span>
          </button>

          <button
            id="btn-step-forward"
            onClick={() => onUpdateSimState({ currentDay: Math.min(maxDays, currentDay + 1) })}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Step Forward 1 Day"
          >
            <ChevronsRight className="w-4 h-4" />
          </button>

          <button
            id="btn-step-end"
            onClick={() => onUpdateSimState({ currentDay: maxDays })}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Jump to Completed Mansion (Day 490)"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          {/* Reverse / Deconstruct Mode */}
          <button
            id="btn-toggle-reverse"
            onClick={() => onUpdateSimState({ isReverse: !isReverse })}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
              isReverse
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-[0_0_10px_rgba(244,63,94,0.3)]'
                : 'text-slate-400 hover:bg-white/10 hover:text-slate-200'
            }`}
            title="Deconstruct / Reverse Build Animation"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isReverse ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Deconstruct</span>
          </button>
        </div>

        {/* Simulation Speed Multipliers */}
        <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-xl p-1">
          <span className="text-[10px] text-slate-400 px-2 font-mono uppercase tracking-wider hidden sm:inline">Speed:</span>
          {speedOptions.map((spd) => (
            <button
              key={spd}
              id={`btn-speed-${spd}`}
              onClick={() => onUpdateSimState({ playbackSpeed: spd })}
              className={`px-2.5 py-0.5 rounded-lg text-[11px] font-mono transition-all ${
                playbackSpeed === spd
                  ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_10px_rgba(255,123,0,0.4)]'
                  : 'text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {spd}×
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
