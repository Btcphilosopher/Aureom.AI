/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Marginal Value Engine & Value Engineering Upgrade Matrix
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  Award,
  CheckCircle2,
  ChevronRight,
  Coins,
  Layers,
  Sparkles,
  TrendingDown,
  TrendingUp,
  X,
  Zap
} from 'lucide-react';
import { HouseParameters, ProjectFinancials, ValueEngineUpgrade } from '../types/simulation';
import { GENERATE_VALUE_ENGINE_UPGRADES } from '../engine/simulationModel';

interface MarginalValueEnginePanelProps {
  parameters: HouseParameters;
  financials: ProjectFinancials;
  onUpdateParameters: (newParams: HouseParameters) => void;
  onClose: () => void;
}

export const MarginalValueEnginePanel: React.FC<MarginalValueEnginePanelProps> = ({
  parameters,
  financials,
  onUpdateParameters,
  onClose
}) => {
  const [selectedUpgradeId, setSelectedUpgradeId] = useState<string>('UPG-001');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  const upgrades = GENERATE_VALUE_ENGINE_UPGRADES(parameters);

  const filteredUpgrades = filterCategory === 'ALL'
    ? upgrades
    : upgrades.filter((u) => u.category === filterCategory);

  const selectedUpgrade = upgrades.find((u) => u.id === selectedUpgradeId) || upgrades[0];

  const formatCurrency = (v: number) => `$${Math.round(v).toLocaleString()}`;

  const handleApplyUpgrade = (upgrade: ValueEngineUpgrade) => {
    const updated = { ...parameters };
    if (upgrade.id === 'UPG-001') {
      updated.stoneFacade = 'INDIANA_LIMESTONE';
    } else if (upgrade.id === 'UPG-002') {
      updated.basementAreaSqFt = Math.round(parameters.livingAreaSqFt * 0.38);
      updated.hasBasement = true;
    } else if (upgrade.id === 'UPG-003') {
      updated.hasBasementCinema = true;
      updated.hasWineCellar = true;
    } else if (upgrade.id === 'UPG-004') {
      updated.hasEstatePool = true;
    } else if (upgrade.id === 'UPG-005') {
      updated.hvacType = 'GEOTHERMAL_GROUND_LOOP';
    } else if (upgrade.id === 'UPG-006') {
      updated.roofMaterial = 'NATURAL_SLATE';
    } else if (upgrade.id === 'UPG-007') {
      updated.garageBays = 4;
    }
    onUpdateParameters(updated);
  };

  return (
    <div className="absolute top-16 right-4 w-[480px] max-w-[calc(100vw-2rem)] bg-[#0f1218]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.85)] z-40 text-slate-100 overflow-hidden animate-in fade-in slide-in-from-right-6 duration-200 font-mono">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3.5 bg-black/60 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-lg bg-purple-500/20 border border-purple-500/50 flex items-center justify-center text-purple-400">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-white">
              Marginal Value Engine
            </span>
            <span className="text-[10px] text-slate-400 block">
              Investment ROI & Upgrade Impact Matrix
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto text-xs scrollbar-thin">
        {/* Value Creation Summary */}
        <div className="grid grid-cols-3 gap-2 bg-black/40 p-3 rounded-xl border border-white/10 text-center">
          <div>
            <span className="text-[9px] text-slate-400 uppercase block">Total Project Capex</span>
            <span className="text-xs font-bold text-[#ff7b00]">
              {formatCurrency(financials.totalProjectBudget)}
            </span>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase block">Appraised Valuation</span>
            <span className="text-xs font-bold text-purple-300">
              {formatCurrency(financials.potentialMarketValue)}
            </span>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase block">Implied Equity</span>
            <span className="text-xs font-bold text-emerald-400">
              +{formatCurrency(financials.potentialMarketValue - financials.totalProjectBudget)}
            </span>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none text-[10px]">
          {['ALL', 'Space', 'Exterior', 'Amenities', 'MEP', 'Finish'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterCategory === cat
                  ? 'bg-purple-600 text-white font-bold'
                  : 'bg-black/30 text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Upgrade Cards List */}
        <div className="space-y-2">
          {filteredUpgrades.map((u) => {
            const isSelected = u.id === selectedUpgradeId;
            const isHighValue = u.verdict === 'HIGH_VALUE';
            const isComplexity = u.verdict === 'PURE_COMPLEXITY';

            return (
              <button
                key={u.id}
                onClick={() => setSelectedUpgradeId(u.id)}
                className={`w-full p-3 rounded-xl border text-left transition-all space-y-2 ${
                  isSelected
                    ? 'bg-purple-500/15 border-purple-500 ring-1 ring-purple-500/40 text-white'
                    : 'bg-black/30 border-white/5 hover:border-white/20 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-xs flex items-center gap-2">
                    {u.name}
                    {isHighValue && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                        {u.valueCostRatio}x ROI
                      </span>
                    )}
                    {isComplexity && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-400 border border-rose-500/40">
                        {u.valueCostRatio}x ROI
                      </span>
                    )}
                  </div>
                  <div className="text-right font-mono font-bold text-[#ff7b00]">
                    +{formatCurrency(u.costDeltaUsd)}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-[10px] font-mono text-slate-400 bg-black/40 p-2 rounded-lg">
                  <div>
                    <span className="text-slate-500 block">Schedule:</span>
                    <span className="text-slate-200">+{u.timeDeltaDays} Days</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Appraisal:</span>
                    <span className="text-emerald-400">+{formatCurrency(u.estimatedValueContributionUsd)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">30-Yr Maint:</span>
                    <span className={u.maintenanceDelta30YrUsd > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                      {u.maintenanceDelta30YrUsd > 0 ? `+${formatCurrency(u.maintenanceDelta30YrUsd)}` : `${formatCurrency(u.maintenanceDelta30YrUsd)}`}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Upgrade In-Depth Breakdown */}
        {selectedUpgrade && (
          <div className="bg-black/50 p-4 rounded-xl border border-purple-500/30 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white uppercase">{selectedUpgrade.name}</span>
              <span className="text-purple-300 font-bold">{selectedUpgrade.valueCostRatio}x Multiple</span>
            </div>

            <p className="text-[11px] text-slate-300 font-sans leading-relaxed">
              {selectedUpgrade.description}
            </p>

            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
              <div className="p-2 bg-slate-900 rounded border border-white/5">
                <span className="text-slate-400 block">Energy Consumption:</span>
                <span className="text-[#00f2ff] font-bold">
                  {selectedUpgrade.energyImpactKwhPerYr > 0 ? `+${selectedUpgrade.energyImpactKwhPerYr.toLocaleString()} kWh/yr` : `${selectedUpgrade.energyImpactKwhPerYr.toLocaleString()} kWh/yr (Saved)`}
                </span>
              </div>
              <div className="p-2 bg-slate-900 rounded border border-white/5">
                <span className="text-slate-400 block">Luxury Prestige Index:</span>
                <span className="text-amber-400 font-bold">+{selectedUpgrade.luxuryScorePoints} Points</span>
              </div>
            </div>

            <button
              onClick={() => handleApplyUpgrade(selectedUpgrade)}
              className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-lg shadow-purple-600/30 hover:brightness-110 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              Apply {selectedUpgrade.name} to Model
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
