/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Top Header & Control Navigation HUD
 */

import React from 'react';
import {
  Award,
  Building2,
  Calendar,
  Camera,
  CloudRain,
  Coins,
  Compass,
  Cpu,
  DollarSign,
  Layers,
  Moon,
  Play,
  RotateCcw,
  Sliders,
  Sparkles,
  Sun,
  TrendingUp,
  Wind,
  Wrench,
  Zap
} from 'lucide-react';
import {
  CameraPreset,
  ConstructionStage,
  HouseParameters,
  ProjectFinancials,
  SimulationState,
  TimeOfDay,
  ViewMode,
  WeatherType
} from '../types/simulation';

interface TopHeaderProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  onSetCameraPreset: (preset: CameraPreset) => void;
  parameters: HouseParameters;
  financials: ProjectFinancials;
  currentStage: ConstructionStage;
  overallProgress: number;
  onToggleEconomics: () => void;
  onToggleOptimiser: () => void;
  onToggleValueEngine: () => void;
  onToggleHandover: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  simState,
  onUpdateSimState,
  onSetCameraPreset,
  parameters,
  financials,
  currentStage,
  overallProgress,
  onToggleEconomics,
  onToggleOptimiser,
  onToggleValueEngine,
  onToggleHandover
}) => {
  const getStageBadgeColor = (stage: ConstructionStage) => {
    switch (stage) {
      case ConstructionStage.SITE:
      case ConstructionStage.GROUNDWORK:
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case ConstructionStage.FOUNDATION:
      case ConstructionStage.BASEMENT:
      case ConstructionStage.GROUND_FLOOR:
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case ConstructionStage.STRUCTURE:
      case ConstructionStage.ROOF:
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40';
      case ConstructionStage.STONE_FACADE:
      case ConstructionStage.ENVELOPE:
        return 'bg-amber-600/20 text-amber-300 border-amber-500/50';
      case ConstructionStage.SERVICES:
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';
      case ConstructionStage.INTERNAL_FINISH:
      case ConstructionStage.EXTERNAL_FINISH:
        return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case ConstructionStage.LANDSCAPE:
        return 'bg-teal-500/20 text-teal-300 border-teal-500/40';
      case ConstructionStage.COMPLETE:
      case ConstructionStage.BUILDING_LIFE:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      default:
        return 'bg-slate-500/20 text-slate-300 border-slate-500/40';
    }
  };

  const cycleTimeOfDay = () => {
    const times = [TimeOfDay.SUNRISE, TimeOfDay.MIDDAY, TimeOfDay.GOLDEN_HOUR, TimeOfDay.NIGHT];
    const nextIdx = (times.indexOf(simState.timeOfDay) + 1) % times.length;
    onUpdateSimState({ timeOfDay: times[nextIdx] });
  };

  const cycleWeather = () => {
    const weathers = [WeatherType.CLEAR_SUNNY, WeatherType.PARTLY_CLOUDY, WeatherType.RAIN, WeatherType.SNOW];
    const nextIdx = (weathers.indexOf(simState.weather) + 1) % weathers.length;
    onUpdateSimState({ weather: weathers[nextIdx] });
  };

  const spentSoFar = Math.round(financials.hardConstructionCost * (overallProgress / 100));

  return (
    <header className="w-full bg-[#0f1218]/95 backdrop-blur-xl border-b border-white/10 text-slate-100 z-30 px-4 py-2.5 select-none shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono">
      {/* Brand & Estate Metadata */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-[#ff7b00] to-amber-600 text-white shadow-lg shadow-[#ff7b00]/30 ring-1 ring-[#ff7b00]/40">
          <Building2 className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-extrabold text-base tracking-wider text-white flex items-center gap-1.5 font-mono">
              HOUSEBUILDER <span className="text-[#ff7b00] font-black text-xs px-1.5 py-0.5 rounded bg-[#ff7b00]/10 border border-[#ff7b00]/40 shadow-[0_0_10px_rgba(255,123,0,0.3)]">OS</span>
            </h1>
            <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold border uppercase tracking-widest bg-amber-500/10 border-amber-500/30 text-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.2)]">
              AMERICAN ESTATE EDITION
            </span>
          </div>
          <p className="text-xs text-slate-400 flex items-center gap-2 font-mono">
            <span className="text-slate-200">The Biltmore Estate • Greenwich, CT</span>
            <span className="text-slate-600">•</span>
            <span className="text-[#ff7b00] font-bold">{parameters.livingAreaSqFt.toLocaleString()} sq ft</span>
            <span className="text-slate-600 hidden lg:inline">•</span>
            <span className="text-[10px] text-slate-500 hidden lg:inline">{parameters.stoneFacade.replace('_', ' ')}</span>
          </p>
        </div>
      </div>

      {/* Real-time Project Status & Metrics HUD */}
      <div className="flex items-center gap-2 md:gap-4 flex-wrap bg-black/40 border border-white/10 rounded-xl px-3 py-1.5">
        {/* Stage Badge */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider hidden sm:inline">Stage:</span>
          <span className={`text-xs px-2.5 py-0.5 rounded font-mono font-bold border tracking-wide uppercase shadow-sm ${getStageBadgeColor(currentStage)}`}>
            {currentStage.replace('_', ' ')}
          </span>
        </div>

        {/* Progress % */}
        <div className="flex items-center gap-2 pl-2 border-l border-white/10">
          <div className="text-right">
            <div className="text-xs font-mono font-bold text-[#ff7b00] drop-shadow-[0_0_8px_rgba(255,123,0,0.4)]">{overallProgress}%</div>
            <div className="text-[9px] uppercase tracking-wider text-slate-400 hidden sm:block">Day {simState.currentDay} / 490</div>
          </div>
          <div className="w-14 h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#ff7b00] to-[#00f2ff] rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(255,123,0,0.6)]"
              style={{ width: `${overallProgress}%` }}
            />
          </div>
        </div>

        {/* Hard Cost Spend */}
        <div className="flex items-center gap-2 pl-2 border-l border-white/10">
          <Coins className="w-4 h-4 text-[#00f2ff] hidden sm:block drop-shadow-[0_0_6px_rgba(0,242,255,0.4)]" />
          <div>
            <div className="text-xs font-mono font-bold text-[#00f2ff] drop-shadow-[0_0_8px_rgba(0,242,255,0.3)]">
              ${((spentSoFar || 0) / 1000000).toFixed(2)}M <span className="text-slate-500 font-normal">/ ${((financials?.hardConstructionCost || 0) / 1000000).toFixed(2)}M</span>
            </div>
            <div className="text-[9px] uppercase tracking-wider text-slate-400 hidden sm:block">${financials?.hardCostPerSqFt ?? 0}/sq ft Hard</div>
          </div>
        </div>

        {/* Quick Launch Economic Engine */}
        <button
          onClick={onToggleEconomics}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#ff7b00]/15 border border-[#ff7b00]/40 text-[#ff7b00] hover:bg-[#ff7b00]/25 text-xs font-bold transition-all shadow-[0_0_10px_rgba(255,123,0,0.2)]"
          title="Open Economic Matrix & Marginal Cost Model"
        >
          <Coins className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Economics</span>
        </button>

        {/* Quick Launch Optimiser */}
        <button
          onClick={onToggleOptimiser}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#ff7b00] to-amber-600 text-black hover:brightness-110 text-xs font-bold transition-all shadow-md shadow-[#ff7b00]/30"
          title="Launch Economic Parameter Solver"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Optimiser</span>
        </button>
      </div>

      {/* View Mode Switcher Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
        <button
          id="btn-mode-construction"
          onClick={() => onUpdateSimState({ viewMode: ViewMode.CONSTRUCTION })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
            simState.viewMode === ViewMode.CONSTRUCTION
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white border border-transparent'
          }`}
          title="490-Day Construction Timeline"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Timeline</span>
        </button>

        <button
          id="btn-mode-cutaway"
          onClick={() => onUpdateSimState({ viewMode: ViewMode.CUTAWAY })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
            simState.viewMode === ViewMode.CUTAWAY
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white border border-transparent'
          }`}
          title="Section Cutaway Mode"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Cutaway</span>
        </button>

        <button
          id="btn-mode-exploded"
          onClick={() => onUpdateSimState({ viewMode: ViewMode.EXPLODED })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
            simState.viewMode === ViewMode.EXPLODED
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white border border-transparent'
          }`}
          title="10-Layer Exploded Assembly"
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Exploded</span>
        </button>

        <button
          id="btn-mode-mep"
          onClick={() => onUpdateSimState({ viewMode: ViewMode.SERVICES_MEP })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
            simState.viewMode === ViewMode.SERVICES_MEP
              ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white border border-transparent'
          }`}
          title="Geothermal & MEP Flows"
        >
          <Zap className="w-3.5 h-3.5" />
          <span>MEP</span>
        </button>

        <button
          id="btn-mode-masterplan"
          onClick={() => onUpdateSimState({ viewMode: ViewMode.MASTERPLAN })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
            simState.viewMode === ViewMode.MASTERPLAN
              ? 'bg-purple-600 text-white font-bold shadow-[0_0_15px_rgba(168,85,247,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white border border-transparent'
          }`}
          title="Estate Enclave Masterplan"
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Masterplan</span>
        </button>

        {/* Handover Certificate */}
        <button
          onClick={onToggleHandover}
          className="p-1.5 rounded-lg text-amber-400 hover:bg-amber-400/20 transition-colors"
          title="View Digital Twin Handover Certificate"
        >
          <Award className="w-4 h-4" />
        </button>

        {/* Lighting & Weather quick controls */}
        <div className="flex items-center gap-1 pl-2 border-l border-white/10">
          <button
            id="btn-toggle-time"
            onClick={cycleTimeOfDay}
            className="p-1.5 rounded-lg text-slate-300 hover:bg-white/10 hover:text-[#ff7b00] transition-colors"
            title={`Time: ${simState.timeOfDay}`}
          >
            {simState.timeOfDay === TimeOfDay.NIGHT ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-[#ff7b00]" />}
          </button>

          <button
            id="btn-toggle-weather"
            onClick={cycleWeather}
            className="p-1.5 rounded-lg text-slate-300 hover:bg-white/10 hover:text-[#00f2ff] transition-colors"
            title={`Weather: ${simState.weather}`}
          >
            <CloudRain className="w-4 h-4 text-[#00f2ff]" />
          </button>
        </div>
      </div>
    </header>
  );
};
