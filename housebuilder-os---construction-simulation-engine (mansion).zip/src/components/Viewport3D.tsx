/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * 3D Viewport & HUD Overlay
 */

import React, { useEffect, useRef } from 'react';
import {
  Boxes,
  Building,
  Building2,
  Camera,
  Coins,
  Compass,
  Focus,
  History,
  Info,
  Layers,
  LayoutGrid,
  Maximize,
  Minimize,
  Move,
  Ruler,
  Sliders,
  Sparkles,
  TrendingUp,
  Zap
} from 'lucide-react';
import { ConstructionSceneEngine } from '../engine/threeScene';
import {
  BimComponent,
  CameraPreset,
  HouseParameters,
  SimulationState,
  ViewMode
} from '../types/simulation';

interface Viewport3DProps {
  simState: SimulationState;
  onUpdateSimState: (updates: Partial<SimulationState>) => void;
  bimComponents: BimComponent[];
  onSelectComponent: (componentId: string | null) => void;
  activePanel: string | null;
  onTogglePanel: (panel: string) => void;
}

export const Viewport3D: React.FC<Viewport3DProps> = ({
  simState,
  onUpdateSimState,
  bimComponents,
  onSelectComponent,
  activePanel,
  onTogglePanel
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneEngineRef = useRef<ConstructionSceneEngine | null>(null);

  // Initialize Three.js WebGL Scene Engine
  useEffect(() => {
    if (!containerRef.current) return;

    const engine = new ConstructionSceneEngine(containerRef.current);
    engine.onSelectComponent = onSelectComponent;
    sceneEngineRef.current = engine;

    return () => {
      engine.dispose();
      sceneEngineRef.current = null;
    };
  }, []);

  // Update scene when simulation state changes
  useEffect(() => {
    if (sceneEngineRef.current) {
      sceneEngineRef.current.update(simState, bimComponents);
    }
  }, [simState, bimComponents]);

  // Re-build geometry when parametric values or stone facade changes
  useEffect(() => {
    if (sceneEngineRef.current) {
      sceneEngineRef.current.buildAmericanMansionGeometry(simState.parameters);
    }
  }, [simState.parameters]);

  // Handle camera presets
  useEffect(() => {
    if (sceneEngineRef.current) {
      sceneEngineRef.current.setCameraPreset(simState.cameraPreset);
    }
  }, [simState.cameraPreset]);

  // Get hovered component name
  const hoveredId = sceneEngineRef.current?.hoveredComponentId;
  const hoveredComp = hoveredId ? bimComponents.find((c) => c.id === hoveredId) : null;

  return (
    <div className="relative w-full h-full flex-1 overflow-hidden select-none bg-[#050608]">
      {/* Three.js Canvas Container */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* BIM Hover Tooltip Badge */}
      {hoveredComp && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-[#0f1218]/90 backdrop-blur-xl border border-[#ff7b00]/60 px-4 py-2 rounded-xl shadow-[0_0_20px_rgba(255,123,0,0.3)] z-20 flex items-center gap-2.5 text-xs text-white pointer-events-none animate-in fade-in zoom-in-95 duration-150 font-mono">
          <span className="font-mono font-bold text-[#ff7b00]">{hoveredComp.id}</span>
          <span className="text-slate-500">•</span>
          <span className="font-medium text-slate-100">{hoveredComp.name}</span>
          <span className="text-[10px] text-[#00f2ff] uppercase tracking-wider hidden sm:inline">[Click to Inspect]</span>
        </div>
      )}

      {/* Top Left Navigation / Orbit Hint HUD */}
      <div className="absolute top-4 left-4 z-20 pointer-events-none hidden sm:flex items-center gap-2 bg-[#0f1218]/80 backdrop-blur-xl border border-white/10 rounded-xl px-3 py-1.5 text-[11px] text-slate-300 shadow-xl font-mono">
        <Compass className="w-3.5 h-3.5 text-[#ff7b00]" />
        <span>Orbit: Drag • Zoom: Scroll • Pan: Shift+Drag</span>
      </div>

      {/* Floating Tools HUD Dock (Bottom Left) */}
      <div className="absolute bottom-4 left-4 z-20 flex items-center gap-1.5 bg-[#0f1218]/95 backdrop-blur-2xl border border-white/10 rounded-2xl p-1.5 shadow-[0_10px_30px_rgba(0,0,0,0.85)] overflow-x-auto max-w-[calc(100vw-2rem)] scrollbar-none font-mono">
        <button
          id="dock-btn-economics"
          onClick={() => onTogglePanel('economics')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'economics'
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Economic Matrix & Hard/Soft/Site Costs"
        >
          <Coins className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Economics</span>
        </button>

        <button
          id="dock-btn-value-engine"
          onClick={() => onTogglePanel('value_engine')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'value_engine'
              ? 'bg-purple-600 text-white font-bold shadow-[0_0_15px_rgba(168,85,247,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Marginal Value Engine & Upgrade Matrix"
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Value ROI</span>
        </button>

        <button
          id="dock-btn-cutaway"
          onClick={() => onTogglePanel('cutaway')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'cutaway'
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Cutaway & Exploded Controls"
        >
          <Layers className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Layers</span>
        </button>

        <button
          id="dock-btn-mep"
          onClick={() => onTogglePanel('mep')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'mep'
              ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Geothermal & MEP Flows"
        >
          <Zap className="w-3.5 h-3.5" />
          <span className="hidden md:inline">MEP & Flows</span>
        </button>

        <button
          id="dock-btn-rooms"
          onClick={() => onTogglePanel('rooms')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'rooms'
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Mansion Room Matrix"
        >
          <LayoutGrid className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Rooms</span>
        </button>

        <button
          id="dock-btn-parametric"
          onClick={() => onTogglePanel('parametric')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'parametric'
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Estate Parametric Generator"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Parameters</span>
        </button>

        <button
          id="dock-btn-materials"
          onClick={() => onTogglePanel('materials')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'materials'
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Material & Limestone Stock Ledger"
        >
          <Boxes className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Logistics</span>
        </button>

        <button
          id="dock-btn-masterplan"
          onClick={() => onTogglePanel('masterplan')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'masterplan'
              ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Estate Enclave Masterplan"
        >
          <Building2 className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Masterplan</span>
        </button>

        <button
          id="dock-btn-maintenance"
          onClick={() => onTogglePanel('maintenance')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'maintenance'
              ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="30-Year Whole-Life Lifecycle"
        >
          <History className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Lifecycle</span>
        </button>

        <button
          id="dock-btn-camera"
          onClick={() => onTogglePanel('camera')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
            activePanel === 'camera'
              ? 'bg-[#ff7b00] text-black font-bold shadow-[0_0_15px_rgba(255,123,0,0.4)]'
              : 'text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
          title="Cinematic Camera Views"
        >
          <Camera className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Camera</span>
        </button>
      </div>
    </div>
  );
};
