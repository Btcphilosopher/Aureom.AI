/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Housebuilder OS - American Stone Estate Edition
 * Final Project Handover Certificate & Digital Twin Dossier
 */

import React from 'react';
import {
  Award,
  Building,
  CheckCircle,
  Coins,
  Download,
  FileCheck,
  Globe,
  MapPin,
  QrCode,
  Shield,
  Sparkles,
  X,
  Zap
} from 'lucide-react';
import { HouseParameters, ProjectFinancials } from '../types/simulation';

interface HandoverCertificateModalProps {
  parameters: HouseParameters;
  financials: ProjectFinancials;
  onClose: () => void;
}

export const HandoverCertificateModal: React.FC<HandoverCertificateModalProps> = ({
  parameters,
  financials,
  onClose
}) => {
  const formatCurrency = (v: number) => `$${Math.round(v).toLocaleString()}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0b0e14] border border-amber-500/30 rounded-2xl w-[680px] max-w-full text-slate-100 shadow-[0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden animate-in fade-in zoom-in-95 duration-200 font-mono">
        {/* Certificate Header Banner */}
        <div className="relative bg-gradient-to-r from-amber-950 via-slate-900 to-black p-6 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.3)]">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="text-[10px] text-amber-400 uppercase tracking-widest font-bold">
                Certificate of Practical Completion & Handover
              </div>
              <div className="text-base font-bold text-white tracking-wide">
                The American Stone Estate • Digital Twin ID #EST-6000-CT
              </div>
              <div className="text-[11px] text-slate-400">
                Greenwich, CT • AIA G704-2017 Digital Verification Standard
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Certificate Body */}
        <div className="p-6 space-y-5 text-xs">
          {/* Executive Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/40 p-4 rounded-xl border border-white/10">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Total Area</span>
              <span className="text-sm font-bold text-white">
                {parameters.livingAreaSqFt.toLocaleString()} sq ft
              </span>
              <span className="text-[10px] text-slate-500 block">
                + {Math.round(parameters.livingAreaSqFt * 0.35)} sf Bsm
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Construction Cost</span>
              <span className="text-sm font-bold text-[#ff7b00]">
                {formatCurrency(financials.hardConstructionCost)}
              </span>
              <span className="text-[10px] text-slate-500 block">
                ${financials.hardCostPerSqFt}/sq ft hard
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Total Capex</span>
              <span className="text-sm font-bold text-[#00f2ff]">
                {formatCurrency(financials.totalProjectBudget)}
              </span>
              <span className="text-[10px] text-slate-500 block">
                Incl. Soft & Site
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Appraised Value</span>
              <span className="text-sm font-bold text-purple-300">
                {formatCurrency(financials.potentialMarketValue)}
              </span>
              <span className="text-[10px] text-emerald-400 block font-bold">
                +32% Equity Gain
              </span>
            </div>
          </div>

          {/* Architectural & Structural Specifications */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              As-Built Engineering & Architectural Specifications
            </span>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 bg-black/30 rounded-lg border border-white/5 space-y-1">
                <div className="text-slate-400">Exterior Cladding:</div>
                <div className="text-white font-bold">{parameters.stoneFacade.replace('_', ' ')} (6,200 sf envelope)</div>
              </div>
              <div className="p-2.5 bg-black/30 rounded-lg border border-white/5 space-y-1">
                <div className="text-slate-400">Roofing System:</div>
                <div className="text-white font-bold">{parameters.roofMaterial.replace('_', ' ')} (50-Yr Durability)</div>
              </div>
              <div className="p-2.5 bg-black/30 rounded-lg border border-white/5 space-y-1">
                <div className="text-slate-400">HVAC / Energy:</div>
                <div className="text-white font-bold">{parameters.hvacType.replace('_', ' ')} (COP 4.8)</div>
              </div>
              <div className="p-2.5 bg-black/30 rounded-lg border border-white/5 space-y-1">
                <div className="text-slate-400">Garages & Amenities:</div>
                <div className="text-white font-bold">{parameters.garageBays}-Car Garage • Gunite Pool • Cinema</div>
              </div>
            </div>
          </div>

          {/* Compliance & Warranty Seals */}
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between text-[11px]">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <div>
                <div className="font-bold text-white">Full BIM Verification & Structural Warranty Active</div>
                <div className="text-slate-400 text-[10px]">10-Year Structural Defect Coverage • Energy Star & HERS Index 38 Certified</div>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40">
                PASSED 100%
              </span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 bg-black/60 border-t border-white/10">
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <QrCode className="w-4 h-4 text-amber-400" />
            <span>Cryptographic BIM Seal: SHA-256 Validated</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-300 hover:bg-white/10 transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => {
                alert('Downloading Housebuilder OS American Stone Estate BIM Digital Twin Archive (.IFC / .JSON / .GLTF)...');
              }}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-xs shadow-lg shadow-amber-500/30 hover:brightness-110 transition-all"
            >
              <Download className="w-4 h-4" />
              Export BIM Digital Twin Dossier
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
