"""
data_ingestion.py — PropIntel Data Ingestion Pipeline
Pulls property, economic, demographic, and geospatial data from
CSV/Excel files, REST APIs, and mock generators for testing.
"""

from __future__ import annotations

import io
import random
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests

from utils import get_logger, CONFIG, ensure_dir

log = get_logger("data_ingestion")


# ─────────────────────────────────────────────
# BASE INGESTION CLASS
# ─────────────────────────────────────────────


class BaseIngester:
    """Abstract base for all data ingesters."""

    source_name: str = "base"

    def fetch(self) -> pd.DataFrame:
        raise NotImplementedError

    def validate(self, df: pd.DataFrame) -> pd.DataFrame:
        """Basic nullity check — subclasses extend this."""
        initial = len(df)
        df = df.dropna(how="all")
        dropped = initial - len(df)
        if dropped:
            log.warning(f"[{self.source_name}] Dropped {dropped} fully-null rows")
        return df


# ─────────────────────────────────────────────
# CSV / EXCEL INGESTION
# ─────────────────────────────────────────────


class FileIngester(BaseIngester):
    """Loads property data from local CSV or Excel files."""

    source_name = "file"

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def fetch(self) -> pd.DataFrame:
        suffix = self.path.suffix.lower()
        log.info(f"Loading {self.path}")
        if suffix == ".csv":
            df = pd.read_csv(self.path, low_memory=False)
        elif suffix in (".xlsx", ".xls"):
            df = pd.read_excel(self.path)
        else:
            raise ValueError(f"Unsupported file type: {suffix}")
        log.info(f"Loaded {len(df):,} rows from {self.path.name}")
        return self.validate(df)


# ─────────────────────────────────────────────
# REST API INGESTION (generic)
# ─────────────────────────────────────────────


class APIIngester(BaseIngester):
    """
    Generic REST API ingester with retry logic.
    Subclass and override `_parse_response` for specific APIs.
    """

    source_name = "api"
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds

    def __init__(self, url: str, params: dict | None = None, headers: dict | None = None):
        self.url = url
        self.params = params or {}
        self.headers = headers or {"Accept": "application/json"}

    def _get(self) -> dict:
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                resp = requests.get(
                    self.url, params=self.params, headers=self.headers, timeout=15
                )
                resp.raise_for_status()
                return resp.json()
            except requests.RequestException as exc:
                log.warning(f"API attempt {attempt}/{self.MAX_RETRIES} failed: {exc}")
                if attempt < self.MAX_RETRIES:
                    time.sleep(self.RETRY_DELAY * attempt)
        raise RuntimeError(f"API call failed after {self.MAX_RETRIES} retries: {self.url}")

    def _parse_response(self, raw: dict) -> pd.DataFrame:
        return pd.DataFrame(raw if isinstance(raw, list) else [raw])

    def fetch(self) -> pd.DataFrame:
        raw = self._get()
        df = self._parse_response(raw)
        log.info(f"[{self.source_name}] Fetched {len(df):,} rows")
        return self.validate(df)


# ─────────────────────────────────────────────
# MOCK DATA GENERATOR (for testing / demo)
# ─────────────────────────────────────────────

# London neighbourhood bounding boxes  (lat_min, lat_max, lon_min, lon_max)
_LONDON_NEIGHBOURHOODS = {
    "Kensington":     (51.488, 51.504, -0.206, -0.175),
    "Shoreditch":     (51.520, 51.532, -0.082, -0.063),
    "Canary Wharf":   (51.499, 51.510, -0.025,  0.005),
    "Brixton":        (51.457, 51.470, -0.117, -0.094),
    "Hackney":        (51.537, 51.555, -0.068, -0.038),
    "Islington":      (51.530, 51.553, -0.122, -0.090),
    "Hammersmith":    (51.483, 51.498, -0.240, -0.208),
    "Greenwich":      (51.473, 51.490,  0.001,  0.033),
    "Croydon":        (51.368, 51.386, -0.106, -0.076),
    "Stratford":      (51.536, 51.552,  0.000,  0.020),
}

_PROPERTY_TYPES = ["Flat", "Terraced House", "Semi-Detached", "Detached", "Studio", "Penthouse"]
_TENURE = ["Freehold", "Leasehold"]


class MockPropertyDataIngester(BaseIngester):
    """
    Generates realistic synthetic property listing data for the
    Greater London area. Used for demo runs and unit tests.
    """

    source_name = "mock_properties"

    def __init__(self, n: int = 2_000, seed: int = 42):
        self.n = n
        self.seed = seed

    def fetch(self) -> pd.DataFrame:
        rng = np.random.default_rng(self.seed)
        random.seed(self.seed)

        records = []
        neighbourhoods = list(_LONDON_NEIGHBOURHOODS.keys())

        for i in range(self.n):
            hood = random.choice(neighbourhoods)
            lat_min, lat_max, lon_min, lon_max = _LONDON_NEIGHBOURHOODS[hood]

            prop_type = random.choice(_PROPERTY_TYPES)
            bedrooms = int(rng.choice([1, 2, 3, 4, 5], p=[0.25, 0.35, 0.25, 0.10, 0.05]))
            size_sqm = float(rng.normal(55 + bedrooms * 18, 12))

            # Base price driven by neighbourhood prestige & size
            prestige = {
                "Kensington": 1.8, "Canary Wharf": 1.5, "Shoreditch": 1.3,
                "Islington": 1.2, "Hammersmith": 1.1, "Hackney": 1.0,
                "Greenwich": 0.9, "Brixton": 0.85, "Stratford": 0.80, "Croydon": 0.70,
            }[hood]
            base_price = size_sqm * 9_500 * prestige * float(rng.normal(1.0, 0.12))

            list_date = datetime(2020, 1, 1) + timedelta(days=int(rng.integers(0, 365 * 4)))

            records.append({
                "property_id": f"PROP-{i + 1:05d}",
                "neighbourhood": hood,
                "property_type": prop_type,
                "bedrooms": bedrooms,
                "bathrooms": max(1, bedrooms - 1),
                "size_sqm": round(max(20.0, size_sqm), 1),
                "price_gbp": round(max(75_000, base_price), -3),
                "price_per_sqm": round(base_price / max(20.0, size_sqm), 0),
                "lat": float(rng.uniform(lat_min, lat_max)),
                "lon": float(rng.uniform(lon_min, lon_max)),
                "tenure": random.choice(_TENURE),
                "year_built": int(rng.integers(1880, 2023)),
                "epc_rating": random.choice(["A", "B", "C", "D", "E"]),
                "list_date": list_date.strftime("%Y-%m-%d"),
                "days_on_market": int(rng.integers(1, 180)),
                "is_sold": bool(rng.random() > 0.35),
            })

        df = pd.DataFrame(records)
        log.info(f"[mock_properties] Generated {len(df):,} synthetic listings")
        return df


class MockEconomicDataIngester(BaseIngester):
    """Generates synthetic monthly economic indicators (2015–2025)."""

    source_name = "mock_economics"

    def fetch(self) -> pd.DataFrame:
        dates = pd.date_range("2015-01-01", "2025-01-01", freq="MS")
        rng = np.random.default_rng(0)
        n = len(dates)

        base_rate = 0.50
        rates, inflations, unemployments = [], [], []
        for i in range(n):
            base_rate += float(rng.normal(0, 0.08))
            base_rate = max(0.1, min(6.0, base_rate))
            rates.append(round(base_rate, 2))
            inflations.append(round(float(rng.normal(2.5, 0.8)), 2))
            unemployments.append(round(float(rng.normal(4.5, 0.5)), 2))

        df = pd.DataFrame({
            "date": dates,
            "bank_rate_pct": rates,
            "inflation_pct": inflations,
            "unemployment_pct": unemployments,
            "gdp_growth_pct": [round(float(rng.normal(1.8, 0.9)), 2) for _ in range(n)],
            "consumer_confidence": [round(float(rng.normal(95, 8)), 1) for _ in range(n)],
        })
        log.info(f"[mock_economics] Generated {len(df):,} monthly economic records")
        return df


class MockSalesHistoryIngester(BaseIngester):
    """Generates synthetic monthly average sale prices per neighbourhood."""

    source_name = "mock_sales_history"

    def fetch(self) -> pd.DataFrame:
        dates = pd.date_range("2015-01-01", "2025-01-01", freq="MS")
        rng = np.random.default_rng(7)
        records = []

        base_prices = {
            "Kensington": 1_400_000, "Canary Wharf": 900_000, "Shoreditch": 750_000,
            "Islington": 680_000, "Hammersmith": 620_000, "Hackney": 550_000,
            "Greenwich": 490_000, "Brixton": 440_000, "Stratford": 410_000, "Croydon": 370_000,
        }

        for hood, base in base_prices.items():
            price = float(base)
            for dt in dates:
                price *= float(rng.normal(1.005, 0.018))  # slight upward drift + noise
                price = max(base * 0.6, price)
                records.append({
                    "date": dt,
                    "neighbourhood": hood,
                    "avg_sale_price": round(price, -3),
                    "transaction_count": int(rng.integers(15, 120)),
                    "avg_days_to_sell": int(rng.integers(25, 90)),
                })

        df = pd.DataFrame(records)
        log.info(f"[mock_sales_history] Generated {len(df):,} records")
        return df


class MockNeighbourhoodIngester(BaseIngester):
    """Generates neighbourhood-level demographic and risk data."""

    source_name = "mock_neighbourhood"

    def fetch(self) -> pd.DataFrame:
        rng = np.random.default_rng(3)
        records = []
        for hood in _LONDON_NEIGHBOURHOODS:
            records.append({
                "neighbourhood": hood,
                "population": int(rng.integers(15_000, 80_000)),
                "median_income_gbp": int(rng.integers(28_000, 95_000)),
                "crime_rate_per_1k": round(float(rng.uniform(8, 65)), 1),
                "school_rating": round(float(rng.uniform(3.5, 9.0)), 1),
                "flood_risk_score": round(float(rng.uniform(0.0, 1.0)), 2),
                "transport_score": round(float(rng.uniform(4.0, 10.0)), 1),
                "green_space_pct": round(float(rng.uniform(5.0, 35.0)), 1),
                "avg_commute_min": int(rng.integers(18, 50)),
                "planning_activity_score": round(float(rng.uniform(1.0, 10.0)), 1),
            })
        return pd.DataFrame(records)


# ─────────────────────────────────────────────
# INGESTION ORCHESTRATOR
# ─────────────────────────────────────────────


class DataIngestionPipeline:
    """
    Runs all configured ingesters, returning a dict of
    named DataFrames ready for the cleaning pipeline.
    """

    def __init__(self, use_mock: bool = True):
        self.use_mock = use_mock
        self._ingesters: list[tuple[str, BaseIngester]] = []

        if use_mock:
            self._ingesters = [
                ("properties",    MockPropertyDataIngester(n=2_000)),
                ("economics",     MockEconomicDataIngester()),
                ("sales_history", MockSalesHistoryIngester()),
                ("neighbourhoods", MockNeighbourhoodIngester()),
            ]

    def add_file_source(self, name: str, path: str | Path) -> None:
        self._ingesters.append((name, FileIngester(path)))

    def run(self) -> dict[str, pd.DataFrame]:
        results: dict[str, pd.DataFrame] = {}
        for name, ingester in self._ingesters:
            try:
                results[name] = ingester.fetch()
            except Exception as exc:
                log.error(f"Failed to ingest [{name}]: {exc}", exc_info=True)
        log.info(f"Ingestion complete — {len(results)} datasets loaded")
        return results
