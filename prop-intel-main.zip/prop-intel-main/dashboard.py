"""
dashboard.py — PropIntel Bloomberg-Style Interactive Dashboard
Built with Plotly Dash. Provides:
  • Market overview with live KPI tiles
  • Interactive geospatial maps (scatter, heatmap, risk)
  • Price trend charts and forecasts
  • Neighbourhood analytics & clustering
  • Portfolio management view
  • Scenario simulation panel
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import dash
from dash import Input, Output, State, callback, dcc, html
import dash_bootstrap_components as dbc

from utils import get_logger, CONFIG, format_currency
from geospatial import (
    build_property_scatter_map,
    build_price_density_map,
    build_risk_scatter_map,
    build_neighbourhood_bubble_map,
)

log = get_logger("dashboard")

# ─────────────────────────────────────────────
# COLOUR PALETTE (Anglo-Futurist dark theme)
# ─────────────────────────────────────────────

C = {
    "bg_deep":  "#0d0d1a",
    "bg_card":  "#13132b",
    "bg_panel": "#1a1a3e",
    "gold":     "#c9a84c",
    "cyan":     "#00d4ff",
    "green":    "#00e676",
    "red":      "#ff4444",
    "amber":    "#ffb74d",
    "text":     "#e8e8f0",
    "muted":    "#7878a0",
    "border":   "#2a2a5a",
}

FONT_DISPLAY = "'Bebas Neue', 'Arial Narrow', sans-serif"
FONT_MONO    = "'DM Mono', 'Courier New', monospace"
FONT_BODY    = "'Inter', 'Helvetica Neue', sans-serif"


# ─────────────────────────────────────────────
# COMPONENT HELPERS
# ─────────────────────────────────────────────


def kpi_tile(title: str, value: str, subtitle: str = "", delta: str = "", delta_up: bool = True) -> html.Div:
    delta_colour = C["green"] if delta_up else C["red"]
    return html.Div([
        html.P(title, style={
            "fontSize": "10px", "letterSpacing": "2px", "color": C["muted"],
            "textTransform": "uppercase", "marginBottom": "4px", "fontFamily": FONT_BODY,
        }),
        html.H3(value, style={
            "fontSize": "26px", "fontFamily": FONT_DISPLAY, "letterSpacing": "1px",
            "color": C["gold"], "margin": "0 0 2px 0",
        }),
        html.Div([
            html.Span(delta, style={"color": delta_colour, "fontSize": "12px", "fontFamily": FONT_MONO}),
            html.Span(f"  {subtitle}", style={"color": C["muted"], "fontSize": "11px"}),
        ]),
    ], style={
        "background": C["bg_card"],
        "border": f"1px solid {C['border']}",
        "borderTop": f"2px solid {C['gold']}",
        "borderRadius": "4px",
        "padding": "16px 20px",
        "flex": "1",
        "minWidth": "160px",
    })


def section_header(title: str, subtitle: str = "") -> html.Div:
    return html.Div([
        html.H4(title, style={
            "fontFamily": FONT_DISPLAY,
            "color": C["cyan"],
            "letterSpacing": "3px",
            "fontSize": "16px",
            "margin": "0 0 2px 0",
            "textTransform": "uppercase",
        }),
        html.P(subtitle, style={"color": C["muted"], "fontSize": "12px", "margin": 0}) if subtitle else None,
    ], style={"marginBottom": "16px", "paddingBottom": "8px", "borderBottom": f"1px solid {C['border']}"})


def card(children, style: dict | None = None) -> html.Div:
    base = {
        "background": C["bg_card"],
        "border": f"1px solid {C['border']}",
        "borderRadius": "6px",
        "padding": "20px",
        "marginBottom": "16px",
    }
    if style:
        base.update(style)
    return html.Div(children, style=base)


# ─────────────────────────────────────────────
# CHART BUILDERS
# ─────────────────────────────────────────────


def build_price_history_chart(sales_history: pd.DataFrame, neighbourhoods: list[str] | None = None) -> go.Figure:
    sh = sales_history.copy()
    sh["date"] = pd.to_datetime(sh["date"])
    if neighbourhoods:
        sh = sh[sh["neighbourhood"].isin(neighbourhoods)]

    fig = go.Figure()
    for hood, g in sh.groupby("neighbourhood"):
        g = g.sort_values("date")
        fig.add_trace(go.Scatter(
            x=g["date"], y=g["avg_sale_price"],
            name=hood, mode="lines",
            line=dict(width=2),
            hovertemplate=f"<b>{hood}</b><br>%{{x|%b %Y}}<br>£%{{y:,.0f}}<extra></extra>",
        ))

    fig.update_layout(
        **_dark_layout("Average Sale Price by Neighbourhood"),
        xaxis_title="Date", yaxis_title="Avg Sale Price (£)",
        legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor=C["border"]),
        yaxis=dict(tickprefix="£", tickformat=",.0f"),
    )
    return fig


def build_forecast_chart(sales_history: pd.DataFrame, forecasts: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    colours = px.colors.qualitative.Plotly

    for i, (hood, g) in enumerate(sales_history.groupby("neighbourhood")):
        g = g.sort_values("date")
        g["date"] = pd.to_datetime(g["date"])
        colour = colours[i % len(colours)]

        fig.add_trace(go.Scatter(
            x=g["date"], y=g["avg_sale_price"],
            name=hood, mode="lines",
            line=dict(color=colour, width=2),
            showlegend=True,
        ))

        if not forecasts.empty and "neighbourhood" in forecasts.columns:
            fc = forecasts[forecasts["neighbourhood"] == hood].sort_values("date")
            if not fc.empty:
                fig.add_trace(go.Scatter(
                    x=fc["date"], y=fc["forecast_price"],
                    mode="lines", line=dict(color=colour, width=2, dash="dash"),
                    showlegend=False,
                ))
                fig.add_trace(go.Scatter(
                    x=pd.concat([fc["date"], fc["date"].iloc[::-1]]),
                    y=pd.concat([fc["upper_95"], fc["lower_95"].iloc[::-1]]),
                    fill="toself",
                    fillcolor=f"rgba{tuple(list(px.colors.hex_to_rgb(colour)) + [30])}",
                    line=dict(color="rgba(0,0,0,0)"),
                    showlegend=False,
                    name=f"{hood} CI",
                ))

    fig.update_layout(
        **_dark_layout("Price Forecast (12 months)"),
        xaxis_title="Date", yaxis_title="Price (£)",
        yaxis=dict(tickprefix="£", tickformat=",.0f"),
    )
    return fig


def build_price_distribution_chart(properties: pd.DataFrame) -> go.Figure:
    fig = go.Figure(go.Histogram(
        x=properties["price_gbp"].dropna(),
        nbinsx=60,
        marker_color=C["gold"],
        marker_line=dict(color=C["bg_deep"], width=0.5),
        opacity=0.85,
    ))
    fig.update_layout(
        **_dark_layout("Property Price Distribution"),
        xaxis=dict(tickprefix="£", tickformat=",.0s"),
        yaxis_title="Count",
        bargap=0.02,
    )
    return fig


def build_roi_waterfall(portfolio_summary: dict) -> go.Figure:
    if not portfolio_summary:
        return go.Figure()

    labels = ["Purchase Cost", "Capital Gain", "Rental Income", "Holding Costs", "Net Return"]
    values = [
        -portfolio_summary.get("total_cost", 0),
        portfolio_summary.get("total_portfolio_value", 0) - portfolio_summary.get("total_cost", 0),
        portfolio_summary.get("total_monthly_cashflow", 0) * 12 * 5,
        -portfolio_summary.get("total_monthly_cashflow", 0) * 12 * 5 * 0.3,
        0,
    ]
    values[-1] = sum(values[:-1])

    colours = [C["red"] if v < 0 else C["green"] for v in values]

    fig = go.Figure(go.Bar(
        x=labels, y=[abs(v) for v in values],
        marker_color=colours,
        text=[format_currency(v) for v in values],
        textposition="outside",
    ))
    fig.update_layout(**_dark_layout("Portfolio Return Waterfall"))
    return fig


def build_risk_histogram(properties: pd.DataFrame) -> go.Figure:
    if "risk_score" not in properties.columns:
        return go.Figure()

    fig = go.Figure(go.Histogram(
        x=properties["risk_score"],
        nbinsx=40,
        marker=dict(
            color=properties["risk_score"].values,
            colorscale=[[0, "#2ecc71"], [0.5, "#f39c12"], [1, "#e74c3c"]],
            showscale=False,
        ),
    ))
    fig.update_layout(
        **_dark_layout("Risk Score Distribution"),
        xaxis_title="Risk Score (0=low, 1=high)",
        yaxis_title="Properties",
    )
    return fig


def build_neighbourhood_radar(neighbourhoods: pd.DataFrame, selected: list[str]) -> go.Figure:
    cats = ["school_rating", "transport_score", "green_space_pct", "liveability_index"]
    cats_available = [c for c in cats if c in neighbourhoods.columns]
    if not cats_available:
        return go.Figure()

    fig = go.Figure()
    for hood in selected[:5]:
        row = neighbourhoods[neighbourhoods["neighbourhood"] == hood]
        if row.empty:
            continue
        values = [float(row[c].values[0]) for c in cats_available]
        # Normalise each cat to 0–10 for radar
        fig.add_trace(go.Scatterpolar(
            r=values + [values[0]],
            theta=cats_available + [cats_available[0]],
            name=hood, fill="toself", opacity=0.7,
        ))

    fig.update_layout(
        **_dark_layout("Neighbourhood Quality Radar"),
        polar=dict(
            bgcolor=C["bg_panel"],
            radialaxis=dict(gridcolor=C["border"], color=C["muted"]),
            angularaxis=dict(gridcolor=C["border"]),
        ),
    )
    return fig


def build_scenario_bar(scenarios: list[dict]) -> go.Figure:
    if not scenarios:
        return go.Figure()
    df = pd.DataFrame(scenarios)
    fig = go.Figure(go.Bar(
        x=df["scenario"],
        y=df["new_avg_price"],
        marker_color=[C["green"] if v > df["original_avg_price"].iloc[0] else C["red"]
                      for v in df["new_avg_price"]],
        text=df["price_impact_pct"].apply(lambda x: f"{x:+.1f}%"),
        textposition="outside",
    ))
    fig.add_hline(y=df["original_avg_price"].iloc[0], line_dash="dash",
                  line_color=C["gold"], annotation_text="Baseline")
    fig.update_layout(
        **_dark_layout("Scenario Analysis — Impact on Avg Price"),
        yaxis=dict(tickprefix="£", tickformat=",.0s"),
    )
    return fig


def _dark_layout(title: str) -> dict:
    """Returns shared dark-theme layout kwargs for Plotly figures."""
    return dict(
        title=dict(text=title, font=dict(family=FONT_DISPLAY, size=16, color=C["cyan"])),
        paper_bgcolor=C["bg_card"],
        plot_bgcolor=C["bg_deep"],
        font=dict(family=FONT_BODY, color=C["text"], size=12),
        xaxis=dict(gridcolor=C["border"], zeroline=False),
        yaxis=dict(gridcolor=C["border"], zeroline=False),
        margin=dict(l=60, r=20, t=50, b=50),
        height=360,
    )


# ─────────────────────────────────────────────
# DASHBOARD FACTORY
# ─────────────────────────────────────────────


def create_dashboard(engine) -> dash.Dash:
    """
    Instantiates and returns the PropIntel Dash application.

    Parameters
    ----------
    engine : PropIntelEngine  (fully initialised with data)
    """

    app = dash.Dash(
        __name__,
        external_stylesheets=[
            dbc.themes.CYBORG,
            "https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@300;400&family=Inter:wght@300;400;600&display=swap",
        ],
        title="PropIntel",
        suppress_callback_exceptions=True,
    )

    props  = engine.data.get("properties", pd.DataFrame())
    hoods  = engine.data.get("neighbourhoods", pd.DataFrame())
    sales  = engine.data.get("sales_history", pd.DataFrame())
    kpis   = engine.kpis
    forecasts = engine.forecasts
    hotspots  = engine.hotspots
    portfolio = engine.portfolio

    hood_options = [{"label": h, "value": h} for h in sorted(props["neighbourhood"].dropna().unique())] if "neighbourhood" in props.columns else []

    # ── KPI tiles ──────────────────────────────────────────────────

    def kpis_row() -> html.Div:
        return html.Div([
            kpi_tile("Total Listings", f"{kpis.get('total_listings', 0):,}", "active"),
            kpi_tile("Median Price", format_currency(kpis.get("median_asking_price", 0)), "GBP"),
            kpi_tile("Avg £/sqm", f"£{kpis.get('avg_price_per_sqm', 0):,.0f}", "per m²"),
            kpi_tile("YoY Change", f"{kpis.get('avg_yoy_price_change_pct', 0):+.1f}%", "12 months",
                     f"{kpis.get('avg_yoy_price_change_pct', 0):+.1f}%",
                     kpis.get("avg_yoy_price_change_pct", 0) >= 0),
            kpi_tile("Avg Risk", f"{kpis.get('avg_property_risk', 0):.2f}", "0–1 scale"),
            kpi_tile("Active Areas", str(kpis.get("active_neighbourhoods", 0)), "neighbourhoods"),
        ], style={"display": "flex", "gap": "12px", "flexWrap": "wrap", "marginBottom": "24px"})

    # ── Layout ─────────────────────────────────────────────────────

    app.layout = html.Div([

        # ── Top Nav Bar ────────────────────────────────────────────
        html.Div([
            html.Div([
                html.Span("⬡", style={"color": C["gold"], "fontSize": "22px", "marginRight": "10px"}),
                html.Span("PROPINTEL", style={
                    "fontFamily": FONT_DISPLAY, "fontSize": "22px",
                    "letterSpacing": "6px", "color": C["gold"],
                }),
                html.Span("  REAL ESTATE INTELLIGENCE PLATFORM", style={
                    "fontFamily": FONT_MONO, "fontSize": "10px",
                    "color": C["muted"], "letterSpacing": "3px", "marginLeft": "12px",
                }),
            ], style={"display": "flex", "alignItems": "center"}),
            html.Div([
                html.Span("◆ LIVE", style={"color": C["green"], "fontFamily": FONT_MONO, "fontSize": "11px"}),
                html.Span("  |  AI MODEL: ACTIVE", style={"color": C["cyan"], "fontFamily": FONT_MONO, "fontSize": "11px"}),
            ]),
        ], style={
            "background": C["bg_card"],
            "borderBottom": f"1px solid {C['gold']}",
            "padding": "14px 32px",
            "display": "flex",
            "justifyContent": "space-between",
            "alignItems": "center",
        }),

        # ── Main Content ───────────────────────────────────────────
        html.Div([
            dcc.Tabs(id="main-tabs", value="tab-overview", style={"fontFamily": FONT_BODY},
                children=[
                    dcc.Tab(label="MARKET OVERVIEW",    value="tab-overview"),
                    dcc.Tab(label="MAP ANALYTICS",      value="tab-map"),
                    dcc.Tab(label="PRICE TRENDS",       value="tab-trends"),
                    dcc.Tab(label="NEIGHBOURHOODS",     value="tab-hoods"),
                    dcc.Tab(label="PORTFOLIO",          value="tab-portfolio"),
                    dcc.Tab(label="SCENARIOS",          value="tab-scenarios"),
                ],
                colors={"border": C["border"], "primary": C["gold"], "background": C["bg_deep"]},
            ),

            html.Div(id="tab-content", style={"padding": "24px"}),

        ], style={"background": C["bg_deep"], "minHeight": "calc(100vh - 60px)"}),

    ], style={"background": C["bg_deep"], "fontFamily": FONT_BODY})

    # ─────────────────────────────────────────────
    # CALLBACKS
    # ─────────────────────────────────────────────

    @app.callback(Output("tab-content", "children"), Input("main-tabs", "value"))
    def render_tab(tab):
        if tab == "tab-overview":
            return render_overview()
        elif tab == "tab-map":
            return render_map()
        elif tab == "tab-trends":
            return render_trends()
        elif tab == "tab-hoods":
            return render_neighbourhoods()
        elif tab == "tab-portfolio":
            return render_portfolio()
        elif tab == "tab-scenarios":
            return render_scenarios()
        return html.Div()

    # ── Tab renderers ──────────────────────────────────────────────

    def render_overview() -> html.Div:
        return html.Div([
            kpis_row(),
            html.Div([
                html.Div([
                    card([
                        section_header("Price Distribution", "Asking prices across all listings"),
                        dcc.Graph(figure=build_price_distribution_chart(props), config={"displayModeBar": False}),
                    ]),
                ], style={"flex": "1", "minWidth": "400px"}),
                html.Div([
                    card([
                        section_header("Risk Score Distribution", "Portfolio-wide risk profile"),
                        dcc.Graph(figure=build_risk_histogram(props), config={"displayModeBar": False}),
                    ]),
                ], style={"flex": "1", "minWidth": "400px"}),
            ], style={"display": "flex", "gap": "16px", "flexWrap": "wrap"}),
            card([
                section_header("AI Model Performance", f"Price Prediction R²: {engine.model_metrics.get('r2', 0):.3f} | MAE: £{engine.model_metrics.get('mae', 0):,.0f}"),
                html.Div([
                    html.Div([
                        html.P(f"R² Score", style={"color": C["muted"], "fontSize": "11px", "margin": "0 0 4px"}),
                        html.H4(f"{engine.model_metrics.get('r2', 0):.4f}", style={"color": C["green"], "fontFamily": FONT_MONO, "margin": 0}),
                    ], style={"flex": 1}),
                    html.Div([
                        html.P(f"MAE", style={"color": C["muted"], "fontSize": "11px", "margin": "0 0 4px"}),
                        html.H4(format_currency(engine.model_metrics.get("mae", 0)), style={"color": C["amber"], "fontFamily": FONT_MONO, "margin": 0}),
                    ], style={"flex": 1}),
                    html.Div([
                        html.P(f"RMSE", style={"color": C["muted"], "fontSize": "11px", "margin": "0 0 4px"}),
                        html.H4(format_currency(engine.model_metrics.get("rmse", 0)), style={"color": C["amber"], "fontFamily": FONT_MONO, "margin": 0}),
                    ], style={"flex": 1}),
                    html.Div([
                        html.P("Training Samples", style={"color": C["muted"], "fontSize": "11px", "margin": "0 0 4px"}),
                        html.H4(f"{engine.model_metrics.get('train_samples', 0):,}", style={"color": C["cyan"], "fontFamily": FONT_MONO, "margin": 0}),
                    ], style={"flex": 1}),
                ], style={"display": "flex", "gap": "32px"}),
            ]),
        ])

    def render_map() -> html.Div:
        return html.Div([
            card([
                section_header("Map Controls"),
                html.Div([
                    html.Div([
                        html.Label("Map Type", style={"color": C["muted"], "fontSize": "11px"}),
                        dcc.RadioItems(
                            id="map-type",
                            options=[
                                {"label": "Properties", "value": "scatter"},
                                {"label": "Price Density", "value": "density"},
                                {"label": "Risk Map", "value": "risk"},
                                {"label": "Area Bubbles", "value": "bubbles"},
                            ],
                            value="scatter",
                            inline=True,
                            style={"color": C["text"], "fontFamily": FONT_BODY, "fontSize": "13px"},
                            inputStyle={"marginRight": "6px", "marginLeft": "12px"},
                        ),
                    ], style={"flex": "2"}),
                    html.Div([
                        html.Label("Neighbourhood", style={"color": C["muted"], "fontSize": "11px"}),
                        dcc.Dropdown(
                            id="map-hood-filter",
                            options=[{"label": "All", "value": "ALL"}] + hood_options,
                            value="ALL",
                            style={"background": C["bg_panel"], "color": C["text"], "border": f"1px solid {C['border']}"},
                        ),
                    ], style={"flex": "1"}),
                ], style={"display": "flex", "gap": "24px", "alignItems": "flex-end"}),
            ], style={"marginBottom": "8px"}),
            card([dcc.Graph(id="main-map", style={"height": "600px"})], style={"padding": "8px"}),
        ])

    def render_trends() -> html.Div:
        return html.Div([
            card([
                section_header("Historical Price Trends & AI Forecast"),
                html.Label("Select Neighbourhoods:", style={"color": C["muted"], "fontSize": "11px"}),
                dcc.Dropdown(
                    id="trend-hood-select",
                    options=hood_options,
                    value=[h["value"] for h in hood_options[:4]],
                    multi=True,
                    style={"background": C["bg_panel"], "border": f"1px solid {C['border']}"},
                ),
                html.Div(style={"marginTop": "12px"}),
                dcc.Graph(id="trend-chart", config={"displayModeBar": False}),
            ]),
            card([
                section_header("AI Price Forecast", f"12-month forward projection with 95% CI"),
                dcc.Graph(figure=build_forecast_chart(sales, forecasts), config={"displayModeBar": False}),
            ]) if not forecasts.empty else html.Div(),
        ])

    def render_neighbourhoods() -> html.Div:
        if hoods.empty:
            return html.Div("No neighbourhood data available", style={"color": C["muted"]})

        hood_table_df = hoods.copy()
        display_cols = ["neighbourhood", "median_income_gbp", "crime_rate_per_1k",
                        "school_rating", "transport_score", "liveability_index",
                        "risk_score", "risk_label", "cluster_archetype"]
        display_cols = [c for c in display_cols if c in hood_table_df.columns]

        return html.Div([
            html.Div([
                html.Div([
                    card([
                        section_header("Investment Hotspots"),
                        html.Div([
                            html.Div([
                                html.Span(f"#{row.get('hotspot_rank', '?')}",
                                          style={"color": C["gold"], "fontFamily": FONT_MONO,
                                                 "fontSize": "20px", "marginRight": "12px"}),
                                html.Span(row.get("neighbourhood", ""),
                                          style={"color": C["text"], "fontFamily": FONT_DISPLAY, "fontSize": "16px"}),
                                html.Span(f"  Score: {row.get('hotspot_score', 0):.3f}",
                                          style={"color": C["cyan"], "fontFamily": FONT_MONO,
                                                 "fontSize": "12px", "marginLeft": "12px"}),
                            ], style={"display": "flex", "alignItems": "center", "marginBottom": "8px"})
                            for _, row in (hotspots[hotspots["is_hotspot"] == True].head(6).iterrows()
                                           if not hotspots.empty and "is_hotspot" in hotspots.columns
                                           else hoods.head(6).iterrows())
                        ]),
                    ]),
                ], style={"flex": "1"}),
                html.Div([
                    card([
                        section_header("Neighbourhood Radar", "Quality metrics comparison"),
                        dcc.Dropdown(
                            id="radar-hoods",
                            options=hood_options,
                            value=[h["value"] for h in hood_options[:3]],
                            multi=True,
                            style={"background": C["bg_panel"], "border": f"1px solid {C['border']}",
                                   "marginBottom": "12px"},
                        ),
                        dcc.Graph(id="radar-chart", config={"displayModeBar": False}),
                    ]),
                ], style={"flex": "1"}),
            ], style={"display": "flex", "gap": "16px", "flexWrap": "wrap"}),
            card([
                section_header("Neighbourhood Data Table"),
                dash.dash_table.DataTable(
                    data=hood_table_df[display_cols].round(3).to_dict("records"),
                    columns=[{"name": c.replace("_", " ").title(), "id": c} for c in display_cols],
                    style_table={"overflowX": "auto"},
                    style_header={
                        "backgroundColor": C["bg_panel"],
                        "color": C["gold"],
                        "fontFamily": FONT_MONO,
                        "fontSize": "11px",
                        "fontWeight": "bold",
                        "letterSpacing": "1px",
                        "border": f"1px solid {C['border']}",
                    },
                    style_data={
                        "backgroundColor": C["bg_card"],
                        "color": C["text"],
                        "fontFamily": FONT_MONO,
                        "fontSize": "12px",
                        "border": f"1px solid {C['border']}",
                    },
                    style_data_conditional=[
                        {"if": {"row_index": "odd"}, "backgroundColor": C["bg_panel"]},
                        {"if": {"filter_query": "{risk_label} = 'High'"},
                         "color": "#e67e22"},
                        {"if": {"filter_query": "{risk_label} = 'Very High'"},
                         "color": "#e74c3c"},
                        {"if": {"filter_query": "{risk_label} = 'Low'"},
                         "color": "#2ecc71"},
                    ],
                    page_size=12,
                    sort_action="native",
                    filter_action="native",
                ),
            ]),
        ])

    def render_portfolio() -> html.Div:
        summary = portfolio.summary()
        pos_df  = portfolio.to_dataframe()

        return html.Div([
            html.Div([
                kpi_tile("Portfolio Value", format_currency(summary.get("total_portfolio_value", 0)), "GBP"),
                kpi_tile("Total Equity", format_currency(summary.get("total_equity", 0))),
                kpi_tile("Capital Gain", f"{summary.get('portfolio_capital_gain_pct', 0):+.1f}%", "all properties",
                         f"{summary.get('portfolio_capital_gain_pct', 0):+.1f}%",
                         summary.get("portfolio_capital_gain_pct", 0) >= 0),
                kpi_tile("Gross Yield", f"{summary.get('portfolio_gross_yield_pct', 0):.2f}%", "annual"),
                kpi_tile("Monthly CF", format_currency(summary.get("total_monthly_cashflow", 0)), "net cashflow"),
                kpi_tile("Properties", str(summary.get("n_properties", 0)), "in portfolio"),
            ], style={"display": "flex", "gap": "12px", "flexWrap": "wrap", "marginBottom": "24px"}),
            html.Div([
                html.Div([
                    card([
                        section_header("Return Waterfall"),
                        dcc.Graph(figure=build_roi_waterfall(summary), config={"displayModeBar": False}),
                    ]),
                ], style={"flex": "1"}),
                html.Div([
                    card([
                        section_header("Position Performance"),
                        html.Div([
                            html.Div([
                                html.Span(row.get("property_id", ""), style={"color": C["cyan"], "fontFamily": FONT_MONO, "fontSize": "12px"}),
                                html.Span(f"  +{row.get('capital_gain_pct', 0):.1f}%",
                                          style={"color": C["green"] if row.get("capital_gain_pct", 0) >= 0 else C["red"],
                                                 "fontFamily": FONT_MONO, "fontSize": "12px"}),
                                html.Br(),
                                html.Span(f"£{row.get('current_value', 0):,.0f}  |  Yield {row.get('gross_yield_pct', 0):.2f}%",
                                          style={"color": C["muted"], "fontSize": "11px"}),
                            ], style={"padding": "8px 0", "borderBottom": f"1px solid {C['border']}"})
                            for _, row in pos_df.iterrows()
                        ] if not pos_df.empty else [html.P("No positions", style={"color": C["muted"]})]),
                    ]),
                ], style={"flex": "1"}),
            ], style={"display": "flex", "gap": "16px", "flexWrap": "wrap"}),
        ])

    def render_scenarios() -> html.Div:
        rate_scenarios = [
            engine.run_rate_scenario(r) for r in [-2, -1, 0, 1, 2, 3]
        ]
        return html.Div([
            card([
                section_header("Scenario Simulation Engine", "What-if analysis for market shocks"),
                html.Div([
                    html.Div([
                        html.Label("Interest Rate Change (%)", style={"color": C["muted"], "fontSize": "11px"}),
                        dcc.Slider(
                            id="rate-slider", min=-3, max=5, step=0.5, value=1,
                            marks={i: {"label": f"{i:+d}%", "style": {"color": C["muted"]}}
                                   for i in range(-3, 6)},
                        ),
                    ], style={"flex": 2}),
                    html.Div([
                        html.Label("SDLT Change (%)", style={"color": C["muted"], "fontSize": "11px"}),
                        dcc.Slider(
                            id="sdlt-slider", min=-5, max=5, step=0.5, value=0,
                            marks={i: {"label": f"{i:+d}%", "style": {"color": C["muted"]}}
                                   for i in range(-5, 6)},
                        ),
                    ], style={"flex": 1}),
                    html.Div([
                        html.Label("Supply Increase (%)", style={"color": C["muted"], "fontSize": "11px"}),
                        dcc.Slider(
                            id="supply-slider", min=0, max=30, step=1, value=5,
                            marks={i: {"label": f"{i}%", "style": {"color": C["muted"]}}
                                   for i in [0, 10, 20, 30]},
                        ),
                    ], style={"flex": 1}),
                ], style={"display": "flex", "gap": "32px", "flexWrap": "wrap", "marginBottom": "24px"}),
                html.Div(id="scenario-result", style={"marginTop": "16px"}),
            ]),
            card([
                section_header("Rate Scenarios — Market Impact"),
                dcc.Graph(figure=build_scenario_bar(rate_scenarios), config={"displayModeBar": False}),
            ]),
        ])

    # ── Dynamic callbacks ──────────────────────────────────────────

    @app.callback(Output("main-map", "figure"),
                  [Input("map-type", "value"), Input("map-hood-filter", "value")])
    def update_map(map_type, hood_filter):
        filt = None if hood_filter == "ALL" else hood_filter
        if map_type == "scatter":
            return build_property_scatter_map(props, colour_by="price_gbp", filter_neighbourhood=filt)
        elif map_type == "density":
            p = props if not filt else props[props["neighbourhood"] == filt]
            return build_price_density_map(p)
        elif map_type == "risk":
            return build_risk_scatter_map(props)
        elif map_type == "bubbles":
            return build_neighbourhood_bubble_map(props, hoods)
        return go.Figure()

    @app.callback(Output("trend-chart", "figure"), Input("trend-hood-select", "value"))
    def update_trend_chart(selected_hoods):
        return build_price_history_chart(sales, selected_hoods)

    @app.callback(Output("radar-chart", "figure"), Input("radar-hoods", "value"))
    def update_radar(selected_hoods):
        return build_neighbourhood_radar(hoods, selected_hoods or [])

    @app.callback(Output("scenario-result", "children"),
                  [Input("rate-slider", "value"),
                   Input("sdlt-slider", "value"),
                   Input("supply-slider", "value")])
    def update_scenario(rate, sdlt, supply):
        r = engine.run_rate_scenario(rate)
        t = engine.run_tax_scenario(sdlt)
        s = engine.run_supply_scenario(supply)
        combined_impact = r["price_impact_pct"] + t["price_impact_pct"] + s["price_impact_pct"]

        return html.Div([
            html.Div([
                html.Div([
                    html.P("Rate Impact", style={"color": C["muted"], "fontSize": "11px", "margin": 0}),
                    html.H3(f"{r['price_impact_pct']:+.1f}%",
                            style={"fontFamily": FONT_MONO, "color": C["green"] if r["price_impact_pct"] >= 0 else C["red"], "margin": 0}),
                ], style={"flex": 1}),
                html.Div([
                    html.P("SDLT Impact", style={"color": C["muted"], "fontSize": "11px", "margin": 0}),
                    html.H3(f"{t['price_impact_pct']:+.1f}%",
                            style={"fontFamily": FONT_MONO, "color": C["green"] if t["price_impact_pct"] >= 0 else C["red"], "margin": 0}),
                ], style={"flex": 1}),
                html.Div([
                    html.P("Supply Impact", style={"color": C["muted"], "fontSize": "11px", "margin": 0}),
                    html.H3(f"{s['price_impact_pct']:+.1f}%",
                            style={"fontFamily": FONT_MONO, "color": C["green"] if s["price_impact_pct"] >= 0 else C["red"], "margin": 0}),
                ], style={"flex": 1}),
                html.Div([
                    html.P("Combined Impact", style={"color": C["muted"], "fontSize": "11px", "margin": 0}),
                    html.H3(f"{combined_impact:+.1f}%",
                            style={"fontFamily": FONT_MONO, "fontSize": "28px",
                                   "color": C["green"] if combined_impact >= 0 else C["red"], "margin": 0}),
                ], style={"flex": 1}),
                html.Div([
                    html.P("New Avg Price", style={"color": C["muted"], "fontSize": "11px", "margin": 0}),
                    html.H3(format_currency(r["new_avg_price"] * (1 + combined_impact / 100)),
                            style={"fontFamily": FONT_MONO, "color": C["gold"], "margin": 0}),
                ], style={"flex": 1}),
            ], style={"display": "flex", "gap": "24px", "flexWrap": "wrap",
                      "padding": "16px", "background": C["bg_panel"],
                      "borderRadius": "4px", "border": f"1px solid {C['border']}"}),
        ])

    return app


# ─────────────────────────────────────────────
# STANDALONE ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    from core import PropIntelEngine
    engine = PropIntelEngine(use_mock=True)
    engine.run_full_pipeline()
    app = create_dashboard(engine)
    app.run(debug=False, host=CONFIG["dash_host"], port=CONFIG["dash_port"])
