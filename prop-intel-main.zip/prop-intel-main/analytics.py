"""
analytics.py — PropIntel Analytics Engine
Market trend analysis, KPI computation, scenario simulation,
and neighbourhood hotspot identification.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from utils import get_logger, CONFIG, safe_divide, pct_change, format_currency

log = get_logger("analytics")


# ─────────────────────────────────────────────
# MARKET KPI ENGINE
# ─────────────────────────────────────────────


class MarketKPIEngine:
    """
    Computes top-level market KPIs from cleaned property and sales data.
    Output is a flat dict suitable for a dashboard header row.
    """

    def compute(
        self,
        properties: pd.DataFrame,
        sales_history: pd.DataFrame,
        neighbourhoods: pd.DataFrame,
    ) -> dict:
        kpis: dict = {}

        # ── Total market value ────────────────────────────────────
        if "price_gbp" in properties.columns:
            kpis["total_listings"] = len(properties)
            kpis["avg_asking_price"] = int(properties["price_gbp"].mean())
            kpis["median_asking_price"] = int(properties["price_gbp"].median())
            kpis["total_market_value"] = int(properties["price_gbp"].sum())

        # ── Price per sqm ─────────────────────────────────────────
        if "price_per_sqm" in properties.columns:
            kpis["avg_price_per_sqm"] = int(properties["price_per_sqm"].mean())

        # ── Recent market velocity ────────────────────────────────
        if "days_on_market" in properties.columns:
            kpis["avg_days_on_market"] = round(properties["days_on_market"].mean(), 1)

        # ── YoY price change from sales history ───────────────────
        if not sales_history.empty and "avg_sale_price" in sales_history.columns:
            sh = sales_history.copy()
            sh["date"] = pd.to_datetime(sh["date"])
            latest = sh.sort_values("date").groupby("neighbourhood")["avg_sale_price"].last()
            year_ago = (
                sh[sh["date"] <= (sh["date"].max() - pd.DateOffset(years=1))]
                .sort_values("date")
                .groupby("neighbourhood")["avg_sale_price"]
                .last()
            )
            common = latest.index.intersection(year_ago.index)
            if len(common):
                yoy = ((latest[common] - year_ago[common]) / year_ago[common] * 100).mean()
                kpis["avg_yoy_price_change_pct"] = round(yoy, 2)

        # ── Risk metrics ──────────────────────────────────────────
        if "risk_score" in properties.columns:
            kpis["avg_property_risk"] = round(properties["risk_score"].mean(), 3)
            kpis["high_risk_pct"] = round(
                (properties["risk_score"] > 0.5).mean() * 100, 1
            )

        # ── Neighbourhood summary ─────────────────────────────────
        kpis["active_neighbourhoods"] = properties["neighbourhood"].nunique() if "neighbourhood" in properties.columns else 0

        log.info(f"Market KPIs computed: {list(kpis.keys())}")
        return kpis


# ─────────────────────────────────────────────
# NEIGHBOURHOOD TREND ANALYSER
# ─────────────────────────────────────────────


class NeighbourhoodTrendAnalyser:
    """
    Computes trend metrics per neighbourhood from sales history:
    - Compound annual growth rate (CAGR)
    - 6-month and 12-month price appreciation
    - Momentum (acceleration of growth)
    - Volume trend
    """

    def analyse(self, sales_history: pd.DataFrame) -> pd.DataFrame:
        if sales_history.empty:
            return pd.DataFrame()

        sh = sales_history.copy()
        sh["date"] = pd.to_datetime(sh["date"])
        sh = sh.sort_values(["neighbourhood", "date"])

        results = []
        for hood, g in sh.groupby("neighbourhood"):
            g = g.set_index("date")["avg_sale_price"]
            rec = {"neighbourhood": hood}

            # CAGR over full period
            if len(g) >= 24:
                start, end = g.iloc[0], g.iloc[-1]
                years = (g.index[-1] - g.index[0]).days / 365.25
                rec["cagr_pct"] = round(
                    (safe_divide(end, start) ** safe_divide(1, years) - 1) * 100, 2
                )

            # 12m & 6m appreciation
            latest_date = g.index.max()
            try:
                p_12m = g.asof(latest_date - pd.DateOffset(months=12))
                p_6m  = g.asof(latest_date - pd.DateOffset(months=6))
                p_now = g.iloc[-1]
                rec["appreciation_12m_pct"] = round(pct_change(p_12m, p_now), 2)
                rec["appreciation_6m_pct"]  = round(pct_change(p_6m, p_now), 2)
            except Exception:
                pass

            # Momentum: difference between 6m and prior 6m growth
            try:
                p_18m = g.asof(latest_date - pd.DateOffset(months=18))
                rec["momentum"] = round(
                    rec.get("appreciation_6m_pct", 0)
                    - pct_change(p_18m, p_12m), 2
                )
            except Exception:
                pass

            results.append(rec)

        df = pd.DataFrame(results)
        log.info(f"Trend analysis complete for {len(df)} neighbourhoods")
        return df


# ─────────────────────────────────────────────
# HOTSPOT DETECTOR
# ─────────────────────────────────────────────


class HotspotDetector:
    """
    Identifies investment hotspot neighbourhoods by combining:
    - Price appreciation momentum
    - Transaction volume growth
    - Liveability index
    - Low current risk score
    """

    def detect(
        self,
        trend_df: pd.DataFrame,
        neighbourhoods: pd.DataFrame,
    ) -> pd.DataFrame:
        df = trend_df.copy()

        # Merge with neighbourhood data
        merge_cols = ["neighbourhood"]
        for c in ["liveability_index", "risk_score", "planning_activity_score"]:
            if c in neighbourhoods.columns:
                merge_cols.append(c)

        df = df.merge(neighbourhoods[merge_cols], on="neighbourhood", how="left")

        # Hotspot score: reward growth, liveability, low risk
        score_parts = []
        if "cagr_pct" in df.columns:
            score_parts.append(self._norm(df["cagr_pct"].fillna(0)) * 0.30)
        if "momentum" in df.columns:
            score_parts.append(self._norm(df["momentum"].fillna(0)) * 0.25)
        if "liveability_index" in df.columns:
            score_parts.append(df["liveability_index"].fillna(0.5) * 0.25)
        if "risk_score" in df.columns:
            score_parts.append((1 - df["risk_score"].fillna(0.5)) * 0.20)

        if score_parts:
            df["hotspot_score"] = sum(score_parts).round(3)
        else:
            df["hotspot_score"] = 0.0

        df = df.sort_values("hotspot_score", ascending=False)
        df["hotspot_rank"] = range(1, len(df) + 1)
        df["is_hotspot"] = df["hotspot_rank"] <= max(1, len(df) // 3)

        log.info(f"Hotspots detected: {df['is_hotspot'].sum()} of {len(df)} neighbourhoods")
        return df

    @staticmethod
    def _norm(s: pd.Series) -> pd.Series:
        rng = s.max() - s.min()
        return (s - s.min()) / rng if rng > 0 else pd.Series(0.5, index=s.index)


# ─────────────────────────────────────────────
# SCENARIO SIMULATION ENGINE
# ─────────────────────────────────────────────


class ScenarioSimulator:
    """
    Monte Carlo and deterministic scenario simulation for property market analysis.

    Supports:
    - Interest rate shock scenarios
    - Tax policy changes (SDLT)
    - Urban development impact
    - Demand/supply shifts
    """

    def __init__(self, n_simulations: int | None = None):
        self.n_sim = n_simulations or CONFIG.get("scenario_monte_carlo_runs", 1_000)

    def run_interest_rate_scenario(
        self,
        properties: pd.DataFrame,
        rate_change_pct: float,
        holding_years: int = 5,
    ) -> dict:
        """
        Estimates impact of an interest rate change on property values.

        Higher rates → reduced affordability → price pressure.
        Rule-of-thumb: each 1% rate rise reduces affordability by ~7–10%.
        """
        sensitivity = -0.08  # 8% price drop per 1% rate rise
        price_impact_pct = rate_change_pct * sensitivity * 100

        if "price_gbp" in properties.columns:
            original_avg = properties["price_gbp"].mean()
            new_avg = original_avg * (1 + price_impact_pct / 100)
        else:
            original_avg = new_avg = 0

        # Monte Carlo: add noise to simulate path uncertainty
        rng = np.random.default_rng(0)
        annual_returns = rng.normal(
            loc=price_impact_pct / holding_years / 100,
            scale=0.08,
            size=(self.n_sim, holding_years),
        )
        terminal_values = original_avg * np.prod(1 + annual_returns, axis=1)

        return {
            "scenario": f"Rate change {rate_change_pct:+.1f}%",
            "rate_change_pct": rate_change_pct,
            "price_impact_pct": round(price_impact_pct, 2),
            "original_avg_price": int(original_avg),
            "new_avg_price": int(new_avg),
            "mc_mean": int(terminal_values.mean()),
            "mc_p5": int(np.percentile(terminal_values, 5)),
            "mc_p95": int(np.percentile(terminal_values, 95)),
            "mc_distribution": terminal_values.tolist()[:200],  # sample for charting
        }

    def run_tax_scenario(
        self,
        properties: pd.DataFrame,
        sdlt_change_pct: float,
    ) -> dict:
        """
        Simulates the impact of SDLT (stamp duty) changes on transaction volume
        and effective pricing.
        """
        # Higher SDLT reduces effective demand by ~5% per 1% SDLT increase
        demand_impact = -0.05 * sdlt_change_pct
        price_impact = demand_impact * 0.6  # prices absorb ~60% of demand shock

        if "price_gbp" in properties.columns:
            original_avg = properties["price_gbp"].mean()
            new_avg = original_avg * (1 + price_impact)
        else:
            original_avg = new_avg = 0

        return {
            "scenario": f"SDLT change {sdlt_change_pct:+.1f}%",
            "sdlt_change_pct": sdlt_change_pct,
            "demand_impact_pct": round(demand_impact * 100, 2),
            "price_impact_pct": round(price_impact * 100, 2),
            "original_avg_price": int(original_avg),
            "new_avg_price": int(new_avg),
        }

    def run_supply_shock_scenario(
        self,
        properties: pd.DataFrame,
        new_units_pct: float,
    ) -> dict:
        """
        Simulates the impact of a supply increase (new housing units) on prices.
        +10% supply → ~3–5% price decline historically.
        """
        price_impact_pct = -0.4 * new_units_pct  # 0.4% drop per 1% supply increase

        if "price_gbp" in properties.columns:
            original_avg = properties["price_gbp"].mean()
            new_avg = original_avg * (1 + price_impact_pct / 100)
        else:
            original_avg = new_avg = 0

        return {
            "scenario": f"Supply +{new_units_pct:.1f}%",
            "new_units_pct": new_units_pct,
            "price_impact_pct": round(price_impact_pct, 2),
            "original_avg_price": int(original_avg),
            "new_avg_price": int(new_avg),
        }
