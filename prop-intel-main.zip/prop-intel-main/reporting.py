"""
reporting.py — PropIntel Reporting Engine
Generates PDF executive summaries and Excel data exports.
Uses ReportLab for PDFs and openpyxl for Excel workbooks.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from utils import get_logger, ensure_dir, timestamp_slug, format_currency, CONFIG

log = get_logger("reporting")

REPORTS_DIR = ensure_dir(CONFIG.get("reports_dir", "reports"))


# ─────────────────────────────────────────────
# EXCEL REPORTER
# ─────────────────────────────────────────────


class ExcelReporter:
    """
    Exports cleaned DataFrames and analytics results into a multi-sheet
    Excel workbook with styled headers and auto-fitted columns.
    """

    def export(
        self,
        data: dict[str, pd.DataFrame],
        kpis: dict | None = None,
        filename: str | None = None,
    ) -> Path:
        filename = filename or f"propintel_report_{timestamp_slug()}.xlsx"
        out_path = REPORTS_DIR / filename

        with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
            # ── KPI summary sheet ──────────────────────────────
            if kpis:
                kpi_df = pd.DataFrame([kpis]).T.reset_index()
                kpi_df.columns = ["Metric", "Value"]
                kpi_df.to_excel(writer, sheet_name="KPI Summary", index=False)
                self._style_sheet(writer, "KPI Summary", kpi_df)

            # ── Data sheets ───────────────────────────────────
            for sheet_name, df in data.items():
                if df.empty:
                    continue
                # Truncate to 100k rows for Excel limit safety
                df_out = df.head(100_000)
                df_out.to_excel(writer, sheet_name=sheet_name[:31], index=False)
                self._style_sheet(writer, sheet_name[:31], df_out)

        log.info(f"Excel report exported: {out_path}")
        return out_path

    @staticmethod
    def _style_sheet(writer: pd.ExcelWriter, sheet_name: str, df: pd.DataFrame) -> None:
        """Applies column auto-fit and header bold styling."""
        try:
            from openpyxl.styles import Font, PatternFill, Alignment
            ws = writer.sheets[sheet_name]

            # Bold header row
            header_fill = PatternFill("solid", fgColor="1a1a2e")
            for cell in ws[1]:
                cell.font = Font(bold=True, color="C9A84C")
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")

            # Auto-fit column widths
            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 40)
        except Exception as e:
            log.debug(f"Sheet styling skipped: {e}")


# ─────────────────────────────────────────────
# TEXT / MARKDOWN REPORT
# ─────────────────────────────────────────────


class MarkdownReporter:
    """
    Generates a plain-text Markdown executive summary report.
    Useful for logging pipelines and CI environments without GUI.
    """

    def export(
        self,
        kpis: dict,
        trend_df: pd.DataFrame | None = None,
        hotspots: pd.DataFrame | None = None,
        portfolio_summary: dict | None = None,
        filename: str | None = None,
    ) -> Path:
        filename = filename or f"propintel_summary_{timestamp_slug()}.md"
        out_path = REPORTS_DIR / filename

        lines = [
            "# PropIntel — Market Intelligence Report",
            f"*Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}*",
            "",
            "---",
            "",
            "## Market KPIs",
            "",
        ]

        for k, v in kpis.items():
            label = k.replace("_", " ").title()
            if isinstance(v, float):
                lines.append(f"- **{label}**: {v:.2f}")
            elif isinstance(v, int) and v > 1000:
                lines.append(f"- **{label}**: {format_currency(v)}")
            else:
                lines.append(f"- **{label}**: {v}")

        if trend_df is not None and not trend_df.empty:
            lines += ["", "## Neighbourhood Trends (Top 5 by CAGR)", ""]
            top5 = trend_df.nlargest(5, "cagr_pct") if "cagr_pct" in trend_df.columns else trend_df.head(5)
            for _, row in top5.iterrows():
                lines.append(
                    f"- **{row.get('neighbourhood', '?')}**: "
                    f"CAGR {row.get('cagr_pct', 0):.1f}% | "
                    f"12m Appreciation {row.get('appreciation_12m_pct', 0):.1f}%"
                )

        if hotspots is not None and not hotspots.empty:
            lines += ["", "## Investment Hotspots", ""]
            hot = hotspots[hotspots.get("is_hotspot", True) == True] if "is_hotspot" in hotspots.columns else hotspots.head(3)
            for _, row in hot.iterrows():
                lines.append(
                    f"- **{row.get('neighbourhood', '?')}**: "
                    f"Score {row.get('hotspot_score', 0):.3f} | "
                    f"Rank #{row.get('hotspot_rank', '?')}"
                )

        if portfolio_summary:
            lines += ["", "## Portfolio Summary", ""]
            for k, v in portfolio_summary.items():
                label = k.replace("_", " ").title()
                lines.append(f"- **{label}**: {v}")

        lines += ["", "---", "*PropIntel — AI-powered Real Estate Intelligence Platform*"]

        out_path.write_text("\n".join(lines), encoding="utf-8")
        log.info(f"Markdown report exported: {out_path}")
        return out_path


# ─────────────────────────────────────────────
# CSV EXPORTER
# ─────────────────────────────────────────────


def export_csv(df: pd.DataFrame, name: str) -> Path:
    """Quick utility — exports a DataFrame to CSV in the reports directory."""
    out = REPORTS_DIR / f"{name}_{timestamp_slug()}.csv"
    df.to_csv(out, index=False)
    log.info(f"CSV exported: {out}")
    return out
