"""
main.py — PropIntel Entry Point
CLI runner and scheduler for the PropIntel BI platform.

Usage:
  python main.py                         # run pipeline + launch dashboard
  python main.py --pipeline-only         # run pipeline, no dashboard
  python main.py --report-only           # just generate reports
  python main.py --port 8080             # launch on custom port
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Add propintel package to path when running from project root
sys.path.insert(0, str(Path(__file__).parent))

from utils import get_logger, CONFIG, ensure_dir
from core import PropIntelEngine
from reporting import ExcelReporter, MarkdownReporter

log = get_logger("main")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PropIntel Real Estate Intelligence Platform")
    parser.add_argument("--pipeline-only", action="store_true",
                        help="Run data pipeline without launching dashboard")
    parser.add_argument("--report-only", action="store_true",
                        help="Generate reports only (skip dashboard)")
    parser.add_argument("--port", type=int, default=CONFIG["dash_port"],
                        help=f"Dashboard port (default: {CONFIG['dash_port']})")
    parser.add_argument("--host", default=CONFIG["dash_host"],
                        help=f"Dashboard host (default: {CONFIG['dash_host']})")
    parser.add_argument("--no-mock", action="store_true",
                        help="Use real data sources (requires configuration)")
    parser.add_argument("--export-excel", action="store_true",
                        help="Export Excel report after pipeline run")
    parser.add_argument("--export-markdown", action="store_true",
                        help="Export Markdown summary report")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ensure_dir("logs")
    ensure_dir("reports")
    ensure_dir("data")

    log.info("━" * 60)
    log.info("  PropIntel — Real Estate Intelligence Platform")
    log.info("━" * 60)

    # ── Initialise & run pipeline ──────────────────────────────────
    use_mock = not args.no_mock
    engine = PropIntelEngine(use_mock=use_mock)
    engine.run_full_pipeline()

    # ── Reports ───────────────────────────────────────────────────
    if args.export_excel or args.report_only:
        reporter = ExcelReporter()
        path = reporter.export(
            data={
                "Properties":     engine.data.get("properties", __import__("pandas").DataFrame()),
                "Sales History":  engine.data.get("sales_history", __import__("pandas").DataFrame()),
                "Neighbourhoods": engine.data.get("neighbourhoods", __import__("pandas").DataFrame()),
                "Economics":      engine.data.get("economics", __import__("pandas").DataFrame()),
                "Forecasts":      engine.forecasts,
                "Hotspots":       engine.hotspots,
            },
            kpis=engine.kpis,
        )
        log.info(f"Excel report: {path}")

    if args.export_markdown or args.report_only:
        md_reporter = MarkdownReporter()
        path = md_reporter.export(
            kpis=engine.kpis,
            trend_df=engine.trend_df,
            hotspots=engine.hotspots,
            portfolio_summary=engine.portfolio.summary(),
        )
        log.info(f"Markdown report: {path}")

    if args.pipeline_only or args.report_only:
        log.info("Pipeline complete. Exiting.")
        return

    # ── Launch Dashboard ──────────────────────────────────────────
    from dashboard import create_dashboard
    app = create_dashboard(engine)

    log.info(f"Dashboard launching → http://{args.host}:{args.port}")
    app.run(debug=False, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
