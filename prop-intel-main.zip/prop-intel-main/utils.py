"""
utils.py — PropIntel Utility Layer
Centralised logging, configuration, constants, and helper functions
for all PropIntel modules.
"""

from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)


def get_logger(name: str, level: int = logging.DEBUG) -> logging.Logger:
    """
    Returns a configured logger that writes to both stdout and a rotating
    log file under logs/<name>.log.
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # already configured

    logger.setLevel(level)
    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File handler
    fh = logging.FileHandler(LOG_DIR / f"{name}.log", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger


# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

DEFAULT_CONFIG: dict[str, Any] = {
    # --- Database ---
    "db_url": "sqlite:///propintel.db",
    "es_host": "localhost",
    "es_port": 9200,
    # --- Data paths ---
    "data_dir": "data",
    "reports_dir": "reports",
    # --- Analytics ---
    "forecast_horizon_months": 12,
    "clustering_n_clusters": 8,
    "anomaly_contamination": 0.05,
    "risk_weights": {
        "flood": 0.20,
        "crime": 0.25,
        "price_volatility": 0.20,
        "regulatory": 0.15,
        "school_quality": 0.10,
        "transport": 0.10,
    },
    # --- Portfolio ---
    "default_discount_rate": 0.08,
    "default_holding_years": 5,
    # --- Dashboard ---
    "dash_host": "127.0.0.1",
    "dash_port": 8050,
    "mapbox_style": "carto-darkmatter",
    # --- Simulation ---
    "scenario_monte_carlo_runs": 1_000,
}


def load_config(path: str | None = None) -> dict[str, Any]:
    """
    Loads config from a JSON file, merging over defaults.
    Falls back to defaults if file not found.
    """
    cfg = DEFAULT_CONFIG.copy()
    if path and Path(path).exists():
        with open(path) as f:
            overrides = json.load(f)
        cfg.update(overrides)
    return cfg


CONFIG = load_config()


# ─────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Returns numerator / denominator, or default if denominator is zero."""
    return numerator / denominator if denominator != 0 else default


def pct_change(old: float, new: float) -> float:
    """Returns percentage change from old to new value."""
    return safe_divide(new - old, old) * 100


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamps value to [lo, hi]."""
    return max(lo, min(hi, value))


def normalise_series(s: pd.Series) -> pd.Series:
    """Min-max normalises a pandas Series to [0, 1]."""
    rng = s.max() - s.min()
    return (s - s.min()) / rng if rng != 0 else pd.Series(0.5, index=s.index)


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Haversine formula — returns the great-circle distance in kilometres
    between two lat/lon points.
    """
    R = 6_371.0  # Earth radius in km
    φ1, φ2 = np.radians(lat1), np.radians(lat2)
    Δφ = np.radians(lat2 - lat1)
    Δλ = np.radians(lon2 - lon1)
    a = np.sin(Δφ / 2) ** 2 + np.cos(φ1) * np.cos(φ2) * np.sin(Δλ / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


def timestamp_slug() -> str:
    """Returns a compact ISO timestamp suitable for filenames."""
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


def ensure_dir(path: str | Path) -> Path:
    """Creates directory if it doesn't exist, returns Path."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def format_currency(value: float, symbol: str = "£") -> str:
    """Returns a human-readable currency string, e.g. £1.23M."""
    if abs(value) >= 1_000_000:
        return f"{symbol}{value / 1_000_000:.2f}M"
    if abs(value) >= 1_000:
        return f"{symbol}{value / 1_000:.1f}K"
    return f"{symbol}{value:.0f}"
