"""
geospatial.py — PropIntel Geospatial Analytics & Visualisation
Builds Plotly map figures: property scatter maps, price heatmaps,
risk overlays, and neighbourhood choropleth layers.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from utils import get_logger, CONFIG

log = get_logger("geospatial")

# Map style — defaults to open-source (no API key required)
MAP_STYLE = "open-street-map"

# Colour scales
PRICE_SCALE   = "Plasma"
RISK_SCALE    = [[0, "#2ecc71"], [0.33, "#f39c12"], [0.66, "#e67e22"], [1, "#e74c3c"]]
HOTSPOT_SCALE = "YlOrRd"


# ─────────────────────────────────────────────
# PROPERTY SCATTER MAP
# ─────────────────────────────────────────────


def build_property_scatter_map(
    properties: pd.DataFrame,
    colour_by: str = "price_gbp",
    size_by: str | None = None,
    filter_neighbourhood: str | None = None,
    max_points: int = 1_500,
) -> go.Figure:
    """
    Creates an interactive scatter map of property listings.

    Parameters
    ----------
    colour_by           : column name to use for marker colour
    size_by             : column name to use for marker size (optional)
    filter_neighbourhood: if set, only show this neighbourhood
    max_points          : cap plotted points for performance

    Returns a Plotly Figure.
    """
    df = properties.copy()
    if filter_neighbourhood:
        df = df[df["neighbourhood"] == filter_neighbourhood]

    # Drop rows without coordinates
    df = df.dropna(subset=["lat", "lon"])

    # Sample if too large
    if len(df) > max_points:
        df = df.sample(max_points, random_state=42)

    if df.empty:
        return go.Figure()

    hover_cols = [c for c in ["property_id", "neighbourhood", "property_type",
                               "bedrooms", "price_gbp", "risk_score"] if c in df.columns]

    fig = px.scatter_mapbox(
        df,
        lat="lat",
        lon="lon",
        color=colour_by if colour_by in df.columns else None,
        size=size_by if size_by and size_by in df.columns else None,
        hover_data={c: True for c in hover_cols},
        color_continuous_scale=PRICE_SCALE,
        size_max=14,
        zoom=10,
        height=580,
        mapbox_style=MAP_STYLE,
    )

    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 0, "b": 0},
        coloraxis_colorbar=dict(title=colour_by.replace("_", " ").title()),
        paper_bgcolor="#1a1a2e",
        plot_bgcolor="#1a1a2e",
        font_color="#e0e0e0",
    )
    log.info(f"Property scatter map built: {len(df):,} points")
    return fig


# ─────────────────────────────────────────────
# PRICE HEATMAP (density)
# ─────────────────────────────────────────────


def build_price_density_map(properties: pd.DataFrame) -> go.Figure:
    """
    Creates a density heatmap showing property price concentration.
    """
    df = properties.dropna(subset=["lat", "lon", "price_gbp"]).copy()

    # Weight by price (normalised)
    max_price = df["price_gbp"].max()
    df["weight"] = df["price_gbp"] / max_price if max_price > 0 else 1

    fig = go.Figure(go.Densitymapbox(
        lat=df["lat"],
        lon=df["lon"],
        z=df["weight"],
        radius=22,
        colorscale=PRICE_SCALE,
        showscale=True,
        colorbar=dict(title="Price Density"),
    ))

    fig.update_layout(
        mapbox_style=MAP_STYLE,
        mapbox=dict(center=dict(lat=df["lat"].mean(), lon=df["lon"].mean()), zoom=10),
        margin={"l": 0, "r": 0, "t": 0, "b": 0},
        height=580,
        paper_bgcolor="#1a1a2e",
        font_color="#e0e0e0",
    )
    log.info("Price density heatmap built")
    return fig


# ─────────────────────────────────────────────
# RISK MAP
# ─────────────────────────────────────────────


def build_risk_scatter_map(properties: pd.DataFrame) -> go.Figure:
    """
    Scatter map with properties colour-coded by risk_score.
    """
    df = properties.dropna(subset=["lat", "lon"]).copy()

    if "risk_score" not in df.columns:
        df["risk_score"] = 0.5

    fig = px.scatter_mapbox(
        df,
        lat="lat",
        lon="lon",
        color="risk_score",
        color_continuous_scale=RISK_SCALE,
        range_color=[0, 1],
        hover_data={c: True for c in ["property_id", "neighbourhood", "risk_label", "price_gbp"]
                    if c in df.columns},
        zoom=10,
        height=580,
        mapbox_style=MAP_STYLE,
    )
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 0, "b": 0},
        coloraxis_colorbar=dict(title="Risk Score", tickformat=".2f"),
        paper_bgcolor="#1a1a2e",
        font_color="#e0e0e0",
    )
    return fig


# ─────────────────────────────────────────────
# NEIGHBOURHOOD BUBBLE MAP
# ─────────────────────────────────────────────


def build_neighbourhood_bubble_map(
    properties: pd.DataFrame,
    neighbourhoods: pd.DataFrame,
    metric: str = "hotspot_score",
) -> go.Figure:
    """
    Bubble map with one marker per neighbourhood.
    Bubble size = average price; colour = chosen metric.
    """
    hood_agg = (
        properties.groupby("neighbourhood")
        .agg(avg_price=("price_gbp", "mean"), lat=("lat", "mean"), lon=("lon", "mean"), count=("price_gbp", "count"))
        .reset_index()
    )
    df = hood_agg.merge(neighbourhoods, on="neighbourhood", how="left")

    colour_col = metric if metric in df.columns else "avg_price"

    fig = px.scatter_mapbox(
        df,
        lat="lat",
        lon="lon",
        size="avg_price",
        color=colour_col,
        hover_name="neighbourhood",
        hover_data={"avg_price": ":.0f", "count": True},
        color_continuous_scale=HOTSPOT_SCALE,
        size_max=40,
        zoom=10,
        height=580,
        mapbox_style=MAP_STYLE,
    )
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 0, "b": 0},
        paper_bgcolor="#1a1a2e",
        font_color="#e0e0e0",
    )
    log.info(f"Neighbourhood bubble map built: {len(df)} areas")
    return fig
