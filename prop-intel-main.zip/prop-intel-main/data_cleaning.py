"""
data_cleaning.py — PropIntel Data Cleaning & Enrichment Pipeline
Validates, normalises, deduplicates, and enriches raw ingested DataFrames
before they are stored or consumed by analytics modules.
"""

from __future__ import annotations

import re
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from utils import get_logger, normalise_series

log = get_logger("data_cleaning")


# ─────────────────────────────────────────────
# BASE CLEANER
# ─────────────────────────────────────────────


class BaseCleaner:
    """Abstract base — subclasses implement `clean`."""

    dataset_name: str = "base"

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError

    def _report(self, before: int, after: int) -> None:
        removed = before - after
        log.info(
            f"[{self.dataset_name}] {after:,} rows retained "
            f"({removed:,} removed, {removed / max(before, 1) * 100:.1f}%)"
        )


# ─────────────────────────────────────────────
# PROPERTY LISTINGS CLEANER
# ─────────────────────────────────────────────


class PropertyCleaner(BaseCleaner):
    """
    Cleans and enriches raw property listing data.
    Steps:
        1. Drop duplicates on property_id
        2. Enforce numeric types and sensible bounds
        3. Impute missing values (median per neighbourhood)
        4. Remove statistical outliers (Z-score > 3.5) on price
        5. Engineer derived features
    """

    dataset_name = "properties"

    # Price bounds in GBP — discard anything outside this range
    PRICE_MIN = 50_000
    PRICE_MAX = 50_000_000

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        n0 = len(df)
        df = df.copy()

        # ── 1. Deduplication ──────────────────────────────────────
        if "property_id" in df.columns:
            df = df.drop_duplicates(subset=["property_id"])

        # ── 2. Type coercion ──────────────────────────────────────
        numeric_cols = ["price_gbp", "size_sqm", "bedrooms", "bathrooms",
                        "price_per_sqm", "lat", "lon"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        # ── 3. Bounds filtering ───────────────────────────────────
        if "price_gbp" in df.columns:
            df = df[df["price_gbp"].between(self.PRICE_MIN, self.PRICE_MAX)]
        if "size_sqm" in df.columns:
            df = df[df["size_sqm"].between(10, 2_000)]
        if "lat" in df.columns:
            df = df[df["lat"].between(49.0, 61.0)]  # UK bounds

        # ── 4. Median imputation per neighbourhood ────────────────
        for col in ["price_gbp", "size_sqm", "bedrooms"]:
            if col in df.columns and df[col].isna().any():
                if "neighbourhood" in df.columns:
                    df[col] = df.groupby("neighbourhood")[col].transform(
                        lambda s: s.fillna(s.median())
                    )
                df[col] = df[col].fillna(df[col].median())

        # ── 5. Outlier removal on price (Z-score) ────────────────
        if "price_gbp" in df.columns:
            z = np.abs(stats.zscore(df["price_gbp"].dropna()))
            mask = pd.Series(True, index=df.index)
            valid_idx = df["price_gbp"].dropna().index
            mask.loc[valid_idx] = z < 3.5
            df = df[mask]

        # ── 6. Feature engineering ────────────────────────────────
        if "price_gbp" in df.columns and "size_sqm" in df.columns:
            df["price_per_sqm"] = (df["price_gbp"] / df["size_sqm"]).round(0)

        if "list_date" in df.columns:
            df["list_date"] = pd.to_datetime(df["list_date"], errors="coerce")
            df["list_year"] = df["list_date"].dt.year
            df["list_quarter"] = df["list_date"].dt.to_period("Q").astype(str)

        if "year_built" in df.columns:
            df["property_age"] = datetime_year() - df["year_built"].clip(1800, datetime_year())

        self._report(n0, len(df))
        return df.reset_index(drop=True)


# ─────────────────────────────────────────────
# ECONOMIC DATA CLEANER
# ─────────────────────────────────────────────


class EconomicCleaner(BaseCleaner):
    """Ensures economic time-series is sorted, typed, and interpolated."""

    dataset_name = "economics"

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
            df = df.sort_values("date").reset_index(drop=True)

        numeric_cols = [c for c in df.columns if c != "date"]
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            df[col] = df[col].interpolate(method="linear")  # fill gaps by linear interpolation

        log.info(f"[economics] Cleaned {len(df):,} records")
        return df


# ─────────────────────────────────────────────
# SALES HISTORY CLEANER
# ─────────────────────────────────────────────


class SalesHistoryCleaner(BaseCleaner):
    dataset_name = "sales_history"

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
            df = df.sort_values(["neighbourhood", "date"]).reset_index(drop=True)

        numeric_cols = ["avg_sale_price", "transaction_count", "avg_days_to_sell"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
                df[col] = df[col].clip(lower=0).interpolate(method="linear")

        # MoM price change per neighbourhood
        df["mom_price_change_pct"] = df.groupby("neighbourhood")["avg_sale_price"].pct_change() * 100

        log.info(f"[sales_history] Cleaned {len(df):,} records")
        return df


# ─────────────────────────────────────────────
# NEIGHBOURHOOD CLEANER
# ─────────────────────────────────────────────


class NeighbourhoodCleaner(BaseCleaner):
    dataset_name = "neighbourhoods"

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        # Normalise score columns to [0, 1]
        score_cols = ["crime_rate_per_1k", "school_rating", "transport_score",
                      "flood_risk_score", "planning_activity_score"]
        for col in score_cols:
            if col in df.columns:
                df[f"{col}_norm"] = normalise_series(df[col])

        # Composite liveability index (higher = better)
        if all(c in df.columns for c in ["school_rating_norm", "transport_score_norm",
                                          "crime_rate_per_1k_norm"]):
            df["liveability_index"] = (
                df["school_rating_norm"] * 0.35
                + df["transport_score_norm"] * 0.35
                + (1 - df["crime_rate_per_1k_norm"]) * 0.30  # invert crime
            ).round(3)

        log.info(f"[neighbourhoods] Enriched {len(df):,} neighbourhood records")
        return df


# ─────────────────────────────────────────────
# CLEANING ORCHESTRATOR
# ─────────────────────────────────────────────


CLEANER_MAP: dict[str, BaseCleaner] = {
    "properties": PropertyCleaner(),
    "economics": EconomicCleaner(),
    "sales_history": SalesHistoryCleaner(),
    "neighbourhoods": NeighbourhoodCleaner(),
}


class DataCleaningPipeline:
    """
    Applies the appropriate cleaner to each raw DataFrame returned
    by the ingestion pipeline, returning a dict of clean DataFrames.
    """

    def run(self, raw: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
        clean: dict[str, pd.DataFrame] = {}
        for name, df in raw.items():
            cleaner = CLEANER_MAP.get(name)
            if cleaner:
                try:
                    clean[name] = cleaner.clean(df)
                except Exception as exc:
                    log.error(f"Cleaning failed for [{name}]: {exc}", exc_info=True)
                    clean[name] = df  # pass through uncleaned on error
            else:
                log.debug(f"No cleaner registered for [{name}], passing through")
                clean[name] = df
        return clean


# helper
def datetime_year() -> int:
    from datetime import datetime
    return datetime.utcnow().year
