"""
ai_models.py — PropIntel Machine Learning & AI Model Suite
Provides:
  • PricePredictionModel  — Gradient-boosted regression for property price forecasting
  • NeighbourhoodClusterer — KMeans-based neighbourhood segmentation
  • AnomalyDetector        — Isolation Forest for suspicious listings
  • TrendForecaster        — Prophet / ARIMA-style time-series forecasting
"""

from __future__ import annotations

import warnings
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, IsolationForest, RandomForestRegressor
from sklearn.cluster import KMeans
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.pipeline import Pipeline

from utils import get_logger, CONFIG

warnings.filterwarnings("ignore")
log = get_logger("ai_models")


# ─────────────────────────────────────────────
# PRICE PREDICTION MODEL
# ─────────────────────────────────────────────


class PricePredictionModel:
    """
    Gradient Boosted Regression model for property price forecasting.

    Features used (when available):
        bedrooms, bathrooms, size_sqm, property_age, epc_risk_score,
        lat, lon, neighbourhood_encoded, property_type_encoded,
        liveability_index (joined from neighbourhoods)

    The pipeline includes StandardScaler + GBR for robustness.
    """

    FEATURES = [
        "bedrooms", "bathrooms", "size_sqm", "property_age",
        "lat", "lon", "neighbourhood_code", "property_type_code",
        "liveability_index", "risk_score",
    ]
    TARGET = "price_gbp"

    def __init__(self):
        self.pipeline: Pipeline | None = None
        self.label_encoders: dict[str, LabelEncoder] = {}
        self.feature_importances_: pd.Series | None = None
        self.metrics_: dict[str, float] = {}

    # ── Training ──────────────────────────────────────────────────

    def train(
        self,
        properties: pd.DataFrame,
        neighbourhoods: pd.DataFrame | None = None,
    ) -> dict[str, float]:
        """
        Trains the GBR pipeline and returns evaluation metrics.
        """
        df = self._prepare_features(properties, neighbourhoods)

        available_feats = [f for f in self.FEATURES if f in df.columns]
        X = df[available_feats].copy()
        y = df[self.TARGET]

        # Drop rows with NaN in any feature or target
        mask = X.notna().all(axis=1) & y.notna()
        X, y = X[mask], y[mask]

        if len(X) < 50:
            raise ValueError("Insufficient training samples (< 50) after cleaning")

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=42
        )

        self.pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("gbr", GradientBoostingRegressor(
                n_estimators=300,
                learning_rate=0.08,
                max_depth=5,
                subsample=0.85,
                min_samples_leaf=10,
                random_state=42,
            )),
        ])

        self.pipeline.fit(X_train, y_train)
        y_pred = self.pipeline.predict(X_test)

        # Feature importance from underlying GBR
        gbr = self.pipeline.named_steps["gbr"]
        self.feature_importances_ = pd.Series(
            gbr.feature_importances_, index=available_feats
        ).sort_values(ascending=False)

        self.metrics_ = {
            "mae": mean_absolute_error(y_test, y_pred),
            "rmse": np.sqrt(mean_squared_error(y_test, y_pred)),
            "r2": r2_score(y_test, y_pred),
            "train_samples": len(X_train),
            "test_samples": len(X_test),
        }
        log.info(
            f"PricePrediction trained | R²={self.metrics_['r2']:.3f} "
            f"| MAE=£{self.metrics_['mae']:,.0f}"
        )
        return self.metrics_

    def predict(
        self,
        properties: pd.DataFrame,
        neighbourhoods: pd.DataFrame | None = None,
    ) -> pd.Series:
        """Returns a Series of predicted prices aligned to `properties` index."""
        if self.pipeline is None:
            raise RuntimeError("Model not trained. Call .train() first.")
        df = self._prepare_features(properties, neighbourhoods)
        available_feats = [f for f in self.FEATURES if f in df.columns]
        X = df[available_feats].fillna(0)
        return pd.Series(self.pipeline.predict(X), index=properties.index, name="predicted_price")

    # ── Feature engineering ───────────────────────────────────────

    def _prepare_features(
        self,
        properties: pd.DataFrame,
        neighbourhoods: pd.DataFrame | None,
    ) -> pd.DataFrame:
        df = properties.copy()

        # Label encode categoricals
        for col, code_col in [("neighbourhood", "neighbourhood_code"),
                               ("property_type", "property_type_code")]:
            if col in df.columns:
                if col not in self.label_encoders:
                    le = LabelEncoder()
                    df[code_col] = le.fit_transform(df[col].fillna("Unknown"))
                    self.label_encoders[col] = le
                else:
                    le = self.label_encoders[col]
                    known = set(le.classes_)
                    df[code_col] = df[col].apply(
                        lambda x: le.transform([x])[0] if x in known else -1
                    )

        # EPC risk
        if "epc_rating" in df.columns:
            epc_map = {"A": 0.0, "B": 0.1, "C": 0.25, "D": 0.4, "E": 0.6, "F": 0.8, "G": 1.0}
            df["epc_risk_score"] = df["epc_rating"].map(epc_map).fillna(0.3)

        # Join neighbourhood liveability / risk
        if neighbourhoods is not None and "neighbourhood" in df.columns:
            hood_cols = ["neighbourhood"]
            for c in ["liveability_index", "risk_score", "median_income_gbp"]:
                if c in neighbourhoods.columns:
                    hood_cols.append(c)
            df = df.merge(neighbourhoods[hood_cols], on="neighbourhood", how="left",
                          suffixes=("", "_hood"))

        return df


# ─────────────────────────────────────────────
# NEIGHBOURHOOD CLUSTERER
# ─────────────────────────────────────────────


class NeighbourhoodClusterer:
    """
    KMeans clustering of neighbourhoods into investment archetypes
    based on price, demographics, risk, and liveability.

    Cluster labels are auto-interpreted into human-readable archetypes.
    """

    FEATURES = [
        "median_income_gbp", "crime_rate_per_1k", "school_rating",
        "transport_score", "flood_risk_score", "planning_activity_score",
        "green_space_pct",
    ]

    ARCHETYPE_MAP = {
        0: "Luxury Core",
        1: "Rising Opportunity",
        2: "Stable Suburban",
        3: "Urban Fringe",
        4: "Emerging Growth",
        5: "High Risk Undervalued",
        6: "Commuter Belt",
        7: "Premium Regeneration",
    }

    def __init__(self, n_clusters: int | None = None):
        self.n_clusters = n_clusters or CONFIG.get("clustering_n_clusters", 8)
        self.model: KMeans | None = None
        self.scaler = StandardScaler()

    def fit_predict(self, neighbourhoods: pd.DataFrame) -> pd.DataFrame:
        df = neighbourhoods.copy()
        feat_cols = [f for f in self.FEATURES if f in df.columns]
        if len(feat_cols) < 3:
            log.warning("Insufficient features for clustering; skipping")
            df["cluster"] = 0
            df["cluster_archetype"] = "Unknown"
            return df

        X = df[feat_cols].fillna(df[feat_cols].median())
        X_scaled = self.scaler.fit_transform(X)

        k = min(self.n_clusters, len(df))
        self.model = KMeans(n_clusters=k, random_state=42, n_init=10)
        df["cluster"] = self.model.fit_predict(X_scaled)
        df["cluster_archetype"] = df["cluster"].map(
            lambda c: self.ARCHETYPE_MAP.get(c, f"Type-{c}")
        )

        log.info(f"Clustering complete: {k} clusters across {len(df)} neighbourhoods")
        return df


# ─────────────────────────────────────────────
# ANOMALY DETECTOR
# ─────────────────────────────────────────────


class AnomalyDetector:
    """
    Isolation Forest model to flag suspicious property listings:
    unusually low/high prices, extreme size/price ratios, etc.

    Adds `is_anomaly` (bool) and `anomaly_score` (float, lower = more anomalous)
    """

    FEATURES = ["price_gbp", "size_sqm", "price_per_sqm", "bedrooms", "days_on_market"]

    def __init__(self, contamination: float | None = None):
        self.contamination = contamination or CONFIG.get("anomaly_contamination", 0.05)
        self.model = IsolationForest(
            contamination=self.contamination,
            n_estimators=200,
            random_state=42,
        )

    def detect(self, properties: pd.DataFrame) -> pd.DataFrame:
        df = properties.copy()
        feat_cols = [f for f in self.FEATURES if f in df.columns]

        X = df[feat_cols].fillna(df[feat_cols].median())
        raw_scores = self.model.fit_predict(X)        # +1 = normal, -1 = anomaly
        decision = self.model.decision_function(X)    # continuous score

        df["is_anomaly"] = raw_scores == -1
        df["anomaly_score"] = np.round(decision, 4)

        n_flagged = df["is_anomaly"].sum()
        log.info(f"Anomaly detection: {n_flagged} flagged ({n_flagged / len(df) * 100:.1f}%)")
        return df


# ─────────────────────────────────────────────
# TREND FORECASTER (Simple time-series)
# ─────────────────────────────────────────────


class TrendForecaster:
    """
    Forecasts neighbourhood average property prices forward N months
    using Exponential Smoothing and polynomial trend extrapolation.

    Returns a DataFrame with columns: date, neighbourhood, forecast_price,
    lower_95, upper_95.
    """

    def __init__(self, horizon_months: int | None = None):
        self.horizon = horizon_months or CONFIG.get("forecast_horizon_months", 12)

    def forecast(self, sales_history: pd.DataFrame) -> pd.DataFrame:
        """
        Runs a per-neighbourhood forecast.
        """
        required = {"date", "neighbourhood", "avg_sale_price"}
        if not required.issubset(set(sales_history.columns)):
            raise ValueError(f"sales_history must contain: {required}")

        results = []
        for hood, group in sales_history.groupby("neighbourhood"):
            try:
                result = self._forecast_series(group, hood)
                results.append(result)
            except Exception as e:
                log.warning(f"Forecast failed for [{hood}]: {e}")

        if not results:
            return pd.DataFrame()
        return pd.concat(results, ignore_index=True)

    def _forecast_series(self, group: pd.DataFrame, neighbourhood: str) -> pd.DataFrame:
        """
        Fits a polynomial trend + noise envelope to one neighbourhood's price series.
        """
        g = group.sort_values("date").copy()
        g["date"] = pd.to_datetime(g["date"])
        g = g.set_index("date")["avg_sale_price"].resample("MS").mean().interpolate()

        n = len(g)
        x = np.arange(n)
        y = g.values

        # Fit degree-2 polynomial trend
        coeffs = np.polyfit(x, y, deg=2)
        poly = np.poly1d(coeffs)

        residuals = y - poly(x)
        std_resid = residuals.std()

        # Forecast future periods
        future_x = np.arange(n, n + self.horizon)
        future_dates = pd.date_range(g.index[-1] + pd.offsets.MonthBegin(1),
                                     periods=self.horizon, freq="MS")

        base_forecast = poly(future_x)
        # Widen confidence interval with time (uncertainty grows)
        ci_factor = np.linspace(1.0, 2.0, self.horizon)
        lower = base_forecast - 1.96 * std_resid * ci_factor
        upper = base_forecast + 1.96 * std_resid * ci_factor

        return pd.DataFrame({
            "date": future_dates,
            "neighbourhood": neighbourhood,
            "forecast_price": np.round(base_forecast, -2),
            "lower_95": np.round(lower, -2),
            "upper_95": np.round(upper, -2),
        })
