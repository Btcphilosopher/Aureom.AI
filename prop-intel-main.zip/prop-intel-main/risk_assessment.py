"""
risk_assessment.py — PropIntel Risk Assessment Engine
Computes property-level and neighbourhood-level composite risk scores
across flood, crime, regulatory, volatility, and infrastructure dimensions.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from utils import get_logger, CONFIG, clamp, normalise_series

log = get_logger("risk_assessment")


# ─────────────────────────────────────────────
# RISK WEIGHT DEFINITIONS
# ─────────────────────────────────────────────

# Weights must sum to 1.0.  Loaded from CONFIG for easy tuning.
DEFAULT_WEIGHTS = CONFIG.get(
    "risk_weights",
    {
        "flood": 0.20,
        "crime": 0.25,
        "price_volatility": 0.20,
        "regulatory": 0.15,
        "school_quality": 0.10,
        "transport": 0.10,
    },
)

# Risk bands for UI display
RISK_BANDS = [
    (0.0,  0.25, "Low",         "#2ecc71"),
    (0.25, 0.50, "Moderate",    "#f39c12"),
    (0.50, 0.75, "High",        "#e67e22"),
    (0.75, 1.01, "Very High",   "#e74c3c"),
]


def risk_label(score: float) -> tuple[str, str]:
    """Returns (label, hex_colour) for a normalised risk score [0,1]."""
    for lo, hi, label, colour in RISK_BANDS:
        if lo <= score < hi:
            return label, colour
    return "Very High", "#e74c3c"


# ─────────────────────────────────────────────
# PROPERTY-LEVEL RISK SCORER
# ─────────────────────────────────────────────


class PropertyRiskScorer:
    """
    Scores each property in the listings DataFrame by joining to
    neighbourhood-level risk attributes and applying weighted aggregation.

    Output column: `risk_score` ∈ [0, 1]  (higher = riskier)
    """

    def __init__(self, weights: dict[str, float] | None = None):
        self.weights = weights or DEFAULT_WEIGHTS
        # Normalise weights to sum to 1.0
        total = sum(self.weights.values())
        self.weights = {k: v / total for k, v in self.weights.items()}

    def score(
        self,
        properties: pd.DataFrame,
        neighbourhoods: pd.DataFrame,
        sales_history: pd.DataFrame | None = None,
    ) -> pd.DataFrame:
        """
        Joins neighbourhood attributes to properties and computes risk_score.

        Parameters
        ----------
        properties    : clean property DataFrame
        neighbourhoods: clean neighbourhood DataFrame with risk attributes
        sales_history : optional — used to compute price volatility per hood

        Returns
        -------
        properties DataFrame with `risk_score`, `risk_label`, `risk_colour` columns added
        """
        df = properties.copy()

        # ── Price volatility from sales history ───────────────────
        vol_map: dict[str, float] = {}
        if sales_history is not None and "neighbourhood" in sales_history.columns:
            vol = (
                sales_history.groupby("neighbourhood")["avg_sale_price"]
                .std()
                .fillna(0)
            )
            vol_map = normalise_series(vol).to_dict()

        # ── Build neighbourhood risk lookup ───────────────────────
        hood_risk = self._build_hood_risk(neighbourhoods, vol_map)

        # ── Merge and compute ─────────────────────────────────────
        if "neighbourhood" in df.columns:
            df = df.merge(hood_risk, on="neighbourhood", how="left")

        # Property-specific adjustments
        if "property_age" in df.columns:
            # Older buildings have slightly higher structural risk
            df["_age_risk"] = (df["property_age"].fillna(30) / 150).clip(0.0, 1.0)
        else:
            df["_age_risk"] = 0.3

        if "epc_rating" in df.columns:
            epc_risk = {"A": 0.0, "B": 0.1, "C": 0.25, "D": 0.4, "E": 0.6, "F": 0.8, "G": 1.0}
            df["_epc_risk"] = df["epc_rating"].map(epc_risk).fillna(0.3)
        else:
            df["_epc_risk"] = 0.3

        # Blend neighbourhood score with property-specific adjustments
        hood_cols = [c for c in df.columns if c.startswith("_hood_")]
        if hood_cols:
            df["_base_risk"] = df[[c for c in hood_cols]].mean(axis=1)
        else:
            df["_base_risk"] = 0.4

        df["risk_score"] = (
            df["_base_risk"] * 0.70
            + df["_age_risk"] * 0.15
            + df["_epc_risk"] * 0.15
        ).round(3).clip(0, 1)

        # Decode label
        df["risk_label"] = df["risk_score"].apply(lambda s: risk_label(s)[0])
        df["risk_colour"] = df["risk_score"].apply(lambda s: risk_label(s)[1])

        # Cleanup internal columns
        drop_cols = [c for c in df.columns if c.startswith("_")]
        df = df.drop(columns=drop_cols, errors="ignore")

        log.info(f"Property risk scored: mean={df['risk_score'].mean():.3f}")
        return df

    def _build_hood_risk(
        self,
        neighbourhoods: pd.DataFrame,
        vol_map: dict[str, float],
    ) -> pd.DataFrame:
        """
        Builds a lookup table of component risk scores per neighbourhood.
        """
        h = neighbourhoods[["neighbourhood"]].copy()

        # Flood risk (already 0–1 if available)
        if "flood_risk_score" in neighbourhoods.columns:
            h["_hood_flood"] = normalise_series(neighbourhoods["flood_risk_score"]).values
        else:
            h["_hood_flood"] = 0.3

        # Crime risk (higher crime rate = higher risk)
        if "crime_rate_per_1k" in neighbourhoods.columns:
            h["_hood_crime"] = normalise_series(neighbourhoods["crime_rate_per_1k"]).values
        else:
            h["_hood_crime"] = 0.3

        # School quality risk (lower school rating = higher risk)
        if "school_rating" in neighbourhoods.columns:
            h["_hood_school"] = (1 - normalise_series(neighbourhoods["school_rating"])).values
        else:
            h["_hood_school"] = 0.3

        # Transport risk (lower transport score = higher risk)
        if "transport_score" in neighbourhoods.columns:
            h["_hood_transport"] = (1 - normalise_series(neighbourhoods["transport_score"])).values
        else:
            h["_hood_transport"] = 0.3

        # Price volatility risk
        h["_hood_volatility"] = h["neighbourhood"].map(vol_map).fillna(0.3)

        return h


# ─────────────────────────────────────────────
# NEIGHBOURHOOD-LEVEL RISK SCORER
# ─────────────────────────────────────────────


class NeighbourhoodRiskScorer:
    """
    Produces a composite `risk_score` column in the neighbourhoods DataFrame,
    combining all available risk factors via configurable weights.
    """

    def score(
        self,
        neighbourhoods: pd.DataFrame,
        sales_history: pd.DataFrame | None = None,
    ) -> pd.DataFrame:
        df = neighbourhoods.copy()

        components: dict[str, pd.Series] = {}

        if "flood_risk_score" in df.columns:
            components["flood"] = normalise_series(df["flood_risk_score"])

        if "crime_rate_per_1k" in df.columns:
            components["crime"] = normalise_series(df["crime_rate_per_1k"])

        if "school_rating" in df.columns:
            components["school_quality"] = 1 - normalise_series(df["school_rating"])

        if "transport_score" in df.columns:
            components["transport"] = 1 - normalise_series(df["transport_score"])

        if "planning_activity_score" in df.columns:
            # High planning activity can mean more uncertainty
            components["regulatory"] = normalise_series(df["planning_activity_score"]) * 0.5

        if sales_history is not None and "neighbourhood" in sales_history.columns:
            vol = (
                sales_history.groupby("neighbourhood")["avg_sale_price"]
                .std()
                .fillna(0)
            )
            vol_norm = normalise_series(vol)
            df = df.merge(vol_norm.rename("_vol").reset_index(), on="neighbourhood", how="left")
            components["price_volatility"] = df["_vol"].fillna(0.3)

        if not components:
            df["risk_score"] = 0.35
        else:
            weights = {k: DEFAULT_WEIGHTS.get(k, 0.1) for k in components}
            w_total = sum(weights.values())
            score = sum(components[k] * weights[k] / w_total for k in components)
            df["risk_score"] = score.round(3).clip(0, 1)

        df["risk_label"] = df["risk_score"].apply(lambda s: risk_label(s)[0])
        df["risk_colour"] = df["risk_score"].apply(lambda s: risk_label(s)[1])

        drop_cols = [c for c in df.columns if c.startswith("_")]
        df = df.drop(columns=drop_cols, errors="ignore")

        log.info(f"Neighbourhood risk scored: {len(df)} areas")
        return df
