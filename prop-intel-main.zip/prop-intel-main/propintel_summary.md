# PropIntel — Market Intelligence Report
*Generated: 2026-04-05 17:37 UTC*

---

## Market KPIs

- **Total Listings**: £2.0K
- **Avg Asking Price**: £1.03M
- **Median Asking Price**: £946.0K
- **Total Market Value**: £2043.67M
- **Avg Price Per Sqm**: £10.6K
- **Avg Days On Market**: 91.00
- **Avg Yoy Price Change Pct**: 3.22
- **Avg Property Risk**: 0.42
- **High Risk Pct**: 21.00
- **Active Neighbourhoods**: 10

## Neighbourhood Trends (Top 5 by CAGR)

- **Islington**: CAGR 8.0% | 12m Appreciation 12.4%
- **Brixton**: CAGR 5.8% | 12m Appreciation 14.0%
- **Croydon**: CAGR 5.5% | 12m Appreciation 2.9%
- **Hackney**: CAGR 5.5% | 12m Appreciation 7.8%
- **Greenwich**: CAGR 5.3% | 12m Appreciation -4.9%

## Investment Hotspots

- **Islington**: Score 0.780 | Rank #1
- **Brixton**: Score 0.701 | Rank #2
- **Hackney**: Score 0.660 | Rank #3

## Portfolio Summary

- **N Properties**: 4
- **Total Portfolio Value**: 2875000
- **Total Equity**: 1252000
- **Total Cost**: 2300000
- **Portfolio Capital Gain Pct**: 25.0
- **Portfolio Gross Yield Pct**: 4.38
- **Total Monthly Cashflow**: -436.0
- **Avg Cagr Pct**: 3.0
- **Best Performer**: PROP-00789
- **Worst Performer**: PROP-00312

---
*PropIntel — AI-powered Real Estate Intelligence Platform*