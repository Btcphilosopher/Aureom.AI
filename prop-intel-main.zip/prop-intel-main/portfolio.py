"""
portfolio.py — PropIntel Portfolio Management & ROI Engine
Tracks property portfolios, computes ROI, IRR, yield, and
runs holding-period simulations under different exit scenarios.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import brentq

from utils import get_logger, CONFIG, safe_divide, format_currency

log = get_logger("portfolio")


# ─────────────────────────────────────────────
# PORTFOLIO POSITION
# ─────────────────────────────────────────────


class PortfolioPosition:
    """Represents a single property position in the portfolio."""

    def __init__(
        self,
        property_id: str,
        purchase_price: float,
        purchase_date: str,
        current_value: float | None = None,
        monthly_income: float = 0.0,   # rental income
        monthly_costs: float = 0.0,    # mortgage, service charge, insurance
        ltv_pct: float = 0.75,         # loan-to-value ratio
        mortgage_rate_pct: float = 4.5,
        notes: str = "",
    ):
        self.property_id = property_id
        self.purchase_price = purchase_price
        self.purchase_date = pd.to_datetime(purchase_date)
        self.current_value = current_value or purchase_price
        self.monthly_income = monthly_income
        self.monthly_costs = monthly_costs
        self.ltv_pct = ltv_pct
        self.mortgage_rate_pct = mortgage_rate_pct
        self.notes = notes

    # ── Key metrics ───────────────────────────────────────────────

    @property
    def loan_amount(self) -> float:
        return self.purchase_price * self.ltv_pct

    @property
    def equity(self) -> float:
        return self.current_value - self.loan_amount

    @property
    def capital_gain(self) -> float:
        return self.current_value - self.purchase_price

    @property
    def capital_gain_pct(self) -> float:
        return safe_divide(self.capital_gain, self.purchase_price) * 100

    @property
    def holding_years(self) -> float:
        delta = datetime.utcnow() - self.purchase_date.to_pydatetime()
        return delta.days / 365.25

    @property
    def cagr_pct(self) -> float:
        if self.holding_years <= 0:
            return 0.0
        return (
            safe_divide(self.current_value, self.purchase_price) ** safe_divide(1, self.holding_years) - 1
        ) * 100

    @property
    def gross_yield_pct(self) -> float:
        """Annual gross rental yield."""
        return safe_divide(self.monthly_income * 12, self.current_value) * 100

    @property
    def net_monthly_cashflow(self) -> float:
        """Monthly income less all costs."""
        monthly_interest = self.loan_amount * (self.mortgage_rate_pct / 100) / 12
        return self.monthly_income - self.monthly_costs - monthly_interest

    @property
    def net_yield_pct(self) -> float:
        annual_net = self.net_monthly_cashflow * 12
        return safe_divide(annual_net, self.current_value) * 100

    def total_return_pct(self, holding_years: float | None = None) -> float:
        """Total return = capital gain + cumulative net income over holding period."""
        yrs = holding_years or self.holding_years
        total_income = self.net_monthly_cashflow * 12 * yrs
        total_return = self.capital_gain + total_income
        return safe_divide(total_return, self.purchase_price) * 100

    def to_dict(self) -> dict:
        return {
            "property_id": self.property_id,
            "purchase_price": self.purchase_price,
            "current_value": self.current_value,
            "equity": round(self.equity, 0),
            "capital_gain": round(self.capital_gain, 0),
            "capital_gain_pct": round(self.capital_gain_pct, 2),
            "cagr_pct": round(self.cagr_pct, 2),
            "holding_years": round(self.holding_years, 2),
            "gross_yield_pct": round(self.gross_yield_pct, 2),
            "net_yield_pct": round(self.net_yield_pct, 2),
            "net_monthly_cashflow": round(self.net_monthly_cashflow, 0),
            "total_return_pct": round(self.total_return_pct(), 2),
        }


# ─────────────────────────────────────────────
# PORTFOLIO MANAGER
# ─────────────────────────────────────────────


class PortfolioManager:
    """
    Manages a collection of PortfolioPositions and computes
    aggregate metrics, concentration risk, and performance attribution.
    """

    def __init__(self):
        self.positions: list[PortfolioPosition] = []

    def add_position(self, pos: PortfolioPosition) -> None:
        self.positions.append(pos)
        log.info(f"Added position {pos.property_id} @ £{pos.purchase_price:,.0f}")

    def remove_position(self, property_id: str) -> None:
        self.positions = [p for p in self.positions if p.property_id != property_id]

    # ── Portfolio-level metrics ───────────────────────────────────

    @property
    def total_value(self) -> float:
        return sum(p.current_value for p in self.positions)

    @property
    def total_equity(self) -> float:
        return sum(p.equity for p in self.positions)

    @property
    def total_cost(self) -> float:
        return sum(p.purchase_price for p in self.positions)

    @property
    def total_monthly_cashflow(self) -> float:
        return sum(p.net_monthly_cashflow for p in self.positions)

    @property
    def portfolio_capital_gain_pct(self) -> float:
        return safe_divide(self.total_value - self.total_cost, self.total_cost) * 100

    @property
    def portfolio_gross_yield_pct(self) -> float:
        income = sum(p.monthly_income * 12 for p in self.positions)
        return safe_divide(income, self.total_value) * 100

    def to_dataframe(self) -> pd.DataFrame:
        if not self.positions:
            return pd.DataFrame()
        return pd.DataFrame([p.to_dict() for p in self.positions])

    def summary(self) -> dict:
        df = self.to_dataframe()
        if df.empty:
            return {}
        return {
            "n_properties": len(self.positions),
            "total_portfolio_value": int(self.total_value),
            "total_equity": int(self.total_equity),
            "total_cost": int(self.total_cost),
            "portfolio_capital_gain_pct": round(self.portfolio_capital_gain_pct, 2),
            "portfolio_gross_yield_pct": round(self.portfolio_gross_yield_pct, 2),
            "total_monthly_cashflow": round(self.total_monthly_cashflow, 0),
            "avg_cagr_pct": round(df["cagr_pct"].mean(), 2),
            "best_performer": df.loc[df["capital_gain_pct"].idxmax(), "property_id"],
            "worst_performer": df.loc[df["capital_gain_pct"].idxmin(), "property_id"],
        }

    # ── IRR calculation ───────────────────────────────────────────

    def compute_irr(self, position: PortfolioPosition, sale_price: float | None = None) -> float:
        """
        Computes the Internal Rate of Return (IRR) for a portfolio position.
        Uses scipy.brentq to solve for the discount rate that makes NPV = 0.
        """
        sale = sale_price or position.current_value
        n_months = max(1, int(position.holding_years * 12))

        # Cash flows: -purchase_price at t=0, monthly net cashflow, +sale at end
        cashflows = [-position.purchase_price]
        cashflows += [position.net_monthly_cashflow] * (n_months - 1)
        cashflows.append(position.net_monthly_cashflow + sale)

        cf = np.array(cashflows)

        def npv(r_monthly):
            t = np.arange(len(cf))
            return np.sum(cf / (1 + r_monthly) ** t)

        try:
            r_monthly = brentq(npv, -0.05, 0.10)
            return round((1 + r_monthly) ** 12 - 1, 4) * 100  # annualised %
        except Exception:
            return 0.0

    # ── Scenario exit simulation ──────────────────────────────────

    def simulate_exit_scenarios(
        self,
        position: PortfolioPosition,
        growth_scenarios: dict[str, float] | None = None,
        holding_years: int | None = None,
    ) -> pd.DataFrame:
        """
        Compares portfolio outcomes across multiple exit scenarios.

        Parameters
        ----------
        position         : the PortfolioPosition to analyse
        growth_scenarios : dict of {label: annual_growth_rate}
        holding_years    : override holding period

        Returns a DataFrame with one row per scenario.
        """
        if growth_scenarios is None:
            growth_scenarios = {
                "Bear (-2% pa)": -0.02,
                "Base (+3% pa)": 0.03,
                "Bull (+7% pa)": 0.07,
                "Boom (+12% pa)": 0.12,
            }

        years = holding_years or CONFIG.get("default_holding_years", 5)
        rows = []

        for label, rate in growth_scenarios.items():
            future_value = position.purchase_price * (1 + rate) ** years
            total_income = position.net_monthly_cashflow * 12 * years
            total_return = (future_value - position.purchase_price) + total_income
            total_return_pct = safe_divide(total_return, position.purchase_price) * 100
            irr = self.compute_irr(position, sale_price=future_value)

            rows.append({
                "scenario": label,
                "annual_growth_rate_pct": rate * 100,
                "exit_value": int(future_value),
                "capital_gain": int(future_value - position.purchase_price),
                "total_income": int(total_income),
                "total_return": int(total_return),
                "total_return_pct": round(total_return_pct, 1),
                "irr_pct": round(irr, 2),
            })

        return pd.DataFrame(rows)


# ─────────────────────────────────────────────
# DEFAULT DEMO PORTFOLIO
# ─────────────────────────────────────────────


def build_demo_portfolio() -> PortfolioManager:
    """Creates a sample portfolio for dashboard demonstration."""
    pm = PortfolioManager()
    pm.add_position(PortfolioPosition(
        "PROP-00023", 650_000, "2019-06-01", 810_000, 2_800, 1_200, ltv_pct=0.75
    ))
    pm.add_position(PortfolioPosition(
        "PROP-00105", 420_000, "2020-03-15", 505_000, 1_800, 900, ltv_pct=0.70
    ))
    pm.add_position(PortfolioPosition(
        "PROP-00312", 280_000, "2021-09-01", 310_000, 1_400, 650, ltv_pct=0.80
    ))
    pm.add_position(PortfolioPosition(
        "PROP-00789", 950_000, "2018-01-20", 1_250_000, 4_500, 2_100, ltv_pct=0.65
    ))
    return pm
