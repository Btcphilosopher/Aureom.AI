"""
core.py — PropIntel Core Orchestrator
Coordinates the full pipeline: ingest → clean → persist → analyse → score.
Exposes a single `PropIntelEngine` class consumed by the dashboard and CLI.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from utils import get_logger, CONFIG
from data_ingestion import DataIngestionPipeline
from data_cleaning import DataCleaningPipeline
from database import DatabaseManager
from risk_assessment import PropertyRiskScorer, NeighbourhoodRiskScorer
from ai_models import (
    PricePredictionModel,
    NeighbourhoodClusterer,
    AnomalyDetector,
    TrendForecaster,
)
from analytics import MarketKPIEngine, NeighbourhoodTrendAnalyser, HotspotDetector, ScenarioSimulator
from portfolio import PortfolioManager, build_demo_portfolio

log = get_logger("core")


class PropIntelEngine:
    """
    Central engine — wires together all PropIntel subsystems.

    Usage
    -----
    engine = PropIntelEngine()
    engine.run_full_pipeline()

    data = engine.data          # cleaned DataFrames
    kpis = engine.kpis          # market KPI dict
    portfolio = engine.portfolio
    """

    def __init__(self, use_mock: bool = True, db_url: str | None = None):
        self.use_mock = use_mock

        # Subsystems
        self.ingestion_pipeline  = DataIngestionPipeline(use_mock=use_mock)
        self.cleaning_pipeline   = DataCleaningPipeline()
        self.db                  = DatabaseManager(db_url)
        self.property_risk       = PropertyRiskScorer()
        self.neighbourhood_risk  = NeighbourhoodRiskScorer()
        self.price_model         = PricePredictionModel()
        self.clusterer           = NeighbourhoodClusterer()
        self.anomaly_detector    = AnomalyDetector()
        self.forecaster          = TrendForecaster()
        self.kpi_engine          = MarketKPIEngine()
        self.trend_analyser      = NeighbourhoodTrendAnalyser()
        self.hotspot_detector    = HotspotDetector()
        self.scenario_simulator  = ScenarioSimulator()

        # State
        self.data: dict[str, pd.DataFrame] = {}
        self.kpis: dict[str, Any] = {}
        self.forecasts: pd.DataFrame = pd.DataFrame()
        self.trend_df: pd.DataFrame = pd.DataFrame()
        self.hotspots: pd.DataFrame = pd.DataFrame()
        self.model_metrics: dict = {}
        self.portfolio: PortfolioManager = build_demo_portfolio()

    # ─────────────────────────────────────────────
    # FULL PIPELINE
    # ─────────────────────────────────────────────

    def run_full_pipeline(self) -> None:
        """
        End-to-end execution:
        1. Ingest raw data
        2. Clean & validate
        3. Score risk (neighbourhoods, then properties)
        4. Cluster neighbourhoods
        5. Train price prediction model
        6. Detect anomalies
        7. Run trend analysis + hotspot detection
        8. Compute market KPIs
        9. Forecast prices
        10. Persist to database
        """
        log.info("━━━ PropIntel pipeline starting ━━━")

        # ── Step 1: Ingest ─────────────────────────────────────────
        raw = self.ingestion_pipeline.run()

        # ── Step 2: Clean ──────────────────────────────────────────
        clean = self.cleaning_pipeline.run(raw)
        self.data = clean

        props  = self.data.get("properties", pd.DataFrame())
        hoods  = self.data.get("neighbourhoods", pd.DataFrame())
        sales  = self.data.get("sales_history", pd.DataFrame())
        econ   = self.data.get("economics", pd.DataFrame())

        # ── Step 3: Risk scoring ───────────────────────────────────
        if not hoods.empty:
            hoods = self.neighbourhood_risk.score(hoods, sales)
            self.data["neighbourhoods"] = hoods

        if not props.empty:
            props = self.property_risk.score(props, hoods, sales)
            self.data["properties"] = props

        # ── Step 4: Neighbourhood clustering ──────────────────────
        if not hoods.empty:
            hoods = self.clusterer.fit_predict(hoods)
            self.data["neighbourhoods"] = hoods

        # ── Step 5: Train price model ──────────────────────────────
        if not props.empty and len(props) >= 50:
            try:
                self.model_metrics = self.price_model.train(props, hoods)
                preds = self.price_model.predict(props, hoods)
                self.data["properties"]["predicted_price"] = preds.values
            except Exception as exc:
                log.error(f"Price model training failed: {exc}", exc_info=True)

        # ── Step 6: Anomaly detection ──────────────────────────────
        if not props.empty:
            props_with_anomalies = self.anomaly_detector.detect(self.data["properties"])
            self.data["properties"] = props_with_anomalies

        # ── Step 7: Trend analysis + hotspots ─────────────────────
        if not sales.empty:
            self.trend_df = self.trend_analyser.analyse(sales)
            if not self.trend_df.empty:
                self.hotspots = self.hotspot_detector.detect(self.trend_df, hoods)

        # ── Step 8: Market KPIs ────────────────────────────────────
        self.kpis = self.kpi_engine.compute(
            self.data.get("properties", pd.DataFrame()),
            self.data.get("sales_history", pd.DataFrame()),
            self.data.get("neighbourhoods", pd.DataFrame()),
        )

        # ── Step 9: Price forecasts ────────────────────────────────
        if not sales.empty:
            try:
                self.forecasts = self.forecaster.forecast(sales)
            except Exception as exc:
                log.error(f"Forecasting failed: {exc}", exc_info=True)

        # ── Step 10: Persist ───────────────────────────────────────
        self.db.persist_all(self.data)

        log.info(f"━━━ Pipeline complete | KPIs: {len(self.kpis)} | "
                 f"Properties: {len(self.data.get('properties', []))} ━━━")

    # ─────────────────────────────────────────────
    # SCENARIO ACCESS HELPERS
    # ─────────────────────────────────────────────

    def run_rate_scenario(self, rate_change_pct: float) -> dict:
        return self.scenario_simulator.run_interest_rate_scenario(
            self.data.get("properties", pd.DataFrame()), rate_change_pct
        )

    def run_tax_scenario(self, sdlt_change_pct: float) -> dict:
        return self.scenario_simulator.run_tax_scenario(
            self.data.get("properties", pd.DataFrame()), sdlt_change_pct
        )

    def run_supply_scenario(self, new_units_pct: float) -> dict:
        return self.scenario_simulator.run_supply_shock_scenario(
            self.data.get("properties", pd.DataFrame()), new_units_pct
        )
