"""
database.py — PropIntel Database Layer
SQLAlchemy-based persistence layer using SQLite (default) or PostgreSQL.
Handles table creation, upsert operations, and query helpers.
"""

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

import pandas as pd
from sqlalchemy import (
    Column, Float, Integer, String, Date, Boolean, DateTime,
    create_engine, text, inspect
)
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from utils import get_logger, CONFIG

log = get_logger("database")


# ─────────────────────────────────────────────
# ORM BASE & MODELS
# ─────────────────────────────────────────────


class Base(DeclarativeBase):
    pass


class PropertyRecord(Base):
    __tablename__ = "properties"

    property_id     = Column(String(20), primary_key=True)
    neighbourhood   = Column(String(80))
    property_type   = Column(String(40))
    bedrooms        = Column(Integer)
    bathrooms       = Column(Integer)
    size_sqm        = Column(Float)
    price_gbp       = Column(Float)
    price_per_sqm   = Column(Float)
    lat             = Column(Float)
    lon             = Column(Float)
    tenure          = Column(String(20))
    year_built      = Column(Integer)
    epc_rating      = Column(String(2))
    list_date       = Column(String(12))
    days_on_market  = Column(Integer)
    is_sold         = Column(Boolean)
    property_age    = Column(Integer)
    risk_score      = Column(Float)
    predicted_price = Column(Float)


class SalesRecord(Base):
    __tablename__ = "sales_history"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    date             = Column(String(12))
    neighbourhood    = Column(String(80))
    avg_sale_price   = Column(Float)
    transaction_count = Column(Integer)
    avg_days_to_sell = Column(Integer)
    mom_price_change_pct = Column(Float)


class NeighbourhoodRecord(Base):
    __tablename__ = "neighbourhoods"

    neighbourhood          = Column(String(80), primary_key=True)
    population             = Column(Integer)
    median_income_gbp      = Column(Integer)
    crime_rate_per_1k      = Column(Float)
    school_rating          = Column(Float)
    flood_risk_score       = Column(Float)
    transport_score        = Column(Float)
    green_space_pct        = Column(Float)
    avg_commute_min        = Column(Integer)
    planning_activity_score = Column(Float)
    liveability_index      = Column(Float)
    risk_score             = Column(Float)


class EconomicRecord(Base):
    __tablename__ = "economics"

    id                   = Column(Integer, primary_key=True, autoincrement=True)
    date                 = Column(String(12))
    bank_rate_pct        = Column(Float)
    inflation_pct        = Column(Float)
    unemployment_pct     = Column(Float)
    gdp_growth_pct       = Column(Float)
    consumer_confidence  = Column(Float)


class PortfolioProperty(Base):
    __tablename__ = "portfolio"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    property_id     = Column(String(20))
    purchase_price  = Column(Float)
    purchase_date   = Column(String(12))
    current_value   = Column(Float)
    monthly_income  = Column(Float)
    holding_costs   = Column(Float)
    notes           = Column(String(500))


# ─────────────────────────────────────────────
# DATABASE ENGINE
# ─────────────────────────────────────────────


class DatabaseManager:
    """
    Manages the SQLAlchemy engine and provides DataFrame ↔ DB helpers.
    Connection string is read from CONFIG['db_url'] (defaults to SQLite).
    """

    def __init__(self, db_url: str | None = None):
        self.db_url = db_url or CONFIG["db_url"]
        log.info(f"Connecting to database: {self.db_url}")
        self.engine = create_engine(self.db_url, echo=False)
        self._SessionLocal = sessionmaker(bind=self.engine)
        self._init_schema()

    def _init_schema(self) -> None:
        """Creates all tables if they don't already exist."""
        Base.metadata.create_all(self.engine)
        log.info("Database schema initialised")

    @contextmanager
    def session(self) -> Generator[Session, None, None]:
        """Context manager for a transactional session."""
        s = self._SessionLocal()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()

    # ── DataFrame I/O ─────────────────────────────────────────────

    def upsert_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        if_exists: str = "append",
    ) -> int:
        """
        Writes a DataFrame to the specified table.
        'replace' drops and recreates; 'append' inserts new rows.
        Returns the number of rows written.
        """
        if df.empty:
            log.warning(f"Skipping empty DataFrame for table [{table_name}]")
            return 0
        df.to_sql(
            table_name,
            self.engine,
            if_exists=if_exists,
            index=False,
            chunksize=500,
            method="multi",
        )
        log.info(f"Wrote {len(df):,} rows → [{table_name}]")
        return len(df)

    def query(self, sql: str, params: dict | None = None) -> pd.DataFrame:
        """Executes a raw SQL query and returns a DataFrame."""
        with self.engine.connect() as conn:
            return pd.read_sql_query(text(sql), conn, params=params or {})

    def load_table(self, table_name: str) -> pd.DataFrame:
        """Loads an entire table into a DataFrame."""
        return self.query(f"SELECT * FROM {table_name}")

    def table_exists(self, table_name: str) -> bool:
        inspector = inspect(self.engine)
        return table_name in inspector.get_table_names()

    def persist_all(self, clean_data: dict[str, pd.DataFrame]) -> None:
        """
        Persists all cleaned DataFrames to the database, replacing existing data.
        Called from core.py after the cleaning pipeline completes.
        """
        table_map = {
            "properties": "properties",
            "sales_history": "sales_history",
            "neighbourhoods": "neighbourhoods",
            "economics": "economics",
        }
        for key, table in table_map.items():
            if key in clean_data:
                self.upsert_dataframe(clean_data[key], table, if_exists="replace")
