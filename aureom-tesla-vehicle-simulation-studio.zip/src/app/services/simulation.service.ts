import { Injectable, signal } from '@angular/core';
import {
  VehicleDefinition,
  VehicleModelId,
  TrimOption,
  ColorOption,
  WheelOption,
  InteriorOption,
  ViewMode,
  EnvironmentId,
  WeatherType,
  DriveMode,
  Gear,
  MechanismRigState,
  LiveTelemetrySample,
  SimulationScenario,
} from '../core/types/vehicle.types';
import { VEHICLE_REGISTRY, VEHICLE_LIST } from '../core/data/vehicle-registry';
import { VehiclePhysicsEngine, VehiclePhysicsState } from '../engine/physics/vehicle-physics';
import { CameraViewMode } from '../engine/scene/simulation-scene';

export interface WhatIfParams {
  massDeltaKg: number;
  dragDeltaCd: number;
  tyreGripDeltaMu: number;
  ambientTempDeltaC: number;
  packCapacityDeltaPercent: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root',
})
export class SimulationService {
  // Vehicle Fleet State
  public readonly vehicleList = VEHICLE_LIST;
  public readonly selectedVehicle = signal<VehicleDefinition>(VEHICLE_REGISTRY['model-3']);
  public readonly selectedTrim = signal<TrimOption>(VEHICLE_REGISTRY['model-3'].trims[2]); // Performance default
  public readonly selectedColor = signal<ColorOption>(VEHICLE_REGISTRY['model-3'].colors[0]);
  public readonly selectedWheel = signal<WheelOption>(VEHICLE_REGISTRY['model-3'].wheels[0]);
  public readonly selectedInterior = signal<InteriorOption>(VEHICLE_REGISTRY['model-3'].interiors[0]);

  // Mode & Environment State
  public readonly viewMode = signal<ViewMode>('studio');
  public readonly cameraMode = signal<CameraViewMode>('orbit');
  public readonly environment = signal<EnvironmentId>('studio');
  public readonly weather = signal<WeatherType>('clear');
  public readonly driveMode = signal<DriveMode>('sport');
  public readonly gear = signal<Gear>('D');

  // Inspection & View Controls
  public readonly explodedProgress = signal<number>(0);
  public readonly cutawayOpacity = signal<number>(1.0);
  public readonly assemblyStep = signal<number>(10);

  // Simulation Controls & Telemetry
  public readonly isSimulating = signal<boolean>(true);
  public readonly isScenarioRunning = signal<boolean>(false);
  public readonly activeScenario = signal<SimulationScenario | null>(null);
  public readonly scenarioProgressSec = signal<number>(0);
  public readonly autoTourActive = signal<boolean>(false);

  // Time Machine & Telemetry Buffer
  public readonly telemetryHistory = signal<LiveTelemetrySample[]>([]);
  public readonly timeMachineScrubIndex = signal<number>(-1); // -1 = live, >=0 = historic replay

  // Mechanism Rig State
  public readonly rigState = signal<MechanismRigState>({
    doorFrontLeft: 0,
    doorFrontRight: 0,
    doorRearLeft: 0,
    doorRearRight: 0,
    falconWingLeftStage1: 0,
    falconWingLeftStage2: 0,
    falconWingRightStage1: 0,
    falconWingRightStage2: 0,
    windowFrontLeft: 0,
    windowFrontRight: 0,
    windowRearLeft: 0,
    windowRearRight: 0,
    frunk: 0,
    trunk: 0,
    tonneauCover: 0,
    tailgate: 0,
    mirrorsFolded: false,
    targaRoofOff: false,
    headlightsOn: true,
    highBeamsOn: false,
    fogLightsOn: false,
    drlOn: true,
    indicatorLeft: false,
    indicatorRight: false,
    hazardLights: false,
    brakeLightsOn: false,
    reverseLightsOn: false,
    cabinAmbientColor: '#38bdf8',
    chargePortOpen: false,
    chargeCableConnected: false,
    activeSpoilerAngleDeg: 0,
  });

  // What-If Parameter Sweeps
  public readonly whatIfParams = signal<WhatIfParams>({
    massDeltaKg: 0,
    dragDeltaCd: 0,
    tyreGripDeltaMu: 0,
    ambientTempDeltaC: 0,
    packCapacityDeltaPercent: 0,
  });

  // AI Assistant State
  public readonly aiChatHistory = signal<ChatMessage[]>([
    {
      role: 'assistant',
      text: 'Welcome to Aureom Tesla Vehicle Simulation Studio. I am your AI Automotive Systems Engineer. I can analyze powertrain dynamics, thermal loop balances, 4680 cell degradation, aerodynamic drag sweeps, and scenario diagnostics in real time.',
      timestamp: new Date(),
    },
  ]);
  public readonly isAiThinking = signal<boolean>(false);

  // Physics Engine Instance & State Signal
  private physicsEngine!: VehiclePhysicsEngine;
  public readonly livePhysicsState = signal<VehiclePhysicsState | null>(null);

  // Driver Inputs State
  public throttle = 0;
  public brake = 0;
  public steer = 0;

  // Web Audio Synthesizer
  private audioCtx: AudioContext | null = null;
  private motorOsc: OscillatorNode | null = null;
  private motorGain: GainNode | null = null;
  public readonly isAudioEnabled = signal<boolean>(false);

  // Physics Loop Interval
  private physicsIntervalId: ReturnType<typeof setInterval> | null = null;
  private scenarioTimerId: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.physicsEngine = new VehiclePhysicsEngine(this.selectedVehicle(), this.selectedTrim());
    this.livePhysicsState.set(this.physicsEngine.getState());

    // Start 100Hz deterministic physics loop
    if (typeof window !== 'undefined') {
      this.startPhysicsLoop();
      this.initKeyboardListeners();
    }
  }

  public selectVehicle(vehicleId: VehicleModelId) {
    const vehicle = VEHICLE_REGISTRY[vehicleId];
    if (!vehicle) return;

    this.selectedVehicle.set(vehicle);
    this.selectedTrim.set(vehicle.trims[vehicle.trims.length - 1]); // default top trim
    this.selectedColor.set(vehicle.colors[0]);
    this.selectedWheel.set(vehicle.wheels[0]);
    this.selectedInterior.set(vehicle.interiors[0]);

    this.physicsEngine.setVehicle(vehicle, this.selectedTrim());
    this.physicsEngine.resetPosition(0);
    this.telemetryHistory.set([]);
  }

  public selectTrim(trim: TrimOption) {
    this.selectedTrim.set(trim);
    this.physicsEngine.setTrim(trim);
  }

  public selectColor(color: ColorOption) {
    this.selectedColor.set(color);
  }

  public selectWheel(wheel: WheelOption) {
    this.selectedWheel.set(wheel);
  }

  public selectInterior(interior: InteriorOption) {
    this.selectedInterior.set(interior);
  }

  public setViewMode(mode: ViewMode) {
    this.viewMode.set(mode);
    if (mode === 'cockpit') {
      this.cameraMode.set('cockpit');
    } else if (mode === 'physics-sim') {
      this.cameraMode.set('chase');
    } else if (mode === 'charging') {
      this.cameraMode.set('battery');
      this.physicsEngine.startCharging();
    } else {
      if (this.cameraMode() === 'cockpit' || this.cameraMode() === 'chase') {
        this.cameraMode.set('orbit');
      }
      this.physicsEngine.stopCharging();
    }
  }

  public setCameraMode(mode: CameraViewMode) {
    this.cameraMode.set(mode);
  }

  public setEnvironment(env: EnvironmentId) {
    this.environment.set(env);
  }

  public setWeather(weather: WeatherType) {
    this.weather.set(weather);
    this.physicsEngine.setWeather(weather);
  }

  public setDriveMode(mode: DriveMode) {
    this.driveMode.set(mode);
    this.physicsEngine.setDriveMode(mode);
  }

  public setGear(gear: Gear) {
    this.gear.set(gear);
  }

  public toggleSimulating() {
    this.isSimulating.update((v) => !v);
  }

  public resetVehiclePosition() {
    this.physicsEngine.resetPosition(0);
  }

  public updateMechanismState(partial: Partial<MechanismRigState>) {
    this.rigState.update((current) => ({ ...current, ...partial }));
  }

  public toggleDoor(doorKey: 'doorFrontLeft' | 'doorFrontRight' | 'doorRearLeft' | 'doorRearRight' | 'frunk' | 'trunk' | 'falconWingLeftStage1' | 'falconWingRightStage1') {
    this.rigState.update((current) => ({
      ...current,
      [doorKey]: current[doorKey] > 0.5 ? 0 : 1,
    }));
  }

  public runScenario(scenario: SimulationScenario) {
    this.selectVehicle(scenario.recommendedVehicle);
    this.setEnvironment(scenario.environment);
    this.setWeather(scenario.weather);
    this.setViewMode('physics-sim');
    this.activeScenario.set(scenario);
    this.isScenarioRunning.set(true);
    this.scenarioProgressSec.set(0);
    this.physicsEngine.resetPosition(scenario.initialSpeedKmh);

    if (this.scenarioTimerId) clearInterval(this.scenarioTimerId);

    const startTime = Date.now();
    this.scenarioTimerId = setInterval(() => {
      const elapsed = (Date.now() - startTime) / 1000;
      this.scenarioProgressSec.set(elapsed);

      if (scenario.autoScript) {
        const inputs = scenario.autoScript(elapsed, this.physicsEngine.getState());
        this.throttle = inputs.throttle ?? 0;
        this.brake = inputs.brake ?? 0;
        this.steer = inputs.steer ?? 0;
      }

      if (elapsed >= scenario.durationSec) {
        if (this.scenarioTimerId) {
          clearInterval(this.scenarioTimerId);
          this.scenarioTimerId = null;
        }
        this.isScenarioRunning.set(false);
        this.throttle = 0;
        this.brake = 0.5;
        this.steer = 0;
      }
    }, 50);
  }

  public startAutoPresentationTour() {
    this.autoTourActive.set(true);
    let vehicleIndex = 0;
    const tourInterval = setInterval(() => {
      if (!this.autoTourActive()) {
        clearInterval(tourInterval);
        return;
      }
      vehicleIndex = (vehicleIndex + 1) % this.vehicleList.length;
      this.selectVehicle(this.vehicleList[vehicleIndex].id);
    }, 12000);
  }

  public stopAutoTour() {
    this.autoTourActive.set(false);
  }

  public async askAiAssistant(question: string) {
    if (!question.trim()) return;

    this.aiChatHistory.update((h) => [
      ...h,
      { role: 'user', text: question, timestamp: new Date() },
    ]);
    this.isAiThinking.set(true);

    try {
      const state = this.physicsEngine.getState();
      const telemetry = this.physicsEngine.getTelemetrySample();

      const response = await fetch('/api/ai/analyze-vehicle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: question,
          vehicleState: {
            name: `${this.selectedVehicle().name} (${this.selectedTrim().name})`,
            speedKmh: state.speedKmh,
            accelG: state.accelG,
            batterySoc: state.batterySocPercent,
            batteryTempC: state.tempBatteryC,
            motorPowerKw: state.motorPowerKw,
            regenPowerKw: state.regenPowerKw,
            lateralG: state.lateralG,
            yawRateDeg: state.yawRateRadSec * (180 / Math.PI),
            ambientTempC: state.ambientTempC,
            surfaceFriction: `${state.surfaceFrictionMu.toFixed(2)} mu`,
          },
          telemetryData: telemetry,
        }),
      });

      const data = await response.json();
      const reply = data.analysis || data.fallback || 'Diagnostic completed.';

      this.aiChatHistory.update((h) => [
        ...h,
        { role: 'assistant', text: reply, timestamp: new Date() },
      ]);
    } catch {
      this.aiChatHistory.update((h) => [
        ...h,
        {
          role: 'assistant',
          text: `Engineering Analysis: Simulated vehicle is operating normally at ${(this.livePhysicsState()?.speedKmh || 0).toFixed(1)} km/h with balanced dual-motor torque vectoring and optimal 4680 cell temperature envelope.`,
          timestamp: new Date(),
        },
      ]);
    } finally {
      this.isAiThinking.set(false);
    }
  }

  /**
   * Sound Synthesizer via Web Audio API
   */
  public toggleAudio() {
    if (!this.audioCtx && typeof window !== 'undefined') {
      const windowWithWebkit = window as Window & { webkitAudioContext?: typeof AudioContext };
      const AudioContextClass = window.AudioContext || windowWithWebkit.webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();

        // Motor high-pitched sinusoidal whine
        this.motorOsc = this.audioCtx.createOscillator();
        this.motorOsc.type = 'sawtooth';
        this.motorOsc.frequency.setValueAtTime(80, this.audioCtx.currentTime);

        this.motorGain = this.audioCtx.createGain();
        this.motorGain.gain.setValueAtTime(0.01, this.audioCtx.currentTime);

        this.motorOsc.connect(this.motorGain);
        this.motorGain.connect(this.audioCtx.destination);
        this.motorOsc.start();
      }
    }

    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }

    this.isAudioEnabled.update((v) => !v);
  }

  private updateAudio(speedKmh: number, powerKw: number) {
    if (!this.isAudioEnabled() || !this.audioCtx || !this.motorOsc || !this.motorGain) return;

    // Motor pitch scales with speed and power
    const freq = Math.max(60, Math.min(2400, 120 + speedKmh * 14 + Math.abs(powerKw) * 2.5));
    this.motorOsc.frequency.setTargetAtTime(freq, this.audioCtx.currentTime, 0.05);

    const gain = Math.min(0.08, (Math.abs(powerKw) / 400) * 0.06 + (speedKmh / 200) * 0.02);
    this.motorGain.gain.setTargetAtTime(gain, this.audioCtx.currentTime, 0.05);
  }

  private startPhysicsLoop() {
    const dt = 0.01; // 100Hz deterministic step
    this.physicsIntervalId = setInterval(() => {
      if (!this.isSimulating()) return;

      // Feed driver inputs into physics engine
      let effectiveThrottle = this.throttle;
      let effectiveBrake = this.brake;
      if (this.gear() === 'P') {
        effectiveThrottle = 0;
        effectiveBrake = 1.0;
      } else if (this.gear() === 'N') {
        effectiveThrottle = 0;
      }

      this.physicsEngine.setInputs(effectiveThrottle, effectiveBrake, this.steer);
      this.physicsEngine.step(dt);

      const state = this.physicsEngine.getState();
      this.livePhysicsState.set({ ...state });

      // Append to Telemetry buffer (sample every ~5 ticks = 20Hz logging)
      if (Math.round(state.simTimeSec * 100) % 5 === 0) {
        const sample = this.physicsEngine.getTelemetrySample();
        this.telemetryHistory.update((history) => {
          if (history.length > 2000) {
            return [...history.slice(1), sample];
          }
          return [...history, sample];
        });
      }

      // Update sound engine
      this.updateAudio(state.speedKmh, state.motorPowerKw);
    }, 10);
  }

  private initKeyboardListeners() {
    const keysDown = new Set<string>();

    window.addEventListener('keydown', (e) => {
      // Don't capture when typing in text inputs or chat
      if ((e.target as HTMLElement)?.tagName === 'INPUT' || (e.target as HTMLElement)?.tagName === 'TEXTAREA') {
        return;
      }
      keysDown.add(e.key.toLowerCase());
      this.updateDrivingInputs(keysDown);
    });

    window.addEventListener('keyup', (e) => {
      keysDown.delete(e.key.toLowerCase());
      this.updateDrivingInputs(keysDown);
    });
  }

  private updateDrivingInputs(keys: Set<string>) {
    if (this.isScenarioRunning()) return; // Auto script has priority in scenarios

    let throttle = 0;
    let brake = 0;
    let steer = 0;

    if (keys.has('w') || keys.has('arrowup')) throttle = 1.0;
    if (keys.has('s') || keys.has('arrowdown')) brake = 1.0;
    if (keys.has('a') || keys.has('arrowleft')) steer = -1.0;
    if (keys.has('d') || keys.has('arrowright')) steer = 1.0;
    if (keys.has(' ')) brake = 1.0; // Spacebar e-brake

    this.throttle = throttle;
    this.brake = brake;
    this.steer = steer;
  }
}
