import * as THREE from 'three';
import { VehicleDefinition, ColorOption, WheelOption, InteriorOption } from '../../core/types/vehicle.types';

export interface VehicleMaterials {
  bodyPaint: THREE.MeshPhysicalMaterial;
  glass: THREE.MeshPhysicalMaterial;
  carbonFiber: THREE.MeshStandardMaterial;
  chrome: THREE.MeshStandardMaterial;
  darkPlastic: THREE.MeshStandardMaterial;
  chassisMetal: THREE.MeshStandardMaterial;
  batteryCell: THREE.MeshStandardMaterial;
  brakeRotor: THREE.MeshStandardMaterial;
  brakeCaliper: THREE.MeshStandardMaterial;
  tyreRubber: THREE.MeshStandardMaterial;
  headlightEmissive: THREE.MeshBasicMaterial;
  drlEmissive: THREE.MeshBasicMaterial;
  taillightEmissive: THREE.MeshBasicMaterial;
  brakeEmissive: THREE.MeshBasicMaterial;
  indicatorEmissive: THREE.MeshBasicMaterial;
  chargePortEmissive: THREE.MeshBasicMaterial;
  interiorLeather: THREE.MeshStandardMaterial;
  interiorAccent: THREE.MeshStandardMaterial;
  screenDisplay: THREE.MeshBasicMaterial;
}

export interface VehicleMeshRig {
  rootGroup: THREE.Group;
  bodyGroup: THREE.Group;
  doors: {
    frontLeft?: THREE.Group;
    frontRight?: THREE.Group;
    rearLeft?: THREE.Group;
    rearRight?: THREE.Group;
    falconWingLeft1?: THREE.Group;
    falconWingLeft2?: THREE.Group;
    falconWingRight1?: THREE.Group;
    falconWingRight2?: THREE.Group;
    tonneauCover?: THREE.Group;
    tailgate?: THREE.Group;
  };
  windows: {
    frontLeft?: THREE.Mesh;
    frontRight?: THREE.Mesh;
    rearLeft?: THREE.Mesh;
    rearRight?: THREE.Mesh;
  };
  hoodFrunk?: THREE.Group;
  trunk?: THREE.Group;
  mirrors: {
    left?: THREE.Object3D;
    right?: THREE.Object3D;
  };
  wheels: {
    frontLeft: THREE.Group;
    frontRight: THREE.Group;
    rearLeft: THREE.Group;
    rearRight: THREE.Group;
    frontLeftRotor: THREE.Mesh;
    frontRightRotor: THREE.Mesh;
    rearLeftRotor: THREE.Mesh;
    rearRightRotor: THREE.Mesh;
    frontLeftCaliper: THREE.Mesh;
    frontRightCaliper: THREE.Mesh;
    rearLeftCaliper: THREE.Mesh;
    rearRightCaliper: THREE.Mesh;
    frontLeftSteerPivot: THREE.Group;
    frontRightSteerPivot: THREE.Group;
  };
  suspension: {
    springFL?: THREE.Mesh;
    springFR?: THREE.Mesh;
    springRL?: THREE.Mesh;
    springRR?: THREE.Mesh;
  };
  interior: {
    steeringWheel?: THREE.Group;
    centerScreen?: THREE.Mesh;
    ambientLedStrip?: THREE.Mesh;
  };
  lighting: {
    headlightsLeft?: THREE.Mesh;
    headlightsRight?: THREE.Mesh;
    drlLeft?: THREE.Mesh;
    drlRight?: THREE.Mesh;
    taillights?: THREE.Mesh;
    brakeLights?: THREE.Mesh;
    indicatorFL?: THREE.Mesh;
    indicatorFR?: THREE.Mesh;
    indicatorRL?: THREE.Mesh;
    indicatorRR?: THREE.Mesh;
    chargePortGlow?: THREE.Mesh;
  };
  subassemblies: {
    chassis: THREE.Group;
    batteryPack: THREE.Group;
    powertrain: THREE.Group;
    suspension: THREE.Group;
    interior: THREE.Group;
    bodyPanels: THREE.Group;
  };
  materials: VehicleMaterials;
}

export class VehicleGeometryBuilder {
  /**
   * Builds the complete 3D procedural rig for any of the 9 vehicles
   */
  public static buildVehicle(
    vehicle: VehicleDefinition,
    color?: ColorOption,
    wheel?: WheelOption,
    interior?: InteriorOption
  ): VehicleMeshRig {
    const selectedColor = color || vehicle.colors[0];
    const selectedWheel = wheel || vehicle.wheels[0];
    const selectedInterior = interior || vehicle.interiors[0];

    const materials = this.createMaterials(selectedColor, selectedInterior);
    const rootGroup = new THREE.Group();
    rootGroup.name = `vehicle-${vehicle.id}`;

    // Subassemblies for exploded/cutaway views
    const chassisGroup = new THREE.Group();
    chassisGroup.name = 'subassembly-chassis';
    const batteryGroup = new THREE.Group();
    batteryGroup.name = 'subassembly-battery';
    const powertrainGroup = new THREE.Group();
    powertrainGroup.name = 'subassembly-powertrain';
    const suspensionGroup = new THREE.Group();
    suspensionGroup.name = 'subassembly-suspension';
    const interiorGroup = new THREE.Group();
    interiorGroup.name = 'subassembly-interior';
    const bodyPanelsGroup = new THREE.Group();
    bodyPanelsGroup.name = 'subassembly-bodyPanels';

    // Vehicle scale factor derived from dimensions
    const lengthM = vehicle.dimensions.lengthMm / 1000;
    const widthM = vehicle.dimensions.widthMm / 1000;
    const heightM = vehicle.dimensions.heightMm / 1000;
    const wheelbaseM = vehicle.dimensions.wheelbaseMm / 1000;
    const trackM = vehicle.dimensions.trackFrontMm / 1000;
    const wheelRadiusM = (vehicle.tyres.diameterMm / 2) / 1000;

    // 1. Build Chassis & Skateboard Frame
    this.buildSkateboardChassis(chassisGroup, batteryGroup, lengthM, widthM, wheelbaseM, materials);

    // 2. Build Powertrain (Motors, Inverters, Orange HV cables)
    this.buildPowertrain(powertrainGroup, vehicle, wheelbaseM, materials);

    // 3. Build Wheels, Brakes & Suspension
    const wheelsRig = this.buildWheelsAndSuspension(
      suspensionGroup,
      vehicle,
      selectedWheel,
      lengthM,
      widthM,
      wheelbaseM,
      trackM,
      wheelRadiusM,
      materials
    );

    // 4. Build Interior (Seats, Dashboard, Touchscreen, Ambient LED)
    const interiorRig = this.buildInterior(
      interiorGroup,
      vehicle,
      selectedInterior,
      lengthM,
      widthM,
      heightM,
      materials
    );

    // 5. Build Outer Body, Doors, Glass, Lighting
    const bodyRig = this.buildBodyPanelsAndDoors(
      bodyPanelsGroup,
      vehicle,
      lengthM,
      widthM,
      heightM,
      wheelbaseM,
      materials
    );

    // Add all subassemblies to root
    rootGroup.add(chassisGroup);
    rootGroup.add(batteryGroup);
    rootGroup.add(powertrainGroup);
    rootGroup.add(suspensionGroup);
    rootGroup.add(interiorGroup);
    rootGroup.add(bodyPanelsGroup);

    return {
      rootGroup,
      bodyGroup: bodyPanelsGroup,
      doors: bodyRig.doors,
      windows: bodyRig.windows,
      hoodFrunk: bodyRig.hoodFrunk,
      trunk: bodyRig.trunk,
      mirrors: bodyRig.mirrors,
      wheels: wheelsRig.wheels,
      suspension: wheelsRig.suspension,
      interior: interiorRig,
      lighting: bodyRig.lighting,
      subassemblies: {
        chassis: chassisGroup,
        batteryPack: batteryGroup,
        powertrain: powertrainGroup,
        suspension: suspensionGroup,
        interior: interiorGroup,
        bodyPanels: bodyPanelsGroup,
      },
      materials,
    };
  }

  private static createMaterials(color: ColorOption, interior: InteriorOption) {
    const bodyPaint = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color.hex),
      metalness: color.metallic,
      roughness: color.roughness,
      clearcoat: color.clearcoat,
      clearcoatRoughness: 0.05,
      reflectivity: 0.9,
    });

    const glass = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#0a111a'),
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.88,
      thickness: 0.04,
      transparent: true,
      opacity: 0.85,
    });

    const carbonFiber = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#1c1e22'),
      metalness: 0.7,
      roughness: 0.35,
    });

    const chrome = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#e0e4ec'),
      metalness: 0.95,
      roughness: 0.1,
    });

    const darkPlastic = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#18191c'),
      metalness: 0.1,
      roughness: 0.8,
    });

    const chassisMetal = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#50555d'),
      metalness: 0.85,
      roughness: 0.4,
    });

    const batteryCell = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#10b981'), // Glowing green/cyan cell
      metalness: 0.8,
      roughness: 0.3,
      emissive: new THREE.Color('#047857'),
      emissiveIntensity: 0.35,
    });

    const brakeRotor = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#8a9099'),
      metalness: 0.9,
      roughness: 0.3,
    });

    const brakeCaliper = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#dc2626'), // Brembo red
      metalness: 0.7,
      roughness: 0.3,
    });

    const tyreRubber = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#141517'),
      metalness: 0.05,
      roughness: 0.85,
    });

    const headlightEmissive = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#e0f2fe'),
    });

    const drlEmissive = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#ffffff'),
    });

    const taillightEmissive = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#ef4444'),
    });

    const brakeEmissive = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#ff0000'),
    });

    const indicatorEmissive = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#f59e0b'),
    });

    const chargePortEmissive = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#06b6d4'),
    });

    const interiorLeather = new THREE.MeshStandardMaterial({
      color: new THREE.Color(interior.seatColorHex),
      metalness: 0.1,
      roughness: 0.65,
    });

    const interiorAccent = new THREE.MeshStandardMaterial({
      color: interior.woodOrCarbon === 'carbon' ? new THREE.Color('#1c1e22') : (interior.woodOrCarbon === 'white' ? new THREE.Color('#f1f5f9') : new THREE.Color('#784725')),
      metalness: interior.woodOrCarbon === 'carbon' ? 0.6 : 0.1,
      roughness: interior.woodOrCarbon === 'carbon' ? 0.3 : 0.7,
    });

    const screenCanvas = document.createElement('canvas');
    screenCanvas.width = 512;
    screenCanvas.height = 256;
    const ctx = screenCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#0b0f19';
      ctx.fillRect(0, 0, 512, 256);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 24px monospace';
      ctx.fillText('AUREOM TESLA OS 3.7', 24, 45);
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '16px monospace';
      ctx.fillText('SPEED: 0 KM/H   BATTERY: 82%   FSD: READY', 24, 85);
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.strokeRect(20, 110, 472, 120);
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('NAVIGATION SIMULATOR: PROVING GROUNDS', 40, 150);
      ctx.fillText('DUAL MOTOR SYNCRM: ACTIVE TORQUE VECTORING', 40, 180);
    }
    const screenTexture = new THREE.CanvasTexture(screenCanvas);
    const screenDisplay = new THREE.MeshBasicMaterial({
      map: screenTexture,
    });

    return {
      bodyPaint,
      glass,
      carbonFiber,
      chrome,
      darkPlastic,
      chassisMetal,
      batteryCell,
      brakeRotor,
      brakeCaliper,
      tyreRubber,
      headlightEmissive,
      drlEmissive,
      taillightEmissive,
      brakeEmissive,
      indicatorEmissive,
      chargePortEmissive,
      interiorLeather,
      interiorAccent,
      screenDisplay,
    };
  }

  private static buildSkateboardChassis(
    chassisGroup: THREE.Group,
    batteryGroup: THREE.Group,
    lengthM: number,
    widthM: number,
    wheelbaseM: number,
    materials: VehicleMaterials
  ) {
    // 1. Structural Skateboard Base Tray
    const trayWidth = widthM * 0.76;
    const trayLength = wheelbaseM * 0.95;
    const trayHeight = 0.12;

    const trayGeo = new THREE.BoxGeometry(trayWidth, trayHeight, trayLength);
    const trayMesh = new THREE.Mesh(trayGeo, materials.chassisMetal);
    trayMesh.position.set(0, 0.22, 0);
    trayMesh.castShadow = true;
    trayMesh.receiveShadow = true;
    batteryGroup.add(trayMesh);

    // 2. Battery 4680 / Prismatic Cell Arrays Matrix (Visual Cross-Section)
    const cellRows = 6;
    const cellCols = 14;
    const cellRadius = 0.024;
    const cellHeight = 0.08;
    const cellGeo = new THREE.CylinderGeometry(cellRadius, cellRadius, cellHeight, 10);

    const cellInstanced = new THREE.InstancedMesh(cellGeo, materials.batteryCell, cellRows * cellCols);
    const dummy = new THREE.Object3D();
    let idx = 0;
    const xStep = (trayWidth * 0.85) / cellRows;
    const zStep = (trayLength * 0.88) / cellCols;
    const startX = -((cellRows - 1) * xStep) / 2;
    const startZ = -((cellCols - 1) * zStep) / 2;

    for (let r = 0; r < cellRows; r++) {
      for (let c = 0; c < cellCols; c++) {
        dummy.position.set(startX + r * xStep, 0.22, startZ + c * zStep);
        dummy.updateMatrix();
        cellInstanced.setMatrixAt(idx++, dummy.matrix);
      }
    }
    cellInstanced.instanceMatrix.needsUpdate = true;
    batteryGroup.add(cellInstanced);

    // 3. Front Single-Piece Megacasting & Subframe
    const frontCastGeo = new THREE.BoxGeometry(trayWidth * 0.85, 0.24, 0.65);
    const frontCastMesh = new THREE.Mesh(frontCastGeo, materials.chassisMetal);
    frontCastMesh.position.set(0, 0.32, wheelbaseM * 0.5 + 0.15);
    chassisGroup.add(frontCastMesh);

    // 4. Rear Megacasting & Subframe
    const rearCastGeo = new THREE.BoxGeometry(trayWidth * 0.88, 0.26, 0.75);
    const rearCastMesh = new THREE.Mesh(rearCastGeo, materials.chassisMetal);
    rearCastMesh.position.set(0, 0.34, -(wheelbaseM * 0.5 + 0.15));
    chassisGroup.add(rearCastMesh);

    // 5. High-Voltage Orange Busbar Runs
    const busbarCurve = new THREE.LineCurve3(
      new THREE.Vector3(0.08, 0.28, wheelbaseM * 0.5),
      new THREE.Vector3(0.08, 0.28, -wheelbaseM * 0.5)
    );
    const busbarGeo = new THREE.TubeGeometry(busbarCurve, 10, 0.015, 8, false);
    const orangeHvMat = new THREE.MeshStandardMaterial({ color: '#ea580c', roughness: 0.4, metalness: 0.3 });
    const busbarMesh = new THREE.Mesh(busbarGeo, orangeHvMat);
    batteryGroup.add(busbarMesh);
  }

  private static buildPowertrain(
    powertrainGroup: THREE.Group,
    vehicle: VehicleDefinition,
    wheelbaseM: number,
    materials: VehicleMaterials
  ) {
    const motorMat = new THREE.MeshStandardMaterial({ color: '#2b2e35', metalness: 0.85, roughness: 0.3 });

    // Front Motor Unit (Induction / PM SynRM)
    const frontMotorGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.36, 16);
    frontMotorGeo.rotateZ(Math.PI / 2);
    const frontMotorMesh = new THREE.Mesh(frontMotorGeo, motorMat);
    frontMotorMesh.position.set(0, 0.32, wheelbaseM * 0.5);
    powertrainGroup.add(frontMotorMesh);

    // Front Inverter Module (SiC)
    const frontInvGeo = new THREE.BoxGeometry(0.25, 0.12, 0.22);
    const frontInvMesh = new THREE.Mesh(frontInvGeo, materials.chrome);
    frontInvMesh.position.set(0, 0.44, wheelbaseM * 0.5);
    powertrainGroup.add(frontInvMesh);

    // Rear Drive Unit (Carbon-Sleeved Performance / Dual PM)
    const rearMotorGeo = new THREE.CylinderGeometry(0.17, 0.17, 0.46, 18);
    rearMotorGeo.rotateZ(Math.PI / 2);
    const rearMotorMesh = new THREE.Mesh(rearMotorGeo, motorMat);
    rearMotorMesh.position.set(0, 0.34, -wheelbaseM * 0.5);
    powertrainGroup.add(rearMotorMesh);

    // Rear Inverter Module
    const rearInvGeo = new THREE.BoxGeometry(0.32, 0.14, 0.26);
    const rearInvMesh = new THREE.Mesh(rearInvGeo, materials.chrome);
    rearInvMesh.position.set(0, 0.48, -wheelbaseM * 0.5);
    powertrainGroup.add(rearInvMesh);

    // Drive Half-Shafts
    const shaftMat = materials.chassisMetal;
    const shaftGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.4, 8);
    shaftGeo.rotateZ(Math.PI / 2);

    const fShaftL = new THREE.Mesh(shaftGeo, shaftMat);
    fShaftL.position.set(-0.35, 0.32, wheelbaseM * 0.5);
    const fShaftR = new THREE.Mesh(shaftGeo, shaftMat);
    fShaftR.position.set(0.35, 0.32, wheelbaseM * 0.5);
    const rShaftL = new THREE.Mesh(shaftGeo, shaftMat);
    rShaftL.position.set(-0.4, 0.34, -wheelbaseM * 0.5);
    const rShaftR = new THREE.Mesh(shaftGeo, shaftMat);
    rShaftR.position.set(0.4, 0.34, -wheelbaseM * 0.5);

    powertrainGroup.add(fShaftL, fShaftR, rShaftL, rShaftR);
  }

  private static buildWheelsAndSuspension(
    suspensionGroup: THREE.Group,
    vehicle: VehicleDefinition,
    wheelOption: WheelOption,
    lengthM: number,
    widthM: number,
    wheelbaseM: number,
    trackM: number,
    wheelRadiusM: number,
    materials: VehicleMaterials
  ) {
    const halfTrack = trackM * 0.5;
    const halfWb = wheelbaseM * 0.5;
    const tyreWidth = (vehicle.tyres.widthMm / 1000) || 0.245;

    // Wheel Geometry Generator
    const createWheelAssembly = (isFront: boolean, isLeft: boolean) => {
      const wheelAssembly = new THREE.Group();
      wheelAssembly.name = `wheel-${isFront ? 'front' : 'rear'}-${isLeft ? 'left' : 'right'}`;

      // Tyre (Torus or Cylinder with bevel)
      const tyreGeo = new THREE.CylinderGeometry(wheelRadiusM, wheelRadiusM, tyreWidth, 24);
      tyreGeo.rotateZ(Math.PI / 2);
      const tyreMesh = new THREE.Mesh(tyreGeo, materials.tyreRubber);
      tyreMesh.castShadow = true;
      wheelAssembly.add(tyreMesh);

      // Rim & Spokes
      const rimRadius = wheelRadiusM * 0.72;
      const rimGeo = new THREE.CylinderGeometry(rimRadius, rimRadius, tyreWidth * 0.98, 16);
      rimGeo.rotateZ(Math.PI / 2);
      const rimMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(wheelOption.colorHex),
        metalness: 0.9,
        roughness: 0.25,
      });
      const rimMesh = new THREE.Mesh(rimGeo, rimMat);
      wheelAssembly.add(rimMesh);

      // Aero Aero Disk / Spokes Overlay
      const spokeCount = 5;
      for (let s = 0; s < spokeCount; s++) {
        const spokeGeo = new THREE.BoxGeometry(0.035, rimRadius * 1.6, tyreWidth * 0.5);
        const spokeMesh = new THREE.Mesh(spokeGeo, rimMat);
        spokeMesh.rotation.x = (s * Math.PI) / spokeCount;
        wheelAssembly.add(spokeMesh);
      }

      // Brake Rotor (Grooved Disk)
      const rotorRadius = rimRadius * 0.78;
      const rotorGeo = new THREE.CylinderGeometry(rotorRadius, rotorRadius, 0.024, 20);
      rotorGeo.rotateZ(Math.PI / 2);
      const rotorMesh = new THREE.Mesh(rotorGeo, materials.brakeRotor);
      rotorMesh.position.x = isLeft ? 0.03 : -0.03;
      wheelAssembly.add(rotorMesh);

      // Brake Caliper (Brembo Style Red/Silver)
      const caliperGeo = new THREE.BoxGeometry(0.06, rotorRadius * 0.7, 0.08);
      const caliperMesh = new THREE.Mesh(caliperGeo, materials.brakeCaliper);
      caliperMesh.position.set(isLeft ? 0.04 : -0.04, rotorRadius * 0.65, 0);
      wheelAssembly.add(caliperMesh);

      return { assembly: wheelAssembly, rotor: rotorMesh, caliper: caliperMesh };
    };

    // Front Left Steer Pivot & Wheel
    const flSteerPivot = new THREE.Group();
    flSteerPivot.position.set(-halfTrack, wheelRadiusM, halfWb);
    const flWheel = createWheelAssembly(true, true);
    flSteerPivot.add(flWheel.assembly);
    suspensionGroup.add(flSteerPivot);

    // Front Right Steer Pivot & Wheel
    const frSteerPivot = new THREE.Group();
    frSteerPivot.position.set(halfTrack, wheelRadiusM, halfWb);
    const frWheel = createWheelAssembly(true, false);
    frSteerPivot.add(frWheel.assembly);
    suspensionGroup.add(frSteerPivot);

    // Rear Left Wheel
    const rlWheel = createWheelAssembly(false, true);
    rlWheel.assembly.position.set(-halfTrack, wheelRadiusM, -halfWb);
    suspensionGroup.add(rlWheel.assembly);

    // Rear Right Wheel
    const rrWheel = createWheelAssembly(false, false);
    rrWheel.assembly.position.set(halfTrack, wheelRadiusM, -halfWb);
    suspensionGroup.add(rrWheel.assembly);

    // Suspension Coilover Springs (Double-Wishbone / Multilink)
    const springMat = new THREE.MeshStandardMaterial({ color: '#38bdf8', metalness: 0.8, roughness: 0.3 });
    const springGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.28, 12);

    const springFL = new THREE.Mesh(springGeo, springMat);
    springFL.position.set(-halfTrack * 0.75, wheelRadiusM + 0.15, halfWb);
    const springFR = new THREE.Mesh(springGeo, springMat);
    springFR.position.set(halfTrack * 0.75, wheelRadiusM + 0.15, halfWb);
    const springRL = new THREE.Mesh(springGeo, springMat);
    springRL.position.set(-halfTrack * 0.75, wheelRadiusM + 0.15, -halfWb);
    const springRR = new THREE.Mesh(springGeo, springMat);
    springRR.position.set(halfTrack * 0.75, wheelRadiusM + 0.15, -halfWb);

    suspensionGroup.add(springFL, springFR, springRL, springRR);

    return {
      wheels: {
        frontLeft: flWheel.assembly,
        frontRight: frWheel.assembly,
        rearLeft: rlWheel.assembly,
        rearRight: rrWheel.assembly,
        frontLeftRotor: flWheel.rotor,
        frontRightRotor: frWheel.rotor,
        rearLeftRotor: rlWheel.rotor,
        rearRightRotor: rrWheel.rotor,
        frontLeftCaliper: flWheel.caliper,
        frontRightCaliper: frWheel.caliper,
        rearLeftCaliper: rlWheel.caliper,
        rearRightCaliper: rrWheel.caliper,
        frontLeftSteerPivot: flSteerPivot,
        frontRightSteerPivot: frSteerPivot,
      },
      suspension: {
        springFL,
        springFR,
        springRL,
        springRR,
      },
    };
  }

  private static buildInterior(
    interiorGroup: THREE.Group,
    vehicle: VehicleDefinition,
    interior: InteriorOption,
    lengthM: number,
    widthM: number,
    heightM: number,
    materials: VehicleMaterials
  ) {
    const seatWidth = widthM * 0.24;
    const seatLength = 0.52;
    const seatHeight = 0.65;

    // Front Bucket Seats
    const seatGeo = new THREE.BoxGeometry(seatWidth, seatHeight, seatLength);
    const seatFL = new THREE.Mesh(seatGeo, materials.interiorLeather);
    seatFL.position.set(-widthM * 0.22, 0.62, 0.1);
    const seatFR = new THREE.Mesh(seatGeo, materials.interiorLeather);
    seatFR.position.set(widthM * 0.22, 0.62, 0.1);

    // Rear Bench Seat
    const rearBenchGeo = new THREE.BoxGeometry(widthM * 0.75, seatHeight * 0.9, seatLength * 1.1);
    const seatRear = new THREE.Mesh(rearBenchGeo, materials.interiorLeather);
    seatRear.position.set(0, 0.62, -lengthM * 0.18);

    interiorGroup.add(seatFL, seatFR, seatRear);

    // Minimalist Horizontal Dashboard
    const dashWidth = widthM * 0.82;
    const dashGeo = new THREE.BoxGeometry(dashWidth, 0.16, 0.38);
    const dashMesh = new THREE.Mesh(dashGeo, materials.darkPlastic);
    dashMesh.position.set(0, 0.74, 0.68);

    // Dashboard Accent Trim (Open Pore Wood or Carbon Fiber)
    const accentGeo = new THREE.BoxGeometry(dashWidth * 0.96, 0.03, 0.12);
    const accentMesh = new THREE.Mesh(accentGeo, materials.interiorAccent);
    accentMesh.position.set(0, 0.81, 0.72);

    interiorGroup.add(dashMesh, accentMesh);

    // Central Touchscreen Display (15.4" - 17" Tilting Display)
    const screenGeo = new THREE.BoxGeometry(0.38, 0.24, 0.02);
    const centerScreen = new THREE.Mesh(screenGeo, materials.screenDisplay);
    centerScreen.position.set(0, 0.86, 0.62);
    centerScreen.rotation.x = -0.15; // slightly tilted back
    interiorGroup.add(centerScreen);

    // Steering Mechanism (Yoke or Round Wheel)
    const steeringWheelGroup = new THREE.Group();
    steeringWheelGroup.position.set(-widthM * 0.22, 0.82, 0.52);

    if (interior.steeringType === 'yoke' || vehicle.id === 'cybertruck' || vehicle.id === 'model-s' || vehicle.id === 'roadster') {
      // Yoke Steering
      const yokeUGeo = new THREE.TorusGeometry(0.14, 0.016, 8, 16, Math.PI);
      yokeUGeo.rotateX(Math.PI / 2);
      const yokeMesh = new THREE.Mesh(yokeUGeo, materials.darkPlastic);
      steeringWheelGroup.add(yokeMesh);
    } else {
      // Classic Round Steering Wheel
      const wheelGeo = new THREE.TorusGeometry(0.16, 0.016, 8, 24);
      const wheelMesh = new THREE.Mesh(wheelGeo, materials.darkPlastic);
      steeringWheelGroup.add(wheelMesh);
    }
    steeringWheelGroup.rotation.x = -0.35;
    interiorGroup.add(steeringWheelGroup);

    // Ambient LED Strip Channel
    const ledCurve = new THREE.LineCurve3(
      new THREE.Vector3(-dashWidth * 0.45, 0.78, 0.62),
      new THREE.Vector3(dashWidth * 0.45, 0.78, 0.62)
    );
    const ledGeo = new THREE.TubeGeometry(ledCurve, 10, 0.008, 8, false);
    const ambientLedStrip = new THREE.Mesh(ledGeo, materials.chargePortEmissive);
    interiorGroup.add(ambientLedStrip);

    return {
      steeringWheel: steeringWheelGroup,
      centerScreen,
      ambientLedStrip,
    };
  }

  private static buildBodyPanelsAndDoors(
    bodyGroup: THREE.Group,
    vehicle: VehicleDefinition,
    lengthM: number,
    widthM: number,
    heightM: number,
    wheelbaseM: number,
    materials: VehicleMaterials
  ) {
    const isCybertruck = vehicle.id === 'cybertruck';
    const isSemi = vehicle.id === 'semi';

    // 1. Main Outer Body Shell
    let bodyMesh: THREE.Mesh;
    if (isCybertruck) {
      // Angular Origami Exoskeleton Geometry
      const cyberShape = new THREE.Shape();
      cyberShape.moveTo(-lengthM * 0.5, 0.45);
      cyberShape.lineTo(-lengthM * 0.45, heightM * 0.72); // Rear vault peak
      cyberShape.lineTo(0, heightM); // Roof triangle apex
      cyberShape.lineTo(lengthM * 0.42, heightM * 0.55); // Hood apex
      cyberShape.lineTo(lengthM * 0.5, 0.45); // Front bumper
      cyberShape.lineTo(lengthM * 0.5, 0.28);
      cyberShape.lineTo(-lengthM * 0.5, 0.28);
      cyberShape.closePath();

      const extrudeSettings = { depth: widthM * 0.88, bevelEnabled: false };
      const cyberGeo = new THREE.ExtrudeGeometry(cyberShape, extrudeSettings);
      cyberGeo.center();
      cyberGeo.rotateY(Math.PI / 2);
      bodyMesh = new THREE.Mesh(cyberGeo, materials.bodyPaint);
      bodyMesh.position.set(0, heightM * 0.45, 0);
    } else if (isSemi) {
      // Semi Aerodynamic Cab Fairing
      const semiGeo = new THREE.BoxGeometry(widthM * 0.85, heightM * 0.85, lengthM * 0.7);
      bodyMesh = new THREE.Mesh(semiGeo, materials.bodyPaint);
      bodyMesh.position.set(0, heightM * 0.52, 0);
    } else {
      // Streamline Aerodynamic Curvature Body (Model 3, Y, S, X, Roadster, Cybercab, Robovan)
      const bodyGeo = new THREE.BoxGeometry(widthM * 0.86, heightM * 0.55, lengthM * 0.88);
      bodyMesh = new THREE.Mesh(bodyGeo, materials.bodyPaint);
      bodyMesh.position.set(0, heightM * 0.48, 0);
    }

    bodyMesh.castShadow = true;
    bodyMesh.receiveShadow = true;
    bodyGroup.add(bodyMesh);

    // 2. Panoramic Glass Canopy / Windshield
    const glassWidth = widthM * 0.78;
    const glassLength = lengthM * 0.62;
    const glassGeo = new THREE.BoxGeometry(glassWidth, heightM * 0.38, glassLength);
    const glassMesh = new THREE.Mesh(glassGeo, materials.glass);
    glassMesh.position.set(0, heightM * 0.72, -lengthM * 0.02);
    bodyGroup.add(glassMesh);

    // 3. Doors Rigging (With Accurate Open/Close Hinge Pivots)
    const doors: Record<string, THREE.Group> = {};
    const windows: Record<string, THREE.Mesh> = {};

    const doorWidth = 0.05;
    const doorHeight = heightM * 0.45;
    const doorLength = lengthM * 0.22;
    const doorGeo = new THREE.BoxGeometry(doorWidth, doorHeight, doorLength);

    if (vehicle.doorConfig === 'FALCON_WING_REAR') {
      // Model X Dual-Hinged Falcon Wing Doors
      // Stage 1 (Roof Hinge Pivot)
      const fwLeft1 = new THREE.Group();
      fwLeft1.position.set(-widthM * 0.38, heightM * 0.95, -lengthM * 0.12);
      const fwLeftMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      fwLeftMesh.position.set(0, -doorHeight * 0.5, 0);
      fwLeft1.add(fwLeftMesh);
      bodyGroup.add(fwLeft1);
      doors['falconWingLeft1'] = fwLeft1;

      const fwRight1 = new THREE.Group();
      fwRight1.position.set(widthM * 0.38, heightM * 0.95, -lengthM * 0.12);
      const fwRightMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      fwRightMesh.position.set(0, -doorHeight * 0.5, 0);
      fwRight1.add(fwRightMesh);
      bodyGroup.add(fwRight1);
      doors['falconWingRight1'] = fwRight1;

      // Front standard doors for Model X
      const flDoorGroup = new THREE.Group();
      flDoorGroup.position.set(-widthM * 0.44, heightM * 0.48, lengthM * 0.18);
      const flMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      flMesh.position.set(0, 0, -doorLength * 0.5);
      flDoorGroup.add(flMesh);
      bodyGroup.add(flDoorGroup);
      doors['frontLeft'] = flDoorGroup;

      const frDoorGroup = new THREE.Group();
      frDoorGroup.position.set(widthM * 0.44, heightM * 0.48, lengthM * 0.18);
      const frMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      frMesh.position.set(0, 0, -doorLength * 0.5);
      frDoorGroup.add(frMesh);
      bodyGroup.add(frDoorGroup);
      doors['frontRight'] = frDoorGroup;
    } else if (vehicle.doorConfig === 'BUTTERFLY_2') {
      // Cybercab Upward Dihedral Butterfly Doors
      const flDoorGroup = new THREE.Group();
      flDoorGroup.position.set(-widthM * 0.42, heightM * 0.65, lengthM * 0.1);
      const flMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      flDoorGroup.add(flMesh);
      bodyGroup.add(flDoorGroup);
      doors['frontLeft'] = flDoorGroup;

      const frDoorGroup = new THREE.Group();
      frDoorGroup.position.set(widthM * 0.42, heightM * 0.65, lengthM * 0.1);
      const frMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      frDoorGroup.add(frMesh);
      bodyGroup.add(frDoorGroup);
      doors['frontRight'] = frDoorGroup;
    } else {
      // Standard 4 Doors
      // Front Left Door Pivot (Hinged at A-pillar)
      const flDoorGroup = new THREE.Group();
      flDoorGroup.position.set(-widthM * 0.44, heightM * 0.48, lengthM * 0.18);
      const flMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      flMesh.position.set(0, 0, -doorLength * 0.5);
      flDoorGroup.add(flMesh);
      bodyGroup.add(flDoorGroup);
      doors['frontLeft'] = flDoorGroup;

      // Front Right Door Pivot
      const frDoorGroup = new THREE.Group();
      frDoorGroup.position.set(widthM * 0.44, heightM * 0.48, lengthM * 0.18);
      const frMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      frMesh.position.set(0, 0, -doorLength * 0.5);
      frDoorGroup.add(frMesh);
      bodyGroup.add(frDoorGroup);
      doors['frontRight'] = frDoorGroup;

      // Rear Left Door Pivot (Hinged at B-pillar)
      const rlDoorGroup = new THREE.Group();
      rlDoorGroup.position.set(-widthM * 0.44, heightM * 0.48, -lengthM * 0.04);
      const rlMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      rlMesh.position.set(0, 0, -doorLength * 0.5);
      rlDoorGroup.add(rlMesh);
      bodyGroup.add(rlDoorGroup);
      doors['rearLeft'] = rlDoorGroup;

      // Rear Right Door Pivot
      const rrDoorGroup = new THREE.Group();
      rrDoorGroup.position.set(widthM * 0.44, heightM * 0.48, -lengthM * 0.04);
      const rrMesh = new THREE.Mesh(doorGeo, materials.bodyPaint);
      rrMesh.position.set(0, 0, -doorLength * 0.5);
      rrDoorGroup.add(rrMesh);
      bodyGroup.add(rrDoorGroup);
      doors['rearRight'] = rrDoorGroup;
    }

    // 4. Frunk (Hood) & Trunk (Powered Liftgate)
    const hoodFrunkGroup = new THREE.Group();
    hoodFrunkGroup.position.set(0, heightM * 0.58, lengthM * 0.22);
    const hoodGeo = new THREE.BoxGeometry(widthM * 0.76, 0.03, lengthM * 0.28);
    const hoodMesh = new THREE.Mesh(hoodGeo, materials.bodyPaint);
    hoodMesh.position.set(0, 0, lengthM * 0.14);
    hoodFrunkGroup.add(hoodMesh);
    bodyGroup.add(hoodFrunkGroup);

    const trunkGroup = new THREE.Group();
    trunkGroup.position.set(0, heightM * 0.82, -lengthM * 0.32);
    const trunkGeo = new THREE.BoxGeometry(widthM * 0.74, 0.04, lengthM * 0.22);
    const trunkMesh = new THREE.Mesh(trunkGeo, materials.bodyPaint);
    trunkMesh.position.set(0, 0, -lengthM * 0.11);
    trunkGroup.add(trunkMesh);
    bodyGroup.add(trunkGroup);

    // 5. Cybertruck Motorized Tonneau Shutter Cover
    let tonneauGroup: THREE.Group | undefined;
    if (isCybertruck) {
      tonneauGroup = new THREE.Group();
      tonneauGroup.position.set(0, heightM * 0.78, -lengthM * 0.15);
      const tonneauGeo = new THREE.BoxGeometry(widthM * 0.72, 0.02, lengthM * 0.35);
      const tonneauMesh = new THREE.Mesh(tonneauGeo, materials.darkPlastic);
      tonneauGroup.add(tonneauMesh);
      bodyGroup.add(tonneauGroup);
      doors['tonneauCover'] = tonneauGroup;
    }

    // 6. Side Mirrors with Tesla Vision Autopilot Cameras
    const mirrorGeo = new THREE.BoxGeometry(0.14, 0.08, 0.18);
    const mirrorLeft = new THREE.Mesh(mirrorGeo, materials.bodyPaint);
    mirrorLeft.position.set(-widthM * 0.48, heightM * 0.65, lengthM * 0.18);
    const mirrorRight = new THREE.Mesh(mirrorGeo, materials.bodyPaint);
    mirrorRight.position.set(widthM * 0.48, heightM * 0.65, lengthM * 0.18);
    bodyGroup.add(mirrorLeft, mirrorRight);

    // 7. Lighting Clusters (Matrix LED Front, DRLs, Rear Lightbars, Indicators, Charge Port)
    const headLightGeo = new THREE.BoxGeometry(0.18, 0.04, 0.12);
    const headlightsLeft = new THREE.Mesh(headLightGeo, materials.headlightEmissive);
    headlightsLeft.position.set(-widthM * 0.35, heightM * 0.46, lengthM * 0.45);

    const headlightsRight = new THREE.Mesh(headLightGeo, materials.headlightEmissive);
    headlightsRight.position.set(widthM * 0.35, heightM * 0.46, lengthM * 0.45);

    // DRL Horizon Lightbar Strip (Full width for Cybertruck/Robovan/New Model 3)
    const drlGeo = new THREE.BoxGeometry(widthM * 0.8, 0.02, 0.04);
    const drlMesh = new THREE.Mesh(drlGeo, materials.drlEmissive);
    drlMesh.position.set(0, heightM * 0.49, lengthM * 0.46);

    // Rear Taillight & Brake Lightbar
    const tailGeo = new THREE.BoxGeometry(widthM * 0.78, 0.03, 0.04);
    const taillights = new THREE.Mesh(tailGeo, materials.taillightEmissive);
    taillights.position.set(0, heightM * 0.52, -lengthM * 0.45);

    // Animated Charging Port LED Glow (Driver Side Rear Tailfin)
    const chargePortGeo = new THREE.TorusGeometry(0.025, 0.006, 8, 16);
    chargePortGeo.rotateY(Math.PI / 2);
    const chargePortGlow = new THREE.Mesh(chargePortGeo, materials.chargePortEmissive);
    chargePortGlow.position.set(-widthM * 0.435, heightM * 0.55, -lengthM * 0.42);

    bodyGroup.add(headlightsLeft, headlightsRight, drlMesh, taillights, chargePortGlow);

    return {
      doors,
      windows,
      hoodFrunk: hoodFrunkGroup,
      trunk: trunkGroup,
      mirrors: { left: mirrorLeft, right: mirrorRight },
      lighting: {
        headlightsLeft,
        headlightsRight,
        drlLeft: drlMesh,
        taillights,
        chargePortGlow,
      },
    };
  }
}
