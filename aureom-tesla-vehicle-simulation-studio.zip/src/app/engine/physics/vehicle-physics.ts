import {
  VehicleDefinition,
  TrimOption,
  WeatherType,
  ChargingState,
  DriveMode,
  LiveTelemetrySample,
} from '../../core/types/vehicle.types';

export interface VehiclePhysicsState {
  // Kinematics
  x: number;
  y: number; // ground plane
  z: number;
  vx: number;
  vy: number;
  vz: number;
  speedMs: number;
  speedKmh: number;
  speedMph: number;
  accelXMs2: number; // longitudinal
  accelYMs2: number; // vertical
  accelZMs2: number; // lateral
  accelG: number;
  lateralG: number;

  // Angles (Radians)
  headingRad: number;
  pitchRad: number;
  rollRad: number;
  yawRateRadSec: number;
  steeringAngleRad: number;

  // Driver Inputs
  throttleInput: number; // 0 to 1
  brakeInput: number; // 0 to 1
  steerInput: number; // -1 to 1

  // Wheels & Suspension (FL, FR, RL, RR)
  wheelRpm: [number, number, number, number];
  wheelSlipRatio: [number, number, number, number];
  suspensionDisplacementM: [number, number, number, number];
  suspensionVelocityMs: [number, number, number, number];
  tyreVerticalLoadN: [number, number, number, number];

  // Electrical & Powertrain
  motorPowerKw: number;
  regenPowerKw: number;
  totalTorqueNm: number;
  motorRpmFront: number;
  motorRpmRear: number;

  // Battery
  batterySocPercent: number;
  batteryVoltageV: number;
  batteryCurrentA: number;
  totalEnergyUsedKwh: number;
  energyConsumptionWhPerKm: number;

  // Thermal Nodes (°C)
  tempBatteryC: number;
  tempMotorFrontC: number;
  tempMotorRearC: number;
  tempInverterC: number;
  tempBrakeDiscsC: number;
  tempCabinC: number;

  // Charging Simulator
  chargingState: ChargingState;
  chargePowerKw: number;
  chargeEnergyDeliveredKwh: number;
  chargeTimeRemainingMin: number;

  // Environment & Timing
  simTimeSec: number;
  ambientTempC: number;
  surfaceFrictionMu: number;
}

export class VehiclePhysicsEngine {
  private state: VehiclePhysicsState;
  private vehicleDef: VehicleDefinition;
  private currentTrim: TrimOption;
  private driveMode: DriveMode = 'sport';

  // Constants
  private readonly AIR_DENSITY_RHO = 1.225; // kg/m³
  private readonly GRAVITY_G = 9.80665; // m/s²
  private readonly CRR_BASE = 0.011; // Rolling resistance coefficient

  constructor(vehicleDef: VehicleDefinition, trim?: TrimOption) {
    this.vehicleDef = vehicleDef;
    this.currentTrim = trim || vehicleDef.trims[0];
    this.state = this.createInitialState();
  }

  public setVehicle(vehicleDef: VehicleDefinition, trim?: TrimOption) {
    this.vehicleDef = vehicleDef;
    this.currentTrim = trim || vehicleDef.trims[0];
    const prevSoc = this.state.batterySocPercent;
    const prevTime = this.state.simTimeSec;
    this.state = this.createInitialState();
    this.state.batterySocPercent = prevSoc;
    this.state.simTimeSec = prevTime;
  }

  public setTrim(trim: TrimOption) {
    this.currentTrim = trim;
  }

  public setDriveMode(mode: DriveMode) {
    this.driveMode = mode;
  }

  public getState(): Readonly<VehiclePhysicsState> {
    return this.state;
  }

  public setInputs(throttle: number, brake: number, steer: number) {
    this.state.throttleInput = Math.max(0, Math.min(1, throttle));
    this.state.brakeInput = Math.max(0, Math.min(1, brake));
    this.state.steerInput = Math.max(-1, Math.min(1, steer));
  }

  public resetPosition(speedKmh = 0, x = 0, z = 0, headingRad = 0) {
    this.state.x = x;
    this.state.z = z;
    this.state.y = 0;
    this.state.headingRad = headingRad;
    this.state.speedMs = speedKmh / 3.6;
    this.state.speedKmh = speedKmh;
    this.state.speedMph = speedKmh * 0.621371;
    this.state.vx = Math.sin(headingRad) * this.state.speedMs;
    this.state.vz = Math.cos(headingRad) * this.state.speedMs;
    this.state.vy = 0;
    this.state.pitchRad = 0;
    this.state.rollRad = 0;
    this.state.yawRateRadSec = 0;
    this.state.accelXMs2 = 0;
    this.state.accelZMs2 = 0;
    this.state.accelG = 0;
    this.state.lateralG = 0;
    this.state.suspensionDisplacementM = [0, 0, 0, 0];
  }

  public setWeather(weather: WeatherType) {
    switch (weather) {
      case 'clear':
        this.state.surfaceFrictionMu = this.vehicleDef.tyres.baseFrictionMu;
        this.state.ambientTempC = 22;
        break;
      case 'rain':
        this.state.surfaceFrictionMu = this.vehicleDef.tyres.baseFrictionMu * 0.65;
        this.state.ambientTempC = 16;
        break;
      case 'snow':
        this.state.surfaceFrictionMu = this.vehicleDef.tyres.baseFrictionMu * 0.28;
        this.state.ambientTempC = -8;
        break;
      case 'fog':
        this.state.surfaceFrictionMu = this.vehicleDef.tyres.baseFrictionMu * 0.85;
        this.state.ambientTempC = 12;
        break;
    }
  }

  /**
   * Deterministic 100Hz / Sub-stepped physics integration
   */
  public step(dt: number) {
    if (dt <= 0) return;
    // Sub-step if dt > 0.02s for numerical stability
    const subSteps = Math.ceil(dt / 0.01);
    const subDt = dt / subSteps;

    for (let i = 0; i < subSteps; i++) {
      this.integratePhysics(subDt);
    }
  }

  private integratePhysics(dt: number) {
    this.state.simTimeSec += dt;
    const v = this.state.speedMs;
    const massKg = this.vehicleDef.dimensions.curbWeightKg * this.currentTrim.massMultiplier;
    const Cd = this.vehicleDef.dimensions.dragCoefficientCd;
    const frontalArea = this.vehicleDef.dimensions.frontalAreaM2;
    const tyreRadius = (this.vehicleDef.tyres.diameterMm / 2) / 1000;

    // 1. Steering & Ackermann Approximation
    const maxSteerDeg = 32; // max front wheel angle
    const targetSteerAngle = this.state.steerInput * (maxSteerDeg * (Math.PI / 180));
    // Dynamic steer-rate smoothing (simulates human hand/power-steering latency)
    const steerSmoothing = 14.0;
    this.state.steeringAngleRad += (targetSteerAngle - this.state.steeringAngleRad) * Math.min(1, steerSmoothing * dt);

    // 2. Drive Mode Multiplier
    let throttleScale = 1.0;
    let regenMaxKw = 75;
    if (this.driveMode === 'chill') {
      throttleScale = 0.65;
      regenMaxKw = 50;
    } else if (this.driveMode === 'plaid' || this.driveMode === 'insane') {
      throttleScale = 1.15;
      regenMaxKw = 95;
    } else if (this.driveMode === 'track') {
      throttleScale = 1.25;
      regenMaxKw = 110;
    }

    // 3. Motor Torques & Power Calculations
    let totalMotorTorqueNm = 0;
    let totalMotorPowerKw = 0;
    let regenPowerKw = 0;

    const totalPeakPower = this.currentTrim.motors.reduce((sum, m) => sum + m.peakPowerKw, 0) * throttleScale;
    const totalPeakTorque = this.currentTrim.motors.reduce((sum, m) => sum + m.peakTorqueNm, 0) * throttleScale;
    const gearRatio = this.currentTrim.motors[0]?.gearRatio || 9.03;

    // Derating factor for low SOC or extreme temperature
    let batteryThermalDerate = 1.0;
    if (this.state.batterySocPercent < 15) {
      batteryThermalDerate *= Math.max(0.4, this.state.batterySocPercent / 15);
    }
    if (this.state.tempBatteryC > 52) {
      batteryThermalDerate *= Math.max(0.5, 1 - (this.state.tempBatteryC - 52) * 0.05);
    }

    if (this.state.throttleInput > 0.01) {
      // Traction torque calculation with field-weakening curve
      const baseRpm = Math.max(100, (v / (2 * Math.PI * tyreRadius)) * 60 * gearRatio);
      let torqueCurveFactor = 1.0;
      if (baseRpm > 6000) {
        // Constant power region (torque decays inversely with RPM)
        torqueCurveFactor = 6000 / baseRpm;
      }

      const requestedTorque = this.state.throttleInput * totalPeakTorque * torqueCurveFactor * batteryThermalDerate;
      totalMotorTorqueNm = requestedTorque;

      // Power = Torque (Nm) * Omega (rad/s)
      const omega = (baseRpm * 2 * Math.PI) / 60;
      totalMotorPowerKw = Math.min(totalPeakPower, (requestedTorque * omega) / 1000);
    } else if (this.state.brakeInput < 0.05 && v > 0.5) {
      // One-Pedal Regenerative Braking (Harvesting)
      const regenDecel = 0.25; // standard ~0.25g regen drag
      const maxRegenKw = Math.min(regenMaxKw, this.currentTrim.battery.coolingCapacityKw * 4);
      regenPowerKw = Math.min(maxRegenKw, (massKg * regenDecel * this.GRAVITY_G * v) / 1000);
    }

    // 4. Force Equations: F_net = F_drive - F_drag - F_roll - F_brake
    const F_drive = totalMotorTorqueNm > 0 ? (totalMotorTorqueNm * gearRatio) / tyreRadius : 0;
    const F_drag = 0.5 * this.AIR_DENSITY_RHO * Cd * frontalArea * v * v;
    const F_roll = this.CRR_BASE * massKg * this.GRAVITY_G;
    
    // Braking force: Hydraulic Friction + Regenerative
    const maxBrakeForce = massKg * this.GRAVITY_G * this.state.surfaceFrictionMu * 1.15;
    const F_hydraulicBrake = this.state.brakeInput * maxBrakeForce;
    const F_regenBrake = (regenPowerKw * 1000) / Math.max(0.5, v);
    const F_brake = F_hydraulicBrake + F_regenBrake;

    // Net longitudinal force
    let F_net = F_drive - F_drag - F_roll - F_brake;
    if (v < 0.05 && F_net < 0 && this.state.throttleInput < 0.01) {
      F_net = 0; // Stationary at rest with brakes
    }

    const accelX = F_net / massKg;
    this.state.accelXMs2 = accelX;
    this.state.accelG = accelX / this.GRAVITY_G;

    // 5. Integrate Velocity & Speed
    this.state.speedMs = Math.max(0, this.state.speedMs + accelX * dt);
    // Cap at trim top speed
    const maxSpeedMs = (this.currentTrim.topSpeedKmh / 3.6);
    if (this.state.speedMs > maxSpeedMs) {
      this.state.speedMs = maxSpeedMs;
    }
    this.state.speedKmh = this.state.speedMs * 3.6;
    this.state.speedMph = this.state.speedKmh * 0.621371;

    // 6. Lateral Dynamics & Yaw Rate (Bicycle Model approximation)
    const wheelbaseM = this.vehicleDef.dimensions.wheelbaseMm / 1000;
    const targetYawRate = (this.state.speedMs / wheelbaseM) * Math.tan(this.state.steeringAngleRad);
    this.state.yawRateRadSec += (targetYawRate - this.state.yawRateRadSec) * Math.min(1, 12 * dt);

    // Lateral G
    const lateralAccel = this.state.speedMs * this.state.yawRateRadSec;
    this.state.accelZMs2 = lateralAccel;
    this.state.lateralG = lateralAccel / this.GRAVITY_G;

    // Heading update
    this.state.headingRad += this.state.yawRateRadSec * dt;

    // Global position update (X/Z plane in Three.js)
    this.state.vx = Math.sin(this.state.headingRad) * this.state.speedMs;
    this.state.vz = Math.cos(this.state.headingRad) * this.state.speedMs;
    this.state.x += this.state.vx * dt;
    this.state.z += this.state.vz * dt;

    // 7. Suspension Pitch & Roll Kinematics
    // Pitch: squat under acceleration (rear down), dive under braking (front down)
    const targetPitch = (this.state.accelG * -0.06); // ~3.5 deg per G
    this.state.pitchRad += (targetPitch - this.state.pitchRad) * Math.min(1, 8 * dt);

    // Roll: roll towards outside of turn under lateral G
    const targetRoll = (this.state.lateralG * 0.055); // ~3.1 deg per G
    this.state.rollRad += (targetRoll - this.state.rollRad) * Math.min(1, 8 * dt);

    // Per-wheel vertical load transfer & suspension displacement
    const baseWheelLoadN = (massKg * this.GRAVITY_G) / 4;
    const longLoadTransfer = (massKg * this.state.accelXMs2 * 0.45) / 2; // h_cg / L
    const latLoadTransfer = (massKg * this.state.accelZMs2 * 0.45) / 2; // h_cg / T

    const fL_Load = Math.max(200, baseWheelLoadN - longLoadTransfer - latLoadTransfer);
    const fR_Load = Math.max(200, baseWheelLoadN - longLoadTransfer + latLoadTransfer);
    const rL_Load = Math.max(200, baseWheelLoadN + longLoadTransfer - latLoadTransfer);
    const rR_Load = Math.max(200, baseWheelLoadN + longLoadTransfer + latLoadTransfer);
    this.state.tyreVerticalLoadN = [fL_Load, fR_Load, rL_Load, rR_Load];

    const springK = this.vehicleDef.suspension.springRateFrontNPerM;
    this.state.suspensionDisplacementM = [
      (fL_Load - baseWheelLoadN) / springK,
      (fR_Load - baseWheelLoadN) / springK,
      (rL_Load - baseWheelLoadN) / springK,
      (rR_Load - baseWheelLoadN) / springK,
    ];

    // 8. Wheels RPM & Slip
    const wheelCircumference = 2 * Math.PI * tyreRadius;
    const baseWheelRpm = (this.state.speedMs / wheelCircumference) * 60;
    this.state.wheelRpm = [baseWheelRpm, baseWheelRpm, baseWheelRpm, baseWheelRpm];
    this.state.motorRpmFront = baseWheelRpm * gearRatio;
    this.state.motorRpmRear = baseWheelRpm * gearRatio;

    // Pacejka Slip Ratio calculation: (w*r - v) / max(v, w*r)
    const slipRatioBase = totalMotorTorqueNm > 0 ? Math.min(0.18, (totalMotorPowerKw / 400) * 0.08) : 0.01;
    this.state.wheelSlipRatio = [slipRatioBase, slipRatioBase, slipRatioBase * 1.1, slipRatioBase * 1.1];

    // 9. Battery Coulomb Counting & Voltage Model
    this.state.motorPowerKw = totalMotorPowerKw;
    this.state.regenPowerKw = regenPowerKw;
    this.state.totalTorqueNm = totalMotorTorqueNm;

    const netElectricPowerKw = totalMotorPowerKw - regenPowerKw + 1.2; // +1.2kW baseline HVAC & computing
    const nominalVoltage = this.currentTrim.battery.nominalVoltageV;
    const capacityKwh = this.currentTrim.battery.usableCapacityKwh;

    // Open-circuit voltage based on SOC
    const voc = nominalVoltage * (0.88 + 0.24 * (this.state.batterySocPercent / 100));
    const currentA = (netElectricPowerKw * 1000) / voc;
    this.state.batteryVoltageV = Math.max(nominalVoltage * 0.75, voc - currentA * this.currentTrim.battery.internalResistanceOhm);
    this.state.batteryCurrentA = currentA;

    // Coulomb counting update
    const energyDeltaKwh = (netElectricPowerKw * (dt / 3600));
    this.state.totalEnergyUsedKwh += energyDeltaKwh;
    const socDelta = (energyDeltaKwh / capacityKwh) * 100;
    this.state.batterySocPercent = Math.max(0, Math.min(100, this.state.batterySocPercent - socDelta));

    // Wh/km consumption calculation
    if (this.state.speedKmh > 2.0) {
      const instantaneousWhPerKm = (netElectricPowerKw * 1000) / this.state.speedKmh;
      this.state.energyConsumptionWhPerKm += (instantaneousWhPerKm - this.state.energyConsumptionWhPerKm) * Math.min(1, 2 * dt);
    }

    // 10. Thermal System Digital Twin (Differential Heat Balance)
    // dQ/dt = I²R_loss - Cooling
    const ambient = this.state.ambientTempC;
    const batteryJouleHeating = (currentA * currentA * this.currentTrim.battery.internalResistanceOhm) / 1000; // kW
    const coolingEffKw = this.currentTrim.battery.coolingCapacityKw * (this.state.tempBatteryC > 35 ? 0.9 : 0.2);
    const dT_battery = ((batteryJouleHeating - coolingEffKw) * dt * 1000) / this.currentTrim.battery.thermalMassJoulePerK;
    this.state.tempBatteryC += dT_battery;
    this.state.tempBatteryC += (ambient - this.state.tempBatteryC) * 0.0005 * dt;

    // Motors & Inverter Thermal
    const motorLossKw = totalMotorPowerKw * (1 - this.currentTrim.motors[0]?.efficiency || 0.03);
    this.state.tempMotorRearC += (motorLossKw * 0.8 * dt * 0.05) - (this.state.tempMotorRearC - ambient) * 0.008 * dt;
    this.state.tempInverterC += (motorLossKw * 0.2 * dt * 0.06) - (this.state.tempInverterC - ambient) * 0.01 * dt;

    // Brakes Thermal
    if (F_hydraulicBrake > 100) {
      const brakeHeatKw = (F_hydraulicBrake * v) / 1000;
      this.state.tempBrakeDiscsC += brakeHeatKw * dt * 0.08;
    }
    this.state.tempBrakeDiscsC += (ambient - this.state.tempBrakeDiscsC) * (0.015 + (v / 100) * 0.05) * dt;

    // 11. Charging Simulation State Machine
    if (this.state.chargingState === 'CHARGING') {
      const maxChargeRate = this.currentTrim.battery.maxChargeRateKw;
      // Fast Charging Curve: Taper as SOC rises (CC -> CV phase)
      let chargeCurveMultiplier = 1.0;
      if (this.state.batterySocPercent > 50) {
        chargeCurveMultiplier = Math.max(0.18, 1.0 - (this.state.batterySocPercent - 50) * 0.016);
      }
      this.state.chargePowerKw = maxChargeRate * chargeCurveMultiplier;
      const chargeEnergyKwh = (this.state.chargePowerKw * (dt / 3600));
      this.state.chargeEnergyDeliveredKwh += chargeEnergyKwh;
      this.state.batterySocPercent = Math.min(100, this.state.batterySocPercent + (chargeEnergyKwh / capacityKwh) * 100);

      // Precondition pack to 42°C for optimal ion mobility
      if (this.state.tempBatteryC < 42) {
        this.state.tempBatteryC += 0.8 * dt;
      }

      // Estimate remaining charge time to 80%
      const neededKwh = Math.max(0, (80 - this.state.batterySocPercent) * (capacityKwh / 100));
      this.state.chargeTimeRemainingMin = (neededKwh / Math.max(20, this.state.chargePowerKw)) * 60;

      if (this.state.batterySocPercent >= 99.8) {
        this.state.chargingState = 'COMPLETE';
        this.state.chargePowerKw = 0;
      }
    }
  }

  public startCharging() {
    this.state.chargingState = 'CHARGING';
    this.state.chargeEnergyDeliveredKwh = 0;
    this.state.speedMs = 0;
    this.state.speedKmh = 0;
    this.state.speedMph = 0;
  }

  public stopCharging() {
    this.state.chargingState = 'DISCONNECTED';
    this.state.chargePowerKw = 0;
  }

  public getTelemetrySample(): LiveTelemetrySample {
    return {
      timestampMs: Date.now(),
      simTimeSec: this.state.simTimeSec,
      speedKmh: this.state.speedKmh,
      speedMph: this.state.speedMph,
      accelerationG: this.state.accelG,
      lateralG: this.state.lateralG,
      yawRateDeg: this.state.yawRateRadSec * (180 / Math.PI),
      headingDeg: (this.state.headingRad * (180 / Math.PI)) % 360,
      steeringAngleDeg: this.state.steeringAngleRad * (180 / Math.PI),
      throttlePercent: this.state.throttleInput * 100,
      brakePercent: this.state.brakeInput * 100,
      regenPowerKw: this.state.regenPowerKw,
      motorPowerKw: this.state.motorPowerKw,
      totalEnergyUsedKwh: this.state.totalEnergyUsedKwh,
      energyConsumptionWhPerKm: Math.max(0, this.state.energyConsumptionWhPerKm),
      batterySocPercent: this.state.batterySocPercent,
      batteryVoltageV: this.state.batteryVoltageV,
      batteryCurrentA: this.state.batteryCurrentA,
      batteryTempC: this.state.tempBatteryC,
      motorTempFrontC: this.state.tempMotorFrontC,
      motorTempRearC: this.state.tempMotorRearC,
      inverterTempC: this.state.tempInverterC,
      brakeDiscsTempC: this.state.tempBrakeDiscsC,
      cabinTempC: this.state.tempCabinC,
      suspensionTravelMm: [
        this.state.suspensionDisplacementM[0] * 1000,
        this.state.suspensionDisplacementM[1] * 1000,
        this.state.suspensionDisplacementM[2] * 1000,
        this.state.suspensionDisplacementM[3] * 1000,
      ],
      wheelSlipRatio: this.state.wheelSlipRatio,
      wheelSpeedRpm: this.state.wheelRpm,
      tyreLoadN: this.state.tyreVerticalLoadN,
      pitchDeg: this.state.pitchRad * (180 / Math.PI),
      rollDeg: this.state.rollRad * (180 / Math.PI),
      altitudeM: 0,
    };
  }

  private createInitialState(): VehiclePhysicsState {
    return {
      x: 0,
      y: 0,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      speedMs: 0,
      speedKmh: 0,
      speedMph: 0,
      accelXMs2: 0,
      accelYMs2: 0,
      accelZMs2: 0,
      accelG: 0,
      lateralG: 0,
      headingRad: 0,
      pitchRad: 0,
      rollRad: 0,
      yawRateRadSec: 0,
      steeringAngleRad: 0,
      throttleInput: 0,
      brakeInput: 0,
      steerInput: 0,
      wheelRpm: [0, 0, 0, 0],
      wheelSlipRatio: [0, 0, 0, 0],
      suspensionDisplacementM: [0, 0, 0, 0],
      suspensionVelocityMs: [0, 0, 0, 0],
      tyreVerticalLoadN: [4500, 4500, 4500, 4500],
      motorPowerKw: 0,
      regenPowerKw: 0,
      totalTorqueNm: 0,
      motorRpmFront: 0,
      motorRpmRear: 0,
      batterySocPercent: 82.0,
      batteryVoltageV: this.currentTrim?.battery.nominalVoltageV || 400,
      batteryCurrentA: 0,
      totalEnergyUsedKwh: 0,
      energyConsumptionWhPerKm: 155,
      tempBatteryC: 28.5,
      tempMotorFrontC: 34.0,
      tempMotorRearC: 36.5,
      tempInverterC: 38.0,
      tempBrakeDiscsC: 24.0,
      tempCabinC: 21.0,
      chargingState: 'DISCONNECTED',
      chargePowerKw: 0,
      chargeEnergyDeliveredKwh: 0,
      chargeTimeRemainingMin: 0,
      simTimeSec: 0,
      ambientTempC: 20.0,
      surfaceFrictionMu: this.vehicleDef.tyres.baseFrictionMu,
    };
  }
}
