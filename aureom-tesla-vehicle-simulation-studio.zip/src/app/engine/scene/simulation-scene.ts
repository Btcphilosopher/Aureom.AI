import * as THREE from 'three';
import {
  VehicleDefinition,
  ColorOption,
  WheelOption,
  InteriorOption,
  EnvironmentId,
  WeatherType,
  ViewMode,
  MechanismRigState,
} from '../../core/types/vehicle.types';
import { VehicleGeometryBuilder, VehicleMeshRig } from '../geometry/vehicle-geometry-builder';
import { VehiclePhysicsState } from '../physics/vehicle-physics';

export type CameraViewMode =
  | 'orbit'
  | 'cockpit'
  | 'chase'
  | 'front'
  | 'rear'
  | 'side'
  | 'top'
  | 'wheel'
  | 'battery'
  | 'cinematic';

export class SimulationScene {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private currentRig: VehicleMeshRig | null = null;
  private vehicleDef: VehicleDefinition;

  // Environment & Lights
  private envGroup: THREE.Group;
  private dirLight: THREE.DirectionalLight;
  private ambientLight: THREE.AmbientLight;
  private hemiLight: THREE.HemisphereLight;
  private groundMesh: THREE.Mesh | null = null;
  private gridHelper: THREE.GridHelper | null = null;
  private weatherParticles: THREE.Points | null = null;

  // Camera Orbit Controls State
  private cameraMode: CameraViewMode = 'orbit';
  private orbitRadius = 6.8;
  private orbitTheta = Math.PI / 4; // Azimuth
  private orbitPhi = Math.PI / 3.2; // Elevation
  private targetLookAt = new THREE.Vector3(0, 0.7, 0);
  private isDragging = false;
  private prevMouseX = 0;
  private prevMouseY = 0;

  // Exploded & Cutaway State
  private explodedFactor = 0.0; // 0.0 to 1.0
  private cutawayOpacity = 1.0;
  private viewMode: ViewMode = 'studio';
  private assemblyStep = 0; // 0 to 10

  // Animation & Particle state
  private clock = new THREE.Clock();
  private energyParticles: THREE.LineSegments | null = null;
  private isRunning = false;

  constructor(container: HTMLElement, vehicleDef: VehicleDefinition) {
    this.container = container;
    this.vehicleDef = vehicleDef;

    // 1. WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    container.appendChild(this.renderer.domElement);

    // 2. Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0b0e14');

    this.camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / Math.max(1, container.clientHeight),
      0.1,
      1000
    );
    this.updateCameraPosition();

    // 3. Environment Lighting Group
    this.envGroup = new THREE.Group();
    this.scene.add(this.envGroup);

    this.ambientLight = new THREE.AmbientLight('#ffffff', 0.8);
    this.scene.add(this.ambientLight);

    this.hemiLight = new THREE.HemisphereLight('#60a5fa', '#1e293b', 0.9);
    this.scene.add(this.hemiLight);

    this.dirLight = new THREE.DirectionalLight('#ffffff', 2.2);
    this.dirLight.position.set(10, 20, 15);
    this.dirLight.castShadow = true;
    this.dirLight.shadow.mapSize.width = 2048;
    this.dirLight.shadow.mapSize.height = 2048;
    this.dirLight.shadow.camera.near = 0.5;
    this.dirLight.shadow.camera.far = 80;
    this.dirLight.shadow.camera.left = -12;
    this.dirLight.shadow.camera.right = 12;
    this.dirLight.shadow.camera.top = 12;
    this.dirLight.shadow.camera.bottom = -12;
    this.dirLight.shadow.bias = -0.0005;
    this.scene.add(this.dirLight);

    // 4. Build Environment Ground & Studio Grid
    this.setupEnvironment('studio');

    // 5. Build Initial Vehicle Mesh Rig
    this.loadVehicle(this.vehicleDef);

    // 6. Setup Mouse/Touch Event Listeners
    this.setupEventListeners();

    // 7. Start Render Loop
    this.isRunning = true;
    this.animate();
  }

  public loadVehicle(
    vehicle: VehicleDefinition,
    color?: ColorOption,
    wheel?: WheelOption,
    interior?: InteriorOption
  ) {
    if (this.currentRig) {
      this.scene.remove(this.currentRig.rootGroup);
      this.disposeHierarchy(this.currentRig.rootGroup);
      this.currentRig = null;
    }

    this.vehicleDef = vehicle;
    this.currentRig = VehicleGeometryBuilder.buildVehicle(vehicle, color, wheel, interior);
    this.scene.add(this.currentRig.rootGroup);
    this.applyViewMode(this.viewMode);
  }

  public updateVehicleColor(color: ColorOption) {
    if (this.currentRig) {
      this.currentRig.materials.bodyPaint.color.set(color.hex);
      this.currentRig.materials.bodyPaint.metalness = color.metallic;
      this.currentRig.materials.bodyPaint.roughness = color.roughness;
      this.currentRig.materials.bodyPaint.clearcoat = color.clearcoat;
    }
  }

  public updateVehicleInterior(interior: InteriorOption) {
    if (this.currentRig) {
      this.currentRig.materials.interiorLeather.color.set(interior.seatColorHex);
      const isCarbon = interior.woodOrCarbon === 'carbon';
      const isWhite = interior.woodOrCarbon === 'white';
      this.currentRig.materials.interiorAccent.color.set(
        isCarbon ? '#1c1e22' : isWhite ? '#f1f5f9' : '#784725'
      );
      this.currentRig.materials.interiorAccent.metalness = isCarbon ? 0.6 : 0.1;
    }
  }

  public setCameraMode(mode: CameraViewMode) {
    this.cameraMode = mode;
    switch (mode) {
      case 'cockpit':
        this.camera.fov = 60;
        break;
      case 'chase':
        this.camera.fov = 50;
        break;
      case 'front':
        this.orbitTheta = 0;
        this.orbitPhi = Math.PI / 2.2;
        this.orbitRadius = 6.0;
        this.camera.fov = 45;
        break;
      case 'rear':
        this.orbitTheta = Math.PI;
        this.orbitPhi = Math.PI / 2.2;
        this.orbitRadius = 6.0;
        this.camera.fov = 45;
        break;
      case 'side':
        this.orbitTheta = Math.PI / 2;
        this.orbitPhi = Math.PI / 2.2;
        this.orbitRadius = 6.5;
        this.camera.fov = 45;
        break;
      case 'top':
        this.orbitTheta = 0;
        this.orbitPhi = 0.05;
        this.orbitRadius = 9.0;
        this.camera.fov = 45;
        break;
      case 'wheel':
        this.orbitTheta = Math.PI / 2.8;
        this.orbitPhi = Math.PI / 2.1;
        this.orbitRadius = 2.5;
        this.targetLookAt.set(-0.9, 0.35, 1.4);
        this.camera.fov = 50;
        break;
      case 'battery':
        this.orbitTheta = Math.PI / 3;
        this.orbitPhi = Math.PI / 2.6;
        this.orbitRadius = 4.2;
        this.targetLookAt.set(0, 0.25, 0);
        this.camera.fov = 45;
        break;
      default:
        this.camera.fov = 45;
        this.targetLookAt.set(0, 0.7, 0);
        break;
    }
    this.camera.updateProjectionMatrix();
    this.updateCameraPosition();
  }

  public setViewMode(mode: ViewMode) {
    this.viewMode = mode;
    this.applyViewMode(mode);
  }

  public setExplodedProgress(progress: number) {
    this.explodedFactor = Math.max(0, Math.min(1, progress));
    this.updateExplodedTransforms();
  }

  public setCutawayOpacity(opacity: number) {
    this.cutawayOpacity = Math.max(0.05, Math.min(1.0, opacity));
    if (this.currentRig) {
      this.currentRig.materials.bodyPaint.transparent = this.cutawayOpacity < 0.98;
      this.currentRig.materials.bodyPaint.opacity = this.cutawayOpacity;
    }
  }

  public setAssemblyStep(step: number) {
    this.assemblyStep = Math.max(0, Math.min(10, step));
    this.updateAssemblyVisibility();
  }

  /**
   * Applies live physics state to vehicle 3D node transforms
   */
  public updatePhysicsTransform(state: VehiclePhysicsState, rigState: MechanismRigState) {
    if (!this.currentRig) return;

    // 1. Vehicle Root World Position & Rotations (Heading, Pitch, Roll)
    if (this.viewMode === 'physics-sim') {
      this.currentRig.rootGroup.position.set(state.x, 0, state.z);
      this.currentRig.rootGroup.rotation.y = state.headingRad;
    } else {
      // Keep centered in viewer modes
      this.currentRig.rootGroup.position.set(0, 0, 0);
      this.currentRig.rootGroup.rotation.y = 0;
    }

    // Body Pitch (squat/dive) & Roll
    this.currentRig.bodyGroup.rotation.x = state.pitchRad;
    this.currentRig.bodyGroup.rotation.z = -state.rollRad;
    this.currentRig.subassemblies.interior.rotation.x = state.pitchRad;
    this.currentRig.subassemblies.interior.rotation.z = -state.rollRad;

    // 2. Wheels Spin Rate derived from RPM & Steering Angle
    const spinDelta = (state.speedMs / ((this.vehicleDef.tyres.diameterMm / 2) / 1000)) * (1 / 60);
    this.currentRig.wheels.frontLeft.rotation.x += spinDelta;
    this.currentRig.wheels.frontRight.rotation.x += spinDelta;
    this.currentRig.wheels.rearLeft.rotation.x += spinDelta;
    this.currentRig.wheels.rearRight.rotation.x += spinDelta;

    // Front Wheels Steer Angle & Cockpit Steering Wheel
    const steerRad = state.steeringAngleRad;
    this.currentRig.wheels.frontLeftSteerPivot.rotation.y = steerRad;
    this.currentRig.wheels.frontRightSteerPivot.rotation.y = steerRad;

    if (this.currentRig.interior.steeringWheel) {
      this.currentRig.interior.steeringWheel.rotation.z = -steerRad * 2.5;
    }

    // 3. Brake Caliper Thermal Glow
    const brakeTemp = state.tempBrakeDiscsC;
    if (brakeTemp > 250) {
      const heatFactor = Math.min(1, (brakeTemp - 250) / 400);
      this.currentRig.materials.brakeRotor.emissive = new THREE.Color('#ff3300');
      this.currentRig.materials.brakeRotor.emissiveIntensity = heatFactor * 1.5;
    } else {
      this.currentRig.materials.brakeRotor.emissiveIntensity = 0;
    }

    // 4. Lighting States
    this.currentRig.materials.headlightEmissive.color.set(rigState.headlightsOn ? '#e0f2fe' : '#223344');
    this.currentRig.materials.taillightEmissive.color.set(rigState.brakeLightsOn ? '#ff0000' : '#881111');

    // 5. Doors & Mechanism Articulations
    this.applyMechanismState(rigState);

    // 6. Cockpit & Chase Camera Tracking
    if (this.cameraMode === 'cockpit') {
      const bodyPos = this.currentRig.rootGroup.position;
      const heading = this.currentRig.rootGroup.rotation.y;
      // Driver head position inside vehicle
      const driverOffset = new THREE.Vector3(-0.4, 1.15, 0.1).applyAxisAngle(new THREE.Vector3(0, 1, 0), heading);
      this.camera.position.copy(bodyPos).add(driverOffset);

      const lookTarget = new THREE.Vector3(-0.4, 1.1, 15).applyAxisAngle(new THREE.Vector3(0, 1, 0), heading);
      this.camera.lookAt(bodyPos.clone().add(lookTarget));
    } else if (this.cameraMode === 'chase') {
      const bodyPos = this.currentRig.rootGroup.position;
      const heading = this.currentRig.rootGroup.rotation.y;
      const chaseOffset = new THREE.Vector3(0, 2.2, -7.5).applyAxisAngle(new THREE.Vector3(0, 1, 0), heading);
      this.camera.position.lerp(bodyPos.clone().add(chaseOffset), 0.1);
      this.camera.lookAt(bodyPos.clone().add(new THREE.Vector3(0, 1.0, 3.0).applyAxisAngle(new THREE.Vector3(0, 1, 0), heading)));
    }
  }

  private applyMechanismState(rigState: MechanismRigState) {
    if (!this.currentRig) return;

    const doors = this.currentRig.doors;

    // Standard Doors Opening Angle (0 to ~65 deg)
    const maxDoorAngle = 1.1; // rad
    if (doors.frontLeft) doors.frontLeft.rotation.y = -rigState.doorFrontLeft * maxDoorAngle;
    if (doors.frontRight) doors.frontRight.rotation.y = rigState.doorFrontRight * maxDoorAngle;
    if (doors.rearLeft) doors.rearLeft.rotation.y = -rigState.doorRearLeft * maxDoorAngle;
    if (doors.rearRight) doors.rearRight.rotation.y = rigState.doorRearRight * maxDoorAngle;

    // Model X Falcon Wing Dual Articulation
    if (doors.falconWingLeft1) {
      doors.falconWingLeft1.rotation.z = -rigState.falconWingLeftStage1 * 1.45;
    }
    if (doors.falconWingRight1) {
      doors.falconWingRight1.rotation.z = rigState.falconWingRightStage1 * 1.45;
    }

    // Frunk & Trunk
    if (this.currentRig.hoodFrunk) {
      this.currentRig.hoodFrunk.rotation.x = -rigState.frunk * 0.75;
    }
    if (this.currentRig.trunk) {
      this.currentRig.trunk.rotation.x = rigState.trunk * 0.85;
    }

    // Cybertruck Tonneau Cover roll
    if (doors.tonneauCover) {
      doors.tonneauCover.position.z = -this.vehicleDef.dimensions.lengthMm / 1000 * 0.15 + (rigState.tonneauCover * 1.2);
    }
  }

  public setupEnvironment(envId: EnvironmentId) {
    // Clear existing environment meshes
    while (this.envGroup.children.length > 0) {
      const child = this.envGroup.children[0];
      this.envGroup.remove(child);
      this.disposeHierarchy(child);
    }

    switch (envId) {
      case 'studio': {
        this.scene.background = new THREE.Color('#0b0e14');
        this.ambientLight.intensity = 0.85;
        this.dirLight.intensity = 2.4;
        this.dirLight.color.set('#ffffff');

        // Dark reflective floor
        const floorGeo = new THREE.PlaneGeometry(80, 80);
        const floorMat = new THREE.MeshStandardMaterial({
          color: '#0d1117',
          roughness: 0.18,
          metalness: 0.85,
        });
        this.groundMesh = new THREE.Mesh(floorGeo, floorMat);
        this.groundMesh.rotation.x = -Math.PI / 2;
        this.groundMesh.receiveShadow = true;
        this.envGroup.add(this.groundMesh);

        // Circular Studio Radial Stage Grid
        this.gridHelper = new THREE.GridHelper(30, 30, '#38bdf8', '#1e293b');
        this.gridHelper.position.y = 0.005;
        this.envGroup.add(this.gridHelper);
        break;
      }

      case 'test-track': {
        this.scene.background = new THREE.Color('#0f172a');
        this.ambientLight.intensity = 1.0;
        this.dirLight.intensity = 2.8;

        // Asphalt Racetrack Ground
        const trackGeo = new THREE.PlaneGeometry(400, 400);
        const trackMat = new THREE.MeshStandardMaterial({
          color: '#1e2026',
          roughness: 0.7,
          metalness: 0.1,
        });
        const trackMesh = new THREE.Mesh(trackGeo, trackMat);
        trackMesh.rotation.x = -Math.PI / 2;
        trackMesh.receiveShadow = true;
        this.envGroup.add(trackMesh);

        // Track Curbs & White Markings
        const skidCircleGeo = new THREE.RingGeometry(35, 36.5, 64);
        const markMat = new THREE.MeshBasicMaterial({ color: '#f8fafc', side: THREE.DoubleSide });
        const skidCircle = new THREE.Mesh(skidCircleGeo, markMat);
        skidCircle.rotation.x = -Math.PI / 2;
        skidCircle.position.y = 0.01;
        this.envGroup.add(skidCircle);
        break;
      }

      case 'supercharger': {
        this.scene.background = new THREE.Color('#090d16');
        const scGroundGeo = new THREE.PlaneGeometry(100, 100);
        const scGroundMat = new THREE.MeshStandardMaterial({ color: '#161b22', roughness: 0.3, metalness: 0.5 });
        const scGround = new THREE.Mesh(scGroundGeo, scGroundMat);
        scGround.rotation.x = -Math.PI / 2;
        scGround.receiveShadow = true;
        this.envGroup.add(scGround);

        // 4 V4 Supercharging Stalls
        for (let i = -2; i <= 2; i += 2) {
          const stallGroup = new THREE.Group();
          stallGroup.position.set(i * 3.5, 0, -5.5);

          // Red/White V4 Stall Body
          const stallGeo = new THREE.BoxGeometry(0.85, 2.1, 0.45);
          const stallMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.2 });
          const stallMesh = new THREE.Mesh(stallGeo, stallMat);
          stallMesh.position.y = 1.05;

          // Glowing Red Hollow Center
          const glowGeo = new THREE.BoxGeometry(0.5, 1.4, 0.46);
          const glowMat = new THREE.MeshBasicMaterial({ color: '#ef4444' });
          const glowMesh = new THREE.Mesh(glowGeo, glowMat);
          glowMesh.position.y = 1.05;

          stallGroup.add(stallMesh, glowMesh);
          this.envGroup.add(stallGroup);
        }
        break;
      }

      case 'city':
      case 'mountain':
      case 'factory': {
        this.scene.background = new THREE.Color('#0a0f1d');
        const defaultGroundGeo = new THREE.PlaneGeometry(200, 200);
        const defaultGroundMat = new THREE.MeshStandardMaterial({ color: '#151922', roughness: 0.4 });
        const defaultGround = new THREE.Mesh(defaultGroundGeo, defaultGroundMat);
        defaultGround.rotation.x = -Math.PI / 2;
        defaultGround.receiveShadow = true;
        this.envGroup.add(defaultGround);

        const cityGrid = new THREE.GridHelper(100, 50, '#38bdf8', '#1e293b');
        cityGrid.position.y = 0.01;
        this.envGroup.add(cityGrid);
        break;
      }
    }
  }

  public setWeather(weather: WeatherType) {
    if (this.weatherParticles) {
      this.scene.remove(this.weatherParticles);
      this.disposeHierarchy(this.weatherParticles);
      this.weatherParticles = null;
    }

    if (weather === 'rain') {
      const particleCount = 2500;
      const rainGeo = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      for (let i = 0; i < particleCount * 3; i += 3) {
        positions[i] = (Math.random() - 0.5) * 40;
        positions[i + 1] = Math.random() * 20;
        positions[i + 2] = (Math.random() - 0.5) * 40;
      }
      rainGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const rainMat = new THREE.PointsMaterial({
        color: '#93c5fd',
        size: 0.12,
        transparent: true,
        opacity: 0.75,
      });
      this.weatherParticles = new THREE.Points(rainGeo, rainMat);
      this.scene.add(this.weatherParticles);
      this.scene.fog = new THREE.FogExp2('#0f172a', 0.025);
    } else if (weather === 'snow') {
      const particleCount = 2000;
      const snowGeo = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      for (let i = 0; i < particleCount * 3; i += 3) {
        positions[i] = (Math.random() - 0.5) * 40;
        positions[i + 1] = Math.random() * 20;
        positions[i + 2] = (Math.random() - 0.5) * 40;
      }
      snowGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const snowMat = new THREE.PointsMaterial({
        color: '#ffffff',
        size: 0.18,
        transparent: true,
        opacity: 0.85,
      });
      this.weatherParticles = new THREE.Points(snowGeo, snowMat);
      this.scene.add(this.weatherParticles);
      this.scene.fog = new THREE.FogExp2('#1e293b', 0.035);
    } else if (weather === 'fog') {
      this.scene.fog = new THREE.FogExp2('#1e293b', 0.06);
    } else {
      this.scene.fog = null;
    }
  }

  private applyViewMode(mode: ViewMode) {
    if (!this.currentRig) return;

    // Reset default opacities & transforms
    this.currentRig.subassemblies.bodyPanels.visible = true;
    this.currentRig.subassemblies.chassis.visible = true;
    this.currentRig.subassemblies.batteryPack.visible = true;
    this.currentRig.subassemblies.powertrain.visible = true;
    this.currentRig.subassemblies.suspension.visible = true;
    this.currentRig.subassemblies.interior.visible = true;

    if (mode === 'cutaway') {
      this.setCutawayOpacity(0.18);
    } else if (mode === 'exploded') {
      this.setCutawayOpacity(0.85);
      this.updateExplodedTransforms();
    } else if (mode === 'thermal') {
      // Apply Thermal false-color heatmap overlay
      this.currentRig.materials.batteryCell.emissive.set('#ef4444');
      this.currentRig.materials.batteryCell.emissiveIntensity = 0.8;
      this.setCutawayOpacity(0.35);
    } else if (mode === 'assembly') {
      this.updateAssemblyVisibility();
    } else {
      this.setCutawayOpacity(1.0);
      this.explodedFactor = 0;
      this.updateExplodedTransforms();
    }
  }

  private updateExplodedTransforms() {
    if (!this.currentRig) return;
    const f = this.explodedFactor;

    // Explode components along primary expansion vectors
    this.currentRig.subassemblies.bodyPanels.position.y = f * 1.8;
    this.currentRig.subassemblies.interior.position.y = f * 0.9;
    this.currentRig.subassemblies.batteryPack.position.y = -f * 0.85;

    // Wheels outward separation
    this.currentRig.wheels.frontLeftSteerPivot.position.x = -this.vehicleDef.dimensions.trackFrontMm / 2000 - f * 0.75;
    this.currentRig.wheels.frontRightSteerPivot.position.x = this.vehicleDef.dimensions.trackFrontMm / 2000 + f * 0.75;
    this.currentRig.wheels.rearLeft.position.x = -this.vehicleDef.dimensions.trackRearMm / 2000 - f * 0.75;
    this.currentRig.wheels.rearRight.position.x = this.vehicleDef.dimensions.trackRearMm / 2000 + f * 0.75;
  }

  private updateAssemblyVisibility() {
    if (!this.currentRig) return;
    const step = this.assemblyStep;

    // 0: Empty floor, 1: Chassis, 3: Battery, 5: Suspension, 7: Powertrain, 8: Interior, 9: Body panels, 10: Complete
    this.currentRig.subassemblies.chassis.visible = step >= 1;
    this.currentRig.subassemblies.batteryPack.visible = step >= 3;
    this.currentRig.subassemblies.suspension.visible = step >= 4;
    this.currentRig.subassemblies.powertrain.visible = step >= 6;
    this.currentRig.subassemblies.interior.visible = step >= 7;
    this.currentRig.subassemblies.bodyPanels.visible = step >= 9;
  }

  public handleResize() {
    if (!this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private setupEventListeners() {
    const dom = this.renderer.domElement;

    dom.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging || this.cameraMode === 'cockpit' || this.cameraMode === 'chase') return;
      const deltaX = e.clientX - this.prevMouseX;
      const deltaY = e.clientY - this.prevMouseY;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;

      this.orbitTheta -= deltaX * 0.007;
      this.orbitPhi = Math.max(0.08, Math.min(Math.PI / 2.05, this.orbitPhi - deltaY * 0.007));
      this.updateCameraPosition();
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    dom.addEventListener('wheel', (e) => {
      if (this.cameraMode === 'cockpit' || this.cameraMode === 'chase') return;
      e.preventDefault();
      this.orbitRadius = Math.max(2.0, Math.min(25.0, this.orbitRadius + e.deltaY * 0.006));
      this.updateCameraPosition();
    }, { passive: false });
  }

  private updateCameraPosition() {
    if (this.cameraMode === 'cockpit' || this.cameraMode === 'chase') return;
    const x = this.targetLookAt.x + this.orbitRadius * Math.sin(this.orbitPhi) * Math.sin(this.orbitTheta);
    const y = this.targetLookAt.y + this.orbitRadius * Math.cos(this.orbitPhi);
    const z = this.targetLookAt.z + this.orbitRadius * Math.sin(this.orbitPhi) * Math.cos(this.orbitTheta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.targetLookAt);
  }

  private animate = () => {
    if (!this.isRunning) return;
    requestAnimationFrame(this.animate);

    const delta = this.clock.getDelta();

    // Weather particle animation (Rain/Snow)
    if (this.weatherParticles) {
      const positions = this.weatherParticles.geometry.attributes['position']?.array as Float32Array;
      if (positions) {
        for (let i = 1; i < positions.length; i += 3) {
          positions[i] -= delta * 18;
          if (positions[i] < 0) {
            positions[i] = 20;
          }
        }
        this.weatherParticles.geometry.attributes['position'].needsUpdate = true;
      }
    }

    this.renderer.render(this.scene, this.camera);
  };

  public destroy() {
    this.isRunning = false;
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
    this.renderer.dispose();
  }

  private disposeHierarchy(obj: THREE.Object3D) {
    obj.traverse((child: THREE.Object3D) => {
      const mesh = child as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      if (mesh.material) {
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m: THREE.Material) => m.dispose());
        } else {
          mesh.material.dispose();
        }
      }
    });
  }
}
