import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

interface AssemblyStation {
  step: number;
  title: string;
  subTitle: string;
  description: string;
  icon: string;
}

@Component({
  selector: 'app-manufacturing-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col gap-6 font-sans scrollbar-thin">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-4">
        <div>
          <h2 class="text-xl font-black text-white tracking-tight flex items-center gap-2">
            <mat-icon class="text-purple-400">precision_manufacturing</mat-icon>
            Gigafactory Unboxed Assembly
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">High-speed modular manufacturing line visualizer</p>
        </div>
      </div>

      <!-- Current Step Card -->
      <div class="p-4 bg-gradient-to-br from-purple-950/50 to-slate-900 rounded-2xl border border-purple-800/60 shadow-xl flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-mono font-bold text-purple-300 uppercase">Station {{ sim.assemblyStep() }} of 10</span>
          <span class="px-2 py-0.5 text-[10px] font-mono bg-purple-950 border border-purple-700 text-purple-200 rounded">
            Takt Time: 45s
          </span>
        </div>
        <div class="text-base font-bold text-white">{{ currentStation()?.title }}</div>
        <div class="text-xs text-slate-300 leading-relaxed">{{ currentStation()?.description }}</div>
      </div>

      <!-- Interactive Stepper -->
      <div class="flex flex-col gap-2">
        @for (st of stations; track st.step) {
          <button
            type="button"
            (click)="sim.assemblyStep.set(st.step)"
            class="w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between"
            [class.bg-purple-950/40]="sim.assemblyStep() === st.step"
            [class.border-purple-500]="sim.assemblyStep() === st.step"
            [class.bg-slate-900/60]="sim.assemblyStep() !== st.step"
            [class.border-slate-800]="sim.assemblyStep() !== st.step"
            [class.opacity-50]="st.step > sim.assemblyStep()"
          >
            <div class="flex items-center gap-3">
              <div
                class="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-mono font-bold"
                [class.bg-purple-600]="sim.assemblyStep() === st.step"
                [class.text-white]="sim.assemblyStep() === st.step"
                [class.bg-slate-800]="sim.assemblyStep() !== st.step"
                [class.text-slate-400]="sim.assemblyStep() !== st.step"
              >
                {{ st.step }}
              </div>
              <div>
                <div class="text-xs font-bold text-white">{{ st.title }}</div>
                <div class="text-[11px] text-slate-400 font-mono">{{ st.subTitle }}</div>
              </div>
            </div>
            <mat-icon class="text-sm text-slate-500">{{ st.icon }}</mat-icon>
          </button>
        }
      </div>
    </div>
  `,
})
export class ManufacturingPanelComponent {
  public readonly sim = inject(SimulationService);

  public readonly stations: AssemblyStation[] = [
    {
      step: 0,
      title: 'Empty Assembly Bay',
      subTitle: 'Tooling Calibration',
      description: 'Clean robotic assembly fixture ready for initial giga-casting loading.',
      icon: 'grid_view',
    },
    {
      step: 1,
      title: '9000T Giga Press Castings',
      subTitle: 'Front & Rear Single-Piece Castings',
      description: 'High-pressure die-cast front and rear underbody aluminum megacastings eliminating 140+ stamped parts.',
      icon: 'foundation',
    },
    {
      step: 3,
      title: 'Structural 4680 Battery Pack',
      subTitle: 'Chassis Floor Integration',
      description: 'Tabless 4680 cylindrical cells integrated directly into the structural lower floor of the vehicle.',
      icon: 'battery_charging_full',
    },
    {
      step: 5,
      title: 'Suspension & Adaptive Dampers',
      subTitle: 'Subframe & Steering Rack',
      description: 'Double wishbone front suspension, multi-link rear, and high-frequency active air struts installed.',
      icon: 'build',
    },
    {
      step: 7,
      title: 'Permanent Magnet Synchronous Motors',
      subTitle: 'Dual / Tri-Motor Powertrain',
      description: 'Carbon-sleeved rotors and high-efficiency silicon carbide (SiC) inverters mounted to axle subframes.',
      icon: 'settings',
    },
    {
      step: 8,
      title: 'Unboxed Interior Marriage',
      subTitle: 'HVAC Octovalve & Cockpit Seating',
      description: 'Seats, center touchscreen, and steering wheel assembled as an open module before side panels.',
      icon: 'airline_seat_recline_extra',
    },
    {
      step: 9,
      title: 'Ultra-Hard Exoskeleton Panels',
      subTitle: 'Doors, Hood, Glass & Lighting',
      description: 'Flush body panels, falcon wings, acoustic glass, and matrix LED headlights aligned to tight tolerances.',
      icon: 'layers',
    },
    {
      step: 10,
      title: 'End of Line Validation & Dyno Test',
      subTitle: 'Factory Complete Certification',
      description: 'Full automated roll-test, sensor calibration, headlight alignment, and QA clearance pass.',
      icon: 'verified',
    },
  ];

  public currentStation(): AssemblyStation | undefined {
    return this.stations.find((s) => s.step === this.sim.assemblyStep()) || this.stations[0];
  }
}
