import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  ChangeDetectionStrategy,
  inject,
  effect,
  PLATFORM_ID,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';
import { SimulationScene, CameraViewMode } from '../../engine/scene/simulation-scene';
import { EnvironmentId, WeatherType, Gear } from '../../core/types/vehicle.types';

@Component({
  selector: 'app-simulation-viewport',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full overflow-hidden bg-slate-950 select-none">
      <!-- 3D WebGL Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: Telemetry HUD & Status -->
      <div class="absolute top-3 left-3 right-3 flex items-start justify-between pointer-events-none gap-2">
        <!-- Live Kinematics Badge -->
        <div class="pointer-events-auto bg-slate-900/85 backdrop-blur-md border border-slate-800 p-3 rounded-2xl shadow-xl flex items-center gap-4 text-slate-100 font-mono">
          <div class="flex flex-col items-center">
            <div class="text-3xl font-black tracking-tighter text-cyan-400">
              {{ (sim.livePhysicsState()?.speedKmh || 0) | number:'1.0-0' }}
            </div>
            <div class="text-[10px] text-slate-400 font-semibold tracking-wider uppercase">KM/H</div>
          </div>

          <div class="h-8 w-px bg-slate-800"></div>

          <div class="flex flex-col">
            <div class="text-xs font-semibold text-slate-300">
              {{ (sim.livePhysicsState()?.speedMph || 0) | number:'1.0-0' }} <span class="text-[10px] text-slate-500">MPH</span>
            </div>
            <div class="text-[11px] font-semibold text-amber-400 flex items-center gap-1">
              <span>{{ (sim.livePhysicsState()?.accelG || 0) | number:'1.2-2' }}</span>
              <span class="text-[9px] text-slate-500">G</span>
            </div>
          </div>

          <div class="h-8 w-px bg-slate-800"></div>

          <!-- Battery & Power State -->
          <div class="flex flex-col gap-1 min-w-[110px]">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400 flex items-center gap-1">
                <mat-icon class="text-emerald-400 text-xs">battery_charging_full</mat-icon>
                SOC
              </span>
              <span class="font-bold text-emerald-400">{{ (sim.livePhysicsState()?.batterySocPercent || 80) | number:'1.1-1' }}%</span>
            </div>
            <!-- Battery Bar -->
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                class="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-300"
                [style.width.%]="sim.livePhysicsState()?.batterySocPercent || 80"
              ></div>
            </div>
            <div class="text-[10px] text-slate-400 flex justify-between">
              <span>{{ (sim.livePhysicsState()?.tempBatteryC || 30) | number:'1.1-1' }}°C</span>
              <span>{{ (sim.livePhysicsState()?.motorPowerKw || 0) | number:'1.0-0' }} kW</span>
            </div>
          </div>

          <div class="h-8 w-px bg-slate-800 hidden sm:block"></div>

          <!-- Drive Mode & Gear -->
          <div class="hidden sm:flex flex-col items-center gap-1">
            <div class="flex items-center gap-1">
              @for (g of gears; track g) {
                <span
                  class="px-1.5 py-0.5 text-[10px] font-bold rounded font-mono"
                  [class.bg-red-600]="sim.gear() === g"
                  [class.text-white]="sim.gear() === g"
                  [class.text-slate-500]="sim.gear() !== g"
                >
                  {{ g }}
                </span>
              }
            </div>
            <span class="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider">{{ sim.driveMode() }}</span>
          </div>
        </div>

        <!-- Top Right: Environment & Weather Quick Bar -->
        <div class="pointer-events-auto flex items-center gap-2">
          <div class="bg-slate-900/85 backdrop-blur-md border border-slate-800 p-1.5 rounded-xl shadow-lg flex items-center gap-1 text-slate-300">
            <!-- Environment Selector -->
            <select
              [value]="sim.environment()"
              (change)="onEnvironmentChange($event)"
              class="bg-slate-950 border border-slate-700 text-xs rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="studio">Studio Stage</option>
              <option value="test-track">Proving Grounds (Track)</option>
              <option value="supercharger">Supercharger V4</option>
              <option value="city">City Grid</option>
              <option value="mountain">Mountain Pass</option>
              <option value="factory">Gigafactory Floor</option>
            </select>

            <!-- Weather Selector -->
            <select
              [value]="sim.weather()"
              (change)="onWeatherChange($event)"
              class="bg-slate-950 border border-slate-700 text-xs rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="clear">Clear (Dry μ=1.0)</option>
              <option value="rain">Rain (Wet μ=0.65)</option>
              <option value="snow">Snow/Ice (μ=0.28)</option>
              <option value="fog">Dense Fog</option>
            </select>

            <button
              (click)="sim.resetVehiclePosition()"
              class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all"
              title="Reset Position to Origin"
            >
              <mat-icon class="text-sm">restart_alt</mat-icon>
            </button>
          </div>
        </div>
      </div>

      <!-- Center Exploded View / Cutaway / Assembly Overlay Sliders (Contextual) -->
      @if (sim.viewMode() === 'exploded') {
        <div class="absolute top-20 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur-md border border-slate-800 px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-4 text-slate-200 z-20">
          <mat-icon class="text-cyan-400 text-sm">dashboard_customize</mat-icon>
          <span class="text-xs font-semibold whitespace-nowrap">Exploded Separation:</span>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            [value]="sim.explodedProgress()"
            (input)="onExplodedSlider($event)"
            class="w-44 accent-cyan-400 cursor-pointer"
          />
          <span class="text-xs font-mono text-cyan-300 w-10 text-right">{{ (sim.explodedProgress() * 100) | number:'1.0-0' }}%</span>
        </div>
      }

      @if (sim.viewMode() === 'cutaway') {
        <div class="absolute top-20 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur-md border border-slate-800 px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-4 text-slate-200 z-20">
          <mat-icon class="text-cyan-400 text-sm">layers</mat-icon>
          <span class="text-xs font-semibold whitespace-nowrap">Body Transparency:</span>
          <input
            type="range"
            min="0.05"
            max="1.0"
            step="0.02"
            [value]="sim.cutawayOpacity()"
            (input)="onCutawaySlider($event)"
            class="w-44 accent-cyan-400 cursor-pointer"
          />
          <span class="text-xs font-mono text-cyan-300 w-10 text-right">{{ ((1 - sim.cutawayOpacity()) * 100) | number:'1.0-0' }}%</span>
        </div>
      }

      @if (sim.viewMode() === 'assembly') {
        <div class="absolute top-20 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur-md border border-purple-800/80 px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-4 text-slate-200 z-20">
          <mat-icon class="text-purple-400 text-sm">precision_manufacturing</mat-icon>
          <span class="text-xs font-semibold whitespace-nowrap">Production Station:</span>
          <input
            type="range"
            min="0"
            max="10"
            step="1"
            [value]="sim.assemblyStep()"
            (input)="onAssemblySlider($event)"
            class="w-40 accent-purple-400 cursor-pointer"
          />
          <span class="text-xs font-mono text-purple-300 whitespace-nowrap">Stage {{ sim.assemblyStep() }}/10</span>
        </div>
      }

      <!-- Bottom Controls & Camera Pill -->
      <div class="absolute bottom-3 left-3 right-3 flex flex-col md:flex-row items-center justify-between pointer-events-none gap-3">
        <!-- Mechanism Quick Doors Actions -->
        <div class="pointer-events-auto bg-slate-900/85 backdrop-blur-md border border-slate-800 px-3 py-2 rounded-2xl shadow-xl flex items-center gap-2 overflow-x-auto max-w-full">
          <button
            (click)="sim.toggleDoor('doorFrontLeft')"
            class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
            [class.bg-cyan-950]="sim.rigState().doorFrontLeft > 0.5"
            [class.border-cyan-500]="sim.rigState().doorFrontLeft > 0.5"
            [class.text-cyan-300]="sim.rigState().doorFrontLeft > 0.5"
            [class.border-slate-800]="sim.rigState().doorFrontLeft <= 0.5"
            [class.text-slate-400]="sim.rigState().doorFrontLeft <= 0.5"
          >
            FL Door
          </button>

          <button
            (click)="sim.toggleDoor('doorFrontRight')"
            class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
            [class.bg-cyan-950]="sim.rigState().doorFrontRight > 0.5"
            [class.border-cyan-500]="sim.rigState().doorFrontRight > 0.5"
            [class.text-cyan-300]="sim.rigState().doorFrontRight > 0.5"
            [class.border-slate-800]="sim.rigState().doorFrontRight <= 0.5"
            [class.text-slate-400]="sim.rigState().doorFrontRight <= 0.5"
          >
            FR Door
          </button>

          @if (sim.selectedVehicle().doorConfig === 'FALCON_WING_REAR') {
            <button
              (click)="sim.toggleDoor('falconWingLeftStage1')"
              class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
              [class.bg-rose-950]="sim.rigState().falconWingLeftStage1 > 0.5"
              [class.border-rose-500]="sim.rigState().falconWingLeftStage1 > 0.5"
              [class.text-rose-300]="sim.rigState().falconWingLeftStage1 > 0.5"
              [class.border-slate-800]="sim.rigState().falconWingLeftStage1 <= 0.5"
              [class.text-slate-400]="sim.rigState().falconWingLeftStage1 <= 0.5"
            >
              Falcon Wings
            </button>
          } @else {
            <button
              (click)="sim.toggleDoor('doorRearLeft')"
              class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
              [class.bg-cyan-950]="sim.rigState().doorRearLeft > 0.5"
              [class.border-cyan-500]="sim.rigState().doorRearLeft > 0.5"
              [class.text-cyan-300]="sim.rigState().doorRearLeft > 0.5"
              [class.border-slate-800]="sim.rigState().doorRearLeft <= 0.5"
              [class.text-slate-400]="sim.rigState().doorRearLeft <= 0.5"
            >
              Rear Doors
            </button>
          }

          <button
            (click)="sim.toggleDoor('frunk')"
            class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
            [class.bg-cyan-950]="sim.rigState().frunk > 0.5"
            [class.border-cyan-500]="sim.rigState().frunk > 0.5"
            [class.text-cyan-300]="sim.rigState().frunk > 0.5"
            [class.border-slate-800]="sim.rigState().frunk <= 0.5"
            [class.text-slate-400]="sim.rigState().frunk <= 0.5"
          >
            Frunk
          </button>

          <button
            (click)="sim.toggleDoor('trunk')"
            class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
            [class.bg-cyan-950]="sim.rigState().trunk > 0.5"
            [class.border-cyan-500]="sim.rigState().trunk > 0.5"
            [class.text-cyan-300]="sim.rigState().trunk > 0.5"
            [class.border-slate-800]="sim.rigState().trunk <= 0.5"
            [class.text-slate-400]="sim.rigState().trunk <= 0.5"
          >
            Trunk
          </button>

          @if (sim.selectedVehicle().id === 'cybertruck') {
            <button
              (click)="sim.updateMechanismState({ tonneauCover: sim.rigState().tonneauCover > 0.5 ? 0 : 1 })"
              class="px-2 py-1 text-[11px] font-medium rounded-lg border transition-all flex items-center gap-1 whitespace-nowrap"
              [class.bg-amber-950]="sim.rigState().tonneauCover > 0.5"
              [class.border-amber-500]="sim.rigState().tonneauCover > 0.5"
              [class.text-amber-300]="sim.rigState().tonneauCover > 0.5"
              [class.border-slate-800]="sim.rigState().tonneauCover <= 0.5"
              [class.text-slate-400]="sim.rigState().tonneauCover <= 0.5"
            >
              Vault Shutter
            </button>
          }
        </div>

        <!-- Camera Views Selection -->
        <div class="pointer-events-auto bg-slate-900/85 backdrop-blur-md border border-slate-800 px-3 py-2 rounded-2xl shadow-xl flex items-center gap-1.5 overflow-x-auto max-w-full">
          @for (cam of cameraModes; track cam.id) {
            <button
              (click)="sim.setCameraMode(cam.id)"
              class="px-2.5 py-1 text-xs font-medium rounded-lg transition-all whitespace-nowrap flex items-center gap-1"
              [class.bg-slate-800]="sim.cameraMode() === cam.id"
              [class.text-cyan-400]="sim.cameraMode() === cam.id"
              [class.text-slate-400]="sim.cameraMode() !== cam.id"
              [class.hover:text-slate-200]="sim.cameraMode() !== cam.id"
            >
              <mat-icon class="text-xs">{{ cam.icon }}</mat-icon>
              <span>{{ cam.name }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Virtual Drive HUD Controller (WASD Buttons) -->
      <div class="absolute bottom-16 right-4 pointer-events-auto hidden lg:flex flex-col items-center gap-1 bg-slate-900/70 backdrop-blur-md p-2 rounded-2xl border border-slate-800/80 shadow-lg">
        <button
          (mousedown)="sim.throttle = 1"
          (mouseup)="sim.throttle = 0"
          (mouseleave)="sim.throttle = 0"
          class="w-10 h-10 rounded-xl bg-slate-800 hover:bg-cyan-600 active:bg-cyan-500 text-slate-200 flex items-center justify-center font-bold text-xs border border-slate-700"
          title="Hold W to Accelerate"
        >
          W
        </button>
        <div class="flex items-center gap-1">
          <button
            (mousedown)="sim.steer = -1"
            (mouseup)="sim.steer = 0"
            (mouseleave)="sim.steer = 0"
            class="w-10 h-10 rounded-xl bg-slate-800 hover:bg-cyan-600 active:bg-cyan-500 text-slate-200 flex items-center justify-center font-bold text-xs border border-slate-700"
            title="Hold A to Steer Left"
          >
            A
          </button>
          <button
            (mousedown)="sim.brake = 1"
            (mouseup)="sim.brake = 0"
            (mouseleave)="sim.brake = 0"
            class="w-10 h-10 rounded-xl bg-slate-800 hover:bg-red-600 active:bg-red-500 text-slate-200 flex items-center justify-center font-bold text-xs border border-slate-700"
            title="Hold S to Brake"
          >
            S
          </button>
          <button
            (mousedown)="sim.steer = 1"
            (mouseup)="sim.steer = 0"
            (mouseleave)="sim.steer = 0"
            class="w-10 h-10 rounded-xl bg-slate-800 hover:bg-cyan-600 active:bg-cyan-500 text-slate-200 flex items-center justify-center font-bold text-xs border border-slate-700"
            title="Hold D to Steer Right"
          >
            D
          </button>
        </div>
      </div>
    </div>
  `,
})
export class SimulationViewportComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true })
  public canvasContainerRef!: ElementRef<HTMLDivElement>;

  public readonly sim = inject(SimulationService);
  private readonly platformId = inject(PLATFORM_ID);

  public readonly gears: Gear[] = ['P', 'R', 'N', 'D'];
  public readonly cameraModes: { id: CameraViewMode; name: string; icon: string }[] = [
    { id: 'orbit', name: 'Orbit', icon: '360' },
    { id: 'cockpit', name: 'Cockpit', icon: 'airline_seat_recline_extra' },
    { id: 'chase', name: 'Chase', icon: 'videocam' },
    { id: 'front', name: 'Front', icon: 'arrow_upward' },
    { id: 'side', name: 'Side', icon: 'arrow_forward' },
    { id: 'rear', name: 'Rear', icon: 'arrow_downward' },
    { id: 'top', name: 'Top', icon: 'vertical_align_top' },
    { id: 'wheel', name: 'Wheel', icon: 'tire_repair' },
    { id: 'battery', name: 'Battery', icon: 'battery_charging_full' },
  ];

  private sceneManager: SimulationScene | null = null;
  private resizeObserver: ResizeObserver | null = null;
  private animationFrameId: number | null = null;

  constructor() {
    // Reactive effect for vehicle updates
    effect(() => {
      const vehicle = this.sim.selectedVehicle();
      const color = this.sim.selectedColor();
      const wheel = this.sim.selectedWheel();
      const interior = this.sim.selectedInterior();
      if (this.sceneManager) {
        this.sceneManager.loadVehicle(vehicle, color, wheel, interior);
      }
    });

    // Reactive effect for color
    effect(() => {
      const color = this.sim.selectedColor();
      if (this.sceneManager) {
        this.sceneManager.updateVehicleColor(color);
      }
    });

    // Reactive effect for interior
    effect(() => {
      const interior = this.sim.selectedInterior();
      if (this.sceneManager) {
        this.sceneManager.updateVehicleInterior(interior);
      }
    });

    // Reactive effect for view mode
    effect(() => {
      const mode = this.sim.viewMode();
      if (this.sceneManager) {
        this.sceneManager.setViewMode(mode);
      }
    });

    // Reactive effect for camera mode
    effect(() => {
      const cam = this.sim.cameraMode();
      if (this.sceneManager) {
        this.sceneManager.setCameraMode(cam);
      }
    });

    // Reactive effect for environment
    effect(() => {
      const env = this.sim.environment();
      if (this.sceneManager) {
        this.sceneManager.setupEnvironment(env);
      }
    });

    // Reactive effect for weather
    effect(() => {
      const weather = this.sim.weather();
      if (this.sceneManager) {
        this.sceneManager.setWeather(weather);
      }
    });
  }

  public ngAfterViewInit(): void {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }
    const container = this.canvasContainerRef.nativeElement;
    this.sceneManager = new SimulationScene(container, this.sim.selectedVehicle());

    this.resizeObserver = new ResizeObserver(() => {
      if (this.sceneManager) {
        this.sceneManager.handleResize();
      }
    });
    this.resizeObserver.observe(container);

    // Render sync loop for physics transforms
    const syncLoop = () => {
      const state = this.sim.livePhysicsState();
      const rig = this.sim.rigState();
      if (this.sceneManager && state) {
        this.sceneManager.updatePhysicsTransform(state, rig);
      }
      this.animationFrameId = requestAnimationFrame(syncLoop);
    };
    syncLoop();
  }

  public onExplodedSlider(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.sim.explodedProgress.set(val);
    if (this.sceneManager) {
      this.sceneManager.setExplodedProgress(val);
    }
  }

  public onCutawaySlider(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.sim.cutawayOpacity.set(val);
    if (this.sceneManager) {
      this.sceneManager.setCutawayOpacity(val);
    }
  }

  public onAssemblySlider(e: Event) {
    const val = parseInt((e.target as HTMLInputElement).value, 10);
    this.sim.assemblyStep.set(val);
    if (this.sceneManager) {
      this.sceneManager.setAssemblyStep(val);
    }
  }

  public onEnvironmentChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as EnvironmentId;
    this.sim.setEnvironment(val);
  }

  public onWeatherChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as WeatherType;
    this.sim.setWeather(val);
  }

  public ngOnDestroy(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.sceneManager) {
      this.sceneManager.destroy();
    }
  }
}
