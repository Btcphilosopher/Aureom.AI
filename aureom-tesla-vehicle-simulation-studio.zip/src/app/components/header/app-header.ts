import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5 flex flex-col xl:flex-row items-center justify-between gap-3 text-slate-100 z-50 select-none">
      <!-- Brand & Studio Title -->
      <div class="flex items-center justify-between w-full xl:w-auto gap-4">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-red-600 to-rose-700 flex items-center justify-center shadow-lg shadow-red-900/30 border border-red-400/30">
            <mat-icon class="text-white text-lg">electric_car</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="font-black tracking-widest text-sm text-white font-mono">AUREOM</span>
              <span class="px-1.5 py-0.5 text-[10px] font-semibold bg-red-950/80 border border-red-800/60 text-red-300 rounded font-mono">SIM-3.7</span>
            </div>
            <div class="text-[11px] text-slate-400 font-mono">Vehicle Simulation & Engineering Studio</div>
          </div>
        </div>

        <!-- Mobile Quick View Toggle -->
        <div class="flex xl:hidden items-center gap-2">
          <button
            (click)="sim.toggleAudio()"
            class="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            [class.border-red-500]="sim.isAudioEnabled()"
          >
            <mat-icon class="text-sm">{{ sim.isAudioEnabled() ? 'volume_up' : 'volume_off' }}</mat-icon>
          </button>
        </div>
      </div>

      <!-- Vehicle Fleet Selector (All 9 Models) -->
      <div class="flex items-center gap-1 overflow-x-auto max-w-full py-1 px-1 bg-slate-900/80 rounded-xl border border-slate-800/80 scrollbar-none">
        @for (veh of sim.vehicleList; track veh.id) {
          <button
            (click)="sim.selectVehicle(veh.id)"
            class="px-2.5 py-1 text-xs font-semibold rounded-lg transition-all duration-150 whitespace-nowrap flex items-center gap-1.5"
            [class.bg-gradient-to-r]="sim.selectedVehicle().id === veh.id"
            [class.from-red-600]="sim.selectedVehicle().id === veh.id"
            [class.to-rose-600]="sim.selectedVehicle().id === veh.id"
            [class.text-white]="sim.selectedVehicle().id === veh.id"
            [class.shadow-md]="sim.selectedVehicle().id === veh.id"
            [class.text-slate-400]="sim.selectedVehicle().id !== veh.id"
            [class.hover:text-slate-200]="sim.selectedVehicle().id !== veh.id"
            [class.hover:bg-slate-800/60]="sim.selectedVehicle().id !== veh.id"
          >
            <span>{{ veh.name }}</span>
            @if (veh.series === 'Autonomous') {
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            } @else if (veh.series === 'Performance') {
              <span class="w-1.5 h-1.5 rounded-full bg-red-400"></span>
            }
          </button>
        }
      </div>

      <!-- View Modes Navigation -->
      <div class="flex items-center gap-1.5 overflow-x-auto max-w-full py-1">
        <button
          (click)="sim.setViewMode('studio')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'studio'"
          [class.border-cyan-500/60]="sim.viewMode() === 'studio'"
          [class.text-cyan-300]="sim.viewMode() === 'studio'"
          [class.border-slate-800]="sim.viewMode() !== 'studio'"
          [class.text-slate-400]="sim.viewMode() !== 'studio'"
        >
          <mat-icon class="text-sm">visibility</mat-icon>
          <span>Studio</span>
        </button>

        <button
          (click)="sim.setViewMode('configurator')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'configurator'"
          [class.border-cyan-500/60]="sim.viewMode() === 'configurator'"
          [class.text-cyan-300]="sim.viewMode() === 'configurator'"
          [class.border-slate-800]="sim.viewMode() !== 'configurator'"
          [class.text-slate-400]="sim.viewMode() !== 'configurator'"
        >
          <mat-icon class="text-sm">tune</mat-icon>
          <span>Config</span>
        </button>

        <button
          (click)="sim.setViewMode('physics-sim')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'physics-sim'"
          [class.border-cyan-500/60]="sim.viewMode() === 'physics-sim'"
          [class.text-cyan-300]="sim.viewMode() === 'physics-sim'"
          [class.border-slate-800]="sim.viewMode() !== 'physics-sim'"
          [class.text-slate-400]="sim.viewMode() !== 'physics-sim'"
        >
          <mat-icon class="text-sm">sports_motorsports</mat-icon>
          <span>Drive Sim</span>
        </button>

        <button
          (click)="sim.setViewMode('cockpit')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'cockpit'"
          [class.border-cyan-500/60]="sim.viewMode() === 'cockpit'"
          [class.text-cyan-300]="sim.viewMode() === 'cockpit'"
          [class.border-slate-800]="sim.viewMode() !== 'cockpit'"
          [class.text-slate-400]="sim.viewMode() !== 'cockpit'"
        >
          <mat-icon class="text-sm">airline_seat_recline_extra</mat-icon>
          <span>Cockpit</span>
        </button>

        <button
          (click)="sim.setViewMode('cutaway')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'cutaway'"
          [class.border-cyan-500/60]="sim.viewMode() === 'cutaway'"
          [class.text-cyan-300]="sim.viewMode() === 'cutaway'"
          [class.border-slate-800]="sim.viewMode() !== 'cutaway'"
          [class.text-slate-400]="sim.viewMode() !== 'cutaway'"
        >
          <mat-icon class="text-sm">layers</mat-icon>
          <span>X-Ray Cutaway</span>
        </button>

        <button
          (click)="sim.setViewMode('exploded')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'exploded'"
          [class.border-cyan-500/60]="sim.viewMode() === 'exploded'"
          [class.text-cyan-300]="sim.viewMode() === 'exploded'"
          [class.border-slate-800]="sim.viewMode() !== 'exploded'"
          [class.text-slate-400]="sim.viewMode() !== 'exploded'"
        >
          <mat-icon class="text-sm">dashboard_customize</mat-icon>
          <span>Exploded CAD</span>
        </button>

        <button
          (click)="sim.setViewMode('thermal')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'thermal'"
          [class.border-amber-500/60]="sim.viewMode() === 'thermal'"
          [class.text-amber-300]="sim.viewMode() === 'thermal'"
          [class.border-slate-800]="sim.viewMode() !== 'thermal'"
          [class.text-slate-400]="sim.viewMode() !== 'thermal'"
        >
          <mat-icon class="text-sm">thermostat</mat-icon>
          <span>Thermal IR</span>
        </button>

        <button
          (click)="sim.setViewMode('charging')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'charging'"
          [class.border-emerald-500/60]="sim.viewMode() === 'charging'"
          [class.text-emerald-300]="sim.viewMode() === 'charging'"
          [class.border-slate-800]="sim.viewMode() !== 'charging'"
          [class.text-slate-400]="sim.viewMode() !== 'charging'"
        >
          <mat-icon class="text-sm">ev_station</mat-icon>
          <span>V4 Supercharge</span>
        </button>

        <button
          (click)="sim.setViewMode('assembly')"
          class="px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all flex items-center gap-1.5 whitespace-nowrap"
          [class.bg-slate-800]="sim.viewMode() === 'assembly'"
          [class.border-purple-500/60]="sim.viewMode() === 'assembly'"
          [class.text-purple-300]="sim.viewMode() === 'assembly'"
          [class.border-slate-800]="sim.viewMode() !== 'assembly'"
          [class.text-slate-400]="sim.viewMode() !== 'assembly'"
        >
          <mat-icon class="text-sm">precision_manufacturing</mat-icon>
          <span>Assembly</span>
        </button>
      </div>

      <!-- Secondary Controls: Audio & Presentation Tour -->
      <div class="hidden xl:flex items-center gap-2">
        <button
          (click)="sim.toggleAudio()"
          class="px-2.5 py-1.5 rounded-lg text-xs font-mono border transition-all flex items-center gap-1"
          [class.bg-slate-800]="sim.isAudioEnabled()"
          [class.border-cyan-500/60]="sim.isAudioEnabled()"
          [class.text-cyan-300]="sim.isAudioEnabled()"
          [class.border-slate-800]="!sim.isAudioEnabled()"
          [class.text-slate-400]="!sim.isAudioEnabled()"
          title="Toggle Web Audio Motor Synthesizer"
        >
          <mat-icon class="text-sm">{{ sim.isAudioEnabled() ? 'volume_up' : 'volume_off' }}</mat-icon>
          <span>SFX</span>
        </button>

        <button
          (click)="sim.autoTourActive() ? sim.stopAutoTour() : sim.startAutoPresentationTour()"
          class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 shadow-md"
          [class.bg-gradient-to-r]="true"
          [class.from-amber-600]="!sim.autoTourActive()"
          [class.to-yellow-600]="!sim.autoTourActive()"
          [class.from-red-600]="sim.autoTourActive()"
          [class.to-rose-700]="sim.autoTourActive()"
          [class.text-white]="true"
        >
          <mat-icon class="text-sm">{{ sim.autoTourActive() ? 'stop' : 'play_circle' }}</mat-icon>
          <span>{{ sim.autoTourActive() ? 'Stop Tour' : 'Auto Tour' }}</span>
        </button>
      </div>
    </header>
  `,
})
export class AppHeaderComponent {
  public readonly sim = inject(SimulationService);
}
