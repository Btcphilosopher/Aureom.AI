import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';
import { SIMULATION_SCENARIOS } from '../../core/data/scenarios-registry';
import { SimulationScenario } from '../../core/types/vehicle.types';

@Component({
  selector: 'app-scenario-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col gap-6 font-sans scrollbar-thin">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-4">
        <div>
          <h2 class="text-xl font-black text-white tracking-tight flex items-center gap-2">
            <mat-icon class="text-amber-400">science</mat-icon>
            Autonomous Simulation Scenarios
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">Automated closed-loop multi-physics validation test benches</p>
        </div>
      </div>

      <!-- Live Scenario Running Banner -->
      @if (sim.isScenarioRunning() && sim.activeScenario()) {
        <div class="p-4 bg-gradient-to-r from-amber-950/70 to-slate-900 rounded-2xl border border-amber-600/60 shadow-xl flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></span>
              <span class="text-xs font-mono font-bold text-amber-300 uppercase">RUNNING: {{ sim.activeScenario()?.title }}</span>
            </div>
            <span class="text-xs font-mono font-bold text-slate-200">
              {{ sim.scenarioProgressSec() | number:'1.1-1' }}s / {{ sim.activeScenario()?.durationSec }}s
            </span>
          </div>

          <!-- Progress Bar -->
          <div class="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
            <div
              class="bg-amber-400 h-full rounded-full transition-all duration-100"
              [style.width.%]="(sim.scenarioProgressSec() / (sim.activeScenario()?.durationSec || 10)) * 100"
            ></div>
          </div>

          <div class="text-[11px] text-slate-300 font-mono flex justify-between pt-1">
            <span>Speed: {{ (sim.livePhysicsState()?.speedKmh || 0) | number:'1.0-0' }} km/h</span>
            <span>G-Force: {{ (sim.livePhysicsState()?.accelG || 0) | number:'1.2-2' }} G</span>
            <span>Power: {{ (sim.livePhysicsState()?.motorPowerKw || 0) | number:'1.0-0' }} kW</span>
          </div>
        </div>
      }

      <!-- List of 10 Test Scenarios -->
      <div class="flex flex-col gap-3">
        @for (sc of scenarios; track sc.id) {
          <div
            class="p-4 rounded-2xl border transition-all flex flex-col gap-3 relative overflow-hidden"
            [class.bg-slate-900]="sim.activeScenario()?.id === sc.id"
            [class.border-amber-500]="sim.activeScenario()?.id === sc.id"
            [class.shadow-lg]="sim.activeScenario()?.id === sc.id"
            [class.bg-slate-950]="sim.activeScenario()?.id !== sc.id"
            [class.border-slate-800]="sim.activeScenario()?.id !== sc.id"
            [class.hover:border-slate-700]="sim.activeScenario()?.id !== sc.id"
          >
            <div class="flex items-start justify-between">
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-sm font-bold text-white">{{ sc.title }}</span>
                  <span class="px-2 py-0.5 text-[10px] font-mono font-semibold bg-slate-900 border border-slate-700 text-cyan-300 rounded">
                    {{ sc.environment | uppercase }}
                  </span>
                </div>
                <p class="text-xs text-slate-400 mt-1 leading-relaxed">{{ sc.description }}</p>
              </div>

              <button
                (click)="sim.runScenario(sc)"
                class="px-3.5 py-1.5 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-1.5 shadow-md whitespace-nowrap"
                [class.bg-amber-500]="sim.activeScenario()?.id !== sc.id || !sim.isScenarioRunning()"
                [class.hover:bg-amber-400]="sim.activeScenario()?.id !== sc.id || !sim.isScenarioRunning()"
                [class.text-slate-950]="sim.activeScenario()?.id !== sc.id || !sim.isScenarioRunning()"
                [class.bg-slate-800]="sim.activeScenario()?.id === sc.id && sim.isScenarioRunning()"
                [class.text-slate-400]="sim.activeScenario()?.id === sc.id && sim.isScenarioRunning()"
              >
                <mat-icon class="text-sm">play_arrow</mat-icon>
                <span>{{ sim.activeScenario()?.id === sc.id && sim.isScenarioRunning() ? 'In Test' : 'Run Suite' }}</span>
              </button>
            </div>

            <!-- Objectives List -->
            @if (sc.objectives && sc.objectives.length > 0) {
              <div class="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
                <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Test Objectives:</span>
                <ul class="text-xs text-slate-300 flex flex-col gap-1 list-disc pl-4 font-mono">
                  @for (obj of sc.objectives; track obj) {
                    <li>{{ obj }}</li>
                  }
                </ul>
              </div>
            } @else {
              <div class="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
                <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Test Target:</span>
                <p class="text-xs text-slate-300 font-mono">{{ sc.targetObjective }}</p>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `,
})
export class ScenarioPanelComponent {
  public readonly sim = inject(SimulationService);
  public readonly scenarios: SimulationScenario[] = SIMULATION_SCENARIOS;
}
