import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

type EngineeringTab = 'dynamics' | 'powertrain' | 'battery' | 'thermal' | 'aero' | 'suspension';

@Component({
  selector: 'app-engineering-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col gap-5 font-mono scrollbar-thin">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-base">memory</mat-icon>
          <span class="text-sm font-bold text-white tracking-wide uppercase">Engineering Telemetry</span>
        </div>
        <span class="px-2 py-0.5 text-[10px] font-bold bg-cyan-950 border border-cyan-800 text-cyan-300 rounded">
          100 Hz Real-Time
        </span>
      </div>

      <!-- Navigation Tabs -->
      <div class="grid grid-cols-3 gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
        <button
          (click)="activeTab.set('dynamics')"
          class="py-1.5 px-2 rounded-lg text-center transition-all font-semibold"
          [class.bg-slate-800]="activeTab() === 'dynamics'"
          [class.text-cyan-400]="activeTab() === 'dynamics'"
          [class.text-slate-400]="activeTab() !== 'dynamics'"
        >
          Dynamics
        </button>
        <button
          (click)="activeTab.set('powertrain')"
          class="py-1.5 px-2 rounded-lg text-center transition-all font-semibold"
          [class.bg-slate-800]="activeTab() === 'powertrain'"
          [class.text-cyan-400]="activeTab() === 'powertrain'"
          [class.text-slate-400]="activeTab() !== 'powertrain'"
        >
          Motors
        </button>
        <button
          (click)="activeTab.set('battery')"
          class="py-1.5 px-2 rounded-lg text-center transition-all font-semibold"
          [class.bg-slate-800]="activeTab() === 'battery'"
          [class.text-cyan-400]="activeTab() === 'battery'"
          [class.text-slate-400]="activeTab() !== 'battery'"
        >
          4680 Pack
        </button>
        <button
          (click)="activeTab.set('thermal')"
          class="py-1.5 px-2 rounded-lg text-center transition-all font-semibold"
          [class.bg-slate-800]="activeTab() === 'thermal'"
          [class.text-cyan-400]="activeTab() === 'thermal'"
          [class.text-slate-400]="activeTab() !== 'thermal'"
        >
          Thermal IR
        </button>
        <button
          (click)="activeTab.set('aero')"
          class="py-1.5 px-2 rounded-lg text-center transition-all font-semibold"
          [class.bg-slate-800]="activeTab() === 'aero'"
          [class.text-cyan-400]="activeTab() === 'aero'"
          [class.text-slate-400]="activeTab() !== 'aero'"
        >
          Aero & Drag
        </button>
        <button
          (click)="activeTab.set('suspension')"
          class="py-1.5 px-2 rounded-lg text-center transition-all font-semibold"
          [class.bg-slate-800]="activeTab() === 'suspension'"
          [class.text-cyan-400]="activeTab() === 'suspension'"
          [class.text-slate-400]="activeTab() !== 'suspension'"
        >
          Tyres / Load
        </button>
      </div>

      <!-- Tab Content 1: Vehicle Dynamics & Kinematics -->
      @if (activeTab() === 'dynamics') {
        <div class="flex flex-col gap-3">
          <div class="grid grid-cols-2 gap-2 text-xs">
            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">LONGITUDINAL G</span>
              <span class="text-base font-bold text-amber-300">
                {{ (sim.livePhysicsState()?.accelG || 0) | number:'1.2-2' }} G
              </span>
              <span class="text-[10px] text-slate-500">{{ (sim.livePhysicsState()?.accelXMs2 || 0) | number:'1.2-2' }} m/s²</span>
            </div>

            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">LATERAL G</span>
              <span class="text-base font-bold text-cyan-300">
                {{ (sim.livePhysicsState()?.lateralG || 0) | number:'1.2-2' }} G
              </span>
              <span class="text-[10px] text-slate-500">{{ (sim.livePhysicsState()?.accelZMs2 || 0) | number:'1.2-2' }} m/s²</span>
            </div>

            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">YAW RATE</span>
              <span class="text-base font-bold text-white">
                {{ ((sim.livePhysicsState()?.yawRateRadSec || 0) * (180 / 3.14159)) | number:'1.1-1' }} °/s
              </span>
              <span class="text-[10px] text-slate-500">Target Yaw Moment</span>
            </div>

            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">STEER ANGLE</span>
              <span class="text-base font-bold text-emerald-300">
                {{ ((sim.livePhysicsState()?.steeringAngleRad || 0) * (180 / 3.14159)) | number:'1.1-1' }}°
              </span>
              <span class="text-[10px] text-slate-500">Ackermann Ratio</span>
            </div>
          </div>

          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-2">
            <span class="text-xs font-bold text-slate-300">Body Chassis Attitude</span>
            <div class="flex items-center justify-between text-xs">
              <span class="text-slate-400">Pitch Angle (Squat / Dive):</span>
              <span class="font-bold text-amber-400">
                {{ ((sim.livePhysicsState()?.pitchRad || 0) * (180 / 3.14159)) | number:'1.2-2' }}°
              </span>
            </div>
            <div class="flex items-center justify-between text-xs">
              <span class="text-slate-400">Roll Angle (Lateral Sway):</span>
              <span class="font-bold text-cyan-400">
                {{ ((sim.livePhysicsState()?.rollRad || 0) * (180 / 3.14159)) | number:'1.2-2' }}°
              </span>
            </div>
          </div>
        </div>
      }

      <!-- Tab Content 2: Powertrain & Motors -->
      @if (activeTab() === 'powertrain') {
        <div class="flex flex-col gap-3">
          <div class="p-3.5 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-200">Total Powertrain Power</span>
              <span class="text-sm font-bold text-cyan-400">
                {{ (sim.livePhysicsState()?.motorPowerKw || 0) | number:'1.1-1' }} kW
              </span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                class="bg-gradient-to-r from-cyan-500 to-blue-600 h-full rounded-full"
                [style.width.%]="Math.min(100, ((sim.livePhysicsState()?.motorPowerKw || 0) / 750) * 100)"
              ></div>
            </div>
            <div class="flex justify-between text-[11px] text-slate-400">
              <span>Mechanical Equivalent:</span>
              <span class="text-slate-200 font-bold">
                {{ ((sim.livePhysicsState()?.motorPowerKw || 0) * 1.341) | number:'1.0-0' }} HP
              </span>
            </div>
          </div>

          <!-- Motors Breakdown -->
          @for (m of sim.selectedTrim().motors; track m.id) {
            <div class="p-3 bg-slate-900/80 rounded-xl border border-slate-800 flex flex-col gap-1 text-xs">
              <div class="flex justify-between font-bold text-white">
                <span>{{ m.name }}</span>
                <span class="text-cyan-400">{{ m.peakPowerKw }} kW</span>
              </div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Type: {{ m.type }}</span>
                <span>Gear Ratio: {{ m.gearRatio }}:1</span>
              </div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Inverter Efficiency: {{ (m.efficiency * 100) | number:'1.1-1' }}%</span>
                <span>Max RPM: {{ m.maxRpm | number }}</span>
              </div>
            </div>
          }
        </div>
      }

      <!-- Tab Content 3: 4680 Battery Pack -->
      @if (activeTab() === 'battery') {
        <div class="flex flex-col gap-3 text-xs">
          <div class="p-3.5 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-200">Battery State of Charge</span>
              <span class="text-base font-bold text-emerald-400">
                {{ (sim.livePhysicsState()?.batterySocPercent || 80) | number:'1.1-1' }}%
              </span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                class="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full"
                [style.width.%]="sim.livePhysicsState()?.batterySocPercent || 80"
              ></div>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2">
            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">PACK VOLTAGE</span>
              <span class="text-sm font-bold text-white">
                {{ (sim.livePhysicsState()?.batteryVoltageV || 400) | number:'1.1-1' }} V
              </span>
            </div>
            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">PACK CURRENT</span>
              <span class="text-sm font-bold text-amber-300">
                {{ (sim.livePhysicsState()?.batteryCurrentA || 0) | number:'1.1-1' }} A
              </span>
            </div>
            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">CAPACITY</span>
              <span class="text-sm font-bold text-emerald-300">
                {{ sim.selectedTrim().battery.usableCapacityKwh }} kWh
              </span>
            </div>
            <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-1">
              <span class="text-[10px] text-slate-400">EFFICIENCY</span>
              <span class="text-sm font-bold text-cyan-300">
                {{ (sim.livePhysicsState()?.energyConsumptionWhPerKm || 155) | number:'1.0-0' }} Wh/km
              </span>
            </div>
          </div>
        </div>
      }

      <!-- Tab Content 4: Thermal Nodes Digital Twin -->
      @if (activeTab() === 'thermal') {
        <div class="flex flex-col gap-2 text-xs">
          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-sm">battery_full</mat-icon>
              <span>4680 Battery Cells</span>
            </div>
            <span class="font-bold text-emerald-300">
              {{ (sim.livePhysicsState()?.tempBatteryC || 30) | number:'1.1-1' }} °C
            </span>
          </div>

          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-sm">electric_bolt</mat-icon>
              <span>SiC Power Inverters</span>
            </div>
            <span class="font-bold text-cyan-300">
              {{ (sim.livePhysicsState()?.tempInverterC || 38) | number:'1.1-1' }} °C
            </span>
          </div>

          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">rotate_right</mat-icon>
              <span>Rear Drive Motor Stator</span>
            </div>
            <span class="font-bold text-amber-300">
              {{ (sim.livePhysicsState()?.tempMotorRearC || 36) | number:'1.1-1' }} °C
            </span>
          </div>

          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-red-400 text-sm">tire_repair</mat-icon>
              <span>Brake Discs & Friction</span>
            </div>
            <span class="font-bold text-red-300">
              {{ (sim.livePhysicsState()?.tempBrakeDiscsC || 24) | number:'1.1-1' }} °C
            </span>
          </div>

          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-blue-400 text-sm">ac_unit</mat-icon>
              <span>Octovalve Cabin HVAC</span>
            </div>
            <span class="font-bold text-blue-300">
              {{ (sim.livePhysicsState()?.tempCabinC || 21) | number:'1.1-1' }} °C
            </span>
          </div>
        </div>
      }

      <!-- Tab Content 5: Aerodynamics & Drag -->
      @if (activeTab() === 'aero') {
        <div class="flex flex-col gap-3 text-xs">
          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-2">
            <div class="flex justify-between">
              <span class="text-slate-400">Drag Coefficient (Cd):</span>
              <span class="font-bold text-cyan-400">{{ sim.selectedVehicle().dimensions.dragCoefficientCd }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Frontal Area (A):</span>
              <span class="font-bold text-slate-200">{{ sim.selectedVehicle().dimensions.frontalAreaM2 }} m²</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Aerodynamic Cd·A Product:</span>
              <span class="font-bold text-emerald-400">
                {{ (sim.selectedVehicle().dimensions.dragCoefficientCd * sim.selectedVehicle().dimensions.frontalAreaM2) | number:'1.3-3' }} m²
              </span>
            </div>
          </div>
        </div>
      }

      <!-- Tab Content 6: Tyres, Load & Suspension -->
      @if (activeTab() === 'suspension') {
        <div class="flex flex-col gap-3 text-xs">
          <div class="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-2">
            <span class="text-xs font-bold text-slate-200">Per-Corner Vertical Load (N)</span>
            <div class="grid grid-cols-2 gap-2 text-center text-xs">
              <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div class="text-[10px] text-slate-400">FRONT LEFT</div>
                <div class="font-bold text-cyan-300">
                  {{ (sim.livePhysicsState()?.tyreVerticalLoadN?.[0] || 4500) | number:'1.0-0' }} N
                </div>
              </div>
              <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div class="text-[10px] text-slate-400">FRONT RIGHT</div>
                <div class="font-bold text-cyan-300">
                  {{ (sim.livePhysicsState()?.tyreVerticalLoadN?.[1] || 4500) | number:'1.0-0' }} N
                </div>
              </div>
              <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div class="text-[10px] text-slate-400">REAR LEFT</div>
                <div class="font-bold text-cyan-300">
                  {{ (sim.livePhysicsState()?.tyreVerticalLoadN?.[2] || 4500) | number:'1.0-0' }} N
                </div>
              </div>
              <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                <div class="text-[10px] text-slate-400">REAR RIGHT</div>
                <div class="font-bold text-cyan-300">
                  {{ (sim.livePhysicsState()?.tyreVerticalLoadN?.[3] || 4500) | number:'1.0-0' }} N
                </div>
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class EngineeringPanelComponent {
  public readonly sim = inject(SimulationService);
  public readonly activeTab = signal<EngineeringTab>('dynamics');
  public readonly Math = Math;
}
