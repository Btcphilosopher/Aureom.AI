import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';
import { DriveMode, Gear } from '../../core/types/vehicle.types';

@Component({
  selector: 'app-cockpit-overlay',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-slate-950/90 backdrop-blur-md p-4 lg:p-6 text-slate-100 flex flex-col font-sans select-none overflow-y-auto">
      <!-- Cockpit Center Touchscreen Display Frame -->
      <div class="max-w-5xl mx-auto w-full flex-1 bg-slate-900/95 border-2 border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col relative">
        <!-- Top Status Bar -->
        <div class="bg-slate-950/90 px-6 py-2 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-300">
          <div class="flex items-center gap-4">
            <div class="flex items-center gap-1 font-bold">
              @for (g of gears; track g) {
                <button
                  type="button"
                  (click)="sim.setGear(g)"
                  class="cursor-pointer px-2 py-0.5 rounded border-0 transition-colors"
                  [class.bg-red-600]="sim.gear() === g"
                  [class.text-white]="sim.gear() === g"
                  [class.text-slate-500]="sim.gear() !== g"
                >
                  {{ g }}
                </button>
              }
            </div>
            <span class="text-slate-600">|</span>
            <span class="text-cyan-400 font-bold tracking-wider uppercase">{{ sim.selectedTrim().name }}</span>
          </div>

          <div class="flex items-center gap-4">
            <span class="text-slate-400">12:45 PM</span>
            <span class="text-slate-400">{{ (sim.livePhysicsState()?.tempCabinC || 21) | number:'1.0-0' }}°C Exterior</span>
            <div class="flex items-center gap-1 text-emerald-400 font-bold">
              <mat-icon class="text-xs">battery_full</mat-icon>
              <span>{{ (sim.livePhysicsState()?.batterySocPercent || 80) | number:'1.0-0' }}%</span>
            </div>
          </div>
        </div>

        <!-- Main Display Split: Left Driver FSD Vector Visualizer, Right Maps & Controls -->
        <div class="flex-1 grid grid-cols-1 md:grid-cols-12 gap-0 overflow-hidden">
          <!-- Left: 3D Autopilot / FSD Self-Driving Visualizer Screen (Cols 5) -->
          <div class="md:col-span-5 bg-gradient-to-b from-slate-950 to-slate-900 p-6 flex flex-col justify-between border-r border-slate-800 relative">
            <!-- Speed Gauge -->
            <div class="flex flex-col items-center">
              <div class="text-7xl font-black text-white font-mono tracking-tighter">
                {{ (sim.livePhysicsState()?.speedKmh || 0) | number:'1.0-0' }}
              </div>
              <div class="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">KM/H</div>
              <div class="text-xs text-slate-500 font-mono mt-0.5">
                {{ (sim.livePhysicsState()?.speedMph || 0) | number:'1.0-0' }} MPH
              </div>
            </div>

            <!-- FSD Simulated 3D Lane Vector Path -->
            <div class="my-6 relative h-44 w-full flex items-center justify-center overflow-hidden rounded-2xl bg-slate-950/60 border border-slate-800/80">
              <!-- Road Perspective Lines -->
              <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div class="w-24 h-full border-x-2 border-cyan-500/50 transform perspective-500 rotate-x-60"></div>
                <div class="w-1 h-full bg-cyan-400/40 animate-pulse"></div>
              </div>

              <!-- Ego Vehicle Silhouette -->
              <div class="w-12 h-20 rounded-xl bg-gradient-to-t from-red-600 to-rose-400 border border-red-300 shadow-xl shadow-cyan-500/20 z-10 flex items-center justify-center">
                <mat-icon class="text-white text-base">directions_car</mat-icon>
              </div>

              <!-- FSD Full Self-Driving Active Badge -->
              <div class="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/60 text-[10px] font-mono text-cyan-300 flex items-center gap-1">
                <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                <span>FSD v13 Supervised</span>
              </div>
            </div>

            <!-- Speed Limit & Autosteer Set Speed -->
            <div class="flex items-center justify-around bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-xs font-mono">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-full border-2 border-red-500 flex items-center justify-center font-bold text-[10px] text-white">
                  120
                </div>
                <span class="text-slate-400">MAX</span>
              </div>
              <div class="flex items-center gap-1 text-cyan-400 font-bold">
                <mat-icon class="text-sm">auto_mode</mat-icon>
                <span>ACTIVE</span>
              </div>
            </div>
          </div>

          <!-- Right: Maps, Media, Climate & Vehicle Controls (Cols 7) -->
          <div class="md:col-span-7 bg-slate-950 p-6 flex flex-col justify-between gap-4">
            <!-- Simulated Navigation Route Card -->
            <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 flex items-center justify-between shadow-lg">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-cyan-600/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                  <mat-icon>turn_right</mat-icon>
                </div>
                <div>
                  <div class="text-sm font-bold text-white">Turn right onto Supercharger Way</div>
                  <div class="text-xs text-slate-400">In 350 meters • Arrival at 1:15 PM (68% SOC)</div>
                </div>
              </div>
              <div class="text-right font-mono text-xs text-cyan-400 font-bold">
                14.2 km
              </div>
            </div>

            <!-- Plaid / Acceleration Launch Control Panel -->
            <div class="bg-gradient-to-r from-red-950/60 to-slate-900 p-4 rounded-2xl border border-red-900/60 flex items-center justify-between">
              <div>
                <div class="text-xs font-mono font-bold text-red-400 uppercase tracking-wider flex items-center gap-1">
                  <mat-icon class="text-sm">bolt</mat-icon>
                  Acceleration Mode
                </div>
                <div class="text-xs text-slate-300 mt-0.5">Battery Preconditioned for Peak Power</div>
              </div>

              <div class="flex items-center gap-1.5 font-mono">
                @for (m of driveModes; track m) {
                  <button
                    (click)="sim.setDriveMode(m)"
                    class="px-2.5 py-1 text-xs font-bold rounded-lg uppercase border transition-all"
                    [class.bg-red-600]="sim.driveMode() === m"
                    [class.border-red-500]="sim.driveMode() === m"
                    [class.text-white]="sim.driveMode() === m"
                    [class.border-slate-800]="sim.driveMode() !== m"
                    [class.text-slate-400]="sim.driveMode() !== m"
                  >
                    {{ m }}
                  </button>
                }
              </div>
            </div>

            <!-- Dual-Zone Climate Controls -->
            <div class="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
              <div class="flex items-center gap-2">
                <button
                  (click)="cabinTemp.set(cabinTemp() - 0.5)"
                  class="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center font-bold"
                >
                  -
                </button>
                <span class="text-base font-bold font-mono text-cyan-300">{{ cabinTemp() | number:'1.1-1' }}°C</span>
                <button
                  (click)="cabinTemp.set(cabinTemp() + 0.5)"
                  class="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center font-bold"
                >
                  +
                </button>
                <span class="text-slate-400 ml-2">Dual Climate Auto</span>
              </div>

              <div class="flex items-center gap-2 text-slate-400">
                <mat-icon class="text-sm text-cyan-400">air</mat-icon>
                <span>Fan Level 3</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Bottom App Dock Bar -->
        <div class="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-around text-slate-400">
          <button (click)="sim.toggleDoor('doorFrontLeft')" class="hover:text-white flex flex-col items-center gap-0.5">
            <mat-icon class="text-lg">car_rental</mat-icon>
            <span class="text-[10px] font-mono">Locks</span>
          </button>
          <button (click)="sim.setViewMode('charging')" class="hover:text-emerald-400 flex flex-col items-center gap-0.5">
            <mat-icon class="text-lg">ev_station</mat-icon>
            <span class="text-[10px] font-mono">Charging</span>
          </button>
          <button (click)="sim.setViewMode('cutaway')" class="hover:text-cyan-400 flex flex-col items-center gap-0.5">
            <mat-icon class="text-lg">layers</mat-icon>
            <span class="text-[10px] font-mono">X-Ray</span>
          </button>
          <button (click)="sim.setViewMode('scenarios')" class="hover:text-amber-400 flex flex-col items-center gap-0.5">
            <mat-icon class="text-lg">science</mat-icon>
            <span class="text-[10px] font-mono">Scenarios</span>
          </button>
          <button (click)="sim.setViewMode('studio')" class="hover:text-white flex flex-col items-center gap-0.5">
            <mat-icon class="text-lg">exit_to_app</mat-icon>
            <span class="text-[10px] font-mono">Exit Cockpit</span>
          </button>
        </div>
      </div>
    </div>
  `,
})
export class CockpitOverlayComponent {
  public readonly sim = inject(SimulationService);
  public readonly gears: Gear[] = ['P', 'R', 'N', 'D'];
  public readonly driveModes: DriveMode[] = ['chill', 'sport', 'plaid', 'track'];
  public readonly cabinTemp = signal<number>(21.5);
}
