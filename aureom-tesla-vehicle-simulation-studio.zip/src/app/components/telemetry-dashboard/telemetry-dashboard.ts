import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

@Component({
  selector: 'app-telemetry-dashboard',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col gap-6 font-mono scrollbar-thin">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-4">
        <div>
          <h2 class="text-xl font-black text-white tracking-tight flex items-center gap-2">
            <mat-icon class="text-cyan-400">query_stats</mat-icon>
            Digital Twin Telemetry Lab
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">High-frequency multi-channel physics time-series log</p>
        </div>

        <button
          (click)="exportTelemetryJson()"
          class="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md"
        >
          <mat-icon class="text-sm">download</mat-icon>
          <span>Export .SIMDATA</span>
        </button>
      </div>

      <!-- Time Machine & Playback Controls -->
      <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 flex flex-col gap-3 shadow-lg">
        <div class="flex items-center justify-between text-xs">
          <span class="font-bold text-slate-200 flex items-center gap-1.5">
            <mat-icon class="text-amber-400 text-sm">history</mat-icon>
            Digital Twin Time Machine
          </span>
          <span class="text-slate-400">
            Recorded: {{ sim.telemetryHistory().length }} samples
          </span>
        </div>

        <!-- Timeline Scrubber Slider -->
        <div class="flex items-center gap-3">
          <input
            type="range"
            min="0"
            [max]="Math.max(1, sim.telemetryHistory().length - 1)"
            [value]="sim.timeMachineScrubIndex() >= 0 ? sim.timeMachineScrubIndex() : sim.telemetryHistory().length - 1"
            (input)="onScrubSlider($event)"
            class="w-full accent-amber-400 cursor-pointer"
          />
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-400">
          <span>0.00s (T0)</span>
          <span class="text-amber-300 font-bold">
            {{ sim.timeMachineScrubIndex() >= 0 ? 'HISTORIC REPLAY' : 'LIVE 100Hz FEED' }}
          </span>
          <span>{{ (sim.livePhysicsState()?.simTimeSec || 0) | number:'1.2-2' }}s</span>
        </div>
      </div>

      <!-- Real-Time Sparkline / Time-Series Visualizers -->
      <div class="flex flex-col gap-4">
        <!-- 1. Velocity & Power Plot -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-bold">
            <span class="text-slate-200">Velocity Profile (km/h)</span>
            <span class="text-cyan-400">{{ (sim.livePhysicsState()?.speedKmh || 0) | number:'1.1-1' }} km/h</span>
          </div>

          <!-- SVG Sparkline of last 60 samples -->
          <svg class="w-full h-16 bg-slate-950 rounded-xl p-1 border border-slate-800/60" viewBox="0 0 300 60">
            <polyline
              fill="none"
              stroke="#38bdf8"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              [attr.points]="speedSparklinePoints()"
            />
          </svg>
        </div>

        <!-- 2. Powertrain Mechanical Power & Regen Plot -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-bold">
            <span class="text-slate-200">Powertrain Output (kW)</span>
            <span class="text-amber-400">{{ (sim.livePhysicsState()?.motorPowerKw || 0) | number:'1.0-0' }} kW</span>
          </div>

          <svg class="w-full h-16 bg-slate-950 rounded-xl p-1 border border-slate-800/60" viewBox="0 0 300 60">
            <polyline
              fill="none"
              stroke="#fbbf24"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              [attr.points]="powerSparklinePoints()"
            />
          </svg>
        </div>

        <!-- 3. Lateral & Longitudinal Acceleration G -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-bold">
            <span class="text-slate-200">G-Force Acceleration Vector</span>
            <span class="text-emerald-400">{{ (sim.livePhysicsState()?.accelG || 0) | number:'1.2-2' }} G</span>
          </div>

          <svg class="w-full h-16 bg-slate-950 rounded-xl p-1 border border-slate-800/60" viewBox="0 0 300 60">
            <polyline
              fill="none"
              stroke="#34d399"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              [attr.points]="gForceSparklinePoints()"
            />
          </svg>
        </div>

        <!-- 4. Thermal Loop Temps -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-bold">
            <span class="text-slate-200">4680 Battery Core Thermal Curve</span>
            <span class="text-rose-400">{{ (sim.livePhysicsState()?.tempBatteryC || 30) | number:'1.1-1' }} °C</span>
          </div>

          <svg class="w-full h-16 bg-slate-950 rounded-xl p-1 border border-slate-800/60" viewBox="0 0 300 60">
            <polyline
              fill="none"
              stroke="#f43f5e"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              [attr.points]="tempSparklinePoints()"
            />
          </svg>
        </div>
      </div>
    </div>
  `,
})
export class TelemetryDashboardComponent {
  public readonly sim = inject(SimulationService);
  public readonly Math = Math;

  public onScrubSlider(e: Event) {
    const val = parseInt((e.target as HTMLInputElement).value, 10);
    this.sim.timeMachineScrubIndex.set(val);
  }

  public speedSparklinePoints = computed(() => {
    const history = this.sim.telemetryHistory();
    if (history.length < 2) return '0,55 300,55';
    const recent = history.slice(-50);
    return recent
      .map((s, idx) => {
        const x = (idx / (recent.length - 1)) * 300;
        const norm = Math.min(1, s.speedKmh / 280);
        const y = 55 - norm * 45;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public powerSparklinePoints = computed(() => {
    const history = this.sim.telemetryHistory();
    if (history.length < 2) return '0,55 300,55';
    const recent = history.slice(-50);
    return recent
      .map((s, idx) => {
        const x = (idx / (recent.length - 1)) * 300;
        const norm = Math.min(1, Math.max(0, s.motorPowerKw / 750));
        const y = 55 - norm * 45;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public gForceSparklinePoints = computed(() => {
    const history = this.sim.telemetryHistory();
    if (history.length < 2) return '0,55 300,55';
    const recent = history.slice(-50);
    return recent
      .map((s, idx) => {
        const x = (idx / (recent.length - 1)) * 300;
        const norm = Math.min(1, Math.abs(s.accelerationG) / 1.5);
        const y = 55 - norm * 45;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public tempSparklinePoints = computed(() => {
    const history = this.sim.telemetryHistory();
    if (history.length < 2) return '0,55 300,55';
    const recent = history.slice(-50);
    return recent
      .map((s, idx) => {
        const x = (idx / (recent.length - 1)) * 300;
        const norm = Math.min(1, Math.max(0, (s.batteryTempC - 20) / 45));
        const y = 55 - norm * 45;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public exportTelemetryJson() {
    const data = JSON.stringify(this.sim.telemetryHistory(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Aureom_${this.sim.selectedVehicle().id}_telemetry_${Date.now()}.simdata`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
