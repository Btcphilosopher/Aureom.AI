import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

@Component({
  selector: 'app-ai-assistant-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col justify-between gap-4 font-sans scrollbar-thin">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-950/50">
            <mat-icon class="text-white text-sm">smart_toy</mat-icon>
          </div>
          <div>
            <h2 class="text-sm font-bold text-white tracking-wide">Gemini 3.8 Engineering AI</h2>
            <p class="text-[10px] text-cyan-400 font-mono">Live Automotive Systems Diagnostics</p>
          </div>
        </div>
      </div>

      <!-- Quick Engineering Query Prompts -->
      <div class="flex items-center gap-1.5 overflow-x-auto py-1 text-[11px] font-mono scrollbar-none">
        <button
          (click)="sendQuickPrompt('Analyze the current aerodynamic drag and Cd·A efficiency at this vehicle speed.')"
          class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-300 hover:text-cyan-300 whitespace-nowrap"
        >
          Aero Cd·A Analysis
        </button>
        <button
          (click)="sendQuickPrompt('Diagnose 4680 cell thermal temperature and check for potential thermal throttling.')"
          class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-300 hover:text-cyan-300 whitespace-nowrap"
        >
          Thermal Health
        </button>
        <button
          (click)="sendQuickPrompt('Evaluate regenerative braking power and energy capture efficiency.')"
          class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-300 hover:text-cyan-300 whitespace-nowrap"
        >
          Regen Capture
        </button>
      </div>

      <!-- Message History List -->
      <div class="flex-1 overflow-y-auto flex flex-col gap-3 pr-1 scrollbar-thin min-h-[220px]">
        @for (msg of sim.aiChatHistory(); track msg.timestamp) {
          <div
            class="p-3.5 rounded-2xl text-xs leading-relaxed flex flex-col gap-1"
            [class.bg-slate-900]="msg.role === 'assistant'"
            [class.border]="msg.role === 'assistant'"
            [class.border-slate-800]="msg.role === 'assistant'"
            [class.text-slate-200]="msg.role === 'assistant'"
            [class.bg-gradient-to-r]="msg.role === 'user'"
            [class.from-cyan-950/80]="msg.role === 'user'"
            [class.to-slate-900]="msg.role === 'user'"
            [class.border-cyan-800/50]="msg.role === 'user'"
            [class.self-end]="msg.role === 'user'"
            [class.text-cyan-100]="msg.role === 'user'"
          >
            <div class="flex items-center gap-1.5 font-mono text-[10px]" [class.text-cyan-400]="msg.role === 'assistant'" [class.text-slate-400]="msg.role === 'user'">
              <mat-icon class="text-xs">{{ msg.role === 'assistant' ? 'smart_toy' : 'person' }}</mat-icon>
              <span>{{ msg.role === 'assistant' ? 'AI Systems Engineer' : 'You' }}</span>
            </div>
            <div class="whitespace-pre-wrap">{{ msg.text }}</div>
          </div>
        }

        @if (sim.isAiThinking()) {
          <div class="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-cyan-400 font-mono flex items-center gap-2">
            <mat-icon class="animate-spin text-sm">rotate_right</mat-icon>
            <span>Analyzing multi-physics telemetry streams...</span>
          </div>
        }
      </div>

      <!-- Input Bar -->
      <div class="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
        <input
          #promptInput
          type="text"
          placeholder="Ask engineering question..."
          (keydown.enter)="submitPrompt(promptInput)"
          class="flex-1 bg-transparent px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
        />
        <button
          (click)="submitPrompt(promptInput)"
          class="w-8 h-8 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center transition-all shadow-md"
        >
          <mat-icon class="text-sm">send</mat-icon>
        </button>
      </div>
    </div>
  `,
})
export class AiAssistantModalComponent {
  public readonly sim = inject(SimulationService);

  public submitPrompt(input: HTMLInputElement) {
    const text = input.value.trim();
    if (!text) return;
    this.sim.askAiAssistant(text);
    input.value = '';
  }

  public sendQuickPrompt(prompt: string) {
    this.sim.askAiAssistant(prompt);
  }
}
