import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

@Component({
  selector: 'app-configurator-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col gap-6 font-sans scrollbar-thin">
      <!-- Vehicle Header Summary -->
      <div class="flex flex-col gap-1 border-b border-slate-800/80 pb-4">
        <div class="flex items-center justify-between">
          <span class="text-xs font-mono text-cyan-400 tracking-wider uppercase">{{ sim.selectedVehicle().series }} Series</span>
          <span class="px-2 py-0.5 text-[11px] font-mono font-bold bg-slate-900 border border-slate-700 text-slate-300 rounded">
            EST. \${{ sim.selectedTrim().priceSyntheticUsd | number }}
          </span>
        </div>
        <h2 class="text-2xl font-black text-white tracking-tight">{{ sim.selectedVehicle().name }}</h2>
        <p class="text-xs text-slate-400 leading-relaxed">{{ sim.selectedVehicle().tagline }}</p>
      </div>

      <!-- 1. Powertrain & Performance Trims -->
      <div class="flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">1. Select Powertrain Trim</span>
          <span class="text-[11px] text-slate-400">{{ sim.selectedVehicle().trims.length }} Configurations</span>
        </div>

        <div class="grid grid-cols-1 gap-2.5">
          @for (trim of sim.selectedVehicle().trims; track trim.id) {
            <button
              type="button"
              (click)="sim.selectTrim(trim)"
              class="w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col gap-2 relative overflow-hidden"
              [class.bg-slate-900]="sim.selectedTrim().id === trim.id"
              [class.border-cyan-500]="sim.selectedTrim().id === trim.id"
              [class.shadow-lg]="sim.selectedTrim().id === trim.id"
              [class.shadow-cyan-950/40]="sim.selectedTrim().id === trim.id"
              [class.bg-slate-950]="sim.selectedTrim().id !== trim.id"
              [class.border-slate-800]="sim.selectedTrim().id !== trim.id"
              [class.hover:border-slate-700]="sim.selectedTrim().id !== trim.id"
            >
              @if (sim.selectedTrim().id === trim.id) {
                <div class="absolute top-0 right-0 w-2 h-full bg-cyan-400"></div>
              }

              <div class="flex items-center justify-between">
                <div>
                  <div class="font-bold text-sm text-white">{{ trim.name }}</div>
                  <div class="text-[11px] text-slate-400 font-mono">{{ trim.subTitle }}</div>
                </div>
                <div class="text-right font-mono">
                  <div class="text-xs font-bold text-cyan-400">\${{ trim.priceSyntheticUsd | number }}</div>
                  <div class="text-[10px] text-slate-400">{{ trim.driveType }}</div>
                </div>
              </div>

              <!-- Key Specs Grid -->
              <div class="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-center font-mono">
                <div class="bg-slate-950/60 p-1.5 rounded-lg border border-slate-800/60">
                  <div class="text-[10px] text-slate-400">0–60 MPH</div>
                  <div class="text-xs font-bold text-amber-300">{{ trim.acceleration0to60Sec }}s</div>
                </div>
                <div class="bg-slate-950/60 p-1.5 rounded-lg border border-slate-800/60">
                  <div class="text-[10px] text-slate-400">TOP SPEED</div>
                  <div class="text-xs font-bold text-slate-200">{{ trim.topSpeedKmh }} km/h</div>
                </div>
                <div class="bg-slate-950/60 p-1.5 rounded-lg border border-slate-800/60">
                  <div class="text-[10px] text-slate-400">EST. RANGE</div>
                  <div class="text-xs font-bold text-emerald-300">{{ trim.estimatedRangeKm }} km</div>
                </div>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- 2. Paint & Exterior Finishes -->
      <div class="flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">2. Exterior Paint</span>
          <span class="text-xs font-medium text-cyan-400">{{ sim.selectedColor().name }}</span>
        </div>

        <div class="flex items-center gap-3 overflow-x-auto py-2">
          @for (c of sim.selectedVehicle().colors; track c.id) {
            <button
              type="button"
              (click)="sim.selectColor(c)"
              class="w-10 h-10 rounded-full border-2 transition-all transform hover:scale-110 flex items-center justify-center relative shadow-md"
              [style.background-color]="c.hex"
              [class.border-cyan-400]="sim.selectedColor().id === c.id"
              [class.ring-2]="sim.selectedColor().id === c.id"
              [class.ring-cyan-500/40]="sim.selectedColor().id === c.id"
              [class.border-slate-700]="sim.selectedColor().id !== c.id"
              [title]="c.name + ' (+$' + c.extraCostUsd + ')'"
            >
              @if (sim.selectedColor().id === c.id) {
                <mat-icon class="text-white text-xs drop-shadow-md">check</mat-icon>
              }
            </button>
          }
        </div>
      </div>

      <!-- 3. Wheels & Aerodynamics -->
      <div class="flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">3. Wheels & Aero Packages</span>
          <span class="text-xs font-medium text-slate-400">{{ sim.selectedWheel().name }}</span>
        </div>

        <div class="grid grid-cols-1 gap-2">
          @for (w of sim.selectedVehicle().wheels; track w.id) {
            <button
              type="button"
              (click)="sim.selectWheel(w)"
              class="w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between"
              [class.bg-slate-900]="sim.selectedWheel().id === w.id"
              [class.border-cyan-500]="sim.selectedWheel().id === w.id"
              [class.border-slate-800]="sim.selectedWheel().id !== w.id"
            >
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full border border-slate-700 flex items-center justify-center bg-slate-950">
                  <mat-icon class="text-sm text-slate-400">tire_repair</mat-icon>
                </div>
                <div>
                  <div class="text-xs font-bold text-white">{{ w.name }}</div>
                  <div class="text-[10px] text-slate-400 font-mono">
                    Aero Efficiency: {{ w.aeroBonusRangePercent > 0 ? '+' : '' }}{{ w.aeroBonusRangePercent }}% Range
                  </div>
                </div>
              </div>
              <div class="text-xs font-mono text-cyan-400">
                {{ w.extraCostUsd > 0 ? '+$' + (w.extraCostUsd | number) : 'Included' }}
              </div>
            </button>
          }
        </div>
      </div>

      <!-- 4. Premium Interior Options -->
      <div class="flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">4. Interior Décor & Seating</span>
        </div>

        <div class="grid grid-cols-1 gap-2">
          @for (int of sim.selectedVehicle().interiors; track int.id) {
            <button
              type="button"
              (click)="sim.selectInterior(int)"
              class="w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between"
              [class.bg-slate-900]="sim.selectedInterior().id === int.id"
              [class.border-cyan-500]="sim.selectedInterior().id === int.id"
              [class.border-slate-800]="sim.selectedInterior().id !== int.id"
            >
              <div class="flex items-center gap-3">
                <div class="w-6 h-6 rounded-full border border-slate-600 shadow-inner" [style.background-color]="int.seatColorHex"></div>
                <div>
                  <div class="text-xs font-bold text-white">{{ int.name }}</div>
                  <div class="text-[10px] text-slate-400 uppercase font-mono">Trim: {{ int.woodOrCarbon }} | Steering: {{ int.steeringType }}</div>
                </div>
              </div>
              <div class="text-xs font-mono text-cyan-400">Included</div>
            </button>
          }
        </div>
      </div>

      <!-- Hardware & Engineering Package Features -->
      <div class="flex flex-col gap-2 p-3.5 bg-slate-900/80 rounded-xl border border-slate-800">
        <span class="text-[11px] font-bold text-slate-300 uppercase font-mono">Engineering Capabilities</span>
        <ul class="text-xs text-slate-400 flex flex-col gap-1.5 list-disc pl-4">
          @for (feat of sim.selectedVehicle().specialFeatures; track feat) {
            <li>{{ feat }}</li>
          }
        </ul>
      </div>
    </div>
  `,
})
export class ConfiguratorPanelComponent {
  public readonly sim = inject(SimulationService);
}
