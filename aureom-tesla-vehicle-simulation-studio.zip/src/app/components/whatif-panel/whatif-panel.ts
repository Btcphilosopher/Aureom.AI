import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../services/simulation.service';

@Component({
  selector: 'app-whatif-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto bg-slate-950/95 border-l border-slate-800/80 p-5 text-slate-100 flex flex-col gap-6 font-sans scrollbar-thin">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-4">
        <div>
          <h2 class="text-xl font-black text-white tracking-tight flex items-center gap-2">
            <mat-icon class="text-cyan-400">tune</mat-icon>
            What-If Parameter Sweeps
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">Synthetic multi-physics sensitivity analysis</p>
        </div>
      </div>

      <!-- Parameter Sliders -->
      <div class="flex flex-col gap-5">
        <!-- 1. Mass Delta (Curb Weight) -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="font-bold text-slate-200">Chassis Mass Variation (Δ kg)</span>
            <span class="font-bold text-cyan-400">{{ deltaMass() > 0 ? '+' : '' }}{{ deltaMass() }} kg</span>
          </div>
          <input
            type="range"
            min="-300"
            max="400"
            step="10"
            [value]="deltaMass()"
            (input)="deltaMass.set(parseSlider($event))"
            class="w-full accent-cyan-400 cursor-pointer"
          />
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>-300 kg (Carbon Fiber Diet)</span>
            <span>+400 kg (Full Payload/Armor)</span>
          </div>
        </div>

        <!-- 2. Aerodynamic Drag Coefficient Delta -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="font-bold text-slate-200">Aero Drag Cd Delta</span>
            <span class="font-bold text-amber-400">{{ deltaCd() > 0 ? '+' : '' }}{{ deltaCd() | number:'1.2-2' }}</span>
          </div>
          <input
            type="range"
            min="-0.06"
            max="0.10"
            step="0.01"
            [value]="deltaCd()"
            (input)="deltaCd.set(parseSlider($event))"
            class="w-full accent-amber-400 cursor-pointer"
          />
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>-0.06 (Aero wheel covers)</span>
            <span>+0.10 (Roof rack / Trailer)</span>
          </div>
        </div>

        <!-- 3. Tyre Friction Coefficient mu -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="font-bold text-slate-200">Tyre Compound Grip (μ Delta)</span>
            <span class="font-bold text-emerald-400">{{ deltaGrip() > 0 ? '+' : '' }}{{ deltaGrip() | number:'1.2-2' }}</span>
          </div>
          <input
            type="range"
            min="-0.4"
            max="0.4"
            step="0.05"
            [value]="deltaGrip()"
            (input)="deltaGrip.set(parseSlider($event))"
            class="w-full accent-emerald-400 cursor-pointer"
          />
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>-0.4 (Wet/Worn Tyres)</span>
            <span>+0.4 (Cup 2 Racing Slicks)</span>
          </div>
        </div>

        <!-- 4. Ambient Temperature (Thermal Loop Impact) -->
        <div class="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="font-bold text-slate-200">Ambient Temperature</span>
            <span class="font-bold text-rose-400">{{ ambientTemp() }} °C</span>
          </div>
          <input
            type="range"
            min="-20"
            max="50"
            step="1"
            [value]="ambientTemp()"
            (input)="ambientTemp.set(parseSlider($event))"
            class="w-full accent-rose-400 cursor-pointer"
          />
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>-20 °C (Sub-Zero Winter)</span>
            <span>+50 °C (Death Valley Heat)</span>
          </div>
        </div>
      </div>

      <!-- Dynamic Predicted Performance Delta Cards -->
      <div class="p-4 bg-gradient-to-br from-slate-900 to-slate-950 rounded-2xl border border-cyan-500/40 flex flex-col gap-3 shadow-xl">
        <span class="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
          <mat-icon class="text-cyan-400 text-sm">auto_graph</mat-icon>
          Predicted Engineering Impact
        </span>

        <div class="grid grid-cols-2 gap-2 text-xs font-mono">
          <div class="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <div class="text-[10px] text-slate-400">0–60 MPH TIME</div>
            <div class="text-sm font-bold text-amber-300">
              {{ predicted0to60() | number:'1.2-2' }}s
              <span class="text-[10px] text-slate-400">({{ (predicted0to60() - sim.selectedTrim().acceleration0to60Sec) > 0 ? '+' : '' }}{{ (predicted0to60() - sim.selectedTrim().acceleration0to60Sec) | number:'1.2-2' }}s)</span>
            </div>
          </div>

          <div class="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <div class="text-[10px] text-slate-400">ESTIMATED RANGE</div>
            <div class="text-sm font-bold text-emerald-300">
              {{ predictedRange() | number:'1.0-0' }} km
              <span class="text-[10px] text-slate-400">({{ (predictedRange() - sim.selectedTrim().estimatedRangeKm) > 0 ? '+' : '' }}{{ (predictedRange() - sim.selectedTrim().estimatedRangeKm) | number:'1.0-0' }} km)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class WhatIfPanelComponent {
  public readonly sim = inject(SimulationService);

  public readonly deltaMass = signal<number>(0);
  public readonly deltaCd = signal<number>(0);
  public readonly deltaGrip = signal<number>(0);
  public readonly ambientTemp = signal<number>(22);

  public parseSlider(e: Event): number {
    return parseFloat((e.target as HTMLInputElement).value);
  }

  public predicted0to60 = computed(() => {
    const base = this.sim.selectedTrim().acceleration0to60Sec;
    const baseWeight = this.sim.selectedVehicle().dimensions.curbWeightKg * this.sim.selectedTrim().massMultiplier;
    const massFactor = (this.deltaMass() / (baseWeight || 2000)) * 1.2;
    const gripFactor = -this.deltaGrip() * 0.45;
    return Math.max(1.1, base + massFactor + gripFactor);
  });

  public predictedRange = computed(() => {
    const base = this.sim.selectedTrim().estimatedRangeKm;
    const baseWeight = this.sim.selectedVehicle().dimensions.curbWeightKg * this.sim.selectedTrim().massMultiplier;
    const massLoss = (this.deltaMass() / (baseWeight || 2000)) * 0.4 * base;
    const aeroLoss = (this.deltaCd() / this.sim.selectedVehicle().dimensions.dragCoefficientCd) * 0.6 * base;
    const tempLoss = this.ambientTemp() < 10 ? (10 - this.ambientTemp()) * 2.5 : 0;
    return Math.max(80, base - massLoss - aeroLoss - tempLoss);
  });
}
