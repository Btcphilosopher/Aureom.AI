import { SimulationScenario } from '../types/vehicle.types';

export const SIMULATION_SCENARIOS: SimulationScenario[] = [
  {
    id: 'launch-0-60',
    title: 'Scenario 01: 0–60 MPH Max Acceleration Launch',
    category: 'Performance',
    description:
      'Tests full battery power discharge, dual/tri-motor torque response, inverter peak switching, tyre slip ratio grip circle, and squat dynamics.',
    recommendedVehicle: 'model-s',
    environment: 'test-track',
    weather: 'clear',
    initialSpeedKmh: 0,
    durationSec: 10,
    targetObjective: 'Achieve sub-3.0s 0-60 mph sprint while logging longitudinal G-force and battery current draw.',
    autoScript: (timeSec: number) => {
      if (timeSec < 0.5) return { throttle: 0, brake: 1, steer: 0 };
      if (timeSec < 8.0) return { throttle: 1.0, brake: 0, steer: 0 };
      return { throttle: 0, brake: 0.8, steer: 0 };
    },
  },
  {
    id: 'emergency-brake-60-0',
    title: 'Scenario 02: 60–0 MPH Emergency Braking & ABS',
    category: 'Safety',
    description:
      'Evaluates blended regenerative braking, front-to-rear hydraulic bias, brake disc thermal dissipation, and suspension anti-dive geometry.',
    recommendedVehicle: 'model-3',
    environment: 'test-track',
    weather: 'clear',
    initialSpeedKmh: 96.5,
    durationSec: 8,
    targetObjective: 'Measure stopping distance and brake rotor heating from 60 mph to complete standstill.',
    autoScript: (timeSec: number) => {
      if (timeSec < 1.0) return { throttle: 0, brake: 0, steer: 0 };
      return { throttle: 0, brake: 1.0, steer: 0 };
    },
  },
  {
    id: 'wet-skidpad-cornering',
    title: 'Scenario 03: Wet-Road Skidpad Lateral Grip & ESC',
    category: 'Handling',
    description:
      'Simulates reduced friction surface (μ = 0.55), yaw moment control, electronic stability program torque vectoring, and lateral tyre slip angle.',
    recommendedVehicle: 'model-y',
    environment: 'test-track',
    weather: 'rain',
    initialSpeedKmh: 40,
    durationSec: 15,
    targetObjective: 'Maintain circular radius trajectory on wet track without exceeding critical spin-out yaw rate.',
    autoScript: (timeSec: number) => {
      const steer = Math.sin(timeSec * 0.4) * 0.35 + 0.2;
      return { throttle: 0.45, brake: 0, steer };
    },
  },
  {
    id: 'v4-supercharging-curve',
    title: 'Scenario 04: V4 Supercharger Fast Charging (10% → 80%)',
    category: 'Charging',
    description:
      'Simulates high-power 250kW-350kW DC fast charging, battery preconditioning to 45°C, Joule heating, Octovalve cooling loop, and CC-CV tapering.',
    recommendedVehicle: 'cybertruck',
    environment: 'supercharger',
    weather: 'clear',
    initialSpeedKmh: 0,
    durationSec: 25,
    targetObjective: 'Observe 800V architecture rapid charge session and active thermal management response.',
    autoScript: () => ({ throttle: 0, brake: 1, steer: 0 }),
  },
  {
    id: 'mountain-regen-descent',
    title: 'Scenario 05: Mountain Descent & High-Regen Harvesting',
    category: 'Efficiency',
    description:
      'Simulates steep 8% downhill grade, one-pedal drive regenerative braking recapture, motor generator mode, and pack SOC replenishment.',
    recommendedVehicle: 'model-y',
    environment: 'mountain',
    weather: 'clear',
    initialSpeedKmh: 70,
    durationSec: 20,
    targetObjective: 'Harvest kinetic energy into battery with negative motor power kW and zero friction pad wear.',
    autoScript: (timeSec: number) => {
      const steer = Math.sin(timeSec * 0.8) * 0.25;
      return { throttle: 0.1, brake: 0.35, steer };
    },
  },
  {
    id: 'thermal-stress-track-lap',
    title: 'Scenario 06: High-Load Thermal Stress & Derating Lap',
    category: 'Stress',
    description:
      'Sustained continuous maximum power draw on racetrack to evaluate battery cell temperature rise, stator heating, and cooling capacity headroom.',
    recommendedVehicle: 'roadster',
    environment: 'test-track',
    weather: 'clear',
    initialSpeedKmh: 60,
    durationSec: 20,
    targetObjective: 'Analyze thermal throttling margins under repetitive high-torque corner exits.',
    autoScript: (timeSec: number) => {
      const steer = Math.sin(timeSec * 0.6) * 0.4;
      const throttle = 0.6 + Math.cos(timeSec * 0.3) * 0.4;
      return { throttle, brake: (timeSec % 4 > 3) ? 0.6 : 0, steer };
    },
  },
  {
    id: 'highway-aero-cruise',
    title: 'Scenario 07: 75 MPH Highway Aerodynamic Cruise',
    category: 'Efficiency',
    description:
      'Measures aerodynamic drag force vs rolling resistance at steady 120 km/h (75 mph) velocity. Calculates Wh/km efficiency.',
    recommendedVehicle: 'model-3',
    environment: 'city',
    weather: 'clear',
    initialSpeedKmh: 120,
    durationSec: 15,
    targetObjective: 'Demonstrate ultra-low Cd (0.219) contribution to long-distance EV range efficiency.',
    autoScript: () => ({ throttle: 0.22, brake: 0, steer: 0 }),
  },
  {
    id: 'urban-robotaxi-stop-go',
    title: 'Scenario 08: Urban Autonomous Stop & Go Traffic',
    category: 'Autonomous',
    description:
      'Autonomous passenger dispatch cycle: smooth acceleration, intersection creep, pedestrian avoidance deceleration, and soft stopping.',
    recommendedVehicle: 'cybercab',
    environment: 'city',
    weather: 'clear',
    initialSpeedKmh: 0,
    durationSec: 18,
    targetObjective: 'Smooth G-force envelope with passenger jerk minimization (dG/dt < 0.2g/s).',
    autoScript: (timeSec: number) => {
      const cycle = timeSec % 6;
      if (cycle < 2.5) return { throttle: 0.35, brake: 0, steer: Math.sin(timeSec) * 0.1 };
      if (cycle < 4.0) return { throttle: 0, brake: 0.4, steer: 0 };
      return { throttle: 0, brake: 1.0, steer: 0 };
    },
  },
  {
    id: 'heavy-semi-haulage',
    title: 'Scenario 09: 82,000 lb Heavy Freight Highway Grade',
    category: 'Commercial',
    description:
      'Class-8 electric tractor high-torque grade climbing. Evaluates tri-motor load balancing, high-voltage bus thermal dissipation, and torque distribution.',
    recommendedVehicle: 'semi',
    environment: 'mountain',
    weather: 'clear',
    initialSpeedKmh: 65,
    durationSec: 20,
    targetObjective: 'Maintain 65 mph on a 5% continuous highway grade under 82k lb gross combined weight.',
    autoScript: () => ({ throttle: 0.85, brake: 0, steer: 0.05 }),
  },
  {
    id: 'winter-cold-soak',
    title: 'Scenario 10: Sub-Zero Winter Cold Soak & Heating',
    category: 'Stress',
    description:
      'Simulates -10°C ambient temperature, initial battery internal resistance increase, Heat Pump Octovalve COP scavenging, and regenerative braking cold restriction.',
    recommendedVehicle: 'model-y',
    environment: 'test-track',
    weather: 'snow',
    initialSpeedKmh: 30,
    durationSec: 15,
    targetObjective: 'Measure cabin warm-up rate and battery warm-up energy consumption in sub-zero climate.',
    autoScript: (timeSec: number) => ({ throttle: 0.3, brake: (timeSec % 5 > 4) ? 0.3 : 0, steer: 0 }),
  },
];
