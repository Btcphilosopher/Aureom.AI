export type VehicleModelId =
  | 'model-3'
  | 'model-y'
  | 'model-s'
  | 'model-x'
  | 'cybertruck'
  | 'semi'
  | 'roadster'
  | 'cybercab'
  | 'robovan';

export type ViewMode =
  | 'studio'
  | 'configurator'
  | 'physics-sim'
  | 'cockpit'
  | 'cutaway'
  | 'exploded'
  | 'energy-flow'
  | 'charging'
  | 'thermal'
  | 'assembly'
  | 'telemetry'
  | 'scenarios'
  | 'what-if'
  | 'ai-assistant';

export type EnvironmentId =
  | 'studio'
  | 'city'
  | 'test-track'
  | 'mountain'
  | 'supercharger'
  | 'factory';

export type WeatherType = 'clear' | 'rain' | 'snow' | 'fog';

export type DriveMode = 'chill' | 'sport' | 'plaid' | 'insane' | 'track' | 'offroad';

export type Gear = 'P' | 'R' | 'N' | 'D';

export type ChargingState =
  | 'DISCONNECTED'
  | 'CONNECTING'
  | 'NEGOTIATING'
  | 'PRECONDITIONING'
  | 'CHARGING'
  | 'THROTTLING'
  | 'COMPLETE'
  | 'FAULT';

export interface VehicleDimensions {
  lengthMm: number;
  widthMm: number;
  heightMm: number;
  wheelbaseMm: number;
  trackFrontMm: number;
  trackRearMm: number;
  groundClearanceMm: number;
  curbWeightKg: number;
  weightDistributionFrontRear: [number, number]; // e.g. [0.49, 0.51]
  frontalAreaM2: number;
  dragCoefficientCd: number;
  liftCoefficientCl: number;
}

export interface MotorSpec {
  id: string;
  name: string;
  type: 'PM_SYNCRM' | 'INDUCTION' | 'CARBON_SLEEVED_PM';
  location: 'FRONT' | 'REAR_LEFT' | 'REAR_RIGHT' | 'REAR_AXLE' | 'MID_AXLE';
  peakPowerKw: number;
  peakTorqueNm: number;
  maxRpm: number;
  gearRatio: number;
  efficiency: number;
}

export interface BatterySpec {
  chemistry: 'NMC_4680' | 'NCA_2170' | 'LFP_PRISMATIC' | 'SOLID_STATE_SYNTHETIC';
  packCapacityKwh: number;
  usableCapacityKwh: number;
  nominalVoltageV: number;
  maxDischargeCurrentA: number;
  maxChargeRateKw: number;
  internalResistanceOhm: number;
  thermalMassJoulePerK: number;
  coolingCapacityKw: number;
}

export interface SuspensionSpec {
  typeFront: 'DOUBLE_WISHBONE' | 'MACPHERSON' | 'AIR_ADAPTIVE';
  typeRear: 'MULTI_LINK' | 'AIR_ADAPTIVE';
  springRateFrontNPerM: number;
  springRateRearNPerM: number;
  dampingFrontNsPerM: number;
  dampingRearNsPerM: number;
  antiRollBarFrontRate: number;
  antiRollBarRearRate: number;
  maxTravelMm: number;
}

export interface TyreSpec {
  sizeFront: string;
  sizeRear: string;
  diameterMm: number;
  widthMm: number;
  pressureBar: number;
  baseFrictionMu: number;
  corneringStiffnessNPerRad: number;
}

export interface TrimOption {
  id: string;
  name: string;
  subTitle: string;
  driveType: 'RWD' | 'AWD' | 'TRI_MOTOR' | 'QUAD_MOTOR';
  motors: MotorSpec[];
  battery: BatterySpec;
  acceleration0to60Sec: number;
  acceleration0to100KmhSec: number;
  topSpeedKmh: number;
  estimatedRangeKm: number;
  priceSyntheticUsd: number;
  massMultiplier: number;
}

export interface ColorOption {
  id: string;
  name: string;
  hex: string;
  metallic: number;
  roughness: number;
  clearcoat: number;
  extraCostUsd: number;
}

export interface WheelOption {
  id: string;
  name: string;
  diameterInch: number;
  aeroBonusRangePercent: number;
  colorHex: string;
  extraCostUsd: number;
}

export interface InteriorOption {
  id: string;
  name: string;
  seatColorHex: string;
  dashColorHex: string;
  woodOrCarbon: 'wood' | 'carbon' | 'white' | 'slate';
  steeringType: 'round' | 'yoke';
}

export interface VehicleDefinition {
  id: VehicleModelId;
  name: string;
  series: 'Passenger' | 'Commercial' | 'Performance' | 'Autonomous';
  tagline: string;
  description: string;
  dimensions: VehicleDimensions;
  suspension: SuspensionSpec;
  tyres: TyreSpec;
  trims: TrimOption[];
  colors: ColorOption[];
  wheels: WheelOption[];
  interiors: InteriorOption[];
  specialFeatures: string[];
  doorConfig: 'STANDARD_4' | 'FALCON_WING_REAR' | 'BUTTERFLY_2' | 'SLIDING_POD' | 'CYBER_ANGULAR';
}

export interface MechanismRigState {
  doorFrontLeft: number; // 0 to 1
  doorFrontRight: number;
  doorRearLeft: number;
  doorRearRight: number;
  falconWingLeftStage1: number;
  falconWingLeftStage2: number;
  falconWingRightStage1: number;
  falconWingRightStage2: number;
  windowFrontLeft: number;
  windowFrontRight: number;
  windowRearLeft: number;
  windowRearRight: number;
  frunk: number;
  trunk: number;
  tonneauCover: number; // For Cybertruck 0 = closed, 1 = open
  tailgate: number;
  mirrorsFolded: boolean;
  targaRoofOff: boolean;
  headlightsOn: boolean;
  highBeamsOn: boolean;
  fogLightsOn: boolean;
  drlOn: boolean;
  indicatorLeft: boolean;
  indicatorRight: boolean;
  hazardLights: boolean;
  brakeLightsOn: boolean;
  reverseLightsOn: boolean;
  cabinAmbientColor: string;
  chargePortOpen: boolean;
  chargeCableConnected: boolean;
  activeSpoilerAngleDeg: number;
}

export interface LiveTelemetrySample {
  timestampMs: number;
  simTimeSec: number;
  speedKmh: number;
  speedMph: number;
  accelerationG: number;
  lateralG: number;
  yawRateDeg: number;
  headingDeg: number;
  steeringAngleDeg: number;
  throttlePercent: number;
  brakePercent: number;
  regenPowerKw: number;
  motorPowerKw: number;
  totalEnergyUsedKwh: number;
  energyConsumptionWhPerKm: number;
  batterySocPercent: number;
  batteryVoltageV: number;
  batteryCurrentA: number;
  batteryTempC: number;
  motorTempFrontC: number;
  motorTempRearC: number;
  inverterTempC: number;
  brakeDiscsTempC: number;
  cabinTempC: number;
  suspensionTravelMm: [number, number, number, number]; // FL, FR, RL, RR
  wheelSlipRatio: [number, number, number, number];
  wheelSpeedRpm: [number, number, number, number];
  tyreLoadN: [number, number, number, number];
  pitchDeg: number;
  rollDeg: number;
  altitudeM: number;
}

export interface SimulationScenario {
  id: string;
  title: string;
  category: 'Performance' | 'Handling' | 'Efficiency' | 'Charging' | 'Stress' | 'Safety' | 'Autonomous' | 'Commercial';
  description: string;
  recommendedVehicle: VehicleModelId;
  environment: EnvironmentId;
  weather: WeatherType;
  initialSpeedKmh: number;
  durationSec: number;
  targetObjective: string;
  objectives?: string[];
  autoScript?: (timeSec: number, state?: unknown) => { throttle?: number; brake?: number; steer?: number };
}
