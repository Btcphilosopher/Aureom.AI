import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AppHeaderComponent } from './components/header/app-header';
import { SimulationViewportComponent } from './components/viewport/simulation-viewport';
import { CockpitOverlayComponent } from './components/cockpit/cockpit-overlay';
import { ConfiguratorPanelComponent } from './components/configurator-panel/configurator-panel';
import { EngineeringPanelComponent } from './components/engineering-panel/engineering-panel';
import { TelemetryDashboardComponent } from './components/telemetry-dashboard/telemetry-dashboard';
import { ScenarioPanelComponent } from './components/scenario-panel/scenario-panel';
import { WhatIfPanelComponent } from './components/whatif-panel/whatif-panel';
import { ManufacturingPanelComponent } from './components/manufacturing-panel/manufacturing-panel';
import { AiAssistantModalComponent } from './components/ai-assistant-modal/ai-assistant-modal';
import { SimulationService } from './services/simulation.service';
import { ViewMode } from './core/types/vehicle.types';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    AppHeaderComponent,
    SimulationViewportComponent,
    CockpitOverlayComponent,
    ConfiguratorPanelComponent,
    EngineeringPanelComponent,
    TelemetryDashboardComponent,
    ScenarioPanelComponent,
    WhatIfPanelComponent,
    ManufacturingPanelComponent,
    AiAssistantModalComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public readonly sim = inject(SimulationService);
  public readonly isSidebarOpen = signal<boolean>(true);

  public toggleSidebar() {
    this.isSidebarOpen.update((v) => !v);
  }

  public setSideTab(mode: ViewMode) {
    this.sim.setViewMode(mode);
    this.isSidebarOpen.set(true);
  }
}

