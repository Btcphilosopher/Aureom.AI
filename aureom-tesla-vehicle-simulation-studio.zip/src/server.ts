import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Lazy Gemini AI initialization for AI Engineering Assistant
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

/**
 * AI Engineering Assistant API endpoint
 */
app.post('/api/ai/analyze-vehicle', async (req, res) => {
  try {
    const { prompt, vehicleState, telemetryData } = req.body;

    const ai = getGenAI();
    if (!ai) {
      // Deterministic synthetic fallback if API key is not configured
      const responseText = generateSyntheticEngineeringAnalysis(prompt, vehicleState);
      return res.json({
        success: true,
        source: 'synthetic-engineering-engine',
        analysis: responseText,
      });
    }

    const systemPrompt = `You are the Principal Automotive Simulation & Telemetry Engineer for the Aureom Tesla Vehicle Simulation Studio.
You provide deep, mathematically grounded vehicle dynamics, thermal, battery, aerodynamics, and powertrain engineering insights.
Analyze the user query based on the supplied vehicle state, specifications, and telemetry data.
Keep your response professional, insightful, concise, and structured with clear engineering terminology (e.g. slip angle, weight transfer, Cd*A, regenerative torque limit, C-rate, thermal throttling).
Do not claim to have proprietary internal Tesla confidential data; clarify that calculations reflect theoretical multi-body physics and observed synthetic parameters.`;

    const contextSummary = `Vehicle Context:
- Model: ${vehicleState?.name || 'Tesla Model 3 Performance'}
- Speed: ${vehicleState?.speedKmh?.toFixed(1) || '0'} km/h
- Acceleration: ${vehicleState?.accelG?.toFixed(2) || '0'} g
- Battery SOC: ${vehicleState?.batterySoc?.toFixed(1) || '80'}%
- Battery Temp: ${vehicleState?.batteryTempC?.toFixed(1) || '32'} °C
- Motor Power: ${vehicleState?.motorPowerKw?.toFixed(1) || '0'} kW
- Regen Power: ${vehicleState?.regenPowerKw?.toFixed(1) || '0'} kW
- Tyre Slip Front/Rear: ${vehicleState?.slipFront?.toFixed(3) || '0.02'} / ${vehicleState?.slipRear?.toFixed(3) || '0.01'}
- Lateral G: ${vehicleState?.lateralG?.toFixed(2) || '0'} g
- Yaw Rate: ${vehicleState?.yawRateDeg?.toFixed(1) || '0'} deg/s
- Ambient Temp: ${vehicleState?.ambientTempC || '20'} °C
- Surface Condition: ${vehicleState?.surfaceFriction || 'Dry Asphalt (mu=0.98)'}
- Energy Consumption: ${telemetryData?.energyConsumptionWhPerKm?.toFixed(1) || '148'} Wh/km`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `${contextSummary}\n\nUser Question: ${prompt || 'Perform full vehicle dynamics and energy efficiency diagnostic.'}`,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.4,
      },
    });

    return res.json({
      success: true,
      source: 'gemini-3.8-flash',
      analysis: response.text || 'Analysis completed.',
    });
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : 'Failed to complete vehicle analysis';
    console.error('AI analysis error:', errMessage);
    return res.status(500).json({
      success: false,
      error: errMessage,
      fallback: generateSyntheticEngineeringAnalysis(req.body?.prompt, req.body?.vehicleState),
    });
  }
});

function generateSyntheticEngineeringAnalysis(prompt?: string, state?: Record<string, number>): string {
  const speed = state?.['speedKmh'] || 0;
  const power = state?.['motorPowerKw'] || 0;
  const temp = state?.['batteryTempC'] || 32;
  const soc = state?.['batterySoc'] || 80;

  return `### Engineering Diagnostics & Simulation Analysis
- **Kinematics & Traction**: Operating at ${speed.toFixed(1)} km/h with balanced longitudinal tyre slip (${(state?.['slipFront'] || 0.02).toFixed(3)} front / ${(state?.['slipRear'] || 0.015).toFixed(3)} rear). Dual-motor torque vectoring maintains neutral yaw rate without adverse understeer.
- **Powertrain & Inverter Efficiency**: Total electrical draw at ${power.toFixed(1)} kW (~${(power * 1.341).toFixed(0)} hp). Inverter switching efficiency estimated at 97.4% utilizing SiC MOSFET power stages.
- **Battery Pack & Thermal State**: State of Charge is at ${soc.toFixed(1)}% with pack core temperature at ${temp.toFixed(1)}°C. Octovalve manifold active loop maintains coolant flow within optimal window (28°C - 38°C).
- **Aerodynamic Drag**: Projected Cd·A drag power increases with the cube of velocity $P_{drag} = 0.5 \\rho C_d A v^3$, accounting for ~64% of total energy consumption at highway velocities.`;
}

/**
 * Health check & telemetry ping
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    system: 'AUREOM TESLA VEHICLE SIMULATION STUDIO',
    version: '3.7.0-PROD',
    physicsRateHz: 120,
    renderTargetFps: 60,
    timestamp: new Date().toISOString(),
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
