package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.BrowserTab
import com.example.data.model.SearchEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("清简浏览器", appName)
    }

    @Test
    fun `test browser tab model creation and defaults`() {
        val tab = BrowserTab(
            url = "https://www.zhihu.com",
            title = "知乎"
        )
        assertEquals("https://www.zhihu.com", tab.url)
        assertEquals("知乎", tab.title)
        assertEquals(false, tab.isPinned)
        assertEquals(false, tab.isSuspended)
        assertNotNull(tab.id)
    }

    @Test
    fun `test search engine query builder`() {
        val engine = SearchEngine(
            id = "baidu",
            name = "百度",
            searchUrl = "https://www.baidu.com/s?wd={q}"
        )
        val url = engine.buildSearchUrl("人工智能")
        assertTrue(url.contains("https://www.baidu.com/s?wd="))
    }
}
