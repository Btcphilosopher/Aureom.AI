package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.model.Bookmark
import com.example.data.model.BrowserHistory
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.SitePermission
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val category: String,
    val tagsCsv: String,
    val addedTime: Long,
    val faviconUrl: String?,
    val notes: String
) {
    fun toDomain(): Bookmark = Bookmark(
        id = id,
        url = url,
        title = title,
        category = category,
        tags = if (tagsCsv.isBlank()) emptyList() else tagsCsv.split(","),
        addedTime = addedTime,
        faviconUrl = faviconUrl,
        notes = notes
    )

    companion object {
        fun fromDomain(b: Bookmark): BookmarkEntity = BookmarkEntity(
            id = b.id,
            url = b.url,
            title = b.title,
            category = b.category,
            tagsCsv = b.tags.joinToString(","),
            addedTime = b.addedTime,
            faviconUrl = b.faviconUrl,
            notes = b.notes
        )
    }
}

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val visitTime: Long,
    val visitCount: Int,
    val domain: String,
    val faviconUrl: String?,
    val isIncognito: Boolean
) {
    fun toDomain(): BrowserHistory = BrowserHistory(
        id = id,
        url = url,
        title = title,
        visitTime = visitTime,
        visitCount = visitCount,
        domain = domain,
        faviconUrl = faviconUrl,
        isIncognito = isIncognito
    )

    companion object {
        fun fromDomain(h: BrowserHistory): HistoryEntity = HistoryEntity(
            id = h.id,
            url = h.url,
            title = h.title,
            visitTime = h.visitTime,
            visitCount = h.visitCount,
            domain = h.domain,
            faviconUrl = h.faviconUrl,
            isIncognito = h.isIncognito
        )
    }
}

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    val url: String,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: String,
    val speedKbps: Int,
    val mimeType: String,
    val startTime: Long
) {
    fun toDomain(): DownloadItem = DownloadItem(
        id = id,
        fileName = fileName,
        url = url,
        totalBytes = totalBytes,
        downloadedBytes = downloadedBytes,
        status = try { DownloadStatus.valueOf(status) } catch (e: Exception) { DownloadStatus.COMPLETED },
        speedKbps = speedKbps,
        mimeType = mimeType,
        startTime = startTime
    )

    companion object {
        fun fromDomain(d: DownloadItem): DownloadEntity = DownloadEntity(
            id = d.id,
            fileName = d.fileName,
            url = d.url,
            totalBytes = d.totalBytes,
            downloadedBytes = d.downloadedBytes,
            status = d.status.name,
            speedKbps = d.speedKbps,
            mimeType = d.mimeType,
            startTime = d.startTime
        )
    }
}

@Entity(tableName = "site_permissions")
data class SitePermissionEntity(
    @PrimaryKey val domain: String,
    val camera: Boolean,
    val microphone: Boolean,
    val location: Boolean,
    val notifications: Boolean,
    val cookiesBlocked: Boolean,
    val trackersBlockedCount: Int
) {
    fun toDomain(): SitePermission = SitePermission(
        domain = domain,
        camera = camera,
        microphone = microphone,
        location = location,
        notifications = notifications,
        cookiesBlocked = cookiesBlocked,
        trackersBlockedCount = trackersBlockedCount
    )

    companion object {
        fun fromDomain(sp: SitePermission): SitePermissionEntity = SitePermissionEntity(
            domain = sp.domain,
            camera = sp.camera,
            microphone = sp.microphone,
            location = sp.location,
            notifications = sp.notifications,
            cookiesBlocked = sp.cookiesBlocked,
            trackersBlockedCount = sp.trackersBlockedCount
        )
    }
}

@Dao
interface BrowserDao {
    // Bookmarks
    @Query("SELECT * FROM bookmarks ORDER BY addedTime DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity): Long

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: Long)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteBookmarkByUrl(url: String)

    @Query("SELECT * FROM bookmarks WHERE url = :url LIMIT 1")
    suspend fun getBookmarkByUrl(url: String): BookmarkEntity?

    // History
    @Query("SELECT * FROM history WHERE isIncognito = 0 ORDER BY visitTime DESC")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryEntity): Long

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteHistory(id: Long)

    @Query("DELETE FROM history WHERE isIncognito = 0")
    suspend fun clearAllHistory()

    @Query("DELETE FROM history WHERE visitTime >= :sinceTime AND isIncognito = 0")
    suspend fun clearHistorySince(sinceTime: Long)

    // Downloads
    @Query("SELECT * FROM downloads ORDER BY startTime DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownload(id: String)

    @Query("DELETE FROM downloads WHERE status = 'COMPLETED'")
    suspend fun clearCompletedDownloads()

    // Site Permissions
    @Query("SELECT * FROM site_permissions WHERE domain = :domain LIMIT 1")
    suspend fun getSitePermission(domain: String): SitePermissionEntity?

    @Query("SELECT * FROM site_permissions")
    fun getAllSitePermissions(): Flow<List<SitePermissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSitePermission(sp: SitePermissionEntity)
}

@Database(
    entities = [
        BookmarkEntity::class,
        HistoryEntity::class,
        DownloadEntity::class,
        SitePermissionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun browserDao(): BrowserDao
}
