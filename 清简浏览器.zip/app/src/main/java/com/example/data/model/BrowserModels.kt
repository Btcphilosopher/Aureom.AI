package com.example.data.model

import java.util.UUID

/**
 * Tab model representing a browser tab process/renderer.
 */
data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val url: String = "about:blank",
    val title: String = "新标签页",
    val faviconUrl: String? = null,
    val isPinned: Boolean = false,
    val isIncognito: Boolean = false,
    val isSuspended: Boolean = false, // Hibernated to save memory
    val memoryUsageMb: Int = 85,
    val cpuUsagePercent: Float = 0.5f,
    val groupTag: String? = null, // "工作", "阅读", "开发", "金融", etc.
    val groupColor: Long? = null,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isLoading: Boolean = false,
    val loadProgress: Int = 0,
    val lastAccessedTime: Long = System.currentTimeMillis(),
    val extractedText: String = "",
    val isPlayingAudio: Boolean = false,
    val isCrashed: Boolean = false
)

/**
 * Bookmark entity model
 */
data class Bookmark(
    val id: Long = 0,
    val url: String,
    val title: String,
    val category: String = "全部",
    val tags: List<String> = emptyList(),
    val addedTime: Long = System.currentTimeMillis(),
    val faviconUrl: String? = null,
    val notes: String = ""
)

/**
 * History item
 */
data class BrowserHistory(
    val id: Long = 0,
    val url: String,
    val title: String,
    val visitTime: Long = System.currentTimeMillis(),
    val visitCount: Int = 1,
    val domain: String = "",
    val faviconUrl: String? = null,
    val isIncognito: Boolean = false
)

/**
 * Download item
 */
enum class DownloadStatus {
    DOWNLOADING, PAUSED, COMPLETED, CANCELLED, FAILED
}

data class DownloadItem(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val url: String,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: DownloadStatus = DownloadStatus.DOWNLOADING,
    val speedKbps: Int = 0,
    val mimeType: String = "application/octet-stream",
    val startTime: Long = System.currentTimeMillis()
)

/**
 * Site Security & Permissions
 */
data class SitePermission(
    val domain: String,
    val camera: Boolean = false,
    val microphone: Boolean = false,
    val location: Boolean = false,
    val notifications: Boolean = false,
    val cookiesBlocked: Boolean = false,
    val trackersBlockedCount: Int = 0
)

data class SiteSecurityInfo(
    val url: String,
    val domain: String,
    val isHttps: Boolean,
    val certificateIssuer: String = "DigiCert Global Root G2",
    val certificateExpiry: String = "2028-12-31",
    val securityLevel: SecurityLevel = SecurityLevel.SECURE,
    val blockedTrackersCount: Int = 4
)

enum class SecurityLevel {
    SECURE, CAUTION, INSECURE
}

/**
 * Search Engines
 */
data class SearchEngine(
    val id: String,
    val name: String,
    val searchUrl: String,
    val iconResName: String? = null,
    val isCustom: Boolean = false
) {
    fun buildSearchUrl(query: String): String {
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        return searchUrl.replace("{q}", encoded)
    }
}

/**
 * Suggestion types for Command Bar
 */
sealed class SearchSuggestion {
    data class SearchQuery(val query: String, val engineName: String) : SearchSuggestion()
    data class DirectUrl(val url: String, val title: String) : SearchSuggestion()
    data class HistoryItem(val url: String, val title: String, val timeAgo: String) : SearchSuggestion()
    data class BookmarkItem(val url: String, val title: String, val tag: String) : SearchSuggestion()
    data class SwitchToTab(val tabId: String, val title: String, val url: String) : SearchSuggestion()
    data class CommandAction(val command: String, val description: String, val actionType: String) : SearchSuggestion()
    data class QuickCalc(val expression: String, val result: String) : SearchSuggestion()
    data class QuickTranslate(val query: String, val translation: String) : SearchSuggestion()
}

/**
 * AI Analysis result for a page or multiple pages
 */
data class AiAnalysisResult(
    val title: String,
    val summaryBullets: List<String> = emptyList(),
    val keyInsights: List<String> = emptyList(),
    val extractedTables: List<ExtractedTable> = emptyList(),
    val multiTabComparison: MultiTabComparison? = null,
    val generatedNotesMarkdown: String = "",
    val citations: List<String> = emptyList(),
    val queryResponse: String? = null,
    val isProcessing: Boolean = false
)

data class ExtractedTable(
    val headers: List<String>,
    val rows: List<List<String>>
)

data class MultiTabComparison(
    val tabTitles: List<String>,
    val commonGrounds: List<String>,
    val keyDifferences: List<String>,
    val comparativeData: List<Pair<String, List<String>>>,
    val synthesizedConclusion: String
)

/**
 * Reader Mode article representation
 */
data class ReaderArticle(
    val title: String,
    val author: String? = null,
    val publishDate: String? = null,
    val readingTimeMinutes: Int = 3,
    val wordCount: Int = 1200,
    val siteName: String = "",
    val paragraphs: List<String> = emptyList(),
    val originalUrl: String = ""
)

/**
 * Network request entry for DevTools
 */
data class NetworkRequestEntry(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    val method: String = "GET",
    val statusCode: Int = 200,
    val type: String = "document",
    val sizeKb: Float = 14.2f,
    val durationMs: Int = 68,
    val timestamp: Long = System.currentTimeMillis()
)

data class ConsoleLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val level: String = "info", // info, warn, error, log
    val message: String,
    val source: String = "page.js:42",
    val timestamp: Long = System.currentTimeMillis()
)
