package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.HistoryEntity
import com.example.data.local.DownloadEntity
import com.example.data.local.SitePermissionEntity
import com.example.data.model.Bookmark
import com.example.data.model.BrowserHistory
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.SearchEngine
import com.example.data.model.SitePermission
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class BrowserRepository(context: Context) {
    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "qingjian_browser.db"
    ).build()

    private val dao = db.browserDao()

    val bookmarks: Flow<List<Bookmark>> = dao.getAllBookmarks().map { list ->
        list.map { it.toDomain() }
    }

    val history: Flow<List<BrowserHistory>> = dao.getAllHistory().map { list ->
        list.map { it.toDomain() }
    }

    val downloads: Flow<List<DownloadItem>> = dao.getAllDownloads().map { list ->
        list.map { it.toDomain() }
    }

    val sitePermissions: Flow<List<SitePermission>> = dao.getAllSitePermissions().map { list ->
        list.map { it.toDomain() }
    }

    init {
        // Seed default bookmarks and permissions if first launch
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialData()
        }
    }

    private suspend fun seedInitialData() {
        val existing = dao.getBookmarkByUrl("https://www.baidu.com")
        if (existing == null) {
            val defaults = listOf(
                Bookmark(
                    url = "https://www.zhihu.com",
                    title = "知乎 - 有问题，就会有答案",
                    category = "阅读",
                    tags = listOf("问答", "知识", "社区")
                ),
                Bookmark(
                    url = "https://github.com",
                    title = "GitHub - Let's build from here",
                    category = "开发",
                    tags = listOf("代码", "开源", "Git")
                ),
                Bookmark(
                    url = "https://36kr.com",
                    title = "36氪 - 让一部分人先看到未来",
                    category = "研究",
                    tags = listOf("科技", "创投", "商业")
                ),
                Bookmark(
                    url = "https://arxiv.org",
                    title = "arXiv.org e-Print archive",
                    category = "研究",
                    tags = listOf("学术", "论文", "AI")
                ),
                Bookmark(
                    url = "https://www.douban.com",
                    title = "豆瓣 - 提供书影音生活服务",
                    category = "阅读",
                    tags = listOf("书影音", "评分", "文化")
                ),
                Bookmark(
                    url = "https://www.baidu.com",
                    title = "百度一下，你就知道",
                    category = "日常",
                    tags = listOf("中文搜索", "导航")
                )
            )
            defaults.forEach {
                dao.insertBookmark(BookmarkEntity.fromDomain(it))
            }

            // Seed initial history
            val initialHistory = listOf(
                BrowserHistory(
                    url = "https://www.zhihu.com/explore",
                    title = "发现更多深度讨论 - 知乎",
                    domain = "zhihu.com",
                    visitTime = System.currentTimeMillis() - 1000 * 60 * 35
                ),
                BrowserHistory(
                    url = "https://github.com/trending",
                    title = "Trending repositories on GitHub today",
                    domain = "github.com",
                    visitTime = System.currentTimeMillis() - 1000 * 60 * 90
                ),
                BrowserHistory(
                    url = "https://36kr.com/newsflashes",
                    title = "36氪快讯 - 7x24小时实时财经资讯",
                    domain = "36kr.com",
                    visitTime = System.currentTimeMillis() - 1000 * 60 * 180
                ),
                BrowserHistory(
                    url = "https://arxiv.org/abs/2403.00001",
                    title = "Next-Generation Browser Architectures and Reasoning Engines",
                    domain = "arxiv.org",
                    visitTime = System.currentTimeMillis() - 1000 * 60 * 60 * 24
                )
            )
            initialHistory.forEach {
                dao.insertHistory(HistoryEntity.fromDomain(it))
            }

            // Seed initial downloads
            val initialDownloads = listOf(
                DownloadItem(
                    fileName = "Qingjian_Architecture_Whitepaper_v1.0.pdf",
                    url = "https://qingjian.org/docs/whitepaper.pdf",
                    totalBytes = 2_840_000,
                    downloadedBytes = 2_840_000,
                    status = DownloadStatus.COMPLETED,
                    mimeType = "application/pdf"
                ),
                DownloadItem(
                    fileName = "chinese_typography_specs_2027.zip",
                    url = "https://design.qingjian.org/typography.zip",
                    totalBytes = 14_500_000,
                    downloadedBytes = 14_500_000,
                    status = DownloadStatus.COMPLETED,
                    mimeType = "application/zip"
                )
            )
            initialDownloads.forEach {
                dao.insertDownload(DownloadEntity.fromDomain(it))
            }
        }
    }

    // Bookmark operations
    suspend fun addBookmark(bookmark: Bookmark): Long {
        return dao.insertBookmark(BookmarkEntity.fromDomain(bookmark))
    }

    suspend fun removeBookmark(id: Long) {
        dao.deleteBookmark(id)
    }

    suspend fun removeBookmarkByUrl(url: String) {
        dao.deleteBookmarkByUrl(url)
    }

    suspend fun isBookmarked(url: String): Boolean {
        return dao.getBookmarkByUrl(url) != null
    }

    // History operations
    suspend fun recordHistory(history: BrowserHistory) {
        if (!history.isIncognito && history.url != "about:blank" && !history.url.startsWith("qingjian://")) {
            dao.insertHistory(HistoryEntity.fromDomain(history))
        }
    }

    suspend fun deleteHistory(id: Long) {
        dao.deleteHistory(id)
    }

    suspend fun clearAllHistory() {
        dao.clearAllHistory()
    }

    suspend fun clearHistorySince(sinceTime: Long) {
        dao.clearHistorySince(sinceTime)
    }

    // Download operations
    suspend fun addOrUpdateDownload(item: DownloadItem) {
        dao.insertDownload(DownloadEntity.fromDomain(item))
    }

    suspend fun deleteDownload(id: String) {
        dao.deleteDownload(id)
    }

    suspend fun clearCompletedDownloads() {
        dao.clearCompletedDownloads()
    }

    // Permissions
    suspend fun getSitePermission(domain: String): SitePermission {
        return dao.getSitePermission(domain)?.toDomain() ?: SitePermission(domain = domain)
    }

    suspend fun updateSitePermission(permission: SitePermission) {
        dao.saveSitePermission(SitePermissionEntity.fromDomain(permission))
    }
}
