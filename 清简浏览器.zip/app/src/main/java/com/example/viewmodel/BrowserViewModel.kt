package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AiAnalysisResult
import com.example.data.model.Bookmark
import com.example.data.model.BrowserHistory
import com.example.data.model.BrowserTab
import com.example.data.model.ConsoleLogEntry
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.ExtractedTable
import com.example.data.model.MultiTabComparison
import com.example.data.model.NetworkRequestEntry
import com.example.data.model.ReaderArticle
import com.example.data.model.SearchEngine
import com.example.data.model.SearchSuggestion
import com.example.data.model.SecurityLevel
import com.example.data.model.SitePermission
import com.example.data.model.SiteSecurityInfo
import com.example.data.repository.BrowserRepository
import com.example.ui.webview.BuiltInWebPages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

// Active dialog / sheet overlays
enum class ActiveOverlay {
    NONE,
    TAB_OVERVIEW,
    AI_PANEL,
    READER_MODE,
    TRANSLATION,
    DEV_TOOLS,
    TASK_MANAGER,
    PRIVACY_CENTER,
    BOOKMARKS,
    HISTORY,
    DOWNLOADS,
    SETTINGS
}

data class BrowserUiState(
    val tabs: List<BrowserTab> = emptyList(),
    val activeTabId: String = "",
    val activeOverlay: ActiveOverlay = ActiveOverlay.NONE,
    val isIncognitoWindow: Boolean = false,
    val isDarkMode: Boolean = false,
    val defaultSearchEngine: SearchEngine = SearchEngine(
        id = "baidu",
        name = "百度",
        searchUrl = "https://www.baidu.com/s?wd={q}"
    ),
    val availableSearchEngines: List<SearchEngine> = listOf(
        SearchEngine("baidu", "百度", "https://www.baidu.com/s?wd={q}"),
        SearchEngine("bing", "必应 Bing", "https://www.bing.com/search?q={q}"),
        SearchEngine("google", "Google", "https://www.google.com/search?q={q}"),
        SearchEngine("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q={q}"),
        SearchEngine("qingjian_ai", "清简 AI 搜索", "https://qingjian.ai/search?q={q}")
    ),
    val searchSuggestions: List<SearchSuggestion> = emptyList(),
    val isOmnibarFocused: Boolean = false,
    val commandBarText: String = "",
    val siteSecurityInfo: SiteSecurityInfo? = null,
    val readerArticle: ReaderArticle? = null,
    val readerFontSizeSp: Int = 16,
    val readerLineHeightMultiplier: Float = 1.8f,
    val readerMaxWidthDp: Int = 640,
    val readerThemeName: String = "羊皮纸暖黄", // 羊皮纸暖黄, 水墨淡白, 墨黑夜读, 苍青护眼
    val isReaderSpeaking: Boolean = false,
    val isReaderBilingual: Boolean = false,
    val aiAnalysisResult: AiAnalysisResult? = null,
    val selectedTabsForAiComparison: Set<String> = emptySet(),
    val devToolsLogs: List<ConsoleLogEntry> = emptyList(),
    val devToolsRequests: List<NetworkRequestEntry> = emptyList(),
    val totalMemoryUsageMb: Int = 180,
    val trackingProtectionEnabled: Boolean = true,
    val thirdPartyCookiesBlocked: Boolean = true,
    val currentSitePermission: SitePermission? = null,
    val recentlyClosedTabs: List<BrowserTab> = emptyList()
)

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BrowserRepository(application)

    val bookmarks: StateFlow<List<Bookmark>> = repository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<BrowserHistory>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloads: StateFlow<List<DownloadItem>> = repository.downloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    init {
        // Initialize with default home tab
        val initialTab = BrowserTab(
            id = UUID.randomUUID().toString(),
            url = "qingjian://newtab",
            title = "新标签页",
            memoryUsageMb = 48,
            cpuUsagePercent = 0.2f
        )
        _uiState.update {
            it.copy(
                tabs = listOf(initialTab),
                activeTabId = initialTab.id
            )
        }
        updateSiteSecurityInfo("qingjian://newtab")
        simulateBackgroundPerformanceMonitor()
    }

    // Tab Management
    fun createNewTab(url: String = "qingjian://newtab", title: String = "新标签页", isIncognito: Boolean = false) {
        val newTab = BrowserTab(
            id = UUID.randomUUID().toString(),
            url = url,
            title = title,
            isIncognito = isIncognito || _uiState.value.isIncognitoWindow,
            memoryUsageMb = if (url == "qingjian://newtab") 45 else 85,
            cpuUsagePercent = 0.4f
        )
        _uiState.update { state ->
            val updatedTabs = state.tabs + newTab
            state.copy(
                tabs = updatedTabs,
                activeTabId = newTab.id,
                commandBarText = if (url == "qingjian://newtab") "" else url
            )
        }
        updateSiteSecurityInfo(url)
    }

    fun switchTab(tabId: String) {
        val tab = _uiState.value.tabs.find { it.id == tabId } ?: return
        // If tab was suspended, wake it up
        val updatedTabs = _uiState.value.tabs.map {
            if (it.id == tabId) it.copy(isSuspended = false, lastAccessedTime = System.currentTimeMillis())
            else it
        }
        _uiState.update {
            it.copy(
                tabs = updatedTabs,
                activeTabId = tabId,
                commandBarText = if (tab.url == "qingjian://newtab") "" else tab.url
            )
        }
        updateSiteSecurityInfo(tab.url)
    }

    fun closeTab(tabId: String) {
        val currentTabs = _uiState.value.tabs
        val closingTab = currentTabs.find { it.id == tabId }
        val remaining = currentTabs.filter { it.id != tabId }

        if (closingTab != null && closingTab.url != "qingjian://newtab") {
            _uiState.update {
                it.copy(recentlyClosedTabs = (listOf(closingTab) + it.recentlyClosedTabs).take(10))
            }
        }

        if (remaining.isEmpty()) {
            val freshTab = BrowserTab(
                id = UUID.randomUUID().toString(),
                url = "qingjian://newtab",
                title = "新标签页"
            )
            _uiState.update {
                it.copy(
                    tabs = listOf(freshTab),
                    activeTabId = freshTab.id,
                    commandBarText = ""
                )
            }
        } else {
            val nextActiveId = if (_uiState.value.activeTabId == tabId) {
                remaining.last().id
            } else {
                _uiState.value.activeTabId
            }
            _uiState.update {
                it.copy(
                    tabs = remaining,
                    activeTabId = nextActiveId
                )
            }
        }
    }

    fun restoreRecentlyClosedTab() {
        val closed = _uiState.value.recentlyClosedTabs.firstOrNull() ?: return
        _uiState.update {
            it.copy(
                recentlyClosedTabs = it.recentlyClosedTabs.drop(1),
                tabs = it.tabs + closed,
                activeTabId = closed.id
            )
        }
    }

    fun pinTab(tabId: String) {
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == tabId) it.copy(isPinned = !it.isPinned) else it
                }
            )
        }
    }

    fun suspendTab(tabId: String) {
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == tabId) it.copy(isSuspended = true, memoryUsageMb = 12, cpuUsagePercent = 0.0f) else it
                }
            )
        }
    }

    fun setTabGroup(tabId: String, groupTag: String?, color: Long?) {
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == tabId) it.copy(groupTag = groupTag, groupColor = color) else it
                }
            )
        }
    }

    // Navigation & Command Bar
    fun navigateTo(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        // 1. Check if special command (!cmd)
        if (trimmed.startsWith("!")) {
            handleUniversalCommand(trimmed)
            return
        }

        // 2. Check if calculation expression
        if (isMathExpression(trimmed)) {
            val result = evaluateMath(trimmed)
            _uiState.update {
                it.copy(
                    commandBarText = "= $result",
                    isOmnibarFocused = false
                )
            }
            return
        }

        // 3. Determine if URL or Search Query
        val targetUrl = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("qingjian://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> _uiState.value.defaultSearchEngine.buildSearchUrl(trimmed)
        }

        val domain = extractDomain(targetUrl)
        val defaultTitle = if (targetUrl.startsWith("qingjian://newtab")) "新标签页" else domain

        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == state.activeTabId) {
                        it.copy(
                            url = targetUrl,
                            title = defaultTitle,
                            isLoading = true,
                            loadProgress = 15,
                            isSuspended = false,
                            isCrashed = false
                        )
                    } else it
                },
                commandBarText = targetUrl,
                isOmnibarFocused = false,
                searchSuggestions = emptyList()
            )
        }

        updateSiteSecurityInfo(targetUrl)

        // Record history
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordHistory(
                BrowserHistory(
                    url = targetUrl,
                    title = defaultTitle,
                    domain = domain,
                    isIncognito = _uiState.value.isIncognitoWindow
                )
            )
            // Add mock DevTools network log
            addDevToolsNetworkEntry(targetUrl)
        }
    }

    fun onPageLoadProgress(progress: Int) {
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == state.activeTabId) {
                        it.copy(
                            loadProgress = progress,
                            isLoading = progress < 100
                        )
                    } else it
                }
            )
        }
    }

    fun onPageTitleReceived(title: String, url: String) {
        val domain = extractDomain(url)
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == state.activeTabId) {
                        it.copy(title = title, url = url)
                    } else it
                },
                commandBarText = if (url == "qingjian://newtab") "" else url
            )
        }

        // Update Reader Article data
        _uiState.update {
            it.copy(readerArticle = BuiltInWebPages.getSimulatedArticle(url))
        }

        // Update history title
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordHistory(
                BrowserHistory(
                    url = url,
                    title = title,
                    domain = domain,
                    isIncognito = _uiState.value.isIncognitoWindow
                )
            )
        }
    }

    fun updateCommandBarText(text: String) {
        _uiState.update { it.copy(commandBarText = text) }
        generateSearchSuggestions(text)
    }

    fun setOmnibarFocused(focused: Boolean) {
        _uiState.update {
            it.copy(
                isOmnibarFocused = focused,
                searchSuggestions = if (focused) generateInitialSuggestions() else emptyList()
            )
        }
    }

    private fun generateSearchSuggestions(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            _uiState.update { it.copy(searchSuggestions = generateInitialSuggestions()) }
            return
        }

        val suggestions = mutableListOf<SearchSuggestion>()

        // Check command prefix
        if (trimmed.startsWith("!")) {
            val cmd = trimmed.removePrefix("!").lowercase()
            val availableCommands = listOf(
                Pair("!新闻 <关键词>", "使用新华社 / 人民网等权威新闻源检索"),
                Pair("!书籍 <书名>", "在中文出版物与豆瓣读书中检索"),
                Pair("!百科 <词条>", "在中国大百科全书及维基百科中检索"),
                Pair("!代码 <关键词>", "在 GitHub / Rust / Kotlin 代码库中检索"),
                Pair("!计算 238*19", "即时数学表达式计算"),
                Pair("!翻译 <语句>", "即时中英多语言极速翻译"),
                Pair("!设置", "打开清简浏览器系统设置"),
                Pair("!任务", "打开浏览器进程与任务管理器"),
                Pair("!隐私", "打开网站安全与隐私保护中心")
            )
            val matches = availableCommands.filter { it.first.contains(cmd) || it.second.contains(cmd) }
            matches.forEach { (c, desc) ->
                suggestions.add(SearchSuggestion.CommandAction(c, desc, c))
            }
        }

        // Math calculation suggestion
        if (isMathExpression(trimmed)) {
            val result = evaluateMath(trimmed)
            suggestions.add(SearchSuggestion.QuickCalc(trimmed, result))
        }

        // Translation suggestion
        if (trimmed.startsWith("!trans ") || trimmed.startsWith("!翻译 ")) {
            val transText = trimmed.substringAfter(" ")
            suggestions.add(SearchSuggestion.QuickTranslate(transText, getMockTranslation(transText)))
        }

        // Search engines suggestions
        suggestions.add(
            SearchSuggestion.SearchQuery(trimmed, _uiState.value.defaultSearchEngine.name)
        )

        // Matching open tabs
        _uiState.value.tabs.filter { it.title.contains(trimmed, ignoreCase = true) || it.url.contains(trimmed, ignoreCase = true) }
            .take(2).forEach {
                suggestions.add(SearchSuggestion.SwitchToTab(it.id, it.title, it.url))
            }

        // Matching bookmarks
        bookmarks.value.filter { it.title.contains(trimmed, ignoreCase = true) || it.url.contains(trimmed, ignoreCase = true) }
            .take(3).forEach {
                suggestions.add(SearchSuggestion.BookmarkItem(it.url, it.title, it.category))
            }

        // Matching history
        history.value.filter { it.title.contains(trimmed, ignoreCase = true) || it.url.contains(trimmed, ignoreCase = true) }
            .take(3).forEach {
                suggestions.add(SearchSuggestion.HistoryItem(it.url, it.title, "历史访问"))
            }

        _uiState.update { it.copy(searchSuggestions = suggestions) }
    }

    private fun generateInitialSuggestions(): List<SearchSuggestion> {
        val recents = history.value.take(4).map {
            SearchSuggestion.HistoryItem(it.url, it.title, "最近")
        }
        val commands = listOf(
            SearchSuggestion.CommandAction("!新闻", "新闻深度搜索", "!news"),
            SearchSuggestion.CommandAction("!百科", "百科词条查询", "!wiki"),
            SearchSuggestion.CommandAction("!代码", "代码与开发库检索", "!code"),
            SearchSuggestion.CommandAction("!计算", "快速算术运算", "!calc")
        )
        return commands + recents
    }

    private fun handleUniversalCommand(command: String) {
        when {
            command.startsWith("!新闻 ") || command.startsWith("!news ") -> {
                val q = command.substringAfter(" ")
                navigateTo("https://www.baidu.com/s?tn=news&rtt=1&bsst=1&cl=2&wd=" + java.net.URLEncoder.encode(q, "UTF-8"))
            }
            command.startsWith("!书籍 ") || command.startsWith("!book ") -> {
                val q = command.substringAfter(" ")
                navigateTo("https://search.douban.com/book/subject_search?search_text=" + java.net.URLEncoder.encode(q, "UTF-8"))
            }
            command.startsWith("!百科 ") || command.startsWith("!wiki ") -> {
                val q = command.substringAfter(" ")
                navigateTo("https://baike.baidu.com/item/" + java.net.URLEncoder.encode(q, "UTF-8"))
            }
            command.startsWith("!代码 ") || command.startsWith("!code ") -> {
                val q = command.substringAfter(" ")
                navigateTo("https://github.com/search?q=" + java.net.URLEncoder.encode(q, "UTF-8"))
            }
            command.startsWith("!计算 ") || command.startsWith("!calc ") -> {
                val expr = command.substringAfter(" ")
                val res = evaluateMath(expr)
                _uiState.update { it.copy(commandBarText = "$expr = $res", isOmnibarFocused = false) }
            }
            command.startsWith("!翻译 ") || command.startsWith("!trans ") -> {
                setOverlay(ActiveOverlay.TRANSLATION)
            }
            command == "!设置" || command == "!settings" -> setOverlay(ActiveOverlay.SETTINGS)
            command == "!任务" || command == "!task" -> setOverlay(ActiveOverlay.TASK_MANAGER)
            command == "!书签" || command == "!bookmarks" -> setOverlay(ActiveOverlay.BOOKMARKS)
            command == "!历史" || command == "!history" -> setOverlay(ActiveOverlay.HISTORY)
            command == "!下载" || command == "!downloads" -> setOverlay(ActiveOverlay.DOWNLOADS)
            command == "!隐私" || command == "!privacy" -> setOverlay(ActiveOverlay.PRIVACY_CENTER)
            else -> navigateTo(_uiState.value.defaultSearchEngine.buildSearchUrl(command.removePrefix("!")))
        }
    }

    // AI Features ("问问清简")
    fun triggerAiSummaryForCurrentPage() {
        val currentTab = _uiState.value.tabs.find { it.id == _uiState.value.activeTabId } ?: return
        _uiState.update {
            it.copy(
                activeOverlay = ActiveOverlay.AI_PANEL,
                aiAnalysisResult = AiAnalysisResult(
                    title = currentTab.title,
                    isProcessing = true
                )
            )
        }

        viewModelScope.launch {
            delay(900) // Realistic synthesis time
            val article = BuiltInWebPages.getSimulatedArticle(currentTab.url)
            _uiState.update { state ->
                state.copy(
                    aiAnalysisResult = AiAnalysisResult(
                        title = currentTab.title,
                        summaryBullets = listOf(
                            "核心命题：在当代计算环境中，信息密集度激增使得专注度成为稀缺资源，浏览器应当尽可能隐入背景，让内容成为主体。",
                            "工程突破：采用沙箱隔离与多进程生命周期管控，闲置标签页内存占用压缩达 80% 以上，支持零损耗即时唤醒。",
                            "排版与阅读：重构 CJK 字体度量与 1.8x 呼吸感行高，结合端云协同 AI 实现跨标签观点对比与结构化表格提炼。"
                        ),
                        keyInsights = listOf(
                            "防追踪拦截率高达 99.8%，有效阻断第三方 Cookie 与指纹探针",
                            "页面冷启动时间优化至 0.9s 以内，较传统架构大幅提速",
                            "Universal Command Bar 支持自然语言、搜索、算术与多语言翻译一体化"
                        ),
                        extractedTables = listOf(
                            ExtractedTable(
                                headers = listOf("评估指标", "行业基线", "清简实测"),
                                rows = listOf(
                                    listOf("冷启动延迟", "2.8s - 4.5s", "0.85s"),
                                    listOf("后台标签均耗内存", "240 MB", "45 MB (休眠)"),
                                    listOf("防跟踪拦截能力", "基础拦截", "零侵入严苛沙箱")
                                )
                            )
                        ),
                        citations = listOf(
                            "来源：当前网页正文 · ${article.siteName}",
                            "验证时间：${article.publishDate} · 字数统计：${article.wordCount} 字"
                        ),
                        generatedNotesMarkdown = """
                            # 研读笔记 · ${currentTab.title}
                            - **发布源**：${article.siteName} (${article.publishDate})
                            - **要点归纳**：
                              1. 架构去伪存真，以功能极简（Minimalism as Function）取代视觉炫技。
                              2. 智能休眠与内存弹性调度，兼顾澎湃性能与低发热量。
                              3. 结构化数据提取无缝集成，随时可导出 Markdown 与 CSV。
                        """.trimIndent(),
                        isProcessing = false
                    )
                )
            }
        }
    }

    fun toggleTabSelectionForAiComparison(tabId: String) {
        _uiState.update { state ->
            val set = state.selectedTabsForAiComparison.toMutableSet()
            if (set.contains(tabId)) set.remove(tabId) else set.add(tabId)
            state.copy(selectedTabsForAiComparison = set)
        }
    }

    fun executeMultiTabAiComparison() {
        val selectedIds = _uiState.value.selectedTabsForAiComparison
        val tabs = _uiState.value.tabs.filter { selectedIds.contains(it.id) }
        if (tabs.size < 2) return

        _uiState.update {
            it.copy(
                activeOverlay = ActiveOverlay.AI_PANEL,
                aiAnalysisResult = AiAnalysisResult(
                    title = "跨标签综合对比分析 (${tabs.size} 个网页)",
                    isProcessing = true
                )
            )
        }

        viewModelScope.launch {
            delay(1200)
            val titles = tabs.map { it.title }
            _uiState.update { state ->
                state.copy(
                    aiAnalysisResult = AiAnalysisResult(
                        title = "跨标签综合对比分析 (${tabs.size} 个网页)",
                        multiTabComparison = MultiTabComparison(
                            tabTitles = titles,
                            commonGrounds = listOf(
                                "一致认同现代计算环境需大幅降低界面认知负荷与视觉干扰",
                                "均指出内存膨胀与功耗是多标签浏览的最大痛点",
                                "强调隐私安全与反指纹追踪应当作为底层默认配置而非额外扩展"
                            ),
                            keyDifferences = listOf(
                                "标签页 A 侧重底层 Rust 内存沙箱与渲染器进程隔离；",
                                "标签页 B 聚焦于中文排版美学与 1.8x 字体行距的最佳实践；",
                                "标签页 C 强调端侧小模型与云端知识检索的低延迟协同。"
                            ),
                            comparativeData = listOf(
                                "核心侧重点" to listOf("系统架构", "中文排版", "AI协同"),
                                "冷启动指标" to listOf("0.85s", "0.92s", "1.10s"),
                                "内存压缩率" to listOf("82%", "75%", "78%")
                            ),
                            synthesizedConclusion = "三个来源从架构、排版与智能交互三个维度互为印证，表明现代原生浏览器正朝着‘极轻量核心 + 极致内容专注 + 隐形 AI 赋能’的全新范式演进。"
                        ),
                        isProcessing = false
                    )
                )
            }
        }
    }

    fun askAiQuestion(question: String) {
        val currentTab = _uiState.value.tabs.find { it.id == _uiState.value.activeTabId }
        _uiState.update {
            it.copy(
                aiAnalysisResult = it.aiAnalysisResult?.copy(isProcessing = true) ?: AiAnalysisResult(
                    title = currentTab?.title ?: "问问清简",
                    isProcessing = true
                )
            )
        }

        viewModelScope.launch {
            delay(1000)
            val answer = "根据当前网页正文与权威知识库分析：关于「$question」，本页面核心阐明了以功能极简（Minimalism as Function）为导向的工程实践。不仅实现了 99.8% 的防追踪拦截与 0.9 秒内的极速冷启动，更在中文排版与多标签休眠上提供了原生级的流畅体验。"
            _uiState.update { state ->
                state.copy(
                    aiAnalysisResult = state.aiAnalysisResult?.copy(
                        queryResponse = answer,
                        isProcessing = false
                    )
                )
            }
        }
    }

    // Reader Mode Settings
    fun toggleReaderMode() {
        if (_uiState.value.activeOverlay == ActiveOverlay.READER_MODE) {
            setOverlay(ActiveOverlay.NONE)
        } else {
            val currentTab = _uiState.value.tabs.find { it.id == _uiState.value.activeTabId }
            if (currentTab != null) {
                _uiState.update {
                    it.copy(
                        readerArticle = BuiltInWebPages.getSimulatedArticle(currentTab.url),
                        activeOverlay = ActiveOverlay.READER_MODE
                    )
                }
            }
        }
    }

    fun setReaderFontSize(size: Int) {
        _uiState.update { it.copy(readerFontSizeSp = size.coerceIn(12, 28)) }
    }

    fun setReaderLineHeight(height: Float) {
        _uiState.update { it.copy(readerLineHeightMultiplier = height) }
    }

    fun setReaderMaxWidth(widthDp: Int) {
        _uiState.update { it.copy(readerMaxWidthDp = widthDp) }
    }

    fun setReaderTheme(themeName: String) {
        _uiState.update { it.copy(readerThemeName = themeName) }
    }

    fun toggleReaderSpeech() {
        _uiState.update { it.copy(isReaderSpeaking = !it.isReaderSpeaking) }
    }

    fun toggleReaderBilingual() {
        _uiState.update { it.copy(isReaderBilingual = !it.isReaderBilingual) }
    }

    // Bookmarks operations
    fun toggleBookmarkCurrentPage() {
        val currentTab = _uiState.value.tabs.find { it.id == _uiState.value.activeTabId } ?: return
        if (currentTab.url == "qingjian://newtab") return

        viewModelScope.launch(Dispatchers.IO) {
            val isBookmarked = repository.isBookmarked(currentTab.url)
            if (isBookmarked) {
                repository.removeBookmarkByUrl(currentTab.url)
            } else {
                repository.addBookmark(
                    Bookmark(
                        url = currentTab.url,
                        title = currentTab.title,
                        category = "全部",
                        tags = listOf("网页")
                    )
                )
            }
        }
    }

    fun deleteBookmark(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeBookmark(id)
        }
    }

    fun deleteHistory(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteHistory(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllHistory()
        }
    }

    // Downloads
    fun simulateNewDownload(fileName: String, sizeBytes: Long) {
        val item = DownloadItem(
            fileName = fileName,
            url = "https://download.qingjian.org/assets/$fileName",
            totalBytes = sizeBytes,
            downloadedBytes = 0,
            status = DownloadStatus.DOWNLOADING,
            speedKbps = 2450
        )
        viewModelScope.launch(Dispatchers.IO) {
            repository.addOrUpdateDownload(item)
            // Progressively simulate download completion
            for (p in 1..10) {
                delay(300)
                val downloaded = (sizeBytes * (p / 10.0)).toLong()
                val status = if (p == 10) DownloadStatus.COMPLETED else DownloadStatus.DOWNLOADING
                repository.addOrUpdateDownload(
                    item.copy(
                        downloadedBytes = downloaded,
                        status = status,
                        speedKbps = if (p == 10) 0 else (2100 + (Math.random() * 400).toInt())
                    )
                )
            }
        }
    }

    fun deleteDownload(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteDownload(id)
        }
    }

    // Site Security & Permissions
    private fun updateSiteSecurityInfo(url: String) {
        val domain = extractDomain(url)
        val isHttps = url.startsWith("https://") || url.startsWith("qingjian://")
        _uiState.update {
            it.copy(
                siteSecurityInfo = SiteSecurityInfo(
                    url = url,
                    domain = domain,
                    isHttps = isHttps,
                    securityLevel = if (isHttps) SecurityLevel.SECURE else SecurityLevel.CAUTION,
                    blockedTrackersCount = if (url.startsWith("qingjian://")) 0 else 4
                )
            )
        }

        viewModelScope.launch(Dispatchers.IO) {
            val perm = repository.getSitePermission(domain)
            _uiState.update { it.copy(currentSitePermission = perm) }
        }
    }

    fun togglePermission(domain: String, permissionType: String) {
        val current = _uiState.value.currentSitePermission ?: SitePermission(domain = domain)
        val updated = when (permissionType) {
            "camera" -> current.copy(camera = !current.camera)
            "microphone" -> current.copy(microphone = !current.microphone)
            "location" -> current.copy(location = !current.location)
            "notifications" -> current.copy(notifications = !current.notifications)
            "cookies" -> current.copy(cookiesBlocked = !current.cookiesBlocked)
            else -> current
        }
        _uiState.update { it.copy(currentSitePermission = updated) }
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSitePermission(updated)
        }
    }

    // Settings
    fun setDefaultSearchEngine(engine: SearchEngine) {
        _uiState.update { it.copy(defaultSearchEngine = engine) }
    }

    fun toggleTrackingProtection() {
        _uiState.update { it.copy(trackingProtectionEnabled = !it.trackingProtectionEnabled) }
    }

    fun toggleThirdPartyCookies() {
        _uiState.update { it.copy(thirdPartyCookiesBlocked = !it.thirdPartyCookiesBlocked) }
    }

    fun toggleDarkMode() {
        _uiState.update { it.copy(isDarkMode = !it.isDarkMode) }
    }

    fun setOverlay(overlay: ActiveOverlay) {
        _uiState.update { it.copy(activeOverlay = overlay) }
    }

    // DevTools & Crash simulation
    fun simulateTabCrash(tabId: String) {
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == tabId) it.copy(isCrashed = true) else it
                }
            )
        }
    }

    fun recoverCrashedTab(tabId: String) {
        _uiState.update { state ->
            state.copy(
                tabs = state.tabs.map {
                    if (it.id == tabId) it.copy(isCrashed = false, isLoading = false) else it
                }
            )
        }
    }

    private fun addDevToolsNetworkEntry(url: String) {
        val entry = NetworkRequestEntry(
            url = url,
            method = "GET",
            statusCode = 200,
            type = if (url.endsWith(".png") || url.endsWith(".jpg")) "image" else "document",
            sizeKb = (12.4f + Math.random() * 8.0f).toFloat(),
            durationMs = (45 + Math.random() * 60).toInt()
        )
        val log = ConsoleLogEntry(
            level = "info",
            message = "[Qingjian Security Sandbox] Connection secured to ${extractDomain(url)} (TLS 1.3)",
            source = "security_pipeline.cpp:118"
        )
        _uiState.update {
            it.copy(
                devToolsRequests = (listOf(entry) + it.devToolsRequests).take(30),
                devToolsLogs = (listOf(log) + it.devToolsLogs).take(30)
            )
        }
    }

    private fun simulateBackgroundPerformanceMonitor() {
        viewModelScope.launch {
            while (true) {
                delay(3000)
                val totalMem = _uiState.value.tabs.sumOf { it.memoryUsageMb } + 60
                _uiState.update { it.copy(totalMemoryUsageMb = totalMem) }
            }
        }
    }

    // Helper functions
    private fun extractDomain(url: String): String {
        return try {
            if (url.startsWith("qingjian://")) "qingjian://系统"
            else {
                val clean = url.removePrefix("http://").removePrefix("https://")
                clean.substringBefore("/").substringBefore("?")
            }
        } catch (e: Exception) {
            url
        }
    }

    private fun isMathExpression(input: String): Boolean {
        val expr = input.removePrefix("!计算 ").removePrefix("!calc ").trim()
        val mathChars = "+-*/%^().0123456789 "
        return expr.isNotEmpty() && expr.any { it in "+-*/" } && expr.all { it in mathChars }
    }

    private fun evaluateMath(input: String): String {
        val expr = input.removePrefix("!计算 ").removePrefix("!calc ").trim()
        return try {
            // Simple arithmetic parser
            when {
                expr.contains("+") -> {
                    val p = expr.split("+")
                    (p[0].trim().toDouble() + p[1].trim().toDouble()).toString().removeSuffix(".0")
                }
                expr.contains("-") -> {
                    val p = expr.split("-")
                    (p[0].trim().toDouble() - p[1].trim().toDouble()).toString().removeSuffix(".0")
                }
                expr.contains("*") -> {
                    val p = expr.split("*")
                    (p[0].trim().toDouble() * p[1].trim().toDouble()).toString().removeSuffix(".0")
                }
                expr.contains("/") -> {
                    val p = expr.split("/")
                    val b = p[1].trim().toDouble()
                    if (b == 0.0) "除数不可为零" else (p[0].trim().toDouble() / b).toString().take(8)
                }
                else -> expr
            }
        } catch (e: Exception) {
            "无法计算"
        }
    }

    private fun getMockTranslation(query: String): String {
        return when {
            query.contains("market", ignoreCase = true) -> "市场正在趋于出清与均衡。"
            query.contains("browser", ignoreCase = true) -> "新一代原生中文轻量浏览器。"
            query.contains("minimalism", ignoreCase = true) -> "功能优先的极简主义，摒弃一切冗余噪音。"
            else -> "已翻译：$query （即时双语对照已就绪）"
        }
    }
}
