package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrowserTab
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.InkGraphiteMuted
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.SubduedBlue

@Composable
fun TabOverviewDialog(
    tabs: List<BrowserTab>,
    activeTabId: String,
    recentlyClosed: List<BrowserTab>,
    onSelectTab: (String) -> Unit,
    onCloseTab: (String) -> Unit,
    onNewTab: () -> Unit,
    onRestoreClosed: () -> Unit,
    onSuspendTab: (String) -> Unit,
    onSetTabGroup: (String, String?, Long?) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterGroup by remember { mutableStateOf<String?>(null) }

    val filteredTabs = tabs.filter {
        val matchesQuery = it.title.contains(searchQuery, ignoreCase = true) || it.url.contains(searchQuery, ignoreCase = true)
        val matchesGroup = selectedFilterGroup == null || it.groupTag == selectedFilterGroup
        matchesQuery && matchesGroup
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "标签页与多进程概览",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "共 ${tabs.size} 个标签 · 运行中 ${tabs.count { !it.isSuspended }} · 智能休眠 ${tabs.count { it.isSuspended }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onNewTab, modifier = Modifier.size(36.dp).testTag("overview_new_tab_btn")) {
                        Icon(Icons.Default.Add, contentDescription = "新建标签", tint = CinnabarRed)
                    }
                    IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "完成", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Tabs Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(8.dp))
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.weight(1f).testTag("tab_search_input"),
                    textStyle = TextStyle(fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface),
                    singleLine = true,
                    cursorBrush = SolidColor(CinnabarRed),
                    decorationBox = { inner ->
                        if (searchQuery.isEmpty()) {
                            Text("搜索已打开的标签页……", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                        }
                        inner()
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tab Groups Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GroupChip("全部", isSelected = selectedFilterGroup == null, onClick = { selectedFilterGroup = null })
                GroupChip("工作", isSelected = selectedFilterGroup == "工作", tagColor = Color(0xFF41677A), onClick = { selectedFilterGroup = "工作" })
                GroupChip("阅读", isSelected = selectedFilterGroup == "阅读", tagColor = Color(0xFF3F6B5B), onClick = { selectedFilterGroup = "阅读" })
                GroupChip("开发", isSelected = selectedFilterGroup == "开发", tagColor = Color(0xFFB83A32), onClick = { selectedFilterGroup = "开发" })
                GroupChip("金融", isSelected = selectedFilterGroup == "金融", tagColor = Color(0xFF8A6428), onClick = { selectedFilterGroup = "金融" })
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Grid of Tabs
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredTabs, key = { it.id }) { tab ->
                    val isActive = tab.id == activeTabId
                    TabGridCard(
                        tab = tab,
                        isActive = isActive,
                        onSelect = { onSelectTab(tab.id); onClose() },
                        onClose = { onCloseTab(tab.id) },
                        onSuspend = { onSuspendTab(tab.id) },
                        onSetGroup = { tag, color -> onSetTabGroup(tab.id, tag, color) }
                    )
                }
            }

            // Bottom Actions (Restore Closed Tab)
            if (recentlyClosed.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "最近关闭：${recentlyClosed.first().title}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(onClick = onRestoreClosed) {
                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("恢复最近关闭", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupChip(
    title: String,
    isSelected: Boolean,
    tagColor: Color? = null,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
            .border(
                1.dp,
                if (isSelected) CinnabarRed else MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(4.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (tagColor != null) {
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(tagColor))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun TabGridCard(
    tab: BrowserTab,
    isActive: Boolean,
    onSelect: () -> Unit,
    onClose: () -> Unit,
    onSuspend: () -> Unit,
    onSetGroup: (String?, Long?) -> Unit
) {
    Column(
        modifier = Modifier
            .height(130.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                width = if (isActive) 1.5.dp else 1.dp,
                color = if (isActive) CinnabarRed else MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onSelect() }
            .padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                if (tab.groupColor != null) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(tab.groupColor)))
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = tab.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(20.dp)) {
                Icon(Icons.Default.Close, contentDescription = "关闭", modifier = Modifier.size(12.dp))
            }
        }

        // URL subtitle & memory status
        Column {
            Text(
                text = tab.url,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (tab.isSuspended) "已休眠 (12MB)" else "内存: ${tab.memoryUsageMb}MB · CPU: ${(tab.cpuUsagePercent * 100).toInt()}%",
                style = MaterialTheme.typography.labelSmall,
                color = if (tab.isSuspended) MutedGreen else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }

        // Card actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (tab.isSuspended) "休眠中" else "活跃",
                style = MaterialTheme.typography.labelSmall,
                color = if (tab.isSuspended) MutedGreen else CinnabarRed
            )
            if (!tab.isSuspended) {
                Text(
                    text = "休眠省电",
                    style = MaterialTheme.typography.labelSmall,
                    color = SubduedBlue,
                    modifier = Modifier.clickable { onSuspend() }
                )
            }
        }
    }
}
