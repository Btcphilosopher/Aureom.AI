package com.example.ui.webview

import com.example.data.model.ReaderArticle

object BuiltInWebPages {

    fun getSimulatedArticle(url: String): ReaderArticle {
        return when {
            url.contains("zhihu.com") -> ReaderArticle(
                title = "如何评价新一代现代计算架构与极简浏览器设计？",
                author = "知乎专栏 · 计算美学与软件工程",
                publishDate = "2026-10-06",
                readingTimeMinutes = 5,
                wordCount = 1840,
                siteName = "知乎",
                originalUrl = url,
                paragraphs = listOf(
                    "在过去的二十年里，浏览器的界面设计经历了一场从繁复工具栏到“内容即界面”的深刻演进。随着屏幕分辨率的飞跃和信息密度的激增，现代知识工作者对专注度的渴望达到了前所未有的高度。",
                    "清简浏览器的核心理念正是：『浏览器应该尽可能消失，让网页成为计算机的主要内容。』这并非简单的视觉删减，而是深度的功能优先主义（Minimalism as Function）。",
                    "在系统级资源分配上，多标签页管理采用了基于渲染进程生命周期的智能休眠机制。当后台标签闲置超过指定阈值时，自动压缩内存占用达80%以上，同时保留完整的DOM状态树以便瞬间无缝唤醒。",
                    "在中文排版方面，现代网页长期面临字偶间距失衡与段落呼吸感不足的问题。通过重新校准 CJK 字形度量、正文行高（1.8x）与自适应留白，真正让中文阅读回归印刷时代的温润质感。",
                    "结合端侧与云端双核 AI 架构，用户能够在毫无侵入感的指令栏中唤起深度研读助手，完成跨标签观点聚类、结构化表格提取与中英学术级双语对照，实现了工具与思想的高效共振。"
                )
            )
            url.contains("36kr.com") -> ReaderArticle(
                title = "2027 中国人工智能产业链与算力基础设施发展白皮书",
                author = "36氪研究院 · 深度前瞻",
                publishDate = "2026-10-05",
                readingTimeMinutes = 7,
                wordCount = 2600,
                siteName = "36氪",
                originalUrl = url,
                paragraphs = listOf(
                    "根据最新产业调研数据，中国在新一代生成式 AI 基础设施、端侧大模型推理框架以及垂直行业计算平台的总投资规模已突破万亿元大关。",
                    "在芯片与编译器协同层，国产硬件生态正在从单纯的浮点峰值竞争，转向低延迟显存带宽与片上互联拓扑的综合能效比竞赛。全栈式异构计算正在工业制造、金融风控与生命科学领域规模化落地。",
                    "核心指标统计显示：核心算力中心平均 PUE 降至 1.15 以下，大模型单卡微调能耗较上一代降低 42%，推理吞吐效率提升 3.4 倍。",
                    "与此同时，端侧设备如智能汽车座舱、轻量化智能终端与企业级工作站的算力下沉趋势显著，推动着隐私计算与离线推理成为下一阶段的刚性需求。"
                )
            )
            url.contains("arxiv.org") -> ReaderArticle(
                title = "Next-Generation Browser Architectures: Process Isolation and Cognitive AI Layer",
                author = "T. Zhang, H. Chen, K. Vance et al.",
                publishDate = "2026-09-28",
                readingTimeMinutes = 6,
                wordCount = 2100,
                siteName = "arXiv.org",
                originalUrl = url,
                paragraphs = listOf(
                    "Modern web browsers act as universal operating systems for human-computer interaction. However, monolithic tab implementations and bloated chrome interfaces introduce significant cognitive load and memory overhead.",
                    "We introduce a decoupled architecture combining lightweight sandboxed renderer processes with an on-demand semantic synthesis layer.",
                    "Empirical evaluations across 10,000 top enterprise and knowledge domains demonstrate a 63% reduction in cold startup latency and an 82% decrease in idle tab memory footprint.",
                    "Furthermore, the integrated bilingual translation pipeline preserves technical terminology fidelity while enhancing reading speed by 41% compared to traditional whole-page DOM replacements."
                )
            )
            url.contains("github.com") -> ReaderArticle(
                title = "Qingjian Engine: High Performance Native Web Runtime",
                author = "GitHub Trending · Open Source Core",
                publishDate = "2026-10-01",
                readingTimeMinutes = 4,
                wordCount = 1450,
                siteName = "GitHub",
                originalUrl = url,
                paragraphs = listOf(
                    "Qingjian Engine is a next-generation lightweight web runtime crafted in modern Rust and Kotlin with zero-telemetry and process isolation.",
                    "Features include zero-overhead tab swapping, instant Universal Command Bar, hardware-accelerated CJK font rendering, and secure sandboxing.",
                    "Build instructions: clone the repository, run `cargo check` and deploy via native Android Jetpack Compose shell bindings."
                )
            )
            else -> ReaderArticle(
                title = "清简视界 · 纯净网页阅读与探索",
                author = "清简浏览器内容引擎",
                publishDate = "2026-10-06",
                readingTimeMinutes = 3,
                wordCount = 890,
                siteName = "清简网络",
                originalUrl = url,
                paragraphs = listOf(
                    "欢迎访问 $url。清简浏览器正在为您提供安全、高速、无干扰的沉浸式浏览体验。",
                    "所有网络数据均通过沙箱隔离传输，内置智能防跟踪保护机制与内容纯净提取引擎。",
                    "您可以随时使用顶部指令栏输入新网址、搜索关键词，或点击 AI 按钮开启深度研读与速览。"
                )
            )
        }
    }

    fun getSampleHtml(url: String, title: String): String {
        val isZhihu = url.contains("zhihu.com")
        val is36Kr = url.contains("36kr.com")
        val isArxiv = url.contains("arxiv.org")
        val isGithub = url.contains("github.com")

        return """
            <!DOCTYPE html>
            <html lang="zh-CN">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>$title</title>
                <style>
                    :root {
                        --bg: #FBFBF9;
                        --text: #1E2120;
                        --muted: #5F6562;
                        --card: #F4F5F3;
                        --border: #D6DAD7;
                        --accent: #B83A32;
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg: #151817;
                            --text: #EAECEA;
                            --muted: #8E9491;
                            --card: #1E2221;
                            --border: #373E3B;
                            --accent: #D8554D;
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Noto Sans CJK SC", "Microsoft YaHei", sans-serif;
                        background-color: var(--bg);
                        color: var(--text);
                        margin: 0;
                        padding: 24px 20px 80px 20px;
                        line-height: 1.8;
                        font-size: 16px;
                    }
                    .container {
                        max-width: 720px;
                        margin: 0 auto;
                    }
                    .site-badge {
                        display: inline-block;
                        font-size: 12px;
                        color: var(--accent);
                        background: rgba(184, 58, 50, 0.08);
                        padding: 3px 8px;
                        border-radius: 4px;
                        margin-bottom: 12px;
                        font-weight: 500;
                    }
                    h1 {
                        font-size: 24px;
                        line-height: 1.35;
                        margin-top: 0;
                        margin-bottom: 12px;
                        font-weight: 600;
                    }
                    .meta {
                        color: var(--muted);
                        font-size: 13px;
                        margin-bottom: 24px;
                        padding-bottom: 16px;
                        border-bottom: 1px solid var(--border);
                    }
                    p {
                        margin-bottom: 18px;
                        text-align: justify;
                    }
                    .stat-box {
                        background: var(--card);
                        border: 1px solid var(--border);
                        border-radius: 8px;
                        padding: 16px;
                        margin: 20px 0;
                    }
                    .stat-grid {
                        display: grid;
                        grid-template-columns: repeat(3, 1fr);
                        gap: 12px;
                        text-align: center;
                    }
                    .stat-val {
                        font-size: 20px;
                        font-weight: 600;
                        color: var(--accent);
                    }
                    .stat-label {
                        font-size: 12px;
                        color: var(--muted);
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin: 20px 0;
                        font-size: 14px;
                    }
                    th, td {
                        border: 1px solid var(--border);
                        padding: 8px 12px;
                        text-align: left;
                    }
                    th {
                        background-color: var(--card);
                        font-weight: 600;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <span class="site-badge">${if (isZhihu) "知乎深度" else if (is36Kr) "36氪快讯" else if (isArxiv) "arXiv e-Print" else if (isGithub) "GitHub Trending" else "清简视界"}</span>
                    <h1>$title</h1>
                    <div class="meta">
                        作者：${if (isZhihu) "专栏作者" else if (is36Kr) "36Kr 财经科技团队" else if (isArxiv) "Research Team" else "Qingjian Engine"} · 发布于 2026-10-06 · 来源：$url
                    </div>
                    
                    <p>在当代数字化与知识密集型工作环境中，信息的流动速度与密度达到了历史新高。面对庞杂的网页结构与广告干扰，回归内容本身成为了最高效的生产力选择。</p>
                    
                    <div class="stat-box">
                        <div class="stat-grid">
                            <div>
                                <div class="stat-val">99.8%</div>
                                <div class="stat-label">防追踪拦截率</div>
                            </div>
                            <div>
                                <div class="stat-val">1.2 s</div>
                                <div class="stat-label">页面解析延迟</div>
                            </div>
                            <div>
                                <div class="stat-val">85 MB</div>
                                <div class="stat-label">平均沙箱内存</div>
                            </div>
                        </div>
                    </div>

                    <p>核心技术突破包括了轻量化沙箱隔离、多标签零损耗休眠机制、以及深度嵌入的语义问答助手。通过将繁琐的操作简化为统一的指令栏交互，使用户能随时完成检索、计算、翻译与深度多页对比。</p>

                    <h3>关键数据对比</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>对比维度</th>
                                <th>传统浏览器</th>
                                <th>清简原生架构</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>冷启动速度</td>
                                <td>2.8s ~ 4.5s</td>
                                <td>&lt; 0.9s (极速启动)</td>
                            </tr>
                            <tr>
                                <td>后台标签内存占用</td>
                                <td>~240 MB / 标签</td>
                                <td>~45 MB / 标签 (智能休眠)</td>
                            </tr>
                            <tr>
                                <td>中文排版阅读</td>
                                <td>未经调校，易疲劳</td>
                                <td>专有 1.8x 呼吸感排版</td>
                            </tr>
                            <tr>
                                <td>AI 深度辅助</td>
                                <td>外挂插件，卡顿</td>
                                <td>系统级 Universal Bar</td>
                            </tr>
                        </tbody>
                    </table>

                    <p>通过持续精简视觉噪音，让用户的每一次点击和每一次输入都聚焦于真正关键的思考与创造之中。</p>
                </div>
            </body>
            </html>
        """.trimIndent()
    }
}
