package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Warm Palette (Light Graphite / Warm White / Pale Grey)
val WarmWhite = Color(0xFFFBFBF9)
val PaleGreyBg = Color(0xFFF4F5F3)
val PaleGreySurface = Color(0xFFECEEEB)
val LightGraphiteSurfaceVar = Color(0xFFE2E5E1)
val PaleBorder = Color(0xFFD6DAD7)
val PaleBorderSubtle = Color(0xFFE3E6E4)

// Ink Text Palette
val InkGraphitePrimary = Color(0xFF1E2120)
val InkGraphiteSecondary = Color(0xFF383C3A)
val InkGraphiteMuted = Color(0xFF5F6562)
val InkGraphiteFaint = Color(0xFF8B928E)

// Restrained Accents
val CinnabarRed = Color(0xFFB83A32)      // Primary action, loading line, notification
val CinnabarRedLight = Color(0xFFD8554D)
val CinnabarRedBg = Color(0xFFFBEBEA)
val CinnabarRedBorder = Color(0xFFF3C7C4)

val MutedGreen = Color(0xFF3F6B5B)       // SSL / Security safe
val MutedGreenBg = Color(0xFFEBF3F0)
val SubduedBlue = Color(0xFF41677A)      // Link / info
val SubduedBlueBg = Color(0xFFEAF0F4)
val SubduedAmber = Color(0xFF8A6428)     // Caution
val SubduedAmberBg = Color(0xFFF8F2E8)

// Dark Graphite Palette (Warm Dark / Incognito Mode)
val DarkGraphiteBg = Color(0xFF151817)
val DarkGraphiteSurface = Color(0xFF1E2221)
val DarkGraphiteSurfaceVar = Color(0xFF292E2C)
val DarkGraphiteBorder = Color(0xFF373E3B)
val DarkGraphiteTextPrimary = Color(0xFFEAECEA)
val DarkGraphiteTextSecondary = Color(0xFFB4B9B6)
val DarkGraphiteTextMuted = Color(0xFF7E8682)
