package com.example.ui.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReaderArticle
import com.example.ui.theme.CinnabarRed

@Composable
fun ReaderModeSheet(
    article: ReaderArticle?,
    fontSizeSp: Int,
    onFontSizeChange: (Int) -> Unit,
    lineHeightMultiplier: Float,
    onLineHeightChange: (Float) -> Unit,
    columnWidthDp: Int,
    onColumnWidthChange: (Int) -> Unit,
    themeName: String,
    onThemeChange: (String) -> Unit,
    isSpeaking: Boolean,
    onToggleSpeech: () -> Unit,
    isBilingual: Boolean,
    onToggleBilingual: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showTypeControls by remember { mutableStateOf(false) }

    // Theme color sets for reading
    val (readerBg, readerTextColor, readerMutedColor) = when (themeName) {
        "羊皮纸暖黄" -> Triple(Color(0xFFF7F3E8), Color(0xFF2C2723), Color(0xFF6E645A))
        "水墨淡白" -> Triple(Color(0xFFF9F9F8), Color(0xFF1E2120), Color(0xFF5F6562))
        "墨黑夜读" -> Triple(Color(0xFF181B1A), Color(0xFFE5E7E6), Color(0xFF888F8C))
        "苍青护眼" -> Triple(Color(0xFFEAF2EE), Color(0xFF1C2823), Color(0xFF4C665C))
        else -> Triple(Color(0xFFF9F9F8), Color(0xFF1E2120), Color(0xFF5F6562))
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(readerBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Reader Control Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(readerBg)
                    .border(1.dp, readerMutedColor.copy(alpha = 0.15f))
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "退出阅读模式",
                            modifier = Modifier.size(18.dp),
                            tint = readerTextColor
                        )
                    }

                    Text(
                        text = "清简原生阅读模式",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        color = readerTextColor
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Typography settings toggle
                    IconButton(
                        onClick = { showTypeControls = !showTypeControls },
                        modifier = Modifier.size(32.dp).testTag("reader_type_controls_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FormatSize,
                            contentDescription = "字体与排版设置",
                            modifier = Modifier.size(18.dp),
                            tint = readerTextColor
                        )
                    }

                    // TTS Speech
                    IconButton(
                        onClick = onToggleSpeech,
                        modifier = Modifier.size(32.dp).testTag("reader_tts_button")
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.Pause else Icons.Default.VolumeUp,
                            contentDescription = "朗读全文",
                            modifier = Modifier.size(18.dp),
                            tint = if (isSpeaking) CinnabarRed else readerTextColor
                        )
                    }

                    // Bilingual toggle
                    IconButton(
                        onClick = onToggleBilingual,
                        modifier = Modifier.size(32.dp).testTag("reader_bilingual_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "中英双语对照",
                            modifier = Modifier.size(18.dp),
                            tint = if (isBilingual) CinnabarRed else readerTextColor
                        )
                    }
                }
            }

            // Typography Controls Tray
            if (showTypeControls) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(readerBg)
                        .border(1.dp, readerMutedColor.copy(alpha = 0.15f))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Theme color circles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("背景色调", style = MaterialTheme.typography.bodySmall, color = readerMutedColor)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("羊皮纸暖黄", "水墨淡白", "墨黑夜读", "苍青护眼").forEach { name ->
                                val swatchColor = when (name) {
                                    "羊皮纸暖黄" -> Color(0xFFF7F3E8)
                                    "水墨淡白" -> Color(0xFFF9F9F8)
                                    "墨黑夜读" -> Color(0xFF181B1A)
                                    "苍青护眼" -> Color(0xFFEAF2EE)
                                    else -> Color.White
                                }
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(swatchColor)
                                        .border(
                                            width = if (themeName == name) 2.dp else 1.dp,
                                            color = if (themeName == name) CinnabarRed else readerMutedColor.copy(alpha = 0.3f),
                                            shape = CircleShape
                                        )
                                        .clickable { onThemeChange(name) }
                                )
                            }
                        }
                    }

                    // Font size slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("字号 (${fontSizeSp}sp)", style = MaterialTheme.typography.bodySmall, color = readerMutedColor, modifier = Modifier.width(90.dp))
                        Slider(
                            value = fontSizeSp.toFloat(),
                            onValueChange = { onFontSizeChange(it.toInt()) },
                            valueRange = 14f..24f,
                            steps = 5,
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(thumbColor = CinnabarRed, activeTrackColor = CinnabarRed)
                        )
                    }

                    // Line height selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("行距倍率", style = MaterialTheme.typography.bodySmall, color = readerMutedColor)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1.5f, 1.8f, 2.2f).forEach { h ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (lineHeightMultiplier == h) CinnabarRed else readerMutedColor.copy(alpha = 0.1f))
                                        .clickable { onLineHeightChange(h) }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${h}x",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (lineHeightMultiplier == h) Color.White else readerTextColor
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Article Content Flow
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = columnWidthDp.dp)
                        .padding(horizontal = 24.dp, vertical = 32.dp)
                ) {
                    if (article == null) {
                        Text(
                            text = "正在从当前页面提取正文与排版结构……",
                            style = MaterialTheme.typography.bodyMedium,
                            color = readerMutedColor
                        )
                    } else {
                        // Title
                        Text(
                            text = article.title,
                            fontSize = (fontSizeSp + 8).sp,
                            lineHeight = (fontSizeSp + 16).sp,
                            fontWeight = FontWeight.SemiBold,
                            color = readerTextColor
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Metadata
                        Text(
                            text = "${article.author ?: "专栏"} · ${article.publishDate ?: "今天"} · 预计阅读 ${article.readingTimeMinutes} 分钟 · 共 ${article.wordCount} 字",
                            fontSize = 12.sp,
                            color = readerMutedColor
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                        HorizontalDivider(color = readerMutedColor.copy(alpha = 0.2f), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(24.dp))

                        // Paragraphs
                        article.paragraphs.forEach { p ->
                            Text(
                                text = p,
                                fontSize = fontSizeSp.sp,
                                lineHeight = (fontSizeSp * lineHeightMultiplier).sp,
                                color = readerTextColor,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier.padding(bottom = (fontSizeSp * 0.9f).dp)
                            )

                            // Bilingual English sentence breakdown if enabled
                            if (isBilingual) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(readerMutedColor.copy(alpha = 0.06f))
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .padding(bottom = 12.dp)
                                ) {
                                    Text(
                                        text = "EN Context: Parallel semantic alignment preserving terminology precision.",
                                        fontSize = (fontSizeSp - 2).sp,
                                        color = readerMutedColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
