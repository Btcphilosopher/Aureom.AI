package com.example.ui.translation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CinnabarRed

@Composable
fun TranslationDialog(
    currentUrl: String,
    onApplyTranslation: (mode: String, from: String, to: String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var sourceLang by remember { mutableStateOf("English (英语)") }
    var targetLang by remember { mutableStateOf("简体中文 (Chinese)") }
    var translationMode by remember { mutableStateOf("bilingual") } // "bilingual", "fullpage", "selection"
    var showSourceMenu by remember { mutableStateOf(false) }
    var showTargetMenu by remember { mutableStateOf(false) }

    val languages = listOf("English (英语)", "简体中文 (Chinese)", "日本語 (Japanese)", "한국어 (Korean)", "Français (法语)", "Deutsch (德语)", "Español (西班牙语)")

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = null,
                        tint = CinnabarRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "清简网页翻译与对照阅读",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "关闭", modifier = Modifier.size(16.dp))
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Language Selector Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Source Language
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { showSourceMenu = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text(sourceLang, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    DropdownMenu(expanded = showSourceMenu, onDismissRequest = { showSourceMenu = false }) {
                        languages.forEach { l ->
                            DropdownMenuItem(text = { Text(l) }, onClick = { sourceLang = l; showSourceMenu = false })
                        }
                    }
                }

                IconButton(
                    onClick = {
                        val temp = sourceLang
                        sourceLang = targetLang
                        targetLang = temp
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = "切换语言", modifier = Modifier.size(18.dp))
                }

                // Target Language
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { showTargetMenu = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text(targetLang, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    DropdownMenu(expanded = showTargetMenu, onDismissRequest = { showTargetMenu = false }) {
                        languages.forEach { l ->
                            DropdownMenuItem(text = { Text(l) }, onClick = { targetLang = l; showTargetMenu = false })
                        }
                    }
                }
            }

            // Mode Selector
            Text("翻译呈现模式：", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ModeRadioItem(
                    title = "双语逐句对照阅读",
                    subtitle = "原文下方显示精确中文释义，保留排版与技术术语",
                    selected = translationMode == "bilingual",
                    onClick = { translationMode = "bilingual" }
                )
                ModeRadioItem(
                    title = "整页无缝翻译",
                    subtitle = "将整个网页正文替换为目标语言",
                    selected = translationMode == "fullpage",
                    onClick = { translationMode = "fullpage" }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Action Button
            Button(
                onClick = {
                    onApplyTranslation(translationMode, sourceLang, targetLang)
                    onClose()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CinnabarRed),
                modifier = Modifier.fillMaxWidth().testTag("apply_translation_button")
            ) {
                Text("开始翻译当前页面")
            }
        }
    }
}

@Composable
private fun ModeRadioItem(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
            .border(
                1.dp,
                if (selected) CinnabarRed else MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = CinnabarRed)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
