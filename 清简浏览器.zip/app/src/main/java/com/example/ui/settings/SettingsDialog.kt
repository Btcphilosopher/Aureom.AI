package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchEngine
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.MutedGreen

@Composable
fun SettingsDialog(
    currentSearchEngine: SearchEngine,
    availableEngines: List<SearchEngine>,
    onSelectEngine: (SearchEngine) -> Unit,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    trackingProtection: Boolean,
    onToggleTrackingProtection: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(0) }
    val categories = listOf("常规", "外观", "搜索引擎", "标签管理", "隐私安全", "AI 引擎", "快捷键", "关于清简")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = CinnabarRed, modifier = Modifier.size(20.dp))
                    Text(
                        text = "清简浏览器设置",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "关闭", modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Navigation Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories.indices.toList()) { idx ->
                    val isSelected = selectedCategory == idx
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
                            .border(1.dp, if (isSelected) CinnabarRed else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp))
                            .clickable { selectedCategory = idx }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = categories[idx],
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(16.dp))

            // Category Body
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                when (selectedCategory) {
                    0 -> GeneralSettingsView()
                    1 -> AppearanceSettingsView(isDarkMode, onToggleDarkMode)
                    2 -> SearchSettingsView(currentSearchEngine, availableEngines, onSelectEngine)
                    3 -> TabsSettingsView()
                    4 -> PrivacySettingsView(trackingProtection, onToggleTrackingProtection)
                    5 -> AiEngineSettingsView()
                    6 -> ShortcutsSettingsView()
                    7 -> AboutQingjianView()
                }
            }
        }
    }
}

@Composable
private fun GeneralSettingsView() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("启动与常规", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        SettingItemRow("启动时打开", "新建空白标签页 (清简极简主页)")
        SettingItemRow("主页按钮行为", "导航至清简主页")
        SettingItemRow("默认下载目录", "内部安全沙箱 /Downloads")
    }
}

@Composable
private fun AppearanceSettingsView(isDarkMode: Boolean, onToggleDarkMode: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("外观与排版美学", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("深色与石墨灰模式", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text("切换至暖黑/石墨低对比度深色模式", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
                checked = isDarkMode,
                onCheckedChange = { onToggleDarkMode() },
                colors = SwitchDefaults.colors(checkedThumbColor = CinnabarRed, checkedTrackColor = CinnabarRed.copy(alpha = 0.5f))
            )
        }
        SettingItemRow("中文排版字偶校准", "已开启（针对 CJK 思源黑体/宋体优化）")
    }
}

@Composable
private fun SearchSettingsView(
    current: SearchEngine,
    available: List<SearchEngine>,
    onSelect: (SearchEngine) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("默认搜索引擎选择", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        available.forEach { engine ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, if (current.id == engine.id) CinnabarRed else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp))
                    .clickable { onSelect(engine) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = current.id == engine.id,
                    onClick = { onSelect(engine) },
                    colors = RadioButtonDefaults.colors(selectedColor = CinnabarRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(engine.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    Text(engine.searchUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun TabsSettingsView() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("标签页与进程调度", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        SettingItemRow("智能休眠阈值", "闲置 10 分钟自动休眠（释放 80% 内存）")
        SettingItemRow("标签页多进程隔离", "每个顶级标签分配独立渲染进程沙箱")
        SettingItemRow("关闭标签确认", "仅当存在未保存表单时提示")
    }
}

@Composable
private fun PrivacySettingsView(tracking: Boolean, onToggle: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("隐私与遥测承诺", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("智能反追踪与反指纹探测", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text("杜绝广告商通过 Canvas/字体指纹追踪用户", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = tracking, onCheckedChange = { onToggle() })
        }
        SettingItemRow("零遥测承诺", "清简浏览器不收集、不上传任何浏览行为与搜索关键词")
    }
}

@Composable
private fun AiEngineSettingsView() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("AI 清简引擎架构", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        SettingItemRow("模型后端", "端云混合语义合成引擎 (Gemini 3.7 Native Integration)")
        SettingItemRow("事实引述验证", "严格附带当前网页段落锚点与出处核验")
    }
}

@Composable
private fun ShortcutsSettingsView() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("快捷键与指令速查", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        ShortcutRow("Ctrl + L", "定位并聚焦通用指令栏")
        ShortcutRow("Ctrl + T", "新建空白标签页")
        ShortcutRow("Ctrl + W", "关闭当前标签页")
        ShortcutRow("Ctrl + Space", "唤出「问问清简」AI 研读面板")
        ShortcutRow("!新闻 <关键词>", "使用权威新闻源检索")
        ShortcutRow("!计算 238*19", "即时数学表达式计算")
        ShortcutRow("!翻译 <语句>", "即时中英双语对照翻译")
    }
}

@Composable
private fun AboutQingjianView() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("关于清简浏览器", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("版本：1.0.0 (Release 2027)\n架构：现代 Rust/Kotlin 原生渲染隔离沙箱\n设计哲学：Minimalism as Function（极简即功能）\n面向中文互联网与现代知识工作的全新计算软件。", style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text("© 2027 清简浏览器项目组 · 敬畏每一刻专注", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SettingItemRow(title: String, desc: String) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp)
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ShortcutRow(key: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surface).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(key, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontWeight = FontWeight.Bold, color = CinnabarRed, style = MaterialTheme.typography.bodySmall)
        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    }
}
