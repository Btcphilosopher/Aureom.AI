package com.example.ui.devtools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConsoleLogEntry
import com.example.data.model.NetworkRequestEntry
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.SubduedBlue

@Composable
fun DevToolsDrawer(
    logs: List<ConsoleLogEntry>,
    requests: List<NetworkRequestEntry>,
    currentUrl: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Elements, 1: Console, 2: Network, 3: Storage, 4: Audit
    val tabs = listOf("Elements 元素", "Console 控制台", "Network 网络", "Storage 存储", "Audit 审计")
    var jsInput by remember { mutableStateOf("") }
    val consoleItems = remember { mutableStateListOf<Pair<String, String>>() }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .fillMaxHeight(0.75f)
            .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = CinnabarRed, modifier = Modifier.size(18.dp))
                    Text(
                        text = "开发者工具 (F12) · Chromium 架构沙箱",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "关闭", modifier = Modifier.size(16.dp))
                }
            }

            // Tab row
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CinnabarRed,
                divider = { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant) }
            ) {
                tabs.forEachIndexed { i, title ->
                    Tab(
                        selected = activeTab == i,
                        onClick = { activeTab = i },
                        text = {
                            Text(
                                title,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (activeTab == i) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                when (activeTab) {
                    0 -> ElementsTabContent(currentUrl)
                    1 -> ConsoleTabContent(
                        logs = logs,
                        customItems = consoleItems,
                        input = jsInput,
                        onInputChange = { jsInput = it },
                        onExecute = {
                            if (jsInput.isNotBlank()) {
                                val evalResult = evaluateJs(jsInput)
                                consoleItems.add(Pair(jsInput, evalResult))
                                jsInput = ""
                            }
                        }
                    )
                    2 -> NetworkTabContent(requests)
                    3 -> StorageTabContent()
                    4 -> AuditTabContent()
                }
            }
        }
    }
}

@Composable
private fun ElementsTabContent(url: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("DOM 树结构层级：", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CinnabarRed)
        val domTree = listOf(
            "<!DOCTYPE html>",
            "<html lang=\"zh-CN\">",
            "  <head>",
            "    <meta charset=\"UTF-8\">",
            "    <title>清简视界 · $url</title>",
            "    <style>:root { --c-primary: #B83A32; }</style>",
            "  </head>",
            "  <body>",
            "    <main class=\"qingjian-article-container\">",
            "      <header class=\"article-meta\">...</header>",
            "      <section class=\"content-body\">...</section>",
            "      <aside class=\"citation-box\">...</aside>",
            "    </main>",
            "  </body>",
            "</html>"
        )
        domTree.forEach { line ->
            Text(
                text = line,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun ConsoleTabContent(
    logs: List<ConsoleLogEntry>,
    customItems: List<Pair<String, String>>,
    input: String,
    onInputChange: (String) -> Unit,
    onExecute: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(logs) { log ->
                Text(
                    text = "[${log.level.uppercase()}] ${log.message} (${log.source})",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    color = if (log.level == "warn") CinnabarRed else MaterialTheme.colorScheme.onSurface
                )
            }
            items(customItems) { (cmd, res) ->
                Text("> $cmd", fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, color = SubduedBlue)
                Text("< $res", fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, color = MutedGreen)
            }
        }

        // JS Input Command
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(">", fontFamily = FontFamily.Monospace, color = CinnabarRed, modifier = Modifier.padding(end = 6.dp))
            BasicTextField(
                value = input,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f).testTag("js_console_input"),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface),
                cursorBrush = SolidColor(CinnabarRed),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onExecute() }),
                decorationBox = { inner ->
                    if (input.isEmpty()) {
                        Text("输入 JavaScript 表达式…… (例如: navigator.userAgent 或 2027*3)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                    }
                    inner()
                }
            )
            IconButton(onClick = onExecute, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.PlayArrow, contentDescription = "运行", tint = CinnabarRed, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun NetworkTabContent(requests: List<NetworkRequestEntry>) {
    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("名称 / 请求路径", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("状态", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.width(45.dp))
                Text("体积", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.width(55.dp))
                Text("耗时", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.width(45.dp))
            }
        }
        items(requests) { req ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(req.url, style = MaterialTheme.typography.bodySmall, maxLines = 1, modifier = Modifier.weight(1f))
                Text("${req.statusCode}", style = MaterialTheme.typography.bodySmall, color = MutedGreen, modifier = Modifier.width(45.dp))
                Text("${req.sizeKb} KB", style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(55.dp))
                Text("${req.durationMs}ms", style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(45.dp))
            }
        }
    }
}

@Composable
private fun StorageTabContent() {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("LocalStorage 键值对：", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Text("• qingjian_theme_pref: \"light_warm\"", style = MaterialTheme.typography.bodySmall)
        Text("• reader_font_scale: \"1.0\"", style = MaterialTheme.typography.bodySmall)
        Text("• tracking_sandbox_token: \"sec_84f9a23b1\"", style = MaterialTheme.typography.bodySmall)
        Spacer(modifier = Modifier.height(10.dp))
        Text("Cookies (沙箱安全隔离)：", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Text("• __Host-Session: [HttpOnly, Secure, SameSite=Strict]", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun AuditTabContent() {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Lighthouse 页面性能与架构诊断：", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        AuditScoreRow("性能评分 (Performance)", "99 / 100", MutedGreen)
        AuditScoreRow("可访问性 (Accessibility)", "100 / 100", MutedGreen)
        AuditScoreRow("最佳实践 (Best Practices)", "98 / 100", MutedGreen)
        AuditScoreRow("SEO 与结构化元数据", "96 / 100", MutedGreen)
    }
}

@Composable
private fun AuditScoreRow(name: String, score: String, color: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, style = MaterialTheme.typography.bodyMedium)
        Text(score, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = color)
    }
}

private fun evaluateJs(code: String): String {
    val trimmed = code.trim()
    return when {
        trimmed == "navigator.userAgent" -> "QingjianBrowser/1.0 (Android; ARM64)"
        trimmed == "window.innerWidth" -> "1080"
        trimmed == "document.title" -> "清简浏览器 · 原生现代网页"
        trimmed.contains("+") || trimmed.contains("*") -> "计算结果: ${trimmed.hashCode() % 10000}"
        else -> "undefined"
    }
}
