package com.example.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.data.model.Bookmark
import com.example.ui.ai.QingjianAiPanel
import com.example.ui.bookmarks.BookmarksSheet
import com.example.ui.devtools.DevToolsDrawer
import com.example.ui.downloads.DownloadsSheet
import com.example.ui.history.HistorySheet
import com.example.ui.newtab.NewTabPage
import com.example.ui.performance.TaskManagerDialog
import com.example.ui.privacy.PrivacySecuritySheet
import com.example.ui.reader.ReaderModeSheet
import com.example.ui.settings.SettingsDialog
import com.example.ui.tabs.TabBar
import com.example.ui.tabs.TabOverviewDialog
import com.example.ui.translation.TranslationDialog
import com.example.ui.webview.BrowserEngineView
import com.example.viewmodel.ActiveOverlay
import com.example.viewmodel.BrowserViewModel

@Composable
fun BrowserShell(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val history by viewModel.history.collectAsState()
    val downloads by viewModel.downloads.collectAsState()

    val activeTab = uiState.tabs.find { it.id == uiState.activeTabId }
    val isBookmarked = bookmarks.any { it.url == activeTab?.url }

    // System BackHandler
    BackHandler(enabled = uiState.activeOverlay != ActiveOverlay.NONE || activeTab?.canGoBack == true) {
        if (uiState.activeOverlay != ActiveOverlay.NONE) {
            viewModel.setOverlay(ActiveOverlay.NONE)
        } else if (activeTab?.canGoBack == true) {
            // handle back
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Column {
                // Top Thin Tab Bar
                TabBar(
                    tabs = uiState.tabs,
                    activeTabId = uiState.activeTabId,
                    onTabClick = { viewModel.switchTab(it) },
                    onTabClose = { viewModel.closeTab(it) },
                    onNewTabClick = { viewModel.createNewTab() },
                    onOverviewClick = { viewModel.setOverlay(ActiveOverlay.TAB_OVERVIEW) },
                    onToggleDarkClick = { viewModel.toggleDarkMode() },
                    isDarkMode = uiState.isDarkMode
                )

                // Universal Omnibar / Navigation Bar
                TopCommandBar(
                    activeTab = activeTab,
                    commandText = uiState.commandBarText,
                    onCommandTextChange = { viewModel.updateCommandBarText(it) },
                    onSubmitCommand = { viewModel.navigateTo(it) },
                    canGoBack = activeTab?.canGoBack ?: false,
                    canGoForward = activeTab?.canGoForward ?: false,
                    onBackClick = { /* back */ },
                    onForwardClick = { /* forward */ },
                    onRefreshClick = {
                        activeTab?.let { viewModel.navigateTo(it.url) }
                    },
                    onHomeClick = { viewModel.navigateTo("qingjian://newtab") },
                    onToggleBookmark = { viewModel.toggleBookmarkCurrentPage() },
                    isBookmarked = isBookmarked,
                    onAiClick = { viewModel.triggerAiSummaryForCurrentPage() },
                    onReaderClick = { viewModel.toggleReaderMode() },
                    onTranslateClick = { viewModel.setOverlay(ActiveOverlay.TRANSLATION) },
                    onDevToolsClick = { viewModel.setOverlay(ActiveOverlay.DEV_TOOLS) },
                    onTaskManagerClick = { viewModel.setOverlay(ActiveOverlay.TASK_MANAGER) },
                    onPrivacyClick = { viewModel.setOverlay(ActiveOverlay.PRIVACY_CENTER) },
                    onBookmarksClick = { viewModel.setOverlay(ActiveOverlay.BOOKMARKS) },
                    onHistoryClick = { viewModel.setOverlay(ActiveOverlay.HISTORY) },
                    onDownloadsClick = { viewModel.setOverlay(ActiveOverlay.DOWNLOADS) },
                    onSettingsClick = { viewModel.setOverlay(ActiveOverlay.SETTINGS) },
                    searchSuggestions = uiState.searchSuggestions,
                    isOmnibarFocused = uiState.isOmnibarFocused,
                    onOmnibarFocusChange = { viewModel.setOmnibarFocused(it) },
                    siteSecurity = uiState.siteSecurityInfo
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Main Web View or New Tab Page
            if (activeTab != null) {
                if (activeTab.url == "qingjian://newtab" || activeTab.url.isEmpty()) {
                    NewTabPage(
                        defaultSearchEngine = uiState.defaultSearchEngine,
                        bookmarks = bookmarks,
                        history = history,
                        onNavigate = { viewModel.navigateTo(it) },
                        onOpenSearch = { viewModel.setOmnibarFocused(true) }
                    )
                } else {
                    BrowserEngineView(
                        tab = activeTab,
                        onProgressUpdate = { viewModel.onPageLoadProgress(it) },
                        onTitleReceived = { title, url -> viewModel.onPageTitleReceived(title, url) },
                        onNavigateUrl = { viewModel.navigateTo(it) },
                        onRecoverCrash = { viewModel.recoverCrashedTab(it) },
                        onCloseTab = { viewModel.closeTab(it) }
                    )
                }
            }

            // Overlays & Sheets
            when (uiState.activeOverlay) {
                ActiveOverlay.TAB_OVERVIEW -> {
                    TabOverviewDialog(
                        tabs = uiState.tabs,
                        activeTabId = uiState.activeTabId,
                        recentlyClosed = uiState.recentlyClosedTabs,
                        onSelectTab = { viewModel.switchTab(it) },
                        onCloseTab = { viewModel.closeTab(it) },
                        onNewTab = { viewModel.createNewTab(); viewModel.setOverlay(ActiveOverlay.NONE) },
                        onRestoreClosed = { viewModel.restoreRecentlyClosedTab() },
                        onSuspendTab = { viewModel.suspendTab(it) },
                        onSetTabGroup = { id, tag, color -> viewModel.setTabGroup(id, tag, color) },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.AI_PANEL -> {
                    QingjianAiPanel(
                        result = uiState.aiAnalysisResult,
                        openTabs = uiState.tabs,
                        selectedTabsForComparison = uiState.selectedTabsForAiComparison,
                        onToggleTabForComparison = { viewModel.toggleTabSelectionForAiComparison(it) },
                        onExecuteComparison = { viewModel.executeMultiTabAiComparison() },
                        onAskQuestion = { viewModel.askAiQuestion(it) },
                        onTriggerSummary = { viewModel.triggerAiSummaryForCurrentPage() },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
                ActiveOverlay.READER_MODE -> {
                    ReaderModeSheet(
                        article = uiState.readerArticle,
                        fontSizeSp = uiState.readerFontSizeSp,
                        onFontSizeChange = { viewModel.setReaderFontSize(it) },
                        lineHeightMultiplier = uiState.readerLineHeightMultiplier,
                        onLineHeightChange = { viewModel.setReaderLineHeight(it) },
                        columnWidthDp = uiState.readerMaxWidthDp,
                        onColumnWidthChange = { viewModel.setReaderMaxWidth(it) },
                        themeName = uiState.readerThemeName,
                        onThemeChange = { viewModel.setReaderTheme(it) },
                        isSpeaking = uiState.isReaderSpeaking,
                        onToggleSpeech = { viewModel.toggleReaderSpeech() },
                        isBilingual = uiState.isReaderBilingual,
                        onToggleBilingual = { viewModel.toggleReaderBilingual() },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.TRANSLATION -> {
                    TranslationDialog(
                        currentUrl = activeTab?.url ?: "",
                        onApplyTranslation = { mode, from, to ->
                            // apply translation
                            viewModel.toggleReaderBilingual()
                        },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.DEV_TOOLS -> {
                    DevToolsDrawer(
                        logs = uiState.devToolsLogs,
                        requests = uiState.devToolsRequests,
                        currentUrl = activeTab?.url ?: "",
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
                ActiveOverlay.TASK_MANAGER -> {
                    TaskManagerDialog(
                        tabs = uiState.tabs,
                        totalMemoryMb = uiState.totalMemoryUsageMb,
                        onSuspendTab = { viewModel.suspendTab(it) },
                        onCloseTab = { viewModel.closeTab(it) },
                        onSimulateCrash = { viewModel.simulateTabCrash(it) },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.PRIVACY_CENTER -> {
                    PrivacySecuritySheet(
                        siteSecurity = uiState.siteSecurityInfo,
                        permission = uiState.currentSitePermission,
                        trackingProtection = uiState.trackingProtectionEnabled,
                        onToggleTrackingProtection = { viewModel.toggleTrackingProtection() },
                        thirdPartyCookiesBlocked = uiState.thirdPartyCookiesBlocked,
                        onToggleCookiesBlocked = { viewModel.toggleThirdPartyCookies() },
                        onTogglePermission = { domain, perm -> viewModel.togglePermission(domain, perm) },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.BOOKMARKS -> {
                    BookmarksSheet(
                        bookmarks = bookmarks,
                        onSelectBookmark = { viewModel.navigateTo(it) },
                        onDeleteBookmark = { viewModel.deleteBookmark(it) },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.HISTORY -> {
                    HistorySheet(
                        history = history,
                        onSelectHistory = { viewModel.navigateTo(it) },
                        onDeleteHistory = { viewModel.deleteHistory(it) },
                        onClearAllHistory = { viewModel.clearAllHistory() },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.DOWNLOADS -> {
                    DownloadsSheet(
                        downloads = downloads,
                        onSimulateDownload = {
                            viewModel.simulateNewDownload("rust_engine_v1.0.tar.gz", 3_450_000)
                        },
                        onDeleteDownload = { viewModel.deleteDownload(it) },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.SETTINGS -> {
                    SettingsDialog(
                        currentSearchEngine = uiState.defaultSearchEngine,
                        availableEngines = uiState.availableSearchEngines,
                        onSelectEngine = { viewModel.setDefaultSearchEngine(it) },
                        isDarkMode = uiState.isDarkMode,
                        onToggleDarkMode = { viewModel.toggleDarkMode() },
                        trackingProtection = uiState.trackingProtectionEnabled,
                        onToggleTrackingProtection = { viewModel.toggleTrackingProtection() },
                        onClose = { viewModel.setOverlay(ActiveOverlay.NONE) }
                    )
                }
                ActiveOverlay.NONE -> {}
            }
        }
    }
}
