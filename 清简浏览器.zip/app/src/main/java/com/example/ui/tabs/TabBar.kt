package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrowserTab
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.DarkGraphiteBorder
import com.example.ui.theme.InkGraphiteMuted
import com.example.ui.theme.InkGraphitePrimary
import com.example.ui.theme.PaleBorder

@Composable
fun TabBar(
    tabs: List<BrowserTab>,
    activeTabId: String,
    onTabClick: (String) -> Unit,
    onTabClose: (String) -> Unit,
    onNewTabClick: () -> Unit,
    onOverviewClick: () -> Unit,
    onToggleDarkClick: () -> Unit,
    isDarkMode: Boolean,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Tab list horizontally scrollable
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(scrollState),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEach { tab ->
                val isActive = tab.id == activeTabId
                TabItem(
                    tab = tab,
                    isActive = isActive,
                    onClick = { onTabClick(tab.id) },
                    onClose = { onTabClose(tab.id) }
                )
            }

            // New Tab button
            IconButton(
                onClick = onNewTabClick,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("tab_new_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "新建标签页",
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Dark/Light toggle
        IconButton(
            onClick = onToggleDarkClick,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Nightlight,
                contentDescription = "切换深色模式",
                modifier = Modifier.size(16.dp),
                tint = if (isDarkMode) CinnabarRed else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Tab switcher overview button with counter
        IconButton(
            onClick = onOverviewClick,
            modifier = Modifier
                .size(32.dp)
                .testTag("tab_overview_button")
        ) {
            BadgedBox(
                badge = {
                    Badge(
                        containerColor = if (isDarkMode) DarkGraphiteBorder else PaleBorder,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ) {
                        Text(
                            text = "${tabs.size}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.GridView,
                    contentDescription = "标签页管理",
                    modifier = Modifier.size(17.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TabItem(
    tab: BrowserTab,
    isActive: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    val backgroundColor = when {
        isActive -> MaterialTheme.colorScheme.surfaceVariant
        else -> Color.Transparent
    }

    Box(
        modifier = Modifier
            .height(34.dp)
            .widthIn(min = 90.dp, max = 160.dp)
            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
            .background(backgroundColor)
            .clickable { onClick() }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (tab.isIncognito) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "无痕",
                            modifier = Modifier
                                .size(12.dp)
                                .padding(end = 4.dp),
                            tint = InkGraphiteMuted
                        )
                    }

                    if (tab.isPlayingAudio) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "播放音频",
                            modifier = Modifier
                                .size(12.dp)
                                .padding(end = 4.dp),
                            tint = CinnabarRed
                        )
                    }

                    // Tab Group dot indicator
                    if (tab.groupColor != null) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(tab.groupColor))
                                .padding(end = 4.dp)
                        )
                    }

                    Text(
                        text = if (tab.isSuspended) "💤 ${tab.title}" else tab.title,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = if (isActive) FontWeight.Medium else FontWeight.Normal,
                        color = if (isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Close tab button
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "关闭标签",
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (isActive) 0.8f else 0.4f)
                    )
                }
            }

            // Minimal active indicator line (Subtle Cinnabar Red / Graphite)
            if (isActive) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(CinnabarRed)
                )
            }
        }
    }
}
