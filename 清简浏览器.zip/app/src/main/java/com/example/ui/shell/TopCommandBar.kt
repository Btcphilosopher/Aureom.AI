package com.example.ui.shell

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.data.model.BrowserTab
import com.example.data.model.SearchSuggestion
import com.example.data.model.SecurityLevel
import com.example.data.model.SiteSecurityInfo
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.InkGraphiteMuted
import com.example.ui.theme.InkGraphitePrimary
import com.example.ui.theme.MutedGreen
import com.example.ui.theme.SubduedAmber
import com.example.ui.theme.SubduedBlue

@Composable
fun TopCommandBar(
    activeTab: BrowserTab?,
    commandText: String,
    onCommandTextChange: (String) -> Unit,
    onSubmitCommand: (String) -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBackClick: () -> Unit,
    onForwardClick: () -> Unit,
    onRefreshClick: () -> Unit,
    onHomeClick: () -> Unit,
    onToggleBookmark: () -> Unit,
    isBookmarked: Boolean,
    onAiClick: () -> Unit,
    onReaderClick: () -> Unit,
    onTranslateClick: () -> Unit,
    onDevToolsClick: () -> Unit,
    onTaskManagerClick: () -> Unit,
    onPrivacyClick: () -> Unit,
    onBookmarksClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onDownloadsClick: () -> Unit,
    onSettingsClick: () -> Unit,
    searchSuggestions: List<SearchSuggestion>,
    isOmnibarFocused: Boolean,
    onOmnibarFocusChange: (Boolean) -> Unit,
    siteSecurity: SiteSecurityInfo?,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var showMenu by remember { mutableStateOf(false) }
    var showSslDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Navigation and Universal Address Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Back button
            IconButton(
                onClick = onBackClick,
                enabled = canGoBack,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "后退",
                    modifier = Modifier.size(16.dp),
                    tint = if (canGoBack) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                )
            }

            // Forward button
            IconButton(
                onClick = onForwardClick,
                enabled = canGoForward,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_forward_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "前进",
                    modifier = Modifier.size(16.dp),
                    tint = if (canGoForward) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                )
            }

            // Refresh button
            IconButton(
                onClick = onRefreshClick,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_refresh_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "刷新",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            // Home button
            IconButton(
                onClick = onHomeClick,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("nav_home_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "主页",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Universal Command Bar (Address Bar)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(
                        width = 1.dp,
                        color = if (isOmnibarFocused) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // SSL Security Icon / Badge
                    val sslIconColor = when (siteSecurity?.securityLevel) {
                        SecurityLevel.SECURE -> MutedGreen
                        SecurityLevel.CAUTION -> SubduedAmber
                        else -> InkGraphiteMuted
                    }

                    Box(
                        modifier = Modifier
                            .clickable { showSslDialog = !showSslDialog }
                            .padding(end = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (siteSecurity?.securityLevel == SecurityLevel.CAUTION) Icons.Default.Warning else Icons.Default.Lock,
                            contentDescription = "安全状态",
                            modifier = Modifier.size(13.dp),
                            tint = sslIconColor
                        )
                    }

                    // Text Field
                    BasicTextField(
                        value = commandText,
                        onValueChange = onCommandTextChange,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { onOmnibarFocusChange(it.isFocused) }
                            .testTag("address_bar_input"),
                        textStyle = TextStyle(
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Normal
                        ),
                        singleLine = true,
                        cursorBrush = SolidColor(CinnabarRed),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(
                            onGo = {
                                focusManager.clearFocus()
                                onSubmitCommand(commandText)
                            }
                        ),
                        decorationBox = { innerTextField ->
                            if (commandText.isEmpty()) {
                                Text(
                                    text = "搜索或输入网址…… (支持 !新闻, !计算, !代码)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            innerTextField()
                        }
                    )

                    // Clear button if text not empty
                    if (commandText.isNotEmpty() && isOmnibarFocused) {
                        IconButton(
                            onClick = { onCommandTextChange("") },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "清除",
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Bookmark Star action
                    IconButton(
                        onClick = onToggleBookmark,
                        modifier = Modifier
                            .size(26.dp)
                            .testTag("bookmark_star_button")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "收藏",
                            modifier = Modifier.size(15.dp),
                            tint = if (isBookmarked) CinnabarRed else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Reader Mode action
                    IconButton(
                        onClick = onReaderClick,
                        modifier = Modifier
                            .size(26.dp)
                            .testTag("reader_mode_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "阅读模式",
                            modifier = Modifier.size(15.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // AI Assistant Button ("问问清简")
            Box(
                modifier = Modifier
                    .height(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onAiClick() }
                    .padding(horizontal = 8.dp)
                    .testTag("ai_assistant_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "问问清简",
                        modifier = Modifier.size(14.dp),
                        tint = CinnabarRed
                    )
                    Text(
                        text = "清简 AI",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Unified 3-dots Menu
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("main_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "菜单",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                ) {
                    DropdownMenuItem(
                        text = { Text("网页翻译与双语对照", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onTranslateClick() }
                    )
                    DropdownMenuItem(
                        text = { Text("收藏夹与标签", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onBookmarksClick() }
                    )
                    DropdownMenuItem(
                        text = { Text("历史记录", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onHistoryClick() }
                    )
                    DropdownMenuItem(
                        text = { Text("下载管理", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onDownloadsClick() }
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    DropdownMenuItem(
                        text = { Text("隐私与安全中心", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onPrivacyClick() }
                    )
                    DropdownMenuItem(
                        text = { Text("任务管理器与性能", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.Tab, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onTaskManagerClick() }
                    )
                    DropdownMenuItem(
                        text = { Text("开发者工具 (F12)", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = { Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        onClick = { showMenu = false; onDevToolsClick() }
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    DropdownMenuItem(
                        text = { Text("系统设置", style = MaterialTheme.typography.bodyMedium) },
                        onClick = { showMenu = false; onSettingsClick() }
                    )
                }
            }
        }

        // Web Loading Progress Bar
        if (activeTab?.isLoading == true) {
            LinearProgressIndicator(
                progress = { (activeTab.loadProgress / 100f).coerceIn(0.05f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = CinnabarRed,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        } else {
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant,
                thickness = 1.dp
            )
        }

        // Search Suggestions Floating Overlay
        AnimatedVisibility(
            visible = isOmnibarFocused && searchSuggestions.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .zIndex(10f)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    .padding(8.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(searchSuggestions) { suggestion ->
                        SearchSuggestionItem(
                            suggestion = suggestion,
                            onClick = {
                                focusManager.clearFocus()
                                when (suggestion) {
                                    is SearchSuggestion.SearchQuery -> onSubmitCommand(suggestion.query)
                                    is SearchSuggestion.DirectUrl -> onSubmitCommand(suggestion.url)
                                    is SearchSuggestion.HistoryItem -> onSubmitCommand(suggestion.url)
                                    is SearchSuggestion.BookmarkItem -> onSubmitCommand(suggestion.url)
                                    is SearchSuggestion.SwitchToTab -> onSubmitCommand(suggestion.url)
                                    is SearchSuggestion.CommandAction -> onSubmitCommand(suggestion.command)
                                    is SearchSuggestion.QuickCalc -> onSubmitCommand(suggestion.result)
                                    is SearchSuggestion.QuickTranslate -> onSubmitCommand(suggestion.translation)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchSuggestionItem(
    suggestion: SearchSuggestion,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val (icon, title, subtitle, badge) = when (suggestion) {
            is SearchSuggestion.SearchQuery -> Quad(Icons.Default.Search, suggestion.query, "使用 ${suggestion.engineName} 搜索", "搜索")
            is SearchSuggestion.DirectUrl -> Quad(Icons.Default.Lock, suggestion.title, suggestion.url, "网址")
            is SearchSuggestion.HistoryItem -> Quad(Icons.Default.History, suggestion.title, suggestion.url, "历史")
            is SearchSuggestion.BookmarkItem -> Quad(Icons.Default.Bookmark, suggestion.title, "${suggestion.tag} · ${suggestion.url}", "书签")
            is SearchSuggestion.SwitchToTab -> Quad(Icons.Default.Tab, suggestion.title, "切换至已打开标签页", "标签")
            is SearchSuggestion.CommandAction -> Quad(Icons.Default.AutoAwesome, suggestion.command, suggestion.description, "指令")
            is SearchSuggestion.QuickCalc -> Quad(Icons.Default.Calculate, suggestion.expression, "= ${suggestion.result}", "计算")
            is SearchSuggestion.QuickTranslate -> Quad(Icons.Default.Translate, suggestion.query, suggestion.translation, "翻译")
        }

        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = when (badge) {
                "指令", "计算" -> CinnabarRed
                "翻译" -> SubduedBlue
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
