package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val QingjianLightColorScheme = lightColorScheme(
    primary = CinnabarRed,
    onPrimary = WarmWhite,
    primaryContainer = CinnabarRedBg,
    onPrimaryContainer = CinnabarRed,
    secondary = SubduedBlue,
    onSecondary = WarmWhite,
    secondaryContainer = SubduedBlueBg,
    onSecondaryContainer = SubduedBlue,
    tertiary = MutedGreen,
    onTertiary = WarmWhite,
    tertiaryContainer = MutedGreenBg,
    onTertiaryContainer = MutedGreen,
    background = PaleGreyBg,
    onBackground = InkGraphitePrimary,
    surface = WarmWhite,
    onSurface = InkGraphitePrimary,
    surfaceVariant = PaleGreySurface,
    onSurfaceVariant = InkGraphiteSecondary,
    outline = PaleBorder,
    outlineVariant = PaleBorderSubtle
)

private val QingjianDarkColorScheme = darkColorScheme(
    primary = CinnabarRedLight,
    onPrimary = DarkGraphiteBg,
    primaryContainer = DarkGraphiteSurfaceVar,
    onPrimaryContainer = CinnabarRedLight,
    secondary = SubduedBlue,
    onSecondary = DarkGraphiteBg,
    secondaryContainer = DarkGraphiteSurfaceVar,
    onSecondaryContainer = DarkGraphiteTextPrimary,
    tertiary = MutedGreen,
    onTertiary = DarkGraphiteBg,
    tertiaryContainer = DarkGraphiteSurfaceVar,
    onTertiaryContainer = DarkGraphiteTextPrimary,
    background = DarkGraphiteBg,
    onBackground = DarkGraphiteTextPrimary,
    surface = DarkGraphiteSurface,
    onSurface = DarkGraphiteTextPrimary,
    surfaceVariant = DarkGraphiteSurfaceVar,
    onSurfaceVariant = DarkGraphiteTextSecondary,
    outline = DarkGraphiteBorder,
    outlineVariant = DarkGraphiteBorder
)

@Composable
fun QingjianTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) QingjianDarkColorScheme else QingjianLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.surface.toArgb()
            window.navigationBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
