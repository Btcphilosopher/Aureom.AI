# 清简浏览器视觉设计规范 (UI.md)

## 色彩规范 (Light Graphite / Warm White / Pale Grey)

- **基底暖白 (Warm White)**: `#FBFBF9`
- **浅灰背景 (Pale Grey)**: `#F4F5F3`
- **表面容器 (Surface)**: `#ECEEEB`
- **边框与分割 (Border)**: `#D6DAD7` / `#E3E6E4`
- **石墨文字 (Ink Graphite Primary)**: `#1E2120`
- **次要文字 (Secondary)**: `#383C3A` / `#5F6562`
- **克制朱红 (Cinnabar Red)**: `#B83A32`（仅用于状态指示、加载线与核心操作）
- **沉静青绿 (Muted Green)**: `#3F6B5B`（安全认证）
- **幽蓝标牌 (Subdued Blue)**: `#41677A`

## 排版原则
- 字体：Noto Sans CJK SC / 思源黑体，无衬线，现代精炼。
- 行高：正文 1.8x 呼吸感排版。
- 留白：大面积留白与清晰层级，让内容成为主角。
