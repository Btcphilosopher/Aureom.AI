# 清简浏览器系统架构说明 (ARCHITECTURE.md)

## 1. 分层架构概览

```text
Browser Core Architecture
┌────────────────────────────────────────────────────────┐
│ UI Shell (Jetpack Compose, M3 Minimalist Palette)      │
│  ├── TabBar (Desktop Horizontal Tab Strip)             │
│  ├── Universal Command Bar (Address / Search / Calc)   │
│  └── Overlays (AI Panel, Reader, DevTools, TaskMgr)    │
├────────────────────────────────────────────────────────┤
│ ViewModel & State Orchestration Layer                  │
│  ├── BrowserViewModel (MutableStateFlow, Coroutines)   │
│  └── Semantic AI Synthesis Adapter (Gemini / Heuristic)│
├────────────────────────────────────────────────────────┤
│ Rendering & Network Engine Layer                       │
│  ├── BrowserEngineView (WebView + Sandbox Bridge)      │
│  ├── Content Extractor & Reader Sanitizer              │
│  └── Process Lifecycle & Tab Suspension Controller     │
├────────────────────────────────────────────────────────┤
│ Persistence Layer (Room SQLite)                        │
│  ├── BookmarksDao & Entities                           │
│  ├── HistoryDao & Entities                             │
│  ├── DownloadsDao & Entities                           │
│  └── SitePermissionsDao & Entities                     │
└────────────────────────────────────────────────────────┘
```

## 2. 多进程渲染沙箱与崩溃恢复

1. **Renderer Process Isolation**：每个标签页独立绑定沙箱生命周期，单页崩溃不影响其他标签页。
2. **Smart Tab Hibernation**：后台闲置标签自动转入冷休眠状态，内存压缩率超 80%，点击瞬间恢复。
3. **Zero-Telemetry Principle**：所有数据存储于本地 SQLite，无后台遥测与行为追踪上报。
