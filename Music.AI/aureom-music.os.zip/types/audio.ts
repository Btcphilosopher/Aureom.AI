export type TrackType = 'audio' | 'midi' | 'synth' | 'drum' | 'sampler' | 'bus' | 'return';

export type ViewMode =
  | 'arrange'
  | 'mix'
  | 'synth'
  | 'sampler'
  | 'analysis'
  | 'generative'
  | 'mastering'
  | 'catalogue'
  | 'r-console';

export interface AudioClip {
  id: string;
  name: string;
  trackId: string;
  startBeat: number; // in beats (e.g. 0, 4, 8)
  lengthBeats: number;
  offsetBeats: number;
  gainDb: number;
  fadeInBeats: number;
  fadeOutBeats: number;
  isMuted: boolean;
  isReversed: boolean;
  pitchShiftSemitones: number;
  timeStretchRatio: number;
  color: string;
  bufferData?: Float32Array; // synthetic or loaded waveform
  pyramids?: WaveformPyramids;
  midiNotes?: MidiNote[];
}

export interface MidiNote {
  id: string;
  pitch: number; // 0-127 (e.g. 60 = C4)
  startBeat: number;
  durationBeats: number;
  velocity: number; // 0-127
}

export interface WaveformPyramids {
  scale1: Float32Array; // 1:1
  scale8: Float32Array; // 1:8 min/max
  scale64: Float32Array; // 1:64 min/max
  scale512: Float32Array; // 1:512 min/max
  scale4096: Float32Array; // 1:4096 min/max
}

export interface AutomationPoint {
  beat: number;
  value: number;
  curve: 'linear' | 'exponential' | 'bezier' | 'step';
}

export interface AutomationLane {
  id: string;
  parameter: 'volume' | 'pan' | 'filterCutoff' | 'filterRes' | 'sendReverb' | 'sendDelay' | 'drive';
  points: AutomationPoint[];
  enabled: boolean;
}

export interface Track {
  id: string;
  name: string;
  type: TrackType;
  color: string;
  volumeDb: number;
  pan: number; // -1 to +1
  isMuted: boolean;
  isSoloed: boolean;
  isArmed: boolean;
  sendReverbDb: number;
  sendDelayDb: number;
  outputBusId: string; // 'master' or bus ID
  clips: AudioClip[];
  automationLanes: AutomationLane[];
  synthPreset?: string;
  fxChain: FxPlugin[];
  activePeakLeft: number;
  activePeakRight: number;
}

export interface FxPlugin {
  id: string;
  type: 'eq5' | 'compressor' | 'saturation' | 'delay' | 'reverb' | 'bitcrusher' | 'transientShaper';
  name: string;
  enabled: boolean;
  params: Record<string, number>;
}

export interface SongSection {
  id: string;
  name: string; // 'INTRO' | 'VERSE' | 'CHORUS' | 'BRIDGE' | 'OUTRO' | custom
  startBar: number;
  lengthBars: number;
  color: string;
  confidence: number; // R analysis confidence
}

export interface ProjectState {
  id: string;
  name: string;
  version: string;
  bpm: number;
  timeSignature: [number, number]; // [4, 4]
  sampleRate: number; // 48000
  bitDepth: number; // 24
  bufferSize: number; // 128
  totalBars: number;
  loopStartBeat: number;
  loopEndBeat: number;
  isLooping: boolean;
  tracks: Track[];
  sections: SongSection[];
  masterVolumeDb: number;
  masterLimiterCeilingDb: number;
  masterLimiterThresholdDb: number;
}

// R Statistical & Musical Analysis Types
export interface SpectralMetrics {
  centroid: number; // Hz
  spread: number; // Hz
  skewness: number;
  kurtosis: number;
  rolloff85: number; // Hz
  rolloff95: number; // Hz
  flux: number;
  flatness: number; // 0 (tonal) to 1 (noise)
  contrast: number[]; // sub-band contrast values
  harmonicity: number; // 0 to 1
  inharmonicity: number; // 0 to 1
  frequencies: number[];
  magnitudes: number[];
  stftMatrix: number[][]; // time x freq for spectrogram
}

export interface RhythmProfile {
  estimatedBpm: number;
  confidence: number;
  beatPositions: number[]; // seconds
  downbeats: number[];
  onsetDensity: number; // onsets per second
  syncopationIndex: number; // 0-1
  swingFactor: number; // % (50% = straight, 66% = triplet)
  microtimingJitterMs: number; // average deviation in ms
  onsetCurve: number[];
}

export interface HarmonicProfile {
  estimatedKey: string;
  keyConfidence: number;
  alternativeKeys: { key: string; confidence: number }[];
  chromaVector: number[]; // 12 notes: C, C#, D, ... B
  chordProgression: { timeSeconds: number; bar: number; chord: string; confidence: number }[];
  harmonicRhythmDensity: number; // chords per bar
  scaleType: 'major' | 'minor' | 'dorian' | 'mixolydian' | 'aeolian' | 'lydian' | 'pentatonic';
}

export interface TimbreVector {
  spectralCentroid: number; // 0-1 normalized
  brightness: number; // 0-1
  roughness: number; // 0-1
  attackTimeMs: number;
  decayTimeMs: number;
  zeroCrossingRate: number;
  harmonicity: number; // 0-1
  dynamicRangeDb: number;
  noiseRatio: number; // 0-1
}

export interface MusicalDNA {
  tempo: number;
  key: string;
  loudnessLufs: number;
  dynamicRangeDr: number;
  spectralCentroidHz: number;
  spectralFlux: number;
  rhythmicDensity: number;
  harmonicComplexity: number;
  timbralWarmth: number;
  energyScore: number;
  sectionDensity: number;
  radarMetrics: { label: string; value: number }[];
}

export interface ArrangementDensityBar {
  bar: number;
  activeTracks: number;
  energy: number; // 0-100
  spectralDensity: number; // 0-100
  rhythmicDensity: number; // 0-100
  dynamicRange: number; // dB
  harmonicActivity: number; // 0-100
}

export interface MasteringMetrics {
  integratedLufs: number; // e.g. -14.2 LUFS
  shortTermLufs: number;
  momentaryLufs: number;
  truePeakDb: number; // e.g. -0.8 dBTP
  rmsLevelDb: number;
  crestFactorDb: number;
  dynamicRangeDr: number; // e.g. DR11
  stereoCorrelation: number; // -1.0 to +1.0
  stereoWidthPct: number; // 0% to 200%
  lowEndEnergyRatio: number; // sub 120Hz energy share
  goniometerPoints: { x: number; y: number }[];
}

export interface ReferenceComparison {
  trackName: string;
  refName: string;
  lufsDelta: number;
  centroidDeltaHz: number;
  dynamicRangeDelta: number;
  lowEndDeltaDb: number;
  spectralCurveDiff: { freq: number; deltaDb: number }[];
}

export interface CatalogueTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: number;
  genre: string;
  bpm: number;
  key: string;
  durationSeconds: number;
  loudnessLufs: number;
  dynamicRangeDr: number;
  spectralCentroid: number;
  rhythmicDensity: number;
  energy: number;
  harmonicComplexity: number;
  timbreVector: TimbreVector;
  musicalDna: MusicalDNA;
  format: 'WAV' | 'FLAC' | 'AIFF';
  provenanceDate: string;
}

export interface GenerativeParameters {
  seed: number;
  tempo: number;
  scale: string;
  density: number; // 0-100
  complexity: number; // 0-100
  repetition: number; // 0-100
  variation: number; // 0-100
  syncopation: number; // 0-100
  swing: number; // 50-75%
  polyrhythm: boolean;
  patternLengthBars: number;
  styleModel: 'markov' | 'probabilistic-phrase' | 'ngram-rhythm' | 'cellular-automata';
}

export interface ExperimentRun {
  id: string;
  experimentNumber: string;
  variableName: string;
  variableUnit: string;
  values: number[];
  results: {
    variableValue: number;
    spectralDensity: number;
    energyScore: number;
    dynamicRange: number;
    rhythmicComplexity: number;
    lufs: number;
  }[];
  conclusions: string[];
}

export interface ProvenanceRecord {
  timestamp: string;
  stage: string;
  operator: string;
  details: string;
  pluginChain: string[];
  sampleRate: number;
  bitDepth: number;
  hash: string;
}

export interface CatalogueAsset {
  id: string;
  name: string;
  type: 'synth' | 'drum' | 'bass' | 'pad' | 'vocal' | 'effect';
  key: string;
  bpm: number;
  durationSeconds: number;
  sampleRate: number;
  lufs: number;
  dynamicRange: number;
  tags: string[];
  sha256: string;
  dnaVector: {
    harmonicity: number;
    brightness: number;
    rhythmDensity: number;
    energy: number;
  };
}

export interface ProvenanceNode {
  id: string;
  action: string;
  engine: string;
  inputHash: string;
  outputHash: string;
  parameters: Record<string, any>;
  timestamp: string;
}

export interface Experiment {
  id: string;
  name: string;
  hypothesis: string;
  winnerBranch: string;
  variantA: {
    name: string;
    lufs: number;
    thd: number;
    crestFactor: number;
  };
  variantB: {
    name: string;
    lufs: number;
    thd: number;
    crestFactor: number;
  };
}

