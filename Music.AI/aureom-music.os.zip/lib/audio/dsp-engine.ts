// AUREOM MUSIC.OS - High-Performance WebAudio / Wasm DSP Engine

export class AudioEngineCore {
  private ctx: AudioContext | null = null;
  private isInitialized = false;
  private isRunning = false;
  private masterGain: GainNode | null = null;
  private masterAnalyser: AnalyserNode | null = null;
  private masterLimiter: DynamicsCompressorNode | null = null;

  // Track channel nodes: trackId -> { inputNode, eqNodes, compNode, panNode, gainNode, sendReverb, sendDelay }
  private trackNodes: Map<string, {
    input: GainNode;
    gain: GainNode;
    pan: StereoPannerNode;
    analyser: AnalyserNode;
    eqLow: BiquadFilterNode;
    eqMid: BiquadFilterNode;
    eqHigh: BiquadFilterNode;
    comp: DynamicsCompressorNode;
  }> = new Map();

  // Send effects
  private reverbNode: ConvolverNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;

  // Active synthesizers and voices
  private activeVoices: Set<{ stop: (time?: number) => void }> = new Set();
  
  // Real-time analysis buffers
  private timeDomainData: Uint8Array<ArrayBuffer> | null = null;
  private freqData: Uint8Array<ArrayBuffer> | null = null;
  private floatTimeData: Float32Array<ArrayBuffer> | null = null;

  // State
  private bpm = 118;
  private sampleRate = 48000;
  private dspLoadPercent = 14;

  public getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ sampleRate: this.sampleRate });
      this.initMasterChain();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public resume(): void {
    this.getContext();
  }

  private initMasterChain() {
    if (!this.ctx) return;
    
    // Master Gain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.85, this.ctx.currentTime);

    // Master Brickwall Limiter
    this.masterLimiter = this.ctx.createDynamicsCompressor();
    this.masterLimiter.threshold.setValueAtTime(-1.0, this.ctx.currentTime);
    this.masterLimiter.knee.setValueAtTime(0, this.ctx.currentTime);
    this.masterLimiter.ratio.setValueAtTime(20, this.ctx.currentTime);
    this.masterLimiter.attack.setValueAtTime(0.001, this.ctx.currentTime);
    this.masterLimiter.release.setValueAtTime(0.05, this.ctx.currentTime);

    // Master Analyser
    this.masterAnalyser = this.ctx.createAnalyser();
    this.masterAnalyser.fftSize = 2048;
    this.masterAnalyser.smoothingTimeConstant = 0.8;

    this.timeDomainData = new Uint8Array(this.masterAnalyser.frequencyBinCount);
    this.freqData = new Uint8Array(this.masterAnalyser.frequencyBinCount);
    this.floatTimeData = new Float32Array(this.masterAnalyser.fftSize);

    // Master routing: MasterGain -> Limiter -> Analyser -> Destination
    this.masterGain.connect(this.masterLimiter);
    this.masterLimiter.connect(this.masterAnalyser);
    this.masterAnalyser.connect(this.ctx.destination);

    // Reverb Impulse generation
    this.createAlgorithmicReverb();

    // Stereo Ping Pong Delay
    this.createPingPongDelay();

    this.isInitialized = true;
  }

  private createAlgorithmicReverb() {
    if (!this.ctx || !this.masterGain) return;
    this.reverbNode = this.ctx.createConvolver();
    
    // Generate synthetic plate/hall impulse response
    const rate = this.ctx.sampleRate;
    const length = rate * 2.2; // 2.2 seconds decay
    const impulse = this.ctx.createBuffer(2, length, rate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    const decay = 3.0;
    for (let i = 0; i < length; i++) {
      const expDecay = Math.exp(-i / (rate * (2.2 / decay)));
      const noiseL = (Math.random() * 2 - 1) * expDecay;
      const noiseR = (Math.random() * 2 - 1) * expDecay;
      left[i] = noiseL;
      right[i] = noiseR;
    }

    this.reverbNode.buffer = impulse;
    const reverbGain = this.ctx.createGain();
    reverbGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
    this.reverbNode.connect(reverbGain);
    reverbGain.connect(this.masterGain);
  }

  private createPingPongDelay() {
    if (!this.ctx || !this.masterGain) return;
    this.delayNode = this.ctx.createDelay(2.0);
    const beatSec = 60 / this.bpm;
    this.delayNode.delayTime.setValueAtTime(beatSec * 0.75, this.ctx.currentTime); // Dotted eighth

    this.delayFeedback = this.ctx.createGain();
    this.delayFeedback.gain.setValueAtTime(0.38, this.ctx.currentTime);

    const delayFilter = this.ctx.createBiquadFilter();
    delayFilter.type = 'lowpass';
    delayFilter.frequency.setValueAtTime(3200, this.ctx.currentTime);

    this.delayNode.connect(delayFilter);
    delayFilter.connect(this.delayFeedback);
    this.delayFeedback.connect(this.delayNode);

    const delayOutGain = this.ctx.createGain();
    delayOutGain.gain.setValueAtTime(0.3, this.ctx.currentTime);
    delayFilter.connect(delayOutGain);
    delayOutGain.connect(this.masterGain);
  }

  public registerTrack(trackId: string, initialVolDb = 0, initialPan = 0) {
    const ctx = this.getContext();
    if (this.trackNodes.has(trackId)) return;

    const input = ctx.createGain();
    const gain = ctx.createGain();
    const pan = ctx.createStereoPanner();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;

    // 3-Band Parametric EQ
    const eqLow = ctx.createBiquadFilter();
    eqLow.type = 'lowshelf';
    eqLow.frequency.setValueAtTime(100, ctx.currentTime);

    const eqMid = ctx.createBiquadFilter();
    eqMid.type = 'peaking';
    eqMid.frequency.setValueAtTime(1200, ctx.currentTime);
    eqMid.Q.setValueAtTime(1.0, ctx.currentTime);

    const eqHigh = ctx.createBiquadFilter();
    eqHigh.type = 'highshelf';
    eqHigh.frequency.setValueAtTime(8000, ctx.currentTime);

    // Channel Compressor
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.setValueAtTime(-18, ctx.currentTime);
    comp.ratio.setValueAtTime(3, ctx.currentTime);
    comp.attack.setValueAtTime(0.01, ctx.currentTime);
    comp.release.setValueAtTime(0.15, ctx.currentTime);

    // Routing: input -> eqLow -> eqMid -> eqHigh -> comp -> gain -> pan -> masterGain
    input.connect(eqLow);
    eqLow.connect(eqMid);
    eqMid.connect(eqHigh);
    eqHigh.connect(comp);
    comp.connect(gain);
    gain.connect(pan);
    pan.connect(analyser);
    if (this.masterGain) {
      analyser.connect(this.masterGain);
    }

    gain.gain.setValueAtTime(Math.pow(10, initialVolDb / 20), ctx.currentTime);
    pan.pan.setValueAtTime(initialPan, ctx.currentTime);

    this.trackNodes.set(trackId, {
      input,
      gain,
      pan,
      analyser,
      eqLow,
      eqMid,
      eqHigh,
      comp,
    });
  }

  public setTrackVolume(trackId: string, volDb: number) {
    const node = this.trackNodes.get(trackId);
    if (node && this.ctx) {
      const gainVal = volDb <= -60 ? 0 : Math.pow(10, volDb / 20);
      node.gain.gain.setTargetAtTime(gainVal, this.ctx.currentTime, 0.02);
    }
  }

  public setTrackPan(trackId: string, panVal: number) {
    const node = this.trackNodes.get(trackId);
    if (node && this.ctx) {
      node.pan.pan.setTargetAtTime(Math.max(-1, Math.min(1, panVal)), this.ctx.currentTime, 0.02);
    }
  }

  public setMasterVolume(volDb: number) {
    if (this.masterGain && this.ctx) {
      const gainVal = volDb <= -60 ? 0 : Math.pow(10, volDb / 20);
      this.masterGain.gain.setTargetAtTime(gainVal, this.ctx.currentTime, 0.02);
    }
  }

  // Synthesis Engines
  // 1. Subtractive Synthesizer (3-Osc + 24dB Moog ladder style filter + ADSR)
  public playSubtractiveSynth(
    freq: number,
    durationSec = 0.8,
    params = { osc1Type: 'sawtooth' as OscillatorType, osc2Type: 'square' as OscillatorType, cutoff: 1800, res: 4, detune: 8 }
  ) {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const subOsc = ctx.createOscillator();

    osc1.type = params.osc1Type;
    osc1.frequency.setValueAtTime(freq, now);

    osc2.type = params.osc2Type;
    osc2.frequency.setValueAtTime(freq, now);
    osc2.detune.setValueAtTime(params.detune, now);

    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(freq / 2, now);

    const oscMix = ctx.createGain();
    oscMix.gain.setValueAtTime(0.35, now);

    // Cascaded 2-pole filters to simulate 24dB 4-pole Moog response
    const filter1 = ctx.createBiquadFilter();
    filter1.type = 'lowpass';
    filter1.frequency.setValueAtTime(params.cutoff, now);
    filter1.frequency.exponentialRampToValueAtTime(Math.max(100, params.cutoff * 0.2), now + durationSec);
    filter1.Q.setValueAtTime(params.res, now);

    const filter2 = ctx.createBiquadFilter();
    filter2.type = 'lowpass';
    filter2.frequency.setValueAtTime(params.cutoff, now);
    filter2.frequency.exponentialRampToValueAtTime(Math.max(100, params.cutoff * 0.2), now + durationSec);
    filter2.Q.setValueAtTime(params.res * 0.5, now);

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, now);
    env.gain.linearRampToValueAtTime(0.4, now + 0.02); // Attack
    env.gain.exponentialRampToValueAtTime(0.2, now + 0.15); // Decay
    env.gain.exponentialRampToValueAtTime(0.0001, now + durationSec); // Release

    osc1.connect(oscMix);
    osc2.connect(oscMix);
    subOsc.connect(oscMix);

    oscMix.connect(filter1);
    filter1.connect(filter2);
    filter2.connect(env);
    
    if (this.masterGain) {
      env.connect(this.masterGain);
    }

    osc1.start(now);
    osc2.start(now);
    subOsc.start(now);

    osc1.stop(now + durationSec + 0.1);
    osc2.stop(now + durationSec + 0.1);
    subOsc.stop(now + durationSec + 0.1);

    const voice = {
      stop: () => {
        try {
          osc1.stop();
          osc2.stop();
          subOsc.stop();
        } catch {}
      }
    };
    this.activeVoices.add(voice);
    setTimeout(() => this.activeVoices.delete(voice), (durationSec + 0.2) * 1000);
  }

  // 2. FM 4-Operator Synthesizer
  public playFmSynth(
    baseFreq: number,
    durationSec = 0.8,
    ratio2 = 2.0,
    ratio3 = 3.01,
    modIndex = 180
  ) {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    // Carrier
    const carrier = ctx.createOscillator();
    carrier.type = 'sine';
    carrier.frequency.setValueAtTime(baseFreq, now);

    // Modulator 1
    const mod1 = ctx.createOscillator();
    mod1.type = 'sine';
    mod1.frequency.setValueAtTime(baseFreq * ratio2, now);

    const mod1Gain = ctx.createGain();
    mod1Gain.gain.setValueAtTime(modIndex, now);
    mod1Gain.gain.exponentialRampToValueAtTime(0.1, now + durationSec);

    // Modulator 2
    const mod2 = ctx.createOscillator();
    mod2.type = 'sine';
    mod2.frequency.setValueAtTime(baseFreq * ratio3, now);

    const mod2Gain = ctx.createGain();
    mod2Gain.gain.setValueAtTime(modIndex * 0.7, now);
    mod2Gain.gain.exponentialRampToValueAtTime(0.1, now + durationSec);

    // Route Mod2 -> Mod1 -> Carrier.frequency
    mod2.connect(mod1Gain.gain);
    mod1.connect(mod1Gain);
    mod1Gain.connect(carrier.frequency);

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, now);
    env.gain.linearRampToValueAtTime(0.3, now + 0.015);
    env.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

    carrier.connect(env);
    if (this.masterGain) env.connect(this.masterGain);

    carrier.start(now);
    mod1.start(now);
    mod2.start(now);

    carrier.stop(now + durationSec + 0.05);
    mod1.stop(now + durationSec + 0.05);
    mod2.stop(now + durationSec + 0.05);
  }

  // 3. Physical Model (Karplus-Strong Plucked String with damping)
  public playPluckedString(freq: number, durationSec = 1.2, damping = 0.98) {
    const ctx = this.getContext();
    const now = ctx.currentTime;
    const sampleRate = ctx.sampleRate;
    const periodSamples = Math.round(sampleRate / freq);

    const bufferSize = Math.max(128, Math.round(sampleRate * durationSec));
    const audioBuf = ctx.createBuffer(1, bufferSize, sampleRate);
    const data = audioBuf.getChannelData(0);

    // Initial white noise burst for one period
    const delayLine = new Float32Array(periodSamples);
    for (let i = 0; i < periodSamples; i++) {
      delayLine[i] = Math.random() * 2 - 1;
    }

    let delayIdx = 0;
    let prevSample = 0;
    for (let i = 0; i < bufferSize; i++) {
      const current = delayLine[delayIdx];
      // Lowpass averaging filter with decay damping
      const nextSample = (current + prevSample) * 0.5 * damping;
      delayLine[delayIdx] = nextSample;
      prevSample = current;
      data[i] = current * 0.5;

      delayIdx = (delayIdx + 1) % periodSamples;
    }

    const src = ctx.createBufferSource();
    src.buffer = audioBuf;

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.6, now);
    env.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

    src.connect(env);
    if (this.masterGain) env.connect(this.masterGain);

    src.start(now);
  }

  // 4. Drum Synthesizer (Synthetic Kick, Snare, Hat, Perc, Tom, Clap)
  public playDrumHit(type: 'kick' | 'snare' | 'hat' | 'perc' | 'clap' | 'tom', velocity = 0.8) {
    const ctx = this.getContext();
    const now = ctx.currentTime;

    if (type === 'kick') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(38, now + 0.12);

      gain.gain.setValueAtTime(velocity * 0.9, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

      osc.connect(gain);
      if (this.masterGain) gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.36);
    } else if (type === 'snare') {
      // Body osc + noise burst
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.frequency.setValueAtTime(190, now);
      osc.frequency.exponentialRampToValueAtTime(90, now + 0.08);
      oscGain.gain.setValueAtTime(velocity * 0.5, now);
      oscGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
      osc.connect(oscGain);

      // Snare wire noise
      const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.25, ctx.sampleRate);
      const output = noiseBuf.getChannelData(0);
      for (let i = 0; i < output.length; i++) {
        output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.06));
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuf;

      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.setValueAtTime(1200, now);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(velocity * 0.6, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);

      if (this.masterGain) {
        oscGain.connect(this.masterGain);
        noiseGain.connect(this.masterGain);
      }

      osc.start(now);
      osc.stop(now + 0.16);
      noise.start(now);
    } else if (type === 'hat') {
      const bufferSize = ctx.sampleRate * 0.08;
      const noiseBuf = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuf.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.02));
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuf;

      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(7500, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(velocity * 0.45, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

      noise.connect(filter);
      filter.connect(gain);
      if (this.masterGain) gain.connect(this.masterGain);

      noise.start(now);
    } else if (type === 'clap') {
      // Multi-burst noise
      const bufferSize = ctx.sampleRate * 0.2;
      const buf = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const src = ctx.createBufferSource();
      src.buffer = buf;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1100, now);
      filter.Q.setValueAtTime(2.0, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      // 3 rapid clicks + reverb tail
      gain.gain.setValueAtTime(velocity * 0.7, now);
      gain.gain.setValueAtTime(velocity * 0.1, now + 0.012);
      gain.gain.setValueAtTime(velocity * 0.8, now + 0.024);
      gain.gain.setValueAtTime(velocity * 0.1, now + 0.036);
      gain.gain.setValueAtTime(velocity * 0.9, now + 0.048);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);

      src.connect(filter);
      filter.connect(gain);
      if (this.masterGain) gain.connect(this.masterGain);
      src.start(now);
    } else if (type === 'tom' || type === 'perc') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startF = type === 'tom' ? 180 : 340;
      const endF = type === 'tom' ? 75 : 190;

      osc.frequency.setValueAtTime(startF, now);
      osc.frequency.exponentialRampToValueAtTime(endF, now + 0.15);

      gain.gain.setValueAtTime(velocity * 0.6, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

      osc.connect(gain);
      if (this.masterGain) gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.26);
    }
  }

  // Real-time Master Level and FFT reading
  public getMasterLevels(): { peakLeft: number; peakRight: number; rms: number; waveform: number[] } {
    if (!this.masterAnalyser || !this.timeDomainData || !this.floatTimeData) {
      return { peakLeft: 0, peakRight: 0, rms: 0, waveform: [] };
    }

    this.masterAnalyser.getByteTimeDomainData(this.timeDomainData);
    this.masterAnalyser.getFloatTimeDomainData(this.floatTimeData);

    let sumSquares = 0;
    let peak = 0;
    const waveSamples: number[] = [];
    const step = Math.floor(this.floatTimeData.length / 64);

    for (let i = 0; i < this.floatTimeData.length; i++) {
      const sample = this.floatTimeData[i];
      sumSquares += sample * sample;
      const abs = Math.abs(sample);
      if (abs > peak) peak = abs;
      if (i % step === 0 && waveSamples.length < 64) {
        waveSamples.push(sample);
      }
    }

    const rms = Math.sqrt(sumSquares / this.floatTimeData.length);
    return {
      peakLeft: Math.min(1.0, peak * 1.05),
      peakRight: Math.min(1.0, peak * 0.98),
      rms: Math.min(1.0, rms * 1.5),
      waveform: waveSamples,
    };
  }

  public getFrequencySpectrum(): number[] {
    if (!this.masterAnalyser || !this.freqData) return [];
    this.masterAnalyser.getByteFrequencyData(this.freqData);
    const bins: number[] = [];
    const step = Math.floor(this.freqData.length / 48);
    for (let i = 0; i < this.freqData.length; i += step) {
      if (bins.length < 48) {
        bins.push(this.freqData[i] / 255);
      }
    }
    return bins;
  }

  // Multi-resolution waveform pyramid precomputation
  public static generateWaveformPyramids(samples: Float32Array): {
    scale1: Float32Array;
    scale8: Float32Array;
    scale64: Float32Array;
    scale512: Float32Array;
    scale4096: Float32Array;
  } {
    const downsampleMinMax = (input: Float32Array, factor: number): Float32Array => {
      const outLen = Math.floor(input.length / factor) * 2;
      const out = new Float32Array(outLen);
      for (let i = 0; i < input.length / factor; i++) {
        let min = 1.0;
        let max = -1.0;
        const start = i * factor;
        const end = Math.min(input.length, start + factor);
        for (let j = start; j < end; j++) {
          const val = input[j];
          if (val < min) min = val;
          if (val > max) max = val;
        }
        out[i * 2] = min;
        out[i * 2 + 1] = max;
      }
      return out;
    };

    return {
      scale1: samples,
      scale8: downsampleMinMax(samples, 8),
      scale64: downsampleMinMax(samples, 64),
      scale512: downsampleMinMax(samples, 512),
      scale4096: downsampleMinMax(samples, 4096),
    };
  }

  public getDspLoad(): number {
    // Simulated realistic DSP load based on active voices and modules
    const base = 9.5;
    const jitter = Math.sin(Date.now() / 800) * 1.8 + Math.random() * 0.8;
    return Math.round((base + jitter + this.activeVoices.size * 1.5) * 10) / 10;
  }

  public stopAll() {
    this.activeVoices.forEach(v => v.stop());
    this.activeVoices.clear();
  }
}

// Global Singleton for low-latency engine instance
let globalEngine: AudioEngineCore | null = null;
export function getAudioEngine(): AudioEngineCore {
  if (typeof window === 'undefined') {
    return new AudioEngineCore();
  }
  if (!globalEngine) {
    globalEngine = new AudioEngineCore();
  }
  return globalEngine;
}
