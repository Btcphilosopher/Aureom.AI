import { CatalogueTrack, ExperimentRun, ProvenanceRecord } from '@/types/audio';

export const CATALOGUE_TRACKS: CatalogueTrack[] = [
  {
    id: 'cat_001',
    title: 'Aureom Session 118',
    artist: 'Aureom Core',
    album: 'First Principles',
    year: 2026,
    genre: 'Electronic Research',
    bpm: 118,
    key: 'D Minor',
    durationSeconds: 213,
    loudnessLufs: -13.8,
    dynamicRangeDr: 12.2,
    spectralCentroid: 2140,
    rhythmicDensity: 7.8,
    energy: 84,
    harmonicComplexity: 8.2,
    format: 'WAV',
    provenanceDate: '2026-09-18 14:22 UTC',
    timbreVector: {
      spectralCentroid: 0.68,
      brightness: 0.72,
      roughness: 0.28,
      attackTimeMs: 14.5,
      decayTimeMs: 420.0,
      zeroCrossingRate: 0.082,
      harmonicity: 0.88,
      dynamicRangeDb: 18.4,
      noiseRatio: 0.12
    },
    musicalDna: {
      tempo: 118,
      key: 'D Minor',
      loudnessLufs: -13.8,
      dynamicRangeDr: 12.2,
      spectralCentroidHz: 2140,
      spectralFlux: 0.38,
      rhythmicDensity: 7.8,
      harmonicComplexity: 8.2,
      timbralWarmth: 8.6,
      energyScore: 84.0,
      sectionDensity: 8,
      radarMetrics: [
        { label: 'Spectral Brightness', value: 72 },
        { label: 'Rhythmic Density', value: 78 },
        { label: 'Harmonic Complexity', value: 84 },
        { label: 'Dynamic Range', value: 68 },
        { label: 'Timbral Warmth', value: 86 },
        { label: 'Spatial Width', value: 81 },
        { label: 'Groove / Syncopation', value: 65 },
        { label: 'Energy Peak', value: 88 }
      ]
    }
  },
  {
    id: 'cat_002',
    title: 'Kinetic Monolith',
    artist: 'Aureom Core',
    album: 'First Principles',
    year: 2026,
    genre: 'Modular Techno',
    bpm: 132,
    key: 'F Minor',
    durationSeconds: 340,
    loudnessLufs: -10.2,
    dynamicRangeDr: 8.5,
    spectralCentroid: 2980,
    rhythmicDensity: 11.4,
    energy: 94,
    harmonicComplexity: 4.8,
    format: 'FLAC',
    provenanceDate: '2026-09-12 11:05 UTC',
    timbreVector: {
      spectralCentroid: 0.82,
      brightness: 0.88,
      roughness: 0.54,
      attackTimeMs: 4.2,
      decayTimeMs: 210.0,
      zeroCrossingRate: 0.124,
      harmonicity: 0.62,
      dynamicRangeDb: 12.1,
      noiseRatio: 0.38
    },
    musicalDna: {
      tempo: 132,
      key: 'F Minor',
      loudnessLufs: -10.2,
      dynamicRangeDr: 8.5,
      spectralCentroidHz: 2980,
      spectralFlux: 0.58,
      rhythmicDensity: 11.4,
      harmonicComplexity: 4.8,
      timbralWarmth: 5.4,
      energyScore: 94.0,
      sectionDensity: 5,
      radarMetrics: [
        { label: 'Spectral Brightness', value: 88 },
        { label: 'Rhythmic Density', value: 95 },
        { label: 'Harmonic Complexity', value: 48 },
        { label: 'Dynamic Range', value: 42 },
        { label: 'Timbral Warmth', value: 54 },
        { label: 'Spatial Width', value: 72 },
        { label: 'Groove / Syncopation', value: 82 },
        { label: 'Energy Peak', value: 96 }
      ]
    }
  },
  {
    id: 'cat_003',
    title: 'Submerged Nocturne',
    artist: 'Dr. E. Vance',
    album: 'Acoustic Studies',
    year: 2025,
    genre: 'Ambient Neo-Classical',
    bpm: 72,
    key: 'C Minor',
    durationSeconds: 412,
    loudnessLufs: -18.5,
    dynamicRangeDr: 16.4,
    spectralCentroid: 1120,
    rhythmicDensity: 2.1,
    energy: 38,
    harmonicComplexity: 9.1,
    format: 'WAV',
    provenanceDate: '2025-11-04 09:14 UTC',
    timbreVector: {
      spectralCentroid: 0.32,
      brightness: 0.28,
      roughness: 0.11,
      attackTimeMs: 140.0,
      decayTimeMs: 2800.0,
      zeroCrossingRate: 0.038,
      harmonicity: 0.94,
      dynamicRangeDb: 22.8,
      noiseRatio: 0.06
    },
    musicalDna: {
      tempo: 72,
      key: 'C Minor',
      loudnessLufs: -18.5,
      dynamicRangeDr: 16.4,
      spectralCentroidHz: 1120,
      spectralFlux: 0.14,
      rhythmicDensity: 2.1,
      harmonicComplexity: 9.1,
      timbralWarmth: 9.5,
      energyScore: 38.0,
      sectionDensity: 4,
      radarMetrics: [
        { label: 'Spectral Brightness', value: 28 },
        { label: 'Rhythmic Density', value: 22 },
        { label: 'Harmonic Complexity', value: 92 },
        { label: 'Dynamic Range', value: 95 },
        { label: 'Timbral Warmth', value: 96 },
        { label: 'Spatial Width', value: 89 },
        { label: 'Groove / Syncopation', value: 18 },
        { label: 'Energy Peak', value: 36 }
      ]
    }
  },
  {
    id: 'cat_004',
    title: 'Stochastic Calculus',
    artist: 'Markov Collective',
    album: 'Generative Matrices',
    year: 2026,
    genre: 'Algorithmic IDM',
    bpm: 144,
    key: 'A Dorian',
    durationSeconds: 278,
    loudnessLufs: -12.1,
    dynamicRangeDr: 10.8,
    spectralCentroid: 3420,
    rhythmicDensity: 12.8,
    energy: 88,
    harmonicComplexity: 7.6,
    format: 'WAV',
    provenanceDate: '2026-08-20 17:40 UTC',
    timbreVector: {
      spectralCentroid: 0.89,
      brightness: 0.91,
      roughness: 0.62,
      attackTimeMs: 2.1,
      decayTimeMs: 180.0,
      zeroCrossingRate: 0.148,
      harmonicity: 0.58,
      dynamicRangeDb: 14.6,
      noiseRatio: 0.42
    },
    musicalDna: {
      tempo: 144,
      key: 'A Dorian',
      loudnessLufs: -12.1,
      dynamicRangeDr: 10.8,
      spectralCentroidHz: 3420,
      spectralFlux: 0.72,
      rhythmicDensity: 12.8,
      harmonicComplexity: 7.6,
      timbralWarmth: 4.8,
      energyScore: 88.0,
      sectionDensity: 7,
      radarMetrics: [
        { label: 'Spectral Brightness', value: 92 },
        { label: 'Rhythmic Density', value: 98 },
        { label: 'Harmonic Complexity', value: 76 },
        { label: 'Dynamic Range', value: 58 },
        { label: 'Timbral Warmth', value: 48 },
        { label: 'Spatial Width', value: 84 },
        { label: 'Groove / Syncopation', value: 92 },
        { label: 'Energy Peak', value: 90 }
      ]
    }
  },
  {
    id: 'cat_005',
    title: 'Harmonic Resonator 7',
    artist: 'Aureom Core',
    album: 'DSP Laboratory 01',
    year: 2025,
    genre: 'Physical Modeling',
    bpm: 105,
    key: 'G Major',
    durationSeconds: 195,
    loudnessLufs: -15.2,
    dynamicRangeDr: 14.1,
    spectralCentroid: 1850,
    rhythmicDensity: 5.6,
    energy: 62,
    harmonicComplexity: 8.8,
    format: 'AIFF',
    provenanceDate: '2025-07-15 19:30 UTC',
    timbreVector: {
      spectralCentroid: 0.52,
      brightness: 0.58,
      roughness: 0.22,
      attackTimeMs: 18.0,
      decayTimeMs: 650.0,
      zeroCrossingRate: 0.072,
      harmonicity: 0.91,
      dynamicRangeDb: 19.2,
      noiseRatio: 0.09
    },
    musicalDna: {
      tempo: 105,
      key: 'G Major',
      loudnessLufs: -15.2,
      dynamicRangeDr: 14.1,
      spectralCentroidHz: 1850,
      spectralFlux: 0.28,
      rhythmicDensity: 5.6,
      harmonicComplexity: 8.8,
      timbralWarmth: 8.9,
      energyScore: 62.0,
      sectionDensity: 6,
      radarMetrics: [
        { label: 'Spectral Brightness', value: 58 },
        { label: 'Rhythmic Density', value: 56 },
        { label: 'Harmonic Complexity', value: 88 },
        { label: 'Dynamic Range', value: 82 },
        { label: 'Timbral Warmth', value: 89 },
        { label: 'Spatial Width', value: 76 },
        { label: 'Groove / Syncopation', value: 52 },
        { label: 'Energy Peak', value: 64 }
      ]
    }
  },
  {
    id: 'cat_006',
    title: 'London Fog Tube Saturator',
    artist: 'British Tape Works',
    album: 'Analog Heat Series',
    year: 2024,
    genre: 'Warm Analog Dub',
    bpm: 88,
    key: 'E Minor',
    durationSeconds: 320,
    loudnessLufs: -14.4,
    dynamicRangeDr: 13.5,
    spectralCentroid: 1450,
    rhythmicDensity: 6.2,
    energy: 70,
    harmonicComplexity: 6.4,
    format: 'WAV',
    provenanceDate: '2024-10-29 22:18 UTC',
    timbreVector: {
      spectralCentroid: 0.44,
      brightness: 0.48,
      roughness: 0.35,
      attackTimeMs: 25.0,
      decayTimeMs: 820.0,
      zeroCrossingRate: 0.061,
      harmonicity: 0.85,
      dynamicRangeDb: 16.8,
      noiseRatio: 0.18
    },
    musicalDna: {
      tempo: 88,
      key: 'E Minor',
      loudnessLufs: -14.4,
      dynamicRangeDr: 13.5,
      spectralCentroidHz: 1450,
      spectralFlux: 0.32,
      rhythmicDensity: 6.2,
      harmonicComplexity: 6.4,
      timbralWarmth: 9.8,
      energyScore: 70.0,
      sectionDensity: 5,
      radarMetrics: [
        { label: 'Spectral Brightness', value: 48 },
        { label: 'Rhythmic Density', value: 62 },
        { label: 'Harmonic Complexity', value: 64 },
        { label: 'Dynamic Range', value: 78 },
        { label: 'Timbral Warmth', value: 98 },
        { label: 'Spatial Width', value: 74 },
        { label: 'Groove / Syncopation', value: 75 },
        { label: 'Energy Peak', value: 72 }
      ]
    }
  }
];

export const EXPERIMENT_RUNS: ExperimentRun[] = [
  {
    id: 'exp_042',
    experimentNumber: 'EXPERIMENT 042',
    variableName: 'TEMPO',
    variableUnit: 'BPM',
    values: [90, 100, 110, 120, 130],
    results: [
      { variableValue: 90, spectralDensity: 48.2, energyScore: 58.4, dynamicRange: 15.2, rhythmicComplexity: 42.1, lufs: -16.2 },
      { variableValue: 100, spectralDensity: 56.4, energyScore: 68.1, dynamicRange: 14.1, rhythmicComplexity: 54.8, lufs: -15.1 },
      { variableValue: 110, spectralDensity: 66.8, energyScore: 76.5, dynamicRange: 13.0, rhythmicComplexity: 68.4, lufs: -14.4 },
      { variableValue: 120, spectralDensity: 78.1, energyScore: 86.2, dynamicRange: 11.8, rhythmicComplexity: 79.2, lufs: -13.5 },
      { variableValue: 130, spectralDensity: 89.5, energyScore: 94.0, dynamicRange: 9.6, rhythmicComplexity: 88.6, lufs: -11.9 }
    ],
    conclusions: [
      'Positive monotonic correlation (r = +0.98, p < 0.001) between Tempo and Spectral Density due to overlapping transient tails.',
      'Dynamic range compresses by 5.6 dB as tempo increases from 90 to 130 BPM.',
      'Optimum rhythmic clarity vs energy balance achieved at 118-120 BPM for this acoustic arrangement.'
    ]
  },
  {
    id: 'exp_018',
    experimentNumber: 'EXPERIMENT 018',
    variableName: 'TAPE SATURATION DRIVE',
    variableUnit: 'dB',
    values: [0, 3, 6, 9, 12],
    results: [
      { variableValue: 0, spectralDensity: 52.0, energyScore: 60.0, dynamicRange: 18.0, rhythmicComplexity: 60.0, lufs: -16.0 },
      { variableValue: 3, spectralDensity: 61.2, energyScore: 69.4, dynamicRange: 15.5, rhythmicComplexity: 61.2, lufs: -14.8 },
      { variableValue: 6, spectralDensity: 74.8, energyScore: 78.8, dynamicRange: 12.8, rhythmicComplexity: 62.0, lufs: -13.6 },
      { variableValue: 9, spectralDensity: 88.0, energyScore: 89.1, dynamicRange: 9.4, rhythmicComplexity: 61.5, lufs: -12.1 },
      { variableValue: 12, spectralDensity: 96.5, energyScore: 96.2, dynamicRange: 6.2, rhythmicComplexity: 58.0, lufs: -10.4 }
    ],
    conclusions: [
      'Even-harmonic content (2nd and 4th partials) increases by +14dB at 6dB drive with zero harsh intermodulation.',
      'Crest factor drops linearly by 1.1 dB per 3 dB of saturation drive.',
      'Warm British console character threshold sits at 4.5 dB to 6.2 dB input gain.'
    ]
  }
];

export const PROVENANCE_CHAIN: ProvenanceRecord[] = [
  {
    timestamp: '2026-09-22 09:00:12 UTC',
    stage: '01. Raw Multitrack Ingestion',
    operator: 'Rust IO AudioBuffer',
    details: '10 channels allocated at 48,000 Hz 24-bit floating point precision. Zero clipping detected.',
    pluginChain: ['Direct Memory Arena', 'Symphonia WAV Decoder'],
    sampleRate: 48000,
    bitDepth: 24,
    hash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
  },
  {
    stage: '02. DSP Channel Processing',
    timestamp: '2026-09-22 09:04:45 UTC',
    operator: 'Aureom DSP Engine (Rust)',
    details: 'Parametric 5-Band Biquad EQ + Moog 24dB ladder filter + Tube Saturation applied to tracks 01-10.',
    pluginChain: ['aureom_eq5_v2', 'aureom_ladder_filter_v1', 'aureom_tube_saturator_v3'],
    sampleRate: 48000,
    bitDepth: 24,
    hash: 'sha256:4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a'
  },
  {
    stage: '03. R Statistical Analysis & DNA Extraction',
    timestamp: '2026-09-22 09:07:22 UTC',
    operator: 'aureomMusicR Engine (R 4.4.2)',
    details: 'Computed STFT (2048 bins), Longuet-Higgins syncopation index, Krumhansl key profile (D Minor, conf 0.93), and 9D Timbre space.',
    pluginChain: ['aureom_stft()', 'aureom_krumhansl_key()', 'aureom_timbre_radar()'],
    sampleRate: 48000,
    bitDepth: 24,
    hash: 'sha256:9a912e75cb73cf325d7776b2ad6802e9cfc7d42cf898aa249f3e3713589b276d'
  },
  {
    stage: '04. Final EBU R128 Mastering Verification',
    timestamp: '2026-09-22 09:10:04 UTC',
    operator: 'Mastering Lab & True Peak Limiter',
    details: 'True peak checked at -0.8 dBTP, Integrated Loudness target -14.1 LUFS verified. Zero intersample overs.',
    pluginChain: ['aureom_brickwall_limiter_v4', 'aureom_ebu_r128_meter'],
    sampleRate: 48000,
    bitDepth: 24,
    hash: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  }
];

export const mockCatalogueAssets = [
  {
    id: 'asset_01',
    name: 'Analog Sub-Moog Bassline (D Minor)',
    type: 'bass' as const,
    key: 'D Minor',
    bpm: 118,
    durationSeconds: 16.27,
    sampleRate: 48000,
    lufs: -14.2,
    dynamicRange: 12.8,
    tags: ['Moog', 'Subtractive', 'Analog', 'Warm', 'Resonant'],
    sha256: '9a912e75cb73cf325d7776b2ad6802e9cfc7d42cf898aa249f3e3713589b276d',
    dnaVector: {
      harmonicity: 0.94,
      brightness: 0.42,
      rhythmDensity: 0.75,
      energy: 0.82
    }
  },
  {
    id: 'asset_02',
    name: 'Karplus-Strong Plucked Harp Pattern',
    type: 'synth' as const,
    key: 'D Minor',
    bpm: 118,
    durationSeconds: 8.14,
    sampleRate: 48000,
    lufs: -16.4,
    dynamicRange: 15.2,
    tags: ['Physical Model', 'Karplus', 'Acoustic', 'Percussive', 'Arp'],
    sha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    dnaVector: {
      harmonicity: 0.88,
      brightness: 0.78,
      rhythmDensity: 0.88,
      energy: 0.68
    }
  },
  {
    id: 'asset_03',
    name: 'Polymetric 7/8 Kinetic Drum Groove',
    type: 'drum' as const,
    key: 'Atonal',
    bpm: 118,
    durationSeconds: 12.21,
    sampleRate: 48000,
    lufs: -12.8,
    dynamicRange: 10.4,
    tags: ['Polymetric', 'R-Generated', 'Transient', 'Punchy', 'Groove'],
    sha256: '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    dnaVector: {
      harmonicity: 0.32,
      brightness: 0.65,
      rhythmDensity: 0.94,
      energy: 0.91
    }
  },
  {
    id: 'asset_04',
    name: 'Cello Granular Octave Swarm',
    type: 'pad' as const,
    key: 'D Minor',
    bpm: 118,
    durationSeconds: 24.4,
    sampleRate: 48000,
    lufs: -18.2,
    dynamicRange: 17.5,
    tags: ['Granular', 'Resynthesis', 'Texture', 'Atmospheric', 'Slow Attack'],
    sha256: 'c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2',
    dnaVector: {
      harmonicity: 0.91,
      brightness: 0.54,
      rhythmDensity: 0.28,
      energy: 0.58
    }
  }
];

export const mockProvenanceTree = [
  {
    id: 'node_01',
    action: 'Ingest Raw 24-bit PCM Master Tracks',
    engine: 'Rust I/O Arena',
    inputHash: 'root:genesis_session_001',
    outputHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    parameters: { channels: 10, sampleRate: 48000, bitDepth: 24 },
    timestamp: '2026-09-22T09:00:12Z'
  },
  {
    id: 'node_02',
    action: 'Moog 24dB Ladder Filtering + Non-linear Saturation',
    engine: 'Rust DSP Engine',
    inputHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    outputHash: 'sha256:4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    parameters: { cutoffHz: 2200, resonanceQ: 4.5, driveDb: 4.5 },
    timestamp: '2026-09-22T09:04:45Z'
  },
  {
    id: 'node_03',
    action: 'R Statistical STFT & Musical DNA Extraction',
    engine: 'aureomMusicR v4.4.2',
    inputHash: 'sha256:4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    outputHash: 'sha256:9a912e75cb73cf325d7776b2ad6802e9cfc7d42cf898aa249f3e3713589b276d',
    parameters: { nFft: 2048, window: 'hann', krumhanslProfile: 'd_minor' },
    timestamp: '2026-09-22T09:07:22Z'
  },
  {
    id: 'node_04',
    action: 'EBU R128 True Peak Master Limiting (-0.3 dBTP)',
    engine: 'Rust Brickwall Limiter',
    inputHash: 'sha256:9a912e75cb73cf325d7776b2ad6802e9cfc7d42cf898aa249f3e3713589b276d',
    outputHash: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    parameters: { ceilingDb: -0.3, lufsTarget: -14.0, oversampling: '4x' },
    timestamp: '2026-09-22T09:10:04Z'
  }
];

export const mockExperiments = [
  {
    id: 'exp_01',
    name: 'Experiment #01: Saturation Topology (Triode vs Pentode)',
    hypothesis: 'Even-harmonic triode saturation at +4.5dB produces superior warmth with lower intermodulation distortion than pentode clipping.',
    winnerBranch: 'Branch B (Triode)',
    variantA: {
      name: 'Pentode Hard Clipping',
      lufs: -13.2,
      thd: 0.42,
      crestFactor: 13.8
    },
    variantB: {
      name: 'Triode Asymmetric Warmth',
      lufs: -14.1,
      thd: 0.18,
      crestFactor: 15.2
    }
  },
  {
    id: 'exp_02',
    name: 'Experiment #02: Reverb Damping Spectrum (Plate vs Convolution IR)',
    hypothesis: 'Physical plate damping above 6.5kHz preserves vocal intelligibility while maintaining spacious low-mid envelopment.',
    winnerBranch: 'Branch A (Plate 2.2s)',
    variantA: {
      name: 'Plate 2.2s (6.5kHz Cut)',
      lufs: -14.0,
      thd: 0.05,
      crestFactor: 15.0
    },
    variantB: {
      name: 'Cathedral Convolution IR',
      lufs: -15.4,
      thd: 0.09,
      crestFactor: 13.2
    }
  }
];

