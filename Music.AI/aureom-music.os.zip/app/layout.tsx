import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aureom Music.OS — Professional Audio Workstation & Analytical Lab',
  description: 'Aureom Music.OS: Real-time DSP audio engine coupled with R statistical intelligence, generative composition, and mastering analytics.',
  openGraph: {
    title: 'Aureom Music.OS — Professional Audio Workstation & Analytical Lab',
    description: 'Aureom Music.OS: Real-time DSP audio engine coupled with R statistical intelligence, generative composition, and mastering analytics.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aureom Music.OS — Professional Audio Workstation & Analytical Lab',
    description: 'Aureom Music.OS: Real-time DSP audio engine coupled with R statistical intelligence, generative composition, and mastering analytics.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
