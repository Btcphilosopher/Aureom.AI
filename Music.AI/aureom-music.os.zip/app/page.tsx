'use client';

import React, { useState, useEffect, useRef } from 'react';
import { initialAureomProject } from '@/lib/demo/aureom-session';
import { ProjectState, Track, ViewMode } from '@/types/audio';
import { getAudioEngine } from '@/lib/audio/dsp-engine';
import { TopNav } from '@/components/header/TopNav';
import { ArrangeView } from '@/components/views/ArrangeView';
import { MixerView } from '@/components/views/MixerView';
import { SynthWorkstationView } from '@/components/views/SynthWorkstationView';
import { AnalysisView } from '@/components/views/AnalysisView';
import { GenerativeLabView } from '@/components/views/GenerativeLabView';
import { MasteringLabView } from '@/components/views/MasteringLabView';
import { SamplingLabView } from '@/components/views/SamplingLabView';
import { CatalogueProvenanceView } from '@/components/views/CatalogueProvenanceView';
import { ConsoleRTerminalView } from '@/components/views/ConsoleRTerminalView';
import { Cpu, HardDrive, Zap, Radio } from 'lucide-react';

export default function AureomWorkstationPage() {
  const [project, setProject] = useState<ProjectState>(initialAureomProject);
  const [activeView, setActiveView] = useState<ViewMode>('arrange');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentBeat, setCurrentBeat] = useState<number>(0);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [masterVolumeDb, setMasterVolumeDb] = useState<number>(0);
  const [activeTrack, setActiveTrack] = useState<Track>(initialAureomProject.tracks[0]);
  const [cpuUsage, setCpuUsage] = useState<number>(4.2);

  const isPlayingRef = useRef(isPlaying);
  const currentBeatRef = useRef(currentBeat);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  useEffect(() => {
    currentBeatRef.current = currentBeat;
  }, [currentBeat]);

  // Transport Clock Timer Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const tick = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;

      if (isPlayingRef.current) {
        // Beats per second = BPM / 60
        const beatsPerSec = project.bpm / 60;
        let nextBeat = currentBeatRef.current + dt * beatsPerSec;
        const totalBeats = project.totalBars * 4;

        if (nextBeat >= totalBeats) {
          if (isLooping) {
            nextBeat = 0;
          } else {
            nextBeat = 0;
            setIsPlaying(false);
          }
        }

        // Audition synthetic step triggers during playback
        const oldStep = Math.floor(currentBeatRef.current * 2);
        const newStep = Math.floor(nextBeat * 2);
        if (newStep !== oldStep) {
          const engine = getAudioEngine();
          // Step drum trigger
          if (newStep % 4 === 0) engine.playDrumHit('kick', 0.8);
          if (newStep % 8 === 4) engine.playDrumHit('snare', 0.7);
          if (newStep % 2 === 1) engine.playDrumHit('hat', 0.4);

          // Arpeggio step
          if (newStep % 2 === 0) {
            const scalePitches = [220, 261.63, 293.66, 329.63, 349.23, 392.00, 440, 523.25];
            const pitch = scalePitches[newStep % scalePitches.length];
            engine.playPluckedString(pitch, 0.4);
          }
        }

        setCurrentBeat(nextBeat);
      }

      // Gentle CPU jitter
      if (isPlayingRef.current) {
        setCpuUsage(Number((4.8 + Math.sin(now / 500) * 0.9).toFixed(1)));
      } else {
        setCpuUsage(1.2);
      }

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animId);
  }, [project.bpm, project.totalBars, isLooping]);

  const handlePlayToggle = () => {
    const nextPlay = !isPlaying;
    setIsPlaying(nextPlay);
    getAudioEngine().resume();
  };

  const handleStop = () => {
    setIsPlaying(false);
    setCurrentBeat(0);
  };

  const handleUpdateTrack = (updatedTrack: Track) => {
    setProject((prev) => ({
      ...prev,
      tracks: prev.tracks.map((t) => (t.id === updatedTrack.id ? updatedTrack : t))
    }));
  };

  const handleBpmChange = (newBpm: number) => {
    setProject((prev) => ({ ...prev, bpm: newBpm }));
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-mono select-none">
      {/* Top Professional Navigation & Transport Header */}
      <TopNav
        activeView={activeView}
        onSelectView={setActiveView}
        isPlaying={isPlaying}
        onPlayToggle={handlePlayToggle}
        onStop={handleStop}
        bpm={project.bpm}
        onBpmChange={handleBpmChange}
        currentBeat={currentBeat}
        isLooping={isLooping}
        onToggleLoop={() => setIsLooping(!isLooping)}
        masterVolumeDb={masterVolumeDb}
        onMasterVolumeChange={(val) => {
          setMasterVolumeDb(val);
          getAudioEngine().setMasterVolume(val);
        }}
      />

      {/* Main Workspace Area Depending on Active View */}
      <div className="flex-1 flex overflow-hidden relative">
        {activeView === 'arrange' && (
          <ArrangeView
            project={project}
            currentBeat={currentBeat}
            onSelectTrack={setActiveTrack}
            onUpdateTrack={handleUpdateTrack}
            onSeek={(beat) => setCurrentBeat(beat)}
          />
        )}

        {activeView === 'mix' && (
          <MixerView
            project={project}
            onUpdateTrack={handleUpdateTrack}
            onUpdateMasterVolume={setMasterVolumeDb}
            isPlaying={isPlaying}
          />
        )}

        {activeView === 'synth' && <SynthWorkstationView />}

        {activeView === 'sampler' && <SamplingLabView />}

        {activeView === 'analysis' && <AnalysisView project={project} />}

        {activeView === 'generative' && <GenerativeLabView />}

        {activeView === 'mastering' && <MasteringLabView project={project} />}

        {activeView === 'catalogue' && <CatalogueProvenanceView />}

        {activeView === 'r-console' && <ConsoleRTerminalView />}
      </div>

      {/* Bottom Status Bar & Audio Telemetry */}
      <div className="h-6 bg-slate-950 border-t border-slate-800/80 px-3 flex items-center justify-between text-[10px] text-slate-400 font-mono shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <Radio className="w-3 h-3 animate-pulse" />
            <span>RUST DSP ENGINE: RUNNING (48.0 kHz / 24-BIT)</span>
          </div>
          <div className="h-3 w-px bg-slate-800" />
          <div className="flex items-center gap-1 text-slate-400">
            <span>BUFFER:</span>
            <span className="text-slate-200">128 SAMPLES (2.67ms)</span>
          </div>
          <div className="h-3 w-px bg-slate-800" />
          <div className="flex items-center gap-1 text-slate-400">
            <span>R IPC PIPE:</span>
            <span className="text-cyan-400 font-bold">/tmp/aureom_dsp.sock</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3 h-3 text-amber-400" />
            <span>DSP CPU:</span>
            <span className="text-amber-400 font-bold">{cpuUsage}%</span>
          </div>
          <div className="h-3 w-px bg-slate-800" />
          <div className="flex items-center gap-1.5">
            <HardDrive className="w-3 h-3 text-cyan-400" />
            <span>RAM:</span>
            <span className="text-slate-200">148 MB</span>
          </div>
          <div className="h-3 w-px bg-slate-800" />
          <span className="text-slate-500">AUREOM MUSIC.OS v2.4.0-PRO</span>
        </div>
      </div>
    </div>
  );
}
