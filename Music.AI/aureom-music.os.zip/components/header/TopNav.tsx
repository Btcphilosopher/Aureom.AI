'use client';

import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Square,
  Repeat,
  Circle,
  Volume2,
  Cpu,
  HardDrive,
  FileCode2,
  History,
  Download,
  Sliders,
  Sparkles,
  Activity,
  Layers,
  Music4,
  BarChart3,
  SlidersHorizontal,
  Compass,
  Radio,
  FolderGit2,
  Terminal
} from 'lucide-react';
import { ProjectState, ViewMode } from '@/types/audio';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

interface TopNavProps {
  activeView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  isPlaying: boolean;
  onPlayToggle: () => void;
  onStop: () => void;
  bpm: number;
  onBpmChange: (bpm: number) => void;
  currentBeat: number;
  isLooping: boolean;
  onToggleLoop: () => void;
  masterVolumeDb: number;
  onMasterVolumeChange: (volDb: number) => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeView,
  onSelectView,
  isPlaying,
  onPlayToggle,
  onStop,
  bpm,
  onBpmChange,
  currentBeat,
  isLooping,
  onToggleLoop,
  masterVolumeDb,
  onMasterVolumeChange
}) => {
  const [tapTimes, setTapTimes] = useState<number[]>([]);
  const [meters, setMeters] = useState({ left: 0, right: 0 });

  useEffect(() => {
    const engine = getAudioEngine();
    const timer = setInterval(() => {
      if (isPlaying) {
        const levels = engine.getMasterLevels();
        setMeters({ left: levels.peakLeft, right: levels.peakRight });
      } else {
        setMeters({ left: 0, right: 0 });
      }
    }, 80);
    return () => clearInterval(timer);
  }, [isPlaying]);

  const handleTapTempo = () => {
    const now = Date.now();
    const newTaps = [...tapTimes.slice(-3), now];
    setTapTimes(newTaps);
    if (newTaps.length >= 2) {
      const intervals = [];
      for (let i = 1; i < newTaps.length; i++) {
        intervals.push(newTaps[i] - newTaps[i - 1]);
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const calcBpm = Math.round(60000 / avgInterval);
      if (calcBpm >= 40 && calcBpm <= 280) {
        onBpmChange(calcBpm);
      }
    }
  };

  // Convert currentBeat to Bar : Beat : Sixteenth format
  const currentBar = Math.floor(currentBeat / 4) + 1;
  const beatInBar = Math.floor(currentBeat % 4) + 1;
  const sixteenth = Math.floor((currentBeat * 4) % 4) + 1;

  // Time in mm:ss.ms
  const totalSeconds = (currentBeat * 60) / bpm;
  const mins = Math.floor(totalSeconds / 60);
  const secs = Math.floor(totalSeconds % 60);
  const ms = Math.floor((totalSeconds % 1) * 100);

  const navItems: { id: ViewMode; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'arrange', label: 'ARRANGE', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'mix', label: 'MIXER', icon: <SlidersHorizontal className="w-3.5 h-3.5" /> },
    { id: 'synth', label: 'SYNTHESIS', icon: <Radio className="w-3.5 h-3.5" /> },
    { id: 'sampler', label: 'SAMPLER', icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'analysis', label: 'R-ANALYSIS', icon: <BarChart3 className="w-3.5 h-3.5" />, badge: 'R 4.4' },
    { id: 'generative', label: 'GENERATIVE', icon: <Sparkles className="w-3.5 h-3.5" />, badge: 'R↔RUST' },
    { id: 'mastering', label: 'MASTERING', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'catalogue', label: 'CATALOGUE & PROVENANCE', icon: <FolderGit2 className="w-3.5 h-3.5" /> },
    { id: 'r-console', label: 'R CONSOLE', icon: <Terminal className="w-3.5 h-3.5" /> }
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 select-none text-slate-100 flex flex-col z-30 shrink-0">
      {/* Top Utility & Transport Strip */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 bg-slate-900/90 gap-4">
        {/* Brand & System Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-amber-500/20 border border-amber-500/60 flex items-center justify-center font-mono font-bold text-amber-400 text-xs shadow-sm">
              Æ
            </div>
            <div>
              <div className="flex items-center gap-1.5 leading-none">
                <span className="font-mono font-black text-sm tracking-wider text-slate-100">AUREOM</span>
                <span className="font-mono text-[10px] px-1 py-0.5 rounded bg-slate-800 text-amber-400 border border-slate-700">MUSIC.OS</span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono tracking-tight">RUST DSP ↔ R STATISTICAL ENGINE</p>
            </div>
          </div>
        </div>

        {/* Central Transport & Timing Engine */}
        <div className="flex items-center gap-3">
          {/* Main Transport Buttons */}
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 shadow-inner">
            <button
              id="transport-stop-btn"
              onClick={onStop}
              title="Stop (Reset to Start)"
              className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
            >
              <Square className="w-4 h-4 fill-current" />
            </button>
            <button
              id="transport-play-btn"
              onClick={onPlayToggle}
              title={isPlaying ? 'Pause' : 'Play'}
              className={`px-3 py-1.5 rounded flex items-center gap-1.5 font-mono text-xs font-bold transition-all ${
                isPlaying
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-100'
              }`}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span>{isPlaying ? 'PAUSE' : 'PLAY'}</span>
            </button>
            <button
              id="transport-loop-btn"
              onClick={onToggleLoop}
              title="Toggle Loop Range"
              className={`p-1.5 rounded transition-colors ${
                isLooping ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Repeat className="w-4 h-4" />
            </button>
          </div>

          {/* Bar / Beat Counter Display */}
          <div className="flex items-center bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 font-mono">
            <div className="text-center">
              <span className="text-[9px] text-slate-500 uppercase block leading-none">Bar.Beat.16</span>
              <span className="text-sm font-bold text-amber-400 tracking-wider">
                {String(currentBar).padStart(3, '0')}.{beatInBar}.{sixteenth}
              </span>
            </div>
            <div className="h-6 w-px bg-slate-800 mx-3" />
            <div className="text-center">
              <span className="text-[9px] text-slate-500 uppercase block leading-none">Time Code</span>
              <span className="text-sm font-semibold text-slate-200 tracking-wider">
                {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}.{String(ms).padStart(2, '0')}
              </span>
            </div>
          </div>

          {/* Tempo & Time Signature Controls */}
          <div className="flex items-center bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 font-mono gap-2">
            <div>
              <span className="text-[9px] text-slate-500 uppercase block leading-none">TEMPO</span>
              <div className="flex items-center gap-1">
                <input
                  id="bpm-input"
                  type="number"
                  min="40"
                  max="280"
                  value={bpm}
                  onChange={(e) => onBpmChange(Number(e.target.value) || 120)}
                  className="w-12 bg-transparent text-sm font-bold text-slate-100 focus:outline-none focus:text-amber-400"
                />
                <span className="text-[10px] text-slate-400 font-normal">BPM</span>
              </div>
            </div>
            <button
              onClick={handleTapTempo}
              className="px-1.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-amber-300"
              title="Tap Tempo (click repeatedly in rhythm)"
            >
              TAP
            </button>
          </div>
        </div>

        {/* Master Volume & Peak Meters */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 font-mono">
            <Volume2 className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[10px] text-slate-400">MASTER:</span>
            <input
              type="range"
              min="-40"
              max="6"
              step="0.5"
              value={masterVolumeDb}
              onChange={(e) => onMasterVolumeChange(parseFloat(e.target.value))}
              className="w-16 accent-amber-400 h-1"
            />
            <span className="text-xs font-bold text-amber-400 w-10 text-right">
              {masterVolumeDb <= -40 ? '-∞' : `${masterVolumeDb.toFixed(1)}`}
            </span>
          </div>

          {/* Master Peak Level Bars */}
          <div className="w-12 h-6 bg-slate-950 rounded border border-slate-800 p-0.5 flex flex-col justify-between">
            <div className="w-full h-2 bg-slate-900 rounded-xs overflow-hidden">
              <div
                className="h-full bg-emerald-400 transition-all duration-75"
                style={{ width: `${Math.min(100, meters.left * 100)}%` }}
              />
            </div>
            <div className="w-full h-2 bg-slate-900 rounded-xs overflow-hidden">
              <div
                className="h-full bg-emerald-400 transition-all duration-75"
                style={{ width: `${Math.min(100, meters.right * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Mode Navigation Bar */}
      <nav className="flex items-center px-4 py-1.5 bg-slate-950 gap-1 overflow-x-auto scrollbar-none">
        {navItems.map((item) => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectView(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-mono font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
              {item.badge && (
                <span
                  className={`text-[9px] px-1 py-0.2 rounded font-mono ${
                    isActive ? 'bg-slate-950 text-amber-400' : 'bg-slate-800 text-amber-300'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
