'use client';

import React, { useState } from 'react';
import {
  Compass,
  Activity,
  Sliders,
  Volume2,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { computeMasteringMetrics } from '@/lib/r-engine/statistical-bridge';
import { ProjectState } from '@/types/audio';

interface MasteringLabViewProps {
  project: ProjectState;
}

export const MasteringLabView: React.FC<MasteringLabViewProps> = ({ project }) => {
  const [selectedRef, setSelectedRef] = useState<'ref_commercial' | 'ref_club' | 'ref_audiophile'>('ref_commercial');
  const metrics = computeMasteringMetrics();

  const refProfiles = {
    ref_commercial: {
      name: 'Commercial Streaming Standard (EBU R128 / Apple Music)',
      targetLufs: -14.0,
      targetTruePeak: -1.0,
      targetDr: 12.0,
      targetCorrelation: 0.85
    },
    ref_club: {
      name: 'Club Sound System / Festival Master',
      targetLufs: -9.0,
      targetTruePeak: -0.3,
      targetDr: 8.0,
      targetCorrelation: 0.70
    },
    ref_audiophile: {
      name: 'Audiophile Vinyl / High-Res FLAC Master',
      targetLufs: -18.0,
      targetTruePeak: -2.0,
      targetDr: 16.0,
      targetCorrelation: 0.92
    }
  };

  const currentRef = refProfiles[selectedRef];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto font-mono text-slate-200 select-none">
      {/* Mastering Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-amber-400" />
            MASTERING LABORATORY & EBU R128 METRICS
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/80">
            TRUE PEAK LIMITER: ENGAGED (-0.3 dBTP)
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">REFERENCE TARGET:</span>
          <select
            value={selectedRef}
            onChange={(e) => setSelectedRef(e.target.value as any)}
            className="bg-slate-950 border border-slate-700 rounded p-1 text-xs text-amber-400 font-bold"
          >
            <option value="ref_commercial">Streaming Target (-14 LUFS)</option>
            <option value="ref_club">Club Master (-9 LUFS)</option>
            <option value="ref_audiophile">Audiophile Master (-18 LUFS)</option>
          </select>
        </div>
      </div>

      {/* Main Mastering Metrics Dashboard */}
      <div className="flex-1 p-4 space-y-4">
        {/* Top 5 Core Meter Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">INTEGRATED LOUDNESS</span>
            <div className="text-xl font-black text-amber-400">{metrics.integratedLufs} LUFS</div>
            <div className="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Target: {currentRef.targetLufs}</span>
              <span className="text-emerald-400 font-bold">Δ 0.1 LU</span>
            </div>
          </div>

          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">TRUE PEAK MAX</span>
            <div className="text-xl font-black text-emerald-400">{metrics.truePeakDb} dBTP</div>
            <div className="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Ceiling: {currentRef.targetTruePeak}</span>
              <span className="text-emerald-400 font-bold">SAFE</span>
            </div>
          </div>

          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">DYNAMIC RANGE (DR)</span>
            <div className="text-xl font-black text-cyan-400">DR{Math.round(metrics.dynamicRangeDr)}</div>
            <div className="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Target: DR{Math.round(currentRef.targetDr)}</span>
              <span className="text-cyan-400 font-bold">Balanced</span>
            </div>
          </div>

          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">CREST FACTOR</span>
            <div className="text-xl font-black text-slate-100">{metrics.crestFactorDb} dB</div>
            <div className="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Peak to RMS</span>
              <span className="text-slate-300">Natural</span>
            </div>
          </div>

          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-1">PHASE CORRELATION</span>
            <div className="text-xl font-black text-emerald-400">+{metrics.stereoCorrelation}</div>
            <div className="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Range: -1 to +1</span>
              <span className="text-emerald-400 font-bold">MONO-SAFE</span>
            </div>
          </div>
        </div>

        {/* Middle Split: Goniometer / Lissajous Vectorscope & Frequency Spectrum Delta */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Stereo Goniometer Vectorscope */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-amber-400">LISSAJOUS STEREO FIELD GONIOMETER</span>
              <span className="text-[10px] text-slate-400">STEREO WIDTH: {metrics.stereoWidthPct}%</span>
            </div>

            <div className="h-56 bg-black rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
              <svg className="w-52 h-52" viewBox="-1.2 -1.2 2.4 2.4">
                {/* Diagonal Crosshair Guides */}
                <line x1="-1" y1="-1" x2="1" y2="1" stroke="#334155" strokeWidth="0.02" strokeDasharray="0.05" />
                <line x1="-1" y1="1" x2="1" y2="-1" stroke="#334155" strokeWidth="0.02" strokeDasharray="0.05" />
                <circle cx="0" cy="0" r="1" fill="none" stroke="#1e293b" strokeWidth="0.02" />
                
                {/* Goniometer Scatter / Lissajous Cloud */}
                {metrics.goniometerPoints.map((pt, i) => (
                  <circle
                    key={i}
                    cx={pt.x}
                    cy={pt.y}
                    r="0.03"
                    fill="#38bdf8"
                    opacity="0.75"
                  />
                ))}
              </svg>
              <div className="absolute top-2 left-2 text-[9px] text-slate-500 font-bold">L (+45°)</div>
              <div className="absolute top-2 right-2 text-[9px] text-slate-500 font-bold">R (-45°)</div>
              <div className="absolute bottom-2 text-[9px] text-emerald-400 font-bold">PHASE: +0.84 (SAFE)</div>
            </div>
          </div>

          {/* Reference Track Comparison Spectrum */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-cyan-400">REFERENCE TRACK SPECTRAL DELTA</span>
              <span className="text-[10px] text-slate-400">{currentRef.name.slice(0, 30)}...</span>
            </div>

            <div className="h-56 bg-black rounded-lg border border-slate-800 p-3 flex flex-col justify-between">
              <svg className="w-full h-40" viewBox="0 0 300 100">
                {/* 0 dB Center Baseline */}
                <line x1="10" y1="50" x2="290" y2="50" stroke="#475569" strokeWidth="1" strokeDasharray="3" />
                {/* Reference Curve (Gold) */}
                <path
                  d="M 10 50 Q 75 35 150 48 T 290 55"
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2"
                />
                {/* Current Track Curve (Cyan) */}
                <path
                  d="M 10 52 Q 75 38 150 50 T 290 52"
                  fill="none"
                  stroke="#06b6d4"
                  strokeWidth="2"
                />
              </svg>

              <div className="flex justify-between text-[9px] text-slate-400 border-t border-slate-800 pt-1">
                <span>SUB (40Hz)</span>
                <span>LOW-MID (350Hz)</span>
                <span>MID (2.5kHz)</span>
                <span>HIGH (10kHz)</span>
                <span>AIR (18kHz)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Mastering Diagnostic Checklist */}
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
          <span className="text-xs font-bold text-slate-200 block mb-3">AUTOMATED EBU R128 COMPLIANCE REPORT</span>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="flex items-center gap-2 bg-slate-950 p-2.5 rounded border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold text-slate-200 block">Loudness Target Met</span>
                <span className="text-[10px] text-slate-400">-14.1 LUFS ± 0.5 LU tolerance</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-slate-950 p-2.5 rounded border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold text-slate-200 block">Zero Intersample Overs</span>
                <span className="text-[10px] text-slate-400">Peak capped strictly at -0.8 dBTP</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-slate-950 p-2.5 rounded border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold text-slate-200 block">Low-End Mono Stability</span>
                <span className="text-[10px] text-slate-400">Sub 120Hz 100% phase-aligned</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
