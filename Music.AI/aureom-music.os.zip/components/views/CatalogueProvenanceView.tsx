'use client';

import React, { useState } from 'react';
import {
  FolderGit2,
  Database,
  Search,
  GitBranch,
  History,
  FlaskConical,
  Play,
  ArrowRight,
  ShieldCheck,
  Tag,
  CheckCircle2,
  Layers
} from 'lucide-react';
import { mockCatalogueAssets, mockProvenanceTree, mockExperiments } from '@/lib/catalogue/mock-data';
import { CatalogueAsset, ProvenanceRecord, Experiment } from '@/types/audio';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

export const CatalogueProvenanceView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'catalogue' | 'provenance' | 'experiments'>('catalogue');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAsset, setSelectedAsset] = useState<CatalogueAsset>(mockCatalogueAssets[0]);
  const [selectedExperiment, setSelectedExperiment] = useState<Experiment>(mockExperiments[0]);

  const filteredAssets = mockCatalogueAssets.filter((a) =>
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
    a.key.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAuditionAsset = (asset: CatalogueAsset) => {
    const engine = getAudioEngine();
    if (asset.type === 'drum') engine.playDrumHit('kick');
    else if (asset.type === 'synth') engine.playSubtractiveSynth(440, 0.8);
    else engine.playPluckedString(330, 0.9);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto font-mono text-slate-200 select-none">
      {/* Catalogue & Provenance Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <FolderGit2 className="w-4 h-4 text-amber-400" />
            CATALOGUE, PROVENANCE & EXPERIMENTATION
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'catalogue', label: 'ASSET CATALOGUE & DNA SEARCH', icon: <Database className="w-3.5 h-3.5" /> },
                { id: 'provenance', label: 'PROVENANCE GRAPH (AUDIT TREE)', icon: <GitBranch className="w-3.5 h-3.5" /> },
                { id: 'experiments', label: 'EXPERIMENTATION & A/B BENCH', icon: <FlaskConical className="w-3.5 h-3.5" /> }
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold transition-all ${
                  activeTab === tab.id
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/80">
          <ShieldCheck className="w-3 h-3" />
          <span>CRYPTOGRAPHIC HASH INTEGRITY: 100%</span>
        </div>
      </div>

      {/* TAB 1: ASSET CATALOGUE */}
      {activeTab === 'catalogue' && (
        <div className="flex-1 p-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Asset List & Search */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col shadow-xl">
            {/* Search Input */}
            <div className="relative mb-3">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, tag, key (e.g. 'D min', 'Moog', 'Kick', '118 BPM')..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Asset Table */}
            <div className="flex-1 overflow-y-auto border border-slate-800 rounded-lg bg-slate-950">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[10px]">
                  <tr>
                    <th className="p-2.5">NAME & TYPE</th>
                    <th className="p-2.5">KEY / BPM</th>
                    <th className="p-2.5">LUFS</th>
                    <th className="p-2.5">DYNAMIC RANGE</th>
                    <th className="p-2.5">ACTION</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900">
                  {filteredAssets.map((asset) => {
                    const isSel = selectedAsset.id === asset.id;
                    return (
                      <tr
                        key={asset.id}
                        onClick={() => setSelectedAsset(asset)}
                        className={`cursor-pointer transition-colors ${
                          isSel ? 'bg-slate-800/80' : 'hover:bg-slate-900/60'
                        }`}
                      >
                        <td className="p-2.5">
                          <div className="font-bold text-slate-200">{asset.name}</div>
                          <div className="text-[10px] text-slate-400 uppercase">{asset.type} • {asset.sampleRate / 1000}kHz</div>
                        </td>
                        <td className="p-2.5 text-slate-300">
                          {asset.key} • {asset.bpm} BPM
                        </td>
                        <td className="p-2.5 text-amber-400 font-semibold">{asset.lufs} LUFS</td>
                        <td className="p-2.5 text-cyan-400 font-semibold">DR{asset.dynamicRange}</td>
                        <td className="p-2.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAuditionAsset(asset);
                            }}
                            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-400"
                            title="Audition Sound"
                          >
                            <Play className="w-3 h-3 fill-current" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Selected Asset Metadata & DNA Details */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
            <div>
              <div className="border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-amber-400 block">{selectedAsset.name}</span>
                <span className="text-[10px] text-slate-400">HASH: {selectedAsset.sha256.slice(0, 20)}...</span>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 mb-4">
                {selectedAsset.tags.map((t, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-cyan-300">
                    #{t}
                  </span>
                ))}
              </div>

              {/* DNA Vectors Comparison */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Acoustic DNA Score</span>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Harmonicity:</span>
                    <span className="text-amber-400 font-bold">{Math.round(selectedAsset.dnaVector.harmonicity * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Spectral Brightness:</span>
                    <span className="text-cyan-400 font-bold">{Math.round(selectedAsset.dnaVector.brightness * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Rhythmic Density:</span>
                    <span className="text-emerald-400 font-bold">{Math.round(selectedAsset.dnaVector.rhythmDensity * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Energy Profile:</span>
                    <span className="text-fuchsia-400 font-bold">{Math.round(selectedAsset.dnaVector.energy * 100)}%</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleAuditionAsset(selectedAsset)}
              className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 shadow-md transition-colors mt-4"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>LOAD INTO ACTIVE SESSION</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: PROVENANCE GRAPH (AUDIT TRAIL) */}
      {activeTab === 'provenance' && (
        <div className="flex-1 p-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-amber-400">NON-DESTRUCTIVE TRANSFORMATION TREE (GRAPH)</span>
              <span className="text-[10px] text-slate-400">100% REVERSIBLE PARAMETRIC GRAPH</span>
            </div>

            <div className="space-y-3">
              {mockProvenanceTree.map((node, idx) => (
                <div
                  key={node.id}
                  className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-start justify-between relative pl-8"
                >
                  {/* Step index badge */}
                  <div className="absolute left-2.5 top-3.5 w-4 h-4 rounded-full bg-amber-500/20 border border-amber-500/60 text-amber-400 text-[9px] font-bold flex items-center justify-center">
                    {idx + 1}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-100">{node.action}</span>
                      <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800">
                        {node.engine}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      INPUT: <span className="text-slate-300 font-mono">{node.inputHash.slice(0, 16)}...</span> → OUTPUT: <span className="text-slate-300 font-mono">{node.outputHash.slice(0, 16)}...</span>
                    </div>
                    <div className="text-[10px] text-amber-300/80 bg-slate-900/90 p-1.5 rounded font-mono mt-1">
                      PARAMS: {JSON.stringify(node.parameters)}
                    </div>
                  </div>

                  <div className="text-right text-[9px] text-slate-500 shrink-0 ml-4">
                    {new Date(node.timestamp).toLocaleTimeString()}
                    <button className="block mt-2 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold">
                      ROLLBACK
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: EXPERIMENTATION & A/B BENCH */}
      {activeTab === 'experiments' && (
        <div className="flex-1 p-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-cyan-400">AUDIO DSP EXPERIMENTS & A/B TESTS</span>
              <span className="text-[10px] text-slate-400">OBJECTIVE STATISTICAL SCORING</span>
            </div>

            <div className="space-y-3">
              {mockExperiments.map((exp) => (
                <div
                  key={exp.id}
                  onClick={() => setSelectedExperiment(exp)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedExperiment.id === exp.id
                      ? 'bg-slate-800/90 border-cyan-500/80 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-100">{exp.name}</span>
                    <span className="text-[10px] text-emerald-400 font-bold">WINNER: {exp.winnerBranch.toUpperCase()}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">{exp.hypothesis}</p>

                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800/80 text-[10px]">
                    <div className="bg-slate-900 p-1.5 rounded">
                      <span className="text-slate-400 block font-bold">BRANCH A ({exp.variantA.name}):</span>
                      <span className="text-slate-200">LUFS: {exp.variantA.lufs} | THD: {exp.variantA.thd}%</span>
                    </div>
                    <div className="bg-slate-900 p-1.5 rounded">
                      <span className="text-slate-400 block font-bold">BRANCH B ({exp.variantB.name}):</span>
                      <span className="text-slate-200">LUFS: {exp.variantB.lufs} | THD: {exp.variantB.thd}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
            <div>
              <div className="border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-amber-400 block">{selectedExperiment.name}</span>
                <span className="text-[10px] text-slate-400">HYPOTHESIS VERIFICATION</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800 mb-3">
                {selectedExperiment.hypothesis}
              </p>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">THD Reduction:</span>
                  <span className="text-emerald-400 font-bold">-0.09% (Significant)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Crest Factor:</span>
                  <span className="text-cyan-400 font-bold">+1.2 dB Dynamics Preserved</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Subjective Clarity:</span>
                  <span className="text-amber-400 font-bold">88% Preference</span>
                </div>
              </div>
            </div>

            <button className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-lg transition-colors mt-4">
              MERGE WINNING VARIANT B INTO MAIN BUS
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
