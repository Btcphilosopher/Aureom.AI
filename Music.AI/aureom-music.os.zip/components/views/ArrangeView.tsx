'use client';

import React, { useState, useRef } from 'react';
import {
  Volume2,
  VolumeX,
  Radio,
  Sliders,
  Play,
  Grid,
  Maximize2,
  Minimize2,
  Eye,
  Plus,
  Layers,
  Sparkles
} from 'lucide-react';
import { ProjectState, Track, AudioClip } from '@/types/audio';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

interface ArrangeViewProps {
  project: ProjectState;
  currentBeat: number;
  onSelectTrack: (track: Track) => void;
  onUpdateTrack: (updatedTrack: Track) => void;
  onSeek: (beat: number) => void;
}

export const ArrangeView: React.FC<ArrangeViewProps> = ({
  project,
  currentBeat,
  onSelectTrack,
  onUpdateTrack,
  onSeek
}) => {
  const [selectedTrackId, setSelectedTrackId] = useState<string>(project.tracks[0]?.id || '');
  const [zoomLevel, setZoomLevel] = useState<number>(24); // pixels per beat
  const [snapGrid, setSnapGrid] = useState<'1/4' | '1/8' | '1/16' | 'off'>('1/4');
  const [expandedAutomation, setExpandedAutomation] = useState<Record<string, boolean>>({});
  const timelineRef = useRef<HTMLDivElement>(null);

  const totalBars = project.totalBars;
  const totalBeats = totalBars * 4;

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left + timelineRef.current.scrollLeft;
    let targetBeat = Math.max(0, clickX / zoomLevel);
    if (snapGrid === '1/4') targetBeat = Math.round(targetBeat);
    else if (snapGrid === '1/8') targetBeat = Math.round(targetBeat * 2) / 2;
    else if (snapGrid === '1/16') targetBeat = Math.round(targetBeat * 4) / 4;
    onSeek(targetBeat);
  };

  const handleAuditionTrack = (track: Track) => {
    const engine = getAudioEngine();
    if (track.type === 'drum') {
      if (track.id.includes('kick')) engine.playDrumHit('kick');
      else if (track.id.includes('snare')) engine.playDrumHit('snare');
      else if (track.id.includes('perc')) engine.playDrumHit('perc');
      else engine.playDrumHit('clap');
    } else if (track.id.includes('arp')) {
      engine.playPluckedString(440, 0.8);
    } else if (track.id.includes('fm')) {
      engine.playFmSynth(110, 0.6);
    } else {
      engine.playSubtractiveSynth(220, 0.8);
    }
  };

  const toggleMute = (track: Track) => {
    const updated = { ...track, isMuted: !track.isMuted };
    onUpdateTrack(updated);
    const engine = getAudioEngine();
    engine.setTrackVolume(track.id, updated.isMuted ? -96 : updated.volumeDb);
  };

  const toggleSolo = (track: Track) => {
    const updated = { ...track, isSoloed: !track.isSoloed };
    onUpdateTrack(updated);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden font-sans">
      {/* Arrange Toolbar Strip */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 bg-slate-900/60">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            TIMELINE ARRANGEMENT
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
            <Grid className="w-3.5 h-3.5 text-slate-500" />
            <span>SNAP:</span>
            {(['1/4', '1/8', '1/16', 'off'] as const).map((snap) => (
              <button
                key={snap}
                onClick={() => setSnapGrid(snap)}
                className={`px-1.5 py-0.5 rounded text-[10px] ${
                  snapGrid === snap ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50' : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
                }`}
              >
                {snap.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-2 font-mono text-xs text-slate-400">
          <span>ZOOM:</span>
          <button
            onClick={() => setZoomLevel(Math.max(12, zoomLevel - 6))}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
            title="Zoom Out"
          >
            <Minimize2 className="w-3 h-3" />
          </button>
          <span className="w-10 text-center text-[10px] text-slate-200">{zoomLevel}px</span>
          <button
            onClick={() => setZoomLevel(Math.min(64, zoomLevel + 6))}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
            title="Zoom In"
          >
            <Maximize2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Workspace Split: Track Headers Left | Timeline Scroll Area Right */}
      <div className="flex-1 flex overflow-hidden">
        {/* Track Headers Panel (Fixed Width) */}
        <div className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 overflow-y-auto">
          {/* Section Marker Header spacer */}
          <div className="h-8 border-b border-slate-800 px-3 flex items-center justify-between text-[10px] font-mono text-slate-400 bg-slate-950">
            <span>TRACK / BUS</span>
            <span>VOL / PAN</span>
          </div>

          {/* Track Rows */}
          {project.tracks.map((track) => {
            const isSelected = track.id === selectedTrackId;
            return (
              <div
                key={track.id}
                onClick={() => {
                  setSelectedTrackId(track.id);
                  onSelectTrack(track);
                }}
                className={`h-16 border-b border-slate-800/80 px-2.5 py-1.5 flex flex-col justify-between cursor-pointer transition-colors ${
                  isSelected ? 'bg-slate-800/90 border-l-2 border-l-amber-400' : 'hover:bg-slate-850 bg-slate-900/60'
                }`}
              >
                {/* Track Title & Solo / Mute */}
                <div className="flex items-center justify-between gap-1">
                  <div className="flex items-center gap-1.5 overflow-hidden">
                    <div
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{ backgroundColor: track.color }}
                    />
                    <span className="font-mono text-xs font-semibold text-slate-200 truncate" title={track.name}>
                      {track.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleMute(track);
                      }}
                      className={`w-5 h-5 rounded text-[10px] font-mono font-bold flex items-center justify-center transition-colors ${
                        track.isMuted ? 'bg-rose-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                      title="Mute Track"
                    >
                      M
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSolo(track);
                      }}
                      className={`w-5 h-5 rounded text-[10px] font-mono font-bold flex items-center justify-center transition-colors ${
                        track.isSoloed ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                      title="Solo Track"
                    >
                      S
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAuditionTrack(track);
                      }}
                      className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 flex items-center justify-center"
                      title="Audition Sound"
                    >
                      <Play className="w-2.5 h-2.5 fill-current" />
                    </button>
                  </div>
                </div>

                {/* Fader / Pan mini controls */}
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1">
                  <div className="flex items-center gap-1">
                    <span>VOL:</span>
                    <span className="text-slate-200">{track.volumeDb.toFixed(1)}dB</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span>PAN:</span>
                    <span className="text-slate-200">{track.pan === 0 ? 'C' : track.pan > 0 ? `R${Math.round(track.pan*50)}` : `L${Math.round(-track.pan*50)}`}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Timeline Area (Horizontally and Vertically Scrollable) */}
        <div
          ref={timelineRef}
          onClick={handleTimelineClick}
          className="flex-1 bg-slate-950 overflow-x-auto overflow-y-auto relative scrollbar-thin select-none"
        >
          {/* Internal Timeline Canvas Container */}
          <div
            style={{ width: `${totalBeats * zoomLevel}px` }}
            className="min-h-full flex flex-col relative"
          >
            {/* Song Sections Ruler Strip */}
            <div className="h-8 bg-slate-900/90 border-b border-slate-800 flex relative sticky top-0 z-20">
              {project.sections.map((sec) => {
                const left = (sec.startBar - 1) * 4 * zoomLevel;
                const width = sec.lengthBars * 4 * zoomLevel;
                return (
                  <div
                    key={sec.id}
                    style={{ left: `${left}px`, width: `${width}px` }}
                    className="absolute top-0 bottom-0 border-r border-slate-700/80 px-2 flex items-center justify-between text-[10px] font-mono font-bold text-slate-200 overflow-hidden"
                  >
                    <div className="flex items-center gap-1 truncate">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: sec.color }} />
                      <span>{sec.name}</span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">
                      {Math.round(sec.confidence * 100)}%
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Bars & Beats Ruler */}
            <div className="h-5 bg-slate-950 border-b border-slate-800/80 flex relative font-mono text-[9px] text-slate-500">
              {Array.from({ length: totalBars }).map((_, barIdx) => (
                <div
                  key={barIdx}
                  style={{ left: `${barIdx * 4 * zoomLevel}px`, width: `${4 * zoomLevel}px` }}
                  className="absolute top-0 bottom-0 border-l border-slate-800/60 pl-1 flex items-center"
                >
                  <span className="font-semibold text-slate-400">{barIdx + 1}</span>
                </div>
              ))}
            </div>

            {/* Playhead Scrub Line */}
            <div
              style={{ left: `${currentBeat * zoomLevel}px` }}
              className="absolute top-0 bottom-0 w-px bg-amber-400 z-30 pointer-events-none shadow-[0_0_8px_rgba(245,158,11,0.8)]"
            >
              <div className="w-3 h-3 -ml-1.5 -mt-1 bg-amber-400 rotate-45" />
            </div>

            {/* Track Clip Lanes */}
            <div className="flex-1 flex flex-col">
              {project.tracks.map((track) => (
                <div
                  key={track.id}
                  className="h-16 border-b border-slate-900 relative flex items-center bg-slate-950/40"
                >
                  {/* Grid Lines */}
                  {Array.from({ length: totalBars }).map((_, barIdx) => (
                    <div
                      key={barIdx}
                      style={{ left: `${barIdx * 4 * zoomLevel}px` }}
                      className="absolute top-0 bottom-0 w-px bg-slate-900 pointer-events-none"
                    />
                  ))}

                  {/* Render Audio / MIDI Clips */}
                  {track.clips.map((clip) => {
                    const clipLeft = clip.startBeat * zoomLevel;
                    const clipWidth = clip.lengthBeats * zoomLevel;
                    return (
                      <div
                        key={clip.id}
                        style={{
                          left: `${clipLeft}px`,
                          width: `${clipWidth}px`,
                          borderColor: clip.color,
                          backgroundColor: `${clip.color}20`
                        }}
                        className="h-12 absolute rounded border border-l-2 p-1 overflow-hidden flex flex-col justify-between cursor-pointer hover:brightness-110 shadow-sm transition-all"
                      >
                        {/* Clip Label */}
                        <div className="flex items-center justify-between text-[10px] font-mono font-medium text-slate-100 truncate px-1">
                          <span className="truncate">{clip.name}</span>
                          <span className="text-[9px] text-slate-400 shrink-0">
                            {clip.lengthBeats / 4} bars
                          </span>
                        </div>

                        {/* Synthetic Waveform Pyramid Visualizer */}
                        <div className="h-6 w-full flex items-center justify-around gap-0.5 px-1 opacity-70">
                          {Array.from({ length: Math.floor(clipWidth / 4) }).map((_, i) => {
                            // Simulated deterministic waveform pattern based on clip and index
                            const h = Math.abs(Math.sin((i + clip.startBeat) * 0.4) * Math.cos(i * 0.15)) * 100;
                            return (
                              <div
                                key={i}
                                style={{
                                  height: `${Math.max(15, h)}%`,
                                  backgroundColor: clip.color
                                }}
                                className="w-0.5 rounded-full"
                              />
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
