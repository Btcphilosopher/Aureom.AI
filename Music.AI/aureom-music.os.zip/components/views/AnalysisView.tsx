'use client';

import React, { useState } from 'react';
import {
  BarChart3,
  Activity,
  Layers,
  Music2,
  PieChart,
  Sliders,
  Sparkles,
  FileCode2,
  Download,
  Info
} from 'lucide-react';
import {
  computeSpectralMetrics,
  computeRhythmProfile,
  computeHarmonicProfile,
  computeTimbreVector,
  computeMusicalDNA,
  computeArrangementDensity
} from '@/lib/r-engine/statistical-bridge';
import { ProjectState } from '@/types/audio';

interface AnalysisViewProps {
  project: ProjectState;
}

type AnalysisTab = 
  | 'overview'
  | 'spectrum'
  | 'rhythm'
  | 'harmony'
  | 'timbre'
  | 'structure'
  | 'arrangement';

export const AnalysisView: React.FC<AnalysisViewProps> = ({ project }) => {
  const [activeTab, setActiveTab] = useState<AnalysisTab>('overview');
  const [selectedBar, setSelectedBar] = useState<number>(25); // Chorus 1

  const spectral = computeSpectralMetrics();
  const rhythm = computeRhythmProfile(project.bpm);
  const harmonic = computeHarmonicProfile();
  const timbre = computeTimbreVector();
  const dna = computeMusicalDNA(project.bpm);
  const arrangement = computeArrangementDensity(project.totalBars);

  const tabs: { id: AnalysisTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'MUSICAL DNA (R-SUMMARY)', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'spectrum', label: 'SPECTRAL & STFT', icon: <BarChart3 className="w-3.5 h-3.5" /> },
    { id: 'rhythm', label: 'RHYTHM & SYNCOPATION', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'harmony', label: 'HARMONY & CHROMA', icon: <Music2 className="w-3.5 h-3.5" /> },
    { id: 'timbre', label: 'TIMBRE 9D SPACE', icon: <PieChart className="w-3.5 h-3.5" /> },
    { id: 'structure', label: 'SONG STRUCTURE', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'arrangement', label: 'ARRANGEMENT DENSITY', icon: <Sliders className="w-3.5 h-3.5" /> }
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto font-mono text-slate-200 select-none">
      {/* Analysis Suite Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            aureomMusicR STATISTICAL & ACOUSTIC LABORATORY
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/80">
            R ENGINE: v4.4.2 ACTIVE
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">DATASET:</span>
          <span className="text-amber-400 font-bold">{project.name} (48kHz)</span>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex items-center px-4 py-1.5 bg-slate-950 border-b border-slate-800/80 gap-1 overflow-x-auto scrollbar-none">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === t.id
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/80 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            {t.icon}
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* Main Analysis Content Panel */}
      <div className="flex-1 p-4">
        {/* TAB 1: OVERVIEW & MUSICAL DNA */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-1">MEASURED KEY</span>
                <span className="text-lg font-black text-amber-400">{harmonic.estimatedKey}</span>
                <span className="text-[9px] text-emerald-400 block mt-1">Confidence: {Math.round(harmonic.keyConfidence * 100)}%</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-1">INTEGRATED LOUDNESS</span>
                <span className="text-lg font-black text-cyan-400">{dna.loudnessLufs} LUFS</span>
                <span className="text-[9px] text-slate-400 block mt-1">Target EBU R128: -14.0</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-1">SPECTRAL CENTROID</span>
                <span className="text-lg font-black text-slate-100">{spectral.centroid} Hz</span>
                <span className="text-[9px] text-slate-400 block mt-1">Rolloff (85%): {spectral.rolloff85} Hz</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-1">SYNCOPATION INDEX</span>
                <span className="text-lg font-black text-fuchsia-400">{rhythm.syncopationIndex}</span>
                <span className="text-[9px] text-slate-400 block mt-1">Swing: {rhythm.swingFactor}%</span>
              </div>
            </div>

            {/* Radar / Spider Chart Vector */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                  <span className="text-xs font-bold text-amber-400">MUSICAL DNA FEATURE VECTOR</span>
                  <span className="text-[10px] text-slate-400">8 MEASURED ACOUSTIC DIMENSIONS</span>
                </div>

                <div className="space-y-2.5">
                  {dna.radarMetrics.map((m, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-300">{m.label}</span>
                        <span className="text-amber-400 font-bold">{m.value}/100</span>
                      </div>
                      <div className="h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-amber-400 rounded-full"
                          style={{ width: `${m.value}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* R Interpretation & Empirical Reasoning */}
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                    <span className="text-xs font-bold text-cyan-400">R MODEL DIAGNOSTICS & PROBABILITIES</span>
                    <span className="text-[10px] text-slate-400">aureomMusicR::dna_summary()</span>
                  </div>

                  <div className="space-y-2 text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800/80">
                    <p>
                      <strong className="text-amber-400">1. Tonal Center:</strong> Strong minor triad weighting (D-F-A) with 93% Krumhansl-Schmuckler correlation. Modal interchange detected in Bars 25-32 toward F Major.
                    </p>
                    <p>
                      <strong className="text-cyan-400">2. Spectral Balance:</strong> Warm analog low-end contour (34% sub-140Hz energy), smooth rolloff above 8.5kHz. Spectral flatness at 0.042 indicates high harmonic tonality with low broadband noise.
                    </p>
                    <p>
                      <strong className="text-emerald-400">3. Rhythmic Complexity:</strong> Polymetric 7/8 percussion track introduces polyrhythmic tension without destabilizing the 118 BPM 4/4 primary beat grid.
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                  <span>SHA256 FEATURE HASH: 9a912e75cb...</span>
                  <span className="text-emerald-400">CONFIDENCE: PASS (p &lt; 0.001)</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SPECTRAL & STFT */}
        {activeTab === 'spectrum' && (
          <div className="space-y-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-amber-400">SHORT-TIME FOURIER TRANSFORM (STFT SPECTROGRAM)</span>
                <span className="text-[10px] text-slate-400">FFT SIZE: 2048 | HANNING WINDOW | 48kHz</span>
              </div>

              {/* STFT Heatmap Grid */}
              <div className="h-56 bg-black rounded-lg border border-slate-800 p-2 flex flex-col justify-between overflow-hidden">
                <div className="flex-1 flex items-end gap-1">
                  {spectral.stftMatrix.map((frame, timeIdx) => (
                    <div key={timeIdx} className="flex-1 h-full flex flex-col-reverse gap-0.5">
                      {frame.slice(0, 24).map((val, freqIdx) => {
                        // Heatmap color interpolation from navy -> cyan -> amber -> red
                        const col =
                          val > 0.75 ? '#f43f5e' : val > 0.5 ? '#f59e0b' : val > 0.25 ? '#06b6d4' : '#1e293b';
                        return (
                          <div
                            key={freqIdx}
                            style={{ backgroundColor: col, opacity: Math.max(0.2, val) }}
                            className="w-full h-1.5 rounded-xs"
                          />
                        );
                      })}
                    </div>
                  ))}
                </div>

                <div className="flex justify-between text-[9px] text-slate-500 pt-1 border-t border-slate-800">
                  <span>0:00 (Intro)</span>
                  <span>1:00 (Verse 1)</span>
                  <span>2:00 (Chorus 1)</span>
                  <span>3:00 (Outro)</span>
                </div>
              </div>
            </div>

            {/* Spectral Metrics Grid */}
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">SPECTRAL CENTROID</span>
                <span className="text-sm font-bold text-amber-400">{spectral.centroid} Hz</span>
                <span className="text-[9px] text-slate-500 block mt-0.5">Brightness center of mass</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">SPECTRAL SPREAD</span>
                <span className="text-sm font-bold text-cyan-400">{spectral.spread} Hz</span>
                <span className="text-[9px] text-slate-500 block mt-0.5">Bandwidth dispersion around centroid</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">SPECTRAL FLATNESS</span>
                <span className="text-sm font-bold text-emerald-400">{spectral.flatness}</span>
                <span className="text-[9px] text-slate-500 block mt-0.5">Tonal (0.0) vs Noise (1.0)</span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: RHYTHM & SYNCOPATION */}
        {activeTab === 'rhythm' && (
          <div className="space-y-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-fuchsia-400">ONSET DETECTION FUNCTION & BEAT GRID</span>
                <span className="text-[10px] text-slate-400">SPECTRAL FLUX DERIVATIVE</span>
              </div>

              {/* Onset Curve Visualizer */}
              <div className="h-40 bg-black rounded-lg border border-slate-800 p-2 flex items-end gap-1">
                {rhythm.onsetCurve.map((strength, idx) => (
                  <div key={idx} className="flex-1 flex flex-col justify-end items-center h-full">
                    <div
                      style={{
                        height: `${Math.round(strength * 100)}%`,
                        backgroundColor: idx % 8 === 0 ? '#ec4899' : idx % 2 === 0 ? '#38bdf8' : '#334155'
                      }}
                      className="w-full rounded-t"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-3 text-xs">
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">SYNCOPATION INDEX</span>
                <span className="text-sm font-bold text-fuchsia-400">{rhythm.syncopationIndex}</span>
                <span className="text-[9px] text-slate-500 block">Longuet-Higgins & Lee</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">SWING GROOVE</span>
                <span className="text-sm font-bold text-amber-400">{rhythm.swingFactor}%</span>
                <span className="text-[9px] text-slate-500 block">50% = Straight, 66% = Triplet</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">ONSET DENSITY</span>
                <span className="text-sm font-bold text-cyan-400">{rhythm.onsetDensity} onsets/sec</span>
                <span className="text-[9px] text-slate-500 block">Rhythmic rate</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] text-slate-400 block">MICROTIMING JITTER</span>
                <span className="text-sm font-bold text-emerald-400">±{rhythm.microtimingJitterMs} ms</span>
                <span className="text-[9px] text-slate-500 block">Human groove deviation</span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: HARMONY & CHROMA */}
        {activeTab === 'harmony' && (
          <div className="space-y-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-amber-400">12-DIMENSIONAL CHROMAGRAM DISTRIBUTION</span>
                <span className="text-[10px] text-slate-400">PITCH CLASS ENERGY PROFILING</span>
              </div>

              {/* Chroma Vector Bars */}
              <div className="grid grid-cols-12 gap-2 h-36 bg-black p-3 rounded-lg border border-slate-800 items-end">
                {['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'].map((pitch, idx) => {
                  const val = harmonic.chromaVector[idx] || 0.1;
                  return (
                    <div key={idx} className="flex flex-col items-center h-full justify-end">
                      <div
                        style={{ height: `${Math.round(val * 100)}%` }}
                        className={`w-full rounded-t ${
                          val > 0.8 ? 'bg-amber-400' : val > 0.5 ? 'bg-cyan-400' : 'bg-slate-700'
                        }`}
                      />
                      <span className="text-[10px] font-bold text-slate-300 mt-1">{pitch}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Chord Progression Timeline */}
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-xs font-bold text-cyan-400 block mb-2">CHORD PROGRESSION ESTIMATION</span>
              <div className="grid grid-cols-4 gap-2">
                {harmonic.chordProgression.map((ch, idx) => (
                  <div key={idx} className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-[9px] text-slate-500 block">BAR {ch.bar} ({ch.timeSeconds}s)</span>
                    <span className="text-sm font-black text-amber-400">{ch.chord}</span>
                    <span className="text-[9px] text-emerald-400 block mt-0.5">Conf: {Math.round(ch.confidence * 100)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: TIMBRE 9D SPACE */}
        {activeTab === 'timbre' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              {Object.entries(timbre).map(([key, val]) => (
                <div key={key} className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase block">{key.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="text-sm font-bold text-amber-400">
                    {typeof val === 'number' ? (val < 1 ? val.toFixed(3) : val.toFixed(1)) : val}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: SONG STRUCTURE */}
        {activeTab === 'structure' && (
          <div className="space-y-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-amber-400">AUTOMATIC BOUNDARY SEGMENTATION</span>
                <span className="text-[10px] text-slate-400">NOVELTY SCORE CHANGE-POINT DETECTION</span>
              </div>

              <div className="space-y-2">
                {project.sections.map((sec) => (
                  <div
                    key={sec.id}
                    className="flex items-center justify-between bg-slate-950 p-2.5 rounded-lg border border-slate-800"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: sec.color }} />
                      <span className="text-xs font-bold text-slate-200">{sec.name}</span>
                      <span className="text-[10px] text-slate-400">
                        Bars {sec.startBar} - {sec.startBar + sec.lengthBars - 1} ({sec.lengthBars} bars)
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs">
                      <span className="text-emerald-400 font-bold">Conf: {Math.round(sec.confidence * 100)}%</span>
                      <button className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300">
                        RENAME
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: ARRANGEMENT DENSITY */}
        {activeTab === 'arrangement' && (
          <div className="space-y-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-cyan-400">BAR-BY-BAR ARRANGEMENT DENSITY MODEL</span>
                <span className="text-[10px] text-slate-400">CLICK BAR TO INSPECT ACOUSTIC LOAD</span>
              </div>

              {/* Bar Density Matrix */}
              <div className="h-44 bg-black rounded-lg border border-slate-800 p-2 flex items-end gap-1 overflow-x-auto">
                {arrangement.slice(0, 64).map((b) => (
                  <button
                    key={b.bar}
                    onClick={() => setSelectedBar(b.bar)}
                    className="flex-1 flex flex-col justify-end items-center h-full group"
                    title={`Bar ${b.bar}: ${b.activeTracks} tracks, Energy: ${b.energy}%`}
                  >
                    <div
                      style={{ height: `${b.energy}%` }}
                      className={`w-full rounded-t transition-all ${
                        selectedBar === b.bar
                          ? 'bg-amber-400'
                          : b.energy > 80
                          ? 'bg-rose-500'
                          : b.energy > 50
                          ? 'bg-cyan-500'
                          : 'bg-slate-700'
                      }`}
                    />
                    <span className="text-[7px] text-slate-500 mt-1">{b.bar}</span>
                  </button>
                ))}
              </div>

              {/* Selected Bar Diagnostic Readout */}
              <div className="mt-3 bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
                <span className="font-bold text-amber-400">BAR {selectedBar} DIAGNOSTIC:</span>
                <span className="text-slate-300">Active Tracks: {arrangement[selectedBar - 1]?.activeTracks || 8}</span>
                <span className="text-cyan-400">Energy: {arrangement[selectedBar - 1]?.energy || 75}%</span>
                <span className="text-emerald-400">Dynamic Range: {arrangement[selectedBar - 1]?.dynamicRange || 14.2} dB</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
