'use client';

import React, { useState } from 'react';
import {
  Terminal,
  Play,
  RotateCcw,
  Sparkles,
  FileCode2,
  Copy,
  Check,
  CheckCircle2
} from 'lucide-react';
import { executeRCommand } from '@/lib/r-engine/statistical-bridge';

export const ConsoleRTerminalView: React.FC = () => {
  const [inputCommand, setInputCommand] = useState('aureomMusicR::dna_summary(target_lufs = -14.0)');
  const [commandHistory, setCommandHistory] = useState<
    { command: string; output: string; timestamp: string }[]
  >([
    {
      command: 'library(aureomMusicR)\nlibrary(seewave)\nlibrary(tuneR)',
      output: 'Attaching package: ‘aureomMusicR’ (v4.4.2)\nLoaded DSP backend: Rust audio engine bridge (/tmp/aureom_dsp.sock)\nFFT engine: KissFFT / Rust SIMD AVX2 acceleration enabled.\nReady for acoustic modeling.',
      timestamp: '10:14:02'
    },
    {
      command: 'track_stft <- aureomMusicR::compute_stft("track_01_cello", window="hann", n_fft=2048)',
      output: '[1] "Computed STFT across 231,360 samples. Matrix dimensions: 1025 x 452 bins. Dynamic range: 84.2 dB."',
      timestamp: '10:14:28'
    }
  ]);

  const handleRunCommand = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputCommand.trim()) return;

    const res = executeRCommand(inputCommand);
    const newEntry = {
      command: inputCommand,
      output: res.output,
      timestamp: new Date().toLocaleTimeString()
    };
    setCommandHistory([...commandHistory, newEntry]);
  };

  const presetScripts = [
    {
      label: 'Inspect Spectral Flux',
      code: 'flux <- aureomMusicR::spectral_flux(window = 1024, hop = 256)\nsummary(flux)'
    },
    {
      label: 'Krumhansl-Schmuckler Key Profiler',
      code: 'chroma <- aureomMusicR::chromagram(bins = 12)\nkey_est <- aureomMusicR::estimate_key(chroma)\nprint(key_est)'
    },
    {
      label: 'Markov Composition Mutation',
      code: 'motif <- aureomMusicR::markov_generate(order = 2, seed = 42891, scale = "D_minor")\nprint(motif$notes[1:8])'
    },
    {
      label: 'EBU R128 True Peak Compliance',
      code: 'meter <- aureomMusicR::ebu_r128_meter(track = "master_bus")\ncat(sprintf("Integrated: %.2f LUFS, True Peak: %.2f dBTP\\n", meter$integrated, meter$true_peak))'
    }
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden font-mono text-slate-200 select-none">
      {/* Terminal Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-emerald-400" />
            aureomMusicR INTERACTIVE REPL CONSOLE (R v4.4.2)
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
            IPC FIFO: CONNECTED
          </span>
        </div>

        <button
          onClick={() => setCommandHistory([])}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 font-bold transition-colors"
        >
          CLEAR LOGS
        </button>
      </div>

      {/* Preset Script Buttons Strip */}
      <div className="flex items-center px-4 py-2 bg-slate-900/60 border-b border-slate-800 gap-2 overflow-x-auto">
        <span className="text-[10px] font-bold text-slate-400 shrink-0">QUICK MACROS:</span>
        {presetScripts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInputCommand(p.code);
            }}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-cyan-300 border border-slate-700/60 shrink-0 whitespace-nowrap transition-colors"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Terminal Log Output Area */}
      <div className="flex-1 p-4 overflow-y-auto bg-black font-mono text-xs space-y-4">
        {commandHistory.map((item, idx) => (
          <div key={idx} className="space-y-1">
            <div className="flex items-center gap-2 text-slate-400 text-[11px]">
              <span className="text-amber-400 font-bold">&gt;</span>
              <span className="text-slate-100 font-semibold">{item.command}</span>
              <span className="text-[9px] text-slate-600 ml-auto">{item.timestamp}</span>
            </div>
            <pre className="text-emerald-400 pl-4 py-1 text-[11px] whitespace-pre-wrap leading-relaxed border-l-2 border-emerald-500/30">
              {item.output}
            </pre>
          </div>
        ))}
      </div>

      {/* Command Input Form */}
      <form
        onSubmit={handleRunCommand}
        className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
      >
        <div className="flex items-center gap-1 text-amber-400 font-bold text-sm">
          <span>&gt;</span>
        </div>
        <input
          type="text"
          value={inputCommand}
          onChange={(e) => setInputCommand(e.target.value)}
          placeholder="Enter R statement or aureomMusicR function call (e.g. aureomMusicR::dna_summary())..."
          className="flex-1 bg-black border border-slate-700 rounded px-3 py-2 text-xs text-emerald-400 font-mono focus:outline-none focus:border-amber-400"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded flex items-center gap-1.5 shadow transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>EXECUTE R</span>
        </button>
      </form>
    </div>
  );
};
