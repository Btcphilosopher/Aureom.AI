'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  Play,
  RotateCcw,
  Sliders,
  Copy,
  Check,
  FileCode2,
  Activity,
  Music,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { runGenerativeComposition } from '@/lib/r-engine/statistical-bridge';
import { GenerativeParameters } from '@/types/audio';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

export const GenerativeLabView: React.FC = () => {
  const [params, setParams] = useState<GenerativeParameters>({
    seed: 42891,
    tempo: 118,
    scale: 'minor',
    density: 70,
    complexity: 65,
    repetition: 60,
    variation: 45,
    syncopation: 55,
    swing: 54,
    polyrhythm: true,
    patternLengthBars: 16,
    styleModel: 'markov'
  });

  const [isCopied, setIsCopied] = useState(false);
  const [isPlayingGen, setIsPlayingGen] = useState(false);
  const [iterationCount, setIterationCount] = useState(1);

  const genResult = runGenerativeComposition(params);

  const handleAuditionGenerated = () => {
    const engine = getAudioEngine();
    setIsPlayingGen(true);

    // Play initial synthetic motif
    genResult.melodyNotes.slice(0, 8).forEach((n, i) => {
      setTimeout(() => {
        const freq = 440 * Math.pow(2, (n.pitch - 69) / 12);
        engine.playSubtractiveSynth(freq, 0.4);
      }, i * 180);
    });

    // Play drum accents
    [0, 180, 360, 540, 720, 900, 1080, 1260].forEach((t, i) => {
      setTimeout(() => {
        if (i % 2 === 0) engine.playDrumHit('kick');
        if (i === 2 || i === 6) engine.playDrumHit('snare');
        engine.playDrumHit('hat', 0.5);
      }, t);
    });

    setTimeout(() => setIsPlayingGen(false), 2000);
  };

  const handleMutateAndIterate = () => {
    const newSeed = Math.floor(Math.random() * 90000) + 10000;
    setParams({
      ...params,
      seed: newSeed,
      density: Math.min(90, Math.max(30, params.density + (Math.floor(Math.random() * 11) - 5))),
      syncopation: Math.min(85, Math.max(20, params.syncopation + (Math.floor(Math.random() * 9) - 4)))
    });
    setIterationCount(iterationCount + 1);
  };

  const copyRScript = () => {
    navigator.clipboard.writeText(genResult.rScriptCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto font-mono text-slate-200 select-none">
      {/* Generative Lab Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            R ↔ RUST CLOSED-LOOP COMPOSITION ENGINE
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <span className="text-[10px] text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/80">
            ITERATION #{iterationCount} (SEED {params.seed})
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleMutateAndIterate}
            className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
            <span>MUTATE & RE-SCORE</span>
          </button>
          <button
            onClick={handleAuditionGenerated}
            disabled={isPlayingGen}
            className={`px-3 py-1 rounded text-xs font-bold flex items-center gap-1.5 transition-all ${
              isPlayingGen
                ? 'bg-amber-500 text-slate-950'
                : 'bg-emerald-700 hover:bg-emerald-600 text-white'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isPlayingGen ? 'AUDITIONING...' : 'AUDITION MOTIF'}</span>
          </button>
        </div>
      </div>

      {/* Closed-Loop Pipeline Diagram */}
      <div className="bg-slate-900/60 border-b border-slate-800 px-4 py-3">
        <div className="flex items-center justify-between max-w-4xl mx-auto text-xs text-center">
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-[9px] text-slate-400 block">STEP 1</span>
            <span className="font-bold text-cyan-400">R: Markov Gen</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-600" />
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-[9px] text-slate-400 block">STEP 2</span>
            <span className="font-bold text-amber-400">MIDI Stream</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-600" />
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-[9px] text-slate-400 block">STEP 3</span>
            <span className="font-bold text-rose-400">Rust DSP Synth</span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-600" />
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-[9px] text-slate-400 block">STEP 4</span>
            <span className="font-bold text-emerald-400">R: Score & Optimize</span>
          </div>
        </div>
      </div>

      {/* Controls & Output Split */}
      <div className="flex-1 p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: Generative Parameter Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-amber-400">STATISTICAL & MARKOV PARAMETERS</span>
            <span className="text-[10px] text-emerald-400">FITNESS: {genResult.fitnessScore}%</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block mb-1">RNG SEED (REPRODUCIBLE)</span>
              <input
                type="number"
                value={params.seed}
                onChange={(e) => setParams({ ...params, seed: parseInt(e.target.value) || 1 })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-amber-400 font-bold"
              />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block mb-1">SCALE CONSTRAINT</span>
              <select
                value={params.scale}
                onChange={(e) => setParams({ ...params, scale: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-amber-300"
              >
                <option value="minor">D Natural Minor</option>
                <option value="dorian">D Dorian Modal</option>
                <option value="pentatonic">D Minor Pentatonic</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">NOTE DENSITY:</span>
                <span className="text-amber-400 font-bold">{params.density}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="95"
                value={params.density}
                onChange={(e) => setParams({ ...params, density: parseInt(e.target.value) })}
                className="w-full accent-amber-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">SYNCOPATION WEIGHT:</span>
                <span className="text-fuchsia-400 font-bold">{params.syncopation}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="90"
                value={params.syncopation}
                onChange={(e) => setParams({ ...params, syncopation: parseInt(e.target.value) })}
                className="w-full accent-fuchsia-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">MARKOV COMPLEXITY (ORDER 2):</span>
                <span className="text-cyan-400 font-bold">{params.complexity}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="95"
                value={params.complexity}
                onChange={(e) => setParams({ ...params, complexity: parseInt(e.target.value) })}
                className="w-full accent-cyan-400"
              />
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[10px] space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>GENERATED MELODY EVENTS:</span>
              <span className="text-slate-200 font-bold">{genResult.melodyNotes.length} notes</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>BASSLINE EVENTS:</span>
              <span className="text-slate-200 font-bold">{genResult.bassNotes.length} notes</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>POLYMETRIC PATTERN:</span>
              <span className="text-slate-200 font-bold">16x12x15x7 Grid Active</span>
            </div>
          </div>
        </div>

        {/* Right: Generated R Code & Matrix Viewer */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
              <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                <FileCode2 className="w-4 h-4 text-cyan-400" />
                GENERATED aureomMusicR SCRIPT
              </span>
              <button
                onClick={copyRScript}
                className="p-1 px-2 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 flex items-center gap-1 transition-colors"
              >
                {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{isCopied ? 'COPIED' : 'COPY R'}</span>
              </button>
            </div>

            <pre className="h-72 bg-black rounded-lg p-3 text-[10px] font-mono text-emerald-400 overflow-y-auto border border-slate-800 scrollbar-thin">
              {genResult.rScriptCode}
            </pre>
          </div>

          <div className="pt-2 text-[10px] text-slate-500 text-right">
            Deterministic IPC Socket: /tmp/aureom_dsp.sock
          </div>
        </div>
      </div>
    </div>
  );
};
