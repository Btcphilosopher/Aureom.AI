'use client';

import React, { useState, useEffect } from 'react';
import {
  SlidersHorizontal,
  Volume2,
  VolumeX,
  Radio,
  Sparkles,
  Layers,
  Activity
} from 'lucide-react';
import { ProjectState, Track } from '@/types/audio';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

interface MixerViewProps {
  project: ProjectState;
  onUpdateTrack: (track: Track) => void;
  onUpdateMasterVolume: (volDb: number) => void;
  isPlaying: boolean;
}

export const MixerView: React.FC<MixerViewProps> = ({
  project,
  onUpdateTrack,
  onUpdateMasterVolume,
  isPlaying
}) => {
  const [activeMeters, setActiveMeters] = useState<Record<string, { left: number; right: number }>>({});
  const [reverbReturnDb, setReverbReturnDb] = useState(-12);
  const [delayReturnDb, setDelayReturnDb] = useState(-16);
  const [masterVol, setMasterVol] = useState(project.masterVolumeDb);

  // Meter update loop
  useEffect(() => {
    const timer = setInterval(() => {
      const newMeters: Record<string, { left: number; right: number }> = {};
      project.tracks.forEach((t) => {
        if (isPlaying && !t.isMuted) {
          const jitter = (Math.sin(Date.now() / 150 + parseInt(t.id.slice(-2) || '1')) * 0.15 + 0.85);
          const val = Math.max(0.05, Math.min(0.98, t.activePeakLeft * jitter));
          newMeters[t.id] = { left: val, right: val * 0.96 };
        } else {
          newMeters[t.id] = { left: 0, right: 0 };
        }
      });
      setActiveMeters(newMeters);
    }, 80);
    return () => clearInterval(timer);
  }, [isPlaying, project.tracks]);

  const handleVolumeChange = (track: Track, newDb: number) => {
    const updated = { ...track, volumeDb: newDb };
    onUpdateTrack(updated);
    getAudioEngine().setTrackVolume(track.id, track.isMuted ? -96 : newDb);
  };

  const handlePanChange = (track: Track, newPan: number) => {
    const updated = { ...track, pan: newPan };
    onUpdateTrack(updated);
    getAudioEngine().setTrackPan(track.id, newPan);
  };

  const handleMasterChange = (newDb: number) => {
    setMasterVol(newDb);
    onUpdateMasterVolume(newDb);
    getAudioEngine().setMasterVolume(newDb);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden font-mono select-none">
      {/* Mixer Console Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/80">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <SlidersHorizontal className="w-4 h-4 text-amber-400" />
            CONSOLE MIXER (48kHz / 24-BIT FLOATING BUS)
          </span>
          <span className="text-[10px] text-slate-400">
            10 CHANNEL STRIPS • 2 AUX RETURNS • MASTER BRICKWALL BUS
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="text-slate-400">PAN LAW:</span>
            <span className="text-amber-400 font-bold">-3.0dB (Compensated)</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="text-slate-400">HEADROOM:</span>
            <span className="text-emerald-400 font-bold">+18.0 dBu</span>
          </div>
        </div>
      </div>

      {/* Console Channels Scroll Area */}
      <div className="flex-1 flex overflow-x-auto p-3 gap-2 bg-gradient-to-b from-slate-950 to-slate-900">
        {/* Track Channel Strips */}
        {project.tracks.map((track, idx) => {
          const meter = activeMeters[track.id] || { left: 0, right: 0 };
          return (
            <div
              key={track.id}
              className="w-36 bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex flex-col justify-between shrink-0 shadow-lg relative group hover:border-slate-700 transition-colors"
            >
              {/* Channel Index & Color Tag */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                <div className="flex items-center gap-1.5 overflow-hidden">
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: track.color }} />
                  <span className="text-[11px] font-bold text-slate-200 truncate" title={track.name}>
                    {track.name.replace(/^\d+\s*/, '')}
                  </span>
                </div>
                <span className="text-[9px] text-slate-400 font-semibold">CH {idx + 1}</span>
              </div>

              {/* EQ Mini Visualizer Curve */}
              <div className="h-12 bg-black/60 rounded border border-slate-800/80 p-1 flex items-center justify-center relative overflow-hidden my-1">
                <svg className="w-full h-full" viewBox="0 0 100 40">
                  <path
                    d="M 5 20 Q 25 15 50 20 T 95 18"
                    fill="none"
                    stroke={track.color}
                    strokeWidth="1.5"
                  />
                  <line x1="5" y1="20" x2="95" y2="20" stroke="#334155" strokeWidth="0.5" strokeDasharray="2" />
                </svg>
                <span className="absolute bottom-0.5 right-1 text-[8px] text-slate-400">5-BAND EQ</span>
              </div>

              {/* Aux Sends Knobs: Reverb & Delay */}
              <div className="grid grid-cols-2 gap-1.5 py-1 border-y border-slate-800/60 my-1 text-center">
                <div>
                  <span className="text-[8px] text-slate-400 block mb-0.5">REV SEND</span>
                  <div className="text-[10px] font-bold text-amber-400/90">{track.sendReverbDb}dB</div>
                </div>
                <div>
                  <span className="text-[8px] text-slate-400 block mb-0.5">DLY SEND</span>
                  <div className="text-[10px] font-bold text-cyan-400/90">{track.sendDelayDb}dB</div>
                </div>
              </div>

              {/* Pan Potentiometer */}
              <div className="flex flex-col items-center py-1">
                <div className="flex items-center justify-between w-full text-[8px] text-slate-400 mb-0.5">
                  <span>L</span>
                  <span className="text-slate-200 font-bold">
                    {track.pan === 0 ? 'C' : track.pan > 0 ? `R${Math.round(track.pan * 50)}` : `L${Math.round(-track.pan * 50)}`}
                  </span>
                  <span>R</span>
                </div>
                <input
                  type="range"
                  min="-1"
                  max="1"
                  step="0.05"
                  value={track.pan}
                  onChange={(e) => handlePanChange(track, parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-800 accent-amber-400 rounded-lg cursor-pointer"
                />
              </div>

              {/* Mute and Solo Buttons */}
              <div className="grid grid-cols-2 gap-1 my-1">
                <button
                  onClick={() => {
                    const updated = { ...track, isMuted: !track.isMuted };
                    onUpdateTrack(updated);
                    getAudioEngine().setTrackVolume(track.id, updated.isMuted ? -96 : updated.volumeDb);
                  }}
                  className={`py-1 rounded text-[10px] font-bold transition-colors ${
                    track.isMuted ? 'bg-rose-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  MUTE
                </button>
                <button
                  onClick={() => {
                    const updated = { ...track, isSoloed: !track.isSoloed };
                    onUpdateTrack(updated);
                  }}
                  className={`py-1 rounded text-[10px] font-bold transition-colors ${
                    track.isSoloed ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  SOLO
                </button>
              </div>

              {/* Fader & Stereo Peak Ladder Meter Section */}
              <div className="flex items-stretch justify-between gap-2 h-44 bg-slate-950 p-1.5 rounded border border-slate-800">
                {/* dB Scale Markings */}
                <div className="flex flex-col justify-between text-[8px] text-slate-400 font-mono py-1">
                  <span>+6</span>
                  <span className="text-amber-400 font-bold">0</span>
                  <span>-6</span>
                  <span>-18</span>
                  <span>-36</span>
                  <span>-∞</span>
                </div>

                {/* Vertical Long-Throw Console Fader */}
                <div className="flex-1 flex items-center justify-center relative">
                  <input
                    type="range"
                    min="-60"
                    max="6"
                    step="0.5"
                    value={track.volumeDb}
                    onChange={(e) => handleVolumeChange(track, parseFloat(e.target.value))}
                    className="h-36 w-24 -rotate-90 origin-center accent-amber-400 bg-slate-800 rounded cursor-pointer"
                  />
                </div>

                {/* Dual LED Peak Ladder Meter */}
                <div className="w-4 bg-black/90 rounded flex gap-0.5 p-0.5">
                  {/* Left */}
                  <div className="flex-1 bg-slate-900 rounded-sm flex flex-col-reverse overflow-hidden">
                    <div
                      className={`w-full transition-all duration-75 ${
                        meter.left > 0.9 ? 'bg-rose-500' : meter.left > 0.7 ? 'bg-amber-400' : 'bg-emerald-500'
                      }`}
                      style={{ height: `${Math.min(100, meter.left * 100)}%` }}
                    />
                  </div>
                  {/* Right */}
                  <div className="flex-1 bg-slate-900 rounded-sm flex flex-col-reverse overflow-hidden">
                    <div
                      className={`w-full transition-all duration-75 ${
                        meter.right > 0.9 ? 'bg-rose-500' : meter.right > 0.7 ? 'bg-amber-400' : 'bg-emerald-500'
                      }`}
                      style={{ height: `${Math.min(100, meter.right * 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Numerical Fader Readout & Routing */}
              <div className="mt-2 text-center border-t border-slate-800 pt-1.5">
                <span className="text-xs font-bold text-slate-100 block">
                  {track.volumeDb <= -60 ? '-∞ dB' : `${track.volumeDb.toFixed(1)} dB`}
                </span>
                <span className="text-[9px] text-slate-400 truncate block">
                  → {track.outputBusId.toUpperCase()}
                </span>
              </div>
            </div>
          );
        })}

        {/* Reverb Return Strip */}
        <div className="w-32 bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 flex flex-col justify-between shrink-0">
          <div className="border-b border-slate-800 pb-1.5 text-center">
            <span className="text-[11px] font-bold text-amber-400 block">FX1 REVERB</span>
            <span className="text-[9px] text-slate-400">PLATE 2.2s</span>
          </div>
          <div className="h-40 flex items-center justify-center">
            <input
              type="range"
              min="-40"
              max="0"
              step="0.5"
              value={reverbReturnDb}
              onChange={(e) => setReverbReturnDb(parseFloat(e.target.value))}
              className="h-32 w-20 -rotate-90 accent-amber-400"
            />
          </div>
          <div className="text-center">
            <span className="text-xs font-bold text-slate-200">{reverbReturnDb} dB</span>
            <span className="text-[9px] text-slate-400 block">AUX RETURN</span>
          </div>
        </div>

        {/* Delay Return Strip */}
        <div className="w-32 bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 flex flex-col justify-between shrink-0">
          <div className="border-b border-slate-800 pb-1.5 text-center">
            <span className="text-[11px] font-bold text-cyan-400 block">FX2 DELAY</span>
            <span className="text-[9px] text-slate-400">PING-PONG 3/16</span>
          </div>
          <div className="h-40 flex items-center justify-center">
            <input
              type="range"
              min="-40"
              max="0"
              step="0.5"
              value={delayReturnDb}
              onChange={(e) => setDelayReturnDb(parseFloat(e.target.value))}
              className="h-32 w-20 -rotate-90 accent-cyan-400"
            />
          </div>
          <div className="text-center">
            <span className="text-xs font-bold text-slate-200">{delayReturnDb} dB</span>
            <span className="text-[9px] text-slate-400 block">AUX RETURN</span>
          </div>
        </div>

        {/* Master Output Console Strip */}
        <div className="w-40 bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500/60 rounded-lg p-3 flex flex-col justify-between shrink-0 shadow-2xl">
          <div className="border-b border-amber-500/30 pb-1.5 text-center">
            <span className="text-xs font-black text-amber-400 tracking-wider block">MASTER BUS</span>
            <span className="text-[9px] text-slate-400">BRICKWALL LIMITER</span>
          </div>

          {/* Master Limiter Threshold and Ceiling Controls */}
          <div className="bg-black/80 rounded p-1.5 border border-slate-800 text-center my-1">
            <span className="text-[8px] text-slate-400 block">CEILING: -0.3 dBTP</span>
            <span className="text-[8px] text-emerald-400 font-bold block">LUFS: -14.1 EBU</span>
          </div>

          {/* Master Long-Throw Fader */}
          <div className="flex items-stretch justify-between gap-2 h-44 bg-slate-950 p-1.5 rounded border border-slate-800">
            <div className="flex flex-col justify-between text-[8px] text-slate-400 py-1">
              <span>+6</span>
              <span className="text-amber-400 font-bold">0</span>
              <span>-6</span>
              <span>-18</span>
              <span>-36</span>
              <span>-∞</span>
            </div>

            <div className="flex-1 flex items-center justify-center relative">
              <input
                type="range"
                min="-60"
                max="6"
                step="0.5"
                value={masterVol}
                onChange={(e) => handleMasterChange(parseFloat(e.target.value))}
                className="h-36 w-24 -rotate-90 origin-center accent-amber-500 bg-slate-800 rounded cursor-pointer"
              />
            </div>
          </div>

          <div className="text-center border-t border-slate-800 pt-1.5">
            <span className="text-sm font-black text-amber-400 block">
              {masterVol <= -60 ? '-∞ dB' : `${masterVol.toFixed(1)} dB`}
            </span>
            <span className="text-[9px] text-slate-400 block">STEREO MAIN OUT</span>
          </div>
        </div>
      </div>
    </div>
  );
};
