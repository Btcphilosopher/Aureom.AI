'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Radio,
  Sliders,
  Sparkles,
  Layers,
  Activity,
  Zap,
  RotateCcw,
  Play
} from 'lucide-react';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

type SynthEngineType = 'subtractive' | 'fm' | 'wavetable' | 'additive' | 'physical';

export const SynthWorkstationView: React.FC = () => {
  const [activeEngine, setActiveEngine] = useState<SynthEngineType>('subtractive');
  const [octave, setOctave] = useState(3);
  
  // Subtractive Parameters
  const [subParams, setSubParams] = useState({
    osc1Type: 'sawtooth' as OscillatorType,
    osc2Type: 'square' as OscillatorType,
    cutoff: 2200,
    resonance: 4.5,
    drive: 3.0,
    detune: 12,
    attack: 0.02,
    decay: 0.3,
    sustain: 0.5,
    release: 0.4
  });

  // FM Parameters
  const [fmParams, setFmParams] = useState({
    ratio2: 2.0,
    ratio3: 3.01,
    modIndex: 220,
    algorithm: 1
  });

  // Wavetable Parameters
  const [wtParams, setWtParams] = useState({
    tableType: 'vocal-formant',
    position: 45, // 0 to 100
    subLevel: 0.4
  });

  // Additive 16 Partials
  const [partials, setPartials] = useState<number[]>([
    1.0, 0.8, 0.6, 0.45, 0.35, 0.28, 0.22, 0.18, 0.14, 0.11, 0.09, 0.07, 0.05, 0.04, 0.03, 0.02
  ]);

  // Physical Modeling Parameters
  const [physicalParams, setPhysicalParams] = useState({
    model: 'plucked-string' as 'plucked-string' | 'membrane' | 'metallic',
    damping: 0.985,
    brightness: 0.85,
    tension: 0.75
  });

  // Oscilloscope Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw Center Grid Line
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, canvas.height / 2);
      ctx.lineTo(canvas.width, canvas.height / 2);
      ctx.stroke();

      const engine = getAudioEngine();
      const levels = engine.getMasterLevels();
      const wave = levels.waveform;

      // Draw Live Oscilloscope Waveform
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.beginPath();

      if (wave && wave.length > 0) {
        const sliceWidth = canvas.width / wave.length;
        for (let i = 0; i < wave.length; i++) {
          const v = wave[i];
          const y = (v * 0.4 + 0.5) * canvas.height;
          if (i === 0) ctx.moveTo(0, y);
          else ctx.lineTo(i * sliceWidth, y);
        }
      } else {
        // Idling baseline with gentle noise
        for (let x = 0; x < canvas.width; x += 4) {
          const y = canvas.height / 2 + Math.sin(x * 0.05 + Date.now() * 0.005) * 3;
          if (x === 0) ctx.moveTo(0, y);
          else ctx.lineTo(x, y);
        }
      }
      ctx.stroke();

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, []);

  const playNote = (midiPitch: number) => {
    const freq = 440 * Math.pow(2, (midiPitch - 69) / 12);
    const engine = getAudioEngine();

    if (activeEngine === 'subtractive') {
      engine.playSubtractiveSynth(freq, 0.9, {
        osc1Type: subParams.osc1Type,
        osc2Type: subParams.osc2Type,
        cutoff: subParams.cutoff,
        res: subParams.resonance,
        detune: subParams.detune
      });
    } else if (activeEngine === 'fm') {
      engine.playFmSynth(freq, 0.9, fmParams.ratio2, fmParams.ratio3, fmParams.modIndex);
    } else if (activeEngine === 'physical') {
      engine.playPluckedString(freq, 1.2, physicalParams.damping);
    } else {
      // Wavetable / Additive fallback
      engine.playSubtractiveSynth(freq, 0.9, {
        osc1Type: 'sawtooth',
        osc2Type: 'sine',
        cutoff: 3500,
        res: 2,
        detune: 5
      });
    }
  };

  const whiteKeys = [
    { note: 'C', offset: 0 },
    { note: 'D', offset: 2 },
    { note: 'E', offset: 4 },
    { note: 'F', offset: 5 },
    { note: 'G', offset: 7 },
    { note: 'A', offset: 9 },
    { note: 'B', offset: 11 },
    { note: 'C+', offset: 12 },
    { note: 'D+', offset: 14 },
    { note: 'E+', offset: 16 },
    { note: 'F+', offset: 17 },
    { note: 'G+', offset: 19 },
    { note: 'A+', offset: 21 },
    { note: 'B+', offset: 23 },
  ];

  const blackKeys = [
    { note: 'C#', offset: 1, pos: 0 },
    { note: 'D#', offset: 3, pos: 1 },
    { note: 'F#', offset: 6, pos: 3 },
    { note: 'G#', offset: 8, pos: 4 },
    { note: 'A#', offset: 10, pos: 5 },
    { note: 'C#+', offset: 13, pos: 7 },
    { note: 'D#+', offset: 15, pos: 8 },
    { note: 'F#+', offset: 18, pos: 10 },
    { note: 'G#+', offset: 20, pos: 11 },
    { note: 'A#+', offset: 22, pos: 12 },
  ];

  const baseMidi = octave * 12 + 12; // C3 = 48 when octave=3

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto font-mono text-slate-200 select-none">
      {/* Top Synth Engine Selector Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-amber-400" />
            SYNTHESIS WORKSTATION (NATIVE RUST DSP CORE)
          </span>
          <div className="h-4 w-px bg-slate-800" />
          {/* Engine Tabs */}
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'subtractive', label: 'SUBTRACTIVE 3-OSC' },
                { id: 'fm', label: 'FM 4-OPERATOR' },
                { id: 'wavetable', label: 'WAVETABLE MORPH' },
                { id: 'additive', label: 'ADDITIVE 16-PARTIAL' },
                { id: 'physical', label: 'PHYSICAL KARPLUS' }
              ] as const
            ).map((eng) => (
              <button
                key={eng.id}
                onClick={() => setActiveEngine(eng.id)}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                  activeEngine === eng.id
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
                }`}
              >
                {eng.label}
              </button>
            ))}
          </div>
        </div>

        {/* Octave Selector */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">OCTAVE:</span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setOctave(Math.max(1, octave - 1))}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold"
            >
              -
            </button>
            <span className="w-6 text-center text-amber-400 font-bold">C{octave}</span>
            <button
              onClick={() => setOctave(Math.min(6, octave + 1))}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold"
            >
              +
            </button>
          </div>
        </div>
      </div>

      {/* Main Synth Controls Area */}
      <div className="flex-1 p-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Engine Parameter Controls (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
          {/* Subtractive View */}
          {activeEngine === 'subtractive' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-amber-400">MOOG 24dB LADDER 3-OSCILLATOR ARCHITECTURE</span>
                <span className="text-[10px] text-slate-400">NON-LINEAR SATURATION ENABLED</span>
              </div>

              {/* Oscillators Grid */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] font-bold text-slate-300 block mb-1.5">OSC 1 (PRIMARY)</span>
                  <div className="space-y-2">
                    <select
                      value={subParams.osc1Type}
                      onChange={(e) => setSubParams({ ...subParams, osc1Type: e.target.value as OscillatorType })}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-amber-300"
                    >
                      <option value="sawtooth">Sawtooth 24dB</option>
                      <option value="square">Square 50% Pulse</option>
                      <option value="triangle">Triangle Harmonic</option>
                    </select>
                    <div>
                      <span className="text-[9px] text-slate-400 block">DETUNE: {subParams.detune} Cts</span>
                      <input
                        type="range"
                        min="0"
                        max="50"
                        value={subParams.detune}
                        onChange={(e) => setSubParams({ ...subParams, detune: parseInt(e.target.value) })}
                        className="w-full accent-amber-400"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] font-bold text-slate-300 block mb-1.5">OSC 2 (SYNC/SUB)</span>
                  <div className="space-y-2">
                    <select
                      value={subParams.osc2Type}
                      onChange={(e) => setSubParams({ ...subParams, osc2Type: e.target.value as OscillatorType })}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-amber-300"
                    >
                      <option value="square">Square Pulse</option>
                      <option value="sawtooth">Sawtooth</option>
                      <option value="sine">Sine Pure Sub</option>
                    </select>
                    <div>
                      <span className="text-[9px] text-slate-400 block">SUB LEVEL: +3dB</span>
                      <input type="range" min="0" max="100" defaultValue="70" className="w-full accent-amber-400" />
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] font-bold text-amber-400 block mb-1.5">24dB LADDER FILTER</span>
                  <div className="space-y-2">
                    <div>
                      <span className="text-[9px] text-slate-400 block">CUTOFF: {subParams.cutoff} Hz</span>
                      <input
                        type="range"
                        min="80"
                        max="16000"
                        value={subParams.cutoff}
                        onChange={(e) => setSubParams({ ...subParams, cutoff: parseInt(e.target.value) })}
                        className="w-full accent-amber-400"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 block">RESONANCE (Q): {subParams.resonance}</span>
                      <input
                        type="range"
                        min="0.5"
                        max="18"
                        step="0.5"
                        value={subParams.resonance}
                        onChange={(e) => setSubParams({ ...subParams, resonance: parseFloat(e.target.value) })}
                        className="w-full accent-amber-400"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Envelope ADSR Visualizer and Controls */}
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-[10px] font-bold text-slate-300 block mb-2">AMPLITUDE ENVELOPE (ADSR)</span>
                <div className="grid grid-cols-4 gap-3 text-center">
                  <div>
                    <span className="text-[9px] text-slate-400 block mb-1">ATTACK: {subParams.attack}s</span>
                    <input
                      type="range"
                      min="0.001"
                      max="1.5"
                      step="0.01"
                      value={subParams.attack}
                      onChange={(e) => setSubParams({ ...subParams, attack: parseFloat(e.target.value) })}
                      className="w-full accent-amber-400"
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block mb-1">DECAY: {subParams.decay}s</span>
                    <input
                      type="range"
                      min="0.01"
                      max="3.0"
                      step="0.05"
                      value={subParams.decay}
                      onChange={(e) => setSubParams({ ...subParams, decay: parseFloat(e.target.value) })}
                      className="w-full accent-amber-400"
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block mb-1">SUSTAIN: {Math.round(subParams.sustain * 100)}%</span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={subParams.sustain}
                      onChange={(e) => setSubParams({ ...subParams, sustain: parseFloat(e.target.value) })}
                      className="w-full accent-amber-400"
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block mb-1">RELEASE: {subParams.release}s</span>
                    <input
                      type="range"
                      min="0.05"
                      max="4.0"
                      step="0.05"
                      value={subParams.release}
                      onChange={(e) => setSubParams({ ...subParams, release: parseFloat(e.target.value) })}
                      className="w-full accent-amber-400"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* FM View */}
          {activeEngine === 'fm' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-cyan-400">4-OPERATOR FREQUENCY MODULATION MATRIX</span>
                <span className="text-[10px] text-slate-400">ALGORITHM: SERIAL CASCADE (OP4 → OP3 → OP2 → OP1)</span>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-cyan-400 block mb-1">OP 1 (CARRIER)</span>
                  <span className="text-xs text-slate-300">RATIO: 1.000</span>
                  <div className="text-[9px] text-slate-400 mt-2">Outputs directly to master audio bus.</div>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-cyan-400 block mb-1">OP 2 (MODULATOR 1)</span>
                  <span className="text-xs text-slate-300">RATIO: {fmParams.ratio2.toFixed(2)}</span>
                  <input
                    type="range"
                    min="0.5"
                    max="12"
                    step="0.25"
                    value={fmParams.ratio2}
                    onChange={(e) => setFmParams({ ...fmParams, ratio2: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 mt-2"
                  />
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-cyan-400 block mb-1">OP 3 (MODULATOR 2)</span>
                  <span className="text-xs text-slate-300">RATIO: {fmParams.ratio3.toFixed(2)}</span>
                  <input
                    type="range"
                    min="1"
                    max="16"
                    step="0.01"
                    value={fmParams.ratio3}
                    onChange={(e) => setFmParams({ ...fmParams, ratio3: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 mt-2"
                  />
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-[10px] font-bold text-slate-300 block mb-1">MODULATION INDEX: {fmParams.modIndex}</span>
                <input
                  type="range"
                  min="0"
                  max="800"
                  value={fmParams.modIndex}
                  onChange={(e) => setFmParams({ ...fmParams, modIndex: parseInt(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>
          )}

          {/* Physical Modeling View */}
          {activeEngine === 'physical' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-emerald-400">KARPLUS-STRONG PLUCKED RESONATOR</span>
                <span className="text-[10px] text-slate-400">DISPERSION & STRING DAMPING FILTER</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-emerald-400 block mb-1">STRING DAMPING: {physicalParams.damping}</span>
                  <input
                    type="range"
                    min="0.90"
                    max="0.999"
                    step="0.001"
                    value={physicalParams.damping}
                    onChange={(e) => setPhysicalParams({ ...physicalParams, damping: parseFloat(e.target.value) })}
                    className="w-full accent-emerald-400"
                  />
                  <span className="text-[9px] text-slate-400 block mt-1">Higher damping values produce long ringing acoustic resonance.</span>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-emerald-400 block mb-1">STRING MATERIAL</span>
                  <div className="grid grid-cols-2 gap-1 mt-2">
                    {['Nylon', 'Steel', 'Brass', 'Silk'].map((mat) => (
                      <button
                        key={mat}
                        className="py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-200"
                      >
                        {mat}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Additive 16 Partials View */}
          {activeEngine === 'additive' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-fuchsia-400">16-PARTIAL ADDITIVE FOURIER SYNTHESIS</span>
                <span className="text-[10px] text-slate-400">EXPLICIT PHASE & AMPLITUDE WEIGHTING</span>
              </div>
              <div className="grid grid-cols-16 gap-1 h-32 bg-slate-950 p-2 rounded border border-slate-800 items-end">
                {partials.map((amp, idx) => (
                  <div key={idx} className="flex flex-col items-center h-full justify-end">
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.02"
                      value={amp}
                      onChange={(e) => {
                        const newP = [...partials];
                        newP[idx] = parseFloat(e.target.value);
                        setPartials(newP);
                      }}
                      className="h-24 w-4 -rotate-90 origin-center accent-fuchsia-400"
                    />
                    <span className="text-[8px] text-slate-400 mt-1">{idx + 1}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Wavetable View */}
          {activeEngine === 'wavetable' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-amber-400">WAVETABLE MORPHING ENGINE</span>
                <span className="text-[10px] text-slate-400">INTERPOLATION: SPECTRAL SINC</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-slate-300 block mb-1">TABLE POSITION: {wtParams.position}%</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={wtParams.position}
                    onChange={(e) => setWtParams({ ...wtParams, position: parseInt(e.target.value) })}
                    className="w-full accent-amber-400"
                  />
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800">
                  <span className="text-[10px] font-bold text-slate-300 block mb-1">WAVETABLE BANK</span>
                  <select
                    value={wtParams.tableType}
                    onChange={(e) => setWtParams({ ...wtParams, tableType: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-xs text-amber-300"
                  >
                    <option value="vocal-formant">Vocal Formants (A-E-I-O-U)</option>
                    <option value="analog-harmonics">Analog Saw-Pulse-Sub</option>
                    <option value="metallic-bell">Metallic Bells & Gongs</option>
                    <option value="organ-drawbars">Hammond Drawbar Morph</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right: Oscilloscope & Audio Telemetry */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-amber-400" />
                REAL-TIME OSCILLOSCOPE
              </span>
              <span className="text-[10px] text-emerald-400 font-mono">DETERMINISTIC DSP</span>
            </div>

            {/* Canvas Display */}
            <div className="h-44 bg-black rounded-lg border border-slate-800 overflow-hidden shadow-inner flex items-center justify-center relative">
              <canvas
                ref={canvasRef}
                width={360}
                height={170}
                className="w-full h-full"
              />
              <span className="absolute bottom-1 right-2 text-[8px] text-slate-400 font-mono">48 kHz / 2048 BINS</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[10px] font-mono space-y-1 mt-3">
            <div className="flex justify-between text-slate-400">
              <span>LATENCY:</span>
              <span className="text-emerald-400 font-bold">2.67 ms (128 samples)</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>ANTIALIASING:</span>
              <span className="text-slate-200">PolyBLEP Bandlimited</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>VOICE ALLOCATION:</span>
              <span className="text-slate-200">8-Voice Poly / Dynamic Rob</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Interactive Piano Keyboard (2 Octaves) */}
      <div className="p-4 bg-slate-900/90 border-t border-slate-800">
        <div className="text-xs font-bold text-slate-400 mb-2 flex items-center justify-between">
          <span>PIANO AUDITION KEYBOARD (CLICK OR TOUCH TO TRIGGER DSP VOICES)</span>
          <span className="text-[10px] text-amber-400 font-mono">CURRENT BASE: C{octave} ({baseMidi} MIDI)</span>
        </div>

        <div className="relative h-28 bg-slate-950 rounded-lg p-1.5 border border-slate-800 overflow-hidden flex shadow-2xl">
          {/* White Keys */}
          {whiteKeys.map((k, i) => (
            <button
              key={i}
              onClick={() => playNote(baseMidi + k.offset)}
              className="flex-1 bg-gradient-to-b from-slate-100 to-slate-300 hover:from-amber-100 hover:to-amber-200 active:from-amber-300 active:to-amber-400 rounded-b-md border-r border-slate-400 text-slate-800 text-[9px] font-bold flex flex-col justify-end pb-1 items-center transition-colors shadow-sm select-none"
            >
              {k.note}
            </button>
          ))}

          {/* Black Keys Positioned Absolutely */}
          {blackKeys.map((bk, i) => {
            // Approx position based on white key width percentage (14 white keys total)
            const leftPct = (bk.pos + 0.65) * (100 / 14);
            return (
              <button
                key={i}
                onClick={() => playNote(baseMidi + bk.offset)}
                style={{ left: `${leftPct}%`, width: `${100 / 22}%` }}
                className="absolute top-1.5 h-16 bg-gradient-to-b from-slate-900 to-slate-950 hover:bg-slate-800 active:bg-amber-600 rounded-b border border-slate-700 text-[8px] text-slate-300 font-bold flex items-end justify-center pb-1 z-10 shadow-md transition-colors select-none"
              >
                {bk.note}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
