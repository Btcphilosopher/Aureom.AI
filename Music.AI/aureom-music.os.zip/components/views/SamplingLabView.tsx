'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  Play,
  RotateCcw,
  Sliders,
  Scissors,
  Layers,
  Activity,
  AudioWaveform
} from 'lucide-react';
import { getAudioEngine } from '@/lib/audio/dsp-engine';

export const SamplingLabView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'granular' | 'spectral' | 'slicing'>('granular');
  
  // Granular Parameters
  const [grainSizeMs, setGrainSizeMs] = useState(65);
  const [grainDensity, setGrainDensity] = useState(48);
  const [positionJitter, setPositionJitter] = useState(25);
  const [pitchJitterCents, setPitchJitterCents] = useState(15);
  const [envelopeShape, setEnvelopeShape] = useState<'hann' | 'gaussian' | 'tukey' | 'blackman'>('hann');

  // Spectral Parameters
  const [formantShift, setFormantShift] = useState(0);
  const [spectralFreeze, setSpectralFreeze] = useState(false);
  const [transientTonalBalance, setTransientTonalBalance] = useState(50); // 0 = 100% transient, 100 = 100% tonal

  const handleAuditionGranular = () => {
    const engine = getAudioEngine();
    // Trigger real-time granular cloud burst
    for (let i = 0; i < 12; i++) {
      setTimeout(() => {
        const jitterFreq = 220 * Math.pow(2, (Math.random() * 0.4 - 0.2));
        engine.playSubtractiveSynth(jitterFreq, grainSizeMs / 1000, {
          osc1Type: 'sawtooth',
          osc2Type: 'sine',
          cutoff: 3000,
          res: 3,
          detune: 10
        });
      }, i * (1000 / grainDensity));
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto font-mono text-slate-200 select-none">
      {/* Sampling Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/90">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
            <Sliders className="w-4 h-4 text-cyan-400" />
            GRANULAR SAMPLER & SPECTRAL RESYNTHESIZER
          </span>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'granular', label: 'GRANULAR CLOUD' },
                { id: 'spectral', label: 'SPECTRAL RESYNTHESIS' },
                { id: 'slicing', label: 'TRANSIENT SLICING' }
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                  activeTab === tab.id
                    ? 'bg-cyan-500 text-slate-950'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleAuditionGranular}
          className="px-3 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>TRIGGER CLOUD BURST</span>
        </button>
      </div>

      {/* Main Sample Waveform Stage */}
      <div className="p-4 space-y-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <span className="text-xs font-bold text-amber-400">SAMPLE BUFFER: CELLO_OCTAVE_SUSTAIN.WAV (48kHz / 32-BIT FLOAT)</span>
            <span className="text-[10px] text-slate-400">LENGTH: 4.82s | 231,360 SAMPLES</span>
          </div>

          {/* Interactive Waveform Display with Granular Spray Cloud */}
          <div className="h-40 bg-black rounded-lg border border-slate-800 p-2 relative overflow-hidden flex items-center justify-center">
            {/* Simulated Waveform Silhouette */}
            <div className="w-full h-28 flex items-center justify-around gap-1 opacity-60">
              {Array.from({ length: 64 }).map((_, i) => {
                const h = Math.abs(Math.sin(i * 0.2) * Math.cos(i * 0.08)) * 100;
                return (
                  <div
                    key={i}
                    style={{ height: `${Math.max(10, h)}%` }}
                    className="w-1 bg-cyan-400 rounded-full"
                  />
                );
              })}
            </div>

            {/* Granular Grain Spray Scatter (Dots) */}
            {Array.from({ length: 24 }).map((_, i) => (
              <div
                key={i}
                style={{
                  left: `${40 + (Math.sin(i) * positionJitter * 0.8)}%`,
                  top: `${30 + (Math.cos(i * 2) * 35)}%`
                }}
                className="absolute w-2 h-2 rounded-full bg-amber-400/80 shadow-[0_0_6px_rgba(245,158,11,0.9)] animate-pulse"
              />
            ))}

            {/* Playhead Marker */}
            <div className="absolute top-0 bottom-0 left-[42%] w-0.5 bg-amber-400 shadow-[0_0_8px_rgba(245,158,11,1)]" />
          </div>
        </div>

        {/* Granular Engine Controls */}
        {activeTab === 'granular' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-400 block">GRAIN SIZE</span>
              <div className="text-lg font-black text-slate-100">{grainSizeMs} ms</div>
              <input
                type="range"
                min="10"
                max="400"
                value={grainSizeMs}
                onChange={(e) => setGrainSizeMs(parseInt(e.target.value))}
                className="w-full accent-cyan-400"
              />
              <span className="text-[9px] text-slate-500 block">Window duration per grain</span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-400 block">GRAIN DENSITY</span>
              <div className="text-lg font-black text-slate-100">{grainDensity} grains/s</div>
              <input
                type="range"
                min="2"
                max="100"
                value={grainDensity}
                onChange={(e) => setGrainDensity(parseInt(e.target.value))}
                className="w-full accent-cyan-400"
              />
              <span className="text-[9px] text-slate-500 block">Emission frequency</span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-amber-400 block">POSITION SPRAY</span>
              <div className="text-lg font-black text-slate-100">±{positionJitter}%</div>
              <input
                type="range"
                min="0"
                max="100"
                value={positionJitter}
                onChange={(e) => setPositionJitter(parseInt(e.target.value))}
                className="w-full accent-amber-400"
              />
              <span className="text-[9px] text-slate-500 block">Gaussian scatter window</span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-amber-400 block">GRAIN WINDOW</span>
              <select
                value={envelopeShape}
                onChange={(e) => setEnvelopeShape(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-amber-300"
              >
                <option value="hann">Hann Cosine</option>
                <option value="gaussian">Gaussian Curve</option>
                <option value="tukey">Tukey Tapered</option>
                <option value="blackman">Blackman-Harris</option>
              </select>
              <span className="text-[9px] text-slate-500 block">Grain crossfade curve</span>
            </div>
          </div>
        )}

        {/* Spectral Resynthesis Controls */}
        {activeTab === 'spectral' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-amber-400 block">FORMANT SHIFT</span>
              <div className="text-lg font-black text-slate-100">{formantShift > 0 ? `+${formantShift}` : formantShift} st</div>
              <input
                type="range"
                min="-12"
                max="12"
                value={formantShift}
                onChange={(e) => setFormantShift(parseInt(e.target.value))}
                className="w-full accent-amber-400"
              />
              <span className="text-[9px] text-slate-500 block">Spectral envelope resonance shift</span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-400 block">SPECTRAL FREEZE</span>
              <button
                onClick={() => setSpectralFreeze(!spectralFreeze)}
                className={`w-full py-2 rounded text-xs font-bold transition-all ${
                  spectralFreeze ? 'bg-cyan-500 text-slate-950 shadow-lg' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {spectralFreeze ? 'FREEZE ACTIVE (INFINITE DRONE)' : 'ENGAGE SPECTRAL FREEZE'}
              </button>
              <span className="text-[9px] text-slate-500 block">Lock STFT magnitude bins infinitely</span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-emerald-400 block">TRANSIENT / TONAL SEPARATION</span>
              <div className="text-lg font-black text-slate-100">{transientTonalBalance}% Tonal</div>
              <input
                type="range"
                min="0"
                max="100"
                value={transientTonalBalance}
                onChange={(e) => setTransientTonalBalance(parseInt(e.target.value))}
                className="w-full accent-emerald-400"
              />
              <span className="text-[9px] text-slate-500 block">Median filtering harmonic sieve</span>
            </div>
          </div>
        )}

        {/* Transient Slicing Controls */}
        {activeTab === 'slicing' && (
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-bold text-amber-400 block">DETECTED TRANSIENT SLICES (16 SLICES)</span>
            <div className="grid grid-cols-8 gap-2">
              {Array.from({ length: 16 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    const engine = getAudioEngine();
                    engine.playDrumHit(i % 2 === 0 ? 'kick' : 'snare', 0.8);
                  }}
                  className="bg-slate-950 hover:bg-amber-500 hover:text-slate-950 p-2 rounded border border-slate-800 text-center transition-colors"
                >
                  <span className="text-[10px] font-bold block">SLICE {i + 1}</span>
                  <span className="text-[8px] text-slate-500 block">{(i * 0.3).toFixed(2)}s</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
