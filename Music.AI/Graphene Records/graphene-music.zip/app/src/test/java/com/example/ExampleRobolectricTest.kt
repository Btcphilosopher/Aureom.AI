package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TrackEntity
import com.example.ui.screens.filterSmartTracks
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Graphene Music", appName)
    }

    @Test
    fun `smart playlist engine filters high rating tracks`() {
        val tracks = listOf(
            TrackEntity(id = "1", title = "Low Track", artistName = "Artist A", albumName = "Album A", rating = 2, durationMs = 120000),
            TrackEntity(id = "2", title = "High Track 1", artistName = "Artist A", albumName = "Album A", rating = 4, durationMs = 180000),
            TrackEntity(id = "3", title = "High Track 2", artistName = "Artist B", albumName = "Album B", rating = 5, durationMs = 240000)
        )

        val filtered = filterSmartTracks(tracks, "rating >= 4")
        assertEquals(2, filtered.size)
        assertEquals("High Track 1", filtered[0].title)
        assertEquals("High Track 2", filtered[1].title)
    }
}
