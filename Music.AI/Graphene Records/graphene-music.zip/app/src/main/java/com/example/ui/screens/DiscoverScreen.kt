package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayHistoryEntity
import com.example.data.model.TrackEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*

@Composable
fun DiscoverScreen(
    viewModel: GrapheneViewModel
) {
    val tracks by viewModel.tracks.collectAsState()
    val history by viewModel.recentlyPlayed.collectAsState()

    val recommendations = remember(tracks, history) {
        generateLocalRecommendations(tracks, history)
    }

    val forgottenFavourites = remember(tracks, history) {
        tracks.filter { it.isFavourite && history.none { h -> h.trackId == it.id } }
    }

    val deepCuts = remember(tracks) {
        tracks.filter { it.playCount == 0 }.shuffled().take(5)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "DISCOVERY ENGINE",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "OFFLINE SIGNAL RE-SYNTHESIS & EXPLAINABLE RECS",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneMuted
                )
            }
        }

        Divider(color = GrapheneDarkGray, thickness = 1.dp)

        // RECOMMENDATION BLOCK
        HomeSectionHeader(title = "EXPLAINABLE AUDIOPHILE RECOMMENDATIONS")
        if (recommendations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(1.dp, GrapheneDarkGray)
                    .background(GrapheneGraphite)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Info, tint = GrapheneMuted, contentDescription = null)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "AWAITING INGEST: LOG MORE PLAYS TO INITIATE RECOMMENDATIONS",
                        color = GrapheneMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        } else {
            recommendations.take(4).forEach { rec ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .border(1.dp, MaterialTheme.colorScheme.secondary)
                        .background(GrapheneGraphite)
                        .clickable { viewModel.playTrack(rec.track, recommendations.map { it.track }) }
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "CONFIDENCE: ${rec.confidence}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = rec.track.title, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                        Text(text = "by ${rec.track.artistName}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "ANALYSIS LOG: ${rec.reason}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrapheneSilver
                        )
                    }
                }
            }
        }

        // FORGOTTEN FAVOURITES
        if (forgottenFavourites.isNotEmpty()) {
            HomeSectionHeader(title = "FORGOTTEN ARCHIVE FAVOURITES")
            forgottenFavourites.take(3).forEach { track ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .border(1.dp, GrapheneDarkGray)
                        .background(GrapheneGraphite)
                        .clickable { viewModel.playTrack(track, forgottenFavourites) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = track.title, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                        Text(text = track.artistName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        text = "LAST PLAYED: NEVER",
                        style = MaterialTheme.typography.labelSmall,
                        color = GrapheneMuted
                    )
                }
            }
        }

        // DEEP CUTS (unplayed tracks)
        if (deepCuts.isNotEmpty()) {
            HomeSectionHeader(title = "UNEXPLORED DEEP CUTS")
            deepCuts.forEach { track ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .border(1.dp, GrapheneDarkGray)
                        .background(GrapheneGraphite)
                        .clickable { viewModel.playTrack(track, deepCuts) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = track.title, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                        Text(text = track.artistName, style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                    }
                    Text(
                        text = "0 PLAYS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

data class RecommendationResult(
    val track: TrackEntity,
    val reason: String,
    val confidence: Int
)

// Explains recommend outputs with strict input details
fun generateLocalRecommendations(tracks: List<TrackEntity>, history: List<PlayHistoryEntity>): List<RecommendationResult> {
    val artistCounts = history.groupingBy { it.artistName }.eachCount()
    val favoriteArtists = artistCounts.entries.sortedByDescending { it.value }.map { it.key }

    val recommendations = mutableListOf<RecommendationResult>()

    tracks.forEach { track ->
        val wasPlayed = history.any { it.trackId == track.id }
        if (!wasPlayed) {
            val isFavoriteArtist = favoriteArtists.contains(track.artistName)
            if (isFavoriteArtist) {
                val artistCount = artistCounts[track.artistName] ?: 0
                val confidence = (60 + (artistCount * 8)).coerceAtMost(99)
                recommendations.add(
                    RecommendationResult(
                        track = track,
                        reason = "You have played ${track.artistName} $artistCount time(s) recently. This related recording inside your library remains unexplored.",
                        confidence = confidence
                    )
                )
            } else if (track.isFavourite) {
                recommendations.add(
                    RecommendationResult(
                        track = track,
                        reason = "You flagged this track as highly important, but it has not been included in your historical playback queues recently.",
                        confidence = 85
                    )
                )
            }
        }
    }

    return recommendations.sortedByDescending { it.confidence }
}
