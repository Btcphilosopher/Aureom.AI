package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GrapheneCatalogueEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*

@Composable
fun GrapheneCatalogueScreen(
    viewModel: GrapheneViewModel
) {
    val catalogue by viewModel.grapheneCatalogue.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .padding(bottom = 76.dp)
    ) {
        // Catalogue Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "GRAPHENE RECORD CATALOGUE",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "CURATED AUDIO SPECIMENS & EXCLUSIVE MASTERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneMuted
                )
            }
        }

        Divider(color = GrapheneDarkGray, thickness = 1.dp)

        if (catalogue.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CATALOGUE OFFLINE OR LOADING SCHEMA...",
                    color = GrapheneMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("catalogue_list")
            ) {
                items(catalogue) { release ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .border(1.dp, if (release.collected) MaterialTheme.colorScheme.primary else GrapheneDarkGray)
                            .background(GrapheneGraphite)
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                // Geometric visual art
                                Box(
                                    modifier = Modifier
                                        .size(80.dp)
                                        .background(GrapheneBlack)
                                        .border(1.dp, GrapheneDarkGray),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Album,
                                        contentDescription = null,
                                        tint = if (release.collected) MaterialTheme.colorScheme.primary else GrapheneMuted,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "CAT_REF: GRAPHENE_00${release.id.last()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = release.title,
                                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                                        color = GrapheneOffWhite
                                    )
                                    Text(
                                        text = "by ${release.artistName}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = release.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = GrapheneSilver
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "YEAR: ${release.releaseYear}  |  48kHz Lossless",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GrapheneMuted
                                )

                                Button(
                                    onClick = { viewModel.collectGrapheneRelease(release) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (release.collected) GrapheneDarkGray else MaterialTheme.colorScheme.primary
                                    ),
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Icon(
                                        imageVector = if (release.collected) Icons.Default.LibraryAddCheck else Icons.Default.CloudDownload,
                                        contentDescription = null,
                                        tint = if (release.collected) GrapheneSilver else GrapheneBlack,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (release.collected) "COLLECTED" else "COLLECT LOSSLESS",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (release.collected) GrapheneSilver else GrapheneBlack
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
