package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TrackEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.components.StarRatingBar
import com.example.ui.theme.*

enum class LibraryTab {
    SONGS, ALBUMS, ARTISTS, GENRES
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: GrapheneViewModel
) {
    val tracks by viewModel.tracks.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    val selectedAlbum by viewModel.selectedAlbum.collectAsState()
    val selectedArtist by viewModel.selectedArtist.collectAsState()

    var activeTab by remember { mutableStateOf(LibraryTab.SONGS) }

    // Navigation back logic inside our custom modular views
    if (selectedAlbum != null) {
        AlbumDetailView(
            albumName = selectedAlbum!!,
            viewModel = viewModel,
            onBack = { viewModel.selectAlbum(null) }
        )
    } else if (selectedArtist != null) {
        ArtistDetailView(
            artistName = selectedArtist!!,
            viewModel = viewModel,
            onBack = { viewModel.selectArtist(null) }
        )
    } else {
        // Core list
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(GrapheneBlack)
                .padding(bottom = 76.dp)
        ) {
            // Header with Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GrapheneGraphite)
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "LOCAL DATABASE",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("SEARCH DATABASE...", color = GrapheneMuted, fontFamily = FontFamily.Monospace) },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = GrapheneOffWhite, fontFamily = FontFamily.Monospace),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("library_search_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = GrapheneDarkGray
                        ),
                        leadingIcon = { Icon(imageVector = Icons.Default.Search, tint = GrapheneMuted, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(imageVector = Icons.Default.Clear, tint = GrapheneSilver, contentDescription = "Clear")
                                }
                            }
                        }
                    )
                }
            }

            // Tabs sub-navigation
            if (searchQuery.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GrapheneGraphite)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    LibraryTab.values().forEach { tab ->
                        val isSelected = activeTab == tab
                        Box(
                            modifier = Modifier
                                .clickable { activeTab = tab }
                                .padding(vertical = 12.dp)
                                .border(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    RoundedCornerShape(1.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = tab.name,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else GrapheneMuted
                            )
                        }
                    }
                }
            }

            Divider(color = GrapheneDarkGray, thickness = 1.dp)

            // Content lists
            val displayTracks = if (searchQuery.isNotEmpty()) searchResults else tracks

            if (searchQuery.isNotEmpty()) {
                Text(
                    text = "SEARCH RESULTS [${displayTracks.size} MATCHES]",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(16.dp)
                )
            }

            if (displayTracks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = GrapheneMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("NO TRACKS LOCATED IN SCHEMA", color = GrapheneMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            } else {
                when {
                    searchQuery.isNotEmpty() || activeTab == LibraryTab.SONGS -> {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .testTag("songs_list")
                        ) {
                            items(displayTracks) { track ->
                                TrackListItem(
                                    track = track,
                                    onClick = { viewModel.playTrack(track, displayTracks) },
                                    onToggleFavourite = { viewModel.toggleFavourite(track.id) },
                                    onAddToQueue = { viewModel.addToQueue(track) }
                                )
                            }
                        }
                    }
                    activeTab == LibraryTab.ALBUMS -> {
                        val albums = tracks.map { it.albumName }.distinct()
                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            items(albums) { albumName ->
                                val albumTracks = tracks.filter { it.albumName == albumName }
                                val artist = albumTracks.firstOrNull()?.artistName ?: "Unknown Artist"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.selectAlbum(albumName) }
                                        .padding(16.dp)
                                        .border(1.dp, GrapheneDarkGray)
                                        .background(GrapheneGraphite)
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Album, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(text = albumName, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                                        Text(text = "$artist • ${albumTracks.size} Tracks", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                                    }
                                }
                            }
                        }
                    }
                    activeTab == LibraryTab.ARTISTS -> {
                        val artists = tracks.map { it.artistName }.distinct()
                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            items(artists) { artistName ->
                                val artistTracks = tracks.filter { it.artistName == artistName }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.selectArtist(artistName) }
                                        .padding(16.dp)
                                        .border(1.dp, GrapheneDarkGray)
                                        .background(GrapheneGraphite)
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(text = artistName, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                                        Text(text = "${artistTracks.size} Tracks inside local storage", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                                    }
                                }
                            }
                        }
                    }
                    activeTab == LibraryTab.GENRES -> {
                        val genres = tracks.map { it.genre }.distinct()
                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            items(genres) { genreName ->
                                val genreTracks = tracks.filter { it.genre == genreName }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { /* Filter list or trigger local query */ }
                                        .padding(16.dp)
                                        .border(1.dp, GrapheneDarkGray)
                                        .background(GrapheneGraphite)
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Category, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(text = genreName, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                                        Text(text = "${genreTracks.size} Tracks categorised", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackListItem(
    track: TrackEntity,
    onClick: () -> Unit,
    onToggleFavourite: () -> Unit,
    onAddToQueue: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 16.dp)
            .border(1.dp, GrapheneDarkGray)
            .background(GrapheneGraphite)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(text = track.title, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = track.artistName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                Text(text = "  //  ", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                Text(text = track.albumName, style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted, maxLines = 1)
            }
        }

        // Tech specs display
        Text(
            text = "FLAC | 24-bit",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary),
            modifier = Modifier.padding(end = 8.dp)
        )

        IconButton(onClick = onToggleFavourite) {
            Icon(
                imageVector = if (track.isFavourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favourite",
                tint = if (track.isFavourite) MaterialTheme.colorScheme.tertiary else GrapheneSilver
            )
        }

        IconButton(onClick = onAddToQueue) {
            Icon(imageVector = Icons.Default.Queue, contentDescription = "Add to Queue", tint = GrapheneSilver)
        }
    }
}

@Composable
fun AlbumDetailView(
    albumName: String,
    viewModel: GrapheneViewModel,
    onBack: () -> Unit
) {
    val tracks by viewModel.tracks.collectAsState()
    val albumTracks = tracks.filter { it.albumName == albumName }
    val artistName = albumTracks.firstOrNull()?.artistName ?: "Unknown Artist"
    val year = albumTracks.firstOrNull()?.year ?: 2026
    val genre = albumTracks.firstOrNull()?.genre ?: "Unknown"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, tint = GrapheneOffWhite, contentDescription = "Back")
            }
            Text("ALBUM INDEX DETAIL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }

        // Album info banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, MaterialTheme.colorScheme.primary)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .background(GrapheneDarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Album, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(text = albumName, style = MaterialTheme.typography.displayMedium, color = GrapheneOffWhite)
                    Text(text = artistName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "RELEASE YEAR: $year  |  GENRE: $genre", style = MaterialTheme.typography.labelSmall, color = GrapheneMuted)
                    Text(text = "TOTAL LENGTH: ${albumTracks.size} TRACKS", style = MaterialTheme.typography.labelSmall, color = GrapheneMuted)
                }
            }
        }

        // Action controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { if (albumTracks.isNotEmpty()) viewModel.playTrack(albumTracks.first(), albumTracks) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = GrapheneBlack)
                Spacer(modifier = Modifier.width(8.dp))
                Text("PLAY ALL", color = GrapheneBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            Button(
                onClick = {
                    if (albumTracks.isNotEmpty()) {
                        viewModel.setShuffle(true)
                        viewModel.playTrack(albumTracks.random(), albumTracks)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GrapheneGraphite),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.Shuffle, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SHUFFLE", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        // Tracks List Header
        Text(
            text = "CANONICAL AUDIO TRACKS",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 12.dp)
        )

        albumTracks.forEachIndexed { idx, track ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.playTrack(track, albumTracks) }
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .border(1.dp, GrapheneDarkGray)
                    .background(GrapheneGraphite)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format("%02d", idx + 1),
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.width(36.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = track.title, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                    Text(
                        text = "FLAC / 24-bit / 96.0 kHz  |  Rating: ${if (track.rating > 0) "${track.rating}★" else "Unrated"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = GrapheneMuted
                    )
                }

                // Star Ratings inside Album Detail
                StarRatingBar(
                    rating = track.rating,
                    onRatingSelected = { viewModel.updateRating(track.id, it) }
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = String.format("%d:%02d", track.durationMs / 60000, (track.durationMs % 60000) / 1000),
                    style = MaterialTheme.typography.labelLarge,
                    color = GrapheneSilver
                )
            }
        }
    }
}

@Composable
fun ArtistDetailView(
    artistName: String,
    viewModel: GrapheneViewModel,
    onBack: () -> Unit
) {
    val tracks by viewModel.tracks.collectAsState()
    val socialProfiles by viewModel.socialProfiles.collectAsState()
    val artistTracks = tracks.filter { it.artistName == artistName }
    val artistAlbums = artistTracks.map { it.albumName }.distinct()
    
    val profile = socialProfiles.find { it.name == artistName || it.userId.contains(artistName.replace(" ", "").lowercase()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Back Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, tint = GrapheneOffWhite, contentDescription = "Back")
            }
            Text("ARTIST DIRECTORY PROFILE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
        }

        // Artist Profiler Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, MaterialTheme.colorScheme.secondary)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(GrapheneDarkGray)
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(44.dp).align(Alignment.Center))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = artistName, style = MaterialTheme.typography.displayMedium, color = GrapheneOffWhite)
                        Text(
                            text = if (profile?.isGrapheneArtist == true) "OFFICIAL GRAPHENE RECORDS ARTIST" else "LOCAL LIBRARY CATALOGUE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                profile?.let { prof ->
                    Text(text = prof.bio, style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${prof.followCount} FAN FOLLOWERS",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Button(
                            onClick = { viewModel.toggleFollowArtist(prof) },
                            colors = ButtonDefaults.buttonColors(containerColor = if (prof.isFollowed) GrapheneDarkGray else MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = if (prof.isFollowed) "FOLLOWED ✓" else "FOLLOW FAN",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (prof.isFollowed) GrapheneSilver else GrapheneBlack
                            )
                        }
                    }
                } ?: run {
                    Text(
                        text = "This artist is imported from local storage media files. No cloud biographical meta records found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = GrapheneMuted
                    )
                }
            }
        }

        // Albums list
        HomeSectionHeader(title = "CATALOGUED ALBUMS")
        artistAlbums.forEach { album ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectAlbum(album) }
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .border(1.dp, GrapheneDarkGray)
                    .background(GrapheneGraphite)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Album, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = album, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite, modifier = Modifier.weight(1f))
                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = GrapheneMuted, modifier = Modifier.size(16.dp))
            }
        }

        // All Tracks
        HomeSectionHeader(title = "INDEXED SINE WAVES / TRACKS")
        artistTracks.forEach { track ->
            TrackListItem(
                track = track,
                onClick = { viewModel.playTrack(track, artistTracks) },
                onToggleFavourite = { viewModel.toggleFavourite(track.id) },
                onAddToQueue = { viewModel.addToQueue(track) }
            )
        }
    }
}
