package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TrackEntity
import com.example.playback.RepeatMode
import com.example.ui.GrapheneViewModel
import com.example.ui.components.StarRatingBar
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.*

@Composable
fun NowPlayingScreen(
    viewModel: GrapheneViewModel
) {
    val currentTrack by viewModel.currentTrack.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val position by viewModel.positionMs.collectAsState()
    val duration by viewModel.durationMs.collectAsState()
    val queue by viewModel.queue.collectAsState()
    val activeIndex by viewModel.currentIndex.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()
    val shuffleMode by viewModel.shuffleMode.collectAsState()

    var showQueueSheet by remember { mutableStateOf(false) }

    if (currentTrack == null) return

    // Dynamic rotation animation for vinyl artwork
    val infiniteTransition = rememberInfiniteTransition()
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(GrapheneGraphite, GrapheneBlack)
                )
            )
            .statusBarsPadding()
            .testTag("full_player_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.setPlayerExpanded(false) },
                modifier = Modifier.testTag("player_collapse_button")
            ) {
                Icon(imageVector = Icons.Default.KeyboardArrowDown, tint = GrapheneOffWhite, modifier = Modifier.size(32.dp), contentDescription = "Collapse")
            }
            Text(
                text = "GRAPHENE DECODER STREAM",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(
                onClick = { showQueueSheet = !showQueueSheet }
            ) {
                Icon(
                    imageVector = if (showQueueSheet) Icons.Default.QueueMusic else Icons.Default.FormatListBulleted,
                    tint = if (showQueueSheet) MaterialTheme.colorScheme.primary else GrapheneOffWhite,
                    contentDescription = "Queue"
                )
            }
        }

        if (showQueueSheet) {
            // Queue View Mode
            QueueSection(
                queue = queue,
                activeIndex = activeIndex,
                viewModel = viewModel,
                onDismiss = { showQueueSheet = false }
            )
        } else {
            // Active Player View Mode
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Geometric Vinyl Disc
                Box(
                    modifier = Modifier
                        .size(260.dp)
                        .padding(top = 16.dp)
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(130.dp))
                        .background(GrapheneBlack),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .rotate(if (isPlaying) rotation else 0f)
                            .border(1.dp, GrapheneDarkGray, RoundedCornerShape(120.dp))
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(GrapheneGraphite, GrapheneBlack)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        // Sound waves icon center
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(64.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Track Title & Artist Info
                Text(
                    text = currentTrack!!.title,
                    style = MaterialTheme.typography.displayMedium.copy(fontSize = 24.sp),
                    color = GrapheneOffWhite,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.testTag("player_track_title")
                )
                Text(
                    text = currentTrack!!.artistName,
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.testTag("player_track_artist")
                )
                Text(
                    text = currentTrack!!.albumName,
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneMuted,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Waveform Reactance in central core
                WaveformVisualizer(
                    isPlaying = isPlaying,
                    barCount = 18,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Progress Slider & Timing Indicators
                val progress = if (duration > 0) position.toFloat() / duration else 0f
                Slider(
                    value = progress,
                    onValueChange = { targetPercent ->
                        val targetMs = (targetPercent * duration).toLong()
                        viewModel.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = GrapheneDarkGray
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("player_timeline_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTime(position),
                        style = MaterialTheme.typography.labelSmall,
                        color = GrapheneSilver
                    )
                    Text(
                        text = formatTime(duration),
                        style = MaterialTheme.typography.labelSmall,
                        color = GrapheneSilver
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Standard Playback Controls Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Shuffle Toggle
                    IconButton(onClick = { viewModel.toggleShuffle() }) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Shuffle",
                            tint = if (shuffleMode) MaterialTheme.colorScheme.secondary else GrapheneMuted,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Previous Button
                    IconButton(onClick = { viewModel.previous() }) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            tint = GrapheneOffWhite,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Large Core Play/Pause Toggle
                    IconButton(
                        onClick = { viewModel.togglePlayPause() },
                        modifier = Modifier
                            .size(64.dp)
                            .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(32.dp))
                            .background(GrapheneBlack)
                            .testTag("player_play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Next Button
                    IconButton(onClick = { viewModel.next() }) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            tint = GrapheneOffWhite,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Repeat Modes Toggle
                    IconButton(onClick = { viewModel.toggleRepeat() }) {
                        val icon = when (repeatMode) {
                            RepeatMode.OFF -> Icons.Default.Repeat
                            RepeatMode.ALL -> Icons.Default.Repeat
                            RepeatMode.ONE -> Icons.Default.RepeatOne
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Repeat",
                            tint = if (repeatMode != RepeatMode.OFF) MaterialTheme.colorScheme.primary else GrapheneMuted,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Database ratings integration in-view
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GrapheneDarkGray)
                        .background(GrapheneGraphite)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RATING ARCHIVE:",
                        style = MaterialTheme.typography.labelSmall,
                        color = GrapheneMuted
                    )
                    StarRatingBar(
                        rating = currentTrack!!.rating,
                        onRatingSelected = { viewModel.updateRating(currentTrack!!.id, it) },
                        starSize = 24
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Technical Diagnostic specs panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        .background(GrapheneBlack)
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = "METADATA STREAM DECODER:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "FILE_URI: ${currentTrack!!.fileUri}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                            color = GrapheneSilver
                        )
                        Text(
                            text = "RELATIVE_PATH: ${currentTrack!!.relativePath}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                            color = GrapheneSilver
                        )
                        Text(
                            text = "FORMAT: WAV/FLAC 96.0 kHz Stereo (24-bit PCM)",
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                            color = GrapheneSilver
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QueueSection(
    queue: List<TrackEntity>,
    activeIndex: Int,
    viewModel: GrapheneViewModel,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "UPCOMING WAVEFORMS [${queue.size} TOTAL]",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            TextButton(onClick = { viewModel.clearQueue() }) {
                Text(
                    text = "CLEAR ALL",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(queue) { idx, track ->
                val isActive = idx == activeIndex
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(
                            1.dp,
                            if (isActive) MaterialTheme.colorScheme.primary else GrapheneDarkGray
                        )
                        .background(GrapheneGraphite)
                        .clickable { viewModel.playTrack(track) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${idx + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isActive) MaterialTheme.colorScheme.primary else GrapheneMuted,
                        modifier = Modifier.width(28.dp)
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isActive) MaterialTheme.colorScheme.primary else GrapheneOffWhite
                        )
                        Text(
                            text = track.artistName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrapheneMuted
                        )
                    }

                    if (!isActive) {
                        IconButton(onClick = { viewModel.removeFromQueue(track.id) }) {
                            Icon(
                                imageVector = Icons.Default.RemoveCircle,
                                tint = MaterialTheme.colorScheme.tertiary,
                                contentDescription = "Remove"
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            tint = MaterialTheme.colorScheme.primary,
                            contentDescription = "Active"
                        )
                    }
                }
            }
        }
    }
}

fun formatTime(ms: Long): String {
    val sec = (ms / 1000) % 60
    val min = (ms / 60000) % 60
    return String.format("%02d:%02d", min, sec)
}
