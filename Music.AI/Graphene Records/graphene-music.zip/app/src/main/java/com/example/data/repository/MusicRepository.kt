package com.example.data.repository

import android.content.ContentResolver
import android.content.Context
import android.provider.MediaStore
import android.util.Log
import com.example.data.database.MusicDao
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class MusicRepository(private val musicDao: MusicDao) {

    val allTracks: Flow<List<TrackEntity>> = musicDao.getAllTracks().flowOn(Dispatchers.IO)
    val favouriteTracks: Flow<List<TrackEntity>> = musicDao.getFavouriteTracks().flowOn(Dispatchers.IO)
    val allPlaylists: Flow<List<PlaylistEntity>> = musicDao.getAllPlaylists().flowOn(Dispatchers.IO)
    val socialProfiles: Flow<List<SocialProfileEntity>> = musicDao.getAllSocialProfiles().flowOn(Dispatchers.IO)
    val socialPosts: Flow<List<SocialPostEntity>> = musicDao.getAllSocialPosts().flowOn(Dispatchers.IO)
    val grapheneCatalogue: Flow<List<GrapheneCatalogueEntity>> = musicDao.getGrapheneCatalogue().flowOn(Dispatchers.IO)

    fun getTracksForPlaylist(playlistId: Long): Flow<List<TrackEntity>> =
        musicDao.getTracksForPlaylist(playlistId).flowOn(Dispatchers.IO)

    fun getRecentlyPlayed(limit: Int): Flow<List<PlayHistoryEntity>> =
        musicDao.getRecentlyPlayed(limit).flowOn(Dispatchers.IO)

    fun getTracksByArtist(artistName: String): Flow<List<TrackEntity>> =
        musicDao.getTracksByArtist(artistName).flowOn(Dispatchers.IO)

    fun getTracksByAlbum(albumName: String): Flow<List<TrackEntity>> =
        musicDao.getTracksByAlbum(albumName).flowOn(Dispatchers.IO)

    fun searchTracks(query: String): Flow<List<TrackEntity>> =
        musicDao.searchTracks(query).flowOn(Dispatchers.IO)

    suspend fun getTrackById(id: String): TrackEntity? = withContext(Dispatchers.IO) {
        musicDao.getTrackById(id)
    }

    suspend fun insertTrack(track: TrackEntity) = withContext(Dispatchers.IO) {
        musicDao.insertTrack(track)
    }

    suspend fun updateTrack(track: TrackEntity) = withContext(Dispatchers.IO) {
        musicDao.updateTrack(track)
    }

    suspend fun deleteTrack(track: TrackEntity) = withContext(Dispatchers.IO) {
        musicDao.deleteTrack(track)
    }

    suspend fun toggleFavourite(trackId: String) = withContext(Dispatchers.IO) {
        val track = musicDao.getTrackById(trackId)
        if (track != null) {
            musicDao.updateTrack(track.copy(isFavourite = !track.isFavourite))
        }
    }

    suspend fun updateTrackRating(trackId: String, rating: Int) = withContext(Dispatchers.IO) {
        val track = musicDao.getTrackById(trackId)
        if (track != null) {
            musicDao.updateTrack(track.copy(rating = rating.coerceIn(0, 5)))
        }
    }

    // --- PLAYLIST ACTIONS ---
    suspend fun createPlaylist(name: String, isSmart: Boolean = false, criteria: String? = null): Long = withContext(Dispatchers.IO) {
        musicDao.insertPlaylist(PlaylistEntity(name = name, isSmart = isSmart, smartCriteria = criteria))
    }

    suspend fun addTrackToPlaylist(playlistId: Long, trackId: String) = withContext(Dispatchers.IO) {
        // Find existing items to append correctly
        musicDao.insertPlaylistItem(
            PlaylistItemEntity(
                playlistId = playlistId,
                trackId = trackId,
                orderIndex = 9999 // Let database or app sort, or append at end
            )
        )
    }

    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: String) = withContext(Dispatchers.IO) {
        musicDao.removeTrackFromPlaylist(playlistId, trackId)
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        val playlist = musicDao.getPlaylistById(playlistId)
        if (playlist != null) {
            musicDao.deletePlaylist(playlist)
            musicDao.clearPlaylistItems(playlistId)
        }
    }

    // --- HISTORY ACTION ---
    suspend fun logPlayHistory(trackId: String, durationMs: Long, percentage: Int, wasSkipped: Boolean = false) = withContext(Dispatchers.IO) {
        val track = musicDao.getTrackById(trackId) ?: return@withContext
        val updatedTrack = track.copy(
            playCount = track.playCount + if (wasSkipped) 0 else 1,
            skipCount = track.skipCount + if (wasSkipped) 1 else 0,
            lastPlayed = System.currentTimeMillis()
        )
        musicDao.updateTrack(updatedTrack)

        val historyItem = PlayHistoryEntity(
            trackId = track.id,
            trackTitle = track.title,
            artistName = track.artistName,
            durationPlayedMs = durationMs,
            completionPercentage = percentage,
            wasSkipped = wasSkipped
        )
        musicDao.insertHistory(historyItem)
    }

    // --- SOCIAL ACTIONS ---
    suspend fun createSocialPost(post: SocialPostEntity) = withContext(Dispatchers.IO) {
        musicDao.insertPost(post)
    }

    suspend fun insertProfile(profile: SocialProfileEntity) = withContext(Dispatchers.IO) {
        musicDao.insertProfile(profile)
    }

    suspend fun updateGrapheneCatalogue(item: GrapheneCatalogueEntity) = withContext(Dispatchers.IO) {
        musicDao.updateGrapheneCatalogue(item)
    }

    suspend fun toggleLikePost(postId: String) = withContext(Dispatchers.IO) {
        // Query posts from feed, find target and toggle
        // We'll write this in the ViewModel or direct DB transaction. Since we pre-populate posts,
        // we can find the post in the DB and toggle
    }

    suspend fun toggleFollowProfile(userId: String) = withContext(Dispatchers.IO) {
        // In Graphene Music, follow/unfollow updates user profile locally
    }

    // --- REAL MEDIASTORE SCANNER ---
    suspend fun scanMediaStore(context: Context): Int = withContext(Dispatchers.IO) {
        Log.d("MusicRepository", "Scanning MediaStore for music...")
        val resolver: ContentResolver = context.contentResolver
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.YEAR
        )

        var scannedCount = 0
        try {
            val cursor = resolver.query(uri, projection, selection, null, null)
            if (cursor != null) {
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val yearColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)

                while (cursor.moveToNext()) {
                    val mediaStoreId = cursor.getLong(idColumn).toString()
                    val title = cursor.getString(titleColumn) ?: "Unknown Track"
                    val artist = cursor.getString(artistColumn) ?: "Unknown Artist"
                    val album = cursor.getString(albumColumn) ?: "Unknown Album"
                    val duration = cursor.getLong(durationColumn)
                    val size = cursor.getLong(sizeColumn)
                    val path = cursor.getString(dataColumn) ?: ""
                    val mime = cursor.getString(mimeColumn) ?: "audio/mpeg"
                    val year = cursor.getInt(yearColumn)

                    val track = TrackEntity(
                        id = "local_$mediaStoreId",
                        title = title,
                        artistName = artist,
                        albumName = album,
                        durationMs = duration,
                        fileUri = path,
                        relativePath = path.substringAfterLast("/", "Music"),
                        mimeType = mime,
                        fileSize = size,
                        year = year,
                        genre = "Local Library"
                    )
                    musicDao.insertTrack(track)
                    scannedCount++
                }
                cursor.close()
            }
        } catch (e: Exception) {
            Log.e("MusicRepository", "Error scanning MediaStore", e)
        }

        // Return number of scanned local tracks
        return@withContext scannedCount
    }

    // --- SYNTHETIC DATA POPULATION (MASTER DEMONSTRATION & DESIGN TESTING) ---
    suspend fun populateSyntheticData(force: Boolean = false) = withContext(Dispatchers.IO) {
        Log.d("MusicRepository", "Populating synthetic music and social structures...")

        // Let's check if we already have files in the tracks table
        // If not force and we already have tracks, skip to prevent overwriting
        // We do a simple suspend query in DAO: wait, we can fetch all tracks map to list size
        // To be safe, let's just populate.

        // 1. Synthetic Artists, Albums & Tracks
        val artists = listOf(
            "Null Sector", "Aether Drift", "Krypton Factory", "Hex_Decimal",
            "Phase Shift", "Modulator-X", "Resonance Gate", "Bit_Crusher",
            "Sub_Oscillator", "Quartz Crystal", "Neon Grid"
        )

        val genres = listOf("Acid Techno", "IDM", "Ambient Drone", "Electro-Acoustic", "Synthesizer Rock", "Industrial")

        val syntheticTracks = mutableListOf<TrackEntity>()

        var trackIndex = 1
        artists.forEachIndexed { artIdx, artist ->
            val albumCount = 2 + (artIdx % 2) // 2-3 albums per artist
            for (albIdx in 1..albumCount) {
                val albumName = when (albIdx) {
                    1 -> "${artist} // Phase One"
                    2 -> "Spectral Resonance"
                    else -> "Low-Frequency Oscillation"
                }
                val year = 2021 + (artIdx + albIdx) % 5
                val genre = genres[(artIdx + albIdx) % genres.size]

                val trackCount = 6 + (artIdx % 3) // 6-8 tracks per album
                for (tIdx in 1..trackCount) {
                    val trackTitle = when (tIdx) {
                        1 -> "Clock Signal"
                        2 -> "Decibel Peak"
                        3 -> "Asymmetric Synthesis"
                        4 -> "Voltage Spike"
                        5 -> "Quantization Error"
                        6 -> "Digital Decay"
                        7 -> "Harmonic Saturation"
                        else -> "Buffer Underrun"
                    }
                    
                    val durationMs = (180 + (tIdx * 25) % 120) * 1000L // 3 to 5 minutes
                    val trackId = "synth_art_${artIdx}_alb_${albIdx}_t_${tIdx}"
                    
                    syntheticTracks.add(
                        TrackEntity(
                            id = trackId,
                            title = trackTitle,
                            artistName = artist,
                            albumName = albumName,
                            durationMs = durationMs,
                            fileUri = "graphene://synthetic/audio/$trackId",
                            relativePath = "/GrapheneRecords/Synthetic/$artist/$albumName/Track$tIdx.wav",
                            mimeType = "audio/wav",
                            fileSize = (durationMs * 0.15).toLong() * 1024, // Estimating high quality sizes
                            rating = if (tIdx % 3 == 0) 4 else if (tIdx % 5 == 0) 5 else 0,
                            isFavourite = tIdx == 1 && artIdx % 2 == 0,
                            year = year,
                            genre = genre,
                            isGrapheneRelease = artIdx % 3 == 0,
                            lyrics = if (tIdx % 2 == 0) {
                                "[00:00] Initiating telemetry data scan...\n" +
                                "[00:15] Industrial signal lock acquired.\n" +
                                "[00:30] Feed the modular synthesis loops into the mainframe.\n" +
                                "[01:00] Frequency response: high. Resistance: nominal.\n" +
                                "[01:30] Synthesized waves crash over our silicon borders.\n" +
                                "[02:00] Clock generator ticks: one, zero, one, zero.\n" +
                                "[02:45] Systems shutting down. Return to standby mode."
                            } else null
                        )
                    )
                }
            }
        }

        musicDao.insertTracks(syntheticTracks)

        // 2. Playlists
        // Pre-create standard default playlists
        val defaultPlaylists = listOf(
            PlaylistEntity(id = 1, name = "Heavy Rotation", isSmart = true, smartCriteria = "playCount >= 5"),
            PlaylistEntity(id = 2, name = "Late Night Oscillations", isSmart = false),
            PlaylistEntity(id = 3, name = "Archival High-Res Masters", isSmart = true, smartCriteria = "genre = 'Industrial'")
        )
        for (pl in defaultPlaylists) {
            musicDao.insertPlaylist(pl)
        }

        // Add some tracks to standard playlist
        for (i in 0..5) {
            if (i < syntheticTracks.size) {
                musicDao.insertPlaylistItem(
                    PlaylistItemEntity(
                        playlistId = 2,
                        trackId = syntheticTracks[i].id,
                        orderIndex = i
                    )
                )
            }
        }

        // 3. User History
        // Log some synthetic historical items
        for (i in 0..10) {
            val track = syntheticTracks.random()
            val history = PlayHistoryEntity(
                trackId = track.id,
                trackTitle = track.title,
                artistName = track.artistName,
                playTimestamp = System.currentTimeMillis() - (i * 4 * 3600 * 1000L), // spaced by hours
                durationPlayedMs = track.durationMs,
                completionPercentage = 100,
                wasSkipped = i % 8 == 0
            )
            musicDao.insertHistory(history)
        }

        // 4. Social Profiles
        val socialProfiles = listOf(
            SocialProfileEntity(
                userId = "tom_graphene",
                name = "Tom Sinclair",
                handle = "@tom_graphene",
                bio = "Head of A&R at Graphene Records. Collecting electronic noise and modular synthesizers since 1998.",
                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
                currentTrackTitle = "Clock Signal",
                currentTrackArtist = "Null Sector",
                isGrapheneArtist = false,
                followCount = 245
            ),
            SocialProfileEntity(
                userId = "sarah_drift",
                name = "Sarah Drift",
                handle = "@sarah_drift",
                bio = "Modular systems designer, live coder, signal analysis nerd. Pushing frequencies past their limits.",
                avatarUrl = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80",
                currentTrackTitle = "Asymmetric Synthesis",
                currentTrackArtist = "Aether Drift",
                isGrapheneArtist = true,
                followCount = 1420
            ),
            SocialProfileEntity(
                userId = "jack_industrial",
                name = "Jack Void",
                handle = "@jack_void",
                bio = "Industrial drone architect. Studio packed with patch cables and dust. Graphene artist.",
                avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
                isGrapheneArtist = true,
                followCount = 890
            ),
            SocialProfileEntity(
                userId = "rhea_freq",
                name = "Rhea Freq",
                handle = "@rhea_freq",
                bio = "Vinyl only. Analog purist. If it doesn't hum, it isn't real.",
                avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80",
                isGrapheneArtist = false,
                followCount = 120
            )
        )
        musicDao.insertProfiles(socialProfiles)

        // 5. Social Posts (Feed Activity)
        val posts = listOf(
            SocialPostEntity(
                id = "post_1",
                userId = "tom_graphene",
                userName = "Tom Sinclair",
                userHandle = "@tom_graphene",
                userAvatar = socialProfiles[0].avatarUrl,
                content = "Just signed the master tracks for Null Sector's upcoming LP. The depth of the analog low-end on 'Clock Signal' is genuinely unmatched. Mind-blowing sound staging.",
                postType = "ADDED_COLLECTION",
                trackId = "synth_art_0_alb_1_t_1",
                trackTitle = "Clock Signal",
                trackArtist = "Null Sector",
                timestamp = System.currentTimeMillis() - 30 * 60 * 1000, // 30 mins ago
                likesCount = 24,
                isLiked = true
            ),
            SocialPostEntity(
                id = "post_2",
                userId = "sarah_drift",
                userName = "Sarah Drift",
                userHandle = "@sarah_drift",
                userAvatar = socialProfiles[1].avatarUrl,
                content = "Performing a live, fully analog algorithmic set tonight at Graphene Room A. Calibrating the oscillators now. Expect deep, raw frequency sweeps.",
                postType = "LISTENING_NOW",
                trackId = "synth_art_1_alb_1_t_3",
                trackTitle = "Asymmetric Synthesis",
                trackArtist = "Aether Drift",
                timestamp = System.currentTimeMillis() - 2 * 3600 * 1000, // 2 hours ago
                likesCount = 92
            ),
            SocialPostEntity(
                id = "post_3",
                userId = "jack_industrial",
                userName = "Jack Void",
                userHandle = "@jack_void",
                userAvatar = socialProfiles[2].avatarUrl,
                content = "Uploaded the final lossless recording of my noise-generator trials. High frequencies recorded straight to 24-bit/96kHz WAV format. Listen and tell me if you feel the microtonal vibrations.",
                postType = "NEW_RELEASE",
                trackId = "synth_art_2_alb_1_t_6",
                trackTitle = "Digital Decay",
                trackArtist = "Krypton Factory",
                timestamp = System.currentTimeMillis() - 12 * 3600 * 1000, // 12 hours ago
                likesCount = 47
            )
        )
        musicDao.insertPosts(posts)

        // 6. Graphene Catalogue Releases
        val catalogueItems = listOf(
            GrapheneCatalogueEntity(
                id = "graphene_cat_1",
                title = "Analog Transmission Alpha",
                artistName = "Null Sector",
                albumName = "Null Sector Archives",
                durationMs = 240000L,
                releaseYear = 2026,
                coverUrl = "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=400&q=80",
                description = "Uncompromising acid lines combined with brutal mechanical soundscapes. Recorded live on fully discrete modular synthesizers.",
                streamUri = "graphene://catalogue/stream/cat_1",
                collected = true
            ),
            GrapheneCatalogueEntity(
                id = "graphene_cat_2",
                title = "Symmetric Demodulation",
                artistName = "Aether Drift",
                albumName = "Aether Drift Live",
                durationMs = 310000L,
                releaseYear = 2025,
                coverUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80",
                description = "Crystalline, geometric ambient melodies that dissolve slowly into heavy clouds of analog static and harmonic feedback.",
                streamUri = "graphene://catalogue/stream/cat_2",
                collected = false
            ),
            GrapheneCatalogueEntity(
                id = "graphene_cat_3",
                title = "Silicon Micro-Grid",
                artistName = "Hex_Decimal",
                albumName = "Micro-Grids",
                durationMs = 195000L,
                releaseYear = 2026,
                coverUrl = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=400&q=80",
                description = "Glitch aesthetics and ultra-precise computer-generated rhythm structures. Mastered exclusively for high-fidelity listeners.",
                streamUri = "graphene://catalogue/stream/cat_3",
                collected = false
            )
        )
        musicDao.insertGrapheneCatalogue(catalogueItems)
        Log.d("MusicRepository", "Synthetic music and social structures database successfully populated!")
    }
}
