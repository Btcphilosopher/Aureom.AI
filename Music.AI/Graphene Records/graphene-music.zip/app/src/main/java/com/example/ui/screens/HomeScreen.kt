package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TrackEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: GrapheneViewModel,
    onNavigateToLibrary: () -> Unit,
    onNavigateToPlaylists: () -> Unit,
    onNavigateToDiscover: () -> Unit,
    onNavigateToSocial: () -> Unit,
    onNavigateToCatalogue: () -> Unit
) {
    val tracks by viewModel.tracks.collectAsState()
    val favourites by viewModel.favourites.collectAsState()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentTrack by viewModel.currentTrack.collectAsState()

    // Extract distinct albums and artists for quick sections
    val distinctAlbums = remember(tracks) {
        tracks.map { it.albumName }.distinct().take(10)
    }

    val distinctArtists = remember(tracks) {
        tracks.map { it.artistName }.distinct().take(10)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp) // Leave space for floating Mini Player
    ) {
        // Asymmetrical Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(GrapheneGraphite, GrapheneBlack)
                    )
                )
                .padding(horizontal = 16.dp, vertical = 24.dp)
        ) {
            Column {
                Text(
                    text = "GRAPHENE MUSIC",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "MY MUSIC. MY LIBRARY. MY ARCHIVE.",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneSilver
                )
            }
            
            // Quick Rescan / Terminal button top right
            IconButton(
                onClick = { viewModel.toggleCommandPalette() },
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
                    .background(GrapheneGraphite)
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Command Console",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        Divider(color = GrapheneDarkGray, thickness = 1.dp)

        // Industrial Navigation Quick Links
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickLinkButton(title = "SONGS", icon = Icons.Default.MusicNote, onClick = onNavigateToLibrary)
            QuickLinkButton(title = "PLAYLISTS", icon = Icons.Default.QueueMusic, onClick = onNavigateToPlaylists)
            QuickLinkButton(title = "DISCOVER", icon = Icons.Default.Psychology, onClick = onNavigateToDiscover)
            QuickLinkButton(title = "CATALOGUE", icon = Icons.Default.Album, onClick = onNavigateToCatalogue)
        }

        // Active Playback Overlay Highlight
        if (currentTrack != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .border(1.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(2.dp))
                    .background(GrapheneGraphite)
                    .clickable { viewModel.setPlayerExpanded(true) }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = "Playing",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "NOW PLAYING",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = currentTrack!!.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = GrapheneOffWhite,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // RECENTLY PLAYED SECTION
        if (recentlyPlayed.isNotEmpty()) {
            HomeSectionHeader(title = "RECENTLY PLAYED")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.testTag("recently_played_row")
            ) {
                items(recentlyPlayed.take(6)) { historyItem ->
                    val originalTrack = tracks.find { it.id == historyItem.trackId }
                    Box(
                        modifier = Modifier
                            .width(130.dp)
                            .border(1.dp, GrapheneDarkGray)
                            .background(GrapheneGraphite)
                            .clickable {
                                if (originalTrack != null) {
                                    viewModel.playTrack(originalTrack, recentlyPlayed.mapNotNull { h -> tracks.find { it.id == h.trackId } })
                                }
                            }
                            .padding(8.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .background(GrapheneDarkGray)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = GrapheneSilver,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = historyItem.trackTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = GrapheneOffWhite,
                                maxLines = 1
                            )
                            Text(
                                text = historyItem.artistName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // FAVOURITES HIGHLIGHT
        if (favourites.isNotEmpty()) {
            HomeSectionHeader(title = "FAVOURITES ARCHIVE")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.testTag("favourites_row")
            ) {
                items(favourites) { track ->
                    Box(
                        modifier = Modifier
                            .width(130.dp)
                            .border(1.dp, GrapheneDarkGray)
                            .background(GrapheneGraphite)
                            .clickable { viewModel.playTrack(track, favourites) }
                            .padding(8.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .background(GrapheneDarkGray)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = track.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = GrapheneOffWhite,
                                maxLines = 1
                            )
                            Text(
                                text = track.artistName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = GrapheneMuted,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // ALBUMS CATALOGUE
        if (distinctAlbums.isNotEmpty()) {
            HomeSectionHeader(title = "ALBUM DATABASES")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(distinctAlbums) { albumName ->
                    val albumTracks = tracks.filter { it.albumName == albumName }
                    val albumArtist = albumTracks.firstOrNull()?.artistName ?: "Unknown Artist"
                    
                    Box(
                        modifier = Modifier
                            .width(130.dp)
                            .border(1.dp, GrapheneDarkGray)
                            .background(GrapheneGraphite)
                            .clickable {
                                viewModel.selectAlbum(albumName)
                                onNavigateToLibrary()
                            }
                            .padding(8.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .background(GrapheneDarkGray)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LibraryMusic,
                                    contentDescription = null,
                                    tint = GrapheneSilver,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = albumName,
                                style = MaterialTheme.typography.titleMedium,
                                color = GrapheneOffWhite,
                                maxLines = 1
                            )
                            Text(
                                text = albumArtist,
                                style = MaterialTheme.typography.bodyMedium,
                                color = GrapheneMuted,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // ARTISTS CATALOGUE
        if (distinctArtists.isNotEmpty()) {
            HomeSectionHeader(title = "ARTIST DIRECTORIES")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(distinctArtists) { artistName ->
                    Box(
                        modifier = Modifier
                            .width(110.dp)
                            .border(1.dp, GrapheneDarkGray)
                            .background(GrapheneGraphite)
                            .clickable {
                                viewModel.selectArtist(artistName)
                                onNavigateToLibrary()
                            }
                            .padding(12.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(GrapheneDarkGray)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = artistName,
                                style = MaterialTheme.typography.titleMedium,
                                color = GrapheneOffWhite,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 12.dp)
    )
}

@Composable
fun QuickLinkButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .border(1.dp, GrapheneDarkGray)
            .background(GrapheneGraphite)
            .padding(12.dp)
            .width(72.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = GrapheneSilver
        )
    }
}
