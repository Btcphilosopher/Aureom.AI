package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlaylistEntity
import com.example.data.model.TrackEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(
    viewModel: GrapheneViewModel
) {
    val playlists by viewModel.playlists.collectAsState()
    val tracks by viewModel.tracks.collectAsState()
    val selectedPlaylist by viewModel.selectedPlaylist.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var isSmartPlaylist by remember { mutableStateOf(false) }
    var smartRuleSelection by remember { mutableStateOf("rating >= 4") }

    if (selectedPlaylist != null) {
        PlaylistDetailView(
            playlist = selectedPlaylist!!,
            viewModel = viewModel,
            allTracks = tracks,
            onBack = { viewModel.selectPlaylist(null) }
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(GrapheneBlack)
                .padding(bottom = 76.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GrapheneGraphite)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PLAYLIST DICTIONARIES",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "CUSTOM SEQUENCES & SMART QUERIES",
                        style = MaterialTheme.typography.labelSmall,
                        color = GrapheneMuted
                    )
                }

                IconButton(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
                        .background(GrapheneBlack)
                        .testTag("create_playlist_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, tint = MaterialTheme.colorScheme.primary, contentDescription = "Create Playlist")
                }
            }

            Divider(color = GrapheneDarkGray, thickness = 1.dp)

            if (playlists.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NO PLAYLISTS INITIALISED IN LOCAL STORAGE",
                        color = GrapheneMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f)
                ) {
                    items(playlists) { pl ->
                        val count = if (pl.isSmart) {
                            filterSmartTracks(tracks, pl.smartCriteria).size
                        } else {
                            // We can let the DB handle it, or we will query inside Detail.
                            // We will approximate or let details show it
                            "Custom"
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectPlaylist(pl) }
                                .padding(16.dp)
                                .border(1.dp, GrapheneDarkGray)
                                .background(GrapheneGraphite)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (pl.isSmart) Icons.Default.Psychology else Icons.Default.QueueMusic,
                                contentDescription = null,
                                tint = if (pl.isSmart) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = pl.name, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                                Text(
                                    text = if (pl.isSmart) "SMART ENGINE RULE: ${pl.smartCriteria}" else "NORMAL LIST SELECTION",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = GrapheneMuted
                                )
                            }
                            Text(
                                text = if (pl.isSmart) "$count tracks" else "Sequence",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    // Playlist Creation Dialog
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("INITIALISE PLAYLIST SCHEMA", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("PLAYLIST NAME...", color = GrapheneMuted) },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = GrapheneOffWhite),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("playlist_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = GrapheneDarkGray
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isSmartPlaylist,
                            onCheckedChange = { isSmartPlaylist = it },
                            colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.secondary)
                        )
                        Text("ENABLE SMART ENGINE RULE", style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                    }

                    if (isSmartPlaylist) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("CRITERIA FILTER:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                        
                        // Select Rule Row
                        Column {
                            val rules = listOf("rating >= 4", "genre = 'Industrial'", "playCount >= 5")
                            rules.forEach { rule ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { smartRuleSelection = rule }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = smartRuleSelection == rule,
                                        onClick = { smartRuleSelection = rule },
                                        colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.secondary)
                                    )
                                    Text(text = "Tracks matching [$rule]", style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            viewModel.createPlaylist(
                                name = newPlaylistName,
                                isSmart = isSmartPlaylist,
                                criteria = if (isSmartPlaylist) smartRuleSelection else null
                            )
                            newPlaylistName = ""
                            isSmartPlaylist = false
                            showCreateDialog = false
                        }
                    },
                    modifier = Modifier.testTag("confirm_create_playlist")
                ) {
                    Text("COMPILE", color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("ABORT", color = GrapheneMuted)
                }
            },
            containerColor = GrapheneGraphite,
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
        )
    }
}

@Composable
fun PlaylistDetailView(
    playlist: PlaylistEntity,
    viewModel: GrapheneViewModel,
    allTracks: List<TrackEntity>,
    onBack: () -> Unit
) {
    // For smart playlists, filter list directly. For normal playlists, fetch items reactively from db
    val playlistTracksFlow = remember(playlist) { viewModel.getTracksForPlaylist(playlist.id) }
    val playlistTracks by playlistTracksFlow.collectAsState(initial = emptyList())

    val displayTracks = if (playlist.isSmart) {
        remember(allTracks, playlist.smartCriteria) {
            filterSmartTracks(allTracks, playlist.smartCriteria)
        }
    } else {
        playlistTracks
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .padding(bottom = 80.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, tint = GrapheneOffWhite, contentDescription = "Back")
            }
            Text("PLAYLIST COMPILATION VIEW", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.weight(1f))
            
            // Delete Playlist Button
            IconButton(onClick = {
                viewModel.deletePlaylist(playlist.id)
                onBack()
            }) {
                Icon(imageVector = Icons.Default.Delete, tint = MaterialTheme.colorScheme.tertiary, contentDescription = "Delete Playlist")
            }
        }

        // Info block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, if (playlist.isSmart) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text(text = playlist.name, style = MaterialTheme.typography.displayMedium, color = GrapheneOffWhite)
                Text(
                    text = if (playlist.isSmart) "SMART LOGICAL ENGINE DETECTED" else "MANUAL USER CHRONOLOGY SEQUENCE",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (playlist.isSmart) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                )
                if (playlist.isSmart) {
                    Text(
                        text = "DB QUERY RULE: tracks matching [${playlist.smartCriteria}]",
                        style = MaterialTheme.typography.bodyMedium,
                        color = GrapheneSilver
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ACTIVE INDEX: ${displayTracks.size} AUDIO RECORD(S)",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneMuted
                )
            }
        }

        // Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { if (displayTracks.isNotEmpty()) viewModel.playTrack(displayTracks.first(), displayTracks) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.weight(1f),
                enabled = displayTracks.isNotEmpty()
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = GrapheneBlack)
                Spacer(modifier = Modifier.width(8.dp))
                Text("EXECUTE", color = GrapheneBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        // List
        if (displayTracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("EMPTY SELECTION INDEX. ADD AUDIO RECORDS TO POPULATE.", color = GrapheneMuted, style = MaterialTheme.typography.labelSmall)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f)
            ) {
                items(displayTracks) { track ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .border(1.dp, GrapheneDarkGray)
                            .background(GrapheneGraphite)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = track.title, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                            Text(text = track.artistName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        }

                        // Remove from playlist action (for normal playlists)
                        if (!playlist.isSmart) {
                            IconButton(onClick = { viewModel.removeTrackFromPlaylist(playlist.id, track.id) }) {
                                Icon(imageVector = Icons.Default.RemoveCircle, tint = MaterialTheme.colorScheme.tertiary, contentDescription = "Remove")
                            }
                        }

                        IconButton(onClick = { viewModel.playTrack(track, displayTracks) }) {
                            Icon(imageVector = Icons.Default.PlayCircle, tint = GrapheneSilver, contentDescription = "Play")
                        }
                    }
                }
            }
        }
    }
}

// Logical Local Rule Engine for Smart Playlists
fun filterSmartTracks(tracks: List<TrackEntity>, criteria: String?): List<TrackEntity> {
    if (criteria == null) return emptyList()
    return when {
        criteria.contains("rating >= 4") -> tracks.filter { it.rating >= 4 }
        criteria.contains("genre = 'Industrial'") -> tracks.filter { it.genre.equals("Industrial", ignoreCase = true) }
        criteria.contains("playCount >= 5") -> tracks.filter { it.playCount >= 5 }
        else -> tracks
    }
}
