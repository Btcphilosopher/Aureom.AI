package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Graphene Records Industrial Color Palette
val GrapheneBlack = Color(0xFF080808)       // Deep core background
val GrapheneGraphite = Color(0xFF141414)    // Surface depth, containers, panels
val GrapheneDarkGray = Color(0xFF222222)    // Secondary borders & elevation
val GrapheneSilver = Color(0xFFDCDCDC)      // Primary high-contrast body text
val GrapheneMuted = Color(0xFF7A7A7A)       // Lower-hierarchy labels, metadata

val GrapheneAcidGreen = Color(0xFFCCFF00)   // High-voltage primary accent
val GrapheneElectricBlue = Color(0xFF00E5FF)// Secondary interactive state / streaming
val GrapheneFuchsia = Color(0xFFFF0055)     // Favorites & rating highlights
val GrapheneOffWhite = Color(0xFFFAFAFA)    // Strong high-contrast display text
