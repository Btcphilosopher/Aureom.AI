package com.example.data.database

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {

    // --- TRACKS ---
    @Query("SELECT * FROM tracks ORDER BY title ASC")
    fun getAllTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE isFavourite = 1")
    fun getFavouriteTracks(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE id = :id LIMIT 1")
    suspend fun getTrackById(id: String): TrackEntity?

    @Query("SELECT * FROM tracks WHERE artistName = :artistName ORDER BY albumName ASC, title ASC")
    fun getTracksByArtist(artistName: String): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE albumName = :albumName ORDER BY title ASC")
    fun getTracksByAlbum(albumName: String): Flow<List<TrackEntity>>

    @Query("""
        SELECT * FROM tracks 
        WHERE title LIKE '%' || :query || '%' 
        OR artistName LIKE '%' || :query || '%' 
        OR albumName LIKE '%' || :query || '%' 
        OR genre LIKE '%' || :query || '%'
    """)
    fun searchTracks(query: String): Flow<List<TrackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<TrackEntity>)

    @Update
    suspend fun updateTrack(track: TrackEntity)

    @Delete
    suspend fun deleteTrack(track: TrackEntity)

    @Query("DELETE FROM tracks")
    suspend fun clearAllTracks()


    // --- PLAYLISTS ---
    @Query("SELECT * FROM playlists ORDER BY name ASC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :playlistId LIMIT 1")
    suspend fun getPlaylistById(playlistId: Long): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)


    // --- PLAYLIST ITEMS ---
    @Query("""
        SELECT t.* FROM tracks t 
        INNER JOIN playlist_items pi ON t.id = pi.trackId 
        WHERE pi.playlistId = :playlistId 
        ORDER BY pi.orderIndex ASC
    """)
    fun getTracksForPlaylist(playlistId: Long): Flow<List<TrackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun clearPlaylistItems(playlistId: Long)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId AND trackId = :trackId")
    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: String)


    // --- HISTORY ---
    @Query("SELECT * FROM play_history ORDER BY playTimestamp DESC LIMIT :limit")
    fun getRecentlyPlayed(limit: Int): Flow<List<PlayHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: PlayHistoryEntity)


    // --- SOCIAL PROFILES ---
    @Query("SELECT * FROM social_profiles ORDER BY name ASC")
    fun getAllSocialProfiles(): Flow<List<SocialProfileEntity>>

    @Query("SELECT * FROM social_profiles WHERE userId = :userId LIMIT 1")
    fun getProfileById(userId: String): Flow<SocialProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: SocialProfileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<SocialProfileEntity>)


    // --- SOCIAL FEED / POSTS ---
    @Query("SELECT * FROM social_posts ORDER BY timestamp DESC")
    fun getAllSocialPosts(): Flow<List<SocialPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: SocialPostEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<SocialPostEntity>)

    @Update
    suspend fun updatePost(post: SocialPostEntity)


    // --- GRAPHENE CATALOGUE ---
    @Query("SELECT * FROM graphene_catalogue ORDER BY title ASC")
    fun getGrapheneCatalogue(): Flow<List<GrapheneCatalogueEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrapheneCatalogue(items: List<GrapheneCatalogueEntity>)

    @Update
    suspend fun updateGrapheneCatalogue(item: GrapheneCatalogueEntity)
}
