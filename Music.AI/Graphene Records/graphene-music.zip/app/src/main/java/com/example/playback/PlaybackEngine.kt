package com.example.playback

import android.util.Log
import com.example.data.model.TrackEntity
import com.example.data.repository.MusicRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class RepeatMode {
    OFF, ONE, ALL
}

class PlaybackEngine(
    private val repository: MusicRepository,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentTrack = MutableStateFlow<TrackEntity?>(null)
    val currentTrack: StateFlow<TrackEntity?> = _currentTrack.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _queue = MutableStateFlow<List<TrackEntity>>(emptyList())
    val queue: StateFlow<List<TrackEntity>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(-1)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.OFF)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _shuffleMode = MutableStateFlow(false)
    val shuffleMode: StateFlow<Boolean> = _shuffleMode.asStateFlow()

    private var playbackJob: Job? = null
    private var originalQueue: List<TrackEntity> = emptyList() // For toggling shuffle

    init {
        startPlaybackTicker()
    }

    private fun startPlaybackTicker() {
        playbackJob?.cancel()
        playbackJob = scope.launch {
            while (isActive) {
                if (_isPlaying.value && _currentTrack.value != null) {
                    val currentPos = _positionMs.value
                    val trackDuration = _durationMs.value
                    
                    if (currentPos >= trackDuration) {
                        // Track completed!
                        onTrackCompleted()
                    } else {
                        _positionMs.value = (currentPos + 200).coerceAtMost(trackDuration)
                    }
                }
                delay(200)
            }
        }
    }

    private suspend fun onTrackCompleted() {
        val track = _currentTrack.value ?: return
        
        // 1. Log play history
        repository.logPlayHistory(
            trackId = track.id,
            durationMs = track.durationMs,
            percentage = 100,
            wasSkipped = false
        )

        // 2. Advance queue based on repeat rules
        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                seekTo(0) // Restart track
            }
            RepeatMode.ALL, RepeatMode.OFF -> {
                if (hasNext()) {
                    next()
                } else if (_repeatMode.value == RepeatMode.ALL && _queue.value.isNotEmpty()) {
                    // Loop back to beginning
                    playAtIndex(0)
                } else {
                    _isPlaying.value = false
                    seekTo(0)
                }
            }
        }
    }

    fun playTrack(track: TrackEntity, playlistContext: List<TrackEntity>? = null) {
        scope.launch {
            if (playlistContext != null) {
                originalQueue = playlistContext
                _queue.value = if (_shuffleMode.value) playlistContext.shuffled() else playlistContext
                val idx = _queue.value.indexOfFirst { it.id == track.id }
                _currentIndex.value = if (idx != -1) idx else 0
            } else {
                // Single track playback or fallback
                originalQueue = listOf(track)
                _queue.value = listOf(track)
                _currentIndex.value = 0
            }

            _currentTrack.value = track
            _durationMs.value = track.durationMs
            _positionMs.value = 0L
            _isPlaying.value = true
            Log.d("PlaybackEngine", "Playing track: ${track.title} by ${track.artistName}")
        }
    }

    fun togglePlayPause() {
        if (_currentTrack.value == null && _queue.value.isNotEmpty()) {
            playAtIndex(0)
            return
        }
        _isPlaying.value = !_isPlaying.value
        Log.d("PlaybackEngine", "Playback toggled to: isPlaying = ${_isPlaying.value}")
    }

    fun seekTo(positionMs: Long) {
        _positionMs.value = positionMs.coerceIn(0L, _durationMs.value)
    }

    fun hasNext(): Boolean {
        val nextIdx = _currentIndex.value + 1
        return nextIdx in _queue.value.indices
    }

    fun hasPrevious(): Boolean {
        val prevIdx = _currentIndex.value - 1
        return prevIdx in _queue.value.indices
    }

    fun next() {
        scope.launch {
            val nextIdx = _currentIndex.value + 1
            if (nextIdx in _queue.value.indices) {
                // Log skip history if track was skipped before 30% completion
                val currentTrack = _currentTrack.value
                if (currentTrack != null && _positionMs.value < _durationMs.value * 0.3) {
                    repository.logPlayHistory(
                        trackId = currentTrack.id,
                        durationMs = _positionMs.value,
                        percentage = ((_positionMs.value.toFloat() / _durationMs.value) * 100).toInt(),
                        wasSkipped = true
                    )
                }
                playAtIndex(nextIdx)
            } else if (_repeatMode.value == RepeatMode.ALL && _queue.value.isNotEmpty()) {
                playAtIndex(0)
            }
        }
    }

    fun previous() {
        scope.launch {
            if (_positionMs.value > 3000L) {
                // Restart current track if played > 3s
                seekTo(0)
            } else {
                val prevIdx = _currentIndex.value - 1
                if (prevIdx in _queue.value.indices) {
                    playAtIndex(prevIdx)
                } else if (_queue.value.isNotEmpty()) {
                    // Loop back to end of queue if repeat all is active
                    if (_repeatMode.value == RepeatMode.ALL) {
                        playAtIndex(_queue.value.lastIndex)
                    } else {
                        seekTo(0)
                    }
                }
            }
        }
    }

    private fun playAtIndex(index: Int) {
        if (index in _queue.value.indices) {
            _currentIndex.value = index
            val track = _queue.value[index]
            _currentTrack.value = track
            _durationMs.value = track.durationMs
            _positionMs.value = 0L
            _isPlaying.value = true
        }
    }

    fun addToQueue(track: TrackEntity) {
        val currentList = _queue.value.toMutableList()
        currentList.add(track)
        _queue.value = currentList
    }

    fun playNextInQueue(track: TrackEntity) {
        val currentList = _queue.value.toMutableList()
        val insertPos = _currentIndex.value + 1
        if (insertPos <= currentList.size) {
            currentList.add(insertPos, track)
        } else {
            currentList.add(track)
        }
        _queue.value = currentList
    }

    fun removeFromQueue(trackId: String) {
        val currentList = _queue.value.toMutableList()
        val removeIndex = currentList.indexOfFirst { it.id == trackId }
        if (removeIndex != -1) {
            currentList.removeAt(removeIndex)
            if (removeIndex == _currentIndex.value) {
                // We removed the active track, play next
                if (currentList.isNotEmpty()) {
                    _queue.value = currentList
                    val nextIdx = removeIndex.coerceAtMost(currentList.lastIndex)
                    playAtIndex(nextIdx)
                } else {
                    _queue.value = emptyList()
                    _currentIndex.value = -1
                    _currentTrack.value = null
                    _isPlaying.value = false
                }
            } else {
                if (removeIndex < _currentIndex.value) {
                    _currentIndex.value = _currentIndex.value - 1
                }
                _queue.value = currentList
            }
        }
    }

    fun setShuffle(enabled: Boolean) {
        _shuffleMode.value = enabled
        val activeTrack = _currentTrack.value
        if (enabled) {
            val shuffled = originalQueue.shuffled().toMutableList()
            if (activeTrack != null) {
                // Ensure current playing track stays as first/current
                shuffled.remove(activeTrack)
                shuffled.add(0, activeTrack)
            }
            _queue.value = shuffled
            _currentIndex.value = if (activeTrack != null) 0 else -1
        } else {
            _queue.value = originalQueue
            _currentIndex.value = if (activeTrack != null) originalQueue.indexOf(activeTrack) else -1
        }
    }

    fun setRepeat(mode: RepeatMode) {
        _repeatMode.value = mode
    }

    fun clearQueue() {
        _queue.value = emptyList()
        _currentIndex.value = -1
        _currentTrack.value = null
        _isPlaying.value = false
        _positionMs.value = 0L
    }
}
