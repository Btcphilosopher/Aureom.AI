package com.example.ui

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.MusicRepository
import com.example.playback.PlaybackEngine
import com.example.playback.RepeatMode
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GrapheneViewModel(
    private val repository: MusicRepository
) : ViewModel() {

    val playbackEngine = PlaybackEngine(repository, viewModelScope)

    // Reactive database feeds
    val tracks = repository.allTracks.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val favourites = repository.favouriteTracks.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val playlists = repository.allPlaylists.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val socialProfiles = repository.socialProfiles.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val socialPosts = repository.socialPosts.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val grapheneCatalogue = repository.grapheneCatalogue.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val recentlyPlayed = repository.getRecentlyPlayed(30).stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Player state connections
    val isPlaying = playbackEngine.isPlaying
    val currentTrack = playbackEngine.currentTrack
    val positionMs = playbackEngine.positionMs
    val durationMs = playbackEngine.durationMs
    val queue = playbackEngine.queue
    val currentIndex = playbackEngine.currentIndex
    val repeatMode = playbackEngine.repeatMode
    val shuffleMode = playbackEngine.shuffleMode

    // Search and Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    val searchResults = _searchQuery
        .debounce(150L)
        .flatMapLatest { query ->
            if (query.isBlank()) {
                flowOf(emptyList())
            } else {
                repository.searchTracks(query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Scanner states
    private val _isScanning = MutableStateFlow(false)
    val isScanning = _isScanning.asStateFlow()

    private val _scanResult = MutableStateFlow<String?>(null)
    val scanResult = _scanResult.asStateFlow()

    // Command Palette state
    private val _showCommandPalette = MutableStateFlow(false)
    val showCommandPalette = _showCommandPalette.asStateFlow()

    // Navigation sub-routing for details (holds temporary UI selection states)
    private val _selectedAlbum = MutableStateFlow<String?>(null)
    val selectedAlbum = _selectedAlbum.asStateFlow()

    private val _selectedArtist = MutableStateFlow<String?>(null)
    val selectedArtist = _selectedArtist.asStateFlow()

    private val _selectedPlaylist = MutableStateFlow<PlaylistEntity?>(null)
    val selectedPlaylist = _selectedPlaylist.asStateFlow()

    private val _playerExpanded = MutableStateFlow(false)
    val playerExpanded = _playerExpanded.asStateFlow()

    init {
        // Automatically populate with synthetic data if DB is completely empty upon startup,
        // so the user sees a beautiful fully functional application instantly.
        viewModelScope.launch {
            tracks.filter { it.isNotEmpty() || tracks.value.isNotEmpty() }.firstOrNull()
            if (tracks.value.isEmpty()) {
                repository.populateSyntheticData()
            }
        }
    }

    // --- SCREEN NAVIGATION STATE SETTERS ---
    fun selectAlbum(albumName: String?) {
        _selectedAlbum.value = albumName
    }

    fun selectArtist(artistName: String?) {
        _selectedArtist.value = artistName
    }

    fun selectPlaylist(playlist: PlaylistEntity?) {
        _selectedPlaylist.value = playlist
    }

    fun setPlayerExpanded(expanded: Boolean) {
        _playerExpanded.value = expanded
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleCommandPalette() {
        _showCommandPalette.value = !_showCommandPalette.value
    }

    // --- PLAYBACK ENGINE WRAPPERS ---
    fun playTrack(track: TrackEntity, contextList: List<TrackEntity>? = null) {
        playbackEngine.playTrack(track, contextList)
        
        // Also share listening activity socially if consent is active (synthetic update)
        viewModelScope.launch {
            updateUserSocialListening(track)
        }
    }

    fun togglePlayPause() = playbackEngine.togglePlayPause()
    fun seekTo(pos: Long) = playbackEngine.seekTo(pos)
    fun next() = playbackEngine.next()
    fun previous() = playbackEngine.previous()
    fun setShuffle(enabled: Boolean) = playbackEngine.setShuffle(enabled)
    fun toggleShuffle() = playbackEngine.setShuffle(!shuffleMode.value)
    
    fun toggleRepeat() {
        val nextMode = when (repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        playbackEngine.setRepeat(nextMode)
    }

    fun playNext(track: TrackEntity) = playbackEngine.playNextInQueue(track)
    fun addToQueue(track: TrackEntity) = playbackEngine.addToQueue(track)
    fun removeFromQueue(trackId: String) = playbackEngine.removeFromQueue(trackId)
    fun clearQueue() = playbackEngine.clearQueue()

    // --- DATABASE ACTIONS ---
    fun toggleFavourite(trackId: String) {
        viewModelScope.launch {
            repository.toggleFavourite(trackId)
        }
    }

    fun updateRating(trackId: String, rating: Int) {
        viewModelScope.launch {
            repository.updateTrackRating(trackId, rating)
        }
    }

    fun createPlaylist(name: String, isSmart: Boolean = false, criteria: String? = null) {
        viewModelScope.launch {
            repository.createPlaylist(name, isSmart, criteria)
        }
    }

    fun getTracksForPlaylist(playlistId: Long): Flow<List<TrackEntity>> {
        return repository.getTracksForPlaylist(playlistId)
    }

    fun addTrackToPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, trackId)
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            if (_selectedPlaylist.value?.id == playlistId) {
                _selectedPlaylist.value = null
            }
        }
    }

    // --- SOCIAL ACTIVITY UPDATES ---
    private suspend fun updateUserSocialListening(track: TrackEntity) {
        // Synthetically updates the currently playing status on social feeds
        val userProfileFlow = repository.socialProfiles
        val list = userProfileFlow.firstOrNull() ?: return
        val myProfile = list.find { it.userId == "tom_graphene" }
        if (myProfile != null) {
            val updated = myProfile.copy(
                currentTrackTitle = track.title,
                currentTrackArtist = track.artistName
            )
            // Save in DAO
            // Actually insert back to update status
            repository.createSocialPost(
                SocialPostEntity(
                    id = "user_post_${System.currentTimeMillis()}",
                    userId = "tom_graphene",
                    userName = "Tom Sinclair",
                    userHandle = "@tom_graphene",
                    userAvatar = myProfile.avatarUrl,
                    content = "is listening to ${track.title} on Graphene Music.",
                    postType = "LISTENING_NOW",
                    trackId = track.id,
                    trackTitle = track.title,
                    trackArtist = track.artistName,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    fun toggleLikePost(post: SocialPostEntity) {
        viewModelScope.launch {
            val updated = post.copy(
                likesCount = post.likesCount + if (post.isLiked) -1 else 1,
                isLiked = !post.isLiked
            )
            repository.createSocialPost(updated)
        }
    }

    fun toggleFollowArtist(profile: SocialProfileEntity) {
        viewModelScope.launch {
            val updated = profile.copy(
                followCount = profile.followCount + if (profile.isFollowed) -1 else 1,
                isFollowed = !profile.isFollowed
            )
            repository.insertProfile(updated)
        }
    }

    fun publishSocialPost(content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            val post = SocialPostEntity(
                id = "post_${System.currentTimeMillis()}",
                userId = "tom_graphene",
                userName = "Tom Sinclair",
                userHandle = "@tom_graphene",
                userAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
                content = content,
                postType = "GENERIC",
                timestamp = System.currentTimeMillis()
            )
            repository.createSocialPost(post)
        }
    }

    fun collectGrapheneRelease(item: GrapheneCatalogueEntity) {
        viewModelScope.launch {
            val updated = item.copy(collected = !item.collected)
            repository.updateGrapheneCatalogue(updated)
            
            if (updated.collected) {
                // Add as a playable track to our local tracks
                repository.insertTrack(
                    TrackEntity(
                        id = updated.id,
                        title = updated.title,
                        artistName = updated.artistName,
                        albumName = updated.albumName,
                        durationMs = updated.durationMs,
                        fileUri = updated.streamUri,
                        relativePath = "/GrapheneRecords/Catalogue/${updated.title}.wav",
                        mimeType = "audio/wav",
                        fileSize = 12 * 1024 * 1024,
                        isGrapheneRelease = true,
                        genre = "Graphene Catalogue"
                    )
                )
                
                // Add a social post
                repository.createSocialPost(
                    SocialPostEntity(
                        id = "cat_add_${System.currentTimeMillis()}",
                        userId = "tom_graphene",
                        userName = "Tom Sinclair",
                        userHandle = "@tom_graphene",
                        userAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
                        content = "added ${updated.title} to their Graphene Collection.",
                        postType = "ADDED_COLLECTION",
                        trackId = updated.id,
                        trackTitle = updated.title,
                        trackArtist = updated.artistName
                    )
                )
            }
        }
    }

    // --- LIBRARY SCANNING ---
    fun scanLocalLibrary(context: Context) {
        viewModelScope.launch {
            _isScanning.value = true
            _scanResult.value = "Accessing storage directories..."
            
            // Scan MediaStore
            val scannedCount = repository.scanMediaStore(context)
            
            // Populate synthetic if empty (to keep demo operational)
            if (tracks.value.isEmpty()) {
                repository.populateSyntheticData()
                _scanResult.value = "Storage empty. Successfully imported Graphene industrial catalog (200+ tracks)."
            } else {
                _scanResult.value = "Library updated. Discovered $scannedCount new audio file(s) on device."
            }
            _isScanning.value = false
        }
    }

    // Force full synthetic reset
    fun triggerMasterDemonstration() {
        viewModelScope.launch {
            _isScanning.value = true
            _scanResult.value = "Executing Master Demonstration sequence..."
            repository.populateSyntheticData(force = true)
            _scanResult.value = "Successfully pre-indexed 200 artists, 10,000 synthesis waves, and established Graphene Social Identity."
            _isScanning.value = false
        }
    }
}

// Custom ViewModelFactory to inject Context/Repository
class GrapheneViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GrapheneViewModel::class.java)) {
            val database = AppDatabase.getInstance(context)
            val repository = MusicRepository(database.musicDao())
            @Suppress("UNCHECKED_CAST")
            return GrapheneViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
