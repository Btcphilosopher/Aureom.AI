package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: GrapheneViewModel
) {
    val context = LocalContext.current
    val tracks by viewModel.tracks.collectAsState()
    val favourites by viewModel.favourites.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val scanResult by viewModel.scanResult.collectAsState()

    var sampleRateOption by remember { mutableStateOf("96.0 kHz") }
    var bitDepthOption by remember { mutableStateOf("24-bit PCM") }
    var priorityThread by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Settings Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "ENGINE DIAGNOSTICS",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "STORAGE INDEXING, DECODERS & PRIVACY CONTROLS",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneMuted
                )
            }
        }

        Divider(color = GrapheneDarkGray, thickness = 1.dp)

        // LIBRARY METRIC OVERVIEW
        HomeSectionHeader(title = "LOCAL METRICS SCHEMA")
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, GrapheneDarkGray)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                MetricRow(label = "CATALOGUED WAVEFORMS:", value = "${tracks.size} tracks")
                MetricRow(label = "FAVOURITES ARCHIVE:", value = "${favourites.size} tracks")
                MetricRow(label = "PLAYLIST DICTIONARIES:", value = "${playlists.size} lists")
                MetricRow(label = "STORAGE DEPLOYMENT:", value = "Offline-First")
            }
        }

        // DATABASE RE-SCANNING ACTIONS
        HomeSectionHeader(title = "DATABASE SCANNING ENGINE")
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, MaterialTheme.colorScheme.primary)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "Graphene scanner indexes native MediaStore storage folders recursively. If no local music is resolved, standard synthesis testwaves will be initialized.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = GrapheneSilver
                )
                Spacer(modifier = Modifier.height(12.dp))

                if (isScanning) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                scanResult?.let { res ->
                    Text(
                        text = "SCAN_LOG: $res",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.scanLocalLibrary(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("rescan_storage_button"),
                        enabled = !isScanning
                    ) {
                        Text("SCAN STORAGE", color = GrapheneBlack, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerMasterDemonstration() },
                        colors = ButtonDefaults.buttonColors(containerColor = GrapheneDarkGray),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("master_demo_button"),
                        enabled = !isScanning
                    ) {
                        Text("MASTER RESET", color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // DECODER SPECIFICATIONS (Professional Settings)
        HomeSectionHeader(title = "DECODER RESOLUTION CONTEXT")
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, GrapheneDarkGray)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text("DAC OUTPUT SAMPLE RESOLUTION:", style = MaterialTheme.typography.labelSmall, color = GrapheneMuted)
                val sampleRates = listOf("44.1 kHz (CD Standard)", "96.0 kHz (Studio Standard)", "192.0 kHz (Extreme Resolution)")
                sampleRates.forEach { rate ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { sampleRateOption = rate }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = sampleRateOption == rate,
                            onClick = { sampleRateOption = rate },
                            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                        )
                        Text(text = rate, style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("PCM BIT DEPTH SPECIFICATION:", style = MaterialTheme.typography.labelSmall, color = GrapheneMuted)
                val bitDepths = listOf("16-bit PCM Integer", "24-bit PCM Master", "32-bit Float Processing")
                bitDepths.forEach { depth ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { bitDepthOption = depth }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = bitDepthOption == depth,
                            onClick = { bitDepthOption = depth },
                            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.secondary)
                        )
                        Text(text = depth, style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("HIGH PRIORITY AUDIO THREAD", style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp), color = GrapheneOffWhite)
                        Text("Locks audio stream decoders in isolated CPU cores to bypass UI latency jitter.", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                    }
                    Switch(
                        checked = priorityThread,
                        onCheckedChange = { priorityThread = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }

        // ABOUT & LEGAL
        HomeSectionHeader(title = "GRAPHENE RECORD SYSTEM")
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .border(1.dp, GrapheneDarkGray)
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Column {
                Text(text = "GRAPHENE MUSIC OPERATING SYSTEM", style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                Text(text = "Software Version: 1.0.0 (Build 2026-09-13)", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                Text(text = "License: Graphene Records Archival License 4.0", style = MaterialTheme.typography.bodyMedium, color = GrapheneMuted)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Designed and engineered as a serious personal music hub for physical local media collections. No tracking, no metadata scraping, no advertisements. Just your music, your device, your local listening life.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = GrapheneSilver
                )
            }
        }
    }
}

@Composable
fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = GrapheneSilver)
        Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary))
    }
}
