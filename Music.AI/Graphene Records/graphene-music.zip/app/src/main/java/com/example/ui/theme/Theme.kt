package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GrapheneColorScheme = darkColorScheme(
    primary = GrapheneAcidGreen,
    onPrimary = GrapheneBlack,
    secondary = GrapheneElectricBlue,
    onSecondary = GrapheneBlack,
    tertiary = GrapheneFuchsia,
    onTertiary = GrapheneOffWhite,
    background = GrapheneBlack,
    onBackground = GrapheneSilver,
    surface = GrapheneGraphite,
    onSurface = GrapheneOffWhite,
    surfaceVariant = GrapheneDarkGray,
    onSurfaceVariant = GrapheneMuted,
    outline = GrapheneDarkGray
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // We enforce our industrial dark theme absolutely as specified in Graphene Records design rules
    MaterialTheme(
        colorScheme = GrapheneColorScheme,
        typography = Typography,
        content = content
    )
}
