package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.TrackEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun NowPlayingBar(
    viewModel: GrapheneViewModel,
    modifier: Modifier = Modifier
) {
    val currentTrack by viewModel.currentTrack.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val position by viewModel.positionMs.collectAsState()
    val duration by viewModel.durationMs.collectAsState()

    if (currentTrack == null) return

    val progress = if (duration > 0) position.toFloat() / duration else 0f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(2.dp))
            .background(GrapheneGraphite)
            .clickable { viewModel.setPlayerExpanded(true) }
            .testTag("mini_player_bar")
    ) {
        // Asymmetric Progress Line underneath the bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(progress)
                .height(2.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.secondary
                        )
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Mini Album Art
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .border(1.dp, GrapheneDarkGray)
                    .background(GrapheneBlack)
            ) {
                if (currentTrack?.id?.startsWith("synth") == true || currentTrack?.id?.startsWith("graphene") == true) {
                    // Generate geometric artwork dynamically or fetch Unsplash fallback
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(GrapheneDarkGray, GrapheneBlack)
                                )
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(24.dp)
                                .align(Alignment.Center)
                        )
                    }
                } else {
                    AsyncImage(
                        model = "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=80&q=80",
                        contentDescription = "Cover",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Metadata info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = currentTrack?.title ?: "Unknown Track",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = GrapheneOffWhite
                    ),
                    maxLines = 1
                )
                Text(
                    text = currentTrack?.artistName ?: "Unknown Artist",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.primary
                    ),
                    maxLines = 1
                )
            }

            // Quick Waveform Feedback
            WaveformVisualizer(
                isPlaying = isPlaying,
                modifier = Modifier
                    .width(48.dp)
                    .height(28.dp)
                    .padding(horizontal = 4.dp)
            )

            // Play/Pause Control
            IconButton(
                onClick = { viewModel.togglePlayPause() },
                modifier = Modifier.testTag("mini_play_pause_button")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = GrapheneOffWhite
                )
            }

            // Next Control
            IconButton(
                onClick = { viewModel.next() },
                modifier = Modifier.testTag("mini_next_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Next",
                    tint = GrapheneOffWhite
                )
            }
        }
    }
}

@Composable
fun WaveformVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 10,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val barHeights = remember { mutableStateListOf<Float>().apply { addAll(List(barCount) { 0.2f }) } }

    if (isPlaying) {
        LaunchedEffect(Unit) {
            while (true) {
                for (i in 0 until barCount) {
                    barHeights[i] = Random.nextFloat().coerceIn(0.15f, 0.95f)
                }
                delay(120)
            }
        }
    } else {
        LaunchedEffect(Unit) {
            // Animate gently to rest
            for (i in 0 until barCount) {
                barHeights[i] = 0.15f
            }
        }
    }

    Canvas(modifier = modifier) {
        val spacing = size.width / (barCount * 1.5f)
        val barWidth = size.width / (barCount * 2.5f)
        
        for (i in 0 until barCount) {
            val barHeight = size.height * barHeights[i]
            val x = (i * (barWidth + spacing)) + (barWidth / 2)
            val y = (size.height - barHeight) / 2
            
            drawRect(
                color = color,
                topLeft = androidx.compose.ui.geometry.Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
            )
        }
    }
}

@Composable
fun StarRatingBar(
    rating: Int,
    onRatingSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    starSize: Int = 16
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..5) {
            Icon(
                imageVector = if (i <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "$i Stars",
                tint = if (i <= rating) MaterialTheme.colorScheme.tertiary else GrapheneMuted,
                modifier = Modifier
                    .size(starSize.dp)
                    .clickable { onRatingSelected(i) }
                    .padding(horizontal = 2.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandPaletteDialog(
    viewModel: GrapheneViewModel,
    onDismiss: () -> Unit
) {
    var textQuery by remember { mutableStateOf("") }
    val context = LocalContext.current

    val allCommands = listOf(
        CommandAction("PLAY", "Toggle track playback state") { viewModel.togglePlayPause() },
        CommandAction("NEXT", "Advance to next queue track") { viewModel.next() },
        CommandAction("PREV", "Return to previous track") { viewModel.previous() },
        CommandAction("RESCAN", "Scan standard MediaStore directories") { viewModel.scanLocalLibrary(context) },
        CommandAction("DEMO", "Reset with Graphene Master Demonstration structures") { viewModel.triggerMasterDemonstration() },
        CommandAction("CLEAR QUEUE", "Clear active music playback queue") { viewModel.clearQueue() },
        CommandAction("SHUFFLE", "Toggle shuffle playback state") { viewModel.toggleShuffle() },
        CommandAction("REPEAT", "Toggle loop playback mode") { viewModel.toggleRepeat() },
        CommandAction("SETTINGS", "Configure audio formats & diagnostics") { /* handled by route changes or visual indicator */ }
    )

    val filteredCommands = allCommands.filter {
        it.command.contains(textQuery, ignoreCase = true) || it.description.contains(textQuery, ignoreCase = true)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp)),
            color = GrapheneGraphite,
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxHeight(0.6f)
            ) {
                Text(
                    text = "GRAPHENE MUSIC TERMINAL_v1.0",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                OutlinedTextField(
                    value = textQuery,
                    onValueChange = { textQuery = it },
                    placeholder = { Text("ENTER COMMAND...", color = GrapheneMuted, fontFamily = FontFamily.Monospace) },
                    textStyle = MaterialTheme.typography.titleMedium.copy(color = GrapheneOffWhite, fontFamily = FontFamily.Monospace),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("command_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = GrapheneDarkGray
                    ),
                    trailingIcon = {
                        Icon(imageVector = Icons.Default.Search, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredCommands) { cmd ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    cmd.action()
                                    onDismiss()
                                }
                                .padding(vertical = 10.dp, horizontal = 6.dp)
                                .border(1.dp, Color.Transparent)
                                .background(GrapheneBlack),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "> ${cmd.command}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                modifier = Modifier.width(110.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = cmd.description,
                                style = MaterialTheme.typography.bodyMedium.copy(color = GrapheneSilver),
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }

                Text(
                    text = "ESC/TAP OUTSIDE TO ABORT",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrapheneMuted,
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(top = 8.dp)
                )
            }
        }
    }
}

data class CommandAction(
    val command: String,
    val description: String,
    val action: () -> Unit
)
