package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.ui.GrapheneViewModel
import com.example.ui.GrapheneViewModelFactory
import com.example.ui.components.CommandPaletteDialog
import com.example.ui.components.NowPlayingBar
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class GrapheneScreen {
    HOME, LIBRARY, PLAYLISTS, DISCOVER, SOCIAL, CATALOGUE
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create the core ViewModel injecting current context
        val factory = GrapheneViewModelFactory(applicationContext)
        val viewModel = ViewModelProvider(this, factory)[GrapheneViewModel::class.java]

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf(GrapheneScreen.HOME) }
                val showCommandPalette by viewModel.showCommandPalette.collectAsState()
                val playerExpanded by viewModel.playerExpanded.collectAsState()
                val currentTrack by viewModel.currentTrack.collectAsState()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(GrapheneBlack)
                ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = GrapheneBlack,
                        bottomBar = {
                            Column {
                                // Floating Now Playing mini-bar if music is loaded
                                if (currentTrack != null) {
                                    NowPlayingBar(
                                        viewModel = viewModel,
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                }

                                // High-contrast Industrial Navigation Bottom Bar
                                NavigationBottomBar(
                                    currentScreen = currentScreen,
                                    onScreenSelected = { screen ->
                                        currentScreen = screen
                                        // Reset deep-dive views upon tab switching for user comfort
                                        if (screen != GrapheneScreen.LIBRARY) {
                                            viewModel.selectAlbum(null)
                                            viewModel.selectArtist(null)
                                        }
                                        if (screen != GrapheneScreen.PLAYLISTS) {
                                            viewModel.selectPlaylist(null)
                                        }
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            // Render Active Screen based on tab choice
                            when (currentScreen) {
                                GrapheneScreen.HOME -> HomeScreen(
                                    viewModel = viewModel,
                                    onNavigateToLibrary = { currentScreen = GrapheneScreen.LIBRARY },
                                    onNavigateToPlaylists = { currentScreen = GrapheneScreen.PLAYLISTS },
                                    onNavigateToDiscover = { currentScreen = GrapheneScreen.DISCOVER },
                                    onNavigateToSocial = { currentScreen = GrapheneScreen.SOCIAL },
                                    onNavigateToCatalogue = { currentScreen = GrapheneScreen.CATALOGUE }
                                )
                                GrapheneScreen.LIBRARY -> LibraryScreen(viewModel = viewModel)
                                GrapheneScreen.PLAYLISTS -> PlaylistsScreen(viewModel = viewModel)
                                GrapheneScreen.DISCOVER -> DiscoverScreen(viewModel = viewModel)
                                GrapheneScreen.SOCIAL -> SocialScreen(viewModel = viewModel)
                                GrapheneScreen.CATALOGUE -> GrapheneCatalogueScreen(viewModel = viewModel)
                            }
                        }
                    }

                    // Slide-up full screen player overlay
                    AnimatedVisibility(
                        visible = playerExpanded,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        NowPlayingScreen(viewModel = viewModel)
                    }

                    // Command Terminal Dialogue popover overlay
                    if (showCommandPalette) {
                        CommandPaletteDialog(
                            viewModel = viewModel,
                            onDismiss = { viewModel.toggleCommandPalette() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NavigationBottomBar(
    currentScreen: GrapheneScreen,
    onScreenSelected: (GrapheneScreen) -> Unit
) {
    NavigationBar(
        containerColor = GrapheneGraphite,
        tonalElevation = 0.dp,
        modifier = Modifier
            .border(BorderStroke(1.dp, GrapheneDarkGray))
            .height(58.dp)
    ) {
        val navItems = listOf(
            NavigationItem(GrapheneScreen.HOME, Icons.Default.Home, "HOME"),
            NavigationItem(GrapheneScreen.LIBRARY, Icons.Default.Folder, "LIBRARY"),
            NavigationItem(GrapheneScreen.PLAYLISTS, Icons.Default.List, "LISTS"),
            NavigationItem(GrapheneScreen.DISCOVER, Icons.Default.Psychology, "DISCOVER"),
            NavigationItem(GrapheneScreen.SOCIAL, Icons.Default.Group, "COMMUNE"),
            NavigationItem(GrapheneScreen.CATALOGUE, Icons.Default.Album, "LABELS")
        )

        navItems.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenSelected(item.screen) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else GrapheneMuted,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else GrapheneMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}

data class NavigationItem(
    val screen: GrapheneScreen,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String
)
