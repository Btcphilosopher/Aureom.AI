package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artistName: String,
    val albumName: String,
    val durationMs: Long,
    val fileUri: String,
    val relativePath: String,
    val mimeType: String,
    val fileSize: Long,
    val rating: Int = 0, // 1 to 5 stars
    val isFavourite: Boolean = false,
    val playCount: Int = 0,
    val skipCount: Int = 0,
    val lastPlayed: Long = 0,
    val year: Int = 0,
    val genre: String = "Unknown",
    val lyrics: String? = null,
    val isGrapheneRelease: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isSmart: Boolean = false,
    val smartCriteria: String? = null, // JSON containing filters, e.g. "rating >= 4"
    val dateCreated: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val trackId: String,
    val orderIndex: Int
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: String,
    val trackTitle: String,
    val artistName: String,
    val playTimestamp: Long = System.currentTimeMillis(),
    val durationPlayedMs: Long,
    val completionPercentage: Int, // 0-100
    val wasSkipped: Boolean = false,
    val deviceName: String = "Android Device"
)

@Entity(tableName = "social_profiles")
data class SocialProfileEntity(
    @PrimaryKey val userId: String,
    val name: String,
    val handle: String,
    val bio: String,
    val avatarUrl: String,
    val currentTrackTitle: String? = null,
    val currentTrackArtist: String? = null,
    val isGrapheneArtist: Boolean = false,
    val followCount: Int = 0,
    val isFollowed: Boolean = false
)

@Entity(tableName = "social_posts")
data class SocialPostEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val userHandle: String,
    val userAvatar: String,
    val content: String,
    val postType: String, // "LISTENING_NOW", "ADDED_COLLECTION", "NEW_RELEASE", "GENERIC"
    val trackId: String? = null,
    val trackTitle: String? = null,
    val trackArtist: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    var likesCount: Int = 0,
    var isLiked: Boolean = false
)

@Entity(tableName = "graphene_catalogue")
data class GrapheneCatalogueEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artistName: String,
    val albumName: String,
    val durationMs: Long,
    val releaseYear: Int,
    val coverUrl: String,
    val description: String,
    val streamUri: String,
    val collected: Boolean = false
)
