package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SocialPostEntity
import com.example.data.model.SocialProfileEntity
import com.example.ui.GrapheneViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(
    viewModel: GrapheneViewModel
) {
    val profiles by viewModel.socialProfiles.collectAsState()
    val posts by viewModel.socialPosts.collectAsState()

    var showProfileEditor by remember { mutableStateOf(false) }
    var customBio by remember { mutableStateOf("Head of A&R at Graphene Records. Collecting electronic noise and modular synthesizers since 1998.") }
    var privacyConstraint by remember { mutableStateOf("Share recent listening") }
    
    var showComposer by remember { mutableStateOf(false) }
    var postContent by remember { mutableStateOf("") }

    val myProfile = profiles.find { it.userId == "tom_graphene" } ?: SocialProfileEntity(
        userId = "tom_graphene", name = "Tom Sinclair", handle = "@tom_graphene", bio = customBio, avatarUrl = ""
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack)
            .padding(bottom = 76.dp)
    ) {
        // Social Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneGraphite)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "GRAPHENE COMMUNE",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "MUSIC-SOCIAL IDENTITY & ACTIVITY LOG",
                        style = MaterialTheme.typography.labelSmall,
                        color = GrapheneMuted
                    )
                }

                Row {
                    IconButton(
                        onClick = { showComposer = true },
                        modifier = Modifier
                            .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
                            .background(GrapheneBlack)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, tint = MaterialTheme.colorScheme.primary, contentDescription = "Post")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { showProfileEditor = true },
                        modifier = Modifier
                            .border(1.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(2.dp))
                            .background(GrapheneBlack)
                    ) {
                        Icon(imageVector = Icons.Default.Settings, tint = MaterialTheme.colorScheme.secondary, contentDescription = "Edit Profile")
                    }
                }
            }
        }

        Divider(color = GrapheneDarkGray, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("social_feed_list")
        ) {
            // USER PROFILE SUMMARY
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(1.dp, MaterialTheme.colorScheme.primary)
                        .background(GrapheneGraphite)
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(GrapheneDarkGray)
                            ) {
                                Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp).align(Alignment.Center))
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(text = myProfile.name, style = MaterialTheme.typography.titleMedium, color = GrapheneOffWhite)
                                Text(text = myProfile.handle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = myProfile.bio, style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(text = "Privacy Status: $privacyConstraint", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }

            // FEED HEADER
            item {
                Text(
                    text = "REAL-TIME COMMUNITY FEED",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 12.dp)
                )
            }

            // FEED POSTS
            items(posts) { post ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .border(1.dp, GrapheneDarkGray)
                        .background(GrapheneGraphite)
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(GrapheneDarkGray)
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = GrapheneSilver, modifier = Modifier.size(20.dp).align(Alignment.Center))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = post.userName, style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp), color = GrapheneOffWhite)
                                Text(text = post.userHandle, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(text = post.content, style = MaterialTheme.typography.bodyLarge, color = GrapheneSilver)

                        // If post is related to a track
                        if (post.trackTitle != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f))
                                    .background(GrapheneBlack)
                                    .clickable {
                                        // Play track if we find it locally
                                        // viewModel.playTrack(...)
                                    }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = post.trackTitle ?: "", style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp), color = GrapheneOffWhite)
                                    Text(text = post.trackArtist ?: "", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = GrapheneMuted)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "OFFLINE SOURCE",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                                color = GrapheneMuted
                            )
                            Row(
                                modifier = Modifier.clickable { viewModel.toggleLikePost(post) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    tint = if (post.isLiked) MaterialTheme.colorScheme.tertiary else GrapheneMuted,
                                    contentDescription = "Like",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${post.likesCount}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (post.isLiked) MaterialTheme.colorScheme.tertiary else GrapheneMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Compose Custom Post Dialog
    if (showComposer) {
        AlertDialog(
            onDismissRequest = { showComposer = false },
            title = { Text("PUBLISH TO GRAPHENE FEED", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) },
            text = {
                OutlinedTextField(
                    value = postContent,
                    onValueChange = { postContent = it },
                    placeholder = { Text("WHAT ARE YOU LISTENING TO?", color = GrapheneMuted) },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = GrapheneOffWhite),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("post_composer_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = GrapheneDarkGray
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (postContent.isNotBlank()) {
                            viewModel.publishSocialPost(postContent)
                            postContent = ""
                            showComposer = false
                        }
                    },
                    modifier = Modifier.testTag("publish_post_button")
                ) {
                    Text("TRANSMIT", color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showComposer = false }) {
                    Text("ABORT", color = GrapheneMuted)
                }
            },
            containerColor = GrapheneGraphite,
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
        )
    }

    // Profile Settings Dialog
    if (showProfileEditor) {
        AlertDialog(
            onDismissRequest = { showProfileEditor = false },
            title = { Text("CONFIGURE SOCIAL METRICS", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary) },
            text = {
                Column {
                    Text("BIOGRAPHICAL SUMMARY:", style = MaterialTheme.typography.labelSmall, color = GrapheneMuted)
                    OutlinedTextField(
                        value = customBio,
                        onValueChange = { customBio = it },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = GrapheneOffWhite),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.secondary,
                            unfocusedBorderColor = GrapheneDarkGray
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("LISTENING PRIVACY CONTROL:", style = MaterialTheme.typography.labelSmall, color = GrapheneMuted)
                    val privacyOptions = listOf("Do not share listening activity", "Share currently playing only", "Share recent listening")
                    privacyOptions.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { privacyConstraint = opt }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = privacyConstraint == opt,
                                onClick = { privacyConstraint = opt },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.secondary)
                            )
                            Text(text = opt, style = MaterialTheme.typography.bodyMedium, color = GrapheneSilver)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        // Updates localized mock parameters immediately
                        showProfileEditor = false
                    }
                ) {
                    Text("APPLY", color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = GrapheneGraphite,
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(2.dp))
        )
    }
}
