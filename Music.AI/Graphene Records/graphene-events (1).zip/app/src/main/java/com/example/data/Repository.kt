package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class GrapheneRepository(private val dao: GrapheneDao) {

    val allArtists: Flow<List<ArtistEntity>> = dao.getAllArtists()
    val allVenues: Flow<List<VenueEntity>> = dao.getAllVenues()
    val allEvents: Flow<List<EventEntity>> = dao.getAllEvents()
    val allTickets: Flow<List<TicketEntity>> = dao.getAllTickets()

    suspend fun getEventById(eventId: Long): EventEntity? = dao.getEventById(eventId)
    suspend fun getEventBySlug(slug: String): EventEntity? = dao.getEventBySlug(slug)
    suspend fun getArtistById(artistId: Long): ArtistEntity? = dao.getArtistById(artistId)
    suspend fun getVenueById(venueId: Long): VenueEntity? = dao.getVenueById(venueId)

    fun getTicketTypesForEvent(eventId: Long): Flow<List<TicketTypeEntity>> = dao.getTicketTypesForEvent(eventId)
    suspend fun getTicketTypeById(ticketTypeId: Long): TicketTypeEntity? = dao.getTicketTypeById(ticketTypeId)
    fun getGuestListForEvent(eventId: Long): Flow<List<GuestListEntryEntity>> = dao.getGuestListForEvent(eventId)
    fun getIncidentsForEvent(eventId: Long): Flow<List<IncidentEntity>> = dao.getIncidentsForEvent(eventId)

    suspend fun insertTicket(ticket: TicketEntity) = dao.insertTicket(ticket)
    suspend fun updateTicketStatus(ticketId: String, status: String) = dao.updateTicketStatus(ticketId, status)
    suspend fun updateEventStatus(eventId: Long, status: String) = dao.updateEventStatus(eventId, status)
    suspend fun updateEventAttendance(eventId: Long, attendance: Int) = dao.updateEventAttendance(eventId, attendance)
    suspend fun updateEventTimetable(eventId: Long, timetable: String) = dao.updateEventTimetable(eventId, timetable)
    suspend fun updateFollowStatus(artistId: Long, isFollowed: Boolean) = dao.updateFollowStatus(artistId, isFollowed)
    suspend fun updateTicketTypeSold(ticketTypeId: Long, sold: Int) = dao.updateTicketTypeSold(ticketTypeId, sold)

    suspend fun insertGuestListEntry(entry: GuestListEntryEntity) = dao.insertGuestListEntry(entry)
    suspend fun updateGuestStatus(entryId: Long, status: String) = dao.updateGuestStatus(entryId, status)

    suspend fun insertIncident(incident: IncidentEntity) = dao.insertIncident(incident)
    suspend fun updateIncidentStatus(incidentId: Long, status: String) = dao.updateIncidentStatus(incidentId, status)

    suspend fun getMemoryForEvent(eventId: Long): EventMemoryEntity? = dao.getMemoryForEvent(eventId)
    suspend fun insertMemory(memory: EventMemoryEntity) = dao.insertMemory(memory)

    // Pre-populate high-fidelity synthetic seed data
    suspend fun seedDatabaseIfNeeded() {
        val existingEvents = allEvents.firstOrNull()
        if (!existingEvents.isNullOrEmpty()) {
            return // Database already has data
        }

        // Seed Artists
        val artists = listOf(
            ArtistEntity(101, "DJ KRYPTON", "A pioneer of the deep Berlin techno revival, known for marathon 10-hour vinyl sets in concrete vaults.", "Techno", 4200, false),
            ArtistEntity(102, "SINE WAVE PROJECT", "Live modular synthesis explorer focusing on spatial acoustics, sub-bass anomalies, and visual frequency synthesis.", "Experimental / Live Modular", 1950, true),
            ArtistEntity(103, "VOLT_AGE", "UK-born garage and breakbeat innovator blending nostalgic warehouse riddims with futuristic sub-basses.", "UK Garage / Breaks", 3100, false),
            ArtistEntity(104, "LYRA", "Ethereal ambient drone and darkwave artist, utilizing heavy tape-delay vocal layers and modular organs.", "Darkwave / Ambient", 850, false),
            ArtistEntity(105, "ACID FLUX", "Acid house fanatic hailing from Manchester, pushing vintage 303 hardware to its absolute limit.", "Acid House", 2800, false),
            ArtistEntity(106, "ECHO LABS", "Legendary production duo specializing in sub-heavy dub techno and industrial noise-scapes.", "Dub Techno", 1500, false)
        )
        dao.insertArtists(artists)

        // Seed Venues
        val venues = listOf(
            VenueEntity(
                venueId = 201,
                name = "THE VORTEX WAREHOUSE",
                city = "London",
                area = "Hackney Wick",
                capacity = 850,
                coordinates = "51.5430, -0.0210",
                addressVisibility = "AREA_ONLY",
                exactAddress = "Unit 12B, Marshgate Lane, London E15 2NH",
                accessibility = "Step-free street access, accessible toilets located in main lobby.",
                transport = "Overground: Hackney Wick (5 min walk). Buses: 276, 339.",
                rooms = "Main Chamber, The Boiler Room, Chill Out Vault"
            ),
            VenueEntity(
                venueId = 202,
                name = "SUBTERRANEAN BASEMENT",
                city = "London",
                area = "Soho",
                capacity = 150,
                coordinates = "51.5130, -0.1300",
                addressVisibility = "PUBLIC",
                exactAddress = "14B Greek Street, London W1D 4DJ",
                accessibility = "Narrow steep staircase entry, non-step-free access.",
                transport = "Underground: Tottenham Court Road (3 min walk), Leicester Square (5 min walk).",
                rooms = "Basement Vault, Side Alley Bar"
            ),
            VenueEntity(
                venueId = 203,
                name = "THE OUTPOST",
                city = "Manchester",
                area = "Ancoats",
                capacity = 500,
                coordinates = "53.4830, -2.2280",
                addressVisibility = "PUBLIC",
                exactAddress = "Red Bank, Ancoats, Manchester M4 4HF",
                accessibility = "Fully accessible ground floor, power-assisted entrance door.",
                transport = "Tram: Victoria Station (10 min walk). Bus: 201, 202.",
                rooms = "The Engine Room, Courtyard"
            ),
            VenueEntity(
                venueId = 204,
                name = "SECRET INDUSTRIAL ARCH",
                city = "London",
                area = "Bermondsey",
                capacity = 100,
                coordinates = "51.4980, -0.0680",
                addressVisibility = "SECRET",
                exactAddress = "Arch 402, Druid Street, London SE1 2QA",
                accessibility = "Flat entrance, compact interior.",
                transport = "Tube: Bermondsey (8 min walk). London Bridge (15 min walk).",
                rooms = "Archway, Rooftop Deck"
            )
        )
        dao.insertVenues(venues)

        // Seed Events
        val now = System.currentTimeMillis()
        val oneHour = 3600_000L
        val oneDay = 24 * oneHour

        val events = listOf(
            EventEntity(
                eventId = 1,
                slug = "graphene-after-dark",
                title = "GRAPHENE AFTER DARK",
                subtitle = "WAREHOUSE SESSION 01",
                description = "Graphene Records kicks off a new chapter of late-night warehouse exploration. Expect uncompromising acid house, heavy breaks, and deep modular experiments in Hackney's premium concrete vault. High-intensity lighting, sound by Void Acoustics.",
                eventType = "WAREHOUSE",
                status = "ON_SALE",
                visibility = "PUBLIC",
                promoterId = 501,
                venueId = 201, // Vortex
                cityId = "London",
                sceneId = "Electronic",
                startDateTime = now + (oneHour * 2), // Tonight! starts in 2 hours
                endDateTime = now + (oneHour * 8),
                doorsDateTime = now + (oneHour * 2),
                locationVisibility = "AREA_ONLY",
                agePolicy = "18+ ID Required",
                capacity = 850,
                currentAttendance = 412,
                artworkUrl = "graphene_after_dark",
                genre = "Acid House / Breaks",
                tags = "Tonight, Warehouse, Rave, Loud",
                safetyInformation = "This event features extremely high sound levels. Earplugs are available at the bar free of charge. Graphene Records enforces a zero-tolerance policy for harassment of any kind. Look out for our safety crew in pink armbands.",
                transportInformation = "Hackney Wick overground station is close, but closes around midnight. Taxis are recommended for late night departures.",
                lineup = "101,103,105", // Krypton, Volt_Age, Acid Flux
                timetable = "23:00 - Doors Open\n23:30 - ACID FLUX (Acid Hybrid Set)\n01:30 - VOLT_AGE (Breaks Live)\n03:30 - DJ KRYPTON (Modular Closing Session)\n06:00 - Curfew"
            ),
            EventEntity(
                eventId = 2,
                slug = "basement-session",
                title = "GRAPHENE BASEMENT SESSION",
                subtitle = "INTIMATE MINIMAL & TECHNO",
                description = "An intimate gathering of minimal enthusiasts in Soho's deep underground cavern. Strictly limited to 150 capacities. No cameras. No spotlights. Pure auditory devotion.",
                eventType = "BASEMENT",
                status = "ON_SALE",
                visibility = "PUBLIC",
                promoterId = 501,
                venueId = 202, // Subterranean
                cityId = "London",
                sceneId = "Techno",
                startDateTime = now + oneDay, // Tomorrow
                endDateTime = now + oneDay + (oneHour * 5),
                doorsDateTime = now + oneDay,
                locationVisibility = "PUBLIC",
                agePolicy = "21+",
                capacity = 150,
                currentAttendance = 0,
                artworkUrl = "basement_session",
                genre = "Minimal Techno / Ambient",
                tags = "This Week, Small Room, Dark, Minimal",
                safetyInformation = "Our basement is dark and has a high step count. Watch your step. Intoxicated guests will be refused entry.",
                transportInformation = "Soho is well-served by night tubes. Tottenham Court Road station is less than 3 minutes away.",
                lineup = "102,106", // Sine Wave Project, Echo Labs
                timetable = "22:00 - Doors Open\n22:30 - ECHO LABS (Dub Techno Warm-up)\n01:00 - SINE WAVE PROJECT (Live Hardware Set)\n03:00 - Closing B2B"
            ),
            EventEntity(
                eventId = 3,
                slug = "new-names-south",
                title = "NEW NAMES: SOUTH",
                subtitle = "EMERGING LIVE SHOWCASE",
                description = "Focusing on local emerging electronic talent from South and East London. Discover new artists before they break on the global underground circuit. Label representatives will be present.",
                eventType = "SHOWCASE",
                status = "ON_SALE",
                visibility = "PUBLIC",
                promoterId = 502,
                venueId = 202,
                cityId = "London",
                sceneId = "Emerging Electronic",
                startDateTime = now + (oneDay * 4), // Next week
                endDateTime = now + (oneDay * 4) + (oneHour * 4),
                doorsDateTime = now + (oneDay * 4),
                locationVisibility = "PUBLIC",
                agePolicy = "18+",
                capacity = 150,
                currentAttendance = 0,
                artworkUrl = "new_names_south",
                genre = "Experimental / Breaks / IDM",
                tags = "Emerging, Showcase, New Names",
                safetyInformation = "Fully inclusive atmosphere. Reach out to any security if you feel uncomfortable.",
                transportInformation = "Nearby Soho bus routes running 24/7.",
                lineup = "104,102", // Lyra, Sine Wave Project
                timetable = "19:00 - Doors\n20:00 - LYRA (Ambient Drone Set)\n21:30 - SINE WAVE PROJECT (Live Modular Exploration)"
            ),
            EventEntity(
                eventId = 4,
                slug = "listening-room-private",
                title = "GRAPHENE LISTENING ROOM",
                subtitle = "MEMBERS ONLY PRIVATE PREVIEW",
                description = "A strictly invite-only listening session for Graphene's upcoming 2026 catalogue releases. High-fidelity spatial audio playback. Chat with artists in a secret Bermondsey industrial arch. Entry only with verified Graphene Invite Pass.",
                eventType = "PRIVATE_EVENT",
                status = "ON_SALE",
                visibility = "SECRET",
                promoterId = 501,
                venueId = 204, // Secret Arch
                cityId = "London",
                sceneId = "Industrial Ambient",
                startDateTime = now + (oneHour * 10), // Tonight, but late night / private
                endDateTime = now + (oneHour * 13),
                doorsDateTime = now + (oneHour * 10),
                locationVisibility = "POST_PURCHASE", // Exact coordinates hidden until ticket is in wallet!
                agePolicy = "18+ Invite Only",
                capacity = 100,
                currentAttendance = 24,
                artworkUrl = "listening_room",
                genre = "Experimental Ambient / A&R Showcase",
                tags = "Secret, Invite Only, Label Night, Exclusive",
                safetyInformation = "Private event. Right of admission is strictly reserved.",
                transportInformation = "The exact address is near Bermondsey Station. Walk details will be revealed with your ticket.",
                lineup = "104,106", // Lyra, Echo Labs
                timetable = "21:00 - Doors Open & Welcome Drinks\n21:30 - Spatial Playback: Upcoming Releases\n22:30 - Q&A with Artists\n23:30 - LYRA (Exclusive Closing Live Set)"
            ),
            EventEntity(
                eventId = 5,
                slug = "manchester-showcase",
                title = "GRAPHENE RECORDS SHOWCASE",
                subtitle = "THE ENGINE ROOM RE-OPENING",
                description = "Graphene Records takes over Manchester's premier industrial brick hangar for an unforgettable evening. This showcase is approaching immediate capacity. Our annual northern showcase.",
                eventType = "LABEL_NIGHT",
                status = "SOLD_OUT",
                visibility = "PUBLIC",
                promoterId = 501,
                venueId = 203, // Ancoats
                cityId = "Manchester",
                sceneId = "Techno",
                startDateTime = now + (oneDay * 6),
                endDateTime = now + (oneDay * 6) + (oneHour * 7),
                doorsDateTime = now + (oneDay * 6),
                locationVisibility = "PUBLIC",
                agePolicy = "18+",
                capacity = 500,
                currentAttendance = 0,
                artworkUrl = "manchester_showcase",
                genre = "Hard Techno / Acid House",
                tags = "Selling Fast, Manchester, Massive, Rave",
                safetyInformation = "Strobe lighting, lasers, and high-intensity fog are used heavily throughout this performance. Not recommended for guests with photosensitive epilepsy.",
                transportInformation = "Victoria Station is a short walk. Taxis line up outside the venue.",
                lineup = "101,105", // Krypton, Acid Flux
                timetable = "22:00 - Doors\n23:00 - ACID FLUX (303 Session)\n01:30 - DJ KRYPTON (Industrial Techno DJ Set)\n05:00 - Curfew"
            )
        )
        dao.insertEvents(events)

        // Seed Ticket Types for each Event
        val ticketTypes = listOf(
            // Event 1 (Graphene After Dark)
            TicketTypeEntity(3001, 1, "EARLY BIRD (SOLD OUT)", 12.00, 150, 150),
            TicketTypeEntity(3002, 1, "GENERAL RELEASE", 18.00, 500, 262),
            TicketTypeEntity(3003, 1, "LATE RELEASE", 24.00, 200, 0),

            // Event 2 (Basement Session)
            TicketTypeEntity(3004, 2, "LIMITED ENTRY PASS", 15.00, 150, 48),

            // Event 3 (New Names: South)
            TicketTypeEntity(3005, 3, "STANDARD ENTRY", 8.00, 150, 20),

            // Event 4 (Graphene Listening Room)
            TicketTypeEntity(3006, 4, "INVITE-ONLY COMP PASS", 0.00, 50, 24),
            TicketTypeEntity(3007, 4, "VIP PATRON SPOT", 30.00, 50, 12),

            // Event 5 (Manchester Showcase)
            TicketTypeEntity(3008, 5, "EARLY BIRD (SOLD OUT)", 15.00, 100, 100),
            TicketTypeEntity(3009, 5, "GENERAL RELEASE (SOLD OUT)", 22.00, 400, 400)
        )
        dao.insertTicketTypes(ticketTypes)

        // Seed some starter Guest List entries
        val guestEntries = listOf(
            GuestListEntryEntity(4001, 1, "Sarah Connor", "promoter guest", 1, "PENDING", "Priority entry at front desk"),
            GuestListEntryEntity(4002, 1, "Thomas Anderson", "artist guest", 0, "PENDING", "Vortex backstage wristband access required"),
            GuestListEntryEntity(4003, 1, "Marcus Aurelius", "press", 1, "CHECKED_IN", "Photography pass issued")
        )
        for (entry in guestEntries) {
            dao.insertGuestListEntry(entry)
        }

        // Seed initial Incident
        val incident = IncidentEntity(
            incidentId = 6001,
            eventId = 1,
            type = "TECHNICAL",
            severity = "MEDIUM",
            status = "RESOLVED",
            description = "Sub-bass vibration causing secondary visual grid fixture to rattle in Main Chamber. Secured with heavy-duty safety cables.",
            timestamp = now - (oneHour)
        )
        dao.insertIncident(incident)
    }
}
