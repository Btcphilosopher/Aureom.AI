package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val selectedEventId by viewModel.selectedEventId.collectAsStateWithLifecycle()
    val selectedArtistId by viewModel.selectedArtistId.collectAsStateWithLifecycle()
    val selectedVenueId by viewModel.selectedVenueId.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val isOfflineMode by viewModel.isOfflineMode.collectAsStateWithLifecycle()
    val isSynchronizing by viewModel.isSynchronizing.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column {
                // Urgent Ticker Bar
                NotificationTicker(notifications)
                
                // Graphene Branded Header with Role Selector
                GrapheneHeader(
                    currentRole = currentRole,
                    isOffline = isOfflineMode,
                    isSyncing = isSynchronizing,
                    onRoleChange = { viewModel.selectRole(it) },
                    onToggleOffline = { viewModel.toggleOfflineMode() }
                )
            }
        },
        bottomBar = {
            if (currentRole == GrapheneRole.ATTENDEE) {
                GrapheneBottomBar(activeTab = activeTab, onTabSelect = { viewModel.selectTab(it) })
            }
        },
        containerColor = GrapheneBlack,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GrapheneBlack)
        ) {
            // Draw a subtle brutalist background grid using Canvas
            BrutalistBackgroundGrid()

            // State Routing
            AnimatedContent(
                targetState = Triple(currentRole, activeTab, selectedEventId),
                transitionSpec = {
                    fadeIn(spring()) togetherWith fadeOut(spring())
                },
                label = "MainContentTransition"
            ) { (role, tab, eventId) ->
                when {
                    eventId != null -> {
                        EventDetailScreen(
                            eventId = eventId,
                            viewModel = viewModel,
                            onBack = { viewModel.selectEvent(null) }
                        )
                    }
                    selectedArtistId != null -> {
                        ArtistProfileScreen(
                            artistId = selectedArtistId!!,
                            viewModel = viewModel,
                            onBack = { viewModel.selectArtist(null) }
                        )
                    }
                    selectedVenueId != null -> {
                        VenueProfileScreen(
                            venueId = selectedVenueId!!,
                            viewModel = viewModel,
                            onBack = { viewModel.selectVenue(null) }
                        )
                    }
                    role == GrapheneRole.PROMOTER -> {
                        PromoterDashboard(viewModel = viewModel)
                    }
                    role == GrapheneRole.DOOR_STAFF -> {
                        DoorModeScreen(viewModel = viewModel)
                    }
                    role == GrapheneRole.ARTIST -> {
                        ArtistPortalScreen(viewModel = viewModel)
                    }
                    role == GrapheneRole.VENUE_STAFF -> {
                        VenuePortalScreen(viewModel = viewModel)
                    }
                    else -> {
                        // Attendee mode tabs
                        when (tab) {
                            "discover" -> DiscoverTab(viewModel = viewModel)
                            "search" -> SearchTab(viewModel = viewModel)
                            "wallet" -> WalletTab(viewModel = viewModel)
                            else -> DiscoverTab(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

// --- SUB-COMPONENTS & LAYOUT PARTS ---

@Composable
fun BrutalistBackgroundGrid() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 0.5.dp.toPx()
        val step = 40.dp.toPx()
        // Draw vertical lines
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = Color(0x15FFFFFF),
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = strokeWidth
            )
            x += step
        }
        // Draw horizontal lines
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Color(0x15FFFFFF),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = strokeWidth
            )
            y += step
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NotificationTicker(notifications: List<String>) {
    val combinedText = remember(notifications) {
        notifications.joinToString("   //   ") + "   //   "
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(GrapheneFuchsia)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "ALERT",
            color = GrapheneBlack,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier
                .background(GrapheneOffWhite)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = combinedText,
            color = GrapheneOffWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            modifier = Modifier
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    initialDelayMillis = 0,
                    spacing = MarqueeSpacing(20.dp),
                    velocity = 40.dp
                )
        )
    }
}

@Composable
fun GrapheneHeader(
    currentRole: GrapheneRole,
    isOffline: Boolean,
    isSyncing: Boolean,
    onRoleChange: (GrapheneRole) -> Unit,
    onToggleOffline: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(GrapheneBlack)
            .border(1.dp, GrapheneLightGray)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Oversized logo
            Text(
                text = "GRAPHENE // EVENTS",
                color = GrapheneOffWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = (-1).sp
            )

            // Connection Badge / System Indicators
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        color = GrapheneAcidGreen,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (isOffline) GrapheneAmber else GrapheneAcidGreen)
                        .clickable { onToggleOffline() }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isOffline) "OFFLINE" else "LIVE",
                        color = GrapheneBlack,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box {
                    IconButton(
                        onClick = { expanded = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Switch Mode",
                            tint = GrapheneOffWhite
                        )
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(GrapheneGraphite).border(1.dp, GrapheneLightGray)
                    ) {
                        GrapheneRole.values().forEach { role ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = role.name.replace("_", " "),
                                        color = if (currentRole == role) GrapheneAcidGreen else GrapheneOffWhite,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                onClick = {
                                    onRoleChange(role)
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Active role subtitle label
        Text(
            text = "MODE: ${currentRole.name.replace("_", " ")} // OPERATIONAL SYSTEM",
            color = GrapheneSilver,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun GrapheneBottomBar(activeTab: String, onTabSelect: (String) -> Unit) {
    NavigationBar(
        containerColor = GrapheneBlack,
        tonalElevation = 0.dp,
        modifier = Modifier.border(1.dp, GrapheneLightGray)
    ) {
        NavigationBarItem(
            selected = activeTab == "discover",
            onClick = { onTabSelect("discover") },
            icon = { Icon(Icons.Outlined.MusicNote, contentDescription = "Discover") },
            label = { Text("DISCOVER", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GrapheneAcidGreen,
                selectedTextColor = GrapheneAcidGreen,
                indicatorColor = GrapheneLightGray,
                unselectedIconColor = GrapheneSilver,
                unselectedTextColor = GrapheneSilver
            )
        )
        NavigationBarItem(
            selected = activeTab == "search",
            onClick = { onTabSelect("search") },
            icon = { Icon(Icons.Outlined.Search, contentDescription = "Search") },
            label = { Text("EXPLORE", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GrapheneElectricBlue,
                selectedTextColor = GrapheneElectricBlue,
                indicatorColor = GrapheneLightGray,
                unselectedIconColor = GrapheneSilver,
                unselectedTextColor = GrapheneSilver
            )
        )
        NavigationBarItem(
            selected = activeTab == "wallet",
            onClick = { onTabSelect("wallet") },
            icon = { Icon(Icons.Outlined.ConfirmationNumber, contentDescription = "Wallet") },
            label = { Text("TICKETS", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GrapheneFuchsia,
                selectedTextColor = GrapheneFuchsia,
                indicatorColor = GrapheneLightGray,
                unselectedIconColor = GrapheneSilver,
                unselectedTextColor = GrapheneSilver
            )
        )
    }
}

// --- DISCOVER TAB ---

@Composable
fun DiscoverTab(viewModel: MainViewModel) {
    val events by viewModel.events.collectAsStateWithLifecycle()
    val artists by viewModel.artists.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp)
    ) {
        // Tonight hero section
        val tonightEvents = events.filter { it.tags.contains("Tonight", ignoreCase = true) }
        if (tonightEvents.isNotEmpty()) {
            item {
                BrutalistHeader("TONIGHT // IMMEDIATE ACTION")
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    items(tonightEvents) { event ->
                        TonightEventCard(event = event, viewModel = viewModel) {
                            viewModel.selectEvent(event.eventId)
                        }
                    }
                }
            }
        }

        // Just Announced section
        item {
            BrutalistHeader("JUST ANNOUNCED")
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(events) { event ->
                    CompactEventCard(event = event, viewModel = viewModel) {
                        viewModel.selectEvent(event.eventId)
                    }
                }
            }
        }

        // Secret Section
        val secretEvents = events.filter { it.visibility == "SECRET" }
        if (secretEvents.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BrutalistHeader("SECRET SESSIONS")
                    Box(
                        modifier = Modifier
                            .background(GrapheneFuchsia)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "INVITE REQUIRED",
                            color = GrapheneBlack,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    items(secretEvents) { event ->
                        SecretEventCard(event = event) {
                            viewModel.selectEvent(event.eventId)
                        }
                    }
                }
            }
        }

        // Scene Graph Quick Summary
        item {
            BrutalistHeader("LONDON / NORTH SCENE MAP")
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GrapheneGraphite)
                    .border(1.dp, GrapheneLightGray)
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "LONDON CORE",
                        color = GrapheneAcidGreen,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = " └── South London\n      └── Electronic / Bass Culture\n           ├── The Vortex Warehouse (Hackney)\n           ├── Subterranean Basement (Soho)\n           └── Echo Labs (Ambient residents)",
                        color = GrapheneOffWhite,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 4.dp),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Your Artists Section
        item {
            BrutalistHeader("FOLLOWED ARTISTS")
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(artists) { artist ->
                    ArtistMiniCard(artist = artist, onFollowToggle = {
                        viewModel.toggleFollowArtist(artist.artistId)
                    }, onClick = {
                        viewModel.selectArtist(artist.artistId)
                    })
                }
            }
        }
    }
}

// --- PROCEDURAL ALPHABETICAL FLYER ART DRAWING COMPOSABLE ---

@Composable
fun ProceduralFlyer(
    artworkSeed: String,
    modifier: Modifier = Modifier,
    accentColor: Color = GrapheneAcidGreen
) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(0.dp))
            .border(1.dp, GrapheneOffWhite)
    ) {
        drawRect(color = GrapheneBlack)

        val sizeL = size.width
        val center = Offset(size.width / 2, size.height / 2)

        when (artworkSeed) {
            "graphene_after_dark" -> {
                // Concentric circles with lines
                for (i in 1..6) {
                    drawCircle(
                        color = accentColor.copy(alpha = i * 0.15f),
                        radius = sizeL * 0.08f * i,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                    )
                }
                drawLine(
                    color = GrapheneOffWhite,
                    start = Offset(0f, 0f),
                    end = Offset(size.width, size.height),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = GrapheneOffWhite,
                    start = Offset(0f, size.height),
                    end = Offset(size.width, 0f),
                    strokeWidth = 1.dp.toPx()
                )
            }
            "basement_session" -> {
                // Diagonal metal grid
                var x = 0f
                while (x < size.width) {
                    drawLine(
                        color = GrapheneElectricBlue.copy(alpha = 0.4f),
                        start = Offset(x, 0f),
                        end = Offset(x + 50f, size.height),
                        strokeWidth = 2.dp.toPx()
                    )
                    x += 30.dp.toPx()
                }
                // Centered sharp square
                drawRect(
                    color = GrapheneElectricBlue,
                    topLeft = Offset(size.width * 0.25f, size.height * 0.25f),
                    size = androidx.compose.ui.geometry.Size(size.width * 0.5f, size.height * 0.5f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                )
            }
            "listening_room" -> {
                // Waveforms
                val steps = 80
                val spacing = size.width / steps
                for (i in 0..steps) {
                    val h = (sin(i * 0.2) * (size.height * 0.3) + (size.height * 0.5)).toFloat()
                    drawLine(
                        color = GrapheneFuchsia.copy(alpha = 0.8f),
                        start = Offset(i * spacing, size.height),
                        end = Offset(i * spacing, h),
                        strokeWidth = 3.dp.toPx()
                    )
                }
            }
            "new_names_south" -> {
                // Asymmetric split stripes
                drawRect(
                    color = GrapheneAmber.copy(alpha = 0.3f),
                    topLeft = Offset(0f, 0f),
                    size = androidx.compose.ui.geometry.Size(size.width * 0.4f, size.height)
                )
                drawLine(
                    color = GrapheneOffWhite,
                    start = Offset(size.width * 0.4f, 0f),
                    end = Offset(size.width * 0.4f, size.height),
                    strokeWidth = 4.dp.toPx()
                )
                // Small metadata looking crosshairs
                drawCircle(color = GrapheneAmber, radius = 6.dp.toPx(), center = center)
            }
            else -> {
                // Default brutalist checkerboard or cross
                drawLine(
                    color = accentColor,
                    start = Offset(center.x, 0f),
                    end = Offset(center.x, size.height),
                    strokeWidth = 4.dp.toPx()
                )
                drawLine(
                    color = accentColor,
                    start = Offset(0f, center.y),
                    end = Offset(size.width, center.y),
                    strokeWidth = 4.dp.toPx()
                )
            }
        }
    }
}

@Composable
fun BrutalistHeader(text: String) {
    Text(
        text = text.uppercase(),
        color = GrapheneOffWhite,
        fontSize = 12.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Monospace,
        letterSpacing = 1.sp,
        modifier = Modifier
            .border(1.dp, GrapheneLightGray)
            .background(GrapheneGraphite)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

@Composable
fun TonightEventCard(event: EventEntity, viewModel: MainViewModel, onClick: () -> Unit) {
    val explanation = remember(event) { viewModel.calculateDiscoveryExplanation(event) }
    
    Card(
        modifier = Modifier
            .width(280.dp)
            .border(1.dp, GrapheneOffWhite)
            .clickable { onClick() }
            .testTag("tonight_event_${event.eventId}"),
        colors = CardDefaults.cardColors(containerColor = GrapheneGraphite),
        shape = RoundedCornerShape(0.dp)
    ) {
        Column {
            ProceduralFlyer(
                artworkSeed = event.artworkUrl,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                accentColor = GrapheneAcidGreen
            )

            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DISCOVERY SCORE: ${explanation.score}",
                        color = GrapheneAcidGreen,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .background(GrapheneFuchsia)
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = event.eventType,
                            color = GrapheneBlack,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = event.title,
                    color = GrapheneOffWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    lineHeight = 24.sp
                )

                Text(
                    text = event.subtitle,
                    color = GrapheneSilver,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "CAP: ${event.capacity} PAX",
                        color = GrapheneSilver,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "LONDON / UK",
                        color = GrapheneSilver,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun CompactEventCard(event: EventEntity, viewModel: MainViewModel, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(200.dp)
            .border(1.dp, GrapheneLightGray)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = GrapheneGraphite),
        shape = RoundedCornerShape(0.dp)
    ) {
        Column {
            ProceduralFlyer(
                artworkSeed = event.artworkUrl,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                accentColor = GrapheneElectricBlue
            )

            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = event.title,
                    color = GrapheneOffWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = event.subtitle,
                    color = GrapheneSilver,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "GENRE: ${event.genre}",
                    color = GrapheneElectricBlue,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun SecretEventCard(event: EventEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(200.dp)
            .border(1.dp, GrapheneFuchsia)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = GrapheneBlack),
        shape = RoundedCornerShape(0.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(GrapheneLightGray)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(color = Color.Black)
                    // Drawing confidential text
                    drawLine(GrapheneFuchsia, Offset(0f, 0f), Offset(size.width, size.height), 2.dp.toPx())
                    drawLine(GrapheneFuchsia, Offset(0f, size.height), Offset(size.width, 0f), 2.dp.toPx())
                }
                Text(
                    text = "REVEALED\nON TICKET",
                    color = GrapheneFuchsia,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = event.title,
                    color = GrapheneOffWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ACCESS: EXCLUSIVE",
                    color = GrapheneSilver,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ArtistMiniCard(artist: ArtistEntity, onFollowToggle: () -> Unit, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(140.dp)
            .border(1.dp, GrapheneLightGray)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = GrapheneGraphite),
        shape = RoundedCornerShape(0.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(GrapheneLightGray)
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = artist.name,
                    tint = GrapheneOffWhite,
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.Center)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = artist.name,
                color = GrapheneOffWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = artist.genre.uppercase(),
                color = GrapheneSilver,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = onFollowToggle,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (artist.isFollowed) GrapheneLightGray else GrapheneAcidGreen
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier
                    .height(24.dp)
                    .minimumInteractiveComponentSize()
            ) {
                Text(
                    text = if (artist.isFollowed) "FOLLOWED" else "FOLLOW",
                    color = if (artist.isFollowed) GrapheneOffWhite else GrapheneBlack,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// --- EVENT DETAIL PAGE SCREEN ---

@Composable
fun EventDetailScreen(eventId: Long, viewModel: MainViewModel, onBack: () -> Unit) {
    val events by viewModel.events.collectAsStateWithLifecycle()
    val event = remember(events, eventId) { events.find { it.eventId == eventId } } ?: return
    val venues by viewModel.venues.collectAsStateWithLifecycle()
    val venue = remember(venues, event.venueId) { venues.find { it.venueId == event.venueId } }
    val venueAddress = venue?.exactAddress ?: "CLASSIFIED WAREHOUSE VAULT"
    val ticketTypes by viewModel.getTicketTypesForEvent(eventId).collectAsState(initial = emptyList())
    val walletTickets by viewModel.tickets.collectAsStateWithLifecycle()
    val hasTicket = remember(walletTickets, eventId) { walletTickets.any { it.eventId == eventId && it.status == "ISSUED" } }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(GrapheneBlack)
    ) {
        // Hero Artwork block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            ProceduralFlyer(
                artworkSeed = event.artworkUrl,
                modifier = Modifier.fillMaxSize(),
                accentColor = GrapheneFuchsia
            )

            // Overlap Back Button
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .padding(16.dp)
                    .background(GrapheneBlack.copy(alpha = 0.7f))
                    .align(Alignment.TopStart)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = GrapheneOffWhite
                )
            }

            // Category & Status pill
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.background(GrapheneFuchsia).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(text = event.eventType, color = GrapheneBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Box(modifier = Modifier.background(GrapheneAcidGreen).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(text = event.status, color = GrapheneBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Body Info
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = event.title,
                color = GrapheneOffWhite,
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                lineHeight = 36.sp
            )

            Text(
                text = event.subtitle,
                color = GrapheneSilver,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // AI Discovery Debug Panel
            AIDiscoveryScorePanel(event, viewModel)

            Spacer(modifier = Modifier.height(16.dp))

            // Location Reveal Card
            BrutalistHeader("LOCATION REVEAL")
            Spacer(modifier = Modifier.height(8.dp))
            LocationRevealCard(event, venueAddress, hasTicket)

            Spacer(modifier = Modifier.height(16.dp))

            // Ticket Purchasing Panel
            BrutalistHeader("SECURE TICKETS")
            Spacer(modifier = Modifier.height(8.dp))
            if (event.status == "SOLD_OUT") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GrapheneLightGray)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CAPACITY MAXIMUM REACHED. TICKETS FULLY EXHAUSTED.",
                        color = GrapheneOffWhite,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                ticketTypes.forEach { type ->
                    TicketPurchaseRow(type, event) {
                        viewModel.purchaseTicket(event, type)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Timetable Scheduler
            BrutalistHeader("PERFORMANCE TIMETABLE")
            Spacer(modifier = Modifier.height(8.dp))
            TimelineDisplay(event.timetable)

            Spacer(modifier = Modifier.height(16.dp))

            // Sound, Safety & travel guidelines
            BrutalistHeader("SAFETY & COMMUNITY COVENANT")
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = event.safetyInformation,
                color = GrapheneSilver,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                modifier = Modifier
                    .background(GrapheneGraphite)
                    .border(1.dp, GrapheneLightGray)
                    .padding(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            BrutalistHeader("TRANSPORT AND ACCESS")
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = event.transportInformation,
                color = GrapheneSilver,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                modifier = Modifier
                    .background(GrapheneGraphite)
                    .border(1.dp, GrapheneLightGray)
                    .padding(12.dp)
            )
        }
    }
}

@Composable
fun AIDiscoveryScorePanel(event: EventEntity, viewModel: MainViewModel) {
    val explanation = remember(event) { viewModel.calculateDiscoveryExplanation(event) }
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GrapheneAcidGreen)
            .background(GrapheneBlack)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Analytics, contentDescription = "AI", tint = GrapheneAcidGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AI DISCOVERY FIT: ${explanation.score}%",
                    color = GrapheneAcidGreen,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Text(
                text = if (expanded) "HIDE BREAKDOWN" else "DEBUG GRAPH",
                color = GrapheneSilver,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { expanded = !expanded }
                    .padding(4.dp)
            )
        }

        if (expanded) {
            Spacer(modifier = Modifier.height(8.dp))
            explanation.factors.forEach { factor ->
                Text(
                    text = "  // $factor",
                    color = GrapheneOffWhite,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun LocationRevealCard(event: EventEntity, venueAddress: String, hasTicket: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (hasTicket) GrapheneAcidGreen else GrapheneFuchsia)
            .background(GrapheneGraphite)
            .padding(16.dp)
    ) {
        if (hasTicket) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = GrapheneAcidGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "LOCATION CONFIRMED",
                    color = GrapheneAcidGreen,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "EXACT VENUE: $venueAddress",
                color = GrapheneOffWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Please keep this physical location discrete to maintain scene integrity.",
                color = GrapheneSilver,
                fontSize = 11.sp
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = "Locked", tint = GrapheneFuchsia)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "LOCATION CLASSIFIED",
                    color = GrapheneFuchsia,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ACCESS CODES RESTRICTED TO VALID TICKET HOLDERS ONLY.",
                color = GrapheneSilver,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun TicketPurchaseRow(type: TicketTypeEntity, event: EventEntity, onPurchase: () -> Unit) {
    val remaining = type.allocation - type.sold
    val isAvailable = remaining > 0

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GrapheneLightGray)
            .background(GrapheneBlack)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = type.name.uppercase(),
                color = GrapheneOffWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = if (isAvailable) "REMAINING: $remaining TICKETS" else "SOLD OUT",
                color = if (isAvailable) GrapheneSilver else GrapheneRed,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "£${String.format("%.2f", type.price)}",
                color = GrapheneAcidGreen,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                fontSize = 16.sp,
                modifier = Modifier.padding(end = 12.dp)
            )

            Button(
                onClick = onPurchase,
                enabled = isAvailable,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GrapheneAcidGreen,
                    contentColor = GrapheneBlack,
                    disabledContainerColor = GrapheneLightGray,
                    disabledContentColor = GrapheneSilver
                ),
                shape = RoundedCornerShape(0.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Text(text = "BUY", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun TimelineDisplay(timetable: String) {
    val items = timetable.split("\n")
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GrapheneLightGray)
            .background(GrapheneGraphite)
            .padding(12.dp)
    ) {
        items.forEach { item ->
            val parts = item.split(" - ")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (parts.size >= 2) {
                    Text(
                        text = parts[0],
                        color = GrapheneAcidGreen,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = parts[1].uppercase(),
                        color = GrapheneOffWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Text(text = item, color = GrapheneOffWhite, fontSize = 12.sp)
                }
            }
        }
    }
}

// --- SEARCH TAB ---

@Composable
fun SearchTab(viewModel: MainViewModel) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val filteredEvents by viewModel.filteredEvents.collectAsStateWithLifecycle()
    val selectedTagFilter by viewModel.selectedTagFilter.collectAsStateWithLifecycle()

    val tagsList = listOf("Tonight", "Warehouse", "Rave", "Secret", "Manchester", "Emerging")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneOffWhite)
                .background(GrapheneGraphite),
            placeholder = { Text("SEARCH ARTIST, GENRE, CITY, TAGS...", color = GrapheneSilver, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = GrapheneOffWhite,
                unfocusedTextColor = GrapheneOffWhite,
                focusedBorderColor = GrapheneAcidGreen,
                unfocusedBorderColor = Color.Transparent
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal Tag Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tagsList) { tag ->
                val isSelected = selectedTagFilter == tag
                Box(
                    modifier = Modifier
                        .background(if (isSelected) GrapheneAcidGreen else GrapheneGraphite)
                        .border(1.dp, if (isSelected) GrapheneAcidGreen else GrapheneLightGray)
                        .clickable { viewModel.setTagFilter(if (isSelected) null else tag) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = tag.uppercase(),
                        color = if (isSelected) GrapheneBlack else GrapheneOffWhite,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Results list
        if (filteredEvents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NO MATCHES FOUND FOR GIVEN FILTER SPECS.",
                    color = GrapheneSilver,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1.0f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(filteredEvents) { event ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GrapheneLightGray)
                            .background(GrapheneGraphite)
                            .clickable { viewModel.selectEvent(event.eventId) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProceduralFlyer(
                            artworkSeed = event.artworkUrl,
                            modifier = Modifier.size(60.dp),
                            accentColor = GrapheneElectricBlue
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = event.title,
                                color = GrapheneOffWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${event.eventType} • ${event.genre}",
                                color = GrapheneSilver,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "CITY: ${event.cityId.uppercase()}",
                                color = GrapheneElectricBlue,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- WALLET / TICKETS TAB ---

@Composable
fun WalletTab(viewModel: MainViewModel) {
    val tickets by viewModel.tickets.collectAsStateWithLifecycle()
    val events by viewModel.events.collectAsStateWithLifecycle()

    val myActiveTickets = remember(tickets) { tickets.filter { it.userId == "G-ATTENDEE-007" } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SECURE WALLET // ACTIVE PASSES",
            color = GrapheneOffWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (myActiveTickets.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "WALLET EMPTY. PURCHASE A TICKET TO REVEAL SECURE GRAPHENE QR CODE.",
                    color = GrapheneSilver,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(24.dp)
                )
            }
        } else {
            val venues by viewModel.venues.collectAsStateWithLifecycle()
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.weight(1.0f)
            ) {
                items(myActiveTickets) { ticket ->
                    val matchingEvent = events.find { it.eventId == ticket.eventId }
                    val matchingVenue = venues.find { it.venueId == matchingEvent?.venueId }
                    val venueAddress = matchingVenue?.exactAddress ?: "SECRET VAULT ARCHES"
                    if (matchingEvent != null) {
                        WalletTicketCard(
                            ticket = ticket,
                            event = matchingEvent,
                            venueAddress = venueAddress,
                            onTransfer = { email ->
                                viewModel.transferTicket(ticket, email)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WalletTicketCard(ticket: TicketEntity, event: EventEntity, venueAddress: String, onTransfer: (String) -> Unit) {
    var transferOpen by remember { mutableStateOf(false) }
    var transferEmail by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GrapheneOffWhite)
            .background(GrapheneGraphite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneFuchsia)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = ticket.ticketId,
                color = GrapheneBlack,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = ticket.status.uppercase(),
                color = GrapheneBlack,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
            )
        }

        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = event.title,
                color = GrapheneOffWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = event.subtitle,
                color = GrapheneSilver,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Procedural QR Code display
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Drawing a styled high-contrast QR box
                Canvas(modifier = Modifier.size(100.dp)) {
                    drawRect(color = Color.White)
                    // Quick geometric grid representation of a QR
                    val squareSize = size.width / 5
                    // Draw 3 primary corner anchors
                    drawRect(color = Color.Black, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(squareSize * 1.5f, squareSize * 1.5f))
                    drawRect(color = Color.Black, topLeft = Offset(size.width - squareSize * 1.5f, 0f), size = androidx.compose.ui.geometry.Size(squareSize * 1.5f, squareSize * 1.5f))
                    drawRect(color = Color.Black, topLeft = Offset(0f, size.height - squareSize * 1.5f), size = androidx.compose.ui.geometry.Size(squareSize * 1.5f, squareSize * 1.5f))

                    // Draw some generic random digital matrix cubes
                    val seed = ticket.ticketId.hashCode()
                    for (row in 1..4) {
                        for (col in 1..4) {
                            if ((seed + row * 17 + col * 23) % 2 == 0) {
                                drawRect(
                                    color = Color.Black,
                                    topLeft = Offset(row * squareSize, col * squareSize),
                                    size = androidx.compose.ui.geometry.Size(squareSize * 0.8f, squareSize * 0.8f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "LOCATION:",
                        color = GrapheneAcidGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = venueAddress,
                        color = GrapheneOffWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "SCAN QR CODE FOR FAST ENTRY ADMISSION",
                        color = GrapheneSilver,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (ticket.status == "ISSUED") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = { transferOpen = !transferOpen },
                        colors = ButtonDefaults.buttonColors(containerColor = GrapheneLightGray),
                        shape = RoundedCornerShape(0.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text(text = "TRANSFER PASS", color = GrapheneOffWhite, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }

            if (transferOpen) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = transferEmail,
                    onValueChange = { transferEmail = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GrapheneBlack),
                    placeholder = { Text("RECIPIENT EMAIL", color = GrapheneSilver, fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GrapheneOffWhite,
                        focusedBorderColor = GrapheneFuchsia
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (transferEmail.isNotEmpty()) {
                            onTransfer(transferEmail)
                            transferOpen = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GrapheneFuchsia),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize()
                ) {
                    Text(text = "CONFIRM TRANSFER", color = GrapheneBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

// --- DOOR MODE STAFF PORTAL SCREEN ---

@Composable
fun DoorModeScreen(viewModel: MainViewModel) {
    val events by viewModel.events.collectAsStateWithLifecycle()
    val doorScanResult by viewModel.doorScanResult.collectAsStateWithLifecycle()
    val scannedTicket by viewModel.doorScannedTicket.collectAsStateWithLifecycle()

    val firstEvent = events.firstOrNull() ?: return
    val guestList by viewModel.getGuestListForEvent(firstEvent.eventId).collectAsState(initial = emptyList())

    var manualCodeInput by remember { mutableStateOf("") }
    var activeDoorTab by remember { mutableStateOf("scan") } // "scan", "guests"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Stats Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneLightGray)
                .background(GrapheneGraphite)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "CHECKED IN", color = GrapheneSilver, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "${firstEvent.currentAttendance} / ${firstEvent.capacity}", color = GrapheneAcidGreen, fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
            Column {
                Text(text = "QUEUE SIZE", color = GrapheneSilver, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "27 PAX", color = GrapheneOffWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
            Column {
                Text(text = "DOOR SALES", color = GrapheneSilver, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "£7,840", color = GrapheneAcidGreen, fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tab selection for scan vs guest list
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(if (activeDoorTab == "scan") GrapheneAcidGreen else GrapheneGraphite)
                    .clickable { activeDoorTab = "scan" }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CAMERA & MANUAL SCAN",
                    color = if (activeDoorTab == "scan") GrapheneBlack else GrapheneOffWhite,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(if (activeDoorTab == "guests") GrapheneAcidGreen else GrapheneGraphite)
                    .clickable { activeDoorTab = "guests" }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "GUEST LIST SHEET",
                    color = if (activeDoorTab == "guests") GrapheneBlack else GrapheneOffWhite,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeDoorTab == "scan") {
            // Scanner View
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Interactive Result Display
                if (doorScanResult != null) {
                    val boxColor = when (doorScanResult) {
                        "VALID" -> GrapheneAcidGreen
                        "OFFLINE_VERIFIED" -> GrapheneAmber
                        "ALREADY_USED" -> GrapheneRed
                        else -> GrapheneRed
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, boxColor)
                            .background(GrapheneGraphite)
                            .padding(16.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = doorScanResult!!.replace("_", " "),
                                color = boxColor,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            if (scannedTicket != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "TICKET ID: ${scannedTicket!!.ticketId}\nBUYER: ${scannedTicket!!.userId}",
                                    color = GrapheneOffWhite,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Center
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.clearDoorScan() },
                                colors = ButtonDefaults.buttonColors(containerColor = GrapheneLightGray),
                                shape = RoundedCornerShape(0.dp),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text(text = "CLEAR SCANNER", color = GrapheneOffWhite, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                } else {
                    // Simulating live viewport
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .border(1.dp, GrapheneLightGray)
                            .background(GrapheneBlack),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Drawing viewfinder lines
                            val stroke = 3.dp.toPx()
                            drawLine(GrapheneAcidGreen, Offset(20f, 20f), Offset(50f, 20f), stroke)
                            drawLine(GrapheneAcidGreen, Offset(20f, 20f), Offset(20f, 50f), stroke)

                            drawLine(GrapheneAcidGreen, Offset(size.width - 20f, 20f), Offset(size.width - 50f, 20f), stroke)
                            drawLine(GrapheneAcidGreen, Offset(size.width - 20f, 20f), Offset(size.width - 20f, 50f), stroke)

                            drawLine(GrapheneAcidGreen, Offset(20f, size.height - 20f), Offset(50f, size.height - 20f), stroke)
                            drawLine(GrapheneAcidGreen, Offset(20f, size.height - 20f), Offset(20f, size.height - 50f), stroke)

                            drawLine(GrapheneAcidGreen, Offset(size.width - 20f, size.height - 20f), Offset(size.width - 50f, size.height - 20f), stroke)
                            drawLine(GrapheneAcidGreen, Offset(size.width - 20f, size.height - 20f), Offset(size.width - 20f, size.height - 50f), stroke)
                        }
                        Text(
                            text = "[ ALIVE SCANNING SYSTEM V2 ]",
                            color = GrapheneAcidGreen,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Manual input or instant simulation buttons
                OutlinedTextField(
                    value = manualCodeInput,
                    onValueChange = { manualCodeInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GrapheneGraphite),
                    placeholder = { Text("INPUT SECURE TICKET KEY / QR CODE...", color = GrapheneSilver, fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GrapheneOffWhite,
                        unfocusedTextColor = GrapheneOffWhite,
                        focusedBorderColor = GrapheneAcidGreen
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            if (manualCodeInput.isNotEmpty()) {
                                viewModel.simulateDoorScan(manualCodeInput)
                                manualCodeInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GrapheneAcidGreen),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                    ) {
                        Text(text = "VERIFY", color = GrapheneBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = {
                            // Quick Demo scan seed
                            viewModel.simulateDoorScan("GTKT-DEMO-VALID")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GrapheneLightGray),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                    ) {
                        Text(text = "SCAN TEST", color = GrapheneOffWhite, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        } else {
            // Guest list view
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(guestList) { guest ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GrapheneLightGray)
                            .background(GrapheneGraphite)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = guest.name, color = GrapheneOffWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "CAT: ${guest.category.uppercase()} • PLS ONE: ${guest.plusOne}", color = GrapheneSilver, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        if (guest.status == "PENDING") {
                            Button(
                                onClick = { viewModel.checkInGuest(guest) },
                                colors = ButtonDefaults.buttonColors(containerColor = GrapheneAcidGreen),
                                shape = RoundedCornerShape(0.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text(text = "ADMIT", color = GrapheneBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        } else {
                            Text(text = "ADMITTED", color = GrapheneAcidGreen, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// --- PROMOTER CONTROL ROOM DASHBOARD ---

@Composable
fun PromoterDashboard(viewModel: MainViewModel) {
    val events by viewModel.events.collectAsStateWithLifecycle()
    val firstEvent = events.firstOrNull() ?: return
    val ticketTypes by viewModel.getTicketTypesForEvent(firstEvent.eventId).collectAsState(initial = emptyList())

    val financials = remember(firstEvent, ticketTypes) {
        viewModel.getEconomicsForEvent(firstEvent, ticketTypes)
    }

    var selectedRoomTab by remember { mutableStateOf("analytics") } // "analytics", "incidents", "timetable"
    var timetableEditText by remember { mutableStateOf(firstEvent.timetable) }

    // Incident inputs
    var incidentType by remember { mutableStateOf("MEDICAL") }
    var incidentSeverity by remember { mutableStateOf("MEDIUM") }
    var incidentDesc by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Large header info
        Text(
            text = firstEvent.title,
            color = GrapheneOffWhite,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = "LIVE CONTROL ROOM COMMANDER",
            color = GrapheneFuchsia,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Capacity Progress bar
        val ratio = firstEvent.currentAttendance.toFloat() / firstEvent.capacity.toFloat()
        Column {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "CURRENT ATTENDANCE", color = GrapheneSilver, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Text(text = "${firstEvent.currentAttendance} / ${firstEvent.capacity} PAX", color = GrapheneOffWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { ratio.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = GrapheneAcidGreen,
                trackColor = GrapheneLightGray
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Sector Tab Menu
        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("analytics", "incidents", "timetable").forEach { tab ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (selectedRoomTab == tab) GrapheneFuchsia else GrapheneGraphite)
                        .clickable { selectedRoomTab = tab }
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.uppercase(),
                        color = if (selectedRoomTab == tab) GrapheneBlack else GrapheneOffWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        when (selectedRoomTab) {
            "analytics" -> {
                // Economics Ledger Table
                BrutalistHeader("REVENUE & EXPENSES LEDGER")
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GrapheneLightGray)
                        .background(GrapheneGraphite)
                        .padding(12.dp)
                ) {
                    val gross = financials["grossSales"] ?: 0.0
                    val fees = (financials["platformFees"] ?: 0.0) + (financials["cardProcessing"] ?: 0.0)
                    val cost = (financials["artistBooking"] ?: 0.0) + (financials["production"] ?: 0.0)
                    val net = financials["netRevenue"] ?: 0.0

                    LedgerRow("GROSS TICKET SALES", "+£${String.format("%.2f", gross)}", GrapheneAcidGreen)
                    LedgerRow("PLATFORM / GATEWAY FEES", "-£${String.format("%.2f", fees)}", GrapheneRed)
                    LedgerRow("ARTIST booking COSTS", "-£${String.format("%.2f", financials["artistBooking"] ?: 0.0)}", GrapheneRed)
                    LedgerRow("SOUND / SECURITY PRODUCTION", "-£${String.format("%.2f", financials["production"] ?: 0.0)}", GrapheneRed)
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = GrapheneOffWhite)
                    Spacer(modifier = Modifier.height(8.dp))
                    LedgerRow("NET COVENANT REVENUE", "£${String.format("%.2f", net)}", GrapheneOffWhite, isBold = true)
                }
            }
            "incidents" -> {
                // Reporting Form
                BrutalistHeader("REGISTER INCIDENT HAZARD")
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GrapheneFuchsia)
                        .padding(12.dp)
                ) {
                    // Type selector
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("MEDICAL", "SECURITY", "TECHNICAL").forEach { type ->
                            Box(
                                modifier = Modifier
                                    .background(if (incidentType == type) GrapheneFuchsia else GrapheneBlack)
                                    .border(1.dp, GrapheneFuchsia)
                                    .clickable { incidentType = type }
                                    .padding(6.dp)
                            ) {
                                Text(text = type, color = if (incidentType == type) GrapheneBlack else GrapheneOffWhite, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = incidentDesc,
                        onValueChange = { incidentDesc = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(GrapheneGraphite),
                        placeholder = { Text("BRIEF SAFETY HAZARD DESCRIPTION...", color = GrapheneSilver, fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = GrapheneOffWhite,
                            focusedBorderColor = GrapheneFuchsia
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (incidentDesc.isNotEmpty()) {
                                viewModel.reportIncident(firstEvent.eventId, incidentType, incidentSeverity, incidentDesc)
                                incidentDesc = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GrapheneFuchsia),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize()
                    ) {
                        Text(text = "BROADCAST ALERT", color = GrapheneBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
            "timetable" -> {
                // Timetable live edit
                BrutalistHeader("EDIT ACTIVE PERFORMANCE TIMELINE")
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = timetableEditText,
                    onValueChange = { timetableEditText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .background(GrapheneGraphite),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GrapheneOffWhite,
                        focusedBorderColor = GrapheneAcidGreen
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.updateTimetable(firstEvent.eventId, timetableEditText)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GrapheneAcidGreen),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize()
                ) {
                    Text(text = "RECALIBRATE SCHEDULE", color = GrapheneBlack, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun LedgerRow(label: String, valText: String, color: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = GrapheneSilver,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = valText,
            color = color,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

// --- ARTIST PORTAL SCREEN ---

@Composable
fun ArtistPortalScreen(viewModel: MainViewModel) {
    val artists by viewModel.artists.collectAsStateWithLifecycle()
    val events by viewModel.events.collectAsStateWithLifecycle()
    
    val currentArtist = remember(artists) { artists.firstOrNull() ?: return@remember null } ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ARTIST PROFILE COMMANDER",
            color = GrapheneFuchsia,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = currentArtist.name.uppercase(),
            color = GrapheneOffWhite,
            fontSize = 28.sp,
            fontWeight = FontWeight.Black
        )

        Spacer(modifier = Modifier.height(16.dp))

        BrutalistHeader("BOOKING HISTORY & OFFERS")
        Spacer(modifier = Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneLightGray)
                .background(GrapheneGraphite)
                .padding(12.dp)
        ) {
            Text(text = "EVENT: GRAPHENE AFTER DARK", color = GrapheneOffWhite, fontWeight = FontWeight.Bold)
            Text(text = "SET TIME: 03:30 - 06:00", color = GrapheneAcidGreen, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text(text = "RIDER: Void Sound compliance, 2x Technics SL1210 MK7, Allen & Heath Xone:96 mixer.", color = GrapheneSilver, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .background(GrapheneAcidGreen)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(text = "CONFIRMED & CONTRACTED", color = GrapheneBlack, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- VENUE PORTAL SCREEN ---

@Composable
fun VenuePortalScreen(viewModel: MainViewModel) {
    val venues by viewModel.venues.collectAsStateWithLifecycle()
    val currentVenue = remember(venues) { venues.firstOrNull() ?: return@remember null } ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "VENUE OPERATIONAL COMMANDER",
            color = GrapheneElectricBlue,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = currentVenue.name.uppercase(),
            color = GrapheneOffWhite,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
        )

        Spacer(modifier = Modifier.height(16.dp))

        BrutalistHeader("SAFETY & LIMIT COMPLIANCE")
        Spacer(modifier = Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneLightGray)
                .background(GrapheneGraphite)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "LICENSED CAPACITY: ${currentVenue.capacity} PAX", color = GrapheneOffWhite, fontWeight = FontWeight.Bold)
            Text(text = "SOUND LIMIT: 102dB LAeq (15 min) Curfew enforcement 06:00.", color = GrapheneSilver, fontSize = 11.sp)
            Text(text = "EMERGENCY PROCEDURES: Fully integrated fire exit signage, first-aid station in Chill Out Vault.", color = GrapheneSilver, fontSize = 11.sp)
        }
    }
}

// --- ARTIST & VENUE PROFILE GRAHP PANELS (DETAILS) ---

@Composable
fun ArtistProfileScreen(artistId: Long, viewModel: MainViewModel, onBack: () -> Unit) {
    val artists by viewModel.artists.collectAsStateWithLifecycle()
    val artist = remember(artists, artistId) { artists.find { it.artistId == artistId } } ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GrapheneOffWhite)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = artist.name.uppercase(),
            color = GrapheneOffWhite,
            fontSize = 32.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = artist.genre.uppercase(),
            color = GrapheneAcidGreen,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        BrutalistHeader("BIOGRAPHY")
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = artist.bio,
            color = GrapheneSilver,
            fontSize = 13.sp,
            lineHeight = 20.sp,
            modifier = Modifier
                .background(GrapheneGraphite)
                .border(1.dp, GrapheneLightGray)
                .padding(12.dp)
        )
    }
}

@Composable
fun VenueProfileScreen(venueId: Long, viewModel: MainViewModel, onBack: () -> Unit) {
    val venues by viewModel.venues.collectAsStateWithLifecycle()
    val venue = remember(venues, venueId) { venues.find { it.venueId == venueId } } ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GrapheneOffWhite)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = venue.name.uppercase(),
            color = GrapheneOffWhite,
            fontSize = 28.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = "CITY: ${venue.city.uppercase()}",
            color = GrapheneElectricBlue,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        BrutalistHeader("FACILITY STATS")
        Spacer(modifier = Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneLightGray)
                .background(GrapheneGraphite)
                .padding(12.dp)
        ) {
            Text(text = "EXACT ADDRESS: ${venue.exactAddress}", color = GrapheneOffWhite, fontSize = 12.sp)
            Text(text = "ROOMS: ${venue.rooms}", color = GrapheneSilver, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            Text(text = "TRANSPORTATION: ${venue.transport}", color = GrapheneSilver, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
