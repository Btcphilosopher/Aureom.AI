package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "artists")
data class ArtistEntity(
    @PrimaryKey val artistId: Long,
    val name: String,
    val bio: String,
    val genre: String,
    val followersCount: Int,
    val isFollowed: Boolean = false,
    val bannerUrl: String = ""
)

@Entity(tableName = "venues")
data class VenueEntity(
    @PrimaryKey val venueId: Long,
    val name: String,
    val city: String,
    val area: String,
    val capacity: Int,
    val coordinates: String, // e.g. "51.5074, -0.1278"
    val addressVisibility: String, // PUBLIC, POST_PURCHASE, SECRET
    val exactAddress: String,
    val accessibility: String,
    val transport: String,
    val rooms: String // Comma-separated list of rooms: "Main Room, Basement, Courtyard"
)

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey val eventId: Long,
    val slug: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val eventType: String, // RAVE, CLUB_NIGHT, LISTENING_PARTY, etc.
    val status: String, // DRAFT, HOLD, CONFIRMED, ANNOUNCED, ON_SALE, SOLD_OUT, DOORS_OPEN, LIVE, COMPLETED, ARCHIVED
    val visibility: String, // PUBLIC, UNLISTED, PRIVATE, SECRET
    val promoterId: Long,
    val venueId: Long,
    val cityId: String,
    val sceneId: String,
    val startDateTime: Long, // timestamp
    val endDateTime: Long,
    val doorsDateTime: Long,
    val locationVisibility: String, // PUBLIC, AREA_ONLY, POST_PURCHASE, INVITATION_ONLY
    val agePolicy: String,
    val capacity: Int,
    val currentAttendance: Int,
    val artworkUrl: String,
    val genre: String,
    val tags: String, // Comma-separated
    val safetyInformation: String,
    val transportInformation: String,
    val lineup: String, // Comma-separated list of artist IDs
    val timetable: String // Line-break separated list: "22:00 - Doors\n23:00 - Support\n01:30 - DJ X"
)

@Entity(tableName = "ticket_types")
data class TicketTypeEntity(
    @PrimaryKey val ticketTypeId: Long,
    val eventId: Long,
    val name: String, // EARLY_BIRD, GENERAL_RELEASE, LATE_RELEASE, VIP
    val price: Double, // Real price
    val allocation: Int,
    val sold: Int
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val ticketId: String,
    val eventId: Long,
    val ticketTypeId: Long,
    val userId: String,
    val status: String, // ISSUED, TRANSFERRED, CHECKED_IN, REFUNDED, VOID
    val qrToken: String,
    val purchaseTime: Long
)

@Entity(tableName = "guest_list_entries")
data class GuestListEntryEntity(
    @PrimaryKey val entryId: Long,
    val eventId: Long,
    val name: String,
    val category: String, // artist guest, press, staff, VIP, industry
    val plusOne: Int,
    val status: String, // PENDING, CHECKED_IN
    val notes: String
)

@Entity(tableName = "incidents")
data class IncidentEntity(
    @PrimaryKey val incidentId: Long,
    val eventId: Long,
    val type: String, // MEDICAL, SECURITY, TECHNICAL, CAPACITY
    val severity: String, // LOW, MEDIUM, HIGH
    val status: String, // OPEN, INVESTIGATING, RESOLVED
    val description: String,
    val timestamp: Long
)

@Entity(tableName = "event_memories")
data class EventMemoryEntity(
    @PrimaryKey val memoryId: Long,
    val eventId: Long,
    val finalLineup: String,
    val attendance: Int,
    val reviews: String,
    val photosUrl: String // Comma-separated lists of local/generated resources
)

@Entity(tableName = "follows")
data class FollowEntity(
    @PrimaryKey val artistId: Long,
    val timestamp: Long
)
