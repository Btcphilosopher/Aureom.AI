package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GrapheneDao {

    // --- ARTISTS ---
    @Query("SELECT * FROM artists ORDER BY name ASC")
    fun getAllArtists(): Flow<List<ArtistEntity>>

    @Query("SELECT * FROM artists WHERE artistId = :artistId")
    suspend fun getArtistById(artistId: Long): ArtistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtists(artists: List<ArtistEntity>)

    @Query("UPDATE artists SET isFollowed = :isFollowed WHERE artistId = :artistId")
    suspend fun updateFollowStatus(artistId: Long, isFollowed: Boolean)

    // --- VENUES ---
    @Query("SELECT * FROM venues ORDER BY name ASC")
    fun getAllVenues(): Flow<List<VenueEntity>>

    @Query("SELECT * FROM venues WHERE venueId = :venueId")
    suspend fun getVenueById(venueId: Long): VenueEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVenues(venues: List<VenueEntity>)

    // --- EVENTS ---
    @Query("SELECT * FROM events ORDER BY startDateTime ASC")
    fun getAllEvents(): Flow<List<EventEntity>>

    @Query("SELECT * FROM events WHERE eventId = :eventId")
    suspend fun getEventById(eventId: Long): EventEntity?

    @Query("SELECT * FROM events WHERE slug = :slug")
    suspend fun getEventBySlug(slug: String): EventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<EventEntity>)

    @Query("UPDATE events SET status = :status WHERE eventId = :eventId")
    suspend fun updateEventStatus(eventId: Long, status: String)

    @Query("UPDATE events SET currentAttendance = :attendance WHERE eventId = :eventId")
    suspend fun updateEventAttendance(eventId: Long, attendance: Int)

    @Query("UPDATE events SET timetable = :timetable WHERE eventId = :eventId")
    suspend fun updateEventTimetable(eventId: Long, timetable: String)

    // --- TICKET TYPES ---
    @Query("SELECT * FROM ticket_types WHERE eventId = :eventId")
    fun getTicketTypesForEvent(eventId: Long): Flow<List<TicketTypeEntity>>

    @Query("SELECT * FROM ticket_types WHERE ticketTypeId = :ticketTypeId")
    suspend fun getTicketTypeById(ticketTypeId: Long): TicketTypeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicketTypes(types: List<TicketTypeEntity>)

    @Query("UPDATE ticket_types SET sold = :sold WHERE ticketTypeId = :ticketTypeId")
    suspend fun updateTicketTypeSold(ticketTypeId: Long, sold: Int)

    // --- TICKETS (USER WALLET & SCANNER) ---
    @Query("SELECT * FROM tickets ORDER BY purchaseTime DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Query("SELECT * FROM tickets WHERE ticketId = :ticketId")
    suspend fun getTicketById(ticketId: String): TicketEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET status = :status WHERE ticketId = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, status: String)

    // --- GUEST LIST ---
    @Query("SELECT * FROM guest_list_entries WHERE eventId = :eventId")
    fun getGuestListForEvent(eventId: Long): Flow<List<GuestListEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGuestListEntry(entry: GuestListEntryEntity)

    @Query("UPDATE guest_list_entries SET status = :status WHERE entryId = :entryId")
    suspend fun updateGuestStatus(entryId: Long, status: String)

    // --- INCIDENTS ---
    @Query("SELECT * FROM incidents WHERE eventId = :eventId ORDER BY timestamp DESC")
    fun getIncidentsForEvent(eventId: Long): Flow<List<IncidentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: IncidentEntity)

    @Query("UPDATE incidents SET status = :status WHERE incidentId = :incidentId")
    suspend fun updateIncidentStatus(incidentId: Long, status: String)

    // --- MEMORIES ---
    @Query("SELECT * FROM event_memories WHERE eventId = :eventId")
    suspend fun getMemoryForEvent(eventId: Long): EventMemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: EventMemoryEntity)
}
