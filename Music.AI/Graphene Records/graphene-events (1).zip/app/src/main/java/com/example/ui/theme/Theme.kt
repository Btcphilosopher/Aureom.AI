package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val GrapheneColorScheme = darkColorScheme(
    primary = GrapheneAcidGreen,
    secondary = GrapheneFuchsia,
    tertiary = GrapheneElectricBlue,
    background = GrapheneBlack,
    surface = GrapheneGraphite,
    onPrimary = GrapheneBlack,
    onSecondary = GrapheneOffWhite,
    onTertiary = GrapheneOffWhite,
    onBackground = GrapheneOffWhite,
    onSurface = GrapheneOffWhite,
    error = GrapheneRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme for underground aesthetics
    dynamicColor: Boolean = false, // Force Graphene brand colors instead of wallpaper colors
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GrapheneColorScheme,
        typography = Typography,
        content = content
    )
}
