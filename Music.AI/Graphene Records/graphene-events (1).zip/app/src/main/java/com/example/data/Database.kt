package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ArtistEntity::class,
        VenueEntity::class,
        EventEntity::class,
        TicketTypeEntity::class,
        TicketEntity::class,
        GuestListEntryEntity::class,
        IncidentEntity::class,
        EventMemoryEntity::class,
        FollowEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GrapheneDatabase : RoomDatabase() {
    abstract fun dao(): GrapheneDao

    companion object {
        @Volatile
        private var INSTANCE: GrapheneDatabase? = null

        fun getDatabase(context: Context): GrapheneDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GrapheneDatabase::class.java,
                    "graphene_events_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
