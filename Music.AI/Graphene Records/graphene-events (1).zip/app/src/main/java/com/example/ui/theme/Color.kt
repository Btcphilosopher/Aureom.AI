package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GrapheneBlack = Color(0xFF000000)
val GrapheneDarkGray = Color(0xFF0F0F0F)
val GrapheneGraphite = Color(0xFF161616)
val GrapheneMediumGray = Color(0xFF242424)
val GrapheneLightGray = Color(0xFF323232)
val GrapheneSilver = Color(0xFFC0C0C0)
val GrapheneOffWhite = Color(0xFFF0F0F0)

// Branded Accents
val GrapheneAcidGreen = Color(0xFF00FF66)  // neon green
val GrapheneElectricBlue = Color(0xFF0066FF) // tech blue
val GrapheneFuchsia = Color(0xFFFF007F)      // energy pink
val GrapheneRed = Color(0xFFFF2233)          // danger red
val GrapheneAmber = Color(0xFFFFB300)        // alert yellow
