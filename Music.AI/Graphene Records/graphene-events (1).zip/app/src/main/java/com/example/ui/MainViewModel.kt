package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

// Enum representing the current user role/app mode
enum class GrapheneRole {
    ATTENDEE,
    PROMOTER,
    DOOR_STAFF,
    ARTIST,
    VENUE_STAFF
}

// Model for recommendation explanation
data class DiscoveryExplanation(
    val score: Int,
    val factors: List<String>
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GrapheneRepository

    init {
        val database = GrapheneDatabase.getDatabase(application)
        repository = GrapheneRepository(database.dao())
        
        // Populate initial synthetic seed data
        viewModelScope.launch {
            repository.seedDatabaseIfNeeded()
        }
    }

    // --- NAVIGATION & MODE STATE ---
    private val _currentRole = MutableStateFlow(GrapheneRole.ATTENDEE)
    val currentRole: StateFlow<GrapheneRole> = _currentRole.asStateFlow()

    private val _selectedEventId = MutableStateFlow<Long?>(null)
    val selectedEventId: StateFlow<Long?> = _selectedEventId.asStateFlow()

    private val _selectedArtistId = MutableStateFlow<Long?>(null)
    val selectedArtistId: StateFlow<Long?> = _selectedArtistId.asStateFlow()

    private val _selectedVenueId = MutableStateFlow<Long?>(null)
    val selectedVenueId: StateFlow<Long?> = _selectedVenueId.asStateFlow()

    private val _activeTab = MutableStateFlow("discover") // "discover", "wallet", "search", "promoter", "door"
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    // --- SEARCH & FILTER ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTagFilter = MutableStateFlow<String?>(null)
    val selectedTagFilter: StateFlow<String?> = _selectedTagFilter.asStateFlow()

    // --- OFFLINE SIMULATION ---
    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    private val _isSynchronizing = MutableStateFlow(false)
    val isSynchronizing: StateFlow<Boolean> = _isSynchronizing.asStateFlow()

    // --- NOTIFICATION BANNER TICKER ---
    private val _notifications = MutableStateFlow<List<String>>(
        listOf(
            "WELCOME TO THE GRAPHENE LIVE CULTURE PLATFORM.",
            "ALERT: GRAPHENE AFTER DARK WAREHOUSE SESSION TICKETS SELLING RAPIDLY.",
            "INFO: SOUNDSYSTEM COMPLIANCE CHECKS PASSED FOR VORTEX."
        )
    )
    val notifications: StateFlow<List<String>> = _notifications.asStateFlow()

    // --- SEED OBSERVABLES ---
    val artists: StateFlow<List<ArtistEntity>> = repository.allArtists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val venues: StateFlow<List<VenueEntity>> = repository.allVenues
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val events: StateFlow<List<EventEntity>> = repository.allEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getTicketTypesForEvent(eventId: Long): Flow<List<TicketTypeEntity>> {
        return repository.getTicketTypesForEvent(eventId)
    }

    fun getGuestListForEvent(eventId: Long): Flow<List<GuestListEntryEntity>> {
        return repository.getGuestListForEvent(eventId)
    }

    // --- COMBINED RECOMMENDATIONS & SEARCH RESULTS ---
    val filteredEvents: StateFlow<List<EventEntity>> = combine(
        events, searchQuery, selectedTagFilter
    ) { eventList, query, tag ->
        eventList.filter { event ->
            val matchesQuery = query.isEmpty() || 
                event.title.contains(query, ignoreCase = true) ||
                event.subtitle.contains(query, ignoreCase = true) ||
                event.genre.contains(query, ignoreCase = true) ||
                event.tags.contains(query, ignoreCase = true)
            
            val matchesTag = tag == null || event.tags.contains(tag, ignoreCase = true)
            
            matchesQuery && matchesTag
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- DOOR / SCAN STATE ---
    private val _doorScanResult = MutableStateFlow<String?>(null) // "VALID", "INVALID", "ALREADY_USED", "OFFLINE_VERIFIED"
    val doorScanResult: StateFlow<String?> = _doorScanResult.asStateFlow()

    private val _doorScannedTicket = MutableStateFlow<TicketEntity?>(null)
    val doorScannedTicket: StateFlow<TicketEntity?> = _doorScannedTicket.asStateFlow()

    // --- INCIDENTS ---
    private val _activeIncidents = MutableStateFlow<List<IncidentEntity>>(emptyList())
    val activeIncidents: StateFlow<List<IncidentEntity>> = _activeIncidents.asStateFlow()

    // --- FUNCTIONS ---
    fun selectRole(role: GrapheneRole) {
        _currentRole.value = role
        when (role) {
            GrapheneRole.ATTENDEE -> _activeTab.value = "discover"
            GrapheneRole.PROMOTER -> _activeTab.value = "promoter"
            GrapheneRole.DOOR_STAFF -> _activeTab.value = "door"
            GrapheneRole.ARTIST -> _activeTab.value = "discover"
            GrapheneRole.VENUE_STAFF -> _activeTab.value = "discover"
        }
    }

    fun selectTab(tab: String) {
        _activeTab.value = tab
        _selectedEventId.value = null
        _selectedArtistId.value = null
        _selectedVenueId.value = null
    }

    fun selectEvent(eventId: Long?) {
        _selectedEventId.value = eventId
    }

    fun selectArtist(artistId: Long?) {
        _selectedArtistId.value = artistId
    }

    fun selectVenue(venueId: Long?) {
        _selectedVenueId.value = venueId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setTagFilter(tag: String?) {
        _selectedTagFilter.value = tag
    }

    fun toggleOfflineMode() {
        viewModelScope.launch {
            if (_isOfflineMode.value) {
                // Synch back
                _isSynchronizing.value = true
                kotlinx.coroutines.delay(1200) // simulated sync latency
                _isSynchronizing.value = false
                pushNotification("OFFLINE LOGS SYNCHRONIZED DETERMINISTICALLY.")
            } else {
                pushNotification("RUNNING IN OFFLINE DOOR-CACHE CACHED MODE.")
            }
            _isOfflineMode.value = !_isOfflineMode.value
        }
    }

    fun pushNotification(text: String) {
        _notifications.value = listOf(text.uppercase()) + _notifications.value
    }

    // --- THE DISCOVERY SCORE CALCULATION (EXPLAINABLE ENGINE) ---
    fun calculateDiscoveryExplanation(event: EventEntity): DiscoveryExplanation {
        var score = 50 // Base score
        val factors = mutableListOf<String>()

        // 1. Followed artist affinity
        val artistList = event.lineup.split(",")
        var followsArtist = false
        artists.value.filter { it.isFollowed }.forEach { followedArtist ->
            if (artistList.contains(followedArtist.artistId.toString())) {
                followsArtist = true
            }
        }
        if (followsArtist) {
            score += 25
            factors.add("+25 Affined artist in lineup")
        }

        // 2. Scene / Genre affinity
        if (event.genre.contains("Acid", ignoreCase = true)) {
            score += 15
            factors.add("+15 Label core sound match (Acid)")
        } else if (event.genre.contains("Techno", ignoreCase = true)) {
            score += 10
            factors.add("+10 Techno movement affinity")
        }

        // 3. Size / Venue density (Underground rave size vs Massive)
        if (event.capacity < 200) {
            score += 10
            factors.add("+10 Intimate room density bonus")
        }

        // 4. Temporal fit (Tonight vs far in future)
        if (event.tags.contains("Tonight", ignoreCase = true)) {
            score += 20
            factors.add("+20 Instant temporal fit (Tonight)")
        }

        // 5. Editorial weight (Label showcase)
        if (event.eventType == "LABEL_NIGHT") {
            score += 15
            factors.add("+15 Official Graphene release label curator weight")
        }

        // Penalties (Oversaturation, Sold out)
        if (event.status == "SOLD_OUT") {
            score -= 30
            factors.add("-30 Restricted access (SOLD OUT)")
        }

        return DiscoveryExplanation(score.coerceIn(0, 100), factors)
    }

    // --- PURCHASE / TICKET FLUX ENGINE (TRANSACTIONAL LOCKING) ---
    fun purchaseTicket(event: EventEntity, ticketType: TicketTypeEntity) {
        viewModelScope.launch {
            if (_isOfflineMode.value) {
                pushNotification("CANNOT PURCHASE TICKETS: TRANSACTIONS LOCKING REQUIRES ENFORCED CONNECTION.")
                return@launch
            }

            // Check inventory capacity
            if (ticketType.sold >= ticketType.allocation) {
                pushNotification("PURCHASE FAILED: SOLD OUT EXCEEDED.")
                return@launch
            }

            // Update ticket type sold count
            repository.updateTicketTypeSold(ticketType.ticketTypeId, ticketType.sold + 1)

            // Generate unique verifiable signed ticket QR token
            val ticketId = "GTKT-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
            val qrToken = "GRAPHENE_SIG_SECURE_TOKEN_" + UUID.randomUUID().toString().substring(0, 12)
            
            val newTicket = TicketEntity(
                ticketId = ticketId,
                eventId = event.eventId,
                ticketTypeId = ticketType.ticketTypeId,
                userId = "G-ATTENDEE-007",
                status = "ISSUED",
                qrToken = qrToken,
                purchaseTime = System.currentTimeMillis()
            )

            repository.insertTicket(newTicket)
            pushNotification("PURCHASED: ${ticketType.name} TICKET FOR ${event.title}.")
            
            // Increment current event attendance capacity estimation
            val updatedEvent = repository.getEventById(event.eventId)
            if (updatedEvent != null) {
                repository.updateEventAttendance(event.eventId, updatedEvent.currentAttendance + 1)
            }
        }
    }

    // --- TICKETS TRANSFER ---
    fun transferTicket(ticket: TicketEntity, email: String) {
        viewModelScope.launch {
            repository.updateTicketStatus(ticket.ticketId, "TRANSFERRED")
            pushNotification("TICKET ${ticket.ticketId} TRANSFERRED TO ${email.uppercase()}.")
        }
    }

    // --- GUEST LIST ADD ---
    fun addGuestListEntry(eventId: Long, name: String, category: String, notes: String) {
        viewModelScope.launch {
            val entryId = System.currentTimeMillis()
            val entry = GuestListEntryEntity(
                entryId = entryId,
                eventId = eventId,
                name = name,
                category = category,
                plusOne = 1,
                status = "PENDING",
                notes = notes
            )
            repository.insertGuestListEntry(entry)
            pushNotification("GUEST LIST ADDED: ${name.uppercase()} (${category.uppercase()})")
        }
    }

    // --- GUEST CHECK IN ---
    fun checkInGuest(entry: GuestListEntryEntity) {
        viewModelScope.launch {
            repository.updateGuestStatus(entry.entryId, "CHECKED_IN")
            pushNotification("GUEST CHECKED IN: ${entry.name.uppercase()}")
        }
    }

    // --- QR TICKET VALIDATOR (DOOR CODE PROCESSOR) ---
    fun simulateDoorScan(qrCodeText: String) {
        viewModelScope.launch {
            _doorScanResult.value = null
            _doorScannedTicket.value = null

            // Find ticket matching the qr token or exact code ID
            val cleanToken = qrCodeText.trim()
            val allTkts = repository.allTickets.firstOrNull() ?: emptyList()
            val foundTicket = allTkts.find { it.qrToken == cleanToken || it.ticketId == cleanToken }

            if (foundTicket == null) {
                _doorScanResult.value = "INVALID"
                pushNotification("SCAN FAILED: UNRECOGNIZED TOKEN SIGNATURE.")
                return@launch
            }

            if (foundTicket.status == "CHECKED_IN") {
                _doorScanResult.value = "ALREADY_USED"
                _doorScannedTicket.value = foundTicket
                pushNotification("SCAN WARNING: DUPLICATE ENTRY FOR ${foundTicket.ticketId}.")
                return@launch
            }

            if (foundTicket.status == "TRANSFERRED") {
                _doorScanResult.value = "REVOKED"
                _doorScannedTicket.value = foundTicket
                pushNotification("SCAN REJECTED: TICKET MARKED TRANSFERRED.")
                return@launch
            }

            // Valid!
            repository.updateTicketStatus(foundTicket.ticketId, "CHECKED_IN")
            
            // Check offline mode
            if (_isOfflineMode.value) {
                _doorScanResult.value = "OFFLINE_VERIFIED"
            } else {
                _doorScanResult.value = "VALID"
            }
            _doorScannedTicket.value = foundTicket

            // Trigger attendance count
            val currentEv = repository.getEventById(foundTicket.eventId)
            if (currentEv != null) {
                repository.updateEventAttendance(foundTicket.eventId, currentEv.currentAttendance + 1)
            }
            pushNotification("SCAN SUCCESSFUL: ADMIT ATTENDEE [${foundTicket.ticketId}].")
        }
    }

    fun clearDoorScan() {
        _doorScanResult.value = null
        _doorScannedTicket.value = null
    }

    // --- TIMELINE MANAGEMENT (STAGE CONTROL) ---
    fun updateTimetable(eventId: Long, newTimetable: String) {
        viewModelScope.launch {
            repository.updateEventTimetable(eventId, newTimetable)
            pushNotification("TIMELINE RECALIBRATED: SCHEDULE ADAPTED.")
        }
    }

    // --- INCIDENT RECORDING ---
    fun reportIncident(eventId: Long, type: String, severity: String, description: String) {
        viewModelScope.launch {
            val incidentId = System.currentTimeMillis()
            val newIncident = IncidentEntity(
                incidentId = incidentId,
                eventId = eventId,
                type = type,
                severity = severity,
                status = "OPEN",
                description = description,
                timestamp = System.currentTimeMillis()
            )
            repository.insertIncident(newIncident)
            
            // Update local state flow
            val updated = _activeIncidents.value.toMutableList()
            updated.add(0, newIncident)
            _activeIncidents.value = updated

            pushNotification("INCIDENT REGISTERED: ${severity.uppercase()} [${type.uppercase()}] REPORT.")
        }
    }

    fun updateIncidentStatus(incidentId: Long, status: String) {
        viewModelScope.launch {
            repository.updateIncidentStatus(incidentId, status)
            val updated = _activeIncidents.value.map {
                if (it.incidentId == incidentId) it.copy(status = status) else it
            }
            _activeIncidents.value = updated
            pushNotification("INCIDENT RESOLVED/MODIFIED STATUS UPDATED.")
        }
    }

    // --- FOLLOWER GRAPH MANAGEMENT ---
    fun toggleFollowArtist(artistId: Long) {
        viewModelScope.launch {
            val art = repository.getArtistById(artistId)
            if (art != null) {
                val nextState = !art.isFollowed
                repository.updateFollowStatus(artistId, nextState)
                pushNotification(if (nextState) "FOLLOWING: ${art.name.uppercase()}" else "UNFOLLOWED: ${art.name.uppercase()}")
            }
        }
    }

    // --- METRICS / ACCOUNTING CALCULATOR FOR ACTIVE PROMOTER ---
    fun getEconomicsForEvent(event: EventEntity, ticketsTypes: List<TicketTypeEntity>): Map<String, Double> {
        var grossSales = 0.0
        var totalTicketsSold = 0
        ticketsTypes.forEach { type ->
            grossSales += type.sold * type.price
            totalTicketsSold += type.sold
        }

        val platformFees = grossSales * 0.05
        val cardProcessingFees = grossSales * 0.02
        val artistCosts = 1500.0 // Synthetic static booking cost
        val venueProductionCosts = 800.0 // Sound compliance and security
        val netRevenue = grossSales - platformFees - cardProcessingFees - artistCosts - venueProductionCosts

        return mapOf(
            "grossSales" to grossSales,
            "totalSold" to totalTicketsSold.toDouble(),
            "platformFees" to platformFees,
            "cardProcessing" to cardProcessingFees,
            "artistBooking" to artistCosts,
            "production" to venueProductionCosts,
            "netRevenue" to netRevenue
        )
    }
}
