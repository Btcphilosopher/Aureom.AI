import type {Metadata} from 'next';
import { Syne, Space_Grotesk } from 'next/font/google';
import './globals.css'; // Global styles

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['400', '700', '800'],
  display: 'swap',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  weight: ['300', '400', '500', '600', '700'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Graphene Records | Music at the Molecular Level',
  description: 'Futuristic independent record label, music technology firm, and underground electronic music platform.',
  openGraph: {
    title: 'Graphene Records | Music at the Molecular Level',
    description: 'Futuristic independent record label, music technology firm, and underground electronic music platform.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Graphene Records',
    description: 'Futuristic independent record label, music technology firm, and underground electronic music platform.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${syne.variable} ${spaceGrotesk.variable}`}>
      <body suppressHydrationWarning className="bg-[#050505] text-white antialiased font-space selection:bg-[#00f3ff] selection:text-black">
        {children}
      </body>
    </html>
  );
}

