'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, ListMusic, 
  Maximize2, Minimize2, Search, SlidersHorizontal, ArrowUpRight, 
  Send, Plus, ShoppingBag, X, Globe, Radio, Sparkles, BookOpen, 
  Clock, CheckCircle, Disc, Filter, ArrowRight, Music, Inbox
} from 'lucide-react';

// --- TYPE DEFINITIONS ---
interface Track {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: string;
  genre: string;
  catNum: string;
  audioUrl?: string; // Optional real fallback or generative synth parameters
  color: string;
}

interface Artist {
  id: string;
  name: string;
  role: string;
  bio: string;
  portrait: string;
  latestRelease: string;
  discography: string[];
  upcoming: string;
  videos: string[];
  liveDates: { date: string; venue: string; city: string; soldOut: boolean }[];
  related: string[];
  socials: { spotify?: string; soundcloud?: string; instagram?: string; bandcamp?: string };
}

interface Release {
  catNum: string;
  artist: string;
  title: string;
  format: 'Vinyl (12")' | 'EP / Digital' | 'LP / Album' | 'Limited Cassette' | 'CD / Digital';
  releaseDate: string;
  genre: string;
  image: string;
  year: number;
  tracklist: string[];
}

interface Article {
  id: number;
  category: string;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  image: string;
}

interface Product {
  id: number;
  name: string;
  price: string;
  category: 'Vinyl' | 'Apparel' | 'Cassette' | 'Art Prints';
  image: string;
  limited: boolean;
  specs: string;
}

export default function GrapheneRecordsHome() {
  // --- STATE MANAGEMENT ---
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.8);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(12);
  const [totalTime] = useState<number>(248); // 4:08 simulation
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);
  const [catalogView, setCatalogView] = useState<'visual' | 'technical'>('visual');
  const [releaseFilter, setReleaseFilter] = useState<string>('ALL');
  const [activeTab, setActiveTab] = useState<string>('HOME');
  const [isSubmitSuccess, setIsSubmitSuccess] = useState<boolean>(false);
  const [cart, setCart] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [radioActive, setRadioActive] = useState<boolean>(false);
  const [isFullscreenPlayer, setIsFullscreenPlayer] = useState<boolean>(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Web Audio Context & Audio Generator refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const synthTimerRef = useRef<any>(null);

  // Canvas Refs
  const heroCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const playerCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const radioCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Tracks Database
  const tracks: Track[] = [
    { id: 1, title: "COVALENT BOND", artist: "ANODE", album: "HEXAGONAL METRIC", duration: "4:08", genre: "Glitch / IDM", catNum: "GPHN-026", color: "from-cyan-400 to-blue-600" },
    { id: 2, title: "SPECTRAL SHELL", artist: "HELIUM DRIP", album: "EXCITED STATES", duration: "3:45", genre: "Avant-Pop / Club", catNum: "GPHN-027", color: "from-violet-500 to-fuchsia-600" },
    { id: 3, title: "ISOMER GRID", artist: "CYANIDE SOUL", album: "CARBON MATRIX", duration: "5:12", genre: "Experimental Bass", catNum: "GPHN-028", color: "from-magenta-500 to-rose-600" },
    { id: 4, title: "RESONANT WAVE", artist: "HEXAGONAL", album: "MOLECULAR SYMMETRY", duration: "4:30", genre: "Ambient Techno", catNum: "GPHN-029", color: "from-amber-400 to-yellow-600" },
    { id: 5, title: "CHALCOGENIDE", artist: "VIRTUAL STATIC", album: "CONDUCTIVE CORE", duration: "6:04", genre: "Deconstructed Club", catNum: "GPHN-030", color: "from-emerald-400 to-teal-600" },
  ];

  const currentTrack = tracks[currentTrackIndex];

  // Artists Database
  const artists: Artist[] = [
    {
      id: "anode",
      name: "ANODE",
      role: "IDM / Modular Synthesis / Sound Art",
      bio: "ANODE operates at the absolute frontier of generative synthesis. Harnessing modular systems and custom-engineered DSP algorithms, they sculpt auditory carbon grids that bridge the gap between high-frequency physics and low-end sensory weight.",
      portrait: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
      latestRelease: "HEXAGONAL METRIC (GPHN-026)",
      discography: ["Hexagonal Metric (2026)", "Atomic Decay (2025)", "Lattice Theory (2024)"],
      upcoming: "London Institute of Contemporary Arts - Solo Audio-Visual Performance (Dec 2026)",
      videos: ["Covalent Bond Live (MUTEK 2025)", "Molecular Resonance Studio Documentary"],
      liveDates: [
        { date: "24.10.26", venue: "FABRIC", city: "LONDON", soldOut: true },
        { date: "12.11.26", venue: "BERGHAIN / KANTINE", city: "BERLIN", soldOut: false },
        { date: "05.12.26", venue: "MUTANT BAR", city: "TOKYO", soldOut: true }
      ],
      related: ["HELIUM DRIP", "HEXAGONAL"],
      socials: { spotify: "#", soundcloud: "#", instagram: "#" }
    },
    {
      id: "helium-drip",
      name: "HELIUM DRIP",
      role: "Deconstructed Avant-Pop / Club Culture",
      bio: "HELIUM DRIP merges classical choral harmonies with volatile, deconstructed club rhythmic templates. Their music features highly polished metallic textures, crystal clear soprano vocal chains, and earth-shattering carbon sub-bass lines.",
      portrait: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=800",
      latestRelease: "EXCITED STATES (GPHN-027)",
      discography: ["Excited States (2026)", "Phase Shift EP (2025)"],
      upcoming: "Sonar Festival Showcase (2027)",
      videos: ["Spectral Shell (Official Music Video)", "Boiler Room: Graphene Records Special"],
      liveDates: [
        { date: "18.10.26", venue: "MUTANT STAGE", city: "PARIS", soldOut: true },
        { date: "15.11.26", venue: "S3", city: "AMSTERDAM", soldOut: false },
        { date: "18.12.26", venue: "WOMB", city: "TOKYO", soldOut: false }
      ],
      related: ["ANODE", "CYANIDE SOUL"],
      socials: { spotify: "#", soundcloud: "#", instagram: "#", bandcamp: "#" }
    },
    {
      id: "cyanide-soul",
      name: "CYANIDE SOUL",
      role: "Experimental Bass / Post-Industrial Soundscapes",
      bio: "CYANIDE SOUL is the dark carbon engine of the label. Sculpting heavy, abrasive industrial rhythmic noise and deep, subterranean sub-bass frequencies, they formulate tracks that feel physically imposing.",
      portrait: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&q=80&w=800",
      latestRelease: "CARBON MATRIX (GPHN-028)",
      discography: ["Carbon Matrix (2026)", "Heavy Isotope (2024)", "Kinetic Drag (2023)"],
      upcoming: "Berghain Clubnight Showcase (Oct 2026)",
      videos: ["Isomer Grid (Interactive AV Session)", "Acoustic Resonance at Brutalist Boiler"],
      liveDates: [
        { date: "29.10.26", venue: "BERGHAIN CLUB", city: "BERLIN", soldOut: true },
        { date: "10.12.26", venue: "UNDERGROUND DOME", city: "KYOTO", soldOut: false }
      ],
      related: ["ANODE", "VIRTUAL STATIC"],
      socials: { spotify: "#", instagram: "#" }
    },
    {
      id: "hexagonal",
      name: "HEXAGONAL",
      role: "Ambient Techno / Generative Spatial Systems",
      bio: "HEXAGONAL constructs deep, expansive soundscapes utilizing a proprietary multi-dimensional spatial sound engine. Their compositions unfold slowly like crystals forming, with each sound node positioned with precision in a virtual 3D environment.",
      portrait: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=800",
      latestRelease: "MOLECULAR SYMMETRY (GPHN-029)",
      discography: ["Molecular Symmetry (2026)", "Crystal Lattice (2025)"],
      upcoming: "MUTEK Montreal Special AV Integration (2027)",
      videos: ["Generative Lattice Live Performance", "Spatial Audio Lab Experiments"],
      liveDates: [
        { date: "04.11.26", venue: "VIRTUAL SANCTUARY", city: "METAVERSE", soldOut: false },
        { date: "22.12.26", venue: "DOME THEATRE", city: "MONTREAL", soldOut: true }
      ],
      related: ["ANODE", "HELIUM DRIP"],
      socials: { spotify: "#", bandcamp: "#" }
    }
  ];

  // Releases Database
  const releases: Release[] = [
    {
      catNum: "GPHN-026",
      artist: "ANODE",
      title: "HEXAGONAL METRIC",
      format: "Vinyl (12\")",
      releaseDate: "2026-08-14",
      genre: "Glitch / IDM",
      image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
      year: 2026,
      tracklist: ["Covalent Bond", "Pi Electron", "Valence Shell", "Symmetry Orbit", "Dirac Point"]
    },
    {
      catNum: "GPHN-027",
      artist: "HELIUM DRIP",
      title: "EXCITED STATES",
      format: "EP / Digital",
      releaseDate: "2026-07-02",
      genre: "Avant-Pop / Club",
      image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=800",
      year: 2026,
      tracklist: ["Spectral Shell", "Argon Mist", "Luminescence", "Ground State", "Isotope Decay"]
    },
    {
      catNum: "GPHN-028",
      artist: "CYANIDE SOUL",
      title: "CARBON MATRIX",
      format: "LP / Album",
      releaseDate: "2026-05-18",
      genre: "Experimental Bass",
      image: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&q=80&w=800",
      year: 2026,
      tracklist: ["Isomer Grid", "Heavy Carbon", "Abrasive State", "Graphene Sheet", "Synthetic Core"]
    },
    {
      catNum: "GPHN-029",
      artist: "HEXAGONAL",
      title: "MOLECULAR SYMMETRY",
      format: "Limited Cassette",
      releaseDate: "2025-11-09",
      genre: "Ambient Techno",
      image: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=800",
      year: 2025,
      tracklist: ["Resonant Wave", "Crystal Lattice", "Concentric Ring", "Sub-Kelvin Ambient", "Absolute Zero"]
    },
    {
      catNum: "GPHN-030",
      artist: "VIRTUAL STATIC",
      title: "CONDUCTIVE CORE",
      format: "LP / Album",
      releaseDate: "2025-06-25",
      genre: "Deconstructed Club",
      image: "https://images.unsplash.com/photo-1500462918059-b1a0cb512f1d?auto=format&fit=crop&q=80&w=800",
      year: 2025,
      tracklist: ["Chalcogenide", "Signal Interference", "Dynamic Range", "Anisotropic Flow"]
    }
  ];

  // Graphene Journal Articles
  const journalArticles: Article[] = [
    {
      id: 1,
      category: "STUDIO CULTURE",
      title: "SCULPTING SOUND AT THE ANSTROM SCALE: INSIDE THE GRAPHENE LAB",
      excerpt: "An intimate look into Graphene Records' research facility, where custom modular synthesizers are developed using state-of-the-art silicon and graphite processors to achieve pure analog depth.",
      readTime: "8 MIN READ",
      date: "04.09.2026",
      image: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=800"
    },
    {
      id: 2,
      category: "CULTURE & FUTURE",
      title: "POST-CLUB ARCHITECTURES: HOW EXPERIMENTAL VENUES IN 2026 RESTRUCTURE FREQUENCY",
      excerpt: "Investigating the emergence of multi-directional acoustic spaces in Tokyo and Berlin, designed explicitly around molecular geometry to deliver zero-phase cancellation sub bass.",
      readTime: "12 MIN READ",
      date: "28.08.2026",
      image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=800"
    },
    {
      id: 3,
      category: "ARTIST TALK",
      title: "THE QUANTUM DISSONANCE: IN CONVERSATION WITH ANODE",
      excerpt: "The mysterious synthesist unpacks their upcoming audiovisual masterwork, explaining how atomic collision theory guides the frequency modulation of their custom Eurorack racks.",
      readTime: "15 MIN READ",
      date: "14.08.2026",
      image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=800"
    }
  ];

  // Merch Store products
  const products: Product[] = [
    { id: 101, name: "ANODE: HEXAGONAL METRIC (12\" CLEAR VINYL)", price: "$35.00", category: "Vinyl", image: "https://images.unsplash.com/photo-1539625319135-8d1b9e788c1a?auto=format&fit=crop&q=80&w=800", limited: true, specs: "180g Ultra-clear hand-poured vinyl. Transparent hexagonal polybag sleeve with iridescent foil-stamped technical labels. Limited to 250 copies worldwide." },
    { id: 102, name: "GRAPHENE LOGO CORE GRAPHITE PARKA", price: "$180.00", category: "Apparel", image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=800", limited: true, specs: "Constructed using water-resistant diamond ripstop carbon nylon mesh. Embroidered tonal Graphene Records logo at chest, conductive headphone cable sleeve." },
    { id: 103, name: "HELIUM DRIP: EXCITED STATES (CHALCOGENIDE TAPE)", price: "$18.00", category: "Cassette", image: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&q=80&w=800", limited: false, specs: "Metallic silver cassette shell with UV-printed neon-cyan molecular graphics. High-bias cobalt tape formula for crystal clear high-frequency audio response." },
    { id: 104, name: "GRAPHENE LATTICE TECHNICAL SCREENPRINT ART PRINT", price: "$45.00", category: "Art Prints", image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&q=80&w=800", limited: true, specs: "Silkscreened on heavyweight 350gsm carbon-black archival card. Metallic silver and iridescent refractive inks mapping out a highly detailed molecular grid." }
  ];

  // Handle subtle mouse movements for cinematic parallax / particle interactions
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth - 0.5) * 30,
        y: (e.clientY / window.innerHeight - 0.5) * 30,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // --- AUDIO SYNTH ENGINE (WEB AUDIO API) ---
  // Generates real futuristic electronic synthesizer sounds in real time!
  const startAudioSynth = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Create generator loop simulating a minimal, hypnotic futuristic modular synth
      let step = 0;
      const notes = [110, 165, 220, 330, 440, 220, 165, 110]; // Sophisticated minimal A-minor/hexatonic frequencies
      
      const playStep = () => {
        if (!isPlaying) return;
        
        const note = notes[step % notes.length];
        
        // Osc
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        // Triangle wave for deep analog feel
        osc.type = step % 4 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(note * (Math.random() > 0.85 ? 2 : 1), ctx.currentTime);
        
        // Extreme narrow bandpass filter for clinical precision
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(800 + Math.sin(step) * 400, ctx.currentTime);
        filter.Q.setValueAtTime(4, ctx.currentTime);

        // Gain Envelope
        gain.gain.setValueAtTime(0.001, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(volume * 0.15, ctx.currentTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
        
        step++;
        synthTimerRef.current = setTimeout(playStep, 250); // 120BPM 16th/8th notes
      };
      
      playStep();
    } catch (e) {
      console.warn("Audio Context init error or unsupported: ", e);
    }
  };

  const stopAudioSynth = () => {
    if (synthTimerRef.current) {
      clearTimeout(synthTimerRef.current);
    }
  };

  // Synchronize audio states
  useEffect(() => {
    if (isPlaying) {
      startAudioSynth();
      
      // Update simulated progress bar
      const interval = setInterval(() => {
        setCurrentTime((prev) => (prev >= totalTime ? 0 : prev + 1));
      }, 1000);
      return () => {
        clearInterval(interval);
        stopAudioSynth();
      };
    } else {
      stopAudioSynth();
    }
  }, [isPlaying, currentTrackIndex]);

  // Adjust volume of live synthesizer
  useEffect(() => {
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setValueAtTime(isMuted ? 0 : volume, audioCtxRef.current.currentTime);
    }
  }, [volume, isMuted]);

  // --- HERO CANVAS LATTICE ANIMATION ---
  // Beautiful interactive background showing shifting carbon lattices, waves, and fields
  useEffect(() => {
    const canvas = heroCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    // Grid nodes
    const cols = 24;
    const rows = 14;
    const spacingX = width / cols;
    const spacingY = height / rows;
    
    let time = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      time += isPlaying ? 0.015 : 0.006;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;

      // Draw shifting horizontal / hexagonal interconnected carbon mesh
      for (let r = 0; r < rows; r++) {
        ctx.beginPath();
        for (let c = 0; c < cols; c++) {
          // Add complex physics equations for waves, electromagnetic fields, and sound vibrations
          const waveX = Math.sin(time + c * 0.2 + r * 0.1) * 15;
          const waveY = Math.cos(time + r * 0.3 + c * 0.15) * 15;

          // Sound wave interference overlay if music plays
          const soundImpact = isPlaying ? Math.sin(time * 3 + c * 0.5) * 10 : 0;

          const x = c * spacingX + waveX;
          const y = r * spacingY + waveY + soundImpact;

          if (c === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }

          // Draw molecular hexagonal nodes
          if (c % 2 === 0 && r % 2 === 0) {
            ctx.fillStyle = 'rgba(0, 243, 255, 0.3)';
            // Subtle glowing gold highlights or iridescent cyan highlights
            if ((c + r) % 6 === 0) {
              ctx.fillStyle = 'rgba(191, 85, 236, 0.5)'; // Violet
            } else if ((c + r) % 8 === 0) {
              ctx.fillStyle = 'rgba(255, 215, 0, 0.5)'; // Gold
            }
            ctx.beginPath();
            ctx.arc(x, y, 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.stroke();
      }

      // Draw subtle overlapping electromagnetic orbits (concentric vinyl geometry)
      ctx.strokeStyle = 'rgba(0, 243, 255, 0.02)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 280 + Math.sin(time) * 40, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(216, 85, 236, 0.02)';
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 450 + Math.cos(time * 0.8) * 60, 0, Math.PI * 2);
      ctx.stroke();

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [isPlaying]);

  // --- PERSISTENT PLAYER WAVEFORM & MOLECULAR VISUALIZATION ---
  useEffect(() => {
    const canvas = playerCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    const height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
    };
    window.addEventListener('resize', handleResize);

    let phase = 0;
    const renderPlayerWave = () => {
      ctx.clearRect(0, 0, width, height);
      phase += isPlaying ? 0.08 : 0.02;

      // Clean tech grid in background
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.02)';
      ctx.lineWidth = 1;
      for (let i = 0; i < width; i += 30) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
      }

      // Draw wave responding visually
      const amp = isPlaying ? 24 : 6;
      ctx.strokeStyle = 'rgba(0, 243, 255, 0.85)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      
      for (let x = 0; x < width; x++) {
        const angle = (x / width) * Math.PI * 5 + phase;
        // Fine micro-particle waves
        const y = height / 2 + Math.sin(angle) * amp * Math.sin(x / width * Math.PI);
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();

      // Second harmonic overlay wave (Violet / Holographic)
      ctx.strokeStyle = 'rgba(191, 85, 236, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x < width; x++) {
        const angle = (x / width) * Math.PI * 7 - phase * 1.3;
        const y = height / 2 + Math.cos(angle) * (amp * 0.75) * Math.sin(x / width * Math.PI);
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();

      // Live molecular / particle visualization responding to play frequency
      if (isPlaying) {
        // High frequency fine particles
        ctx.fillStyle = 'rgba(0, 243, 255, 0.8)';
        for (let p = 0; p < 8; p++) {
          const px = (width / 2) + Math.cos(phase + p * 2) * (120 + Math.sin(phase) * 30);
          const py = (height / 2) + Math.sin(phase * 1.5 + p) * 15;
          ctx.beginPath();
          ctx.arc(px, py, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Bass structural hex molecule movement in center background
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = 35 + Math.sin(phase * 4) * 4; // structural bass expand
        for (let side = 0; side <= 6; side++) {
          const angle = (side * Math.PI) / 3;
          const hx = centerX + Math.cos(angle) * radius;
          const hy = centerY + Math.sin(angle) * radius;
          if (side === 0) ctx.moveTo(hx, hy);
          else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.stroke();
      }

      animationFrameId = requestAnimationFrame(renderPlayerWave);
    };

    renderPlayerWave();
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [isPlaying]);

  // --- RADIO CONTINUOUS GRAPHICS VISUALIZER ---
  useEffect(() => {
    if (activeTab !== 'RADIO') return;
    const canvas = radioCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    const width = (canvas.width = canvas.offsetWidth);
    const height = (canvas.height = canvas.offsetHeight);

    let rPhase = 0;
    const renderRadioGraphics = () => {
      ctx.clearRect(0, 0, width, height);
      rPhase += 0.05;

      // Draw frequency spectrum analyzer bars (Clinical terminal design)
      const barWidth = 3;
      const spacing = 4;
      const numBars = Math.floor(width / (barWidth + spacing));

      for (let i = 0; i < numBars; i++) {
        // High variation heights using math sine/random combinations
        const baseH = Math.sin(rPhase + i * 0.1) * 30 + 40;
        const noise = Math.random() * 20 - 10;
        const barHeight = Math.max(5, baseH + noise + (radioActive ? Math.sin(rPhase * 5 + i) * 35 : 0));

        const x = i * (barWidth + spacing);
        const y = height - barHeight;

        // Custom iridescent styling colors based on frequency bands
        if (i < numBars * 0.4) {
          ctx.fillStyle = 'rgba(0, 243, 255, 0.8)'; // Cyan low-ends
        } else if (i < numBars * 0.75) {
          ctx.fillStyle = 'rgba(191, 85, 236, 0.8)'; // Violet mids
        } else {
          ctx.fillStyle = 'rgba(255, 215, 0, 0.8)'; // Gold highs
        }

        ctx.fillRect(x, y, barWidth, barHeight);
      }

      // Draw concentric signal radar arcs in center
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 80 + Math.sin(rPhase * 0.5) * 20, 0, Math.PI * 2);
      ctx.stroke();

      animationFrameId = requestAnimationFrame(renderRadioGraphics);
    };

    renderRadioGraphics();
    return () => cancelAnimationFrame(animationFrameId);
  }, [activeTab, radioActive]);

  // --- ACTIONS ---
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const selectAndPlayTrack = (index: number) => {
    setCurrentTrackIndex(index);
    setIsPlaying(true);
  };

  const handleNextTrack = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % tracks.length);
    setIsPlaying(true);
  };

  const handlePrevTrack = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
    setIsPlaying(true);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const addToCart = (product: Product) => {
    setCart((prev) => [...prev, product]);
    setIsCartOpen(true);
  };

  const removeFromCart = (index: number) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="relative min-h-screen bg-[#050505] text-white flex flex-col selection:bg-[#00f3ff] selection:text-black overflow-x-hidden hex-lattice">
      {/* Subtle film grain */}
      <div className="film-grain" />

      {/* --- ELITE GRAPHENE NEWS DYNAMIC TICKER --- */}
      <div className="w-full bg-[#020202] border-b border-white/[0.06] py-2 text-[10px] uppercase font-space tracking-[0.25em] text-neutral-400 overflow-hidden z-40 relative">
        <div className="flex animate-ticker whitespace-nowrap">
          <span className="mx-8 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00f3ff] animate-ping" />
            NEW SIGNING: ANODE — COVALENT BOND EP OUT NOW
          </span>
          <span className="mx-8">|</span>
          <span className="mx-8 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
            GRAPHENE RADIO: LIVE 24/7 BROADCAST ACTIVE
          </span>
          <span className="mx-8">|</span>
          <span className="mx-8">LONDON SHOWCASE: 24.10.26 @ FABRIC (SOLD OUT)</span>
          <span className="mx-8">|</span>
          <span className="mx-8 text-neutral-200">GERMAN SHOWCASE: BERLIN BERGHAIN (12.11.26)</span>
          <span className="mx-8">|</span>
          <span className="mx-8 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            STORE UPDATE: LIMITED EDITION CLEAR 12&quot; VINYL RESTOCK
          </span>
          <span className="mx-8">|</span>
          {/* Ticker repetition for seamless transition */}
          <span className="mx-8 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00f3ff] animate-ping" />
            NEW SIGNING: ANODE — COVALENT BOND EP OUT NOW
          </span>
          <span className="mx-8">|</span>
          <span className="mx-8 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
            GRAPHENE RADIO: LIVE 24/7 BROADCAST ACTIVE
          </span>
          <span className="mx-8">|</span>
          <span className="mx-8">LONDON SHOWCASE: 24.10.26 @ FABRIC (SOLD OUT)</span>
          <span className="mx-8">|</span>
          <span className="mx-8 text-neutral-200">GERMAN SHOWCASE: BERLIN BERGHAIN (12.11.26)</span>
        </div>
      </div>

      {/* --- MINIMALIST FLOATING NAVIGATION BAR --- */}
      <header className="sticky top-0 w-full z-50 glass-panel border-b border-white/[0.05] transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
          <div 
            onClick={() => { setActiveTab('HOME'); window.scrollTo(0, 0); }} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            {/* Minimal Hexagonal Geometric Logo */}
            <div className="relative w-8 h-8 flex items-center justify-center transition-transform duration-500 group-hover:rotate-60">
              <div className="absolute inset-0 border border-white/20 polygon-hex" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }} />
              <div className="absolute w-5 h-5 border border-[#00f3ff]/40 bg-[#00f3ff]/5 polygon-hex" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }} />
              <div className="w-2 h-2 bg-white rounded-full" />
            </div>
            <div>
              <span className="font-display font-black text-lg tracking-[0.3em] text-white">GRAPHENE</span>
              <span className="block text-[8px] tracking-[0.45em] text-neutral-400 font-space mt-[-3px]">RECORDS</span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-[11px] font-space font-medium tracking-[0.25em] text-neutral-400">
            {[
              { id: 'HOME', label: 'HOME' },
              { id: 'ARTISTS', label: 'ARTISTS' },
              { id: 'RELEASES', label: 'RELEASES' },
              { id: 'RADIO', label: 'RADIO' },
              { id: 'JOURNAL', label: 'JOURNAL' },
              { id: 'STORE', label: 'STORE' },
              { id: 'ABOUT', label: 'ABOUT' },
              { id: 'SUBMIT', label: 'A&R PORTAL' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  const el = document.getElementById(tab.id.toLowerCase());
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`hover:text-white transition-colors py-2 relative uppercase ${
                  activeTab === tab.id ? 'text-white' : ''
                }`}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#00f3ff]" />
                )}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            {/* Continuous stream button */}
            <button
              onClick={() => {
                setActiveTab('RADIO');
                setRadioActive(true);
                setIsPlaying(true);
              }}
              className="hidden lg:flex items-center gap-2 text-[10px] font-space tracking-[0.2em] border border-white/10 px-4 py-2 hover:border-[#00f3ff]/60 hover:text-[#00f3ff] transition-all bg-white/[0.02]"
            >
              <Radio className="w-3.5 h-3.5 text-red-500 animate-pulse" />
              LISTEN LIVE
            </button>

            {/* Shopping Bag Button */}
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 border border-white/10 hover:border-white/30 text-neutral-300 hover:text-white transition-colors"
            >
              <ShoppingBag className="w-4 h-4" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#00f3ff] text-black font-space font-bold text-[9px] flex items-center justify-center rounded-full">
                  {cart.length}
                </span>
              )}
            </button>

            {/* Listen / Play Main Action */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="bg-white text-black font-space font-semibold text-[11px] tracking-[0.2em] px-6 py-2.5 hover:bg-[#00f3ff] hover:text-black transition-all shadow-md active:scale-95 uppercase"
            >
              {isPlaying ? 'PAUSE' : 'LISTEN'}
            </button>
          </div>
        </div>
      </header>

      {/* --- CONTENT ARCHITECTURE CONTAINER --- */}
      <main className="flex-grow">
        
        {/* ==================================== */}
        {/* --- SECTION: HOME (CINEMATIC HERO) --- */}
        {/* ==================================== */}
        <section id="home" className="relative min-h-[92vh] flex flex-col justify-center items-center px-6 md:px-12 text-center overflow-hidden border-b border-white/[0.04]">
          {/* Shifting background GPU accelerated canvas */}
          <canvas 
            ref={heroCanvasRef} 
            className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-screen pointer-events-none"
          />

          {/* Interactive glow nodes */}
          <div className="absolute top-1/4 left-1/3 w-96 h-96 rounded-full bg-[#00f3ff]/[0.02] filter blur-[120px] pointer-events-none" />
          <div className="absolute bottom-1/4 right-1/3 w-[500px] h-[500px] rounded-full bg-violet-600/[0.02] filter blur-[150px] pointer-events-none" />

          {/* Giant Hexagonal central emblem and brand typography */}
          <div 
            className="relative z-10 max-w-4xl mx-auto flex flex-col items-center select-none transition-transform duration-300"
            style={{ transform: `translate3d(${mousePosition.x * 0.4}px, ${mousePosition.y * 0.4}px, 0)` }}
          >
            {/* Hexagonal Frame around primary branding */}
            <div className="mb-10 relative w-48 h-48 md:w-56 md:h-56 flex items-center justify-center group">
              <div className="absolute inset-0 border border-white/[0.08] polygon-hex scale-105 group-hover:scale-110 transition-transform duration-1000" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }} />
              <div className="absolute inset-4 border border-[#00f3ff]/20 polygon-hex animate-spin-slow" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)', animationDuration: '40s' }} />
              <div className="absolute inset-8 border border-violet-500/10 polygon-hex animate-spin-reverse" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)', animationDuration: '30s' }} />
              
              {/* Actual user-uploaded elegant Graphene Records Logo */}
              <div className="relative w-36 h-36 md:w-40 md:h-40 rounded-full overflow-hidden flex items-center justify-center bg-[#050505]/40 backdrop-blur-md">
                <img 
                  src="/96c75153-02a2-47f8-b397-8065ab7dac28.png" 
                  alt="Graphene Records Logo" 
                  className="w-full h-full object-contain transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    // Fallback visual in case standard relative serving fails in sandboxed workspace
                    e.currentTarget.style.display = 'none';
                    const parent = e.currentTarget.parentElement;
                    if (parent) {
                      const fb = document.createElement('div');
                      fb.className = "text-center flex flex-col items-center justify-center p-4 text-holographic";
                      fb.innerHTML = '<span class="text-3xl font-black tracking-widest font-display">G</span>';
                      parent.appendChild(fb);
                    }
                  }}
                />
              </div>
            </div>

            <h1 className="font-display font-black text-5xl md:text-8xl tracking-[0.35em] text-white leading-tight mb-4 uppercase">
              GRAPHENE
            </h1>
            <h2 className="font-display font-extrabold text-2xl md:text-4xl tracking-[0.6em] text-neutral-300 border-t border-b border-white/5 py-4 w-full max-w-2xl mb-8">
              RECORDS
            </h2>
            
            <p className="text-[12px] md:text-[14px] font-space tracking-[0.4em] text-neutral-400 uppercase mb-12">
              MUSIC AT THE MOLECULAR LEVEL.
            </p>

            {/* Quick Action Navigation Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-6 z-20">
              <button 
                onClick={() => {
                  setActiveTab('RELEASES');
                  document.getElementById('releases')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="group border border-white/10 px-8 py-3.5 text-[11px] font-space font-medium tracking-[0.2em] hover:bg-white hover:text-black hover:border-white transition-all bg-transparent"
              >
                EXPLORE CATALOGUE
              </button>
              <button 
                onClick={() => {
                  setActiveTab('RADIO');
                  document.getElementById('radio')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="group border border-[#00f3ff]/20 px-8 py-3.5 text-[11px] font-space font-medium tracking-[0.2em] text-[#00f3ff] hover:bg-[#00f3ff]/10 hover:border-[#00f3ff] transition-all bg-[#00f3ff]/[0.01]"
              >
                LAUNCH G-RADIO
              </button>
            </div>
          </div>

          {/* Scrolling visual indicators */}
          <div className="absolute bottom-12 flex flex-col items-center gap-3 text-[10px] font-space tracking-[0.3em] text-neutral-500 animate-pulse">
            <span>SCROLL TO SHIFT FREQUENCY</span>
            <div className="w-[1px] h-10 bg-gradient-to-b from-white/20 to-transparent" />
          </div>
        </section>

        {/* ======================================== */}
        {/* --- SECTION: CURRENT DOMINANT RELEASE --- */}
        {/* ======================================== */}
        <section id="current-release" className="py-24 md:py-36 border-b border-white/[0.04] bg-[#020202] relative">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            
            <div className="flex flex-col md:flex-row items-center gap-12 md:gap-20">
              
              {/* Left Side: Large Editorial Artwork */}
              <div className="w-full md:w-1/2 relative group">
                {/* Conic background representing vinyl record geometry */}
                <div className="absolute inset-[-12px] bg-gradient-to-r from-cyan-500 via-violet-600 to-amber-500 opacity-20 blur-xl group-hover:opacity-35 transition-opacity duration-1000 rounded-none" />
                
                {/* Micro-technical frame corner boundaries */}
                <div className="absolute top-[-4px] left-[-4px] w-8 h-8 border-t-2 border-l-2 border-white/20" />
                <div className="absolute bottom-[-4px] right-[-4px] w-8 h-8 border-b-2 border-r-2 border-white/20" />
                
                <div className="relative overflow-hidden aspect-square border border-white/10 bg-[#0c0c0c] flex items-center justify-center">
                  <img 
                    src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=1200" 
                    alt="Hexagonal Metric Cover Art" 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  />
                  {/* Subtle technical specifications printed overlay */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[8px] font-space tracking-[0.2em] text-neutral-400 bg-black/70 px-3 py-1.5 backdrop-blur-md border border-white/5">
                    <span>CAT#: GPHN-026</span>
                    <span>180G CLEAR VINYL</span>
                    <span>STEREO-AV</span>
                  </div>
                </div>
              </div>

              {/* Right Side: Editorial Information and Interactive Waveform */}
              <div className="w-full md:w-1/2 flex flex-col justify-center">
                <div className="flex items-center gap-3 text-[#00f3ff] text-[10px] font-space tracking-[0.3em] uppercase mb-4">
                  <span className="w-2 h-2 rounded-full bg-[#00f3ff] animate-pulse" />
                  NEW LABELS PRIORITY RELEASE
                </div>

                <h3 className="text-neutral-500 font-space text-[12px] tracking-[0.4em] mb-2 uppercase">ARTIST</h3>
                <h4 className="font-display font-black text-4xl md:text-6xl tracking-wide text-white mb-2 uppercase">
                  ANODE
                </h4>

                <h3 className="text-neutral-500 font-space text-[12px] tracking-[0.4em] mb-2 uppercase">TITLE</h3>
                <h4 className="font-display font-bold text-2xl md:text-3xl tracking-widest text-neutral-300 mb-6 uppercase">
                  HEXAGONAL METRIC
                </h4>

                <div className="flex items-center gap-6 text-[11px] font-space tracking-[0.2em] text-neutral-400 mb-8 pb-6 border-b border-white/5">
                  <div>FORMAT: <span className="text-white">12&quot; VINYL / LOSSLESS</span></div>
                  <div>RELEASED: <span className="text-white">14.08.2026</span></div>
                </div>

                {/* Interactive Waveform display that visualizes real music playing */}
                <div className="mb-8 bg-neutral-900/40 p-6 border border-white/5">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-space tracking-[0.2em] text-[#00f3ff]">SIGNAL ANALYZER (ACTIVE)</span>
                    <span className="text-[10px] font-space tracking-[0.15em] text-neutral-500">{isPlaying && currentTrackIndex === 0 ? "STREAMING COVALENT BOND" : "PREVIEW NODE"}</span>
                  </div>
                  
                  {/* Audio Reacting Canvas visualizer representation */}
                  <div className="h-16 flex items-end gap-[3px] mb-4 overflow-hidden relative">
                    {Array.from({ length: 44 }).map((_, idx) => {
                      // Simulated wave amplitudes responding dynamically to state
                      const defaultH = Math.sin(idx * 0.15) * 20 + 25;
                      const activeH = Math.sin(idx * 0.3) * 35 + 40;
                      const height = isPlaying && currentTrackIndex === 0 
                        ? Math.max(8, activeH + (Math.sin(idx * 4.2) * 8)) 
                        : defaultH;
                      
                      return (
                        <div 
                          key={idx} 
                          className={`flex-grow rounded-none transition-all duration-300 ${
                            isPlaying && currentTrackIndex === 0 
                              ? 'bg-gradient-to-t from-cyan-400 to-[#00f3ff]' 
                              : 'bg-neutral-700/60'
                          }`}
                          style={{ height: `${height}%` }}
                        />
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between text-[10px] font-space tracking-[0.15em] text-neutral-400">
                    <span>0:00</span>
                    <span className="text-neutral-600">-- FREQUENCY RESPONSE --</span>
                    <span>4:08</span>
                  </div>
                </div>

                {/* Primary Actions with Premium Aesthetics */}
                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                  <button 
                    onClick={() => selectAndPlayTrack(0)}
                    className="flex-grow bg-white text-black font-space font-semibold text-[11px] tracking-[0.2em] py-4 hover:bg-[#00f3ff] hover:text-black transition-all flex items-center justify-center gap-3 uppercase"
                  >
                    {isPlaying && currentTrackIndex === 0 ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
                    {isPlaying && currentTrackIndex === 0 ? "PAUSE PREVIEW" : "PLAY COVALENT BOND"}
                  </button>
                  <button 
                    onClick={() => addToCart(products[0])}
                    className="border border-white/10 px-6 py-4 text-[11px] font-space font-medium tracking-[0.2em] hover:bg-white hover:text-black hover:border-white transition-all flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    ADD VINYL TO BAG ($35.00)
                  </button>
                </div>

                {/* Elite Stream Links */}
                <div className="text-[10px] font-space tracking-[0.25em] text-neutral-400 flex flex-wrap items-center gap-6">
                  <span className="text-neutral-500 uppercase">STREAM OUTLETS:</span>
                  <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-0.5">SPOTIFY</a>
                  <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-0.5">APPLE MUSIC</a>
                  <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-0.5">BANDCAMP</a>
                  <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-0.5">SOUNDCLOUD</a>
                </div>

              </div>
            </div>

          </div>
        </section>

        {/* ================================== */}
        {/* --- SECTION: ARTISTS DISCOVERY --- */}
        {/* ================================== */}
        <section id="artists" className="py-24 md:py-36 border-b border-white/[0.04] relative">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            
            <div className="flex flex-col md:flex-row items-baseline justify-between mb-16 md:mb-24">
              <div>
                <h3 className="text-[#00f3ff] text-[10px] font-space tracking-[0.3em] uppercase mb-4">THE TRANSMITTERS</h3>
                <h4 className="font-display font-black text-4xl md:text-7xl tracking-tight text-white mb-4 uppercase">
                  LABEL ROSTER
                </h4>
              </div>
              <p className="max-w-md text-neutral-400 text-xs md:text-sm font-space leading-relaxed">
                Asymmetric discovery nodes mapped around carbon lattices. Hover to activate electrical stimulation. Select to unfold full performance histories, discographies and visual content.
              </p>
            </div>

            {/* Asymmetrical Layout for premium non-grid design */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-16 items-start">
              
              {artists.map((artist, idx) => {
                // Different column spans and heights to create asymmetrical rhythm
                const colSpan = idx % 3 === 0 ? "md:col-span-7" : idx % 3 === 1 ? "md:col-span-5" : "md:col-span-6";
                const offset = idx % 2 === 1 ? "md:mt-16" : "";
                
                return (
                  <div 
                    key={artist.id} 
                    className={`${colSpan} ${offset} group cursor-pointer`}
                    onClick={() => setSelectedArtist(artist)}
                  >
                    {/* Visual Card */}
                    <div className="relative overflow-hidden aspect-[4/5] border border-white/5 bg-[#090909] mb-6 transition-all duration-500 hover:border-white/20">
                      
                      {/* Holographic lines activated on hover */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/25 to-transparent z-10 pointer-events-none" />
                      <div className="absolute inset-0 bg-[#00f3ff]/[0.02] mix-blend-color opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10" />
                      
                      {/* Technical hex boundaries overlaying artist */}
                      <div className="absolute top-4 left-4 z-20 text-[9px] font-space tracking-[0.2em] text-neutral-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/60 px-2 py-1 border border-white/5">
                        [ SYSTEM ACTIVE: {artist.name} ]
                      </div>

                      {/* Moving vector lines on hover simulating electrical grid */}
                      <div className="absolute inset-0 bg-radial-gradient opacity-0 group-hover:opacity-20 transition-opacity duration-500 pointer-events-none z-10 flex items-center justify-center">
                        <div className="w-4/5 h-4/5 border border-[#00f3ff] opacity-10 rounded-full animate-ping" />
                      </div>

                      <img 
                        src={artist.portrait} 
                        alt={artist.name} 
                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-102"
                      />
                    </div>

                    <div className="flex items-baseline justify-between border-b border-white/5 pb-4">
                      <div>
                        <h5 className="font-display font-bold text-2xl tracking-widest text-white uppercase">{artist.name}</h5>
                        <p className="text-[10px] font-space tracking-[0.2em] text-neutral-400 mt-1 uppercase">{artist.role}</p>
                      </div>
                      <span className="text-[11px] font-space text-[#00f3ff] group-hover:translate-x-1 transition-transform flex items-center gap-1 uppercase">
                        EXPAND <ArrowUpRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}

            </div>

          </div>
        </section>

        {/* ========================================= */}
        {/* --- ARTIST PROFILE EXPANSION MODAL --- */}
        {/* ========================================= */}
        {selectedArtist && (
          <div className="fixed inset-0 z-50 bg-[#020202]/95 backdrop-blur-xl flex justify-end overflow-y-auto transition-opacity duration-500">
            <div className="w-full max-w-4xl min-h-screen bg-[#060606] border-l border-white/10 p-6 md:p-16 relative flex flex-col justify-between">
              
              {/* Close Button */}
              <button 
                onClick={() => setSelectedArtist(null)}
                className="absolute top-6 right-6 md:top-12 md:right-12 p-3 border border-white/10 hover:border-[#00f3ff]/60 hover:text-[#00f3ff] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-12">
                {/* Header Profile */}
                <div className="flex flex-col md:flex-row items-start gap-8 md:gap-12 pb-10 border-b border-white/5">
                  <div className="w-40 h-40 md:w-48 md:h-48 shrink-0 overflow-hidden border border-white/10 bg-neutral-900">
                    <img src={selectedArtist.portrait} alt={selectedArtist.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <span className="text-[10px] font-space tracking-[0.3em] text-[#00f3ff] uppercase block mb-2">[ LICENSED TRANSMITTER ]</span>
                    <h4 className="font-display font-black text-4xl md:text-6xl tracking-wide uppercase text-white mb-2">{selectedArtist.name}</h4>
                    <p className="text-[11px] font-space tracking-[0.2em] text-neutral-400 uppercase">{selectedArtist.role}</p>
                    
                    <div className="flex items-center gap-4 mt-6">
                      {selectedArtist.socials.spotify && <a href="#" className="text-[9px] font-space tracking-[0.2em] hover:text-[#00f3ff] text-neutral-400 border border-white/5 px-3 py-1 bg-white/[0.02] uppercase">Spotify</a>}
                      {selectedArtist.socials.soundcloud && <a href="#" className="text-[9px] font-space tracking-[0.2em] hover:text-[#00f3ff] text-neutral-400 border border-white/5 px-3 py-1 bg-white/[0.02] uppercase">SoundCloud</a>}
                      {selectedArtist.socials.instagram && <a href="#" className="text-[9px] font-space tracking-[0.2em] hover:text-[#00f3ff] text-neutral-400 border border-white/5 px-3 py-1 bg-white/[0.02] uppercase">Instagram</a>}
                    </div>
                  </div>
                </div>

                {/* Main Biography */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12">
                  <div className="md:col-span-7 space-y-8">
                    <div>
                      <h6 className="text-neutral-500 text-[10px] font-space tracking-[0.3em] uppercase mb-3">BIOGRAPHY</h6>
                      <p className="text-neutral-300 text-xs md:text-sm font-space leading-relaxed uppercase tracking-[0.05em]">{selectedArtist.bio}</p>
                    </div>

                    <div>
                      <h6 className="text-neutral-500 text-[10px] font-space tracking-[0.3em] uppercase mb-3">LATEST AUDIO TRANSMISSION</h6>
                      <div className="bg-neutral-950 p-4 border border-white/5 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Disc className="w-8 h-8 text-[#00f3ff] animate-spin-slow" />
                          <div>
                            <p className="font-display font-bold text-xs uppercase tracking-widest">{selectedArtist.latestRelease}</p>
                            <p className="text-[9px] font-space tracking-[0.15em] text-neutral-500 uppercase">SYSTEM MONITORED PLAYBACK</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            // Find and play release of artist if matched
                            const matchedTrackIdx = tracks.findIndex(t => t.artist === selectedArtist.name);
                            if (matchedTrackIdx !== -1) {
                              selectAndPlayTrack(matchedTrackIdx);
                            } else {
                              setIsPlaying(true);
                            }
                          }}
                          className="p-2.5 bg-white text-black hover:bg-[#00f3ff] hover:text-black transition-colors rounded-none"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-5 space-y-8">
                    <div>
                      <h6 className="text-neutral-500 text-[10px] font-space tracking-[0.3em] uppercase mb-3">UPCOMING EXPERIMENTS</h6>
                      <p className="text-xs font-space text-neutral-200 leading-relaxed uppercase">{selectedArtist.upcoming}</p>
                    </div>

                    <div>
                      <h6 className="text-neutral-500 text-[10px] font-space tracking-[0.3em] uppercase mb-3">SYSTEM LIVE COORDINATES</h6>
                      <div className="space-y-3 font-space text-[11px] tracking-[0.15em]">
                        {selectedArtist.liveDates.map((ld, i) => (
                          <div key={i} className="flex justify-between items-center py-2 border-b border-white/5">
                            <span className="text-[#00f3ff]">{ld.date}</span>
                            <span className="text-white uppercase">{ld.venue}</span>
                            <span className="text-neutral-400 uppercase">{ld.city}</span>
                            {ld.soldOut ? (
                              <span className="text-[8px] bg-red-900/40 text-red-400 border border-red-500/20 px-1.5 py-0.5 uppercase">SOLD OUT</span>
                            ) : (
                              <span className="text-[8px] bg-emerald-900/40 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 uppercase">ACTIVE</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sub-discography */}
                <div className="pt-6 border-t border-white/5">
                  <h6 className="text-neutral-500 text-[10px] font-space tracking-[0.3em] uppercase mb-4">SYSTEM CATALOGUE RECORD</h6>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {selectedArtist.discography.map((album, idx) => (
                      <div key={idx} className="p-4 border border-white/5 bg-neutral-900/30 font-space uppercase">
                        <span className="text-[9px] text-neutral-500 block mb-1">0{idx + 1}</span>
                        <span className="text-[11px] text-white tracking-[0.15em] font-medium">{album}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              <div className="pt-12 border-t border-white/5 flex justify-between items-center text-[10px] font-space tracking-[0.2em] text-neutral-500 uppercase">
                <span>GRAPHENE SYSTEMS © 2026</span>
                <button onClick={() => setSelectedArtist(null)} className="hover:text-white transition-colors">MINIMIZE FILE [-]</button>
              </div>

            </div>
          </div>
        )}

        {/* ======================================== */}
        {/* --- SECTION: RELEASES CATALOGUE BROWSER --- */}
        {/* ======================================== */}
        <section id="releases" className="py-24 md:py-36 bg-[#020202] border-b border-white/[0.04] relative">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            
            <div className="flex flex-col md:flex-row items-baseline justify-between mb-16 border-b border-white/5 pb-8">
              <div>
                <h3 className="text-[#00f3ff] text-[10px] font-space tracking-[0.3em] uppercase mb-4">TECHNICAL RELEASES</h3>
                <h4 className="font-display font-black text-4xl md:text-7xl tracking-tight text-white uppercase">
                  CATALOGUE
                </h4>
              </div>
              
              {/* Controls: Mode and Filters */}
              <div className="mt-8 md:mt-0 flex flex-wrap items-center gap-6">
                
                {/* Visual vs Technical Switch */}
                <div className="flex border border-white/10 p-1 bg-black">
                  <button 
                    onClick={() => setCatalogView('visual')}
                    className={`px-4 py-1.5 text-[10px] font-space tracking-[0.15em] uppercase transition-colors ${
                      catalogView === 'visual' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    VISUAL MODE
                  </button>
                  <button 
                    onClick={() => setCatalogView('technical')}
                    className={`px-4 py-1.5 text-[10px] font-space tracking-[0.15em] uppercase transition-colors ${
                      catalogView === 'technical' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    TECHNICAL MODE
                  </button>
                </div>

                {/* Category Filters */}
                <div className="flex flex-wrap items-center gap-2">
                  {['ALL', 'ALBUMS', 'EPs', 'LIMITED'].map((f) => (
                    <button
                      key={f}
                      onClick={() => setReleaseFilter(f)}
                      className={`px-3 py-1 border text-[9px] font-space tracking-[0.2em] uppercase transition-all ${
                        releaseFilter === f 
                          ? 'border-[#00f3ff] text-[#00f3ff] bg-[#00f3ff]/5' 
                          : 'border-white/5 text-neutral-400 hover:border-white/20 hover:text-white'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>

              </div>
            </div>

            {/* CATALOGUE VIEW RENDER */}
            {catalogView === 'visual' ? (
              /* --- VISUAL BROWSER MODE --- */
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
                {releases
                  .filter(r => {
                    if (releaseFilter === 'ALL') return true;
                    if (releaseFilter === 'ALBUMS') return r.format.includes('LP') || r.format.includes('Album');
                    if (releaseFilter === 'EPs') return r.format.includes('EP');
                    if (releaseFilter === 'LIMITED') return r.format.includes('Limited') || r.format.includes('Cassette');
                    return true;
                  })
                  .map((rel) => (
                    <div key={rel.catNum} className="group border border-white/5 p-4 bg-[#070707] hover:border-white/15 hover:bg-[#0b0b0b] transition-all duration-300 flex flex-col justify-between">
                      
                      {/* Album Cover Art */}
                      <div className="relative overflow-hidden aspect-square border border-white/5 mb-4 bg-neutral-900">
                        <img 
                          src={rel.image} 
                          alt={rel.title} 
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-102"
                        />
                        <div className="absolute top-2 right-2 text-[8px] font-space bg-black/80 px-2 py-0.5 border border-white/10 tracking-[0.15em]">
                          {rel.catNum}
                        </div>
                      </div>

                      {/* Info block */}
                      <div>
                        <span className="text-[8px] font-space tracking-[0.2em] text-[#00f3ff] block mb-1 uppercase">{rel.genre}</span>
                        <h5 className="font-display font-bold text-sm tracking-widest text-white truncate uppercase mb-0.5">{rel.title}</h5>
                        <p className="text-[10px] font-space tracking-[0.15em] text-neutral-400 truncate uppercase">{rel.artist}</p>
                      </div>

                      <div className="pt-4 border-t border-white/5 mt-4 flex items-center justify-between text-[9px] font-space text-neutral-500 tracking-[0.15em]">
                        <span>{rel.format}</span>
                        <button 
                          onClick={() => {
                            const matchedTrackIdx = tracks.findIndex(t => t.catNum === rel.catNum);
                            if (matchedTrackIdx !== -1) {
                              selectAndPlayTrack(matchedTrackIdx);
                            } else {
                              setIsPlaying(true);
                            }
                          }}
                          className="text-[#00f3ff] hover:text-white transition-colors"
                        >
                          LISTEN →
                        </button>
                      </div>

                    </div>
                  ))}
              </div>
            ) : (
              /* --- TECHNICAL CATALOGUE MODE --- */
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left border-collapse font-space text-[11px] tracking-[0.2em] uppercase">
                  <thead>
                    <tr className="border-b border-white/10 text-neutral-500">
                      <th className="py-4 font-normal">CATALOGUE NO.</th>
                      <th className="py-4 font-normal">ARTIST</th>
                      <th className="py-4 font-normal">TITLE</th>
                      <th className="py-4 font-normal">FORMAT</th>
                      <th className="py-4 font-normal">RELEASE DATE</th>
                      <th className="py-4 font-normal text-right">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {releases
                      .filter(r => {
                        if (releaseFilter === 'ALL') return true;
                        if (releaseFilter === 'ALBUMS') return r.format.includes('LP') || r.format.includes('Album');
                        if (releaseFilter === 'EPs') return r.format.includes('EP');
                        if (releaseFilter === 'LIMITED') return r.format.includes('Limited') || r.format.includes('Cassette');
                        return true;
                      })
                      .map((rel) => (
                        <tr key={rel.catNum} className="border-b border-white/5 text-neutral-300 hover:text-white hover:bg-white/[0.01] transition-all group">
                          <td className="py-4 text-[#00f3ff] font-semibold">{rel.catNum}</td>
                          <td className="py-4 font-medium">{rel.artist}</td>
                          <td className="py-4 text-neutral-100">{rel.title}</td>
                          <td className="py-4 text-neutral-400">{rel.format}</td>
                          <td className="py-4 text-neutral-400">{rel.releaseDate}</td>
                          <td className="py-4 text-right">
                            <button 
                              onClick={() => {
                                const matchedTrackIdx = tracks.findIndex(t => t.catNum === rel.catNum);
                                if (matchedTrackIdx !== -1) {
                                  selectAndPlayTrack(matchedTrackIdx);
                                } else {
                                  setIsPlaying(true);
                                }
                              }}
                              className="text-xs border border-white/10 hover:border-[#00f3ff] hover:text-[#00f3ff] px-4 py-1 bg-transparent transition-all"
                            >
                              ACTIVATE
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}

          </div>
        </section>

        {/* ================================== */}
        {/* --- SECTION: GRAPHENE RADIO --- */}
        {/* ================================== */}
        <section id="radio" className="py-24 md:py-36 bg-black border-b border-white/[0.04] relative overflow-hidden">
          {/* Radial space glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-red-600/[0.015] filter blur-[150px] pointer-events-none" />

          <div className="max-w-7xl mx-auto px-6 md:px-12">
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
              
              {/* Left Column: Dark Immersive Station Hub */}
              <div className="lg:col-span-5 space-y-8">
                <div className="flex items-center gap-3">
                  <div className={`w-3.5 h-3.5 rounded-full ${radioActive ? 'bg-red-500 animate-pulse' : 'bg-neutral-700'} border border-red-500/20`} />
                  <span className={`text-[10px] font-space tracking-[0.3em] ${radioActive ? 'text-red-400' : 'text-neutral-500'} uppercase`}>
                    {radioActive ? "SYSTEM BROADCASTING LIVE: ON AIR" : "STATION STANDBY"}
                  </span>
                </div>

                <div>
                  <h4 className="font-display font-black text-4xl md:text-6xl tracking-tight text-white mb-4 uppercase">
                    G-RADIO 001
                  </h4>
                  <p className="text-neutral-400 text-xs md:text-sm font-space leading-relaxed uppercase tracking-[0.05em]">
                    A 24/7 autonomous digital frequency broadcasting deep atmospheric soundwaves, continuous DJ showcases, upcoming test previews, and high-fidelity experimental recordings straight from Graphene Records laboratory.
                  </p>
                </div>

                {/* Station Mix metadata info */}
                <div className="p-6 border border-white/5 bg-neutral-900/30 space-y-4 font-space text-xs">
                  <div className="flex justify-between items-baseline border-b border-white/5 pb-2 uppercase">
                    <span className="text-neutral-500 tracking-[0.2em]">CURRENT SHOW</span>
                    <span className="text-white tracking-[0.1em]">HEXAGONAL LATTICE SHIFT MIX</span>
                  </div>
                  <div className="flex justify-between items-baseline border-b border-white/5 pb-2 uppercase">
                    <span className="text-neutral-500 tracking-[0.2em]">HOST</span>
                    <span className="text-white tracking-[0.1em]">ANODE (SPECIAL DJ SET)</span>
                  </div>
                  <div className="flex justify-between items-baseline uppercase">
                    <span className="text-neutral-500 tracking-[0.2em]">AUDIO BITRATE</span>
                    <span className="text-[#00f3ff] tracking-[0.1em]">1411 KBPS SOURCE FLAC</span>
                  </div>
                </div>

                {/* Action Trigger */}
                <button
                  onClick={() => {
                    setRadioActive(!radioActive);
                    if (!radioActive) {
                      setIsPlaying(true);
                      setCurrentTrackIndex(1); // Play helium drip on radio activate
                    }
                  }}
                  className={`w-full font-space font-semibold text-[11px] tracking-[0.25em] py-4.5 uppercase transition-all flex items-center justify-center gap-3 ${
                    radioActive 
                      ? 'bg-red-950 text-red-400 border border-red-500/30' 
                      : 'bg-white text-black hover:bg-[#00f3ff]'
                  }`}
                >
                  <Radio className="w-4 h-4" />
                  {radioActive ? "DISCONNECT BROADCAST" : "CONNECT TO RADIO STREAM"}
                </button>

              </div>

              {/* Right Column: Dynamic Terminal / Frequency spectrum */}
              <div className="lg:col-span-7 bg-[#050505] border border-white/10 p-6 md:p-10 relative">
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-[8px] font-space text-neutral-500 tracking-[0.2em]">
                  <span>FREQUENCY MODULE // REF: GPHN-X01</span>
                  <span>LATENCY: 12MS // STATUS: LOCKED</span>
                </div>

                {/* Wave Visualizer Box */}
                <div className="h-64 mt-6 mb-8 border border-white/5 relative flex flex-col justify-end">
                  <canvas 
                    ref={radioCanvasRef} 
                    className="absolute inset-0 w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="text-center">
                      <span className="font-display font-bold text-neutral-700 tracking-[0.3em] uppercase block text-sm">
                        {radioActive ? "[ SPECTRUM ACTIVE ]" : "[ COAXIAL CARRIER STANDBY ]"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-6 font-space text-[10px] tracking-[0.2em] text-neutral-400 uppercase">
                  <div>
                    <span className="text-neutral-600 block mb-1">BANDWIDTH</span>
                    <span className="text-white">40.5 KHZ</span>
                  </div>
                  <div>
                    <span className="text-neutral-600 block mb-1">SYNTAX CODE</span>
                    <span className="text-white">AES-128 DEC</span>
                  </div>
                  <div>
                    <span className="text-neutral-600 block mb-1">GEOGRAPHIC</span>
                    <span className="text-white">LONDON CORE</span>
                  </div>
                </div>

              </div>

            </div>

          </div>
        </section>

        {/* ================================== */}
        {/* --- SECTION: GRAPHENE JOURNAL --- */}
        {/* ================================== */}
        <section id="journal" className="py-24 md:py-36 border-b border-white/[0.04] relative">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            
            <div className="flex flex-col md:flex-row items-baseline justify-between mb-16 md:mb-24">
              <div>
                <h3 className="text-[#00f3ff] text-[10px] font-space tracking-[0.3em] uppercase mb-4">EDITORIAL PUBLICATION</h3>
                <h4 className="font-display font-black text-4xl md:text-7xl tracking-tight text-white uppercase">
                  JOURNAL
                </h4>
              </div>
              <p className="max-w-md text-neutral-400 text-xs md:text-sm font-space leading-relaxed uppercase tracking-[0.05em]">
                Uncompromising reflections on sound, modular architectures, advanced production techniques, and high-fashion aesthetics.
              </p>
            </div>

            {/* Editorial Sophisticated Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {journalArticles.map((article) => (
                <article key={article.id} className="group flex flex-col justify-between border border-white/5 bg-[#030303] p-6 hover:border-white/10 transition-colors duration-300">
                  <div>
                    <div className="overflow-hidden aspect-[16/10] border border-white/5 mb-6 bg-neutral-900">
                      <img 
                        src={article.image} 
                        alt={article.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103"
                      />
                    </div>

                    <div className="flex items-center gap-4 text-[9px] font-space text-[#00f3ff] tracking-[0.2em] mb-4 uppercase">
                      <span>{article.category}</span>
                      <span className="text-neutral-600">•</span>
                      <span className="text-neutral-400">{article.readTime}</span>
                    </div>

                    <h5 className="font-display font-bold text-lg md:text-xl tracking-wider text-white leading-snug uppercase mb-4 group-hover:text-neutral-200 transition-colors">
                      {article.title}
                    </h5>

                    <p className="text-neutral-400 text-xs font-space leading-relaxed uppercase tracking-[0.04em]">
                      {article.excerpt}
                    </p>
                  </div>

                  <div className="pt-6 border-t border-white/5 mt-8 flex items-center justify-between text-[10px] font-space text-neutral-500 tracking-[0.15em] uppercase">
                    <span>{article.date}</span>
                    <span className="text-[#00f3ff] group-hover:text-white transition-colors">READ TEXT →</span>
                  </div>
                </article>
              ))}
            </div>

          </div>
        </section>

        {/* ================================== */}
        {/* --- SECTION: PREMIUM STORE --- */}
        {/* ================================== */}
        <section id="store" className="py-24 md:py-36 bg-[#020202] border-b border-white/[0.04] relative">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            
            <div className="flex flex-col md:flex-row items-baseline justify-between mb-16 md:mb-24">
              <div>
                <h3 className="text-[#00f3ff] text-[10px] font-space tracking-[0.3em] uppercase mb-4">DESIGNED OBJECTS</h3>
                <h4 className="font-display font-black text-4xl md:text-7xl tracking-tight text-white uppercase">
                  STORE
                </h4>
              </div>
              <p className="max-w-sm text-neutral-400 text-xs md:text-sm font-space leading-relaxed uppercase">
                Ultra-high-end limited-edition vinyl pressings, technical outerwear apparel, and physical design hardware.
              </p>
            </div>

            {/* Product grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {products.map((product) => (
                <div key={product.id} className="group border border-white/5 bg-[#060606] p-4 flex flex-col justify-between hover:border-white/20 transition-all duration-300">
                  
                  <div className="relative overflow-hidden aspect-[4/5] border border-white/5 bg-neutral-900 mb-6">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
                    />
                    {product.limited && (
                      <span className="absolute top-3 left-3 text-[8px] bg-[#00f3ff]/10 text-[#00f3ff] border border-[#00f3ff]/20 px-2 py-0.5 font-space tracking-widest uppercase">
                        LIMITED RUN
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-[8px] font-space tracking-[0.2em] text-neutral-500 block mb-1 uppercase">{product.category}</span>
                    <h5 className="font-display font-bold text-xs md:text-sm tracking-widest text-neutral-100 uppercase mb-2 line-clamp-2">
                      {product.name}
                    </h5>
                    <p className="text-[10px] font-space text-neutral-400 uppercase tracking-widest mb-4 line-clamp-3">
                      {product.specs}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-white/5 mt-4 flex items-center justify-between">
                    <span className="font-space text-sm tracking-widest text-white">{product.price}</span>
                    <button 
                      onClick={() => addToCart(product)}
                      className="bg-white text-black font-space font-medium text-[10px] tracking-[0.15em] px-4 py-2 hover:bg-[#00f3ff] hover:text-black transition-all uppercase"
                    >
                      ADD TO BAG
                    </button>
                  </div>

                </div>
              ))}
            </div>

          </div>
        </section>

        {/* ================================== */}
        {/* --- SECTION: ABOUT PHILOSOPHY --- */}
        {/* ================================== */}
        <section id="about" className="py-24 md:py-36 border-b border-white/[0.04] relative">
          <div className="max-w-5xl mx-auto px-6 md:px-12 text-center space-y-12">
            
            <h3 className="text-[#00f3ff] text-[10px] font-space tracking-[0.4em] uppercase">MANIFESTO</h3>
            
            <h4 className="font-display font-black text-3xl md:text-6xl tracking-tight text-white leading-tight uppercase">
              WE BUILD THE FUTURE OF SOUND.
            </h4>

            <p className="text-neutral-400 text-xs md:text-sm font-space leading-relaxed max-w-2xl mx-auto uppercase tracking-[0.05em]">
              Graphene Records is not a standard record label. We operate at the molecular intersection of raw structural acoustic energy, advanced digital DSP systems, high-fashion art direction, and modular community networks. Just as graphene is ultra-thin yet exponentially stronger than steel, our musical curation targets precise frequencies and physical gravity.
            </p>

            {/* Microscopic visual grid schematic */}
            <div className="border border-white/10 p-6 md:p-12 relative max-w-xl mx-auto bg-neutral-950/60 overflow-hidden">
              <div className="absolute top-2 left-2 text-[8px] font-space text-neutral-500 tracking-[0.1em]">LATTICE RECONSTRUCTION CORE</div>
              <div className="absolute bottom-2 right-2 text-[8px] font-space text-neutral-500 tracking-[0.1em]">STEREO FIELD INTEGRITY // 100%</div>

              <div className="flex justify-around items-center h-24 relative">
                {/* Visual connection nodes representing graphene molecular structure */}
                <div className="w-4 h-4 rounded-full bg-[#00f3ff] animate-pulse" />
                <div className="h-[1px] flex-grow bg-gradient-to-r from-[#00f3ff] via-violet-500 to-amber-500" />
                <div className="w-4 h-4 rounded-full bg-violet-500" />
                <div className="h-[1px] flex-grow bg-gradient-to-r from-violet-500 to-amber-500" />
                <div className="w-4 h-4 rounded-full bg-amber-500" />
              </div>

              <div className="grid grid-cols-3 gap-4 font-space text-[9px] tracking-[0.15em] text-neutral-500 uppercase mt-4">
                <span>01. FREQUENCY NODES</span>
                <span>02. METRIC DECAY</span>
                <span>03. CARBON SYNAPSE</span>
              </div>
            </div>

          </div>
        </section>

        {/* ==================================== */}
        {/* --- SECTION: SIGNINGS A&R PORTAL --- */}
        {/* ==================================== */}
        <section id="submit" className="py-24 md:py-36 bg-[#020202] border-b border-white/[0.04] relative">
          <div className="max-w-3xl mx-auto px-6 md:px-12 border border-white/10 bg-[#050505] p-8 md:p-16 relative">
            <div className="absolute top-4 left-4 text-[8px] font-space text-neutral-500 tracking-[0.2em]">[ SECURE TRANSMISSION PORTAL ]</div>

            <div className="text-center space-y-4 mb-12">
              <h4 className="font-display font-black text-3xl md:text-5xl tracking-tight text-white uppercase">
                SEND US YOUR MUSIC.
              </h4>
              <p className="text-neutral-400 text-xs font-space tracking-[0.05em] leading-relaxed uppercase">
                THIS IS AN EXCLUSIVE A&R SUBMISSION CHANNEL. PROVIDE STREAMABLE PRIVATE AUDIO LINKS FOR CLASSIFIED EVALUATION.
              </p>
            </div>

            {isSubmitSuccess ? (
              <div className="text-center p-8 bg-neutral-950 border border-[#00f3ff]/30 space-y-6">
                <CheckCircle className="w-12 h-12 text-[#00f3ff] mx-auto animate-bounce" />
                <div className="space-y-2">
                  <h5 className="font-display font-bold text-lg uppercase tracking-widest text-white">TRANSMISSION ENCRYPTED</h5>
                  <p className="text-neutral-400 text-xs font-space uppercase tracking-widest leading-relaxed">
                    YOUR DATA NODES HAVE BEEN RECEIVED BY THE GRAPHENE A&R DISPATCH. WE WILL COMMUNICATE IF STIMULATION OCCURS.
                  </p>
                </div>
                <button 
                  onClick={() => setIsSubmitSuccess(false)}
                  className="font-space text-[10px] text-neutral-500 hover:text-white underline tracking-widest uppercase"
                >
                  TRANSMIT ANOTHER RECORD
                </button>
              </div>
            ) : (
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  setIsSubmitSuccess(true);
                }}
                className="space-y-6 font-space text-xs tracking-[0.1em]"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-neutral-400 block uppercase">TRANSMITTER NAME / ALIAS *</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="E.G. ANODE" 
                      className="w-full bg-neutral-950 border border-white/10 p-3.5 focus:border-[#00f3ff] focus:outline-none text-white uppercase"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-neutral-400 block uppercase">SECURE DIGITAL MAILBOX *</label>
                    <input 
                      required 
                      type="email" 
                      placeholder="ARTIST@CORE.IO" 
                      className="w-full bg-neutral-950 border border-white/10 p-3.5 focus:border-[#00f3ff] focus:outline-none text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-neutral-400 block uppercase">SOUND CLASSIFICATION</label>
                    <input 
                      type="text" 
                      placeholder="E.G. DECONSTRUCTED CLUB / GLITCH" 
                      className="w-full bg-neutral-950 border border-white/10 p-3.5 focus:border-[#00f3ff] focus:outline-none text-white uppercase"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-neutral-400 block uppercase">TRANSCEIVER LOCATION</label>
                    <input 
                      type="text" 
                      placeholder="E.G. KYOTO, JAPAN" 
                      className="w-full bg-neutral-950 border border-white/10 p-3.5 focus:border-[#00f3ff] focus:outline-none text-white uppercase"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-neutral-400 block uppercase">PRIVATE SOUND STREAM LINK (SOUNDCLOUD/DISCO) *</label>
                  <input 
                    required 
                    type="url" 
                    placeholder="HTTPS://SOUNDCLOUD.COM/ANODE/COVALENT-PRIVATE..." 
                    className="w-full bg-neutral-950 border border-white/10 p-3.5 focus:border-[#00f3ff] focus:outline-none text-white"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-neutral-400 block uppercase">SOUND SPECIFICATIONS & BIO</label>
                  <textarea 
                    rows={4}
                    placeholder="DESCRIBE THE KINETIC IMPACT OF THE WORK..." 
                    className="w-full bg-neutral-950 border border-white/10 p-3.5 focus:border-[#00f3ff] focus:outline-none text-white uppercase"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-white text-black font-semibold text-[11px] tracking-[0.25em] py-4 hover:bg-[#00f3ff] hover:text-black transition-all uppercase"
                >
                  ENCRYPT AND DISPATCH TRANSMISSION
                </button>
              </form>
            )}

          </div>
        </section>

      </main>

      {/* ================================== */}
      {/* --- SECTION: PREMIUM SHOPPING BAG --- */}
      {/* ================================== */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex justify-end">
          <div className="w-full max-w-md h-full bg-[#070707] border-l border-white/10 p-8 flex flex-col justify-between font-space text-xs">
            
            <div className="space-y-6">
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <span className="font-display font-bold text-sm tracking-widest uppercase">SHOPPING BAG</span>
                <button onClick={() => setIsCartOpen(false)} className="p-1 hover:text-[#00f3ff] transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {cart.length === 0 ? (
                <div className="py-20 text-center text-neutral-500 uppercase tracking-widest space-y-4">
                  <Inbox className="w-8 h-8 mx-auto opacity-35" />
                  <p>YOUR BAG IS VOID.</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                  {cart.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 border border-white/5 bg-neutral-950">
                      <div>
                        <p className="font-display font-bold text-neutral-200 uppercase tracking-wider">{item.name}</p>
                        <p className="text-[10px] text-neutral-500 mt-0.5 uppercase">{item.category} • {item.price}</p>
                      </div>
                      <button 
                        onClick={() => removeFromCart(idx)} 
                        className="text-neutral-500 hover:text-red-400 transition-colors uppercase text-[9px]"
                      >
                        REMOVE
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="space-y-6 pt-6 border-t border-white/5">
                <div className="flex justify-between font-bold text-sm uppercase tracking-wider">
                  <span>SUBTOTAL</span>
                  <span>
                    ${cart.reduce((acc, item) => acc + parseFloat(item.price.replace('$', '')), 0).toFixed(2)}
                  </span>
                </div>
                
                <button 
                  onClick={() => {
                    alert("Graphene Transaction Simulator Active: Secure encrypted checkout initialized.");
                    setCart([]);
                    setIsCartOpen(false);
                  }}
                  className="w-full bg-[#00f3ff] text-black font-semibold text-[11px] tracking-[0.25em] py-4 hover:bg-white hover:text-black transition-all uppercase"
                >
                  PROCEED TO SECURE CHECKOUT
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* ================================== */}
      {/* --- SECTION: FOOTER --- */}
      {/* ================================== */}
      <footer className="bg-[#020202] border-t border-white/[0.05] py-20 pb-36 relative z-10 font-space text-[11px] tracking-[0.2em] text-neutral-500">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-4 gap-12">
          
          <div className="space-y-6">
            <div>
              <span className="font-display font-black text-xl tracking-[0.3em] text-white">GRAPHENE</span>
              <span className="block text-[8px] tracking-[0.45em] text-[#00f3ff] font-space mt-[-3px]">RECORDS</span>
            </div>
            <p className="text-[9px] text-neutral-600 uppercase leading-relaxed">
              MUSIC AT THE MOLECULAR LEVEL.<br />
              HIGH-FIDELITY CORE COMPONENT © 2026.
            </p>
          </div>

          <div>
            <h6 className="text-white mb-4 uppercase">NAVIGATION</h6>
            <ul className="space-y-2.5">
              <li><button onClick={() => { setActiveTab('HOME'); window.scrollTo(0,0); }} className="hover:text-white transition-colors uppercase">HOME</button></li>
              <li><button onClick={() => { setActiveTab('ARTISTS'); document.getElementById('artists')?.scrollIntoView({behavior:'smooth'}); }} className="hover:text-white transition-colors uppercase">ARTISTS</button></li>
              <li><button onClick={() => { setActiveTab('RELEASES'); document.getElementById('releases')?.scrollIntoView({behavior:'smooth'}); }} className="hover:text-white transition-colors uppercase">RELEASES</button></li>
              <li><button onClick={() => { setActiveTab('RADIO'); document.getElementById('radio')?.scrollIntoView({behavior:'smooth'}); }} className="hover:text-white transition-colors uppercase">G-RADIO</button></li>
            </ul>
          </div>

          <div>
            <h6 className="text-white mb-4 uppercase">CHANNELS</h6>
            <ul className="space-y-2.5 uppercase">
              <li><a href="#" className="hover:text-white transition-colors">INSTAGRAM</a></li>
              <li><a href="#" className="hover:text-white transition-colors">SOUNDCLOUD</a></li>
              <li><a href="#" className="hover:text-white transition-colors">SPOTIFY</a></li>
              <li><a href="#" className="hover:text-white transition-colors">BANDCAMP</a></li>
            </ul>
          </div>

          <div>
            <h6 className="text-white mb-4 uppercase font-bold">A&R DISPATCH</h6>
            <p className="text-[10px] text-neutral-400 mb-4 leading-relaxed uppercase">
              SUBMIT DEMO RECOGNITIONS DIRECTLY THROUGH OUR PORTAL FOR PRIVATE SECURE BROADCAST ANALYSIS.
            </p>
            <button 
              onClick={() => { setActiveTab('SUBMIT'); document.getElementById('submit')?.scrollIntoView({behavior:'smooth'}); }} 
              className="text-[#00f3ff] hover:text-white hover:underline transition-all uppercase"
            >
              ACCESS PORTAL →
            </button>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-6 md:px-12 mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4 text-[9px] text-neutral-700">
          <span>ALL RIGHTS RESERVED. GRAPHENE RECORDS © 2026.</span>
          <span>DESIGN INTEGRITY AT THE QUANTUM SCALE.</span>
        </div>
      </footer>

      {/* ============================================= */}
      {/* --- PERSISTENT FUTURISTIC MUSIC PLAYER --- */}
      {/* ============================================= */}
      <section className="fixed bottom-0 left-0 right-0 z-40 glass-panel border-t border-white/10 h-24 flex items-center transition-transform duration-500">
        <div className="max-w-7xl mx-auto w-full px-6 md:px-12 grid grid-cols-12 items-center gap-4">
          
          {/* Col 1: Track Info */}
          <div className="col-span-4 md:col-span-3 flex items-center gap-4">
            <div className="w-12 h-12 border border-white/10 relative overflow-hidden bg-neutral-900 shrink-0">
              <img 
                src={releases[currentTrackIndex]?.image || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=120" } 
                alt={currentTrack.album} 
                className="w-full h-full object-cover" 
              />
            </div>
            <div className="truncate font-space">
              <span className="block text-white font-bold text-xs uppercase tracking-wider truncate">
                {currentTrack.title}
              </span>
              <span className="block text-neutral-400 text-[10px] uppercase tracking-wider truncate">
                {currentTrack.artist}
              </span>
            </div>
          </div>

          {/* Col 2: Player Controls */}
          <div className="col-span-8 md:col-span-6 flex flex-col items-center justify-center space-y-2">
            <div className="flex items-center gap-5">
              <button 
                onClick={handlePrevTrack}
                className="p-1.5 text-neutral-400 hover:text-white hover:scale-105 active:scale-95 transition-all"
                title="PREVIOUS TRANSMISSION"
              >
                <SkipBack className="w-4 h-4 fill-current" />
              </button>
              
              <button 
                onClick={handlePlayPause}
                className="p-3 bg-white text-black hover:bg-[#00f3ff] transition-all duration-300 scale-105 hover:scale-110 active:scale-95 flex items-center justify-center rounded-none"
                title={isPlaying ? "PAUSE FEED" : "ENGAGE FEED"}
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
              </button>

              <button 
                onClick={handleNextTrack}
                className="p-1.5 text-neutral-400 hover:text-white hover:scale-105 active:scale-95 transition-all"
                title="NEXT TRANSMISSION"
              >
                <SkipForward className="w-4 h-4 fill-current" />
              </button>
            </div>

            {/* Simulated Live Audio Spectrum Grid Progress Bar */}
            <div className="w-full flex items-center gap-3 text-[9px] font-space text-neutral-500">
              <span>{formatTime(currentTime)}</span>
              <div 
                className="flex-grow h-1.5 bg-neutral-900 border border-white/5 relative cursor-pointer group"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const percent = (e.clientX - rect.left) / rect.width;
                  setCurrentTime(Math.floor(percent * totalTime));
                }}
              >
                {/* Active progress */}
                <div 
                  className="h-full bg-gradient-to-r from-[#00f3ff] to-violet-500 transition-all duration-100" 
                  style={{ width: `${(currentTime / totalTime) * 100}%` }}
                />
              </div>
              <span>{formatTime(totalTime)}</span>
            </div>
          </div>

          {/* Col 3: Sound-Reactive Live Visualizer & Volume */}
          <div className="hidden md:col-span-3 md:flex items-center justify-end gap-6">
            
            {/* Embedded Mini Live Interactive Visualizer Canvas */}
            <div className="w-28 h-10 border border-white/5 relative overflow-hidden bg-black/40">
              <canvas 
                ref={playerCanvasRef} 
                className="w-full h-full object-cover" 
              />
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-2 font-space text-[10px] text-neutral-400">
              <button onClick={toggleMute} className="hover:text-white transition-colors">
                {isMuted ? <VolumeX className="w-4 h-4 text-[#00f3ff]" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  setVolume(parseFloat(e.target.value));
                  setIsMuted(false);
                }}
                className="w-16 h-1 bg-neutral-800 rounded-none appearance-none cursor-pointer accent-[#00f3ff] focus:outline-none"
              />
            </div>

          </div>

        </div>
      </section>

    </div>
  );
}
