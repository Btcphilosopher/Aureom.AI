package com.example.data.model

import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class Converters {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    @TypeConverter
    fun fromStringList(value: List<String>): String {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toStringList(value: String): List<String> {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.fromJson(value) ?: emptyList()
    }

    @TypeConverter
    fun fromStrokePointList(value: List<StrokePoint>): String {
        val type = Types.newParameterizedType(List::class.java, StrokePoint::class.java)
        val adapter = moshi.adapter<List<StrokePoint>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toStrokePointList(value: String): List<StrokePoint> {
        val type = Types.newParameterizedType(List::class.java, StrokePoint::class.java)
        val adapter = moshi.adapter<List<StrokePoint>>(type)
        return adapter.fromJson(value) ?: emptyList()
    }
}
