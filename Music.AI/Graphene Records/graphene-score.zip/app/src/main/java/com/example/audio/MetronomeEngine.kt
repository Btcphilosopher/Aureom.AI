package com.example.audio

import android.media.AudioManager
import android.media.ToneGenerator
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.system.measureTimeMillis

class MetronomeEngine {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _bpm = MutableStateFlow(80)
    val bpm: StateFlow<Int> = _bpm.asStateFlow()

    private val _beat = MutableStateFlow(1)
    val beat: StateFlow<Int> = _beat.asStateFlow()

    private val _timeSignature = MutableStateFlow("4/4")
    val timeSignature: StateFlow<String> = _timeSignature.asStateFlow()

    private var metronomeJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // High quality sine wave beep using system tone generator on the audio channel
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            Log.e("MetronomeEngine", "Failed to create ToneGenerator: ${e.message}")
        }
    }

    fun setBpm(newBpm: Int) {
        _bpm.value = newBpm.coerceIn(30, 300)
        if (isPlaying.value) {
            restart()
        }
    }

    fun setTimeSignature(sig: String) {
        _timeSignature.value = sig
        _beat.value = 1
    }

    fun togglePlay() {
        if (_isPlaying.value) {
            stop()
        } else {
            start()
        }
    }

    fun start() {
        _isPlaying.value = true
        _beat.value = 1
        metronomeJob?.cancel()
        metronomeJob = scope.launch {
            runMetronomeLoop()
        }
    }

    fun stop() {
        _isPlaying.value = false
        metronomeJob?.cancel()
        _beat.value = 1
    }

    private fun restart() {
        if (_isPlaying.value) {
            stop()
            start()
        }
    }

    private suspend fun runMetronomeLoop() {
        var nextBeatTime = System.currentTimeMillis()
        val beatsPerMeasure = when (_timeSignature.value) {
            "3/4" -> 3
            "2/4" -> 2
            "6/8" -> 6
            else -> 4
        }

        while (currentCoroutineContext().isActive && _isPlaying.value) {
            val currentBpm = _bpm.value
            val intervalMs = (60000.0 / currentBpm).toLong()

            // Visual flash tick trigger
            val curBeat = _beat.value
            
            // Audio sound play
            try {
                if (curBeat == 1) {
                    // Accented click for first beat of measure
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 80)
                } else {
                    // Normal click for rest
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
                }
            } catch (e: Exception) {
                // Fail-safe if audio channel is blocked
            }

            nextBeatTime += intervalMs
            val delayTime = nextBeatTime - System.currentTimeMillis()
            if (delayTime > 0) {
                delay(delayTime)
            } else {
                nextBeatTime = System.currentTimeMillis()
                delay(10) // fallback
            }

            // Move to next beat after the delay
            _beat.value = (curBeat % beatsPerMeasure) + 1
        }
    }

    // Capture tap intervals to calculate BPM dynamically
    private val tapTimes = mutableListOf<Long>()
    fun tap() {
        val now = System.currentTimeMillis()
        tapTimes.add(now)
        if (tapTimes.size > 4) {
            tapTimes.removeAt(0)
        }
        if (tapTimes.size >= 2) {
            var total = 0L
            for (i in 1 until tapTimes.size) {
                total += (tapTimes[i] - tapTimes[i - 1])
            }
            val avgInterval = total / (tapTimes.size - 1)
            if (avgInterval in 200..2000) { // 30 bpm to 300 bpm
                val calculatedBpm = (60000 / avgInterval).toInt()
                setBpm(calculatedBpm)
            }
        }
    }

    fun clearTaps() {
        tapTimes.clear()
    }

    fun release() {
        stop()
        toneGenerator?.release()
    }
}
