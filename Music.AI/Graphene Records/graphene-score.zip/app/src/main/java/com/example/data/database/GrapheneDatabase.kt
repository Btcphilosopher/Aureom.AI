package com.example.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.dao.GrapheneDao
import com.example.data.model.*

@Database(
    entities = [
        Artist::class,
        Composition::class,
        Score::class,
        GrapheneAnnotation::class,
        Setlist::class,
        SetlistItem::class,
        PracticeSession::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class GrapheneDatabase : RoomDatabase() {
    abstract fun grapheneDao(): GrapheneDao
}
