package com.example.data

import com.example.data.model.*

object SampleData {

    val artists = listOf(
        Artist("mara_vale", "Mara Vale", "Neo-classical composer and modular synthesist. Known for blending acoustic grand piano with dark ambient soundscapes.", "https://example.com/images/mara.jpg"),
        Artist("orion_dust", "Orion Dust", "Modern jazz-fusion quartet pushing the boundaries of rhythm and microtonal harmony.", "https://example.com/images/orion.jpg"),
        Artist("lyra_vance", "Lyra Vance", "Vocal art-pop visionary who crafts dense vocal harmonies and intricate poetic compositions.", "https://example.com/images/lyra.jpg"),
        Artist("corvus_black", "Corvus Black", "Avant-garde electric cellist specializing in looped noise textures and structural drone.", "https://example.com/images/corvus.jpg"),
        Artist("zephyr_brass", "Zephyr Brass", "A premier chamber brass quintet exploring modern polyphonic arrangements.", "https://example.com/images/zephyr.jpg"),
        Artist("nova_choir", "Nova Choir", "Choral ensemble dedicated to minimalist sacred vocal arrangements.", "https://example.com/images/nova.jpg"),
        Artist("helio_suite", "Helio Suite", "Cinematic progressive synth ensemble painting cosmic analog sound murals.", "https://example.com/images/helio.jpg"),
        Artist("saffron_keys", "Saffron Keys", "Minimalist pianist focused on repetitive patterns, micro-timings, and dynamic restraint.", "https://example.com/images/saffron.jpg"),
        Artist("echo_pulse", "Echo Pulse", "Trip-hop and live instrument collective known for dark, heavy, bass-driven beats.", "https://example.com/images/echo.jpg"),
        Artist("graphene_chamber", "Graphene Chamber Players", "A flexible elite ensemble performing new chamber commissions.", "https://example.com/images/graphene_chamber.jpg")
    )

    val compositions = listOf(
        Composition("black_glass", "Black Glass", "mara_vale", "Mara Vale", "Neo-Classical", "A minor", 72, listOf("Ambient", "Piano", "Moody"), "Graphene G-014"),
        Composition("midnight_drift", "Midnight Drift", "orion_dust", "Orion Dust", "Jazz Fusion", "C# minor", 110, listOf("Complex", "Groove", "Syncopated"), "Graphene G-022"),
        Composition("solar_flare", "Solar Flare", "helio_suite", "Helio Suite", "Space Rock", "G major", 128, listOf("Synthesizer", "Driving", "Anthemic"), "Graphene G-089"),
        Composition("gravity_wave", "Gravity Wave", "corvus_black", "Corvus Black", "Experimental Cello", "D minor", 60, listOf("Drone", "Dark", "Atmospheric"), "Graphene G-005"),
        Composition("fuchsia_dusk", "Fuchsia Dusk", "lyra_vance", "Lyra Vance", "Art Pop", "F major", 92, listOf("Vocal-driven", "Polyrhythmic"), "Graphene G-041"),
        Composition("sacred_vow", "Sacred Vow", "nova_choir", "Nova Choir", "Choral Minimalist", "E minor", 54, listOf("Acapella", "Echoing"), "Graphene G-033"),
        Composition("copper_wind", "Copper Wind", "zephyr_brass", "Zephyr Brass", "Chamber Brass", "Bb major", 88, listOf("Polyphonic", "Brass"), "Graphene G-012"),
        Composition("minimal_steps", "Minimal Steps", "saffron_keys", "Saffron Keys", "Minimalist", "C major", 120, listOf("Phasing", "Repetitive"), "Graphene G-015"),
        Composition("sub_zero", "Sub Zero", "echo_pulse", "Echo Pulse", "Trip Hop", "F# minor", 80, listOf("Heavy Bass", "Drums"), "Graphene G-067"),
        Composition("graphene_study_1", "Graphene Study No. 1", "graphene_chamber", "Graphene Chamber Players", "Chamber", "C minor", 96, listOf("Orchestral", "Contemporary"), "Graphene G-100"),
        Composition("echoes_in_void", "Echoes in Void", "mara_vale", "Mara Vale", "Neo-Classical", "G minor", 68, listOf("Subtle", "Reverb"), "Graphene G-014"),
        Composition("synapse_burst", "Synapse Burst", "orion_dust", "Orion Dust", "Jazz Fusion", "Ab major", 132, listOf("Upbeat", "Improvised"), "Graphene G-022"),
        Composition("nebula_dust", "Nebula Dust", "helio_suite", "Helio Suite", "Ambient Synth", "E major", 75, listOf("Ethereal", "Floating"), "Graphene G-089"),
        Composition("rusty_anchor", "Rusty Anchor", "corvus_black", "Corvus Black", "Experimental Cello", "A minor", 50, listOf("Gritty", "Industrial"), "Graphene G-005"),
        Composition("glass_sky", "Glass Sky", "lyra_vance", "Lyra Vance", "Art Pop", "D major", 100, listOf("Electronic", "Percussive"), "Graphene G-041"),
        Composition("vocal_fracture", "Vocal Fracture", "nova_choir", "Nova Choir", "Contemporary Vocal", "F# minor", 62, listOf("Interlocking", "Clean"), "Graphene G-033"),
        Composition("bronze_bell", "Bronze Bell", "zephyr_brass", "Zephyr Brass", "Chamber Brass", "Eb major", 70, listOf("Warm", "Sustained"), "Graphene G-012"),
        Composition("looping_time", "Looping Time", "saffron_keys", "Saffron Keys", "Minimalist", "G major", 116, listOf("Hypnotic", "Piano"), "Graphene G-015"),
        Composition("magnetic_pulse", "Magnetic Pulse", "echo_pulse", "Echo Pulse", "Trip Hop", "B minor", 84, listOf("Downtempo", "Lo-fi"), "Graphene G-067"),
        Composition("after_dark", "After Dark (Theme)", "graphene_chamber", "Graphene Chamber Players", "Chamber Jazz", "C minor", 85, listOf("Nocturnal", "Elegant"), "Graphene G-101")
    )

    val scores = listOf(
        Score("black_glass_piano", "black_glass", "Piano — Original", "Piano", "Medium", true, true, true, "Original"),
        Score("black_glass_band", "black_glass", "Band — Live Arrangement", "Full Score", "Advanced", true, true, true, "Rehearsal 03"),
        Score("black_glass_strings", "black_glass", "Strings — Chamber Arrangement", "Strings", "Advanced", true, true, false, "Live Version"),
        
        Score("midnight_drift_fusion", "midnight_drift", "Lead Sheet", "Guitar", "Advanced", true, true, true, "Original"),
        Score("midnight_drift_piano", "midnight_drift", "Piano Part", "Piano", "Advanced", true, true, false, "Original"),
        
        Score("solar_flare_synth", "solar_flare", "Synth Guide", "Piano", "Medium", true, true, true, "Original"),
        Score("solar_flare_full", "solar_flare", "Full Score", "Full Score", "Advanced", true, true, false, "Live Version"),
        
        Score("gravity_wave_cello", "gravity_wave", "Cello - Solo Loop", "Strings", "Professional", true, true, true, "Original"),
        Score("fuchsia_dusk_vocals", "fuchsia_dusk", "Vocal Guide & Lyrics", "Vocals", "Medium", true, true, true, "Original"),
        Score("sacred_vow_choir", "sacred_vow", "SAB Choral score", "Vocals", "Easy", true, true, false, "Original"),
        Score("copper_brass_quintet", "copper_wind", "Brass Quintet", "Brass", "Advanced", true, true, true, "Original"),
        Score("minimal_steps_keys", "minimal_steps", "Piano - Main Pattern", "Piano", "Medium", true, true, false, "Original"),
        Score("sub_zero_drums", "sub_zero", "Drum Lead Sheet", "Drums", "Medium", true, true, true, "Original"),
        Score("graphene_study_orch", "graphene_study_1", "Conductor Score", "Full Score", "Professional", true, true, false, "Original"),
        
        Score("echoes_in_void_piano", "echoes_in_void", "Piano - Solo Edition", "Piano", "Medium", true, true, false, "Original"),
        Score("synapse_burst_lead", "synapse_burst", "Lead Sheet", "Guitar", "Advanced", true, true, false, "Original"),
        Score("nebula_dust_ambient", "nebula_dust", "Synth & Pads", "Piano", "Easy", true, true, false, "Original"),
        Score("rusty_anchor_cello", "rusty_anchor", "Cello - Loops & Fx", "Strings", "Advanced", true, true, false, "Original"),
        Score("glass_sky_melody", "glass_sky", "Lead Vocals & Synth", "Vocals", "Medium", true, true, false, "Original"),
        Score("vocal_fracture_satb", "vocal_fracture", "SATB Score", "Vocals", "Advanced", true, true, false, "Original"),
        Score("bronze_bell_horns", "bronze_bell", "Horn Quartet", "Brass", "Medium", true, true, false, "Original"),
        Score("looping_time_piano", "looping_time", "Piano Part", "Piano", "Medium", true, true, false, "Original"),
        Score("magnetic_pulse_bass", "magnetic_pulse", "Bass Lead Sheet", "Bass", "Medium", true, true, false, "Original"),
        Score("after_dark_chamber", "after_dark", "Chamber Ensemble", "Full Score", "Advanced", true, true, false, "Original"),
        
        Score("black_glass_easy", "black_glass", "Piano — Easy Edition", "Piano", "Easy", true, true, false, "Original"),
        Score("midnight_drift_bass", "midnight_drift", "Bass Part", "Bass", "Advanced", true, true, false, "Original"),
        Score("solar_flare_drums", "solar_flare", "Drum Score", "Drums", "Medium", true, true, false, "Original"),
        Score("gravity_wave_chamber", "gravity_wave", "Chamber Ensemble", "Full Score", "Advanced", true, true, false, "Original"),
        Score("fuchsia_dusk_band", "fuchsia_dusk", "Band Lead Sheet", "Full Score", "Advanced", true, true, false, "Original"),
        Score("sub_zero_bass", "sub_zero", "Synth Bass Part", "Bass", "Medium", true, true, false, "Original")
    )

    val setlists = listOf(
        Setlist("setlist_gala", "Tonight's Graphene Gala", System.currentTimeMillis() - 3600000, false, "Graphene Annual Gala", "Graphene Hall A", "Sept 13, 2026"),
        Setlist("setlist_showcase", "A&R Showcase 2026", System.currentTimeMillis() - 86400000, false, "Graphene A&R Sessions", "The Blue Note", "Sept 14, 2026"),
        Setlist("setlist_mara_live", "Mara Vale Live at Graphene After Dark", System.currentTimeMillis() - 259200000, false, "Graphene After Dark Series", "Red Rock Amphitheatre", "Sept 12, 2026"),
        Setlist("setlist_brass_tour", "Zephyr Brass Tour", System.currentTimeMillis() - 604800000, true, "National Chamber Brass Tour", "Symphony Hall", "Sept 10, 2026"),
        Setlist("setlist_rehearsal_chamber", "Chamber Ensemble Rehearsal", System.currentTimeMillis() - 1209600000, true, "Weekly Session", "Studio 4", "Sept 05, 2026")
    )

    val setlistItems = listOf(
        SetlistItem("item_g1", "setlist_gala", "black_glass_piano", "Black Glass", "Mara Vale", 0, "Opener. Use warm preset on synth. Keep metronome silent in live mode."),
        SetlistItem("item_g2", "setlist_gala", "midnight_drift_fusion", "Midnight Drift", "Orion Dust", 1, "Sync guitar looping pedal with MIDI clock."),
        SetlistItem("item_g3", "setlist_gala", "solar_flare_synth", "Solar Flare", "Helio Suite", 2, "Transition immediately from Midnight Drift. Start metronome tap."),
        SetlistItem("item_g4", "setlist_gala", "gravity_wave_cello", "Gravity Wave", "Corvus Black", 3, "Interlude. High-contrast ambient cello drone."),
        SetlistItem("item_g5", "setlist_gala", "fuchsia_dusk_vocals", "Fuchsia Dusk", "Lyra Vance", 4, "Encore track. Watch vocal cue note on Measure 47."),
        
        SetlistItem("item_s1", "setlist_showcase", "black_glass_band", "Black Glass", "Mara Vale", 0, "Showcase live version."),
        SetlistItem("item_s2", "setlist_showcase", "midnight_drift_piano", "Midnight Drift", "Orion Dust", 1, "A&R evaluation take."),
        SetlistItem("item_s3", "setlist_showcase", "sub_zero_drums", "Sub Zero", "Echo Pulse", 2, "Check bass level on playback.")
    )

    // A helper to generate canonical notation data for rendering
    fun getMeasuresForScore(scoreId: String, pageNumber: Int): List<CanonicalMeasure> {
        val seed = scoreId.hashCode() + pageNumber
        val section = when (pageNumber) {
            1 -> "INTRO"
            2 -> "VERSE"
            3 -> "CHORUS"
            4 -> "SOLO"
            else -> "CODA"
        }
        
        return when {
            scoreId.contains("black_glass") -> listOf(
                CanonicalMeasure(1, "4/4", section, listOf(
                    CanonicalNote("A4", "QUARTER", "In", "Am", "p"),
                    CanonicalNote("C5", "QUARTER", "the", null, null),
                    CanonicalNote("E5", "QUARTER", "dark", null, null),
                    CanonicalNote("C5", "QUARTER", "glass", null, null, isSlurStart = true)
                )),
                CanonicalMeasure(2, "4/4", null, listOf(
                    CanonicalNote("G4", "QUARTER", "re", "G", null, isSlurEnd = true),
                    CanonicalNote("B4", "QUARTER", "flec", null, null),
                    CanonicalNote("D5", "QUARTER", "tions", null, null),
                    CanonicalNote("B4", "QUARTER", "pass", null, null)
                )),
                CanonicalMeasure(3, "4/4", "VERSE", listOf(
                    CanonicalNote("F4", "QUARTER", "shad", "F", null),
                    CanonicalNote("A4", "QUARTER", "ows", null, null),
                    CanonicalNote("C5", "QUARTER", "fade", null, null),
                    CanonicalNote("A4", "QUARTER", "to", null, null)
                )),
                CanonicalMeasure(4, "4/4", null, listOf(
                    CanonicalNote("E4", "QUARTER", "black", "E", null),
                    CanonicalNote("G#4", "QUARTER", "and", null, null),
                    CanonicalNote("B4", "QUARTER", "gray", null, null),
                    CanonicalNote("R", "QUARTER", null, null, "mp")
                ))
            )
            scoreId.contains("midnight_drift") -> listOf(
                CanonicalMeasure(1, "4/4", section, listOf(
                    CanonicalNote("C#4", "QUARTER", "Walk", "C#m7", "mp"),
                    CanonicalNote("E4", "QUARTER", "ing", null, null),
                    CanonicalNote("G#4", "EIGHTH", "through", null, null),
                    CanonicalNote("B4", "EIGHTH", "the", null, null),
                    CanonicalNote("C#5", "QUARTER", "night", null, null)
                )),
                CanonicalMeasure(2, "4/4", null, listOf(
                    CanonicalNote("F#4", "QUARTER", "drift", "F#m9", null),
                    CanonicalNote("A4", "QUARTER", "ing", null, null),
                    CanonicalNote("C#5", "QUARTER", "out", null, null),
                    CanonicalNote("E5", "QUARTER", "of", null, null)
                )),
                CanonicalMeasure(3, "4/4", "CHORUS", listOf(
                    CanonicalNote("G#4", "QUARTER", "sight", "G#m7b5", "f"),
                    CanonicalNote("B4", "QUARTER", "un", null, null),
                    CanonicalNote("D5", "QUARTER", "der", null, null),
                    CanonicalNote("F#5", "QUARTER", "stars", null, null)
                )),
                CanonicalMeasure(4, "4/4", null, listOf(
                    CanonicalNote("C#4", "HALF", "clear", "C#m7", null),
                    CanonicalNote("R", "HALF", null, null, null)
                ))
            )
            else -> {
                // Generate a generic beautiful page based on seed
                val chords = listOf("C", "G", "Am", "F", "Dm", "Em", "Bb", "D")
                val notes = listOf("C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5")
                val chord1 = chords[(seed) % chords.size]
                val chord2 = chords[(seed + 1) % chords.size]
                
                listOf(
                    CanonicalMeasure(1, "4/4", section, listOf(
                        CanonicalNote(notes[seed % notes.size], "QUARTER", "Let", chord1, "mp"),
                        CanonicalNote(notes[(seed + 1) % notes.size], "QUARTER", "the", null, null),
                        CanonicalNote(notes[(seed + 2) % notes.size], "QUARTER", "mu", null, null),
                        CanonicalNote(notes[(seed + 3) % notes.size], "QUARTER", "sic", null, null)
                    )),
                    CanonicalMeasure(2, "4/4", null, listOf(
                        CanonicalNote(notes[(seed + 4) % notes.size], "QUARTER", "play", chord2, null),
                        CanonicalNote(notes[(seed + 5) % notes.size], "QUARTER", "its", null, null),
                        CanonicalNote(notes[(seed + 6) % notes.size], "QUARTER", "own", null, null),
                        CanonicalNote(notes[(seed + 7) % notes.size], "QUARTER", "way", null, null)
                    )),
                    CanonicalMeasure(3, "4/4", "CHORUS", listOf(
                        CanonicalNote(notes[(seed + 2) % notes.size], "HALF", "rise", chord1, "f"),
                        CanonicalNote(notes[(seed + 4) % notes.size], "HALF", "up", chord2, null)
                    )),
                    CanonicalMeasure(4, "4/4", null, listOf(
                        CanonicalNote("R", "WHOLE", null, null, "p")
                    ))
                )
            }
        }
    }
}
