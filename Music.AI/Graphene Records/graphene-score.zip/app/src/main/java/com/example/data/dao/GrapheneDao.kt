package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GrapheneDao {

    // --- ARTISTS ---
    @Query("SELECT * FROM artists")
    fun getAllArtists(): Flow<List<Artist>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtist(artist: Artist)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtists(artists: List<Artist>)


    // --- COMPOSITIONS ---
    @Query("SELECT * FROM compositions")
    fun getAllCompositions(): Flow<List<Composition>>

    @Query("SELECT * FROM compositions WHERE artistId = :artistId")
    fun getCompositionsByArtist(artistId: String): Flow<List<Composition>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComposition(composition: Composition)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompositions(compositions: List<Composition>)


    // --- SCORES ---
    @Query("SELECT * FROM scores")
    fun getAllScores(): Flow<List<Score>>

    @Query("SELECT * FROM scores WHERE compositionId = :compositionId")
    fun getScoresForComposition(compositionId: String): Flow<List<Score>>

    @Query("SELECT * FROM scores WHERE id = :scoreId LIMIT 1")
    suspend fun getScoreById(scoreId: String): Score?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(score: Score)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScores(scores: List<Score>)


    // --- ANNOTATIONS ---
    @Query("SELECT * FROM annotations WHERE scoreId = :scoreId")
    fun getAnnotationsForScore(scoreId: String): Flow<List<GrapheneAnnotation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnotation(annotation: GrapheneAnnotation)

    @Query("DELETE FROM annotations WHERE id = :id")
    suspend fun deleteAnnotationById(id: String)

    @Query("DELETE FROM annotations WHERE scoreId = :scoreId")
    suspend fun clearAnnotationsForScore(scoreId: String)


    // --- SETLISTS ---
    @Query("SELECT * FROM setlists ORDER BY createdAt DESC")
    fun getAllSetlists(): Flow<List<Setlist>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetlist(setlist: Setlist)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetlists(setlists: List<Setlist>)

    @Query("DELETE FROM setlists WHERE id = :setlistId")
    suspend fun deleteSetlistById(setlistId: String)


    // --- SETLIST ITEMS ---
    @Query("SELECT * FROM setlist_items WHERE setlistId = :setlistId ORDER BY position ASC")
    fun getItemsForSetlist(setlistId: String): Flow<List<SetlistItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetlistItem(item: SetlistItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetlistItems(items: List<SetlistItem>)

    @Query("DELETE FROM setlist_items WHERE id = :id")
    suspend fun deleteSetlistItemById(id: String)

    @Query("DELETE FROM setlist_items WHERE setlistId = :setlistId")
    suspend fun clearSetlistItems(setlistId: String)


    // --- PRACTICE SESSIONS ---
    @Query("SELECT * FROM practice_sessions ORDER BY startTime DESC")
    fun getAllPracticeSessions(): Flow<List<PracticeSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPracticeSession(session: PracticeSession)
}
