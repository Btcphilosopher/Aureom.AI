package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.rendering.ScoreSheetCanvas
import com.example.ui.viewmodel.GrapheneViewModel

// Graphene Records Brand Palette
val GrapheneDarkBg = Color(0xFF121211)     // deep black
val GrapheneCardBg = Color(0xFF1E1E1C)     // graphite graphite gray
val GrapheneAcidGreen = Color(0xFF23C13D)  // vivid acid green
val GrapheneElectricBlue = Color(0xFF005DFF)// electric pop blue
val GrapheneFuchsia = Color(0xFF9E005D)     // restrained fuchsia
val GrapheneSilver = Color(0xFF8E8E93)      // silver chrome grey
val GrapheneWhite = Color(0xFFFBFBF9)       // warm sheet paper white

@Composable
fun GrapheneScoreApp(
    viewModel: GrapheneViewModel,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf("LIBRARY") } // LIBRARY, NOTATION, PRACTICE, PERFORMANCE, CATALOGUE

    val isPerformanceMode by viewModel.isPerformanceMode.collectAsState()
    val isPerformanceLocked by viewModel.isPerformanceLocked.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            if (!isPerformanceMode) {
                GrapheneBottomNavBar(
                    activeTab = activeTab,
                    onTabSelected = { activeTab = it }
                )
            }
        },
        containerColor = GrapheneDarkBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isPerformanceMode) {
                PerformanceView(viewModel = viewModel)
            } else {
                when (activeTab) {
                    "LIBRARY" -> LibraryView(
                        viewModel = viewModel,
                        onOpenScore = { activeTab = "NOTATION" }
                    )
                    "NOTATION" -> NotationViewerScreen(viewModel = viewModel)
                    "PRACTICE" -> PracticeView(viewModel = viewModel)
                    "PERFORMANCE" -> PerformanceOnboardingScreen(viewModel = viewModel)
                    "CATALOGUE" -> CatalogueView(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun GrapheneBottomNavBar(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    NavigationBar(
        containerColor = GrapheneCardBg,
        contentColor = Color.White,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        val tabs = listOf(
            Triple("LIBRARY", "Library", Icons.Default.LibraryMusic),
            Triple("NOTATION", "Score Stand", Icons.Default.MenuBook),
            Triple("PRACTICE", "Practice Desk", Icons.Default.Timer),
            Triple("PERFORMANCE", "Live Concert", Icons.Default.MusicNote),
            Triple("CATALOGUE", "Graphene Net", Icons.Default.Hub)
        )

        tabs.forEach { (id, label, icon) ->
            val isSelected = activeTab == id
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(id) },
                label = {
                    Text(
                        text = label,
                        color = if (isSelected) GrapheneAcidGreen else GrapheneSilver,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) GrapheneAcidGreen else GrapheneSilver,
                        modifier = Modifier.size(24.dp)
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = GrapheneDarkBg.copy(alpha = 0.5f)
                ),
                modifier = Modifier.testTag("nav_tab_$id")
            )
        }
    }
}

// --- VIEW 1: LIBRARY VIEWER ---
@Composable
fun LibraryView(
    viewModel: GrapheneViewModel,
    onOpenScore: () -> Unit
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val artists by viewModel.artists.collectAsState()
    val compositions by viewModel.filteredCompositions.collectAsState()
    val scores by viewModel.scores.collectAsState()
    val setlists by viewModel.setlists.collectAsState()

    val selectedArtist by viewModel.selectedArtist.collectAsState()
    val selectedScore by viewModel.selectedScore.collectAsState()
    val selectedSetlist by viewModel.selectedSetlist.collectAsState()

    Row(modifier = Modifier.fillMaxSize()) {
        // Left Column: Filter Side panel list
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .background(GrapheneCardBg)
                .border(1.dp, Color.Black)
                .padding(16.dp)
        ) {
            Text(
                text = "GRAPHENE RECORDS",
                color = GrapheneAcidGreen,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )
            Text(
                text = "ARCHIVE DEPOSITORY",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Search input box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search title, composer...", color = GrapheneSilver) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = GrapheneSilver) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GrapheneAcidGreen,
                    unfocusedBorderColor = Color.DarkGray,
                    focusedContainerColor = GrapheneDarkBg,
                    unfocusedContainerColor = GrapheneDarkBg
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .testTag("library_search_input")
            )

            Text(
                text = "SETLIST PACKAGES",
                color = GrapheneElectricBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(setlists) { setlist ->
                    val isSelected = selectedSetlist?.id == setlist.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) GrapheneElectricBlue.copy(alpha = 0.2f) else GrapheneDarkBg
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectSetlist(if (isSelected) null else setlist) }
                            .border(
                                width = 1.dp,
                                color = if (isSelected) GrapheneElectricBlue else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(setlist.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("${setlist.venue} • ${setlist.performanceDate}", color = GrapheneSilver, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Middle & Right: Composition / Part list and score preview details
        Column(
            modifier = Modifier
                .weight(2f)
                .fillMaxHeight()
                .padding(24.dp)
        ) {
            if (selectedSetlist != null) {
                Text(
                    text = "SETLIST ITEMS: ${selectedSetlist?.name}",
                    color = GrapheneElectricBlue,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                val items by viewModel.currentSetlistItems.collectAsState()
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(items) { item ->
                        val isScoreSelected = selectedScore?.id == item.scoreId
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(GrapheneCardBg, shape = RoundedCornerShape(8.dp))
                                .clickable {
                                    val score = scores.firstOrNull { it.id == item.scoreId }
                                    viewModel.selectScore(score)
                                }
                                .border(
                                    width = 1.dp,
                                    color = if (isScoreSelected) GrapheneAcidGreen else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "0${item.position + 1}",
                                color = GrapheneElectricBlue,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.songTitle, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text("Artist: ${item.artistName}", color = GrapheneSilver, fontSize = 12.sp)
                                if (item.performanceNotes.isNotBlank()) {
                                    Text(item.performanceNotes, color = GrapheneAcidGreen, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (isScoreSelected) {
                                Button(
                                    onClick = onOpenScore,
                                    colors = ButtonDefaults.buttonColors(containerColor = GrapheneAcidGreen)
                                ) {
                                    Text("OPEN STAND", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                Text(
                    text = "AVAILABLE MASTER NOTATION COMPOSITIONS",
                    color = GrapheneAcidGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(compositions) { composition ->
                        val compScores = scores.filter { it.compositionId == composition.id }
                        val artistName = artists.firstOrNull { it.id == composition.artistId }?.name ?: "Unknown"

                        Card(
                            colors = CardDefaults.cardColors(containerColor = GrapheneCardBg),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column {
                                        Text(composition.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("By $artistName • Composer: ${composition.composer}", color = GrapheneSilver, fontSize = 13.sp)
                                    }
                                    Text(
                                        text = composition.releaseCode,
                                        color = GrapheneFuchsia,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    composition.tags.forEach { tag ->
                                        Box(
                                            modifier = Modifier
                                                .background(Color.Black, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(tag, color = GrapheneSilver, fontSize = 10.sp)
                                        }
                                    }
                                }

                                Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 12.dp))

                                Text("Available Parts/Arrangements:", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))

                                 Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    compScores.forEach { score ->
                                        val isThisSelected = selectedScore?.id == score.id
                                        AssistChip(
                                            onClick = { viewModel.selectScore(score) },
                                            label = { Text(score.title, color = if (isThisSelected) Color.Black else Color.White) },
                                            colors = AssistChipDefaults.assistChipColors(
                                                containerColor = if (isThisSelected) GrapheneAcidGreen else Color.Black
                                            ),
                                            modifier = Modifier.testTag("score_chip_${score.id}")
                                        )
                                    }
                                }

                                if (selectedScore?.compositionId == composition.id) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = onOpenScore,
                                        colors = ButtonDefaults.buttonColors(containerColor = GrapheneAcidGreen),
                                        modifier = Modifier.fillMaxWidth().testTag("open_score_button")
                                    ) {
                                        Text("OPEN SCORE: ${selectedScore?.title}", color = Color.Black, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- VIEW 2: INTERACTIVE SCORE VIEWER & STAND ---
@Composable
fun NotationViewerScreen(viewModel: GrapheneViewModel) {
    val score by viewModel.selectedScore.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val currentMeasure by viewModel.currentMeasure.collectAsState()
    val currentNoteIndex by viewModel.currentNoteIndex.collectAsState()
    val activeMeasures by viewModel.activeMeasures.collectAsState()

    val isDrawingMode by viewModel.isDrawingMode.collectAsState()
    val drawingColor by viewModel.drawingColor.collectAsState()
    val drawingWidth by viewModel.drawingWidth.collectAsState()
    val activeTool by viewModel.activeTool.collectAsState()
    val activeLayer by viewModel.activeAnnotationLayer.collectAsState()

    val activeAnnotations by viewModel.activeAnnotations.collectAsState()
    val drawingStrokes by viewModel.drawingStrokes.collectAsState()

    if (score == null) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.MenuBook, contentDescription = null, tint = GrapheneSilver, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("THE SCORE STAND IS EMPTY", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Please select a composition part from the Library to mount it on the music stand.", color = GrapheneSilver, fontSize = 14.sp)
            }
        }
        return
    }

    Row(modifier = Modifier.fillMaxSize()) {
        // Main Sheet music viewing panel
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            // Stand top bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GrapheneCardBg, shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(GrapheneFuchsia, RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    ) {
                        Text("STAND", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(score!!.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Page $currentPage of 4 • Measure $currentMeasure", color = GrapheneSilver, fontSize = 12.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { viewModel.prevPage() }) {
                        Icon(Icons.Default.ArrowBackIos, contentDescription = "Prev page", tint = Color.White)
                    }
                    Text(
                        "$currentPage / 4",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                    IconButton(onClick = { viewModel.nextPage() }) {
                        Icon(Icons.Default.ArrowForwardIos, contentDescription = "Next page", tint = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Score drawing board
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, Color.DarkGray, RoundedCornerShape(12.dp))
            ) {
                ScoreSheetCanvas(
                    measures = activeMeasures,
                    currentMeasure = currentMeasure,
                    currentNoteIndex = currentNoteIndex,
                    annotations = activeAnnotations,
                    drawingStrokes = drawingStrokes,
                    currentDrawingColor = drawingColor,
                    currentDrawingWidth = drawingWidth,
                    isDrawingMode = isDrawingMode,
                    onStrokeFinished = { stroke ->
                        viewModel.addFreehandStroke(stroke)
                    }
                )
            }
        }

        // Right overlay Annotation Toolbar Panel
        Column(
            modifier = Modifier
                .width(220.dp)
                .fillMaxHeight()
                .background(GrapheneCardBg)
                .border(1.dp, Color.Black)
                .padding(16.dp)
        ) {
            Text("PENCIL & STAMPS", color = GrapheneAcidGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("ANNOTATION TOOL", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)

            Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 12.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Draw / Ink Mode", color = Color.White, fontSize = 13.sp)
                Switch(
                    checked = isDrawingMode,
                    onCheckedChange = { viewModel.setDrawingMode(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = GrapheneAcidGreen)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Select Active Tool", color = GrapheneSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            val tools = listOf(
                Pair("PEN", "Pen Brush"),
                Pair("HIGHLIGHTER", "Highlighter"),
                Pair("TEXT", "Add Text Cue"),
                Pair("STAMP_P", "Stamp p"),
                Pair("STAMP_FF", "Stamp ff"),
                Pair("STAMP_BREATH", "Stamp Breath"),
                Pair("STAMP_ACCENT", "Stamp Accent")
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(tools) { (id, label) ->
                    val isToolSelected = activeTool == id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = if (isToolSelected) GrapheneElectricBlue.copy(alpha = 0.2f) else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { viewModel.setTool(id) }
                            .padding(8.dp)
                            .border(
                                width = 1.dp,
                                color = if (isToolSelected) GrapheneElectricBlue else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                    ) {
                        Icon(
                            imageVector = when {
                                id == "PEN" -> Icons.Default.Edit
                                id == "HIGHLIGHTER" -> Icons.Default.BorderColor
                                id == "TEXT" -> Icons.Default.TextFields
                                else -> Icons.Default.FormatQuote
                            },
                            contentDescription = label,
                            tint = if (isToolSelected) GrapheneAcidGreen else GrapheneSilver,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, color = Color.White, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Toggle Shared Layer", color = GrapheneSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            val layers = listOf("PERSONAL", "BAND", "CONDUCTOR")
            layers.forEach { layer ->
                val isLayerSelected = activeLayer == layer
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setAnnotationLayer(layer) }
                        .padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = isLayerSelected,
                        onClick = { viewModel.setAnnotationLayer(layer) },
                        colors = RadioButtonDefaults.colors(selectedColor = GrapheneAcidGreen)
                    )
                    Text(
                        text = layer,
                        color = when (layer) {
                            "PERSONAL" -> GrapheneFuchsia
                            "BAND" -> GrapheneElectricBlue
                            else -> GrapheneAcidGreen
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { viewModel.undoLastAnnotation() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().testTag("undo_annotation")
            ) {
                Icon(Icons.Default.Undo, contentDescription = "Undo")
                Spacer(modifier = Modifier.width(8.dp))
                Text("UNDO MARK", color = Color.White)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { viewModel.clearAllAnnotations() },
                colors = ButtonDefaults.buttonColors(containerColor = GrapheneFuchsia),
                modifier = Modifier.fillMaxWidth().testTag("clear_annotations")
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Clear")
                Spacer(modifier = Modifier.width(8.dp))
                Text("CLEAR STAND", color = Color.White)
            }
        }
    }
}

// --- VIEW 3: PRACTICE DESK ---
@Composable
fun PracticeView(viewModel: GrapheneViewModel) {
    val score by viewModel.selectedScore.collectAsState()
    val metronomeIsPlaying by viewModel.metronome.isPlaying.collectAsState()
    val metronomeBpm by viewModel.metronome.bpm.collectAsState()
    val metronomeBeat by viewModel.metronome.beat.collectAsState()

    val audioIsPlaying by viewModel.audio.isPlaying.collectAsState()
    val audioProgress by viewModel.audio.playbackProgress.collectAsState()
    val audioConfidence by viewModel.audio.trackingConfidence.collectAsState()

    var notesText by remember { mutableStateOf("") }

    if (score == null) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Text("No active piece mounted on stand for practice.", color = GrapheneSilver)
        }
        return
    }

    Row(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        // Metronome and timing Deck
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(GrapheneCardBg, shape = RoundedCornerShape(12.dp))
                .border(1.dp, Color.DarkGray, RoundedCornerShape(12.dp))
                .padding(24.dp)
        ) {
            Text("PRACTICE METRONOME", color = GrapheneAcidGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("TIMING ENGINE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)

            Spacer(modifier = Modifier.height(24.dp))

            // Beat Flasher count-in
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                for (b in 1..4) {
                    val isActive = metronomeIsPlaying && metronomeBeat == b
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(60.dp)
                            .background(
                                color = if (isActive) {
                                    if (b == 1) GrapheneAcidGreen else GrapheneElectricBlue
                                } else Color.Black,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .border(1.dp, Color.DarkGray, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$b",
                            color = if (isActive) Color.Black else GrapheneSilver,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text("TEMPO ADJUSTMENT (BPM)", color = GrapheneSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { viewModel.metronome.setBpm(metronomeBpm - 5) }) {
                    Icon(Icons.Default.Remove, contentDescription = "Bpm - 5", tint = Color.White, modifier = Modifier.size(32.dp))
                }
                Text(
                    "$metronomeBpm",
                    color = Color.White,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black
                )
                IconButton(onClick = { viewModel.metronome.setBpm(metronomeBpm + 5) }) {
                    Icon(Icons.Default.Add, contentDescription = "Bpm + 5", tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }

            Slider(
                value = metronomeBpm.toFloat(),
                onValueChange = { viewModel.metronome.setBpm(it.toInt()) },
                valueRange = 40f..240f,
                colors = SliderDefaults.colors(
                    activeTrackColor = GrapheneAcidGreen,
                    thumbColor = GrapheneAcidGreen
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { viewModel.metronome.tap() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("TAP TEMPO", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.metronome.togglePlay() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (metronomeIsPlaying) GrapheneFuchsia else GrapheneAcidGreen
                    ),
                    modifier = Modifier.weight(1f).testTag("metronome_play_btn")
                ) {
                    Text(
                        if (metronomeIsPlaying) "STOP METRONOME" else "START METRONOME",
                        color = if (metronomeIsPlaying) Color.White else Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(24.dp))

        // Practice session logger and audio deck
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
        ) {
            // Audio companion card
            Card(
                colors = CardDefaults.cardColors(containerColor = GrapheneCardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.DarkGray, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("AUDIO COMPANION BACKING", color = GrapheneElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Graphene Catalogue Link", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { viewModel.audio.togglePlay() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (audioIsPlaying) GrapheneFuchsia else GrapheneElectricBlue
                            )
                        ) {
                            Icon(if (audioIsPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (audioIsPlaying) "Pause Backing" else "Play Backing")
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("AUDIO FOLLOW SCORE", color = GrapheneSilver, fontSize = 10.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(GrapheneAcidGreen, RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Confidence: ${(audioConfidence * 100).toInt()}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    LinearProgressIndicator(
                        progress = audioProgress,
                        color = GrapheneElectricBlue,
                        trackColor = Color.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Session Notes logger
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(GrapheneCardBg, shape = RoundedCornerShape(12.dp))
                    .border(1.dp, Color.DarkGray, RoundedCornerShape(12.dp))
                    .padding(24.dp)
            ) {
                Text("PRACTICE SESSION LOGGER", color = GrapheneFuchsia, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Write Journal Log", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    placeholder = { Text("Log your progress: e.g. Managed tempo transition at measure 43. Work on left-hand trill.", color = GrapheneSilver) },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GrapheneFuchsia,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (notesText.isNotBlank()) {
                            viewModel.savePracticeSession(notesText)
                            notesText = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GrapheneFuchsia),
                    modifier = Modifier.fillMaxWidth().testTag("save_practice")
                ) {
                    Text("SAVE PRACTICE JOURNAL ENTRY", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// --- VIEW 4: PERFORMANCE ONBOARDING & PRE-CHECK ---
@Composable
fun PerformanceOnboardingScreen(viewModel: GrapheneViewModel) {
    val checkState by viewModel.performanceCheckState.collectAsState()
    val checkLogs by viewModel.performanceCheckLogs.collectAsState()

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize().padding(32.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .width(550.dp)
                .background(GrapheneCardBg, RoundedCornerShape(16.dp))
                .border(1.dp, Color.DarkGray, RoundedCornerShape(16.dp))
                .padding(32.dp)
        ) {
            Icon(Icons.Default.NewReleases, contentDescription = null, tint = GrapheneAcidGreen, modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))

            Text("CONCERT STAGE PREPARATION", color = GrapheneAcidGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("PERFORMANCE MODE LOCK", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Performance mode locks the setlist, suppresses background notifications, prevents screen-sleep, and mounts a distraction-free full-screen music notation stand designed for quick pedal taps.",
                color = GrapheneSilver,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { viewModel.runPerformanceSafetyCheck() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().testTag("run_perf_check")
            ) {
                Text("RUN PERFORMANCE SAFETY CHECK", color = Color.White, fontWeight = FontWeight.Bold)
            }

            if (checkState != "IDLE") {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color.Black, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    LazyColumn {
                        items(checkLogs) { log ->
                            Text(
                                log,
                                color = if (log.contains("PASS")) GrapheneAcidGreen else if (log.contains("WARN")) GrapheneFuchsia else Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                    }
                }
            }

            if (checkState == "PASSED") {
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.setPerformanceMode(true) },
                    colors = ButtonDefaults.buttonColors(containerColor = GrapheneAcidGreen),
                    modifier = Modifier.fillMaxWidth().testTag("launch_perf_mode")
                ) {
                    Text("LAUNCH PERFORMANCE CONCERT MODE", color = Color.Black, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// --- VIEW 5: FULLSCREEN LIVE CONCERT MODE ---
@Composable
fun PerformanceView(viewModel: GrapheneViewModel) {
    val score by viewModel.selectedScore.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val currentMeasure by viewModel.currentMeasure.collectAsState()
    val currentNoteIndex by viewModel.currentNoteIndex.collectAsState()
    val activeMeasures by viewModel.activeMeasures.collectAsState()

    val isLocked by viewModel.isPerformanceLocked.collectAsState()
    val setlist by viewModel.selectedSetlist.collectAsState()
    val setlistItems by viewModel.currentSetlistItems.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(12.dp)
    ) {
        // Concert header chrome
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneCardBg, shape = RoundedCornerShape(8.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(GrapheneFuchsia, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("LIVE PERFORM", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = score?.title ?: "No Score Loaded",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (setlist != null) {
                        Text("Setlist: ${setlist?.name}", color = GrapheneSilver, fontSize = 11.sp)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                // Lock toggle button
                Button(
                    onClick = { viewModel.setPerformanceLocked(!isLocked) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLocked) GrapheneAcidGreen else Color.DarkGray
                    )
                ) {
                    Icon(if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen, contentDescription = null, tint = if (isLocked) Color.Black else Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isLocked) "STAGE LOCK ON" else "LOCK CONTROLS", color = if (isLocked) Color.Black else Color.White, fontSize = 11.sp)
                }

                Button(
                    onClick = { viewModel.setPerformanceMode(false) },
                    colors = ButtonDefaults.buttonColors(containerColor = GrapheneFuchsia)
                ) {
                    Text("EXIT PERFORMANCE", color = Color.White, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Large clean score notation sheet
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
        ) {
            ScoreSheetCanvas(
                measures = activeMeasures,
                currentMeasure = currentMeasure,
                currentNoteIndex = currentNoteIndex,
                annotations = emptyList(), // Blank annotation page in concert sight-reading mode!
                drawingStrokes = emptyList(),
                currentDrawingColor = Color.Transparent,
                currentDrawingWidth = 0f,
                isDrawingMode = false,
                onStrokeFinished = {}
            )

            // Huge simulated Foot pedal tap overlay zones (left and right edges for turning pages)
            if (!isLocked) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .clickable { viewModel.prevPage() }
                            .testTag("pedal_prev_zone")
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .clickable { viewModel.nextPage() }
                            .testTag("pedal_next_zone")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Stage foot pedal dashboard console
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(GrapheneCardBg, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Text("Simulated Bluetooth Page-Turn Pedal Transmitters", color = GrapheneSilver, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { viewModel.prevPage() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                    enabled = !isLocked
                ) {
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("TAP PEDAL PREV (CC 21)", fontSize = 11.sp)
                }

                Button(
                    onClick = { viewModel.nextPage() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                    enabled = !isLocked
                ) {
                    Text("TAP PEDAL NEXT (CC 20)", fontSize = 11.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = null)
                }
            }
        }
    }
}

// --- VIEW 6: GRAPHENE CATALOGUE INTEGRATION MAP ---
@Composable
fun CatalogueView(viewModel: GrapheneViewModel) {
    val artists by viewModel.artists.collectAsState()
    val compositions by viewModel.compositions.collectAsState()
    val scores by viewModel.scores.collectAsState()
    val practiceSessions by viewModel.practiceSessions.collectAsState()

    Row(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        // Left column: A&R Leads and unreleased demo submissions
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .background(GrapheneCardBg, RoundedCornerShape(12.dp))
                .border(1.dp, Color.DarkGray, RoundedCornerShape(12.dp))
                .padding(24.dp)
        ) {
            Text("GRAPHENE RECORDS A&R", color = GrapheneAcidGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("CONFIDENTIAL LEADS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

            Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 12.dp))

            val demoLeads = listOf(
                Triple("Mara Vale", "Untitled Demo 7 - Slow Piano Loop", "UNDER REVIEW"),
                Triple("Orion Dust", "Synapse Burst (Alternate Take 4)", "APPROVED FOR EP"),
                Triple("Lyra Vance", "Glass Sky (Acoustic Vocal Stem)", "IN MASTERING"),
                Triple("Echo Pulse", "Heavy Sub Bass - Section C Loop", "AWAITING CLEARANCE")
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(demoLeads) { (artist, demo, status) ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(artist, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = if (status.contains("APPROVED")) GrapheneAcidGreen.copy(alpha = 0.2f) else GrapheneFuchsia.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        status,
                                        color = if (status.contains("APPROVED")) GrapheneAcidGreen else GrapheneFuchsia,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(demo, color = GrapheneSilver, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(24.dp))

        // Right column: Historical practice journal entries
        Column(
            modifier = Modifier
                .weight(1.5f)
                .fillMaxHeight()
                .background(GrapheneCardBg, RoundedCornerShape(12.dp))
                .border(1.dp, Color.DarkGray, RoundedCornerShape(12.dp))
                .padding(24.dp)
        ) {
            Text("PRACTICE ANALYTICS SYSTEM", color = GrapheneFuchsia, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("OFFLINE PRACTICE JOURNAL", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

            Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 12.dp))

            if (practiceSessions.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) {
                    Text("No practice entries logged. Save a journal entry from the Practice Deck.", color = GrapheneSilver, fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(practiceSessions) { session ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.Black),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(session.scoreTitle, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${session.durationSeconds}s @ ${session.tempoBpm} BPM",
                                        color = GrapheneFuchsia,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = session.notes,
                                    color = GrapheneSilver,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
