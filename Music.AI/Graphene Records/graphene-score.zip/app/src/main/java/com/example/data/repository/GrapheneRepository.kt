package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.SampleData
import com.example.data.dao.GrapheneDao
import com.example.data.database.GrapheneDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GrapheneRepository private constructor(context: Context) {

    private val db: GrapheneDatabase = Room.databaseBuilder(
        context.applicationContext,
        GrapheneDatabase::class.java,
        "graphene_score_database"
    ).fallbackToDestructiveMigration().build()

    private val dao: GrapheneDao = db.grapheneDao()

    init {
        // Automatically pre-populate database if empty on startup
        CoroutineScope(Dispatchers.IO).launch {
            prepopulateIfNeeded()
        }
    }

    private suspend fun prepopulateIfNeeded() {
        val existingArtists = dao.getAllArtists().first()
        if (existingArtists.isEmpty()) {
            dao.insertArtists(SampleData.artists)
            dao.insertCompositions(SampleData.compositions)
            dao.insertScores(SampleData.scores)
            dao.insertSetlists(SampleData.setlists)
            dao.insertSetlistItems(SampleData.setlistItems)
        }
    }

    // --- ARTISTS ---
    fun getAllArtists(): Flow<List<Artist>> = dao.getAllArtists()

    // --- COMPOSITIONS ---
    fun getAllCompositions(): Flow<List<Composition>> = dao.getAllCompositions()
    fun getCompositionsByArtist(artistId: String): Flow<List<Composition>> = dao.getCompositionsByArtist(artistId)

    // --- SCORES ---
    fun getAllScores(): Flow<List<Score>> = dao.getAllScores()
    fun getScoresForComposition(compositionId: String): Flow<List<Score>> = dao.getScoresForComposition(compositionId)
    suspend fun getScoreById(scoreId: String): Score? = withContext(Dispatchers.IO) {
        dao.getScoreById(scoreId)
    }

    // --- ANNOTATIONS ---
    fun getAnnotationsForScore(scoreId: String): Flow<List<GrapheneAnnotation>> = dao.getAnnotationsForScore(scoreId)
    suspend fun insertAnnotation(annotation: GrapheneAnnotation) = withContext(Dispatchers.IO) {
        dao.insertAnnotation(annotation)
    }
    suspend fun deleteAnnotationById(id: String) = withContext(Dispatchers.IO) {
        dao.deleteAnnotationById(id)
    }
    suspend fun clearAnnotationsForScore(scoreId: String) = withContext(Dispatchers.IO) {
        dao.clearAnnotationsForScore(scoreId)
    }

    // --- SETLISTS ---
    fun getAllSetlists(): Flow<List<Setlist>> = dao.getAllSetlists()
    suspend fun insertSetlist(setlist: Setlist) = withContext(Dispatchers.IO) {
        dao.insertSetlist(setlist)
    }
    suspend fun deleteSetlistById(setlistId: String) = withContext(Dispatchers.IO) {
        dao.deleteSetlistById(setlistId)
    }

    // --- SETLIST ITEMS ---
    fun getItemsForSetlist(setlistId: String): Flow<List<SetlistItem>> = dao.getItemsForSetlist(setlistId)
    suspend fun insertSetlistItem(item: SetlistItem) = withContext(Dispatchers.IO) {
        dao.insertSetlistItem(item)
    }
    suspend fun insertSetlistItems(items: List<SetlistItem>) = withContext(Dispatchers.IO) {
        dao.insertSetlistItems(items)
    }
    suspend fun deleteSetlistItemById(id: String) = withContext(Dispatchers.IO) {
        dao.deleteSetlistItemById(id)
    }
    suspend fun clearSetlistItems(setlistId: String) = withContext(Dispatchers.IO) {
        dao.clearSetlistItems(setlistId)
    }

    // --- PRACTICE SESSIONS ---
    fun getAllPracticeSessions(): Flow<List<PracticeSession>> = dao.getAllPracticeSessions()
    suspend fun insertPracticeSession(session: PracticeSession) = withContext(Dispatchers.IO) {
        dao.insertPracticeSession(session)
    }

    companion object {
        @Volatile
        private var INSTANCE: GrapheneRepository? = null

        fun getInstance(context: Context): GrapheneRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = GrapheneRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
