package com.example.midi

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

enum class MidiAction {
    NEXT_PAGE,
    PREVIOUS_PAGE,
    NEXT_SCORE,
    PREVIOUS_SCORE,
    START_METRONOME,
    STOP_METRONOME,
    RESTART_SECTION,
    TOGGLE_FULLSCREEN
}

data class MidiMapEntry(
    val triggerType: String, // "CC", "NOTE", "PROGRAM_CHANGE"
    val channel: Int,
    val value: Int, // note number, CC number, or program number
    val action: MidiAction
)

class MidiManager {

    private val _connectedDevices = MutableStateFlow<List<String>>(listOf("Graphene Virtual MIDI", "AirTurn Duo Pedal (Simulated)"))
    val connectedDevices: StateFlow<List<String>> = _connectedDevices.asStateFlow()

    private val _midiLog = MutableStateFlow<List<String>>(listOf("MIDI System Initialized", "Device 'Graphene Virtual MIDI' listening"))
    val midiLog: StateFlow<List<String>> = _midiLog.asStateFlow()

    private val _commandMap = MutableStateFlow(
        listOf(
            MidiMapEntry("CC", 1, 20, MidiAction.NEXT_PAGE),
            MidiMapEntry("CC", 1, 21, MidiAction.PREVIOUS_PAGE),
            MidiMapEntry("NOTE", 1, 60, MidiAction.START_METRONOME), // C4 note
            MidiMapEntry("NOTE", 1, 62, MidiAction.STOP_METRONOME),  // D4 note
            MidiMapEntry("PROGRAM_CHANGE", 1, 10, MidiAction.NEXT_SCORE)
        )
    )
    val commandMap: StateFlow<List<MidiMapEntry>> = _commandMap.asStateFlow()

    // Event bus to broadcast triggered actions to the UI
    private val _actionTriggered = MutableSharedFlow<MidiAction>(replay = 0)
    val actionTriggered: SharedFlow<MidiAction> = _actionTriggered.asSharedFlow()

    suspend fun simulateMidiInput(type: String, channel: Int, value: Int) {
        val typeStr = type.uppercase()
        val desc = "Received MIDI: $typeStr on Ch $channel with val $value"
        addLog(desc)

        // Lookup action in mapping
        val match = _commandMap.value.firstOrNull {
            it.triggerType.equals(typeStr, ignoreCase = true) && it.channel == channel && it.value == value
        }

        if (match != null) {
            addLog("-> Action triggered: ${match.action.name}")
            _actionTriggered.emit(match.action)
        } else {
            addLog("-> Unmapped input event")
        }
    }

    fun updateMapping(entry: MidiMapEntry) {
        val updatedList = _commandMap.value.toMutableList()
        // Replace existing action mapping if exists
        updatedList.removeAll { it.action == entry.action }
        updatedList.add(entry)
        _commandMap.value = updatedList
        addLog("Updated mapping for action: ${entry.action.name}")
    }

    fun addDevice(name: String) {
        _connectedDevices.value = _connectedDevices.value + name
        addLog("Connected MIDI device: $name")
    }

    fun removeDevice(name: String) {
        _connectedDevices.value = _connectedDevices.value.filter { it != name }
        addLog("Disconnected MIDI device: $name")
    }

    private fun addLog(message: String) {
        val logs = _midiLog.value.toMutableList()
        logs.add(0, message) // Insert at top
        if (logs.size > 20) logs.removeAt(logs.size - 1)
        _midiLog.value = logs
    }

    fun clearLog() {
        _midiLog.value = listOf("Logs Cleared")
    }
}
