package com.example.rendering

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GrapheneAnnotation
import com.example.data.model.CanonicalMeasure
import com.example.data.model.StrokePoint
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@OptIn(ExperimentalTextApi::class)
@Composable
fun ScoreSheetCanvas(
    measures: List<CanonicalMeasure>,
    currentMeasure: Int, // 1-indexed
    currentNoteIndex: Int, // 0-indexed
    annotations: List<GrapheneAnnotation>,
    drawingStrokes: List<List<StrokePoint>>,
    currentDrawingColor: Color,
    currentDrawingWidth: Float,
    isDrawingMode: Boolean,
    onStrokeFinished: (List<StrokePoint>) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    var currentStroke = remember { mutableStateListOf<StrokePoint>() }

    val canvasModifier = if (isDrawingMode) {
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        currentStroke.clear()
                        currentStroke.add(StrokePoint(offset.x, offset.y))
                    },
                    onDragEnd = {
                        if (currentStroke.isNotEmpty()) {
                            onStrokeFinished(currentStroke.toList())
                            currentStroke.clear()
                        }
                    },
                    onDragCancel = {
                        currentStroke.clear()
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val pos = change.position
                        currentStroke.add(StrokePoint(pos.x, pos.y))
                    }
                )
            }
    } else {
        modifier.fillMaxSize()
    }

    Canvas(modifier = canvasModifier) {
        val width = size.width
        val height = size.height

        // 1. Draw Pristine Warm-White Sheet Music Page Background
        drawRect(color = Color(0xFFFBFBF9))

        if (measures.isEmpty()) {
            // Draw placeholder if no measures
            drawText(
                textMeasurer = textMeasurer,
                text = "NO NOTATION AVAILABLE",
                topLeft = Offset(width / 2 - 100f, height / 2 - 20f),
                style = TextStyle(color = Color.Gray, fontSize = 16.sp)
            )
            return@Canvas
        }

        // 2. Render Music Notation (Staves, notes, clefs, lyrics, chords)
        val systemPaddingLeft = 60f
        val systemWidth = width - 120f
        val lineSpacing = 16f
        val staffHeight = lineSpacing * 4

        // Position of the system in the middle of the page
        val systemTopY = height / 3f

        // Draw staff lines
        drawStaffLines(systemTopY, systemPaddingLeft, systemWidth, lineSpacing)

        // Draw stylized Treble Clef
        drawTrebleClef(systemTopY, systemPaddingLeft + 15f, lineSpacing)

        // Render Measures
        val measureCount = measures.size
        val measureWidth = systemWidth / measureCount

        var measureLeftX = systemPaddingLeft

        for (i in 0 until measureCount) {
            val measure = measures[i]
            val isCurrentMeasure = (i + 1) == currentMeasure

            // Draw measure boundaries
            if (i > 0) {
                drawLine(
                    color = Color.Black,
                    start = Offset(measureLeftX, systemTopY),
                    end = Offset(measureLeftX, systemTopY + staffHeight),
                    strokeWidth = 2f
                )
            }

            // Draw Measure Number
            drawText(
                textMeasurer = textMeasurer,
                text = "${measure.number}",
                topLeft = Offset(measureLeftX + 10f, systemTopY - 35f),
                style = TextStyle(color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            )

            // Draw Section Marker if present
            measure.sectionMarker?.let { section ->
                drawRect(
                    color = Color(0xFF23C13D), // Graphene Acid Green highlight for sections
                    topLeft = Offset(measureLeftX + 10f, systemTopY - 70f),
                    size = Size(80f, 30f)
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = section,
                    topLeft = Offset(measureLeftX + 15f, systemTopY - 65f),
                    style = TextStyle(color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                )
            }

            // Draw measure highlight if currently reading here (probabilistic follow cursor)
            if (isCurrentMeasure) {
                drawRect(
                    color = Color(0x15007AFF), // subtle blue fill
                    topLeft = Offset(measureLeftX, systemTopY - 20f),
                    size = Size(measureWidth, staffHeight + 40f)
                )
            }

            // Draw Notes in this measure
            val notes = measure.notes
            if (notes.isNotEmpty()) {
                val noteSpacing = measureWidth / (notes.size + 1)
                for (nIndex in 0 until notes.size) {
                    val note = notes[nIndex]
                    val isCurrentNote = isCurrentMeasure && nIndex == currentNoteIndex

                    val noteCenterX = measureLeftX + noteSpacing * (nIndex + 1)

                    // Draw note (stem, head, beams, ledger lines)
                    drawCanonicalNote(
                        note = note,
                        centerX = noteCenterX,
                        systemTopY = systemTopY,
                        lineSpacing = lineSpacing,
                        isHighlighted = isCurrentNote,
                        textMeasurer = textMeasurer
                    )
                }
            }

            measureLeftX += measureWidth
        }

        // Draw final double barline
        val finalBarX = systemPaddingLeft + systemWidth
        drawLine(
            color = Color.Black,
            start = Offset(finalBarX - 4f, systemTopY),
            end = Offset(finalBarX - 4f, systemTopY + staffHeight),
            strokeWidth = 1.5f
        )
        drawLine(
            color = Color.Black,
            start = Offset(finalBarX, systemTopY),
            end = Offset(finalBarX, systemTopY + staffHeight),
            strokeWidth = 5f
        )

        // 3. Render Non-Destructive Vector & Stamp Annotation Layers
        drawStoredAnnotations(annotations, textMeasurer)

        // 4. Render Active Freehand Drawing Strokes (Touch Engine)
        drawFreehandStrokes(drawingStrokes, currentStroke.toList(), currentDrawingColor, currentDrawingWidth)
    }
}

private fun DrawScope.drawStaffLines(topY: Float, leftX: Float, width: Float, spacing: Float) {
    for (line in 0..4) {
        val y = topY + line * spacing
        drawLine(
            color = Color(0xFFD0D0D0),
            start = Offset(leftX, y),
            end = Offset(leftX + width, y),
            strokeWidth = 1.5f
        )
    }
}

private fun DrawScope.drawTrebleClef(topY: Float, startX: Float, spacing: Float) {
    // Stylized artistic treble clef drawing using paths
    val clefPath = Path().apply {
        moveTo(startX, topY + spacing * 4.5f)
        cubicTo(
            startX + 12f, topY + spacing * 4.5f,
            startX + 22f, topY + spacing * 3f,
            startX + 12f, topY + spacing * 2f
        )
        cubicTo(
            startX + 2f, topY + spacing,
            startX + 12f, topY - spacing,
            startX + 12f, topY - spacing * 1.5f
        )
        lineTo(startX + 12f, topY + spacing * 5f)
        cubicTo(
            startX + 12f, topY + spacing * 5.5f,
            startX + 8f, topY + spacing * 5.8f,
            startX + 5f, topY + spacing * 5.5f
        )
    }
    drawPath(
        path = clefPath,
        color = Color(0xFF333333),
        style = Stroke(width = 3f)
    )
    drawCircle(
        color = Color(0xFF333333),
        radius = 4f,
        center = Offset(startX + 5f, topY + spacing * 5.5f)
    )
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawCanonicalNote(
    note: com.example.data.model.CanonicalNote,
    centerX: Float,
    systemTopY: Float,
    lineSpacing: Float,
    isHighlighted: Boolean,
    textMeasurer: TextMeasurer
) {
    // Calculate pitch height index relative to Middle B4 (center line of treble staff, index 0)
    // E4 is 4 steps below B4, etc.
    val pitchStepsFromB4 = when (note.pitch) {
        "G5" -> 5
        "F5" -> 4
        "E5" -> 3
        "D5" -> 2
        "C5" -> 1
        "B4" -> 0
        "A4" -> -1
        "G4" -> -2
        "F4" -> -3
        "E4" -> -4
        "D4" -> -5
        "C4" -> -6
        else -> 0
    }

    val noteY = systemTopY + (lineSpacing * 2) - (pitchStepsFromB4 * (lineSpacing / 2f))

    val themeColor = if (isHighlighted) Color(0xFF007AFF) else Color(0xFF1E1E1C)

    if (note.pitch == "R") {
        // Draw rest symbol
        if (note.durationType == "WHOLE") {
            drawRect(
                color = themeColor,
                topLeft = Offset(centerX - 8f, systemTopY + lineSpacing),
                size = Size(16f, 8f)
            )
        } else if (note.durationType == "HALF") {
            drawRect(
                color = themeColor,
                topLeft = Offset(centerX - 8f, systemTopY + lineSpacing * 1.5f),
                size = Size(16f, 8f)
            )
        } else {
            // Stylized quarter/eighth rest squiggle
            val restPath = Path().apply {
                moveTo(centerX - 4f, systemTopY + lineSpacing)
                lineTo(centerX + 4f, systemTopY + lineSpacing * 1.5f)
                lineTo(centerX - 4f, systemTopY + lineSpacing * 2.2f)
                cubicTo(
                    centerX - 4f, systemTopY + lineSpacing * 2.7f,
                    centerX + 4f, systemTopY + lineSpacing * 3.2f,
                    centerX + 2f, systemTopY + lineSpacing * 3.5f
                )
            }
            drawPath(path = restPath, color = themeColor, style = Stroke(width = 3f))
        }
    } else {
        // 1. Draw Ledger lines if needed (C4 or lower, or A5 or higher)
        if (pitchStepsFromB4 <= -6) { // C4 is step -6
            drawLine(
                color = Color.Gray,
                start = Offset(centerX - 16f, systemTopY + lineSpacing * 5f),
                end = Offset(centerX + 16f, systemTopY + lineSpacing * 5f),
                strokeWidth = 1.5f
            )
        }

        // 2. Draw Notehead (filled oval or empty oval depending on duration)
        val noteWidth = 18f
        val noteHeight = 12f
        val noteHeadPath = Path().apply {
            addOval(
                androidx.compose.ui.geometry.Rect(
                    left = centerX - noteWidth / 2f,
                    top = noteY - noteHeight / 2f,
                    right = centerX + noteWidth / 2f,
                    bottom = noteY + noteHeight / 2f
                )
            )
        }

        if (note.durationType == "WHOLE") {
            drawPath(path = noteHeadPath, color = themeColor, style = Stroke(width = 3.5f))
        } else if (note.durationType == "HALF") {
            drawPath(path = noteHeadPath, color = themeColor, style = Stroke(width = 3.5f))
            // Draw stem
            val stemUp = pitchStepsFromB4 < 0
            val stemEndY = if (stemUp) noteY - 50f else noteY + 50f
            val stemX = if (stemUp) centerX + (noteWidth / 2f) - 1.5f else centerX - (noteWidth / 2f) + 1.5f
            drawLine(
                color = themeColor,
                start = Offset(stemX, noteY),
                end = Offset(stemX, stemEndY),
                strokeWidth = 2.5f
            )
        } else {
            // Filled quarter/eighth note
            drawPath(path = noteHeadPath, color = themeColor)

            // Draw stem
            val stemUp = pitchStepsFromB4 < 0
            val stemEndY = if (stemUp) noteY - 50f else noteY + 50f
            val stemX = if (stemUp) centerX + (noteWidth / 2f) - 1.5f else centerX - (noteWidth / 2f) + 1.5f
            drawLine(
                color = themeColor,
                start = Offset(stemX, noteY),
                end = Offset(stemX, stemEndY),
                strokeWidth = 2.5f
            )

            // Draw flag for eighth notes
            if (note.durationType == "EIGHTH") {
                val flagPath = Path().apply {
                    moveTo(stemX, stemEndY)
                    if (stemUp) {
                        cubicTo(
                            stemX + 10f, stemEndY + 10f,
                            stemX + 15f, stemEndY + 15f,
                            stemX + 12f, stemEndY + 25f
                        )
                        cubicTo(
                            stemX + 8f, stemEndY + 18f,
                            stemX, stemEndY + 10f,
                            stemX, stemEndY + 8f
                        )
                    } else {
                        cubicTo(
                            stemX + 10f, stemEndY - 10f,
                            stemX + 15f, stemEndY - 15f,
                            stemX + 12f, stemEndY - 25f
                        )
                        cubicTo(
                            stemX + 8f, stemEndY - 18f,
                            stemX, stemEndY - 10f,
                            stemX, stemEndY - 8f
                        )
                    }
                }
                drawPath(path = flagPath, color = themeColor)
            }
        }

        // 3. Draw slurs/ties if marked
        if (note.isSlurStart) {
            val slurPath = Path().apply {
                moveTo(centerX, noteY + 15f)
                quadraticTo(centerX + 60f, noteY + 35f, centerX + 120f, noteY + 15f)
            }
            drawPath(path = slurPath, color = Color(0x708E8E93), style = Stroke(width = 2f))
        }

        // 4. Draw Chord symbol above
        note.chord?.let { chord ->
            drawText(
                textMeasurer = textMeasurer,
                text = chord,
                topLeft = Offset(centerX - 15f, systemTopY - 45f),
                style = TextStyle(color = Color(0xFF007AFF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            )
        }

        // 5. Draw Lyric below
        note.lyrics?.let { lyric ->
            drawText(
                textMeasurer = textMeasurer,
                text = lyric,
                topLeft = Offset(centerX - 15f, systemTopY + lineSpacing * 5f + 15f),
                style = TextStyle(color = Color(0xFF2C2C2E), fontSize = 11.sp, fontWeight = FontWeight.Medium)
            )
        }

        // 6. Draw Dynamics below lyric
        note.dynamic?.let { dyn ->
            drawText(
                textMeasurer = textMeasurer,
                text = dyn,
                topLeft = Offset(centerX - 10f, systemTopY + lineSpacing * 5f + 40f),
                style = TextStyle(color = Color(0xFF9E005D), fontSize = 12.sp, fontWeight = FontWeight.Black) // Restrained Fuchsia
            )
        }

        // 7. Draw Articulation (like staccato/accent)
        note.articulation?.let { art ->
            if (art == "staccato") {
                drawCircle(
                    color = themeColor,
                    radius = 2.5f,
                    center = Offset(centerX, noteY - 12f)
                )
            } else if (art == "accent") {
                val accPath = Path().apply {
                    moveTo(centerX - 4f, noteY - 15f)
                    lineTo(centerX + 4f, noteY - 12f)
                    lineTo(centerX - 4f, noteY - 9f)
                }
                drawPath(path = accPath, color = themeColor, style = Stroke(width = 1.5f))
            }
        }
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawStoredAnnotations(annotations: List<GrapheneAnnotation>, textMeasurer: TextMeasurer) {
    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    val strokeType = Types.newParameterizedType(List::class.java, StrokePoint::class.java)
    val strokeAdapter = moshi.adapter<List<StrokePoint>>(strokeType)

    for (ann in annotations) {
        val layerColor = when (ann.layerId) {
            "CONDUCTOR" -> Color(0xFF23C13D) // acid green
            "BAND" -> Color(0xFF005DFF) // electric blue
            "PERSONAL" -> Color(0xFF9E005D) // fuchsia
            else -> Color(0xFFE31B23) // red
        }

        when (ann.type) {
            "FREEHAND" -> {
                try {
                    val points: List<StrokePoint>? = strokeAdapter.fromJson(ann.strokePointsJson)
                    if (points != null && points.size > 1) {
                        val path = Path()
                        path.moveTo(points[0].x, points[0].y)
                        for (j in 1 until points.size) {
                            path.lineTo(points[j].x, points[j].y)
                        }
                        drawPath(
                            path = path,
                            color = Color(ann.strokeColor),
                            style = Stroke(width = ann.strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                        )
                    }
                } catch (e: Exception) {
                    // Fail gracefully
                }
            }
            "HIGHLIGHT" -> {
                // Draw transparent highlighter yellow bar
                drawRect(
                    color = Color(0x35FFCC00),
                    topLeft = Offset(ann.x, ann.y),
                    size = Size(ann.width, ann.height)
                )
            }
            "TEXT" -> {
                drawText(
                    textMeasurer = textMeasurer,
                    text = ann.textContent,
                    topLeft = Offset(ann.x, ann.y),
                    style = TextStyle(color = layerColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                )
            }
            "SYMBOL" -> {
                // Render stylized musical stamp annotations
                drawCircle(
                    color = layerColor.copy(alpha = 0.2f),
                    radius = 16f,
                    center = Offset(ann.x, ann.y)
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = ann.symbolType,
                    topLeft = Offset(ann.x - 8f, ann.y - 10f),
                    style = TextStyle(color = layerColor, fontSize = 12.sp, fontWeight = FontWeight.Black)
                )
            }
        }
    }
}

private fun DrawScope.drawFreehandStrokes(
    drawingStrokes: List<List<StrokePoint>>,
    currentStroke: List<StrokePoint>,
    color: Color,
    width: Float
) {
    // Draw past strokes
    for (stroke in drawingStrokes) {
        if (stroke.size > 1) {
            val path = Path()
            path.moveTo(stroke[0].x, stroke[0].y)
            for (j in 1 until stroke.size) {
                path.lineTo(stroke[j].x, stroke[j].y)
            }
            drawPath(
                path = path,
                color = color,
                style = Stroke(width = width, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
    }

    // Draw active stroke
    if (currentStroke.size > 1) {
        val path = Path()
        path.moveTo(currentStroke[0].x, currentStroke[0].y)
        for (j in 1 until currentStroke.size) {
            path.lineTo(currentStroke[j].x, currentStroke[j].y)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = width, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
    }
}
