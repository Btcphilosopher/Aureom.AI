package com.example.audio

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioEngine {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f) // 0.0f to 1.0f
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f) // 0.5f to 2.0f
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _volume = MutableStateFlow(0.8f) // 0f to 1f
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private val _isLooping = MutableStateFlow(false)
    val isLooping: StateFlow<Boolean> = _isLooping.asStateFlow()

    // Loop bounds (expressed in progress percentage)
    private val _loopStart = MutableStateFlow(0.3f)
    val loopStart: StateFlow<Float> = _loopStart.asStateFlow()

    private val _loopEnd = MutableStateFlow(0.6f)
    val loopEnd: StateFlow<Float> = _loopEnd.asStateFlow()

    // Confidence mapping for score position tracking
    private val _trackingConfidence = MutableStateFlow(0.95f) // Probabilistic audio-to-score tracking
    val trackingConfidence: StateFlow<Float> = _trackingConfidence.asStateFlow()

    private val _currentTrackMeasure = MutableStateFlow(1)
    val currentTrackMeasure: StateFlow<Int> = _currentTrackMeasure.asStateFlow()

    private var playbackJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    fun togglePlay() {
        if (_isPlaying.value) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        _isPlaying.value = true
        playbackJob?.cancel()
        playbackJob = scope.launch {
            while (isActive && _isPlaying.value) {
                val step = 0.01f * _playbackSpeed.value
                var nextProgress = _playbackProgress.value + step

                if (_isLooping.value && nextProgress >= _loopEnd.value) {
                    nextProgress = _loopStart.value
                } else if (nextProgress >= 1.0f) {
                    nextProgress = 0.0f
                    _isPlaying.value = false
                }

                _playbackProgress.value = nextProgress

                // Map progress to measures (assume 32 measures total)
                val totalMeasures = 32
                val calculatedMeasure = (nextProgress * totalMeasures).toInt() + 1
                _currentTrackMeasure.value = calculatedMeasure.coerceIn(1, totalMeasures)

                // Probabilistic tracking confidence fluctuates slightly representing real-time audio analysis
                _trackingConfidence.value = (0.92f + (Math.sin(nextProgress.toDouble() * 30).toFloat() * 0.05f)).coerceIn(0f, 1f)

                delay(100)
            }
        }
    }

    fun pause() {
        _isPlaying.value = false
        playbackJob?.cancel()
    }

    fun stop() {
        pause()
        _playbackProgress.value = 0f
        _currentTrackMeasure.value = 1
    }

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed.coerceIn(0.5f, 2.0f)
    }

    fun setVolume(vol: Float) {
        _volume.value = vol.coerceIn(0f, 1f)
    }

    fun toggleLoop() {
        _isLooping.value = !_isLooping.value
    }

    fun setLoopPoints(start: Float, end: Float) {
        _loopStart.value = start.coerceIn(0f, 1f)
        _loopEnd.value = end.coerceIn(start, 1f)
    }

    fun seekTo(progress: Float) {
        _playbackProgress.value = progress.coerceIn(0f, 1f)
        val totalMeasures = 32
        _currentTrackMeasure.value = ((_playbackProgress.value * totalMeasures).toInt() + 1).coerceIn(1, totalMeasures)
    }

    fun release() {
        stop()
    }
}
