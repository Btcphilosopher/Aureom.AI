package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "artists")
@JsonClass(generateAdapter = true)
data class Artist(
    @PrimaryKey val id: String,
    val name: String,
    val bio: String,
    val imageUrl: String
)

@Entity(tableName = "compositions")
@JsonClass(generateAdapter = true)
data class Composition(
    @PrimaryKey val id: String,
    val title: String,
    val artistId: String,
    val composer: String,
    val genre: String,
    val keySignature: String,
    val baseTempoBpm: Int,
    val tags: List<String> = emptyList(),
    val releaseCode: String = "" // e.g. Graphene G-014
)

@Entity(tableName = "scores")
@JsonClass(generateAdapter = true)
data class Score(
    @PrimaryKey val id: String,
    val compositionId: String,
    val title: String, // e.g. "Piano - Original", "Band - Live Arrangement"
    val instrument: String, // Piano, Guitar, Bass, Strings, Brass, Full Score
    val difficulty: String, // Easy, Medium, Advanced, Professional
    val isGrapheneCatalogue: Boolean = true,
    val isDownloaded: Boolean = true,
    val hasAudioAttached: Boolean = false,
    val currentVersionName: String = "Original"
)

@Entity(tableName = "annotations")
@JsonClass(generateAdapter = true)
data class GrapheneAnnotation(
    @PrimaryKey val id: String,
    val scoreId: String,
    val pageNumber: Int,
    val layerId: String, // PERSONAL, BAND, CONDUCTOR, REHEARSAL
    val type: String, // FREEHAND, HIGHLIGHT, TEXT, SYMBOL
    val x: Float = 0f,
    val y: Float = 0f,
    val width: Float = 0f,
    val height: Float = 0f,
    val strokePointsJson: String = "[]", // List of points for vector drawings
    val strokeColor: Int = 0,
    val strokeWidth: Float = 4f,
    val textContent: String = "",
    val symbolType: String = "", // p, pp, f, ff, breath, staccato, accent, up_bow, down_bow, rehearsal_a, rehearsal_b
    val author: String = "Conductor",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "setlists")
@JsonClass(generateAdapter = true)
data class Setlist(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false,
    val eventName: String = "",
    val venue: String = "",
    val performanceDate: String = ""
)

@Entity(tableName = "setlist_items")
@JsonClass(generateAdapter = true)
data class SetlistItem(
    @PrimaryKey val id: String,
    val setlistId: String,
    val scoreId: String,
    val songTitle: String,
    val artistName: String,
    val position: Int,
    val performanceNotes: String = ""
)

@Entity(tableName = "practice_sessions")
@JsonClass(generateAdapter = true)
data class PracticeSession(
    @PrimaryKey val id: String,
    val scoreId: String,
    val scoreTitle: String,
    val startTime: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0,
    val tempoBpm: Int = 80,
    val sectionsPracticed: List<String> = emptyList(),
    val notes: String = "",
    val completionPct: Int = 0
)

// Embedded structures representing the actual vector/canonical notes of the score
@JsonClass(generateAdapter = true)
data class StrokePoint(
    val x: Float,
    val y: Float,
    val pressure: Float = 1.0f
)

@JsonClass(generateAdapter = true)
data class CanonicalNote(
    val pitch: String, // C4, E4, G4, R (Rest)
    val durationType: String, // WHOLE, HALF, QUARTER, EIGHTH
    val lyrics: String? = null,
    val chord: String? = null,
    val dynamic: String? = null, // p, pp, f, ff
    val articulation: String? = null, // staccato, accent, fermata
    val isSlurStart: Boolean = false,
    val isSlurEnd: Boolean = false
)

@JsonClass(generateAdapter = true)
data class CanonicalMeasure(
    val number: Int,
    val timeSignature: String = "4/4", // e.g. "4/4", "3/4"
    val sectionMarker: String? = null, // "INTRO", "VERSE", "CHORUS", "SOLO", "CODA"
    val notes: List<CanonicalNote> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ScorePageDefinition(
    val pageNumber: Int,
    val measures: List<CanonicalMeasure> = emptyList()
)
