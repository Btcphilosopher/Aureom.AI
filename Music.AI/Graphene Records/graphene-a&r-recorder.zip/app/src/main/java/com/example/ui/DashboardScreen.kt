package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import com.example.audio.DspCore
import java.io.File
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.RecordingState
import com.example.data.Artist
import com.example.data.Project
import com.example.data.Recording
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val artists by viewModel.artists.collectAsStateWithLifecycle()

    val context = LocalContext.current

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(GrapheneBlack),
        bottomBar = {
            NavigationBar(
                containerColor = GrapheneDarkGraphite,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .background(GrapheneLightGraphite)
                    .padding(top = 1.dp)
                    .navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = currentTab == "SCOUT",
                    onClick = { viewModel.currentTab.value = "SCOUT" },
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Scout Mode") },
                    label = { Text("SCOUT", fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GrapheneAcidGreen,
                        selectedTextColor = GrapheneAcidGreen,
                        indicatorColor = GrapheneLightGraphite,
                        unselectedIconColor = GrapheneSilver,
                        unselectedTextColor = GrapheneSilver
                    )
                )
                NavigationBarItem(
                    selected = currentTab == "LIBRARY",
                    onClick = { viewModel.currentTab.value = "LIBRARY" },
                    icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Vault") },
                    label = { Text("VAULT", fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GrapheneAcidGreen,
                        selectedTextColor = GrapheneAcidGreen,
                        indicatorColor = GrapheneLightGraphite,
                        unselectedIconColor = GrapheneSilver,
                        unselectedTextColor = GrapheneSilver
                    )
                )
                NavigationBarItem(
                    selected = currentTab == "COMPARE",
                    onClick = { viewModel.currentTab.value = "COMPARE" },
                    icon = { Icon(Icons.Default.Compare, contentDescription = "A/B Compare") },
                    label = { Text("A/B", fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GrapheneAcidGreen,
                        selectedTextColor = GrapheneAcidGreen,
                        indicatorColor = GrapheneLightGraphite,
                        unselectedIconColor = GrapheneSilver,
                        unselectedTextColor = GrapheneSilver
                    )
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GrapheneBlack)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GrapheneLightGraphite)
                    .padding(bottom = 1.dp)
                    .background(GrapheneDarkGraphite)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "GRAPHENE",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = 1.5.sp,
                        color = GrapheneOffWhite
                    )
                    Text(
                        text = "A&R RECORDER | FIELD INSTRUMENT",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        color = GrapheneSilver
                    )
                }

                // Input Manager Display Status
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrapheneLightGraphite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(GrapheneAcidGreen, RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "48.0 kHz | 16-BIT | MONO",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = GrapheneOffWhite
                        )
                    }
                }
            }

            // Tab Navigation Screens
            when (currentTab) {
                "SCOUT" -> ScoutTab(viewModel, projects, artists)
                "LIBRARY" -> VaultTab(viewModel, projects, artists)
                "COMPARE" -> CompareTab(viewModel)
            }
        }
    }
}

@Composable
fun ScoutTab(
    viewModel: MainViewModel,
    projects: List<Project>,
    artists: List<Artist>
) {
    val recordState by viewModel.audioEngine.state.collectAsStateWithLifecycle()
    val rms by viewModel.audioEngine.rmsLevelL.collectAsStateWithLifecycle()
    val peak by viewModel.audioEngine.peakLevelL.collectAsStateWithLifecycle()
    val duration by viewModel.audioEngine.durationMs.collectAsStateWithLifecycle()
    val liveWaveform by viewModel.audioEngine.liveWaveform.collectAsStateWithLifecycle()

    val selectedProj by viewModel.selectedProject.collectAsStateWithLifecycle()
    val selectedArt by viewModel.selectedArtist.collectAsStateWithLifecycle()
    val selectedVenue by viewModel.selectedVenue.collectAsStateWithLifecycle()

    var showProjectDialog by remember { mutableStateOf(false) }
    var showArtistDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Technical Info Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneLightGraphite)
                .background(GrapheneDarkGraphite)
                .padding(14.dp)
        ) {
            Text(
                text = "HARDWARE CAPTURE PROFILE",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = GrapheneSilver
            )
            Divider(color = GrapheneLightGraphite, modifier = Modifier.padding(vertical = 8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MetadataColumn("DEVICE", "BUILT-IN MIC")
                MetadataColumn("CHANNELS", "1 MONO")
                MetadataColumn("PRE-ROLL", "${viewModel.audioEngine.preRecordDurationSeconds} SEC")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Pre-Record Buffer Configurator (Requirement #14)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "PRE-RECORD BUFFER:",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = GrapheneSilver
                )
                Row {
                    listOf(0, 3, 5, 10).forEach { sec ->
                        val isSelected = viewModel.audioEngine.preRecordDurationSeconds == sec
                        Box(
                            modifier = Modifier
                                .border(1.dp, if (isSelected) GrapheneAcidGreen else GrapheneLightGraphite, RoundedCornerShape(2.dp))
                                .background(if (isSelected) GrapheneAcidGreen else Color.Transparent)
                                .clickable { viewModel.audioEngine.preRecordDurationSeconds = sec }
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${sec}S",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) GrapheneBlack else GrapheneSilver
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Level Meters and Waveform Display
        GrapheneMeter(rms = rms, peak = peak, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(12.dp))

        // Live Waveform Canvas (Requirement #9)
        Text(
            text = "LIVE WAVEFORM",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = GrapheneSilver,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        GrapheneWaveform(
            peaks = liveWaveform,
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Large Dominant Recording Controls (Requirement #3, #4, #45)
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Armed status text
            Text(
                text = when (recordState) {
                    RecordingState.IDLE -> "SYSTEM READY"
                    RecordingState.ARMED -> "RECORD ARMED"
                    RecordingState.RECORDING -> "RECORDING LIVE"
                    else -> recordState.name
                },
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = when (recordState) {
                    RecordingState.RECORDING -> GrapheneFuchsia
                    RecordingState.ARMED -> GrapheneElectricBlue
                    else -> GrapheneSilver
                }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Duration Monospace (Requirement #8)
            val sec = (duration / 1000) % 60
            val min = (duration / 60000) % 60
            val ms = (duration % 1000) / 100
            val durationText = String.format("%02d:%02d.%d", min, sec, ms)

            Text(
                text = durationText,
                fontSize = 42.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (recordState == RecordingState.RECORDING) GrapheneOffWhite else GrapheneSilver,
                letterSpacing = (-1).sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Big Record Buttons Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                // ARM Button
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .border(
                            1.dp,
                            if (recordState == RecordingState.ARMED) GrapheneElectricBlue else GrapheneSilver,
                            RoundedCornerShape(30.dp)
                        )
                        .background(if (recordState == RecordingState.ARMED) GrapheneElectricBlue.copy(alpha = 0.1f) else Color.Transparent)
                        .clickable { viewModel.toggleArm() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Circle,
                        contentDescription = "Arm Recorder",
                        tint = if (recordState == RecordingState.ARMED) GrapheneElectricBlue else GrapheneSilver,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(24.dp))

                // Huge Master Record Button (Requirement #3, #4, #78)
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .border(
                            2.dp,
                            if (recordState == RecordingState.RECORDING) GrapheneFuchsia else GrapheneAcidGreen,
                            RoundedCornerShape(50.dp)
                        )
                        .background(
                            if (recordState == RecordingState.RECORDING) GrapheneFuchsia.copy(alpha = 0.15f) else GrapheneAcidGreen
                        )
                        .clickable {
                            if (recordState == RecordingState.RECORDING) {
                                viewModel.stopRecordingAndSave()
                            } else {
                                viewModel.triggerQuickRecord()
                            }
                        }
                        .testTag("record_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (recordState == RecordingState.RECORDING) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(GrapheneFuchsia, RoundedCornerShape(2.dp))
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Start Recording",
                            tint = GrapheneBlack,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamic Marker Buttons during recording (Requirement #16, #17)
        if (recordState == RecordingState.RECORDING) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GrapheneLightGraphite)
                    .padding(12.dp)
            ) {
                Text(
                    text = "ONE-TAP A&R QUICK MARKS (STAMP LIVE)",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = GrapheneSilver
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    GrapheneButton("HOOK", onClick = { viewModel.addMarker("HOOK") }, modifier = Modifier.weight(1f), accentColor = GrapheneElectricBlue)
                    Spacer(modifier = Modifier.width(6.dp))
                    GrapheneButton("DROP", onClick = { viewModel.addMarker("DROP") }, modifier = Modifier.weight(1f), accentColor = GrapheneFuchsia)
                    Spacer(modifier = Modifier.width(6.dp))
                    GrapheneButton("VOCAL", onClick = { viewModel.addMarker("VOCAL") }, modifier = Modifier.weight(1f), accentColor = GrapheneAcidGreen)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    GrapheneButton("BEAT", onClick = { viewModel.addMarker("BEAT") }, modifier = Modifier.weight(1f), isPrimary = false)
                    Spacer(modifier = Modifier.width(6.dp))
                    GrapheneButton("IMPORTANT", onClick = { viewModel.addMarker("IMPORTANT") }, modifier = Modifier.weight(1f), isPrimary = false)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Target Metadata Context Form Templates (Requirement #3, #4)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GrapheneLightGraphite)
                .background(GrapheneDarkGraphite)
                .padding(14.dp)
        ) {
            Text(
                text = "SESSION CONTEXT (TEMPLATES)",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = GrapheneSilver
            )
            Divider(color = GrapheneLightGraphite, modifier = Modifier.padding(vertical = 8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showProjectDialog = true }
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("PROJECT", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = GrapheneSilver)
                Text(selectedProj?.name ?: "LONDON NEW BLOOD", fontSize = 12.sp, color = GrapheneAcidGreen, fontWeight = FontWeight.Bold)
            }

            Divider(color = GrapheneLightGraphite)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showArtistDialog = true }
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("ARTIST", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = GrapheneSilver)
                Text(selectedArt?.stageName ?: "YVES CYLINDER", fontSize = 12.sp, color = GrapheneAcidGreen, fontWeight = FontWeight.Bold)
            }

            Divider(color = GrapheneLightGraphite)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("VENUE", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = GrapheneSilver)
                Text(selectedVenue, fontSize = 12.sp, color = GrapheneOffWhite)
            }
        }
    }

    // Project selection dialog mockup
    if (showProjectDialog) {
        AlertDialog(
            onDismissRequest = { showProjectDialog = false },
            containerColor = GrapheneDarkGraphite,
            title = { Text("CHOOSE ACTIVE PROJECT", fontFamily = FontFamily.Monospace, color = GrapheneOffWhite) },
            text = {
                Column {
                    projects.forEach { proj ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectedProject.value = proj
                                    showProjectDialog = false
                                }
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(proj.name, color = GrapheneOffWhite)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // Artist selection dialog mockup
    if (showArtistDialog) {
        AlertDialog(
            onDismissRequest = { showArtistDialog = false },
            containerColor = GrapheneDarkGraphite,
            title = { Text("CHOOSE ACTIVE ARTIST", fontFamily = FontFamily.Monospace, color = GrapheneOffWhite) },
            text = {
                Column {
                    artists.forEach { art ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectedArtist.value = art
                                    showArtistDialog = false
                                }
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(art.stageName, color = GrapheneOffWhite)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
fun VaultTab(
    viewModel: MainViewModel,
    projects: List<Project>,
    artists: List<Artist>
) {
    val recordings by viewModel.recordings.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val reviewRec by viewModel.reviewRecording.collectAsStateWithLifecycle()
    val reviewMarks by viewModel.reviewMarkers.collectAsStateWithLifecycle()

    val filtered = viewModel.filteredRecordings(recordings)

    Row(modifier = Modifier.fillMaxSize()) {
        // Left Side: List (Width 40% if on wide display, otherwise full screen)
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .weight(1.1f)
                .background(GrapheneLightGraphite)
                .padding(end = 1.dp)
                .background(GrapheneBlack)
                .padding(12.dp)
        ) {
            // Search Box (Requirement #42)
            TextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("SEARCH VAULT...", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = GrapheneSilver) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .border(1.dp, GrapheneLightGraphite, RoundedCornerShape(2.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = GrapheneDarkGraphite,
                    unfocusedContainerColor = GrapheneDarkGraphite,
                    focusedTextColor = GrapheneOffWhite,
                    unfocusedTextColor = GrapheneOffWhite,
                    cursorColor = GrapheneAcidGreen
                ),
                textStyle = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "LABEL ARCHIVES | ALL TAKES (${filtered.size})",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = GrapheneSilver,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filtered) { rec ->
                    val isSelected = reviewRec?.recordingId == rec.recordingId
                    val proj = projects.find { it.projectId == rec.projectId }
                    val art = artists.find { it.artistId == rec.artistId }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (isSelected) GrapheneAcidGreen else GrapheneLightGraphite,
                                RoundedCornerShape(2.dp)
                            )
                            .background(if (isSelected) GrapheneLightGraphite else GrapheneDarkGraphite)
                            .clickable { viewModel.selectReviewRecording(rec) }
                            .padding(10.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = rec.title,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GrapheneOffWhite,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "TAKE 0${rec.takeNumber}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = GrapheneAcidGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${art?.stageName ?: "UNKNOWN"} | ${proj?.name ?: "RAW"}",
                                fontSize = 10.sp,
                                color = GrapheneSilver
                            )
                            Text(
                                text = "${rec.durationMs / 1000}s",
                                fontSize = 10.sp,
                                color = GrapheneSilver
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Compact thumbnail wave (Requirement #34)
                        val points = rec.waveformPoints.split(",").mapNotNull { it.toFloatOrNull() }
                        GrapheneWaveform(
                            peaks = points,
                            activeAccentColor = GrapheneSilver,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // Right Side: Take Review Details (Width 60%)
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .weight(1.9f)
                .background(GrapheneDarkGraphite)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (reviewRec != null) {
                val rec = reviewRec!!
                val proj = projects.find { it.projectId == rec.projectId }
                val art = artists.find { it.artistId == rec.artistId }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "A&R TAKE DOSSIER",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = GrapheneAcidGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = rec.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GrapheneOffWhite
                        )
                    }

                    // Synced indicator
                    GrapheneTag(text = rec.isSynced, isSelected = rec.isSynced == "SYNCED")
                }

                Divider(color = GrapheneLightGraphite, modifier = Modifier.padding(vertical = 12.dp))

                // Interactive Audio Player & Big Waveform (Requirement #35)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val isPlaying = viewModel.audioEngine.isPlaying()
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .border(1.dp, GrapheneAcidGreen, RoundedCornerShape(25.dp))
                            .background(GrapheneAcidGreen.copy(alpha = 0.1f))
                            .clickable {
                                if (isPlaying) {
                                    viewModel.audioEngine.stopPlayback()
                                } else {
                                    viewModel.audioEngine.startPlayback(rec.filePath)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Playback",
                            tint = GrapheneAcidGreen
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        val points = rec.waveformPoints.split(",").mapNotNull { it.toFloatOrNull() }
                        GrapheneWaveform(
                            peaks = points,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Detail Information grid
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetadataColumn("PROJECT", proj?.name ?: "NONE")
                    MetadataColumn("ARTIST", art?.stageName ?: "UNKNOWN")
                    MetadataColumn("VENUE", "The Steel Yard")
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetadataColumn("FORMAT", "${rec.format} | ${rec.sampleRate / 1000}kHz")
                    MetadataColumn("DURATION", "${rec.durationMs / 1000}s")
                    MetadataColumn("FINGERPRINT", DspCore.generateFingerprint(File(rec.filePath)))
                }

                Divider(color = GrapheneLightGraphite, modifier = Modifier.padding(vertical = 12.dp))

                // --- Graphene A&R Scorecard & Ratings Slider Edit Form (Requirement #37, #38) ---
                var scoutNotesText by remember(rec.recordingId) { mutableStateOf(rec.arNotes) }
                var scoreBook by remember(rec.recordingId) { mutableStateOf("NOT_SURE") }
                var scoreSign by remember(rec.recordingId) { mutableStateOf("NOT_SURE") }
                var scoreFit by remember(rec.recordingId) { mutableStateOf("NOT_SURE") }

                var overallRat by remember(rec.recordingId) { mutableStateOf(rec.overallRating) }
                var songRat by remember(rec.recordingId) { mutableStateOf(rec.songRating) }
                var artRat by remember(rec.recordingId) { mutableStateOf(rec.artistRating) }
                var liveRat by remember(rec.recordingId) { mutableStateOf(rec.liveRating) }

                Text(
                    text = "A&R SCORECARD & JUDGMENT",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = GrapheneOffWhite,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Question Box
                AandRQuestion("Would I book this?", scoreBook) { scoreBook = it }
                AandRQuestion("Would I sign this?", scoreSign) { scoreSign = it }
                AandRQuestion("Does this fit Graphene?", scoreFit) { scoreFit = it }

                Spacer(modifier = Modifier.height(12.dp))

                // Ratings Block
                GrapheneRatingSelector(rating = overallRat, onRatingSelected = { overallRat = it }, label = "Overall Potential")
                GrapheneRatingSelector(rating = songRat, onRatingSelected = { songRat = it }, label = "Song Writing")
                GrapheneRatingSelector(rating = artRat, onRatingSelected = { artRat = it }, label = "Artist Identity")
                GrapheneRatingSelector(rating = liveRat, onRatingSelected = { liveRat = it }, label = "Live Presence")

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "SCOUT FIELD ANNOTATIONS",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = GrapheneSilver
                )
                Spacer(modifier = Modifier.height(4.dp))
                TextField(
                    value = scoutNotesText,
                    onValueChange = { scoutNotesText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .border(1.dp, GrapheneLightGraphite),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = GrapheneBlack,
                        unfocusedContainerColor = GrapheneBlack,
                        focusedTextColor = GrapheneOffWhite,
                        unfocusedTextColor = GrapheneOffWhite
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                GrapheneButton(
                    text = "SAVE A&R ASSESSMENT",
                    onClick = {
                        val ansMap = mapOf(
                            "Would I book this?" to scoreBook,
                            "Would I sign this?" to scoreSign,
                            "Does this fit Graphene?" to scoreFit
                        )
                        viewModel.saveAandRScorecard(
                            scoutNotesText, ansMap, listOf("LIVE", "RAW"),
                            overallRat, songRat, artRat, liveRat, 0, 0, 0, 0, 0, false
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(color = GrapheneLightGraphite, modifier = Modifier.padding(vertical = 14.dp))

                // --- AI Assistant Integration (Requirement #39) ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GRAPHENE A&R AI ASSISTANT",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = GrapheneOffWhite,
                        fontWeight = FontWeight.Bold
                    )
                    GrapheneButton(
                        text = "RUN ANALYSIS",
                        onClick = { viewModel.runAiAnalysis() },
                        isPrimary = false,
                        isEnabled = !viewModel.aiLoading.value
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val aiResultText by viewModel.aiResult.collectAsStateWithLifecycle()
                val aiLoading by viewModel.aiLoading.collectAsStateWithLifecycle()

                if (aiLoading) {
                    CircularProgressIndicator(color = GrapheneAcidGreen, modifier = Modifier.align(Alignment.CenterHorizontally))
                } else if (aiResultText != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = GrapheneBlack),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GrapheneLightGraphite)
                    ) {
                        Text(
                            text = aiResultText!!,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = GrapheneOffWhite,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "SELECT A TAKE FROM THE ARCHIVES\nTO DEPLOY A&R REVIEW SCREEN",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = GrapheneSilver,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun CompareTab(viewModel: MainViewModel) {
    val recordings by viewModel.recordings.collectAsStateWithLifecycle()
    val tA by viewModel.takeA.collectAsStateWithLifecycle()
    val tB by viewModel.takeB.collectAsStateWithLifecycle()

    var showDialogA by remember { mutableStateOf(false) }
    var showDialogB by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "A/B TAKE SIDE-BY-SIDE COMPARISON",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = GrapheneAcidGreen,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Synchronize reviews of parallel session takes to determine signing potential.",
            fontSize = 11.sp,
            color = GrapheneSilver,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Row(modifier = Modifier.fillMaxWidth()) {
            // Take A Column
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, GrapheneLightGraphite)
                    .background(GrapheneDarkGraphite)
                    .padding(12.dp)
            ) {
                Text("TAKE A", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = GrapheneSilver)
                Spacer(modifier = Modifier.height(6.dp))

                if (tA != null) {
                    Text(tA!!.title, fontWeight = FontWeight.Bold, color = GrapheneOffWhite, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Duration: ${tA!!.durationMs / 1000}s", fontSize = 11.sp, color = GrapheneSilver)
                    Spacer(modifier = Modifier.height(8.dp))

                    val points = tA!!.waveformPoints.split(",").mapNotNull { it.toFloatOrNull() }
                    GrapheneWaveform(peaks = points, modifier = Modifier.fillMaxWidth().height(40.dp))

                    Spacer(modifier = Modifier.height(12.dp))
                    GrapheneButton("PLAY TAKE A", onClick = { viewModel.audioEngine.startPlayback(tA!!.filePath) }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    GrapheneButton("CHANGE TAKE", onClick = { showDialogA = true }, isPrimary = false, modifier = Modifier.fillMaxWidth())
                } else {
                    GrapheneButton("SELECT TAKE A", onClick = { showDialogA = true }, modifier = Modifier.fillMaxWidth())
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Take B Column
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, GrapheneLightGraphite)
                    .background(GrapheneDarkGraphite)
                    .padding(12.dp)
            ) {
                Text("TAKE B", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = GrapheneSilver)
                Spacer(modifier = Modifier.height(6.dp))

                if (tB != null) {
                    Text(tB!!.title, fontWeight = FontWeight.Bold, color = GrapheneOffWhite, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Duration: ${tB!!.durationMs / 1000}s", fontSize = 11.sp, color = GrapheneSilver)
                    Spacer(modifier = Modifier.height(8.dp))

                    val points = tB!!.waveformPoints.split(",").mapNotNull { it.toFloatOrNull() }
                    GrapheneWaveform(peaks = points, modifier = Modifier.fillMaxWidth().height(40.dp))

                    Spacer(modifier = Modifier.height(12.dp))
                    GrapheneButton("PLAY TAKE B", onClick = { viewModel.audioEngine.startPlayback(tB!!.filePath) }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(6.dp))
                    GrapheneButton("CHANGE TAKE", onClick = { showDialogB = true }, isPrimary = false, modifier = Modifier.fillMaxWidth())
                } else {
                    GrapheneButton("SELECT TAKE B", onClick = { showDialogB = true }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }

    // Select Take A Dialog
    if (showDialogA) {
        AlertDialog(
            onDismissRequest = { showDialogA = false },
            containerColor = GrapheneDarkGraphite,
            title = { Text("SELECT TAKE A", fontFamily = FontFamily.Monospace, color = GrapheneOffWhite) },
            text = {
                Column {
                    recordings.forEach { rec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.takeA.value = rec
                                    showDialogA = false
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            Text(rec.title, color = GrapheneOffWhite)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // Select Take B Dialog
    if (showDialogB) {
        AlertDialog(
            onDismissRequest = { showDialogB = false },
            containerColor = GrapheneDarkGraphite,
            title = { Text("SELECT TAKE B", fontFamily = FontFamily.Monospace, color = GrapheneOffWhite) },
            text = {
                Column {
                    recordings.forEach { rec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.takeB.value = rec
                                    showDialogB = false
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            Text(rec.title, color = GrapheneOffWhite)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
fun AandRQuestion(
    question: String,
    answer: String,
    onAnswerSelected: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = question,
            fontSize = 11.sp,
            color = GrapheneOffWhite,
            modifier = Modifier.weight(1.2f)
        )

        Row(modifier = Modifier.weight(0.8f), horizontalArrangement = Arrangement.End) {
            listOf("YES", "NO", "NOT_SURE").forEach { ans ->
                val isSelected = answer == ans
                val text = when (ans) {
                    "YES" -> "Y"
                    "NO" -> "N"
                    else -> "?"
                }
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .border(1.dp, if (isSelected) GrapheneAcidGreen else GrapheneLightGraphite, RoundedCornerShape(2.dp))
                        .background(if (isSelected) GrapheneAcidGreen else Color.Transparent)
                        .clickable { onAnswerSelected(ans) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) GrapheneBlack else GrapheneSilver
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
            }
        }
    }
}

@Composable
fun MetadataColumn(label: String, value: String) {
    Column {
        Text(label.uppercase(), fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = GrapheneSilver)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, fontSize = 12.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, color = GrapheneOffWhite)
    }
}
