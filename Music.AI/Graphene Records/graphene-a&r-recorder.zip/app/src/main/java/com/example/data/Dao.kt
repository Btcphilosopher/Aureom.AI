package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY name ASC")
    fun getAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE projectId = :id")
    suspend fun getProjectById(id: String): Project?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project)

    @Delete
    suspend fun deleteProject(project: Project)
}

@Dao
interface ArtistDao {
    @Query("SELECT * FROM artists ORDER BY stageName ASC")
    fun getAllArtists(): Flow<List<Artist>>

    @Query("SELECT * FROM artists WHERE artistId = :id")
    suspend fun getArtistById(id: String): Artist?

    @Query("SELECT * FROM artists WHERE artistId = :id")
    fun getArtistFlowById(id: String): Flow<Artist?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtist(artist: Artist)

    @Query("UPDATE artists SET status = :status, updatedAt = :updatedAt WHERE artistId = :id")
    suspend fun updateArtistStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM artists WHERE artistId = :id")
    suspend fun deleteArtist(id: String)
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM recording_sessions ORDER BY date DESC")
    fun getAllSessions(): Flow<List<RecordingSession>>

    @Query("SELECT * FROM recording_sessions WHERE sessionId = :id")
    suspend fun getSessionById(id: String): RecordingSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: RecordingSession)
}

@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY timestamp DESC")
    fun getAllRecordings(): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun getRecordingsByProject(projectId: String): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE artistId = :artistId ORDER BY timestamp DESC")
    fun getRecordingsByArtist(artistId: String): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE recordingId = :id")
    suspend fun getRecordingById(id: String): Recording?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(recording: Recording)

    @Query("DELETE FROM recordings WHERE recordingId = :id")
    suspend fun deleteRecording(id: String)

    @Query("UPDATE recordings SET isSynced = :status WHERE recordingId = :id")
    suspend fun updateSyncStatus(id: String, status: String)

    @Query("""
        UPDATE recordings 
        SET overallRating = :overall, songRating = :song, artistRating = :artist, 
            liveRating = :live, productionRating = :prod, voiceRating = :voice, 
            originalityRating = :orig, commercialPotential = :comm, culturalPotential = :cult,
            arNotes = :notes, scorecardAnswers = :answers, tags = :tags, isPrivate = :isPrivate
        WHERE recordingId = :id
    """)
    suspend fun updateRatingAndScorecard(
        id: String,
        overall: Int, song: Int, artist: Int, live: Int, prod: Int, voice: Int, orig: Int, comm: Int, cult: Int,
        notes: String, answers: String, tags: String, isPrivate: Boolean
    )
}

@Dao
interface MarkerDao {
    @Query("SELECT * FROM markers WHERE recordingId = :recordingId ORDER BY timestampMs ASC")
    fun getMarkersForRecording(recordingId: String): Flow<List<Marker>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarker(marker: Marker)

    @Query("DELETE FROM markers WHERE markerId = :markerId")
    suspend fun deleteMarker(markerId: String)
}
