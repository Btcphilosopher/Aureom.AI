package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Graphene Records Studio Colors
val GrapheneBlack = Color(0xFF000000)
val GrapheneDarkGraphite = Color(0xFF0C0C0C)
val GrapheneGraphite = Color(0xFF161616)
val GrapheneLightGraphite = Color(0xFF222222)
val GrapheneOffWhite = Color(0xFFF4F4F4)
val GrapheneSilver = Color(0xFF9E9E9E)
val GrapheneAcidGreen = Color(0xFFBFFF00) // Striking, highly responsive Acid Green
val GrapheneElectricBlue = Color(0xFF00E5FF)
val GrapheneFuchsia = Color(0xFFFF007F)

private val GrapheneColorScheme = darkColorScheme(
    primary = GrapheneAcidGreen,
    onPrimary = GrapheneBlack,
    secondary = GrapheneElectricBlue,
    onSecondary = GrapheneBlack,
    tertiary = GrapheneFuchsia,
    onTertiary = GrapheneOffWhite,
    background = GrapheneBlack,
    onBackground = GrapheneOffWhite,
    surface = GrapheneGraphite,
    onSurface = GrapheneOffWhite,
    surfaceVariant = GrapheneLightGraphite,
    onSurfaceVariant = GrapheneSilver,
    outline = GrapheneSilver
)

val GrapheneTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        letterSpacing = (-0.5).sp,
        color = GrapheneOffWhite
    ),
    displayMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        letterSpacing = (-0.2).sp,
        color = GrapheneOffWhite
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        letterSpacing = 0.5.sp,
        color = GrapheneOffWhite
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        color = GrapheneOffWhite
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        color = GrapheneSilver
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace, // Monospaced technical values
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 1.sp,
        color = GrapheneAcidGreen
    )
)

@Composable
fun GrapheneTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GrapheneColorScheme,
        typography = GrapheneTypography,
        content = content
    )
}
