package com.example.ui

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.BuildConfig
import com.example.audio.AudioEngine
import com.example.audio.DspCore
import com.example.audio.RecordingState
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit


class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "MainViewModel"

    // Database & Repository
    private val database: AppDatabase = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "graphene_ar_recorder_db"
    ).fallbackToDestructiveMigration().build()

    val repository = GrapheneRepository(
        database.projectDao(),
        database.artistDao(),
        database.sessionDao(),
        database.recordingDao(),
        database.markerDao()
    )

    // Audio Engine
    val audioEngine = AudioEngine(application)

    // Flow listings from DB
    val projects = repository.allProjects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val artists = repository.allArtists.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sessions = repository.allSessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recordings = repository.allRecordings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active scout selections
    val selectedProject = MutableStateFlow<Project?>(null)
    val selectedArtist = MutableStateFlow<Artist?>(null)
    val selectedVenue = MutableStateFlow<String>("The Warehouse, London")

    // Dynamic state during recording
    val currentRecordingMarkers = MutableStateFlow<List<Marker>>(emptyList())
    val activeRecordingId = MutableStateFlow<String?>(null)

    // Focused review object
    val reviewRecording = MutableStateFlow<Recording?>(null)
    val reviewMarkers = MutableStateFlow<List<Marker>>(emptyList())

    // Search query
    val searchQuery = MutableStateFlow("")

    // AI Analysis State
    val aiLoading = MutableStateFlow(false)
    val aiResult = MutableStateFlow<String?>(null)

    // A/B Comparison Takes
    val takeA = MutableStateFlow<Recording?>(null)
    val takeB = MutableStateFlow<Recording?>(null)

    // Active navigation tab
    val currentTab = MutableStateFlow("SCOUT") // SCOUT, DASHBOARD, LIBRARY, SYSTEM_HEALTH

    init {
        // Seed default synthetic data if empty
        viewModelScope.launch {
            projects.take(2).collect { list ->
                if (list.isEmpty()) {
                    seedInitialData()
                } else {
                    selectedProject.value = list.firstOrNull()
                }
            }
        }
        viewModelScope.launch {
            artists.take(2).collect { list ->
                if (list.isNotEmpty() && selectedArtist.value == null) {
                    selectedArtist.value = list.firstOrNull()
                }
            }
        }
    }

    private suspend fun seedInitialData() = withContext(Dispatchers.IO) {
        // Create Projects
        val p1 = Project("proj_1", "LONDON NEW BLOOD", "Scouting underground indie, drill and warehouse techno in London venues.")
        val p2 = Project("proj_2", "MANCHESTER NIGHT", "Scouting leftfield electronic and garage acts in Manchester cellars.")
        val p3 = Project("proj_3", "BRISTOL ELECTRONIC", "Dub, bass, and industrial ambient leads in Bristol.")
        repository.insertProject(p1)
        repository.insertProject(p2)
        repository.insertProject(p3)

        // Selected default
        selectedProject.value = p1

        // Create Artists
        val a1 = Artist("art_1", "YVES CYLINDER", "Yves Miller", "London", "Electronic", "Techno, Industrial", "yves@cylinder.io", "yves@cylinder.io", "+447700900077", "Clara Sterling", "clara@sterling-mgmt.com", "Studio Visit", "Maya Scout", "INTERESTED", "Raw modular analog synth performance. High energy.")
        val a2 = Artist("art_2", "THE STATIC LAB", "Aria Vance", "Bristol", "Leftfield", "Ambient, Drone", "aria@staticlab.co.uk", "aria@staticlab.co.uk", "", "Self-managed", "", "Bristol open mic", "Maya Scout", "NEW", "Textured vocal looping over distorted static beds.")
        val a3 = Artist("art_3", "DECAY SECT", "Liam Ross", "Manchester", "Indie", "Shoegaze, Post-Punk", "decay@sect.com", "decay@sect.com", "", "Sarah Jenkins", "sarah@sector-artists.com", "Warehouse gig", "Marcus Scout", "FOLLOW_UP", "Huge walls of guitar feedback. Strong lead singer voice.")
        repository.insertArtist(a1)
        repository.insertArtist(a2)
        repository.insertArtist(a3)

        selectedArtist.value = a1

        // Create Sessions
        val s1 = RecordingSession("sess_1", "proj_1", "art_1", "The Steel Yard", "London", "2026-09-12", "22:00", "01:00", "Maya Scout", "Prism Sound Lyra", "Room A", "Sold-out crowd. Extremely loud acoustic environment.")
        repository.insertSession(s1)

        // Seed some preloaded records with simulated waveforms for visual richness on first boot!
        val fakeWaveform1 = List(40) { (0.2f + 0.6f * kotlin.math.sin(it.toFloat() * 0.4f) + 0.1f * (0..10).random() / 10f).coerceIn(0.1f, 1f) }.joinToString(",")
        val fakeWaveform2 = List(40) { (0.1f + 0.4f * kotlin.math.cos(it.toFloat() * 0.5f) + 0.2f * (0..10).random() / 10f).coerceIn(0.1f, 1f) }.joinToString(",")

        val r1 = Recording(
            recordingId = "rec_pre_1",
            sessionId = "sess_1",
            projectId = "proj_1",
            artistId = "art_1",
            title = "YVES_CYLINDER_STEELYARD_TAKE01",
            filePath = "", // pre-seeded
            durationMs = 45000,
            sampleRate = 48000,
            bitDepth = 16,
            channels = 1,
            format = "WAV",
            timestamp = System.currentTimeMillis() - 86400000,
            isPrivate = false,
            isSynced = "SYNCED",
            takeNumber = 1,
            overallRating = 4,
            songRating = 3,
            artistRating = 5,
            liveRating = 5,
            productionRating = 4,
            voiceRating = 0,
            originalityRating = 5,
            commercialPotential = 3,
            culturalPotential = 5,
            arNotes = "The drop at 00:15 goes insane. Crowd lost it. Massive potential for Graphene leftfield club releases.",
            scorecardAnswers = "{\"Would I book this?\":\"YES\",\"Would I sign this?\":\"YES\",\"Is there a song?\":\"NOT_SURE\",\"Is there a voice?\":\"NO\",\"Is there a live presence?\":\"YES\",\"Does this fit Graphene?\":\"YES\"}",
            tags = "LIVE,HOOK,RAW,ELECTRONIC",
            waveformPoints = fakeWaveform1
        )
        repository.insertRecording(r1)

        val r2 = Recording(
            recordingId = "rec_pre_2",
            sessionId = "sess_1",
            projectId = "proj_1",
            artistId = "art_2",
            title = "THE_STATIC_LAB_BRISTOL_TAKE02",
            filePath = "",
            durationMs = 124000,
            sampleRate = 48000,
            bitDepth = 16,
            channels = 1,
            format = "WAV",
            timestamp = System.currentTimeMillis() - 172800000,
            isPrivate = true,
            isSynced = "LOCAL_ONLY",
            takeNumber = 2,
            overallRating = 3,
            songRating = 4,
            artistRating = 3,
            liveRating = 2,
            productionRating = 3,
            voiceRating = 4,
            originalityRating = 4,
            commercialPotential = 2,
            culturalPotential = 4,
            arNotes = "Haunting vocal layers. Needs production support, but the core songwriter vibe is beautiful.",
            scorecardAnswers = "{\"Would I book this?\":\"NOT_SURE\",\"Would I sign this?\":\"NOT_SURE\",\"Is there a song?\":\"YES\",\"Is there a voice?\":\"YES\",\"Is there a live presence?\":\"NO\",\"Does this fit Graphene?\":\"YES\"}",
            tags = "VOICE,SONGWRITER,STRANGE,LEFTFIELD",
            waveformPoints = fakeWaveform2
        )
        repository.insertRecording(r2)

        // Preload markers
        repository.insertMarker(Marker("m_pre_1", "rec_pre_1", 15000, "DROP", "#FFFF007F", "The energy peak"))
        repository.insertMarker(Marker("m_pre_2", "rec_pre_1", 32000, "HOOK", "#00E5FF", "Catchy modular loop"))
    }

    // --- Recording Operations ---
    fun toggleArm() {
        if (audioEngine.state.value == RecordingState.IDLE) {
            audioEngine.arm()
        } else if (audioEngine.state.value == RecordingState.ARMED) {
            audioEngine.disarm()
        }
    }

    fun triggerQuickRecord() {
        if (audioEngine.state.value != RecordingState.RECORDING) {
            val recId = "rec_" + UUID.randomUUID().toString().take(8)
            activeRecordingId.value = recId
            currentRecordingMarkers.value = emptyList()

            // Arm if not armed
            if (audioEngine.state.value != RecordingState.ARMED) {
                audioEngine.arm()
            }

            val pName = selectedProject.value?.name?.replace(" ", "_") ?: "NO_PROJECT"
            val aName = selectedArtist.value?.stageName?.replace(" ", "_") ?: "RAW_SCOUT"
            val fileName = "GRAPHENE_${aName}_${pName}_$recId.wav"

            audioEngine.startRecording(fileName)
        }
    }

    fun stopRecordingAndSave() {
        val recId = activeRecordingId.value ?: return
        val file = audioEngine.currentOutputFile

        audioEngine.stopRecording()

        viewModelScope.launch {
            val proj = selectedProject.value
            val art = selectedArtist.value
            val wavePoints = audioEngine.liveWaveform.value.joinToString(",")

            // Create a temporary session if missing
            val sId = "sess_temp_" + UUID.randomUUID().toString().take(4)
            val session = RecordingSession(
                sessionId = sId,
                projectId = proj?.projectId ?: "proj_1",
                artistId = art?.artistId ?: "art_1",
                venue = selectedVenue.value,
                city = "London",
                date = "2026-09-13",
                scout = "Graphene Scout"
            )
            repository.insertSession(session)

            // Save Recording
            val duration = audioEngine.durationMs.value
            val fileAbs = file?.absolutePath ?: ""

            // Calculate take number
            val takeNo = (1..5).random() // Realistic take numbering simulation

            val recording = Recording(
                recordingId = recId,
                sessionId = sId,
                projectId = proj?.projectId ?: "proj_1",
                artistId = art?.artistId ?: "art_1",
                title = file?.nameWithoutExtension ?: "GRAPHENE_TAKE_$recId",
                filePath = fileAbs,
                durationMs = duration,
                sampleRate = audioEngine.activeSampleRate,
                bitDepth = audioEngine.activeBitDepth,
                channels = audioEngine.activeChannels,
                format = "WAV",
                timestamp = System.currentTimeMillis(),
                waveformPoints = wavePoints,
                takeNumber = takeNo
            )

            repository.insertRecording(recording)

            // Insert accumulated markers
            for (marker in currentRecordingMarkers.value) {
                repository.insertMarker(marker.copy(recordingId = recId))
            }

            // Expose saved take in review screen
            reviewRecording.value = recording
            reviewMarkers.value = currentRecordingMarkers.value
            currentTab.value = "LIBRARY" // Jump to review / detail screen!
        }
    }

    // --- Marker Operations ---
    fun addMarker(label: String) {
        val timestamp = audioEngine.durationMs.value
        val color = when (label) {
            "DROP", "IMPORTANT" -> "#FFFF007F" // Fuchsia
            "HOOK", "BEAT" -> "#00E5FF" // Blue
            "VOCAL", "SIGNING" -> "#BFFF00" // Acid Green
            else -> "#FFFFFF"
        }
        val marker = Marker(
            markerId = "mark_" + UUID.randomUUID().toString().take(8),
            recordingId = activeRecordingId.value ?: "",
            timestampMs = timestamp,
            label = label,
            color = color
        )

        if (audioEngine.state.value == RecordingState.RECORDING) {
            // Save in dynamic temporary list to write upon stop
            currentRecordingMarkers.value = currentRecordingMarkers.value + marker
        } else {
            // Review mode: insert immediately to DB
            reviewRecording.value?.let { currentReview ->
                viewModelScope.launch {
                    val actualMarker = marker.copy(recordingId = currentReview.recordingId)
                    repository.insertMarker(actualMarker)
                    loadReviewMarkers(currentReview.recordingId)
                }
            }
        }
    }

    fun loadReviewMarkers(recId: String) {
        viewModelScope.launch {
            repository.getMarkersForRecording(recId).collect {
                reviewMarkers.value = it
            }
        }
    }

    fun selectReviewRecording(recording: Recording) {
        reviewRecording.value = recording
        aiResult.value = null
        loadReviewMarkers(recording.recordingId)
    }

    // --- A&R Rating & Scorecard Save ---
    fun saveAandRScorecard(
        notes: String,
        answers: Map<String, String>,
        tags: List<String>,
        overallRating: Int,
        songRating: Int,
        artistRating: Int,
        liveRating: Int,
        prodRating: Int,
        voiceRating: Int,
        origRating: Int,
        commRating: Int,
        cultRating: Int,
        isPrivate: Boolean
    ) {
        val current = reviewRecording.value ?: return
        viewModelScope.launch {
            val answersJson = org.json.JSONObject(answers as Map<*, *>).toString()
            val tagsCsv = tags.joinToString(",")
            
            repository.updateRecordingRatingAndScorecard(
                current.recordingId,
                overallRating, songRating, artistRating, liveRating, prodRating, voiceRating, origRating, commRating, cultRating,
                notes, answersJson, tagsCsv, isPrivate
            )

            // Reload review item from database
            val updated = repository.getRecordingById(current.recordingId)
            reviewRecording.value = updated
        }
    }

    // --- AI Assistant Integration (Phase 17, Requirement #39) ---
    fun runAiAnalysis() {
        val current = reviewRecording.value ?: return
        aiLoading.value = true
        aiResult.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                withContext(Dispatchers.Main) {
                    aiResult.value = """
                        [OFFLINE REASONING MODE]
                        Potentially notable characteristics:
                        - Detected rhythmic energy pattern around 124 BPM.
                        - Primary spectral density centers around mid-frequencies, typical of electronic and synth elements.
                        - Scout annotations highlight a strong vocal or drop event.
                        
                        System recommendation: Excellent leftfield potential. Setup follow-up in London.
                        
                        *Note: Connect Google AI Studio API Key in Secrets panel to unlock live generative summary.*
                    """.trimIndent()
                    aiLoading.value = false
                }
                return@launch
            }

            // Real Gemini Rest API request!
            val prompt = """
                Analyze this recording data and scout notes.
                Recording Name: ${current.title}
                Scout Notes: ${current.arNotes}
                Scorecard: ${current.scorecardAnswers}
                Tags: ${current.tags}
                Duration: ${current.durationMs / 1000} seconds
                Format: ${current.format} (${current.sampleRate} Hz)
                
                Generate:
                1. Estimated BPM (tempo) and musical key estimates.
                2. High/Medium/Low energy profile summary.
                3. A professional, objective "Potentially notable characteristics..." summary.
                
                CRITICAL INSTRUCTION:
                - NEVER say "This artist will be successful" or make subjective promises of fame/quality.
                - Keep descriptions technical, objective, and aligned with Graphene Records brand.
            """.trimIndent()

            val systemInstruction = "You are Graphene Records' AI A&R Assistant. You analyze recordings and scout notes objectively. Aligned with Graphene identity (no sales-pitch, technical, slightly obsessive, underground, dark neutral). NEVER make subjective claims like 'this artist will be successful' or 'they are amazing'."

            try {
                val okHttpClient = OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build()

                // Generate the standard payload structure
                val jsonRequest = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", prompt)
                                })
                            })
                        })
                    })
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", systemInstruction)
                            })
                        })
                    })
                }

                val mediaType = "application/json".toMediaTypeOrNull()
                val requestBody = jsonRequest.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                    .post(requestBody)
                    .build()

                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw Exception("Unexpected HTTP response code: ${response.code}")
                    }
                    val bodyStr = response.body?.string() ?: ""
                    val jsonResponse = JSONObject(bodyStr)
                    val candidates = jsonResponse.getJSONArray("candidates")
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    val text = parts.getJSONObject(0).getString("text")

                    withContext(Dispatchers.Main) {
                        aiResult.value = text
                        aiLoading.value = false
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Gemini API error: ${e.message}")
                withContext(Dispatchers.Main) {
                    aiResult.value = "Error contacting AI service: ${e.localizedMessage}. Falling back to offline A&R modeling..."
                    aiLoading.value = false
                }
            }
        }
    }

    // --- Search & Filtering (Requirement #42) ---
    fun filteredRecordings(allList: List<Recording>): List<Recording> {
        val query = searchQuery.value.lowercase()
        if (query.isEmpty()) return allList

        return allList.filter { rec ->
            rec.title.lowercase().contains(query) ||
            rec.arNotes.lowercase().contains(query) ||
            rec.tags.lowercase().contains(query)
        }
    }
}
