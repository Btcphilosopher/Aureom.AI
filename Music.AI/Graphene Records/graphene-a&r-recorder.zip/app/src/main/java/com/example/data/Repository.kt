package com.example.data

import kotlinx.coroutines.flow.Flow

class GrapheneRepository(
    private val projectDao: ProjectDao,
    private val artistDao: ArtistDao,
    private val sessionDao: SessionDao,
    private val recordingDao: RecordingDao,
    private val markerDao: MarkerDao
) {
    val allProjects: Flow<List<Project>> = projectDao.getAllProjects()
    val allArtists: Flow<List<Artist>> = artistDao.getAllArtists()
    val allSessions: Flow<List<RecordingSession>> = sessionDao.getAllSessions()
    val allRecordings: Flow<List<Recording>> = recordingDao.getAllRecordings()

    suspend fun getProjectById(id: String) = projectDao.getProjectById(id)
    suspend fun insertProject(project: Project) = projectDao.insertProject(project)
    suspend fun deleteProject(project: Project) = projectDao.deleteProject(project)

    suspend fun getArtistById(id: String) = artistDao.getArtistById(id)
    fun getArtistFlowById(id: String) = artistDao.getArtistFlowById(id)
    suspend fun insertArtist(artist: Artist) = artistDao.insertArtist(artist)
    suspend fun updateArtistStatus(id: String, status: String) = artistDao.updateArtistStatus(id, status)
    suspend fun deleteArtist(id: String) = artistDao.deleteArtist(id)

    suspend fun getSessionById(id: String) = sessionDao.getSessionById(id)
    suspend fun insertSession(session: RecordingSession) = sessionDao.insertSession(session)

    fun getRecordingsByProject(projectId: String) = recordingDao.getRecordingsByProject(projectId)
    fun getRecordingsByArtist(artistId: String) = recordingDao.getRecordingsByArtist(artistId)
    suspend fun getRecordingById(id: String) = recordingDao.getRecordingById(id)
    suspend fun insertRecording(recording: Recording) = recordingDao.insertRecording(recording)
    suspend fun deleteRecording(id: String) = recordingDao.deleteRecording(id)
    suspend fun updateSyncStatus(id: String, status: String) = recordingDao.updateSyncStatus(id, status)
    
    suspend fun updateRecordingRatingAndScorecard(
        id: String,
        overall: Int, song: Int, artist: Int, live: Int, prod: Int, voice: Int, orig: Int, comm: Int, cult: Int,
        notes: String, answers: String, tags: String, isPrivate: Boolean
    ) = recordingDao.updateRatingAndScorecard(
        id, overall, song, artist, live, prod, voice, orig, comm, cult, notes, answers, tags, isPrivate
    )

    fun getMarkersForRecording(recordingId: String) = markerDao.getMarkersForRecording(recordingId)
    suspend fun insertMarker(marker: Marker) = markerDao.insertMarker(marker)
    suspend fun deleteMarker(markerId: String) = markerDao.deleteMarker(markerId)
}
