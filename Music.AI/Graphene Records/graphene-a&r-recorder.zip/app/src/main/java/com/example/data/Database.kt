package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey val projectId: String,
    val name: String,
    val description: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "artists")
data class Artist(
    @PrimaryKey val artistId: String,
    val stageName: String,
    val legalName: String = "",
    val location: String = "",
    val genre: String = "",
    val subgenres: String = "", // comma separated
    val contact: String = "",
    val email: String = "",
    val phone: String = "",
    val manager: String = "",
    val managementContact: String = "",
    val discoverySource: String = "",
    val arOwner: String = "",
    val status: String = "NEW", // NEW, HEARD, INTERESTED, FOLLOW_UP, SHORTLISTED, SIGNED, PASSED, ARCHIVED
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recording_sessions")
data class RecordingSession(
    @PrimaryKey val sessionId: String,
    val projectId: String,
    val artistId: String,
    val venue: String = "",
    val city: String = "",
    val date: String = "",
    val startTime: String = "",
    val endTime: String = "",
    val scout: String = "",
    val equipment: String = "",
    val room: String = "",
    val notes: String = "",
    val arStatus: String = "NEW"
)

@Entity(tableName = "recordings")
data class Recording(
    @PrimaryKey val recordingId: String,
    val sessionId: String,
    val projectId: String,
    val artistId: String,
    val title: String,
    val filePath: String,
    val durationMs: Long,
    val sampleRate: Int,
    val bitDepth: Int,
    val channels: Int,
    val format: String = "WAV",
    val timestamp: Long = System.currentTimeMillis(),
    val isPrivate: Boolean = true,
    val isSynced: String = "LOCAL_ONLY", // LOCAL_ONLY, QUEUED, UPLOADING, SYNCED, FAILED
    val takeNumber: Int = 1,
    
    // Ratings (1-5)
    val overallRating: Int = 0,
    val songRating: Int = 0,
    val artistRating: Int = 0,
    val liveRating: Int = 0,
    val productionRating: Int = 0,
    val voiceRating: Int = 0,
    val originalityRating: Int = 0,
    val commercialPotential: Int = 0,
    val culturalPotential: Int = 0,
    
    // Scorecard & Commentary
    val arNotes: String = "",
    val scorecardAnswers: String = "{}", // JSON Map of Q -> Answer (YES, NO, NOT_SURE)
    val tags: String = "", // comma-separated
    val waveformPoints: String = "" // Comma-separated floats representing pre-computed waveform peaks
)

@Entity(tableName = "markers")
data class Marker(
    @PrimaryKey val markerId: String,
    val recordingId: String,
    val timestampMs: Long,
    val label: String, // HOOK, VOCAL, BEAT, DROP, CHORUS, VERSE, GUITAR, SYNTH, DRUMS, IDEA, ARTIST, IMPORTANT, FOLLOW-UP, SIGNING, STRANGE, GREAT, BAD AUDIO
    val color: String, // hex string
    val note: String = ""
)

// Simple JSON sidecar for generic settings or complex lists if needed
class Converters {
    @TypeConverter
    fun fromStringList(value: List<String>?): String? {
        if (value == null) return null
        return value.joinToString(",")
    }

    @TypeConverter
    fun toStringList(value: String?): List<String>? {
        if (value == null) return null
        return if (value.isEmpty()) emptyList() else value.split(",")
    }
}

@Database(
    entities = [Project::class, Artist::class, RecordingSession::class, Recording::class, Marker::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun artistDao(): ArtistDao
    abstract fun sessionDao(): SessionDao
    abstract fun recordingDao(): RecordingDao
    abstract fun markerDao(): MarkerDao
}
