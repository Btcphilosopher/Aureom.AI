package com.example.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.sqrt

enum class RecordingState {
    IDLE,
    ARMED,
    RECORDING,
    PAUSED,
    FINALISING,
    SAVED,
    ERROR,
    RECOVERING,
    UPLOADING,
    SYNCED
}

class AudioEngine(private val context: Context) {
    private val TAG = "AudioEngine"

    private val _state = MutableStateFlow(RecordingState.IDLE)
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    // Meter levels
    private val _rmsLevelL = MutableStateFlow(0f)
    val rmsLevelL: StateFlow<Float> = _rmsLevelL.asStateFlow()

    private val _peakLevelL = MutableStateFlow(0f)
    val peakLevelL: StateFlow<Float> = _peakLevelL.asStateFlow()

    private val _clippingL = MutableStateFlow(false)
    val clippingL: StateFlow<Float> = MutableStateFlow(0f).asStateFlow() // 0 to 1 clipping indicator

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    // Real-time waveform data (accumulated peaks)
    private val _liveWaveform = MutableStateFlow<List<Float>>(emptyList())
    val liveWaveform: StateFlow<List<Float>> = _liveWaveform.asStateFlow()

    // Hardware Cap Information
    var activeSampleRate = 48000
    var activeBitDepth = 16
    var activeChannels = 1
    var bufferSize = 4096

    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private var durationJob: Job? = null
    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Files
    var currentOutputFile: File? = null
    private var rawAudioBytesCount = 0L

    // Pre-record rolling buffer (Configurable: 0, 3, 5, 10, 15 seconds)
    var preRecordDurationSeconds = 5
    private val preRecordQueue = ConcurrentLinkedQueue<ShortArray>()
    private var preRecordSamplesCount = 0

    // Playback
    private var mediaPlayer: MediaPlayer? = null
    private val _playbackPosition = MutableStateFlow(0)
    val playbackPosition: StateFlow<Int> = _playbackPosition.asStateFlow()
    private var playbackJob: Job? = null

    init {
        queryHardwareCapabilities()
    }

    private fun queryHardwareCapabilities() {
        val sampleRates = intArrayOf(48000, 44100, 22050, 16000)
        for (rate in sampleRates) {
            val size = AudioRecord.getMinBufferSize(
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (size > 0) {
                activeSampleRate = rate
                bufferSize = size * 2
                break
            }
        }
    }

    fun arm() {
        if (_state.value == RecordingState.IDLE) {
            _state.value = RecordingState.ARMED
            startPreRecording()
        }
    }

    fun disarm() {
        if (_state.value == RecordingState.ARMED) {
            _state.value = RecordingState.IDLE
            stopPreRecording()
        }
    }

    private var preRecordingJob: Job? = null
    private fun startPreRecording() {
        preRecordingJob?.cancel()
        preRecordQueue.clear()
        preRecordSamplesCount = 0

        preRecordingJob = coroutineScope.launch {
            try {
                val size = AudioRecord.getMinBufferSize(
                    activeSampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(1024)

                val tempRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    activeSampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    size
                )

                if (tempRecord.state != AudioRecord.STATE_INITIALIZED) {
                    _state.value = RecordingState.ERROR
                    return@launch
                }

                tempRecord.startRecording()
                val tempBuffer = ShortArray(1024)

                while (isActive && _state.value == RecordingState.ARMED) {
                    val read = tempRecord.read(tempBuffer, 0, tempBuffer.size)
                    if (read > 0) {
                        val chunk = tempBuffer.copyOf(read)
                        preRecordQueue.add(chunk)
                        preRecordSamplesCount += read

                        // Calculate max size of queue
                        val maxSamples = activeSampleRate * preRecordDurationSeconds
                        while (preRecordSamplesCount > maxSamples && preRecordQueue.isNotEmpty()) {
                            val removed = preRecordQueue.poll()
                            if (removed != null) {
                                preRecordSamplesCount -= removed.size
                            }
                        }

                        // Compute basic live meters even when armed (scout sees feedback!)
                        computeMeters(chunk)
                    }
                    delay(10)
                }
                tempRecord.stop()
                tempRecord.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error in pre-recording: ${e.message}")
            }
        }
    }

    private fun stopPreRecording() {
        preRecordingJob?.cancel()
        preRecordingJob = null
    }

    fun startRecording(outputFileName: String) {
        if (_state.value != RecordingState.ARMED && _state.value != RecordingState.IDLE) {
            Log.e(TAG, "Cannot start recording from state: ${_state.value}")
            return
        }

        stopPreRecording()

        _state.value = RecordingState.RECORDING
        _durationMs.value = 0L
        rawAudioBytesCount = 0L
        _liveWaveform.value = emptyList()

        val outputDir = File(context.filesDir, "recordings")
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }
        val file = File(outputDir, outputFileName)
        currentOutputFile = file

        recordingJob = coroutineScope.launch {
            var fos: FileOutputStream? = null
            try {
                fos = FileOutputStream(file)
                // Leave 44 bytes space for WAV header
                fos.write(ByteArray(44))

                // 1. Write the pre-record buffer!
                var preRecordBytesWritten = 0L
                while (preRecordQueue.isNotEmpty()) {
                    val chunk = preRecordQueue.poll()
                    if (chunk != null) {
                        val byteBuffer = ByteBuffer.allocate(chunk.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                        for (s in chunk) {
                            byteBuffer.putShort(s)
                        }
                        fos.write(byteBuffer.array())
                        preRecordBytesWritten += chunk.size * 2
                    }
                }
                rawAudioBytesCount += preRecordBytesWritten

                // 2. Initialize real recorder
                val minSize = AudioRecord.getMinBufferSize(
                    activeSampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(1024)

                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    activeSampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minSize
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    _state.value = RecordingState.ERROR
                    return@launch
                }

                audioRecord?.startRecording()
                val buffer = ShortArray(1024)
                val startTime = System.currentTimeMillis()

                // Launch duration updater
                durationJob = launch {
                    while (isActive) {
                        _durationMs.value = System.currentTimeMillis() - startTime + ((preRecordBytesWritten / 2.0 / activeSampleRate) * 1000).toLong()
                        delay(100)
                    }
                }

                var pointsCounter = 0
                var currentWindowMax = 0f

                while (isActive && _state.value == RecordingState.RECORDING) {
                    val audioRecordLocal = audioRecord ?: break
                    val read = audioRecordLocal.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        val byteBuffer = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                        var maxVal = 0f
                        for (i in 0 until read) {
                            val sample = buffer[i]
                            byteBuffer.putShort(sample)
                            val absVal = abs(sample.toFloat()) / 32768.0f
                            if (absVal > maxVal) maxVal = absVal
                        }
                        fos.write(byteBuffer.array())
                        rawAudioBytesCount += read * 2

                        // Meter computations
                        computeMeters(buffer.copyOf(read))

                        // Waveform computations
                        if (maxVal > currentWindowMax) {
                            currentWindowMax = maxVal
                        }
                        pointsCounter += read
                        if (pointsCounter >= activeSampleRate / 10) { // 10 points per second
                            val currentList = _liveWaveform.value.toMutableList()
                            currentList.add(currentWindowMax)
                            _liveWaveform.value = currentList
                            currentWindowMax = 0f
                            pointsCounter = 0
                        }
                    }
                }

                // Finalize wav header
                fos.close()
                fos = null

                finalizeWavFile(file)
                _state.value = RecordingState.SAVED
            } catch (e: Exception) {
                Log.e(TAG, "Error in recording engine: ${e.message}")
                _state.value = RecordingState.ERROR
            } finally {
                fos?.close()
                audioRecord?.stop()
                audioRecord?.release()
                audioRecord = null
                durationJob?.cancel()
            }
        }
    }

    fun stopRecording() {
        if (_state.value == RecordingState.RECORDING) {
            _state.value = RecordingState.FINALISING
            recordingJob?.cancel()
            durationJob?.cancel()
            _state.value = RecordingState.SAVED
        }
    }

    private fun finalizeWavFile(file: File) {
        val totalAudioLen = rawAudioBytesCount
        val totalDataLen = totalAudioLen + 36
        val channels = 1
        val byteRate = activeSampleRate * channels * 2L

        val wavHeader = ByteArray(44)
        wavHeader[0] = 'R'.toByte()
        wavHeader[1] = 'I'.toByte()
        wavHeader[2] = 'F'.toByte()
        wavHeader[3] = 'F'.toByte()
        wavHeader[4] = (totalDataLen and 0xff).toByte()
        wavHeader[5] = ((totalDataLen shr 8) and 0xff).toByte()
        wavHeader[6] = ((totalDataLen shr 16) and 0xff).toByte()
        wavHeader[7] = ((totalDataLen shr 24) and 0xff).toByte()
        wavHeader[8] = 'W'.toByte()
        wavHeader[9] = 'A'.toByte()
        wavHeader[10] = 'V'.toByte()
        wavHeader[11] = 'E'.toByte()
        wavHeader[12] = 'f'.toByte()
        wavHeader[13] = 'm'.toByte()
        wavHeader[14] = 't'.toByte()
        wavHeader[15] = ' '.toByte()
        wavHeader[16] = 16
        wavHeader[17] = 0
        wavHeader[18] = 0
        wavHeader[19] = 0
        wavHeader[20] = 1
        wavHeader[21] = 0
        wavHeader[22] = channels.toByte()
        wavHeader[23] = 0
        wavHeader[24] = (activeSampleRate and 0xff).toByte()
        wavHeader[25] = ((activeSampleRate shr 8) and 0xff).toByte()
        wavHeader[26] = ((activeSampleRate shr 16) and 0xff).toByte()
        wavHeader[27] = ((activeSampleRate shr 24) and 0xff).toByte()
        wavHeader[28] = (byteRate and 0xff).toByte()
        wavHeader[29] = ((byteRate shr 8) and 0xff).toByte()
        wavHeader[30] = ((byteRate shr 16) and 0xff).toByte()
        wavHeader[31] = ((byteRate shr 24) and 0xff).toByte()
        wavHeader[32] = (channels * 2).toByte()
        wavHeader[33] = 0
        wavHeader[34] = 16
        wavHeader[35] = 0
        wavHeader[36] = 'd'.toByte()
        wavHeader[37] = 'a'.toByte()
        wavHeader[38] = 't'.toByte()
        wavHeader[39] = 'a'.toByte()
        wavHeader[40] = (totalAudioLen and 0xff).toByte()
        wavHeader[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        wavHeader[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        wavHeader[43] = ((totalAudioLen shr 24) and 0xff).toByte()

        val raf = RandomAccessFile(file, "rw")
        raf.seek(0)
        raf.write(wavHeader)
        raf.close()
    }

    private fun computeMeters(buffer: ShortArray) {
        var sumSquares = 0.0
        var maxPeak = 0f
        for (sample in buffer) {
            val sampleFloat = sample.toFloat() / 32768.0f
            sumSquares += sampleFloat * sampleFloat
            val absSample = abs(sampleFloat)
            if (absSample > maxPeak) {
                maxPeak = absSample
            }
        }
        val rms = if (buffer.isNotEmpty()) sqrt(sumSquares / buffer.size).toFloat() else 0f
        _rmsLevelL.value = rms
        _peakLevelL.value = maxPeak
    }

    // Playback APIs
    fun startPlayback(filePath: String) {
        stopPlayback()
        val file = File(filePath)
        if (!file.exists()) {
            Log.e(TAG, "File to play does not exist: $filePath")
            return
        }

        mediaPlayer = MediaPlayer().apply {
            setDataSource(filePath)
            prepare()
            start()
        }

        playbackJob = coroutineScope.launch {
            while (isActive) {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        _playbackPosition.value = mp.currentPosition
                    } else {
                        // Check if playback ended
                        if (_playbackPosition.value > mp.duration - 200) {
                            _playbackPosition.value = 0
                        }
                    }
                }
                delay(50)
            }
        }
    }

    fun pausePlayback() {
        mediaPlayer?.pause()
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        _playbackPosition.value = 0
    }

    fun seekPlayback(positionMs: Int) {
        mediaPlayer?.seekTo(positionMs)
        _playbackPosition.value = positionMs
    }

    fun isPlaying(): Boolean {
        return mediaPlayer?.isPlaying ?: false
    }

    fun getDuration(): Int {
        return mediaPlayer?.duration ?: 0
    }
}
