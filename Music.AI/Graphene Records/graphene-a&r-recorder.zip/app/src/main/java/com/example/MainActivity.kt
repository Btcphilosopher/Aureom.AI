package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.DashboardScreen
import com.example.ui.GrapheneButton
import com.example.ui.MainViewModel
import com.example.ui.theme.GrapheneBlack
import com.example.ui.theme.GrapheneDarkGraphite
import com.example.ui.theme.GrapheneLightGraphite
import com.example.ui.theme.GrapheneOffWhite
import com.example.ui.theme.GrapheneSilver
import com.example.ui.theme.GrapheneTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GrapheneTheme {
                var hasMicPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasMicPermission = isGranted
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = GrapheneBlack
                ) {
                    if (hasMicPermission) {
                        DashboardScreen(viewModel = viewModel)
                    } else {
                        // Custom styled Graphene permission warning
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(GrapheneBlack)
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GrapheneLightGraphite)
                                    .background(GrapheneDarkGraphite)
                                    .padding(24.dp)
                            ) {
                                Text(
                                    text = "MIC REQUIRED",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif,
                                    color = GrapheneOffWhite,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "To capture real, uncompressed field audio for Graphene Records, this device requires microphone hardware permissions.",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = GrapheneSilver,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(24.dp))
                                GrapheneButton(
                                    text = "GRANT MIC ACCESS",
                                    onClick = {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

