package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.log10

@Composable
fun GrapheneButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true,
    isEnabled: Boolean = true,
    accentColor: Color = GrapheneAcidGreen
) {
    val borderColor = if (isPrimary) accentColor else GrapheneSilver
    val bg = if (isPrimary) accentColor else Color.Transparent
    val tc = if (isPrimary) GrapheneBlack else GrapheneOffWhite

    Box(
        modifier = modifier
            .border(1.dp, borderColor, RoundedCornerShape(2.dp))
            .background(bg, RoundedCornerShape(2.dp))
            .clickable(enabled = isEnabled) { onClick() }
            .padding(vertical = 12.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.uppercase(),
            color = if (isEnabled) tc else GrapheneSilver,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
fun GrapheneMeter(
    rms: Float,
    peak: Float,
    modifier: Modifier = Modifier
) {
    // Convert linear to decibel representation or simple linear percent
    val rmsPercent = (rms * 1.5f).coerceIn(0f, 1f)
    val peakPercent = peak.coerceIn(0f, 1f)
    val isClipping = peak >= 0.98f

    Column(
        modifier = modifier
            .background(GrapheneDarkGraphite)
            .border(1.dp, GrapheneLightGraphite)
            .padding(8.dp)
    ) {
        // Label
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "METER LEVEL (DBFS)",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = GrapheneSilver
            )
            Text(
                text = if (isClipping) "OVER / CLIP" else "NOMINAL",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = if (isClipping) GrapheneFuchsia else GrapheneAcidGreen,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Level Bar (L)
        LevelBarRow(label = "L", rms = rmsPercent, peak = peakPercent, isClipping = isClipping)
        Spacer(modifier = Modifier.height(4.dp))
        // Level Bar (R) (mirroring for professional L/R dual stereo visuals!)
        LevelBarRow(label = "R", rms = rmsPercent * 0.95f, peak = peakPercent * 0.98f, isClipping = isClipping)
    }
}

@Composable
private fun LevelBarRow(
    label: String,
    rms: Float,
    peak: Float,
    isClipping: Boolean
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = label,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = GrapheneOffWhite,
            modifier = Modifier.width(16.dp)
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Segmented bar drawing
        Canvas(
            modifier = Modifier
                .weight(1f)
                .height(10.dp)
        ) {
            val segmentsCount = 30
            val spacing = 2.dp.toPx()
            val totalWidth = size.width
            val segmentWidth = (totalWidth - (spacing * (segmentsCount - 1))) / segmentsCount

            for (i in 0 until segmentsCount) {
                val segmentStart = i * (segmentWidth + spacing)
                val fraction = i.toFloat() / segmentsCount

                val color = when {
                    fraction > 0.9f && isClipping -> GrapheneFuchsia
                    fraction > 0.8f -> GrapheneElectricBlue
                    fraction > rms -> GrapheneLightGraphite
                    else -> GrapheneAcidGreen
                }

                drawRect(
                    color = color,
                    topLeft = Offset(segmentStart, 0f),
                    size = Size(segmentWidth, size.height)
                )
            }

            // Draw single thin peak indicator
            val peakPosition = peak * totalWidth
            drawRect(
                color = if (isClipping) GrapheneFuchsia else GrapheneOffWhite,
                topLeft = Offset(peakPosition.coerceAtMost(totalWidth - 2.dp.toPx()), 0f),
                size = Size(2.dp.toPx(), size.height)
            )
        }
    }
}

@Composable
fun GrapheneWaveform(
    peaks: List<Float>,
    modifier: Modifier = Modifier,
    playheadFraction: Float = -1f, // If >= 0, draws a vertical playback marker
    markers: List<Pair<Float, String>> = emptyList(), // Pair of (fraction, label) for marking hooks, beats, etc.
    activeAccentColor: Color = GrapheneAcidGreen
) {
    Canvas(
        modifier = modifier
            .background(GrapheneBlack)
            .border(1.dp, GrapheneLightGraphite)
    ) {
        val totalWidth = size.width
        val midY = size.height / 2f

        if (peaks.isEmpty()) {
            // Draw baseline
            drawLine(
                color = GrapheneLightGraphite,
                start = Offset(0f, midY),
                end = Offset(totalWidth, midY),
                strokeWidth = 1.dp.toPx()
            )
            return@Canvas
        }

        val barSpacing = 2.dp.toPx()
        val totalBars = peaks.size
        val barWidth = (totalWidth - (barSpacing * (totalBars - 1))) / totalBars

        for (i in 0 until totalBars) {
            val barStart = i * (barWidth + barSpacing)
            val peak = peaks[i].coerceIn(0.02f, 1f)
            val barHeight = peak * size.height * 0.8f

            // Determine if this bar is before or after playhead
            val barFraction = i.toFloat() / totalBars
            val color = if (playheadFraction >= 0f && barFraction > playheadFraction) {
                GrapheneSilver.copy(alpha = 0.3f)
            } else {
                activeAccentColor
            }

            drawLine(
                color = color,
                start = Offset(barStart + barWidth / 2f, midY - barHeight / 2f),
                end = Offset(barStart + barWidth / 2f, midY + barHeight / 2f),
                strokeWidth = barWidth.coerceAtLeast(1.dp.toPx())
            )
        }

        // Draw markers
        for (marker in markers) {
            val markerX = marker.first * totalWidth
            // Marker line
            drawLine(
                color = GrapheneFuchsia,
                start = Offset(markerX, 0f),
                end = Offset(markerX, size.height),
                strokeWidth = 1.5.dp.toPx()
            )
        }

        // Draw playhead marker
        if (playheadFraction in 0f..1f) {
            val playheadX = playheadFraction * totalWidth
            drawLine(
                color = GrapheneOffWhite,
                start = Offset(playheadX, 0f),
                end = Offset(playheadX, size.height),
                strokeWidth = 2.dp.toPx()
            )
            drawCircle(
                color = GrapheneOffWhite,
                radius = 4.dp.toPx(),
                center = Offset(playheadX, 0f)
            )
        }
    }
}

@Composable
fun GrapheneTag(
    text: String,
    isSelected: Boolean = false,
    onClick: (() -> Unit)? = null,
    color: Color = GrapheneAcidGreen
) {
    val bg = if (isSelected) color.copy(alpha = 0.15f) else Color.Transparent
    val borderCol = if (isSelected) color else GrapheneLightGraphite
    val textCol = if (isSelected) color else GrapheneSilver

    Box(
        modifier = Modifier
            .border(1.dp, borderCol, RoundedCornerShape(2.dp))
            .background(bg)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text.uppercase(),
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = textCol,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun GrapheneRatingSelector(
    rating: Int,
    onRatingSelected: (Int) -> Unit,
    label: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label.uppercase(),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = GrapheneOffWhite,
            modifier = Modifier.width(130.dp)
        )

        Row {
            for (i in 1..5) {
                val isFilled = i <= rating
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .padding(2.dp)
                        .border(1.dp, if (isFilled) GrapheneAcidGreen else GrapheneLightGraphite, RoundedCornerShape(2.dp))
                        .background(if (isFilled) GrapheneAcidGreen else Color.Transparent)
                        .clickable { onRatingSelected(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = i.toString(),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (isFilled) GrapheneBlack else GrapheneSilver
                    )
                }
            }
        }
    }
}
