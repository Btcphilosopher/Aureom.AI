/** Pure playback-queue state machine (unit tested in tests/queue.test.ts). */
import type { Track } from "../types";

export type Repeat = "off" | "all" | "one";

export interface QueueState {
  items: Track[];
  /** Playback order as indexes into items (identity when shuffle is off). */
  order: number[];
  /** Position within `order`. -1 = nothing loaded. */
  cursor: number;
  repeat: Repeat;
  shuffle: boolean;
  seed: number;
}

export const emptyQueue: QueueState = { items: [], order: [], cursor: -1, repeat: "off", shuffle: false, seed: 1 };

export type QueueAction =
  | { type: "playList"; tracks: Track[]; start: number }
  | { type: "enqueue"; track: Track }
  | { type: "playNext"; track: Track }
  | { type: "remove"; index: number }
  | { type: "removeTrack"; trackId: string }
  | { type: "jump"; index: number }
  | { type: "next"; auto?: boolean }
  | { type: "prev" }
  | { type: "toggleShuffle" }
  | { type: "cycleRepeat" }
  | { type: "clear" };

function rng(seed: number) {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    return (s >>> 0) / 4294967296;
  };
}

export function shuffledOrder(n: number, first: number, seed: number): number[] {
  const rest = Array.from({ length: n }, (_, i) => i).filter((i) => i !== first);
  const r = rng(seed);
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [rest[i], rest[j]] = [rest[j], rest[i]];
  }
  return first >= 0 && first < n ? [first, ...rest] : rest;
}

export function currentTrack(s: QueueState): Track | null {
  if (s.cursor < 0 || s.cursor >= s.order.length) return null;
  return s.items[s.order[s.cursor]] ?? null;
}

export function currentIndex(s: QueueState): number {
  return s.cursor >= 0 ? s.order[s.cursor] : -1;
}

function rebuild(s: QueueState, items: Track[], currentItem: number): QueueState {
  const order = s.shuffle ? shuffledOrder(items.length, currentItem, s.seed) : items.map((_, i) => i);
  const cursor = currentItem >= 0 ? order.indexOf(currentItem) : -1;
  return { ...s, items, order, cursor };
}

export function queueReducer(s: QueueState, a: QueueAction): QueueState {
  switch (a.type) {
    case "playList": {
      const items = a.tracks.filter((t) => t.available !== false);
      const start = Math.max(0, items.findIndex((t) => t.id === a.tracks[a.start]?.id));
      return rebuild({ ...s, seed: s.seed + 1 }, items, items.length ? start : -1);
    }
    case "enqueue": {
      const items = [...s.items, a.track];
      if (s.cursor < 0) return rebuild(s, items, items.length - 1);
      return { ...s, items, order: [...s.order, items.length - 1] };
    }
    case "playNext": {
      if (s.cursor < 0) return queueReducer(s, { type: "enqueue", track: a.track });
      const items = [...s.items, a.track];
      const order = [...s.order];
      order.splice(s.cursor + 1, 0, items.length - 1);
      return { ...s, items, order };
    }
    case "remove": {
      if (a.index < 0 || a.index >= s.items.length) return s;
      const cur = currentIndex(s);
      const items = s.items.filter((_, i) => i !== a.index);
      const remap = (i: number) => (i > a.index ? i - 1 : i);
      const order = s.order.filter((i) => i !== a.index).map(remap);
      let cursor: number;
      if (cur === a.index) {
        // Removing the playing item: stay at the same cursor slot (the next item), or end.
        cursor = s.cursor < order.length ? s.cursor : s.repeat === "all" && order.length ? 0 : -1;
      } else {
        cursor = order.indexOf(remap(cur));
      }
      return { ...s, items, order, cursor };
    }
    case "removeTrack": {
      let st = s;
      for (let i = st.items.length - 1; i >= 0; i--) if (st.items[i].id === a.trackId) st = queueReducer(st, { type: "remove", index: i });
      return st;
    }
    case "jump": {
      const c = s.order.indexOf(a.index);
      return c >= 0 ? { ...s, cursor: c } : s;
    }
    case "next": {
      if (!s.order.length) return s;
      if (a.auto && s.repeat === "one") return { ...s };
      if (s.cursor + 1 < s.order.length) return { ...s, cursor: s.cursor + 1 };
      if (s.repeat === "all" || (!a.auto && s.repeat === "one")) return { ...s, cursor: 0 };
      return a.auto ? { ...s, cursor: -1 } : s;
    }
    case "prev": {
      if (!s.order.length) return s;
      if (s.cursor > 0) return { ...s, cursor: s.cursor - 1 };
      return s.repeat === "all" ? { ...s, cursor: s.order.length - 1 } : s;
    }
    case "toggleShuffle": {
      const next = { ...s, shuffle: !s.shuffle, seed: s.seed + 1 };
      return rebuild(next, s.items, currentIndex(s));
    }
    case "cycleRepeat":
      return { ...s, repeat: s.repeat === "off" ? "all" : s.repeat === "all" ? "one" : "off" };
    case "clear":
      return { ...emptyQueue, repeat: s.repeat, shuffle: s.shuffle, seed: s.seed };
  }
}
