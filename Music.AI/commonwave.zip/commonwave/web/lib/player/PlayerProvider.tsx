"use client";

/**
 * Persistent audio player. Lives in the root layout so playback survives
 * client-side navigation. Responsibilities:
 *  - queue (pure reducer in ./queue.ts), repeat/shuffle, previous/next
 *  - playback sessions + signed stream URLs; transparent refresh of expired URLs
 *  - graceful handling of stalled playback, unavailable/withdrawn tracks and removed queue items
 *  - untrusted analytics events (start/progress/pause/seek/end/stall) with sequence numbers
 *  - Media Session integration and keyboard shortcuts
 * Audio never starts before an explicit user action.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState, type ReactNode } from "react";
import { api, ApiError } from "../api";
import type { PlaybackSession, Track } from "../types";
import { currentIndex, currentTrack, emptyQueue, queueReducer, type QueueState } from "./queue";

type Status = "idle" | "loading" | "playing" | "paused" | "buffering" | "error";

interface PlayerValue {
  queue: QueueState;
  current: Track | null;
  currentIndex: number;
  status: Status;
  message: string | null;
  waveform: number[] | null;
  volume: number;
  muted: boolean;
  rate: number;
  normalise: boolean;
  playbackGainDb: number | null;
  playList: (tracks: Track[], start?: number, source?: string) => void;
  playTrack: (track: Track, source?: string) => void;
  toggle: () => void;
  pause: () => void;
  seek: (ms: number) => void;
  seekBy: (ms: number) => void;
  next: () => void;
  prev: () => void;
  enqueue: (t: Track) => void;
  playNext: (t: Track) => void;
  remove: (index: number) => void;
  jump: (index: number) => void;
  clear: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  setRate: (r: number) => void;
  setNormalise: (v: boolean) => void;
  dismissMessage: () => void;
}

interface PositionValue {
  position: number;
  duration: number;
  buffered: number;
}

const PlayerCtx = createContext<PlayerValue | null>(null);
const PositionCtx = createContext<PositionValue>({ position: 0, duration: 0, buffered: 0 });

export const RATES = [0.75, 1, 1.25, 1.5, 2];

function stored<T>(key: string, fallback: T): T {
  try {
    const v = window.localStorage.getItem(key);
    return v === null ? fallback : (JSON.parse(v) as T);
  } catch {
    return fallback;
  }
}
function store(key: string, v: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* storage unavailable: preference is per-page only */
  }
}

interface SessionRef {
  s: PlaybackSession;
  seq: number;
  started: boolean;
  lastPos: number;
  refreshes: number;
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [queue, dispatch] = useReducer(queueReducer, emptyQueue);
  const [nonce, setNonce] = useState(0);
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState<string | null>(null);
  const [waveform, setWaveform] = useState<number[] | null>(null);
  const [pos, setPos] = useState<PositionValue>({ position: 0, duration: 0, buffered: 0 });
  const [volume, setVolumeState] = useState(0.9);
  const [muted, setMuted] = useState(false);
  const [rate, setRateState] = useState(1);
  const [normalise, setNormaliseState] = useState(true);
  const [gain, setGain] = useState<number | null>(null);

  const sessionRef = useRef<SessionRef | null>(null);
  const sourceRef = useRef<string | undefined>(undefined);
  const activated = useRef(false); // set only by explicit user actions
  const wantPlay = useRef(false);
  const loadedNonce = useRef(-1);
  const stallTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const heartbeat = useRef<ReturnType<typeof setInterval> | null>(null);
  const seekFrom = useRef<number | null>(null);
  const queueRef = useRef(queue);
  queueRef.current = queue;

  const current = currentTrack(queue);

  useEffect(() => {
    setVolumeState(stored("cw-volume", 0.9));
    setRateState(stored("cw-rate", 1));
    setNormaliseState(stored("cw-normalise", true));
  }, []);

  // Effective element volume: user volume × normalisation attenuation (never boosts
  // above 1.0 — the file itself is never modified).
  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const att = normalise && gain !== null && gain < 0 ? Math.pow(10, gain / 20) : 1;
    a.volume = Math.max(0, Math.min(1, volume * att));
    a.muted = muted;
  }, [volume, muted, normalise, gain]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.playbackRate = rate;
  }, [rate]);

  // ------------------------------------------------------------ analytics
  const send = useCallback((kind: "start" | "progress" | "pause" | "seek" | "end" | "stall", positionMs?: number) => {
    const ref = sessionRef.current;
    const a = audioRef.current;
    if (!ref || !a) return;
    const position = Math.max(0, Math.round(positionMs ?? a.currentTime * 1000));
    const ev = { seq: ref.seq++, kind, position_ms: position };
    void api(`/playback/sessions/${ref.s.session_id}/events`, {
      method: "POST",
      keepalive: true,
      body: { session_token: ref.s.session_token, events: [ev] },
    }).catch(() => {
      /* analytics are best effort; the server de-duplicates retries by seq */
    });
  }, []);

  const stopHeartbeat = () => {
    if (heartbeat.current) clearInterval(heartbeat.current);
    heartbeat.current = null;
  };
  const startHeartbeat = useCallback(() => {
    stopHeartbeat();
    const every = (sessionRef.current?.s.heartbeat_seconds ?? 15) * 1000;
    heartbeat.current = setInterval(() => send("progress"), every);
  }, [send]);

  // ------------------------------------------------------------ loading
  const markUnavailable = useCallback((track: Track, text: string) => {
    setMessage(text);
    dispatch({ type: "removeTrack", trackId: track.id });
    setNonce((n) => n + 1);
  }, []);

  const openSession = useCallback(async (track: Track) => {
    return api<PlaybackSession>("/playback/sessions", { method: "POST", body: { track_id: track.id, source: sourceRef.current } });
  }, []);

  const load = useCallback(
    async (track: Track, startAt = 0, autoplay = false) => {
      const a = audioRef.current;
      if (!a) return;
      setStatus("loading");
      stopHeartbeat();
      try {
        const s = await openSession(track);
        if (currentTrack(queueRef.current)?.id !== track.id) return; // user moved on meanwhile
        sessionRef.current = { s, seq: 0, started: false, lastPos: startAt, refreshes: 0 };
        setWaveform(s.waveform);
        setGain(s.playback_gain_db);
        a.src = s.stream_url;
        a.playbackRate = rate;
        if (startAt) a.currentTime = startAt / 1000;
        setPos({ position: startAt, duration: s.duration_ms ?? 0, buffered: 0 });
        if (autoplay && activated.current) {
          await a.play().catch(() => setStatus("paused"));
        } else setStatus("paused");
      } catch (e) {
        if (e instanceof ApiError && (e.status === 404 || e.status === 410)) {
          markUnavailable(track, `“${track.title}” is no longer available and was removed from your queue.`);
        } else {
          setStatus("error");
          setMessage("Couldn't start playback. Check your connection and try again.");
        }
      }
    },
    [openSession, markUnavailable, rate],
  );

  /** Replace an expired or failing stream URL without losing the listening position. */
  const refreshUrl = useCallback(
    async (reason: "expired" | "stall" | "error") => {
      const a = audioRef.current;
      const ref = sessionRef.current;
      const track = currentTrack(queueRef.current);
      if (!a || !ref || !track) return;
      if (ref.refreshes >= 3) {
        setStatus("error");
        setMessage("Playback keeps failing for this track. Skip it or try again later.");
        return;
      }
      const at = a.currentTime * 1000 || ref.lastPos;
      const wasPlaying = wantPlay.current;
      try {
        const s = await openSession(track);
        sessionRef.current = { s, seq: 0, started: false, lastPos: at, refreshes: ref.refreshes + 1 };
        a.src = s.stream_url;
        a.currentTime = at / 1000;
        if (wasPlaying) await a.play().catch(() => undefined);
        if (reason === "stall") setMessage("Playback stalled — reconnected.");
      } catch (e) {
        if (e instanceof ApiError && (e.status === 404 || e.status === 410)) {
          markUnavailable(track, `“${track.title}” was withdrawn and has been removed from your queue.`);
        } else {
          setStatus("error");
          setMessage("Lost connection to the stream.");
        }
      }
    },
    [openSession, markUnavailable],
  );

  // Load whenever the current queue item changes or a reload is forced.
  useEffect(() => {
    const track = currentTrack(queue);
    const a = audioRef.current;
    if (!track) {
      if (a && queue.cursor < 0) {
        a.pause();
        a.removeAttribute("src");
        a.load();
      }
      sessionRef.current = null;
      setStatus("idle");
      setWaveform(null);
      return;
    }
    if (loadedNonce.current === nonce) return;
    loadedNonce.current = nonce;
    void load(track, 0, wantPlay.current);
  }, [queue, nonce, load]);

  // ------------------------------------------------------------ element events
  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const clearStall = () => {
      if (stallTimer.current) clearTimeout(stallTimer.current);
      stallTimer.current = null;
    };
    const onPlaying = () => {
      clearStall();
      setStatus("playing");
      const ref = sessionRef.current;
      if (ref && !ref.started) {
        ref.started = true;
        send("start", a.currentTime * 1000);
      } else send("progress");
      startHeartbeat();
    };
    const onPause = () => {
      if (a.ended) return;
      setStatus("paused");
      stopHeartbeat();
      if (sessionRef.current?.started) send("pause");
    };
    const onWaiting = () => {
      setStatus("buffering");
      clearStall();
      stallTimer.current = setTimeout(() => {
        send("stall");
        void refreshUrl("stall");
      }, 12_000);
    };
    const onTime = () => {
      const ms = a.currentTime * 1000;
      if (sessionRef.current && !a.seeking) sessionRef.current.lastPos = ms;
      let buffered = 0;
      for (let i = 0; i < a.buffered.length; i++) if (a.buffered.start(i) <= a.currentTime) buffered = a.buffered.end(i) * 1000;
      setPos({ position: ms, duration: Number.isFinite(a.duration) ? a.duration * 1000 : sessionRef.current?.s.duration_ms ?? 0, buffered });
      if ("mediaSession" in navigator && Number.isFinite(a.duration) && a.duration > 0) {
        try {
          navigator.mediaSession.setPositionState({ duration: a.duration, position: Math.min(a.currentTime, a.duration), playbackRate: a.playbackRate });
        } catch {
          /* some browsers reject transient states */
        }
      }
    };
    const onSeeking = () => {
      if (seekFrom.current === null && sessionRef.current?.started) {
        seekFrom.current = sessionRef.current.lastPos;
        send("progress", sessionRef.current.lastPos); // credit what was heard before the jump
      }
    };
    const onSeeked = () => {
      if (seekFrom.current !== null) send("seek", a.currentTime * 1000);
      seekFrom.current = null;
      if (sessionRef.current) sessionRef.current.lastPos = a.currentTime * 1000;
    };
    const onEnded = () => {
      stopHeartbeat();
      send("end", a.duration * 1000);
      const q = queueRef.current;
      if (q.repeat === "one") {
        setNonce((n) => n + 1); // a fresh session: each loop is its own listen
        return;
      }
      dispatch({ type: "next", auto: true });
      setNonce((n) => n + 1);
    };
    const onError = async () => {
      const ref = sessionRef.current;
      if (!ref || !a.src) return;
      // The element can't tell us the HTTP status, so ask the server about this URL.
      try {
        const res = await fetch(ref.s.stream_url, { method: "HEAD", credentials: "same-origin" });
        if (res.status === 403) return void refreshUrl("expired");
        if (res.status === 410 || res.status === 404) {
          const t = currentTrack(queueRef.current);
          if (t) markUnavailable(t, `“${t.title}” is no longer available and was removed from your queue.`);
          return;
        }
      } catch {
        /* fall through to a generic retry */
      }
      void refreshUrl("error");
    };
    const onVisibility = () => {
      if (document.visibilityState === "hidden" && !a.paused) send("progress");
    };
    a.addEventListener("playing", onPlaying);
    a.addEventListener("pause", onPause);
    a.addEventListener("waiting", onWaiting);
    a.addEventListener("stalled", onWaiting);
    a.addEventListener("timeupdate", onTime);
    a.addEventListener("progress", onTime);
    a.addEventListener("loadedmetadata", onTime);
    a.addEventListener("seeking", onSeeking);
    a.addEventListener("seeked", onSeeked);
    a.addEventListener("ended", onEnded);
    a.addEventListener("error", onError);
    a.addEventListener("canplay", clearStall);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      a.removeEventListener("playing", onPlaying);
      a.removeEventListener("pause", onPause);
      a.removeEventListener("waiting", onWaiting);
      a.removeEventListener("stalled", onWaiting);
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("progress", onTime);
      a.removeEventListener("loadedmetadata", onTime);
      a.removeEventListener("seeking", onSeeking);
      a.removeEventListener("seeked", onSeeked);
      a.removeEventListener("ended", onEnded);
      a.removeEventListener("error", onError);
      a.removeEventListener("canplay", clearStall);
      document.removeEventListener("visibilitychange", onVisibility);
      clearStall();
    };
  }, [send, startHeartbeat, refreshUrl, markUnavailable]);

  // ------------------------------------------------------------ actions
  const play = useCallback(() => {
    activated.current = true;
    wantPlay.current = true;
    const a = audioRef.current;
    if (!a) return;
    if (!a.src && current) {
      setNonce((n) => n + 1);
      return;
    }
    void a.play().catch(() => setStatus("paused"));
  }, [current]);

  const pause = useCallback(() => {
    wantPlay.current = false;
    audioRef.current?.pause();
  }, []);

  const actions = useMemo(
    () => ({
      playList: (tracks: Track[], start = 0, source?: string) => {
        activated.current = true;
        wantPlay.current = true;
        sourceRef.current = source;
        dispatch({ type: "playList", tracks, start });
        setNonce((n) => n + 1);
      },
      playTrack: (track: Track, source?: string) => {
        activated.current = true;
        wantPlay.current = true;
        sourceRef.current = source;
        dispatch({ type: "playList", tracks: [track], start: 0 });
        setNonce((n) => n + 1);
      },
      seek: (ms: number) => {
        const a = audioRef.current;
        if (a && a.src) a.currentTime = Math.max(0, ms / 1000);
      },
      seekBy: (ms: number) => {
        const a = audioRef.current;
        if (a && a.src) a.currentTime = Math.max(0, Math.min(a.duration || Infinity, a.currentTime + ms / 1000));
      },
      next: () => {
        activated.current = true;
        dispatch({ type: "next" });
        setNonce((n) => n + 1);
      },
      prev: () => {
        activated.current = true;
        const a = audioRef.current;
        if (a && a.currentTime > 3) {
          a.currentTime = 0;
          return;
        }
        dispatch({ type: "prev" });
        setNonce((n) => n + 1);
      },
      enqueue: (t: Track) => dispatch({ type: "enqueue", track: t }),
      playNext: (t: Track) => dispatch({ type: "playNext", track: t }),
      remove: (index: number) => {
        const playing = currentIndex(queueRef.current) === index;
        dispatch({ type: "remove", index });
        if (playing) setNonce((n) => n + 1);
      },
      jump: (index: number) => {
        activated.current = true;
        wantPlay.current = true;
        dispatch({ type: "jump", index });
        setNonce((n) => n + 1);
      },
      clear: () => {
        wantPlay.current = false;
        dispatch({ type: "clear" });
      },
      toggleShuffle: () => dispatch({ type: "toggleShuffle" }),
      cycleRepeat: () => dispatch({ type: "cycleRepeat" }),
      setVolume: (v: number) => {
        const c = Math.max(0, Math.min(1, v));
        setVolumeState(c);
        setMuted(false);
        store("cw-volume", c);
      },
      toggleMute: () => setMuted((m) => !m),
      setRate: (r: number) => {
        setRateState(r);
        store("cw-rate", r);
      },
      setNormalise: (v: boolean) => {
        setNormaliseState(v);
        store("cw-normalise", v);
      },
      dismissMessage: () => setMessage(null),
    }),
    [],
  );

  const toggle = useCallback(() => {
    const a = audioRef.current;
    if (!a || a.paused) play();
    else pause();
  }, [play, pause]);

  // Media Session integration
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const ms = navigator.mediaSession;
    if (current) {
      const art = current.artwork_url ? [{ src: current.artwork_url, sizes: "1200x1200", type: "image/jpeg" }] : [];
      ms.metadata = new MediaMetadata({ title: current.title, artist: current.artist.name, album: current.release?.title ?? "", artwork: art });
    } else ms.metadata = null;
    const handlers: [MediaSessionAction, MediaSessionActionHandler | null][] = [
      ["play", () => play()],
      ["pause", () => pause()],
      ["previoustrack", () => actions.prev()],
      ["nexttrack", () => actions.next()],
      ["seekbackward", (d) => actions.seekBy(-(d.seekOffset ?? 10) * 1000)],
      ["seekforward", (d) => actions.seekBy((d.seekOffset ?? 10) * 1000)],
      ["seekto", (d) => d.seekTime != null && actions.seek(d.seekTime * 1000)],
      ["stop", () => pause()],
    ];
    for (const [k, h] of handlers) {
      try {
        ms.setActionHandler(k, h);
      } catch {
        /* unsupported action */
      }
    }
  }, [current, play, pause, actions]);

  useEffect(() => {
    if ("mediaSession" in navigator) navigator.mediaSession.playbackState = status === "playing" ? "playing" : current ? "paused" : "none";
  }, [status, current]);

  // Global keyboard shortcuts (ignored while typing or when a control owns the key).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey) return;
      if (t && (t.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName))) return;
      const onControl = t && ["BUTTON", "A"].includes(t.tagName);
      // Sliders own arrows/Home/End/Space; letter shortcuts still work while one is focused.
      const onSlider = t?.getAttribute("role") === "slider";
      if (onSlider && e.key === " ") return;
      switch (e.key) {
        case " ":
          if (onControl) return;
          e.preventDefault();
          toggle();
          break;
        case "k":
          toggle();
          break;
        case "j":
          actions.seekBy(-10_000);
          break;
        case "l":
          actions.seekBy(10_000);
          break;
        case "m":
          actions.toggleMute();
          break;
        case "N":
          if (e.shiftKey) actions.next();
          break;
        case "P":
          if (e.shiftKey) actions.prev();
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, actions]);

  const value: PlayerValue = {
    queue,
    current,
    currentIndex: currentIndex(queue),
    status,
    message,
    waveform,
    volume,
    muted,
    rate,
    normalise,
    playbackGainDb: gain,
    toggle,
    pause,
    ...actions,
  };

  return (
    <PlayerCtx.Provider value={value}>
      <PositionCtx.Provider value={pos}>
        {children}
        {/* preload="none": nothing is fetched until the listener presses play */}
        <audio ref={audioRef} preload="none" aria-hidden="true" />
      </PositionCtx.Provider>
    </PlayerCtx.Provider>
  );
}

export function usePlayer(): PlayerValue {
  const v = useContext(PlayerCtx);
  if (!v) throw new Error("usePlayer outside PlayerProvider");
  return v;
}

export function usePosition(): PositionValue {
  return useContext(PositionCtx);
}
