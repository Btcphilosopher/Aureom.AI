export interface ArtistBrief {
  id: string;
  slug: string;
  name: string;
  kind: string;
  verified: boolean;
  avatar_url: string | null;
}

export interface Licence {
  code: string;
  name: string;
  short: string;
  version: string | null;
  url: string | null;
  attribution: string | null;
  allows_reuse: boolean;
  verification: string;
  declared_at: string;
}

export interface Track {
  id: string;
  title: string;
  status: string;
  available: boolean;
  artist: ArtistBrief;
  duration_ms: number | null;
  genre: string | null;
  tags: string[];
  explicit: boolean;
  language: string | null;
  artwork_url: string | null;
  artwork_thumb_url: string | null;
  release: { id: string; title: string; kind: string; position: number } | null;
  published_at: string | null;
  release_date: string | null;
  downloads: { mp3: boolean; original: boolean };
  licence: Licence | null;
  collaborators: { name: string; role: string }[];
  description?: string | null;
  credits?: { name: string; role: string }[];
  lyrics?: string | null;
  waveform?: number[] | null;
  position?: number;
}

export interface ReleaseBrief {
  id: string;
  title: string;
  kind: string;
  genre: string | null;
  tags: string[];
  artist: ArtistBrief;
  artwork_url: string | null;
  artwork_thumb_url: string | null;
  release_date: string | null;
  published_at: string | null;
  track_count: number;
  status: string;
  available: boolean;
  pwyw: { enabled: boolean; min_minor: number; currency: string } | null;
  artwork_id?: string | null;
  track_ids?: string[];
}

export interface Me {
  user: {
    id: string;
    username: string;
    display_name: string;
    email: string;
    role: "user" | "moderator" | "admin";
    status: string;
    restricted_until: string | null;
    history_enabled: boolean;
    personalisation_enabled: boolean;
    interests: string[];
  } | null;
  csrf_token: string | null;
  artists: (ArtistBrief & { role: string; status: string })[];
}

export interface PlaybackSession {
  session_id: string;
  session_token: string;
  track_id: string;
  version_id: string;
  stream_url: string;
  expires_at: number;
  duration_ms: number | null;
  playback_gain_db: number | null;
  waveform: number[] | null;
  heartbeat_seconds: number;
}
