"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { api, setCsrf } from "./api";
import type { Me } from "./types";

interface AuthValue {
  me: Me | null;
  loading: boolean;
  refresh: () => Promise<Me | null>;
  login: (email: string, password: string) => Promise<void>;
  register: (data: { email: string; username: string; password: string; display_name?: string }) => Promise<void>;
  logout: () => Promise<void>;
}

const Ctx = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);

  const apply = (m: Me) => {
    setCsrf(m.csrf_token);
    setMe(m);
    return m;
  };

  const refresh = useCallback(async () => {
    try {
      return apply(await api<Me>("/auth/me"));
    } catch {
      setMe({ user: null, csrf_token: null, artists: [] });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const value: AuthValue = {
    me,
    loading,
    refresh,
    login: async (email, password) => {
      apply(await api<Me>("/auth/login", { method: "POST", body: { email, password } }));
    },
    register: async (data) => {
      apply(await api<Me>("/auth/register", { method: "POST", body: data }));
    },
    logout: async () => {
      await api("/auth/logout", { method: "POST" });
      setCsrf(null);
      setMe({ user: null, csrf_token: null, artists: [] });
    },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthValue {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth outside AuthProvider");
  return v;
}
