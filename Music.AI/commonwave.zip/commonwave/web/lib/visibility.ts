export const VIS: Record<string, string> = {
  private: "Private — only you",
  unlisted: "Unlisted — anyone with the link",
  public: "Public — listed on your profile",
};
