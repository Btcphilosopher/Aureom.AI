/** Small tus 1.0.0 client (creation + resume) for the upload studio.
 *
 * Resume works across page reloads: the upload URL is remembered in
 * localStorage under a fingerprint of (file name, size, mtime, artist). On
 * restart we HEAD the URL to learn the server offset and continue from there.
 */
import { getCsrf } from "./api";

export interface UploadProgress {
  uploaded: number;
  total: number;
  state: "creating" | "uploading" | "paused" | "retrying" | "complete" | "error";
  message?: string;
}

export function encodeMetadata(meta: Record<string, string>): string {
  return Object.entries(meta)
    .map(([k, v]) => `${k} ${btoa(unescape(encodeURIComponent(v)))}`)
    .join(",");
}

export function fingerprint(file: { name: string; size: number; lastModified: number }, artistId: string, trackId?: string): string {
  return `cw-upload:${artistId}:${trackId ?? "new"}:${file.name}:${file.size}:${file.lastModified}`;
}

export function backoffMs(attempt: number): number {
  return Math.min(30_000, 1000 * 2 ** attempt);
}

const TUS = { "Tus-Resumable": "1.0.0" };

function storage(): Storage | null {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

export class ResumableUpload {
  private controller = new AbortController();
  private paused = false;
  location: string | null = null;
  trackId: string | null = null;

  constructor(
    private file: File,
    private opts: { artistId: string; trackId?: string; title?: string; chunkSize?: number; onProgress: (p: UploadProgress) => void },
  ) {}

  private headers(extra: Record<string, string> = {}): Record<string, string> {
    const h: Record<string, string> = { ...TUS, ...extra };
    const csrf = getCsrf();
    if (csrf) h["X-CSRF-Token"] = csrf;
    return h;
  }

  private key() {
    return fingerprint(this.file, this.opts.artistId, this.opts.trackId);
  }

  pause() {
    this.paused = true;
    this.controller.abort();
  }

  async start(): Promise<{ trackId: string }> {
    this.paused = false;
    this.controller = new AbortController();
    const total = this.file.size;
    const report = (uploaded: number, state: UploadProgress["state"], message?: string) =>
      this.opts.onProgress({ uploaded, total, state, message });

    let offset = await this.resumeOffset();
    if (offset === null) {
      report(0, "creating");
      const meta: Record<string, string> = { filename: this.file.name, artist_id: this.opts.artistId };
      if (this.opts.trackId) meta.track_id = this.opts.trackId;
      if (this.opts.title) meta.title = this.opts.title;
      const res = await fetch("/api/v1/uploads", {
        method: "POST",
        credentials: "same-origin",
        headers: this.headers({ "Upload-Length": String(total), "Upload-Metadata": encodeMetadata(meta) }),
      });
      if (res.status !== 201) throw new Error(await errorText(res));
      this.location = res.headers.get("Location");
      this.trackId = res.headers.get("X-Track-Id");
      storage()?.setItem(this.key(), JSON.stringify({ location: this.location, trackId: this.trackId }));
      offset = 0;
    }

    const chunk = this.opts.chunkSize ?? 2 * 1024 * 1024;
    let attempt = 0;
    while (offset < total) {
      if (this.paused) {
        report(offset, "paused");
        throw new PausedError();
      }
      report(offset, attempt ? "retrying" : "uploading");
      try {
        const res: Response = await fetch(this.location!, {
          method: "PATCH",
          credentials: "same-origin",
          signal: this.controller.signal,
          headers: this.headers({ "Upload-Offset": String(offset), "Content-Type": "application/offset+octet-stream" }),
          body: this.file.slice(offset, Math.min(total, offset + chunk)),
        });
        if (res.status === 204) {
          offset = Number(res.headers.get("Upload-Offset"));
          attempt = 0;
          continue;
        }
        if (res.status === 409 || res.status === 423) {
          const o = await this.headOffset();
          if (o !== null) offset = o;
          continue;
        }
        if (res.status >= 400 && res.status < 500) {
          storage()?.removeItem(this.key());
          const msg = await errorText(res);
          report(offset, "error", msg);
          throw new Error(msg);
        }
        throw new Error(`Server error ${res.status}`);
      } catch (e) {
        if (this.paused) {
          report(offset, "paused");
          throw new PausedError();
        }
        if (e instanceof Error && !(e instanceof TypeError) && !e.message.startsWith("Server error")) throw e;
        if (attempt >= 6) {
          report(offset, "error", "The connection keeps failing. Your progress is saved — resume when you're back online.");
          throw e;
        }
        report(offset, "retrying", "Connection interrupted — retrying…");
        await new Promise((r) => setTimeout(r, backoffMs(attempt++)));
        const o = await this.headOffset().catch(() => null);
        if (o !== null) offset = o;
      }
    }
    storage()?.removeItem(this.key());
    report(total, "complete");
    return { trackId: this.trackId! };
  }

  private async headOffset(): Promise<number | null> {
    if (!this.location) return null;
    const res = await fetch(this.location, { method: "HEAD", credentials: "same-origin", headers: this.headers() });
    if (res.status !== 200) return null;
    return Number(res.headers.get("Upload-Offset"));
  }

  private async resumeOffset(): Promise<number | null> {
    const saved = storage()?.getItem(this.key());
    if (!saved) return null;
    try {
      const { location, trackId } = JSON.parse(saved);
      this.location = location;
      this.trackId = trackId;
      const o = await this.headOffset();
      if (o === null) {
        storage()?.removeItem(this.key());
        this.location = null;
        return null;
      }
      return o;
    } catch {
      return null;
    }
  }
}

export class PausedError extends Error {
  constructor() {
    super("Upload paused");
  }
}

async function errorText(res: Response): Promise<string> {
  try {
    const j = await res.json();
    return j?.error?.message ?? `Upload failed (${res.status})`;
  } catch {
    return `Upload failed (${res.status})`;
  }
}
