"use client";

import { use, useState } from "react";
import { Empty, ReleaseCard, Section } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import type { ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

export default function GenrePage({ params }: { params: Promise<{ genre: string }> }) {
  const { genre } = use(params);
  const g = decodeURIComponent(genre);
  const [sort, setSort] = useState<"latest" | "popular">("latest");
  const { data } = useApi<{ tracks: Track[]; releases: ReleaseBrief[] }>(`/genres/${encodeURIComponent(g)}?sort=${sort}`, [sort]);
  return (
    <>
      <div className="kicker" style={{ marginTop: 24, color: "var(--turquoise)", fontWeight: 800, letterSpacing: ".14em", textTransform: "uppercase", fontSize: ".78rem" }}>Genre</div>
      <h1 style={{ textTransform: "capitalize" }}>{g}</h1>
      <div role="radiogroup" aria-label="Sort tracks" className="row" style={{ gap: 6 }}>
        <button role="radio" aria-checked={sort === "latest"} className={sort === "latest" ? "btn-teal btn-sm" : "btn-sm"} onClick={() => setSort("latest")}>Latest</button>
        <button role="radio" aria-checked={sort === "popular"} className={sort === "popular" ? "btn-teal btn-sm" : "btn-sm"} onClick={() => setSort("popular")}>Popular (14 days)</button>
      </div>
      {data ? (
        <>
          {data.releases.length ? <Section title="Releases"><div className="cards">{data.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div></Section> : null}
          <Section title="Tracks">
            {data.tracks.length ? <TrackList tracks={data.tracks} source={`genre_${sort}`} /> : <Empty>{sort === "popular" ? "Not enough recent listening to rank tracks in this genre yet." : "No tracks yet."}</Empty>}
          </Section>
        </>
      ) : <p className="muted" role="status">Loading…</p>}
    </>
  );
}
