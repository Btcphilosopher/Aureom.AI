"use client";

import Link from "next/link";
import { CreateArtist } from "@/components/CreateArtist";
import { SignInPrompt } from "@/components/SignInPrompt";
import { useAuth } from "@/lib/auth";

export default function StudioIndex() {
  const { me, loading } = useAuth();
  if (!loading && !me?.user) return <SignInPrompt what="manage your artist profiles" />;
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Artist studio</h1>
      <ul className="stack" style={{ listStyle: "none", padding: 0 }}>
        {me?.artists.map((a) => (
          <li key={a.id} className="card row">
            <Link href={`/studio/${a.id}`} style={{ fontWeight: 700, flex: 1 }}>{a.name}</Link>
            <span className="badge">{a.role}</span>
            {a.status !== "active" ? <span className="badge badge-coral">{a.status}</span> : null}
            <Link className="btn btn-sm" href={`/artists/${a.slug}`}>Public page</Link>
          </li>
        ))}
      </ul>
      <div style={{ marginTop: 20 }}><CreateArtist /></div>
    </>
  );
}
