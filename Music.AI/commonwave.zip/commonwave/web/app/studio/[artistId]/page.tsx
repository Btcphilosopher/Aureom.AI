"use client";

import Link from "next/link";
import { use, useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { formatBytes, formatDate, formatMoney, formatTime, kindLabel } from "@/lib/format";
import type { ReleaseBrief } from "@/lib/types";
import { useApi } from "@/lib/useApi";

interface DashTrack { id: string; title: string; status: string; pipeline: string; duration_ms: number | null; published_at: string | null; downloads: { mp3: boolean; original: boolean }; licence: { short: string } | null; moderation_restricted: boolean }
interface Dash {
  artist: { id: string; name: string; slug: string; status: string }; role: string;
  storage: { used_bytes: number; quota_bytes: number; max_upload_bytes: number };
  tracks: DashTrack[]; releases: ReleaseBrief[];
  uploads_in_progress: { id: string; filename: string; offset: number; length: number; expires_at: string }[];
}
interface Stats {
  window_days: number;
  totals: Record<string, number | string | null>;
  tracks: { track_id: string; title: string; playback_requests: number; qualified_listens: number; listening_hours: number; completions: number; downloads: number }[];
  daily_qualified_listens: { day: string; qualified: number }[];
}

const TABS = ["Catalogue", "Statistics", "Profile", "Members", "Support", "Export"] as const;

export default function Studio({ params }: { params: Promise<{ artistId: string }> }) {
  const { artistId } = use(params);
  const { data: d, error, reload } = useApi<Dash>(`/artists/${artistId}/dashboard`);
  const [tab, setTab] = useState<(typeof TABS)[number]>("Catalogue");
  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Not available</h1><p className="muted">You aren&apos;t a member of this artist.</p></div>;
  if (!d) return <p className="muted" role="status">Loading…</p>;
  const pct = Math.min(100, (d.storage.used_bytes / d.storage.quota_bytes) * 100);
  return (
    <>
      <p style={{ marginTop: 20 }}><Link href="/studio">← Studio</Link></p>
      <div className="row"><h1 style={{ margin: 0 }}>{d.artist.name}</h1><span className="badge">your role: {d.role}</span>{d.artist.status !== "active" ? <span className="badge badge-coral">{d.artist.status}</span> : null}
        <span className="spacer" /><Link className="btn btn-primary" href="/upload">Upload</Link><Link className="btn" href={`/artists/${d.artist.slug}`}>Public page</Link></div>
      <div className="card" style={{ margin: "16px 0" }}>
        <div className="row small"><strong>Storage</strong><span className="dim">{formatBytes(d.storage.used_bytes)} of {formatBytes(d.storage.quota_bytes)} used · max file {formatBytes(d.storage.max_upload_bytes)}</span></div>
        <div className="progressbar" role="progressbar" aria-label="Storage used" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100} style={{ marginTop: 8 }}><span style={{ width: `${pct}%` }} /></div>
      </div>
      <div className="tabs" role="tablist" aria-label="Studio sections">
        {TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}>{t}</button>)}
      </div>
      <div role="tabpanel">
        {tab === "Catalogue" ? <Catalogue d={d} reload={reload} /> : null}
        {tab === "Statistics" ? <StatsTab artistId={artistId} /> : null}
        {tab === "Profile" ? <ProfileTab artistId={artistId} slug={d.artist.slug} /> : null}
        {tab === "Members" ? <MembersTab artistId={artistId} /> : null}
        {tab === "Support" ? <SupportTab artistId={artistId} /> : null}
        {tab === "Export" ? <ExportTab artistId={artistId} /> : null}
      </div>
    </>
  );
}

function Catalogue({ d, reload }: { d: Dash; reload: () => void }) {
  const [title, setTitle] = useState("");
  const [kind, setKind] = useState("ep");
  const [err, setErr] = useState<string | null>(null);
  return (
    <>
      {d.uploads_in_progress.length ? (
        <div className="notice warn" style={{ marginBottom: 16 }}>
          <strong>Unfinished uploads</strong>
          {d.uploads_in_progress.map((u) => <div key={u.id}>{u.filename}: {Math.round((u.offset / u.length) * 100)}% — choose the same file on the Upload page to resume (expires {formatDate(u.expires_at)}).</div>)}
        </div>
      ) : null}
      <h2>Tracks</h2>
      <table>
        <thead><tr><th>Title</th><th>Pipeline</th><th>Length</th><th>Licence</th><th>Downloads</th><th>Published</th></tr></thead>
        <tbody>
          {d.tracks.map((t) => (
            <tr key={t.id}>
              <td><Link href={`/studio/track/${t.id}`}>{t.title}</Link>{t.moderation_restricted ? <> <span className="badge badge-coral">restricted</span></> : null}</td>
              <td><span className={`badge ${t.status === "published" ? "badge-teal" : t.pipeline.includes("failed") ? "badge-coral" : ""}`}>{t.pipeline}</span></td>
              <td>{formatTime(t.duration_ms)}</td>
              <td>{t.licence?.short ?? <span className="dim">none</span>}</td>
              <td>{t.downloads.mp3 ? "MP3" : "—"}{t.downloads.original ? " + original" : ""}</td>
              <td>{formatDate(t.published_at)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {!d.tracks.length ? <p className="dim">No tracks yet.</p> : null}
      <h2 style={{ marginTop: 30 }}>Releases</h2>
      <ul className="stack" style={{ listStyle: "none", padding: 0 }}>
        {d.releases.map((r) => (
          <li key={r.id} className="card row">
            <Link href={`/studio/release/${r.id}`} style={{ fontWeight: 700, flex: 1 }}>{r.title}</Link>
            <span className="dim small">{kindLabel(r.kind)} · {r.track_count} tracks</span>
            <span className={`badge ${r.status === "published" ? "badge-teal" : ""}`}>{r.status}</span>
          </li>
        ))}
      </ul>
      <form className="card row" style={{ alignItems: "flex-end", marginTop: 12 }} onSubmit={async (e) => {
        e.preventDefault();
        try {
          const r = await api<{ id: string }>("/releases", { method: "POST", body: { artist_id: d.artist.id, title, kind } });
          window.location.assign(`/studio/release/${r.id}`);
        } catch (x) {
          setErr(errorMessage(x));
        }
      }}>
        <div style={{ flex: 2, minWidth: 200 }}><label htmlFor="nr">New release title</label><input id="nr" required value={title} onChange={(e) => setTitle(e.target.value)} /></div>
        <div style={{ flex: 1, minWidth: 140 }}><label htmlFor="nk">Type</label><select id="nk" value={kind} onChange={(e) => setKind(e.target.value)}><option value="single">Single</option><option value="ep">EP</option><option value="album">Album</option><option value="compilation">Compilation</option></select></div>
        <button type="submit">Create release</button>
      </form>
      {err ? <p className="notice error" role="alert">{err}</p> : null}
      <button className="btn-sm btn-ghost" style={{ marginTop: 10 }} onClick={() => reload()}>Refresh</button>
    </>
  );
}

function StatsTab({ artistId }: { artistId: string }) {
  const [days, setDays] = useState(28);
  const { data: s, error } = useApi<Stats>(`/artists/${artistId}/stats?days=${days}`, [days]);
  if (error) return <p className="notice error">{error.message}</p>;
  if (!s) return <p className="muted">Loading…</p>;
  const max = Math.max(1, ...s.daily_qualified_listens.map((d) => d.qualified));
  const T = s.totals;
  return (
    <>
      <div className="row"><label htmlFor="days" style={{ margin: 0 }}>Window</label>
        <select id="days" value={days} onChange={(e) => setDays(Number(e.target.value))} style={{ width: "auto" }}><option value={7}>7 days</option><option value={28}>28 days</option><option value={90}>90 days</option><option value={365}>365 days</option></select></div>
      <div className="stats" style={{ marginTop: 16 }}>
        {([["playback_requests", "Playback requests"], ["playback_starts", "Playback starts"], ["qualified_listens", "Qualified listens"], ["listening_hours", "Listening hours"],
          ["completion_rate", "Completion rate"], ["unique_listeners", "Unique listeners"], ["downloads", "Downloads"], ["saves", "Saves"], ["new_follows", "New follows"], ["followers_total", "Followers"]] as const).map(([k, label]) => (
          <div key={k} className="card stat"><b>{k === "completion_rate" ? (T[k] == null ? "—" : `${Math.round(Number(T[k]) * 100)}%`) : String(T[k] ?? 0)}</b><span>{label}</span></div>
        ))}
      </div>
      <h3 style={{ marginTop: 24 }}>Qualified listens per day</h3>
      <div className="bars" role="img" aria-label={`Daily qualified listens over ${days} days, peak ${max}`}>
        {s.daily_qualified_listens.map((d) => <span key={d.day} style={{ height: `${(d.qualified / max) * 100}%` }} title={`${d.day}: ${d.qualified}`} />)}
      </div>
      <table style={{ marginTop: 24 }}>
        <thead><tr><th>Track</th><th>Requests</th><th>Qualified</th><th>Hours</th><th>Completions</th><th>Downloads</th></tr></thead>
        <tbody>{s.tracks.map((t) => <tr key={t.track_id}><td>{t.title}</td><td>{t.playback_requests}</td><td>{t.qualified_listens}</td><td>{t.listening_hours}</td><td>{t.completions}</td><td>{t.downloads}</td></tr>)}</tbody>
      </table>
      <details style={{ marginTop: 16 }}>
        <summary>How these numbers are counted</summary>
        <p className="small muted">A <strong>qualified listen</strong> is at least 30 seconds (or half of a shorter track) of real playback, measured by the server and capped by elapsed time. Repeated listens by the same listener within 30 minutes count once. Automated traffic and your own previews are excluded. Unique listeners under 5 are shown as “&lt;5”. Counts are best-effort, not fraud-proof, and never identify individual listeners.</p>
        <p className="small muted">{String(T.excluded_automated_sessions ?? 0)} sessions in this window were flagged as automated and excluded.</p>
      </details>
    </>
  );
}

function ProfileTab({ artistId, slug }: { artistId: string; slug: string }) {
  const { data: a, reload } = useApi<{ name: string; bio: string | null; location: string | null; links: { label: string; url: string }[]; support_url: string | null; tips_enabled: boolean; kind: string }>(`/artists/${slug}`);
  const [f, setF] = useState<Record<string, string | boolean> | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  if (!a) return <p className="muted">Loading…</p>;
  const v = f ?? { name: a.name, bio: a.bio ?? "", location: a.location ?? "", support_url: a.support_url ?? "", tips_enabled: a.tips_enabled, links: a.links.map((l) => `${l.label} | ${l.url}`).join("\n") };
  const set = (k: string, val: string | boolean) => setF({ ...v, [k]: val });
  const art = async (file: File, purpose: "avatar" | "banner") => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("purpose", purpose);
    fd.append("alt_text", `${purpose} for ${a.name}`);
    try {
      const r = await api<{ id: string }>(`/artists/${artistId}/artworks`, { method: "POST", body: fd });
      await api(`/artists/${artistId}`, { method: "PATCH", body: { [`${purpose}_artwork_id`]: r.id } });
      setMsg(`${purpose} updated`);
      void reload();
    } catch (e) {
      setMsg(errorMessage(e));
    }
  };
  return (
    <form className="panel" onSubmit={async (e) => {
      e.preventDefault();
      try {
        await api(`/artists/${artistId}`, { method: "PATCH", body: {
          name: v.name, bio: v.bio, location: v.location, support_url: v.support_url || null, tips_enabled: v.tips_enabled,
          links: String(v.links).split("\n").map((l) => l.split("|").map((x) => x.trim())).filter((p) => p[0] && p[1]).map(([label, url]) => ({ label, url })),
        } });
        setMsg("Profile saved.");
        void reload();
      } catch (x) {
        setMsg(errorMessage(x));
      }
    }}>
      <div className="grid2">
        <div className="field"><label htmlFor="p-n">Name</label><input id="p-n" value={String(v.name)} onChange={(e) => set("name", e.target.value)} /></div>
        <div className="field"><label htmlFor="p-l">Location</label><input id="p-l" value={String(v.location)} onChange={(e) => set("location", e.target.value)} /></div>
      </div>
      <div className="field"><label htmlFor="p-b">Biography</label><textarea id="p-b" value={String(v.bio)} onChange={(e) => set("bio", e.target.value)} rows={6} /></div>
      <div className="field"><label htmlFor="p-links">Links</label><textarea id="p-links" value={String(v.links)} onChange={(e) => set("links", e.target.value)} placeholder="Website | https://example.org" /><p className="hint">One per line: label | https://…</p></div>
      <div className="field"><label htmlFor="p-s">Support link (optional)</label><input id="p-s" type="url" value={String(v.support_url)} onChange={(e) => set("support_url", e.target.value)} placeholder="https://" /><p className="hint">An external page where fans can support you. COMMONWAVE takes no cut.</p></div>
      <label className="check"><input type="checkbox" checked={Boolean(v.tips_enabled)} onChange={(e) => set("tips_enabled", e.target.checked)} /> Accept one-time tips (simulated payments in this release)</label>
      <div className="grid2" style={{ marginTop: 16 }}>
        <div className="field"><label htmlFor="p-av">Avatar image</label><input id="p-av" type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && void art(e.target.files[0], "avatar")} /></div>
        <div className="field"><label htmlFor="p-ba">Banner image (wide)</label><input id="p-ba" type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && void art(e.target.files[0], "banner")} /></div>
      </div>
      {msg ? <p className="notice" role="status">{msg}</p> : null}
      <button className="btn-primary" type="submit">Save profile</button>
    </form>
  );
}

function MembersTab({ artistId }: { artistId: string }) {
  const { data, reload } = useApi<{ user_id: string; username: string; display_name: string; role: string; since: string }[]>(`/artists/${artistId}/members`);
  const [username, setUsername] = useState("");
  const [role, setRole] = useState("contributor");
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <>
      <p className="muted">Bands can have several authorised managers. <strong>Owners</strong> manage members; <strong>managers</strong> publish, withdraw and see statistics; <strong>contributors</strong> upload and edit drafts but cannot publish.</p>
      <table><thead><tr><th>Member</th><th>Role</th><th>Since</th><th /></tr></thead>
        <tbody>{data?.map((m) => <tr key={m.user_id}><td>{m.display_name} <span className="dim">@{m.username}</span></td><td>{m.role}</td><td>{formatDate(m.since)}</td>
          <td><button className="btn-sm btn-ghost" onClick={() => void api(`/artists/${artistId}/members/${m.user_id}`, { method: "DELETE" }).then(() => reload()).catch((e) => setMsg(errorMessage(e)))}>Remove</button></td></tr>)}</tbody></table>
      <form className="card row" style={{ alignItems: "flex-end", marginTop: 16 }} onSubmit={async (e) => {
        e.preventDefault();
        try { await api(`/artists/${artistId}/members`, { method: "POST", body: { username, role } }); setUsername(""); void reload(); } catch (x) { setMsg(errorMessage(x)); }
      }}>
        <div style={{ flex: 2, minWidth: 180 }}><label htmlFor="m-u">Username</label><input id="m-u" required value={username} onChange={(e) => setUsername(e.target.value)} /></div>
        <div style={{ flex: 1, minWidth: 140 }}><label htmlFor="m-r">Role</label><select id="m-r" value={role} onChange={(e) => setRole(e.target.value)}><option value="contributor">Contributor</option><option value="manager">Manager</option><option value="owner">Owner</option></select></div>
        <button type="submit">Add or change</button>
      </form>
      {msg ? <p className="notice error" role="alert">{msg}</p> : null}
    </>
  );
}

function SupportTab({ artistId }: { artistId: string }) {
  const { data, error } = useApi<{ simulated: boolean; totals: { currency: string; gross_minor: number; net_minor: number }[]; entries: { id: string; currency: string; gross_minor: number; platform_fee_minor: number; provider_fee_minor: number; net_minor: number; status: string; created_at: string }[] }>(`/artists/${artistId}/support/ledger`);
  if (error) return <p className="notice error">{error.message}</p>;
  if (!data) return <p className="muted">Loading…</p>;
  return (
    <>
      <div className="notice warn"><strong>Simulated payments</strong>No real money moves in this release. The ledger shows what an artist would be owed after explicit fees.</div>
      <div className="stats" style={{ margin: "16px 0" }}>{data.totals.map((t) => <div key={t.currency} className="card stat"><b>{formatMoney(t.net_minor, t.currency)}</b><span>owed (net) · gross {formatMoney(t.gross_minor, t.currency)}</span></div>)}</div>
      <table><thead><tr><th>Date</th><th>Gross</th><th>Platform fee</th><th>Provider fee</th><th>Net</th><th>Status</th></tr></thead>
        <tbody>{data.entries.map((e) => <tr key={e.id}><td>{formatDate(e.created_at)}</td><td>{formatMoney(e.gross_minor, e.currency)}</td><td>{formatMoney(e.platform_fee_minor, e.currency)}</td><td>{formatMoney(e.provider_fee_minor, e.currency)}</td><td>{formatMoney(e.net_minor, e.currency)}</td><td>{e.status}</td></tr>)}</tbody></table>
      {!data.entries.length ? <p className="dim">No support received yet.</p> : null}
    </>
  );
}

function ExportTab({ artistId }: { artistId: string }) {
  const [job, setJob] = useState<{ id: string; status: string; download_url?: string; size_bytes?: number } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const start = async () => {
    try {
      const r = await api<{ job_id: string; status: string }>(`/artists/${artistId}/export`, { method: "POST" });
      const poll = async (): Promise<void> => {
        const j = await api<{ id: string; status: string; download_url?: string; size_bytes?: number }>(`/jobs/${r.job_id}`);
        setJob(j);
        if (j.status === "queued" || j.status === "running") {
          await new Promise((ok) => setTimeout(ok, 1500));
          return poll();
        }
      };
      await poll();
    } catch (e) {
      setErr(errorMessage(e));
    }
  };
  return (
    <div className="panel">
      <h2>Export your data</h2>
      <p className="muted">A ZIP with your original uploads (byte-for-byte), artwork, all metadata, the full history of rights declarations and aggregated statistics. Your data is yours — you can take it to another server.</p>
      <button className="btn-primary" onClick={() => void start()} disabled={job?.status === "queued" || job?.status === "running"}>Build export</button>
      {job ? <p role="status" style={{ marginTop: 12 }}>Status: {job.status}{job.download_url ? <> — <a href={job.download_url}>Download ({formatBytes(job.size_bytes)})</a> (link expires in 10 minutes)</> : null}</p> : null}
      {err ? <p className="notice error" role="alert">{err}</p> : null}
    </div>
  );
}
