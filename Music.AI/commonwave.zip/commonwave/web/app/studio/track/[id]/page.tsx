"use client";

import Link from "next/link";
import { use, useEffect, useState } from "react";
import { Waveform } from "@/components/Waveform";
import { api, errorMessage, getCsrf } from "@/lib/api";
import { formatBytes, formatDate, formatTime } from "@/lib/format";
import { ResumableUpload, type UploadProgress } from "@/lib/tus";
import { useApi } from "@/lib/useApi";

interface Version {
  id: string; number: number; state: string; source_format: string | null; original_filename: string | null; duration_ms: number | null;
  technical: Record<string, unknown>; loudness_lufs: number | null; true_peak_dbtp: number | null; playback_gain_db: number | null;
  diagnostics: { level: string; code: string; message: string }[]; failure_reason: string | null; has_waveform: boolean;
  created_at: string; published_at: string | null; replaced_at: string | null;
}
interface Rights { code: string; name: string; recording_origin: string; composition_origin: string; attribution: string | null; composition_details: string | null; samples_details: string | null; remix_details: string | null; declared_at: string }
interface Manage {
  id: string; title: string; status: string; artist: { id: string; name: string; slug: string }; description: string | null; genre: string | null; tags: string[];
  language: string | null; explicit: boolean; lyrics: string | null; lyrics_authorised: boolean; credits: { name: string; role: string }[];
  collaborators: { name: string; role: string }[]; release_date: string | null; artwork_id: string | null; artwork_url: string | null;
  downloads: { mp3: boolean; original: boolean }; versions: Version[]; current_version_id: string | null; rights: Rights | null;
  pipeline: string; waveform: number[] | null; moderation_restricted: boolean; moderation_note: string | null; withdrawn_at: string | null;
  composition: { title: string; writers: { name: string; role: string }[]; origin: string } | null;
}
interface Catalogue {
  licences: { code: string; name: string; short: string; explain: string; allows_reuse: boolean; permits: string[]; requires: string[]; prohibits: string[] }[];
  recording_origins: Record<string, string>; composition_origins: Record<string, string>; withdrawal_notice: string; verification_notice: string;
}

const STEPS = ["uploaded", "validating", "processing", "ready", "published"];
const STEP_LABEL: Record<string, string> = { uploaded: "Uploaded", validating: "Validating", processing: "Processing", ready: "Ready for review", published: "Published" };

function Steps({ version, published }: { version: Version | undefined; published: boolean }) {
  const state = version?.state ?? "uploaded";
  const idx = published && version?.state === "ready" ? 4 : STEPS.indexOf(state);
  return (
    <ol className="steps" aria-label="Processing pipeline">
      {STEPS.map((s, i) => {
        const cls = state === "failed" && i === Math.max(1, idx) ? "fail" : i < idx || (i === idx && (s === "ready" || s === "published")) ? "done" : i === idx ? "now" : "";
        return <li key={s} className={cls} aria-current={i === idx ? "step" : undefined}>{STEP_LABEL[s]}</li>;
      })}
      {state === "failed" ? <li className="fail">Failed</li> : null}
      {state === "cancelled" ? <li className="fail">Cancelled</li> : null}
    </ol>
  );
}

export default function TrackEditor({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data: t, reload, error } = useApi<Manage>(`/tracks/${id}/manage`);
  const cat = useApi<Catalogue>("/rights/catalogue");
  const [msg, setMsg] = useState<{ kind: "ok" | "error" | "warn"; text: string } | null>(null);
  const [form, setForm] = useState<Record<string, unknown> | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [replace, setReplace] = useState<UploadProgress | null>(null);

  const latest = t?.versions[0];
  const busy = latest && ["uploaded", "validating", "processing"].includes(latest.state);
  useEffect(() => {
    if (!busy) return;
    const h = setInterval(() => void reload(), 2000);
    return () => clearInterval(h);
  }, [busy, reload]);

  useEffect(() => {
    if (t && !form) {
      setForm({
        title: t.title, description: t.description ?? "", genre: t.genre ?? "", tags: t.tags.join(", "), language: t.language ?? "",
        explicit: t.explicit, lyrics: t.lyrics ?? "", lyrics_authorised: t.lyrics_authorised, release_date: t.release_date ?? "",
        credits: t.credits.map((c) => `${c.name} — ${c.role}`).join("\n"),
        writers: (t.composition?.writers ?? []).map((c) => `${c.name} — ${c.role}`).join("\n"),
      });
    }
  }, [t, form]);

  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Track not found</h1><p className="muted">You may not manage this track.</p></div>;
  if (!t || !form) return <p className="muted" role="status">Loading…</p>;

  const act = async (path: string, body?: Record<string, unknown>, ok?: string) => {
    try {
      const r = await api<{ notice?: string }>(path, { method: "POST", body: body ?? {} });
      setMsg({ kind: r?.notice ? "warn" : "ok", text: r?.notice ?? ok ?? "Done." });
      void reload();
    } catch (e) {
      setMsg({ kind: "error", text: errorMessage(e) });
    }
  };

  const parseCredits = (s: string) => s.split("\n").map((l) => l.split(/\s+[—-]\s+/)).filter((p) => p[0]?.trim()).map(([name, role]) => ({ name: name.trim(), role: (role ?? "").trim() || "Credit" }));

  const saveMeta = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api(`/tracks/${t.id}`, {
        method: "PATCH",
        body: {
          title: form.title, description: form.description, genre: form.genre, language: form.language, explicit: form.explicit,
          tags: String(form.tags).split(",").map((x) => x.trim()).filter(Boolean), lyrics: form.lyrics, lyrics_authorised: form.lyrics_authorised,
          release_date: form.release_date || null, credits: parseCredits(String(form.credits)),
          composition: { title: form.title, writers: parseCredits(String(form.writers)), origin: t.rights?.composition_origin === "public_domain" ? "public_domain" : "original" },
        },
      });
      setMsg({ kind: "ok", text: "Details saved." });
      void reload();
    } catch (err) {
      setMsg({ kind: "error", text: errorMessage(err) });
    }
  };

  const uploadArt = async (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("alt_text", `Artwork for ${t.title}`);
    try {
      const a = await api<{ id: string }>(`/artists/${t.artist.id}/artworks`, { method: "POST", body: fd });
      await api(`/tracks/${t.id}`, { method: "PATCH", body: { artwork_id: a.id } });
      void reload();
    } catch (err) {
      setMsg({ kind: "error", text: errorMessage(err) });
    }
  };

  const startPreview = async () => {
    try {
      const s = await api<{ stream_url: string }>("/playback/sessions", { method: "POST", body: { track_id: t.id, preview: true, version_id: latest?.state === "ready" ? latest.id : undefined } });
      setPreview(s.stream_url);
    } catch (err) {
      setMsg({ kind: "error", text: errorMessage(err) });
    }
  };

  const replaceAudio = async (file: File) => {
    const up = new ResumableUpload(file, { artistId: t.artist.id, trackId: t.id, onProgress: setReplace });
    try {
      await up.start();
      void reload();
    } catch (err) {
      setMsg({ kind: "error", text: errorMessage(err) });
    }
  };

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm({ ...form, [k]: e.target.type === "checkbox" ? (e.target as HTMLInputElement).checked : e.target.value });
  const published = t.status === "published";
  const readyVersion = t.versions.find((v) => v.state === "ready" && v.id !== t.current_version_id);

  return (
    <>
      <p style={{ marginTop: 20 }}><Link href={`/studio/${t.artist.id}`}>← {t.artist.name} studio</Link></p>
      <h1>{t.title}</h1>
      <div className="row" style={{ marginBottom: 12 }}>
        <span className={`badge ${published ? "badge-teal" : t.status === "withdrawn" ? "badge-coral" : ""}`}>{t.status}</span>
        <span className="dim">{t.pipeline}</span>
        {published ? <Link href={`/tracks/${t.id}`} className="small">View public page</Link> : <span className="dim small">Drafts are visible only to this artist&apos;s members.</span>}
      </div>
      <Steps version={t.versions.find((v) => v.id === t.current_version_id) ?? latest} published={published} />
      {t.moderation_restricted ? <div className="notice error"><strong>Restricted by moderators</strong>{t.moderation_note} — you can appeal in <Link href="/settings#moderation">Settings</Link>.</div> : null}
      {msg ? <p role="status" className={`notice ${msg.kind === "error" ? "error" : msg.kind === "warn" ? "warn" : ""}`}>{msg.text}</p> : null}

      <div className="two-col" style={{ marginTop: 16 }}>
        <div className="stack">
          <section className="panel" aria-labelledby="audio-h">
            <h2 id="audio-h">Audio</h2>
            {latest ? (
              <>
                {latest.has_waveform ? <Waveform peaks={t.waveform ?? null} durationMs={latest.duration_ms ?? 0} positionMs={0} label="Waveform preview" interactive={false} /> : null}
                <table style={{ marginTop: 10 }}>
                  <tbody>
                    <tr><th scope="row">File</th><td>{latest.original_filename} · {latest.source_format?.toUpperCase()} (detected from contents)</td></tr>
                    {latest.duration_ms ? <tr><th scope="row">Duration</th><td>{formatTime(latest.duration_ms)}</td></tr> : null}
                    {latest.technical?.sample_rate ? <tr><th scope="row">Format</th><td>{String(latest.technical.codec)} · {String(latest.technical.sample_rate)} Hz · {String(latest.technical.channels)} ch{latest.technical.bits_per_sample ? ` · ${String(latest.technical.bits_per_sample)}-bit` : ""}</td></tr> : null}
                    {latest.technical?.stream_bitrate_kbps ? <tr><th scope="row">Stream</th><td>MP3 {String(latest.technical.stream_bitrate_kbps)} kbps · {formatBytes(Number(latest.technical.stream_size_bytes))}</td></tr> : null}
                    {latest.loudness_lufs != null ? <tr><th scope="row">Loudness</th><td>{latest.loudness_lufs.toFixed(1)} LUFS integrated, true peak {latest.true_peak_dbtp?.toFixed(1)} dBTP. Player levelling: {latest.playback_gain_db?.toFixed(1)} dB (your file is not changed).</td></tr> : null}
                  </tbody>
                </table>
                {latest.diagnostics.length ? (
                  <ul className="stack" style={{ listStyle: "none", padding: 0, marginTop: 12 }}>
                    {latest.diagnostics.map((d, i) => <li key={i} className={`notice ${d.level === "error" ? "error" : d.level === "warning" ? "warn" : ""}`}><strong>{d.level === "error" ? "Error" : d.level === "warning" ? "Warning" : "Note"}</strong>{d.message}</li>)}
                  </ul>
                ) : null}
                <div className="row" style={{ marginTop: 12 }}>
                  {busy ? <span role="status" className="muted">Processing… this page updates automatically.</span> : null}
                  {busy || latest.state === "ready" && latest.id !== t.current_version_id ? <button className="btn-sm" onClick={() => void act(`/versions/${latest.id}/cancel`, undefined, "Version cancelled.")}>Cancel this version</button> : null}
                  {latest.state === "failed" ? <button className="btn-sm" onClick={() => void act(`/versions/${latest.id}/retry`, undefined, "Retrying processing.")}>Retry processing</button> : null}
                  {t.versions.some((v) => v.state === "ready") ? <button className="btn-sm btn-teal" onClick={() => void startPreview()}>Preview (private)</button> : null}
                </div>
                {preview ? <audio controls src={preview} style={{ width: "100%", marginTop: 12 }} aria-label="Private preview" /> : null}
              </>
            ) : <p className="muted">No audio yet. <Link href="/upload">Upload a file</Link>.</p>}
            <details style={{ marginTop: 14 }}>
              <summary>Replace audio (creates a new version)</summary>
              <p className="dim small">Playlists, comments and statistics stay attached to this track. Listeners keep hearing the current version until you publish the replacement.</p>
              <input type="file" accept=".mp3,.wav,.flac,audio/*" aria-label="Choose replacement audio" onChange={(e) => e.target.files?.[0] && void replaceAudio(e.target.files[0])} />
              {replace ? <p className="small" role="status">{replace.state} {Math.round((replace.uploaded / Math.max(1, replace.total)) * 100)}%</p> : null}
            </details>
            {t.versions.length > 1 ? (
              <details style={{ marginTop: 10 }}>
                <summary>Version history ({t.versions.length})</summary>
                <table><thead><tr><th>#</th><th>State</th><th>File</th><th>Published</th><th>Replaced</th></tr></thead>
                  <tbody>{t.versions.map((v) => <tr key={v.id}><td>{v.number}{v.id === t.current_version_id ? " (current)" : ""}</td><td>{v.state}</td><td>{v.original_filename}</td><td>{formatDate(v.published_at)}</td><td>{formatDate(v.replaced_at)}</td></tr>)}</tbody></table>
              </details>
            ) : null}
          </section>

          <form className="panel" onSubmit={saveMeta} aria-labelledby="meta-h">
            <h2 id="meta-h">Details</h2>
            <div className="field"><label htmlFor="f-title">Title</label><input id="f-title" required value={String(form.title)} onChange={set("title")} /></div>
            <div className="grid2">
              <div className="field"><label htmlFor="f-genre">Genre</label><input id="f-genre" value={String(form.genre)} onChange={set("genre")} placeholder="e.g. ambient" /></div>
              <div className="field"><label htmlFor="f-tags">Tags</label><input id="f-tags" value={String(form.tags)} onChange={set("tags")} placeholder="comma, separated" /></div>
              <div className="field"><label htmlFor="f-lang">Language</label><input id="f-lang" value={String(form.language)} onChange={set("language")} placeholder="en, fr… or zxx for instrumental" /></div>
              <div className="field"><label htmlFor="f-date">Release date</label><input id="f-date" type="date" value={String(form.release_date)} onChange={set("release_date")} /></div>
            </div>
            <div className="field"><label htmlFor="f-desc">Description</label><textarea id="f-desc" value={String(form.description)} onChange={set("description")} maxLength={5000} /></div>
            <div className="field"><label className="check"><input type="checkbox" checked={Boolean(form.explicit)} onChange={set("explicit")} /> Explicit content</label></div>
            <div className="grid2">
              <div className="field"><label htmlFor="f-credits">Recording credits</label><textarea id="f-credits" value={String(form.credits)} onChange={set("credits")} placeholder={"Name — Role\nAlex Doe — Mixing"} /><p className="hint">One per line: name — role.</p></div>
              <div className="field"><label htmlFor="f-writers">Songwriters (composition)</label><textarea id="f-writers" value={String(form.writers)} onChange={set("writers")} placeholder={"Name — Composer"} /><p className="hint">The song and the recording are separate works.</p></div>
            </div>
            <div className="field"><label htmlFor="f-lyrics">Lyrics</label><textarea id="f-lyrics" value={String(form.lyrics)} onChange={set("lyrics")} />
              <label className="check" style={{ marginTop: 8 }}><input type="checkbox" checked={Boolean(form.lyrics_authorised)} onChange={set("lyrics_authorised")} /> I have the right to publish these lyrics (they are only shown when this is ticked)</label></div>
            <button className="btn-primary" type="submit">Save details</button>
          </form>

          {cat.data ? <RightsForm t={t} cat={cat.data} onSaved={(n) => { setMsg({ kind: n ? "warn" : "ok", text: n ?? "Rights declaration saved." }); void reload(); }} onError={(x) => setMsg({ kind: "error", text: x })} /> : null}
        </div>

        <aside className="stack">
          <section className="panel" aria-labelledby="pub-h">
            <h2 id="pub-h">Publishing</h2>
            <ul className="small" style={{ paddingLeft: 18 }}>
              <li>{t.versions.some((v) => v.state === "ready") ? "✓" : "○"} Audio processed</li>
              <li>{t.rights ? "✓" : "○"} Rights declared</li>
              <li>{t.title ? "✓" : "○"} Title</li>
            </ul>
            {t.status === "draft" ? <button className="btn-primary" onClick={() => void act(`/tracks/${t.id}/publish`, {}, "Published! Anyone can now stream this track.")}>Publish track</button> : null}
            {published && readyVersion ? <button className="btn-primary" onClick={() => void act(`/tracks/${t.id}/publish`, { version_id: readyVersion.id }, "Replacement published.")}>Publish replacement (v{readyVersion.number})</button> : null}
            {published ? <button className="btn-danger" style={{ marginTop: 10 }} onClick={() => { if (window.confirm(cat.data?.withdrawal_notice ?? "Withdraw?")) void act(`/tracks/${t.id}/withdraw`); }}>Withdraw track</button> : null}
            {t.status === "withdrawn" ? <button className="btn-teal" onClick={() => void act(`/tracks/${t.id}/restore`, undefined, "Track restored.")}>Restore track</button> : null}
            <p className="dim small" style={{ marginTop: 12 }}>{cat.data?.withdrawal_notice}</p>
          </section>
          <section className="panel" aria-labelledby="dl-h">
            <h2 id="dl-h">Downloads</h2>
            <p className="dim small">Streaming is always free. Downloads are a separate choice.</p>
            <Toggle label="Allow MP3 downloads" initial={t.downloads.mp3} save={(v) => api(`/tracks/${t.id}`, { method: "PATCH", body: { download_mp3: v } })} onError={(x) => setMsg({ kind: "error", text: x })} />
            <Toggle label={`Allow downloading my original file (${latest?.source_format?.toUpperCase() ?? "original"})`} initial={t.downloads.original} save={(v) => api(`/tracks/${t.id}`, { method: "PATCH", body: { download_original: v } })} onError={(x) => setMsg({ kind: "error", text: x })} />
          </section>
          <section className="panel" aria-labelledby="art-h">
            <h2 id="art-h">Artwork</h2>
            {t.artwork_url ? <img src={t.artwork_url} alt={`Artwork for ${t.title}`} style={{ borderRadius: 12, marginBottom: 10 }} /> : <p className="dim small">No track artwork — the release cover is used if there is one.</p>}
            <label htmlFor="art-file">Upload JPEG, PNG or WebP (min 300 px)</label>
            <input id="art-file" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => e.target.files?.[0] && void uploadArt(e.target.files[0])} />
            <p className="dim small">Artwork has its own rights. Only upload images you may use. Metadata such as location (EXIF) is removed.</p>
          </section>
        </aside>
      </div>
    </>
  );
}

/** Optimistic checkbox: flips immediately, reverts if the server refuses. */
function Toggle({ label, initial, save, onError }: { label: string; initial: boolean; save: (v: boolean) => Promise<unknown>; onError: (m: string) => void }) {
  const [on, setOn] = useState(initial);
  const [busy, setBusy] = useState(false);
  return (
    <label className="check">
      <input type="checkbox" checked={on} disabled={busy} onChange={async (e) => {
        const v = e.target.checked;
        setOn(v);
        setBusy(true);
        try { await save(v); } catch (x) { setOn(!v); onError(errorMessage(x)); } finally { setBusy(false); }
      }} /> {label}
    </label>
  );
}

function RightsForm({ t, cat, onSaved, onError }: { t: Manage; cat: Catalogue; onSaved: (notice: string | null) => void; onError: (m: string) => void }) {
  const [f, setF] = useState({
    licence_code: t.rights?.code ?? "ARR", recording_origin: t.rights?.recording_origin ?? "original", composition_origin: t.rights?.composition_origin ?? "original",
    attribution_text: t.rights?.attribution ?? "", composition_details: t.rights?.composition_details ?? "", samples_details: t.rights?.samples_details ?? "",
    remix_details: t.rights?.remix_details ?? "", source_notes: "", confirm_rights: false, confirm_not_verified: false, confirm_irrevocable: false,
  });
  const lic = cat.licences.find((l) => l.code === f.licence_code)!;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const r = await fetch(`/api/v1/tracks/${t.id}/rights`, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", "X-CSRF-Token": getCsrf() ?? "" }, body: JSON.stringify(f) });
      const j = await r.json();
      if (!r.ok) return onError(j?.error?.message ?? "Could not save the declaration.");
      onSaved(j.notice);
    } catch (err) {
      onError(errorMessage(err));
    }
  };
  return (
    <form className="panel" onSubmit={submit} aria-labelledby="rights-h">
      <h2 id="rights-h">Rights &amp; licence</h2>
      {t.rights ? <p className="small">Current: <strong>{t.rights.name}</strong>, declared {formatDate(t.rights.declared_at)}.</p> : <p className="small">Required before publishing.</p>}
      <p className="dim small">{cat.verification_notice}</p>
      <fieldset className="field">
        <legend><strong>The recording</strong> — who made this sound recording?</legend>
        {Object.entries(cat.recording_origins).map(([k, v]) => <label key={k} className="check"><input type="radio" name="rec" checked={f.recording_origin === k} onChange={() => setF({ ...f, recording_origin: k })} /> {v}</label>)}
      </fieldset>
      {f.recording_origin === "contains_samples" ? <div className="field"><label htmlFor="r-s">List each sample and how it is cleared</label><textarea id="r-s" required value={f.samples_details} onChange={(e) => setF({ ...f, samples_details: e.target.value })} /></div> : null}
      {f.recording_origin === "remix" ? <div className="field"><label htmlFor="r-r">Original recording and your permission to remix it</label><textarea id="r-r" required value={f.remix_details} onChange={(e) => setF({ ...f, remix_details: e.target.value })} /></div> : null}
      <fieldset className="field">
        <legend><strong>The composition</strong> — who wrote the song?</legend>
        {Object.entries(cat.composition_origins).map(([k, v]) => <label key={k} className="check"><input type="radio" name="comp" checked={f.composition_origin === k} onChange={() => setF({ ...f, composition_origin: k })} /> {v}</label>)}
      </fieldset>
      {f.composition_origin !== "original" ? <div className="field"><label htmlFor="r-c">Song details (title, writers, how it is licensed)</label><textarea id="r-c" value={f.composition_details} onChange={(e) => setF({ ...f, composition_details: e.target.value })} /></div> : null}
      <div className="field">
        <label htmlFor="r-l">Licence for listeners</label>
        <select id="r-l" value={f.licence_code} onChange={(e) => setF({ ...f, licence_code: e.target.value })}>
          {cat.licences.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
        </select>
        <div className="card small" style={{ marginTop: 8 }}>
          <p style={{ margin: 0 }}>{lic.explain}</p>
          <p className="dim" style={{ margin: "6px 0 0" }}>Allows: {lic.permits.join(", ") || "—"} · Requires: {lic.requires.join(", ") || "nothing"} · Not allowed: {lic.prohibits.join(", ") || "—"}</p>
        </div>
      </div>
      {lic.requires.includes("Attribution") ? <div className="field"><label htmlFor="r-a">Attribution text</label><input id="r-a" value={f.attribution_text} onChange={(e) => setF({ ...f, attribution_text: e.target.value })} placeholder={`“${t.title}” by ${t.artist.name}`} /></div> : null}
      <label className="check"><input type="checkbox" checked={f.confirm_rights} onChange={(e) => setF({ ...f, confirm_rights: e.target.checked })} /> I own or control the rights needed to publish this recording and composition on these terms.</label>
      <label className="check"><input type="checkbox" checked={f.confirm_not_verified} onChange={(e) => setF({ ...f, confirm_not_verified: e.target.checked })} /> I understand this is my declaration; COMMONWAVE does not verify it, and false claims can lead to removal.</label>
      {lic.allows_reuse ? <label className="check"><input type="checkbox" checked={f.confirm_irrevocable} onChange={(e) => setF({ ...f, confirm_irrevocable: e.target.checked })} /> I understand open licences can&apos;t be taken back for copies people already have, even if I withdraw the track later.</label> : null}
      <button className="btn-primary" type="submit" style={{ marginTop: 12 }}>Save rights declaration</button>
    </form>
  );
}
