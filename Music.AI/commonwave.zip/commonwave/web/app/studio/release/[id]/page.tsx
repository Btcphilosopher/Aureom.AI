"use client";

import Link from "next/link";
import { use, useEffect, useState } from "react";
import { api, errorMessage } from "@/lib/api";
import type { ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

interface R extends ReleaseBrief { description: string | null; tracks: Track[]; viewer: { can_manage: boolean } }
interface D { tracks: { id: string; title: string; status: string; pipeline: string }[] }

export default function ReleaseEditor({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data: r, reload, error } = useApi<R>(`/releases/${id}`);
  const dash = useApi<D>(r ? `/artists/${r.artist.id}/dashboard` : null, [r?.artist.id]);
  const [f, setF] = useState<Record<string, string | boolean | number> | null>(null);
  const [order, setOrder] = useState<string[]>([]);
  const [msg, setMsg] = useState<{ error?: boolean; text: string } | null>(null);

  useEffect(() => {
    if (r && !f) {
      setF({ title: r.title, kind: r.kind, description: r.description ?? "", genre: r.genre ?? "", tags: r.tags.join(", "), release_date: r.release_date ?? "",
        pwyw_enabled: Boolean(r.pwyw?.enabled), pwyw_min: (r.pwyw?.min_minor ?? 0) / 100, pwyw_currency: r.pwyw?.currency ?? "USD" });
      setOrder(r.track_ids ?? r.tracks.map((t) => t.id));
    }
  }, [r, f]);
  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Release not found</h1></div>;
  if (!r || !f) return <p className="muted" role="status">Loading…</p>;
  const all = dash.data?.tracks ?? [];
  const title = (tid: string) => all.find((t) => t.id === tid)?.title ?? r.tracks.find((t) => t.id === tid)?.title ?? tid;
  const run = async (fn: () => Promise<unknown>, ok: string) => {
    try { const res = (await fn()) as { notice?: string } | undefined; setMsg({ text: res?.notice ?? ok }); void reload(); } catch (e) { setMsg({ error: true, text: errorMessage(e) }); }
  };
  const move = (i: number, d: number) => { const o = [...order]; const [x] = o.splice(i, 1); o.splice(i + d, 0, x); setOrder(o); };
  const art = async (file: File) => {
    const fd = new FormData(); fd.append("file", file); fd.append("alt_text", `Cover of ${r.title}`);
    await run(async () => { const a = await api<{ id: string }>(`/artists/${r.artist.id}/artworks`, { method: "POST", body: fd }); return api(`/releases/${r.id}`, { method: "PATCH", body: { artwork_id: a.id } }); }, "Cover updated.");
  };
  return (
    <>
      <p style={{ marginTop: 20 }}><Link href={`/studio/${r.artist.id}`}>← {r.artist.name} studio</Link></p>
      <div className="row"><h1 style={{ margin: 0 }}>{r.title}</h1><span className={`badge ${r.status === "published" ? "badge-teal" : ""}`}>{r.status}</span><span className="spacer" />{r.status === "published" ? <Link href={`/releases/${r.id}`}>Public page</Link> : null}</div>
      {msg ? <p role="status" className={`notice ${msg.error ? "error" : ""}`} style={{ marginTop: 12 }}>{msg.text}</p> : null}
      <div className="two-col" style={{ marginTop: 16 }}>
        <div className="stack">
          <form className="panel" onSubmit={(e) => { e.preventDefault(); void run(() => api(`/releases/${r.id}`, { method: "PATCH", body: {
            title: f.title, kind: f.kind, description: f.description, genre: f.genre, tags: String(f.tags).split(",").map((x) => x.trim()).filter(Boolean),
            release_date: f.release_date || null, pwyw_enabled: f.pwyw_enabled, pwyw_min_minor: Math.round(Number(f.pwyw_min) * 100), pwyw_currency: f.pwyw_currency } }), "Release saved."); }}>
            <h2>Details</h2>
            <div className="grid2">
              <div className="field"><label htmlFor="r-t">Title</label><input id="r-t" value={String(f.title)} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
              <div className="field"><label htmlFor="r-k">Type</label><select id="r-k" value={String(f.kind)} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="single">Single</option><option value="ep">EP</option><option value="album">Album</option><option value="compilation">Compilation</option></select></div>
              <div className="field"><label htmlFor="r-g">Genre</label><input id="r-g" value={String(f.genre)} onChange={(e) => setF({ ...f, genre: e.target.value })} /></div>
              <div className="field"><label htmlFor="r-d">Release date</label><input id="r-d" type="date" value={String(f.release_date)} onChange={(e) => setF({ ...f, release_date: e.target.value })} /></div>
            </div>
            <div className="field"><label htmlFor="r-tags">Tags</label><input id="r-tags" value={String(f.tags)} onChange={(e) => setF({ ...f, tags: e.target.value })} /></div>
            <div className="field"><label htmlFor="r-desc">Description</label><textarea id="r-desc" value={String(f.description)} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
            <fieldset className="card"><legend>Pay what you want (optional, simulated)</legend>
              <label className="check"><input type="checkbox" checked={Boolean(f.pwyw_enabled)} onChange={(e) => setF({ ...f, pwyw_enabled: e.target.checked })} /> Ask for a price before the full-release download. Streaming stays free.</label>
              <div className="grid2"><div className="field"><label htmlFor="r-min">Minimum</label><input id="r-min" type="number" min={0} step={0.5} value={Number(f.pwyw_min)} onChange={(e) => setF({ ...f, pwyw_min: Number(e.target.value) })} /></div>
                <div className="field"><label htmlFor="r-cur">Currency</label><select id="r-cur" value={String(f.pwyw_currency)} onChange={(e) => setF({ ...f, pwyw_currency: e.target.value })}><option>USD</option><option>EUR</option><option>GBP</option></select></div></div>
            </fieldset>
            <button className="btn-primary" type="submit" style={{ marginTop: 12 }}>Save</button>
          </form>
          <section className="panel">
            <h2>Track order</h2>
            <ol className="stack">
              {order.map((tid, i) => (
                <li key={tid} className="row"><span style={{ flex: 1 }}>{title(tid)}</span>
                  <button type="button" className="btn-sm" disabled={i === 0} onClick={() => move(i, -1)} aria-label={`Move ${title(tid)} up`}>↑</button>
                  <button type="button" className="btn-sm" disabled={i === order.length - 1} onClick={() => move(i, 1)} aria-label={`Move ${title(tid)} down`}>↓</button>
                  <button type="button" className="btn-sm btn-ghost" onClick={() => setOrder(order.filter((x) => x !== tid))}>Remove</button></li>
              ))}
            </ol>
            <div className="field" style={{ marginTop: 12 }}><label htmlFor="add-t">Add a track</label>
              <select id="add-t" value="" onChange={(e) => e.target.value && setOrder([...order, e.target.value])}>
                <option value="">Choose…</option>
                {all.filter((t) => !order.includes(t.id)).map((t) => <option key={t.id} value={t.id}>{t.title} ({t.pipeline})</option>)}
              </select></div>
            <button onClick={() => void run(() => api(`/releases/${r.id}/tracks`, { method: "PUT", body: { track_ids: order } }), "Track order saved.")}>Save order</button>
          </section>
        </div>
        <aside className="stack">
          <section className="panel">
            <h2>Cover</h2>
            {r.artwork_url ? <img src={r.artwork_url} alt={`Cover of ${r.title}`} style={{ borderRadius: 12, marginBottom: 10 }} /> : null}
            <label htmlFor="cover">Upload cover (square works best)</label>
            <input id="cover" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => e.target.files?.[0] && void art(e.target.files[0])} />
          </section>
          <section className="panel">
            <h2>Publish</h2>
            <p className="small dim">Publishing a release also publishes its tracks. Each track needs processed audio and a rights declaration.</p>
            {r.status !== "published" ? <button className="btn-primary" onClick={() => void run(() => api(`/releases/${r.id}/publish`, { method: "POST" }), "Release published.")}>Publish release</button>
              : <button className="btn-danger" onClick={() => { if (window.confirm("Withdraw this release and its tracks?")) void run(() => api(`/releases/${r.id}/withdraw`, { method: "POST" }), "Release withdrawn."); }}>Withdraw release</button>}
            <button className="btn-sm" style={{ marginTop: 10 }} onClick={() => void run(() => api(`/artists/${r.artist.id}`, { method: "PATCH", body: { pinned_release_id: r.id } }), "Pinned to your artist page.")}>Pin to artist page</button>
          </section>
        </aside>
      </div>
    </>
  );
}
