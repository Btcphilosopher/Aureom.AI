"use client";

import Link from "next/link";
import { useState } from "react";
import { ArtistCard, Empty, ReleaseCard, Section } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/useApi";
import type { ArtistBrief, ReleaseBrief, Track } from "@/lib/types";

interface Feed {
  personalised: boolean;
  ranking: string;
  latest_releases: ReleaseBrief[];
  latest_tracks: Track[];
  popular_tracks: Track[];
  new_voices: ArtistBrief[];
  recently_active_artists: (ArtistBrief & { last_published_at: string })[];
  genres: { genre: string; track_count: number }[];
  collections: { slug: string; title: string; description: string | null; curator_note: string | null; releases: ReleaseBrief[]; tracks: Track[] }[];
  for_you?: { explanation: string; tracks: Track[] };
}

export default function Discover() {
  const { me } = useAuth();
  const canPersonalise = Boolean(me?.user?.personalisation_enabled);
  const [personal, setPersonal] = useState(false);
  const { data, loading, error } = useApi<Feed>(`/discover?personalised=${personal && canPersonalise}`, [personal, canPersonalise]);

  return (
    <>
      <div className="hero" style={{ gridTemplateColumns: "1fr", alignItems: "start", marginTop: 26 }}>
        <div>
          <div className="kicker">Discover</div>
          <h1>Independent music, free to hear.</h1>
          <p className="muted" style={{ maxWidth: "60ch" }}>
            Every track here streams without an account or a subscription. Artists choose how their work may be shared — look for the licence on each release.
          </p>
          <div className="row">
            {canPersonalise ? (
              <div role="radiogroup" aria-label="Feed type" className="row" style={{ gap: 6 }}>
                <button role="radio" aria-checked={!personal} className={!personal ? "btn-teal btn-sm" : "btn-sm"} onClick={() => setPersonal(false)}>Everyone&apos;s feed</button>
                <button role="radio" aria-checked={personal} className={personal ? "btn-teal btn-sm" : "btn-sm"} onClick={() => setPersonal(true)}>For you</button>
              </div>
            ) : (
              <span className="dim small">This feed is the same for everyone. {me?.user ? <Link href="/settings">Opt in to a personal feed</Link> : null}</span>
            )}
            <Link href="/about#discovery" className="small">How ranking works</Link>
          </div>
        </div>
      </div>

      {error ? <div className="notice error">Couldn&apos;t load the feed. {error.message}</div> : null}
      {loading && !data ? <p className="muted" role="status">Loading…</p> : null}
      {data ? (
        <>
          {data.for_you ? (
            <Section title="For you" hint={data.for_you.explanation}>
              <TrackList tracks={data.for_you.tracks} source="for_you" emptyText="Follow artists or choose interests in Settings to fill this shelf." />
            </Section>
          ) : null}
          <Section title="Latest releases" hint="Newest first">
            {data.latest_releases.length ? <div className="cards">{data.latest_releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div> : <Empty>No releases yet.</Empty>}
          </Section>
          {data.collections.map((c) => (
            <Section key={c.slug} title={c.title} hint={c.curator_note ?? "Editorial collection"} action={<Link href={`/collections/${c.slug}`} className="small">Open collection</Link>}>
              {c.description ? <p className="muted">{c.description}</p> : null}
              <div className="cards">{c.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div>
            </Section>
          ))}
          <div className="two-col">
            <div>
              <Section title="New tracks">
                <TrackList tracks={data.latest_tracks} source="discover_latest" />
              </Section>
              <Section title="Popular this fortnight" hint="Distinct listeners over 14 days, not lifetime plays">
                {data.popular_tracks.length ? <TrackList tracks={data.popular_tracks} source="discover_popular" /> : (
                  <Empty>Not enough listening yet to rank anything fairly. A track needs at least three different listeners in the last 14 days.</Empty>
                )}
              </Section>
            </div>
            <div>
              <Section title="New voices" hint="First release in the last 60 days">
                {data.new_voices.length ? <div className="artists-row">{data.new_voices.map((a) => <ArtistCard key={a.id} a={a} />)}</div> : <Empty>No new artists this month.</Empty>}
              </Section>
              <Section title="Genres">
                <div className="row" style={{ gap: 8 }}>
                  {data.genres.map((g) => (
                    <Link key={g.genre} href={`/genres/${encodeURIComponent(g.genre)}`} className="btn btn-sm">
                      {g.genre} <span className="dim">{g.track_count}</span>
                    </Link>
                  ))}
                </div>
              </Section>
              <Section title="Recently active">
                <ul className="stack" style={{ listStyle: "none", padding: 0 }}>
                  {data.recently_active_artists.map((a) => (
                    <li key={a.id}><Link href={`/artists/${a.slug}`}>{a.name}</Link> <span className="dim small">published {new Date(a.last_published_at).toLocaleDateString()}</span></li>
                  ))}
                </ul>
              </Section>
            </div>
          </div>
        </>
      ) : null}
    </>
  );
}
