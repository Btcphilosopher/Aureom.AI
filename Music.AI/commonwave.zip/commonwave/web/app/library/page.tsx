"use client";

import Link from "next/link";
import { useState } from "react";
import { Empty, ReleaseCard, Section } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatDate } from "@/lib/format";
import type { ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";
import { SignInPrompt } from "@/components/SignInPrompt";

export default function Library() {
  const { me, loading } = useAuth();
  const [tab, setTab] = useState<"saved" | "history">("saved");
  const lib = useApi<{ tracks: Track[]; releases: ReleaseBrief[] }>(me?.user ? "/library" : null, [me?.user?.id]);
  const hist = useApi<{ enabled: boolean; items: { id: string; played_at: string; track: Track | null }[] }>(me?.user && tab === "history" ? "/library/history" : null, [tab, me?.user?.id]);
  if (!loading && !me?.user) return <SignInPrompt what="save music to your library" />;
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Library</h1>
      <div className="tabs" role="tablist" aria-label="Library sections">
        <button role="tab" aria-selected={tab === "saved"} onClick={() => setTab("saved")}>Saved</button>
        <button role="tab" aria-selected={tab === "history"} onClick={() => setTab("history")}>Listening history</button>
      </div>
      {tab === "saved" ? (
        <div role="tabpanel">
          <Section title="Saved releases">{lib.data?.releases.length ? <div className="cards">{lib.data.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div> : <Empty>Save albums and EPs to find them here.</Empty>}</Section>
          <Section title="Saved tracks"><TrackList tracks={lib.data?.tracks ?? []} source="library" emptyText="Save tracks from the ⋯ menu." /></Section>
        </div>
      ) : (
        <div role="tabpanel">
          <div className="notice" style={{ marginBottom: 16 }}>
            <strong>Private to you.</strong> History is never shown to artists or other listeners. Artists only see aggregated, anonymous totals.
            {hist.data && !hist.data.enabled ? <> History is currently <b>off</b>. </> : null} <Link href="/settings">Change in Settings</Link>.
          </div>
          {hist.data?.items.length ? (
            <>
              <button className="btn-danger btn-sm" onClick={() => { if (window.confirm("Delete your entire listening history?")) void api("/library/history", { method: "DELETE" }).then(() => hist.reload()); }}>Clear all history</button>
              <ul className="stack" style={{ listStyle: "none", padding: 0, marginTop: 16 }}>
                {hist.data.items.map((h) => (
                  <li key={h.id} className="row">
                    <span className="dim small" style={{ minWidth: 110 }}>{formatDate(h.played_at)}</span>
                    {h.track ? <Link href={`/tracks/${h.track.id}`}>{h.track.title} — {h.track.artist.name}</Link> : <span className="dim">Unavailable track</span>}
                    <button className="btn-sm btn-ghost" onClick={() => void api(`/library/history/${h.id}`, { method: "DELETE" }).then(() => hist.reload())} aria-label="Remove from history">Remove</button>
                  </li>
                ))}
              </ul>
            </>
          ) : <Empty>No listening history. Tracks appear here after a qualified listen (30 seconds, or half of a short track).</Empty>}
        </div>
      )}
    </>
  );
}
