"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, use, useState } from "react";
import { Icon } from "@/components/Icon";
import { ReportButton } from "@/components/ReportButton";
import { TrackList } from "@/components/TrackList";
import { api, errorMessage } from "@/lib/api";
import { usePlayer } from "@/lib/player/PlayerProvider";
import type { Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";
import { VIS } from "@/lib/visibility";

interface Entry { entry_id: string; position: number; track: Track | null; unavailable?: boolean; unavailable_title?: string | null }
interface PL { id: string; title: string; description: string | null; visibility: string; allow_duplicates: boolean; is_owner: boolean; owner: { username: string; display_name: string }; share_path?: string; entries: Entry[] }

function PlaylistView({ id }: { id: string }) {
  const token = useSearchParams().get("token");
  const { data: p, error, reload } = useApi<PL>(`/playlists/${id}${token ? `?token=${encodeURIComponent(token)}` : ""}`, [token]);
  const player = usePlayer();
  const [msg, setMsg] = useState<string | null>(null);
  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Playlist not found</h1><p className="muted">It may be private, or the share link was changed.</p></div>;
  if (!p) return <p className="muted" role="status">Loading…</p>;
  const tracks = p.entries.map((e) => e.track);
  const playable = tracks.filter((t): t is Track => Boolean(t));
  const patch = async (body: Record<string, unknown>) => {
    try {
      await api(`/playlists/${p.id}`, { method: "PATCH", body });
      void reload();
    } catch (e) {
      setMsg(errorMessage(e));
    }
  };
  const move = async (from: number, to: number) => {
    const ids = p.entries.map((e) => e.entry_id);
    const [x] = ids.splice(from, 1);
    ids.splice(to, 0, x);
    await api(`/playlists/${p.id}/order`, { method: "PUT", body: { entry_ids: ids } });
    void reload();
  };
  return (
    <>
      <div className="kicker" style={{ marginTop: 24, color: "var(--turquoise)", fontWeight: 800, letterSpacing: ".14em", textTransform: "uppercase", fontSize: ".78rem" }}>Playlist · {p.visibility}</div>
      <h1>{p.title}</h1>
      <p className="muted">by {p.owner.display_name}{p.description ? ` — ${p.description}` : ""}</p>
      <div className="row" style={{ marginBottom: 20 }}>
        <button className="play-btn" disabled={!playable.length} onClick={() => player.playList(playable, 0, "playlist")} aria-label={`Play ${p.title}`}><Icon name="play" /></button>
        {!p.is_owner ? <ReportButton targetType="playlist" targetId={p.id} /> : null}
      </div>
      {p.is_owner ? (
        <details className="card" style={{ marginBottom: 20 }}>
          <summary style={{ cursor: "pointer", fontWeight: 700 }}>Playlist settings</summary>
          <div className="grid2" style={{ marginTop: 14 }}>
            <div className="field"><label htmlFor="vis">Visibility</label>
              <select id="vis" value={p.visibility} onChange={(e) => void patch({ visibility: e.target.value })}>{Object.entries(VIS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
              <p className="hint">Unlisted is not private: anyone who has the link can open it. Private playlists ignore links entirely.</p></div>
            <div className="field"><label className="check"><input type="checkbox" checked={p.allow_duplicates} onChange={(e) => void patch({ allow_duplicates: e.target.checked })} /> Allow the same track more than once</label></div>
          </div>
          {p.share_path ? (
            <div className="row"><code className="mono" style={{ wordBreak: "break-all" }}>{typeof window !== "undefined" ? window.location.origin : ""}{p.share_path}</code>
              <button className="btn-sm" onClick={() => void patch({ rotate_share_link: true })}>Make a new link (old one stops working)</button></div>
          ) : null}
          <button className="btn-danger btn-sm" style={{ marginTop: 12 }} onClick={() => { if (window.confirm("Delete this playlist?")) void api(`/playlists/${p.id}`, { method: "DELETE" }).then(() => window.location.assign("/playlists")); }}>Delete playlist</button>
        </details>
      ) : null}
      {msg ? <p className="notice error" role="alert">{msg}</p> : null}
      <TrackList tracks={tracks} source="playlist" onRemove={p.is_owner ? (i) => void api(`/playlists/${p.id}/entries/${p.entries[i].entry_id}`, { method: "DELETE" }).then(() => reload()) : undefined} emptyText="This playlist is empty." />
      {p.is_owner && p.entries.length > 1 ? (
        <details style={{ marginTop: 16 }}>
          <summary>Reorder</summary>
          <ol className="stack">
            {p.entries.map((e, i) => (
              <li key={e.entry_id} className="row">
                <span style={{ flex: 1 }}>{e.track?.title ?? "Unavailable track"}</span>
                <button className="btn-sm" disabled={i === 0} onClick={() => void move(i, i - 1)} aria-label={`Move ${e.track?.title ?? "track"} up`}>↑</button>
                <button className="btn-sm" disabled={i === p.entries.length - 1} onClick={() => void move(i, i + 1)} aria-label={`Move ${e.track?.title ?? "track"} down`}>↓</button>
              </li>
            ))}
          </ol>
        </details>
      ) : null}
    </>
  );
}

export default function PlaylistPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return <Suspense fallback={<p className="muted">Loading…</p>}><PlaylistView id={id} /></Suspense>;
}
