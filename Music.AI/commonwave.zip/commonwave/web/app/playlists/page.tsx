"use client";

import Link from "next/link";
import { useState } from "react";
import { Empty } from "@/components/Cards";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatDate } from "@/lib/format";
import { useApi } from "@/lib/useApi";
import { SignInPrompt } from "@/components/SignInPrompt";
import { VIS } from "@/lib/visibility";

interface P { id: string; title: string; visibility: string; entry_count: number; updated_at: string }



export default function Playlists() {
  const { me, loading } = useAuth();
  const { data, reload } = useApi<P[]>(me?.user ? "/playlists" : null, [me?.user?.id]);
  const [title, setTitle] = useState("");
  const [visibility, setVisibility] = useState("private");
  const [msg, setMsg] = useState<string | null>(null);
  if (!loading && !me?.user) return <SignInPrompt what="make playlists" />;
  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api("/playlists", { method: "POST", body: { title, visibility } });
      setTitle("");
      void reload();
    } catch (err) {
      setMsg(errorMessage(err));
    }
  };
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Playlists</h1>
      <form onSubmit={create} className="card row" style={{ alignItems: "flex-end", marginBottom: 24 }}>
        <div style={{ flex: 2, minWidth: 200 }}><label htmlFor="pt">New playlist</label><input id="pt" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Name" /></div>
        <div style={{ flex: 1, minWidth: 200 }}><label htmlFor="pv">Who can see it</label>
          <select id="pv" value={visibility} onChange={(e) => setVisibility(e.target.value)}>{Object.entries(VIS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
        <button className="btn-primary" type="submit">Create</button>
      </form>
      {msg ? <p className="notice error" role="alert">{msg}</p> : null}
      {data?.length ? (
        <ul className="stack" style={{ listStyle: "none", padding: 0 }}>
          {data.map((p) => (
            <li key={p.id} className="card row">
              <div style={{ flex: 1 }}><Link href={`/playlists/${p.id}`} style={{ fontWeight: 700 }}>{p.title}</Link><div className="dim small">{p.entry_count} tracks · updated {formatDate(p.updated_at)}</div></div>
              <span className={`badge ${p.visibility === "public" ? "badge-teal" : p.visibility === "unlisted" ? "badge-gold" : ""}`}>{p.visibility}</span>
            </li>
          ))}
        </ul>
      ) : data ? <Empty>No playlists yet.</Empty> : null}
    </>
  );
}
