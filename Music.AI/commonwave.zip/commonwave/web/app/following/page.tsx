"use client";

import Link from "next/link";
import { SignInPrompt } from "@/components/SignInPrompt";
import { ArtistCard, Empty, ReleaseCard, Section } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import { useAuth } from "@/lib/auth";
import type { ArtistBrief, ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

export default function Following() {
  const { me, loading } = useAuth();
  const { data } = useApi<{ artists: ArtistBrief[]; releases: ReleaseBrief[]; tracks: Track[] }>(me?.user ? "/discover/following" : null, [me?.user?.id]);
  if (!loading && !me?.user) return <SignInPrompt what="follow artists and see their new releases here" />;
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Following</h1>
      <p className="muted">New music from artists you follow, newest first. Your follows are visible as counts only — never as a list of who follows whom.</p>
      {data ? (
        data.artists.length ? (
          <>
            <Section title="Artists"><div className="artists-row">{data.artists.map((a) => <ArtistCard key={a.id} a={a} />)}</div></Section>
            <Section title="Releases">{data.releases.length ? <div className="cards">{data.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div> : <Empty>No releases yet.</Empty>}</Section>
            <Section title="Latest tracks"><TrackList tracks={data.tracks} source="following" /></Section>
          </>
        ) : <Empty>You&apos;re not following anyone yet. Find artists on <Link href="/">Discover</Link>.</Empty>
      ) : <p className="muted" role="status">Loading…</p>}
    </>
  );
}

