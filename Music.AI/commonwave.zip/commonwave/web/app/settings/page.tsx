"use client";

import { useState } from "react";
import { SignInPrompt } from "@/components/SignInPrompt";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatDate } from "@/lib/format";
import { useApi } from "@/lib/useApi";

interface Decision { id: string; action: string; target_type: string; reason: string; created_at: string; expires_at: string | null; appeal: { status: string; decision_note: string | null } | null }

export default function Settings() {
  const { me, loading, refresh } = useAuth();
  const blocks = useApi<{ username: string; display_name: string }[]>(me?.user ? "/me/blocks" : null, [me?.user?.id]);
  const decisions = useApi<Decision[]>(me?.user ? "/me/moderation" : null, [me?.user?.id]);
  const [msg, setMsg] = useState<string | null>(null);
  const [blockName, setBlockName] = useState("");
  const [interests, setInterests] = useState<string | null>(null);
  if (!loading && !me?.user) return <SignInPrompt what="change your settings" />;
  if (!me?.user) return <p className="muted">Loading…</p>;
  const u = me.user;
  const patch = async (body: Record<string, unknown>, ok: string) => {
    try { await api("/me/settings", { method: "PATCH", body }); await refresh(); setMsg(ok); } catch (e) { setMsg(errorMessage(e)); }
  };
  const appeal = async (d: Decision) => {
    const statement = window.prompt("Explain why this decision should be reviewed (at least 10 characters):");
    if (!statement) return;
    try { await api("/appeals", { method: "POST", body: { action_id: d.id, statement } }); setMsg("Appeal sent. A different moderator will review it."); void decisions.reload(); } catch (e) { setMsg(errorMessage(e)); }
  };
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Settings &amp; privacy</h1>
      {msg ? <p className="notice" role="status">{msg}</p> : null}
      {u.status === "restricted" ? <div className="notice warn"><strong>Your account is temporarily restricted</strong>You can listen, but not post, until {formatDate(u.restricted_until)}.</div> : null}
      <div className="two-col">
        <div className="stack">
          <section className="panel">
            <h2>Profile</h2>
            <p className="small dim">Signed in as @{u.username} ({u.email}). Role: {u.role}.</p>
            <form className="row" style={{ alignItems: "flex-end" }} onSubmit={(e) => { e.preventDefault(); const v = new FormData(e.currentTarget).get("dn"); void patch({ display_name: v }, "Display name saved."); }}>
              <div style={{ flex: 1 }}><label htmlFor="dn">Display name</label><input id="dn" name="dn" defaultValue={u.display_name} /></div>
              <button type="submit">Save</button>
            </form>
          </section>
          <section className="panel">
            <h2>Listening privacy</h2>
            <p className="small muted">Your listening activity is <strong>never public</strong>. Artists only receive aggregated totals with no listener identities.</p>
            <label className="check"><input type="checkbox" checked={u.history_enabled} onChange={(e) => void patch({ history_enabled: e.target.checked }, e.target.checked ? "History on." : "History off — existing history deleted.")} /> Keep a private listening history (turning this off deletes it)</label>
            <label className="check"><input type="checkbox" checked={u.personalisation_enabled} onChange={(e) => void patch({ personalisation_enabled: e.target.checked }, "Saved.")} /> Offer a personal “For you” feed based only on artists I follow and interests I choose</label>
            <div className="field" style={{ marginTop: 12 }}>
              <label htmlFor="ints">My interests (genres)</label>
              <div className="row"><input id="ints" value={interests ?? u.interests.join(", ")} onChange={(e) => setInterests(e.target.value)} placeholder="ambient, electronic" style={{ flex: 1 }} />
                <button onClick={() => void patch({ interests: (interests ?? "").split(",").map((x) => x.trim()).filter(Boolean) }, "Interests saved.")}>Save</button></div>
              <p className="hint">The default Discover feed is the same for everyone regardless of these settings.</p>
            </div>
          </section>
          <section className="panel" id="moderation">
            <h2>Moderation decisions</h2>
            <p className="small muted">Decisions affecting you or artists you manage. You can appeal each decision once.</p>
            {decisions.data?.length ? (
              <ul className="stack" style={{ listStyle: "none", padding: 0 }}>
                {decisions.data.map((d) => (
                  <li key={d.id} className="card">
                    <div className="row small"><strong>{d.action.replace(/_/g, " ")}</strong><span className="dim">{d.target_type} · {formatDate(d.created_at)}</span>{d.expires_at ? <span className="badge">until {formatDate(d.expires_at)}</span> : null}</div>
                    <p className="small" style={{ margin: "6px 0" }}>{d.reason}</p>
                    {d.appeal ? <span className="badge badge-gold">Appeal {d.appeal.status}{d.appeal.decision_note ? `: ${d.appeal.decision_note}` : ""}</span> : <button className="btn-sm" onClick={() => void appeal(d)}>Appeal</button>}
                  </li>
                ))}
              </ul>
            ) : <p className="dim small">No decisions.</p>}
          </section>
        </div>
        <aside className="stack">
          <section className="panel">
            <h2>Blocked accounts</h2>
            <p className="small dim">You won&apos;t see their comments, and they can&apos;t comment on artists you manage.</p>
            <form className="row" onSubmit={(e) => { e.preventDefault(); void api("/me/blocks", { method: "POST", body: { username: blockName } }).then(() => { setBlockName(""); void blocks.reload(); }).catch((x) => setMsg(errorMessage(x))); }}>
              <label htmlFor="bl" className="sr-only">Username to block</label>
              <input id="bl" value={blockName} onChange={(e) => setBlockName(e.target.value)} placeholder="username" style={{ flex: 1 }} required />
              <button type="submit">Block</button>
            </form>
            <ul style={{ listStyle: "none", padding: 0 }}>{blocks.data?.map((b) => <li key={b.username} className="row">@{b.username}<span className="spacer" /><button className="btn-sm btn-ghost" onClick={() => void api(`/me/blocks/${b.username}`, { method: "DELETE" }).then(() => blocks.reload())}>Unblock</button></li>)}</ul>
          </section>
          <section className="panel">
            <h2>Your data</h2>
            <p className="small muted">Download everything we hold about your account as JSON: playlists, follows, saves, comments and listening history.</p>
            <a className="btn" href="/api/v1/me/export">Download my data</a>
          </section>
        </aside>
      </div>
    </>
  );
}
