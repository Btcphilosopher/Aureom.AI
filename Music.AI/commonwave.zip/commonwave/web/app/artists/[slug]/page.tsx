"use client";

import Link from "next/link";
import { use, useState } from "react";
import { Artwork } from "@/components/Artwork";
import { VerifiedBadge } from "@/components/Badges";
import { Empty, ReleaseCard, Section } from "@/components/Cards";
import { Icon } from "@/components/Icon";
import { ReportButton } from "@/components/ReportButton";
import { TrackList } from "@/components/TrackList";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { usePlayer } from "@/lib/player/PlayerProvider";
import type { ArtistBrief, ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

interface Artist extends ArtistBrief {
  bio: string | null; location: string | null; links: { label: string; url: string }[]; support_url: string | null; tips_enabled: boolean;
  banner_url: string | null; avatar_large_url: string | null; verification: { status: string; method: string | null }; status: string;
  follower_count: number; viewer: { following: boolean; role: string | null }; pinned_release: ReleaseBrief | null;
  releases: ReleaseBrief[]; tracks: Track[]; credits: { name: string; roles: string[] }[];
}

export default function ArtistPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const { data: a, error, setData } = useApi<Artist>(`/artists/${encodeURIComponent(slug)}`);
  const { me } = useAuth();
  const player = usePlayer();
  const [msg, setMsg] = useState<string | null>(null);

  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Artist not found</h1><p className="muted">{error.message}</p></div>;
  if (!a) return <p role="status" className="muted">Loading…</p>;

  const follow = async () => {
    if (!me?.user) return setMsg("Sign in to follow artists.");
    try {
      const r = await api<{ following: boolean; follower_count: number }>(`/artists/${a.id}/follow`, { method: a.viewer.following ? "DELETE" : "POST" });
      setData({ ...a, follower_count: r.follower_count, viewer: { ...a.viewer, following: r.following } });
    } catch (e) {
      setMsg(errorMessage(e));
    }
  };
  const playable = a.tracks.filter((t) => t.available);

  return (
    <>
      <div className="banner">{a.banner_url ? <Artwork src={a.banner_url} alt="" /> : null}</div>
      <div className="artist-head">
        <div className="avatar"><Artwork src={a.avatar_large_url} alt={`${a.name}`} /></div>
        <div style={{ minWidth: 0 }}>
          <div className="kicker" style={{ color: "var(--turquoise)", fontWeight: 800, letterSpacing: ".14em", fontSize: ".78rem", textTransform: "uppercase" }}>
            {a.kind === "band" ? "Band" : a.kind === "collective" ? "Collective" : "Artist"}{a.location ? ` · ${a.location}` : ""}
          </div>
          <h1 style={{ margin: "4px 0 8px" }}>{a.name}</h1>
          <div className="row">
            <VerifiedBadge verified={a.verification.status === "verified"} />
            <span className="muted small">{a.follower_count} {a.follower_count === 1 ? "follower" : "followers"}</span>
          </div>
        </div>
      </div>
      <div className="row" style={{ marginBottom: 20 }}>
        <button className="play-btn" disabled={!playable.length} onClick={() => player.playList(playable, 0, "artist")} aria-label={`Play ${a.name}`}><Icon name="play" /></button>
        <button className={a.viewer.following ? "btn-teal" : ""} aria-pressed={a.viewer.following} onClick={() => void follow()}>
          {a.viewer.following ? <><Icon name="check" size={16} /> Following</> : <><Icon name="plus" size={16} /> Follow</>}
        </button>
        {a.support_url ? <a className="btn" href={a.support_url} target="_blank" rel="noopener noreferrer nofollow">Support the artist <Icon name="external" size={14} /></a> : null}
        {a.tips_enabled ? <Link className="btn" href={`/support/checkout/new?artist=${a.id}`}>Send a tip (simulated)</Link> : null}
        {a.viewer.role ? <Link className="btn btn-sm" href={`/studio/${a.id}`}>Manage ({a.viewer.role})</Link> : null}
        <ReportButton targetType="artist" targetId={a.id} />
      </div>
      {msg ? <p role="status" className="notice">{msg}</p> : null}
      {a.status === "suspended" ? <div className="notice warn">This profile is suspended and hidden from the public.</div> : null}

      <div className="two-col">
        <div>
          {a.pinned_release ? (
            <Section title="Pinned">
              <div className="cards" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))" }}><ReleaseCard r={a.pinned_release} /></div>
            </Section>
          ) : null}
          <Section title="Tracks">
            <TrackList tracks={a.tracks} source="artist" showArtist={false} emptyText="No published tracks yet." />
          </Section>
          <Section title="Albums & EPs">
            {a.releases.length ? <div className="cards">{a.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div> : <Empty>No releases yet.</Empty>}
          </Section>
        </div>
        <aside>
          <Section title="About">
            {a.bio ? <p className="bio">{a.bio}</p> : <p className="dim">No biography yet.</p>}
            {a.verification.status === "verified" ? <p className="small dim">Verified by this server: {a.verification.method}</p> : <p className="small dim">Identity not verified by this server.</p>}
          </Section>
          {a.links.length ? (
            <Section title="Links">
              <ul style={{ listStyle: "none", padding: 0 }}>
                {a.links.map((l) => <li key={l.url}><a href={l.url} target="_blank" rel="noopener noreferrer nofollow">{l.label} <Icon name="external" size={12} /></a></li>)}
              </ul>
            </Section>
          ) : null}
          {a.credits.length ? (
            <Section title="Credits">
              <ul style={{ listStyle: "none", padding: 0 }} className="small">
                {a.credits.map((c) => <li key={c.name}><strong>{c.name}</strong> <span className="dim">{c.roles.join(", ")}</span></li>)}
              </ul>
            </Section>
          ) : null}
        </aside>
      </div>
    </>
  );
}
