"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, use, useState } from "react";
import { SignInPrompt } from "@/components/SignInPrompt";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatMoney } from "@/lib/format";
import { useApi } from "@/lib/useApi";

interface Intent { id: string; status: string; amount_minor: number; currency: string; platform_fee_minor: number; provider_fee_minor: number; artist_receives_minor: number; kind: string; release_id: string | null; checkout_url: string | null }

function Checkout({ id }: { id: string }) {
  const sp = useSearchParams();
  const { me, loading } = useAuth();
  const releaseId = sp.get("release");
  const artistId = sp.get("artist");
  const release = useApi<{ title: string; pwyw: { min_minor: number; currency: string } | null; artist: { name: string } }>(releaseId ? `/releases/${releaseId}` : null);
  const cfg = useApi<{ enabled: boolean; platform_fee_bps: number; provider_fee_bps: number; provider_fixed_fee_minor: number }>("/support/config");
  const [intent, setIntent] = useState<Intent | null>(null);
  const [amount, setAmount] = useState<number>(5);
  const [err, setErr] = useState<string | null>(null);
  if (!loading && !me?.user) return <SignInPrompt what="support artists" />;
  const currency = release.data?.pwyw?.currency ?? "USD";
  const min = (release.data?.pwyw?.min_minor ?? (releaseId ? 0 : 100)) / 100;
  const create = async () => {
    try {
      const key = `${id}-${releaseId ?? artistId}-${Math.round(amount * 100)}-${Date.now()}`;
      const body = releaseId ? { kind: "pwyw_download", release_id: releaseId, amount_minor: Math.round(amount * 100), currency, idempotency_key: key }
        : { kind: "tip", artist_id: artistId, amount_minor: Math.round(amount * 100), currency, idempotency_key: key };
      setIntent(await api<Intent>("/support/intents", { method: "POST", body }));
    } catch (e) { setErr(errorMessage(e)); }
  };
  const complete = async (outcome: "paid" | "failed") => {
    try {
      const r = await api<{ status: string; intent: Intent }>(`/support/simulated/${intent!.id}/complete?outcome=${outcome}`, { method: "POST" });
      setIntent({ ...intent!, status: r.status });
    } catch (e) { setErr(errorMessage(e)); }
  };
  return (
    <div className="panel" style={{ maxWidth: 560, margin: "30px auto" }}>
      <div className="notice warn"><strong>Simulated payment</strong>This is a demonstration. No card details are collected and no money moves.</div>
      <h1 style={{ marginTop: 16 }}>{releaseId ? `Pay what you want: ${release.data?.title ?? ""}` : "Send a tip"}</h1>
      {!intent ? (
        <>
          <div className="field"><label htmlFor="amt">Amount ({currency})</label><input id="amt" type="number" min={min} step={0.5} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
            <p className="hint">{releaseId ? (min > 0 ? `The artist's minimum is ${formatMoney(min * 100, currency)}.` : "Any amount, including zero.") : "Minimum 1.00."}</p></div>
          {cfg.data ? <p className="small dim">Fees are shown before you pay: platform {cfg.data.platform_fee_bps / 100}% · simulated provider {cfg.data.provider_fee_bps / 100}% + {formatMoney(cfg.data.provider_fixed_fee_minor, currency)}.</p> : null}
          <button className="btn-primary" onClick={() => void create()}>Continue</button>
        </>
      ) : (
        <>
          <table><tbody>
            <tr><th scope="row">You pay</th><td>{formatMoney(intent.amount_minor, intent.currency)}</td></tr>
            <tr><th scope="row">Platform fee</th><td>{formatMoney(intent.platform_fee_minor, intent.currency)}</td></tr>
            <tr><th scope="row">Payment provider fee (simulated)</th><td>{formatMoney(intent.provider_fee_minor, intent.currency)}</td></tr>
            <tr><th scope="row">Artist receives</th><td><strong>{formatMoney(intent.artist_receives_minor, intent.currency)}</strong></td></tr>
            <tr><th scope="row">Status</th><td>{intent.status}</td></tr>
          </tbody></table>
          {intent.status === "pending" ? (
            <div className="row" style={{ marginTop: 16 }}><button className="btn-primary" onClick={() => void complete("paid")}>Simulate successful payment</button><button onClick={() => void complete("failed")}>Simulate failure</button></div>
          ) : intent.status === "settled" ? (
            <p className="notice" role="status" style={{ marginTop: 16 }}>Thank you! {releaseId ? <>You can now <Link href={`/releases/${releaseId}`}>download the release</Link>.</> : "The tip has been recorded for the artist."}</p>
          ) : <p className="notice error" role="status" style={{ marginTop: 16 }}>The payment did not go through. Nothing was charged.</p>}
        </>
      )}
      {err ? <p className="notice error" role="alert">{err}</p> : null}
    </div>
  );
}

export default function CheckoutPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return <Suspense fallback={<p className="muted">Loading…</p>}><Checkout id={id} /></Suspense>;
}
