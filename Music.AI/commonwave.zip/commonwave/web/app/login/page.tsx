"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function Login() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="panel" style={{ maxWidth: 460, margin: "40px auto" }}>
      <h1>Sign in</h1>
      <form onSubmit={async (e) => { e.preventDefault(); try { await login(email, password); router.push("/"); } catch (x) { setErr(errorMessage(x)); } }}>
        <div className="field"><label htmlFor="em">Email</label><input id="em" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="field"><label htmlFor="pw">Password</label><input id="pw" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        {err ? <p className="notice error" role="alert">{err}</p> : null}
        <button className="btn-primary" type="submit">Sign in</button>
      </form>
      <p className="muted small" style={{ marginTop: 16 }}>New here? <Link href="/register">Create a free account</Link>. Demo accounts use the password <code>commonwave-demo</code> (e.g. listener@example.com, marigold@example.com, opsadmin@example.com).</p>
    </div>
  );
}
