"use client";

import Link from "next/link";
import { use, useState } from "react";
import { Artwork } from "@/components/Artwork";
import { LicenceBadge } from "@/components/Badges";
import { Icon } from "@/components/Icon";
import { ReportButton } from "@/components/ReportButton";
import { TrackList } from "@/components/TrackList";
import { api, ApiError, errorMessage, getCsrf } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatBytes, formatDate, formatMoney, formatTime, kindLabel } from "@/lib/format";
import { usePlayer } from "@/lib/player/PlayerProvider";
import type { ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

interface Release extends ReleaseBrief {
  description: string | null; credits: { name: string; role: string }[]; tracks: Track[]; total_duration_ms: number;
  viewer: { can_manage: boolean; saved: boolean }; archive_available: boolean;
}

export default function ReleasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data: r, error, setData } = useApi<Release>(`/releases/${id}`);
  const player = usePlayer();
  const { me } = useAuth();
  const [archive, setArchive] = useState<string | null>(null);

  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Release not found</h1><p className="muted">It may be private, withdrawn or removed.</p></div>;
  if (!r) return <p role="status" className="muted">Loading…</p>;
  const playable = r.tracks.filter((t) => t.available);
  const licences = Array.from(new Map(r.tracks.filter((t) => t.licence).map((t) => [t.licence!.code, t.licence!])).values());

  const save = async () => {
    try {
      if (r.viewer.saved) await api(`/saves/release/${r.id}`, { method: "DELETE" });
      else await api("/saves", { method: "POST", body: { target_type: "release", target_id: r.id } });
      setData({ ...r, viewer: { ...r.viewer, saved: !r.viewer.saved } });
    } catch (e) {
      setArchive(errorMessage(e));
    }
  };

  const requestArchive = async () => {
    setArchive("Preparing the archive…");
    const poll = async (): Promise<void> => {
      try {
        const res = await fetch(`/api/v1/releases/${r.id}/archive`, { method: "POST", headers: { "X-CSRF-Token": getCsrf() ?? "" } });
        const j = await res.json();
        if (res.status === 200 && j.url) {
          setArchive(`Archive ready (${formatBytes(j.size_bytes)}). Downloading…`);
          window.location.assign(j.url);
          return;
        }
        if (res.status === 202) {
          setArchive("Building the release archive in the background…");
          await new Promise((ok) => setTimeout(ok, 2000));
          return poll();
        }
        if (res.status === 402) {
          setArchive(null);
          window.location.assign(`/support/checkout/new?release=${r.id}`);
          return;
        }
        setArchive(j?.error?.message ?? "Download not available.");
      } catch (e) {
        setArchive(e instanceof ApiError ? e.message : "Download failed.");
      }
    };
    await poll();
  };

  return (
    <>
      <div className="hero">
        <div className="art"><Artwork src={r.artwork_url} alt={`Cover of ${r.title}`} /></div>
        <div>
          <div className="kicker">{kindLabel(r.kind)}</div>
          <h1>{r.title}</h1>
          <div className="facts">
            <Link href={`/artists/${r.artist.slug}`} style={{ fontWeight: 700, color: "var(--text)" }}>{r.artist.name}</Link>
            {r.release_date ? <span>{formatDate(r.release_date)}</span> : null}
            <span>{r.tracks.length} {r.tracks.length === 1 ? "track" : "tracks"}, {formatTime(r.total_duration_ms)}</span>
            {r.genre ? <Link href={`/genres/${encodeURIComponent(r.genre)}`}>{r.genre}</Link> : null}
            {licences.map((l) => <LicenceBadge key={l.code} licence={l} />)}
          </div>
          <div className="row">
            <button className="play-btn" disabled={!playable.length} onClick={() => player.playList(playable, 0, "release")} aria-label={`Play ${r.title}`}><Icon name="play" /></button>
            {me?.user ? <button aria-pressed={r.viewer.saved} onClick={() => void save()}><Icon name={r.viewer.saved ? "heartFilled" : "heart"} size={16} /> {r.viewer.saved ? "Saved" : "Save"}</button> : null}
            {r.archive_available ? (
              <button onClick={() => void requestArchive()}>
                <Icon name="download" size={16} /> Download release (MP3 .zip){r.pwyw ? ` — pay what you want, from ${formatMoney(r.pwyw.min_minor, r.pwyw.currency)}` : ""}
              </button>
            ) : null}
            {r.viewer.can_manage ? <Link className="btn btn-sm" href={`/studio/release/${r.id}`}>Edit release</Link> : null}
            <ReportButton targetType="release" targetId={r.id} />
          </div>
          {archive ? <p role="status" className="notice" style={{ marginTop: 12 }}>{archive}</p> : null}
        </div>
      </div>
      {r.status !== "published" ? <div className="notice warn">This release is a {r.status} and only visible to its artist.</div> : null}
      <TrackList tracks={r.tracks} source="release" numbered showArtist={false} />
      <div className="two-col" style={{ marginTop: 30 }}>
        <div>{r.description ? <p className="bio">{r.description}</p> : null}</div>
        <div className="card small">
          <h3>Rights</h3>
          {licences.length ? licences.map((l) => (
            <p key={l.code}><strong>{l.name}</strong><br />{l.attribution ? <>Attribution: {l.attribution}<br /></> : null}{l.url ? <a href={l.url} target="_blank" rel="noopener noreferrer">Licence text</a> : null}</p>
          )) : <p className="dim">No licence information.</p>}
          <p className="dim">Licences are declared by the uploader; COMMONWAVE does not independently verify ownership. Artwork may be licensed separately.</p>
        </div>
      </div>
    </>
  );
}
