"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function Register() {
  const { register } = useAuth();
  const router = useRouter();
  const [f, setF] = useState({ email: "", username: "", password: "", display_name: "" });
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="panel" style={{ maxWidth: 520, margin: "40px auto" }}>
      <h1>Join COMMONWAVE</h1>
      <p className="muted">Free for listeners and artists. No subscription, no token.</p>
      <form onSubmit={async (e) => { e.preventDefault(); try { await register(f); router.push("/"); } catch (x) { setErr(errorMessage(x)); } }}>
        <div className="field"><label htmlFor="r-em">Email</label><input id="r-em" type="email" autoComplete="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div className="field"><label htmlFor="r-un">Username</label><input id="r-un" autoComplete="username" required pattern="[A-Za-z0-9_]{3,32}" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} /><p className="hint">3–32 letters, numbers or underscores.</p></div>
        <div className="field"><label htmlFor="r-dn">Display name</label><input id="r-dn" value={f.display_name} onChange={(e) => setF({ ...f, display_name: e.target.value })} /></div>
        <div className="field"><label htmlFor="r-pw">Password</label><input id="r-pw" type="password" autoComplete="new-password" minLength={10} required value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /><p className="hint">At least 10 characters.</p></div>
        {err ? <p className="notice error" role="alert">{err}</p> : null}
        <button className="btn-primary" type="submit">Create account</button>
      </form>
    </div>
  );
}
