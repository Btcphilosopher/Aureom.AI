"use client";

import Link from "next/link";
import { use, useState } from "react";
import { Artwork } from "@/components/Artwork";
import { ExplicitBadge, LicenceBadge } from "@/components/Badges";
import { Icon } from "@/components/Icon";
import { ReportButton } from "@/components/ReportButton";
import { Waveform } from "@/components/Waveform";
import { AddToPlaylist } from "@/components/AddToPlaylist";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatBytes, formatDate, formatTime } from "@/lib/format";
import { usePlayer, usePosition } from "@/lib/player/PlayerProvider";
import type { Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

interface Detail extends Track { viewer: { can_manage: boolean; saved: boolean }; version: { id: string; number: number } | null }
interface Comment { id: string; body: string; timestamp_ms: number | null; created_at: string; status: string; author: { username: string; display_name: string }; is_mine: boolean; can_hide: boolean }
interface DownloadOpt { format: string; label: string; size_bytes: number; file_format?: string }

export default function TrackPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data: t, error, setData } = useApi<Detail>(`/tracks/${id}`);
  const comments = useApi<{ enabled: boolean; timestamped: boolean; comments: Comment[] }>(`/tracks/${id}/comments`);
  const downloads = useApi<{ options: DownloadOpt[]; notice: string | null }>(`/tracks/${id}/downloads`);
  const player = usePlayer();
  const { position, buffered } = usePosition();
  const { me } = useAuth();
  const [body, setBody] = useState("");
  const [atTime, setAtTime] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);

  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Track not available</h1><p className="muted">It may be a private draft, withdrawn by the artist, or restricted by moderators.</p></div>;
  if (!t) return <p role="status" className="muted">Loading…</p>;

  const isCurrent = player.current?.id === t.id;
  const playing = isCurrent && player.status === "playing";
  const dur = t.duration_ms ?? 0;

  const post = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const c = await api<Comment & { notice: string | null }>(`/tracks/${t.id}/comments`, { method: "POST", body: { body, timestamp_ms: atTime && isCurrent ? Math.round(position) : null } });
      setBody("");
      setMsg(c.notice ?? "Comment posted.");
      void comments.reload();
    } catch (err) {
      setMsg(errorMessage(err));
    }
  };
  const download = async (format: string) => {
    try {
      const d = await api<{ url: string }>(`/tracks/${t.id}/download`, { method: "POST", body: { format } });
      window.location.assign(d.url);
    } catch (err) {
      setMsg(errorMessage(err));
    }
  };
  const save = async () => {
    try {
      if (t.viewer.saved) await api(`/saves/track/${t.id}`, { method: "DELETE" });
      else await api("/saves", { method: "POST", body: { target_type: "track", target_id: t.id } });
      setData({ ...t, viewer: { ...t.viewer, saved: !t.viewer.saved } });
    } catch (err) {
      setMsg(errorMessage(err));
    }
  };
  const hide = async (c: Comment) => {
    await api(`/comments/${c.id}`, { method: "DELETE" }).catch(() => undefined);
    void comments.reload();
  };

  return (
    <>
      <div className="hero">
        <div className="art"><Artwork src={t.artwork_url} alt={t.release ? `Cover of ${t.release.title}` : `Artwork for ${t.title}`} /></div>
        <div style={{ minWidth: 0 }}>
          <div className="kicker">Track</div>
          <h1>{t.title} <ExplicitBadge explicit={t.explicit} /></h1>
          <div className="facts">
            <Link href={`/artists/${t.artist.slug}`} style={{ fontWeight: 700, color: "var(--text)" }}>{t.artist.name}</Link>
            {t.release ? <Link href={`/releases/${t.release.id}`}>{t.release.title}</Link> : null}
            <span>{formatTime(dur)}</span>
            {t.genre ? <Link href={`/genres/${encodeURIComponent(t.genre)}`}>{t.genre}</Link> : null}
            {t.published_at ? <span>Published {formatDate(t.published_at)}</span> : null}
            <LicenceBadge licence={t.licence} />
          </div>
          <div className="row" style={{ marginBottom: 16 }}>
            <button className="play-btn" onClick={() => (isCurrent ? player.toggle() : player.playTrack(t, "track_page"))} aria-label={playing ? `Pause ${t.title}` : `Play ${t.title}`} disabled={!t.available}>
              <Icon name={playing ? "pause" : "play"} />
            </button>
            {me?.user ? <button aria-pressed={t.viewer.saved} onClick={() => void save()}><Icon name={t.viewer.saved ? "heartFilled" : "heart"} size={16} /> {t.viewer.saved ? "Saved" : "Save"}</button> : null}
            {me?.user ? (
              <span style={{ position: "relative" }}>
                <button aria-expanded={menu} onClick={() => setMenu((m) => !m)}><Icon name="plus" size={16} /> Add to playlist</button>
                {menu ? <div className="card" style={{ position: "absolute", zIndex: 30, marginTop: 6, minWidth: 240, padding: 8 }}><AddToPlaylist trackId={t.id} onDone={(m) => { setMsg(m); setMenu(false); }} /></div> : null}
              </span>
            ) : null}
            <button onClick={() => player.enqueue(t)}>Add to queue</button>
            {t.viewer.can_manage ? <Link className="btn btn-sm" href={`/studio/track/${t.id}`}>Manage</Link> : null}
            <ReportButton targetType="track" targetId={t.id} />
          </div>
          <Waveform
            peaks={t.waveform}
            durationMs={dur}
            positionMs={isCurrent ? position : 0}
            bufferedMs={isCurrent ? buffered : 0}
            onSeek={isCurrent ? player.seek : (ms) => { player.playTrack(t, "track_page"); setTimeout(() => player.seek(ms), 400); }}
            label={`Waveform for ${t.title}. Use arrow keys to seek.`}
            markers={(comments.data?.comments ?? []).filter((c) => c.timestamp_ms != null).map((c) => ({ ms: c.timestamp_ms!, label: `${c.author.display_name}: ${c.body.slice(0, 60)}` }))}
          />
          {msg ? <p role="status" className="notice" style={{ marginTop: 10 }}>{msg}</p> : null}
        </div>
      </div>

      <div className="two-col">
        <div>
          {t.description ? <section className="section"><h2>About this track</h2><p className="bio">{t.description}</p></section> : null}
          {t.lyrics ? <section className="section"><h2>Lyrics</h2><p className="bio">{t.lyrics}</p></section> : null}
          <section className="section" aria-labelledby="comments-h">
            <h2 id="comments-h">Comments</h2>
            {comments.data && !comments.data.enabled ? <p className="dim">Comments are turned off on this server.</p> : null}
            {comments.data?.enabled ? (
              me?.user ? (
                <form onSubmit={post} className="card" style={{ marginBottom: 16 }}>
                  <label htmlFor="cbody">Add a comment</label>
                  <textarea id="cbody" value={body} onChange={(e) => setBody(e.target.value)} maxLength={2000} required />
                  <div className="row" style={{ marginTop: 10 }}>
                    {comments.data.timestamped ? (
                      <label className="check" style={{ margin: 0 }}>
                        <input type="checkbox" checked={atTime} disabled={!isCurrent} onChange={(e) => setAtTime(e.target.checked)} />
                        At {isCurrent ? formatTime(position) : "the current time (start playback first)"}
                      </label>
                    ) : null}
                    <span className="spacer" />
                    <button type="submit" className="btn-primary">Post</button>
                  </div>
                  <p className="dim small" style={{ margin: "8px 0 0" }}>Be kind. Comments with links may wait for review.</p>
                </form>
              ) : <p className="muted"><Link href="/login">Sign in</Link> to comment.</p>
            ) : null}
            <ul style={{ listStyle: "none", padding: 0 }} className="stack">
              {comments.data?.comments.map((c) => (
                <li key={c.id} className="card" style={{ padding: 14 }}>
                  <div className="row small" style={{ gap: 8 }}>
                    <strong>{c.author.display_name}</strong><span className="dim">@{c.author.username}</span>
                    {c.timestamp_ms != null ? <button className="btn-sm btn-ghost" onClick={() => (isCurrent ? player.seek(c.timestamp_ms!) : undefined)} aria-label={`Jump to ${formatTime(c.timestamp_ms)}`}>at {formatTime(c.timestamp_ms)}</button> : null}
                    {c.status === "held" ? <span className="badge badge-gold">Awaiting review</span> : null}
                    <span className="spacer" />
                    <span className="dim">{formatDate(c.created_at)}</span>
                    {c.is_mine || c.can_hide ? <button className="btn-sm btn-ghost" onClick={() => void hide(c)}>{c.is_mine ? "Delete" : "Hide"}</button> : null}
                    {!c.is_mine ? <ReportButton targetType="comment" targetId={c.id} compact /> : null}
                  </div>
                  <p style={{ margin: "6px 0 0", whiteSpace: "pre-wrap" }}>{c.body}</p>
                </li>
              ))}
            </ul>
            {comments.data?.enabled && !comments.data.comments.length ? <p className="dim">No comments yet.</p> : null}
          </section>
        </div>
        <aside>
          <section className="card section">
            <h3>Downloads</h3>
            {downloads.data?.options.length ? (
              <>
                <ul style={{ listStyle: "none", padding: 0 }} className="stack">
                  {downloads.data.options.map((o) => (
                    <li key={o.format}><button onClick={() => void download(o.format)} style={{ width: "100%", justifyContent: "space-between" }}>
                      <span><Icon name="download" size={16} /> {o.label}</span><span className="dim">≈ {formatBytes(o.size_bytes)}</span>
                    </button></li>
                  ))}
                </ul>
                {downloads.data.notice ? <p className="small muted" style={{ marginTop: 10 }}>{downloads.data.notice}</p> : null}
              </>
            ) : <p className="dim small">The artist hasn&apos;t enabled downloads for this track. Streaming is always free.</p>}
          </section>
          <section className="card section small">
            <h3>Rights</h3>
            {t.licence ? (
              <>
                <p><strong>{t.licence.name}</strong></p>
                {t.licence.attribution ? <p>Attribution: {t.licence.attribution}</p> : null}
                {t.licence.url ? <p><a href={t.licence.url} target="_blank" rel="noopener noreferrer">Read the licence</a></p> : null}
                <p className="dim">Declared by the uploader on {formatDate(t.licence.declared_at)}. Not independently verified.</p>
              </>
            ) : <p className="dim">No rights declaration.</p>}
          </section>
          {t.credits?.length ? (
            <section className="card section small">
              <h3>Credits</h3>
              <ul style={{ listStyle: "none", padding: 0 }}>{t.credits.map((c, i) => <li key={i}><strong>{c.name}</strong> <span className="dim">{c.role}</span></li>)}</ul>
            </section>
          ) : null}
        </aside>
      </div>
    </>
  );
}
