"use client";

import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { ArtistCard, Empty, ReleaseCard, Section } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import type { ArtistBrief, ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

function Results() {
  const q = useSearchParams().get("q") ?? "";
  const { data, loading } = useApi<{ tracks: Track[]; artists: ArtistBrief[]; releases: ReleaseBrief[] }>(q ? `/search?q=${encodeURIComponent(q)}` : null, [q]);
  if (!q) return <Empty>Type in the search box to find tracks, artists and releases.</Empty>;
  if (loading && !data) return <p role="status" className="muted">Searching…</p>;
  if (!data) return null;
  const none = !data.tracks.length && !data.artists.length && !data.releases.length;
  return (
    <>
      <p role="status" className="muted">{none ? `No results for “${q}”.` : `Results for “${q}”`}</p>
      {data.artists.length ? <Section title="Artists"><div className="artists-row">{data.artists.map((a) => <ArtistCard key={a.id} a={a} />)}</div></Section> : null}
      {data.releases.length ? <Section title="Releases"><div className="cards">{data.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div></Section> : null}
      {data.tracks.length ? <Section title="Tracks"><TrackList tracks={data.tracks} source="search" /></Section> : null}
    </>
  );
}

export default function SearchPage() {
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Search</h1>
      <Suspense fallback={<p className="muted">Loading…</p>}><Results /></Suspense>
    </>
  );
}
