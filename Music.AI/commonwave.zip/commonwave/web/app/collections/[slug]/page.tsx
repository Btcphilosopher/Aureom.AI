"use client";

import { use } from "react";
import { ReleaseCard, Section } from "@/components/Cards";
import { TrackList } from "@/components/TrackList";
import type { ReleaseBrief, Track } from "@/lib/types";
import { useApi } from "@/lib/useApi";

export default function CollectionPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const { data, error } = useApi<{ title: string; description: string | null; curator_note: string | null; releases: ReleaseBrief[]; tracks: Track[] }>(`/collections/${slug}`);
  if (error) return <div className="panel" style={{ marginTop: 30 }}><h1>Collection not found</h1></div>;
  if (!data) return <p className="muted" role="status">Loading…</p>;
  return (
    <>
      <div className="kicker" style={{ marginTop: 24, color: "var(--turquoise)", fontWeight: 800, letterSpacing: ".14em", textTransform: "uppercase", fontSize: ".78rem" }}>Editorial collection</div>
      <h1>{data.title}</h1>
      {data.description ? <p className="muted">{data.description}</p> : null}
      {data.curator_note ? <p className="dim small">{data.curator_note}</p> : null}
      <Section title="Releases"><div className="cards">{data.releases.map((r) => <ReleaseCard key={r.id} r={r} />)}</div></Section>
      {data.tracks.length ? <Section title="Tracks"><TrackList tracks={data.tracks} source="collection" /></Section> : null}
    </>
  );
}
