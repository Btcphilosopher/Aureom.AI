import Link from "next/link";

export default function NotFound() {
  return (
    <div className="panel" style={{ marginTop: 40 }}>
      <h1>Not found</h1>
      <p className="muted">This page doesn&apos;t exist, or it&apos;s private, or the artist withdrew it.</p>
      <Link className="btn btn-primary" href="/">Back to Discover</Link>
    </div>
  );
}
