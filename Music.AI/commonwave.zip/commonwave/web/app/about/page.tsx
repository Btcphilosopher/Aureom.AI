import Link from "next/link";

export const metadata = { title: "About, rights & funding" };

export default function About() {
  return (
    <article style={{ maxWidth: "78ch", marginTop: 20 }}>
      <div className="kicker" style={{ color: "var(--turquoise)", fontWeight: 800, letterSpacing: ".14em", textTransform: "uppercase", fontSize: ".78rem" }}>About</div>
      <h1>An open music commons</h1>
      <p className="muted">COMMONWAVE is open-source software anyone can run. Listening needs no subscription; publishing is free on this demonstration server. The code is licensed under the GNU AGPL v3 or later. That licence covers the <em>software</em> — not the music, artwork or text people upload.</p>

      <h2 id="rights">Music rights are chosen by artists</h2>
      <p>Open-source software doesn&apos;t make the music on it open. Each track carries the licence its uploader declared:</p>
      <ul>
        <li><strong>All rights reserved</strong> — you can stream it here. A download, if offered, is for personal listening only.</li>
        <li><strong>Creative Commons</strong> (BY, BY-SA, BY-NC, BY-NC-SA, BY-ND, BY-NC-ND 4.0) — you may share (and sometimes adapt) the work under the licence terms, including credit to the artist.</li>
        <li><strong>CC0</strong> — the creator waived their rights as far as the law allows. <strong>Public Domain Mark</strong> — the recording is already free of known copyright (this varies by country).</li>
      </ul>
      <p>A recording and the song it performs are separate works with separate rights. Covers, remixes and tracks containing samples involve other people&apos;s rights, so uploaders are asked about each one separately.</p>
      <p className="notice"><strong>Declarations are not verification.</strong>COMMONWAVE records what the uploader declared and when, but it does not independently check ownership. Rights-holders can file a complaint from any track&apos;s Report button. Automated matching, if ever added, only helps human reviewers; it never decides on its own.</p>
      <p>Withdrawing a track stops streaming and new downloads here. It can&apos;t recall copies already downloaded, and it doesn&apos;t cancel permissions already granted under an open licence for copies obtained while that licence applied.</p>

      <h2 id="discovery">How Discover works</h2>
      <p>The default feed is the same for everyone and isn&apos;t personalised. Shelves: latest releases, editorial collections (chosen by people, not by plays), new tracks, <em>New voices</em> (artists whose first release was in the last 60 days), recently active artists and genres.</p>
      <p><strong>Popular this fortnight</strong> counts <em>distinct listeners</em> with a qualified listen in the last 14 days, plus distinct saves and downloads, with each listener&apos;s contribution halving every 7 days. A track needs at least 3 different listeners, and each artist can have at most 2 tracks on the list. Automated traffic and artists&apos; own listens are excluded. Lifetime play counts are never used, so a new artist can appear on equal terms.</p>
      <p>A personal <em>For you</em> shelf is opt-in. It uses only artists you follow and interests you choose. Listening history is private and you can turn it off.</p>

      <h2 id="analytics">What artists can see</h2>
      <p>Aggregated statistics only. Playback requests, starts, qualified listens (at least 30 seconds, or half of a shorter track, measured by the server and capped by real time), listening hours, completions, downloads, saves and follows. No artist ever sees which person listened. Counts are best-effort and not fraud-proof.</p>

      <h2 id="funding">Funding a real deployment</h2>
      <p>Storage, bandwidth, moderation and operations all cost money. This demonstration charges nothing. A real community deployment could combine the following:</p>
      <ul>
        <li>Grants, donations or membership from listeners who choose to support the commons (not required to listen).</li>
        <li>Fair-use storage quotas, with optional paid storage tiers for heavy uploaders.</li>
        <li>An explicit, published platform fee on optional tips and pay-what-you-want sales (configurable; 0% by default).</li>
        <li>Institutional hosting (libraries, universities, arts councils, cooperatives) and volunteer or paid moderation teams.</li>
        <li>Federating hosting costs across independent servers once a tested federation protocol exists. COMMONWAVE does not federate today.</li>
      </ul>
      <p>No platform token or cryptocurrency is required to take part.</p>
      <h2 id="source">Source code</h2>
      <p>COMMONWAVE is free software under the GNU Affero General Public License, version 3 or later. If you use this service over a network, you are entitled to its complete corresponding source code, including any changes the operator made. Operators publish the address of their source with the <code>NEXT_PUBLIC_SOURCE_URL</code> setting. {process.env.NEXT_PUBLIC_SOURCE_URL ? <a href={process.env.NEXT_PUBLIC_SOURCE_URL}>Get the source for this server.</a> : <>This server has not set a source address yet; ask its operators.</>}</p>
      <p>Licences for third-party software are listed in <code>THIRD_PARTY_LICENSES.md</code>. The demonstration music and artwork are original, generated by code, and dedicated to the public domain under CC0 1.0.</p>
      <p><Link href="/">Back to Discover</Link></p>
    </article>
  );
}
