"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { CreateArtist } from "@/components/CreateArtist";
import { SignInPrompt } from "@/components/SignInPrompt";
import { useAuth } from "@/lib/auth";
import { formatBytes } from "@/lib/format";
import { PausedError, ResumableUpload, type UploadProgress } from "@/lib/tus";

interface Item { key: string; file: File; up: ResumableUpload; progress: UploadProgress; trackId?: string; error?: string }

const ACCEPT = ".mp3,.wav,.flac,audio/mpeg,audio/wav,audio/x-wav,audio/flac";

export default function Upload() {
  const { me, loading } = useAuth();
  const [artistId, setArtistId] = useState<string>("");
  const [items, setItems] = useState<Item[]>([]);
  const [drag, setDrag] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const artists = (me?.artists ?? []).filter((a) => ["owner", "manager", "contributor"].includes(a.role));

  useEffect(() => {
    if (!artistId && artists.length) setArtistId(artists[0].id);
  }, [artists, artistId]);

  if (!loading && !me?.user) return <SignInPrompt what="publish your music — free" />;
  if (loading) return <p className="muted" role="status">Loading…</p>;

  const update = (key: string, patch: Partial<Item>) => setItems((xs) => xs.map((x) => (x.key === key ? { ...x, ...patch } : x)));

  const run = async (it: Item) => {
    try {
      const r = await it.up.start();
      update(it.key, { trackId: r.trackId, error: undefined });
    } catch (e) {
      if (!(e instanceof PausedError)) update(it.key, { error: e instanceof Error ? e.message : "Upload failed" });
    }
  };

  const add = (files: FileList | null) => {
    if (!files || !artistId) return;
    const next: Item[] = [];
    for (const file of Array.from(files)) {
      const key = `${file.name}-${file.size}-${file.lastModified}`;
      if (items.some((i) => i.key === key && !i.error)) continue;
      const item: Item = {
        key, file, progress: { uploaded: 0, total: file.size, state: "creating" },
        up: new ResumableUpload(file, { artistId, title: file.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "), onProgress: (p) => update(key, { progress: p }) }),
      };
      next.push(item);
    }
    setItems((xs) => [...xs.filter((x) => !next.some((n) => n.key === x.key)), ...next]);
    next.forEach((it) => void run(it));
  };

  return (
    <>
      <h1 style={{ marginTop: 20 }}>Upload</h1>
      <p className="muted" style={{ maxWidth: "70ch" }}>
        Publishing is free. Upload <strong>WAV or FLAC</strong> for the best results, or MP3. Files are checked by their contents, not their names.
        Your original stays private unless you choose to offer it as a download.
      </p>
      {!artists.length ? <CreateArtist onCreated={setArtistId} /> : (
        <>
          <div className="row" style={{ marginBottom: 16 }}>
            <div style={{ minWidth: 260 }}>
              <label htmlFor="artist">Uploading as</label>
              <select id="artist" value={artistId} onChange={(e) => setArtistId(e.target.value)}>
                {artists.map((a) => <option key={a.id} value={a.id}>{a.name} ({a.role})</option>)}
              </select>
            </div>
            <span className="spacer" />
            <Link className="btn btn-sm" href={`/studio/${artistId}`}>Open artist studio</Link>
          </div>
          <div
            className="panel" role="group" aria-label="Choose audio files"
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); add(e.dataTransfer.files); }}
            style={{ textAlign: "center", borderStyle: "dashed", borderColor: drag ? "var(--turquoise)" : undefined, padding: 40 }}
          >
            <p style={{ fontWeight: 700, fontSize: "1.1rem" }}>Drop MP3, WAV or FLAC files here</p>
            <input ref={input} id="files" type="file" accept={ACCEPT} multiple className="sr-only" onChange={(e) => { add(e.target.files); e.target.value = ""; }} />
            <button className="btn-primary" onClick={() => input.current?.click()}>Choose files</button>
            <p className="dim small" style={{ marginTop: 12 }}>Uploads resume automatically after a dropped connection. If you close the tab, choose the same file again to continue where it stopped.</p>
          </div>
          <div className="notice warn" style={{ marginTop: 16 }}>
            <strong>About quality</strong>
            Converting a low-quality file (for example a 128 kbps MP3) to a higher bitrate does not bring back detail that was lost. We stream your upload at up to 192 kbps MP3 and never raise the bitrate above an MP3 source.
          </div>
          {items.length ? (
            <ul className="stack" style={{ listStyle: "none", padding: 0, marginTop: 20 }} aria-live="polite">
              {items.map((it) => {
                const pct = it.progress.total ? Math.round((it.progress.uploaded / it.progress.total) * 100) : 0;
                const done = it.progress.state === "complete";
                return (
                  <li key={it.key} className="card">
                    <div className="row">
                      <strong style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis" }}>{it.file.name}</strong>
                      <span className="dim small">{formatBytes(it.file.size)}</span>
                    </div>
                    <div className="progressbar" role="progressbar" aria-label={`Upload progress for ${it.file.name}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} style={{ margin: "10px 0" }}>
                      <span style={{ width: `${pct}%` }} />
                    </div>
                    <div className="row small">
                      <span>{done ? "Uploaded — processing has started" : it.error ? <span style={{ color: "var(--danger)" }}>{it.error}</span> : `${it.progress.state} · ${pct}%`}</span>
                      {it.progress.message && !it.error ? <span className="dim">{it.progress.message}</span> : null}
                      <span className="spacer" />
                      {!done && !it.error && it.progress.state !== "paused" ? <button className="btn-sm" onClick={() => it.up.pause()}>Pause</button> : null}
                      {it.progress.state === "paused" || (it.error && it.up.location) ? <button className="btn-sm btn-teal" onClick={() => void run(it)}>Resume</button> : null}
                      {done && it.trackId ? <Link className="btn btn-sm btn-primary" href={`/studio/track/${it.trackId}`}>Add details & publish</Link> : null}
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : null}
        </>
      )}
    </>
  );
}
