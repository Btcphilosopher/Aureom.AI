import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AuthProvider } from "@/lib/auth";
import { PlayerProvider } from "@/lib/player/PlayerProvider";
import { Shell } from "@/components/Shell";

export const metadata: Metadata = {
  title: { default: "COMMONWAVE — Open music for everyone", template: "%s · COMMONWAVE" },
  description: "An open-source music commons: independent artists publish and share, anyone can listen without a subscription.",
};

export const viewport: Viewport = { themeColor: "#0b1026", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <PlayerProvider>
            <Shell>{children}</Shell>
          </PlayerProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
