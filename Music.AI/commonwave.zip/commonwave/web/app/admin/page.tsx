"use client";

import Link from "next/link";
import { useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatBytes, formatDate } from "@/lib/format";
import { useApi } from "@/lib/useApi";

const TABS = ["Reports", "Appeals", "Held comments", "Users", "Artists", "Jobs", "Configuration", "Collections", "Audit log"] as const;

interface Report { id: string; target_type: string; target_id: string; reason: string; details: string | null; rights_claim: Record<string, unknown> | null; priority: number; created_at: string; reporter: string | null; target: Record<string, unknown> }

const ACTIONS: Record<string, [string, string][]> = {
  comment: [["hide_comment", "Hide comment"], ["restore_comment", "Restore comment"]],
  track: [["restrict_track", "Restrict visibility (reversible)"], ["unrestrict_track", "Lift restriction"], ["withdraw_track", "Withdraw"], ["restore_track", "Restore"], ["delete_track_permanently", "Delete permanently (admin)"]],
  release: [["restrict_release", "Restrict visibility"], ["unrestrict_release", "Lift restriction"]],
  artist: [["restrict_artist", "Restrict artist"], ["suspend_artist", "Suspend artist"], ["reinstate_artist", "Reinstate artist"]],
  user: [["restrict_user", "Temporary restriction"], ["suspend_user", "Suspend account"], ["reinstate_user", "Reinstate"]],
  playlist: [["note", "Add note"]],
};

export default function Admin() {
  const { me } = useAuth();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Reports");
  const summary = useApi<Record<string, number>>(me?.user && me.user.role !== "user" ? "/mod/summary" : null, [me?.user?.id, tab]);
  if (!me?.user || me.user.role === "user") return <div className="panel" style={{ marginTop: 30 }}><h1>Staff only</h1><p className="muted">This area is for this server&apos;s moderators and administrators.</p></div>;
  const admin = me.user.role === "admin";
  return (
    <>
      <h1 style={{ marginTop: 20 }}>Moderation &amp; administration</h1>
      {summary.data ? (
        <div className="stats" style={{ marginBottom: 16 }}>
          <div className="card stat"><b>{summary.data.open_reports}</b><span>Open reports</span></div>
          <div className="card stat"><b>{summary.data.open_rights_complaints}</b><span>Rights complaints</span></div>
          <div className="card stat"><b>{summary.data.open_appeals}</b><span>Open appeals</span></div>
          <div className="card stat"><b>{summary.data.held_comments}</b><span>Comments awaiting review</span></div>
        </div>
      ) : null}
      <div className="tabs" role="tablist" aria-label="Admin sections">
        {TABS.filter((t) => admin || !["Configuration", "Audit log"].includes(t)).map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}>{t}</button>)}
      </div>
      <div role="tabpanel">
        {tab === "Reports" ? <Reports /> : null}
        {tab === "Appeals" ? <Appeals /> : null}
        {tab === "Held comments" ? <Held /> : null}
        {tab === "Users" ? <Users admin={admin} /> : null}
        {tab === "Artists" ? <Artists admin={admin} /> : null}
        {tab === "Jobs" ? <Jobs admin={admin} /> : null}
        {tab === "Configuration" ? <Config /> : null}
        {tab === "Collections" ? <Collections /> : null}
        {tab === "Audit log" ? <Audit /> : null}
      </div>
    </>
  );
}

function ActionForm({ targetType, targetId, reportId, onDone }: { targetType: string; targetId: string; reportId?: string; onDone: () => void }) {
  const opts = [...(ACTIONS[targetType] ?? []), ["dismiss_report", "Dismiss report (no action)"] as [string, string]].filter(([a]) => reportId || a !== "dismiss_report");
  const [action, setAction] = useState(opts[0][0]);
  const [reason, setReason] = useState("");
  const [policy, setPolicy] = useState("");
  const [until, setUntil] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <form className="stack" onSubmit={async (e) => {
      e.preventDefault();
      try {
        await api("/mod/actions", { method: "POST", body: { target_type: targetType, target_id: targetId, action, reason, policy_ref: policy || null, report_id: reportId ?? null, expires_at: until ? new Date(until).toISOString() : null } });
        onDone();
      } catch (x) { setMsg(errorMessage(x)); }
    }}>
      <div className="grid2">
        <div><label htmlFor={`a-${targetId}`}>Decision</label><select id={`a-${targetId}`} value={action} onChange={(e) => setAction(e.target.value)}>{opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
        <div><label htmlFor={`p-${targetId}`}>Policy reference</label><input id={`p-${targetId}`} value={policy} onChange={(e) => setPolicy(e.target.value)} placeholder="e.g. community-2.1" /></div>
      </div>
      {["restrict_user", "suspend_user"].includes(action) ? <div><label htmlFor={`u-${targetId}`}>Until {action === "suspend_user" ? "(optional)" : "(required)"}</label><input id={`u-${targetId}`} type="datetime-local" value={until} onChange={(e) => setUntil(e.target.value)} /></div> : null}
      <div><label htmlFor={`r-${targetId}`}>Reason (shown to the affected person)</label><textarea id={`r-${targetId}`} required minLength={3} value={reason} onChange={(e) => setReason(e.target.value)} /></div>
      {msg ? <p className="notice error" role="alert">{msg}</p> : null}
      <button className="btn-primary" type="submit">Record decision</button>
    </form>
  );
}

function Reports() {
  const [status, setStatus] = useState("open");
  const { data, reload } = useApi<Report[]>(`/mod/reports?status=${status}`, [status]);
  return (
    <>
      <div className="row" style={{ marginBottom: 12 }}><label htmlFor="rs" style={{ margin: 0 }}>Show</label><select id="rs" value={status} onChange={(e) => setStatus(e.target.value)} style={{ width: "auto" }}><option value="open">Open</option><option value="actioned">Actioned</option><option value="dismissed">Dismissed</option></select></div>
      <p className="small dim">Rights complaints appear first. A complaint is a claim, not proof: review the evidence and restrict visibility while it is resolved if needed. Restrictions are reversible; permanent deletion is separate and admin-only.</p>
      {data?.length ? data.map((r) => (
        <article key={r.id} className="card" style={{ marginBottom: 12 }}>
          <div className="row small"><span className={`badge ${r.reason === "rights" ? "badge-gold" : "badge-coral"}`}>{r.reason}</span><strong>{r.target_type}</strong><span className="dim">reported by @{r.reporter} · {formatDate(r.created_at)}</span>
            <span className="spacer" />{r.target_type === "track" ? <Link href={`/tracks/${r.target_id}`}>Open track</Link> : null}</div>
          <pre className="mono small" style={{ whiteSpace: "pre-wrap", background: "var(--ink-950)", padding: 10, borderRadius: 8 }}>{JSON.stringify(r.target, null, 2)}</pre>
          {r.details ? <p><strong>Details:</strong> {r.details}</p> : null}
          {r.rights_claim ? <div className="notice warn small"><strong>Rights claim</strong>{Object.entries(r.rights_claim).map(([k, v]) => <div key={k}>{k.replace(/_/g, " ")}: {String(v)}</div>)}</div> : null}
          {status === "open" ? <details style={{ marginTop: 10 }}><summary>Decide</summary><ActionForm targetType={r.target_type} targetId={r.target_id} reportId={r.id} onDone={() => void reload()} /></details> : null}
          <details><summary className="small">Decision history</summary><History type={r.target_type} id={r.target_id} /></details>
        </article>
      )) : <p className="dim">No {status} reports.</p>}
    </>
  );
}

function History({ type, id }: { type: string; id: string }) {
  const { data } = useApi<{ actions: { id: string; action: string; reason: string; moderator: string | null; created_at: string; reversed_by_action_id: string | null }[] }>(`/mod/history/${type}/${id}`);
  return <ul className="small">{data?.actions.map((a) => <li key={a.id}>{formatDate(a.created_at)} — <strong>{a.action}</strong> by @{a.moderator}: {a.reason}{a.reversed_by_action_id ? " (reversed)" : ""}</li>)}{data && !data.actions.length ? <li className="dim">No previous decisions.</li> : null}</ul>;
}

function Appeals() {
  const { data, reload } = useApi<{ id: string; statement: string; appellant: string; created_at: string; action: { action: string; reason: string; target_type: string; moderator: string } }[]>("/mod/appeals");
  const [msg, setMsg] = useState<string | null>(null);
  const decide = async (id: string, outcome: string) => {
    const note = window.prompt(`Note for the appellant (${outcome}):`);
    if (!note) return;
    try { await api(`/mod/appeals/${id}/decide`, { method: "POST", body: { outcome, note } }); void reload(); } catch (e) { setMsg(errorMessage(e)); }
  };
  return (
    <>
      {msg ? <p className="notice error" role="alert">{msg}</p> : null}
      {data?.length ? data.map((a) => (
        <article key={a.id} className="card" style={{ marginBottom: 12 }}>
          <p className="small"><strong>@{a.appellant}</strong> appeals <strong>{a.action.action}</strong> on a {a.action.target_type} (decided by @{a.action.moderator}: “{a.action.reason}”)</p>
          <blockquote style={{ margin: 0 }}>{a.statement}</blockquote>
          <div className="row" style={{ marginTop: 10 }}><button className="btn-teal btn-sm" onClick={() => void decide(a.id, "reversed")}>Reverse decision</button><button className="btn-sm" onClick={() => void decide(a.id, "upheld")}>Uphold</button></div>
        </article>
      )) : <p className="dim">No open appeals.</p>}
    </>
  );
}

function Held() {
  const { data, reload } = useApi<{ id: string; body: string; author: string; track_id: string; created_at: string }[]>("/mod/held-comments");
  return data?.length ? (
    <ul className="stack" style={{ listStyle: "none", padding: 0 }}>{data.map((c) => (
      <li key={c.id} className="card"><p className="small dim">@{c.author} on <Link href={`/tracks/${c.track_id}`}>a track</Link> · {formatDate(c.created_at)}</p><p>{c.body}</p>
        <div className="row"><button className="btn-sm btn-teal" onClick={() => void api(`/comments/${c.id}/approve`, { method: "POST" }).then(() => reload())}>Approve</button>
          <button className="btn-sm" onClick={() => void api("/mod/actions", { method: "POST", body: { target_type: "comment", target_id: c.id, action: "hide_comment", reason: "Rejected in pre-moderation" } }).then(() => reload())}>Reject</button></div></li>
    ))}</ul>
  ) : <p className="dim">Nothing awaiting review.</p>;
}

function Users({ admin }: { admin: boolean }) {
  const [q, setQ] = useState("");
  const { data, reload } = useApi<{ id: string; username: string; email: string | null; role: string; status: string; restricted_until: string | null; created_at: string }[]>(`/admin/users?q=${encodeURIComponent(q)}`, [q]);
  const [open, setOpen] = useState<string | null>(null);
  return (
    <>
      <label htmlFor="uq">Search users</label><input id="uq" value={q} onChange={(e) => setQ(e.target.value)} />
      <table style={{ marginTop: 12 }}><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th /></tr></thead>
        <tbody>{data?.map((u) => (
          <tr key={u.id}><td>@{u.username}{admin && u.email ? <div className="dim small">{u.email}</div> : null}</td>
            <td>{admin ? <select aria-label={`Role for ${u.username}`} value={u.role} onChange={(e) => void api(`/admin/users/${u.id}`, { method: "PATCH", body: { role: e.target.value } }).then(() => reload())}><option>user</option><option>moderator</option><option>admin</option></select> : u.role}</td>
            <td>{u.status}{u.restricted_until ? <div className="dim small">until {formatDate(u.restricted_until)}</div> : null}</td><td>{formatDate(u.created_at)}</td>
            <td>{open === u.id ? <ActionForm targetType="user" targetId={u.id} onDone={() => { setOpen(null); void reload(); }} /> : <button className="btn-sm" onClick={() => setOpen(u.id)}>Restrict / suspend…</button>}</td></tr>
        ))}</tbody></table>
    </>
  );
}

function Artists({ admin }: { admin: boolean }) {
  const { data, reload } = useApi<{ id: string; name: string; slug: string; status: string; verification_status: string; verification_method: string | null; storage_used_bytes: number; storage_quota_bytes: number }[]>("/admin/artists");
  const [msg, setMsg] = useState<string | null>(null);
  const verify = async (id: string, verified: boolean) => {
    const method = verified ? window.prompt("Describe the verification you performed (e.g. 'Confirmed via link from official website https://…'):") : "Verification removed";
    if (!method) return;
    try { await api(`/admin/artists/${id}/verification`, { method: "POST", body: { verified, method } }); void reload(); } catch (e) { setMsg(errorMessage(e)); }
  };
  const quota = async (id: string) => {
    const gb = window.prompt("Storage quota in GB (blank = server default):");
    if (gb === null) return;
    await api(`/admin/artists/${id}/quota`, { method: "PUT", body: { storage_quota_bytes: gb ? Math.round(Number(gb) * 1024 ** 3) : null } }).catch((e) => setMsg(errorMessage(e)));
    void reload();
  };
  return (
    <>
      <p className="small dim">The “Verified” label is shown only after an administrator records how identity or affiliation was checked. Never verify on the artist&apos;s word alone.</p>
      {msg ? <p className="notice error" role="alert">{msg}</p> : null}
      <table><thead><tr><th>Artist</th><th>Status</th><th>Verification</th><th>Storage</th><th /></tr></thead>
        <tbody>{data?.map((a) => (
          <tr key={a.id}><td><Link href={`/artists/${a.slug}`}>{a.name}</Link></td><td>{a.status}</td>
            <td>{a.verification_status}{a.verification_method ? <div className="dim small">{a.verification_method}</div> : null}</td>
            <td>{formatBytes(a.storage_used_bytes)} / {formatBytes(a.storage_quota_bytes)}</td>
            <td>{admin ? <div className="row"><button className="btn-sm" onClick={() => void verify(a.id, a.verification_status !== "verified")}>{a.verification_status === "verified" ? "Remove verification" : "Verify…"}</button><button className="btn-sm" onClick={() => void quota(a.id)}>Quota…</button></div> : null}</td></tr>
        ))}</tbody></table>
    </>
  );
}

function Jobs({ admin }: { admin: boolean }) {
  const { data, reload } = useApi<{ id: string; kind: string; status: string; attempts: number; last_error: string | null; created_at: string; finished_at: string | null }[]>("/admin/jobs");
  return (
    <>
      <button className="btn-sm" onClick={() => void reload()}>Refresh</button>
      <table style={{ marginTop: 12 }}><thead><tr><th>Kind</th><th>Status</th><th>Attempts</th><th>Created</th><th>Error</th><th /></tr></thead>
        <tbody>{data?.map((j) => <tr key={j.id}><td>{j.kind}</td><td>{j.status}</td><td>{j.attempts}</td><td>{formatDate(j.created_at)}</td><td className="small">{j.last_error}</td>
          <td>{admin && j.status === "failed" ? <button className="btn-sm" onClick={() => void api(`/admin/jobs/${j.id}/retry`, { method: "POST" }).then(() => reload())}>Retry</button> : null}</td></tr>)}</tbody></table>
    </>
  );
}

function Config() {
  const { data, reload } = useApi<{ community: Record<string, boolean | number>; limits: Record<string, number | string> }>("/admin/config");
  const [msg, setMsg] = useState<string | null>(null);
  if (!data) return <p className="muted">Loading…</p>;
  const save = async (k: string, v: boolean | number) => {
    try { await api("/admin/config", { method: "PATCH", body: { [k]: v } }); setMsg(`Saved ${k}.`); void reload(); } catch (e) { setMsg(errorMessage(e)); }
  };
  return (
    <div className="two-col">
      <section className="panel">
        <h2>Community features</h2>
        {msg ? <p className="notice" role="status">{msg}</p> : null}
        {Object.entries(data.community).map(([k, v]) => typeof v === "boolean" ? (
          <label key={k} className="check"><input type="checkbox" checked={v} onChange={(e) => void save(k, e.target.checked)} /> {k.replace(/_/g, " ")}</label>
        ) : (
          <div key={k} className="field row"><label htmlFor={k} style={{ flex: 1, margin: 0 }}>{k.replace(/_/g, " ")}</label><input id={k} type="number" defaultValue={v} style={{ width: 120 }} onBlur={(e) => void save(k, Number(e.target.value))} /></div>
        ))}
      </section>
      <section className="panel">
        <h2>Limits (environment)</h2>
        <p className="small dim">Set through CW_* environment variables; see docs/operators.md.</p>
        <table><tbody>{Object.entries(data.limits).map(([k, v]) => <tr key={k}><th scope="row">{k.replace(/_/g, " ")}</th><td>{typeof v === "number" && k.includes("bytes") ? formatBytes(v) : String(v)}</td></tr>)}</tbody></table>
      </section>
    </div>
  );
}

function Collections() {
  const { data, reload } = useApi<{ id: string; slug: string; title: string; published: boolean; release_ids: string[] }[]>("/admin/collections");
  const [title, setTitle] = useState("");
  const [ids, setIds] = useState("");
  return (
    <>
      <ul>{data?.map((c) => <li key={c.id}><Link href={`/collections/${c.slug}`}>{c.title}</Link> — {c.published ? "published" : "draft"}, {c.release_ids.length} releases</li>)}</ul>
      <form className="card stack" onSubmit={(e) => { e.preventDefault(); void api("/admin/collections", { method: "POST", body: { title, release_ids: ids.split(/[\s,]+/).filter(Boolean), published: true } }).then(() => { setTitle(""); setIds(""); void reload(); }); }}>
        <h3>New editorial collection</h3>
        <div><label htmlFor="ct">Title</label><input id="ct" required value={title} onChange={(e) => setTitle(e.target.value)} /></div>
        <div><label htmlFor="ci">Release IDs</label><textarea id="ci" value={ids} onChange={(e) => setIds(e.target.value)} placeholder="one per line" /></div>
        <button type="submit">Create</button>
      </form>
    </>
  );
}

function Audit() {
  const { data } = useApi<{ id: number; actor: string | null; action: string; target_type: string | null; target_id: string | null; data: Record<string, unknown>; created_at: string }[]>("/admin/audit");
  return <table><thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Target</th><th>Data</th></tr></thead>
    <tbody>{data?.map((a) => <tr key={a.id}><td className="small">{new Date(a.created_at).toLocaleString()}</td><td>{a.actor ? `@${a.actor}` : "—"}</td><td>{a.action}</td><td className="small">{a.target_type} {a.target_id?.slice(0, 8)}</td><td className="mono small">{JSON.stringify(a.data)}</td></tr>)}</tbody></table>;
}
