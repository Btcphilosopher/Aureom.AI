import { describe, expect, it } from "vitest";
import { downsample } from "../components/Waveform";
import { formatBytes, formatTime, spokenTime } from "../lib/format";
import { backoffMs, encodeMetadata, fingerprint } from "../lib/tus";

describe("format", () => {
  it("formats durations", () => {
    expect(formatTime(0)).toBe("0:00");
    expect(formatTime(61_500)).toBe("1:01");
    expect(formatTime(3_725_000)).toBe("1:02:05");
    expect(formatTime(null)).toBe("0:00");
    expect(spokenTime(61_000)).toBe("1 minute 1 second");
    expect(formatBytes(1536)).toBe("1.5 KB");
  });
});

describe("tus helpers", () => {
  it("encodes metadata as base64 pairs (unicode safe)", () => {
    const m = encodeMetadata({ filename: "café.wav", artist_id: "x" });
    const [first] = m.split(",");
    const [k, v] = first.split(" ");
    expect(k).toBe("filename");
    expect(decodeURIComponent(escape(atob(v)))).toBe("café.wav");
  });
  it("fingerprints distinguish artist and file", () => {
    const f = { name: "a.wav", size: 10, lastModified: 1 };
    expect(fingerprint(f, "A")).not.toBe(fingerprint(f, "B"));
    expect(fingerprint(f, "A", "t1")).not.toBe(fingerprint(f, "A"));
  });
  it("backs off exponentially with a cap", () => {
    expect(backoffMs(0)).toBe(1000);
    expect(backoffMs(3)).toBe(8000);
    expect(backoffMs(20)).toBe(30000);
  });
});

describe("waveform", () => {
  it("downsamples by taking bucket peaks", () => {
    expect(downsample([0.1, 0.9, 0.2, 0.4], 2)).toEqual([0.9, 0.4]);
    expect(downsample([], 3)).toHaveLength(3);
  });
});
