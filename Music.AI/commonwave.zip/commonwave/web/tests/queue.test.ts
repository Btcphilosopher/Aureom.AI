import { describe, expect, it } from "vitest";
import { currentTrack, emptyQueue, queueReducer, shuffledOrder, type QueueState } from "../lib/player/queue";
import type { Track } from "../lib/types";

const t = (id: string, available = true): Track => ({
  id, title: id, status: "published", available, artist: { id: "a", slug: "a", name: "A", kind: "solo", verified: false, avatar_url: null },
  duration_ms: 1000, genre: null, tags: [], explicit: false, language: null, artwork_url: null, artwork_thumb_url: null, release: null,
  published_at: null, release_date: null, downloads: { mp3: false, original: false }, licence: null, collaborators: [],
});
const ids = (s: QueueState) => s.order.map((i) => s.items[i].id);
const play = (list: string[], start = 0) => queueReducer(emptyQueue, { type: "playList", tracks: list.map((x) => t(x)), start });

describe("queue", () => {
  it("plays a list from the chosen index", () => {
    const s = play(["a", "b", "c"], 1);
    expect(currentTrack(s)?.id).toBe("b");
  });

  it("skips unavailable tracks when building a list", () => {
    const s = queueReducer(emptyQueue, { type: "playList", tracks: [t("a"), t("x", false), t("b")], start: 2 });
    expect(ids(s)).toEqual(["a", "b"]);
    expect(currentTrack(s)?.id).toBe("b");
  });

  it("next/prev respect repeat modes", () => {
    let s = play(["a", "b"], 1);
    expect(currentTrack(queueReducer(s, { type: "next", auto: true }))).toBeNull(); // end of queue
    s = queueReducer(s, { type: "cycleRepeat" }); // all
    expect(currentTrack(queueReducer(s, { type: "next", auto: true }))?.id).toBe("a");
    s = queueReducer(s, { type: "cycleRepeat" }); // one
    expect(currentTrack(queueReducer(s, { type: "next", auto: true }))?.id).toBe("b");
    expect(currentTrack(queueReducer(play(["a", "b"], 0), { type: "prev" }))?.id).toBe("a");
  });

  it("removing the playing item advances to the next one", () => {
    const s = queueReducer(play(["a", "b", "c"], 1), { type: "remove", index: 1 });
    expect(ids(s)).toEqual(["a", "c"]);
    expect(currentTrack(s)?.id).toBe("c");
  });

  it("removing an earlier item keeps the current track", () => {
    const s = queueReducer(play(["a", "b", "c"], 2), { type: "remove", index: 0 });
    expect(currentTrack(s)?.id).toBe("c");
  });

  it("removeTrack drops every occurrence of a withdrawn track", () => {
    let s = play(["a", "w", "b"], 0);
    s = queueReducer(s, { type: "enqueue", track: t("w") });
    s = queueReducer(s, { type: "removeTrack", trackId: "w" });
    expect(ids(s)).toEqual(["a", "b"]);
    expect(currentTrack(s)?.id).toBe("a");
  });

  it("removing the last playing item ends playback", () => {
    const s = queueReducer(play(["a"], 0), { type: "removeTrack", trackId: "a" });
    expect(currentTrack(s)).toBeNull();
  });

  it("playNext inserts after the current item", () => {
    const s = queueReducer(play(["a", "b"], 0), { type: "playNext", track: t("n") });
    expect(ids(s)).toEqual(["a", "n", "b"]);
  });

  it("shuffle keeps the current track first and is a permutation", () => {
    let s = play(["a", "b", "c", "d", "e"], 2);
    s = queueReducer(s, { type: "toggleShuffle" });
    expect(currentTrack(s)?.id).toBe("c");
    expect(s.order[0]).toBe(2);
    expect([...s.order].sort()).toEqual([0, 1, 2, 3, 4]);
    s = queueReducer(s, { type: "toggleShuffle" });
    expect(ids(s)).toEqual(["a", "b", "c", "d", "e"]);
    expect(currentTrack(s)?.id).toBe("c");
  });

  it("shuffledOrder is deterministic per seed", () => {
    expect(shuffledOrder(6, 0, 7)).toEqual(shuffledOrder(6, 0, 7));
  });
});
