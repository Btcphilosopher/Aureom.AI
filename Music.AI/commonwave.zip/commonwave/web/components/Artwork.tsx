/* eslint-disable @next/next/no-img-element */
import { Icon } from "./Icon";

export function Artwork({ src, alt, className }: { src: string | null | undefined; alt: string; className?: string }) {
  if (!src) {
    return (
      <div className={`art-fallback ${className ?? ""}`} role="img" aria-label={alt || "No artwork"}>
        <Icon name="playlists" size={28} />
      </div>
    );
  }
  return <img src={src} alt={alt} loading="lazy" decoding="async" className={className} />;
}
