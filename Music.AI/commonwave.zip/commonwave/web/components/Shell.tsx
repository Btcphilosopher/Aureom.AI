"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import { useAuth } from "@/lib/auth";
import { Icon, Logo } from "./Icon";
import { PlayerBar } from "./PlayerBar";

const NAV = [
  { href: "/", label: "Discover", icon: "discover" },
  { href: "/following", label: "Following", icon: "following" },
  { href: "/library", label: "Library", icon: "library" },
  { href: "/playlists", label: "Playlists", icon: "playlists" },
  { href: "/upload", label: "Upload", icon: "upload" },
];

function active(path: string, href: string) {
  return href === "/" ? path === "/" : path === href || path.startsWith(`${href}/`);
}

export function Shell({ children }: { children: ReactNode }) {
  const path = usePathname() ?? "/";
  const router = useRouter();
  const { me, logout } = useAuth();
  const [q, setQ] = useState("");
  const user = me?.user;

  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <div className="shell">
        <aside className="sidebar">
          <Link href="/" className="brand" aria-label="COMMONWAVE home">
            <Logo />
            <span>COMMONWAVE<small>Open music for everyone</small></span>
          </Link>
          <nav aria-label="Main">
            <div className="nav">
              {NAV.map((n) => (
                <Link key={n.href} href={n.href} aria-current={active(path, n.href) ? "page" : undefined}>
                  <Icon name={n.icon} /> {n.label}
                </Link>
              ))}
            </div>
          </nav>
          <nav aria-label="More" className="nav-secondary">
            {user?.role === "admin" || user?.role === "moderator" ? <Link href="/admin">Moderation &amp; admin</Link> : null}
            {me?.artists.length ? <Link href="/studio">Artist studio</Link> : null}
            <Link href="/about">About, rights &amp; funding</Link>
            <Link href="/settings">Settings &amp; privacy</Link>
            {/* AGPL-3.0 §13: users interacting over a network must be offered the source. */}
            <a href={process.env.NEXT_PUBLIC_SOURCE_URL || "/about#source"}>Source code (AGPL)</a>
          </nav>
        </aside>
        <div className="main">
          <header className="topbar">
            <Link href="/" className="brand mobile-brand" aria-label="COMMONWAVE home"><Logo size={28} /></Link>
            <form role="search" className="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`); }}>
              <label htmlFor="global-search" className="sr-only">Search tracks, artists and releases</label>
              <Icon name="search" size={18} />
              <input id="global-search" type="search" placeholder="Search tracks, artists, releases" value={q} onChange={(e) => setQ(e.target.value)} />
            </form>
            <div className="account">
              {user ? (
                <>
                  <Link href="/settings" className="btn btn-ghost btn-sm hide-sm">{user.display_name}</Link>
                  <button className="btn-sm" onClick={() => void logout().then(() => router.push("/"))}>Sign out</button>
                </>
              ) : (
                <>
                  <Link href="/login" className="btn btn-sm btn-ghost">Sign in</Link>
                  <Link href="/register" className="btn btn-sm btn-primary">Join free</Link>
                </>
              )}
            </div>
          </header>
          <main id="main" className="content" tabIndex={-1}>{children}</main>
        </div>
      </div>
      <PlayerBar />
      <nav aria-label="Main" className="mobile-tabs">
        {NAV.map((n) => (
          <Link key={n.href} href={n.href} aria-current={active(path, n.href) ? "page" : undefined}>
            <Icon name={n.icon} size={22} />
            {n.label}
          </Link>
        ))}
      </nav>
    </>
  );
}
