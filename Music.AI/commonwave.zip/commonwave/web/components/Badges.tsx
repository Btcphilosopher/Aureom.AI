import type { Licence } from "@/lib/types";
import { Icon } from "./Icon";

export function LicenceBadge({ licence }: { licence: Licence | null | undefined }) {
  if (!licence) return null;
  const open = licence.allows_reuse;
  return (
    <span className={`badge ${open ? "badge-teal" : ""}`} title={licence.name}>
      {open ? "Open licence:" : "Licence:"} {licence.short}
    </span>
  );
}

export function ExplicitBadge({ explicit }: { explicit: boolean }) {
  if (!explicit) return null;
  return (
    <span className="badge badge-solid" title="Explicit content">
      E<span className="sr-only">xplicit</span>
    </span>
  );
}

export function VerifiedBadge({ verified }: { verified: boolean }) {
  if (!verified) return null;
  return (
    <span className="badge badge-teal" title="Identity checked by this server's administrators">
      <Icon name="verified" size={14} /> Verified
    </span>
  );
}
