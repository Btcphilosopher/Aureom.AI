import Link from "next/link";

export function SignInPrompt({ what }: { what: string }) {
  return (
    <div className="panel" style={{ marginTop: 30 }}>
      <h1>Sign in to {what}</h1>
      <p className="muted">Listening is always free and needs no account. An account lets you save music, make playlists and follow artists.</p>
      <div className="row"><Link className="btn btn-primary" href="/register">Create a free account</Link><Link className="btn" href="/login">Sign in</Link></div>
    </div>
  );
}
