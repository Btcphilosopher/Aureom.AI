"use client";

import { useRef, type KeyboardEvent, type PointerEvent } from "react";
import { formatTime, spokenTime } from "@/lib/format";

/** Clean, accessible waveform: SVG bars, works as a keyboard slider (←/→ 5 s, PgUp/PgDn 30 s, Home/End). */
export function Waveform({
  peaks, durationMs, positionMs, bufferedMs = 0, onSeek, label, markers = [], interactive = true,
}: {
  peaks: number[] | null | undefined;
  durationMs: number;
  positionMs: number;
  bufferedMs?: number;
  onSeek?: (ms: number) => void;
  label: string;
  markers?: { ms: number; label: string }[];
  interactive?: boolean;
}) {
  const ref = useRef<SVGSVGElement>(null);
  const bars = downsample(peaks ?? [], 160);
  const n = bars.length || 1;
  const playedFrac = durationMs ? Math.min(1, positionMs / durationMs) : 0;
  const bufFrac = durationMs ? Math.min(1, bufferedMs / durationMs) : 0;

  const seekAt = (clientX: number) => {
    const el = ref.current;
    if (!el || !onSeek || !durationMs) return;
    const r = el.getBoundingClientRect();
    onSeek(Math.max(0, Math.min(1, (clientX - r.left) / r.width)) * durationMs);
  };
  const onKey = (e: KeyboardEvent) => {
    if (!onSeek) return;
    const step = { ArrowLeft: -5000, ArrowRight: 5000, ArrowDown: -5000, ArrowUp: 5000, PageDown: -30000, PageUp: 30000 } as Record<string, number>;
    if (e.key in step) {
      e.preventDefault();
      onSeek(Math.max(0, Math.min(durationMs, positionMs + step[e.key])));
    } else if (e.key === "Home") {
      e.preventDefault();
      onSeek(0);
    } else if (e.key === "End") {
      e.preventDefault();
      onSeek(Math.max(0, durationMs - 1000));
    }
  };

  return (
    <div className="wave-wrap">
      <svg
        ref={ref}
        className="waveform"
        viewBox={`0 0 ${n * 4} 100`}
        preserveAspectRatio="none"
        role={interactive ? "slider" : "img"}
        tabIndex={interactive ? 0 : -1}
        aria-label={label}
        aria-valuemin={interactive ? 0 : undefined}
        aria-valuemax={interactive ? Math.round(durationMs / 1000) : undefined}
        aria-valuenow={interactive ? Math.round(positionMs / 1000) : undefined}
        aria-valuetext={interactive ? `${spokenTime(positionMs)} of ${spokenTime(durationMs)}` : undefined}
        onPointerDown={interactive ? (e: PointerEvent) => seekAt(e.clientX) : undefined}
        onKeyDown={interactive ? onKey : undefined}
      >
        {bars.map((p, i) => {
          const h = Math.max(4, p * 96);
          const frac = (i + 0.5) / n;
          const cls = frac <= playedFrac ? "bar played" : frac <= bufFrac ? "bar buffered" : "bar";
          return <rect key={i} className={cls} x={i * 4} y={(100 - h) / 2} width={2.6} height={h} rx={1.2} />;
        })}
        {markers.map((m, i) => (
          <rect key={`m${i}`} className="marker" x={(m.ms / (durationMs || 1)) * n * 4} y={94} width={3} height={6}>
            <title>{m.label}</title>
          </rect>
        ))}
      </svg>
      <div className="wave-times" aria-hidden="true">
        <span>{formatTime(positionMs)}</span>
        <span>{formatTime(durationMs)}</span>
      </div>
    </div>
  );
}

export function downsample(peaks: number[], target: number): number[] {
  if (!peaks.length) return Array.from({ length: target }, () => 0.08);
  if (peaks.length <= target) return peaks;
  const out: number[] = [];
  const step = peaks.length / target;
  for (let i = 0; i < target; i++) {
    let m = 0;
    for (let j = Math.floor(i * step); j < Math.floor((i + 1) * step); j++) m = Math.max(m, peaks[j]);
    out.push(m);
  }
  return out;
}
