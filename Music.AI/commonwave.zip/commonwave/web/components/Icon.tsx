/** Inline icon set (original artwork, stroke-based). Decorative by default. */
import type { SVGProps } from "react";

const paths: Record<string, string> = {
  play: "M7 4.5v15l13-7.5z",
  pause: "M7 4h4v16H7zM13 4h4v16h-4z",
  next: "M5 4.5v15l10-7.5zM17 4h2.5v16H17z",
  prev: "M19 4.5v15L9 12zM4.5 4H7v16H4.5z",
  shuffle: "M3 7h3.5c2 0 3 1 4.2 2.6l2.6 4.8C14.5 16 15.5 17 17.5 17H21M3 17h3.5c1.4 0 2.3-.6 3.1-1.5M14.4 8.5C15.2 7.6 16.1 7 17.5 7H21M18 4l3 3-3 3M18 14l3 3-3 3",
  repeat: "M4 11V9a3 3 0 0 1 3-3h12l-3-3M20 13v2a3 3 0 0 1-3 3H5l3 3",
  volume: "M4 9v6h4l5 4V5L8 9zM16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12",
  mute: "M4 9v6h4l5 4V5L8 9zM17 9l5 6M22 9l-5 6",
  queue: "M4 6h12M4 11h12M4 16h8M17 14v6l4-3z",
  discover: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM15.5 8.5l-2 5-5 2 2-5z",
  following: "M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM2 21c0-3.9 3.1-7 7-7s7 3.1 7 7M17 7v6M14 10h6",
  library: "M4 4v16M9 4v16M14 4l5 16",
  playlists: "M4 6h11M4 11h11M4 16h7M19 4v11.5a2.5 2.5 0 1 1-2.5-2.5H19",
  upload: "M12 16V4M7 9l5-5 5 5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4",
  heart: "M12 20s-7-4.4-9.2-8.6C1.3 8.3 3 5 6.4 5c2 0 3.3 1.1 4.1 2.4h3C14.3 6.1 15.6 5 17.6 5 21 5 22.7 8.3 21.2 11.4 19 15.6 12 20 12 20z",
  heartFilled: "M12 20s-7-4.4-9.2-8.6C1.3 8.3 3 5 6.4 5c2 0 3.3 1.1 4.1 2.4h3C14.3 6.1 15.6 5 17.6 5 21 5 22.7 8.3 21.2 11.4 19 15.6 12 20 12 20z",
  plus: "M12 5v14M5 12h14",
  more: "M5 12h.01M12 12h.01M19 12h.01",
  download: "M12 4v11M7 10l5 5 5-5M4 19h16",
  flag: "M5 21V4M5 4h11l-2 4 2 4H5",
  close: "M6 6l12 12M18 6L6 18",
  check: "M5 12l5 5 9-10",
  shield: "M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z",
  settings: "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 12h2M18 12h2M12 4v2M12 18v2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M6.3 17.7l1.4-1.4M16.3 7.7l1.4-1.4",
  verified: "M12 3l2.4 1.8 3 .2.9 2.9 2.2 2-1 2.9.4 3-2.7 1.4-1.4 2.7-3-.4L12 21l-2.4-1.8-3-.2-.9-2.9-2.2-2 1-2.9-.4-3 2.7-1.4 1.4-2.7 3 .4zM8.5 12l2.5 2.5 4.5-5",
  external: "M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5",
  keyboard: "M3 7h18v10H3zM7 11h.01M11 11h.01M15 11h.01M8 14h8",
  share: "M18 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM18 22a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM8.6 13.5l6.8 4M15.4 6.5l-6.8 4",
};

export function Icon({ name, size = 20, title, ...rest }: { name: keyof typeof paths | string; size?: number; title?: string } & SVGProps<SVGSVGElement>) {
  const filled = ["play", "pause", "next", "prev", "heartFilled"].includes(name);
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden={title ? undefined : true} role={title ? "img" : undefined}
      fill={filled ? "currentColor" : "none"} stroke={filled ? "none" : "currentColor"} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" {...rest}>
      {title ? <title>{title}</title> : null}
      <path d={paths[name] ?? paths.more} />
    </svg>
  );
}

export function Logo({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="9" fill="#151d44" />
      <path d="M4 18c3 0 3-8 6-8s3 12 6 12 3-14 6-14 3 10 6 10" fill="none" stroke="#ff6f61" strokeWidth="2.6" strokeLinecap="round" />
      <path d="M4 22c3 0 3-4 6-4s3 6 6 6 3-7 6-7 3 5 6 5" fill="none" stroke="#40e0d0" strokeWidth="1.6" strokeLinecap="round" opacity=".9" />
    </svg>
  );
}
