"use client";

import Link from "next/link";
import { useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatTime } from "@/lib/format";
import { usePlayer } from "@/lib/player/PlayerProvider";
import type { Track } from "@/lib/types";
import { Artwork } from "./Artwork";
import { ExplicitBadge } from "./Badges";
import { Icon } from "./Icon";
import { AddToPlaylist } from "./AddToPlaylist";

export function TrackList({ tracks, source, numbered = false, showArtist = true, onRemove, emptyText }: {
  tracks: (Track | null)[];
  source: string;
  numbered?: boolean;
  showArtist?: boolean;
  onRemove?: (index: number) => void;
  emptyText?: string;
}) {
  const player = usePlayer();
  const playable = tracks.filter((t): t is Track => Boolean(t && t.available));
  if (!tracks.length) return <div className="empty">{emptyText ?? "Nothing here yet."}</div>;
  return (
    <ol className="tracklist">
      {tracks.map((t, i) =>
        t ? (
          <TrackRow key={`${t.id}-${i}`} t={t} index={i} numbered={numbered} showArtist={showArtist}
            isCurrent={player.current?.id === t.id} playing={player.current?.id === t.id && player.status === "playing"}
            onPlay={() => player.playList(playable, Math.max(0, playable.findIndex((p) => p.id === t.id)), source)}
            onRemove={onRemove ? () => onRemove(i) : undefined} />
        ) : (
          <li key={`gone-${i}`} className="trow unavailable">
            <span className="num">{i + 1}</span>
            <div className="thumb" />
            <div className="meta"><div className="t">Unavailable track</div><div className="a">Withdrawn or removed by the artist or moderators</div></div>
            <span />
            <span className="actions">{onRemove ? <button className="btn-sm btn-ghost" onClick={() => onRemove(i)}>Remove</button> : null}</span>
          </li>
        ),
      )}
    </ol>
  );
}

function TrackRow({ t, index, numbered, showArtist, isCurrent, playing, onPlay, onRemove }: {
  t: Track; index: number; numbered: boolean; showArtist: boolean; isCurrent: boolean; playing: boolean; onPlay: () => void; onRemove?: () => void;
}) {
  const player = usePlayer();
  const { me } = useAuth();
  const [menu, setMenu] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const save = async () => {
    try {
      await api("/saves", { method: "POST", body: { target_type: "track", target_id: t.id } });
      setNote("Saved to your library");
    } catch (e) {
      setNote(errorMessage(e));
    }
  };
  return (
    <li className={`trow ${isCurrent ? "is-current" : ""}`}>
      <span className="num">
        {playing ? <span className="eq" aria-label="Now playing"><i /><i /><i /></span> : numbered ? (t.position ?? index + 1) : index + 1}
      </span>
      <button className="thumb" onClick={playing ? player.toggle : onPlay} style={{ padding: 0, border: 0, borderRadius: 8, overflow: "hidden" }}
        aria-label={playing ? `Pause ${t.title}` : `Play ${t.title} by ${t.artist.name}`}>
        <Artwork src={t.artwork_thumb_url} alt="" />
      </button>
      <div className="meta">
        <div className="t">
          <Link href={`/tracks/${t.id}`}>{t.title}</Link> <ExplicitBadge explicit={t.explicit} />
        </div>
        {showArtist ? <div className="a"><Link href={`/artists/${t.artist.slug}`}>{t.artist.name}</Link>{t.release ? <> · <Link href={`/releases/${t.release.id}`}>{t.release.title}</Link></> : null}</div> : null}
        {note ? <div className="small" role="status" style={{ color: "var(--turquoise)" }}>{note}</div> : null}
      </div>
      <span className="dur">{formatTime(t.duration_ms)}</span>
      <span className="actions">
        <button className="icon-btn" onClick={playing ? player.toggle : onPlay} aria-label={playing ? `Pause ${t.title}` : `Play ${t.title}`}>
          <Icon name={playing ? "pause" : "play"} size={18} />
        </button>
        <button className="icon-btn" aria-label={`More actions for ${t.title}`} aria-expanded={menu} onClick={() => setMenu((m) => !m)}>
          <Icon name="more" size={18} />
        </button>
        {menu ? (
          <div role="menu" className="card" style={{ position: "absolute", right: 24, zIndex: 30, padding: 8, display: "grid", gap: 4, minWidth: 220 }}
            onKeyDown={(e) => e.key === "Escape" && setMenu(false)}>
            <button role="menuitem" className="btn-ghost" onClick={() => { player.playNext(t); setMenu(false); setNote("Will play next"); }}>Play next</button>
            <button role="menuitem" className="btn-ghost" onClick={() => { player.enqueue(t); setMenu(false); setNote("Added to queue"); }}>Add to queue</button>
            {me?.user ? <button role="menuitem" className="btn-ghost" onClick={() => { void save(); setMenu(false); }}>Save to library</button> : null}
            {me?.user ? <AddToPlaylist inMenu trackId={t.id} onDone={(msg) => { setNote(msg); setMenu(false); }} /> : <Link className="btn btn-ghost" href="/login">Sign in to save</Link>}
            {onRemove ? <button role="menuitem" className="btn-ghost" onClick={() => { onRemove(); setMenu(false); }}>Remove from playlist</button> : null}
          </div>
        ) : null}
      </span>
    </li>
  );
}
