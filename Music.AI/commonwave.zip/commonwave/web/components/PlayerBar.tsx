"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { formatTime, spokenTime } from "@/lib/format";
import { RATES, usePlayer, usePosition } from "@/lib/player/PlayerProvider";
import { Artwork } from "./Artwork";
import { Icon } from "./Icon";

export function PlayerBar() {
  const p = usePlayer();
  const { position, duration } = usePosition();
  const [showQueue, setShowQueue] = useState(false);
  const help = useRef<HTMLDialogElement>(null);
  const t = p.current;
  const pct = duration ? (position / duration) * 100 : 0;
  const playing = p.status === "playing";
  const statusText = { idle: "", loading: "Loading…", buffering: "Buffering…", error: "Playback problem", playing: "", paused: "" }[p.status];

  return (
    <>
      <section className="player" aria-label="Audio player">
        <div className="now">
          <div className="thumb"><Artwork src={t?.artwork_thumb_url} alt="" /></div>
          <div style={{ minWidth: 0 }}>
            {t ? (
              <>
                <div className="t"><Link href={`/tracks/${t.id}`}>{t.title}</Link></div>
                <div className="a"><Link href={`/artists/${t.artist.slug}`}>{t.artist.name}</Link></div>
              </>
            ) : (
              <div className="a">Nothing playing. Press play on any track — no account needed.</div>
            )}
            {statusText ? <div className="status-pill" role="status">{statusText}</div> : null}
          </div>
        </div>

        <div className="center">
          <div className="controls">
            <button className="icon-btn hide-sm" onClick={p.toggleShuffle} aria-pressed={p.queue.shuffle} aria-label={`Shuffle ${p.queue.shuffle ? "on" : "off"}`} title="Shuffle">
              <Icon name="shuffle" />
            </button>
            <button className="icon-btn hide-sm" onClick={p.prev} aria-label="Previous track" title="Previous (Shift+P)" disabled={!t}>
              <Icon name="prev" />
            </button>
            <button className="play-btn sm" onClick={p.toggle} disabled={!t} aria-label={playing ? "Pause" : "Play"} title="Play/pause (Space or K)">
              <Icon name={playing ? "pause" : "play"} />
            </button>
            <button className="icon-btn" onClick={p.next} aria-label="Next track" title="Next (Shift+N)" disabled={!t}>
              <Icon name="next" />
            </button>
            <button className="icon-btn hide-sm" onClick={p.cycleRepeat} aria-pressed={p.queue.repeat !== "off"}
              aria-label={`Repeat: ${p.queue.repeat === "off" ? "off" : p.queue.repeat === "all" ? "all tracks" : "this track"}`} title="Repeat" style={{ position: "relative" }}>
              <Icon name="repeat" />
              {p.queue.repeat === "one" ? <span className="repeat-one" aria-hidden="true">1</span> : null}
            </button>
          </div>
          <div className="scrub">
            <span>{formatTime(position)}</span>
            <input
              className="range" type="range" min={0} max={Math.max(1, Math.round(duration))} step={1000} value={Math.round(position)}
              style={{ ["--pct" as string]: `${pct}%` }} disabled={!t}
              onChange={(e) => p.seek(Number(e.target.value))}
              aria-label="Seek" aria-valuetext={`${spokenTime(position)} of ${spokenTime(duration)}`}
            />
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="right">
          <button className="btn-sm rate-btn hide-md" onClick={() => p.setRate(RATES[(RATES.indexOf(p.rate) + 1) % RATES.length])}
            aria-label={`Playback speed ${p.rate} times. Change speed`} title="Playback speed">
            {p.rate}×
          </button>
          <button className="icon-btn hide-md" aria-pressed={p.normalise} onClick={() => p.setNormalise(!p.normalise)}
            aria-label={`Loudness levelling ${p.normalise ? "on" : "off"}`}
            title={`Loudness levelling ${p.normalise ? "on" : "off"}: reduces loud tracks toward a common level in the player only. Files are never changed.`}>
            <span aria-hidden="true" style={{ fontSize: 11, fontWeight: 900 }}>LUFS</span>
          </button>
          <button className="icon-btn" onClick={p.toggleMute} aria-label={p.muted ? "Unmute" : "Mute"} aria-pressed={p.muted} title="Mute (M)">
            <Icon name={p.muted || p.volume === 0 ? "mute" : "volume"} />
          </button>
          <input className="range hide-md" type="range" min={0} max={100} value={Math.round((p.muted ? 0 : p.volume) * 100)}
            style={{ ["--pct" as string]: `${(p.muted ? 0 : p.volume) * 100}%` }} onChange={(e) => p.setVolume(Number(e.target.value) / 100)} aria-label="Volume" />
          <button className="icon-btn" onClick={() => setShowQueue((s) => !s)} aria-expanded={showQueue} aria-controls="queue-panel" aria-label={`Queue, ${p.queue.items.length} tracks`} title="Queue">
            <Icon name="queue" />
          </button>
          <button className="icon-btn hide-md" onClick={() => help.current?.showModal()} aria-label="Keyboard shortcuts" title="Keyboard shortcuts">
            <Icon name="keyboard" />
          </button>
        </div>
      </section>

      {showQueue ? (
        <div id="queue-panel" className="queue-panel" role="region" aria-label="Play queue">
          <div className="row" style={{ marginBottom: 8 }}>
            <h2 style={{ margin: 0, fontSize: "1.1rem" }}>Queue</h2>
            <span className="spacer" />
            {p.queue.items.length ? <button className="btn-sm" onClick={p.clear}>Clear</button> : null}
            <button className="icon-btn" onClick={() => setShowQueue(false)} aria-label="Close queue"><Icon name="close" /></button>
          </div>
          {p.queue.items.length === 0 ? <p className="muted">Your queue is empty.</p> : (
            <ol>
              {p.queue.order.map((idx, pos) => {
                const item = p.queue.items[idx];
                const isCur = pos === p.queue.cursor;
                return (
                  <li key={`${item.id}-${idx}`} aria-current={isCur ? "true" : undefined}>
                    <button className="btn-ghost" style={{ justifyContent: "flex-start", textAlign: "left", minWidth: 0 }} onClick={() => p.jump(idx)}>
                      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {isCur ? <span className="sr-only">Now playing: </span> : null}
                        {item.title} <span className="dim">— {item.artist.name}</span>
                      </span>
                    </button>
                    <button className="icon-btn" onClick={() => p.remove(idx)} aria-label={`Remove ${item.title} from queue`}><Icon name="close" size={16} /></button>
                  </li>
                );
              })}
            </ol>
          )}
          {p.playbackGainDb !== null ? (
            <p className="dim small" style={{ marginTop: 10 }}>
              Loudness levelling {p.normalise ? `is on (${p.playbackGainDb > 0 ? "no boost applied" : `${p.playbackGainDb.toFixed(1)} dB`})` : "is off"}. Levelling only changes playback volume, never the recording.
            </p>
          ) : null}
        </div>
      ) : null}

      {p.message ? (
        <div className="toast" role="alert">
          <span>{p.message}</span>
          <button onClick={p.dismissMessage}>Dismiss</button>
        </div>
      ) : null}

      <dialog ref={help} aria-labelledby="kbd-title">
        <h2 id="kbd-title">Keyboard shortcuts</h2>
        <table>
          <tbody>
            <tr><td><kbd>Space</kbd> or <kbd>K</kbd></td><td>Play / pause</td></tr>
            <tr><td><kbd>J</kbd> / <kbd>L</kbd></td><td>Back / forward 10 seconds</td></tr>
            <tr><td><kbd>Shift</kbd>+<kbd>N</kbd> / <kbd>Shift</kbd>+<kbd>P</kbd></td><td>Next / previous track</td></tr>
            <tr><td><kbd>M</kbd></td><td>Mute</td></tr>
            <tr><td>Waveform focused: <kbd>←</kbd> <kbd>→</kbd>, <kbd>PgUp</kbd> <kbd>PgDn</kbd>, <kbd>Home</kbd> <kbd>End</kbd></td><td>Seek</td></tr>
          </tbody>
        </table>
        <p className="dim small">Shortcuts are ignored while you type in a field.</p>
        <button onClick={() => help.current?.close()}>Close</button>
      </dialog>
    </>
  );
}
