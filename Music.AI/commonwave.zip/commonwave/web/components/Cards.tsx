import Link from "next/link";
import type { ArtistBrief, ReleaseBrief } from "@/lib/types";
import { kindLabel } from "@/lib/format";
import { Artwork } from "./Artwork";
import { VerifiedBadge } from "./Badges";

export function ReleaseCard({ r }: { r: ReleaseBrief }) {
  const year = r.release_date ? r.release_date.slice(0, 4) : "";
  return (
    <Link href={`/releases/${r.id}`} className="rcard">
      <div className="art"><Artwork src={r.artwork_url} alt={`Cover of ${r.title}`} /></div>
      <div className="title">{r.title}</div>
      <div className="sub">{r.artist.name} · {kindLabel(r.kind)}{year ? ` · ${year}` : ""}</div>
    </Link>
  );
}

export function ArtistCard({ a, note }: { a: ArtistBrief; note?: string }) {
  return (
    <Link href={`/artists/${a.slug}`} className="acard">
      <div className="avatar"><Artwork src={a.avatar_url} alt="" /></div>
      <div style={{ fontWeight: 700 }}>{a.name}</div>
      <div className="row" style={{ justifyContent: "center", gap: 6 }}>
        <VerifiedBadge verified={a.verified} />
        {note ? <span className="dim small">{note}</span> : null}
      </div>
    </Link>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="empty">{children}</div>;
}

export function Section({ title, hint, children, action }: { title: string; hint?: string; children: React.ReactNode; action?: React.ReactNode }) {
  const id = `s-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  return (
    <section className="section" aria-labelledby={id}>
      <div className="section-head">
        <h2 id={id}>{title}</h2>
        {hint ? <span className="hint">{hint}</span> : null}
        <span className="spacer" />
        {action}
      </div>
      {children}
    </section>
  );
}
