"use client";

import { useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export function CreateArtist({ onCreated }: { onCreated?: (id: string) => void }) {
  const { refresh } = useAuth();
  const [name, setName] = useState("");
  const [kind, setKind] = useState("solo");
  const [err, setErr] = useState<string | null>(null);
  return (
    <form className="card" onSubmit={async (e) => {
      e.preventDefault();
      try {
        const a = await api<{ id: string }>("/artists", { method: "POST", body: { name, kind } });
        await refresh();
        onCreated?.(a.id);
      } catch (x) {
        setErr(errorMessage(x));
      }
    }}>
      <h2>Create an artist profile</h2>
      <p className="muted small">Your account and your artist identity are separate. A band can add several people as owners, managers or contributors later.</p>
      <div className="grid2">
        <div className="field"><label htmlFor="an">Artist or band name</label><input id="an" required value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="field"><label htmlFor="ak">Type</label><select id="ak" value={kind} onChange={(e) => setKind(e.target.value)}><option value="solo">Solo artist</option><option value="band">Band</option><option value="collective">Collective</option></select></div>
      </div>
      {err ? <p className="notice error" role="alert">{err}</p> : null}
      <button className="btn-primary" type="submit">Create profile</button>
    </form>
  );
}
