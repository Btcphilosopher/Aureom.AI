"use client";

import { useEffect, useState } from "react";
import { api, errorMessage } from "@/lib/api";

interface P { id: string; title: string; visibility: string }

export function AddToPlaylist({ trackId, onDone, inMenu = false }: { trackId: string; onDone: (msg: string) => void; inMenu?: boolean }) {
  const [lists, setLists] = useState<P[] | null>(null);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (open && !lists) api<P[]>("/playlists").then(setLists).catch(() => setLists([]));
  }, [open, lists]);
  const add = async (p: P) => {
    try {
      await api(`/playlists/${p.id}/entries`, { method: "POST", body: { track_id: trackId } });
      onDone(`Added to “${p.title}”`);
    } catch (e) {
      onDone(errorMessage(e));
    }
  };
  const create = async () => {
    const title = window.prompt("New playlist name");
    if (!title) return;
    try {
      const p = await api<P>("/playlists", { method: "POST", body: { title, visibility: "private" } });
      await add(p);
    } catch (e) {
      onDone(errorMessage(e));
    }
  };
  if (!open) return <button role={inMenu ? "menuitem" : undefined} className="btn-ghost" onClick={() => setOpen(true)}>Add to playlist…</button>;
  return (
    <div role="group" aria-label="Choose a playlist" style={{ display: "grid", gap: 4 }}>
      {lists === null ? <span className="dim small">Loading…</span> : null}
      {lists?.map((p) => (
        <button key={p.id} className="btn-ghost btn-sm" onClick={() => void add(p)}>
          {p.title} <span className="dim small">({p.visibility})</span>
        </button>
      ))}
      <button className="btn-sm" onClick={() => void create()}>+ New private playlist</button>
    </div>
  );
}
