"use client";

import { useRef, useState } from "react";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { Icon } from "./Icon";

const REASONS: [string, string][] = [
  ["spam", "Spam or scam"], ["harassment", "Harassment or bullying"], ["hate", "Hateful content"], ["sexual_content", "Sexual content"],
  ["violence", "Violence or threats"], ["rights", "Copyright or rights complaint"], ["impersonation", "Impersonation"], ["other", "Something else"],
];

export function ReportButton({ targetType, targetId, label = "Report", compact = false }: { targetType: string; targetId: string; label?: string; compact?: boolean }) {
  const { me } = useAuth();
  const ref = useRef<HTMLDialogElement>(null);
  const [reason, setReason] = useState("spam");
  const [details, setDetails] = useState("");
  const [claim, setClaim] = useState({ claimant_name: "", claimant_contact: "", relationship: "rights-holder", original_work: "", good_faith_statement: false, accuracy_statement: false });
  const [status, setStatus] = useState<string | null>(null);
  if (!me?.user) return null;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const r = await api<{ duplicate: boolean }>("/reports", { method: "POST", body: { target_type: targetType, target_id: targetId, reason, details, rights_claim: reason === "rights" ? claim : undefined } });
      setStatus(r.duplicate ? "You've already reported this; moderators will review it." : "Thanks — moderators will review your report.");
    } catch (err) {
      setStatus(errorMessage(err));
    }
  };
  return (
    <>
      <button className={compact ? "icon-btn" : "btn-sm btn-ghost"} onClick={() => { setStatus(null); ref.current?.showModal(); }} aria-label={compact ? `${label} ${targetType}` : undefined}>
        <Icon name="flag" size={16} />{compact ? null : label}
      </button>
      <dialog ref={ref} aria-labelledby={`rep-${targetId}`}>
        <form onSubmit={submit}>
          <h2 id={`rep-${targetId}`}>Report this {targetType}</h2>
          <p className="muted small">Reports go to this server&apos;s moderators. Automated tools never decide on their own; a person reviews every report.</p>
          <div className="field">
            <label htmlFor={`reason-${targetId}`}>Reason</label>
            <select id={`reason-${targetId}`} value={reason} onChange={(e) => setReason(e.target.value)}>
              {REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          {reason === "rights" ? (
            <fieldset className="card" style={{ marginBottom: 16 }}>
              <legend>Rights complaint details</legend>
              <div className="field"><label htmlFor={`cn-${targetId}`}>Your name or organisation</label><input id={`cn-${targetId}`} required value={claim.claimant_name} onChange={(e) => setClaim({ ...claim, claimant_name: e.target.value })} /></div>
              <div className="field"><label htmlFor={`cc-${targetId}`}>Contact (email or address)</label><input id={`cc-${targetId}`} required value={claim.claimant_contact} onChange={(e) => setClaim({ ...claim, claimant_contact: e.target.value })} /></div>
              <div className="field"><label htmlFor={`cr-${targetId}`}>Your relationship to the work</label>
                <select id={`cr-${targetId}`} value={claim.relationship} onChange={(e) => setClaim({ ...claim, relationship: e.target.value })}>
                  <option value="rights-holder">I am the rights-holder</option><option value="authorised agent">I am authorised to act for the rights-holder</option>
                </select></div>
              <div className="field"><label htmlFor={`cw-${targetId}`}>Which work is affected, and how?</label><textarea id={`cw-${targetId}`} required value={claim.original_work} onChange={(e) => setClaim({ ...claim, original_work: e.target.value })} /></div>
              <label className="check"><input type="checkbox" checked={claim.good_faith_statement} onChange={(e) => setClaim({ ...claim, good_faith_statement: e.target.checked })} /> I believe in good faith that this use is not authorised by the rights-holder or the law.</label>
              <label className="check"><input type="checkbox" checked={claim.accuracy_statement} onChange={(e) => setClaim({ ...claim, accuracy_statement: e.target.checked })} /> The information in this complaint is accurate.</label>
            </fieldset>
          ) : null}
          <div className="field"><label htmlFor={`d-${targetId}`}>Details (optional)</label><textarea id={`d-${targetId}`} value={details} onChange={(e) => setDetails(e.target.value)} maxLength={4000} /></div>
          {status ? <p role="status" className="notice">{status}</p> : null}
          <div className="row">
            <button type="submit" className="btn-primary">Send report</button>
            <button type="button" onClick={() => ref.current?.close()}>Close</button>
          </div>
        </form>
      </dialog>
    </>
  );
}
