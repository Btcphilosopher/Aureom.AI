# Third-party software licences

COMMONWAVE's own source code is licensed under **AGPL-3.0-or-later** (see `LICENSE`).
This file lists the third-party software it depends on. It was generated on 2026-11-27 from the
locked dependency sets (`backend/requirements.lock.txt`, `web/package-lock.json`) using
`pip-licenses` and the npm lockfile metadata. Regenerate it before every release (see
`docs/operators.md#dependency-and-licence-review`).

These licences are compatible with distributing COMMONWAVE under the AGPL. Points to note:

* **psycopg / psycopg-binary (LGPL-3.0)**: used as an unmodified, dynamically imported library.
* **FFmpeg** is not bundled in this repository. The Docker image installs Debian's `ffmpeg`
  package, which is built with GPL components (including libmp3lame (LGPL) and x264 (GPL)). Operators
  who redistribute the image distribute FFmpeg under its licence terms. COMMONWAVE invokes
  the `ffmpeg`/`ffprobe` executables as separate programs and does not link them.
* **sharp / libvips (Apache-2.0 / LGPL-3.0)** are optional Next.js image-optimisation packages
  pulled in by npm. COMMONWAVE serves its own pre-processed artwork and does not use them.
* **caniuse-lite (CC-BY-4.0)** is browser-support data used at build time.
* **Container images** carry their own licences: `postgres` (PostgreSQL Licence), `valkey/valkey`
  (BSD-3-Clause; a Redis-protocol server, used through the MIT-licensed `redis` Python client),
  `chrislusf/seaweedfs` (Apache-2.0), `python` and `node` (PSF / MIT plus Debian/Alpine packages).
  The cache is optional; without it COMMONWAVE falls back to bounded in-process limits.
* **No fonts** are bundled. The interface uses the visitor's system fonts.

## Python runtime dependencies (direct, locked)

| Name              | Version | License                                            | URL                                                         |
|-------------------|---------|----------------------------------------------------|-------------------------------------------------------------|
| SQLAlchemy        | 2.1.9   | MIT                                                | https://www.sqlalchemy.org                                  |
| alembic           | 1.20.1  | MIT                                                | https://alembic.sqlalchemy.org                              |
| argon2-cffi       | 25.1.0  | MIT                                                | https://github.com/hynek/argon2-cffi/blob/main/CHANGELOG.md |
| boto3             | 1.44.12 | Apache-2.0                                         | https://github.com/boto/boto3                               |
| email-validator   | 2.4.0   | The Unlicense (Unlicense)                          | https://github.com/JoshData/python-email-validator          |
| fastapi           | 0.165.0 | MIT                                                | https://github.com/fastapi/fastapi                          |
| nh3               | 0.3.8   | MIT                                                | UNKNOWN                                                     |
| numpy             | 2.5.5   | BSD-3-Clause AND 0BSD AND MIT AND Zlib AND CC0-1.0 | https://numpy.org                                           |
| pillow            | 13.0.0  | MIT-CMU                                            | https://python-pillow.org                                   |
| psycopg           | 3.3.9   | LGPL-3.0-only                                      | https://psycopg.org/                                        |
| psycopg-binary    | 3.3.9   | LGPL-3.0-only                                      | https://psycopg.org/                                        |
| pydantic          | 2.14.4  | MIT                                                | https://github.com/pydantic/pydantic                        |
| pydantic-settings | 2.16.3  | MIT                                                | https://github.com/pydantic/pydantic-settings               |
| python-multipart  | 0.0.34  | Apache-2.0                                         | https://github.com/Kludex/python-multipart                  |
| redis             | 8.2.0   | MIT                                                | https://github.com/redis/redis-py                           |
| starlette         | 1.10.0  | BSD-3-Clause                                       | https://github.com/Kludex/starlette                         |
| uvicorn           | 0.54.0  | BSD-3-Clause                                       | https://uvicorn.dev/                                        |

Transitive Python dependencies (installed by the above) include: annotated-types, anyio, botocore,
cffi, argon2-cffi-bindings, click, dnspython, h11, httptools, idna, jmespath, Mako, MarkupSafe,
python-dateutil, python-dotenv, PyYAML, s3transfer, six, sniffio, typing-extensions,
typing-inspection, urllib3, uvloop, watchfiles, websockets. All are under MIT, BSD, Apache-2.0,
PSF or ISC licences (verified with `pip-licenses` in the reference environment).

Development-only tools (not shipped in images): pytest (MIT), httpx (BSD-3-Clause), moto (Apache-2.0),
pip-licenses (MIT), vitest (MIT), TypeScript (Apache-2.0), Playwright (Apache-2.0, used by the demo script).

## JavaScript dependencies (web, from package-lock.json)

| Package | Version | Licence | Scope |
|---|---|---|---|
| @emnapi/runtime | 1.11.3 | MIT | runtime (optional) |
| @img/colour | 1.1.0 | MIT | runtime (optional) |
| @img/sharp-darwin-arm64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-darwin-x64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-freebsd-wasm32 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-libvips-darwin-arm64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-darwin-x64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linux-arm | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linux-arm64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linux-ppc64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linux-riscv64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linux-s390x | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linux-x64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linuxmusl-arm64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-libvips-linuxmusl-x64 | 1.3.4 | LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-linux-arm | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linux-arm64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linux-ppc64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linux-riscv64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linux-s390x | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linux-x64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linuxmusl-arm64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-linuxmusl-x64 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-wasm32 | 0.35.5 | Apache-2.0 AND LGPL-3.0-or-later AND MIT | runtime (optional) |
| @img/sharp-webcontainers-wasm32 | 0.35.5 | Apache-2.0 | runtime (optional) |
| @img/sharp-win32-arm64 | 0.35.5 | Apache-2.0 AND LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-win32-ia32 | 0.35.5 | Apache-2.0 AND LGPL-3.0-or-later | runtime (optional) |
| @img/sharp-win32-x64 | 0.35.5 | Apache-2.0 AND LGPL-3.0-or-later | runtime (optional) |
| @jridgewell/resolve-uri | 3.1.3 | MIT | dev |
| @jridgewell/sourcemap-codec | 1.6.0 | MIT | dev |
| @jridgewell/trace-mapping | 0.3.31 | MIT | dev |
| @next/env | 16.4.6 | MIT | runtime |
| @next/swc-darwin-arm64 | 16.4.6 | MIT | runtime (optional) |
| @next/swc-darwin-x64 | 16.4.6 | MIT | runtime (optional) |
| @next/swc-linux-arm64-gnu | 16.4.6 | MIT | runtime (optional) |
| @next/swc-linux-arm64-musl | 16.4.6 | MIT | runtime (optional) |
| @next/swc-linux-x64-gnu | 16.4.6 | MIT | runtime (optional) |
| @next/swc-linux-x64-musl | 16.4.6 | MIT | runtime (optional) |
| @next/swc-win32-arm64-msvc | 16.4.6 | MIT | runtime (optional) |
| @next/swc-win32-x64-msvc | 16.4.6 | MIT | runtime (optional) |
| @oxc-project/types | 0.160.0 | MIT | dev |
| @rolldown/binding-android-arm-eabi | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-android-arm64 | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-darwin-arm64 | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-darwin-x64 | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-freebsd-x64 | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-arm-gnueabihf | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-arm64-gnu | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-arm64-musl | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-ppc64-gnu | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-s390x-gnu | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-x64-gnu | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-linux-x64-musl | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-openharmony-arm64 | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-wasm32-wasi | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-win32-arm64-msvc | 1.3.4 | MIT | dev (optional) |
| @rolldown/binding-win32-x64-msvc | 1.3.4 | MIT | dev (optional) |
| @rolldown/pluginutils | 1.1.1 | MIT | dev |
| @swc/helpers | 0.5.23 | Apache-2.0 | runtime |
| @types/chai | 5.2.3 | MIT | dev |
| @types/deep-eql | 4.0.2 | MIT | dev |
| @types/estree | 1.0.11 | MIT | dev |
| @types/node | 22.20.7 | MIT | dev |
| @types/react | 19.3.3 | MIT | dev |
| @types/react-dom | 19.3.0 | MIT | dev |
| @vitest/mocker | 5.1.2 | MIT | dev |
| @vitest/spy | 5.1.2 | MIT | dev |
| assertion-error | 2.0.1 | MIT | dev |
| baseline-browser-mapping | 2.11.40 | Apache-2.0 | runtime |
| caniuse-lite | 1.0.30001828 | CC-BY-4.0 | runtime |
| chai | 6.3.0 | MIT | dev |
| client-only | 0.0.1 | MIT | runtime |
| csstype | 3.2.4 | MIT | dev |
| detect-libc | 2.1.2 | Apache-2.0 | runtime |
| es-module-lexer | 2.3.2 | MIT | dev |
| estree-walker | 3.0.3 | MIT | dev |
| expect-type | 1.4.0 | Apache-2.0 | dev |
| fdir | 6.5.0 | MIT | dev |
| fsevents | 2.3.3 | MIT | dev (optional) |
| lightningcss | 1.33.0 | MPL-2.0 | dev |
| lightningcss-android-arm64 | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-darwin-arm64 | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-darwin-x64 | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-freebsd-x64 | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-linux-arm-gnueabihf | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-linux-arm64-gnu | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-linux-arm64-musl | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-linux-x64-gnu | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-linux-x64-musl | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-win32-arm64-msvc | 1.33.0 | MPL-2.0 | dev (optional) |
| lightningcss-win32-x64-msvc | 1.33.0 | MPL-2.0 | dev (optional) |
| magic-string | 1.4.5 | MIT | dev |
| nanoid | 3.3.20 | MIT | runtime |
| napi-windows-process-start-time | 0.1.0 | MIT | dev (optional) |
| next | 16.4.6 | MIT | runtime |
| obug | 3.0.0 | MIT | dev |
| picocolors | 1.1.1 | ISC | runtime |
| picomatch | 4.0.7 | MIT | dev |
| postcss | 8.5.23 | MIT | runtime |
| postcss | 8.5.33 | MIT | dev |
| react | 19.3.1 | MIT | runtime |
| react-dom | 19.3.1 | MIT | runtime |
| rolldown | 1.3.4 | MIT | dev |
| scheduler | 0.28.0 | MIT | runtime |
| semver | 7.8.6 | ISC | runtime (optional) |
| sharp | 0.35.5 | Apache-2.0 | runtime (optional) |
| source-map-js | 1.2.4 | BSD-3-Clause | runtime |
| std-env | 4.3.0 | MIT | dev |
| styled-jsx | 5.1.6 | MIT | runtime |
| tinybench | 6.2.5 | MIT | dev |
| tinyexec | 1.4.0 | MIT | dev |
| tinyglobby | 0.2.17 | MIT | dev |
| tslib | 2.9.1 | 0BSD | runtime |
| typescript | 5.9.3 | Apache-2.0 | dev |
| undici-types | 6.21.0 | MIT | dev |
| vite | 8.4.0 | MIT | dev |
| vitest | 5.1.2 | MIT | dev |
| why-is-node-running | 3.2.1 | MIT | dev |
