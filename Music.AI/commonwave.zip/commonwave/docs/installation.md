# Installation

## Requirements

* Docker Engine 24+ with the Compose v2 plugin, **or** for a manual install: Python 3.12+, PostgreSQL 16, FFmpeg (with `libmp3lame`), Node.js 20.9+, an S3-compatible object store or a local disk, and optionally Valkey or Redis.
* A reverse proxy that terminates HTTPS (Caddy, nginx, Traefik) for any public deployment.

## Docker Compose

```bash
git clone <your fork> commonwave && cd commonwave
./scripts/init-env.sh                 # random POSTGRES_PASSWORD, CW_SECRET_KEY, S3 keys → .env, deploy/seaweedfs/s3.json
$EDITOR .env                          # set CW_PUBLIC_BASE_URL, CW_BOOTSTRAP_ADMIN_EMAIL, CW_SOURCE_URL; CW_ENVIRONMENT=development + CW_COOKIE_SECURE=false only for a local http trial
docker compose up -d --build
docker compose logs -f migrate api worker
```

Open the web container's port (3000 by default). Register with the `CW_BOOTSTRAP_ADMIN_EMAIL` address: the first account with that email becomes the administrator.

Services:

| Service | Image | Network | Purpose |
|---|---|---|---|
| `db` | postgres:16.16-alpine | backend (internal) | Catalogue, accounts, jobs, analytics |
| `redis` | valkey/valkey:8.1-alpine | backend | Bounded cache, rate-limit counters, worker wake-ups (optional) |
| `s3` | chrislusf/seaweedfs:4.55 | backend | S3-compatible private object storage |
| `migrate` | built from `backend/` | backend | `alembic upgrade head`, then exits |
| `api` | built from `backend/` | backend + frontend | FastAPI |
| `worker` | built from `backend/` | backend only, **no internet egress** | Audio processing, archives, exports |
| `web` | built from `web/` | frontend, published port | Next.js; proxies `/api` and `/media` to `api` |

The `backend` network is `internal: true`, so the worker and FFmpeg cannot reach the internet. The worker container is read-only, drops all Linux capabilities, sets `no-new-privileges` and has CPU and memory limits.

Demo data (optional; never on a real server): `docker compose --profile demo run --rm seed`.

### HTTPS reverse proxy example (Caddy)

```
music.example.org {
    encode zstd gzip
    request_body { max_size 600MB }
    reverse_proxy web:3000 {
        # Overwrite (never append to) any client-supplied value: rate limits and
        # anonymous listener keys are derived from this address.
        header_up X-Forwarded-For {remote_host}
    }
}
```

The API trusts `X-Forwarded-For` from the web container (`--forwarded-allow-ips "*"` inside the private network), and Next.js passes the header on unchanged. Your edge proxy **must** overwrite it with the real client address, as shown above. Otherwise clients could choose their own rate-limit key.

Uploads use resumable 2 MB chunks by default, so the proxy body limit only needs to exceed one chunk. Keep it generous anyway.

## Manual install (no Docker)

```bash
cd backend
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.lock.txt && pip install -e .
export CW_DATABASE_URL=postgresql+psycopg://commonwave:...@localhost/commonwave CW_SECRET_KEY=... CW_ENVIRONMENT=production CW_COOKIE_SECURE=true
alembic upgrade head
uvicorn commonwave.main:app --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips 127.0.0.1
python -m commonwave.worker          # run as a separate systemd service; several may run in parallel

cd ../web && npm ci && CW_API_ORIGIN=http://127.0.0.1:8000 npm run build && npm start
```

Run the worker as an unprivileged user with no outbound network access (for example systemd `IPAddressDeny=any` plus `IPAddressAllow=` for the database and object store). With `CW_PROCESSING_NETWORK_ISOLATION=auto`, FFmpeg also runs inside an empty network namespace when the kernel allows `unshare -n`.

## Upgrading

```bash
python -m commonwave.ops backup /backups/$(date +%F)   # always back up first
docker compose pull && docker compose up -d --build    # migrate runs automatically
```
