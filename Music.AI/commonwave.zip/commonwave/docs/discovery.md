# Discovery and ranking

Discovery is deterministic, explainable and replaceable (`modules/discovery/ranking.py` implements a `Ranker` protocol; swap it with `set_ranker`).

## Default feed (identical for everyone, non-personalised)

* **Latest releases** and **New tracks**: newest publication first.
* **Editorial collections**: chosen by staff and labelled as such. Not ranked by plays.
* **Popular this fortnight**: see below.
* **New voices**: artists whose *first* publication was in the last 60 days, newest first. Exposure here doesn't depend on any play count.
* **Recently active artists**: by latest publication.
* **Genres** and **tags**: browse pages sorted by latest, or popular within the genre.

## Popular tracks: the published rule

* Window: last **14 days** only, so early success does not lock in rank forever.
* Signal: **distinct listeners** with a qualified listen (not raw plays), plus distinct users who saved the track (×2) and distinct downloaders (×1).
* Each listener's contribution decays with a **7-day half-life**.
* Excluded: sessions flagged as automated, artist previews, and listens by the artist's own members.
* A track needs **≥ 3 distinct listeners** to appear. **At most 2 tracks per artist** are listed.
* This is abuse-*resistant*, not abuse-proof. Anonymous listener keys rotate daily and are derived from IP and user agent, so a determined actor with many IPs can still inflate counts. Operators should watch for anomalies.

## Search

PostgreSQL full-text search over tracks, releases and artists (`tsvector` columns with GIN indexes, `simple` configuration so it doesn't stem in favour of one language). Weighting: title and artist name A, genre and tags B, location C, description D. Free text is reduced to word characters and turned into a prefix query, so search operators can't be injected. Drafts, withdrawn, restricted and suspended content never appears.

## Personalisation (opt-in)

Personalisation is off by default. When a user turns it on in Settings, Discover offers a **For you** shelf built only from artists they follow and genres they chose explicitly. Listening history is private, can be switched off (which deletes it), and is not used by the default ranker. The shelf explains why each item is shown.
