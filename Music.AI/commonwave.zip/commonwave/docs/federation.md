# Federation (extension boundary only)

COMMONWAVE **does not federate**. It makes no claim of decentralisation or cross-server compatibility.

What exists:

* `commonwave/modules/federation/__init__.py` defines `FederationPublisher` (`track_published`, `track_withdrawn`, `artist_updated`) and a no-op default. Catalogue events are the intended hook points.
* `GET /.well-known/commonwave` reports `"federation": {"enabled": false}`.

Requirements before claiming federation:

1. A chosen protocol (for example ActivityPub with a music vocabulary) and a written specification of objects, addressing and signatures.
2. Withdrawal and moderation semantics across servers, including what can and cannot be recalled.
3. Rights metadata travels with every object, and remote servers must not present remote ARR tracks as reusable.
4. Interoperability tests against at least one independent implementation.
5. Abuse controls: instance blocking, rate limits, and signature verification.
