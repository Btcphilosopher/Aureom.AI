# Rights and licensing

## Three separate licence layers

1. **Software** — COMMONWAVE's code: AGPL-3.0-or-later.
2. **Uploaded works** — each track's recording and composition: whatever the uploader declares (All rights reserved by default).
3. **Other assets** — artwork, text and the demo media each have their own terms (see `ASSETS-LICENSE.md`).

The UI never describes uploads as "open source", "copyright free" or "free to reuse". It names the declared licence on each track and release.

## Supported choices (`modules/rights/licences.py`)

| Code | Meaning | Reuse allowed |
|---|---|---|
| `ARR` | All rights reserved; streaming through the platform permitted | No |
| `CC-BY-4.0`, `CC-BY-SA-4.0`, `CC-BY-NC-4.0`, `CC-BY-NC-SA-4.0`, `CC-BY-ND-4.0`, `CC-BY-NC-ND-4.0` | Creative Commons 4.0 International | Yes, under the licence terms |
| `CC0-1.0` | Public-domain dedication (only for work the uploader fully owns) | Yes |
| `PDM-1.0` | Public Domain Mark (only for recordings already in the public domain; varies by country) | Yes |

## What each declaration records

The licence code, version and URL, attribution text, **recording origin** (original, cover, remix, contains samples, public-domain recording), **composition origin** (original, licensed cover, public domain, other), details for covers, samples and remixes, source notes, the confirmations given (with the statement version), who declared it and when. Declarations are **append-only**: a change creates a new row and marks the old one superseded, so the full history appears in exports and in the moderation view.

Consistency rules enforced by the API:

* A cover must have a licensed or public-domain composition, with details.
* Samples and remixes require details of the clearance or permission.
* CC0 requires an original recording and an original or public-domain composition.
* The Public Domain Mark requires a public-domain recording.
* Open licences can't be applied to covers, remixes or sample-based tracks (by default these involve rights the uploader doesn't hold).
* Open licences require acknowledging that they can't be revoked for copies already obtained.

Every declaration is labelled `self_declared`. **COMMONWAVE does not verify ownership**, and the UI says so wherever a licence is shown.

## Downloads are separate from streaming

Streaming is always free for published tracks. Each track has independent `download_mp3` and `download_original` switches. Release archives require MP3 downloads on every track, and can optionally ask for a pay-what-you-want price. Download pages show the format, approximate size, licence and attribution.

## Withdrawal

Withdrawing stops streaming and new downloads at once, including stream links already issued. It cannot recall files people have already downloaded, and it does not revoke rights already granted under CC or CC0 for copies obtained while those terms applied. The artist sees this notice before withdrawing, and when they change an open licence to a more restrictive one.
