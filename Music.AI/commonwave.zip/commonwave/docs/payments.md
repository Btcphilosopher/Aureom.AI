# Optional artist support

The initial release is free to listen to and free to publish on. Support features are optional (`CW_SUPPORT_ENABLED`, plus the runtime toggle in Admin → Configuration).

| Feature | Status |
|---|---|
| External support link on the artist profile | **Implemented.** COMMONWAVE takes no cut. |
| One-time tips | **Simulated.** No money moves. |
| Pay-what-you-want release downloads (with an optional minimum, including zero) | **Simulated.** |
| Lightning Network | **Deferred.** Interface documented only. |
| Platform token | **Not planned.** Nobody needs a token to take part. |

## Separation of concerns

* `payment_intents`: purchase or tip attempts (integer minor units, currency, explicit platform and provider fees, an idempotency key unique per payer).
* `provider_events`: processed webhook event IDs, so fulfilment is idempotent.
* `download_entitlements`: the right to download a release, unique per user and release, linked to the intent.
* `payout_ledger`: what the artist is owed (gross, fees, net), one row per settled intent.

## Simulated provider

`SimulatedProvider` creates a local checkout page and, when "paid", builds an **HMAC-signed webhook event** that goes through the same `handle_webhook` path a real provider would use: signature check → event-ID de-duplication → row lock on the intent → state transition → idempotent fulfilment. The tests cover bad signatures, duplicate deliveries and repeated settlement.

Fees are shown before paying: platform fee `CW_PLATFORM_FEE_BPS` (0 by default) and simulated provider fee `2.9 % + 0.30`.

## Adding a real provider

Implement the `PaymentProvider` protocol (`create_checkout`, `verify_webhook`), keep amounts as integers, verify settlement server-side (never trust the browser redirect), and reconcile `payout_ledger` against provider reports. Real payments bring consumer-protection, tax, anti-money-laundering and data-protection obligations. Research them for your jurisdiction first.

### Lightning (deferred)

`LightningProvider` documents the contract: integer satoshis (`SAT`), invoices from a maintained node or provider SDK, settlement confirmed by the provider and never by the client, routing and provider fees recorded explicitly, and fulfilment idempotent on the payment hash.
