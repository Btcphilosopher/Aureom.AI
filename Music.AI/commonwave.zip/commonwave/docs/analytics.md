# Playback analytics

Client-reported events are **untrusted**. The server derives every counted number and bounds it by real time.

## Events

The player sends `start`, `progress` (every 15 s and before a seek), `pause`, `seek`, `end` and `stall`, each with a per-session sequence number. Requests must carry an HMAC `session_token` issued with the session.

## Processing rules (`modules/playback/router.py`)

* **Duplicates**: `(session, seq)` is unique, so retried batches are ignored and counted as duplicates.
* **Out-of-order** events are stored but never credited.
* **Credit**: forward position movement while playing, at most 5 minutes per event. Seeks credit nothing. Positions are clamped to the track length.
* **Wall-clock bound**: total credited time ≤ (time since start × 2, the maximum playback speed) + 5 s. A client can't claim a whole track instantly.
* **Background tabs**: heartbeats may be throttled; the next event credits the actual movement within the wall-clock bound. A `progress` event is also sent when the page is hidden.
* **Loops**: each repeat starts a new session, so it is a separate listen.
* **Automation**: sessions with no user agent, a known bot or tool user agent, or more than 120 sessions per hour from one listener key are flagged and excluded from every statistic.

## Published definitions

| Metric | Definition |
|---|---|
| Playback request | A playback session created (stream URL issued). |
| Playback start | A session that reported `start`. |
| **Qualified listen** | Server-credited playback ≥ min(30 s, 50 % of duration); not automated, not a preview; at most one per listener key per track per 30 minutes. |
| Listening duration | Sum of credited milliseconds. |
| Completion | An `end` within 3 s of the end after at least half the track was credited (skipping to the end doesn't count). |
| Unique listeners | Distinct pseudonymous listener keys with a qualified listen (anonymous keys rotate daily, so returning anonymous listeners are over-counted). |
| Downloads | Granted download records, counted **separately** from plays. |
| Saves, follows | Rows created in the window. |

## Privacy

Artists receive aggregated totals, per-track totals and a daily series. They never see who listened. Unique-listener counts between 1 and 4 are shown as "<5". Signed-in users' private history (`listen_history`) is written only when history is enabled. It is visible only to that user and deletable.

These counts are best-effort and **not fraud-proof**.
