# Operator guide

## Configuration reference

All settings are environment variables. Production refuses to start with the development secret or with `CW_COOKIE_SECURE=false`.

| Variable | Default |
|---|---|
| `CW_ENVIRONMENT` | `development` |
| `CW_SITE_NAME` | `COMMONWAVE` |
| `CW_PUBLIC_BASE_URL` | `http://localhost:3000` |
| `CW_DATABASE_URL` | `postgresql+psycopg://commonwave:commonwave@localhost:5432/commonwave` |
| `CW_REDIS_URL` | `redis://localhost:6379/0` |
| `CW_SECRET_KEY` | `(dev placeholder — must be set)` |
| `CW_SESSION_COOKIE_NAME` | `cw_session` |
| `CW_SESSION_TTL_HOURS` | `336` |
| `CW_COOKIE_SECURE` | `False` |
| `CW_STORAGE_BACKEND` | `local` |
| `CW_STORAGE_LOCAL_ROOT` | `var/storage` |
| `CW_S3_ENDPOINT_URL` | `None` |
| `CW_S3_REGION` | `us-east-1` |
| `CW_S3_ACCESS_KEY_ID` | `None` |
| `CW_S3_SECRET_ACCESS_KEY` | `None` |
| `CW_S3_BUCKET` | `commonwave-media` |
| `CW_UPLOAD_STAGING_DIR` | `var/staging` |
| `CW_MAX_UPLOAD_BYTES` | `524288000` |
| `CW_MAX_TRACK_DURATION_SECONDS` | `1800` |
| `CW_UPLOAD_EXPIRY_HOURS` | `24` |
| `CW_MAX_ACTIVE_UPLOADS_PER_USER` | `5` |
| `CW_DEFAULT_ARTIST_STORAGE_QUOTA_BYTES` | `5368709120` |
| `CW_MAX_ARTWORK_BYTES` | `10485760` |
| `CW_FFMPEG_PATH` | `ffmpeg` |
| `CW_FFPROBE_PATH` | `ffprobe` |
| `CW_PROCESSING_TIMEOUT_SECONDS` | `600` |
| `CW_PROCESSING_CPU_SECONDS` | `900` |
| `CW_PROCESSING_MEMORY_BYTES` | `1073741824` |
| `CW_PROCESSING_MAX_OUTPUT_BYTES` | `1073741824` |
| `CW_PROCESSING_WORK_DIR` | `var/work` |
| `CW_STREAM_BITRATE_KBPS` | `192` |
| `CW_LOUDNESS_TARGET_LUFS` | `-14.0` |
| `CW_HLS_ENABLED` | `False` |
| `CW_PROCESSING_NETWORK_ISOLATION` | `auto` |
| `CW_STREAM_URL_TTL_SECONDS` | `900` |
| `CW_DOWNLOAD_URL_TTL_SECONDS` | `600` |
| `CW_QUALIFIED_LISTEN_SECONDS` | `30` |
| `CW_QUALIFIED_LISTEN_FRACTION_SHORT` | `0.5` |
| `CW_RATE_LIMIT_ENABLED` | `True` |
| `CW_SUPPORT_ENABLED` | `True` |
| `CW_PAYMENT_PROVIDER` | `simulated` |
| `CW_PLATFORM_FEE_BPS` | `0` |
| `CW_SIMULATED_PROVIDER_FEE_BPS` | `290` |
| `CW_SIMULATED_PROVIDER_FIXED_FEE_MINOR` | `30` |
| `CW_BOOTSTRAP_ADMIN_EMAIL` | `None` |
| `CW_WORKER_POLL_SECONDS` | `2.0` |

Community features (comments, timestamped comments, pre-moderation, new-account comment holds, reports, public playlists, the support module, downloads, comment length and link limits) are changed at runtime in **Admin → Configuration** and stored in the `site_config` table.

## Quotas, limits and fair use

| Control | Where | Default |
|---|---|---|
| Max file size per upload | `CW_MAX_UPLOAD_BYTES` | 500 MB |
| Max track duration | `CW_MAX_TRACK_DURATION_SECONDS` | 30 min |
| Storage per artist | `CW_DEFAULT_ARTIST_STORAGE_QUOTA_BYTES`, per-artist override in Admin → Artists | 5 GB |
| Concurrent unfinished uploads per user | `CW_MAX_ACTIVE_UPLOADS_PER_USER` | 5 |
| Upload expiry | `CW_UPLOAD_EXPIRY_HOURS` | 24 h |
| FFmpeg wall time / CPU / memory / output size | `CW_PROCESSING_*` | 600 s / 900 s / 1 GiB / 1 GiB |
| Request rate limits | `core/ratelimit.py` `LIMITS` | e.g. 20 comments per 10 min, 30 upload sessions per hour |

Quota usage counts originals, streaming derivatives and in-progress uploads. Release archives and exports are excluded. Publish a fair-use policy that explains these numbers to artists.

## Moderation procedures

Moderators work in **Admin → Reports / Appeals / Held comments**. Every decision records the moderator, a reason shown to the affected person, an optional policy reference, and the report it resolves.

1. **Triage.** Rights complaints come first (priority 2). Check the report target, its decision history, and the reporter's details.
2. **Immediate visibility restriction.** `restrict_track`, `restrict_release`, `hide_comment`, `restrict_artist` and `restrict_user` (temporary, with an expiry) take effect at once and are fully reversible. Signed stream URLs that were already issued stop working on the next request.
3. **Withdrawal.** `withdraw_track` takes a track out of public view the same way an artist withdrawal does.
4. **Suspension.** `suspend_user` ends the user's sessions and blocks login. `suspend_artist` hides the profile and all its music. Members keep export access.
5. **Permanent deletion** (`delete_track_permanently`) is **admin-only and irreversible**. It deletes the stored audio but keeps the metadata row and decision history for accountability. Use it only for legal orders or clearly illegal material.
6. **Appeals.** The affected user, or an artist's owners and managers, can appeal each decision once from Settings. A moderator *other than the one who decided* must review it. Reversing an appeal automatically applies the opposite action and links the two records.
7. **Rights complaints are claims, not proof.** Restrict while you investigate if the claim is credible, ask the artist for their side through your usual channel, and record the outcome. Automated audio matching, if you ever add it, must only rank or flag items for human review. Never treat a match as proof of infringement or ownership.

### Jurisdiction-specific procedures

COMMONWAVE provides the mechanics: reports with claimant statements, restrictions, counter-statements via appeals, and an audit trail. It does **not** implement any specific statutory process. Before operating publicly, research current official sources for your jurisdictions and write down your procedures, for example:

* copyright notice-and-action regimes and any counter-notice or put-back timelines (e.g. US DMCA §512, EU Digital Services Act and DSM Directive Art. 17, UK and other national laws)
* platform transparency and statement-of-reasons duties (e.g. DSA Articles 16, 17 and 20 for notice handling and internal complaints)
* privacy law (GDPR / UK GDPR, CCPA and others): lawful basis, retention periods, data-subject requests (the user and artist exports support access and portability)
* accessibility (e.g. EN 301 549 / WCAG 2.2 AA expectations, the European Accessibility Act)
* consumer and payments law, if you enable real payments
* age requirements and the handling of explicit content

Take advice from a lawyer licensed in your jurisdictions. Nothing in this repository is legal advice.

## Artist verification

The **Verified** badge appears only when an administrator records how identity or affiliation was confirmed (Admin → Artists → Verify…). The method text is shown on the artist page. Acceptable evidence includes a link to the COMMONWAVE profile from an official website or account the artist demonstrably controls, or a documented check by a label or collecting society you trust. Never verify on the artist's word alone. Verification says nothing about who owns any particular recording.

## Backups and restoration

```bash
python -m commonwave.ops backup /backups/2026-11-27     # pg_dump (custom format) + every referenced object + manifest with SHA-256
python -m commonwave.ops verify                         # every DB-referenced object exists; stored hashes match
python -m commonwave.ops restore /backups/2026-11-27    # into an EMPTY database and bucket
```

In Docker Compose: `docker compose run --rm -v /backups:/backups api python -m commonwave.ops backup /backups/$(date +%F)`.

* The database is the source of truth for which objects exist, so backups work the same for local and S3 storage. Objects with a recorded SHA-256 are checked before restore.
* Schedule daily backups, keep copies off-site, encrypt them (they contain email addresses and private originals), and **test restoration** regularly. The automated test `tests/test_backup_restore.py` performs a full round trip.
* Uploads in progress (staging files) are not backed up. Clients resume or start again.
* Point-in-time recovery: if you need it, enable PostgreSQL WAL archiving as well.

## Data export

* Artists: Studio → Export builds a ZIP of original uploads (byte-for-byte), artwork, metadata, full rights-declaration history and aggregated statistics. The download link is signed, short-lived and bound to the requester.
* Listeners: Settings → Download my data returns JSON with their account, playlists, follows, saves, comments and listening history.

## Monitoring

* `GET /healthz` checks the database connection.
* Watch the `jobs` table (Admin → Jobs) for failures. Media failures are permanent (with diagnostics shown to the artist). Infrastructure failures retry with exponential backoff, and a job locked for more than 30 minutes is re-queued.
* Logs redact cookies, signatures, tokens, passwords, database credentials and email addresses.

## Scaling notes

The modular monolith scales horizontally: run several `api` replicas (stateless) and several workers (jobs are claimed with `FOR UPDATE SKIP LOCKED`). Media is served through the API with Range support. For larger installs, put a caching CDN in front of `/media/stream/*`; URLs are signed and short-lived, so cache by path and pass query strings through. Bandwidth is usually the dominant cost (see `docs/funding.md`).

## Dependency and licence review

Before each release: update `backend/requirements.lock.txt` and `web/package-lock.json`, run the full test suite and `npm run build`, regenerate `THIRD_PARTY_LICENSES.md` (`pip-licenses`, npm lockfile), and check that every licence is compatible with AGPL distribution. FFmpeg codec support is checked at runtime: the worker needs `libmp3lame` (`ffmpeg -encoders | grep mp3lame`).
