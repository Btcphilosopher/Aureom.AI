# Architecture

COMMONWAVE is a **modular monolith**: one FastAPI process, separate worker processes, and one PostgreSQL database. It is split into modules with clear ownership.

```
 browser ──► web (Next.js) ──/api, /media──► api (FastAPI) ──► PostgreSQL
                                               │   │
                                               │   └──► object storage (local dir or S3: SeaweedFS/Garage/Ceph/AWS)
                                               │
                                               └──► Valkey/Redis (optional: rate limits, bounded cache, job wake-ups)
                  worker(s) ◄── jobs table (FOR UPDATE SKIP LOCKED) ──► FFmpeg adapter (sandboxed subprocess)
```

## Modules (`backend/commonwave/modules/`)

| Module | Owns |
|---|---|
| `identity` | users, sessions, artist profiles, band memberships and roles, follows |
| `catalogue` | tracks, versions, releases, artwork, publication and withdrawal, artist dashboard |
| `uploads` | tus 1.0 resumable uploads, content sniffing, quota checks |
| `processing` | job queue, constrained FFmpeg adapter, processing pipeline |
| `playback` | playback sessions, event ingestion, signed media delivery with Range, downloads, release archives |
| `rights` | licence catalogue and explanations, append-only rights declarations |
| `discovery` | deterministic feeds, replaceable `Ranker`, PostgreSQL full-text search, genres, tags, collections |
| `community` | playlists, saves, library and history, comments, blocks |
| `moderation` | reports, rights complaints, actions, appeals, decision history |
| `admin` | site config, users, verification, quotas, jobs, editorial collections, audit log |
| `support` | external links, simulated tips and PWYW payments, entitlements, payout ledger |
| `analytics` | aggregated artist statistics |
| `exports` | artist export ZIP, user JSON export, job status |
| `federation` | extension interface only (no protocol implemented) |

Shared infrastructure lives in `core/`: database, settings, security (Argon2id, HMAC signing), dependencies (viewer, CSRF, permission matrix), storage, sanitisation, rate limiting, cache, logging redaction and audit.

## Identity vs artist vs works

* **User**: a login.
* **ArtistProfile**: a public artist, band or collective. **ArtistMembership** links users to it with a role: `owner` manages members; `manager` publishes, withdraws, sees stats and exports; `contributor` uploads and edits drafts.
* **Composition**: the song (writers, origin, ISWC).
* **Track**: the sound recording as presented on the platform. This is the stable identity referenced by playlists, comments, reports and saves.
* **TrackVersion**: one uploaded master. Replacements create new versions. The old one is kept with `replaced_at`, so playback sessions and moderation actions keep pointing at the exact audio involved.
* **AudioAsset**: a stored file (`original`, `stream_mp3`, `archive`, `export`).
* **Release** and **ReleaseTrack**: an album, EP, single or compilation, with ordered tracks.

## Track lifecycle

```
Version:  uploaded → validating → processing → ready ─┐     (failed, cancelled)
Track:    draft ─────────────────────────── publish ──┴→ published ⇄ withdrawn
Moderation flag (independent):  moderation_restricted = true/false
```

`is_public = status == published AND NOT moderation_restricted AND artist not suspended`. This is checked on every media request, not only when a URL is issued.

## Media delivery

1. `POST /api/v1/playback/sessions` authorises the track and returns `/media/stream/{asset}?exp=…&sig=…` (HMAC-SHA256, 15 minutes).
2. `GET /media/stream/{asset}` checks the signature, **re-checks publication**, and serves bytes from storage with `Accept-Ranges`, `206`/`416`, `If-Range` and `ETag`.
3. The player swaps in a fresh URL transparently when a URL expires (403 `expired`) and removes the track from the queue on 410 `unavailable`.

Originals are never streamable. They're only reachable through a `Download` record when the artist has enabled original downloads, and that permission is re-checked when the bytes are served.

## Processing pipeline

`uploads` content-sniffs the bytes (RIFF/RF64 WAVE, `fLaC`, or two consecutive valid MPEG Layer III frame headers after any ID3 tag), stores the original privately, and enqueues `process_version`. The worker then:

1. `ffprobe` validates the container and codec against the sniffed type, rejects non-audio streams, and enforces duration, sample-rate and channel limits.
2. Transcodes to CBR MP3 at 44.1 kHz, 192 kbps, **or the source bitrate if the upload is a lower-bitrate MP3** (never upsampled), with metadata stripped and a Xing header written.
3. Measures loudness (EBU R128 integrated LUFS and true peak) and derives a *player* gain. The file is never normalised.
4. Builds a 600-bucket peak waveform.
5. Writes human-readable diagnostics: lossy source, low sample rate, downmix, clipping risk.

HLS renditions are **deferred** (`CW_HLS_ENABLED` exists but does nothing yet). Progressive MP3 with Range support is the supported path.

## Frontend

Next.js App Router with client components. The root layout holds `AuthProvider` and `PlayerProvider`, so the `<audio>` element and queue survive navigation. The queue is a pure reducer (`web/lib/player/queue.ts`, unit-tested). Uploads use a small tus client with localStorage resume (`web/lib/tus.ts`).
