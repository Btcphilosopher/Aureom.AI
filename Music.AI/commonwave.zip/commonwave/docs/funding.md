# Funding a real deployment

The demo charges nobody. A real service has ongoing costs:

| Cost | Driver | Notes |
|---|---|---|
| Bandwidth | Streams: about 1.4 MB per minute at 192 kbps | Usually the largest cost. A CDN or caching proxy for `/media/stream` helps. |
| Storage | Originals (WAV is about 10 MB per minute) plus MP3 derivatives | Quotas and object-storage lifecycle policies |
| Compute | FFmpeg processing, API | Small; workers scale horizontally |
| Moderation | People | Budget for trained, paid or supported moderators and legal advice |
| Operations | Backups, monitoring, security updates | |

Sustainable models that keep listening free and need no token:

1. **Community membership and donations**, optional and never required to listen (Open Collective, a co-operative, a charity).
2. **Institutional hosting**: libraries, universities, arts councils and community radio running instances for their region or genre.
3. **Fair-use quotas with optional paid storage tiers** for heavy uploaders. Publishing stays free within the default quota.
4. **A transparent, optional platform fee** on tips and pay-what-you-want sales (`CW_PLATFORM_FEE_BPS`, shown at checkout; 0 by default).
5. **Grants** for public-interest digital infrastructure.
6. In future, **sharing hosting across independent servers**, but only once real federation exists.

Publish a yearly cost and income report so the community can see what keeps the commons running.
