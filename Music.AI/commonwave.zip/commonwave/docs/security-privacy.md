# Security and privacy

| Threat | Control |
|---|---|
| Password theft | Argon2id hashing; minimum 10 characters; rate-limited login |
| Session theft | 256-bit random tokens stored as SHA-256 digests; HttpOnly, SameSite=Lax, Secure in production; 14-day expiry; sessions deleted on suspension |
| CSRF | Double-submit token header required for every unsafe request with a session |
| Broken object-level authorisation | Every handler checks ownership or membership; private objects return 404; the permission matrix lives in `core/deps.py`; tests cover strangers, contributors, managers and anonymous visitors |
| Private originals leaking | Single private bucket, no public ACLs (a public-access block is applied where supported); no static route to storage; originals are never streamable; download permission is re-checked at fetch time |
| Hot-linking and stale links | HMAC-signed URLs, 15 min for streams and 10 min for downloads; publication re-checked on every request; export links bound to the requester's session |
| Malicious uploads | Content sniffing (extension ignored); ffprobe codec and container validation; size, duration and quota limits; artwork re-encoded with Pillow (EXIF stripped, pixel bomb limit) |
| Media-tool exploitation | Argument lists only (no shell); argument and path validation; only the configured binaries; `-protocol_whitelist file,pipe`; rlimits on CPU, memory, file size, open files and core dumps; wall-clock timeout that kills the process group; empty environment; per-job temp directory; optional `unshare -n`; worker container on an internal network, read-only, no capabilities |
| XSS / HTML injection | All user text stored as plain text (nh3 strips tags, control and bidi characters removed); React escapes on output; strict CSP (`default-src 'self'`, `frame-ancestors 'none'`); only http(s) links accepted |
| SQL injection | SQLAlchemy parameterised queries; full-text queries built from word characters only |
| Abuse and spam | Rate limits (Redis or bounded in-memory, keyed by user or by client IP; the edge proxy must overwrite `X-Forwarded-For`, see installation.md); comment link limits, duplicate detection, pre-moderation options; blocks; reports |
| Secrets in logs | Redacting log filter (signatures, tokens, cookies, passwords, DB credentials, emails); audit data strips secret-like keys |
| Accountability | `audit_log` for sign-ins, uploads, publishing, rights declarations, moderation, admin changes and exports; `moderation_actions` is append-only apart from reversal links |

## Privacy defaults

* No account needed to listen. Anonymous de-duplication uses a keyed hash of IP + user agent + date, which rotates daily, and raw IPs are not stored in analytics.
* Listening history is private, can be turned off (which deletes it), and is never shown to artists.
* Follow lists are not public; only counts are.
* Artists see aggregates only, with small numbers suppressed.
* Users can export their data (JSON). Artists can export everything they uploaded.

Before public operation, research current official guidance on copyright, privacy, consumer, accessibility and payments law for your jurisdictions (see `operators.md`).
