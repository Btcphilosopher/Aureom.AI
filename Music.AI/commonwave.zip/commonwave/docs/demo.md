# Demonstration walkthrough

Seed the fictional catalogue (`python -m commonwave.seed`, or `docker compose --profile demo run --rm seed`), then follow the steps below by hand, or run them automatically:

```bash
node scripts/e2e_demo.mjs http://localhost:3000 ./demo-output     # Playwright + Chromium; writes screenshots and results.json
```

Seeded data, all fictional and all original audio:

| Artist | Type | Release | Licence | Downloads |
|---|---|---|---|---|
| Marigold Static (owner `marigold`, manager `rowan`) | band | *Low Tide Radio* (EP, 3 tracks) | CC BY 4.0 | MP3 |
| Okonkwo Lane | solo | *Night Market Grid* (album, 3) | All rights reserved | none (streaming only) |
| The Quiet Cartographers | collective | *Field Notes* (album, 2) | CC BY-SA 4.0 | MP3 + original; release archive is pay-what-you-want (min $2, simulated) |
| Juniper & Ash (contributor `ash`) | band | *Paper Boats* (single) + a private draft | CC0 1.0 | MP3 + original |

Listener `listener` owns a public, an unlisted and a private playlist, follows two artists, and has saved a release. There is one editorial collection. **Play counts, followers and statistics start at zero.** Nothing is fabricated.

| # | Scenario | How | Automated check |
|---|---|---|---|
| 1 | Upload a track | Sign in as `marigold` → Upload → choose a WAV/FLAC/MP3 | `e2e_demo.mjs`, `test_core_flow.py` |
| 2 | Resume an interrupted upload | Pause, or lose the connection, mid-upload. The client asks the server for its offset (tus `HEAD`) and continues; after a reload, choose the same file again | the e2e script injects a connection reset mid-upload; `test_core_flow.py` sends a wrong offset (409) and resumes |
| 3 | Process audio and generate a waveform | The track editor shows Uploaded → Validating → Processing → Ready for review, technical metadata, loudness and diagnostics | e2e (waveform bars), `test_core_flow.py` (duration, codec, 192 kbps, LUFS, 600 peaks) |
| 4 | Add artwork, credits and a licence | Track editor: Details, Artwork, Rights & licence | e2e; `test_publication.py::test_rights_rules` |
| 5 | Preview and publish | "Preview (private)" plays a member-only signed stream; then "Publish track" | e2e; preview link refused for anonymous users in `test_core_flow.py` |
| 6 | Stream without signing in | Open any track signed out, press play | e2e; `test_core_flow.py` |
| 7 | Seek using range requests | Click or keyboard-seek the waveform; the browser issues `Range` requests answered with `206` | e2e counts 206 responses; `test_core_flow.py` checks `bytes=a-b`, `a-`, `-n`, 416 and HEAD |
| 8 | Follow the artist | Artist page → Follow | e2e; `test_exports_discovery.py` |
| 9 | Save the track to a playlist | Track page → Add to playlist | e2e; `test_playlists.py` |
| 10 | Download an authorised MP3 | Track page → Downloads (shows format, size, licence and attribution) | e2e; `test_support_downloads.py` |
| 11 | Deny access to a private original | Original-file download is refused unless enabled; the original's asset id can't be streamed even with a valid-looking signature | e2e (403/403); `test_private_files.py` |
| 12 | Report a comment | Comment → flag → Report; it appears in Admin → Reports for `modteam` | e2e; `test_moderation.py` (hide, appeal, reversal, history) |
| 13 | Withdraw a track and update the playback queue | While a listener has the track queued, the artist withdraws it. Outstanding stream URLs return 410, and the player removes the track and tells the listener | e2e; `test_publication.py` |
| 14 | Export artist data | Studio → Export → ZIP with originals, artwork, metadata, rights history and statistics | e2e; `test_exports_discovery.py` (original bytes identical) |

Edge cases also demonstrated:

* **Malformed audio**: HTML bytes renamed `.mp3` are rejected as soon as they arrive (415). A file with a `fLaC` header but corrupt data **fails processing**, with diagnostics and a retry button.
* **Oversized uploads**: `413` at creation (size limit and storage quota). Sending more bytes than declared also gives `413`.
* **Unavailable media**: withdrawn, restricted or replaced versions return `410`. Expired links return `403 expired`, and the player transparently gets a new URL.
* **Duplicate playback events**: retried batches are ignored (`duplicates` counter), and impossible listening claims are capped by wall-clock time.
