# Accessibility

Target: WCAG 2.2 AA. An automated tool hasn't checked it; the checks below were done by hand and with scripted keyboard tests.

* **Keyboard**: every control is a native button, link or input. Visible focus ring (turquoise on navy). Skip link. Global player shortcuts: Space/K play-pause, J/L ±10 s, Shift+N / Shift+P next/previous, M mute. They're ignored while you type, and a help dialog lists them. The waveform is a focusable `role="slider"` with arrows, PageUp/PageDown, Home and End.
* **Screen readers**: labelled landmarks (`nav`, `main`, the player `section`, search). `aria-valuetext` on seek sliders reads "1 minute 5 seconds of 3 minutes". `aria-pressed` on toggles (shuffle, repeat, mute, follow, save). Live regions for status and errors. Tracks have accessible names such as "Play Contour Lines by The Quiet Cartographers". The equaliser animation is labelled "Now playing".
* **Not colour alone**: active navigation shows a dot and `aria-current`; toggles show a dot indicator; repeat-one shows a "1"; the explicit badge is a letter; licence badges are text; pipeline steps use ✓/✕ glyphs.
* **Motion**: `prefers-reduced-motion` disables animations. `forced-colors` mode keeps the waveform and navigation state visible.
* **No autoplay**: `preload="none"`, and audio starts only after an explicit user action.
* **Contrast** (computed WCAG ratios on `#0b1026`): warm white 17.2:1, muted text 11.0:1, dim text 6.9:1, coral 6.9:1, turquoise 11.5:1; dark text on coral buttons 6.7:1 and on turquoise 9.5:1. All are at least 4.5:1.
* **Responsive**: layouts from 320 px. On phones, a bottom tab bar holds the five sections and a mini player sits above it. The E2E script checks there is no horizontal scroll at iPhone 13 width.

Known gaps: drag-to-reorder isn't offered (use the ↑/↓ buttons), and there is no captions or transcript model for spoken-word audio.
