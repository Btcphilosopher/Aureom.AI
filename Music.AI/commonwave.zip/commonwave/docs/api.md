# API

* Interactive docs: `/api/docs` (Swagger UI) and `/api/redoc` on any running server.
* Machine-readable spec: [`openapi.json`](openapi.json), generated with `python -m commonwave.ops openapi docs/openapi.json` (99 paths).

## Conventions

* Base path `/api/v1`. JSON bodies. Errors: `{"error": {"code": "not_found", "message": "…"}}`, plus `fields` on validation errors.
* **Authentication**: `POST /auth/register` or `/auth/login` set an HttpOnly, SameSite=Lax session cookie (stored server-side as a SHA-256 digest). `GET /auth/me` returns the user, their artist memberships and a `csrf_token`.
* **CSRF**: when a session cookie is present, every `POST/PUT/PATCH/DELETE` must send `X-CSRF-Token`.
* **Privacy**: objects you may not see return `404`, identical to objects that don't exist.
* **Rate limits** return `429` with `Retry-After`.

## Key flows

### Resumable upload (tus 1.0.0: core, creation, termination, expiration)

```
OPTIONS /api/v1/uploads                          → Tus-Version, Tus-Extension, Tus-Max-Size
POST    /api/v1/uploads   Upload-Length, Upload-Metadata: filename, artist_id, [track_id|title]
                          → 201 Location, X-Track-Id
PATCH   {Location}        Upload-Offset, Content-Type: application/offset+octet-stream → 204 Upload-Offset
HEAD    {Location}        → Upload-Offset (resume point)
DELETE  {Location}        → cancel
```

A wrong offset gives `409`. Non-audio content is rejected with `415` as soon as the first 8 KiB arrive. Oversize or over-quota gives `413`.

### Publish

```
PATCH /tracks/{id}                metadata, credits, composition, download flags
POST  /artists/{id}/artworks      multipart image → artwork id
POST  /tracks/{id}/rights         licence + recording/composition origin + confirmations
POST  /tracks/{id}/publish        {version_id?}  (requires a ready version and a rights declaration)
POST  /tracks/{id}/withdraw | /restore
POST  /releases, PUT /releases/{id}/tracks, POST /releases/{id}/publish
```

### Listen

```
POST /playback/sessions {track_id, source?, preview?}  → stream_url, session_id, session_token, waveform, playback_gain_db
GET  /media/stream/{asset}?exp&sig   (Range supported)
POST /playback/sessions/{id}/events {session_token, events:[{seq, kind, position_ms}]}
```

### Download

```
GET  /tracks/{id}/downloads                 → options with format, size, licence notice
POST /tracks/{id}/download {format: mp3|original} → expiring URL
POST /releases/{id}/archive                 → 202 {job_id} while building, then 200 {url}; 402 if pay-what-you-want applies
```

See `openapi.json` for discovery, search, playlists, comments, moderation, admin, support and export endpoints.
