# Security policy

## Reporting a vulnerability

Please **do not** open public issues for security problems. Email the maintainers at `security@commonwave.invalid` (operators should replace this address with their own before publishing). Encrypt your report if you can, and include:

* the affected version or commit, and the component (API, worker, web, deployment)
* steps to reproduce, proof of concept, and the impact you observed
* whether you plan to disclose it publicly, and when

We aim to acknowledge reports within 3 working days and to agree a fix and disclosure timeline, normally within 90 days. We credit reporters who want credit.

## Scope

In scope: authentication and session handling, authorisation (including private originals, drafts, private and unlisted playlists, and preview links), upload validation, the media-processing sandbox, signed media URLs, payment-webhook verification, injection, and stored XSS.

Out of scope: denial of service by volume against the demonstration server, social engineering, and findings that need a compromised operator account.

## Hardening summary

See [docs/security-privacy.md](docs/security-privacy.md) for the threat model and controls: Argon2id passwords, hashed session tokens, CSRF double-submit, object-level checks returning 404, HMAC-signed short-lived media URLs re-authorised on every request, content-sniffed uploads, FFmpeg in a constrained subprocess (argument lists, protocol whitelist, rlimits, timeout, optional network namespace, no-egress container network), rate limits, quotas, redacted logs and audit records.
