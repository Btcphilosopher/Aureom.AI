# Code of Conduct

COMMONWAVE is a commons. It works only if the people around it can participate safely. This code applies to every project space: repositories, issue trackers, chat, events, and the official demonstration server.

## Expected behaviour

* Be respectful and patient. Assume good faith, and say so when you disagree.
* Credit other people's work, including music, code and ideas.
* Accept that maintainers and moderators make the final call, and use the appeal routes when you disagree.
* Make space for newcomers, non-native English speakers and people who use assistive technology.

## Unacceptable behaviour

* Harassment, threats, stalking, doxxing, or sexual attention people don't want.
* Discrimination or slurs based on any personal characteristic.
* Deliberately uploading or linking to infringing, malicious or abusive material.
* Sustained disruption, spam, or impersonating others.

## Reporting and enforcement

Report incidents to the maintainers at the contact address in `SECURITY.md` (marked "conduct"), or through the server's Report button for content on a COMMONWAVE instance. Reports are handled confidentially. Maintainers may warn, temporarily restrict, or remove participants. Every decision is recorded with a reason, and the affected person can appeal once to a maintainer who was not involved.

Each server operator sets their own content policy for their instance. This code governs the project itself.
