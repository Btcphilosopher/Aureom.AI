// End-to-end demonstration of the 14 required scenarios against a running stack.
//
//   node scripts/e2e_demo.mjs http://localhost:3000 ./demo-output
//
// Requires: the stack running with seeded data (python -m commonwave.seed), ffmpeg
// on PATH (to generate an original test tone), and Playwright with Chromium.
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { chromium, devices } = require("playwright");

const BASE = process.argv[2] ?? "http://localhost:3000";
const OUT = path.resolve(process.argv[3] ?? "demo-output");
fs.mkdirSync(OUT, { recursive: true });
const results = [];
const log = (step, ok, detail) => {
  results.push({ step, ok, detail });
  console.log(`${ok ? "PASS" : "FAIL"}  ${step}${detail ? ` — ${detail}` : ""}`);
};
const shot = async (page, name) => { await page.waitForLoadState("networkidle").catch(() => {}); return page.screenshot({ path: path.join(OUT, `${name}.png`), fullPage: false }); };

// Original demo audio: a 20-second two-tone chord generated locally (CC0).
const wav = path.join(OUT, "e2e-upload.wav");
execFileSync("ffmpeg", ["-nostdin", "-v", "error", "-y", "-f", "lavfi", "-i",
  "aevalsrc=0.3*sin(2*PI*330*t)+0.2*sin(2*PI*495*t)|0.3*sin(2*PI*330*t)+0.2*sin(2*PI*440*t):s=44100:d=20", "-c:a", "pcm_s16le", wav]);
const junk = path.join(OUT, "not-really.mp3");
fs.writeFileSync(junk, Buffer.concat([Buffer.from("<html>definitely not audio</html>"), Buffer.alloc(20000, 7)]));

const browser = await chromium.launch();

async function signIn(ctx, email) {
  const page = await ctx.newPage();
  await page.goto(`${BASE}/login`);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill("commonwave-demo");
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(`${BASE}/`);
  return page;
}

async function apiJson(page, method, url, body) {
  return page.evaluate(async ([method, url, body]) => {
    const me = await (await fetch("/api/v1/auth/me")).json();
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json", "X-CSRF-Token": me.csrf_token ?? "" }, body: body ? JSON.stringify(body) : undefined });
    let j = null;
    try { j = await r.json(); } catch { /* empty */ }
    return { status: r.status, body: j };
  }, [method, url, body]);
}

try {
  // ------------------------------------------------------------------ artist uploads
  const artistCtx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  const artist = await signIn(artistCtx, "marigold@example.com");

  // 1 + 2: upload with an interrupted connection, resumed automatically by the tus client.
  let aborted = 0;
  await artist.route("**/api/v1/uploads/*", async (route) => {
    const req = route.request();
    if (req.method() === "PATCH" && aborted === 0 && Number(req.headers()["upload-offset"]) > 0) {
      aborted++;
      return route.abort("connectionreset");
    }
    return route.continue();
  });
  await artist.goto(`${BASE}/upload`);
  await artist.locator("#files").setInputFiles(junk);
  await artist.getByText("not MP3, WAV or FLAC").waitFor({ timeout: 20000 });
  log("Malformed audio rejected by content", true, "HTML bytes named .mp3 were refused");
  await shot(artist, "01-upload-rejected-malformed");

  await artist.locator("#files").setInputFiles(wav);
  const done = artist.getByRole("link", { name: "Add details & publish" });
  await done.waitFor({ timeout: 90000 });
  log("Upload a track", true);
  log("Resume an interrupted upload", aborted === 1, `connection reset injected ${aborted}× mid-upload; client resumed from server offset`);
  await shot(artist, "02-upload-complete");
  await done.click();
  await artist.waitForURL(/studio\/track\//);
  const trackId = artist.url().split("/").pop();

  // 3: processing + waveform
  await artist.getByText("Ready for review").first().waitFor({ timeout: 60000 });
  await artist.waitForSelector("svg.waveform rect.bar");
  const bars = await artist.locator("svg.waveform rect.bar").count();
  log("Process audio and generate a waveform", bars > 0, `${bars} waveform bars; streaming MP3 generated`);
  await shot(artist, "03-processed-ready-for-review");

  // 4: details, credits, artwork, licence
  await artist.getByLabel("Title").fill("Harbour Test Signal");
  await artist.getByLabel("Genre").fill("dream pop");
  await artist.getByLabel("Recording credits").fill("Marigold Static — Performance\nRowan — Mixing");
  await artist.getByRole("button", { name: "Save details" }).click();
  await artist.getByText("Details saved.").waitFor();
  execFileSync("ffmpeg", ["-nostdin", "-v", "error", "-y", "-f", "lavfi", "-i", "color=c=0x1f2a5c:s=900x900,drawbox=x=200:y=200:w=500:h=500:color=0xff6f61@0.8:t=fill", "-frames:v", "1", path.join(OUT, "cover.png")]);
  await artist.locator("#art-file").setInputFiles(path.join(OUT, "cover.png"));
  await artist.locator(`img[alt="Artwork for Harbour Test Signal"]`).waitFor({ timeout: 15000 });
  await artist.getByLabel("Licence for listeners").selectOption("CC-BY-4.0");
  await artist.getByText("I own or control the rights").click();
  await artist.getByText("I understand this is my declaration").click();
  await artist.getByText("I understand open licences can").click();
  await artist.getByRole("button", { name: "Save rights declaration" }).click();
  await artist.getByText("Rights declaration saved.").waitFor();
  await artist.getByLabel("Allow MP3 downloads").check();
  log("Add artwork, credits and a licence", true, "CC BY 4.0 declared (self-declared, not verified)");

  // 5: preview then publish
  await artist.getByRole("button", { name: "Preview (private)" }).click();
  await artist.locator('audio[aria-label="Private preview"]').waitFor();
  await artist.getByRole("button", { name: "Publish track" }).click();
  await artist.getByText("Published! Anyone can now stream this track.").waitFor();
  log("Preview and publish", true);
  await artist.evaluate(() => window.scrollTo(0, 0));
  await shot(artist, "04-published-track-editor");

  // ------------------------------------------------------------------ anonymous listener
  const anonCtx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  const anon = await anonCtx.newPage();
  const ranges = [];
  anon.on("response", (r) => { if (r.url().includes("/media/stream/")) ranges.push({ status: r.status(), range: r.request().headers()["range"] ?? null }); });
  await anon.goto(`${BASE}/`);
  await anon.getByRole("heading", { name: "Latest releases" }).waitFor();
  await shot(anon, "05-discover-anonymous");
  const autoplayed = await anon.evaluate(() => { const a = document.querySelector("audio"); return a ? !a.paused || Boolean(a.currentSrc) : false; });
  log("No autoplay before interaction", !autoplayed);

  await anon.goto(`${BASE}/tracks/${trackId}`);
  await anon.getByRole("button", { name: "Play Harbour Test Signal" }).click();
  await anon.waitForFunction(() => { const a = document.querySelector("audio"); return a && a.currentTime > 1; }, null, { timeout: 20000 });
  log("Stream without signing in", true, "audio element advancing for anonymous visitor");
  // 7: seek with the keyboard on the waveform slider
  const wave = anon.getByRole("slider", { name: /Waveform for Harbour Test Signal/ });
  await wave.focus();
  await anon.keyboard.press("End");
  await anon.waitForFunction(() => { const a = document.querySelector("audio"); return a && a.currentTime > 15; }, null, { timeout: 10000 });
  await anon.keyboard.press("Home");
  await anon.waitForTimeout(800);
  const partials = ranges.filter((r) => r.status === 206).length;
  log("Seek using range requests", partials > 0, `${partials} × HTTP 206 Partial Content responses observed`);
  await shot(anon, "06-track-page-playing");
  const mediaSession = await anon.evaluate(() => navigator.mediaSession?.metadata?.title ?? null);
  log("Media Session metadata set", mediaSession === "Harbour Test Signal", String(mediaSession));
  await anon.keyboard.press("k");
  await anon.waitForTimeout(300);
  const paused = await anon.evaluate(() => document.querySelector("audio").paused);
  log("Keyboard play/pause (K)", paused);

  // 10: authorised MP3 download (anonymous) and 11: private original denied
  const dl = await apiJson(anon, "POST", `/api/v1/tracks/${trackId}/download`, { format: "mp3" });
  const file = dl.status === 200 ? await anon.evaluate(async (u) => { const r = await fetch(u); return { status: r.status, size: (await r.arrayBuffer()).byteLength, cd: r.headers.get("content-disposition") }; }, dl.body.url) : null;
  log("Download an authorised MP3", dl.status === 200 && file?.status === 200, file ? `${file.size} bytes, ${file.cd}` : JSON.stringify(dl.body));
  const orig = await apiJson(anon, "POST", `/api/v1/tracks/${trackId}/download`, { format: "original" });
  const versionId = execFileSync("psql", ["-At", process.env.CW_PSQL_URL ?? "postgresql://commonwave:commonwave@localhost/commonwave", "-c",
    `select original_asset_id from track_versions where track_id='${trackId}' order by version_number desc limit 1`]).toString().trim();
  const direct = await anon.evaluate(async (id) => (await fetch(`/media/stream/${id}?exp=9999999999&sig=guess`)).status, versionId);
  log("Deny access to a private original", orig.status === 403 && direct === 403, `download API → ${orig.status}; direct media URL → ${direct}`);

  // ------------------------------------------------------------------ signed-in listener
  const fanCtx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  const fan = await signIn(fanCtx, "listener@example.com");
  await fan.goto(`${BASE}/artists/marigold-static`);
  const followBtn = fan.getByRole("button", { name: /Follow/ });
  if ((await followBtn.getAttribute("aria-pressed")) === "false") await followBtn.click();
  await fan.getByRole("button", { name: /Following/ }).waitFor();
  log("Follow the artist", true);
  await shot(fan, "07-artist-page-following");

  // 9: save to playlist
  await fan.goto(`${BASE}/tracks/${trackId}`);
  await fan.getByRole("button", { name: "Add to playlist" }).click();
  await fan.getByRole("button", { name: "Add to playlist…" }).click();
  await fan.getByRole("button", { name: /Late Night Commons/ }).click();
  await fan.getByText("Added to “Late Night Commons”").waitFor();
  log("Save the track to a playlist", true);

  // 12: comment + report + moderation
  await fan.getByLabel("Add a comment").fill("Lovely tones — reminds me of ferry horns.");
  await fan.getByRole("button", { name: "Post" }).click();
  await fan.getByText("Comment posted.").waitFor();
  const reporterCtx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const reporter = await signIn(reporterCtx, "okonkwo@example.com");
  await reporter.goto(`${BASE}/tracks/${trackId}`);
  await reporter.getByRole("button", { name: "Report comment" }).first().click();
  await reporter.getByRole("dialog").getByLabel("Reason").selectOption("spam");
  await reporter.getByRole("dialog").getByRole("button", { name: "Send report" }).click();
  await reporter.getByText("moderators will review your report").waitFor();
  const modCtx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  const mod = await signIn(modCtx, "modteam@example.com");
  await mod.goto(`${BASE}/admin`);
  await mod.getByText("reported by @okonkwo").first().waitFor();
  await shot(mod, "08-moderation-queue");
  log("Report a comment", true, "report visible in moderation queue");

  // 13: withdraw while the listener has the track queued
  await fan.goto(`${BASE}/playlists`);
  await fan.getByRole("link", { name: "Late Night Commons" }).click();
  await fan.getByRole("button", { name: "Play Late Night Commons" }).click();
  await fan.waitForFunction(() => { const a = document.querySelector("audio"); return a && a.currentTime > 0.5; }, null, { timeout: 20000 });
  const queueBefore = await fan.evaluate(() => document.querySelectorAll("audio").length);
  await apiJson(artist, "POST", `/api/v1/tracks/${trackId}/withdraw`);
  // Skip forward until the withdrawn track would be next.
  let toast = null;
  for (let i = 0; i < 10 && !toast; i++) {
    await fan.getByRole("button", { name: "Next track" }).click();
    await fan.waitForTimeout(700);
    toast = await fan.getByRole("alert").filter({ hasText: "no longer available" }).textContent().catch(() => null);
  }
  log("Withdraw a track and update the playback queue", Boolean(toast) && queueBefore === 1, toast ?? "no toast");
  await shot(fan, "09-withdrawn-removed-from-queue");

  // 14: export artist data
  await artist.goto(`${BASE}/studio`);
  await artist.getByRole("link", { name: "Marigold Static" }).click();
  await artist.getByRole("tab", { name: "Export" }).click();
  await artist.getByRole("button", { name: "Build export" }).click();
  await artist.getByRole("link", { name: /Download \(/ }).waitFor({ timeout: 60000 });
  const href = await artist.getByRole("link", { name: /Download \(/ }).getAttribute("href");
  const exp = await artist.evaluate(async (u) => { const r = await fetch(u); return { status: r.status, size: (await r.arrayBuffer()).byteLength }; }, href);
  log("Export artist data", exp.status === 200 && exp.size > 1000, `${exp.size} byte ZIP`);
  await shot(artist, "10-artist-export");
  await artist.getByRole("tab", { name: "Statistics" }).click();
  await artist.getByText("Qualified listens per day").waitFor();
  await shot(artist, "11-artist-statistics");

  // Responsive: phone layout
  const phone = await browser.newContext({ ...devices["iPhone 13"] });
  const mp = await phone.newPage();
  await mp.goto(`${BASE}/`);
  await mp.getByRole("heading", { name: "Latest releases" }).waitFor();
  await mp.screenshot({ path: path.join(OUT, "12-mobile-discover.png") });
  await mp.goto(`${BASE}/artists/the-quiet-cartographers`);
  await mp.getByRole("heading", { name: "The Quiet Cartographers" }).waitFor();
  await mp.getByRole("button", { name: "Play The Quiet Cartographers" }).click();
  await mp.waitForTimeout(1500);
  await mp.screenshot({ path: path.join(OUT, "13-mobile-artist-playing.png") });
  const overflow = await mp.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  log("Mobile layout without horizontal scroll", !overflow);

  // Reduced motion honoured
  const rm = await browser.newContext({ reducedMotion: "reduce" });
  const rmp = await rm.newPage();
  await rmp.goto(`${BASE}/`);
  const rmOk = await rmp.evaluate(() => matchMedia("(prefers-reduced-motion: reduce)").matches);
  log("Reduced-motion preference detected", rmOk);
} catch (e) {
  log("Unexpected error", false, String(e?.stack ?? e).slice(0, 800));
} finally {
  await browser.close();
  fs.writeFileSync(path.join(OUT, "results.json"), JSON.stringify(results, null, 2));
  const failed = results.filter((r) => !r.ok).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  process.exit(failed ? 1 : 0);
}
