#!/usr/bin/env sh
# Create .env and the SeaweedFS credentials file with random secrets.
set -eu
cd "$(dirname "$0")/.."
if [ -f .env ]; then echo ".env already exists; not overwriting"; exit 0; fi
rand() { head -c 48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c "$1"; }
S3_SECRET=$(rand 40)
sed -e "s/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$(rand 32)/" \
    -e "s/^CW_SECRET_KEY=.*/CW_SECRET_KEY=$(rand 64)/" \
    -e "s/^S3_SECRET_KEY=.*/S3_SECRET_KEY=$S3_SECRET/" deploy/env.example > .env
sed -e "s/change-me/$S3_SECRET/" deploy/seaweedfs/s3.json.example > deploy/seaweedfs/s3.json
chmod 600 .env
# Must be readable by the (non-root) SeaweedFS container user; keep the repository directory itself private.
chmod 644 deploy/seaweedfs/s3.json
echo "Wrote .env and deploy/seaweedfs/s3.json. Review CW_COOKIE_SECURE and CW_PUBLIC_BASE_URL before going public."
