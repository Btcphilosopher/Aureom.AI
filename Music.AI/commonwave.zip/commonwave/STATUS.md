# Status report — COMMONWAVE 0.1.0 (2026-11-27)

Legend: **Implemented**: working code exercised by automated tests. **Integrated**: works against the real external software named. **Simulated**: the full flow exists, but a stand-in replaces a real external service. **Deferred**: not built; at most an interface or a documented plan.

## Build and test results (actual runs, reference environment)

Environment: Linux x86_64, Python 3.13.18, PostgreSQL 16.15, FFmpeg (Ubuntu build with libmp3lame), Node 22.23.5, Chromium via Playwright, Docker 29.9.3.

| Check | Result |
|---|---|
| Backend tests `pytest` (real PostgreSQL + FFmpeg) | **69 passed, 0 failed** (79.5 s) |
| — by file | processing limits 13, exports/discovery/storage/sanitisation 8, playback events 8, publication 7, private files 7, permissions 6, moderation 6, support/downloads 5, core flow 4, playlists 3, backup/restore 2 |
| Backend lint `ruff --select F,E9` | clean |
| Alembic `upgrade head` → `downgrade base` → `upgrade head` | passed |
| Web `tsc --noEmit` | clean |
| Web unit tests `vitest` (queue reducer, tus helpers, formatting, waveform) | **15 passed** |
| Web `next build` (Next 16.4.6, React 19.3.1) | passed (23 routes) |
| Browser E2E `scripts/e2e_demo.mjs` (Chromium) on **SeaweedFS 4.55 (S3) + Valkey 8.1 + PostgreSQL** | **20/20 checks passed**, covering all 14 demo scenarios plus no-autoplay, Media Session, keyboard, mobile overflow and reduced motion. Also 20/20 on the local-disk storage backend. Screenshots: `docs/screenshots/` |
| Backup → restore into an empty DB and bucket → verify | passed (49 objects, row counts identical) |
| HTTP Range through the Next.js proxy | `206` + correct `Content-Range` verified |
| `docker compose config` | valid |
| `docker compose build` | **Not verified here.** Base images pulled fine, but this sandbox's network policy blocks `deb.debian.org`, so the `apt-get install ffmpeg` layer could not run. The SeaweedFS and Valkey containers from the compose file *were* run and used for the E2E pass. The `init-env.sh` permissions bug this exposed is fixed. Build the images on a normal host before relying on them. |

## Capabilities

### Implemented
* Accounts (Argon2id), cookie sessions stored as digests, CSRF, roles (user, moderator, admin), account restriction and suspension.
* Separate User / ArtistProfile / ArtistMembership (owner, manager, contributor); several managers per band; last-owner protection.
* Composition / Track / TrackVersion / Release / ReleaseTrack / AudioAsset / Artwork model; version replacement that keeps history.
* tus 1.0.0 resumable uploads (creation, termination, expiration), resume after interruption, content sniffing (MP3, WAV, FLAC), size, duration, quota and concurrency limits.
* Pipeline: Uploaded → Validating → Processing → Ready for review → Published, plus failed, cancelled and withdrawn; retry and cancel.
* Constrained FFmpeg adapter: argument lists, path and argument validation, protocol whitelist, rlimits, timeout with process-group kill, empty environment, optional `unshare -n`.
* Streaming MP3 derivative (192 kbps CBR, or the source bitrate for low-bitrate MP3, never upsampled), technical metadata, EBU R128 loudness and true peak, player-only gain, 600-point waveform, diagnostics (including the "higher bitrate doesn't restore quality" explanation).
* Signed, expiring media URLs re-authorised on every request; HTTP Range (206/416/If-Range/HEAD); private originals never streamable.
* Persistent player: play/pause, seek (slider and keyboard waveform), volume, mute, queue (play next, add, remove, reorder by jump), previous/next, repeat off/all/one, shuffle, speed 0.75–2×, loudness levelling, Media Session, keyboard shortcuts, no autoplay. Handles expired URLs (transparent refresh), stalls (reconnect after 12 s), and unavailable or withdrawn tracks (removed from the queue with a notice).
* Metadata: title, collaborators, credits, release, track number, description, genre, tags, language, release date, explicit label, artwork (re-encoded, EXIF removed), lyrics shown only when authorised; drafts private; explicit publish action.
* Rights: ARR, six CC 4.0 licences, CC0, PDM; recording vs composition origins; cover, sample and remix rules; append-only declaration history; "self-declared, not verified" everywhere; withdrawal and irrevocability notices.
* Downloads: MP3 and original as separate permissions; asynchronous release ZIP archives with licence and credits file; expiring links; permission re-checked at fetch time; counted separately from plays.
* Discovery: latest releases and tracks, followed artists, genres, tags, editorial collections, new voices, recently active artists, abuse-resistant popular ranking (distinct listeners, 14-day window, decay, minimum 3 listeners, at most 2 per artist), replaceable `Ranker`, PostgreSQL full-text search, opt-in personal shelf using explicit interests and follows only.
* Community: private, unlisted (capability token, rotatable) and public playlists; ordering; per-playlist duplicate policy; saves; follows; comments with optional timestamps; pre-moderation and link holds; blocking; reporting. Every feature has a runtime toggle for operators.
* Moderation: reports, structured rights complaints, restriction kept separate from withdrawal and from admin-only permanent deletion, temporary restrictions with automatic expiry, suspensions, appeals reviewed by a different moderator, automatic reversal, decision history, audit log.
* Analytics: server-computed requests, starts, qualified listens (published definition), listening time, completion, downloads, saves and follows; duplicate and out-of-order event handling; wall-clock bounding; bot heuristics; aggregated artist view with small-number suppression; private, deletable listener history.
* Admin console: overview, reports, appeals, held comments, users and roles, artist verification (with recorded method) and quotas, jobs and retries, community configuration, editorial collections, audit log.
* Data export (artist ZIP with byte-identical originals; listener JSON); backup, restore and verify commands.
* Security: object-level 404s, CSP and security headers, rate limits, redacted logs, sanitised text, audit records.

### Integrated (with real external software)
* PostgreSQL 16: schema, full-text search, `SKIP LOCKED` job queue (all tests and E2E).
* FFmpeg / ffprobe (libmp3lame, loudnorm, PCM decoding) through the adapter.
* S3-compatible storage: **SeaweedFS 4.55** (E2E run) and AWS S3 semantics through `moto` (unit test).
* **Valkey 8.1** / Redis protocol: rate limits, bounded discovery cache and worker wake-ups (E2E run). In-memory fallback when absent.
* Chromium playback: Range requests, Media Session, keyboard and mobile viewport (Playwright).

### Simulated
* **Payments**: tips and pay-what-you-want release downloads use `SimulatedProvider`. Signed webhooks, idempotent fulfilment, entitlement, payout ledger and explicit fees all run, but **no money moves**.
* **Demo content**: all artists, accounts and music are fictional. Audio is synthesised by code (CC0). Play counts and followers start at zero and are never fabricated.

### Deferred
* HLS / adaptive streaming (a config flag exists and does nothing; progressive MP3 is the supported path).
* Lightning payments (interface contract only) and any real payment provider.
* Federation (extension interface and a `/.well-known/commonwave` that says "not enabled"; no protocol, no interoperability claims).
* Audio fingerprinting (policy documented: it may only assist human review).
* Email verification, password reset and two-factor authentication.
* Jurisdiction-specific legal workflows (DMCA counter-notice timers, DSA transparency reports). The mechanics exist, but operators must define procedures from current official sources.
* Drag-and-drop reordering, translations / i18n, and an automated accessibility audit (axe) in CI.

## Known limitations
* Anonymous listener de-duplication uses a daily-rotating keyed hash of IP + user agent, so it can be inflated by actors with many IPs. Counts are not fraud-proof.
* The API trusts `X-Forwarded-For` from the web tier; the edge proxy must overwrite it (documented).
* Media bytes pass through the API. For heavy traffic, put a caching CDN in front of `/media/stream`.
