"""Playlists, saves, library, comments and blocking."""
from __future__ import annotations

import re
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session

from commonwave.core import ratelimit
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, can, get_viewer, membership_role, require_active_user, require_user
from commonwave.core.errors import ApiError, bad_request, conflict, forbidden, not_found
from commonwave.core.sanitize import clean_line, clean_text
from commonwave.core.security import new_token
from commonwave.core.siteconfig import get_config
from commonwave.models import (
    ArtistMembership, ArtistProfile, Block, Comment, ListenHistory, Playlist, PlaylistEntry, Release, ReleaseTrack, Save,
    Track, TrackVersion, User,
)
from commonwave.modules.catalogue.service import artist_brief, artwork_url, can_view_release, get_visible_track, serialize_track

router = APIRouter(tags=["community"])


def release_brief(db: Session, r: Release, manage: bool = False) -> dict:
    artist = db.get(ArtistProfile, r.artist_id)
    count = db.scalar(select(func.count()).select_from(ReleaseTrack).where(ReleaseTrack.release_id == r.id))
    out = {
        "id": str(r.id), "title": r.title, "kind": r.kind, "genre": r.genre, "tags": r.tags,
        "artist": artist_brief(artist), "artwork_url": artwork_url(r.artwork_id, "large"),
        "artwork_thumb_url": artwork_url(r.artwork_id, "small"),
        "release_date": r.release_date.isoformat() if r.release_date else None,
        "published_at": r.published_at.isoformat() if r.published_at else None,
        "track_count": count, "status": r.status, "available": r.is_public,
        "pwyw": {"enabled": r.pwyw_enabled, "min_minor": r.pwyw_min_minor, "currency": r.pwyw_currency} if r.pwyw_enabled else None,
    }
    if manage:
        out["artwork_id"] = str(r.artwork_id) if r.artwork_id else None
        out["track_ids"] = [str(e.track_id) for e in r.entries]
        out["moderation_restricted"] = r.moderation_restricted
    return out


# ------------------------------------------------------------------ playlists


class PlaylistIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str | None = None
    visibility: str = "private"
    allow_duplicates: bool = False


class PlaylistPatch(BaseModel):
    title: str | None = None
    description: str | None = None
    visibility: str | None = None
    allow_duplicates: bool | None = None
    rotate_share_link: bool = False


def _playlist_access(db: Session, viewer: Viewer, playlist_id: uuid.UUID, token: str | None) -> Playlist:
    """Access rules:
    * private  — owner only (a share token is ignored).
    * unlisted — owner, or anyone presenting the current share token.
    * public   — anyone.
    Inaccessible playlists return 404 so their existence is not disclosed."""
    p = db.get(Playlist, playlist_id)
    if not p:
        raise not_found("playlist")
    if viewer.id == p.owner_id:
        return p
    if p.visibility == "public":
        return p
    if p.visibility == "unlisted" and token and len(token) == len(p.share_token) and __import__("hmac").compare_digest(token, p.share_token):
        return p
    raise not_found("playlist")


def playlist_payload(db: Session, viewer: Viewer, p: Playlist, include_entries: bool = True) -> dict:
    owner = db.get(User, p.owner_id)
    is_owner = viewer.id == p.owner_id
    out = {
        "id": str(p.id), "title": p.title, "description": p.description, "visibility": p.visibility,
        "allow_duplicates": p.allow_duplicates, "owner": {"username": owner.username, "display_name": owner.display_name},
        "is_owner": is_owner, "updated_at": p.updated_at.isoformat(),
        "entry_count": db.scalar(select(func.count()).select_from(PlaylistEntry).where(PlaylistEntry.playlist_id == p.id)),
    }
    if is_owner and p.visibility == "unlisted":
        out["share_path"] = f"/playlists/{p.id}?token={p.share_token}"
    if include_entries:
        rows = db.execute(select(PlaylistEntry, Track).join(Track, Track.id == PlaylistEntry.track_id)
                          .where(PlaylistEntry.playlist_id == p.id).order_by(PlaylistEntry.position)).all()
        entries = []
        for e, t in rows:
            if t.is_public:
                entries.append({"entry_id": str(e.id), "position": e.position, "track": serialize_track(db, t)})
            else:
                # Keep the slot so the owner sees what disappeared, without leaking details.
                entries.append({"entry_id": str(e.id), "position": e.position, "track": None,
                                "unavailable": True, "unavailable_title": t.title if is_owner and t.status != "draft" else None})
        out["entries"] = entries
    return out


@router.get("/playlists")
def my_playlists(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    ps = db.scalars(select(Playlist).where(Playlist.owner_id == viewer.id).order_by(Playlist.updated_at.desc())).all()
    return [playlist_payload(db, viewer, p, include_entries=False) for p in ps]


@router.get("/users/{username}/playlists")
def public_playlists(username: str, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(func.lower(User.username) == username.lower(), User.status != "suspended"))
    if not u:
        raise not_found("user")
    ps = db.scalars(select(Playlist).where(Playlist.owner_id == u.id, Playlist.visibility == "public").order_by(Playlist.updated_at.desc())).all()
    return [playlist_payload(db, viewer, p, include_entries=False) for p in ps]


@router.post("/playlists", status_code=201)
def create_playlist(body: PlaylistIn, request: Request, viewer: Viewer = Depends(require_active_user), db: Session = Depends(get_db)):
    ratelimit.enforce("playlist_write", request, str(viewer.id))
    if body.visibility not in ("private", "unlisted", "public"):
        raise bad_request("invalid_visibility", "Visibility must be private, unlisted or public")
    if body.visibility == "public" and not get_config(db)["public_playlists_enabled"]:
        raise ApiError(403, "public_playlists_disabled", "Public playlists are disabled on this server.")
    if db.scalar(select(func.count()).select_from(Playlist).where(Playlist.owner_id == viewer.id)) >= 500:
        raise bad_request("playlist_limit", "You have reached the playlist limit.")
    p = Playlist(owner_id=viewer.id, title=clean_line(body.title, 120), description=clean_text(body.description, 2000),
                 visibility=body.visibility, allow_duplicates=body.allow_duplicates, share_token=new_token(32))
    db.add(p)
    db.flush()
    return playlist_payload(db, viewer, p)


@router.get("/playlists/{playlist_id}")
def get_playlist(playlist_id: uuid.UUID, token: str | None = None, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    return playlist_payload(db, viewer, _playlist_access(db, viewer, playlist_id, token))


def _own_playlist(db: Session, viewer: Viewer, playlist_id: uuid.UUID) -> Playlist:
    p = db.scalar(select(Playlist).where(Playlist.id == playlist_id).with_for_update())
    if not p or p.owner_id != viewer.id:
        raise not_found("playlist")
    return p


@router.patch("/playlists/{playlist_id}")
def update_playlist(playlist_id: uuid.UUID, body: PlaylistPatch, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    p = _own_playlist(db, viewer, playlist_id)
    d = body.model_dump(exclude_unset=True)
    if d.get("title"):
        p.title = clean_line(d["title"], 120)
    if "description" in d:
        p.description = clean_text(d["description"], 2000)
    if d.get("visibility"):
        if d["visibility"] not in ("private", "unlisted", "public"):
            raise bad_request("invalid_visibility", "Visibility must be private, unlisted or public")
        if d["visibility"] == "public" and not get_config(db)["public_playlists_enabled"]:
            raise ApiError(403, "public_playlists_disabled", "Public playlists are disabled on this server.")
        if p.visibility != d["visibility"]:
            p.share_token = new_token(32)  # changing visibility invalidates old unlisted links
        p.visibility = d["visibility"]
    if "allow_duplicates" in d and d["allow_duplicates"] is not None:
        p.allow_duplicates = d["allow_duplicates"]
    if d.get("rotate_share_link"):
        p.share_token = new_token(32)
    p.updated_at = utcnow()
    return playlist_payload(db, viewer, p)


@router.delete("/playlists/{playlist_id}")
def delete_playlist(playlist_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    p = _own_playlist(db, viewer, playlist_id)
    db.delete(p)
    return {"ok": True}


class EntryIn(BaseModel):
    track_id: uuid.UUID


@router.post("/playlists/{playlist_id}/entries", status_code=201)
def add_entry(playlist_id: uuid.UUID, body: EntryIn, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    ratelimit.enforce("playlist_write", request, str(viewer.id))
    p = _own_playlist(db, viewer, playlist_id)  # row lock serialises concurrent adds
    t = db.get(Track, body.track_id)
    if not t or not t.is_public:
        raise not_found("track")
    if not p.allow_duplicates and db.scalar(select(PlaylistEntry.id).where(PlaylistEntry.playlist_id == p.id, PlaylistEntry.track_id == t.id)):
        raise conflict("duplicate_entry", "This track is already in the playlist (duplicates are off for this playlist).")
    count = db.scalar(select(func.count()).select_from(PlaylistEntry).where(PlaylistEntry.playlist_id == p.id))
    if count >= 5000:
        raise bad_request("playlist_full", "Playlists can hold at most 5000 tracks.")
    pos = (db.scalar(select(func.max(PlaylistEntry.position)).where(PlaylistEntry.playlist_id == p.id)) or 0) + 1
    db.add(PlaylistEntry(playlist_id=p.id, track_id=t.id, position=pos))
    p.updated_at = utcnow()
    db.flush()
    return playlist_payload(db, viewer, p)


@router.delete("/playlists/{playlist_id}/entries/{entry_id}")
def remove_entry(playlist_id: uuid.UUID, entry_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    p = _own_playlist(db, viewer, playlist_id)
    e = db.get(PlaylistEntry, entry_id)
    if not e or e.playlist_id != p.id:
        raise not_found("entry")
    db.delete(e)
    db.flush()
    _renumber(db, p.id)
    return playlist_payload(db, viewer, p)


class OrderIn(BaseModel):
    entry_ids: list[uuid.UUID]


@router.put("/playlists/{playlist_id}/order")
def reorder(playlist_id: uuid.UUID, body: OrderIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    p = _own_playlist(db, viewer, playlist_id)
    entries = {e.id: e for e in db.scalars(select(PlaylistEntry).where(PlaylistEntry.playlist_id == p.id))}
    if set(body.entry_ids) != set(entries) or len(body.entry_ids) != len(entries):
        raise bad_request("order_mismatch", "Send every entry id exactly once.")
    for i, eid in enumerate(body.entry_ids, start=1):
        entries[eid].position = i
    p.updated_at = utcnow()
    db.flush()
    return playlist_payload(db, viewer, p)


def _renumber(db: Session, playlist_id: uuid.UUID) -> None:
    for i, e in enumerate(db.scalars(select(PlaylistEntry).where(PlaylistEntry.playlist_id == playlist_id).order_by(PlaylistEntry.position)), start=1):
        e.position = i


# ------------------------------------------------------------------ saves & library


class SaveIn(BaseModel):
    target_type: str = Field(pattern="^(track|release)$")
    target_id: uuid.UUID


@router.post("/saves")
def save(body: SaveIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    if body.target_type == "track":
        t = db.get(Track, body.target_id)
        if not t or not t.is_public:
            raise not_found("track")
    else:
        r = db.get(Release, body.target_id)
        if not r or not r.is_public:
            raise not_found("release")
    if not db.get(Save, (viewer.id, body.target_type, body.target_id)):
        db.add(Save(user_id=viewer.id, target_type=body.target_type, target_id=body.target_id))
    return {"saved": True}


@router.delete("/saves/{target_type}/{target_id}")
def unsave(target_type: str, target_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    s = db.get(Save, (viewer.id, target_type, target_id))
    if s:
        db.delete(s)
    return {"saved": False}


@router.get("/library")
def library(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    saves = db.scalars(select(Save).where(Save.user_id == viewer.id).order_by(Save.created_at.desc()).limit(500)).all()
    tracks, releases = [], []
    for s in saves:
        if s.target_type == "track":
            t = db.get(Track, s.target_id)
            if t and t.is_public:
                tracks.append({**serialize_track(db, t), "saved_at": s.created_at.isoformat()})
        else:
            r = db.get(Release, s.target_id)
            if r and r.is_public:
                releases.append({**release_brief(db, r), "saved_at": s.created_at.isoformat()})
    return {"tracks": tracks, "releases": releases}


@router.get("/library/history")
def history(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    """Private to the user. Never shown to artists or other users."""
    rows = db.execute(select(ListenHistory, Track).join(Track, Track.id == ListenHistory.track_id)
                      .where(ListenHistory.user_id == viewer.id).order_by(ListenHistory.played_at.desc()).limit(200)).all()
    return {"enabled": viewer.user.history_enabled,
            "items": [{"id": str(h.id), "played_at": h.played_at.isoformat(), "track": serialize_track(db, t) if t.is_public else None} for h, t in rows]}


@router.delete("/library/history")
def clear_history(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    n = db.execute(delete(ListenHistory).where(ListenHistory.user_id == viewer.id)).rowcount
    return {"deleted": n}


@router.delete("/library/history/{item_id}")
def delete_history_item(item_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    db.execute(delete(ListenHistory).where(ListenHistory.user_id == viewer.id, ListenHistory.id == item_id))
    return {"ok": True}


# ------------------------------------------------------------------ comments


class CommentIn(BaseModel):
    body: str = Field(min_length=1, max_length=4000)
    timestamp_ms: int | None = Field(default=None, ge=0)


_LINK = re.compile(r"https?://|www\.", re.I)


def _blocked_ids(db: Session, user_id: uuid.UUID | None) -> set[uuid.UUID]:
    if not user_id:
        return set()
    rows = db.execute(select(Block.blocker_id, Block.blocked_id).where(or_(Block.blocker_id == user_id, Block.blocked_id == user_id))).all()
    return {b if a == user_id else a for a, b in rows}


def comment_payload(c: Comment, u: User, viewer: Viewer, can_moderate: bool) -> dict:
    return {"id": str(c.id), "body": c.body, "timestamp_ms": c.timestamp_ms, "created_at": c.created_at.isoformat(),
            "status": c.status, "author": {"username": u.username, "display_name": u.display_name},
            "is_mine": viewer.id == c.user_id, "can_hide": can_moderate}


@router.get("/tracks/{track_id}/comments")
def list_comments(track_id: uuid.UUID, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    t = get_visible_track(db, viewer, track_id)
    cfg = get_config(db)
    if not cfg["comments_enabled"]:
        return {"enabled": False, "comments": []}
    member = bool(membership_role(db, t.artist_id, viewer.id))
    blocked = _blocked_ids(db, viewer.id)
    rows = db.execute(select(Comment, User).join(User, User.id == Comment.user_id).where(Comment.track_id == t.id, User.status != "suspended")
                      .order_by(Comment.created_at.desc()).limit(200)).all()
    out = []
    for c, u in rows:
        if c.user_id in blocked:
            continue
        if c.status == "visible" or (c.status == "held" and (c.user_id == viewer.id or member or viewer.is_staff)):
            out.append(comment_payload(c, u, viewer, member or viewer.is_staff))
    return {"enabled": True, "timestamped": cfg["timestamped_comments_enabled"], "comments": out}


@router.post("/tracks/{track_id}/comments", status_code=201)
def post_comment(track_id: uuid.UUID, body: CommentIn, request: Request, viewer: Viewer = Depends(require_active_user), db: Session = Depends(get_db)):
    ratelimit.enforce("comment", request, str(viewer.id))
    t = get_visible_track(db, viewer, track_id)
    cfg = get_config(db)
    if not cfg["comments_enabled"]:
        raise ApiError(403, "comments_disabled", "Comments are disabled on this server.")
    if not t.is_public:
        raise conflict("not_published", "Comments open when the track is published.")
    text = clean_text(body.body, int(cfg["max_comment_length"]))
    if not text:
        raise bad_request("empty_comment", "Comment cannot be empty.")
    # An artist member who blocked this user prevents comments on that artist's tracks.
    member_ids = set(db.scalars(select(ArtistMembership.user_id).where(ArtistMembership.artist_id == t.artist_id)))
    if member_ids & set(db.scalars(select(Block.blocker_id).where(Block.blocked_id == viewer.id))):
        raise forbidden("You can't comment on this artist's tracks.")
    links = len(_LINK.findall(text))
    status = "visible"
    if links > int(cfg["comment_link_limit"]):
        raise bad_request("too_many_links", "Comments may contain at most %d links." % cfg["comment_link_limit"])
    hold_hours = int(cfg["new_account_comment_hold_hours"])
    if cfg["comment_premoderation"] or (hold_hours and viewer.user.created_at > utcnow() - timedelta(hours=hold_hours)) or links:
        status = "held"
    # Simple duplicate-spam check: identical text from the same user within 10 minutes.
    if db.scalar(select(Comment.id).where(Comment.user_id == viewer.id, Comment.body == text, Comment.created_at > utcnow() - timedelta(minutes=10)).limit(1)):
        raise conflict("duplicate_comment", "You just posted that.")
    ts = None
    if body.timestamp_ms is not None and cfg["timestamped_comments_enabled"]:
        v = db.get(TrackVersion, t.current_version_id)
        ts = min(body.timestamp_ms, v.duration_ms or 0)
    c = Comment(track_id=t.id, user_id=viewer.id, body=text, timestamp_ms=ts, status=status)
    db.add(c)
    db.flush()
    return {**comment_payload(c, viewer.user, viewer, False),
            "notice": "Your comment is awaiting review." if status == "held" else None}


@router.delete("/comments/{comment_id}")
def delete_comment(comment_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    c = db.get(Comment, comment_id)
    if not c:
        raise not_found("comment")
    t = db.get(Track, c.track_id)
    if c.user_id == viewer.id:
        c.status = "deleted"
    elif can(db, viewer, t.artist_id, "edit") or viewer.is_staff:
        c.status = "hidden"
        c.hidden_reason = "Hidden by the artist" if not viewer.is_staff else "Hidden by moderators"
        audit(db, viewer.id, "comment.hide", "comment", c.id)
    else:
        raise not_found("comment")
    return {"ok": True, "status": c.status}


@router.post("/comments/{comment_id}/approve")
def approve_comment(comment_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    c = db.get(Comment, comment_id)
    if not c:
        raise not_found("comment")
    t = db.get(Track, c.track_id)
    if not (can(db, viewer, t.artist_id, "edit") or viewer.is_staff) or c.status != "held":
        raise not_found("comment")
    c.status = "visible"
    return {"ok": True}


# ------------------------------------------------------------------ blocks


class BlockIn(BaseModel):
    username: str


@router.get("/me/blocks")
def list_blocks(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    rows = db.execute(select(Block, User).join(User, User.id == Block.blocked_id).where(Block.blocker_id == viewer.id)).all()
    return [{"username": u.username, "display_name": u.display_name, "since": b.created_at.isoformat()} for b, u in rows]


@router.post("/me/blocks", status_code=201)
def block(body: BlockIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(func.lower(User.username) == body.username.lower()))
    if not u or u.id == viewer.id:
        raise not_found("user")
    if not db.get(Block, (viewer.id, u.id)):
        db.add(Block(blocker_id=viewer.id, blocked_id=u.id))
    return {"blocked": True}


@router.delete("/me/blocks/{username}")
def unblock(username: str, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(func.lower(User.username) == username.lower()))
    if u:
        b = db.get(Block, (viewer.id, u.id))
        if b:
            db.delete(b)
    return {"blocked": False}


def releases_visible(db: Session, viewer: Viewer, ids: list[uuid.UUID]) -> list[dict]:
    out = []
    for rid in ids:
        r = db.get(Release, rid)
        if r and can_view_release(db, viewer, r) and r.is_public:
            out.append(release_brief(db, r))
    return out
