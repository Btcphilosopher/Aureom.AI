"""Extension boundary for future federation.

COMMONWAVE does **not** federate today. This module defines the narrow interface
a future protocol adapter (for example ActivityPub) would implement, and a no-op
default. Nothing here claims cross-server compatibility; see docs/federation.md.
"""
from __future__ import annotations

from typing import Protocol


class FederationPublisher(Protocol):
    """Called by the catalogue after local state changes. Implementations must be
    idempotent and must never block local publishing if a remote server is down."""

    def track_published(self, track_id: str) -> None: ...
    def track_withdrawn(self, track_id: str) -> None: ...
    def artist_updated(self, artist_id: str) -> None: ...


class NoFederation:
    enabled = False

    def track_published(self, track_id: str) -> None:
        return None

    def track_withdrawn(self, track_id: str) -> None:
        return None

    def artist_updated(self, artist_id: str) -> None:
        return None


publisher: FederationPublisher = NoFederation()


def node_info(version: str, site_name: str) -> dict:
    return {"software": {"name": "commonwave", "version": version}, "site_name": site_name,
            "federation": {"enabled": False, "protocols": [], "note": "Federation is not implemented in this release."}}
