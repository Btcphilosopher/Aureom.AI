"""Supported licence choices, with plain-language explanations shown to artists and listeners.

Important: none of these choices means a track is "copyright free". All rights
reserved is the default. Creative Commons licences are *grants by the
rights-holder*; the platform records the declaration but does not verify it.
"""
from __future__ import annotations

from commonwave.models import RightsDeclaration

LICENCES: dict[str, dict] = {
    "ARR": {
        "name": "All rights reserved — streaming on COMMONWAVE permitted",
        "short": "All rights reserved",
        "version": None, "url": None,
        "permits": ["Listening through this platform"],
        "requires": [],
        "prohibits": ["Copying, redistribution or reuse outside the platform without the rights-holder's permission"],
        "explain": "You keep every right. Listeners may stream here. A download, if you enable one, is for personal listening only.",
        "allows_reuse": False,
    },
    "CC-BY-4.0": {
        "name": "Creative Commons Attribution 4.0 International", "short": "CC BY 4.0", "version": "4.0",
        "url": "https://creativecommons.org/licenses/by/4.0/",
        "permits": ["Share", "Adapt", "Commercial use"], "requires": ["Attribution"], "prohibits": [],
        "explain": "Anyone may share and adapt the recording, even commercially, if they credit you.",
        "allows_reuse": True,
    },
    "CC-BY-SA-4.0": {
        "name": "Creative Commons Attribution-ShareAlike 4.0 International", "short": "CC BY-SA 4.0", "version": "4.0",
        "url": "https://creativecommons.org/licenses/by-sa/4.0/",
        "permits": ["Share", "Adapt", "Commercial use"], "requires": ["Attribution", "ShareAlike"], "prohibits": [],
        "explain": "Like CC BY, but adaptations must be released under the same licence.",
        "allows_reuse": True,
    },
    "CC-BY-NC-4.0": {
        "name": "Creative Commons Attribution-NonCommercial 4.0 International", "short": "CC BY-NC 4.0", "version": "4.0",
        "url": "https://creativecommons.org/licenses/by-nc/4.0/",
        "permits": ["Share", "Adapt"], "requires": ["Attribution"], "prohibits": ["Commercial use"],
        "explain": "Anyone may share and adapt for non-commercial purposes with credit.",
        "allows_reuse": True,
    },
    "CC-BY-NC-SA-4.0": {
        "name": "Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International", "short": "CC BY-NC-SA 4.0", "version": "4.0",
        "url": "https://creativecommons.org/licenses/by-nc-sa/4.0/",
        "permits": ["Share", "Adapt"], "requires": ["Attribution", "ShareAlike"], "prohibits": ["Commercial use"],
        "explain": "Non-commercial sharing and adaptation with credit; adaptations use the same licence.",
        "allows_reuse": True,
    },
    "CC-BY-ND-4.0": {
        "name": "Creative Commons Attribution-NoDerivatives 4.0 International", "short": "CC BY-ND 4.0", "version": "4.0",
        "url": "https://creativecommons.org/licenses/by-nd/4.0/",
        "permits": ["Share", "Commercial use"], "requires": ["Attribution"], "prohibits": ["Sharing adaptations"],
        "explain": "Anyone may share the unchanged recording, even commercially, with credit. No remixes may be shared.",
        "allows_reuse": True,
    },
    "CC-BY-NC-ND-4.0": {
        "name": "Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International", "short": "CC BY-NC-ND 4.0", "version": "4.0",
        "url": "https://creativecommons.org/licenses/by-nc-nd/4.0/",
        "permits": ["Share"], "requires": ["Attribution"], "prohibits": ["Commercial use", "Sharing adaptations"],
        "explain": "Non-commercial sharing of the unchanged recording with credit only.",
        "allows_reuse": True,
    },
    "CC0-1.0": {
        "name": "CC0 1.0 Universal (public domain dedication)", "short": "CC0 1.0", "version": "1.0",
        "url": "https://creativecommons.org/publicdomain/zero/1.0/",
        "permits": ["Share", "Adapt", "Commercial use"], "requires": [], "prohibits": [],
        "explain": "You waive your rights to the extent the law allows. Only use this for work you fully own (recording and composition).",
        "allows_reuse": True,
    },
    "PDM-1.0": {
        "name": "Public Domain Mark 1.0", "short": "Public domain", "version": "1.0",
        "url": "https://creativecommons.org/publicdomain/mark/1.0/",
        "permits": ["Share", "Adapt", "Commercial use"], "requires": [], "prohibits": [],
        "explain": "For recordings already free of known copyright worldwide (e.g. very old recordings). Not for your own new work — use CC0 for that. Public-domain status varies by country.",
        "allows_reuse": True,
    },
}

RECORDING_ORIGINS = {
    "original": "I/we made this recording.",
    "cover": "This is our recording of a song written by someone else.",
    "remix": "This is a remix or edit of someone else's recording.",
    "contains_samples": "Our recording contains samples of other recordings.",
    "public_domain_recording": "This recording is in the public domain.",
}
COMPOSITION_ORIGINS = {
    "original": "The song (music and lyrics) was written by us.",
    "cover_licensed": "Someone else wrote the song; we have the licence needed to distribute a cover where we are.",
    "public_domain": "The composition is in the public domain.",
    "other": "Other / it's complicated — explained in the notes.",
}

WITHDRAWAL_NOTICE = (
    "Withdrawing a track stops streaming and new downloads on this platform. It cannot recall copies people have "
    "already downloaded, and it does not revoke permissions already granted under a Creative Commons licence or "
    "public-domain dedication for copies obtained while that licence applied."
)


def licence_summary(r: RightsDeclaration) -> dict:
    meta = LICENCES.get(r.licence_code, {})
    return {
        "code": r.licence_code, "name": meta.get("name", r.licence_code), "short": meta.get("short", r.licence_code),
        "version": r.licence_version, "url": r.licence_url, "attribution": r.attribution_text,
        "allows_reuse": meta.get("allows_reuse", False), "verification": r.verification,
        "declared_at": r.created_at.isoformat(),
    }


def catalogue() -> dict:
    return {
        "licences": [{"code": k, **v} for k, v in LICENCES.items()],
        "recording_origins": RECORDING_ORIGINS,
        "composition_origins": COMPOSITION_ORIGINS,
        "withdrawal_notice": WITHDRAWAL_NOTICE,
        "verification_notice": "Rights declarations are statements by the uploader. COMMONWAVE does not independently verify ownership.",
    }
