"""Content sniffing: decide what an upload *is* from its bytes, never its name.

Only three container/codec pairs are accepted: MP3 (MPEG-1/2/2.5 Layer III),
WAV (RIFF/RF64 WAVE) and FLAC (native). The sniffer is a cheap first gate; the
authoritative check is ffprobe inside the sandboxed adapter.
"""
from __future__ import annotations

_MP3_BITRATES = {
    # (version_bits, layer_bits=01 i.e. Layer III)
    3: [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0],  # MPEG-1
    2: [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0],      # MPEG-2
    0: [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0],      # MPEG-2.5
}
_MP3_RATES = {3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000]}


def _id3_skip(head: bytes) -> int:
    if len(head) >= 10 and head[:3] == b"ID3" and all(b < 0x80 for b in head[6:10]):
        size = (head[6] << 21) | (head[7] << 14) | (head[8] << 7) | head[9]
        footer = 10 if head[5] & 0x10 else 0
        return 10 + size + footer
    return 0


def _mp3_frame_len(h: bytes) -> int | None:
    if len(h) < 4 or h[0] != 0xFF or (h[1] & 0xE0) != 0xE0:
        return None
    version = (h[1] >> 3) & 0x03
    layer = (h[1] >> 1) & 0x03
    if version == 1 or layer != 1:  # reserved version, or not Layer III
        return None
    br_idx = (h[2] >> 4) & 0x0F
    sr_idx = (h[2] >> 2) & 0x03
    if br_idx in (0, 15) or sr_idx == 3:
        return None
    bitrate = _MP3_BITRATES[version][br_idx] * 1000
    rate = _MP3_RATES[version][sr_idx]
    padding = (h[2] >> 1) & 0x01
    coef = 144 if version == 3 else 72
    return coef * bitrate // rate + padding


def sniff(head: bytes) -> str | None:
    """Return 'mp3' | 'wav' | 'flac' or None for a buffer that starts at offset 0."""
    if len(head) >= 12 and head[:4] in (b"RIFF", b"RF64", b"BW64") and head[8:12] == b"WAVE":
        return "wav"
    skip = _id3_skip(head)
    return _sniff_body(head[skip:])


def _sniff_body(body: bytes) -> str | None:
    if body[:4] == b"fLaC":
        return "flac"
    # MP3: require two consecutive valid frame headers to avoid false positives.
    limit = min(len(body) - 4, 8192)
    for i in range(max(limit, 0)):
        if body[i] == 0xFF:
            n = _mp3_frame_len(body[i:i + 4])
            if n and i + n + 4 <= len(body) and _mp3_frame_len(body[i + n:i + n + 4]):
                return "mp3"
    return None


def sniff_file(path) -> str | None:
    with open(path, "rb") as f:
        head = f.read(16)
        if len(head) >= 12 and head[:4] in (b"RIFF", b"RF64", b"BW64") and head[8:12] == b"WAVE":
            return "wav"
        f.seek(0)
        skip = _id3_skip(f.read(10))
        f.seek(skip)
        return _sniff_body(f.read(64 * 1024))


def quick_reject(head: bytes) -> bool:
    """Cheap early rejection once the first few KiB of an upload have arrived."""
    if len(head) < 12:
        return False
    if head[:4] in (b"RIFF", b"RF64", b"BW64"):
        return head[8:12] != b"WAVE"
    if head[:3] == b"ID3" or head[:4] == b"fLaC":
        return False
    return sniff(head) is None


CONTENT_TYPES = {"mp3": "audio/mpeg", "wav": "audio/wav", "flac": "audio/flac"}
