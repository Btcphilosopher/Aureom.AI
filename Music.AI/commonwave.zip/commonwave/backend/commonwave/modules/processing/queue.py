"""PostgreSQL-backed job queue (FOR UPDATE SKIP LOCKED) with optional Redis wake-ups.

PostgreSQL is the source of truth, so a Redis outage never loses work; Redis is
only used to wake idle workers immediately instead of waiting for the next poll.
"""
from __future__ import annotations

import socket
import uuid
from datetime import timedelta

from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from commonwave.core.db import utcnow
from commonwave.core.ratelimit import _redis
from commonwave.models import Job

WAKE_KEY = "cw:jobs:wake"
WORKER_ID = f"{socket.gethostname()}:{uuid.uuid4().hex[:6]}"


def enqueue(db: Session, kind: str, payload: dict, *, requested_by=None, dedupe_key: str | None = None, max_attempts: int = 3) -> Job:
    if dedupe_key:
        existing = db.scalar(select(Job).where(Job.dedupe_key == dedupe_key, Job.status.in_(("queued", "running"))))
        if existing:
            return existing
    job = Job(kind=kind, payload=payload, requested_by=requested_by, dedupe_key=dedupe_key, max_attempts=max_attempts)
    db.add(job)
    try:
        with db.begin_nested():
            db.flush()
    except IntegrityError:
        return db.scalar(select(Job).where(Job.dedupe_key == dedupe_key, Job.status.in_(("queued", "running"))))
    r = _redis()
    if r is not None:
        try:
            r.lpush(WAKE_KEY, str(job.id))
            r.ltrim(WAKE_KEY, 0, 999)
        except Exception:
            pass
    return job


def claim(db: Session) -> Job | None:
    # Recover jobs whose worker died (locked for longer than the processing timeout + margin).
    db.execute(text("""
        UPDATE jobs SET status='queued', locked_at=NULL, locked_by=NULL
        WHERE status='running' AND locked_at < now() - interval '30 minutes'
    """))
    job = db.scalar(
        select(Job).where(Job.status == "queued", Job.run_after <= utcnow())
        .order_by(Job.run_after).limit(1).with_for_update(skip_locked=True)
    )
    if not job:
        return None
    job.status = "running"
    job.attempts += 1
    job.locked_at = utcnow()
    job.locked_by = WORKER_ID
    db.flush()
    return job


def finish(job: Job, result: dict | None = None) -> None:
    job.status = "succeeded"
    job.result = result or {}
    job.finished_at = utcnow()
    job.locked_at = None


def fail(job: Job, error: str, *, permanent: bool) -> None:
    job.last_error = error[:2000]
    job.locked_at = None
    if permanent or job.attempts >= job.max_attempts:
        job.status = "failed"
        job.finished_at = utcnow()
    else:
        job.status = "queued"
        job.run_after = utcnow() + timedelta(seconds=10 * 2 ** job.attempts)


def wait_for_work(timeout: float) -> None:
    r = _redis()
    if r is not None:
        try:
            r.brpop([WAKE_KEY], timeout=max(1, int(timeout)))
            return
        except Exception:
            pass
    import time
    time.sleep(timeout)
