"""Audio processing pipeline for one TrackVersion.

uploaded -> validating -> processing -> ready     (failed / cancelled on the side)

The original file is never modified. Outputs: a streaming MP3 derivative,
technical metadata, loudness measurement (for optional player normalisation),
waveform peaks and human-readable diagnostics.
"""
from __future__ import annotations

import hashlib
import logging
import shutil
import tempfile
import uuid
from pathlib import Path

from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core.db import utcnow
from commonwave.core.storage import get_storage
from commonwave.models import AudioAsset, TrackVersion
from commonwave.modules.processing import ffmpeg
from commonwave.modules.processing.ffmpeg import MediaToolError
from commonwave.modules.processing.sniff import sniff_file

log = logging.getLogger(__name__)


class Cancelled(Exception):
    pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _checkpoint(db: Session, version: TrackVersion, state: str | None = None) -> None:
    """Persist progress and honour cancellation. The state change is a conditional
    UPDATE so a concurrent cancel can never be overwritten."""
    from sqlalchemy import update

    db.commit()
    values = {"state": state} if state else {"state": TrackVersion.state}
    res = db.execute(update(TrackVersion).where(TrackVersion.id == version.id, TrackVersion.state != "cancelled").values(**values))
    db.commit()
    if res.rowcount == 0:
        raise Cancelled()
    db.refresh(version)


def process_version(db: Session, version_id: uuid.UUID) -> dict:
    s = get_settings()
    version = db.get(TrackVersion, version_id)
    if not version:
        return {"skipped": "missing"}
    if version.state in ("ready", "cancelled"):
        return {"skipped": version.state}
    original = db.get(AudioAsset, version.original_asset_id) if version.original_asset_id else None
    if not original:
        version.state = "failed"
        version.failure_reason = "Original upload is missing."
        return {"failed": "missing_original"}

    s.processing_work_dir.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="job-", dir=s.processing_work_dir)).resolve()
    work.chmod(0o700)
    diags: list[dict] = []
    try:
        _checkpoint(db, version, "validating")
        src = work / f"input.{version.source_format or 'bin'}"
        get_storage().get_to_path(original.storage_key, src)
        sniffed = sniff_file(src)
        if sniffed is None or sniffed != version.source_format:
            raise MediaToolError("content_mismatch", "File contents are not a supported MP3, WAV or FLAC stream.")
        info = ffmpeg.probe(src, work, sniffed)
        version.technical = {**info.as_dict(), "container": sniffed, "original_size_bytes": original.size_bytes}
        version.duration_ms = info.duration_ms
        if sniffed in ("wav", "flac") and info.sample_rate < 44100:
            diags.append({"level": "warning", "code": "low_sample_rate", "message":
                f"The upload's sample rate is {info.sample_rate} Hz. The stream is resampled to 44.1 kHz, which does not add high-frequency detail."})
        if info.channels > 2:
            diags.append({"level": "info", "code": "downmixed", "message": f"{info.channels}-channel audio is downmixed to stereo for streaming; the original is kept unchanged."})

        _checkpoint(db, version, "processing")
        kbps, more = ffmpeg.choose_stream_bitrate(info, s.stream_bitrate_kbps)
        diags += more
        out = work / "stream.mp3"
        ffmpeg.transcode_mp3(src, out, work, info, kbps)
        _checkpoint(db, version)

        try:
            loud = ffmpeg.measure_loudness(src, work, s.loudness_target_lufs)
            version.loudness_lufs = loud["integrated_lufs"]
            version.true_peak_dbtp = loud["true_peak_dbtp"]
            version.playback_gain_db = ffmpeg.playback_gain(loud["integrated_lufs"], loud["true_peak_dbtp"], s.loudness_target_lufs)
            if loud["true_peak_dbtp"] is not None and loud["true_peak_dbtp"] > 0.0:
                diags.append({"level": "warning", "code": "clipping_risk", "message":
                    f"True peak is {loud['true_peak_dbtp']:+.1f} dBTP; the master may clip on some playback systems."})
        except MediaToolError as e:
            diags.append({"level": "warning", "code": e.code, "message": "Loudness could not be measured; playback normalisation is off for this track."})

        version.waveform = ffmpeg.waveform_peaks(src, work)
        _checkpoint(db, version)

        key = f"streams/{version.track_id}/{version.id}.mp3"
        size = get_storage().put_file(key, out, "audio/mpeg")
        asset = AudioAsset(kind="stream_mp3", storage_key=key, content_type="audio/mpeg", size_bytes=size,
                           sha256=_sha256(out), format="mp3", artist_id=original.artist_id, track_version_id=version.id)
        db.add(asset)
        db.flush()
        version.stream_asset_id = asset.id
        version.technical = {**version.technical, "stream_bitrate_kbps": kbps, "stream_size_bytes": size}
        if s.hls_enabled:
            diags.append({"level": "info", "code": "hls_deferred", "message": "HLS renditions are not generated in this release."})
        version.diagnostics = diags
        version.state = "ready"
        version.processed_at = utcnow()
        version.failure_reason = None
        db.commit()
        return {"state": "ready", "duration_ms": version.duration_ms, "stream_kbps": kbps}
    except Cancelled:
        db.rollback()
        return {"state": "cancelled"}
    except MediaToolError as e:
        db.rollback()
        version = db.get(TrackVersion, version_id)
        if not e.permanent:
            raise
        version.state = "failed"
        version.failure_reason = str(e)[:300]
        version.diagnostics = diags + [{"level": "error", "code": e.code, "message": str(e)[:300]}]
        db.commit()
        return {"state": "failed", "code": e.code}
    finally:
        shutil.rmtree(work, ignore_errors=True)
