"""Constrained subprocess adapter for FFmpeg / FFprobe.

Rules enforced here (and covered by tests):

* Commands are argument *lists*; there is no shell, so file names can never be
  interpreted as shell syntax. Every argument is validated as a plain string
  without NUL bytes, and every file path must live inside the job's work dir.
* Only the configured ``ffmpeg``/``ffprobe`` binaries can be executed.
* Inputs are opened with ``-protocol_whitelist file,pipe`` so FFmpeg cannot be
  tricked (e.g. by a crafted playlist) into opening network or other URLs.
* Resource limits: wall-clock timeout, CPU seconds, address space, maximum
  output file size, open files. The child runs in its own session so the whole
  process group is killed on timeout.
* Minimal environment (no credentials are inherited).
* Optional network namespace isolation via ``unshare -n`` when the kernel
  permits it (``CW_PROCESSING_NETWORK_ISOLATION``).
"""
from __future__ import annotations

import json
import logging
import os
import re
import resource
import shutil
import signal
import subprocess
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from commonwave.config import get_settings

log = logging.getLogger(__name__)


class MediaToolError(Exception):
    def __init__(self, code: str, message: str, permanent: bool = True):
        super().__init__(message)
        self.code = code
        self.permanent = permanent


@dataclass
class ToolResult:
    returncode: int
    stdout: bytes
    stderr: str


@lru_cache
def _unshare_available() -> bool:
    exe = shutil.which("unshare")
    if not exe:
        return False
    try:
        r = subprocess.run([exe, "-n", "--", "true"], capture_output=True, timeout=5)
        return r.returncode == 0
    except Exception:
        return False


def network_isolation_active() -> bool:
    mode = get_settings().processing_network_isolation
    if mode == "off":
        return False
    ok = _unshare_available()
    if mode == "required" and not ok:
        raise MediaToolError("sandbox_unavailable", "Network isolation is required but unshare -n is not permitted", permanent=False)
    return ok


def _limits(cpu: int, mem: int, fsize: int):
    def apply():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu + 5))
        resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
        resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    return apply


_SAFE_ARG = re.compile(r"^[\w.,:=+\-/ ()\[\];'@%]*$")


def _validate_args(args: list[str], workdir: Path) -> None:
    root = workdir.resolve()
    for a in args:
        if not isinstance(a, str) or "\x00" in a or len(a) > 1024:
            raise MediaToolError("bad_argument", "Invalid media tool argument")
        if not _SAFE_ARG.match(a):
            raise MediaToolError("bad_argument", "Media tool argument contains unsupported characters")
        if a.startswith("/"):
            p = Path(a).resolve()
            if p != root and root not in p.parents:
                raise MediaToolError("bad_argument", "Media tool path outside work directory")


def run_tool(tool: str, args: list[str], workdir: Path, *, timeout: int | None = None, max_stdout: int = 64 * 1024 * 1024) -> ToolResult:
    s = get_settings()
    exe = {"ffmpeg": s.ffmpeg_path, "ffprobe": s.ffprobe_path}.get(tool)
    if not exe:
        raise MediaToolError("bad_tool", f"Tool {tool!r} is not permitted")
    resolved = shutil.which(exe)
    if not resolved:
        raise MediaToolError("tool_missing", f"{tool} is not installed", permanent=False)
    _validate_args(args, workdir)
    cmd = [resolved, *args]
    if network_isolation_active():
        cmd = [shutil.which("unshare"), "-n", "--", *cmd]
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LC_ALL": "C", "HOME": str(workdir)}
    timeout = timeout or s.processing_timeout_seconds
    proc = subprocess.Popen(
        cmd, cwd=str(workdir), env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        preexec_fn=_limits(s.processing_cpu_seconds, s.processing_memory_bytes, s.processing_max_output_bytes),
        close_fds=True, shell=False,
    )
    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        proc.communicate()
        raise MediaToolError("timeout", f"{tool} exceeded the {timeout}s processing time limit")
    if len(out) > max_stdout:
        raise MediaToolError("output_too_large", f"{tool} produced more output than permitted")
    stderr = err.decode("utf-8", "replace")[-20000:]
    if proc.returncode < 0:
        sig = -proc.returncode
        if sig in (signal.SIGXCPU, signal.SIGKILL):
            raise MediaToolError("cpu_limit", f"{tool} exceeded its CPU limit")
        if sig == signal.SIGXFSZ:
            raise MediaToolError("output_limit", f"{tool} exceeded the output size limit")
        raise MediaToolError("crashed", f"{tool} terminated by signal {sig}")
    return ToolResult(proc.returncode, out, stderr)


INPUT_GUARD = ["-protocol_whitelist", "file,pipe"]
PCM_CODECS = {"pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_f32le", "pcm_f64le", "pcm_u8", "pcm_s16be", "pcm_s24be"}
EXPECTED = {"mp3": ({"mp3"}, {"mp3"}), "wav": ({"wav"}, PCM_CODECS), "flac": ({"flac"}, {"flac"})}


@dataclass
class ProbeInfo:
    format_name: str
    codec: str
    duration_ms: int
    sample_rate: int
    channels: int
    bit_rate: int | None
    bits_per_sample: int | None

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def probe(path: Path, workdir: Path, expected_format: str) -> ProbeInfo:
    r = run_tool("ffprobe", ["-v", "error", *INPUT_GUARD, "-print_format", "json", "-show_format", "-show_streams", str(path)], workdir, timeout=60)
    if r.returncode != 0:
        raise MediaToolError("unreadable", "The file could not be decoded as audio (it may be truncated or corrupt).")
    try:
        data = json.loads(r.stdout or b"{}")
    except json.JSONDecodeError:
        raise MediaToolError("unreadable", "Unexpected probe output")
    fmt = data.get("format", {})
    streams = [st for st in data.get("streams", []) if st.get("codec_type") == "audio"]
    others = [st for st in data.get("streams", []) if st.get("codec_type") != "audio" and not st.get("disposition", {}).get("attached_pic")]
    if not streams:
        raise MediaToolError("no_audio", "The file contains no audio stream.")
    if others:
        raise MediaToolError("unexpected_streams", "The file contains video or data streams; upload audio only.")
    st = streams[0]
    fmt_names, codecs = EXPECTED[expected_format]
    names = set((fmt.get("format_name") or "").split(","))
    if not names & fmt_names or st.get("codec_name") not in codecs:
        raise MediaToolError("format_mismatch", f"File content does not match a supported {expected_format.upper()} encoding.")
    try:
        duration = float(fmt.get("duration") or st.get("duration") or 0)
    except ValueError:
        duration = 0
    if duration <= 0.5:
        raise MediaToolError("too_short", "Audio must be longer than half a second.")
    if duration > get_settings().max_track_duration_seconds:
        raise MediaToolError("too_long", f"Audio is longer than the {get_settings().max_track_duration_seconds // 60}-minute limit.")
    rate = int(st.get("sample_rate") or 0)
    ch = int(st.get("channels") or 0)
    if not (8000 <= rate <= 384000) or not (1 <= ch <= 8):
        raise MediaToolError("unsupported_layout", "Unsupported sample rate or channel layout.")
    br = st.get("bit_rate") or fmt.get("bit_rate")
    bps = st.get("bits_per_raw_sample") or st.get("bits_per_sample")
    return ProbeInfo(
        format_name=expected_format, codec=st.get("codec_name"), duration_ms=int(duration * 1000),
        sample_rate=rate, channels=ch, bit_rate=int(br) if br and str(br).isdigit() else None,
        bits_per_sample=int(bps) if bps and str(bps).isdigit() and int(bps) > 0 else None,
    )


STANDARD_MP3_BITRATES = [64, 96, 112, 128, 160, 192, 224, 256, 320]


def choose_stream_bitrate(info: ProbeInfo, target_kbps: int) -> tuple[int, list[dict]]:
    diags: list[dict] = []
    if info.codec == "mp3":
        src = (info.bit_rate or 0) // 1000
        if src and src < target_kbps:
            chosen = max([b for b in STANDARD_MP3_BITRATES if b <= max(src, 64)] or [64])
            diags.append({"level": "info", "code": "lossy_source_low_bitrate", "message":
                f"The upload is a {src} kbps MP3. The streaming copy is encoded at {chosen} kbps: re-encoding at a higher bitrate would enlarge the file without restoring detail lost by the original encoding."})
            return chosen, diags
        diags.append({"level": "info", "code": "lossy_source", "message":
            "The upload is already lossy (MP3), so the streaming copy is a second-generation encode. Upload WAV or FLAC for the best streaming quality."})
    return target_kbps, diags


def transcode_mp3(src: Path, dest: Path, workdir: Path, info: ProbeInfo, kbps: int) -> None:
    channels = "2" if info.channels >= 2 else "1"
    args = [
        "-nostdin", "-hide_banner", "-v", "error", "-y", *INPUT_GUARD, "-i", str(src),
        "-map", "0:a:0", "-map_metadata", "-1", "-vn", "-sn", "-dn",
        "-ac", channels, "-ar", "44100", "-c:a", "libmp3lame", "-b:a", f"{kbps}k",
        "-write_xing", "1", "-id3v2_version", "0", "-f", "mp3", str(dest),
    ]
    r = run_tool("ffmpeg", args, workdir)
    if r.returncode != 0 or not dest.exists() or dest.stat().st_size < 1000:
        raise MediaToolError("transcode_failed", "Could not encode the streaming MP3: " + r.stderr.strip()[-300:])


def measure_loudness(src: Path, workdir: Path, target: float) -> dict:
    args = ["-nostdin", "-hide_banner", "-v", "info", *INPUT_GUARD, "-i", str(src), "-map", "0:a:0",
            "-af", f"loudnorm=I={target}:TP=-1.0:LRA=11:print_format=json", "-f", "null", "-"]
    r = run_tool("ffmpeg", args, workdir)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if r.returncode != 0 or not m:
        raise MediaToolError("loudness_failed", "Loudness measurement failed", permanent=False)
    d = json.loads(m.group(0))
    def num(k):
        try:
            v = float(d[k])
            return v if v not in (float("inf"), float("-inf")) else None
        except (KeyError, ValueError):
            return None
    return {"integrated_lufs": num("input_i"), "true_peak_dbtp": num("input_tp"), "lra": num("input_lra")}


def playback_gain(lufs: float | None, peak: float | None, target: float) -> float | None:
    """Gain the *player* may apply (never baked into files). Positive gain is
    limited so the true peak stays below -1 dBTP."""
    if lufs is None:
        return None
    gain = target - lufs
    if peak is not None:
        gain = min(gain, -1.0 - peak)
    return round(max(-20.0, min(gain, 12.0)), 2)


def waveform_peaks(src: Path, workdir: Path, buckets: int = 600) -> list[float]:
    import numpy as np

    args = ["-nostdin", "-hide_banner", "-v", "error", *INPUT_GUARD, "-i", str(src), "-map", "0:a:0",
            "-ac", "1", "-ar", "8000", "-f", "s16le", "-c:a", "pcm_s16le", "pipe:1"]
    r = run_tool("ffmpeg", args, workdir, max_stdout=8000 * 2 * (get_settings().max_track_duration_seconds + 10))
    if r.returncode != 0 or not r.stdout:
        raise MediaToolError("waveform_failed", "Could not decode audio for the waveform")
    samples = np.frombuffer(r.stdout[: len(r.stdout) // 2 * 2], dtype="<i2").astype(np.float32) / 32768.0
    if samples.size == 0:
        return [0.0] * buckets
    edges = np.linspace(0, samples.size, buckets + 1).astype(int)
    peaks = np.array([np.abs(samples[a:b]).max() if b > a else 0.0 for a, b in zip(edges[:-1], edges[1:])])
    top = peaks.max() or 1.0
    return [round(float(p / top), 3) for p in peaks]
