"""Resumable uploads implementing the tus 1.0.0 core protocol plus the
``creation``, ``termination`` and ``expiration`` extensions (https://tus.io/protocols/resumable-upload).

Flow: POST creates an upload (and a draft track if needed) → PATCH appends bytes
at ``Upload-Offset`` → HEAD reports the offset so an interrupted client resumes →
on the final byte the file is content-sniffed, moved into private object storage
and a processing job is queued.
"""
from __future__ import annotations

import base64
import logging
import os
import uuid
from datetime import timedelta
from pathlib import Path

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import func, select
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session
from starlette.requests import ClientDisconnect

from commonwave.config import get_settings
from commonwave.core import ratelimit
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, require_active_user, require_artist_perm, require_user
from commonwave.core.errors import ApiError, bad_request, not_found
from commonwave.core.sanitize import clean_line, safe_filename
from commonwave.core.storage import get_storage
from commonwave.models import AudioAsset, Track, TrackVersion, Upload
from commonwave.modules.catalogue.service import artist_storage_used, refresh_track_search
from commonwave.modules.processing.queue import enqueue
from commonwave.modules.processing.sniff import CONTENT_TYPES, quick_reject, sniff_file

log = logging.getLogger(__name__)
router = APIRouter(tags=["uploads"])

TUS_VERSION = "1.0.0"
TUS_HEADERS = {"Tus-Resumable": TUS_VERSION}
SNIFF_AFTER = 8192


def _staging(upload_id: uuid.UUID) -> Path:
    d = get_settings().upload_staging_dir.resolve()
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{upload_id}.part"


def _parse_metadata(header: str | None) -> dict[str, str]:
    out: dict[str, str] = {}
    for pair in (header or "").split(","):
        pair = pair.strip()
        if not pair:
            continue
        key, _, value = pair.partition(" ")
        try:
            out[key] = base64.b64decode(value).decode("utf-8") if value else ""
        except Exception:
            raise bad_request("invalid_metadata", "Upload-Metadata must be base64 encoded")
    return out


def _check_tus(request: Request) -> None:
    if request.headers.get("tus-resumable") != TUS_VERSION:
        raise ApiError(412, "tus_version", "Unsupported Tus-Resumable version", headers={"Tus-Version": TUS_VERSION})


def _own_upload(db: Session, viewer: Viewer, upload_id: uuid.UUID, lock: bool = False) -> Upload:
    q = select(Upload).where(Upload.id == upload_id)
    if lock:
        q = q.with_for_update(nowait=True)
    try:
        up = db.scalar(q)
    except OperationalError:
        db.rollback()
        raise ApiError(423, "upload_locked", "Another request is writing to this upload; retry shortly.", headers=TUS_HEADERS)
    # Uploads are visible only to the user who created them.
    if not up or up.user_id != viewer.id:
        raise not_found("upload")
    return up


def _upload_headers(up: Upload) -> dict[str, str]:
    return {**TUS_HEADERS, "Upload-Offset": str(up.offset), "Upload-Length": str(up.length),
            "Upload-Expires": up.expires_at.strftime("%a, %d %b %Y %H:%M:%S GMT"), "Cache-Control": "no-store"}


@router.options("/uploads", include_in_schema=False)
def tus_options():
    s = get_settings()
    return Response(status_code=204, headers={**TUS_HEADERS, "Tus-Version": TUS_VERSION,
                                              "Tus-Extension": "creation,termination,expiration",
                                              "Tus-Max-Size": str(s.max_upload_bytes)})


@router.post("/uploads", status_code=201, summary="Create a resumable upload (tus creation)")
def create_upload(request: Request, viewer: Viewer = Depends(require_active_user), db: Session = Depends(get_db)):
    _check_tus(request)
    ratelimit.enforce("upload_create", request, str(viewer.id))
    s = get_settings()
    try:
        length = int(request.headers.get("upload-length", ""))
    except ValueError:
        raise bad_request("length_required", "Upload-Length header is required (deferred length is not supported)")
    if length <= 0:
        raise bad_request("empty_upload", "The file is empty.")
    if length > s.max_upload_bytes:
        raise ApiError(413, "too_large", f"Files may be at most {s.max_upload_bytes // (1024 * 1024)} MB.", headers=TUS_HEADERS)
    meta = _parse_metadata(request.headers.get("upload-metadata"))
    try:
        artist_id = uuid.UUID(meta.get("artist_id", ""))
    except ValueError:
        raise bad_request("artist_required", "Upload-Metadata must include artist_id")
    artist = require_artist_perm(db, viewer, artist_id, "upload")
    quota = artist.storage_quota_bytes or s.default_artist_storage_quota_bytes
    if artist_storage_used(db, artist.id) + length > quota:
        raise ApiError(413, "quota_exceeded", "This upload would exceed the artist's storage quota.", headers=TUS_HEADERS)
    active = db.scalar(select(func.count()).select_from(Upload).where(Upload.user_id == viewer.id, Upload.status == "in_progress", Upload.expires_at > utcnow()))
    if active >= s.max_active_uploads_per_user:
        raise ApiError(429, "too_many_uploads", "Finish or cancel your other uploads first.", headers=TUS_HEADERS)
    filename = safe_filename(meta.get("filename", "upload"))
    if meta.get("track_id"):
        try:
            track = db.get(Track, uuid.UUID(meta["track_id"]))
        except ValueError:
            track = None
        if not track or track.artist_id != artist.id:
            raise not_found("track")
    else:
        title = clean_line(meta.get("title") or os.path.splitext(filename)[0].replace("_", " "), 200) or "Untitled"
        track = Track(artist_id=artist.id, title=title, created_by=viewer.id)
        db.add(track)
        db.flush()
        refresh_track_search(db, track.id)
    up = Upload(user_id=viewer.id, artist_id=artist.id, track_id=track.id, filename=filename, length=length,
                expires_at=utcnow() + timedelta(hours=s.upload_expiry_hours))
    db.add(up)
    db.flush()
    _staging(up.id).touch(mode=0o600)
    audit(db, viewer.id, "upload.create", "track", track.id, upload=up.id, size=length)
    return Response(status_code=201, headers={**_upload_headers(up), "Location": f"/api/v1/uploads/{up.id}",
                                              "X-Track-Id": str(track.id), "Access-Control-Expose-Headers": "Location, Upload-Offset, X-Track-Id"})


@router.head("/uploads/{upload_id}", summary="Get upload offset (tus)")
def head_upload(upload_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    up = _own_upload(db, viewer, upload_id)
    if up.status in ("cancelled", "expired", "rejected") or (up.status == "in_progress" and up.expires_at < utcnow()):
        return Response(status_code=410, headers=TUS_HEADERS)
    return Response(status_code=200, headers=_upload_headers(up))


@router.get("/uploads/{upload_id}")
def get_upload(upload_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    up = _own_upload(db, viewer, upload_id)
    v = db.scalar(select(TrackVersion).where(TrackVersion.upload_id == up.id))
    return {"id": str(up.id), "status": up.status, "offset": up.offset, "length": up.length, "filename": up.filename,
            "track_id": str(up.track_id), "version_id": str(v.id) if v else None, "rejection_reason": up.rejection_reason,
            "expires_at": up.expires_at.isoformat()}


def _reject(db: Session, up: Upload, reason: str, status: int = 415) -> ApiError:
    up.status = "rejected"
    up.rejection_reason = reason
    _staging(up.id).unlink(missing_ok=True)
    db.commit()
    return ApiError(status, "invalid_audio", reason, headers=TUS_HEADERS)


@router.patch("/uploads/{upload_id}", summary="Append bytes (tus)")
async def patch_upload(upload_id: uuid.UUID, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    _check_tus(request)
    ratelimit.enforce("upload_chunk", request, str(viewer.id))
    if request.headers.get("content-type") != "application/offset+octet-stream":
        raise ApiError(415, "content_type", "Content-Type must be application/offset+octet-stream", headers=TUS_HEADERS)
    up = _own_upload(db, viewer, upload_id, lock=True)
    if up.status != "in_progress" or up.expires_at < utcnow():
        raise ApiError(410, "upload_gone", "This upload is no longer active.", headers=TUS_HEADERS)
    try:
        client_offset = int(request.headers.get("upload-offset", ""))
    except ValueError:
        raise bad_request("offset_required", "Upload-Offset header is required")
    if client_offset != up.offset:
        raise ApiError(409, "offset_mismatch", "Upload-Offset does not match the server offset. Send HEAD to resume.", headers=_upload_headers(up))
    path = _staging(up.id)
    written = up.offset
    disconnected = False
    with open(path, "r+b") as f:
        f.seek(up.offset)
        try:
            async for chunk in request.stream():
                if not chunk:
                    continue
                if written + len(chunk) > up.length:
                    f.truncate(up.offset)
                    raise ApiError(413, "length_exceeded", "More bytes were sent than Upload-Length declared.", headers=TUS_HEADERS)
                f.write(chunk)
                written += len(chunk)
        except ClientDisconnect:
            disconnected = True  # keep what arrived; the client resumes from HEAD
        f.flush()
        os.fsync(f.fileno())
    previous = up.offset
    up.offset = written
    if previous < SNIFF_AFTER <= written or (written == up.length and previous < SNIFF_AFTER):
        with open(path, "rb") as f:
            head = f.read(SNIFF_AFTER)
        if quick_reject(head):
            raise _reject(db, up, "This file is not MP3, WAV or FLAC audio (checked by content, not file name).")
    if written == up.length:
        _complete(db, viewer, up, path)
    db.commit()
    if disconnected:
        return Response(status_code=204, headers=_upload_headers(up))
    return Response(status_code=204, headers={**_upload_headers(up), "X-Track-Id": str(up.track_id)})


def _complete(db: Session, viewer: Viewer, up: Upload, path: Path) -> None:
    fmt = sniff_file(path)
    if fmt not in CONTENT_TYPES:
        raise _reject(db, up, "This file is not MP3, WAV or FLAC audio (checked by content, not file name).")
    track = db.get(Track, up.track_id)
    number = (db.scalar(select(func.max(TrackVersion.version_number)).where(TrackVersion.track_id == track.id)) or 0) + 1
    version = TrackVersion(track_id=track.id, version_number=number, state="uploaded", upload_id=up.id,
                           source_format=fmt, original_filename=up.filename)
    db.add(version)
    db.flush()
    key = f"originals/{up.artist_id}/{version.id}.{fmt}"
    size = get_storage().put_file(key, path, CONTENT_TYPES[fmt])
    asset = AudioAsset(kind="original", storage_key=key, content_type=CONTENT_TYPES[fmt], size_bytes=size, format=fmt,
                       artist_id=up.artist_id, track_version_id=version.id)
    db.add(asset)
    db.flush()
    version.original_asset_id = asset.id
    up.status = "complete"
    up.sniffed_format = fmt
    path.unlink(missing_ok=True)
    enqueue(db, "process_version", {"version_id": str(version.id)}, requested_by=viewer.id, dedupe_key=f"process:{version.id}")
    audit(db, viewer.id, "upload.complete", "track", track.id, version=version.id, format=fmt, size=size)


@router.delete("/uploads/{upload_id}", status_code=204, summary="Cancel an upload (tus termination)")
def delete_upload(upload_id: uuid.UUID, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    up = _own_upload(db, viewer, upload_id, lock=True)
    if up.status == "in_progress":
        up.status = "cancelled"
        _staging(up.id).unlink(missing_ok=True)
        track = db.get(Track, up.track_id)
        # Remove an empty draft created solely for this upload.
        if track and track.status == "draft" and not db.scalar(select(TrackVersion.id).where(TrackVersion.track_id == track.id)):
            other = db.scalar(select(Upload.id).where(Upload.track_id == track.id, Upload.id != up.id, Upload.status == "in_progress"))
            if not other:
                db.delete(track)
    return Response(status_code=204, headers=TUS_HEADERS)


def expire_stale_uploads(db: Session) -> int:
    rows = db.scalars(select(Upload).where(Upload.status == "in_progress", Upload.expires_at < utcnow())).all()
    for up in rows:
        up.status = "expired"
        _staging(up.id).unlink(missing_ok=True)
    return len(rows)
