"""Asynchronous bundles: release download archives, artist data exports and user data exports."""
from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import uuid
import zipfile
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core.db import utcnow
from commonwave.core.storage import get_storage
from commonwave.models import (
    ArtistMembership, ArtistProfile, Artwork, AudioAsset, Comment, Follow, ListenHistory, Playlist, PlaylistEntry,
    Release, ReleaseTrack, RightsDeclaration, Save, Track, TrackVersion, User,
)
from commonwave.modules.rights.licences import LICENCES, WITHDRAWAL_NOTICE


def release_fingerprint(db: Session, r: Release) -> str:
    rows = db.execute(select(ReleaseTrack.position, Track.current_version_id, Track.status, Track.download_mp3)
                      .join(Track, Track.id == ReleaseTrack.track_id).where(ReleaseTrack.release_id == r.id).order_by(ReleaseTrack.position)).all()
    raw = json.dumps([[p, str(v), s, d] for p, v, s, d in rows] + [r.title, str(r.artwork_id)])
    return hashlib.sha256(raw.encode()).hexdigest()


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _safe(name: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9 ._()-]+", "_", name).strip()[:100] or "untitled"


def build_release_archive(db: Session, release_id: uuid.UUID) -> dict:
    r = db.get(Release, release_id)
    if not r or not r.is_public:
        return {"skipped": "release_unavailable"}
    artist = db.get(ArtistProfile, r.artist_id)
    fp = release_fingerprint(db, r)
    work = Path(tempfile.mkdtemp(dir=_workdir()))
    try:
        zpath = work / "release.zip"
        lines = [f"{r.title} — {artist.name}", f"Downloaded from {get_settings().site_name}", ""]
        with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_STORED) as z:  # MP3/JPEG are already compressed
            rows = db.execute(select(Track, ReleaseTrack.position).join(ReleaseTrack, ReleaseTrack.track_id == Track.id)
                              .where(ReleaseTrack.release_id == r.id).order_by(ReleaseTrack.position)).all()
            for t, pos in rows:
                if not t.is_public or not t.download_mp3:
                    continue
                v = db.get(TrackVersion, t.current_version_id)
                asset = db.get(AudioAsset, v.stream_asset_id)
                local = work / f"{pos}.mp3"
                get_storage().get_to_path(asset.storage_key, local)
                z.write(local, f"{pos:02d} - {_safe(t.title)}.mp3")
                local.unlink()
                rd = db.scalar(select(RightsDeclaration).where(RightsDeclaration.track_id == t.id, RightsDeclaration.superseded_at.is_(None)))
                lic = LICENCES.get(rd.licence_code, {}) if rd else {}
                lines.append(f"{pos:02d}. {t.title}")
                lines.append(f"    Licence: {lic.get('name', 'All rights reserved')}{' — ' + rd.licence_url if rd and rd.licence_url else ''}")
                if rd and rd.attribution_text:
                    lines.append(f"    Attribution: {rd.attribution_text}")
                for c in t.credits or []:
                    lines.append(f"    {c.get('role')}: {c.get('name')}")
            if r.artwork_id:
                art = db.get(Artwork, r.artwork_id)
                p = work / "cover.jpg"
                get_storage().get_to_path(art.key_large, p)
                z.write(p, "cover.jpg")
                lines.append("")
                lines.append(f"Cover artwork: {art.credit or artist.name} (artwork may be licensed separately from the music).")
            lines += ["", "Rights note: 'All rights reserved' tracks are for personal listening only.", WITHDRAWAL_NOTICE]
            z.writestr("LICENCE-AND-CREDITS.txt", "\n".join(lines) + "\n")
        key = f"archives/{r.id}/{fp[:16]}.zip"
        size = get_storage().put_file(key, zpath, "application/zip")
        old = db.get(AudioAsset, r.archive_asset_id) if r.archive_asset_id else None
        asset = AudioAsset(kind="archive", storage_key=key, content_type="application/zip", size_bytes=size, sha256=_sha(zpath),
                           format="zip", artist_id=None)  # archives are derived copies; not charged to the artist quota
        db.add(asset)
        db.flush()
        r.archive_asset_id = asset.id
        r.archive_fingerprint = fp
        if old and old.storage_key != key:
            get_storage().delete(old.storage_key)
            old.deleted_at = utcnow()
        return {"release_id": str(r.id), "size_bytes": size}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _workdir() -> Path:
    d = get_settings().processing_work_dir
    d.mkdir(parents=True, exist_ok=True)
    return d


def _iso(v):
    return v.isoformat() if v is not None and hasattr(v, "isoformat") else v


def _row(obj, fields: list[str]) -> dict:
    return {f: (str(getattr(obj, f)) if isinstance(getattr(obj, f), uuid.UUID) else _iso(getattr(obj, f))) for f in fields}


def build_artist_export(db: Session, artist_id: uuid.UUID, requested_by: uuid.UUID, include_originals: bool = True) -> dict:
    from commonwave.modules.analytics.stats import artist_stats

    a = db.get(ArtistProfile, artist_id)
    work = Path(tempfile.mkdtemp(dir=_workdir()))
    try:
        zpath = work / "export.zip"
        tracks = db.scalars(select(Track).where(Track.artist_id == a.id)).all()
        releases = db.scalars(select(Release).where(Release.artist_id == a.id)).all()
        data = {
            "format": "commonwave-artist-export", "format_version": 1, "exported_at": utcnow().isoformat(),
            "artist": _row(a, ["id", "slug", "name", "kind", "bio", "location", "links", "support_url", "verification_status", "created_at"]),
            "members": [{"username": u.username, "role": m.role} for m, u in db.execute(
                select(ArtistMembership, User).join(User, User.id == ArtistMembership.user_id).where(ArtistMembership.artist_id == a.id)).all()],
            "tracks": [], "releases": [],
            "statistics_last_365_days": artist_stats(db, a.id, days=365),
            "note": "Statistics are aggregated. Individual listener identities are never included.",
        }
        with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for t in tracks:
                item = _row(t, ["id", "title", "description", "genre", "tags", "language", "explicit", "lyrics", "credits",
                                "collaborators", "status", "published_at", "withdrawn_at", "download_mp3", "download_original", "created_at"])
                item["rights_history"] = [_row(r, ["licence_code", "licence_version", "licence_url", "attribution_text", "recording_origin",
                                                   "composition_origin", "composition_details", "samples_details", "remix_details",
                                                   "source_notes", "verification", "created_at", "superseded_at"])
                                          for r in db.scalars(select(RightsDeclaration).where(RightsDeclaration.track_id == t.id).order_by(RightsDeclaration.created_at))]
                item["versions"] = []
                for v in db.scalars(select(TrackVersion).where(TrackVersion.track_id == t.id).order_by(TrackVersion.version_number)):
                    vi = _row(v, ["version_number", "state", "source_format", "original_filename", "duration_ms", "technical",
                                  "loudness_lufs", "true_peak_dbtp", "diagnostics", "created_at", "published_at", "replaced_at"])
                    if include_originals and v.original_asset_id and v.state != "cancelled":
                        asset = db.get(AudioAsset, v.original_asset_id)
                        if asset and not asset.deleted_at and get_storage().stat(asset.storage_key):
                            local = work / "tmp.audio"
                            get_storage().get_to_path(asset.storage_key, local)
                            arc = f"audio/{_safe(t.title)}-{str(t.id)[:8]}-v{v.version_number}.{asset.format}"
                            z.write(local, arc, compress_type=zipfile.ZIP_STORED)
                            local.unlink()
                            vi["original_file"] = arc
                    item["versions"].append(vi)
                data["tracks"].append(item)
            for r in releases:
                ri = _row(r, ["id", "title", "kind", "description", "genre", "tags", "release_date", "credits", "status", "published_at"])
                ri["track_ids"] = [str(e.track_id) for e in r.entries]
                data["releases"].append(ri)
            for art in db.scalars(select(Artwork).where(Artwork.artist_id == a.id)):
                local = work / "art.jpg"
                if get_storage().stat(art.key_large):
                    get_storage().get_to_path(art.key_large, local)
                    z.write(local, f"artwork/{art.id}.jpg", compress_type=zipfile.ZIP_STORED)
            z.writestr("commonwave-export.json", json.dumps(data, indent=2, ensure_ascii=False, default=str))
            z.writestr("README.txt", "COMMONWAVE artist export.\ncommonwave-export.json holds metadata, rights history and aggregated statistics.\n"
                                     "audio/ holds your original uploads exactly as received. artwork/ holds processed artwork.\n")
        key = f"exports/artist/{a.id}/{uuid.uuid4()}.zip"
        size = get_storage().put_file(key, zpath, "application/zip")
        asset = AudioAsset(kind="export", storage_key=key, content_type="application/zip", size_bytes=size, sha256=_sha(zpath), format="zip")
        db.add(asset)
        db.flush()
        return {"asset_id": str(asset.id), "size_bytes": size, "tracks": len(tracks), "releases": len(releases)}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def user_export(db: Session, user: User) -> dict:
    """Synchronous JSON export of a listener's own data (small)."""
    playlists = []
    for p in db.scalars(select(Playlist).where(Playlist.owner_id == user.id)):
        entries = db.scalars(select(PlaylistEntry).where(PlaylistEntry.playlist_id == p.id).order_by(PlaylistEntry.position)).all()
        playlists.append({**_row(p, ["id", "title", "description", "visibility", "allow_duplicates", "created_at"]),
                          "track_ids": [str(e.track_id) for e in entries]})
    return {
        "format": "commonwave-user-export", "format_version": 1, "exported_at": utcnow().isoformat(),
        "account": _row(user, ["id", "username", "display_name", "email", "created_at", "history_enabled", "personalisation_enabled", "interests"]),
        "playlists": playlists,
        "follows": [str(f.artist_id) for f in db.scalars(select(Follow).where(Follow.user_id == user.id))],
        "saves": [{"type": s.target_type, "id": str(s.target_id), "at": s.created_at.isoformat()} for s in db.scalars(select(Save).where(Save.user_id == user.id))],
        "comments": [_row(c, ["id", "track_id", "body", "timestamp_ms", "status", "created_at"]) for c in db.scalars(select(Comment).where(Comment.user_id == user.id))],
        "listening_history": [{"track_id": str(h.track_id), "played_at": h.played_at.isoformat()} for h in db.scalars(select(ListenHistory).where(ListenHistory.user_id == user.id))],
    }
