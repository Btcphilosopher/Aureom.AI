"""Data export endpoints and job status."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core.audit import audit
from commonwave.core.db import get_db
from commonwave.core.deps import Viewer, can, get_viewer, require_artist_perm, require_user
from commonwave.core.errors import not_found
from commonwave.core.security import check_media_signature, signed_media_params
from commonwave.core.storage import get_storage
from commonwave.models import AudioAsset, Job
from commonwave.modules.exports.archive import user_export
from commonwave.modules.processing.queue import enqueue

router = APIRouter(tags=["exports"])
media = APIRouter(tags=["media"])


@router.post("/artists/{artist_id}/export", status_code=202)
def request_artist_export(artist_id: uuid.UUID, include_originals: bool = True, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, artist_id, "export")
    job = enqueue(db, "artist_export", {"artist_id": str(artist_id), "include_originals": include_originals},
                  requested_by=viewer.id, dedupe_key=f"export:{artist_id}:{viewer.id}")
    audit(db, viewer.id, "artist.export_requested", "artist", artist_id)
    return {"job_id": str(job.id), "status": job.status}


@router.get("/me/export")
def export_me(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    data = user_export(db, viewer.user)
    return JSONResponse(data, headers={"Content-Disposition": 'attachment; filename="commonwave-my-data.json"', "Cache-Control": "no-store"})


@router.get("/jobs/{job_id}")
def job_status(job_id: uuid.UUID, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    job = db.get(Job, job_id)
    if not job:
        raise not_found("job")
    # Jobs are visible to whoever requested them, staff, or — for public release archives — anyone.
    if job.kind != "build_release_archive" and not (viewer.is_staff or (viewer.id and job.requested_by == viewer.id)):
        raise not_found("job")
    out = {"id": str(job.id), "kind": job.kind, "status": job.status, "attempts": job.attempts,
           "created_at": job.created_at.isoformat(), "finished_at": job.finished_at.isoformat() if job.finished_at else None,
           "error": job.last_error if job.status == "failed" and (viewer.is_staff or job.requested_by == viewer.id) else None}
    if job.kind == "artist_export" and job.status == "succeeded" and viewer.id and can(db, viewer, uuid.UUID(job.payload["artist_id"]), "export"):
        aid = job.result["asset_id"]
        p = signed_media_params("export", aid, get_settings().download_url_ttl_seconds, scope=str(viewer.id))
        out["download_url"] = f"/media/export/{aid}?exp={p['exp']}&sig={p['sig']}&scope={viewer.id}"
        out["size_bytes"] = job.result.get("size_bytes")
    return out


@media.get("/media/export/{asset_id}")
def media_export(asset_id: uuid.UUID, request: Request, exp: str | None = None, sig: str | None = None, scope: str = "",
                 viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    from commonwave.modules.playback.router import _media_error, serve_object

    if check_media_signature("export", str(asset_id), exp, sig, scope) != "ok" or not viewer.id or scope != str(viewer.id):
        return _media_error(403, "invalid_signature", "This export link is not valid for your session.")
    asset = db.get(AudioAsset, asset_id)
    if not asset or asset.kind != "export":
        return _media_error(404, "not_found", "Export not found.")
    info = get_storage().stat(asset.storage_key)
    return serve_object(request, asset.storage_key, info.size, "application/zip", None, cache="private, no-store",
                        disposition='attachment; filename="commonwave-artist-export.zip"')
