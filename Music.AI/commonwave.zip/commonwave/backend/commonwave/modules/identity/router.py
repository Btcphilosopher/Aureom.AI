"""Accounts, sessions, privacy settings, artist profiles and band memberships."""
from __future__ import annotations

import re
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, EmailStr, Field, field_validator
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core import ratelimit
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, get_viewer, membership_role, require_artist_perm, require_user
from commonwave.core.errors import ApiError, bad_request, conflict, not_found
from commonwave.core.sanitize import clean_line, clean_text, clean_url, slugify
from commonwave.core.security import hash_password, ip_hash, new_token, token_digest, verify_password
from commonwave.core.siteconfig import get_config
from commonwave.models import ArtistMembership, ArtistProfile, AuthSession, Follow, ListenHistory, Release, Track, User
from commonwave.modules.catalogue.service import artist_brief, artist_visible, artwork_url, refresh_artist_search, serialize_track

router = APIRouter(tags=["identity"])

USERNAME = re.compile(r"^[a-zA-Z0-9_]{3,32}$")
RESERVED = {"admin", "api", "media", "upload", "settings", "moderator", "commonwave", "root", "support", "system"}


class RegisterIn(BaseModel):
    email: EmailStr
    username: str
    password: str = Field(min_length=10, max_length=256)
    display_name: str | None = None

    @field_validator("username")
    @classmethod
    def _u(cls, v: str) -> str:
        if not USERNAME.match(v) or v.lower() in RESERVED:
            raise ValueError("Usernames are 3–32 letters, digits or underscores")
        return v


class LoginIn(BaseModel):
    email: str
    password: str


def _start_session(db: Session, request: Request, response: Response, user: User) -> AuthSession:
    s = get_settings()
    token = new_token()
    sess = AuthSession(
        token_digest=token_digest(token), user_id=user.id, csrf_token=new_token(24),
        expires_at=utcnow() + timedelta(hours=s.session_ttl_hours),
        user_agent=(request.headers.get("user-agent") or "")[:200], ip_hash=ip_hash(ratelimit.client_ip(request)),
    )
    db.add(sess)
    response.set_cookie(s.session_cookie_name, token, max_age=s.session_ttl_hours * 3600, httponly=True,
                        secure=s.cookie_secure, samesite="lax", path="/")
    return sess


def me_payload(db: Session, user: User, sess: AuthSession | None) -> dict:
    rows = db.execute(select(ArtistMembership, ArtistProfile).join(ArtistProfile, ArtistProfile.id == ArtistMembership.artist_id)
                      .where(ArtistMembership.user_id == user.id).order_by(ArtistProfile.name)).all()
    return {
        "user": {
            "id": str(user.id), "username": user.username, "display_name": user.display_name, "email": user.email,
            "role": user.role, "status": user.status,
            "restricted_until": user.restricted_until.isoformat() if user.restricted_until else None,
            "history_enabled": user.history_enabled, "personalisation_enabled": user.personalisation_enabled,
            "interests": user.interests,
        },
        "csrf_token": sess.csrf_token if sess else None,
        "artists": [{**artist_brief(a), "role": m.role, "status": a.status} for m, a in rows],
    }


@router.post("/auth/register", status_code=201)
def register(body: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    ratelimit.enforce("register", request)
    if not get_config(db)["registration_open"]:
        raise ApiError(403, "registration_closed", "Registration is currently closed on this server.")
    if db.scalar(select(User.id).where(func.lower(User.email) == body.email.lower())):
        raise conflict("email_taken", "An account with that email already exists.")
    if db.scalar(select(User.id).where(func.lower(User.username) == body.username.lower())):
        raise conflict("username_taken", "That username is taken.")
    user = User(email=body.email.lower(), username=body.username,
                display_name=clean_line(body.display_name or body.username, 80) or body.username,
                password_hash=hash_password(body.password))
    s = get_settings()
    if s.bootstrap_admin_email and body.email.lower() == s.bootstrap_admin_email.lower() and not db.scalar(select(User.id).where(User.role == "admin")):
        user.role = "admin"
    db.add(user)
    db.flush()
    sess = _start_session(db, request, response, user)
    audit(db, user.id, "user.register", "user", user.id)
    return me_payload(db, user, sess)


@router.post("/auth/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    ratelimit.enforce("login", request)
    user = db.scalar(select(User).where(func.lower(User.email) == body.email.strip().lower()))
    if not user or not verify_password(user.password_hash, body.password):
        raise ApiError(401, "invalid_credentials", "Email or password is incorrect.")
    if user.status == "suspended":
        raise ApiError(403, "account_suspended", "This account is suspended. Contact the operators to appeal.")
    sess = _start_session(db, request, response, user)
    audit(db, user.id, "user.login", "user", user.id, ip_hash=sess.ip_hash)
    return me_payload(db, user, sess)


@router.post("/auth/logout", status_code=204)
def logout(response: Response, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    if viewer.session:
        db.delete(viewer.session)
    response.delete_cookie(get_settings().session_cookie_name, path="/")
    return Response(status_code=204)


@router.get("/auth/me")
def me(viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    if not viewer.user:
        return {"user": None, "csrf_token": None, "artists": []}
    return me_payload(db, viewer.user, viewer.session)


class SettingsIn(BaseModel):
    display_name: str | None = None
    history_enabled: bool | None = None
    personalisation_enabled: bool | None = None
    interests: list[str] | None = None


@router.patch("/me/settings")
def update_settings(body: SettingsIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    u = viewer.user
    if body.display_name is not None:
        u.display_name = clean_line(body.display_name, 80) or u.username
    if body.history_enabled is not None:
        u.history_enabled = body.history_enabled
        if not body.history_enabled:
            db.execute(delete(ListenHistory).where(ListenHistory.user_id == u.id))
    if body.personalisation_enabled is not None:
        u.personalisation_enabled = body.personalisation_enabled
    if body.interests is not None:
        u.interests = [clean_line(i, 48).lower() for i in body.interests if clean_line(i, 48)][:20]
    return me_payload(db, u, viewer.session)


# ------------------------------------------------------------------ artists


class ArtistIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    slug: str | None = None
    kind: str = "solo"
    bio: str | None = None
    location: str | None = None
    links: list[dict] = []
    support_url: str | None = None
    tips_enabled: bool = False


class ArtistPatch(BaseModel):
    name: str | None = None
    kind: str | None = None
    bio: str | None = None
    location: str | None = None
    links: list[dict] | None = None
    support_url: str | None = None
    tips_enabled: bool | None = None
    avatar_artwork_id: uuid.UUID | None = None
    banner_artwork_id: uuid.UUID | None = None
    pinned_release_id: uuid.UUID | None = None
    clear_pinned_release: bool = False


def _clean_links(links: list[dict]) -> list[dict]:
    out = []
    for item in links[:10]:
        label = clean_line(str(item.get("label", "")), 40)
        try:
            url = clean_url(str(item.get("url", "")))
        except ValueError as e:
            raise bad_request("invalid_link", str(e))
        if label and url:
            out.append({"label": label, "url": url})
    return out


@router.post("/artists", status_code=201)
def create_artist(body: ArtistIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    if db.scalar(select(func.count()).select_from(ArtistMembership).where(ArtistMembership.user_id == viewer.id, ArtistMembership.role == "owner")) >= 10:
        raise bad_request("artist_limit", "You can own at most 10 artist profiles.")
    slug = slugify(body.slug or body.name)
    if slug in RESERVED or db.scalar(select(ArtistProfile.id).where(ArtistProfile.slug == slug)):
        slug = f"{slug}-{uuid.uuid4().hex[:4]}"
    if body.kind not in ("solo", "band", "collective"):
        raise bad_request("invalid_kind", "kind must be solo, band or collective")
    try:
        support_url = clean_url(body.support_url)
    except ValueError as e:
        raise bad_request("invalid_link", str(e))
    a = ArtistProfile(slug=slug, name=clean_line(body.name, 120), kind=body.kind, bio=clean_text(body.bio, 5000),
                      location=clean_line(body.location, 120), links=_clean_links(body.links), support_url=support_url,
                      tips_enabled=body.tips_enabled)
    db.add(a)
    db.flush()
    db.add(ArtistMembership(artist_id=a.id, user_id=viewer.id, role="owner"))
    refresh_artist_search(db, a.id)
    audit(db, viewer.id, "artist.create", "artist", a.id)
    return {**artist_brief(a), "role": "owner"}


def artist_payload(db: Session, viewer: Viewer, a: ArtistProfile) -> dict:
    from commonwave.modules.community.router import release_brief

    role = membership_role(db, a.id, viewer.id)
    track_q = select(Track).where(Track.artist_id == a.id)
    rel_q = select(Release).where(Release.artist_id == a.id)
    if not role and not viewer.is_staff:
        track_q = track_q.where(Track.status == "published", Track.moderation_restricted.is_(False))
        rel_q = rel_q.where(Release.status == "published", Release.moderation_restricted.is_(False))
    tracks = db.scalars(track_q.order_by(Track.published_at.desc().nulls_last(), Track.created_at.desc()).limit(200)).all()
    releases = db.scalars(rel_q.order_by(Release.release_date.desc().nulls_last(), Release.created_at.desc())).all()
    followers = db.scalar(select(func.count()).select_from(Follow).where(Follow.artist_id == a.id))
    following = bool(viewer.id and db.get(Follow, (viewer.id, a.id)))
    pinned = db.get(Release, a.pinned_release_id) if a.pinned_release_id else None
    if pinned and not pinned.is_public and not role:
        pinned = None
    credits: dict[str, set] = {}
    for t in tracks:
        for c in t.credits or []:
            credits.setdefault(c.get("name", ""), set()).add(c.get("role", ""))
    return {
        **artist_brief(a), "bio": a.bio, "location": a.location, "links": a.links, "support_url": a.support_url,
        "tips_enabled": a.tips_enabled,
        "banner_url": artwork_url(a.banner_artwork_id, "large"), "avatar_large_url": artwork_url(a.avatar_artwork_id, "large"),
        "verification": {"status": a.verification_status, "method": a.verification_method if a.verification_status == "verified" else None},
        "status": a.status,
        "follower_count": followers,  # real count from the follows table
        "viewer": {"following": following, "role": role},
        "pinned_release": release_brief(db, pinned) if pinned else None,
        "releases": [release_brief(db, r) for r in releases],
        "tracks": [serialize_track(db, t, artist=a) for t in tracks],
        "credits": [{"name": n, "roles": sorted(r - {""})} for n, r in sorted(credits.items()) if n],
        "created_at": a.created_at.isoformat(),
    }


@router.get("/artists/{slug}")
def get_artist(slug: str, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    a = db.scalar(select(ArtistProfile).where(ArtistProfile.slug == slug.lower()))
    if not a:
        try:
            a = db.get(ArtistProfile, uuid.UUID(slug))
        except ValueError:
            a = None
    if not a or not artist_visible(db, viewer, a):
        raise not_found("artist")
    return artist_payload(db, viewer, a)


@router.patch("/artists/{artist_id}")
def update_artist(artist_id: uuid.UUID, body: ArtistPatch, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    from commonwave.models import Artwork

    a = require_artist_perm(db, viewer, artist_id, "manage_profile")
    data = body.model_dump(exclude_unset=True)
    if "name" in data and data["name"]:
        a.name = clean_line(data["name"], 120)
    if "kind" in data and data["kind"] in ("solo", "band", "collective"):
        a.kind = data["kind"]
    if "bio" in data:
        a.bio = clean_text(data["bio"], 5000)
    if "location" in data:
        a.location = clean_line(data["location"], 120)
    if "links" in data and data["links"] is not None:
        a.links = _clean_links(data["links"])
    if "support_url" in data:
        try:
            a.support_url = clean_url(data["support_url"])
        except ValueError as e:
            raise bad_request("invalid_link", str(e))
    if "tips_enabled" in data and data["tips_enabled"] is not None:
        a.tips_enabled = data["tips_enabled"]
    for field in ("avatar_artwork_id", "banner_artwork_id"):
        if field in data:
            if data[field]:
                art = db.get(Artwork, data[field])
                if not art or art.artist_id != a.id:
                    raise not_found("artwork")
            setattr(a, field, data[field])
    if data.get("clear_pinned_release"):
        a.pinned_release_id = None
    elif data.get("pinned_release_id"):
        r = db.get(Release, data["pinned_release_id"])
        if not r or r.artist_id != a.id:
            raise not_found("release")
        a.pinned_release_id = r.id
    refresh_artist_search(db, a.id)
    audit(db, viewer.id, "artist.update", "artist", a.id, fields=sorted(data))
    return artist_payload(db, viewer, a)


# ------------------------------------------------------------------ memberships


class MemberIn(BaseModel):
    username: str
    role: str = "contributor"


@router.get("/artists/{artist_id}/members")
def list_members(artist_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, artist_id, "view")
    rows = db.execute(select(ArtistMembership, User).join(User, User.id == ArtistMembership.user_id)
                      .where(ArtistMembership.artist_id == artist_id).order_by(ArtistMembership.created_at)).all()
    return [{"user_id": str(u.id), "username": u.username, "display_name": u.display_name, "role": m.role,
             "since": m.created_at.isoformat()} for m, u in rows]


@router.post("/artists/{artist_id}/members", status_code=201)
def add_member(artist_id: uuid.UUID, body: MemberIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, artist_id, "manage_members")
    if body.role not in ("owner", "manager", "contributor"):
        raise bad_request("invalid_role", "Role must be owner, manager or contributor")
    user = db.scalar(select(User).where(func.lower(User.username) == body.username.lower()))
    if not user:
        raise not_found("user")
    existing = db.scalar(select(ArtistMembership).where(ArtistMembership.artist_id == artist_id, ArtistMembership.user_id == user.id))
    if existing:
        existing.role = body.role
    else:
        db.add(ArtistMembership(artist_id=artist_id, user_id=user.id, role=body.role, invited_by=viewer.id))
    audit(db, viewer.id, "artist.member_set", "artist", artist_id, member=user.id, role=body.role)
    db.flush()
    return list_members(artist_id, viewer, db)


@router.delete("/artists/{artist_id}/members/{user_id}")
def remove_member(artist_id: uuid.UUID, user_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    self_leave = user_id == viewer.id
    if not self_leave:
        require_artist_perm(db, viewer, artist_id, "manage_members")
    m = db.scalar(select(ArtistMembership).where(ArtistMembership.artist_id == artist_id, ArtistMembership.user_id == user_id))
    if not m:
        raise not_found("member")
    if m.role == "owner":
        owners = db.scalar(select(func.count()).select_from(ArtistMembership).where(ArtistMembership.artist_id == artist_id, ArtistMembership.role == "owner"))
        if owners <= 1:
            raise conflict("last_owner", "An artist must keep at least one owner. Add another owner first.")
    db.delete(m)
    audit(db, viewer.id, "artist.member_remove", "artist", artist_id, member=user_id)
    db.flush()
    return {"ok": True}


# ------------------------------------------------------------------ follows


@router.post("/artists/{artist_id}/follow")
def follow(artist_id: uuid.UUID, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    ratelimit.enforce("follow", request, str(viewer.id))
    a = db.get(ArtistProfile, artist_id)
    if not a or not artist_visible(db, viewer, a):
        raise not_found("artist")
    if not db.get(Follow, (viewer.id, artist_id)):
        db.add(Follow(user_id=viewer.id, artist_id=artist_id))
    db.flush()
    return {"following": True, "follower_count": db.scalar(select(func.count()).select_from(Follow).where(Follow.artist_id == artist_id))}


@router.delete("/artists/{artist_id}/follow")
def unfollow(artist_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    f = db.get(Follow, (viewer.id, artist_id))
    if f:
        db.delete(f)
    db.flush()
    return {"following": False, "follower_count": db.scalar(select(func.count()).select_from(Follow).where(Follow.artist_id == artist_id))}


@router.get("/me/following")
def my_following(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(ArtistProfile).join(Follow, Follow.artist_id == ArtistProfile.id)
                      .where(Follow.user_id == viewer.id, ArtistProfile.status != "suspended").order_by(Follow.created_at.desc())).all()
    return [artist_brief(a) for a in rows]

