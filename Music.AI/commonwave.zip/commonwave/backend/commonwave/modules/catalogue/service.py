"""Catalogue helpers shared by several modules: visibility rules, serialisers, search indexing."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from commonwave.core.deps import Viewer, membership_role
from commonwave.core.errors import not_found
from commonwave.models import ArtistProfile, Release, ReleaseTrack, RightsDeclaration, Track, TrackVersion


def artwork_url(artwork_id: uuid.UUID | None, size: str = "large") -> str | None:
    return f"/media/artwork/{artwork_id}/{size}" if artwork_id else None


def artist_brief(a: ArtistProfile) -> dict:
    return {
        "id": str(a.id), "slug": a.slug, "name": a.name, "kind": a.kind,
        "verified": a.verification_status == "verified",
        "avatar_url": artwork_url(a.avatar_artwork_id, "small"),
    }


def artist_visible(db: Session, viewer: Viewer, a: ArtistProfile) -> bool:
    if a.status != "suspended":
        return True
    return viewer.is_staff or bool(membership_role(db, a.id, viewer.id))


def can_view_track(db: Session, viewer: Viewer, t: Track) -> bool:
    if t.is_public:
        artist = db.get(ArtistProfile, t.artist_id)
        if artist and artist.status != "suspended":
            return True
    if viewer.is_staff:
        return True
    return bool(membership_role(db, t.artist_id, viewer.id))


def get_visible_track(db: Session, viewer: Viewer, track_id: uuid.UUID) -> Track:
    t = db.get(Track, track_id)
    if not t or not can_view_track(db, viewer, t):
        raise not_found("track")
    return t


def can_view_release(db: Session, viewer: Viewer, r: Release) -> bool:
    if r.is_public:
        artist = db.get(ArtistProfile, r.artist_id)
        if artist and artist.status != "suspended":
            return True
    return viewer.is_staff or bool(membership_role(db, r.artist_id, viewer.id))


def current_rights(db: Session, track_id: uuid.UUID) -> RightsDeclaration | None:
    return db.scalar(select(RightsDeclaration).where(RightsDeclaration.track_id == track_id, RightsDeclaration.superseded_at.is_(None))
                     .order_by(RightsDeclaration.created_at.desc()).limit(1))


def track_release(db: Session, track_id: uuid.UUID, public_only: bool = True) -> tuple[Release, int] | None:
    q = select(Release, ReleaseTrack.position).join(ReleaseTrack, ReleaseTrack.release_id == Release.id).where(ReleaseTrack.track_id == track_id)
    if public_only:
        q = q.where(Release.status == "published", Release.moderation_restricted.is_(False))
    row = db.execute(q.order_by(Release.published_at.asc().nulls_last()).limit(1)).first()
    return (row[0], row[1]) if row else None


def serialize_track(db: Session, t: Track, *, artist: ArtistProfile | None = None, detail: bool = False, version: TrackVersion | None = None) -> dict:
    from commonwave.modules.rights.licences import licence_summary

    artist = artist or db.get(ArtistProfile, t.artist_id)
    v = version or (db.get(TrackVersion, t.current_version_id) if t.current_version_id else None)
    rel = track_release(db, t.id)
    artwork_id = t.artwork_id or (rel[0].artwork_id if rel else None)
    rights = current_rights(db, t.id)
    out = {
        "id": str(t.id), "title": t.title, "status": t.status, "available": t.is_public,
        "artist": artist_brief(artist) if artist else None,
        "duration_ms": v.duration_ms if v else None,
        "genre": t.genre, "tags": t.tags, "explicit": t.explicit, "language": t.language,
        "artwork_url": artwork_url(artwork_id, "large"), "artwork_thumb_url": artwork_url(artwork_id, "small"),
        "release": {"id": str(rel[0].id), "title": rel[0].title, "kind": rel[0].kind, "position": rel[1]} if rel else None,
        "published_at": t.published_at.isoformat() if t.published_at else None,
        "release_date": t.release_date.isoformat() if t.release_date else None,
        "downloads": {"mp3": t.download_mp3, "original": t.download_original},
        "licence": licence_summary(rights) if rights else None,
        "collaborators": t.collaborators,
    }
    if detail:
        out.update({
            "description": t.description, "credits": t.credits,
            "lyrics": t.lyrics if t.lyrics_authorised else None,
            "waveform": v.waveform if v else None,
            "version": {"id": str(v.id), "number": v.version_number} if v else None,
            "moderation_restricted": t.moderation_restricted,
        })
    return out


def refresh_track_search(db: Session, track_id: uuid.UUID) -> None:
    db.execute(text("""
        UPDATE tracks t SET search_vector =
            setweight(to_tsvector('simple', coalesce(t.title,'')), 'A') ||
            setweight(to_tsvector('simple', coalesce(a.name,'')), 'A') ||
            setweight(to_tsvector('simple', coalesce(t.genre,'') || ' ' || array_to_string(t.tags, ' ')), 'B') ||
            setweight(to_tsvector('simple', coalesce(t.description,'')), 'D')
        FROM artist_profiles a WHERE a.id = t.artist_id AND t.id = :id
    """), {"id": track_id})


def refresh_release_search(db: Session, release_id: uuid.UUID) -> None:
    db.execute(text("""
        UPDATE releases r SET search_vector =
            setweight(to_tsvector('simple', coalesce(r.title,'')), 'A') ||
            setweight(to_tsvector('simple', coalesce(a.name,'')), 'A') ||
            setweight(to_tsvector('simple', coalesce(r.genre,'') || ' ' || array_to_string(r.tags, ' ')), 'B') ||
            setweight(to_tsvector('simple', coalesce(r.description,'')), 'D')
        FROM artist_profiles a WHERE a.id = r.artist_id AND r.id = :id
    """), {"id": release_id})


def refresh_artist_search(db: Session, artist_id: uuid.UUID) -> None:
    db.execute(text("""
        UPDATE artist_profiles SET search_vector =
            setweight(to_tsvector('simple', coalesce(name,'')), 'A') ||
            setweight(to_tsvector('simple', coalesce(location,'')), 'C') ||
            setweight(to_tsvector('simple', coalesce(bio,'')), 'D')
        WHERE id = :id
    """), {"id": artist_id})


def artist_storage_used(db: Session, artist_id: uuid.UUID) -> int:
    from commonwave.models import AudioAsset, Upload

    stored = db.scalar(select(func.coalesce(func.sum(AudioAsset.size_bytes), 0)).where(AudioAsset.artist_id == artist_id, AudioAsset.deleted_at.is_(None))) or 0
    pending = db.scalar(select(func.coalesce(func.sum(Upload.length), 0)).where(Upload.artist_id == artist_id, Upload.status == "in_progress")) or 0
    return int(stored) + int(pending)
