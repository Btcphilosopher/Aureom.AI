"""Tracks, versions, releases, artwork and rights declarations (artist-facing + public reads)."""
from __future__ import annotations

import io
import tempfile
import uuid
from datetime import date
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core import cache, ratelimit
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, can, get_viewer, require_artist_perm, require_user
from commonwave.core.errors import ApiError, bad_request, conflict, not_found
from commonwave.core.sanitize import clean_line, clean_tags, clean_text
from commonwave.core.storage import get_storage
from commonwave.models import (
    ArtistProfile, Artwork, Composition, Job, Release, ReleaseTrack, RightsDeclaration, Track, TrackVersion, Upload,
)
from commonwave.modules.catalogue.service import (
    artist_brief, artist_storage_used, artwork_url, can_view_release, current_rights, get_visible_track,
    refresh_release_search, refresh_track_search, serialize_track,
)
from commonwave.modules.processing.queue import enqueue
from commonwave.modules.rights.licences import COMPOSITION_ORIGINS, LICENCES, RECORDING_ORIGINS, WITHDRAWAL_NOTICE, catalogue, licence_summary

router = APIRouter(tags=["catalogue"])


# ------------------------------------------------------------------ serialisers


def version_payload(v: TrackVersion) -> dict:
    return {
        "id": str(v.id), "number": v.version_number, "state": v.state, "source_format": v.source_format,
        "original_filename": v.original_filename, "duration_ms": v.duration_ms, "technical": v.technical,
        "loudness_lufs": v.loudness_lufs, "true_peak_dbtp": v.true_peak_dbtp, "playback_gain_db": v.playback_gain_db,
        "diagnostics": v.diagnostics, "failure_reason": v.failure_reason, "has_waveform": bool(v.waveform),
        "created_at": v.created_at.isoformat(), "processed_at": v.processed_at.isoformat() if v.processed_at else None,
        "published_at": v.published_at.isoformat() if v.published_at else None,
        "replaced_at": v.replaced_at.isoformat() if v.replaced_at else None,
    }


def track_manage_payload(db: Session, t: Track) -> dict:
    base = serialize_track(db, t, detail=True)
    versions = db.scalars(select(TrackVersion).where(TrackVersion.track_id == t.id).order_by(TrackVersion.version_number.desc())).all()
    rights = current_rights(db, t.id)
    comp = db.get(Composition, t.composition_id) if t.composition_id else None
    base.update({
        "lyrics": t.lyrics, "lyrics_authorised": t.lyrics_authorised,
        "artwork_id": str(t.artwork_id) if t.artwork_id else None,
        "versions": [version_payload(v) for v in versions],
        "current_version_id": str(t.current_version_id) if t.current_version_id else None,
        "rights": rights_payload(rights) if rights else None,
        "composition": {"id": str(comp.id), "title": comp.title, "writers": comp.writers, "origin": comp.origin, "iswc": comp.iswc} if comp else None,
        "pipeline": pipeline_state(t, versions),
        # Waveform of the version being reviewed (latest processed), so drafts show one too.
        "waveform": next((v.waveform for v in versions if v.waveform), None),
        "withdrawn_at": t.withdrawn_at.isoformat() if t.withdrawn_at else None,
        "moderation_note": t.moderation_note,
    })
    return base


def pipeline_state(t: Track, versions: list[TrackVersion]) -> str:
    """Single human-facing state: Uploaded → Validating → Processing → Ready for review → Published."""
    if t.status == "withdrawn":
        return "withdrawn"
    latest = versions[0] if versions else None
    if t.status == "published":
        if latest and latest.id != t.current_version_id and latest.state not in ("failed", "cancelled", "ready"):
            return f"published (replacement {latest.state})"
        if latest and latest.id != t.current_version_id and latest.state == "ready":
            return "published (replacement ready for review)"
        return "published"
    if not latest:
        return "awaiting upload"
    return {"ready": "ready for review"}.get(latest.state, latest.state)


def rights_payload(r: RightsDeclaration) -> dict:
    return {
        "id": str(r.id), **licence_summary(r),
        "recording_origin": r.recording_origin, "composition_origin": r.composition_origin,
        "composition_details": r.composition_details, "samples_details": r.samples_details,
        "remix_details": r.remix_details, "source_notes": r.source_notes, "confirmations": r.confirmations,
        "superseded_at": r.superseded_at.isoformat() if r.superseded_at else None,
    }


# ------------------------------------------------------------------ public reads


@router.get("/tracks/{track_id}")
def get_track(track_id: uuid.UUID, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    from commonwave.models import Save

    t = get_visible_track(db, viewer, track_id)
    out = serialize_track(db, t, detail=True)
    out["viewer"] = {
        "can_manage": can(db, viewer, t.artist_id, "edit"),
        "saved": bool(viewer.id and db.get(Save, (viewer.id, "track", t.id))),
    }
    return out


@router.get("/rights/catalogue")
def rights_catalogue():
    return catalogue()


# ------------------------------------------------------------------ artist dashboard


@router.get("/artists/{artist_id}/dashboard")
def dashboard(artist_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    from commonwave.modules.community.router import release_brief

    a = require_artist_perm(db, viewer, artist_id, "view")
    tracks = db.scalars(select(Track).where(Track.artist_id == a.id).order_by(Track.created_at.desc())).all()
    releases = db.scalars(select(Release).where(Release.artist_id == a.id).order_by(Release.created_at.desc())).all()
    uploads = db.scalars(select(Upload).where(Upload.artist_id == a.id, Upload.status == "in_progress")).all()
    from commonwave.core.deps import membership_role
    s = get_settings()
    quota = a.storage_quota_bytes or s.default_artist_storage_quota_bytes
    return {
        "artist": {**artist_brief(a), "status": a.status},
        "role": membership_role(db, a.id, viewer.id),
        "storage": {"used_bytes": artist_storage_used(db, a.id), "quota_bytes": quota, "max_upload_bytes": s.max_upload_bytes},
        "tracks": [track_manage_payload(db, t) for t in tracks],
        "releases": [release_brief(db, r, manage=True) for r in releases],
        "uploads_in_progress": [{"id": str(u.id), "filename": u.filename, "offset": u.offset, "length": u.length,
                                 "track_id": str(u.track_id), "expires_at": u.expires_at.isoformat()} for u in uploads],
    }


@router.get("/tracks/{track_id}/manage")
def manage_track(track_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    t = db.get(Track, track_id)
    if not t:
        raise not_found("track")
    require_artist_perm(db, viewer, t.artist_id, "view")
    return track_manage_payload(db, t)


# ------------------------------------------------------------------ track metadata


class Credit(BaseModel):
    name: str
    role: str


class CompositionIn(BaseModel):
    title: str | None = None
    writers: list[Credit] = []
    origin: str = "original"
    iswc: str | None = None


class TrackPatch(BaseModel):
    title: str | None = Field(default=None, max_length=200)
    description: str | None = None
    genre: str | None = None
    tags: list[str] | None = None
    language: str | None = None
    explicit: bool | None = None
    lyrics: str | None = None
    lyrics_authorised: bool | None = None
    credits: list[Credit] | None = None
    collaborators: list[Credit] | None = None
    release_date: date | None = None
    artwork_id: uuid.UUID | None = None
    download_mp3: bool | None = None
    download_original: bool | None = None
    composition: CompositionIn | None = None


def _manageable_track(db: Session, viewer: Viewer, track_id: uuid.UUID, perm: str) -> Track:
    t = db.get(Track, track_id)
    if not t:
        raise not_found("track")
    require_artist_perm(db, viewer, t.artist_id, perm)
    return t


@router.patch("/tracks/{track_id}")
def update_track(track_id: uuid.UUID, body: TrackPatch, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    t = _manageable_track(db, viewer, track_id, "edit")
    data = body.model_dump(exclude_unset=True)
    if "title" in data:
        title = clean_line(data["title"], 200)
        if not title:
            raise bad_request("title_required", "A title is required.")
        t.title = title
    if "description" in data:
        t.description = clean_text(data["description"], 5000)
    if "genre" in data:
        t.genre = (clean_line(data["genre"], 48) or "").lower() or None
    if "tags" in data:
        t.tags = clean_tags(data["tags"])
    if "language" in data:
        t.language = clean_line(data["language"], 16)
    if "explicit" in data:
        t.explicit = bool(data["explicit"])
    if "lyrics" in data:
        t.lyrics = clean_text(data["lyrics"], 20000)
    if "lyrics_authorised" in data:
        t.lyrics_authorised = bool(data["lyrics_authorised"])
    for f in ("credits", "collaborators"):
        if f in data and data[f] is not None:
            setattr(t, f, [{"name": clean_line(c["name"], 120), "role": clean_line(c["role"], 60)} for c in data[f][:40] if clean_line(c["name"], 120)])
    if "release_date" in data:
        t.release_date = data["release_date"]
    if "artwork_id" in data:
        if data["artwork_id"]:
            art = db.get(Artwork, data["artwork_id"])
            if not art or art.artist_id != t.artist_id:
                raise not_found("artwork")
        t.artwork_id = data["artwork_id"]
    if "download_mp3" in data or "download_original" in data:
        # Changing download permission is a publishing decision.
        require_artist_perm(db, viewer, t.artist_id, "publish")
        if "download_mp3" in data:
            t.download_mp3 = bool(data["download_mp3"])
        if "download_original" in data:
            t.download_original = bool(data["download_original"])
    if data.get("composition"):
        c = data["composition"]
        if c["origin"] not in ("original", "cover", "public_domain", "other"):
            raise bad_request("invalid_origin", "Unknown composition origin")
        comp = db.get(Composition, t.composition_id) if t.composition_id else None
        if not comp:
            comp = Composition(artist_id=t.artist_id, title=t.title)
            db.add(comp)
            db.flush()
            t.composition_id = comp.id
        comp.title = clean_line(c.get("title") or t.title, 200)
        comp.writers = [{"name": clean_line(w["name"], 120), "role": clean_line(w["role"], 60)} for w in c.get("writers", [])[:20]]
        comp.origin = c["origin"]
        comp.iswc = clean_line(c.get("iswc"), 15)
    t.updated_at = utcnow()
    db.flush()
    refresh_track_search(db, t.id)
    cache.invalidate("discover")
    return track_manage_payload(db, t)


class NewTrackIn(BaseModel):
    artist_id: uuid.UUID
    title: str = Field(min_length=1, max_length=200)


@router.post("/tracks", status_code=201)
def create_track(body: NewTrackIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, body.artist_id, "upload")
    t = Track(artist_id=body.artist_id, title=clean_line(body.title, 200), created_by=viewer.id)
    db.add(t)
    db.flush()
    refresh_track_search(db, t.id)
    return track_manage_payload(db, t)


# ------------------------------------------------------------------ rights


class RightsIn(BaseModel):
    licence_code: str
    attribution_text: str | None = None
    recording_origin: str
    composition_origin: str
    composition_details: str | None = None
    samples_details: str | None = None
    remix_details: str | None = None
    source_notes: str | None = None
    confirm_rights: bool = False            # "I own or control the rights needed to publish this recording"
    confirm_not_verified: bool = False      # "I understand COMMONWAVE does not verify ownership"
    confirm_irrevocable: bool = False       # required for CC / public-domain choices


@router.post("/tracks/{track_id}/rights", status_code=201)
def declare_rights(track_id: uuid.UUID, body: RightsIn, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    t = _manageable_track(db, viewer, track_id, "edit")
    lic = LICENCES.get(body.licence_code)
    if not lic:
        raise bad_request("invalid_licence", "Unsupported licence")
    if body.recording_origin not in RECORDING_ORIGINS or body.composition_origin not in COMPOSITION_ORIGINS:
        raise bad_request("invalid_origin", "Unknown recording or composition origin")
    if not body.confirm_rights or not body.confirm_not_verified:
        raise bad_request("confirmation_required", "Please confirm the rights statements.")
    if lic["allows_reuse"] and not body.confirm_irrevocable:
        raise bad_request("confirmation_required", "Open licences cannot be withdrawn for copies already shared. Please confirm you understand.")
    problems = []
    if body.recording_origin == "cover" and body.composition_origin not in ("cover_licensed", "public_domain"):
        problems.append("A cover recording needs a licensed or public-domain composition.")
    if body.recording_origin == "cover" and body.composition_origin == "cover_licensed" and not body.composition_details:
        problems.append("Describe the original song and how the cover is licensed.")
    if body.recording_origin == "contains_samples" and not body.samples_details:
        problems.append("List the samples and how each one is cleared.")
    if body.recording_origin == "remix" and not body.remix_details:
        problems.append("Describe the original recording and the permission to remix it.")
    if body.licence_code == "CC0-1.0" and (body.recording_origin not in ("original",) or body.composition_origin not in ("original", "public_domain")):
        problems.append("CC0 can only be used when you own both the recording and the composition (or the composition is public domain).")
    if body.licence_code == "PDM-1.0" and body.recording_origin != "public_domain_recording":
        problems.append("The Public Domain Mark is only for recordings that are already in the public domain.")
    if lic["allows_reuse"] and body.recording_origin in ("cover", "remix", "contains_samples"):
        problems.append("An open licence must not grant rights you do not hold. Covers, remixes and sample-based tracks usually need 'All rights reserved' unless every rights-holder agreed.")
    if problems:
        raise bad_request("rights_inconsistent", " ".join(problems), problems=problems)
    previous = current_rights(db, t.id)
    now = utcnow()
    if previous:
        previous.superseded_at = now
    artist = db.get(ArtistProfile, t.artist_id)
    attribution = clean_line(body.attribution_text, 500) or (f"“{t.title}” by {artist.name}" if "Attribution" in lic["requires"] else None)
    r = RightsDeclaration(
        track_id=t.id, artist_id=t.artist_id, declared_by=viewer.id, licence_code=body.licence_code,
        licence_version=lic["version"], licence_url=lic["url"], attribution_text=attribution,
        recording_origin=body.recording_origin, composition_origin=body.composition_origin,
        composition_details=clean_text(body.composition_details, 2000), samples_details=clean_text(body.samples_details, 2000),
        remix_details=clean_text(body.remix_details, 2000), source_notes=clean_text(body.source_notes, 2000),
        confirmations={"rights": True, "not_verified": True, "irrevocable": body.confirm_irrevocable,
                       "statement_version": "2026-11", "ip_hash_recorded": False},
    )
    db.add(r)
    db.flush()
    audit(db, viewer.id, "rights.declare", "track", t.id, licence=body.licence_code)
    notice = None
    if previous and LICENCES.get(previous.licence_code, {}).get("allows_reuse") and previous.licence_code != body.licence_code and t.published_at:
        notice = (f"The track was previously published under {previous.licence_code}. Copies obtained while that licence applied "
                  "remain usable under its terms; the new choice applies from now on.")
    return {"rights": rights_payload(r), "notice": notice}


@router.get("/tracks/{track_id}/rights")
def rights_history(track_id: uuid.UUID, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    t = get_visible_track(db, viewer, track_id)
    rows = db.scalars(select(RightsDeclaration).where(RightsDeclaration.track_id == t.id).order_by(RightsDeclaration.created_at.desc())).all()
    manage = can(db, viewer, t.artist_id, "view") or viewer.is_staff
    out = [rights_payload(r) if manage else licence_summary(r) for r in rows]
    return {"current": out[0] if out else None, "history": out, "notice": catalogue()["verification_notice"]}


# ------------------------------------------------------------------ publication


class PublishIn(BaseModel):
    version_id: uuid.UUID | None = None


def _do_publish_track(db: Session, viewer: Viewer, t: Track, version_id: uuid.UUID | None) -> None:
    if t.moderation_restricted:
        raise ApiError(403, "moderation_restricted", "This track is restricted by moderation. You can appeal the decision.")
    if version_id:
        v = db.get(TrackVersion, version_id)
        if not v or v.track_id != t.id:
            raise not_found("version")
    else:
        v = db.scalar(select(TrackVersion).where(TrackVersion.track_id == t.id, TrackVersion.state == "ready")
                      .order_by(TrackVersion.version_number.desc()).limit(1))
        if t.current_version_id and t.status == "withdrawn":
            v = db.get(TrackVersion, t.current_version_id)
    if not v or v.state != "ready":
        raise conflict("not_ready", "The audio must finish processing (Ready for review) before it can be published.")
    if not current_rights(db, t.id):
        raise conflict("rights_required", "Add a rights declaration before publishing.")
    if not t.title:
        raise conflict("title_required", "A title is required.")
    now = utcnow()
    if t.current_version_id and t.current_version_id != v.id:
        db.execute(update(TrackVersion).where(TrackVersion.id == t.current_version_id).values(replaced_at=now))
    t.current_version_id = v.id
    v.published_at = v.published_at or now
    v.replaced_at = None
    was_published = t.published_at is not None
    t.status = "published"
    t.published_at = t.published_at or now
    t.withdrawn_at = None
    artist = db.get(ArtistProfile, t.artist_id)
    artist.last_published_at = now
    audit(db, viewer.id, "track.publish", "track", t.id, version=v.id, republish=was_published)


@router.post("/tracks/{track_id}/publish")
def publish_track(track_id: uuid.UUID, body: PublishIn | None = None, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    t = _manageable_track(db, viewer, track_id, "publish")
    _do_publish_track(db, viewer, t, body.version_id if body else None)
    db.flush()
    refresh_track_search(db, t.id)
    cache.invalidate("discover")
    return track_manage_payload(db, t)


@router.post("/tracks/{track_id}/withdraw")
def withdraw_track(track_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    t = _manageable_track(db, viewer, track_id, "withdraw")
    if t.status != "published":
        raise conflict("not_published", "Only published tracks can be withdrawn.")
    t.status = "withdrawn"
    t.withdrawn_at = utcnow()
    audit(db, viewer.id, "track.withdraw", "track", t.id)
    cache.invalidate("discover")
    return {**track_manage_payload(db, t), "notice": WITHDRAWAL_NOTICE}


@router.post("/tracks/{track_id}/restore")
def restore_track(track_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    """Republish a track the artist withdrew. Moderation restrictions are not affected."""
    t = _manageable_track(db, viewer, track_id, "publish")
    if t.status != "withdrawn":
        raise conflict("not_withdrawn", "Only withdrawn tracks can be restored.")
    _do_publish_track(db, viewer, t, t.current_version_id)
    cache.invalidate("discover")
    return track_manage_payload(db, t)


@router.post("/versions/{version_id}/cancel")
def cancel_version(version_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    v = db.get(TrackVersion, version_id)
    if not v:
        raise not_found("version")
    t = db.get(Track, v.track_id)
    require_artist_perm(db, viewer, t.artist_id, "upload")
    if v.state not in ("uploaded", "validating", "processing", "ready") or v.id == t.current_version_id:
        raise conflict("cannot_cancel", "This version can no longer be cancelled.")
    v.state = "cancelled"
    db.execute(update(Job).where(Job.kind == "process_version", Job.status == "queued", Job.payload["version_id"].astext == str(v.id)).values(status="cancelled"))
    audit(db, viewer.id, "version.cancel", "track", t.id, version=v.id)
    return version_payload(v)


@router.post("/versions/{version_id}/retry")
def retry_version(version_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    v = db.get(TrackVersion, version_id)
    if not v:
        raise not_found("version")
    t = db.get(Track, v.track_id)
    require_artist_perm(db, viewer, t.artist_id, "upload")
    if v.state != "failed":
        raise conflict("cannot_retry", "Only failed versions can be retried.")
    v.state = "uploaded"
    v.failure_reason = None
    enqueue(db, "process_version", {"version_id": str(v.id)}, requested_by=viewer.id, dedupe_key=f"process:{v.id}")
    return version_payload(v)


# ------------------------------------------------------------------ releases


class ReleaseIn(BaseModel):
    artist_id: uuid.UUID
    title: str = Field(min_length=1, max_length=200)
    kind: str = "album"
    description: str | None = None
    genre: str | None = None
    tags: list[str] = []
    release_date: date | None = None
    artwork_id: uuid.UUID | None = None


class ReleasePatch(BaseModel):
    title: str | None = None
    kind: str | None = None
    description: str | None = None
    genre: str | None = None
    tags: list[str] | None = None
    release_date: date | None = None
    artwork_id: uuid.UUID | None = None
    credits: list[Credit] | None = None
    pwyw_enabled: bool | None = None
    pwyw_min_minor: int | None = Field(default=None, ge=0, le=100_000_00)
    pwyw_currency: str | None = None


def release_detail(db: Session, viewer: Viewer, r: Release) -> dict:
    from commonwave.models import Save
    from commonwave.modules.community.router import release_brief

    manage = can(db, viewer, r.artist_id, "view")
    rows = db.execute(select(Track, ReleaseTrack.position).join(ReleaseTrack, ReleaseTrack.track_id == Track.id)
                      .where(ReleaseTrack.release_id == r.id).order_by(ReleaseTrack.position)).all()
    tracks = []
    for t, pos in rows:
        if t.is_public or manage or viewer.is_staff:
            tracks.append({**serialize_track(db, t), "position": pos})
    return {
        **release_brief(db, r, manage=manage), "description": r.description, "credits": r.credits,
        "tracks": tracks, "total_duration_ms": sum(t["duration_ms"] or 0 for t in tracks),
        "viewer": {"can_manage": manage, "saved": bool(viewer.id and db.get(Save, (viewer.id, "release", r.id)))},
        "archive_available": bool(tracks) and all(t["downloads"]["mp3"] for t in tracks),
    }


@router.post("/releases", status_code=201)
def create_release(body: ReleaseIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, body.artist_id, "edit")
    if body.kind not in ("single", "ep", "album", "compilation"):
        raise bad_request("invalid_kind", "kind must be single, ep, album or compilation")
    if body.artwork_id:
        art = db.get(Artwork, body.artwork_id)
        if not art or art.artist_id != body.artist_id:
            raise not_found("artwork")
    r = Release(artist_id=body.artist_id, title=clean_line(body.title, 200), kind=body.kind, description=clean_text(body.description, 5000),
                genre=(clean_line(body.genre, 48) or "").lower() or None, tags=clean_tags(body.tags), release_date=body.release_date,
                artwork_id=body.artwork_id)
    db.add(r)
    db.flush()
    refresh_release_search(db, r.id)
    return release_detail(db, viewer, r)


@router.get("/releases/{release_id}")
def get_release(release_id: uuid.UUID, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    r = db.get(Release, release_id)
    if not r or not can_view_release(db, viewer, r):
        raise not_found("release")
    return release_detail(db, viewer, r)


@router.patch("/releases/{release_id}")
def update_release(release_id: uuid.UUID, body: ReleasePatch, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    r = db.get(Release, release_id)
    if not r:
        raise not_found("release")
    require_artist_perm(db, viewer, r.artist_id, "edit")
    d = body.model_dump(exclude_unset=True)
    if "title" in d and d["title"]:
        r.title = clean_line(d["title"], 200)
    if "kind" in d and d["kind"] in ("single", "ep", "album", "compilation"):
        r.kind = d["kind"]
    if "description" in d:
        r.description = clean_text(d["description"], 5000)
    if "genre" in d:
        r.genre = (clean_line(d["genre"], 48) or "").lower() or None
    if "tags" in d:
        r.tags = clean_tags(d["tags"])
    if "release_date" in d:
        r.release_date = d["release_date"]
    if "artwork_id" in d:
        if d["artwork_id"]:
            art = db.get(Artwork, d["artwork_id"])
            if not art or art.artist_id != r.artist_id:
                raise not_found("artwork")
        r.artwork_id = d["artwork_id"]
    if "credits" in d and d["credits"] is not None:
        r.credits = [{"name": clean_line(c["name"], 120), "role": clean_line(c["role"], 60)} for c in d["credits"][:40]]
    if any(k in d for k in ("pwyw_enabled", "pwyw_min_minor", "pwyw_currency")):
        require_artist_perm(db, viewer, r.artist_id, "support")
        if "pwyw_enabled" in d:
            r.pwyw_enabled = bool(d["pwyw_enabled"])
        if d.get("pwyw_min_minor") is not None:
            r.pwyw_min_minor = d["pwyw_min_minor"]
        if d.get("pwyw_currency"):
            if d["pwyw_currency"] not in ("USD", "EUR", "GBP"):
                raise bad_request("invalid_currency", "Supported currencies: USD, EUR, GBP")
            r.pwyw_currency = d["pwyw_currency"]
    db.flush()
    refresh_release_search(db, r.id)
    cache.invalidate("discover")
    return release_detail(db, viewer, r)


class ReleaseTracksIn(BaseModel):
    track_ids: list[uuid.UUID] = Field(max_length=100)


@router.put("/releases/{release_id}/tracks")
def set_release_tracks(release_id: uuid.UUID, body: ReleaseTracksIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    r = db.get(Release, release_id)
    if not r:
        raise not_found("release")
    require_artist_perm(db, viewer, r.artist_id, "edit")
    if len(set(body.track_ids)) != len(body.track_ids):
        raise bad_request("duplicate_tracks", "A track can appear only once in a release.")
    for tid in body.track_ids:
        t = db.get(Track, tid)
        if not t or t.artist_id != r.artist_id:
            raise not_found("track")
    r.entries.clear()
    db.flush()
    for i, tid in enumerate(body.track_ids, start=1):
        r.entries.append(ReleaseTrack(track_id=tid, position=i))
    r.archive_fingerprint = None
    db.flush()
    return release_detail(db, viewer, r)


@router.post("/releases/{release_id}/publish")
def publish_release(release_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    r = db.get(Release, release_id)
    if not r:
        raise not_found("release")
    require_artist_perm(db, viewer, r.artist_id, "publish")
    if r.moderation_restricted:
        raise ApiError(403, "moderation_restricted", "This release is restricted by moderation.")
    if not r.entries:
        raise conflict("empty_release", "Add at least one track before publishing.")
    for e in r.entries:
        t = db.get(Track, e.track_id)
        if t.status != "published":
            _do_publish_track(db, viewer, t, None)  # raises with a clear reason if not ready
        refresh_track_search(db, t.id)
    now = utcnow()
    r.status = "published"
    r.published_at = r.published_at or now
    r.withdrawn_at = None
    r.release_date = r.release_date or now.date()
    db.get(ArtistProfile, r.artist_id).last_published_at = now
    audit(db, viewer.id, "release.publish", "release", r.id)
    db.flush()
    cache.invalidate("discover")
    return release_detail(db, viewer, r)


@router.post("/releases/{release_id}/withdraw")
def withdraw_release(release_id: uuid.UUID, include_tracks: bool = True, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    r = db.get(Release, release_id)
    if not r:
        raise not_found("release")
    require_artist_perm(db, viewer, r.artist_id, "withdraw")
    r.status = "withdrawn"
    r.withdrawn_at = utcnow()
    if include_tracks:
        for e in r.entries:
            t = db.get(Track, e.track_id)
            if t.status == "published":
                t.status = "withdrawn"
                t.withdrawn_at = utcnow()
    audit(db, viewer.id, "release.withdraw", "release", r.id, include_tracks=include_tracks)
    cache.invalidate("discover")
    return {**release_detail(db, viewer, r), "notice": WITHDRAWAL_NOTICE}


# ------------------------------------------------------------------ artwork


@router.post("/artists/{artist_id}/artworks", status_code=201)
async def upload_artwork(artist_id: uuid.UUID, request: Request, file: UploadFile = File(...), purpose: str = Form("cover"),
                         alt_text: str = Form(""), credit: str = Form(""), viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    from PIL import Image, ImageOps

    ratelimit.enforce("artwork", request, str(viewer.id))
    require_artist_perm(db, viewer, artist_id, "edit")
    s = get_settings()
    data = await file.read(s.max_artwork_bytes + 1)
    if len(data) > s.max_artwork_bytes:
        raise ApiError(413, "too_large", f"Artwork must be at most {s.max_artwork_bytes // (1024 * 1024)} MB.")
    Image.MAX_IMAGE_PIXELS = 40_000_000
    try:
        probe = Image.open(io.BytesIO(data))
        if probe.format not in ("JPEG", "PNG", "WEBP"):
            raise bad_request("unsupported_image", "Artwork must be a JPEG, PNG or WebP image.")
        probe.verify()
        img = Image.open(io.BytesIO(data))
        img = ImageOps.exif_transpose(img).convert("RGB")  # drops EXIF/metadata on re-encode
    except ApiError:
        raise
    except Exception:
        raise bad_request("invalid_image", "The file is not a readable image.")
    if min(img.size) < 300:
        raise bad_request("image_too_small", "Artwork must be at least 300 pixels on its shortest side.")
    if purpose == "banner":
        large, small = ImageOps.fit(img, (1800, 600)), ImageOps.fit(img, (600, 200))
    else:
        large, small = ImageOps.fit(img, (1200, 1200)), ImageOps.fit(img, (300, 300))
    color = small.resize((1, 1)).getpixel((0, 0))
    art_id = uuid.uuid4()
    keys = {}
    with tempfile.TemporaryDirectory() as td:
        for name, im in (("large", large), ("small", small)):
            p = Path(td) / f"{name}.jpg"
            im.save(p, "JPEG", quality=88, optimize=True, progressive=True)
            keys[name] = f"artwork/{artist_id}/{art_id}-{name}.jpg"
            get_storage().put_file(keys[name], p, "image/jpeg")
    art = Artwork(id=art_id, artist_id=artist_id, uploaded_by=viewer.id, key_large=keys["large"], key_small=keys["small"],
                  width=large.width, height=large.height, alt_text=clean_line(alt_text, 300), credit=clean_line(credit, 300),
                  dominant_color="#%02x%02x%02x" % color[:3])
    db.add(art)
    db.flush()
    return {"id": str(art.id), "url": artwork_url(art.id), "thumb_url": artwork_url(art.id, "small"), "alt_text": art.alt_text,
            "dominant_color": art.dominant_color}


@router.get("/artists/{artist_id}/artworks")
def list_artworks(artist_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, artist_id, "view")
    arts = db.scalars(select(Artwork).where(Artwork.artist_id == artist_id).order_by(Artwork.created_at.desc())).all()
    return [{"id": str(a.id), "url": artwork_url(a.id), "thumb_url": artwork_url(a.id, "small"), "alt_text": a.alt_text} for a in arts]


def count_tracks(db: Session, artist_id: uuid.UUID) -> int:
    return db.scalar(select(func.count()).select_from(Track).where(Track.artist_id == artist_id)) or 0
