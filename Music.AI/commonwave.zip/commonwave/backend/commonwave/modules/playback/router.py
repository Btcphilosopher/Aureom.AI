"""Playback sessions, untrusted event ingestion, signed media delivery (HTTP Range) and downloads.

Published definition of a **qualified listen** (also in docs/analytics.md):
a playback session in which the server credits at least
``min(30 s, 50 % of the track duration)`` of actual playback, computed from
client heartbeats but bounded by real elapsed time, not flagged as automated,
and not within 30 minutes of another qualified listen of the same track by the
same listener key.
"""
from __future__ import annotations

import re
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core import ratelimit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, can, get_viewer, membership_role
from commonwave.core.errors import ApiError, conflict, not_found
from commonwave.core.security import check_media_signature, listener_key, sign, signed_media_params, verify_sig
from commonwave.core.siteconfig import get_config
from commonwave.core.storage import get_storage
from commonwave.models import (
    ArtistProfile, Artwork, AudioAsset, Download, ListenHistory, PlaybackEvent, PlaybackSession, Release, ReleaseTrack,
    Track, TrackVersion, User,
)
from commonwave.modules.catalogue.service import can_view_release, current_rights, get_visible_track
from commonwave.modules.rights.licences import LICENCES, licence_summary

router = APIRouter(tags=["playback"])
media = APIRouter(tags=["media"])

BOT_UA = re.compile(r"(bot|crawl|spider|slurp|curl|wget|python-requests|httpx|go-http-client|headless|phantom|scrapy)", re.I)
MAX_SPEED = 2.0
MAX_CREDIT_PER_EVENT_MS = 5 * 60 * 1000
SLACK_MS = 5000


# ------------------------------------------------------------------ playback sessions


class SessionIn(BaseModel):
    track_id: uuid.UUID
    source: str | None = Field(default=None, max_length=24)
    preview: bool = False  # artist members previewing an unpublished, processed version
    version_id: uuid.UUID | None = None


def stream_url(asset_id: uuid.UUID, scope: str = "") -> tuple[str, int]:
    s = get_settings()
    p = signed_media_params("stream", str(asset_id), s.stream_url_ttl_seconds, scope)
    q = "&".join(f"{k}={v}" for k, v in p.items())
    return f"/media/stream/{asset_id}?{q}", int(p["exp"])


@router.post("/playback/sessions", status_code=201)
def create_session(body: SessionIn, request: Request, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    ratelimit.enforce("playback_session", request, str(viewer.id) if viewer.id else None)
    ua = request.headers.get("user-agent") or ""
    lk = listener_key(str(viewer.id) if viewer.id else None, ratelimit.client_ip(request), ua)
    t = db.get(Track, body.track_id)
    if not t:
        raise not_found("track")
    scope = ""
    if body.preview:
        if not can(db, viewer, t.artist_id, "view"):
            raise not_found("track")
        v = db.get(TrackVersion, body.version_id) if body.version_id else (
            db.scalar(select(TrackVersion).where(TrackVersion.track_id == t.id, TrackVersion.state == "ready").order_by(TrackVersion.version_number.desc()).limit(1)))
        if not v or v.track_id != t.id or v.state != "ready":
            raise conflict("not_ready", "No processed version is available to preview yet.")
        scope = f"preview:{viewer.id}"
    else:
        t = get_visible_track(db, viewer, body.track_id)
        if not t.is_public:
            # Members/staff viewing an unpublished track must use preview mode explicitly.
            raise ApiError(410, "unavailable", "This track is not currently available for streaming.")
        v = db.get(TrackVersion, t.current_version_id) if t.current_version_id else None
        if not v or v.state != "ready" or not v.stream_asset_id:
            raise ApiError(410, "unavailable", "This track is not currently available for streaming.")
    sess = PlaybackSession(track_id=t.id, track_version_id=v.id, artist_id=t.artist_id, user_id=viewer.id, listener_key=lk,
                           source=body.source, is_preview=body.preview,
                           suspected_bot=bool(not ua or BOT_UA.search(ua)))
    recent = db.scalar(select(func.count()).select_from(PlaybackSession).where(
        PlaybackSession.listener_key == lk, PlaybackSession.created_at > utcnow() - timedelta(hours=1)))
    if recent and recent > 120:
        sess.suspected_bot = True
    db.add(sess)
    db.flush()
    url, exp = stream_url(v.stream_asset_id, scope)
    return {
        "session_id": str(sess.id), "session_token": sign("playback-session", str(sess.id)), "track_id": str(t.id), "version_id": str(v.id), "stream_url": url, "expires_at": exp,
        "duration_ms": v.duration_ms, "playback_gain_db": v.playback_gain_db, "waveform": v.waveform,
        "heartbeat_seconds": 15, "content_type": "audio/mpeg",
    }


class EventIn(BaseModel):
    seq: int = Field(ge=0, le=100_000)
    kind: str = Field(pattern="^(start|progress|pause|seek|end|stall)$")
    position_ms: int = Field(ge=0, le=24 * 3600 * 1000)


class EventsIn(BaseModel):
    session_token: str = Field(max_length=64)
    events: list[EventIn] = Field(max_length=50)


@router.post("/playback/sessions/{session_id}/events")
def ingest_events(session_id: uuid.UUID, body: EventsIn, request: Request, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    """Client events are untrusted: duplicates (same seq) are ignored, positions are
    clamped to the track length, and credited listening time can never exceed real
    elapsed time × maximum playback speed."""
    ratelimit.enforce("playback_events", request, str(viewer.id) if viewer.id else None)
    if not verify_sig("playback-session", str(session_id), body.session_token):
        raise not_found("session")
    sess = db.scalar(select(PlaybackSession).where(PlaybackSession.id == session_id).with_for_update())
    if not sess:
        raise not_found("session")
    version = db.get(TrackVersion, sess.track_version_id)
    duration = version.duration_ms or 0
    now = utcnow()
    accepted = duplicates = 0
    for ev in sorted(body.events, key=lambda e: e.seq):
        stmt = insert(PlaybackEvent).values(session_id=sess.id, seq=ev.seq, kind=ev.kind, position_ms=min(ev.position_ms, duration),
                                            received_at=now).on_conflict_do_nothing(constraint="uq_playback_events_session_seq").returning(PlaybackEvent.id)
        new_id = db.execute(stmt).scalar()
        if new_id is None:
            duplicates += 1
            continue
        accepted += 1
        pos = min(ev.position_ms, duration)
        credited = 0
        if ev.seq <= sess.last_seq:
            sess.rejected_events += 1  # late, out-of-order event: stored, never credited
        else:
            if ev.kind == "start":
                sess.started_at = sess.started_at or now
                sess.last_playing = True
            elif sess.started_at and sess.last_playing and ev.kind in ("progress", "pause", "end", "stall", "seek"):
                credited = max(0, min(pos - sess.last_position_ms, MAX_CREDIT_PER_EVENT_MS)) if ev.kind != "seek" else 0
            if ev.kind in ("pause", "end", "stall"):
                sess.last_playing = False
            elif ev.kind in ("progress",) and sess.started_at:
                sess.last_playing = True
            sess.last_seq = ev.seq
            sess.last_position_ms = pos
            if ev.kind != "seek":
                sess.max_position_ms = max(sess.max_position_ms, pos)
        if credited:
            bound = int((now - sess.started_at).total_seconds() * 1000 * MAX_SPEED) + SLACK_MS
            allowed = max(0, bound - sess.listened_ms)
            if credited > allowed:
                sess.rejected_events += 1
                credited = allowed
            sess.listened_ms += credited
            db.execute(PlaybackEvent.__table__.update().where(PlaybackEvent.id == new_id).values(credited_ms=credited))
        if ev.kind == "end" and duration and pos >= duration - 3000 and sess.listened_ms >= duration * 0.5:
            sess.completed = True
    sess.duplicate_events += duplicates
    sess.last_event_at = now
    _qualify(db, sess, duration)
    return {"accepted": accepted, "duplicates": duplicates, "listened_ms": sess.listened_ms, "qualified": sess.qualified,
            "completed": sess.completed}


def _qualify(db: Session, sess: PlaybackSession, duration_ms: int) -> None:
    s = get_settings()
    if sess.qualified or sess.suspected_bot or sess.is_preview or not duration_ms:
        return
    threshold = min(s.qualified_listen_seconds * 1000, int(duration_ms * s.qualified_listen_fraction_short))
    if sess.listened_ms < threshold:
        return
    recent = db.scalar(select(PlaybackSession.id).where(
        PlaybackSession.listener_key == sess.listener_key, PlaybackSession.track_id == sess.track_id,
        PlaybackSession.qualified.is_(True), PlaybackSession.qualified_at > utcnow() - timedelta(minutes=30),
        PlaybackSession.id != sess.id).limit(1))
    if recent:
        return
    sess.qualified = True
    sess.qualified_at = utcnow()
    if sess.user_id:
        u = db.get(User, sess.user_id)
        if u and u.history_enabled:
            db.add(ListenHistory(user_id=u.id, track_id=sess.track_id))


# ------------------------------------------------------------------ media delivery


_RANGE = re.compile(r"^bytes=(\d*)-(\d*)$")


def parse_range(header: str | None, size: int) -> tuple[int, int] | None | str:
    """Return (start, end) inclusive, None for 'no/ignored range', or 'unsatisfiable'."""
    if not header:
        return None
    m = _RANGE.match(header.strip())
    if not m:
        return None  # multi-range or malformed: RFC 9110 lets us ignore it and send 200
    a, b = m.groups()
    if a == "" and b == "":
        return None
    if a == "":
        n = int(b)
        if n == 0:
            return "unsatisfiable"
        return max(0, size - n), size - 1
    start = int(a)
    end = int(b) if b else size - 1
    if start >= size or (b and end < start):
        return "unsatisfiable"
    return start, min(end, size - 1)


def serve_object(request: Request, key: str, size: int, content_type: str, etag: str | None, *, cache: str,
                 disposition: str | None = None) -> Response:
    headers = {"Accept-Ranges": "bytes", "Cache-Control": cache, "X-Content-Type-Options": "nosniff"}
    if etag:
        headers["ETag"] = f'"{etag}"'
    if disposition:
        headers["Content-Disposition"] = disposition
    rng = parse_range(request.headers.get("range"), size)
    if_range = request.headers.get("if-range")
    if rng and if_range and etag and if_range.strip('"') != etag:
        rng = None
    if rng == "unsatisfiable":
        return Response(status_code=416, headers={**headers, "Content-Range": f"bytes */{size}"})
    start, end, status = (0, size - 1, 200) if rng is None else (rng[0], rng[1], 206)
    if status == 206:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    headers["Content-Length"] = str(end - start + 1)
    if request.method == "HEAD":
        return Response(status_code=status, headers=headers, media_type=content_type)
    return StreamingResponse(get_storage().iter_range(key, start, end), status_code=status, headers=headers, media_type=content_type)


def _media_error(status: int, code: str, message: str) -> Response:
    import json
    return Response(json.dumps({"error": {"code": code, "message": message}}), status_code=status,
                    media_type="application/json", headers={"Cache-Control": "no-store"})


@media.api_route("/media/stream/{asset_id}", methods=["HEAD"], include_in_schema=False)
@media.get("/media/stream/{asset_id}")
def media_stream(asset_id: uuid.UUID, request: Request, exp: str | None = None, sig: str | None = None, scope: str = "",
                 viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    check = check_media_signature("stream", str(asset_id), exp, sig, scope)
    if check == "invalid":
        return _media_error(403, "invalid_signature", "This media link is not valid.")
    if check == "expired":
        return _media_error(403, "expired", "This media link has expired; request a new playback session.")
    asset = db.get(AudioAsset, asset_id)
    if not asset or asset.kind != "stream_mp3" or asset.deleted_at:
        return _media_error(404, "not_found", "Media not found.")
    v = db.get(TrackVersion, asset.track_version_id)
    t = db.get(Track, v.track_id) if v else None
    if not t:
        return _media_error(404, "not_found", "Media not found.")
    if scope.startswith("preview:"):
        # Preview links are bound to the requesting member's session.
        if not viewer.id or scope != f"preview:{viewer.id}" or not membership_role(db, t.artist_id, viewer.id):
            return _media_error(403, "forbidden", "Preview links are only valid for the artist's members.")
    else:
        artist = db.get(ArtistProfile, t.artist_id)
        # Authorisation is re-checked on every request, so a withdrawal takes effect
        # immediately even for links that have not expired yet.
        if not t.is_public or t.current_version_id != v.id or artist.status == "suspended":
            return _media_error(410, "unavailable", "This track is no longer available.")
    info = get_storage().stat(asset.storage_key)
    if not info:
        return _media_error(503, "media_unavailable", "The media file is temporarily unavailable.")
    return serve_object(request, asset.storage_key, info.size, "audio/mpeg", (asset.sha256 or "")[:32] or None, cache="private, max-age=600")


@media.get("/media/artwork/{artwork_id}/{size}")
def media_artwork(artwork_id: uuid.UUID, size: str, request: Request, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    art = db.get(Artwork, artwork_id)
    if not art or size not in ("large", "small"):
        return _media_error(404, "not_found", "Artwork not found.")
    public = bool(
        db.scalar(select(Track.id).where(Track.artwork_id == art.id, Track.status == "published", Track.moderation_restricted.is_(False)).limit(1))
        or db.scalar(select(Release.id).where(Release.artwork_id == art.id, Release.status == "published", Release.moderation_restricted.is_(False)).limit(1))
        or db.scalar(select(ArtistProfile.id).where(((ArtistProfile.avatar_artwork_id == art.id) | (ArtistProfile.banner_artwork_id == art.id)), ArtistProfile.status != "suspended").limit(1))
    )
    if not public and not (viewer.is_staff or membership_role(db, art.artist_id, viewer.id)):
        return _media_error(404, "not_found", "Artwork not found.")
    key = art.key_large if size == "large" else art.key_small
    info = get_storage().stat(key)
    if not info:
        return _media_error(404, "not_found", "Artwork not found.")
    return serve_object(request, key, info.size, "image/jpeg", f"{art.id.hex[:16]}{size[0]}",
                        cache="public, max-age=86400" if public else "private, no-store")


# ------------------------------------------------------------------ downloads


class DownloadIn(BaseModel):
    format: str = Field(pattern="^(mp3|original)$")


def _download_options(db: Session, t: Track) -> list[dict]:
    v = db.get(TrackVersion, t.current_version_id) if t.current_version_id else None
    rights = current_rights(db, t.id)
    lic = licence_summary(rights) if rights else None
    opts = []
    if not v:
        return opts
    if t.download_mp3 and v.stream_asset_id:
        a = db.get(AudioAsset, v.stream_asset_id)
        opts.append({"format": "mp3", "label": f"MP3 {v.technical.get('stream_bitrate_kbps', '')} kbps", "size_bytes": a.size_bytes, "licence": lic})
    if t.download_original and v.original_asset_id:
        a = db.get(AudioAsset, v.original_asset_id)
        label = {"wav": "WAV (original upload)", "flac": "FLAC (original upload)", "mp3": "MP3 (original upload)"}.get(a.format, "Original")
        opts.append({"format": "original", "label": label, "size_bytes": a.size_bytes, "licence": lic, "file_format": a.format})
    return opts


@router.get("/tracks/{track_id}/downloads")
def download_options(track_id: uuid.UUID, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    t = get_visible_track(db, viewer, track_id)
    if not get_config(db)["downloads_enabled"] or not t.is_public:
        return {"options": [], "notice": None}
    rights = current_rights(db, t.id)
    notice = None
    if rights and not LICENCES.get(rights.licence_code, {}).get("allows_reuse"):
        notice = "All rights reserved: this download is for personal listening. Ask the artist before reusing it."
    elif rights:
        notice = f"Licensed under {LICENCES[rights.licence_code]['short']}. Follow the licence terms, including attribution: {rights.attribution_text or ''}".strip()
    return {"options": _download_options(db, t), "notice": notice}


def _disposition(name: str) -> str:
    from urllib.parse import quote
    ascii_name = re.sub(r"[^A-Za-z0-9 ._()-]+", "_", name)[:150]
    return f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(name[:150])}"


def signed_download(download: Download) -> tuple[str, int]:
    s = get_settings()
    p = signed_media_params("download", str(download.id), s.download_url_ttl_seconds)
    return f"/media/download/{download.id}?exp={p['exp']}&sig={p['sig']}", int(p["exp"])


@router.post("/tracks/{track_id}/download")
def request_download(track_id: uuid.UUID, body: DownloadIn, request: Request, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    ratelimit.enforce("download", request, str(viewer.id) if viewer.id else None)
    t = get_visible_track(db, viewer, track_id)
    if not t.is_public or not get_config(db)["downloads_enabled"]:
        raise ApiError(403, "download_not_permitted", "Downloads are not available for this track.")
    v = db.get(TrackVersion, t.current_version_id)
    if body.format == "mp3":
        if not t.download_mp3:
            raise ApiError(403, "download_not_permitted", "The artist has not enabled MP3 downloads for this track.")
        asset_id = v.stream_asset_id
    else:
        if not t.download_original:
            raise ApiError(403, "download_not_permitted", "The artist has not enabled original-file downloads for this track.")
        asset_id = v.original_asset_id
    asset = db.get(AudioAsset, asset_id)
    rights = current_rights(db, t.id)
    d = Download(track_id=t.id, artist_id=t.artist_id, asset_id=asset.id, format=body.format, user_id=viewer.id,
                 listener_key=listener_key(str(viewer.id) if viewer.id else None, ratelimit.client_ip(request), request.headers.get("user-agent")),
                 licence_code=rights.licence_code if rights else None)
    db.add(d)
    db.flush()
    url, exp = signed_download(d)
    artist = db.get(ArtistProfile, t.artist_id)
    return {"url": url, "expires_at": exp, "format": body.format, "file_format": asset.format, "size_bytes": asset.size_bytes,
            "filename": f"{artist.name} - {t.title}.{asset.format}", "licence": licence_summary(rights) if rights else None}


@media.api_route("/media/download/{download_id}", methods=["HEAD"], include_in_schema=False)
@media.get("/media/download/{download_id}")
def media_download(download_id: uuid.UUID, request: Request, exp: str | None = None, sig: str | None = None, db: Session = Depends(get_db)):
    check = check_media_signature("download", str(download_id), exp, sig)
    if check != "ok":
        return _media_error(403, "expired" if check == "expired" else "invalid_signature",
                            "This download link has expired." if check == "expired" else "This download link is not valid.")
    d = db.get(Download, download_id)
    asset = db.get(AudioAsset, d.asset_id) if d and d.asset_id else None
    if not d or not asset or asset.deleted_at:
        return _media_error(404, "not_found", "Download not found.")
    if d.track_id:
        t = db.get(Track, d.track_id)
        allowed = t.is_public and ((d.format == "mp3" and t.download_mp3) or (d.format == "original" and t.download_original))
        name = f"{db.get(ArtistProfile, t.artist_id).name} - {t.title}.{asset.format}"
    else:
        r = db.get(Release, d.release_id)
        allowed = r.is_public and r.archive_asset_id == asset.id
        name = f"{db.get(ArtistProfile, r.artist_id).name} - {r.title}.zip"
    if not allowed:
        return _media_error(410, "unavailable", "This download is no longer permitted by the artist.")
    info = get_storage().stat(asset.storage_key)
    if not info:
        return _media_error(503, "media_unavailable", "The file is temporarily unavailable.")
    if request.method == "GET" and not request.headers.get("range"):
        d.fetched = True
    return serve_object(request, asset.storage_key, info.size, asset.content_type, (asset.sha256 or "")[:32] or None,
                        cache="private, no-store", disposition=_disposition(name))


# ------------------------------------------------------------------ release archives


@router.post("/releases/{release_id}/archive")
def release_archive(release_id: uuid.UUID, request: Request, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    from commonwave.models import DownloadEntitlement
    from commonwave.modules.exports.archive import release_fingerprint
    from commonwave.modules.processing.queue import enqueue

    ratelimit.enforce("download", request, str(viewer.id) if viewer.id else None)
    r = db.get(Release, release_id)
    if not r or not can_view_release(db, viewer, r):
        raise not_found("release")
    if not r.is_public or not get_config(db)["downloads_enabled"]:
        raise ApiError(403, "download_not_permitted", "Downloads are not available for this release.")
    tracks = db.scalars(select(Track).join(ReleaseTrack, ReleaseTrack.track_id == Track.id).where(ReleaseTrack.release_id == r.id)).all()
    public = [t for t in tracks if t.is_public]
    if not public or not all(t.download_mp3 for t in public):
        raise ApiError(403, "download_not_permitted", "The artist has not enabled downloads for every track on this release.")
    if r.pwyw_enabled and not can(db, viewer, r.artist_id, "view"):
        if not viewer.id:
            raise ApiError(402, "payment_required", "Sign in and choose a price to download this release.", extra={"min_minor": r.pwyw_min_minor, "currency": r.pwyw_currency})
        if not db.scalar(select(DownloadEntitlement.id).where(DownloadEntitlement.user_id == viewer.id, DownloadEntitlement.release_id == r.id)):
            raise ApiError(402, "payment_required", "Choose a price (pay what you want) to download this release.", extra={"min_minor": r.pwyw_min_minor, "currency": r.pwyw_currency})
    fp = release_fingerprint(db, r)
    if r.archive_asset_id and r.archive_fingerprint == fp:
        asset = db.get(AudioAsset, r.archive_asset_id)
        d = Download(release_id=r.id, artist_id=r.artist_id, asset_id=asset.id, format="archive", user_id=viewer.id,
                     listener_key=listener_key(str(viewer.id) if viewer.id else None, ratelimit.client_ip(request), request.headers.get("user-agent")))
        db.add(d)
        db.flush()
        url, exp = signed_download(d)
        return {"status": "ready", "url": url, "expires_at": exp, "size_bytes": asset.size_bytes, "format": "zip"}
    job = enqueue(db, "build_release_archive", {"release_id": str(r.id)}, dedupe_key=f"archive:{r.id}:{fp}")
    return Response(status_code=202, content=__import__("json").dumps({"status": "building", "job_id": str(job.id)}), media_type="application/json")
