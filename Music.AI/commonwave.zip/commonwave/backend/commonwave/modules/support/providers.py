"""Payment provider adapters.

Only ``SimulatedProvider`` is implemented. It never moves money: it creates a
local checkout page URL and, when "paid", emits an HMAC-signed webhook event
exactly as a real provider would, so the fulfilment path (signature check,
idempotency, entitlement, ledger) is exercised end to end.

``LightningProvider`` documents the contract a real Lightning integration must
meet (integer sats, verified settlement, explicit fees); it is deliberately
not implemented — see docs/payments.md.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from typing import Protocol

from commonwave.config import get_settings
from commonwave.core.security import sign, verify_sig


@dataclass
class Checkout:
    provider_ref: str
    checkout_url: str
    provider_fee_minor: int


class PaymentProvider(Protocol):
    name: str

    def create_checkout(self, intent_id: uuid.UUID, amount_minor: int, currency: str) -> Checkout: ...
    def verify_webhook(self, body: bytes, signature: str) -> dict | None: ...


class SimulatedProvider:
    name = "simulated"

    def create_checkout(self, intent_id: uuid.UUID, amount_minor: int, currency: str) -> Checkout:
        s = get_settings()
        fee = 0 if amount_minor == 0 else amount_minor * s.simulated_provider_fee_bps // 10_000 + s.simulated_provider_fixed_fee_minor
        ref = f"sim_{uuid.uuid4().hex[:20]}"
        return Checkout(provider_ref=ref, checkout_url=f"/support/checkout/{intent_id}", provider_fee_minor=min(fee, amount_minor))

    def build_event(self, provider_ref: str, status: str) -> tuple[bytes, str]:
        body = json.dumps({"id": f"evt_{uuid.uuid4().hex[:20]}", "type": f"payment.{status}", "provider_ref": provider_ref,
                           "created": int(time.time())}).encode()
        return body, sign("simulated-webhook", body.decode())

    def verify_webhook(self, body: bytes, signature: str) -> dict | None:
        if not verify_sig("simulated-webhook", body.decode(errors="replace"), signature):
            return None
        return json.loads(body)


class LightningProvider(Protocol):  # pragma: no cover - interface only
    """Contract for a future Lightning adapter (not implemented):
    * amounts are integer satoshis (currency "SAT"); never floats;
    * create_invoice returns a BOLT11 invoice and payment hash from a maintained provider/node;
    * settlement is confirmed by the provider (or node) — never by the client;
    * routing/provider fees are recorded explicitly;
    * fulfilment is idempotent on the payment hash."""

    def create_invoice(self, amount_sats: int, memo: str) -> dict: ...
    def is_settled(self, payment_hash: str) -> bool: ...


def get_provider() -> SimulatedProvider:
    return SimulatedProvider()
