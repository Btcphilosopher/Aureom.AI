"""Optional artist support: external links, one-time tips and pay-what-you-want downloads.

Purchasing/tipping (PaymentIntent), download entitlement (DownloadEntitlement)
and author payout (PayoutLedgerEntry) are separate records. Payments are
SIMULATED in this release; no money moves.
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core import ratelimit
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, get_viewer, require_artist_perm, require_user
from commonwave.core.errors import ApiError, bad_request, not_found
from commonwave.core.sanitize import clean_line
from commonwave.core.siteconfig import get_config
from commonwave.models import ArtistProfile, DownloadEntitlement, PaymentIntent, PayoutLedgerEntry, ProviderEvent, Release
from commonwave.modules.support.providers import get_provider

router = APIRouter(tags=["support"])
CURRENCIES = {"USD", "EUR", "GBP"}


def _enabled(db: Session) -> None:
    if not get_settings().support_enabled or not get_config(db)["support_module_enabled"]:
        raise ApiError(404, "support_disabled", "The support module is not enabled on this server.")


def intent_payload(i: PaymentIntent) -> dict:
    return {"id": str(i.id), "kind": i.kind, "status": i.status, "amount_minor": i.amount_minor, "currency": i.currency,
            "platform_fee_minor": i.platform_fee_minor, "provider_fee_minor": i.provider_fee_minor,
            "artist_receives_minor": max(0, i.amount_minor - i.platform_fee_minor - i.provider_fee_minor),
            "provider": i.provider, "simulated": i.provider == "simulated", "release_id": str(i.release_id) if i.release_id else None,
            "artist_id": str(i.artist_id), "created_at": i.created_at.isoformat(), "settled_at": i.settled_at.isoformat() if i.settled_at else None}


class IntentIn(BaseModel):
    kind: str = Field(pattern="^(tip|pwyw_download)$")
    artist_id: uuid.UUID | None = None
    release_id: uuid.UUID | None = None
    amount_minor: int = Field(ge=0, le=1_000_000)
    currency: str = "USD"
    message: str | None = Field(default=None, max_length=280)
    idempotency_key: str = Field(min_length=8, max_length=64)


@router.post("/support/intents", status_code=201)
def create_intent(body: IntentIn, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    _enabled(db)
    ratelimit.enforce("tip", request, str(viewer.id))
    existing = db.scalar(select(PaymentIntent).where(PaymentIntent.payer_user_id == viewer.id, PaymentIntent.idempotency_key == body.idempotency_key))
    if existing:
        return {**intent_payload(existing), "checkout_url": f"/support/checkout/{existing.id}", "idempotent_replay": True}
    if body.currency not in CURRENCIES:
        raise bad_request("invalid_currency", "Supported currencies: " + ", ".join(sorted(CURRENCIES)))
    release = None
    if body.kind == "tip":
        artist = db.get(ArtistProfile, body.artist_id) if body.artist_id else None
        if not artist or artist.status != "active" or not artist.tips_enabled:
            raise not_found("artist")
        if body.amount_minor < 100:
            raise bad_request("amount_too_small", "The minimum tip is 1.00.")
    else:
        release = db.get(Release, body.release_id) if body.release_id else None
        if not release or not release.is_public or not release.pwyw_enabled:
            raise not_found("release")
        artist = db.get(ArtistProfile, release.artist_id)
        if body.currency != release.pwyw_currency:
            raise bad_request("currency_mismatch", f"This release is priced in {release.pwyw_currency}.")
        if body.amount_minor < release.pwyw_min_minor:
            raise bad_request("amount_too_small", "The amount is below the artist's minimum.")
        if db.scalar(select(DownloadEntitlement.id).where(DownloadEntitlement.user_id == viewer.id, DownloadEntitlement.release_id == release.id)):
            raise ApiError(409, "already_entitled", "You can already download this release.")
    s = get_settings()
    provider = get_provider()
    intent = PaymentIntent(kind=body.kind, artist_id=artist.id, payer_user_id=viewer.id, release_id=release.id if release else None,
                           amount_minor=body.amount_minor, currency=body.currency, provider=provider.name, provider_ref="pending",
                           platform_fee_minor=body.amount_minor * s.platform_fee_bps // 10_000, idempotency_key=body.idempotency_key,
                           message=clean_line(body.message, 280))
    db.add(intent)
    db.flush()
    if body.amount_minor == 0:
        # Free pay-what-you-want choice: no payment, entitlement directly.
        intent.provider_ref = f"free_{intent.id.hex[:20]}"
        intent.status = "settled"
        intent.settled_at = utcnow()
        _fulfil(db, intent)
        return {**intent_payload(intent), "checkout_url": None}
    co = provider.create_checkout(intent.id, body.amount_minor, body.currency)
    intent.provider_ref = co.provider_ref
    intent.provider_fee_minor = co.provider_fee_minor
    audit(db, viewer.id, "support.intent", "artist", artist.id, kind=body.kind, amount=body.amount_minor, currency=body.currency)
    return {**intent_payload(intent), "checkout_url": co.checkout_url}


@router.get("/support/intents/{intent_id}")
def get_intent(intent_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    i = db.get(PaymentIntent, intent_id)
    if not i or i.payer_user_id != viewer.id:
        raise not_found("payment")
    return intent_payload(i)


@router.post("/support/simulated/{intent_id}/complete")
def simulate_payment(intent_id: uuid.UUID, outcome: str = "paid", viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    """Simulated checkout page action. Emits a signed provider webhook and delivers it
    through the same handler a real provider would call."""
    _enabled(db)
    i = db.get(PaymentIntent, intent_id)
    if not i or i.payer_user_id != viewer.id or i.provider != "simulated":
        raise not_found("payment")
    body, sig = get_provider().build_event(i.provider_ref, "succeeded" if outcome == "paid" else "failed")
    return handle_webhook(db, body, sig)


def handle_webhook(db: Session, body: bytes, signature: str) -> dict:
    event = get_provider().verify_webhook(body, signature)
    if not event:
        raise ApiError(400, "invalid_signature", "Webhook signature verification failed.")
    try:
        with db.begin_nested():
            db.add(ProviderEvent(provider="simulated", event_id=event["id"]))
            db.flush()
    except IntegrityError:
        return {"ok": True, "duplicate_event": True}
    i = db.scalar(select(PaymentIntent).where(PaymentIntent.provider_ref == event.get("provider_ref")).with_for_update())
    if not i:
        return {"ok": True, "unknown_intent": True}
    db.execute(ProviderEvent.__table__.update().where(ProviderEvent.event_id == event["id"]).values(intent_id=i.id))
    if i.status != "pending":
        return {"ok": True, "status": i.status, "already_processed": True}
    if event["type"] == "payment.succeeded":
        i.status = "settled"
        i.settled_at = utcnow()
        _fulfil(db, i)
    else:
        i.status = "failed"
    return {"ok": True, "status": i.status, "intent": intent_payload(i)}


@router.post("/support/webhooks/simulated", include_in_schema=True)
async def simulated_webhook(request: Request, x_signature: str = Header(...), db: Session = Depends(get_db)):
    return handle_webhook(db, await request.body(), x_signature)


def _fulfil(db: Session, i: PaymentIntent) -> None:
    """Idempotent: entitlement and ledger rows are unique per intent."""
    if i.kind == "pwyw_download" and i.release_id and i.payer_user_id:
        if not db.scalar(select(DownloadEntitlement.id).where(DownloadEntitlement.user_id == i.payer_user_id, DownloadEntitlement.release_id == i.release_id)):
            db.add(DownloadEntitlement(user_id=i.payer_user_id, release_id=i.release_id, intent_id=i.id))
    if i.amount_minor > 0 and not db.scalar(select(PayoutLedgerEntry.id).where(PayoutLedgerEntry.intent_id == i.id)):
        db.add(PayoutLedgerEntry(artist_id=i.artist_id, intent_id=i.id, currency=i.currency, gross_minor=i.amount_minor,
                                 platform_fee_minor=i.platform_fee_minor, provider_fee_minor=i.provider_fee_minor,
                                 net_minor=max(0, i.amount_minor - i.platform_fee_minor - i.provider_fee_minor)))
    db.flush()


@router.get("/artists/{artist_id}/support/ledger")
def ledger(artist_id: uuid.UUID, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, artist_id, "support")
    rows = db.scalars(select(PayoutLedgerEntry).where(PayoutLedgerEntry.artist_id == artist_id).order_by(PayoutLedgerEntry.created_at.desc()).limit(200)).all()
    totals = db.execute(select(PayoutLedgerEntry.currency, func.sum(PayoutLedgerEntry.gross_minor), func.sum(PayoutLedgerEntry.net_minor))
                        .where(PayoutLedgerEntry.artist_id == artist_id).group_by(PayoutLedgerEntry.currency)).all()
    return {"simulated": True,
            "totals": [{"currency": c, "gross_minor": int(g), "net_minor": int(n)} for c, g, n in totals],
            "entries": [{"id": str(e.id), "currency": e.currency, "gross_minor": e.gross_minor, "platform_fee_minor": e.platform_fee_minor,
                         "provider_fee_minor": e.provider_fee_minor, "net_minor": e.net_minor, "status": e.status,
                         "created_at": e.created_at.isoformat()} for e in rows]}


@router.get("/support/config")
def support_config(viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    s = get_settings()
    enabled = s.support_enabled and get_config(db)["support_module_enabled"]
    return {"enabled": enabled, "provider": s.payment_provider, "simulated": s.payment_provider == "simulated",
            "platform_fee_bps": s.platform_fee_bps, "provider_fee_bps": s.simulated_provider_fee_bps,
            "provider_fixed_fee_minor": s.simulated_provider_fixed_fee_minor, "currencies": sorted(CURRENCIES),
            "token_required": False}
