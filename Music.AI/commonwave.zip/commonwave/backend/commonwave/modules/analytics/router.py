from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from commonwave.core.db import get_db
from commonwave.core.deps import Viewer, require_artist_perm, require_user
from commonwave.modules.analytics.stats import artist_stats

router = APIRouter(tags=["analytics"])


@router.get("/artists/{artist_id}/stats")
def stats(artist_id: uuid.UUID, days: int = Query(28, ge=1, le=365), viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    require_artist_perm(db, viewer, artist_id, "stats")
    return artist_stats(db, artist_id, days)
