"""Aggregated artist statistics. Individual listeners are never exposed.

Definitions (also in docs/analytics.md):
* playback_requests — playback sessions created (the listener pressed play and we issued a stream URL).
* playback_starts   — sessions that reported a ``start`` event.
* qualified_listens — sessions meeting the published qualified-listen rule.
* listening_ms      — server-credited listening time (bounded by real time).
* completions       — sessions that reached the end after hearing at least half the track.
* unique_listeners  — distinct pseudonymous listener keys (anonymous keys rotate daily, so this over-counts returning anonymous listeners).
* downloads, saves, follows — counted separately from plays.
Sessions flagged as automated and artist previews are excluded from every figure.
Numbers below 5 for unique listeners are reported as "<5" to reduce re-identification risk.
"""
from __future__ import annotations

import uuid

from sqlalchemy import text
from sqlalchemy.orm import Session


def artist_stats(db: Session, artist_id: uuid.UUID, days: int = 28) -> dict:
    params = {"a": artist_id, "days": days}
    totals = db.execute(text("""
        SELECT count(*) AS requests,
               count(*) FILTER (WHERE started_at IS NOT NULL) AS starts,
               count(*) FILTER (WHERE qualified) AS qualified,
               coalesce(sum(listened_ms), 0) AS listened_ms,
               count(*) FILTER (WHERE completed) AS completions,
               count(DISTINCT listener_key) FILTER (WHERE qualified) AS listeners,
               count(*) FILTER (WHERE suspected_bot) AS excluded_automated
        FROM playback_sessions
        WHERE artist_id = :a AND NOT is_preview AND created_at > now() - make_interval(days => :days)
    """), params).mappings().one()
    bot_free = db.execute(text("""
        SELECT count(*) AS requests,
               count(*) FILTER (WHERE started_at IS NOT NULL) AS starts,
               count(*) FILTER (WHERE qualified) AS qualified,
               coalesce(sum(listened_ms), 0) AS listened_ms,
               count(*) FILTER (WHERE completed) AS completions,
               count(DISTINCT listener_key) FILTER (WHERE qualified) AS listeners
        FROM playback_sessions
        WHERE artist_id = :a AND NOT is_preview AND NOT suspected_bot AND created_at > now() - make_interval(days => :days)
    """), params).mappings().one()
    downloads = db.execute(text("""SELECT count(*) FROM downloads WHERE artist_id = :a AND created_at > now() - make_interval(days => :days)"""), params).scalar()
    saves = db.execute(text("""
        SELECT count(*) FROM saves s
        LEFT JOIN tracks t ON s.target_type = 'track' AND t.id = s.target_id
        LEFT JOIN releases r ON s.target_type = 'release' AND r.id = s.target_id
        WHERE coalesce(t.artist_id, r.artist_id) = :a AND s.created_at > now() - make_interval(days => :days)"""), params).scalar()
    follows = db.execute(text("SELECT count(*) FROM follows WHERE artist_id = :a AND created_at > now() - make_interval(days => :days)"), params).scalar()
    followers_total = db.execute(text("SELECT count(*) FROM follows WHERE artist_id = :a"), params).scalar()
    per_track = db.execute(text("""
        SELECT t.id, t.title,
               count(s.id) FILTER (WHERE NOT s.suspected_bot) AS requests,
               count(s.id) FILTER (WHERE s.qualified) AS qualified,
               coalesce(sum(s.listened_ms) FILTER (WHERE NOT s.suspected_bot), 0) AS listened_ms,
               count(s.id) FILTER (WHERE s.completed AND NOT s.suspected_bot) AS completions,
               (SELECT count(*) FROM downloads d WHERE d.track_id = t.id AND d.created_at > now() - make_interval(days => :days)) AS downloads
        FROM tracks t
        LEFT JOIN playback_sessions s ON s.track_id = t.id AND NOT s.is_preview AND s.created_at > now() - make_interval(days => :days)
        WHERE t.artist_id = :a AND t.status <> 'draft'
        GROUP BY t.id, t.title ORDER BY qualified DESC, t.title
    """), params).mappings().all()
    daily = db.execute(text("""
        SELECT to_char(d, 'YYYY-MM-DD') AS day,
               (SELECT count(*) FROM playback_sessions s WHERE s.artist_id = :a AND s.qualified AND NOT s.is_preview
                  AND s.qualified_at >= d AND s.qualified_at < d + interval '1 day') AS qualified
        FROM generate_series(date_trunc('day', now()) - make_interval(days => :days - 1), date_trunc('day', now()), interval '1 day') d
        ORDER BY d
    """), params).mappings().all()

    def bucket(n: int) -> int | str:
        return "<5" if 0 < n < 5 else n

    starts = bot_free["starts"] or 0
    return {
        "window_days": days,
        "totals": {
            "playback_requests": bot_free["requests"], "playback_starts": starts, "qualified_listens": bot_free["qualified"],
            "listening_hours": round(bot_free["listened_ms"] / 3_600_000, 2), "completions": bot_free["completions"],
            "completion_rate": round(bot_free["completions"] / starts, 3) if starts else None,
            "unique_listeners": bucket(bot_free["listeners"]), "downloads": downloads, "saves": saves,
            "new_follows": follows, "followers_total": followers_total,
            "excluded_automated_sessions": totals["excluded_automated"],
        },
        "tracks": [{"track_id": str(r["id"]), "title": r["title"], "playback_requests": r["requests"], "qualified_listens": r["qualified"],
                    "listening_hours": round(r["listened_ms"] / 3_600_000, 2), "completions": r["completions"], "downloads": r["downloads"]}
                   for r in per_track],
        "daily_qualified_listens": [dict(r) for r in daily],
        "definitions": __doc__,
    }
