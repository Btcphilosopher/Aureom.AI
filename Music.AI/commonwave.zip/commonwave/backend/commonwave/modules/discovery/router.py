"""Discovery: deterministic feeds, genres/tags, editorial collections and PostgreSQL full-text search."""
from __future__ import annotations

import re
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from commonwave.core.cache import cached
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, get_viewer, require_user
from commonwave.core.errors import not_found
from commonwave.models import ArtistProfile, EditorialCollection, Follow, Release, Track
from commonwave.modules.catalogue.service import artist_brief, serialize_track
from commonwave.modules.community.router import release_brief
from commonwave.modules.discovery.ranking import get_ranker

router = APIRouter(tags=["discovery"])


def _public_tracks():
    return (select(Track).join(ArtistProfile, ArtistProfile.id == Track.artist_id)
            .where(Track.status == "published", Track.moderation_restricted.is_(False), ArtistProfile.status != "suspended"))


def _public_releases():
    return (select(Release).join(ArtistProfile, ArtistProfile.id == Release.artist_id)
            .where(Release.status == "published", Release.moderation_restricted.is_(False), ArtistProfile.status != "suspended"))


def _tracks(db: Session, ids: list[uuid.UUID]) -> list[dict]:
    out = []
    for i in ids:
        t = db.get(Track, i)
        if t and t.is_public:
            out.append(serialize_track(db, t))
    return out


def _collection(db: Session, c: EditorialCollection) -> dict:
    releases = [release_brief(db, r) for r in (db.get(Release, uuid.UUID(i)) for i in c.release_ids) if r and r.is_public]
    return {"slug": c.slug, "title": c.title, "description": c.description, "curator_note": c.curator_note,
            "releases": releases, "tracks": _tracks(db, [uuid.UUID(i) for i in c.track_ids])}


def _general_feed(db: Session) -> dict:
    latest_releases = db.scalars(_public_releases().order_by(Release.published_at.desc()).limit(12)).all()
    latest_tracks = db.scalars(_public_tracks().order_by(Track.published_at.desc()).limit(12)).all()
    first_pub = (select(Track.artist_id, func.min(Track.published_at).label("first"))
                 .where(Track.status == "published", Track.moderation_restricted.is_(False)).group_by(Track.artist_id).subquery())
    new_voices = db.scalars(select(ArtistProfile).join(first_pub, first_pub.c.artist_id == ArtistProfile.id)
                            .where(first_pub.c.first > utcnow() - timedelta(days=60), ArtistProfile.status != "suspended")
                            .order_by(first_pub.c.first.desc()).limit(10)).all()
    active = db.scalars(select(ArtistProfile).where(ArtistProfile.last_published_at.is_not(None), ArtistProfile.status != "suspended")
                        .order_by(ArtistProfile.last_published_at.desc()).limit(10)).all()
    genres = db.execute(select(Track.genre, func.count()).where(Track.status == "published", Track.moderation_restricted.is_(False), Track.genre.is_not(None))
                        .group_by(Track.genre).order_by(func.count().desc(), Track.genre).limit(24)).all()
    collections = db.scalars(select(EditorialCollection).where(EditorialCollection.published.is_(True)).order_by(EditorialCollection.position).limit(4)).all()
    ranker = get_ranker()
    return {
        "personalised": False,
        "ranking": ranker.name,
        "latest_releases": [release_brief(db, r) for r in latest_releases],
        "latest_tracks": [serialize_track(db, t) for t in latest_tracks],
        "popular_tracks": _tracks(db, ranker.popular_tracks(db, 10)),
        "new_voices": [artist_brief(a) for a in new_voices],
        "recently_active_artists": [{**artist_brief(a), "last_published_at": a.last_published_at.isoformat()} for a in active],
        "genres": [{"genre": g, "track_count": n} for g, n in genres],
        "collections": [_collection(db, c) for c in collections],
    }


@router.get("/discover")
def discover(personalised: bool = False, viewer: Viewer = Depends(get_viewer), db: Session = Depends(get_db)):
    """The default feed is identical for everyone (non-personalised). Personalisation is opt-in
    and uses only explicit interests and follows."""
    feed = cached("discover:general", 60, lambda: _general_feed(db))
    if personalised and viewer.user and viewer.user.personalisation_enabled:
        interests = [i for i in (viewer.user.interests or []) if isinstance(i, str)]
        q = _public_tracks().order_by(Track.published_at.desc()).limit(12)
        followed = select(Follow.artist_id).where(Follow.user_id == viewer.id)
        conds = [Track.artist_id.in_(followed)]
        if interests:
            conds.append(Track.genre.in_(interests))
        from sqlalchemy import or_
        picks = db.scalars(q.where(or_(*conds))).all()
        feed = {**feed, "personalised": True, "for_you": {
            "explanation": "Recent tracks from artists you follow" + (f" and your chosen interests ({', '.join(interests)})" if interests else ""),
            "tracks": [serialize_track(db, t) for t in picks]}}
    return feed


@router.get("/discover/following")
def following_feed(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    followed = select(Follow.artist_id).where(Follow.user_id == viewer.id)
    tracks = db.scalars(_public_tracks().where(Track.artist_id.in_(followed)).order_by(Track.published_at.desc()).limit(50)).all()
    releases = db.scalars(_public_releases().where(Release.artist_id.in_(followed)).order_by(Release.published_at.desc()).limit(20)).all()
    artists = db.scalars(select(ArtistProfile).where(ArtistProfile.id.in_(followed), ArtistProfile.status != "suspended").order_by(ArtistProfile.name)).all()
    return {"artists": [artist_brief(a) for a in artists], "releases": [release_brief(db, r) for r in releases],
            "tracks": [serialize_track(db, t) for t in tracks]}


@router.get("/genres")
def genres(db: Session = Depends(get_db)):
    rows = db.execute(select(Track.genre, func.count()).where(Track.status == "published", Track.moderation_restricted.is_(False), Track.genre.is_not(None))
                      .group_by(Track.genre).order_by(Track.genre)).all()
    return [{"genre": g, "track_count": n} for g, n in rows]


@router.get("/genres/{genre}")
def genre(genre: str, sort: str = Query("latest", pattern="^(latest|popular)$"), db: Session = Depends(get_db)):
    g = genre.lower()
    if sort == "popular":
        tracks = _tracks(db, get_ranker().popular_tracks(db, 30, genre=g))
    else:
        tracks = [serialize_track(db, t) for t in db.scalars(_public_tracks().where(Track.genre == g).order_by(Track.published_at.desc()).limit(50))]
    releases = db.scalars(_public_releases().where(Release.genre == g).order_by(Release.published_at.desc()).limit(20)).all()
    return {"genre": g, "sort": sort, "tracks": tracks, "releases": [release_brief(db, r) for r in releases]}


@router.get("/tags/{tag}")
def tag(tag: str, db: Session = Depends(get_db)):
    t = tag.lower()
    tracks = db.scalars(_public_tracks().where(Track.tags.any(t)).order_by(Track.published_at.desc()).limit(50)).all()
    return {"tag": t, "tracks": [serialize_track(db, x) for x in tracks]}


@router.get("/collections")
def collections(db: Session = Depends(get_db)):
    cs = db.scalars(select(EditorialCollection).where(EditorialCollection.published.is_(True)).order_by(EditorialCollection.position)).all()
    return [{"slug": c.slug, "title": c.title, "description": c.description} for c in cs]


@router.get("/collections/{slug}")
def collection(slug: str, db: Session = Depends(get_db)):
    c = db.scalar(select(EditorialCollection).where(EditorialCollection.slug == slug, EditorialCollection.published.is_(True)))
    if not c:
        raise not_found("collection")
    return _collection(db, c)


_WORD = re.compile(r"[\w]+", re.UNICODE)


def to_tsquery(q: str) -> str | None:
    """Build a safe prefix tsquery from free text: only word characters survive."""
    words = [w for w in _WORD.findall(q.lower()) if w][:8]
    return " & ".join(f"{w}:*" for w in words) or None


@router.get("/search")
def search(q: str = Query(min_length=1, max_length=120), type: str = Query("all", pattern="^(all|tracks|artists|releases)$"),
           limit: int = Query(20, ge=1, le=50), db: Session = Depends(get_db)):
    tsq = to_tsquery(q)
    out = {"query": q, "tracks": [], "artists": [], "releases": []}
    if not tsq:
        return out
    query = func.to_tsquery("simple", tsq)
    if type in ("all", "tracks"):
        rows = db.scalars(_public_tracks().where(Track.search_vector.op("@@")(query))
                          .order_by(func.ts_rank(Track.search_vector, query).desc(), Track.published_at.desc()).limit(limit)).all()
        out["tracks"] = [serialize_track(db, t) for t in rows]
    if type in ("all", "artists"):
        rows = db.scalars(select(ArtistProfile).where(ArtistProfile.status != "suspended", ArtistProfile.search_vector.op("@@")(query),
                                                       ArtistProfile.last_published_at.is_not(None))
                          .order_by(func.ts_rank(ArtistProfile.search_vector, query).desc()).limit(limit)).all()
        out["artists"] = [artist_brief(a) for a in rows]
    if type in ("all", "releases"):
        rows = db.scalars(_public_releases().where(Release.search_vector.op("@@")(query))
                          .order_by(func.ts_rank(Release.search_vector, query).desc()).limit(limit)).all()
        out["releases"] = [release_brief(db, r) for r in rows]
    return out


@router.get("/discover/rules")
def rules():
    from commonwave.modules.discovery import ranking
    return {"ranker": get_ranker().name, "popular_tracks_rules": ranking.__doc__}
