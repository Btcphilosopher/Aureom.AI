"""Replaceable discovery ranking.

``DeterministicRanker`` implements the documented, non-personalised rules in
docs/discovery.md. Operators can swap in another implementation of ``Ranker``
(``set_ranker``) without touching the HTTP layer.

Popular tracks — rules (abuse-resistant, not fraud-proof):
* Window: the last 14 days only, so early success does not lock in rank forever.
* Signal: *distinct listeners* with a qualified listen (not raw play counts), plus
  distinct users who saved the track (weight 2) and distinct downloaders (weight 1).
* Each listener's contribution decays with a 7-day half-life.
* Excluded: sessions flagged as automated, artist previews, and listens by the
  artist's own members.
* A track needs at least 3 distinct listeners to be ranked; at most 2 tracks per
  artist appear, so one artist cannot fill the list.
* New artists get a separate "New voices" shelf ordered by first publication, so
  exposure does not depend on accumulated plays.
"""
from __future__ import annotations

import uuid
from typing import Protocol

from sqlalchemy import text
from sqlalchemy.orm import Session

POPULAR_SQL = text("""
WITH listens AS (
    SELECT s.track_id, s.listener_key, max(s.qualified_at) AS last_at
    FROM playback_sessions s
    WHERE s.qualified AND NOT s.suspected_bot AND NOT s.is_preview
      AND s.qualified_at > now() - interval '14 days'
      AND (s.user_id IS NULL OR NOT EXISTS (
            SELECT 1 FROM artist_memberships m WHERE m.artist_id = s.artist_id AND m.user_id = s.user_id))
    GROUP BY s.track_id, s.listener_key
), listen_score AS (
    SELECT track_id, count(*) AS listeners,
           sum(power(0.5, extract(epoch FROM (now() - last_at)) / 86400.0 / 7.0)) AS score
    FROM listens GROUP BY track_id
), save_score AS (
    SELECT target_id AS track_id, count(DISTINCT user_id) * 2.0 AS score
    FROM saves WHERE target_type = 'track' AND created_at > now() - interval '14 days' GROUP BY target_id
), dl_score AS (
    SELECT track_id, count(DISTINCT listener_key) * 1.0 AS score
    FROM downloads WHERE track_id IS NOT NULL AND created_at > now() - interval '14 days' GROUP BY track_id
), ranked AS (
    SELECT t.id, t.artist_id,
           coalesce(l.score, 0) + coalesce(sv.score, 0) + coalesce(d.score, 0) AS score,
           coalesce(l.listeners, 0) AS listeners,
           row_number() OVER (PARTITION BY t.artist_id ORDER BY coalesce(l.score, 0) + coalesce(sv.score, 0) + coalesce(d.score, 0) DESC) AS per_artist
    FROM tracks t
    JOIN artist_profiles a ON a.id = t.artist_id AND a.status <> 'suspended'
    LEFT JOIN listen_score l ON l.track_id = t.id
    LEFT JOIN save_score sv ON sv.track_id = t.id
    LEFT JOIN dl_score d ON d.track_id = t.id
    WHERE t.status = 'published' AND NOT t.moderation_restricted
)
SELECT id, score, listeners FROM ranked
WHERE listeners >= :min_listeners AND per_artist <= 2
ORDER BY score DESC, id
LIMIT :limit
""")


class Ranker(Protocol):
    name: str

    def popular_tracks(self, db: Session, limit: int, genre: str | None = None) -> list[uuid.UUID]: ...


class DeterministicRanker:
    name = "deterministic-v1"
    min_listeners = 3

    def popular_tracks(self, db: Session, limit: int, genre: str | None = None) -> list[uuid.UUID]:
        rows = db.execute(POPULAR_SQL, {"limit": limit * 3 if genre else limit, "min_listeners": self.min_listeners}).all()
        ids = [r[0] for r in rows]
        if genre and ids:
            keep = set(db.execute(text("SELECT id FROM tracks WHERE id = ANY(:ids) AND genre = :g"), {"ids": ids, "g": genre}).scalars())
            ids = [i for i in ids if i in keep]
        return ids[:limit]


_ranker: Ranker = DeterministicRanker()


def get_ranker() -> Ranker:
    return _ranker


def set_ranker(r: Ranker) -> None:
    global _ranker
    _ranker = r
