"""Reports, rights complaints, moderation actions, appeals and decision history.

Visibility restrictions (reversible, immediate) are separate from permanent
deletion (admin-only, irreversible). Automated matching is never treated as
proof: every action records a human moderator and a reason.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from commonwave.core import cache, ratelimit
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, membership_role, require_staff, require_user
from commonwave.core.errors import ApiError, bad_request, conflict, forbidden, not_found
from commonwave.core.sanitize import clean_line, clean_text
from commonwave.core.siteconfig import get_config
from commonwave.core.storage import get_storage
from commonwave.models import (
    Appeal, ArtistMembership, ArtistProfile, AudioAsset, Comment, ModerationAction, Playlist, Release, Report, Track, TrackVersion, User,
)
from commonwave.models.community import MODERATION_ACTIONS, REPORT_REASONS, REPORT_TARGETS

router = APIRouter(tags=["moderation"])


class RightsClaimIn(BaseModel):
    claimant_name: str = Field(min_length=2, max_length=200)
    claimant_contact: str = Field(min_length=3, max_length=200)
    relationship: str = Field(max_length=100)  # e.g. "rights-holder", "authorised agent"
    original_work: str = Field(min_length=3, max_length=1000)
    good_faith_statement: bool
    accuracy_statement: bool


class ReportIn(BaseModel):
    target_type: str
    target_id: uuid.UUID
    reason: str
    details: str | None = Field(default=None, max_length=4000)
    rights_claim: RightsClaimIn | None = None


def _target_exists(db: Session, viewer: Viewer, target_type: str, target_id: uuid.UUID) -> bool:
    model = {"track": Track, "release": Release, "comment": Comment, "artist": ArtistProfile, "playlist": Playlist, "user": User}[target_type]
    obj = db.get(model, target_id)
    if not obj:
        return False
    if target_type == "track":
        return obj.is_public
    if target_type == "comment":
        return obj.status in ("visible", "held")
    if target_type == "playlist":
        return obj.visibility != "private" or obj.owner_id == viewer.id
    return True


@router.post("/reports", status_code=201)
def create_report(body: ReportIn, request: Request, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    ratelimit.enforce("report", request, str(viewer.id))
    if not get_config(db)["reports_enabled"]:
        raise ApiError(403, "reports_disabled", "Reporting is disabled on this server; contact the operators.")
    if body.target_type not in REPORT_TARGETS or body.reason not in REPORT_REASONS:
        raise bad_request("invalid_report", "Unknown report target or reason")
    if not _target_exists(db, viewer, body.target_type, body.target_id):
        raise not_found(body.target_type)
    claim = None
    priority = 0
    if body.reason == "rights":
        if not body.rights_claim or not body.rights_claim.good_faith_statement or not body.rights_claim.accuracy_statement:
            raise bad_request("rights_claim_incomplete", "Rights complaints need claimant details and both statements.")
        claim = {k: clean_text(str(v), 1000) if isinstance(v, str) else v for k, v in body.rights_claim.model_dump().items()}
        priority = 2
    existing = db.scalar(select(Report).where(Report.reporter_id == viewer.id, Report.target_type == body.target_type,
                                              Report.target_id == body.target_id, Report.status == "open"))
    if existing:
        return {"id": str(existing.id), "status": existing.status, "duplicate": True}
    r = Report(reporter_id=viewer.id, target_type=body.target_type, target_id=body.target_id, reason=body.reason,
               details=clean_text(body.details, 4000), rights_claim=claim, priority=priority)
    db.add(r)
    db.flush()
    audit(db, viewer.id, "report.create", body.target_type, body.target_id, reason=body.reason)
    return {"id": str(r.id), "status": r.status, "duplicate": False}


def _describe_target(db: Session, target_type: str, target_id: uuid.UUID) -> dict:
    if target_type == "track":
        t = db.get(Track, target_id)
        return {"title": t.title, "status": t.status, "restricted": t.moderation_restricted, "artist_id": str(t.artist_id)} if t else {}
    if target_type == "comment":
        c = db.get(Comment, target_id)
        if not c:
            return {}
        u = db.get(User, c.user_id)
        return {"body": c.body, "status": c.status, "author": u.username, "track_id": str(c.track_id)}
    if target_type == "artist":
        a = db.get(ArtistProfile, target_id)
        return {"name": a.name, "slug": a.slug, "status": a.status} if a else {}
    if target_type == "release":
        r = db.get(Release, target_id)
        return {"title": r.title, "status": r.status, "restricted": r.moderation_restricted} if r else {}
    if target_type == "user":
        u = db.get(User, target_id)
        return {"username": u.username, "status": u.status} if u else {}
    if target_type == "playlist":
        p = db.get(Playlist, target_id)
        return {"title": p.title, "visibility": p.visibility} if p else {}
    return {}


def report_payload(db: Session, r: Report) -> dict:
    reporter = db.get(User, r.reporter_id) if r.reporter_id else None
    return {"id": str(r.id), "target_type": r.target_type, "target_id": str(r.target_id), "reason": r.reason, "details": r.details,
            "rights_claim": r.rights_claim, "status": r.status, "priority": r.priority, "created_at": r.created_at.isoformat(),
            "reporter": reporter.username if reporter else None, "target": _describe_target(db, r.target_type, r.target_id),
            "resolved_at": r.resolved_at.isoformat() if r.resolved_at else None}


@router.get("/mod/reports")
def list_reports(status: str = "open", viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    rows = db.scalars(select(Report).where(Report.status == status).order_by(Report.priority.desc(), Report.created_at).limit(200)).all()
    return [report_payload(db, r) for r in rows]


class ActionIn(BaseModel):
    target_type: str
    target_id: uuid.UUID
    action: str
    reason: str = Field(min_length=3, max_length=4000)
    policy_ref: str | None = None
    report_id: uuid.UUID | None = None
    expires_at: datetime | None = None


def apply_action(db: Session, moderator: Viewer, body: ActionIn) -> ModerationAction:
    if body.action not in MODERATION_ACTIONS:
        raise bad_request("invalid_action", "Unknown moderation action")
    affected: uuid.UUID | None = None
    version_id = None
    a, tt, tid = body.action, body.target_type, body.target_id
    if a in ("hide_comment", "restore_comment"):
        c = db.get(Comment, tid) if tt == "comment" else None
        if not c:
            raise not_found("comment")
        c.status = "hidden" if a == "hide_comment" else "visible"
        c.hidden_reason = "Removed by moderators" if a == "hide_comment" else None
        affected = c.user_id
    elif a in ("restrict_track", "unrestrict_track", "withdraw_track", "restore_track", "delete_track_permanently"):
        t = db.get(Track, tid) if tt == "track" else None
        if not t:
            raise not_found("track")
        version_id = t.current_version_id
        affected = t.created_by
        if a == "restrict_track":
            t.moderation_restricted = True
            t.moderation_note = clean_line(body.reason, 300)
        elif a == "unrestrict_track":
            t.moderation_restricted = False
            t.moderation_note = None
        elif a == "withdraw_track":
            t.status = "withdrawn"
            t.withdrawn_at = utcnow()
        elif a == "restore_track":
            if not t.current_version_id:
                raise conflict("no_version", "This track has no published version to restore.")
            t.status = "published"
            t.withdrawn_at = None
            t.moderation_restricted = False
            t.moderation_note = None
        elif a == "delete_track_permanently":
            if not moderator.is_admin:
                raise forbidden("Only administrators can permanently delete content.")
            for v in db.scalars(select(TrackVersion).where(TrackVersion.track_id == t.id)):
                for aid in (v.original_asset_id, v.stream_asset_id):
                    asset = db.get(AudioAsset, aid) if aid else None
                    if asset and not asset.deleted_at:
                        get_storage().delete(asset.storage_key)
                        asset.deleted_at = utcnow()
            t.status = "withdrawn"
            t.moderation_restricted = True
            t.moderation_note = "Permanently removed"
            t.title = "[removed]"
            t.description = t.lyrics = None
    elif a in ("restrict_release", "unrestrict_release"):
        r = db.get(Release, tid) if tt == "release" else None
        if not r:
            raise not_found("release")
        r.moderation_restricted = a == "restrict_release"
    elif a in ("restrict_user", "suspend_user", "reinstate_user"):
        u = db.get(User, tid) if tt == "user" else None
        if not u:
            raise not_found("user")
        if u.role == "admin" and not moderator.is_admin:
            raise forbidden()
        affected = u.id
        if a == "restrict_user":
            if not body.expires_at:
                raise bad_request("expiry_required", "Temporary restrictions need an expiry time.")
            u.status, u.restricted_until = "restricted", body.expires_at
        elif a == "suspend_user":
            u.status, u.restricted_until = "suspended", body.expires_at
            from sqlalchemy import delete
            from commonwave.models import AuthSession
            db.execute(delete(AuthSession).where(AuthSession.user_id == u.id))
        else:
            u.status, u.restricted_until = "active", None
    elif a in ("restrict_artist", "suspend_artist", "reinstate_artist"):
        ar = db.get(ArtistProfile, tid) if tt == "artist" else None
        if not ar:
            raise not_found("artist")
        ar.status = {"restrict_artist": "restricted", "suspend_artist": "suspended", "reinstate_artist": "active"}[a]
        affected = db.scalar(select(ArtistMembership.user_id).where(ArtistMembership.artist_id == ar.id, ArtistMembership.role == "owner").limit(1))
    elif a in ("dismiss_report", "note"):
        pass
    act = ModerationAction(moderator_id=moderator.id, target_type=tt, target_id=tid, target_version_id=version_id, action=a,
                           reason=clean_text(body.reason, 4000), policy_ref=clean_line(body.policy_ref, 64), report_id=body.report_id,
                           expires_at=body.expires_at, affected_user_id=affected)
    db.add(act)
    if body.report_id:
        rep = db.get(Report, body.report_id)
        if rep and rep.status == "open":
            rep.status = "dismissed" if a == "dismiss_report" else "actioned"
            rep.resolved_at = utcnow()
            rep.resolved_by = moderator.id
    db.flush()
    audit(db, moderator.id, f"moderation.{a}", tt, tid, reason=body.reason[:200], report=body.report_id)
    cache.invalidate("discover")
    return act


def action_payload(db: Session, act: ModerationAction) -> dict:
    mod = db.get(User, act.moderator_id) if act.moderator_id else None
    return {"id": str(act.id), "action": act.action, "target_type": act.target_type, "target_id": str(act.target_id),
            "target_version_id": str(act.target_version_id) if act.target_version_id else None, "reason": act.reason,
            "policy_ref": act.policy_ref, "report_id": str(act.report_id) if act.report_id else None,
            "expires_at": act.expires_at.isoformat() if act.expires_at else None, "created_at": act.created_at.isoformat(),
            "moderator": mod.username if mod else None, "reversed_by_action_id": str(act.reversed_by_action_id) if act.reversed_by_action_id else None}


@router.post("/mod/actions", status_code=201)
def create_action(body: ActionIn, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    return action_payload(db, apply_action(db, viewer, body))


@router.get("/mod/actions")
def list_actions(target_type: str | None = None, target_id: uuid.UUID | None = None, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    q = select(ModerationAction)
    if target_type:
        q = q.where(ModerationAction.target_type == target_type)
    if target_id:
        q = q.where(ModerationAction.target_id == target_id)
    return [action_payload(db, a) for a in db.scalars(q.order_by(ModerationAction.created_at.desc()).limit(300))]


# ------------------------------------------------------------------ appeals


class AppealIn(BaseModel):
    action_id: uuid.UUID
    statement: str = Field(min_length=10, max_length=4000)


def _may_appeal(db: Session, viewer: Viewer, act: ModerationAction) -> bool:
    if act.affected_user_id == viewer.id:
        return True
    artist_id = None
    if act.target_type == "track":
        t = db.get(Track, act.target_id)
        artist_id = t.artist_id if t else None
    elif act.target_type == "release":
        r = db.get(Release, act.target_id)
        artist_id = r.artist_id if r else None
    elif act.target_type == "artist":
        artist_id = act.target_id
    return bool(artist_id and membership_role(db, artist_id, viewer.id) in ("owner", "manager"))


@router.get("/me/moderation")
def my_moderation(viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    """Decisions affecting the viewer or the artists they manage, so they can appeal."""
    artist_ids = list(db.scalars(select(ArtistMembership.artist_id).where(ArtistMembership.user_id == viewer.id, ArtistMembership.role.in_(("owner", "manager")))))
    track_ids = list(db.scalars(select(Track.id).where(Track.artist_id.in_(artist_ids)))) if artist_ids else []
    from sqlalchemy import or_
    q = select(ModerationAction).where(or_(ModerationAction.affected_user_id == viewer.id,
                                           ModerationAction.target_id.in_(track_ids + artist_ids))).where(ModerationAction.action.not_in(("note", "dismiss_report")))
    acts = db.scalars(q.order_by(ModerationAction.created_at.desc()).limit(100)).all()
    appeals = {a.action_id: a for a in db.scalars(select(Appeal).where(Appeal.appellant_id == viewer.id))}
    return [{**action_payload(db, a), "moderator": None, "appeal": ({"status": appeals[a.id].status, "decision_note": appeals[a.id].decision_note}
                                                                  if a.id in appeals else None)} for a in acts]


@router.post("/appeals", status_code=201)
def create_appeal(body: AppealIn, viewer: Viewer = Depends(require_user), db: Session = Depends(get_db)):
    act = db.get(ModerationAction, body.action_id)
    if not act or not _may_appeal(db, viewer, act):
        raise not_found("action")
    if db.scalar(select(Appeal.id).where(Appeal.action_id == act.id, Appeal.appellant_id == viewer.id)):
        raise conflict("already_appealed", "You have already appealed this decision.")
    ap = Appeal(action_id=act.id, appellant_id=viewer.id, statement=clean_text(body.statement, 4000))
    db.add(ap)
    db.flush()
    audit(db, viewer.id, "appeal.create", "moderation_action", act.id)
    return {"id": str(ap.id), "status": ap.status}


@router.get("/mod/appeals")
def list_appeals(status: str = "open", viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    rows = db.execute(select(Appeal, ModerationAction, User).join(ModerationAction, ModerationAction.id == Appeal.action_id)
                      .join(User, User.id == Appeal.appellant_id).where(Appeal.status == status).order_by(Appeal.created_at)).all()
    return [{"id": str(ap.id), "statement": ap.statement, "status": ap.status, "created_at": ap.created_at.isoformat(),
             "appellant": u.username, "action": action_payload(db, act)} for ap, act, u in rows]


REVERSALS = {"hide_comment": "restore_comment", "restrict_track": "unrestrict_track", "withdraw_track": "restore_track",
             "restrict_release": "unrestrict_release", "restrict_user": "reinstate_user", "suspend_user": "reinstate_user",
             "restrict_artist": "reinstate_artist", "suspend_artist": "reinstate_artist"}


class DecideIn(BaseModel):
    outcome: str = Field(pattern="^(upheld|reversed)$")
    note: str = Field(min_length=3, max_length=4000)


@router.post("/mod/appeals/{appeal_id}/decide")
def decide_appeal(appeal_id: uuid.UUID, body: DecideIn, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    ap = db.get(Appeal, appeal_id)
    if not ap or ap.status != "open":
        raise not_found("appeal")
    act = db.get(ModerationAction, ap.action_id)
    if act.moderator_id == viewer.id and not viewer.is_admin:
        raise forbidden("A different moderator should review appeals of your own decisions.")
    ap.status, ap.decided_by, ap.decision_note, ap.decided_at = body.outcome, viewer.id, clean_text(body.note, 4000), utcnow()
    if body.outcome == "reversed":
        rev = REVERSALS.get(act.action)
        if rev:
            new = apply_action(db, viewer, ActionIn(target_type=act.target_type, target_id=act.target_id, action=rev,
                                                     reason=f"Appeal upheld: {body.note}"))
            act.reversed_by_action_id = new.id
    audit(db, viewer.id, "appeal.decide", "appeal", ap.id, outcome=body.outcome)
    return {"id": str(ap.id), "status": ap.status}


@router.get("/mod/history/{target_type}/{target_id}")
def decision_history(target_type: str, target_id: uuid.UUID, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    acts = db.scalars(select(ModerationAction).where(ModerationAction.target_type == target_type, ModerationAction.target_id == target_id)
                      .order_by(ModerationAction.created_at)).all()
    reports = db.scalars(select(Report).where(Report.target_type == target_type, Report.target_id == target_id).order_by(Report.created_at)).all()
    return {"target": _describe_target(db, target_type, target_id), "actions": [action_payload(db, a) for a in acts],
            "reports": [report_payload(db, r) for r in reports]}


@router.get("/mod/summary")
def summary(viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    return {"open_reports": db.scalar(select(func.count()).select_from(Report).where(Report.status == "open")),
            "open_rights_complaints": db.scalar(select(func.count()).select_from(Report).where(Report.status == "open", Report.reason == "rights")),
            "open_appeals": db.scalar(select(func.count()).select_from(Appeal).where(Appeal.status == "open")),
            "held_comments": db.scalar(select(func.count()).select_from(Comment).where(Comment.status == "held"))}


@router.get("/mod/held-comments")
def held_comments(viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    rows = db.execute(select(Comment, User).join(User, User.id == Comment.user_id).where(Comment.status == "held").order_by(Comment.created_at).limit(200)).all()
    return [{"id": str(c.id), "body": c.body, "author": u.username, "track_id": str(c.track_id), "created_at": c.created_at.isoformat()} for c, u in rows]


def expire_restrictions(db: Session) -> int:
    rows = db.scalars(select(User).where(User.status == "restricted", User.restricted_until < utcnow())).all()
    for u in rows:
        u.status, u.restricted_until = "active", None
    sus = db.scalars(select(User).where(User.status == "suspended", User.restricted_until.is_not(None), User.restricted_until < utcnow())).all()
    for u in sus:
        u.status, u.restricted_until = "active", None
    return len(rows) + len(sus)


