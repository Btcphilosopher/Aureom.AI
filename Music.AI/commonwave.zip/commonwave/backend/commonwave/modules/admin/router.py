"""Administration: site configuration, users, artist verification, quotas, jobs, collections, audit log."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core import cache
from commonwave.core.audit import audit
from commonwave.core.db import get_db, utcnow
from commonwave.core.deps import Viewer, require_admin, require_staff
from commonwave.core.errors import bad_request, not_found
from commonwave.core.sanitize import clean_line, clean_text, slugify
from commonwave.core.siteconfig import get_config, set_config
from commonwave.models import (
    ArtistProfile, AuditLog, AudioAsset, EditorialCollection, Job, PlaybackSession, Release, Report, Track, User,
)
from commonwave.modules.catalogue.service import artist_brief, artist_storage_used
from commonwave.modules.processing.queue import enqueue

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/config")
def read_config(viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    s = get_settings()
    return {"community": get_config(db), "limits": {
        "max_upload_bytes": s.max_upload_bytes, "max_track_duration_seconds": s.max_track_duration_seconds,
        "default_artist_storage_quota_bytes": s.default_artist_storage_quota_bytes,
        "max_active_uploads_per_user": s.max_active_uploads_per_user, "processing_timeout_seconds": s.processing_timeout_seconds,
        "stream_bitrate_kbps": s.stream_bitrate_kbps, "storage_backend": s.storage_backend,
    }}


@router.patch("/config")
def write_config(updates: dict, viewer: Viewer = Depends(require_admin), db: Session = Depends(get_db)):
    try:
        cfg = set_config(db, updates, viewer.id)
    except ValueError as e:
        raise bad_request("invalid_config", str(e))
    audit(db, viewer.id, "admin.config", None, None, keys=sorted(updates))
    return {"community": cfg}


@router.get("/overview")
def overview(viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    count = lambda q: db.scalar(select(func.count()).select_from(q))  # noqa: E731
    return {
        "users": count(User), "artists": count(ArtistProfile),
        "published_tracks": db.scalar(select(func.count()).select_from(Track).where(Track.status == "published")),
        "draft_tracks": db.scalar(select(func.count()).select_from(Track).where(Track.status == "draft")),
        "releases": count(Release), "open_reports": db.scalar(select(func.count()).select_from(Report).where(Report.status == "open")),
        "jobs": {s: n for s, n in db.execute(select(Job.status, func.count()).group_by(Job.status)).all()},
        "storage_bytes": int(db.scalar(select(func.coalesce(func.sum(AudioAsset.size_bytes), 0)).where(AudioAsset.deleted_at.is_(None))) or 0),
        "playback_sessions_24h": db.scalar(select(func.count()).select_from(PlaybackSession).where(PlaybackSession.created_at > func.now() - func.make_interval(0, 0, 0, 1))),
    }


@router.get("/users")
def users(q: str = "", viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    query = select(User)
    if q:
        like = f"%{q.lower()}%"
        query = query.where(or_(func.lower(User.username).like(like), func.lower(User.email).like(like)))
    rows = db.scalars(query.order_by(User.created_at.desc()).limit(100)).all()
    return [{"id": str(u.id), "username": u.username, "email": u.email if viewer.is_admin else None, "role": u.role, "status": u.status,
             "restricted_until": u.restricted_until.isoformat() if u.restricted_until else None, "created_at": u.created_at.isoformat()} for u in rows]


class UserPatch(BaseModel):
    role: str | None = Field(default=None, pattern="^(user|moderator|admin)$")
    storage_quota_bytes: int | None = Field(default=None, ge=0)


@router.patch("/users/{user_id}")
def patch_user(user_id: uuid.UUID, body: UserPatch, viewer: Viewer = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise not_found("user")
    if body.role:
        u.role = body.role
    if body.storage_quota_bytes is not None:
        u.storage_quota_bytes = body.storage_quota_bytes
    audit(db, viewer.id, "admin.user_update", "user", u.id, role=body.role)
    return {"id": str(u.id), "role": u.role}


@router.get("/artists")
def artists(q: str = "", viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    query = select(ArtistProfile)
    if q:
        query = query.where(func.lower(ArtistProfile.name).like(f"%{q.lower()}%"))
    rows = db.scalars(query.order_by(ArtistProfile.created_at.desc()).limit(100)).all()
    s = get_settings()
    return [{**artist_brief(a), "status": a.status, "verification_status": a.verification_status, "verification_method": a.verification_method,
             "storage_used_bytes": artist_storage_used(db, a.id), "storage_quota_bytes": a.storage_quota_bytes or s.default_artist_storage_quota_bytes}
            for a in rows]


class VerifyIn(BaseModel):
    verified: bool
    method: str = Field(min_length=5, max_length=200)  # e.g. "Confirmed via link on official website https://..."


@router.post("/artists/{artist_id}/verification")
def verify_artist(artist_id: uuid.UUID, body: VerifyIn, viewer: Viewer = Depends(require_admin), db: Session = Depends(get_db)):
    """Only an administrator, after a documented check (docs/operators.md#verification), can set this label."""
    a = db.get(ArtistProfile, artist_id)
    if not a:
        raise not_found("artist")
    a.verification_status = "verified" if body.verified else "unverified"
    a.verification_method = clean_line(body.method, 200) if body.verified else None
    a.verified_at = utcnow() if body.verified else None
    a.verified_by = viewer.id if body.verified else None
    audit(db, viewer.id, "admin.verify_artist", "artist", a.id, verified=body.verified, method=body.method)
    cache.invalidate("discover")
    return {**artist_brief(a), "verification_method": a.verification_method}


class QuotaIn(BaseModel):
    storage_quota_bytes: int | None = Field(default=None, ge=0)


@router.put("/artists/{artist_id}/quota")
def set_quota(artist_id: uuid.UUID, body: QuotaIn, viewer: Viewer = Depends(require_admin), db: Session = Depends(get_db)):
    a = db.get(ArtistProfile, artist_id)
    if not a:
        raise not_found("artist")
    a.storage_quota_bytes = body.storage_quota_bytes
    audit(db, viewer.id, "admin.quota", "artist", a.id, quota=body.storage_quota_bytes)
    return {"storage_quota_bytes": a.storage_quota_bytes or get_settings().default_artist_storage_quota_bytes,
            "storage_used_bytes": artist_storage_used(db, a.id)}


@router.get("/jobs")
def jobs(status: str | None = None, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    q = select(Job)
    if status:
        q = q.where(Job.status == status)
    return [{"id": str(j.id), "kind": j.kind, "status": j.status, "attempts": j.attempts, "payload": j.payload, "last_error": j.last_error,
             "created_at": j.created_at.isoformat(), "finished_at": j.finished_at.isoformat() if j.finished_at else None}
            for j in db.scalars(q.order_by(Job.created_at.desc()).limit(100))]


@router.post("/jobs/{job_id}/retry")
def retry_job(job_id: uuid.UUID, viewer: Viewer = Depends(require_admin), db: Session = Depends(get_db)):
    j = db.get(Job, job_id)
    if not j or j.status != "failed":
        raise not_found("job")
    new = enqueue(db, j.kind, j.payload, requested_by=viewer.id)
    return {"id": str(new.id), "status": new.status}


class CollectionIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str | None = None
    curator_note: str | None = None
    release_ids: list[uuid.UUID] = []
    track_ids: list[uuid.UUID] = []
    published: bool = False
    position: int = 0


@router.get("/collections")
def list_collections(viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    return [{"id": str(c.id), "slug": c.slug, "title": c.title, "published": c.published, "release_ids": c.release_ids,
             "track_ids": c.track_ids, "position": c.position} for c in db.scalars(select(EditorialCollection).order_by(EditorialCollection.position))]


@router.post("/collections", status_code=201)
def create_collection(body: CollectionIn, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    slug = slugify(body.title)
    if db.scalar(select(EditorialCollection.id).where(EditorialCollection.slug == slug)):
        slug = f"{slug}-{uuid.uuid4().hex[:4]}"
    c = EditorialCollection(slug=slug, title=clean_line(body.title, 120), description=clean_text(body.description, 2000),
                            curator_note=clean_line(body.curator_note, 300), release_ids=[str(i) for i in body.release_ids],
                            track_ids=[str(i) for i in body.track_ids], published=body.published, position=body.position, created_by=viewer.id)
    db.add(c)
    db.flush()
    cache.invalidate("discover")
    audit(db, viewer.id, "admin.collection_create", "collection", c.id)
    return {"id": str(c.id), "slug": c.slug}


@router.put("/collections/{collection_id}")
def update_collection(collection_id: uuid.UUID, body: CollectionIn, viewer: Viewer = Depends(require_staff), db: Session = Depends(get_db)):
    c = db.get(EditorialCollection, collection_id)
    if not c:
        raise not_found("collection")
    c.title, c.description, c.curator_note = clean_line(body.title, 120), clean_text(body.description, 2000), clean_line(body.curator_note, 300)
    c.release_ids, c.track_ids = [str(i) for i in body.release_ids], [str(i) for i in body.track_ids]
    c.published, c.position = body.published, body.position
    cache.invalidate("discover")
    return {"id": str(c.id), "slug": c.slug}


@router.get("/audit")
def audit_log(limit: int = 200, viewer: Viewer = Depends(require_admin), db: Session = Depends(get_db)):
    rows = db.execute(select(AuditLog, User.username).outerjoin(User, User.id == AuditLog.actor_id).order_by(AuditLog.id.desc()).limit(min(limit, 1000))).all()
    return [{"id": a.id, "actor": name, "action": a.action, "target_type": a.target_type, "target_id": a.target_id, "data": a.data,
             "created_at": a.created_at.isoformat()} for a, name in rows]
