"""Deterministic generator for ORIGINAL demonstration music and artwork.

Every seeded recording is synthesised here from code (additive synthesis, simple
drum models and a seeded random melody), so the demo contains no third-party
audio. The generated audio and artwork are dedicated to the public domain
under CC0 1.0 (see ASSETS-LICENSE.md).
"""
from __future__ import annotations

import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np

SR = 44100
NOTE = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}
SCALES = {"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10], "dorian": [0, 2, 3, 5, 7, 9, 10], "pentatonic": [0, 2, 4, 7, 9]}


@dataclass
class Piece:
    seed: int
    bpm: float
    key: str
    scale: str
    seconds: float
    progression: list[int]  # scale degrees
    drums: bool = True
    pad: float = 0.5
    lead: float = 0.35
    bass: float = 0.45
    swing: float = 0.0
    timbre: str = "warm"  # warm | glass | reed


def _freq(midi: float) -> float:
    return 440.0 * 2 ** ((midi - 69) / 12)


def _env(n: int, a: float, r: float) -> np.ndarray:
    a_n, r_n = max(1, int(a * SR)), max(1, int(r * SR))
    e = np.ones(n)
    e[:a_n] = np.linspace(0, 1, min(a_n, n))
    if r_n < n:
        e[-r_n:] *= np.linspace(1, 0, r_n)
    return e


def _tone(f: float, n: int, timbre: str) -> np.ndarray:
    t = np.arange(n) / SR
    if timbre == "glass":
        return np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * f * 3.01 * t) * np.exp(-t * 3)
    if timbre == "reed":
        return sum((1 / k) * np.sin(2 * np.pi * f * k * t) for k in (1, 3, 5, 7)) * 0.8
    return np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 2 * t) + 0.15 * np.sin(2 * np.pi * f * 3 * t)


def render(p: Piece) -> np.ndarray:
    rng = np.random.default_rng(p.seed)
    total = int(p.seconds * SR)
    out = np.zeros((total, 2))
    beat = 60 / p.bpm
    bar = beat * 4
    root = 48 + NOTE[p.key]
    scale = SCALES[p.scale]

    def degree(d: int, octave: int = 0) -> int:
        return root + 12 * (octave + d // len(scale)) + scale[d % len(scale)]

    def add(sig: np.ndarray, start: float, pan: float = 0.0):
        s = int(start * SR)
        if s >= total:
            return
        sig = sig[: total - s]
        out[s:s + len(sig), 0] += sig * (1 - pan) * 0.5
        out[s:s + len(sig), 1] += sig * (1 + pan) * 0.5

    n_bars = int(p.seconds / bar) + 1
    for b in range(n_bars):
        deg = p.progression[b % len(p.progression)]
        start = b * bar
        # Pad chord
        n = int(bar * SR)
        chord = sum(_tone(_freq(degree(deg + i, 1)), n, p.timbre) for i in (0, 2, 4)) / 3
        add(chord * _env(n, 0.4, 0.6) * p.pad * 0.5, start, pan=-0.2)
        # Bass on beats 1 and 3
        for k in (0, 2):
            bn = int(beat * 1.5 * SR)
            f = _freq(degree(deg) - 12)
            t = np.arange(bn) / SR
            bass = np.sin(2 * np.pi * f * t) * _env(bn, 0.01, 0.3)
            add(bass * p.bass, start + k * beat)
        # Lead melody: seeded random walk on the scale, eighth notes with rests
        pos = deg + 7
        for e in range(8):
            if rng.random() < 0.35:
                continue
            pos = int(np.clip(pos + rng.choice([-2, -1, 0, 1, 2]), deg + 4, deg + 14))
            ln = int(beat / 2 * SR * (1.6 if rng.random() < 0.3 else 0.95))
            sw = p.swing * beat / 2 if e % 2 else 0
            add(_tone(_freq(degree(pos, 1)), ln, "glass" if p.timbre == "warm" else "warm") * _env(ln, 0.01, 0.12) * p.lead * 0.6,
                start + e * beat / 2 + sw, pan=0.3)
        if p.drums:
            for k in range(4):
                kn = int(0.35 * SR)
                t = np.arange(kn) / SR
                kick = np.sin(2 * np.pi * (50 + 90 * np.exp(-t * 30)) * t) * np.exp(-t * 9)
                if k in (0, 2) or rng.random() < 0.15:
                    add(kick * 0.9, start + k * beat)
                if k in (1, 3):
                    sn = int(0.2 * SR)
                    snare = rng.standard_normal(sn) * np.exp(-np.arange(sn) / SR * 25) * 0.25
                    add(snare, start + k * beat)
                for h in (0, 0.5):
                    hn = int(0.05 * SR)
                    hat = np.diff(rng.standard_normal(hn + 1)) * np.exp(-np.arange(hn) / SR * 80) * 0.08
                    add(hat, start + (k + h) * beat + (p.swing * beat / 2 if h else 0), pan=0.4)
    fade = int(2.5 * SR)
    out[:int(0.5 * SR)] *= np.linspace(0, 1, int(0.5 * SR))[:, None]
    out[-fade:] *= np.linspace(1, 0, fade)[:, None]
    peak = np.abs(out).max() or 1
    return out / peak * 0.89


def write_wav(path: Path, data: np.ndarray, bits: int = 16) -> None:
    pcm = (np.clip(data, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def artwork(path: Path, seed: int, palette: list[tuple[int, int, int]], size: tuple[int, int] = (1400, 1400), title: str | None = None) -> None:
    from PIL import Image, ImageDraw, ImageFilter

    rng = np.random.default_rng(seed)
    w, h = size
    img = Image.new("RGB", size, palette[0])
    d = ImageDraw.Draw(img)
    for i in range(h):
        a = i / h
        c = tuple(int(palette[0][k] * (1 - a) + palette[1][k] * a) for k in range(3))
        d.line([(0, i), (w, i)], fill=c)
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    for _ in range(7):
        r = int(rng.integers(w // 10, w // 2))
        x, y = int(rng.integers(0, w)), int(rng.integers(0, h))
        col = palette[int(rng.integers(2, len(palette)))]
        ld.ellipse([x - r, y - r, x + r, y + r], fill=(*col, int(rng.integers(70, 170))))
    layer = layer.filter(ImageFilter.GaussianBlur(w // 40))
    img = Image.alpha_composite(img.convert("RGBA"), layer)
    ld = ImageDraw.Draw(img)
    # Waveform motif
    mid = int(h * 0.72)
    pts = [(x, mid + int(np.sin(x / w * np.pi * rng.integers(3, 9)) * h * 0.05 * np.sin(x / w * np.pi))) for x in range(0, w, 6)]
    ld.line(pts, fill=(255, 244, 232, 210), width=max(3, w // 300))
    img.convert("RGB").save(path, "PNG")
