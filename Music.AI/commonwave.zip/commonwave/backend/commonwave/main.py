"""COMMONWAVE API — FastAPI application factory (modular monolith)."""
from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy import text
from starlette.exceptions import HTTPException as StarletteHTTPException

from commonwave import __version__
from commonwave.config import get_settings
from commonwave.core.db import get_engine
from commonwave.core.logging import configure_logging
from commonwave.core.storage import get_storage
from commonwave.modules.admin.router import router as admin_router
from commonwave.modules.analytics.router import router as analytics_router
from commonwave.modules.catalogue.router import router as catalogue_router
from commonwave.modules.community.router import router as community_router
from commonwave.modules.discovery.router import router as discovery_router
from commonwave.modules.exports.router import media as export_media
from commonwave.modules.exports.router import router as exports_router
from commonwave.modules.federation import node_info
from commonwave.modules.identity.router import router as identity_router
from commonwave.modules.moderation.router import router as moderation_router
from commonwave.modules.playback.router import media as playback_media
from commonwave.modules.playback.router import router as playback_router
from commonwave.modules.support.router import router as support_router
from commonwave.modules.uploads.router import router as uploads_router

log = logging.getLogger("commonwave")

DESCRIPTION = """
Open-source music commons API. Public catalogue reads and streaming need no account.

* Cookie sessions; unsafe requests must send `X-CSRF-Token` (from `GET /api/v1/auth/me`).
* Uploads use the tus 1.0.0 resumable protocol at `/api/v1/uploads`.
* Media is served from `/media/*` using short-lived HMAC-signed URLs with HTTP Range support.
* Errors: `{"error": {"code": "...", "message": "..."}}`.
"""


def create_app() -> FastAPI:
    s = get_settings()
    configure_logging("WARNING" if s.environment == "test" else "INFO")
    app = FastAPI(title="COMMONWAVE API", version=__version__, description=DESCRIPTION,
                  openapi_url="/api/openapi.json", docs_url="/api/docs", redoc_url="/api/redoc",
                  license_info={"name": "AGPL-3.0-or-later", "identifier": "AGPL-3.0-or-later"})

    @app.exception_handler(StarletteHTTPException)
    async def http_error(_: Request, exc: StarletteHTTPException):
        detail = exc.detail if isinstance(exc.detail, dict) else {"code": "http_error", "message": str(exc.detail)}
        return JSONResponse({"error": detail}, status_code=exc.status_code, headers=getattr(exc, "headers", None))

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, exc: RequestValidationError):
        fields = [{"field": ".".join(str(p) for p in e["loc"][1:]), "message": e["msg"]} for e in exc.errors()]
        msg = fields[0]["message"] if fields else "Invalid request"
        return JSONResponse({"error": {"code": "validation_error", "message": msg, "fields": fields}}, status_code=422)

    @app.exception_handler(Exception)
    async def unhandled(_: Request, exc: Exception):
        log.exception("Unhandled error: %s", type(exc).__name__)
        return JSONResponse({"error": {"code": "internal_error", "message": "Something went wrong on our side."}}, status_code=500)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("X-Frame-Options", "DENY")
        if request.url.path.startswith("/api/") and "Cache-Control" not in response.headers:
            response.headers["Cache-Control"] = "no-store"
        return response

    api = "/api/v1"
    for r in (identity_router, catalogue_router, uploads_router, playback_router, community_router, discovery_router,
              moderation_router, admin_router, support_router, analytics_router, exports_router):
        app.include_router(r, prefix=api)
    app.include_router(playback_media)
    app.include_router(export_media)

    @app.get("/healthz", tags=["ops"])
    def healthz():
        with get_engine().connect() as c:
            c.execute(text("SELECT 1"))
        return {"ok": True, "version": __version__}

    @app.get("/.well-known/commonwave", tags=["ops"])
    def well_known():
        return node_info(__version__, s.site_name)

    @app.on_event("startup")
    def _startup():  # pragma: no cover - exercised by running server
        get_storage().ensure_ready()
        s.upload_staging_dir.mkdir(parents=True, exist_ok=True)

    return app


app = create_app()
