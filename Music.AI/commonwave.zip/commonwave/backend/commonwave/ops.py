"""Operator commands: backup, restore, integrity verification and OpenAPI export.

    python -m commonwave.ops backup  /backups/2026-11-27      # pg_dump + every stored object
    python -m commonwave.ops restore /backups/2026-11-27      # into an EMPTY database + bucket
    python -m commonwave.ops verify                           # every referenced object exists, hashes match
    python -m commonwave.ops openapi docs/openapi.json

The database is the source of truth for which objects exist, so storage backup
works identically for local disk and any S3-compatible service.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlparse

from sqlalchemy import text

from commonwave.config import get_settings
from commonwave.core.db import get_engine
from commonwave.core.storage import get_storage

KEY_QUERY = """
SELECT storage_key AS key, sha256 FROM audio_assets WHERE deleted_at IS NULL
UNION ALL SELECT key_large, NULL FROM artworks
UNION ALL SELECT key_small, NULL FROM artworks
"""


def _pg_env() -> tuple[list[str], dict]:
    u = urlparse(get_settings().database_url.replace("+psycopg", ""))
    env = {**os.environ, "PGPASSWORD": u.password or ""}
    args = ["-h", u.hostname or "localhost", "-p", str(u.port or 5432), "-U", u.username or "postgres", "-d", u.path.lstrip("/")]
    return args, env


def referenced_objects() -> list[tuple[str, str | None]]:
    with get_engine().connect() as c:
        return [(r[0], r[1]) for r in c.execute(text(KEY_QUERY))]


def backup(dest: Path) -> dict:
    dest.mkdir(parents=True, exist_ok=False)
    args, env = _pg_env()
    subprocess.run(["pg_dump", "-Fc", "--no-owner", "-f", str(dest / "db.dump"), *args], check=True, env=env)
    objdir = dest / "objects"
    storage = get_storage()
    manifest = []
    with tempfile.TemporaryDirectory() as td:
        for key, sha in referenced_objects():
            if not storage.stat(key):
                manifest.append({"key": key, "missing": True})
                continue
            target = objdir / key
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = Path(td) / "obj"
            storage.get_to_path(key, tmp)
            shutil.move(str(tmp), target)
            manifest.append({"key": key, "size": target.stat().st_size, "sha256": _sha(target)})
    (dest / "manifest.json").write_text(json.dumps({"format": "commonwave-backup", "version": 1, "objects": manifest}, indent=1))
    return {"objects": len(manifest), "missing": sum(1 for m in manifest if m.get("missing"))}


def restore(src: Path) -> dict:
    manifest = json.loads((src / "manifest.json").read_text())
    args, env = _pg_env()
    subprocess.run(["pg_restore", "--no-owner", "--exit-on-error", *args, str(src / "db.dump")], check=True, env=env)
    storage = get_storage()
    storage.ensure_ready()
    restored = 0
    for m in manifest["objects"]:
        if m.get("missing"):
            continue
        p = src / "objects" / m["key"]
        if _sha(p) != m["sha256"]:
            raise RuntimeError(f"Backup object corrupted: {m['key']}")
        storage.put_file(m["key"], p, "application/octet-stream")
        restored += 1
    return {"objects_restored": restored}


def verify() -> dict:
    storage = get_storage()
    problems = []
    checked = 0
    with tempfile.TemporaryDirectory() as td:
        for key, sha in referenced_objects():
            checked += 1
            if not storage.stat(key):
                problems.append({"key": key, "problem": "missing"})
                continue
            if sha:
                p = Path(td) / "obj"
                storage.get_to_path(key, p)
                if _sha(p) != sha:
                    problems.append({"key": key, "problem": "checksum mismatch"})
    return {"checked": checked, "problems": problems}


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(prog="python -m commonwave.ops")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("backup").add_argument("dest", type=Path)
    sub.add_parser("restore").add_argument("src", type=Path)
    sub.add_parser("verify")
    sub.add_parser("openapi").add_argument("out", type=Path)
    a = ap.parse_args()
    if a.cmd == "backup":
        print(json.dumps(backup(a.dest)))
    elif a.cmd == "restore":
        print(json.dumps(restore(a.src)))
    elif a.cmd == "verify":
        r = verify()
        print(json.dumps(r, indent=1))
        sys.exit(1 if r["problems"] else 0)
    elif a.cmd == "openapi":
        from commonwave.main import app
        a.out.write_text(json.dumps(app.openapi(), indent=1))
        print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
