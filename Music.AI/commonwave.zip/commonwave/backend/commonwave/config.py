"""Runtime configuration.

All settings come from environment variables prefixed ``CW_`` (see
``deploy/env.example``). Secrets are never logged; ``Settings.redacted()``
returns a printable view.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CW_", env_file=".env", extra="ignore")

    environment: Literal["development", "test", "production"] = "development"
    site_name: str = "COMMONWAVE"
    public_base_url: str = "http://localhost:3000"

    database_url: str = "postgresql+psycopg://commonwave:commonwave@localhost:5432/commonwave"
    redis_url: str | None = "redis://localhost:6379/0"

    # Secret used for HMAC-signing media URLs and webhook simulation. MUST be
    # overridden in production (startup refuses the default there).
    secret_key: SecretStr = SecretStr("dev-insecure-change-me-dev-insecure-change-me")
    session_cookie_name: str = "cw_session"
    session_ttl_hours: int = 24 * 14
    cookie_secure: bool = False

    # Object storage
    storage_backend: Literal["local", "s3"] = "local"
    storage_local_root: Path = Path("./var/storage")
    s3_endpoint_url: str | None = None
    s3_region: str = "us-east-1"
    s3_access_key_id: SecretStr | None = None
    s3_secret_access_key: SecretStr | None = None
    s3_bucket: str = "commonwave-media"  # private bucket; no public ACLs are ever set

    # Uploads
    upload_staging_dir: Path = Path("./var/staging")
    max_upload_bytes: int = 500 * 1024 * 1024
    max_track_duration_seconds: int = 30 * 60
    upload_expiry_hours: int = 24
    max_active_uploads_per_user: int = 5
    default_artist_storage_quota_bytes: int = 5 * 1024 * 1024 * 1024
    max_artwork_bytes: int = 10 * 1024 * 1024

    # Processing (FFmpeg adapter)
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    processing_timeout_seconds: int = 600
    processing_cpu_seconds: int = 900
    processing_memory_bytes: int = 1024 * 1024 * 1024
    processing_max_output_bytes: int = 1024 * 1024 * 1024
    processing_work_dir: Path = Path("./var/work")
    stream_bitrate_kbps: int = 192
    loudness_target_lufs: float = -14.0
    hls_enabled: bool = False  # deferred: progressive MP3 is the supported path
    # "auto": run FFmpeg inside a fresh network namespace (unshare -n) when the
    # kernel allows it; "off": rely on protocol whitelisting + container network policy.
    processing_network_isolation: Literal["auto", "required", "off"] = "auto"

    # Media URL signing
    stream_url_ttl_seconds: int = 15 * 60
    download_url_ttl_seconds: int = 10 * 60

    # Analytics
    qualified_listen_seconds: int = 30
    qualified_listen_fraction_short: float = 0.5

    # Rate limits (requests per window)
    rate_limit_enabled: bool = True

    # Support / payments
    support_enabled: bool = True
    payment_provider: Literal["simulated"] = "simulated"
    platform_fee_bps: int = 0  # basis points taken by the operator, explicit
    simulated_provider_fee_bps: int = 290
    simulated_provider_fixed_fee_minor: int = 30

    bootstrap_admin_email: str | None = None

    worker_poll_seconds: float = Field(default=2.0, ge=0.1)

    def redacted(self) -> dict:
        data = self.model_dump()
        for k in ("secret_key", "s3_access_key_id", "s3_secret_access_key"):
            data[k] = "***" if data.get(k) else None
        if "@" in data["database_url"]:
            data["database_url"] = data["database_url"].split("@")[-1]
        return data


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    if s.environment == "production":
        if "dev-insecure" in s.secret_key.get_secret_value() or len(s.secret_key.get_secret_value()) < 32:
            raise RuntimeError("CW_SECRET_KEY must be set to a random value of at least 32 characters in production")
        if not s.cookie_secure:
            raise RuntimeError("CW_COOKIE_SECURE must be true in production")
    return s
