"""Logging with redaction of credentials, cookies, signatures and e-mail addresses."""
from __future__ import annotations

import logging
import re

_PATTERNS = [
    (re.compile(r"(sig=)[A-Za-z0-9_\-]+"), r"\1[redacted]"),
    (re.compile(r"(token=)[A-Za-z0-9_\-]+"), r"\1[redacted]"),
    (re.compile(r"(?i)(cookie:\s*)[^\n]+"), r"\1[redacted]"),
    (re.compile(r"(?i)(authorization:\s*)[^\n]+"), r"\1[redacted]"),
    (re.compile(r"(?i)(password[\"']?\s*[:=]\s*)[^\s,}]+"), r"\1[redacted]"),
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "[email]"),
    (re.compile(r"(postgres(?:ql)?(?:\+psycopg)?://)[^@\s]+@"), r"\1[redacted]@"),
]


def redact(text: str) -> str:
    for pat, repl in _PATTERNS:
        text = pat.sub(repl, text)
    return text


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        record.msg = redact(msg)
        record.args = ()
        return True


def configure_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    handler.addFilter(RedactingFilter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level)
    for name in ("uvicorn.access", "uvicorn.error"):
        lg = logging.getLogger(name)
        lg.handlers = [handler]
        lg.propagate = False
