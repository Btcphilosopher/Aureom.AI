from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from commonwave.models import AuditLog


def audit(db: Session, actor_id: uuid.UUID | None, action: str, target_type: str | None = None,
          target_id: object | None = None, ip_hash: str | None = None, **data) -> None:
    safe = {k: (str(v) if isinstance(v, uuid.UUID) else v) for k, v in data.items()
            if k not in ("password", "token", "secret", "sig")}
    db.add(AuditLog(actor_id=actor_id, action=action, target_type=target_type,
                    target_id=str(target_id) if target_id is not None else None, data=safe, ip_hash=ip_hash))
