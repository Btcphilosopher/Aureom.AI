"""Operator-configurable community features (stored in site_config, editable in /admin)."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from commonwave.models import SiteConfig

DEFAULTS: dict[str, object] = {
    "registration_open": True,
    "comments_enabled": True,
    "timestamped_comments_enabled": True,
    "comment_premoderation": False,       # hold new comments for review
    "new_account_comment_hold_hours": 0,  # hold comments from accounts younger than N hours
    "reports_enabled": True,
    "public_playlists_enabled": True,
    "support_module_enabled": True,
    "downloads_enabled": True,
    "max_comment_length": 2000,
    "comment_link_limit": 2,
}


def get_config(db: Session) -> dict:
    rows = {r.key: r.value for r in db.scalars(select(SiteConfig))}
    return {k: rows.get(k, v) for k, v in DEFAULTS.items()}


def set_config(db: Session, updates: dict, actor_id) -> dict:
    for k, v in updates.items():
        if k not in DEFAULTS:
            continue
        if type(v) is not type(DEFAULTS[k]):
            raise ValueError(f"{k} must be {type(DEFAULTS[k]).__name__}")
        row = db.get(SiteConfig, k)
        if row:
            row.value = v
            row.updated_by = actor_id
        else:
            db.add(SiteConfig(key=k, value=v, updated_by=actor_id))
    db.flush()
    return get_config(db)
