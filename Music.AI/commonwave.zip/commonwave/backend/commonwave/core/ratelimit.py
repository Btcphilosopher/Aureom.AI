"""Fixed-window rate limiting. Uses Redis when configured and reachable,
otherwise a bounded in-process dictionary (adequate for single-process demos)."""
from __future__ import annotations

import logging
import threading
import time
from collections import OrderedDict

from fastapi import Request

from commonwave.config import get_settings
from commonwave.core.errors import ApiError

log = logging.getLogger(__name__)

# name -> (limit, window seconds)
LIMITS: dict[str, tuple[int, int]] = {
    "register": (10, 3600),
    "login": (20, 600),
    "upload_create": (30, 3600),
    "upload_chunk": (2000, 3600),
    "comment": (20, 600),
    "report": (20, 3600),
    "playback_session": (300, 600),
    "playback_events": (2000, 600),
    "download": (120, 3600),
    "playlist_write": (300, 600),
    "follow": (200, 3600),
    "tip": (30, 3600),
    "artwork": (60, 3600),
}

_redis_client = None
_redis_checked = False
_lock = threading.Lock()
_memory: OrderedDict[str, tuple[int, float]] = OrderedDict()
_MEMORY_MAX = 50_000


def _redis():
    global _redis_client, _redis_checked
    if _redis_checked:
        return _redis_client
    _redis_checked = True
    url = get_settings().redis_url
    if not url:
        return None
    try:
        import redis

        c = redis.Redis.from_url(url, socket_timeout=0.5, socket_connect_timeout=0.5)
        c.ping()
        _redis_client = c
    except Exception as e:  # pragma: no cover - environment dependent
        log.warning("Redis unavailable for rate limiting, using in-memory fallback: %s", type(e).__name__)
        _redis_client = None
    return _redis_client


def reset_memory() -> None:
    with _lock:
        _memory.clear()


def hit(name: str, key: str) -> tuple[bool, int]:
    limit, window = LIMITS[name]
    bucket = int(time.time() // window)
    rkey = f"cw:rl:{name}:{key}:{bucket}"
    r = _redis()
    if r is not None:
        try:
            pipe = r.pipeline()
            pipe.incr(rkey)
            pipe.expire(rkey, window + 5)
            count = int(pipe.execute()[0])
            return count <= limit, window - int(time.time() % window)
        except Exception:
            pass
    with _lock:
        count, _ = _memory.get(rkey, (0, 0.0))
        count += 1
        _memory[rkey] = (count, time.time())
        _memory.move_to_end(rkey)
        while len(_memory) > _MEMORY_MAX:
            _memory.popitem(last=False)
    return count <= limit, window - int(time.time() % window)


def client_ip(request: Request) -> str:
    # Behind a trusted reverse proxy the operator sets --forwarded-allow-ips on uvicorn,
    # which rewrites request.client; we do not parse X-Forwarded-For ourselves.
    return request.client.host if request.client else "unknown"


def enforce(name: str, request: Request, user_id: str | None = None) -> None:
    if not get_settings().rate_limit_enabled:
        return
    key = f"u{user_id}" if user_id else f"ip{client_ip(request)}"
    ok, retry = hit(name, key)
    if not ok:
        raise ApiError(429, "rate_limited", "Too many requests. Please slow down.", headers={"Retry-After": str(retry)})
