"""Request-scoped dependencies: database session, current user, CSRF and permissions."""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import timedelta

from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from commonwave.config import get_settings
from commonwave.core.db import get_db, utcnow
from commonwave.core.errors import ApiError, forbidden, not_found, unauthorized
from commonwave.core.security import token_digest
from commonwave.models import ArtistMembership, ArtistProfile, AuthSession, User

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}

# Permission matrix for artist management.
ARTIST_PERMS: dict[str, set[str]] = {
    "owner": {"view", "upload", "edit", "publish", "withdraw", "manage_members", "manage_profile", "export", "stats", "support"},
    "manager": {"view", "upload", "edit", "publish", "withdraw", "manage_profile", "export", "stats", "support"},
    "contributor": {"view", "upload", "edit"},
}


@dataclass
class Viewer:
    user: User | None
    session: AuthSession | None

    @property
    def id(self) -> uuid.UUID | None:
        return self.user.id if self.user else None

    @property
    def is_staff(self) -> bool:
        return bool(self.user and self.user.role in ("moderator", "admin"))

    @property
    def is_admin(self) -> bool:
        return bool(self.user and self.user.role == "admin")


def _load_session(request: Request, db: Session) -> AuthSession | None:
    token = request.cookies.get(get_settings().session_cookie_name)
    if not token:
        return None
    sess = db.get(AuthSession, token_digest(token))
    if not sess or sess.expires_at < utcnow():
        return None
    now = utcnow()
    if not sess.last_seen_at or now - sess.last_seen_at > timedelta(minutes=5):
        sess.last_seen_at = now
    return sess


def get_viewer(request: Request, db: Session = Depends(get_db)) -> Viewer:
    sess = _load_session(request, db)
    user = sess.user if sess else None
    if user and user.status == "suspended":
        user, sess = None, None
    if sess and request.method in UNSAFE:
        # Double-submit CSRF protection for cookie-authenticated unsafe requests.
        header = request.headers.get("x-csrf-token")
        if not header or header != sess.csrf_token:
            raise ApiError(403, "csrf_failed", "Missing or invalid CSRF token. Reload the page and try again.")
    return Viewer(user=user, session=sess)


def require_user(viewer: Viewer = Depends(get_viewer)) -> Viewer:
    if not viewer.user:
        raise unauthorized()
    return viewer


def require_active_user(viewer: Viewer = Depends(require_user)) -> Viewer:
    u = viewer.user
    if u.status == "restricted" and (u.restricted_until is None or u.restricted_until > utcnow()):
        raise ApiError(403, "account_restricted", "Your account is temporarily restricted from posting. You can appeal from Settings.")
    return viewer


def require_staff(viewer: Viewer = Depends(require_user)) -> Viewer:
    if not viewer.is_staff:
        raise forbidden()
    return viewer


def require_admin(viewer: Viewer = Depends(require_user)) -> Viewer:
    if not viewer.is_admin:
        raise forbidden()
    return viewer


def membership_role(db: Session, artist_id: uuid.UUID, user_id: uuid.UUID | None) -> str | None:
    if not user_id:
        return None
    return db.scalar(select(ArtistMembership.role).where(ArtistMembership.artist_id == artist_id, ArtistMembership.user_id == user_id))


def can(db: Session, viewer: Viewer, artist_id: uuid.UUID, perm: str) -> bool:
    role = membership_role(db, artist_id, viewer.id)
    return bool(role and perm in ARTIST_PERMS[role])


def require_artist_perm(db: Session, viewer: Viewer, artist_id: uuid.UUID, perm: str, *, hide: bool = True) -> ArtistProfile:
    artist = db.get(ArtistProfile, artist_id)
    if not artist:
        raise not_found("artist")
    role = membership_role(db, artist_id, viewer.id)
    if not role:
        raise not_found("artist") if hide else forbidden()
    if perm not in ARTIST_PERMS[role]:
        raise forbidden(f"Your role ({role}) cannot {perm.replace('_', ' ')} for this artist.")
    if artist.status == "suspended" and perm not in ("view", "export", "stats"):
        raise ApiError(403, "artist_suspended", "This artist profile is suspended. You can still export your data or appeal.")
    return artist
