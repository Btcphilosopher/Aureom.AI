"""Text sanitisation for user-supplied descriptions, comments, lyrics and metadata.

COMMONWAVE stores user text as *plain text*. Any HTML is stripped (not escaped
into the database), control characters are removed, Unicode is NFC-normalised
and lengths are bounded. The web client renders text through React, which
escapes on output, so this is defence in depth rather than the only layer.
"""
from __future__ import annotations

import re
import unicodedata
from urllib.parse import urlparse

import nh3

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f​-‏‪-‮⁦-⁩]")
_MULTI_NL = re.compile(r"\n{4,}")
_SLUG = re.compile(r"[^a-z0-9]+")


def clean_text(value: str | None, max_len: int, *, multiline: bool = True) -> str | None:
    if value is None:
        return None
    v = unicodedata.normalize("NFC", str(value))
    v = v.replace("\r\n", "\n").replace("\r", "\n")
    v = _CONTROL.sub("", v)
    # Strip every tag; keep text content. nh3 escapes stray < > & which we undo
    # because we store plain text and the client escapes on render.
    v = nh3.clean(v, tags=set(), attributes={}, strip_comments=True)
    v = v.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    if not multiline:
        v = " ".join(v.split())
    else:
        v = _MULTI_NL.sub("\n\n\n", v)
    v = v.strip()
    return v[:max_len]


def clean_line(value: str | None, max_len: int = 200) -> str | None:
    return clean_text(value, max_len, multiline=False)


def clean_tags(tags: list[str] | None, max_tags: int = 12) -> list[str]:
    out: list[str] = []
    for t in tags or []:
        c = clean_line(t, 32)
        if not c:
            continue
        c = c.lower().lstrip("#")
        if c and c not in out:
            out.append(c)
    return out[:max_tags]


def clean_url(value: str | None) -> str | None:
    if not value:
        return None
    v = value.strip()
    p = urlparse(v)
    if p.scheme not in ("http", "https") or not p.netloc or len(v) > 500:
        raise ValueError("Links must be http(s) URLs of at most 500 characters")
    return v


def slugify(value: str, max_len: int = 60) -> str:
    v = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    v = _SLUG.sub("-", v).strip("-")
    return v[:max_len] or "untitled"


def safe_filename(name: str, max_len: int = 120) -> str:
    base = name.replace("\\", "/").split("/")[-1]
    base = unicodedata.normalize("NFKD", base).encode("ascii", "ignore").decode()
    base = re.sub(r"[^A-Za-z0-9._ -]+", "_", base).strip(" .")
    return (base or "upload")[:max_len]
