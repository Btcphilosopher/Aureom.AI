"""Uniform API errors: {"error": {"code": ..., "message": ...}}."""
from __future__ import annotations

from fastapi import HTTPException


class ApiError(HTTPException):
    def __init__(self, status: int, code: str, message: str, headers: dict | None = None, extra: dict | None = None):
        super().__init__(status_code=status, detail={"code": code, "message": message, **(extra or {})}, headers=headers)
        self.code = code


def not_found(what: str = "resource") -> ApiError:
    # Deliberately identical for "does not exist" and "exists but you may not see it"
    # so private objects are not enumerable.
    return ApiError(404, "not_found", f"The requested {what} was not found.")


def forbidden(message: str = "You do not have permission to do that.") -> ApiError:
    return ApiError(403, "forbidden", message)


def bad_request(code: str, message: str, **extra) -> ApiError:
    return ApiError(400, code, message, extra=extra or None)


def conflict(code: str, message: str) -> ApiError:
    return ApiError(409, code, message)


def unauthorized() -> ApiError:
    return ApiError(401, "authentication_required", "Sign in to do that.")
