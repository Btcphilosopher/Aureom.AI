"""Password hashing, session tokens and HMAC-signed media URLs."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError

from commonwave.config import get_settings

_ph = PasswordHasher()  # argon2id with library defaults (RFC 9106 recommendations)


def hash_password(password: str) -> str:
    return _ph.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return _ph.verify(password_hash, password)
    except (VerificationError, InvalidHashError):
        return False


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_digest(token: str) -> str:
    """Sessions are stored by SHA-256 digest so a database leak does not leak live cookies."""
    return hashlib.sha256(token.encode()).hexdigest()


def _key(purpose: str) -> bytes:
    secret = get_settings().secret_key.get_secret_value().encode()
    return hmac.new(secret, purpose.encode(), hashlib.sha256).digest()


def sign(purpose: str, message: str) -> str:
    mac = hmac.new(_key(purpose), message.encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(mac[:24]).decode().rstrip("=")


def verify_sig(purpose: str, message: str, sig: str) -> bool:
    return hmac.compare_digest(sign(purpose, message), sig or "")


def signed_media_params(purpose: str, asset_id: str, ttl_seconds: int, scope: str = "") -> dict[str, str]:
    exp = int(time.time()) + ttl_seconds
    sig = sign(purpose, f"{asset_id}:{exp}:{scope}")
    out = {"exp": str(exp), "sig": sig}
    if scope:
        out["scope"] = scope
    return out


def check_media_signature(purpose: str, asset_id: str, exp: str | None, sig: str | None, scope: str = "") -> str:
    """Return 'ok', 'expired' or 'invalid'. Signature is checked before expiry so
    that forged URLs are never told whether they are merely 'expired'."""
    if not exp or not sig or not exp.isdigit():
        return "invalid"
    if not verify_sig(purpose, f"{asset_id}:{exp}:{scope}", sig):
        return "invalid"
    if int(exp) < int(time.time()):
        return "expired"
    return "ok"


def listener_key(user_id: str | None, ip: str | None, user_agent: str | None) -> str:
    """Pseudonymous key for de-duplicating anonymous playback without storing IPs.
    Rotates daily, so it cannot be used to build long-term profiles."""
    if user_id:
        return "u:" + hashlib.sha256(f"user:{user_id}".encode()).hexdigest()[:32]
    day = time.strftime("%Y-%m-%d", time.gmtime())
    raw = f"{day}|{ip or ''}|{(user_agent or '')[:200]}"
    return "a:" + hmac.new(_key("listener-key"), raw.encode(), hashlib.sha256).hexdigest()[:32]


def ip_hash(ip: str | None) -> str | None:
    if not ip:
        return None
    return hmac.new(_key("ip-hash"), ip.encode(), hashlib.sha256).hexdigest()[:24]
