"""Small bounded cache for public discovery responses (Redis or in-process LRU)."""
from __future__ import annotations

import json
import threading
import time
from collections import OrderedDict
from typing import Any, Callable

from commonwave.core.ratelimit import _redis

_lock = threading.Lock()
_mem: OrderedDict[str, tuple[float, str]] = OrderedDict()
_MAX = 512


def cached(key: str, ttl: int, producer: Callable[[], Any]) -> Any:
    full = f"cw:cache:{key}"
    r = _redis()
    if r is not None:
        try:
            raw = r.get(full)
            if raw:
                return json.loads(raw)
        except Exception:
            r = None
    else:
        with _lock:
            item = _mem.get(full)
            if item and item[0] > time.time():
                return json.loads(item[1])
    value = producer()
    raw = json.dumps(value, default=str)
    if r is not None:
        try:
            r.setex(full, ttl, raw)
        except Exception:
            pass
    else:
        with _lock:
            _mem[full] = (time.time() + ttl, raw)
            _mem.move_to_end(full)
            while len(_mem) > _MAX:
                _mem.popitem(last=False)
    return json.loads(raw)


def invalidate(prefix: str = "") -> None:
    full = f"cw:cache:{prefix}"
    r = _redis()
    if r is not None:
        try:
            for k in r.scan_iter(match=full + "*", count=200):
                r.delete(k)
        except Exception:
            pass
    with _lock:
        for k in [k for k in _mem if k.startswith(full)]:
            _mem.pop(k, None)
