"""Object storage adapter.

Two backends share one interface:

* ``LocalStorage`` — a directory on disk (single-node / development).
* ``S3Storage``    — any S3-compatible service (SeaweedFS, Garage, Ceph RGW, AWS S3...).

Every object is private. Nothing is ever served directly from storage paths:
the API authorises each request and streams bytes (with HTTP Range support), so a
private original can never be fetched by guessing a key or bucket URL.
"""
from __future__ import annotations

import os
import shutil
from collections.abc import Iterator
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from commonwave.config import get_settings

CHUNK = 64 * 1024


@dataclass
class ObjectInfo:
    size: int
    content_type: str | None = None


class Storage:
    def put_file(self, key: str, src: Path, content_type: str) -> int: ...
    def get_to_path(self, key: str, dest: Path) -> None: ...
    def stat(self, key: str) -> ObjectInfo | None: ...
    def iter_range(self, key: str, start: int, end: int) -> Iterator[bytes]: ...
    def delete(self, key: str) -> None: ...
    def ensure_ready(self) -> None: ...


def _safe_key(key: str) -> str:
    parts = [p for p in key.split("/") if p]
    if not parts or any(p in (".", "..") or p.startswith(".") for p in parts):
        raise ValueError("invalid storage key")
    return "/".join(parts)


class LocalStorage(Storage):
    def __init__(self, root: Path):
        self.root = root.resolve()

    def _path(self, key: str) -> Path:
        p = (self.root / _safe_key(key)).resolve()
        if self.root not in p.parents:
            raise ValueError("invalid storage key")
        return p

    def ensure_ready(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        os.chmod(self.root, 0o700)

    def put_file(self, key: str, src: Path, content_type: str) -> int:
        dest = self._path(key)
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(dest.suffix + ".part")
        shutil.copyfile(src, tmp)
        os.chmod(tmp, 0o600)
        tmp.replace(dest)
        return dest.stat().st_size

    def get_to_path(self, key: str, dest: Path) -> None:
        shutil.copyfile(self._path(key), dest)

    def stat(self, key: str) -> ObjectInfo | None:
        try:
            p = self._path(key)
        except ValueError:
            return None
        if not p.is_file():
            return None
        return ObjectInfo(size=p.stat().st_size)

    def iter_range(self, key: str, start: int, end: int) -> Iterator[bytes]:
        with open(self._path(key), "rb") as f:
            f.seek(start)
            remaining = end - start + 1
            while remaining > 0:
                data = f.read(min(CHUNK, remaining))
                if not data:
                    break
                remaining -= len(data)
                yield data

    def delete(self, key: str) -> None:
        try:
            self._path(key).unlink(missing_ok=True)
        except ValueError:
            pass


class S3Storage(Storage):
    def __init__(self):
        import boto3
        from botocore.config import Config

        s = get_settings()
        self.bucket = s.s3_bucket
        self.client = boto3.client(
            "s3",
            endpoint_url=s.s3_endpoint_url,
            region_name=s.s3_region,
            aws_access_key_id=s.s3_access_key_id.get_secret_value() if s.s3_access_key_id else None,
            aws_secret_access_key=s.s3_secret_access_key.get_secret_value() if s.s3_secret_access_key else None,
            config=Config(signature_version="s3v4", retries={"max_attempts": 3}, s3={"addressing_style": "path"}),
        )

    def ensure_ready(self) -> None:
        from botocore.exceptions import ClientError

        try:
            self.client.head_bucket(Bucket=self.bucket)
        except ClientError:
            self.client.create_bucket(Bucket=self.bucket)
        # Defence in depth: block public access where the service supports it.
        try:
            self.client.put_public_access_block(
                Bucket=self.bucket,
                PublicAccessBlockConfiguration={
                    "BlockPublicAcls": True, "IgnorePublicAcls": True,
                    "BlockPublicPolicy": True, "RestrictPublicBuckets": True,
                },
            )
        except Exception:
            pass  # not all S3-compatible servers implement this API

    def put_file(self, key: str, src: Path, content_type: str) -> int:
        self.client.upload_file(str(src), self.bucket, _safe_key(key), ExtraArgs={"ContentType": content_type})
        return src.stat().st_size

    def get_to_path(self, key: str, dest: Path) -> None:
        self.client.download_file(self.bucket, _safe_key(key), str(dest))

    def stat(self, key: str) -> ObjectInfo | None:
        from botocore.exceptions import ClientError

        try:
            r = self.client.head_object(Bucket=self.bucket, Key=_safe_key(key))
        except (ClientError, ValueError):
            return None
        return ObjectInfo(size=int(r["ContentLength"]), content_type=r.get("ContentType"))

    def iter_range(self, key: str, start: int, end: int) -> Iterator[bytes]:
        r = self.client.get_object(Bucket=self.bucket, Key=_safe_key(key), Range=f"bytes={start}-{end}")
        body = r["Body"]
        try:
            yield from body.iter_chunks(CHUNK)
        finally:
            body.close()

    def delete(self, key: str) -> None:
        self.client.delete_object(Bucket=self.bucket, Key=_safe_key(key))


@lru_cache
def get_storage() -> Storage:
    s = get_settings()
    if s.storage_backend == "s3":
        return S3Storage()
    return LocalStorage(s.storage_local_root)
