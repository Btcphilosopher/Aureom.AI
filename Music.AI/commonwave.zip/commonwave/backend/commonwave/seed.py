"""Seed a demonstration catalogue through the real API and processing pipeline.

Everything is fictional and original: artists, accounts, releases, playlists,
and the audio itself (synthesised by commonwave.synth). No play counts,
followers, reviews or chart positions are invented — those start at zero and
only change through real use.

    python -m commonwave.seed           # seed if empty
    python -m commonwave.seed --reset   # wipe all data first (development only!)
"""
from __future__ import annotations

import argparse
import zlib
import base64
import sys
import tempfile
from pathlib import Path

from sqlalchemy import select, text

from commonwave.config import get_settings
from commonwave.core.db import Base, get_engine, get_sessionmaker
from commonwave.models import ArtistProfile
from commonwave.synth import Piece, artwork, render, write_wav

PASSWORD = "commonwave-demo"

ARTISTS = [
    {
        "user": "marigold", "name": "Marigold Static", "kind": "band", "location": "Port Alder (fictional)",
        "bio": "A fictional three-piece making slow, glowing dream-pop out of tape hiss and cheap synths. Created for the COMMONWAVE demo.",
        "links": [{"label": "Band notes", "url": "https://example.org/marigold-static"}],
        "support_url": "https://example.org/support/marigold", "tips": True, "members": [("rowan", "manager")],
        "palette": [(16, 24, 48), (255, 111, 97), (64, 224, 208), (255, 200, 140)],
        "release": {"title": "Low Tide Radio", "kind": "ep", "genre": "dream pop", "tags": ["synth", "tape", "night"],
                    "licence": "CC-BY-4.0", "download_mp3": True, "download_original": False,
                    "tracks": [("Low Tide Radio", Piece(11, 84, "D", "major", 42, [0, 4, 5, 3], pad=0.6)),
                               ("Harbour Lights Again", Piece(12, 92, "A", "pentatonic", 38, [0, 3, 4, 2], timbre="glass")),
                               ("Static on the Pier", Piece(13, 76, "F", "dorian", 40, [0, 3, 0, 4], drums=False, pad=0.8))]},
    },
    {
        "user": "okonkwo", "name": "Okonkwo Lane", "kind": "solo", "location": "Kestrel City (fictional)",
        "bio": "Fictional producer building warm, swung electronic grooves. Streaming only — all rights reserved.",
        "links": [], "support_url": None, "tips": True, "members": [],
        "palette": [(14, 20, 40), (64, 224, 208), (255, 111, 97), (120, 90, 220)],
        "release": {"title": "Night Market Grid", "kind": "album", "genre": "electronic", "tags": ["groove", "swing", "city"],
                    "licence": "ARR", "download_mp3": False, "download_original": False,
                    "tracks": [("Copper Wire", Piece(21, 112, "G", "minor", 44, [0, 5, 3, 4], swing=0.18, timbre="reed")),
                               ("Lantern Arithmetic", Piece(22, 104, "C", "dorian", 40, [0, 2, 3, 1], swing=0.12)),
                               ("Overpass at 3am", Piece(23, 96, "E", "minor", 46, [0, 5, 6, 4], swing=0.2, lead=0.45))]},
    },
    {
        "user": "cartographers", "name": "The Quiet Cartographers", "kind": "collective", "location": "Hollow Fen (fictional)",
        "bio": "A fictional instrumental collective mapping imaginary places in sound. Released under CC BY-SA — remix freely, share alike.",
        "links": [{"label": "Field journal", "url": "https://example.org/cartographers"}], "support_url": None, "tips": False,
        "members": [], "palette": [(18, 26, 44), (140, 200, 120), (64, 224, 208), (240, 230, 210)],
        "release": {"title": "Field Notes", "kind": "album", "genre": "ambient", "tags": ["instrumental", "folk", "calm"],
                    "licence": "CC-BY-SA-4.0", "download_mp3": True, "download_original": True, "pwyw": 200,
                    "tracks": [("Contour Lines", Piece(31, 70, "D", "pentatonic", 45, [0, 2, 3, 1], drums=False, timbre="glass")),
                               ("Reed Bed at Dawn", Piece(32, 66, "G", "major", 42, [0, 3, 4, 0], drums=False, timbre="reed", pad=0.7))]},
    },
    {
        "user": "juniper", "name": "Juniper & Ash", "kind": "band", "location": "Mossgate (fictional)",
        "bio": "A fictional lo-fi duo. One single is out; another track is still a private draft.",
        "links": [], "support_url": None, "tips": False, "members": [("ash", "contributor")],
        "palette": [(20, 22, 40), (255, 160, 120), (255, 111, 97), (90, 200, 220)],
        "release": {"title": "Paper Boats", "kind": "single", "genre": "lo-fi", "tags": ["lofi", "chill", "dusk"],
                    "licence": "CC0-1.0", "download_mp3": True, "download_original": True,
                    "tracks": [("Paper Boats", Piece(41, 82, "A", "minor", 36, [0, 5, 2, 6], swing=0.25, timbre="warm"))]},
        "draft": ("Unfinished Kite (draft)", Piece(42, 88, "C", "major", 24, [0, 4, 5, 3])),
    },
]


def _meta(**kv) -> str:
    return ",".join(f"{k} {base64.b64encode(str(v).encode()).decode()}" for k, v in kv.items())


class Client:
    def __init__(self, tc):
        self.tc = tc
        self.csrf = None

    def req(self, method, url, **kw):
        h = kw.pop("headers", {}) or {}
        if self.csrf:
            h["X-CSRF-Token"] = self.csrf
        h.setdefault("User-Agent", "commonwave-seed")
        r = self.tc.request(method, url, headers=h, **kw)
        if r.status_code >= 400:
            raise RuntimeError(f"{method} {url} -> {r.status_code}: {r.text[:300]}")
        return r


def _login(app, username: str, email: str, role_sql=None) -> Client:
    from fastapi.testclient import TestClient

    c = Client(TestClient(app, base_url="http://seed.local"))
    r = c.tc.post("/api/v1/auth/register", json={"email": email, "username": username, "password": PASSWORD,
                                                 "display_name": username.capitalize()}, headers={"User-Agent": "commonwave-seed"})
    if r.status_code == 409:
        r = c.tc.post("/api/v1/auth/login", json={"email": email, "password": PASSWORD})
    c.csrf = r.json()["csrf_token"]
    return c


def _upload(c: Client, artist_id: str, path: Path, title: str) -> str:
    data = path.read_bytes()
    r = c.req("POST", "/api/v1/uploads", headers={"Tus-Resumable": "1.0.0", "Upload-Length": str(len(data)),
                                                  "Upload-Metadata": _meta(filename=path.name, artist_id=artist_id, title=title)})
    loc, tid = r.headers["Location"], r.headers["X-Track-Id"]
    off, chunk = 0, 1024 * 1024
    while off < len(data):
        r = c.req("PATCH", loc, content=data[off:off + chunk], headers={"Tus-Resumable": "1.0.0", "Upload-Offset": str(off),
                                                                        "Content-Type": "application/offset+octet-stream"})
        off = int(r.headers["Upload-Offset"])
    return tid


def _drain(timeout: float = 300) -> None:
    """Run queued jobs in-process, then wait for any a separate worker is running."""
    import time

    from commonwave.worker import run_once

    deadline = time.time() + timeout
    with get_sessionmaker()() as db:
        while time.time() < deadline:
            if run_once(db):
                continue
            busy = db.execute(text("SELECT count(*) FROM jobs WHERE status IN ('queued','running')")).scalar()
            db.commit()
            if not busy:
                return
            time.sleep(0.5)
    raise RuntimeError("Timed out waiting for processing jobs")


def _art(c: Client, artist_id: str, path: Path, alt: str, purpose: str = "cover") -> str:
    with open(path, "rb") as f:
        r = c.req("POST", f"/api/v1/artists/{artist_id}/artworks", files={"file": (path.name, f.read(), "image/png")},
                  data={"alt_text": alt, "purpose": purpose, "credit": "Generated artwork, CC0 1.0"})
    return r.json()["id"]


def seed(reset: bool = False) -> None:
    import logging
    logging.getLogger("httpx").setLevel(logging.WARNING)
    s = get_settings()
    s.rate_limit_enabled = False
    from commonwave.main import app
    from commonwave.core.storage import get_storage

    get_storage().ensure_ready()
    if reset:
        if s.environment == "production":
            sys.exit("Refusing to --reset in production")
        tables = ", ".join(t.name for t in Base.metadata.sorted_tables)
        with get_engine().begin() as conn:
            conn.execute(text(f"TRUNCATE {tables} RESTART IDENTITY CASCADE"))
    with get_sessionmaker()() as db:
        if db.scalar(select(ArtistProfile.id).where(ArtistProfile.slug == "marigold-static")):
            print("Demo data already present; use --reset to recreate.")
            return

    admin = _login(app, "opsadmin", "opsadmin@example.com")
    with get_engine().begin() as conn:
        conn.execute(text("UPDATE users SET role='admin' WHERE username='opsadmin'"))
    _login(app, "modteam", "modteam@example.com")
    with get_engine().begin() as conn:
        conn.execute(text("UPDATE users SET role='moderator' WHERE username='modteam'"))
    for extra in ("rowan", "ash"):
        _login(app, extra, f"{extra}@example.com")

    work = Path(tempfile.mkdtemp(prefix="cw-seed-"))
    published: dict[str, list[str]] = {}
    release_ids: dict[str, str] = {}
    for spec in ARTISTS:
        c = _login(app, spec["user"], f"{spec['user']}@example.com")
        a = c.req("POST", "/api/v1/artists", json={"name": spec["name"], "kind": spec["kind"], "bio": spec["bio"], "location": spec["location"],
                                                   "links": spec["links"], "support_url": spec["support_url"], "tips_enabled": spec["tips"]}).json()
        for username, role in spec["members"]:
            c.req("POST", f"/api/v1/artists/{a['id']}/members", json={"username": username, "role": role})
        pal = spec["palette"]
        artwork(work / "avatar.png", zlib.crc32(spec["name"].encode()) % 1000, pal, (800, 800))
        artwork(work / "banner.png", zlib.crc32(spec["name"].encode()) % 1000 + 1, pal, (1800, 600))
        avatar = _art(c, a["id"], work / "avatar.png", f"Abstract avatar for {spec['name']}", "avatar")
        banner = _art(c, a["id"], work / "banner.png", f"Abstract banner for {spec['name']}", "banner")
        c.req("PATCH", f"/api/v1/artists/{a['id']}", json={"avatar_artwork_id": avatar, "banner_artwork_id": banner})

        rel = spec["release"]
        artwork(work / "cover.png", rel["tracks"][0][1].seed, pal, title=rel["title"])
        cover = _art(c, a["id"], work / "cover.png", f"Cover art for {rel['title']}: soft colour fields and a waveform line")
        tids = []
        for title, piece in rel["tracks"]:
            wav = work / f"{piece.seed}.wav"
            write_wav(wav, render(piece))
            tids.append(_upload(c, a["id"], wav, title))
        _drain()
        for i, (tid, (title, piece)) in enumerate(zip(tids, rel["tracks"]), start=1):
            c.req("PATCH", f"/api/v1/tracks/{tid}", json={
                "title": title, "genre": rel["genre"], "tags": rel["tags"], "language": "zxx",
                "description": f"Track {i} from {rel['title']}. Synthesised for the COMMONWAVE demonstration ({piece.bpm:.0f} BPM, {piece.key} {piece.scale}).",
                "credits": [{"name": spec["name"], "role": "Performance"}, {"name": "commonwave.synth", "role": "Synthesis engine"}],
                "download_mp3": rel["download_mp3"], "download_original": rel["download_original"],
                "composition": {"title": title, "writers": [{"name": spec["name"], "role": "Composer"}], "origin": "original"}})
            c.req("POST", f"/api/v1/tracks/{tid}/rights", json={
                "licence_code": rel["licence"], "recording_origin": "original", "composition_origin": "original",
                "source_notes": "Procedurally generated original audio (commonwave.synth).",
                "confirm_rights": True, "confirm_not_verified": True, "confirm_irrevocable": rel["licence"] != "ARR"})
        r = c.req("POST", "/api/v1/releases", json={"artist_id": a["id"], "title": rel["title"], "kind": rel["kind"], "genre": rel["genre"],
                                                    "tags": rel["tags"], "artwork_id": cover,
                                                    "description": f"{rel['title']} — a fictional {rel['kind']} by {spec['name']}."}).json()
        c.req("PUT", f"/api/v1/releases/{r['id']}/tracks", json={"track_ids": tids})
        if rel.get("pwyw"):
            c.req("PATCH", f"/api/v1/releases/{r['id']}", json={"pwyw_enabled": True, "pwyw_min_minor": rel["pwyw"], "pwyw_currency": "USD"})
        c.req("POST", f"/api/v1/releases/{r['id']}/publish")
        c.req("PATCH", f"/api/v1/artists/{a['id']}", json={"pinned_release_id": r["id"]})
        published[spec["name"]] = tids
        release_ids[spec["name"]] = r["id"]
        if spec.get("draft"):
            title, piece = spec["draft"]
            wav = work / "draft.wav"
            write_wav(wav, render(piece))
            _upload(c, a["id"], wav, title)
            _drain()
        print(f"  seeded {spec['name']}: {len(tids)} tracks")

    # Listener with playlists and follows (no fabricated listening data).
    fan = _login(app, "listener", "listener@example.com")
    all_tracks = [t for ts in published.values() for t in ts]
    p1 = fan.req("POST", "/api/v1/playlists", json={"title": "Late Night Commons", "visibility": "public",
                                                   "description": "Slow things for after midnight."}).json()
    p2 = fan.req("POST", "/api/v1/playlists", json={"title": "Roadtrip (share link only)", "visibility": "unlisted"}).json()
    p3 = fan.req("POST", "/api/v1/playlists", json={"title": "Focus — just for me", "visibility": "private"}).json()
    for pl, picks in ((p1, all_tracks[::2]), (p2, all_tracks[1::2]), (p3, all_tracks[-3:])):
        for t in picks:
            fan.req("POST", f"/api/v1/playlists/{pl['id']}/entries", json={"track_id": t})
    artist_ids = [a.id for a in get_sessionmaker()().scalars(select(ArtistProfile))]
    for aid in artist_ids[:2]:
        fan.req("POST", f"/api/v1/artists/{aid}/follow")
    fan.req("POST", "/api/v1/saves", json={"target_type": "release", "target_id": release_ids["The Quiet Cartographers"]})

    admin.req("POST", "/api/v1/admin/collections", json={
        "title": "Instrumental Commons", "description": "Editor's picks: instrumental music you may share and remix under open licences.",
        "curator_note": "Chosen by the demo editors. Not ranked by plays.", "published": True,
        "release_ids": [release_ids["The Quiet Cartographers"], release_ids["Marigold Static"]]})
    print("Seed complete. Accounts (password: %s): opsadmin, modteam, listener, marigold, rowan, okonkwo, cartographers, juniper, ash" % PASSWORD)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true")
    seed(ap.parse_args().reset)


if __name__ == "__main__":
    main()
