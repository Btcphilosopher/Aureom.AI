"""Background worker: audio processing, release archives, exports and housekeeping.

Run several for throughput; jobs are claimed with SKIP LOCKED. Start with
``python -m commonwave.worker`` (or the ``commonwave-worker`` script).
"""
from __future__ import annotations

import logging
import signal
import time
import uuid

from commonwave.config import get_settings
from commonwave.core.db import get_sessionmaker
from commonwave.core.logging import configure_logging
from commonwave.core.storage import get_storage
from commonwave.modules.processing import queue
from commonwave.modules.processing.ffmpeg import MediaToolError, network_isolation_active

log = logging.getLogger("commonwave.worker")
_stop = False


def handle(db, job) -> dict:
    p = job.payload
    if job.kind == "process_version":
        from commonwave.modules.processing.pipeline import process_version
        return process_version(db, uuid.UUID(p["version_id"]))
    if job.kind == "build_release_archive":
        from commonwave.modules.exports.archive import build_release_archive
        return build_release_archive(db, uuid.UUID(p["release_id"]))
    if job.kind == "artist_export":
        from commonwave.modules.exports.archive import build_artist_export
        return build_artist_export(db, uuid.UUID(p["artist_id"]), job.requested_by, p.get("include_originals", True))
    raise MediaToolError("unknown_job", f"Unknown job kind {job.kind}")


def run_once(db) -> bool:
    """Claim and run one job. Returns True if a job was processed."""
    job = queue.claim(db)
    if not job:
        db.commit()
        return False
    job_id = job.id
    db.commit()
    try:
        result = handle(db, job)
        db.commit()
        job = db.get(type(job), job_id)
        queue.finish(job, result)
    except MediaToolError as e:
        db.rollback()
        job = db.get(type(job), job_id)
        queue.fail(job, f"{e.code}: {e}", permanent=e.permanent)
    except Exception as e:  # transient: retry with backoff
        log.exception("Job %s failed", job_id)
        db.rollback()
        job = db.get(type(job), job_id)
        queue.fail(job, f"{type(e).__name__}: {str(e)[:500]}", permanent=False)
    db.commit()
    return True


def housekeeping(db) -> None:
    from commonwave.modules.moderation.router import expire_restrictions
    from commonwave.modules.uploads.router import expire_stale_uploads
    expire_stale_uploads(db)
    expire_restrictions(db)
    db.commit()


def main() -> None:
    configure_logging()
    s = get_settings()
    get_storage().ensure_ready()
    log.info("worker %s starting (network isolation for media tools: %s)", queue.WORKER_ID, network_isolation_active())

    def stop(*_):
        global _stop
        _stop = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    Session = get_sessionmaker()
    last_housekeeping = 0.0
    while not _stop:
        with Session() as db:
            if time.time() - last_housekeeping > 60:
                housekeeping(db)
                last_housekeeping = time.time()
            worked = run_once(db)
        if not worked:
            queue.wait_for_work(s.worker_poll_seconds)


if __name__ == "__main__":
    main()
