"""All ORM models. Import from here so SQLAlchemy sees every mapper."""
from commonwave.models.identity import *  # noqa: F401,F403
from commonwave.models.catalogue import *  # noqa: F401,F403
from commonwave.models.rights import *  # noqa: F401,F403
from commonwave.models.community import *  # noqa: F401,F403
from commonwave.models.identity import ArtistMembership, ArtistProfile, AuthSession, User  # noqa: F401
from commonwave.models.catalogue import (  # noqa: F401
    Artwork, AudioAsset, Composition, EditorialCollection, Release, ReleaseTrack, Track, TrackVersion,
)
from commonwave.models.rights import Download, Job, RightsDeclaration, Upload  # noqa: F401
from commonwave.models.community import (  # noqa: F401
    Appeal, AuditLog, Block, Comment, DownloadEntitlement, Follow, ListenHistory, ModerationAction,
    PaymentIntent, PayoutLedgerEntry, PlaybackEvent, PlaybackSession, Playlist, PlaylistEntry,
    ProviderEvent, Report, Save, SiteConfig,
)
