"""Playback analytics, community, moderation, support payments and site config."""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from commonwave.core.db import Base, Timestamped, UUIDPk, utcnow

# --------------------------------------------------------------------------- playback


class PlaybackSession(UUIDPk, Timestamped, Base):
    """One listener pressing play on one track. ``created_at`` = playback request.

    All counters on this row are computed by the server from client-reported
    events, bounded by wall-clock time, so a client cannot claim more listening
    than real time allows.
    """

    __tablename__ = "playback_sessions"

    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    track_version_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("track_versions.id", ondelete="CASCADE"))
    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    listener_key: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    source: Mapped[str | None] = mapped_column(String(24))
    is_preview: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_event_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_seq: Mapped[int] = mapped_column(Integer, default=-1, nullable=False)
    last_position_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_playing: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    listened_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_position_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    qualified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    qualified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    suspected_bot: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    duplicate_events: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rejected_events: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    __table_args__ = (Index("ix_playback_sessions_track_created", "track_id", "created_at"),)


class PlaybackEvent(Base):
    __tablename__ = "playback_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("playback_sessions.id", ondelete="CASCADE"))
    seq: Mapped[int] = mapped_column(Integer, nullable=False)
    kind: Mapped[str] = mapped_column(String(12), nullable=False)  # start|progress|pause|seek|end|stall
    position_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    credited_ms: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    __table_args__ = (UniqueConstraint("session_id", "seq", name="uq_playback_events_session_seq"),)


class ListenHistory(UUIDPk, Base):
    """Private per-user history. Only written when the user has history enabled;
    never exposed to artists or other users."""

    __tablename__ = "listen_history"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"))
    played_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


# --------------------------------------------------------------------------- community

PLAYLIST_VISIBILITY = ("private", "unlisted", "public")


class Playlist(UUIDPk, Timestamped, Base):
    __tablename__ = "playlists"

    owner_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    visibility: Mapped[str] = mapped_column(String(10), default="private", nullable=False)
    # Unlisted playlists are reachable only with this capability token. Private
    # playlists ignore the token entirely and require the owner's session.
    share_token: Mapped[str] = mapped_column(String(43), nullable=False, unique=True)
    allow_duplicates: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)


class PlaylistEntry(UUIDPk, Base):
    __tablename__ = "playlist_entries"

    playlist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("playlists.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"))
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    added_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class Follow(Base):
    __tablename__ = "follows"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), primary_key=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class Save(Base):
    __tablename__ = "saves"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    target_type: Mapped[str] = mapped_column(String(8), primary_key=True)  # track | release
    target_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    __table_args__ = (Index("ix_saves_target", "target_type", "target_id"),)


class Comment(UUIDPk, Timestamped, Base):
    __tablename__ = "comments"

    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    timestamp_ms: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(10), default="visible", nullable=False)  # visible|held|hidden|deleted
    hidden_reason: Mapped[str | None] = mapped_column(String(200))


class Block(Base):
    __tablename__ = "blocks"

    blocker_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    blocked_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


# --------------------------------------------------------------------------- moderation

REPORT_REASONS = ("spam", "harassment", "hate", "sexual_content", "violence", "rights", "impersonation", "malware", "other")
REPORT_TARGETS = ("track", "release", "comment", "artist", "playlist", "user")


class Report(UUIDPk, Timestamped, Base):
    __tablename__ = "reports"

    reporter_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    target_type: Mapped[str] = mapped_column(String(12), nullable=False)
    target_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    reason: Mapped[str] = mapped_column(String(20), nullable=False)
    details: Mapped[str | None] = mapped_column(Text)
    # Rights complaints carry structured claimant information (see docs/moderation.md)
    rights_claim: Mapped[dict | None] = mapped_column(JSONB)
    status: Mapped[str] = mapped_column(String(12), default="open", nullable=False)  # open|actioned|dismissed
    priority: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))

    __table_args__ = (Index("ix_reports_status_created", "status", "created_at"), Index("ix_reports_target", "target_type", "target_id"))


MODERATION_ACTIONS = (
    "hide_comment", "restore_comment",
    "restrict_track", "unrestrict_track",
    "restrict_release", "unrestrict_release",
    "withdraw_track", "restore_track",
    "restrict_user", "suspend_user", "reinstate_user",
    "restrict_artist", "suspend_artist", "reinstate_artist",
    "delete_track_permanently",
    "dismiss_report", "note",
)


class ModerationAction(UUIDPk, Timestamped, Base):
    """Decision history. Rows are never updated except to record reversal."""

    __tablename__ = "moderation_actions"

    moderator_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    target_type: Mapped[str] = mapped_column(String(12), nullable=False)
    target_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    target_version_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    action: Mapped[str] = mapped_column(String(32), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    policy_ref: Mapped[str | None] = mapped_column(String(64))
    report_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("reports.id", ondelete="SET NULL"))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    affected_user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    reversed_by_action_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))

    __table_args__ = (Index("ix_moderation_actions_target", "target_type", "target_id"),)


class Appeal(UUIDPk, Timestamped, Base):
    __tablename__ = "appeals"

    action_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("moderation_actions.id", ondelete="CASCADE"), index=True)
    appellant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    statement: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(12), default="open", nullable=False)  # open|upheld|reversed
    decided_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    decision_note: Mapped[str | None] = mapped_column(Text)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    actor_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), index=True)
    action: Mapped[str] = mapped_column(String(48), nullable=False)
    target_type: Mapped[str | None] = mapped_column(String(32))
    target_id: Mapped[str | None] = mapped_column(String(64))
    data: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    ip_hash: Mapped[str | None] = mapped_column(String(24))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)


# --------------------------------------------------------------------------- optional support (simulated payments)


class PaymentIntent(UUIDPk, Timestamped, Base):
    """A payment attempt. Purchasing/tipping, entitlement and payout are separate tables."""

    __tablename__ = "payment_intents"

    kind: Mapped[str] = mapped_column(String(16), nullable=False)  # tip | pwyw_download
    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    payer_user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    release_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("releases.id", ondelete="SET NULL"))
    amount_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)  # integer minor units (cents, or sats)
    currency: Mapped[str] = mapped_column(String(4), nullable=False)  # ISO 4217, or "SAT"
    provider: Mapped[str] = mapped_column(String(16), nullable=False)
    provider_ref: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    status: Mapped[str] = mapped_column(String(12), default="pending", nullable=False)  # pending|settled|failed|expired
    platform_fee_minor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    provider_fee_minor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(64), nullable=False)
    message: Mapped[str | None] = mapped_column(String(280))
    settled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    __table_args__ = (UniqueConstraint("payer_user_id", "idempotency_key", name="uq_payment_intents_idem"),)


class ProviderEvent(Base):
    """Processed webhook events, for idempotent fulfilment."""

    __tablename__ = "provider_events"

    provider: Mapped[str] = mapped_column(String(16), primary_key=True)
    event_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    intent_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class DownloadEntitlement(UUIDPk, Timestamped, Base):
    __tablename__ = "download_entitlements"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    release_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("releases.id", ondelete="CASCADE"))
    intent_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("payment_intents.id", ondelete="SET NULL"), unique=True)

    __table_args__ = (UniqueConstraint("user_id", "release_id", name="uq_download_entitlements_user_release"),)


class PayoutLedgerEntry(UUIDPk, Timestamped, Base):
    __tablename__ = "payout_ledger"

    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    intent_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("payment_intents.id", ondelete="CASCADE"), unique=True)
    currency: Mapped[str] = mapped_column(String(4), nullable=False)
    gross_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    platform_fee_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    provider_fee_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    net_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(12), default="accrued", nullable=False)  # accrued|paid (simulated)


class SiteConfig(Base):
    __tablename__ = "site_config"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[dict | list | bool | int | str] = mapped_column(JSONB, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)
    updated_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
