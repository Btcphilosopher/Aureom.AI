"""Catalogue: compositions, recordings (tracks), versions, releases, assets and artwork.

Vocabulary used throughout the code base:

* **Composition** — the underlying song (melody/lyrics). Has its own rights.
* **Track** — a sound recording as presented on the platform; stable identity
  that playlists, comments and reports point at.
* **TrackVersion** — one specific master of that recording. Replacing the audio
  of a published track creates a new version; old versions are retained so that
  analytics and moderation records keep meaningful references.
* **AudioAsset** — a stored file: the uploaded original, the streaming MP3
  derivative, a release archive, an export bundle.
* **Release** — an album, EP, single or compilation; ordered via ReleaseTrack.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import BigInteger, Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, TSVECTOR, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from commonwave.core.db import Base, Timestamped, UUIDPk, utcnow

TRACK_STATUSES = ("draft", "published", "withdrawn")
# Processing pipeline for a single uploaded master:
#   uploaded -> validating -> processing -> ready -> (published when the track points at it)
# side exits: failed, cancelled
VERSION_STATES = ("uploaded", "validating", "processing", "ready", "failed", "cancelled")
RELEASE_KINDS = ("single", "ep", "album", "compilation")


class Composition(UUIDPk, Timestamped, Base):
    __tablename__ = "compositions"

    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    writers: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)  # [{name, role}]
    iswc: Mapped[str | None] = mapped_column(String(15))
    origin: Mapped[str] = mapped_column(String(24), default="original", nullable=False)  # original|cover|public_domain|other


class Artwork(UUIDPk, Timestamped, Base):
    __tablename__ = "artworks"

    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    uploaded_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    key_large: Mapped[str] = mapped_column(String(300), nullable=False)
    key_small: Mapped[str] = mapped_column(String(300), nullable=False)
    width: Mapped[int] = mapped_column(Integer, nullable=False)
    height: Mapped[int] = mapped_column(Integer, nullable=False)
    alt_text: Mapped[str | None] = mapped_column(String(300))
    credit: Mapped[str | None] = mapped_column(String(300))  # artwork has its own licence/credit
    dominant_color: Mapped[str | None] = mapped_column(String(7))


class AudioAsset(UUIDPk, Timestamped, Base):
    __tablename__ = "audio_assets"

    kind: Mapped[str] = mapped_column(String(16), nullable=False)  # original | stream_mp3 | archive | export
    storage_key: Mapped[str] = mapped_column(String(300), unique=True, nullable=False)
    content_type: Mapped[str] = mapped_column(String(64), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sha256: Mapped[str | None] = mapped_column(String(64))
    format: Mapped[str | None] = mapped_column(String(16))
    artist_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    track_version_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("track_versions.id", use_alter=True, ondelete="CASCADE"), index=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Track(UUIDPk, Timestamped, Base):
    __tablename__ = "tracks"

    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    composition_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("compositions.id", ondelete="SET NULL"))
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    genre: Mapped[str | None] = mapped_column(String(48), index=True)
    tags: Mapped[list[str]] = mapped_column(ARRAY(String(32)), default=list, nullable=False)
    language: Mapped[str | None] = mapped_column(String(16))  # BCP-47 tag, or "zxx" for instrumental
    explicit: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    lyrics: Mapped[str | None] = mapped_column(Text)
    lyrics_authorised: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    credits: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)  # [{name, role}]
    collaborators: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)  # [{name, role, artist_slug?}]
    release_date: Mapped[date | None] = mapped_column(Date)
    artwork_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("artworks.id", ondelete="SET NULL"))

    status: Mapped[str] = mapped_column(String(16), default="draft", nullable=False)
    # Moderation visibility restriction is independent of the artist's status choice,
    # so restoring after moderation never silently republishes a withdrawn track.
    moderation_restricted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    moderation_note: Mapped[str | None] = mapped_column(String(300))
    current_version_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("track_versions.id", use_alter=True, ondelete="SET NULL"))
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    withdrawn_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)

    # Download permissions are independent of streaming.
    download_mp3: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    download_original: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    search_vector: Mapped[str | None] = mapped_column(TSVECTOR)

    versions: Mapped[list[TrackVersion]] = relationship(back_populates="track", foreign_keys="TrackVersion.track_id", order_by="TrackVersion.version_number")
    current_version: Mapped[TrackVersion | None] = relationship(foreign_keys=[current_version_id], post_update=True)

    __table_args__ = (
        Index("ix_tracks_search", "search_vector", postgresql_using="gin"),
        Index("ix_tracks_tags", "tags", postgresql_using="gin"),
        Index("ix_tracks_status_published", "status", "published_at"),
    )

    @property
    def is_public(self) -> bool:
        return self.status == "published" and not self.moderation_restricted


class TrackVersion(UUIDPk, Timestamped, Base):
    __tablename__ = "track_versions"

    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    version_number: Mapped[int] = mapped_column(Integer, nullable=False)
    state: Mapped[str] = mapped_column(String(16), default="uploaded", nullable=False)
    upload_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("uploads.id", ondelete="SET NULL"))
    original_asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("audio_assets.id", ondelete="SET NULL"))
    stream_asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("audio_assets.id", ondelete="SET NULL"))
    source_format: Mapped[str | None] = mapped_column(String(8))  # mp3 | wav | flac (sniffed, not from extension)
    original_filename: Mapped[str | None] = mapped_column(String(160))
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    technical: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    waveform: Mapped[list | None] = mapped_column(JSONB)  # normalised peaks 0..1
    loudness_lufs: Mapped[float | None] = mapped_column(Float)
    true_peak_dbtp: Mapped[float | None] = mapped_column(Float)
    playback_gain_db: Mapped[float | None] = mapped_column(Float)  # applied by the player, never to the file
    diagnostics: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)  # [{level, code, message}]
    failure_reason: Mapped[str | None] = mapped_column(String(300))
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    replaced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    note: Mapped[str | None] = mapped_column(String(300))

    track: Mapped[Track] = relationship(back_populates="versions", foreign_keys=[track_id])
    original_asset: Mapped[AudioAsset | None] = relationship(foreign_keys=[original_asset_id])
    stream_asset: Mapped[AudioAsset | None] = relationship(foreign_keys=[stream_asset_id])

    __table_args__ = (UniqueConstraint("track_id", "version_number", name="uq_track_versions_track_number"),)


class Release(UUIDPk, Timestamped, Base):
    __tablename__ = "releases"

    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    kind: Mapped[str] = mapped_column(String(16), default="album", nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    genre: Mapped[str | None] = mapped_column(String(48))
    tags: Mapped[list[str]] = mapped_column(ARRAY(String(32)), default=list, nullable=False)
    release_date: Mapped[date | None] = mapped_column(Date)
    artwork_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("artworks.id", ondelete="SET NULL"))
    credits: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="draft", nullable=False)
    moderation_restricted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    withdrawn_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Optional pay-what-you-want for the full-release archive (simulated payments).
    pwyw_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    pwyw_min_minor: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    pwyw_currency: Mapped[str] = mapped_column(String(3), default="USD", nullable=False)
    archive_asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("audio_assets.id", ondelete="SET NULL"))
    archive_fingerprint: Mapped[str | None] = mapped_column(String(64))
    search_vector: Mapped[str | None] = mapped_column(TSVECTOR)

    entries: Mapped[list[ReleaseTrack]] = relationship(back_populates="release", order_by="ReleaseTrack.position", cascade="all, delete-orphan")

    __table_args__ = (Index("ix_releases_search", "search_vector", postgresql_using="gin"),)

    @property
    def is_public(self) -> bool:
        return self.status == "published" and not self.moderation_restricted


class ReleaseTrack(Base):
    __tablename__ = "release_tracks"

    release_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("releases.id", ondelete="CASCADE"), primary_key=True)
    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"), primary_key=True, index=True)
    position: Mapped[int] = mapped_column(Integer, nullable=False)

    release: Mapped[Release] = relationship(back_populates="entries")
    track: Mapped[Track] = relationship()

    __table_args__ = (UniqueConstraint("release_id", "position", name="uq_release_tracks_position", deferrable=True, initially="DEFERRED"),)


class EditorialCollection(UUIDPk, Timestamped, Base):
    __tablename__ = "editorial_collections"

    slug: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    curator_note: Mapped[str | None] = mapped_column(String(300))
    published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    position: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    release_ids: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    track_ids: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
