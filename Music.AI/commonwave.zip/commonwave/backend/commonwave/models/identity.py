"""Identity: user accounts, sessions, artist profiles and band memberships.

A *User* is a person's login. An *ArtistProfile* is a public artist or band
identity. They are deliberately separate: one person can manage several
artists, and one band can have several authorised managers (ArtistMembership).
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, String, Text, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import JSONB, TSVECTOR, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from commonwave.core.db import Base, Timestamped, UUIDPk

USER_ROLES = ("user", "moderator", "admin")
USER_STATUSES = ("active", "restricted", "suspended")
MEMBER_ROLES = ("owner", "manager", "contributor")


class User(UUIDPk, Timestamped, Base):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(320), nullable=False)
    username: Mapped[str] = mapped_column(String(32), nullable=False)
    display_name: Mapped[str] = mapped_column(String(80), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(16), default="user", nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="active", nullable=False)
    restricted_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Privacy: listening history is private by default and can be disabled entirely.
    history_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    personalisation_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    interests: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)  # explicit genre interests
    storage_quota_bytes: Mapped[int | None] = mapped_column(BigInteger)

    __table_args__ = (
        Index("uq_users_email_lower", text("lower(email)"), unique=True),
        Index("uq_users_username_lower", text("lower(username)"), unique=True),
    )


class AuthSession(Timestamped, Base):
    __tablename__ = "auth_sessions"

    token_digest: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    csrf_token: Mapped[str] = mapped_column(String(64), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    user_agent: Mapped[str | None] = mapped_column(String(200))
    ip_hash: Mapped[str | None] = mapped_column(String(24))

    user: Mapped[User] = relationship()


class ArtistProfile(UUIDPk, Timestamped, Base):
    __tablename__ = "artist_profiles"

    slug: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    kind: Mapped[str] = mapped_column(String(16), default="solo", nullable=False)  # solo | band | collective
    bio: Mapped[str | None] = mapped_column(Text)
    location: Mapped[str | None] = mapped_column(String(120))
    links: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)  # [{label, url}]
    support_url: Mapped[str | None] = mapped_column(String(500))
    tips_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    avatar_artwork_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("artworks.id", use_alter=True, ondelete="SET NULL"))
    banner_artwork_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("artworks.id", use_alter=True, ondelete="SET NULL"))
    pinned_release_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("releases.id", use_alter=True, ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(16), default="active", nullable=False)  # active | restricted | suspended
    # Verification is only set by staff after a documented review (see docs/operators.md).
    verification_status: Mapped[str] = mapped_column(String(16), default="unverified", nullable=False)
    verification_method: Mapped[str | None] = mapped_column(String(200))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    verified_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    storage_quota_bytes: Mapped[int | None] = mapped_column(BigInteger)
    last_published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    search_vector: Mapped[str | None] = mapped_column(TSVECTOR)

    memberships: Mapped[list[ArtistMembership]] = relationship(back_populates="artist", cascade="all, delete-orphan")

    __table_args__ = (Index("ix_artist_profiles_search", "search_vector", postgresql_using="gin"),)


class ArtistMembership(UUIDPk, Timestamped, Base):
    __tablename__ = "artist_memberships"

    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(16), nullable=False)  # owner | manager | contributor
    invited_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))

    artist: Mapped[ArtistProfile] = relationship(back_populates="memberships")
    user: Mapped[User] = relationship(foreign_keys=[user_id])

    __table_args__ = (UniqueConstraint("artist_id", "user_id", name="uq_artist_memberships_artist_user"),)
