"""Rights declarations, uploads and background jobs."""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from commonwave.core.db import Base, Timestamped, UUIDPk, utcnow


class RightsDeclaration(UUIDPk, Timestamped, Base):
    """An *uploader's statement* about rights. Never treated as verification.

    Rows are append-only: a change creates a new row and stamps
    ``superseded_at`` on the previous one, so the history of what was declared,
    when, and by whom is preserved (important because Creative Commons grants are
    irrevocable for copies already obtained).
    """

    __tablename__ = "rights_declarations"

    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"))
    declared_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    licence_code: Mapped[str] = mapped_column(String(24), nullable=False)
    licence_version: Mapped[str | None] = mapped_column(String(8))
    licence_url: Mapped[str | None] = mapped_column(String(200))
    attribution_text: Mapped[str | None] = mapped_column(String(500))
    # Sound recording questions
    recording_origin: Mapped[str] = mapped_column(String(24), nullable=False)  # original|cover|remix|contains_samples|public_domain_recording
    # Composition questions (distinct from the recording)
    composition_origin: Mapped[str] = mapped_column(String(24), nullable=False)  # original|cover_licensed|public_domain|other
    composition_details: Mapped[str | None] = mapped_column(Text)
    samples_details: Mapped[str | None] = mapped_column(Text)
    remix_details: Mapped[str | None] = mapped_column(Text)
    source_notes: Mapped[str | None] = mapped_column(Text)
    confirmations: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    verification: Mapped[str] = mapped_column(String(24), default="self_declared", nullable=False)
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Upload(UUIDPk, Timestamped, Base):
    """A resumable (tus 1.0.0) upload session."""

    __tablename__ = "uploads"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    track_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"))
    filename: Mapped[str] = mapped_column(String(160), nullable=False)
    length: Mapped[int] = mapped_column(BigInteger, nullable=False)
    offset: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="in_progress", nullable=False)  # in_progress|complete|cancelled|expired|rejected
    sniffed_format: Mapped[str | None] = mapped_column(String(8))
    rejection_reason: Mapped[str | None] = mapped_column(String(300))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)


class Job(UUIDPk, Timestamped, Base):
    """Background job; claimed with ``FOR UPDATE SKIP LOCKED`` so several workers can run."""

    __tablename__ = "jobs"

    kind: Mapped[str] = mapped_column(String(32), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="queued", nullable=False)  # queued|running|succeeded|failed|cancelled
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
    run_after: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    locked_by: Mapped[str | None] = mapped_column(String(64))
    last_error: Mapped[str | None] = mapped_column(Text)
    result: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    requested_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    dedupe_key: Mapped[str | None] = mapped_column(String(128))

    __table_args__ = (
        Index("ix_jobs_claim", "status", "run_after"),
        Index("uq_jobs_active_dedupe", "dedupe_key", unique=True, postgresql_where="status IN ('queued','running')"),
    )


class Download(UUIDPk, Timestamped, Base):
    """A granted download. Counted separately from streaming plays."""

    __tablename__ = "downloads"

    track_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("tracks.id", ondelete="CASCADE"), index=True)
    release_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("releases.id", ondelete="CASCADE"), index=True)
    artist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("artist_profiles.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("audio_assets.id", ondelete="SET NULL"))
    format: Mapped[str] = mapped_column(String(16), nullable=False)  # mp3 | original | archive
    user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    listener_key: Mapped[str] = mapped_column(String(40), nullable=False)
    licence_code: Mapped[str | None] = mapped_column(String(24))
    fetched: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
