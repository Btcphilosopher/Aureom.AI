"""Reports, rights complaints, actions, temporary restrictions, appeals and decision history."""
from datetime import datetime, timedelta, timezone

from conftest import create_artist, new_client, publish_track, register


def _setup(audio):
    owner = register("modartist")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    return owner, artist, tid


def test_report_comment_hide_appeal_restore(audio):
    owner, artist, tid = _setup(audio)
    troll = register("troll")
    reporter = register("reporter")
    mod = register("moderator1", role="moderator")
    mod2 = register("moderator2", role="moderator")
    c = troll.post(f"/api/v1/tracks/{tid}/comments", json={"body": "<b>spam</b> buy now", "timestamp_ms": 2500}).json()
    assert c["body"] == "spam buy now"  # HTML stripped
    assert c["timestamp_ms"] == 2500
    r = reporter.post("/api/v1/reports", json={"target_type": "comment", "target_id": c["id"], "reason": "spam", "details": "advert"})
    assert r.status_code == 201
    assert reporter.post("/api/v1/reports", json={"target_type": "comment", "target_id": c["id"], "reason": "spam"}).json()["duplicate"] is True
    assert reporter.get("/api/v1/mod/reports").status_code == 403
    queue = mod.get("/api/v1/mod/reports").json()
    assert queue[0]["target"]["body"] == "spam buy now"
    act = mod.post("/api/v1/mod/actions", json={"target_type": "comment", "target_id": c["id"], "action": "hide_comment",
                                                "reason": "Commercial spam", "policy_ref": "community-1.2", "report_id": queue[0]["id"]}).json()
    assert new_client().get(f"/api/v1/tracks/{tid}/comments").json()["comments"] == []
    assert mod.get("/api/v1/mod/reports").json() == []
    # Affected user sees the decision (without moderator identity) and appeals.
    mine = troll.get("/api/v1/me/moderation").json()
    assert mine[0]["action"] == "hide_comment" and mine[0]["moderator"] is None
    ap = troll.post("/api/v1/appeals", json={"action_id": act["id"], "statement": "It was a joke between friends."})
    assert ap.status_code == 201
    assert reporter.post("/api/v1/appeals", json={"action_id": act["id"], "statement": "I want to appeal too"}).status_code == 404
    # The deciding moderator cannot review their own decision.
    assert mod.post(f"/api/v1/mod/appeals/{ap.json()['id']}/decide", json={"outcome": "reversed", "note": "own decision"}).status_code == 403
    assert mod2.post(f"/api/v1/mod/appeals/{ap.json()['id']}/decide", json={"outcome": "reversed", "note": "Context accepted"}).status_code == 200
    assert len(new_client().get(f"/api/v1/tracks/{tid}/comments").json()["comments"]) == 1
    hist = mod.get(f"/api/v1/mod/history/comment/{c['id']}").json()
    assert [a["action"] for a in hist["actions"]] == ["hide_comment", "restore_comment"]
    assert hist["actions"][0]["reversed_by_action_id"] == hist["actions"][1]["id"]


def test_rights_complaint_requires_statements_and_restricts(audio):
    owner, artist, tid = _setup(audio)
    claimant = register("claimant")
    mod = register("rightsmod", role="moderator")
    r = claimant.post("/api/v1/reports", json={"target_type": "track", "target_id": tid, "reason": "rights"})
    assert r.status_code == 400
    claim = {"claimant_name": "Example Records Ltd", "claimant_contact": "legal@records.example", "relationship": "rights-holder",
             "original_work": "Our 2019 single 'Harbour'", "good_faith_statement": True, "accuracy_statement": True}
    r = claimant.post("/api/v1/reports", json={"target_type": "track", "target_id": tid, "reason": "rights", "rights_claim": claim})
    assert r.status_code == 201
    rep = mod.get("/api/v1/mod/reports").json()[0]
    assert rep["priority"] == 2 and rep["rights_claim"]["claimant_name"] == "Example Records Ltd"
    mod.post("/api/v1/mod/actions", json={"target_type": "track", "target_id": tid, "action": "restrict_track",
                                          "reason": "Restricted pending rights review", "report_id": rep["id"]})
    assert new_client().post("/api/v1/playback/sessions", json={"track_id": tid}).status_code == 404
    # Artist can see the decision and appeal.
    mine = owner.get("/api/v1/me/moderation").json()
    assert mine[0]["action"] == "restrict_track"


def test_temporary_restriction_blocks_posting_then_expires(audio):
    owner, artist, tid = _setup(audio)
    user = register("restricted_user")
    mod = register("tempmod", role="moderator")
    until = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    r = mod.post("/api/v1/mod/actions", json={"target_type": "user", "target_id": user.me["user"]["id"], "action": "restrict_user",
                                              "reason": "Repeated spam", "expires_at": until})
    assert r.status_code == 201
    r = user.post(f"/api/v1/tracks/{tid}/comments", json={"body": "hello"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "account_restricted"
    assert user.get(f"/api/v1/tracks/{tid}").status_code == 200  # can still listen
    from conftest import sql
    sql("UPDATE users SET restricted_until = now() - interval '1 minute' WHERE username='restricted_user'")
    from commonwave.worker import housekeeping
    from commonwave.core.db import get_sessionmaker
    with get_sessionmaker()() as db:
        housekeeping(db)
    assert user.post(f"/api/v1/tracks/{tid}/comments", json={"body": "hello again"}).status_code == 201


def test_suspension_ends_sessions_and_admin_only_deletion(audio):
    owner, artist, tid = _setup(audio)
    mod = register("susmod", role="moderator")
    admin = register("rootadmin", role="admin")
    target = register("badactor")
    mod.post("/api/v1/mod/actions", json={"target_type": "user", "target_id": target.me["user"]["id"], "action": "suspend_user", "reason": "Ban evasion"})
    assert target.get("/api/v1/auth/me").json()["user"] is None
    r = mod.post("/api/v1/mod/actions", json={"target_type": "track", "target_id": tid, "action": "delete_track_permanently", "reason": "not allowed"})
    assert r.status_code == 403
    r = admin.post("/api/v1/mod/actions", json={"target_type": "track", "target_id": tid, "action": "delete_track_permanently", "reason": "Court order"})
    assert r.status_code == 201
    from conftest import sql
    assert sql("SELECT count(*) FROM audio_assets WHERE deleted_at IS NULL AND kind IN ('original','stream_mp3')")[0][0] == 0


def test_comment_premoderation_and_link_hold(audio):
    owner, artist, tid = _setup(audio)
    admin = register("cfgadmin", role="admin")
    fan = register("linker")
    r = fan.post(f"/api/v1/tracks/{tid}/comments", json={"body": "check https://example.com"}).json()
    assert r["status"] == "held"
    assert new_client().get(f"/api/v1/tracks/{tid}/comments").json()["comments"] == []
    assert owner.post(f"/api/v1/comments/{r['id']}/approve").status_code == 200
    assert len(new_client().get(f"/api/v1/tracks/{tid}/comments").json()["comments"]) == 1
    admin.patch("/api/v1/admin/config", json={"comments_enabled": False})
    assert fan.post(f"/api/v1/tracks/{tid}/comments", json={"body": "hi"}).status_code == 403


def test_blocking(audio):
    owner, artist, tid = _setup(audio)
    pest = register("pest")
    pest.post(f"/api/v1/tracks/{tid}/comments", json={"body": "first"})
    owner.post("/api/v1/me/blocks", json={"username": "pest"})
    assert owner.get(f"/api/v1/tracks/{tid}/comments").json()["comments"] == []
    r = pest.post(f"/api/v1/tracks/{tid}/comments", json={"body": "second"})
    assert r.status_code == 403
