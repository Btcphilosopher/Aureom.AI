"""Artist and user data export, discovery rules, search and storage backends."""
import io
import json
import zipfile

from conftest import create_artist, drain_jobs, new_client, publish_track, register, sql


def test_artist_export_contains_originals_and_metadata(audio):
    owner = register("exporter")
    artist = create_artist(owner, "Export Ensemble")
    publish_track(owner, artist["id"], audio["flac"], title="Exported Song")
    stranger = register("snoop")
    assert stranger.post(f"/api/v1/artists/{artist['id']}/export").status_code == 404
    job = owner.post(f"/api/v1/artists/{artist['id']}/export").json()["job_id"]
    drain_jobs()
    st = owner.get(f"/api/v1/jobs/{job}").json()
    assert st["status"] == "succeeded" and st["download_url"]
    assert stranger.get(f"/api/v1/jobs/{job}").status_code == 404
    assert stranger.get(st["download_url"]).status_code == 403  # link bound to requester
    z = zipfile.ZipFile(io.BytesIO(owner.get(st["download_url"]).content))
    data = json.loads(z.read("commonwave-export.json"))
    assert data["artist"]["name"] == "Export Ensemble"
    t = data["tracks"][0]
    assert t["title"] == "Exported Song" and t["rights_history"][0]["licence_code"] == "CC-BY-4.0"
    assert z.read(t["versions"][0]["original_file"]) == audio["flac"].read_bytes()


def test_user_export(audio):
    owner = register("artist_x")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    fan = register("exportfan")
    fan.post(f"/api/v1/artists/{artist['id']}/follow")
    fan.post("/api/v1/saves", json={"target_type": "track", "target_id": tid})
    data = fan.get("/api/v1/me/export").json()
    assert data["follows"] == [artist["id"]] and data["saves"][0]["id"] == tid
    assert data["account"]["username"] == "exportfan"


def test_popular_requires_distinct_listeners_and_caps_per_artist(audio):
    owner = register("popular")
    artist = create_artist(owner, "Popular One")
    for i in range(3):
        publish_track(owner, artist["id"], audio["wav"], title=f"P{i}")
    # One listener with many sessions does not make a track popular.
    sid = sql("INSERT INTO playback_sessions (id, track_id, track_version_id, artist_id, listener_key, is_preview, last_seq, last_position_ms, last_playing, listened_ms, max_position_ms, qualified, qualified_at, completed, suspected_bot, duplicate_events, rejected_events, created_at) "
              "SELECT gen_random_uuid(), t.id, t.current_version_id, t.artist_id, 'a:same', false, 0, 0, false, 5000, 0, true, now(), false, false, 0, 0, now() FROM tracks t, generate_series(1, 20) RETURNING id")
    assert new_client().get("/api/v1/discover").json()["popular_tracks"] == []
    for i in range(4):
        sql("INSERT INTO playback_sessions (id, track_id, track_version_id, artist_id, listener_key, is_preview, last_seq, last_position_ms, last_playing, listened_ms, max_position_ms, qualified, qualified_at, completed, suspected_bot, duplicate_events, rejected_events, created_at) "
            "SELECT gen_random_uuid(), t.id, t.current_version_id, t.artist_id, :k, false, 0, 0, false, 5000, 0, true, now(), false, false, 0, 0, now() FROM tracks t", k=f"a:listener{i}")
    from commonwave.core import cache
    cache.invalidate("")
    popular = new_client().get("/api/v1/discover").json()["popular_tracks"]
    assert len(popular) == 2  # at most two tracks per artist
    assert sid


def test_new_voices_and_following(audio):
    owner = register("newvoice")
    artist = create_artist(owner, "Brand New")
    publish_track(owner, artist["id"], audio["wav"])
    feed = new_client().get("/api/v1/discover").json()
    assert feed["personalised"] is False
    assert [a["name"] for a in feed["new_voices"]] == ["Brand New"]
    fan = register("follower")
    assert fan.post(f"/api/v1/artists/{artist['id']}/follow").json()["follower_count"] == 1
    assert len(fan.get("/api/v1/discover/following").json()["tracks"]) == 1
    page = new_client().get(f"/api/v1/artists/{artist['slug']}").json()
    assert page["follower_count"] == 1 and page["verification"]["status"] == "unverified"


def test_verified_label_only_via_admin(audio):
    owner = register("verifyme")
    artist = create_artist(owner)
    assert owner.post(f"/api/v1/admin/artists/{artist['id']}/verification", json={"verified": True, "method": "self"}).status_code == 403
    admin = register("verifier", role="admin")
    r = admin.post(f"/api/v1/admin/artists/{artist['id']}/verification", json={"verified": True, "method": "Link from official site checked"})
    assert r.json()["verified"] is True
    assert sql("SELECT count(*) FROM audit_log WHERE action='admin.verify_artist'")[0][0] == 1


def test_search_is_safe_with_operators(audio):
    owner = register("searcher")
    artist = create_artist(owner, "Query Band")
    publish_track(owner, artist["id"], audio["wav"], title="Lighthouse")
    anon = new_client()
    for q in ("light & | ! :* ( )", "'; DROP TABLE tracks; --", "lighthouse"):
        assert anon.get("/api/v1/search", params={"q": q}).status_code == 200
    assert anon.get("/api/v1/search", params={"q": "lighth"}).json()["tracks"][0]["title"] == "Lighthouse"


def test_s3_storage_backend_with_range(tmp_path, monkeypatch):
    from moto import mock_aws
    from commonwave.config import get_settings
    from commonwave.core.storage import S3Storage
    s = get_settings()
    monkeypatch.setattr(s, "s3_endpoint_url", None)
    with mock_aws():
        st = S3Storage()
        st.ensure_ready()
        p = tmp_path / "f.bin"
        p.write_bytes(bytes(range(256)) * 100)
        st.put_file("streams/x/y.mp3", p, "audio/mpeg")
        assert st.stat("streams/x/y.mp3").size == 25600
        assert b"".join(st.iter_range("streams/x/y.mp3", 10, 19)) == bytes(range(10, 20))
        assert st.stat("missing") is None


def test_sanitisation_and_log_redaction():
    import pytest
    from commonwave.core.logging import redact
    from commonwave.core.sanitize import clean_text, clean_url
    assert clean_text("<script>alert(1)</script>Hi <img src=x onerror=y>there\x00‮", 100) == "Hi there"  # script bodies are dropped entirely
    assert clean_text("a < b & c", 100) == "a < b & c"
    with pytest.raises(ValueError):
        clean_url("javascript:alert(1)")
    line = redact("GET /media/stream/1?exp=1&sig=abcDEF123 cookie: cw_session=zzz user bob@example.com")
    assert "abcDEF123" not in line and "zzz" not in line and "bob@example.com" not in line
