"""Simulated payments: tips, pay-what-you-want archives, idempotent fulfilment; release archives."""
import io
import zipfile

from conftest import RIGHTS, create_artist, drain_jobs, new_client, publish_track, register, upload_file


def _release(audio, owner, artist, pwyw=False):
    tids = []
    for f in ("wav", "flac"):
        _, t = upload_file(owner, artist["id"], audio[f])
        tids.append(t)
    drain_jobs()
    for i, t in enumerate(tids):
        owner.patch(f"/api/v1/tracks/{t}", json={"title": f"Song {i + 1}", "download_mp3": True,
                                                 "credits": [{"name": "R. Example", "role": "Mixing"}]})
        owner.post(f"/api/v1/tracks/{t}/rights", json=RIGHTS)
    rel = owner.post("/api/v1/releases", json={"artist_id": artist["id"], "title": "Archive Test", "kind": "ep"}).json()
    owner.put(f"/api/v1/releases/{rel['id']}/tracks", json={"track_ids": tids})
    if pwyw:
        owner.patch(f"/api/v1/releases/{rel['id']}", json={"pwyw_enabled": True, "pwyw_min_minor": 300, "pwyw_currency": "USD"})
    owner.post(f"/api/v1/releases/{rel['id']}/publish")
    return rel["id"]


def test_release_archive_async(audio):
    owner = register("archiver")
    artist = create_artist(owner, "Zip Band")
    rid = _release(audio, owner, artist)
    anon = new_client()
    r = anon.post(f"/api/v1/releases/{rid}/archive")
    assert r.status_code == 202 and r.json()["status"] == "building"
    job = r.json()["job_id"]
    assert anon.get(f"/api/v1/jobs/{job}").json()["status"] == "queued"
    drain_jobs()
    assert anon.get(f"/api/v1/jobs/{job}").json()["status"] == "succeeded"
    r = anon.post(f"/api/v1/releases/{rid}/archive")
    assert r.status_code == 200 and r.json()["status"] == "ready"
    z = zipfile.ZipFile(io.BytesIO(anon.get(r.json()["url"]).content))
    names = z.namelist()
    assert "01 - Song 1.mp3" in names and "02 - Song 2.mp3" in names
    txt = z.read("LICENCE-AND-CREDITS.txt").decode()
    assert "Creative Commons Attribution 4.0" in txt and "Mixing: R. Example" in txt and "cannot recall" in txt


def test_archive_denied_when_any_track_disallows_download(audio):
    owner = register("partial")
    artist = create_artist(owner)
    rid = _release(audio, owner, artist)
    tid = owner.get(f"/api/v1/releases/{rid}").json()["tracks"][0]["id"]
    owner.patch(f"/api/v1/tracks/{tid}", json={"download_mp3": False})
    assert new_client().post(f"/api/v1/releases/{rid}/archive").status_code == 403


def test_pwyw_entitlement_and_idempotent_webhooks(audio):
    owner = register("pwywartist")
    artist = create_artist(owner, "Pay What You Want")
    rid = _release(audio, owner, artist, pwyw=True)
    fan = register("buyer")
    r = fan.post(f"/api/v1/releases/{rid}/archive")
    assert r.status_code == 402 and r.json()["error"]["min_minor"] == 300
    r = fan.post("/api/v1/support/intents", json={"kind": "pwyw_download", "release_id": rid, "amount_minor": 100, "currency": "USD", "idempotency_key": "k-too-low"})
    assert r.status_code == 400
    intent = fan.post("/api/v1/support/intents", json={"kind": "pwyw_download", "release_id": rid, "amount_minor": 500,
                                                       "currency": "USD", "idempotency_key": "order-0001"}).json()
    assert intent["simulated"] is True and intent["status"] == "pending"
    assert intent["provider_fee_minor"] == 500 * 290 // 10000 + 30
    replay = fan.post("/api/v1/support/intents", json={"kind": "pwyw_download", "release_id": rid, "amount_minor": 500,
                                                       "currency": "USD", "idempotency_key": "order-0001"}).json()
    assert replay["id"] == intent["id"] and replay["idempotent_replay"] is True
    assert fan.post(f"/api/v1/releases/{rid}/archive").status_code == 402  # not settled yet
    done = fan.post(f"/api/v1/support/simulated/{intent['id']}/complete").json()
    assert done["status"] == "settled"
    # Duplicate webhook delivery of a new event for the same intent is a no-op.
    from commonwave.modules.support.providers import get_provider
    from conftest import sql
    ref = sql("SELECT provider_ref FROM payment_intents")[0][0]
    body, sig = get_provider().build_event(ref, "succeeded")
    anon = new_client()
    assert anon.post("/api/v1/support/webhooks/simulated", content=body, headers={"X-Signature": sig}).json()["already_processed"] is True
    assert anon.post("/api/v1/support/webhooks/simulated", content=body, headers={"X-Signature": sig}).json()["duplicate_event"] is True
    assert anon.post("/api/v1/support/webhooks/simulated", content=body, headers={"X-Signature": "bad"}).status_code == 400
    assert sql("SELECT count(*) FROM download_entitlements")[0][0] == 1
    assert sql("SELECT count(*) FROM payout_ledger")[0][0] == 1
    r = fan.post(f"/api/v1/releases/{rid}/archive")
    assert r.status_code == 202
    ledger = owner.get(f"/api/v1/artists/{artist['id']}/support/ledger").json()
    assert ledger["simulated"] is True and ledger["totals"][0]["net_minor"] == 500 - (500 * 290 // 10000 + 30)


def test_tips_require_opt_in(audio):
    owner = register("tipartist")
    artist = create_artist(owner)
    fan = register("tipper")
    body = {"kind": "tip", "artist_id": artist["id"], "amount_minor": 300, "currency": "USD", "idempotency_key": "tip-00001"}
    assert fan.post("/api/v1/support/intents", json=body).status_code == 404
    owner.patch(f"/api/v1/artists/{artist['id']}", json={"tips_enabled": True})
    i = fan.post("/api/v1/support/intents", json=body).json()
    assert fan.post(f"/api/v1/support/simulated/{i['id']}/complete", params={"outcome": "failed"}).json()["status"] == "failed"
    cfg = new_client().get("/api/v1/support/config").json()
    assert cfg["token_required"] is False and cfg["simulated"] is True


def test_expired_download_link_and_permission_revocation(audio, monkeypatch):
    from commonwave.config import get_settings
    owner = register("revoker")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"], download_mp3=True)
    anon = new_client()
    d = anon.post(f"/api/v1/tracks/{tid}/download", json={"format": "mp3"}).json()
    assert d["licence"]["code"] == "CC-BY-4.0" and d["size_bytes"] > 0
    owner.patch(f"/api/v1/tracks/{tid}", json={"download_mp3": False})
    assert anon.get(d["url"]).status_code == 410
    owner.patch(f"/api/v1/tracks/{tid}", json={"download_mp3": True})
    monkeypatch.setattr(get_settings(), "download_url_ttl_seconds", -1)
    d = anon.post(f"/api/v1/tracks/{tid}/download", json={"format": "mp3"}).json()
    assert anon.get(d["url"]).json()["error"]["code"] == "expired"
