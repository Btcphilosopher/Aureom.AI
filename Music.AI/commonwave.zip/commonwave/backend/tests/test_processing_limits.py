"""Malformed, oversized, over-quota, over-long and failing uploads; adapter safety."""
from pathlib import Path

import pytest

from commonwave.config import get_settings
from commonwave.modules.processing import ffmpeg
from commonwave.modules.processing.ffmpeg import MediaToolError
from commonwave.modules.processing.sniff import sniff, sniff_file
from conftest import create_artist, drain_jobs, register, sql, tus_create, tus_patch, upload_file


def test_oversized_upload_rejected_at_creation(monkeypatch):
    owner = register("big")
    artist = create_artist(owner)
    monkeypatch.setattr(get_settings(), "max_upload_bytes", 1000)
    r = tus_create(owner, artist["id"], 1001)
    assert r.status_code == 413 and r.json()["error"]["code"] == "too_large"


def test_sending_more_than_declared_is_rejected(audio):
    owner = register("over")
    artist = create_artist(owner)
    loc = tus_create(owner, artist["id"], 100).headers["Location"]
    assert tus_patch(owner, loc, 0, b"\0" * 200).status_code == 413


def test_quota_and_concurrency_limits(audio, monkeypatch):
    owner = register("quota")
    artist = create_artist(owner)
    monkeypatch.setattr(get_settings(), "default_artist_storage_quota_bytes", 50_000)
    r = tus_create(owner, artist["id"], 60_000)
    assert r.status_code == 413 and r.json()["error"]["code"] == "quota_exceeded"
    monkeypatch.setattr(get_settings(), "default_artist_storage_quota_bytes", 10**9)
    monkeypatch.setattr(get_settings(), "max_active_uploads_per_user", 2)
    assert tus_create(owner, artist["id"], 10).status_code == 201
    assert tus_create(owner, artist["id"], 10).status_code == 201
    assert tus_create(owner, artist["id"], 10).status_code == 429


def test_non_audio_rejected_by_content(audio):
    owner = register("garbage")
    artist = create_artist(owner)
    data = audio["garbage_mp3"].read_bytes()
    loc = tus_create(owner, artist["id"], len(data), filename="not-audio.mp3").headers["Location"]
    r = tus_patch(owner, loc, 0, data)
    assert r.status_code == 415 and r.json()["error"]["code"] == "invalid_audio"
    assert sql("SELECT status FROM uploads")[0][0] == "rejected"
    assert not list(get_settings().upload_staging_dir.glob("*.part")) or all(p.stat().st_size == 0 for p in get_settings().upload_staging_dir.glob("*.part"))


def test_corrupt_flac_fails_processing_with_diagnostics(audio):
    owner = register("corrupt")
    artist = create_artist(owner)
    _, tid = upload_file(owner, artist["id"], audio["corrupt_flac"])
    drain_jobs()
    v = owner.get(f"/api/v1/tracks/{tid}/manage").json()["versions"][0]
    assert v["state"] == "failed"
    assert v["diagnostics"][-1]["level"] == "error"
    assert v["failure_reason"]
    assert sql("SELECT status FROM jobs")[0][0] == "succeeded"  # permanent media failure: no retry storm
    # Retry is allowed and fails the same way.
    assert owner.post(f"/api/v1/versions/{v['id']}/retry").status_code == 200


def test_duration_limit(audio, monkeypatch):
    owner = register("toolong")
    artist = create_artist(owner)
    monkeypatch.setattr(get_settings(), "max_track_duration_seconds", 60)
    _, tid = upload_file(owner, artist["id"], audio["long_wav"])
    drain_jobs()
    v = owner.get(f"/api/v1/tracks/{tid}/manage").json()["versions"][0]
    assert v["state"] == "failed" and "longer than" in v["failure_reason"]


def test_cancel_before_processing(audio):
    owner = register("canceller")
    artist = create_artist(owner)
    _, tid = upload_file(owner, artist["id"], audio["wav"])
    vid = owner.get(f"/api/v1/tracks/{tid}/manage").json()["versions"][0]["id"]
    assert owner.post(f"/api/v1/versions/{vid}/cancel").json()["state"] == "cancelled"
    drain_jobs()
    assert owner.get(f"/api/v1/tracks/{tid}/manage").json()["versions"][0]["state"] == "cancelled"


def test_cancel_in_progress_upload_removes_empty_draft(audio):
    owner = register("abort")
    artist = create_artist(owner)
    r = tus_create(owner, artist["id"], 5000)
    loc, tid = r.headers["Location"], r.headers["X-Track-Id"]
    assert owner.delete(loc, headers={"Tus-Resumable": "1.0.0"}).status_code == 204
    assert owner.get(f"/api/v1/tracks/{tid}/manage").status_code == 404
    assert owner.head(loc, headers={"Tus-Resumable": "1.0.0"}).status_code in (404, 410)


def test_sniffer(audio):
    assert sniff_file(audio["wav"]) == "wav"
    assert sniff_file(audio["flac"]) == "flac"
    assert sniff_file(audio["mp3_128"]) == "mp3"
    assert sniff_file(audio["garbage_mp3"]) is None
    assert sniff(b"\xff\xfb" + b"\0" * 100) is None  # one plausible header is not enough
    assert sniff(b"RIFF\0\0\0\0AVI ") is None


def test_adapter_refuses_unsafe_invocations(tmp_path: Path):
    with pytest.raises(MediaToolError):
        ffmpeg.run_tool("sh", ["-c", "echo pwned"], tmp_path)
    with pytest.raises(MediaToolError):
        ffmpeg.run_tool("ffprobe", ["/etc/passwd"], tmp_path)
    with pytest.raises(MediaToolError):
        ffmpeg.run_tool("ffprobe", ["a;rm -rf /$(x)"], tmp_path)
    with pytest.raises(MediaToolError):
        ffmpeg.run_tool("ffprobe", ["x\x00y"], tmp_path)


def test_adapter_timeout_kills_process(tmp_path: Path):
    with pytest.raises(MediaToolError) as e:
        ffmpeg.run_tool("ffmpeg", ["-nostdin", "-re", "-f", "lavfi", "-i", "sine=d=60", "-f", "null", "-"], tmp_path, timeout=1)
    assert e.value.code == "timeout"


def test_adapter_blocks_network_protocols(tmp_path: Path):
    r = ffmpeg.run_tool("ffprobe", ["-v", "error", *ffmpeg.INPUT_GUARD, "http://127.0.0.1:9/x.mp3"], tmp_path, timeout=20)
    assert r.returncode != 0
    assert "protocol" in r.stderr.lower() or "not on whitelist" in r.stderr.lower() or r.stderr


def test_adapter_output_size_limit(tmp_path: Path, monkeypatch):
    monkeypatch.setattr(get_settings(), "processing_max_output_bytes", 50_000)
    out = tmp_path / "big.wav"
    with pytest.raises(MediaToolError) as e:
        r = ffmpeg.run_tool("ffmpeg", ["-nostdin", "-v", "error", "-f", "lavfi", "-i", "sine=d=30", str(out)], tmp_path, timeout=30)
        if r.returncode != 0:
            raise MediaToolError("output_limit", "ffmpeg failed when exceeding RLIMIT_FSIZE")
    assert e.value.code in ("output_limit", "crashed")
