"""Untrusted playback events: dedupe, wall-clock bounds, seeking, bots, qualified listens, privacy."""
from conftest import create_artist, new_client, publish_track, register, sql


def _track(audio):
    owner = register("pbowner")
    artist = create_artist(owner)
    return owner, artist, publish_track(owner, artist["id"], audio["wav"])


def _session(client, tid):
    s = client.post("/api/v1/playback/sessions", json={"track_id": tid}).json()
    return s["session_id"], s["session_token"]


def _send(client, sid, token, events):
    return client.post(f"/api/v1/playback/sessions/{sid}/events", json={"session_token": token, "events": events})


def _backdate(sid, seconds):
    sql(f"UPDATE playback_sessions SET started_at = started_at - interval '{int(seconds)} seconds' WHERE id=:i", i=sid)


def test_duplicate_events_are_ignored(audio):
    _, _, tid = _track(audio)
    anon = new_client()
    sid, tok = _session(anon, tid)
    assert _send(anon, sid, tok, [{"seq": 0, "kind": "start", "position_ms": 0}]).json()["accepted"] == 1
    _backdate(sid, 10)
    ev = [{"seq": 1, "kind": "progress", "position_ms": 4000}]
    first = _send(anon, sid, tok, ev).json()
    retry = _send(anon, sid, tok, ev).json()  # network retry of the same batch
    assert first["accepted"] == 1 and retry["accepted"] == 0 and retry["duplicates"] == 1
    assert first["listened_ms"] == retry["listened_ms"] == 4000


def test_listening_cannot_exceed_real_time(audio):
    _, _, tid = _track(audio)
    anon = new_client()
    sid, tok = _session(anon, tid)
    _send(anon, sid, tok, [{"seq": 0, "kind": "start", "position_ms": 0}])
    # Claim the whole 6 s track instantly: credit is capped at elapsed*2 + 5 s slack.
    r = _send(anon, sid, tok, [{"seq": 1, "kind": "progress", "position_ms": 6000}]).json()
    assert r["listened_ms"] <= 5500


def test_seek_does_not_credit_and_loop_needs_new_session(audio):
    _, _, tid = _track(audio)
    anon = new_client()
    sid, tok = _session(anon, tid)
    _send(anon, sid, tok, [{"seq": 0, "kind": "start", "position_ms": 0}])
    _backdate(sid, 60)
    r = _send(anon, sid, tok, [{"seq": 1, "kind": "progress", "position_ms": 1000},
                               {"seq": 2, "kind": "seek", "position_ms": 5500},
                               {"seq": 3, "kind": "end", "position_ms": 6000}]).json()
    assert r["listened_ms"] == 1500  # 1000 before the seek + 500 after it
    assert r["completed"] is False  # skipping to the end is not a completion
    # Positions beyond the duration are clamped; a seek backwards credits nothing.
    r = _send(anon, sid, tok, [{"seq": 4, "kind": "start", "position_ms": 0}, {"seq": 5, "kind": "progress", "position_ms": 999999}]).json()
    assert r["listened_ms"] <= 1500 + 6000


def test_qualified_listen_rule_and_dedupe(audio):
    _, artist, tid = _track(audio)
    fan = register("listener")
    for expected in (True, False):  # second qualified listen within 30 minutes does not count
        sid, tok = _session(fan, tid)
        _send(fan, sid, tok, [{"seq": 0, "kind": "start", "position_ms": 0}])
        _backdate(sid, 30)
        r = _send(fan, sid, tok, [{"seq": 1, "kind": "progress", "position_ms": 3200}, {"seq": 2, "kind": "end", "position_ms": 6000}]).json()
        assert r["qualified"] is expected  # 6 s track: threshold is 50% = 3 s
    assert r["completed"] is True
    history = fan.get("/api/v1/library/history").json()
    assert len(history["items"]) == 1


def test_bots_and_previews_never_qualify(audio):
    owner, _, tid = _track(audio)
    bot = new_client()
    s = bot.post("/api/v1/playback/sessions", json={"track_id": tid}, headers={"User-Agent": "Googlebot/2.1"}).json()
    sid, tok = s["session_id"], s["session_token"]
    _send(bot, sid, tok, [{"seq": 0, "kind": "start", "position_ms": 0}])
    _backdate(sid, 30)
    assert _send(bot, sid, tok, [{"seq": 1, "kind": "progress", "position_ms": 5000}]).json()["qualified"] is False
    p = owner.post("/api/v1/playback/sessions", json={"track_id": tid, "preview": True}).json()
    _send(owner, p["session_id"], p["session_token"], [{"seq": 0, "kind": "start", "position_ms": 0}])
    _backdate(p["session_id"], 30)
    assert _send(owner, p["session_id"], p["session_token"], [{"seq": 1, "kind": "progress", "position_ms": 5000}]).json()["qualified"] is False


def test_forged_session_token_rejected(audio):
    _, _, tid = _track(audio)
    anon = new_client()
    sid, _ = _session(anon, tid)
    assert _send(anon, sid, "forged", [{"seq": 0, "kind": "start", "position_ms": 0}]).status_code == 404


def test_history_privacy_controls(audio):
    owner, artist, tid = _track(audio)
    fan = register("private_fan")
    fan.patch("/api/v1/me/settings", json={"history_enabled": False})
    sid, tok = _session(fan, tid)
    _send(fan, sid, tok, [{"seq": 0, "kind": "start", "position_ms": 0}])
    _backdate(sid, 30)
    assert _send(fan, sid, tok, [{"seq": 1, "kind": "progress", "position_ms": 4000}]).json()["qualified"] is True
    assert fan.get("/api/v1/library/history").json()["items"] == []
    # Artist stats are aggregated and contain no listener identities.
    stats = owner.get(f"/api/v1/artists/{artist['id']}/stats").json()
    assert stats["totals"]["qualified_listens"] == 1
    assert stats["totals"]["unique_listeners"] == "<5"
    assert "private_fan" not in str(stats)
    # Other users cannot see anyone's history.
    assert new_client().get("/api/v1/library/history").status_code == 401


def test_downloads_counted_separately(audio):
    owner = register("dlcount")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"], download_mp3=True)
    anon = new_client()
    anon.post(f"/api/v1/tracks/{tid}/download", json={"format": "mp3"})
    stats = owner.get(f"/api/v1/artists/{artist['id']}/stats").json()["totals"]
    assert stats["downloads"] == 1 and stats["playback_requests"] == 0 and stats["qualified_listens"] == 0
