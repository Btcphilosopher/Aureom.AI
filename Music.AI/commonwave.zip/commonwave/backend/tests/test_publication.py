"""Publication state, withdrawal, restoration, version replacement and moderation independence."""
from conftest import RIGHTS, create_artist, drain_jobs, new_client, publish_track, register, sql, upload_file


def test_withdraw_blocks_live_urls_and_restore(audio):
    owner = register("user_wd")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"], title="Withdraw Me")
    anon = new_client()
    url = anon.post("/api/v1/playback/sessions", json={"track_id": tid}).json()["stream_url"]
    assert anon.get(url, headers={"Range": "bytes=0-99"}).status_code == 206
    r = owner.post(f"/api/v1/tracks/{tid}/withdraw")
    assert r.status_code == 200 and "cannot recall copies" in r.json()["notice"]
    # The still-unexpired URL stops working immediately.
    r = anon.get(url, headers={"Range": "bytes=100-199"})
    assert r.status_code == 410 and r.json()["error"]["code"] == "unavailable"
    assert anon.get(f"/api/v1/tracks/{tid}").status_code == 404
    assert anon.post("/api/v1/playback/sessions", json={"track_id": tid}).status_code == 404
    assert not any(t["id"] == tid for t in anon.get("/api/v1/discover").json()["latest_tracks"])
    # Restoration
    assert owner.post(f"/api/v1/tracks/{tid}/restore").status_code == 200
    assert anon.post("/api/v1/playback/sessions", json={"track_id": tid}).status_code == 201


def test_playlist_keeps_slot_for_withdrawn_track(audio):
    owner = register("wd2")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"], title="Slot Keeper")
    fan = register("fan2")
    pl = fan.post("/api/v1/playlists", json={"title": "Mine"}).json()
    fan.post(f"/api/v1/playlists/{pl['id']}/entries", json={"track_id": tid})
    owner.post(f"/api/v1/tracks/{tid}/withdraw")
    entries = fan.get(f"/api/v1/playlists/{pl['id']}").json()["entries"]
    assert entries[0]["unavailable"] is True and entries[0]["track"] is None
    assert entries[0]["unavailable_title"] == "Slot Keeper"


def test_version_replacement_keeps_history(audio):
    owner = register("ver")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    v1 = sql("SELECT current_version_id FROM tracks WHERE id=:i", i=tid)[0][0]
    fan = register("fan3")
    pl = fan.post("/api/v1/playlists", json={"title": "Keep"}).json()
    fan.post(f"/api/v1/playlists/{pl['id']}/entries", json={"track_id": tid})
    s1 = fan.post("/api/v1/playback/sessions", json={"track_id": tid}).json()
    assert s1["version_id"] == str(v1)
    upload_file(owner, artist["id"], audio["flac"], track_id=tid)
    drain_jobs()
    m = owner.get(f"/api/v1/tracks/{tid}/manage").json()
    assert m["pipeline"] == "published (replacement ready for review)"
    v2 = m["versions"][0]["id"]
    # Still serving v1 until the replacement is explicitly published.
    assert fan.post("/api/v1/playback/sessions", json={"track_id": tid}).json()["version_id"] == str(v1)
    assert owner.post(f"/api/v1/tracks/{tid}/publish", json={"version_id": v2}).status_code == 200
    assert fan.post("/api/v1/playback/sessions", json={"track_id": tid}).json()["version_id"] == v2
    # Old stream URL for v1 is no longer served; analytics keep the v1 reference.
    assert fan.get(s1["stream_url"]).status_code == 410
    assert sql("SELECT count(*) FROM playback_sessions WHERE track_version_id=:v", v=v1)[0][0] == 2
    assert sql("SELECT replaced_at IS NOT NULL FROM track_versions WHERE id=:v", v=v1)[0][0] is True
    assert fan.get(f"/api/v1/playlists/{pl['id']}").json()["entries"][0]["track"]["id"] == tid


def test_publish_requires_ready_audio(audio):
    owner = register("user_nr")
    artist = create_artist(owner)
    _, tid = upload_file(owner, artist["id"], audio["wav"])
    owner.post(f"/api/v1/tracks/{tid}/rights", json=RIGHTS)
    r = owner.post(f"/api/v1/tracks/{tid}/publish", json={})
    assert r.status_code == 409 and r.json()["error"]["code"] == "not_ready"


def test_moderation_restriction_is_independent_of_artist_restore(audio):
    owner = register("user_mr")
    mod = register("mod1", role="moderator")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    r = mod.post("/api/v1/mod/actions", json={"target_type": "track", "target_id": tid, "action": "restrict_track", "reason": "Rights complaint under review"})
    assert r.status_code == 201
    anon = new_client()
    assert anon.get(f"/api/v1/tracks/{tid}").status_code == 404
    owner.post(f"/api/v1/tracks/{tid}/withdraw")
    r = owner.post(f"/api/v1/tracks/{tid}/restore")
    assert r.status_code == 403 and r.json()["error"]["code"] == "moderation_restricted"
    mod.post("/api/v1/mod/actions", json={"target_type": "track", "target_id": tid, "action": "unrestrict_track", "reason": "Complaint withdrawn"})
    assert owner.post(f"/api/v1/tracks/{tid}/restore").status_code == 200
    assert anon.get(f"/api/v1/tracks/{tid}").status_code == 200


def test_release_publish_and_withdraw(audio):
    owner = register("rel")
    artist = create_artist(owner, "Release Band")
    _, t1 = upload_file(owner, artist["id"], audio["wav"])
    _, t2 = upload_file(owner, artist["id"], audio["flac"])
    drain_jobs()
    for t in (t1, t2):
        owner.post(f"/api/v1/tracks/{t}/rights", json=RIGHTS)
    rel = owner.post("/api/v1/releases", json={"artist_id": artist["id"], "title": "Tidewater EP", "kind": "ep"}).json()
    assert owner.put(f"/api/v1/releases/{rel['id']}/tracks", json={"track_ids": [t2, t1]}).status_code == 200
    assert owner.put(f"/api/v1/releases/{rel['id']}/tracks", json={"track_ids": [t1, t1]}).status_code == 400
    anon = new_client()
    assert anon.get(f"/api/v1/releases/{rel['id']}").status_code == 404
    r = owner.post(f"/api/v1/releases/{rel['id']}/publish")
    assert r.status_code == 200
    got = anon.get(f"/api/v1/releases/{rel['id']}").json()
    assert [t["id"] for t in got["tracks"]] == [t2, t1] and got["tracks"][0]["position"] == 1
    assert anon.get(f"/api/v1/tracks/{t1}").json()["release"]["title"] == "Tidewater EP"
    owner.post(f"/api/v1/releases/{rel['id']}/withdraw")
    assert anon.get(f"/api/v1/releases/{rel['id']}").status_code == 404
    assert anon.get(f"/api/v1/tracks/{t1}").status_code == 404


def test_rights_rules(audio):
    owner = register("user_rr")
    artist = create_artist(owner)
    tid = owner.post("/api/v1/tracks", json={"artist_id": artist["id"], "title": "Cover"}).json()["id"]
    base = {"confirm_rights": True, "confirm_not_verified": True, "confirm_irrevocable": True}
    r = owner.post(f"/api/v1/tracks/{tid}/rights", json={**base, "licence_code": "CC-BY-4.0", "recording_origin": "cover", "composition_origin": "original"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "rights_inconsistent"
    r = owner.post(f"/api/v1/tracks/{tid}/rights", json={**base, "licence_code": "CC0-1.0", "recording_origin": "contains_samples", "composition_origin": "original", "samples_details": "x"})
    assert r.status_code == 400
    r = owner.post(f"/api/v1/tracks/{tid}/rights", json={**base, "licence_code": "ARR", "recording_origin": "cover", "composition_origin": "cover_licensed",
                                                         "composition_details": "Song by A. Writer, mechanical licence via local agency"})
    assert r.status_code == 201
    assert r.json()["rights"]["verification"] == "self_declared"
    r = owner.post(f"/api/v1/tracks/{tid}/rights", json={"licence_code": "CC-BY-4.0", "recording_origin": "original", "composition_origin": "original",
                                                         "confirm_rights": True, "confirm_not_verified": True})
    assert r.status_code == 400  # open licence requires acknowledging irrevocability
    history = owner.get(f"/api/v1/tracks/{tid}/manage").json()
    assert history["rights"]["code"] == "ARR"
