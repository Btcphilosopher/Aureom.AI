"""The first-release critical path: upload → validate → streaming MP3 → publish → discover → play → seek."""
from conftest import RIGHTS, create_artist, drain_jobs, register, sql, tus_create, tus_patch, upload_file


def test_full_publish_and_stream_path(audio, anon):
    owner = register("ada")
    artist = create_artist(owner, "Ada & The Lanterns")
    data = audio["wav"].read_bytes()

    # 1-2. Resumable upload, interrupted half way.
    r = tus_create(owner, artist["id"], len(data), filename="first-light.wav", title="First Light")
    assert r.status_code == 201
    loc, track_id = r.headers["Location"], r.headers["X-Track-Id"]
    half = len(data) // 2
    assert tus_patch(owner, loc, 0, data[:half]).status_code == 204
    # Client "crashes" and restarts with a wrong idea of the offset -> 409, then asks the server.
    assert tus_patch(owner, loc, 0, data[:100]).status_code == 409
    head = owner.head(loc, headers={"Tus-Resumable": "1.0.0"})
    assert head.status_code == 200 and int(head.headers["Upload-Offset"]) == half
    r = tus_patch(owner, loc, half, data[half:])
    assert r.status_code == 204 and int(r.headers["Upload-Offset"]) == len(data)

    m = owner.get(f"/api/v1/tracks/{track_id}/manage").json()
    assert m["versions"][0]["state"] == "uploaded"
    assert m["pipeline"] == "uploaded"

    # Draft is private.
    assert anon.get(f"/api/v1/tracks/{track_id}").status_code == 404

    # 3. Process: validation, MP3 derivative, waveform, loudness.
    assert drain_jobs() == 1
    m = owner.get(f"/api/v1/tracks/{track_id}/manage").json()
    v = m["versions"][0]
    assert v["state"] == "ready", v
    assert m["pipeline"] == "ready for review"
    assert 5900 <= v["duration_ms"] <= 6100
    assert v["technical"]["codec"] == "pcm_s16le" and v["technical"]["stream_bitrate_kbps"] == 192
    assert v["has_waveform"] and v["loudness_lufs"] is not None and v["playback_gain_db"] is not None

    # Preview before publishing (members only).
    p = owner.post("/api/v1/playback/sessions", json={"track_id": track_id, "preview": True})
    assert p.status_code == 201
    assert owner.get(p.json()["stream_url"]).status_code == 200
    assert anon.get(p.json()["stream_url"]).status_code == 403  # preview link bound to member session

    # 5. Publish requires rights.
    assert owner.post(f"/api/v1/tracks/{track_id}/publish", json={}).json()["error"]["code"] == "rights_required"
    assert owner.post(f"/api/v1/tracks/{track_id}/rights", json=RIGHTS).status_code == 201
    r = owner.post(f"/api/v1/tracks/{track_id}/publish", json={})
    assert r.status_code == 200 and r.json()["status"] == "published"

    # Discover + search without signing in.
    feed = anon.get("/api/v1/discover").json()
    assert any(t["id"] == track_id for t in feed["latest_tracks"])
    found = anon.get("/api/v1/search", params={"q": "first lig"}).json()
    assert [t["id"] for t in found["tracks"]] == [track_id]
    assert anon.get("/api/v1/search", params={"q": "lanterns"}).json()["artists"][0]["id"] == artist["id"]

    # 6. Stream without signing in.
    s = anon.post("/api/v1/playback/sessions", json={"track_id": track_id, "source": "discover"})
    assert s.status_code == 201
    sess = s.json()
    assert len(sess["waveform"]) == 600
    full = anon.get(sess["stream_url"])
    assert full.status_code == 200 and full.headers["content-type"] == "audio/mpeg"
    assert full.headers["accept-ranges"] == "bytes"
    size = int(full.headers["content-length"])
    assert full.content[:3] in (b"\xff\xfb\xe0", b"\xff\xfb\x90", b"Xin") or full.content[0] == 0xFF  # MPEG frame, no ID3 tag

    # 7. Seek with range requests.
    r = anon.get(sess["stream_url"], headers={"Range": "bytes=1000-1999"})
    assert r.status_code == 206 and r.headers["content-range"] == f"bytes 1000-1999/{size}" and len(r.content) == 1000
    assert r.content == full.content[1000:2000]
    r = anon.get(sess["stream_url"], headers={"Range": f"bytes={size - 500}-"})
    assert r.status_code == 206 and len(r.content) == 500
    r = anon.get(sess["stream_url"], headers={"Range": "bytes=-256"})
    assert r.status_code == 206 and r.content == full.content[-256:]
    r = anon.get(sess["stream_url"], headers={"Range": f"bytes={size + 10}-"})
    assert r.status_code == 416 and r.headers["content-range"] == f"bytes */{size}"
    assert anon.head(sess["stream_url"]).headers["content-length"] == str(size)

    # Original upload never leaks into public payloads.
    body = anon.get(f"/api/v1/tracks/{track_id}").text
    assert "originals/" not in body and "storage_key" not in body


def test_extension_is_ignored_content_decides(audio):
    owner = register("ext")
    artist = create_artist(owner)
    _, track_id = upload_file(owner, artist["id"], audio["renamed_wav_as_mp3"])
    drain_jobs()
    v = owner.get(f"/api/v1/tracks/{track_id}/manage").json()["versions"][0]
    assert v["source_format"] == "wav" and v["state"] == "ready"


def test_flac_and_low_bitrate_mp3_diagnostics(audio):
    owner = register("diag")
    artist = create_artist(owner)
    _, flac_track = upload_file(owner, artist["id"], audio["flac"])
    _, mp3_track = upload_file(owner, artist["id"], audio["mp3_128"])
    drain_jobs()
    f = owner.get(f"/api/v1/tracks/{flac_track}/manage").json()["versions"][0]
    assert f["state"] == "ready" and f["technical"]["codec"] == "flac"
    m = owner.get(f"/api/v1/tracks/{mp3_track}/manage").json()["versions"][0]
    assert m["state"] == "ready"
    assert m["technical"]["stream_bitrate_kbps"] == 128  # never upsampled to 192
    codes = [d["code"] for d in m["diagnostics"]]
    assert "lossy_source_low_bitrate" in codes
    assert "does not" in " ".join(d["message"] for d in m["diagnostics"]) or "without restoring" in " ".join(d["message"] for d in m["diagnostics"])


def test_streaming_derivative_strips_metadata(audio):
    owner = register("meta")
    artist = create_artist(owner)
    _, track_id = upload_file(owner, artist["id"], audio["mp3_320"])
    drain_jobs()
    key = sql("SELECT a.storage_key FROM audio_assets a WHERE a.kind='stream_mp3'")[0][0]
    from commonwave.config import get_settings
    data = (get_settings().storage_local_root / key).read_bytes()
    assert not data.startswith(b"ID3")
