"""Private originals, drafts and signed media isolation."""
import time
import uuid

from commonwave.core.security import sign
from conftest import create_artist, drain_jobs, new_client, publish_track, register, sql, upload_file


def _asset(kind: str) -> str:
    return str(sql("SELECT id FROM audio_assets WHERE kind=:k LIMIT 1", k=kind)[0][0])


def test_original_never_served_through_stream_endpoint(audio):
    owner = register("priv")
    artist = create_artist(owner)
    publish_track(owner, artist["id"], audio["wav"])
    anon = new_client()
    original = _asset("original")
    assert anon.get(f"/media/stream/{original}").status_code == 403
    assert anon.get(f"/media/stream/{original}?exp=9999999999&sig=forged").status_code == 403
    # Even a correctly signed URL for the original's id is refused: only streaming derivatives are streamable.
    exp = str(int(time.time()) + 600)
    good_sig = sign("stream", f"{original}:{exp}:")
    assert anon.get(f"/media/stream/{original}?exp={exp}&sig={good_sig}").status_code == 404
    # Owner is refused too: originals are only reachable through permitted downloads.
    assert owner.get(f"/media/stream/{original}?exp={exp}&sig={good_sig}").status_code == 404


def test_private_original_download_denied_until_enabled(audio):
    owner = register("user_dl")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"], download_mp3=True)
    anon = new_client()
    r = anon.post(f"/api/v1/tracks/{tid}/download", json={"format": "original"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "download_not_permitted"
    opts = anon.get(f"/api/v1/tracks/{tid}/downloads").json()["options"]
    assert [o["format"] for o in opts] == ["mp3"]
    owner.patch(f"/api/v1/tracks/{tid}", json={"download_original": True})
    r = anon.post(f"/api/v1/tracks/{tid}/download", json={"format": "original"})
    assert r.status_code == 200 and r.json()["file_format"] == "wav"
    f = anon.get(r.json()["url"])
    assert f.status_code == 200 and f.content == audio["wav"].read_bytes()  # original preserved byte-for-byte
    assert "attachment" in f.headers["content-disposition"]


def test_drafts_and_unprocessed_are_private(audio):
    owner = register("drafty")
    artist = create_artist(owner)
    _, tid = upload_file(owner, artist["id"], audio["wav"])
    drain_jobs()
    anon = new_client()
    other = register("nosy")
    for c in (anon, other):
        assert c.get(f"/api/v1/tracks/{tid}").status_code == 404
        assert c.post("/api/v1/playback/sessions", json={"track_id": tid}).status_code == 404
        assert c.post("/api/v1/playback/sessions", json={"track_id": tid, "preview": True}).status_code == 404
        assert c.get(f"/api/v1/tracks/{tid}/manage").status_code in (401, 404)
    # The owner can view but must use preview mode to stream.
    assert owner.post("/api/v1/playback/sessions", json={"track_id": tid}).status_code == 410


def test_unknown_ids_look_identical_to_private_ones(audio):
    anon = new_client()
    r1 = anon.get(f"/api/v1/tracks/{uuid.uuid4()}")
    assert r1.status_code == 404 and r1.json()["error"]["code"] == "not_found"


def test_expired_and_tampered_stream_urls(audio, monkeypatch):
    owner = register("exp")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    anon = new_client()
    url = anon.post("/api/v1/playback/sessions", json={"track_id": tid}).json()["stream_url"]
    assert anon.get(url).status_code == 200
    tampered = url.replace("exp=", "exp=1")
    assert anon.get(tampered).json()["error"]["code"] == "invalid_signature"
    from commonwave.config import get_settings
    monkeypatch.setattr(get_settings(), "stream_url_ttl_seconds", -5)
    expired = anon.post("/api/v1/playback/sessions", json={"track_id": tid}).json()["stream_url"]
    r = anon.get(expired)
    assert r.status_code == 403 and r.json()["error"]["code"] == "expired"


def test_storage_layout_is_not_web_reachable(audio):
    """There is no static route to storage; arbitrary paths 404."""
    anon = new_client()
    for p in ("/storage/originals", "/media/originals/x.wav", "/var/storage"):
        assert anon.get(p).status_code == 404


def test_draft_artwork_private(audio):
    import io
    from PIL import Image
    owner = register("arty")
    artist = create_artist(owner)
    buf = io.BytesIO()
    Image.new("RGB", (800, 800), (200, 80, 60)).save(buf, "PNG")
    r = owner.post(f"/api/v1/artists/{artist['id']}/artworks", files={"file": ("c.png", buf.getvalue(), "image/png")}, data={"alt_text": "Red square"})
    assert r.status_code == 201
    url = r.json()["url"]
    assert owner.get(url).status_code == 200
    assert new_client().get(url).status_code == 404
