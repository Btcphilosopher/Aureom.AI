"""Playlist access control and duplicate policy."""
from conftest import create_artist, new_client, publish_track, register


def _setup(audio):
    owner = register("plartist")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    return tid


def test_private_unlisted_public_access(audio):
    tid = _setup(audio)
    alice = register("alice")
    bob = register("bob")
    anon = new_client()
    priv = alice.post("/api/v1/playlists", json={"title": "Private", "visibility": "private"}).json()
    unl = alice.post("/api/v1/playlists", json={"title": "Unlisted", "visibility": "unlisted"}).json()
    pub = alice.post("/api/v1/playlists", json={"title": "Public", "visibility": "public"}).json()
    for p in (priv, unl, pub):
        alice.post(f"/api/v1/playlists/{p['id']}/entries", json={"track_id": tid})

    # Private: only the owner — even with the token.
    from conftest import sql
    priv_token = sql("SELECT share_token FROM playlists WHERE id=:i", i=priv["id"])[0][0]
    for c in (bob, anon):
        assert c.get(f"/api/v1/playlists/{priv['id']}").status_code == 404
        assert c.get(f"/api/v1/playlists/{priv['id']}", params={"token": priv_token}).status_code == 404
    # Unlisted: token required, never listed.
    share = alice.get(f"/api/v1/playlists/{unl['id']}").json()["share_path"]
    token = share.split("token=")[1]
    assert anon.get(f"/api/v1/playlists/{unl['id']}").status_code == 404
    assert anon.get(f"/api/v1/playlists/{unl['id']}", params={"token": token}).status_code == 200
    assert "share_path" not in anon.get(f"/api/v1/playlists/{unl['id']}", params={"token": token}).json()
    listed = anon.get("/api/v1/users/alice/playlists").json()
    assert [p["title"] for p in listed] == ["Public"]
    # Rotating the link revokes the old one.
    alice.patch(f"/api/v1/playlists/{unl['id']}", json={"rotate_share_link": True})
    assert anon.get(f"/api/v1/playlists/{unl['id']}", params={"token": token}).status_code == 404
    # Public: anyone; only the owner can modify.
    assert anon.get(f"/api/v1/playlists/{pub['id']}").status_code == 200
    assert bob.post(f"/api/v1/playlists/{pub['id']}/entries", json={"track_id": tid}).status_code == 404
    assert bob.patch(f"/api/v1/playlists/{pub['id']}", json={"title": "hijack"}).status_code == 404
    # Making an unlisted playlist private kills its link.
    alice.patch(f"/api/v1/playlists/{unl['id']}", json={"visibility": "private"})


def test_duplicate_policy_and_ordering(audio):
    tid = _setup(audio)
    alice = register("dupe")
    p = alice.post("/api/v1/playlists", json={"title": "No dupes"}).json()
    assert alice.post(f"/api/v1/playlists/{p['id']}/entries", json={"track_id": tid}).status_code == 201
    r = alice.post(f"/api/v1/playlists/{p['id']}/entries", json={"track_id": tid})
    assert r.status_code == 409 and r.json()["error"]["code"] == "duplicate_entry"
    alice.patch(f"/api/v1/playlists/{p['id']}", json={"allow_duplicates": True})
    assert alice.post(f"/api/v1/playlists/{p['id']}/entries", json={"track_id": tid}).status_code == 201
    entries = alice.get(f"/api/v1/playlists/{p['id']}").json()["entries"]
    assert [e["position"] for e in entries] == [1, 2]
    ids = [e["entry_id"] for e in entries][::-1]
    assert [e["entry_id"] for e in alice.put(f"/api/v1/playlists/{p['id']}/order", json={"entry_ids": ids}).json()["entries"]] == ids
    assert alice.put(f"/api/v1/playlists/{p['id']}/order", json={"entry_ids": ids[:1]}).status_code == 400
    alice.delete(f"/api/v1/playlists/{p['id']}/entries/{ids[0]}")
    assert [e["position"] for e in alice.get(f"/api/v1/playlists/{p['id']}").json()["entries"]] == [1]


def test_cannot_add_draft_tracks(audio):
    from conftest import upload_file
    owner = register("drafter")
    artist = create_artist(owner)
    _, tid = upload_file(owner, artist["id"], audio["wav"])
    p = owner.post("/api/v1/playlists", json={"title": "x"}).json()
    assert owner.post(f"/api/v1/playlists/{p['id']}/entries", json={"track_id": tid}).status_code == 404
