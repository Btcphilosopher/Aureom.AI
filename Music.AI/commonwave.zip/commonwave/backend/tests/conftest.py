"""Test harness: real PostgreSQL (CW_TEST_DATABASE_URL), local object storage in a temp
dir, Redis disabled (in-memory fallbacks), FFmpeg-generated audio fixtures."""
from __future__ import annotations

import base64
import os
import subprocess
import tempfile
import time
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="cwtest-"))
os.environ.update({
    "CW_ENVIRONMENT": "test",
    "CW_DATABASE_URL": os.environ.get("CW_TEST_DATABASE_URL", "postgresql+psycopg://commonwave:commonwave@localhost:5432/commonwave_test"),
    "CW_REDIS_URL": "",
    "CW_STORAGE_LOCAL_ROOT": str(TMP / "storage"),
    "CW_UPLOAD_STAGING_DIR": str(TMP / "staging"),
    "CW_PROCESSING_WORK_DIR": str(TMP / "work"),
    "CW_SECRET_KEY": "test-secret-key-test-secret-key-0123456789",
    "CW_RATE_LIMIT_ENABLED": "false",
})

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from commonwave.config import get_settings  # noqa: E402
from commonwave.core import cache, ratelimit  # noqa: E402
from commonwave.core.db import Base, get_engine, get_sessionmaker  # noqa: E402

AUDIO = TMP / "audio"


def _ff(*args: str) -> None:
    subprocess.run(["ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-y", *args], check=True)


@pytest.fixture(scope="session", autouse=True)
def database():
    from alembic import command
    from alembic.config import Config

    eng = get_engine()
    with eng.begin() as c:
        c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
    cfg = Config(str(Path(__file__).parent.parent / "alembic.ini"))
    cfg.set_main_option("script_location", str(Path(__file__).parent.parent / "migrations"))
    command.upgrade(cfg, "head")
    get_settings().storage_local_root.mkdir(parents=True, exist_ok=True)
    yield


@pytest.fixture(autouse=True)
def clean_db():
    tables = ", ".join(t.name for t in Base.metadata.sorted_tables)
    with get_engine().begin() as c:
        c.execute(text(f"TRUNCATE {tables} RESTART IDENTITY CASCADE"))
    ratelimit.reset_memory()
    cache.invalidate("")
    yield  # tests change settings only through monkeypatch, which restores them


@pytest.fixture(scope="session")
def audio() -> dict[str, Path]:
    AUDIO.mkdir(parents=True, exist_ok=True)
    tone = "aevalsrc=0.4*sin(2*PI*440*t)*(0.6+0.4*sin(2*PI*0.5*t))|0.4*sin(2*PI*660*t):s=44100:d=6"
    files = {
        "wav": AUDIO / "tone.wav", "flac": AUDIO / "tone.flac", "mp3_128": AUDIO / "tone128.mp3",
        "mp3_320": AUDIO / "tone320.mp3", "long_wav": AUDIO / "long.wav",
    }
    _ff("-f", "lavfi", "-i", tone, "-c:a", "pcm_s16le", str(files["wav"]))
    _ff("-f", "lavfi", "-i", tone, "-c:a", "flac", str(files["flac"]))
    _ff("-f", "lavfi", "-i", tone, "-c:a", "libmp3lame", "-b:a", "128k", str(files["mp3_128"]))
    _ff("-f", "lavfi", "-i", tone, "-c:a", "libmp3lame", "-b:a", "320k", str(files["mp3_320"]))
    _ff("-f", "lavfi", "-i", "sine=f=220:d=75:sample_rate=22050", "-c:a", "pcm_s16le", str(files["long_wav"]))
    # Malformed inputs
    files["garbage_mp3"] = AUDIO / "not-audio.mp3"
    files["garbage_mp3"].write_bytes(b"<html><script>alert(1)</script></html>" + os.urandom(20000))
    files["corrupt_flac"] = AUDIO / "corrupt.flac"
    files["corrupt_flac"].write_bytes(b"fLaC" + os.urandom(30000))
    files["renamed_wav_as_mp3"] = AUDIO / "actually-wav.mp3"
    files["renamed_wav_as_mp3"].write_bytes(files["wav"].read_bytes())
    return files


class Api:
    """TestClient wrapper that sends the CSRF header like the web client does."""

    def __init__(self, client: TestClient):
        self.c = client
        self.csrf: str | None = None
        self.me: dict | None = None

    def _h(self, headers):
        h = dict(headers or {})
        if self.csrf:
            h.setdefault("X-CSRF-Token", self.csrf)
        h.setdefault("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) CommonwaveTest")
        return h

    def get(self, url, **kw):
        kw["headers"] = self._h(kw.get("headers"))
        return self.c.get(url, **kw)

    def head(self, url, **kw):
        kw["headers"] = self._h(kw.get("headers"))
        return self.c.head(url, **kw)

    def post(self, url, **kw):
        kw["headers"] = self._h(kw.get("headers"))
        return self.c.post(url, **kw)

    def patch(self, url, **kw):
        kw["headers"] = self._h(kw.get("headers"))
        return self.c.patch(url, **kw)

    def put(self, url, **kw):
        kw["headers"] = self._h(kw.get("headers"))
        return self.c.put(url, **kw)

    def delete(self, url, **kw):
        kw["headers"] = self._h(kw.get("headers"))
        return self.c.delete(url, **kw)


def new_client() -> Api:
    from commonwave.main import app
    return Api(TestClient(app))


@pytest.fixture
def anon() -> Api:
    return new_client()


def register(username: str, role: str | None = None) -> Api:
    api = new_client()
    r = api.post("/api/v1/auth/register", json={"email": f"{username}@example.com", "username": username, "password": "correct horse battery"})
    assert r.status_code == 201, r.text
    api.csrf = r.json()["csrf_token"]
    api.me = r.json()
    if role:
        with get_sessionmaker()() as db:
            db.execute(text("UPDATE users SET role=:r WHERE username=:u"), {"r": role, "u": username})
            db.commit()
    return api


@pytest.fixture
def users():
    return register


def create_artist(api: Api, name: str = "Test Band") -> dict:
    r = api.post("/api/v1/artists", json={"name": name, "kind": "band"})
    assert r.status_code == 201, r.text
    return r.json()


def meta(**kv) -> str:
    return ",".join(f"{k} {base64.b64encode(str(v).encode()).decode()}" for k, v in kv.items())


def tus_create(api: Api, artist_id: str, size: int, filename: str = "song.wav", **extra):
    return api.post("/api/v1/uploads", headers={"Tus-Resumable": "1.0.0", "Upload-Length": str(size),
                                                 "Upload-Metadata": meta(filename=filename, artist_id=artist_id, **extra)})


def tus_patch(api: Api, location: str, offset: int, data: bytes):
    return api.patch(location, content=data, headers={"Tus-Resumable": "1.0.0", "Upload-Offset": str(offset),
                                                       "Content-Type": "application/offset+octet-stream"})


def upload_file(api: Api, artist_id: str, path: Path, chunk: int = 64 * 1024, **extra) -> tuple[str, str]:
    data = path.read_bytes()
    r = tus_create(api, artist_id, len(data), filename=path.name, **extra)
    assert r.status_code == 201, r.text
    loc, track_id = r.headers["Location"], r.headers["X-Track-Id"]
    off = 0
    while off < len(data):
        rr = tus_patch(api, loc, off, data[off:off + chunk])
        assert rr.status_code == 204, rr.text
        off = int(rr.headers["Upload-Offset"])
    return loc, track_id


def drain_jobs(max_jobs: int = 50) -> int:
    from commonwave.worker import run_once
    n = 0
    with get_sessionmaker()() as db:
        while n < max_jobs and run_once(db):
            n += 1
    return n


RIGHTS = {"licence_code": "CC-BY-4.0", "recording_origin": "original", "composition_origin": "original",
          "confirm_rights": True, "confirm_not_verified": True, "confirm_irrevocable": True}


def publish_track(api: Api, artist_id: str, path: Path, title: str = "Night Ferry", **patch) -> str:
    _, track_id = upload_file(api, artist_id, path)
    drain_jobs()
    r = api.patch(f"/api/v1/tracks/{track_id}", json={"title": title, "genre": "ambient", **patch})
    assert r.status_code == 200, r.text
    r = api.post(f"/api/v1/tracks/{track_id}/rights", json=RIGHTS)
    assert r.status_code == 201, r.text
    r = api.post(f"/api/v1/tracks/{track_id}/publish", json={})
    assert r.status_code == 200, r.text
    return track_id


def sql(q: str, **params):
    with get_sessionmaker()() as db:
        res = db.execute(text(q), params)
        try:
            rows = res.fetchall()
        except Exception:
            rows = None
        db.commit()
        return rows


@pytest.fixture
def artist_setup(audio):
    owner = register("owner1")
    artist = create_artist(owner, "Harbour Lights")
    return owner, artist


def wait(seconds: float) -> None:
    time.sleep(seconds)
