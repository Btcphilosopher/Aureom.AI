"""Backup → restore into an empty database and bucket → integrity verification."""
import uuid

from sqlalchemy import create_engine, text

from commonwave import ops
from commonwave.config import get_settings
from commonwave.core.storage import LocalStorage
from conftest import create_artist, publish_track, register


def test_backup_and_restore_roundtrip(audio, tmp_path, monkeypatch):
    owner = register("backupper")
    artist = create_artist(owner, "Backup Band")
    tid = publish_track(owner, artist["id"], audio["wav"], title="Keep Me Safe")
    result = ops.backup(tmp_path / "bk")
    assert result["objects"] >= 2 and result["missing"] == 0
    assert ops.verify()["problems"] == []

    s = get_settings()
    name = f"cw_restore_{uuid.uuid4().hex[:8]}"
    admin = create_engine(s.database_url, isolation_level="AUTOCOMMIT")
    with admin.connect() as c:
        c.execute(text(f'CREATE DATABASE "{name}"'))
    restored_url = s.database_url.rsplit("/", 1)[0] + "/" + name
    try:
        monkeypatch.setattr(s, "database_url", restored_url)
        restored_storage = LocalStorage(tmp_path / "restored-storage")
        monkeypatch.setattr(ops, "get_storage", lambda: restored_storage)
        assert ops.restore(tmp_path / "bk")["objects_restored"] == result["objects"]
        eng = create_engine(restored_url)
        with eng.connect() as c:
            assert c.execute(text("SELECT title FROM tracks WHERE id=:i"), {"i": tid}).scalar() == "Keep Me Safe"
            keys = [r[0] for r in c.execute(text("SELECT storage_key FROM audio_assets"))]
        eng.dispose()
        assert keys and all(restored_storage.stat(k) for k in keys)
    finally:
        admin.dispose()
        base = create_engine(restored_url.rsplit("/", 1)[0] + "/commonwave_test", isolation_level="AUTOCOMMIT")
        with base.connect() as c:
            c.execute(text(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)'))
        base.dispose()


def test_verify_detects_missing_object(audio):
    owner = register("verifier2")
    artist = create_artist(owner)
    publish_track(owner, artist["id"], audio["wav"])
    key = ops.referenced_objects()[0][0]
    (get_settings().storage_local_root / key).unlink()
    assert any(p["problem"] == "missing" for p in ops.verify()["problems"])
