"""Upload permissions, artist-management roles, CSRF and object-level access."""
from conftest import RIGHTS, create_artist, drain_jobs, new_client, register, tus_create, tus_patch, upload_file


def test_non_member_cannot_upload_or_see_uploads(audio):
    owner = register("own")
    stranger = register("stranger")
    artist = create_artist(owner)
    r = tus_create(stranger, artist["id"], 1000)
    assert r.status_code == 404  # artist management is not disclosed to non-members
    r = tus_create(owner, artist["id"], 1000)
    loc = r.headers["Location"]
    assert stranger.head(loc, headers={"Tus-Resumable": "1.0.0"}).status_code == 404
    assert tus_patch(stranger, loc, 0, b"x" * 10).status_code == 404
    assert stranger.delete(loc, headers={"Tus-Resumable": "1.0.0"}).status_code == 404


def test_anonymous_cannot_upload():
    anon = new_client()
    r = anon.post("/api/v1/uploads", headers={"Tus-Resumable": "1.0.0", "Upload-Length": "10"})
    assert r.status_code == 401


def test_band_roles(audio):
    owner = register("bandowner")
    manager = register("bandmanager")
    contrib = register("bandcontrib")
    artist = create_artist(owner, "The Several")
    assert owner.post(f"/api/v1/artists/{artist['id']}/members", json={"username": "bandmanager", "role": "manager"}).status_code == 201
    assert owner.post(f"/api/v1/artists/{artist['id']}/members", json={"username": "bandcontrib", "role": "contributor"}).status_code == 201
    # Contributor uploads and edits but cannot publish.
    _, track_id = upload_file(contrib, artist["id"], audio["wav"])
    drain_jobs()
    assert contrib.patch(f"/api/v1/tracks/{track_id}", json={"title": "Draft by contributor"}).status_code == 200
    assert contrib.post(f"/api/v1/tracks/{track_id}/rights", json=RIGHTS).status_code == 201
    assert contrib.post(f"/api/v1/tracks/{track_id}/publish", json={}).status_code == 403
    assert contrib.patch(f"/api/v1/tracks/{track_id}", json={"download_mp3": True}).status_code == 403
    # Manager publishes; managers cannot manage members.
    assert manager.post(f"/api/v1/tracks/{track_id}/publish", json={}).status_code == 200
    assert manager.post(f"/api/v1/artists/{artist['id']}/members", json={"username": "bandcontrib", "role": "owner"}).status_code == 403
    # The last owner cannot be removed.
    me = owner.me["user"]["id"]
    assert owner.delete(f"/api/v1/artists/{artist['id']}/members/{me}").status_code == 409
    # Several authorised managers listed.
    members = owner.get(f"/api/v1/artists/{artist['id']}/members").json()
    assert {m["role"] for m in members} == {"owner", "manager", "contributor"}


def test_csrf_required_for_cookie_sessions(audio):
    owner = register("csrf")
    token = owner.csrf
    owner.csrf = None
    r = owner.post("/api/v1/artists", json={"name": "No CSRF"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "csrf_failed"
    owner.csrf = "wrong"
    assert owner.post("/api/v1/artists", json={"name": "Wrong CSRF"}).status_code == 403
    owner.csrf = token
    assert owner.post("/api/v1/artists", json={"name": "With CSRF"}).status_code == 201


def test_suspended_artist_hidden_and_cannot_publish(audio):
    from conftest import publish_track, sql
    owner = register("susp")
    artist = create_artist(owner, "Suspendable")
    tid = publish_track(owner, artist["id"], audio["wav"])
    sql("UPDATE artist_profiles SET status='suspended' WHERE id=:i", i=artist["id"])
    anon = new_client()
    assert anon.get(f"/api/v1/artists/{artist['slug']}").status_code == 404
    assert anon.get(f"/api/v1/tracks/{tid}").status_code == 404
    r = owner.patch(f"/api/v1/artists/{artist['id']}", json={"bio": "x"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "artist_suspended"
    assert owner.get(f"/api/v1/artists/{artist['id']}/stats").status_code == 200  # export & stats remain available


def test_rate_limit_comments(audio, monkeypatch):
    from commonwave.config import get_settings
    from conftest import publish_track
    owner = register("user_rl")
    artist = create_artist(owner)
    tid = publish_track(owner, artist["id"], audio["wav"])
    fan = register("spammer")
    monkeypatch.setattr(get_settings(), "rate_limit_enabled", True)
    codes = [fan.post(f"/api/v1/tracks/{tid}/comments", json={"body": f"comment {i}"}).status_code for i in range(25)]
    assert codes.count(201) == 20 and codes[-1] == 429
