export interface StemTrack {
  id: string;
  name: string;
  stemType: 'vocals' | 'drums' | 'bass' | 'other' | 'guitar' | 'piano' | 'master';
  color: string;
  volume: number; // 0 to 1.5, default 1.0 (0 dB)
  pan: number; // -1 to 1, default 0
  muted: boolean;
  soloed: boolean;
  clipGain: number; // dB
  startTime: number; // seconds
  duration: number; // seconds
  buffer: AudioBuffer | null;
  peaks: number[]; // precomputed min/max waveform points for fast rendering
  // Effects parameters
  eq: {
    enabled: boolean;
    lowGain: number; // dB (-12 to +12)
    lowFreq: number; // Hz (80)
    mid1Gain: number;
    mid1Freq: number; // Hz (500)
    mid1Q: number;
    mid2Gain: number;
    mid2Freq: number; // Hz (2500)
    mid2Q: number;
    highGain: number;
    highFreq: number; // Hz (10000)
  };
  compressor: {
    enabled: boolean;
    threshold: number; // dB (-60 to 0)
    ratio: number; // 1 to 20
    attack: number; // sec (0.001 to 0.1)
    release: number; // sec (0.05 to 1.0)
    makeupGain: number; // dB
  };
  restoration: {
    deEsser: boolean;
    deEsserAmount: number; // 0-100
    deHum: boolean; // 50/60Hz notch
    noiseGate: boolean;
    gateThreshold: number; // dB (-60 to -10)
    transientAttack: number; // -10 to +10 dB
    transientSustain: number; // -10 to +10 dB
  };
  // Real-time meter readings
  currentPeakDbfs: number;
  currentRmsDbfs: number;
  isClipping: boolean;
}

export interface SeparationModel {
  id: string;
  name: string;
  version: string;
  architecture: string;
  stems: string[];
  sampleRate: number;
  channels: number;
  recommendedDevice: string;
  memoryReqMB: number;
  latencyMs: number;
  licence: string;
  status: string;
  precision: string;
  sdrRating: string;
  isDefault: boolean;
}

export interface Marker {
  id: string;
  name: string;
  time: number;
  color: string;
}

export interface AureomProject {
  id: string;
  name: string;
  version: string;
  bpm: number;
  timeSignature: string; // e.g. "4/4"
  sampleRate: number;
  bitDepth: number;
  createdAt: string;
  updatedAt: string;
  tracks: StemTrack[];
  markers: Marker[];
  loopEnabled: boolean;
  loopStart: number;
  loopEnd: number;
  activeModelId: string;
}

export interface BatchItem {
  id: string;
  fileName: string;
  fileSize: number;
  duration: number;
  modelId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed' | 'paused';
  progress: number;
  stems: string[];
  error?: string;
}

export interface AcousticReport {
  integratedLUFS: number;
  shortTermMaxLUFS: number;
  truePeakDbfs: number;
  crestFactorDb: number;
  spectralCentroidHz: number;
  spectralBandwidthHz: number;
  zeroCrossingRate: number;
  estimatedSISDR: number;
  phaseCoherence: number;
  energyDistribution: {
    subBass: number;
    bass: number;
    lowMid: number;
    mid: number;
    highMid: number;
    air: number;
  };
}
