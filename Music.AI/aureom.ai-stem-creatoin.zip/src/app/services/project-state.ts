import { Injectable, signal } from '@angular/core';
import { AureomProject, BatchItem, AcousticReport, Marker } from '../models/audio.types';

export type StudioWorkspace =
  | 'multitrack'
  | 'mixer'
  | 'inspector'
  | 'separation'
  | 'spectral'
  | 'intelligence'
  | 'restoration'
  | 'batch'
  | 'export'
  | 'models'
  | 'quality'
  | 'devices'
  | 'settings'
  | 'performance'
  | 'diagnostics'
  | 'history'
  | 'launcher'
  | 'welcome';

export interface HistoryAction {
  id: string;
  timestamp: string;
  description: string;
  category: 'edit' | 'separation' | 'effect' | 'mixer' | 'project';
}

@Injectable({
  providedIn: 'root'
})
export class ProjectState {
  // Navigation
  readonly activeWorkspace = signal<StudioWorkspace>('multitrack');
  readonly selectedTrackId = signal<string>('track-vocals');
  readonly isInspectorOpen = signal<boolean>(true);

  // Project metadata
  readonly projectName = signal<string>('Aureom Nocturne — Electronic Soul');
  readonly projectBpm = signal<number>(124);
  readonly timeSignature = signal<string>('4/4');
  readonly sampleRate = signal<number>(44100);
  readonly bitDepth = signal<number>(24);
  readonly projectSaved = signal<boolean>(true);
  readonly lastSavedTime = signal<string>('Just now (Autosaved)');

  // Selected Separation Model
  readonly activeModelId = signal<string>('demucs-v4-ht');
  readonly separationTargetStems = signal<2 | 4 | 6>(4);
  readonly separationOverlap = signal<number>(50); // % overlap
  readonly separationDevice = signal<string>('Auto (GPU Preferred)');
  readonly separationProgress = signal<{
    percent: number;
    chunk: number;
    totalChunks: number;
    status: string;
    isProcessing: boolean;
  }>({
    percent: 0,
    chunk: 0,
    totalChunks: 16,
    status: 'Ready',
    isProcessing: false
  });

  // Timeline & Markers
  readonly markers = signal<Marker[]>([
    { id: 'm-1', name: 'Intro', time: 0, color: '#6366f1' },
    { id: 'm-2', name: 'Groove A', time: 3.87, color: '#f59e0b' },
    { id: 'm-3', name: 'Vocal Hook', time: 7.74, color: '#f43f5e' },
    { id: 'm-4', name: 'Drop', time: 11.61, color: '#10b981' }
  ]);
  readonly snapToGrid = signal<boolean>(true);
  readonly zoomLevel = signal<number>(1.0); // 0.5x to 4.0x

  // Batch Queue
  readonly batchQueue = signal<BatchItem[]>([
    {
      id: 'batch-1',
      fileName: 'Lunar_Eclipse_Master_Final.wav',
      fileSize: 48200000,
      duration: 214,
      modelId: 'demucs-v4-ht',
      status: 'completed',
      progress: 100,
      stems: ['Vocals', 'Drums', 'Bass', 'Other']
    },
    {
      id: 'batch-2',
      fileName: 'Solaris_Acoustic_Session_96k.wav',
      fileSize: 112000000,
      duration: 340,
      modelId: 'ht-demucs-6s',
      status: 'queued',
      progress: 0,
      stems: ['Vocals', 'Drums', 'Bass', 'Guitar', 'Piano', 'Other']
    },
    {
      id: 'batch-3',
      fileName: 'Tokyo_Midnight_Remix_StemMix.wav',
      fileSize: 52100000,
      duration: 188,
      modelId: 'mdx-net-vocals',
      status: 'queued',
      progress: 0,
      stems: ['Vocals', 'Instrumental']
    }
  ]);

  // Audio Intelligence & R-Worker data
  readonly acousticReport = signal<AcousticReport | null>({
    integratedLUFS: -14.2,
    shortTermMaxLUFS: -11.8,
    truePeakDbfs: -0.6,
    crestFactorDb: 13.6,
    spectralCentroidHz: 2840,
    spectralBandwidthHz: 3450,
    zeroCrossingRate: 0.048,
    estimatedSISDR: 9.85,
    phaseCoherence: 0.982,
    energyDistribution: {
      subBass: 22,
      bass: 28,
      lowMid: 20,
      mid: 34,
      highMid: 24,
      air: 18
    }
  });

  readonly aiMasteringAdvice = signal<{
    summary: string;
    harmonicStructure: string;
    separationQualityRating: string;
    bleedAnalysis: string;
    mixingRecommendations: string[];
    masteringTarget: {
      recommendedLUFS: number;
      truePeakCeilingDbfs: number;
      stereoWidthTip: string;
    };
  } | null>({
    summary: 'Aureom DSP Engine analysed "Aureom Nocturne" with high dynamic range (13.6 dB crest factor). Frequency distribution shows clean bass foundation and clear vocal presence without mid-range masking.',
    harmonicStructure: 'Primary tonal center in F Minor at 124 BPM. Strong chord movement (Fm7 - Dbmaj7 - Eb7 - Csus4) with excellent vocal formant separation.',
    separationQualityRating: 'Studio-Grade (9.85 dB SDR)',
    bleedAnalysis: 'Negligible vocal bleed into drums; high-hat spill in Vocals channel is attenuated below -26 dB masking ceiling.',
    mixingRecommendations: [
      'High-pass Vocals stem at 95 Hz with 18dB/octave Butterworth slope to eliminate sub-rumble.',
      'Dip 350 Hz on the Other stem by -2.0 dB to carve space for vocal presence.',
      'Apply optical 3:1 compression on the Bass stem with 15ms attack to let kick transients punch through.',
      'Use the Transient Shaper on Drums with +1.5 dB attack to enhance snare snap.'
    ],
    masteringTarget: {
      recommendedLUFS: -14.0,
      truePeakCeilingDbfs: -0.8,
      stereoWidthTip: 'Preserve mono compatibility under 140 Hz; widen synths by 115% above 2.5 kHz.'
    }
  });

  // History & Undo stack
  readonly historyLog = signal<HistoryAction[]>([
    { id: 'h-1', timestamp: '10:04:12', description: 'Initialized project with 4-stem Demucs v4 HT separation', category: 'separation' },
    { id: 'h-2', timestamp: '10:05:40', description: 'Adjusted Vocal EQ: +1.2 dB mid presence at 2.8 kHz', category: 'effect' },
    { id: 'h-3', timestamp: '10:06:15', description: 'Engaged Vocal De-Esser at 6.8 kHz (-3.5 dB gain reduction)', category: 'effect' },
    { id: 'h-4', timestamp: '10:08:02', description: 'Balanced drum bus compressor threshold to -14 dB', category: 'mixer' },
    { id: 'h-5', timestamp: '10:09:20', description: 'Placed timeline marker "Vocal Hook" at bar 5', category: 'edit' }
  ]);

  recordAction(description: string, category: HistoryAction['category']) {
    const action: HistoryAction = {
      id: `h-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      description,
      category
    };
    this.historyLog.update(list => [action, ...list].slice(0, 50));
    this.projectSaved.set(false);
  }

  setWorkspace(workspace: StudioWorkspace) {
    this.activeWorkspace.set(workspace);
  }

  setSelectedTrack(trackId: string) {
    this.selectedTrackId.set(trackId);
  }

  toggleInspector() {
    this.isInspectorOpen.update(v => !v);
  }

  saveProject() {
    this.projectSaved.set(true);
    this.lastSavedTime.set(new Date().toLocaleTimeString());
    this.recordAction(`Project saved: ${this.projectName()}`, 'project');
  }

  downloadProjectManifest() {
    const manifest: AureomProject = {
      id: `proj-${Date.now()}`,
      name: this.projectName(),
      version: '1.0.0-aureom',
      bpm: this.projectBpm(),
      timeSignature: this.timeSignature(),
      sampleRate: this.sampleRate(),
      bitDepth: this.bitDepth(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      tracks: [], // Will be serialized with settings
      markers: this.markers(),
      loopEnabled: true,
      loopStart: 0,
      loopEnd: 15.48,
      activeModelId: this.activeModelId()
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.projectName().replace(/[^a-zA-Z0-9_-]/g, '_')}.aureomusic`;
    a.click();
    URL.revokeObjectURL(url);
    this.saveProject();
  }
}
