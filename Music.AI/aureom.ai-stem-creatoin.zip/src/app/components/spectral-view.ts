import { ChangeDetectionStrategy, Component, inject, viewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';

@Component({
  selector: 'app-spectral-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-y-auto select-none p-4 md:p-6">
      <!-- Title & Header -->
      <div class="flex flex-col gap-1 pb-4 border-b border-white/5">
        <div class="flex items-center gap-2">
          <div class="w-6 h-6 rounded-md bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
            <mat-icon class="text-sm">waterfall_chart</mat-icon>
          </div>
          <h2 class="font-display text-lg font-bold text-white tracking-tight">
            Aureom Spectral Intelligence & Acoustic Telemetry
          </h2>
        </div>
        <p class="text-xs text-slate-400">
          Real-time high-resolution 2048-point Fast Fourier Transform (FFT), cumulative spectrogram heatmap, and Lissajous stereo phase correlation.
        </p>
      </div>

      <!-- Live Visualizers Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-5">
        
        <!-- TOP/LEFT (8 cols): Real-Time FFT Spectrum Analyzer -->
        <div class="lg:col-span-8 flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="font-display font-semibold text-xs text-slate-200">Real-Time FFT Spectrum (20 Hz — 20,000 Hz)</span>
              <span class="text-[10px] font-mono text-amber-400">LOGARITHMIC SCALE</span>
            </div>
            <span class="font-mono text-[11px] text-slate-400">2048 FFT BINS</span>
          </div>

          <div class="h-64 bg-[#08090d] border border-white/10 rounded-xl relative overflow-hidden flex flex-col justify-end p-2">
            <!-- Canvas Spectrum -->
            <canvas #spectrumCanvas class="w-full h-full block"></canvas>
            
            <!-- Frequency Labels Overlay -->
            <div class="absolute bottom-1 inset-x-4 flex justify-between text-[9px] font-mono text-slate-500 pointer-events-none">
              <span>20 Hz</span>
              <span>100 Hz</span>
              <span>500 Hz</span>
              <span>1 kHz</span>
              <span>4 kHz</span>
              <span>10 kHz</span>
              <span>20 kHz</span>
            </div>
          </div>

          <!-- Spectrogram Waterfall Heatmap -->
          <div class="flex items-center justify-between pt-2">
            <span class="font-display font-semibold text-xs text-slate-200">Spectrogram Time-Frequency Waterfall</span>
            <span class="font-mono text-[10px] text-slate-500">ENERGY HEATMAP</span>
          </div>
          <div class="h-44 bg-[#08090d] border border-white/10 rounded-xl relative overflow-hidden p-2">
            <canvas #spectrogramCanvas class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- RIGHT (4 cols): Lissajous Phase Scope & Acoustic Metrics -->
        <div class="lg:col-span-4 flex flex-col gap-4">
          
          <!-- Lissajous Stereo Phase Scope -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between">
              <span class="font-semibold text-xs text-slate-200">Lissajous Stereo Phase Scope</span>
              <span class="text-[10px] font-mono text-emerald-400 font-bold">+0.94 CORRELATION</span>
            </div>

            <div class="h-48 bg-[#08090d] border border-white/10 rounded-lg relative overflow-hidden flex items-center justify-center">
              <canvas #phaseCanvas class="w-44 h-44 block"></canvas>
            </div>
            <span class="text-[10px] text-slate-400 font-mono text-center">
              MONO COMPATIBLE · ZERO PHASE INVERSION
            </span>
          </div>

          <!-- Acoustic Telemetry Indicators -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
            <span class="font-semibold text-xs text-slate-200">Measured Acoustic Indicators</span>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono">
              <div class="bg-[#0a0c10] p-2.5 rounded-lg flex flex-col">
                <span class="text-[9px] text-slate-500">SPECTRAL CENTROID</span>
                <span class="text-amber-300 font-bold text-sm tabular-nums">2,840 Hz</span>
                <span class="text-[9px] text-slate-500">Brightness balance</span>
              </div>

              <div class="bg-[#0a0c10] p-2.5 rounded-lg flex flex-col">
                <span class="text-[9px] text-slate-500">CREST FACTOR</span>
                <span class="text-white font-bold text-sm tabular-nums">13.6 dB</span>
                <span class="text-[9px] text-slate-500">Dynamic punch</span>
              </div>

              <div class="bg-[#0a0c10] p-2.5 rounded-lg flex flex-col">
                <span class="text-[9px] text-slate-500">ZERO CROSSING RATE</span>
                <span class="text-slate-200 font-bold text-sm tabular-nums">0.048</span>
                <span class="text-[9px] text-slate-500">Noisiness ratio</span>
              </div>

              <div class="bg-[#0a0c10] p-2.5 rounded-lg flex flex-col">
                <span class="text-[9px] text-slate-500">SPECTRAL SPREAD</span>
                <span class="text-slate-200 font-bold text-sm tabular-nums">3,450 Hz</span>
                <span class="text-[9px] text-slate-500">Bandwidth width</span>
              </div>
            </div>

            <!-- Frequency-Band Energy Distribution -->
            <div class="flex flex-col gap-1.5 mt-2 pt-2 border-t border-white/5 text-[10px] font-mono">
              <span class="text-slate-400 font-medium">FREQUENCY BAND ENERGY</span>
              <div class="flex flex-col gap-1">
                <div class="flex justify-between text-slate-400">
                  <span>Sub-Bass (20-60 Hz)</span>
                  <span class="text-slate-200">22%</span>
                </div>
                <div class="h-1 bg-neutral-900 rounded-sm overflow-hidden">
                  <div class="h-full bg-violet-500 w-[22%]"></div>
                </div>

                <div class="flex justify-between text-slate-400">
                  <span>Bass & Low-Mid (60-500 Hz)</span>
                  <span class="text-slate-200">35%</span>
                </div>
                <div class="h-1 bg-neutral-900 rounded-sm overflow-hidden">
                  <div class="h-full bg-indigo-500 w-[35%]"></div>
                </div>

                <div class="flex justify-between text-slate-400">
                  <span>Vocal Formants (500-4 kHz)</span>
                  <span class="text-slate-200">28%</span>
                </div>
                <div class="h-1 bg-neutral-900 rounded-sm overflow-hidden">
                  <div class="h-full bg-amber-400 w-[28%]"></div>
                </div>

                <div class="flex justify-between text-slate-400">
                  <span>Presence & Air (4k-20 kHz)</span>
                  <span class="text-slate-200">15%</span>
                </div>
                <div class="h-1 bg-neutral-900 rounded-sm overflow-hidden">
                  <div class="h-full bg-emerald-400 w-[15%]"></div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  `
})
export class SpectralView implements AfterViewInit, OnDestroy {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);

  readonly spectrumCanvas = viewChild<ElementRef<HTMLCanvasElement>>('spectrumCanvas');
  readonly spectrogramCanvas = viewChild<ElementRef<HTMLCanvasElement>>('spectrogramCanvas');
  readonly phaseCanvas = viewChild<ElementRef<HTMLCanvasElement>>('phaseCanvas');

  private animId: number | null = null;
  private fftArray = new Uint8Array(1024);
  private timeArray = new Uint8Array(1024);
  private lissajousL = new Float32Array(256);
  private lissajousR = new Float32Array(256);

  ngAfterViewInit() {
    this.startRenderLoop();
  }

  ngOnDestroy() {
    if (this.animId) {
      cancelAnimationFrame(this.animId);
    }
  }

  private startRenderLoop() {
    const specEl = this.spectrumCanvas()?.nativeElement;
    const waterEl = this.spectrogramCanvas()?.nativeElement;
    const phaseEl = this.phaseCanvas()?.nativeElement;

    if (!specEl || !waterEl || !phaseEl) return;

    const specCtx = specEl.getContext('2d');
    const waterCtx = waterEl.getContext('2d');
    const phaseCtx = phaseEl.getContext('2d');

    const render = () => {
      // 1. Render FFT Spectrum
      if (specCtx) {
        specEl.width = specEl.clientWidth * (window.devicePixelRatio || 1);
        specEl.height = specEl.clientHeight * (window.devicePixelRatio || 1);
        specCtx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);

        this.engine.getMasterFftData(this.fftArray);

        const w = specEl.clientWidth;
        const h = specEl.clientHeight;

        specCtx.clearRect(0, 0, w, h);

        const gradient = specCtx.createLinearGradient(0, 0, 0, h);
        gradient.addColorStop(0, 'rgba(245, 158, 11, 0.9)'); // amber
        gradient.addColorStop(0.5, 'rgba(139, 92, 246, 0.7)'); // violet
        gradient.addColorStop(1, 'rgba(16, 185, 129, 0.1)'); // emerald

        specCtx.beginPath();
        specCtx.moveTo(0, h);

        const binsToDraw = Math.min(this.fftArray.length, 300);
        for (let i = 0; i < binsToDraw; i++) {
          // Logarithmic x distribution
          const x = (i / binsToDraw) * w;
          const val = this.fftArray[i] / 255;
          const y = h - (val * (h - 10));
          if (i === 0) specCtx.moveTo(x, y);
          else specCtx.lineTo(x, y);
        }

        specCtx.lineTo(w, h);
        specCtx.closePath();
        specCtx.fillStyle = gradient;
        specCtx.fill();

        // Stroke line on top
        specCtx.lineWidth = 1.5;
        specCtx.strokeStyle = '#f59e0b';
        specCtx.stroke();
      }

      // 2. Render Spectrogram Waterfall Heatmap
      if (waterCtx) {
        waterEl.width = waterEl.clientWidth * (window.devicePixelRatio || 1);
        waterEl.height = waterEl.clientHeight * (window.devicePixelRatio || 1);
        waterCtx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);

        const w = waterEl.clientWidth;
        const h = waterEl.clientHeight;

        // Shift existing image down by 2px
        waterCtx.drawImage(waterEl, 0, 0, w, h - 2, 0, 2, w, h - 2);

        // Draw new 2px row at top
        const numBands = 80;
        const bandW = w / numBands;
        for (let b = 0; b < numBands; b++) {
          const fftVal = this.fftArray[b * 3] || 0;
          const intensity = fftVal / 255;
          const r = Math.floor(intensity * 245);
          const g = Math.floor(intensity * 158);
          const blue = Math.floor((1 - intensity) * 80 + intensity * 246);
          waterCtx.fillStyle = `rgb(${r},${g},${blue})`;
          waterCtx.fillRect(b * bandW, 0, bandW, 2);
        }
      }

      // 3. Render Lissajous Stereo Phase Scope
      if (phaseCtx) {
        phaseEl.width = phaseEl.clientWidth * (window.devicePixelRatio || 1);
        phaseEl.height = phaseEl.clientHeight * (window.devicePixelRatio || 1);
        phaseCtx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);

        const w = phaseEl.clientWidth;
        const h = phaseEl.clientHeight;
        const cx = w / 2;
        const cy = h / 2;

        phaseCtx.clearRect(0, 0, w, h);

        // Draw reticle cross
        phaseCtx.strokeStyle = 'rgba(255,255,255,0.08)';
        phaseCtx.lineWidth = 1;
        phaseCtx.beginPath();
        phaseCtx.moveTo(cx, 0); phaseCtx.lineTo(cx, h);
        phaseCtx.moveTo(0, cy); phaseCtx.lineTo(w, cy);
        phaseCtx.stroke();

        this.engine.getLissajousData(this.lissajousL, this.lissajousR);

        phaseCtx.strokeStyle = '#10b981';
        phaseCtx.lineWidth = 1.2;
        phaseCtx.beginPath();

        for (let i = 0; i < this.lissajousL.length; i++) {
          const l = this.lissajousL[i];
          const r = this.lissajousR[i];
          // 45 degree rotation for stereo Lissajous
          const x = cx + ((l - r) * (w * 0.42));
          const y = cy - ((l + r) * (h * 0.42));
          if (i === 0) phaseCtx.moveTo(x, y);
          else phaseCtx.lineTo(x, y);
        }
        phaseCtx.stroke();
      }

      this.animId = requestAnimationFrame(render);
    };

    this.animId = requestAnimationFrame(render);
  }
}
