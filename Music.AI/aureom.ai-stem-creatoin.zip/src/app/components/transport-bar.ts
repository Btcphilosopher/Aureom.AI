import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';

@Component({
  selector: 'app-transport-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-14 bg-[#11141b] border-t border-white/5 px-4 flex items-center justify-between text-xs select-none">
      <!-- Left: Playback & Transport Controls -->
      <div class="flex items-center gap-2">
        <!-- Stop -->
        <button
          (click)="stop()"
          class="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 active:bg-white/15 flex items-center justify-center text-slate-300 transition-colors"
          title="Stop (Return to 00:00:00)"
          aria-label="Stop playback"
        >
          <mat-icon class="text-base">stop</mat-icon>
        </button>

        <!-- Play / Pause -->
        <button
          (click)="togglePlay()"
          class="h-8 px-4 rounded-lg flex items-center gap-1.5 font-medium transition-colors cursor-pointer"
          [class]="engine.isPlaying() ? 'bg-amber-500 text-black hover:bg-amber-400' : 'bg-white text-black hover:bg-slate-200'"
          title="Play / Pause (Spacebar)"
          aria-label="Toggle playback"
        >
          <mat-icon class="text-base">{{ engine.isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
          <span class="tracking-wide">{{ engine.isPlaying() ? 'Pause' : 'Play' }}</span>
        </button>

        <!-- Loop Toggle -->
        <button
          (click)="toggleLoop()"
          class="h-8 px-2.5 rounded-lg border flex items-center gap-1 transition-colors cursor-pointer"
          [class]="engine.loopEnabled() ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' : 'bg-transparent border-white/10 text-slate-400 hover:text-white'"
          title="Toggle Loop Region"
          aria-label="Toggle loop"
        >
          <mat-icon class="text-sm">repeat</mat-icon>
          <span class="hidden sm:inline">Loop</span>
        </button>

        <div class="h-5 w-px bg-white/10 mx-1"></div>

        <!-- Timecode Display -->
        <div class="flex items-center gap-2 bg-[#0a0c10] border border-white/10 px-3 py-1 rounded-lg">
          <div class="flex flex-col">
            <span class="text-[9px] text-slate-500 font-mono tracking-wider">TIME</span>
            <span class="font-mono text-sm font-semibold text-amber-300 tracking-wider tabular-nums">
              {{ formattedTime() }}
            </span>
          </div>
          <div class="h-4 w-px bg-white/10 mx-1"></div>
          <div class="flex flex-col">
            <span class="text-[9px] text-slate-500 font-mono tracking-wider">BAR</span>
            <span class="font-mono text-xs text-slate-300 tabular-nums">
              {{ currentBar() }}
            </span>
          </div>
        </div>

        <!-- BPM & Signature -->
        <div class="hidden md:flex items-center gap-2 bg-[#0a0c10] border border-white/10 px-3 py-1 rounded-lg">
          <div class="flex flex-col">
            <span class="text-[9px] text-slate-500 font-mono">TEMPO</span>
            <div class="flex items-center gap-1">
              <span class="font-mono text-xs font-medium text-slate-200 tabular-nums">{{ project.projectBpm() }}</span>
              <span class="text-[10px] text-slate-500 font-mono">BPM</span>
            </div>
          </div>
          <div class="h-4 w-px bg-white/10 mx-0.5"></div>
          <div class="flex flex-col">
            <span class="text-[9px] text-slate-500 font-mono">METER</span>
            <span class="font-mono text-xs text-slate-200">{{ project.timeSignature() }}</span>
          </div>
        </div>
      </div>

      <!-- Center: Loop bounds & Project title badge -->
      <div class="hidden lg:flex items-center gap-4 text-slate-400">
        <div class="flex items-center gap-1.5 text-[11px] font-mono">
          <span class="text-slate-500">RANGE</span>
          <span class="text-slate-300 tabular-nums">{{ engine.loopStart().toFixed(2) }}s</span>
          <span class="text-slate-600">→</span>
          <span class="text-slate-300 tabular-nums">{{ engine.loopEnd().toFixed(2) }}s</span>
        </div>
        <span class="text-white/10">|</span>
        <div class="flex items-center gap-1.5 text-[11px] font-mono">
          <span class="text-slate-500">SAMPLE</span>
          <span class="text-slate-300 tabular-nums">{{ engine.sampleRate() / 1000 }} kHz</span>
          <span class="text-slate-600">·</span>
          <span class="text-slate-300">{{ project.bitDepth() }}-bit</span>
        </div>
      </div>

      <!-- Right: Master Output, VU Meter & Master Fader -->
      <div class="flex items-center gap-3">
        <!-- Master LUFS readout -->
        <div class="hidden sm:flex flex-col items-end">
          <span class="text-[9px] text-slate-500 font-mono">INTEGRATED</span>
          <span class="font-mono text-xs text-amber-400 font-medium tabular-nums">
            {{ engine.masterLufs() }} LUFS
          </span>
        </div>

        <!-- Master Stereo VU Meter -->
        <div class="flex items-center gap-1 bg-[#0a0c10] border border-white/10 p-1.5 rounded-lg">
          <div class="flex flex-col gap-1 w-20">
            <!-- Left Channel Meter -->
            <div class="h-1.5 bg-neutral-900 rounded-sm overflow-hidden flex">
              <div
                class="h-full transition-all duration-75"
                [style.width.%]="getMeterWidth(engine.masterPeakL())"
                [class]="engine.masterPeakL() > -0.5 ? 'bg-rose-500' : engine.masterPeakL() > -6 ? 'bg-amber-400' : 'bg-emerald-500'"
              ></div>
            </div>
            <!-- Right Channel Meter -->
            <div class="h-1.5 bg-neutral-900 rounded-sm overflow-hidden flex">
              <div
                class="h-full transition-all duration-75"
                [style.width.%]="getMeterWidth(engine.masterPeakR())"
                [class]="engine.masterPeakR() > -0.5 ? 'bg-rose-500' : engine.masterPeakR() > -6 ? 'bg-amber-400' : 'bg-emerald-500'"
              ></div>
            </div>
          </div>
          <!-- Peak Clip LED -->
          <div
            class="w-2.5 h-4 rounded-xs border border-black/40 flex items-center justify-center transition-colors"
            [class]="engine.isMasterClipping() ? 'bg-rose-500 shadow-sm shadow-rose-500/50' : 'bg-neutral-800'"
            title="Clip indicator (> -0.1 dBFS)"
          >
            <span class="text-[7px] text-black font-mono font-bold leading-none">C</span>
          </div>
        </div>

        <!-- Master Fader Slider -->
        <div class="flex items-center gap-2">
          <mat-icon class="text-sm text-slate-400">volume_up</mat-icon>
          <input
            type="range"
            min="0"
            max="1.5"
            step="0.01"
            [value]="engine.masterVolume()"
            (input)="onMasterVolumeChange($event)"
            class="w-20 md:w-28 studio-fader h-1.5 cursor-pointer"
            title="Master Bus Output Gain"
            aria-label="Master volume"
          />
          <span class="font-mono text-[11px] text-slate-400 w-10 text-right tabular-nums">
            {{ formatDb(engine.masterVolume()) }}
          </span>
        </div>
      </div>
    </div>
  `
})
export class TransportBar {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);

  readonly formattedTime = computed(() => {
    const sec = this.engine.currentTime();
    const minutes = Math.floor(sec / 60);
    const seconds = Math.floor(sec % 60);
    const centis = Math.floor((sec % 1) * 100);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(centis).padStart(2, '0')}`;
  });

  readonly currentBar = computed(() => {
    const sec = this.engine.currentTime();
    const bpm = this.project.projectBpm();
    const beatSec = 60 / bpm;
    const currentBeat = Math.floor(sec / beatSec);
    const bar = Math.floor(currentBeat / 4) + 1;
    const beatInBar = (currentBeat % 4) + 1;
    return `${bar}.${beatInBar}`;
  });

  togglePlay() {
    if (this.engine.isPlaying()) {
      this.engine.pause();
    } else {
      this.engine.play();
    }
  }

  stop() {
    this.engine.stop();
  }

  toggleLoop() {
    this.engine.setLoop(!this.engine.loopEnabled());
  }

  onMasterVolumeChange(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setMasterVolume(val);
  }

  formatDb(gain: number): string {
    if (gain <= 0.001) return '-inf';
    const db = 20 * Math.log10(gain);
    return `${db > 0 ? '+' : ''}${db.toFixed(1)} dB`;
  }

  getMeterWidth(db: number): number {
    if (db <= -60) return 0;
    // Map -60 dB to 0% and +3 dB to 100%
    const normalized = (db + 60) / 63;
    return Math.max(0, Math.min(100, normalized * 100));
  }
}
