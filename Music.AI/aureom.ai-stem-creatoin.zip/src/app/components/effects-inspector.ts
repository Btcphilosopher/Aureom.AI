import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';
import { StemTrack } from '../models/audio.types';

@Component({
  selector: 'app-effects-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-y-auto select-none p-4">
      <!-- Inspector Header & Track Switcher -->
      <div class="h-10 bg-[#11141b] border border-white/5 rounded-t-xl px-4 flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div class="flex items-center gap-3">
          <span class="font-display font-semibold text-slate-100">Effects & DSP Inspector</span>
          <span class="text-white/10">|</span>
          <span class="text-slate-400 font-mono text-[11px]">ACTIVE CHANNEL:</span>
          <!-- Track Selector -->
          <div class="flex items-center gap-1.5 bg-[#0a0c10] border border-white/10 px-2 py-0.5 rounded-md">
            <span class="w-2 h-2 rounded-full" [style.backgroundColor]="activeTrack().color"></span>
            <span class="font-semibold text-white">{{ activeTrack().name }}</span>
          </div>
        </div>

        <!-- Quick Switch Track Buttons -->
        <div class="flex items-center gap-1 text-[11px]">
          @for (track of engine.tracks(); track track.id) {
            <button
              (click)="project.setSelectedTrack(track.id)"
              class="px-2 py-0.5 rounded-sm transition-colors cursor-pointer font-medium"
              [class]="project.selectedTrackId() === track.id ? 'bg-amber-500 text-black font-semibold' : 'bg-white/5 text-slate-400 hover:text-white'"
            >
              {{ track.stemType | uppercase }}
            </button>
          }
        </div>
      </div>

      <!-- Main DSP Rack Modules -->
      @if (activeTrack(); as track) {
        <div class="bg-[#0d0f14] border-x border-b border-white/5 rounded-b-xl p-5 flex flex-col gap-6">

          <!-- 1. 4-BAND PARAMETRIC EQUALIZER -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400 text-sm">equalizer</mat-icon>
                <span class="font-display font-semibold text-xs text-slate-200">Aureom Precision 4-Band Parametric EQ</span>
              </div>
              <button
                (click)="toggleEq(track)"
                class="px-2.5 py-0.5 rounded-md text-[11px] font-mono font-medium transition-colors cursor-pointer"
                [class]="track.eq.enabled ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300' : 'bg-white/5 text-slate-500'"
              >
                {{ track.eq.enabled ? 'BYPASS: OFF' : 'BYPASSED' }}
              </button>
            </div>

            <!-- EQ Response Curve Canvas Preview -->
            <div class="h-32 bg-[#090b0f] border border-white/10 rounded-lg relative overflow-hidden flex items-center justify-center p-2">
              <!-- Frequency grid background -->
              <div class="absolute inset-0 flex justify-between pointer-events-none opacity-20 px-4">
                <span class="text-[9px] font-mono text-slate-500 mt-1">50 Hz</span>
                <span class="text-[9px] font-mono text-slate-500 mt-1">200 Hz</span>
                <span class="text-[9px] font-mono text-slate-500 mt-1">1 kHz</span>
                <span class="text-[9px] font-mono text-slate-500 mt-1">5 kHz</span>
                <span class="text-[9px] font-mono text-slate-500 mt-1">16 kHz</span>
              </div>

              <!-- EQ Curve SVG Path -->
              <svg class="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
                <!-- 0 dB Center Line -->
                <line x1="0" y1="50" x2="400" y2="50" stroke="rgba(255,255,255,0.1)" stroke-width="1" stroke-dasharray="2,2" />
                <!-- Filter curve -->
                <path
                  [attr.d]="computeEqPath(track)"
                  fill="none"
                  stroke="#f59e0b"
                  stroke-width="2.5"
                />
              </svg>
            </div>

            <!-- EQ 4 Bands Parameter Controls -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
              <!-- Band 1: Low Shelf -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-2">
                <div class="flex items-center justify-between text-slate-400">
                  <span class="text-amber-400 font-semibold">1. LOW SHELF</span>
                  <span class="text-slate-300 tabular-nums">{{ track.eq.lowFreq }} Hz</span>
                </div>
                <div class="flex flex-col gap-1">
                  <span class="text-[10px] text-slate-500">GAIN (dB)</span>
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="0.5"
                    [value]="track.eq.lowGain"
                    (input)="updateEqParam(track, 'lowGain', $event)"
                    class="studio-fader h-1 cursor-pointer"
                  />
                  <span class="text-right text-[11px] text-slate-300 tabular-nums">
                    {{ track.eq.lowGain > 0 ? '+' : '' }}{{ track.eq.lowGain }} dB
                  </span>
                </div>
              </div>

              <!-- Band 2: Mid 1 Peaking -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-2">
                <div class="flex items-center justify-between text-slate-400">
                  <span class="text-indigo-400 font-semibold">2. LOW-MID</span>
                  <span class="text-slate-300 tabular-nums">{{ track.eq.mid1Freq }} Hz</span>
                </div>
                <div class="flex flex-col gap-1">
                  <span class="text-[10px] text-slate-500">GAIN (dB)</span>
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="0.5"
                    [value]="track.eq.mid1Gain"
                    (input)="updateEqParam(track, 'mid1Gain', $event)"
                    class="studio-fader h-1 cursor-pointer"
                  />
                  <span class="text-right text-[11px] text-slate-300 tabular-nums">
                    {{ track.eq.mid1Gain > 0 ? '+' : '' }}{{ track.eq.mid1Gain }} dB
                  </span>
                </div>
              </div>

              <!-- Band 3: Mid 2 Peaking -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-2">
                <div class="flex items-center justify-between text-slate-400">
                  <span class="text-sky-400 font-semibold">3. HIGH-MID</span>
                  <span class="text-slate-300 tabular-nums">{{ track.eq.mid2Freq }} Hz</span>
                </div>
                <div class="flex flex-col gap-1">
                  <span class="text-[10px] text-slate-500">GAIN (dB)</span>
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="0.5"
                    [value]="track.eq.mid2Gain"
                    (input)="updateEqParam(track, 'mid2Gain', $event)"
                    class="studio-fader h-1 cursor-pointer"
                  />
                  <span class="text-right text-[11px] text-slate-300 tabular-nums">
                    {{ track.eq.mid2Gain > 0 ? '+' : '' }}{{ track.eq.mid2Gain }} dB
                  </span>
                </div>
              </div>

              <!-- Band 4: High Shelf -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-2">
                <div class="flex items-center justify-between text-slate-400">
                  <span class="text-emerald-400 font-semibold">4. HIGH SHELF</span>
                  <span class="text-slate-300 tabular-nums">{{ track.eq.highFreq }} Hz</span>
                </div>
                <div class="flex flex-col gap-1">
                  <span class="text-[10px] text-slate-500">GAIN (dB)</span>
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="0.5"
                    [value]="track.eq.highGain"
                    (input)="updateEqParam(track, 'highGain', $event)"
                    class="studio-fader h-1 cursor-pointer"
                  />
                  <span class="text-right text-[11px] text-slate-300 tabular-nums">
                    {{ track.eq.highGain > 0 ? '+' : '' }}{{ track.eq.highGain }} dB
                  </span>
                </div>
              </div>
            </div>
          </div>

          <!-- 2. DYNAMICS COMPRESSOR -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-indigo-400 text-sm">compress</mat-icon>
                <span class="font-display font-semibold text-xs text-slate-200">Aureom Studio VCA Dynamics Compressor</span>
              </div>
              <button
                (click)="toggleComp(track)"
                class="px-2.5 py-0.5 rounded-md text-[11px] font-mono font-medium transition-colors cursor-pointer"
                [class]="track.compressor.enabled ? 'bg-indigo-500/15 border border-indigo-500/40 text-indigo-300' : 'bg-white/5 text-slate-500'"
              >
                {{ track.compressor.enabled ? 'COMPRESSOR: ACTIVE' : 'BYPASSED' }}
              </button>
            </div>

            <!-- Compressor Knobs / Sliders -->
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 text-xs font-mono">
              <!-- Threshold -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">THRESHOLD</span>
                <input
                  type="range"
                  min="-60"
                  max="0"
                  step="1"
                  [value]="track.compressor.threshold"
                  (input)="updateCompParam(track, 'threshold', $event)"
                  class="studio-fader h-1 cursor-pointer"
                />
                <span class="font-bold text-white tabular-nums">{{ track.compressor.threshold }} dB</span>
              </div>

              <!-- Ratio -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">RATIO</span>
                <input
                  type="range"
                  min="1"
                  max="20"
                  step="0.5"
                  [value]="track.compressor.ratio"
                  (input)="updateCompParam(track, 'ratio', $event)"
                  class="studio-fader h-1 cursor-pointer"
                />
                <span class="font-bold text-white tabular-nums">{{ track.compressor.ratio.toFixed(1) }}:1</span>
              </div>

              <!-- Attack -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">ATTACK</span>
                <input
                  type="range"
                  min="0.001"
                  max="0.1"
                  step="0.002"
                  [value]="track.compressor.attack"
                  (input)="updateCompParam(track, 'attack', $event)"
                  class="studio-fader h-1 cursor-pointer"
                />
                <span class="font-bold text-white tabular-nums">{{ (track.compressor.attack * 1000).toFixed(0) }} ms</span>
              </div>

              <!-- Release -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">RELEASE</span>
                <input
                  type="range"
                  min="0.05"
                  max="1.0"
                  step="0.05"
                  [value]="track.compressor.release"
                  (input)="updateCompParam(track, 'release', $event)"
                  class="studio-fader h-1 cursor-pointer"
                />
                <span class="font-bold text-white tabular-nums">{{ (track.compressor.release * 1000).toFixed(0) }} ms</span>
              </div>

              <!-- Gain Reduction Meter -->
              <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex flex-col justify-between">
                <span class="text-slate-500 text-[10px]">GAIN REDUCTION</span>
                <div class="h-3 bg-neutral-900 rounded-sm overflow-hidden flex flex-col justify-end">
                  <div
                    class="h-full bg-rose-500 transition-all duration-75"
                    [style.width.%]="track.compressor.enabled && track.currentPeakDbfs > track.compressor.threshold ? Math.min(100, (track.currentPeakDbfs - track.compressor.threshold) * 5) : 0"
                  ></div>
                </div>
                <span class="text-right text-[10px] text-rose-400 font-bold tabular-nums">
                  -{{ track.compressor.enabled && track.currentPeakDbfs > track.compressor.threshold ? ((track.currentPeakDbfs - track.compressor.threshold) * 0.4).toFixed(1) : '0.0' }} dB
                </span>
              </div>
            </div>
          </div>

          <!-- 3. SPATIAL & RESTORATION MODULE SUMMARY -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <!-- Stereo Imaging & Pan -->
            <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
              <span class="font-display font-semibold text-xs text-slate-200">Stereo Field & Pan Balancing</span>
              <div class="flex items-center justify-between text-xs font-mono">
                <span class="text-slate-400">STEREO PAN:</span>
                <span class="font-semibold text-amber-300">
                  {{ track.pan === 0 ? 'CENTER (0.0)' : track.pan < 0 ? 'LEFT ' + Math.abs(track.pan).toFixed(2) : 'RIGHT ' + track.pan.toFixed(2) }}
                </span>
              </div>
              <input
                type="range"
                min="-1"
                max="1"
                step="0.02"
                [value]="track.pan"
                (input)="onTrackPanChange(track.id, $event)"
                class="studio-fader h-1.5 cursor-pointer"
              />
            </div>

            <!-- Clip Gain Calibration -->
            <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
              <span class="font-display font-semibold text-xs text-slate-200">Pre-FX Clip Gain Calibration</span>
              <div class="flex items-center justify-between text-xs font-mono">
                <span class="text-slate-400">TRIM GAIN:</span>
                <span class="font-semibold text-white tabular-nums">{{ track.clipGain > 0 ? '+' : '' }}{{ track.clipGain }} dB</span>
              </div>
              <input
                type="range"
                min="-18"
                max="18"
                step="0.5"
                [value]="track.clipGain"
                (input)="onClipGainChange(track.id, $event)"
                class="studio-fader h-1.5 cursor-pointer"
              />
            </div>
          </div>

        </div>
      }
    </div>
  `
})
export class EffectsInspector {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);
  readonly Math = Math;

  readonly activeTrack = computed(() => {
    return this.engine.tracks().find(t => t.id === this.project.selectedTrackId()) || this.engine.tracks()[0];
  });

  toggleEq(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      eq: { ...track.eq, enabled: !track.eq.enabled }
    });
  }

  toggleComp(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      compressor: { ...track.compressor, enabled: !track.compressor.enabled }
    });
  }

  updateEqParam(track: StemTrack, param: keyof StemTrack['eq'], e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({
      id: track.id,
      eq: { ...track.eq, [param]: val }
    });
  }

  updateCompParam(track: StemTrack, param: keyof StemTrack['compressor'], e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({
      id: track.id,
      compressor: { ...track.compressor, [param]: val }
    });
  }

  onTrackPanChange(trackId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setTrackPan(trackId, val);
  }

  onClipGainChange(trackId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({ id: trackId, clipGain: val });
  }

  computeEqPath(track: StemTrack): string {
    // Generates smooth SVG curve representing the 4-band filter frequency response
    const lowY = 50 - (track.eq.lowGain * 3);
    const mid1Y = 50 - (track.eq.mid1Gain * 3);
    const mid2Y = 50 - (track.eq.mid2Gain * 3);
    const highY = 50 - (track.eq.highGain * 3);

    return `M 0,${lowY} C 80,${lowY} 120,${mid1Y} 160,${mid1Y} C 200,${mid1Y} 240,${mid2Y} 280,${mid2Y} C 320,${mid2Y} 360,${highY} 400,${highY}`;
  }
}
