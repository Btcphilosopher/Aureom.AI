import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';
import { StemTrack } from '../models/audio.types';

@Component({
  selector: 'app-restoration-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-y-auto select-none p-4 md:p-6">
      <!-- Title & Header -->
      <div class="flex flex-col gap-1 pb-4 border-b border-white/5">
        <div class="flex items-center gap-2">
          <div class="w-6 h-6 rounded-md bg-rose-500/20 text-rose-400 flex items-center justify-center">
            <mat-icon class="text-sm">cleaning_services</mat-icon>
          </div>
          <h2 class="font-display text-lg font-bold text-white tracking-tight">
            Aureom Restoration & Cleanup Lab
          </h2>
        </div>
        <p class="text-xs text-slate-400">
          Non-destructive post-separation cleanup. Clean residual bleed, eliminate vocal sibilance, remove mains ground hum, and sharpen transient dynamics.
        </p>
      </div>

      <!-- Active Channel Selector Ribbon -->
      <div class="flex items-center gap-2 pt-4">
        <span class="text-xs font-mono text-slate-500">TARGET STEM:</span>
        <div class="flex items-center gap-1.5">
          @for (track of engine.tracks(); track track.id) {
            <button
              (click)="project.setSelectedTrack(track.id)"
              class="px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5"
              [class]="project.selectedTrackId() === track.id ? 'bg-amber-500 text-black font-semibold' : 'bg-white/5 text-slate-400 hover:text-white'"
            >
              <span class="w-2 h-2 rounded-full" [style.backgroundColor]="track.color"></span>
              <span>{{ track.name }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Main Restoration Modules Grid -->
      @if (activeTrack(); as track) {
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-5">
          
          <!-- 1. VOCAL DE-ESSER -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-rose-400 text-sm">record_voice_over</mat-icon>
                <span class="font-display font-semibold text-xs text-slate-200">Dynamic Vocal De-Esser</span>
              </div>
              <button
                (click)="toggleDeEsser(track)"
                class="px-2.5 py-0.5 rounded-md text-[11px] font-mono cursor-pointer"
                [class]="track.restoration.deEsser ? 'bg-rose-500/15 border border-rose-500/40 text-rose-300' : 'bg-white/5 text-slate-500'"
              >
                {{ track.restoration.deEsser ? 'ACTIVE' : 'BYPASSED' }}
              </button>
            </div>

            <p class="text-xs text-slate-400">
              Targets harsh high-frequency 'S' and 'T' sibilance between 5 kHz and 9 kHz using dynamic band attenuation.
            </p>

            <div class="flex flex-col gap-2 font-mono text-xs">
              <div class="flex justify-between text-slate-300">
                <span class="text-slate-500">REDUCTION AMOUNT</span>
                <span class="text-rose-400 font-bold tabular-nums">{{ track.restoration.deEsserAmount }}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                [value]="track.restoration.deEsserAmount"
                (input)="onDeEsserAmountChange(track, $event)"
                class="studio-fader h-1.5 cursor-pointer"
              />
            </div>

            <div class="bg-[#0a0c10] border border-white/5 p-3 rounded-lg flex items-center justify-between text-xs font-mono">
              <span class="text-slate-500">DETECTION BAND:</span>
              <span class="text-slate-200 font-semibold">6,800 Hz (Bell Q=2.4)</span>
            </div>
          </div>

          <!-- 2. MAINS GROUND HUM NOTCH FILTER -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400 text-sm">electrical_services</mat-icon>
                <span class="font-display font-semibold text-xs text-slate-200">Ground Hum Eliminator (50 / 60 Hz)</span>
              </div>
              <button
                (click)="toggleDeHum(track)"
                class="px-2.5 py-0.5 rounded-md text-[11px] font-mono cursor-pointer"
                [class]="track.restoration.deHum ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300' : 'bg-white/5 text-slate-500'"
              >
                {{ track.restoration.deHum ? 'NOTCH ACTIVE' : 'BYPASSED' }}
              </button>
            </div>

            <p class="text-xs text-slate-400">
              Narrow steep Q notch filters at 50 Hz (UK/EU) and 60 Hz (US) mains hum and their 2nd harmonics.
            </p>

            <div class="grid grid-cols-2 gap-3 text-xs font-mono">
              <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                <span class="text-slate-500 text-[10px]">UK/EU 50 Hz NOTCH</span>
                <span class="text-emerald-400 font-bold">-36 dB Attenuation</span>
              </div>
              <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                <span class="text-slate-500 text-[10px]">US 60 Hz NOTCH</span>
                <span class="text-emerald-400 font-bold">-36 dB Attenuation</span>
              </div>
            </div>
          </div>

          <!-- 3. TRANSIENT SHAPER -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-sm">speed</mat-icon>
                <span class="font-display font-semibold text-xs text-slate-200">Aureom Transient Shaper (Punch & Sustain)</span>
              </div>
              <span class="text-[10px] font-mono text-emerald-400">DUAL ENVELOPE</span>
            </div>

            <p class="text-xs text-slate-400">
              Boost or tame initial stick-hit attack transients and control ring sustain on drums and percussion.
            </p>

            <div class="grid grid-cols-2 gap-4 font-mono text-xs">
              <div class="flex flex-col gap-1.5">
                <div class="flex justify-between text-slate-300">
                  <span class="text-slate-500">ATTACK PUNCH</span>
                  <span class="text-amber-400 font-bold tabular-nums">
                    {{ track.restoration.transientAttack > 0 ? '+' : '' }}{{ track.restoration.transientAttack }} dB
                  </span>
                </div>
                <input
                  type="range"
                  min="-6"
                  max="6"
                  step="0.5"
                  [value]="track.restoration.transientAttack"
                  (input)="onTransientAttackChange(track, $event)"
                  class="studio-fader h-1.5 cursor-pointer"
                />
              </div>

              <div class="flex flex-col gap-1.5">
                <div class="flex justify-between text-slate-300">
                  <span class="text-slate-500">SUSTAIN TAIL</span>
                  <span class="text-amber-400 font-bold tabular-nums">
                    {{ track.restoration.transientSustain > 0 ? '+' : '' }}{{ track.restoration.transientSustain }} dB
                  </span>
                </div>
                <input
                  type="range"
                  min="-6"
                  max="6"
                  step="0.5"
                  [value]="track.restoration.transientSustain"
                  (input)="onTransientSustainChange(track, $event)"
                  class="studio-fader h-1.5 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <!-- 4. ADAPTIVE NOISE GATE -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-indigo-400 text-sm">shield</mat-icon>
                <span class="font-display font-semibold text-xs text-slate-200">Adaptive Spectral Noise Gate</span>
              </div>
              <button
                (click)="toggleNoiseGate(track)"
                class="px-2.5 py-0.5 rounded-md text-[11px] font-mono cursor-pointer"
                [class]="track.restoration.noiseGate ? 'bg-indigo-500/15 border border-indigo-500/40 text-indigo-300' : 'bg-white/5 text-slate-500'"
              >
                {{ track.restoration.noiseGate ? 'GATE: CLOSED' : 'BYPASSED' }}
              </button>
            </div>

            <p class="text-xs text-slate-400">
              Mutes quiet inter-phrase background room hiss, microphone bleed, and amplifier buzz beneath the threshold.
            </p>

            <div class="flex flex-col gap-2 font-mono text-xs">
              <div class="flex justify-between text-slate-300">
                <span class="text-slate-500">GATE THRESHOLD</span>
                <span class="text-indigo-300 font-bold tabular-nums">{{ track.restoration.gateThreshold }} dB</span>
              </div>
              <input
                type="range"
                min="-60"
                max="-10"
                step="1"
                [value]="track.restoration.gateThreshold"
                (input)="onGateThresholdChange(track, $event)"
                class="studio-fader h-1.5 cursor-pointer"
              />
            </div>
          </div>

        </div>
      }
    </div>
  `
})
export class RestorationView {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);

  readonly activeTrack = computed(() => {
    return this.engine.tracks().find(t => t.id === this.project.selectedTrackId()) || this.engine.tracks()[0];
  });

  toggleDeEsser(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, deEsser: !track.restoration.deEsser }
    });
    this.project.recordAction(`Toggled De-Esser on ${track.name}`, 'effect');
  }

  toggleDeHum(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, deHum: !track.restoration.deHum }
    });
    this.project.recordAction(`Toggled Hum Filter on ${track.name}`, 'effect');
  }

  toggleNoiseGate(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, noiseGate: !track.restoration.noiseGate }
    });
    this.project.recordAction(`Toggled Noise Gate on ${track.name}`, 'effect');
  }

  onDeEsserAmountChange(track: StemTrack, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, deEsserAmount: val }
    });
  }

  onTransientAttackChange(track: StemTrack, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, transientAttack: val }
    });
  }

  onTransientSustainChange(track: StemTrack, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, transientSustain: val }
    });
  }

  onGateThresholdChange(track: StemTrack, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.updateTrack({
      id: track.id,
      restoration: { ...track.restoration, gateThreshold: val }
    });
  }
}
