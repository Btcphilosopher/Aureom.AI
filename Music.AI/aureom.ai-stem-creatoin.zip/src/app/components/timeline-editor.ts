import { ChangeDetectionStrategy, Component, inject, ElementRef, viewChild, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';

@Component({
  selector: 'app-timeline-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0d0f14] overflow-hidden select-none">
      <!-- Timeline Control Header: Track tools, Zoom, Grid, Markers -->
      <div class="h-9 bg-[#11141b] border-b border-white/5 px-4 flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div class="flex items-center gap-3">
          <span class="font-display font-semibold text-slate-200">Multitrack Timeline</span>
          <span class="text-white/10">|</span>
          <div class="flex items-center gap-1.5">
            <button
              (click)="project.snapToGrid.set(!project.snapToGrid())"
              class="h-6 px-2 rounded-sm border flex items-center gap-1 text-[11px] cursor-pointer"
              [class]="project.snapToGrid() ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-transparent border-white/10 text-slate-400'"
              title="Snap to 16th Note Musical Grid"
            >
              <mat-icon class="text-xs">grid_4x4</mat-icon>
              <span>Snap Grid</span>
            </button>
          </div>
        </div>

        <!-- Zoom & Markers Quick Jump -->
        <div class="flex items-center gap-3">
          <!-- Markers -->
          <div class="hidden sm:flex items-center gap-1 text-[11px]">
            <span class="text-slate-500 text-[10px] font-mono mr-1">CUE:</span>
            @for (marker of project.markers(); track marker.id) {
              <button
                (click)="jumpToMarker(marker.time)"
                class="px-1.5 py-0.5 rounded-sm hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1 font-mono"
              >
                <span class="w-1.5 h-1.5 rounded-full" [style.backgroundColor]="marker.color"></span>
                <span>{{ marker.name }}</span>
              </button>
            }
          </div>

          <div class="h-4 w-px bg-white/10 mx-1"></div>

          <!-- Zoom In / Out -->
          <div class="flex items-center gap-1">
            <button
              (click)="adjustZoom(-0.25)"
              class="w-6 h-6 rounded-sm bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 cursor-pointer"
              title="Zoom Out"
            >
              <mat-icon class="text-xs">zoom_out</mat-icon>
            </button>
            <span class="font-mono text-[11px] text-slate-400 w-8 text-center tabular-nums">
              {{ (project.zoomLevel() * 100).toFixed(0) }}%
            </span>
            <button
              (click)="adjustZoom(0.25)"
              class="w-6 h-6 rounded-sm bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 cursor-pointer"
              title="Zoom In"
            >
              <mat-icon class="text-xs">zoom_in</mat-icon>
            </button>
          </div>
        </div>
      </div>

      <!-- Main Timeline Workspace: Left Track Controls + Right Waveform Canvas -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Left: Track Control Headers (fixed width) -->
        <div class="w-60 md:w-72 bg-[#0f1218] border-r border-white/5 flex flex-col shrink-0 overflow-y-auto">
          <!-- Track Header Spacer matching Ruler height -->
          <div class="h-8 bg-[#141720] border-b border-white/5 px-3 flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span>TRACK / STEMS</span>
            <span class="text-[10px] text-slate-500">{{ engine.tracks().length }} ACTIVE</span>
          </div>

          <!-- List of Tracks -->
          @for (track of engine.tracks(); track track.id) {
            <div
              tabindex="0"
              role="button"
              (click)="project.setSelectedTrack(track.id)"
              (keydown.enter)="project.setSelectedTrack(track.id)"
              class="h-28 border-b border-white/5 p-3 flex flex-col justify-between transition-colors cursor-pointer"
              [class]="project.selectedTrackId() === track.id ? 'bg-[#181d27]' : 'bg-[#0f1218] hover:bg-[#13161f]'"
            >
              <!-- Top Row: Color indicator, Name, Solo/Mute -->
              <div class="flex items-center justify-between gap-2">
                <div class="flex items-center gap-2 truncate">
                  <span class="w-2.5 h-2.5 rounded-full shrink-0" [style.backgroundColor]="track.color"></span>
                  <span class="font-semibold text-xs text-slate-100 truncate" [title]="track.name">
                    {{ track.name }}
                  </span>
                </div>

                <!-- Solo / Mute buttons -->
                <div class="flex items-center gap-1 shrink-0">
                  <button
                    (click)="engine.toggleMute(track.id); $event.stopPropagation()"
                    class="w-5 h-5 rounded-xs font-mono font-bold text-[10px] flex items-center justify-center transition-colors cursor-pointer"
                    [class]="track.muted ? 'bg-amber-500 text-black' : 'bg-white/5 text-slate-400 hover:text-white'"
                    title="Mute Track"
                  >
                    M
                  </button>
                  <button
                    (click)="engine.toggleSolo(track.id); $event.stopPropagation()"
                    class="w-5 h-5 rounded-xs font-mono font-bold text-[10px] flex items-center justify-center transition-colors cursor-pointer"
                    [class]="track.soloed ? 'bg-indigo-500 text-white' : 'bg-white/5 text-slate-400 hover:text-white'"
                    title="Solo Track"
                  >
                    S
                  </button>
                </div>
              </div>

              <!-- Middle Row: Volume Slider & Pan Slider -->
              <div class="flex flex-col gap-1.5 text-[10px] font-mono text-slate-400">
                <!-- Volume -->
                <div class="flex items-center justify-between gap-2">
                  <span class="text-slate-500">VOL</span>
                  <input
                    type="range"
                    min="0"
                    max="1.5"
                    step="0.01"
                    [value]="track.volume"
                    (input)="onTrackVolumeChange(track.id, $event)"
                    (click)="$event.stopPropagation()"
                    class="flex-1 studio-fader h-1 cursor-pointer"
                  />
                  <span class="w-8 text-right text-slate-300 tabular-nums">
                    {{ (track.volume * 100).toFixed(0) }}%
                  </span>
                </div>

                <!-- Pan -->
                <div class="flex items-center justify-between gap-2">
                  <span class="text-slate-500">PAN</span>
                  <input
                    type="range"
                    min="-1"
                    max="1"
                    step="0.02"
                    [value]="track.pan"
                    (input)="onTrackPanChange(track.id, $event)"
                    (click)="$event.stopPropagation()"
                    class="flex-1 studio-fader h-1 cursor-pointer"
                  />
                  <span class="w-8 text-right text-slate-300 tabular-nums">
                    {{ track.pan === 0 ? 'C' : track.pan < 0 ? 'L' + Math.abs(track.pan * 100).toFixed(0) : 'R' + (track.pan * 100).toFixed(0) }}
                  </span>
                </div>
              </div>

              <!-- Bottom Row: VU Meter & Clip Gain -->
              <div class="flex items-center justify-between text-[10px] font-mono">
                <!-- Mini Peak Meter -->
                <div class="flex-1 h-1 bg-neutral-900 rounded-sm overflow-hidden mr-2">
                  <div
                    class="h-full transition-all duration-75"
                    [style.width.%]="getMeterWidth(track.currentPeakDbfs)"
                    [class]="track.currentPeakDbfs > -0.5 ? 'bg-rose-500' : 'bg-amber-400'"
                  ></div>
                </div>
                <span class="text-slate-400 tabular-nums">
                  {{ track.currentPeakDbfs > -59 ? track.currentPeakDbfs.toFixed(1) + ' dB' : '-inf' }}
                </span>
              </div>
            </div>
          }
        </div>

        <!-- Right: Synchronized Waveform Area & Ruler -->
        <div #timelineScrollContainer class="flex-1 flex flex-col bg-[#0b0d11] overflow-x-auto relative">
          <!-- Time Ruler -->
          <div
            tabindex="0"
            role="slider"
            aria-label="Timeline Ruler"
            [attr.aria-valuenow]="engine.currentTime()"
            (click)="onRulerClick($event)"
            (keydown.enter)="engine.seek(engine.currentTime() + 1)"
            class="h-8 bg-[#141720] border-b border-white/5 relative cursor-pointer select-none shrink-0"
            [style.width.px]="timelineWidth()"
          >
            <!-- Bar Numbers and Tick marks -->
            @for (bar of bars(); track bar.index) {
              <div
                class="absolute top-0 bottom-0 border-l border-white/10 flex flex-col justify-between pl-1 text-[9px] font-mono text-slate-500"
                [style.left.px]="bar.x"
              >
                <span>Bar {{ bar.index }}</span>
                <span class="text-slate-600">{{ bar.sec.toFixed(1) }}s</span>
              </div>
            }

            <!-- Markers on Ruler -->
            @for (marker of project.markers(); track marker.id) {
              <div
                class="absolute top-0 z-20 flex items-center gap-1 px-1 py-0.5 rounded-b-xs text-[9px] font-mono font-medium text-white shadow-xs"
                [style.left.px]="secondsToPx(marker.time)"
                [style.backgroundColor]="marker.color"
              >
                <mat-icon class="text-[10px]">flag</mat-icon>
                <span>{{ marker.name }}</span>
              </div>
            }

            <!-- Loop Region Highlight -->
            @if (engine.loopEnabled()) {
              <div
                class="absolute top-0 bottom-0 bg-amber-500/15 border-x-2 border-amber-500/60 pointer-events-none"
                [style.left.px]="secondsToPx(engine.loopStart())"
                [style.width.px]="secondsToPx(engine.loopEnd() - engine.loopStart())"
              ></div>
            }
          </div>

          <!-- Waveform Tracks Container -->
          <div
            tabindex="0"
            role="region"
            aria-label="Multitrack Waveforms"
            (click)="onWaveformClick($event)"
            (keydown.enter)="engine.seek(engine.currentTime() + 1)"
            class="flex-1 relative cursor-crosshair"
            [style.width.px]="timelineWidth()"
          >
            <!-- Vertical Grid Lines -->
            @for (bar of bars(); track bar.index) {
              <div
                class="absolute top-0 bottom-0 border-l border-white/[0.04] pointer-events-none"
                [style.left.px]="bar.x"
              ></div>
            }

            <!-- Loop Highlight over waveforms -->
            @if (engine.loopEnabled()) {
              <div
                class="absolute top-0 bottom-0 bg-amber-500/5 pointer-events-none"
                [style.left.px]="secondsToPx(engine.loopStart())"
                [style.width.px]="secondsToPx(engine.loopEnd() - engine.loopStart())"
              ></div>
            }

            <!-- Tracks Waveform Rows -->
            @for (track of engine.tracks(); track track.id) {
              <div
                class="h-28 border-b border-white/5 relative p-2 flex items-center"
                [class.opacity-40]="track.muted"
              >
                <!-- Clip Container -->
                <div
                  class="absolute top-2 bottom-2 rounded-lg border overflow-hidden flex items-center justify-center transition-all shadow-sm"
                  [style.left.px]="secondsToPx(track.startTime)"
                  [style.width.px]="secondsToPx(track.duration)"
                  [style.borderColor]="track.color + '66'"
                  [style.backgroundColor]="track.color + '12'"
                >
                  <!-- Waveform SVG Visualization -->
                  <svg
                    class="w-full h-full"
                    preserveAspectRatio="none"
                    viewBox="0 0 300 80"
                  >
                    <!-- Center guide line -->
                    <line x1="0" y1="40" x2="300" y2="40" stroke="rgba(255,255,255,0.08)" stroke-width="1" />
                    <!-- Waveform mirrored bars -->
                    @for (peak of track.peaks; track $index) {
                      <rect
                        [attr.x]="$index * (300 / track.peaks.length)"
                        [attr.y]="40 - (peak * 36)"
                        [attr.width]="Math.max(1, 300 / track.peaks.length - 0.5)"
                        [attr.height]="peak * 72"
                        [attr.fill]="track.color"
                        [attr.fill-opacity]="project.selectedTrackId() === track.id ? '0.85' : '0.6'"
                      />
                    }
                  </svg>

                  <!-- Clip Label -->
                  <div class="absolute top-1 left-2 text-[10px] font-mono px-1.5 py-0.5 rounded-sm bg-black/50 text-slate-200">
                    {{ track.name }} · {{ track.duration.toFixed(1) }}s
                  </div>
                </div>
              </div>
            }

            <!-- Playhead Needle (Real-time scrubber) -->
            <div
              class="absolute top-0 bottom-0 w-px bg-amber-400 z-30 pointer-events-none transition-all duration-75"
              [style.left.px]="playheadX()"
            >
              <!-- Playhead Top Knob -->
              <div class="w-3.5 h-3.5 -ml-1.5 bg-amber-400 rotate-45 rounded-xs shadow-md shadow-amber-400/50"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TimelineEditor {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);
  readonly Math = Math;

  readonly timelineScrollContainer = viewChild<ElementRef<HTMLDivElement>>('timelineScrollContainer');

  // Pixel scaling: default 70px per second * zoom
  readonly pxPerSec = computed(() => 70 * this.project.zoomLevel());

  readonly timelineWidth = computed(() => {
    return Math.max(1000, this.engine.duration() * this.pxPerSec() + 100);
  });

  readonly playheadX = computed(() => {
    return this.engine.currentTime() * this.pxPerSec();
  });

  readonly bars = computed(() => {
    const bpm = this.project.projectBpm();
    const beatSec = 60 / bpm;
    const barSec = beatSec * 4;
    const totalBars = Math.ceil(this.engine.duration() / barSec) + 2;

    const list: { index: number; sec: number; x: number }[] = [];
    for (let b = 0; b < totalBars; b++) {
      const sec = b * barSec;
      list.push({
        index: b + 1,
        sec,
        x: sec * this.pxPerSec()
      });
    }
    return list;
  });

  secondsToPx(sec: number): number {
    return sec * this.pxPerSec();
  }

  jumpToMarker(time: number) {
    this.engine.seek(time);
  }

  adjustZoom(delta: number) {
    const current = this.project.zoomLevel();
    const next = Math.max(0.5, Math.min(3.0, current + delta));
    this.project.zoomLevel.set(next);
  }

  onRulerClick(e: MouseEvent) {
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickedSeconds = clickX / this.pxPerSec();
    this.engine.seek(clickedSeconds);
  }

  onWaveformClick(e: MouseEvent) {
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickedSeconds = clickX / this.pxPerSec();
    this.engine.seek(clickedSeconds);
  }

  onTrackVolumeChange(trackId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setTrackVolume(trackId, val);
  }

  onTrackPanChange(trackId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setTrackPan(trackId, val);
  }

  getMeterWidth(db: number): number {
    if (db <= -60) return 0;
    const normalized = (db + 60) / 63;
    return Math.max(0, Math.min(100, normalized * 100));
  }
}
