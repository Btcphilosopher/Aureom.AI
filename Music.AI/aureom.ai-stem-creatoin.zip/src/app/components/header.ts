import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ProjectState, StudioWorkspace } from '../services/project-state';
import { AudioEngine } from '../services/audio-engine';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <!-- Zone 1, 2, 3 Strict Top Bar Contract -->
    <header class="h-14 bg-[#0d0f14] border-b border-white/10 px-6 flex items-center justify-between gap-8 select-none shrink-0 z-30">
      <!-- Zone 1: Single text wordmark in display font -->
      <div class="flex items-center gap-3 whitespace-nowrap shrink-0">
        <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 flex items-center justify-center shadow-sm shadow-amber-500/20">
          <span class="font-display font-black text-black text-sm tracking-tighter">A</span>
        </div>
        <span class="font-display text-base font-bold tracking-tight text-white">
          Aureom.AI <span class="text-amber-400/90 font-medium">Music</span>
        </span>
      </div>

      <!-- Zone 2: 4-5 Clean single-line navigation links -->
      <nav class="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          (click)="project.setWorkspace('multitrack')"
          class="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5"
          [class.text-amber-400]="project.activeWorkspace() === 'multitrack'"
          [class.border-b-2]="project.activeWorkspace() === 'multitrack'"
          [class.border-amber-400]="project.activeWorkspace() === 'multitrack'"
        >
          Studio
        </button>
        <button
          (click)="project.setWorkspace('mixer')"
          class="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5"
          [class.text-amber-400]="project.activeWorkspace() === 'mixer'"
          [class.border-b-2]="project.activeWorkspace() === 'mixer'"
          [class.border-amber-400]="project.activeWorkspace() === 'mixer'"
        >
          Mixer
        </button>
        <button
          (click)="project.setWorkspace('separation')"
          class="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5"
          [class.text-amber-400]="project.activeWorkspace() === 'separation'"
          [class.border-b-2]="project.activeWorkspace() === 'separation'"
          [class.border-amber-400]="project.activeWorkspace() === 'separation'"
        >
          Separation
        </button>
        <button
          (click)="project.setWorkspace('intelligence')"
          class="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5"
          [class.text-amber-400]="project.activeWorkspace() === 'intelligence'"
          [class.border-b-2]="project.activeWorkspace() === 'intelligence'"
          [class.border-amber-400]="project.activeWorkspace() === 'intelligence'"
        >
          Intelligence
        </button>
        <button
          (click)="project.setWorkspace('export')"
          class="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer pb-0.5"
          [class.text-amber-400]="project.activeWorkspace() === 'export'"
          [class.border-b-2]="project.activeWorkspace() === 'export'"
          [class.border-amber-400]="project.activeWorkspace() === 'export'"
        >
          Export
        </button>
      </nav>

      <!-- Zone 3: 1 Primary Action -->
      <div class="flex items-center gap-3 shrink-0">
        <button
          (click)="project.setWorkspace('separation')"
          class="h-8 px-4 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-black flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-sm shadow-amber-500/20"
        >
          <mat-icon class="text-sm">auto_fix_high</mat-icon>
          <span>Separate Audio</span>
        </button>
      </div>
    </header>

    <!-- Secondary Studio Workspace Bar: Segmented controls for all 19 functional tools -->
    <div class="h-10 bg-[#12151d] border-b border-white/5 px-4 flex items-center justify-between text-xs overflow-x-auto select-none shrink-0">
      <!-- Left: Segmented workspace tabs -->
      <div class="flex items-center gap-1 shrink-0">
        @for (item of workspaceTabs; track item.id) {
          <button
            (click)="project.setWorkspace(item.id)"
            class="h-7 px-2.5 rounded-md flex items-center gap-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
            [class]="project.activeWorkspace() === item.id ? 'bg-[#1e2330] text-amber-300 shadow-xs' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'"
          >
            <mat-icon class="text-sm">{{ item.icon }}</mat-icon>
            <span>{{ item.label }}</span>
          </button>
        }
      </div>

      <!-- Right: Technical Indicators & Project Manifest Actions -->
      <div class="flex items-center gap-3 text-[11px] text-slate-400 shrink-0 ml-4">
        <!-- Project Save Button -->
        <button
          (click)="project.downloadProjectManifest()"
          class="h-7 px-2.5 rounded-md bg-white/5 hover:bg-white/10 text-slate-300 flex items-center gap-1 transition-colors cursor-pointer"
          title="Save & Download .aureomusic Project File"
        >
          <mat-icon class="text-sm">save</mat-icon>
          <span class="hidden sm:inline">.aureomusic</span>
        </button>

        <!-- Quick Launch / Templates -->
        <button
          (click)="project.setWorkspace('launcher')"
          class="h-7 px-2 rounded-md hover:bg-white/5 text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          title="Project Launcher & Templates"
        >
          <mat-icon class="text-sm">folder_open</mat-icon>
        </button>

        <!-- Diagnostics -->
        <button
          (click)="project.setWorkspace('diagnostics')"
          class="h-7 px-2 rounded-md hover:bg-white/5 text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          title="Engine Diagnostics & Self-Test Suite"
        >
          <mat-icon class="text-sm">verified</mat-icon>
        </button>

        <!-- Settings -->
        <button
          (click)="project.setWorkspace('settings')"
          class="h-7 px-2 rounded-md hover:bg-white/5 text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          title="Project Settings"
        >
          <mat-icon class="text-sm">tune</mat-icon>
        </button>

        <span class="text-white/10">|</span>

        <!-- Engine Status -->
        <div class="flex items-center gap-1.5 font-mono text-[10px]">
          <span class="text-slate-500">ENGINE:</span>
          <span class="text-emerald-400 font-semibold">RUST CPAL</span>
        </div>
      </div>
    </div>
  `
})
export class Header {
  readonly project = inject(ProjectState);
  readonly engine = inject(AudioEngine);

  readonly workspaceTabs: { id: StudioWorkspace; label: string; icon: string }[] = [
    { id: 'multitrack', label: 'Timeline', icon: 'view_timeline' },
    { id: 'mixer', label: 'Mixer', icon: 'tune' },
    { id: 'inspector', label: 'Effects EQ', icon: 'equalizer' },
    { id: 'separation', label: 'Separation', icon: 'graphic_eq' },
    { id: 'spectral', label: 'Spectral', icon: 'waterfall_chart' },
    { id: 'intelligence', label: 'R-Intelligence', icon: 'insights' },
    { id: 'restoration', label: 'Restoration', icon: 'cleaning_services' },
    { id: 'batch', label: 'Batch Queue', icon: 'queue_music' },
    { id: 'export', label: 'Export Studio', icon: 'download' },
    { id: 'models', label: 'Models', icon: 'hub' },
    { id: 'quality', label: 'Quality QA', icon: 'fact_check' }
  ];
}
