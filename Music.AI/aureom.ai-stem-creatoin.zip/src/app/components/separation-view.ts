import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';
import { SeparationModel } from '../models/audio.types';

@Component({
  selector: 'app-separation-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-y-auto select-none p-4 md:p-6">
      <!-- Title & Header -->
      <div class="flex flex-col gap-1 pb-4 border-b border-white/5">
        <div class="flex items-center gap-2">
          <div class="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <mat-icon class="text-sm">auto_fix_high</mat-icon>
          </div>
          <h2 class="font-display text-lg font-bold text-white tracking-tight">
            Aureom Source Intelligence
          </h2>
        </div>
        <p class="text-xs text-slate-400">
          State-of-the-art neural music source separation. Decompose complete recordings into isolated, aligned 32-bit floating-point audio stems.
        </p>
      </div>

      <!-- Main Two-Column Setup: Left File Import & Inspection, Right Model Selection & Execution -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-5">
        
        <!-- LEFT COLUMN (5 cols): Audio Import & Technical Inspection -->
        <div class="lg:col-span-5 flex flex-col gap-4">
          <span class="font-display font-semibold text-xs text-slate-200">1. Recording Input</span>

          <!-- Dropzone Area -->
          <div
            tabindex="0"
            role="button"
            (dragover)="onDragOver($event)"
            (dragleave)="onDragLeave($event)"
            (drop)="onFileDrop($event)"
            (click)="fileInput.click()"
            (keydown.enter)="fileInput.click()"
            class="border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all"
            [class]="isDragging() ? 'border-amber-400 bg-amber-400/5' : 'border-white/10 hover:border-amber-500/40 bg-[#0e1117]'"
          >
            <input
              #fileInput
              type="file"
              accept="audio/*,.wav,.mp3,.flac,.ogg,.m4a"
              class="hidden"
              (change)="onFileInputChange($event)"
            />
            <div class="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-amber-400 mb-3">
              <mat-icon class="text-2xl">cloud_upload</mat-icon>
            </div>
            <span class="font-semibold text-sm text-slate-100">
              Drag & Drop Master Recording
            </span>
            <span class="text-xs text-slate-400 mt-1">
              Supports WAV, FLAC, MP3, AIFF, OGG (Up to 96 kHz / 32-bit)
            </span>
            <button
              class="mt-4 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-xs text-slate-200 font-medium transition-colors"
            >
              Browse Local Audio File
            </button>
          </div>

          <!-- Imported File Technical Inspector -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <span class="font-semibold text-xs text-slate-200">Technical Properties</span>
              <span class="text-[10px] font-mono text-emerald-400">INPUT VERIFIED</span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono">
              <div class="bg-[#0a0c10] p-2 rounded-md flex flex-col">
                <span class="text-[9px] text-slate-500">FILENAME</span>
                <span class="text-slate-200 truncate font-semibold">{{ currentFileName() }}</span>
              </div>
              <div class="bg-[#0a0c10] p-2 rounded-md flex flex-col">
                <span class="text-[9px] text-slate-500">SAMPLE RATE</span>
                <span class="text-amber-300 font-semibold">{{ engine.sampleRate() / 1000 }} kHz</span>
              </div>
              <div class="bg-[#0a0c10] p-2 rounded-md flex flex-col">
                <span class="text-[9px] text-slate-500">DURATION</span>
                <span class="text-slate-200 font-semibold">{{ engine.duration().toFixed(2) }}s ({{ Math.ceil(engine.duration() / 60) }}m)</span>
              </div>
              <div class="bg-[#0a0c10] p-2 rounded-md flex flex-col">
                <span class="text-[9px] text-slate-500">CHANNELS</span>
                <span class="text-slate-200 font-semibold">2 (Stereo L/R)</span>
              </div>
              <div class="bg-[#0a0c10] p-2 rounded-md flex flex-col">
                <span class="text-[9px] text-slate-500">INTEGRATED LUFS</span>
                <span class="text-slate-200 font-semibold">{{ engine.masterLufs() }} LUFS</span>
              </div>
              <div class="bg-[#0a0c10] p-2 rounded-md flex flex-col">
                <span class="text-[9px] text-slate-500">SAMPLE FORMAT</span>
                <span class="text-slate-200 font-semibold">32-Bit Float</span>
              </div>
            </div>
          </div>
        </div>

        <!-- RIGHT COLUMN (7 cols): Model Selector & Separation Settings -->
        <div class="lg:col-span-7 flex flex-col gap-4">
          <span class="font-display font-semibold text-xs text-slate-200">2. Neural Model Selection & Settings</span>

          <!-- Pluggable Model Cards Grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            @for (model of availableModels; track model.id) {
              <div
                tabindex="0"
                role="button"
                (click)="project.activeModelId.set(model.id)"
                (keydown.enter)="project.activeModelId.set(model.id)"
                class="border rounded-xl p-3 flex flex-col justify-between transition-all cursor-pointer"
                [class]="project.activeModelId() === model.id ? 'bg-[#181d29] border-amber-500 shadow-sm shadow-amber-500/10' : 'bg-[#12151e] border-white/5 hover:border-white/10'"
              >
                <div class="flex flex-col gap-1">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-xs text-white">{{ model.name }}</span>
                    <span class="text-[9px] font-mono px-1.5 py-0.5 rounded-xs" [class]="model.isDefault ? 'bg-amber-500/20 text-amber-300' : 'bg-white/5 text-slate-400'">
                      {{ model.version }}
                    </span>
                  </div>
                  <span class="text-[10px] text-slate-400">{{ model.architecture }}</span>
                </div>

                <div class="flex flex-wrap gap-1 mt-3 pt-2 border-t border-white/5">
                  @for (stem of model.stems; track stem) {
                    <span class="text-[9px] font-mono px-1.5 py-0.5 rounded-xs bg-[#0b0d12] text-slate-300 border border-white/5">
                      {{ stem }}
                    </span>
                  }
                </div>

                <div class="flex items-center justify-between mt-2 pt-2 border-t border-white/5 text-[9px] font-mono text-slate-400">
                  <span>{{ model.sdrRating }}</span>
                  <span class="text-emerald-400">{{ model.recommendedDevice }}</span>
                </div>
              </div>
            }
          </div>

          <!-- Quality & Overlap Parameters -->
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
            <span class="font-semibold text-xs text-slate-200">Inference & Reconstruction Quality</span>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
              <!-- Overlap percentage -->
              <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                <span class="text-[10px] text-slate-500">CHUNK OVERLAP</span>
                <select
                  (change)="onOverlapChange($event)"
                  class="bg-[#151922] border border-white/10 text-white rounded-md p-1.5 text-xs outline-none"
                >
                  <option value="50">50% (Recommended)</option>
                  <option value="75">75% (Ultra-Smooth High Res)</option>
                  <option value="25">25% (Fast Render)</option>
                </select>
                <span class="text-[9px] text-slate-500 mt-1">Minimizes chunk boundary clicks</span>
              </div>

              <!-- Compute Device -->
              <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                <span class="text-[10px] text-slate-500">COMPUTE BACKEND</span>
                <select
                  class="bg-[#151922] border border-white/10 text-white rounded-md p-1.5 text-xs outline-none"
                >
                  <option>GPU (CUDA / Metal / WebGPU)</option>
                  <option>CPU Multi-Core (Rayon SIMD)</option>
                </select>
                <span class="text-[9px] text-slate-500 mt-1">Hardware acceleration target</span>
              </div>

              <!-- Target Stem Count -->
              <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                <span class="text-[10px] text-slate-500">STEM TARGETS</span>
                <div class="flex items-center gap-1 mt-1">
                  <button
                    (click)="project.separationTargetStems.set(4)"
                    class="flex-1 py-1 text-center rounded-md font-mono text-xs font-semibold cursor-pointer"
                    [class]="project.separationTargetStems() === 4 ? 'bg-amber-500 text-black' : 'bg-white/5 text-slate-400'"
                  >
                    4 Stems
                  </button>
                  <button
                    (click)="project.separationTargetStems.set(6)"
                    class="flex-1 py-1 text-center rounded-md font-mono text-xs font-semibold cursor-pointer"
                    [class]="project.separationTargetStems() === 6 ? 'bg-amber-500 text-black' : 'bg-white/5 text-slate-400'"
                  >
                    6 Stems
                  </button>
                </div>
                <span class="text-[9px] text-slate-500 mt-1">Vocals, Drums, Bass, Other...</span>
              </div>
            </div>
          </div>

          <!-- SEPARATION EXECUTION & PROGRESS MONITOR -->
          <div class="bg-[#151924] border-2 border-amber-500/25 rounded-xl p-5 flex flex-col gap-4 shadow-lg shadow-black/40">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400">play_circle_filled</mat-icon>
                <span class="font-display font-bold text-sm text-white">Execute Aureom Neural Separation</span>
              </div>
              <span class="text-xs font-mono text-amber-300 font-medium">
                {{ isSeparating() ? 'INFERENCE ACTIVE' : 'ENGINE IDLE' }}
              </span>
            </div>

            <!-- Progress Bar -->
            <div class="flex flex-col gap-1.5 font-mono text-xs">
              <div class="flex justify-between text-slate-300 text-[11px]">
                <span>{{ currentStatus() }}</span>
                <span class="font-bold text-amber-300 tabular-nums">{{ progressPercent() }}%</span>
              </div>
              <div class="h-2.5 bg-neutral-950 rounded-full overflow-hidden border border-white/10 p-0.5">
                <div
                  class="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-300 rounded-full transition-all duration-150"
                  [style.width.%]="progressPercent()"
                ></div>
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex items-center gap-3 pt-2">
              <button
                (click)="startSeparation()"
                [disabled]="isSeparating()"
                class="flex-1 h-10 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm shadow-amber-500/30"
              >
                <mat-icon class="text-base">{{ isSeparating() ? 'hourglass_top' : 'auto_fix_high' }}</mat-icon>
                <span>{{ isSeparating() ? 'Separating Stems in Background...' : 'Start Neural Separation' }}</span>
              </button>

              <button
                (click)="goToStudio()"
                class="px-4 h-10 rounded-lg bg-white/10 hover:bg-white/15 text-white text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <mat-icon class="text-sm">view_timeline</mat-icon>
                <span>Open in Studio</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  `
})
export class SeparationView {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);
  readonly Math = Math;

  readonly isDragging = signal<boolean>(false);
  readonly isSeparating = signal<boolean>(false);
  readonly progressPercent = signal<number>(0);
  readonly currentStatus = signal<string>('Ready to process master audio');
  readonly currentFileName = signal<string>('Aureom_Nocturne_Master.wav');

  private uploadedAudioBuffer: AudioBuffer | null = null;

  readonly availableModels: SeparationModel[] = [
    {
      id: 'demucs-v4-ht',
      name: 'Demucs v4 Hybrid Transformer',
      version: '4.0.1',
      architecture: 'Time & Frequency U-Net',
      stems: ['Vocals', 'Drums', 'Bass', 'Other'],
      sampleRate: 44100,
      channels: 2,
      recommendedDevice: 'GPU / AVX-512',
      memoryReqMB: 2048,
      latencyMs: 12.4,
      licence: 'MIT License',
      status: 'Verified',
      precision: 'FP16',
      sdrRating: '9.4 dB SDR',
      isDefault: true
    },
    {
      id: 'ht-demucs-6s',
      name: 'Hybrid Transformer Pro 6-Stem',
      version: '4.2.0',
      architecture: 'Conformer Cross-Domain',
      stems: ['Vocals', 'Drums', 'Bass', 'Guitar', 'Piano', 'Other'],
      sampleRate: 48000,
      channels: 2,
      recommendedDevice: 'CUDA High-VRAM',
      memoryReqMB: 3584,
      latencyMs: 18.2,
      licence: 'Commercial',
      status: 'Verified',
      precision: 'FP16',
      sdrRating: '10.1 dB SDR',
      isDefault: false
    },
    {
      id: 'mdx-net-vocals',
      name: 'MDX-Net Vocal Isolate Extreme',
      version: '2.4.0',
      architecture: 'Dilated Convolutional ResNet',
      stems: ['Vocals', 'Instrumental'],
      sampleRate: 44100,
      channels: 2,
      recommendedDevice: 'CPU / GPU Unified',
      memoryReqMB: 1024,
      latencyMs: 6.8,
      licence: 'Apache 2.0',
      status: 'Verified',
      precision: 'INT8 / FP16',
      sdrRating: '11.2 dB SDR',
      isDefault: false
    },
    {
      id: 'open-unmix-umx-l',
      name: 'Open-Unmix Large (UMX-L)',
      version: '1.2.1',
      architecture: 'Bi-LSTM Multi-Band STFT',
      stems: ['Vocals', 'Drums', 'Bass', 'Other'],
      sampleRate: 44100,
      channels: 2,
      recommendedDevice: 'Multi-Core CPU',
      memoryReqMB: 850,
      latencyMs: 8.5,
      licence: 'MIT',
      status: 'Verified',
      precision: 'FP32',
      sdrRating: '8.1 dB SDR',
      isDefault: false
    }
  ];

  onDragOver(e: DragEvent) {
    e.preventDefault();
    this.isDragging.set(true);
  }

  onDragLeave(e: DragEvent) {
    e.preventDefault();
    this.isDragging.set(false);
  }

  async onFileDrop(e: DragEvent) {
    e.preventDefault();
    this.isDragging.set(false);
    if (e.dataTransfer && e.dataTransfer.files.length > 0) {
      await this.handleAudioFile(e.dataTransfer.files[0]);
    }
  }

  async onFileInputChange(e: Event) {
    const input = e.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      await this.handleAudioFile(input.files[0]);
    }
  }

  private async handleAudioFile(file: File) {
    this.currentFileName.set(file.name);
    this.currentStatus.set(`Decoding ${file.name}...`);
    try {
      const decoded = await this.engine.decodeUploadedFile(file);
      this.uploadedAudioBuffer = decoded.buffer;
      this.currentStatus.set(`Decoded successfully: ${decoded.info.sampleRate} Hz, ${decoded.info.duration.toFixed(1)}s`);
      this.project.recordAction(`Imported audio recording: ${file.name}`, 'edit');
    } catch (err: unknown) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'File unsupported';
      this.currentStatus.set(`Decoding error: ${msg}`);
    }
  }

  onOverlapChange(e: Event) {
    const val = Number((e.target as HTMLSelectElement).value);
    this.project.separationOverlap.set(val);
  }

  async startSeparation() {
    this.isSeparating.set(true);
    this.progressPercent.set(0);

    // If user hasn't loaded an external file, use the current synthetic mix buffer
    let sourceBuffer = this.uploadedAudioBuffer;
    if (!sourceBuffer) {
      // Create master mix buffer from current tracks
      const ctx = this.engine.getAudioContext();
      const dur = this.engine.duration();
      const numFrames = Math.floor(ctx.sampleRate * dur);
      sourceBuffer = ctx.createBuffer(2, numFrames, ctx.sampleRate);
      const sL = sourceBuffer.getChannelData(0);
      const sR = sourceBuffer.getChannelData(1);
      for (const t of this.engine.tracks()) {
        if (!t.buffer) continue;
        const bL = t.buffer.getChannelData(0);
        const bR = t.buffer.numberOfChannels > 1 ? t.buffer.getChannelData(1) : bL;
        for (let i = 0; i < Math.min(sL.length, bL.length); i++) {
          sL[i] += bL[i] * t.volume * 0.45;
          sR[i] += bR[i] * t.volume * 0.45;
        }
      }
    }

    try {
      await this.engine.runSeparation(
        sourceBuffer,
        this.project.activeModelId(),
        this.project.separationTargetStems(),
        (pct, chunk, total, stage) => {
          this.progressPercent.set(pct);
          this.currentStatus.set(stage);
        }
      );

      this.project.recordAction(
        `Neural separation completed using ${this.project.activeModelId()}`,
        'separation'
      );
      this.isSeparating.set(false);
      this.currentStatus.set('Separation Complete! 4 Aligned Stems Ready in Studio.');
    } catch (err: unknown) {
      this.isSeparating.set(false);
      const msg = err instanceof Error ? err.message : 'Processing error';
      this.currentStatus.set(`Separation failed: ${msg}`);
    }
  }

  goToStudio() {
    this.project.setWorkspace('multitrack');
  }
}
