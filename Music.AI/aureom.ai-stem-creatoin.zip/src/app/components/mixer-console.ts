import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';
import { StemTrack } from '../models/audio.types';

@Component({
  selector: 'app-mixer-console',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-hidden select-none p-4">
      <!-- Mixer Top Bar -->
      <div class="h-9 bg-[#11141b] border border-white/5 rounded-t-xl px-4 flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div class="flex items-center gap-3">
          <span class="font-display font-semibold text-slate-100">Aureom Console & Signal Architecture</span>
          <span class="text-white/10">|</span>
          <span class="text-slate-400 font-mono text-[11px]">32-BIT IEEE FLOAT BUS</span>
        </div>
        <div class="flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <span class="text-slate-500">ROUTING:</span>
          <span class="text-amber-400">STEMS → INSERT DSP → STEREO PAN → MASTER BUS</span>
        </div>
      </div>

      <!-- Channel Strips Container (Horizontal Scroll) -->
      <div class="flex-1 bg-[#0d0f14] border-x border-b border-white/5 rounded-b-xl p-4 flex gap-3 overflow-x-auto">
        <!-- Stem Track Channel Strips -->
        @for (track of engine.tracks(); track track.id) {
          <div
            tabindex="0"
            role="button"
            (click)="project.setSelectedTrack(track.id)"
            (keydown.enter)="project.setSelectedTrack(track.id)"
            class="w-40 bg-[#12151e] border rounded-xl flex flex-col justify-between p-3 shrink-0 transition-all cursor-pointer"
            [class]="project.selectedTrackId() === track.id ? 'border-amber-500/40 shadow-md shadow-amber-500/5' : 'border-white/5 hover:border-white/10'"
          >
            <!-- Top Section: Track Stem Name & Color -->
            <div class="flex flex-col gap-1 pb-2 border-b border-white/5">
              <div class="flex items-center justify-between">
                <span class="w-2 h-2 rounded-full" [style.backgroundColor]="track.color"></span>
                <span class="text-[9px] font-mono text-slate-500 uppercase">{{ track.stemType }}</span>
              </div>
              <span class="font-semibold text-xs text-slate-200 truncate" [title]="track.name">
                {{ track.name }}
              </span>
            </div>

            <!-- Inserts Mini Rack (EQ, Compressor, Restoration) -->
            <div class="flex flex-col gap-1 py-2 border-b border-white/5 text-[9px] font-mono">
              <button
                type="button"
                class="px-1.5 py-0.5 rounded-xs flex items-center justify-between cursor-pointer w-full"
                [class]="track.eq.enabled ? 'bg-amber-500/10 text-amber-300' : 'bg-white/5 text-slate-500'"
                (click)="toggleEq(track); $event.stopPropagation()"
              >
                <span>EQ: 4-BAND</span>
                <span>{{ track.eq.enabled ? 'IN' : 'BYP' }}</span>
              </button>
              <button
                type="button"
                class="px-1.5 py-0.5 rounded-xs flex items-center justify-between cursor-pointer w-full"
                [class]="track.compressor.enabled ? 'bg-indigo-500/15 text-indigo-300' : 'bg-white/5 text-slate-500'"
                (click)="toggleComp(track); $event.stopPropagation()"
              >
                <span>DYN: COMP</span>
                <span>{{ track.compressor.enabled ? 'IN' : 'BYP' }}</span>
              </button>
              <div
                class="px-1.5 py-0.5 rounded-xs flex items-center justify-between"
                [class]="track.restoration.deEsser ? 'bg-rose-500/15 text-rose-300' : 'bg-white/5 text-slate-500'"
              >
                <span>RESTORE</span>
                <span>{{ track.restoration.deEsser ? 'DE-ESS' : 'OFF' }}</span>
              </div>
            </div>

            <!-- Pan Knob & Readout -->
            <div class="flex flex-col items-center gap-1 py-2 border-b border-white/5">
              <span class="text-[9px] font-mono text-slate-500">PAN</span>
              <input
                type="range"
                min="-1"
                max="1"
                step="0.02"
                [value]="track.pan"
                (input)="onTrackPanChange(track.id, $event)"
                (click)="$event.stopPropagation()"
                class="w-24 studio-fader h-1 cursor-pointer"
              />
              <span class="font-mono text-[10px] text-slate-300">
                {{ track.pan === 0 ? 'CENTER' : track.pan < 0 ? 'L ' + Math.abs(track.pan * 100).toFixed(0) : 'R ' + (track.pan * 100).toFixed(0) }}
              </span>
            </div>

            <!-- Fader & LED Meter Section -->
            <div class="flex-1 flex items-center justify-center gap-3 py-3 min-h-[160px]">
              <!-- Vertical Fader -->
              <div class="relative flex flex-col items-center h-full justify-center">
                <input
                  type="range"
                  min="0"
                  max="1.5"
                  step="0.01"
                  [value]="track.volume"
                  (input)="onTrackVolumeChange(track.id, $event)"
                  (click)="$event.stopPropagation()"
                  class="studio-fader studio-fader-vertical h-36 w-3 cursor-pointer"
                  title="Track Fader"
                />
              </div>

              <!-- Dual Stereo / Peak VU Meter with dB ticks -->
              <div class="flex items-center gap-1 h-36">
                <!-- Peak LED column -->
                <div class="w-2.5 h-full bg-neutral-950 rounded-xs p-0.5 flex flex-col justify-end border border-white/5 relative">
                  <div
                    class="w-full transition-all duration-75 rounded-xs"
                    [style.height.%]="getMeterHeight(track.currentPeakDbfs)"
                    [class]="track.currentPeakDbfs > -0.5 ? 'bg-rose-500' : track.currentPeakDbfs > -6 ? 'bg-amber-400' : 'bg-emerald-500'"
                  ></div>
                </div>

                <!-- dB scale ticks -->
                <div class="flex flex-col justify-between h-full text-[8px] font-mono text-slate-600 pl-0.5">
                  <span>+3</span>
                  <span>0</span>
                  <span>-6</span>
                  <span>-18</span>
                  <span>-36</span>
                  <span>-∞</span>
                </div>
              </div>
            </div>

            <!-- Fader dB Readout -->
            <div class="text-center font-mono text-xs font-semibold text-slate-200 py-1 bg-black/30 rounded-md">
              {{ formatDb(track.volume) }}
            </div>

            <!-- Solo / Mute Buttons -->
            <div class="flex items-center gap-1.5 pt-2">
              <button
                (click)="engine.toggleMute(track.id); $event.stopPropagation()"
                class="flex-1 h-7 rounded-md font-mono font-bold text-xs flex items-center justify-center transition-colors cursor-pointer"
                [class]="track.muted ? 'bg-amber-500 text-black font-extrabold' : 'bg-white/5 text-slate-400 hover:text-white'"
              >
                M
              </button>
              <button
                (click)="engine.toggleSolo(track.id); $event.stopPropagation()"
                class="flex-1 h-7 rounded-md font-mono font-bold text-xs flex items-center justify-center transition-colors cursor-pointer"
                [class]="track.soloed ? 'bg-indigo-500 text-white font-extrabold' : 'bg-white/5 text-slate-400 hover:text-white'"
              >
                S
              </button>
            </div>
          </div>
        }

        <!-- MASTER CHANNEL STRIP (Distinguished Champagne Gold Styling) -->
        <div class="w-48 bg-[#151922] border-2 border-amber-500/30 rounded-xl flex flex-col justify-between p-3 shrink-0 shadow-lg shadow-black/40">
          <!-- Top: Master Label -->
          <div class="flex flex-col gap-1 pb-2 border-b border-amber-500/20">
            <div class="flex items-center justify-between">
              <span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
              <span class="text-[9px] font-mono text-amber-400 font-bold uppercase tracking-wider">MASTER BUS</span>
            </div>
            <span class="font-bold text-xs text-white">
              Stereo Output
            </span>
          </div>

          <!-- Master Processing Rack: Limiter & LUFS -->
          <div class="flex flex-col gap-1.5 py-2 border-b border-white/5 text-[9px] font-mono">
            <div class="px-1.5 py-1 rounded-xs bg-amber-500/10 text-amber-300 flex items-center justify-between">
              <span>TRUE PEAK LIMITER</span>
              <span class="text-emerald-400 font-bold">ACTIVE</span>
            </div>
            <div class="px-1.5 py-1 rounded-xs bg-black/40 flex items-center justify-between text-slate-300">
              <span class="text-slate-500">INTEGRATED:</span>
              <span class="text-amber-400 font-bold tabular-nums">{{ engine.masterLufs() }} LUFS</span>
            </div>
          </div>

          <!-- Master Fader & Stereo Twin VU Meters -->
          <div class="flex-1 flex items-center justify-center gap-3 py-3 min-h-[160px]">
            <!-- Master Vertical Fader -->
            <div class="relative flex flex-col items-center h-full justify-center">
              <input
                type="range"
                min="0"
                max="1.5"
                step="0.01"
                [value]="engine.masterVolume()"
                (input)="onMasterVolumeChange($event)"
                class="studio-fader studio-fader-vertical h-36 w-3 cursor-pointer"
                title="Master Output Fader"
              />
            </div>

            <!-- Dual Stereo VU Meter -->
            <div class="flex items-center gap-1 h-36">
              <!-- Left Channel -->
              <div class="w-2.5 h-full bg-neutral-950 rounded-xs p-0.5 flex flex-col justify-end border border-white/10">
                <div
                  class="w-full transition-all duration-75 rounded-xs"
                  [style.height.%]="getMeterHeight(engine.masterPeakL())"
                  [class]="engine.masterPeakL() > -0.5 ? 'bg-rose-500' : engine.masterPeakL() > -6 ? 'bg-amber-400' : 'bg-emerald-500'"
                ></div>
              </div>
              <!-- Right Channel -->
              <div class="w-2.5 h-full bg-neutral-950 rounded-xs p-0.5 flex flex-col justify-end border border-white/10">
                <div
                  class="w-full transition-all duration-75 rounded-xs"
                  [style.height.%]="getMeterHeight(engine.masterPeakR())"
                  [class]="engine.masterPeakR() > -0.5 ? 'bg-rose-500' : engine.masterPeakR() > -6 ? 'bg-amber-400' : 'bg-emerald-500'"
                ></div>
              </div>

              <!-- dB scale ticks -->
              <div class="flex flex-col justify-between h-full text-[8px] font-mono text-slate-500 pl-0.5">
                <span class="text-rose-400">+3</span>
                <span class="text-amber-300">0</span>
                <span>-6</span>
                <span>-18</span>
                <span>-36</span>
                <span>-∞</span>
              </div>
            </div>
          </div>

          <!-- Master Output dB Readout -->
          <div class="text-center font-mono text-xs font-bold text-amber-300 py-1 bg-black/40 rounded-md border border-amber-500/20">
            {{ formatDb(engine.masterVolume()) }}
          </div>

          <!-- Master Mono & Dim buttons -->
          <div class="flex items-center gap-1.5 pt-2">
            <button
              class="flex-1 h-7 rounded-md font-mono text-[10px] bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
              title="Test Mono Compatibility"
            >
              MONO
            </button>
            <button
              class="flex-1 h-7 rounded-md font-mono text-[10px] bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
              title="Dim Output by -20 dB"
            >
              DIM
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MixerConsole {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);
  readonly Math = Math;

  onTrackVolumeChange(trackId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setTrackVolume(trackId, val);
  }

  onTrackPanChange(trackId: string, e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setTrackPan(trackId, val);
  }

  onMasterVolumeChange(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.engine.setMasterVolume(val);
  }

  toggleEq(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      eq: { ...track.eq, enabled: !track.eq.enabled }
    });
  }

  toggleComp(track: StemTrack) {
    this.engine.updateTrack({
      id: track.id,
      compressor: { ...track.compressor, enabled: !track.compressor.enabled }
    });
  }

  formatDb(gain: number): string {
    if (gain <= 0.001) return '-inf';
    const db = 20 * Math.log10(gain);
    return `${db > 0 ? '+' : ''}${db.toFixed(1)} dB`;
  }

  getMeterHeight(db: number): number {
    if (db <= -60) return 0;
    const normalized = (db + 60) / 63;
    return Math.max(0, Math.min(100, normalized * 100));
  }
}
