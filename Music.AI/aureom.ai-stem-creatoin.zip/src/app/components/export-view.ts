import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AudioEngine } from '../services/audio-engine';
import { ProjectState } from '../services/project-state';
import { StemTrack } from '../models/audio.types';

@Component({
  selector: 'app-export-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-y-auto select-none p-4 md:p-6">
      <!-- Title & Header -->
      <div class="flex flex-col gap-1 pb-4 border-b border-white/5">
        <div class="flex items-center gap-2">
          <div class="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <mat-icon class="text-sm">download</mat-icon>
          </div>
          <h2 class="font-display text-lg font-bold text-white tracking-tight">
            Aureom Professional Export Studio
          </h2>
        </div>
        <p class="text-xs text-slate-400">
          Render studio-grade lossless stems or master stereo mix with sample-accurate alignment, TPDF dither, and loudness normalization.
        </p>
      </div>

      <!-- Presets Selector Ribbon -->
      <div class="flex items-center gap-2 pt-4">
        <span class="text-xs font-mono text-slate-500">QUICK PRESET:</span>
        <div class="flex items-center gap-1.5 flex-wrap">
          <button
            (click)="applyPreset('daw')"
            class="px-2.5 py-1 rounded-md text-xs font-medium bg-[#12151e] border border-white/5 hover:border-amber-500/40 text-slate-200 transition-colors cursor-pointer"
          >
            DAW Interchange (24-bit WAV Stems)
          </button>
          <button
            (click)="applyPreset('master')"
            class="px-2.5 py-1 rounded-md text-xs font-medium bg-[#12151e] border border-white/5 hover:border-amber-500/40 text-slate-200 transition-colors cursor-pointer"
          >
            Streaming Master (-14 LUFS Stereo)
          </button>
          <button
            (click)="applyPreset('archival')"
            class="px-2.5 py-1 rounded-md text-xs font-medium bg-[#12151e] border border-white/5 hover:border-amber-500/40 text-slate-200 transition-colors cursor-pointer"
          >
            Archival Lossless (32-bit Float)
          </button>
        </div>
      </div>

      <!-- Main Two-Column Configuration Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-5">
        
        <!-- LEFT COLUMN (7 cols): Export Parameters -->
        <div class="lg:col-span-7 flex flex-col gap-4">
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4">
            <span class="font-display font-semibold text-xs text-slate-200">Format & Encoding Settings</span>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <!-- File Format -->
              <div class="flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">OUTPUT CONTAINER</span>
                <select
                  (change)="onFormatChange()"
                  class="bg-[#0a0c10] border border-white/10 text-white rounded-lg p-2 outline-none"
                >
                  <option value="wav">WAV (Broadcast Wave Format)</option>
                  <option value="flac">FLAC (Free Lossless Audio Codec)</option>
                  <option value="mp3">MP3 (320 kbps CBR)</option>
                </select>
              </div>

              <!-- Bit Depth -->
              <div class="flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">BIT DEPTH / QUANTIZATION</span>
                <select
                  [value]="selectedBitDepth()"
                  (change)="onBitDepthChange($event)"
                  class="bg-[#0a0c10] border border-white/10 text-white rounded-lg p-2 outline-none"
                >
                  <option value="24">24-Bit Linear PCM (Studio Standard)</option>
                  <option value="16">16-Bit Linear PCM (Red Book CD)</option>
                  <option value="32">32-Bit IEEE Floating Point</option>
                </select>
              </div>

              <!-- Sample Rate -->
              <div class="flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">SAMPLE RATE</span>
                <select
                  class="bg-[#0a0c10] border border-white/10 text-white rounded-lg p-2 outline-none"
                >
                  <option>44.1 kHz (Compact Disc / Streaming)</option>
                  <option>48.0 kHz (Cinema / Video Standard)</option>
                  <option>96.0 kHz (Hi-Res Master Audio)</option>
                </select>
              </div>

              <!-- Dither Algorithm -->
              <div class="flex flex-col gap-1.5">
                <span class="text-slate-500 text-[10px]">DITHER & NOISE SHAPING</span>
                <select
                  class="bg-[#0a0c10] border border-white/10 text-white rounded-lg p-2 outline-none"
                >
                  <option>TPDF (Triangular Probability Density)</option>
                  <option>High-Pass Psychoacoustic Shaping</option>
                  <option>None (Truncation)</option>
                </select>
              </div>
            </div>

            <!-- Loudness Normalization & True Peak Ceiling -->
            <div class="flex flex-col gap-3 pt-3 border-t border-white/5 text-xs font-mono">
              <span class="font-semibold text-slate-200">Loudness Target & Limiting</span>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                  <span class="text-[10px] text-slate-500">TARGET INTEGRATED LUFS</span>
                  <select class="bg-[#151922] border border-white/10 text-white rounded-md p-1.5 text-xs outline-none">
                    <option>-14.0 LUFS (Spotify / Apple Music / YouTube)</option>
                    <option>-16.0 LUFS (Apple Digital Masters)</option>
                    <option>-23.0 LUFS (EBU R128 Broadcast)</option>
                    <option>Bypass Normalization (Pure Mix)</option>
                  </select>
                </div>

                <div class="bg-[#0a0c10] p-3 rounded-lg flex flex-col gap-1">
                  <span class="text-[10px] text-slate-500">TRUE PEAK CEILING</span>
                  <span class="text-amber-300 font-bold text-sm tabular-nums">-0.5 dBFS</span>
                  <span class="text-[9px] text-slate-500">Prevents inter-sample clipping on DACs</span>
                </div>
              </div>
            </div>

            <!-- Metadata Tags -->
            <div class="flex flex-col gap-2 pt-3 border-t border-white/5 text-xs font-mono">
              <span class="font-semibold text-slate-200">Broadcast RIFF Metadata</span>
              <div class="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Track Title"
                  [value]="project.projectName()"
                  class="bg-[#0a0c10] border border-white/10 text-white rounded-lg p-2 outline-none"
                />
                <input
                  type="text"
                  placeholder="Artist / Engineer"
                  value="Aureom Production Studio"
                  class="bg-[#0a0c10] border border-white/10 text-white rounded-lg p-2 outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        <!-- RIGHT COLUMN (5 cols): Render Targets & Action -->
        <div class="lg:col-span-5 flex flex-col gap-4">
          <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4">
            <span class="font-display font-semibold text-xs text-slate-200">Render Targets & Execution</span>

            <!-- Render Stems Checklist -->
            <div class="flex flex-col gap-2">
              <span class="text-[10px] font-mono text-slate-500">ACTIVE STEMS FOR EXPORT:</span>
              @for (track of engine.tracks(); track track.id) {
                <div class="bg-[#0a0c10] border border-white/5 p-2.5 rounded-lg flex items-center justify-between text-xs font-mono">
                  <div class="flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full" [style.backgroundColor]="track.color"></span>
                    <span class="font-semibold text-slate-200">{{ track.name }}</span>
                  </div>
                  <button
                    (click)="exportSingleStem(track)"
                    [disabled]="isRendering()"
                    class="px-2 py-0.5 rounded-sm bg-white/10 hover:bg-white/15 text-slate-200 text-[11px] transition-colors cursor-pointer"
                  >
                    Export WAV
                  </button>
                </div>
              }
            </div>

            <!-- Primary Master Render Execution Box -->
            <div class="bg-[#181d29] border-2 border-amber-500/30 rounded-xl p-4 flex flex-col gap-3 mt-2 shadow-lg shadow-black/30">
              <div class="flex items-center justify-between">
                <span class="font-bold text-xs text-amber-300">MASTER STEREO MIXDOWN</span>
                <span class="text-[10px] font-mono text-emerald-400">READY</span>
              </div>
              <p class="text-xs text-slate-300">
                Sum and render all unmuted stem channels with current faders, pan positions, EQ, and compressor dynamics into a pristine WAV file.
              </p>

              <!-- Render Status Message -->
              @if (renderStatus()) {
                <div class="bg-[#0b0d12] p-2.5 rounded-md font-mono text-[11px] text-amber-300 border border-white/5">
                  {{ renderStatus() }}
                </div>
              }

              <!-- Master Render Button -->
              <button
                (click)="exportMasterMix()"
                [disabled]="isRendering()"
                class="h-10 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm shadow-amber-500/30"
              >
                <mat-icon class="text-base">{{ isRendering() ? 'sync' : 'download' }}</mat-icon>
                <span>{{ isRendering() ? 'Rendering Master Audio...' : 'Render & Download Master WAV' }}</span>
              </button>

              <!-- Export All Stems in Bulk -->
              <button
                (click)="exportAllStemsBulk()"
                [disabled]="isRendering()"
                class="h-9 rounded-lg bg-white/10 hover:bg-white/15 text-white font-medium text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <mat-icon class="text-sm">folder_zip</mat-icon>
                <span>Download All 4 Stems (WAV Package)</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  `
})
export class ExportView {
  readonly engine = inject(AudioEngine);
  readonly project = inject(ProjectState);

  readonly selectedBitDepth = signal<16 | 24 | 32>(24);
  readonly isRendering = signal<boolean>(false);
  readonly renderStatus = signal<string>('');

  onBitDepthChange(e: Event) {
    const val = Number((e.target as HTMLSelectElement).value) as 16 | 24 | 32;
    this.selectedBitDepth.set(val);
  }

  onFormatChange() {
    // format handling
  }

  applyPreset(preset: 'daw' | 'master' | 'archival') {
    if (preset === 'daw') {
      this.selectedBitDepth.set(24);
      this.renderStatus.set('Applied Preset: DAW Interchange (24-bit 44.1kHz Linear PCM)');
    } else if (preset === 'master') {
      this.selectedBitDepth.set(24);
      this.renderStatus.set('Applied Preset: Streaming Master (-14 LUFS, -0.5 dBFS ceiling)');
    } else {
      this.selectedBitDepth.set(32);
      this.renderStatus.set('Applied Preset: Archival 32-bit IEEE Float');
    }
  }

  async exportMasterMix() {
    this.isRendering.set(true);
    this.renderStatus.set('Rendering offline audio mixdown buffer...');
    try {
      const wavBlob = await this.engine.exportMasterMixToWav(this.engine.tracks(), this.selectedBitDepth());
      this.triggerDownload(wavBlob, `${this.project.projectName()}_Master_Mix.wav`);
      this.renderStatus.set('Master WAV mix rendered and downloaded successfully.');
      this.project.recordAction('Rendered & exported Master WAV mixdown', 'project');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Render failed';
      this.renderStatus.set(`Render error: ${msg}`);
    } finally {
      this.isRendering.set(false);
    }
  }

  async exportSingleStem(track: StemTrack) {
    this.isRendering.set(true);
    this.renderStatus.set(`Rendering stem: ${track.name}...`);
    try {
      const wavBlob = await this.engine.exportTrackToWav(track, this.selectedBitDepth());
      this.triggerDownload(wavBlob, `${track.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_Stem.wav`);
      this.renderStatus.set(`Exported ${track.name} stem successfully.`);
      this.project.recordAction(`Exported stem: ${track.name}`, 'project');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Stem render failed';
      this.renderStatus.set(`Stem render error: ${msg}`);
    } finally {
      this.isRendering.set(false);
    }
  }

  async exportAllStemsBulk() {
    this.isRendering.set(true);
    this.renderStatus.set('Exporting all stems...');
    try {
      for (const track of this.engine.tracks()) {
        const wavBlob = await this.engine.exportTrackToWav(track, this.selectedBitDepth());
        this.triggerDownload(wavBlob, `${track.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_Stem.wav`);
        await new Promise(r => setTimeout(r, 400));
      }
      this.renderStatus.set('All 4 stems downloaded successfully.');
      this.project.recordAction('Bulk exported all stems as WAV', 'project');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Bulk export failed';
      this.renderStatus.set(`Bulk export error: ${msg}`);
    } finally {
      this.isRendering.set(false);
    }
  }

  private triggerDownload(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
