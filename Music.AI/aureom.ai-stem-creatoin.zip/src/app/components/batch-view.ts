import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ProjectState } from '../services/project-state';
import { BatchItem } from '../models/audio.types';

@Component({
  selector: 'app-batch-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0c10] overflow-y-auto select-none p-4 md:p-6">
      <!-- Title & Header -->
      <div class="flex flex-col gap-1 pb-4 border-b border-white/5">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <mat-icon class="text-sm">queue_music</mat-icon>
            </div>
            <h2 class="font-display text-lg font-bold text-white tracking-tight">
              Aureom Batch Separation Engine
            </h2>
          </div>
          <div class="flex items-center gap-2">
            <button
              (click)="addQueueItem()"
              class="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <mat-icon class="text-sm">add</mat-icon>
              <span>Add Audio Track to Queue</span>
            </button>
            <button
              (click)="startBatchQueue()"
              [disabled]="isQueueRunning()"
              class="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-amber-500/20"
            >
              <mat-icon class="text-sm">{{ isQueueRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
              <span>{{ isQueueRunning() ? 'Pause Batch Worker' : 'Run Batch Queue' }}</span>
            </button>
          </div>
        </div>
        <p class="text-xs text-slate-400">
          Queue multiple albums, EP tracks, or session takes for unattended background separation and bulk stem export.
        </p>
      </div>

      <!-- Queue Status Strip -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3 pt-5 text-xs font-mono">
        <div class="bg-[#12151e] border border-white/5 p-3 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px]">TOTAL JOBS IN QUEUE</span>
          <span class="text-lg font-bold text-white tabular-nums">{{ project.batchQueue().length }} Tracks</span>
        </div>
        <div class="bg-[#12151e] border border-white/5 p-3 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px]">COMPLETED RUNS</span>
          <span class="text-lg font-bold text-emerald-400 tabular-nums">{{ completedCount() }}</span>
        </div>
        <div class="bg-[#12151e] border border-white/5 p-3 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px]">CURRENT MODEL</span>
          <span class="text-xs font-bold text-amber-300 truncate">Demucs v4 HT (Hybrid)</span>
        </div>
        <div class="bg-[#12151e] border border-white/5 p-3 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px]">TARGET DIRECTORY</span>
          <span class="text-xs font-mono text-slate-300 truncate">~/AureomProjects/StemsExport</span>
        </div>
      </div>

      <!-- Queue Table -->
      <div class="bg-[#12151e] border border-white/5 rounded-xl p-5 flex flex-col gap-4 mt-5">
        <div class="flex items-center justify-between border-b border-white/5 pb-2">
          <span class="font-display font-semibold text-xs text-slate-200">Active Batch Queue Jobs</span>
          <span class="text-[10px] font-mono text-slate-400">NAMING: {{ '{track_name}_{stem}.wav' }}</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead>
              <tr class="text-slate-500 border-b border-white/10 pb-2 text-[10px]">
                <th class="py-2">SOURCE FILE</th>
                <th class="py-2">SIZE</th>
                <th class="py-2">DURATION</th>
                <th class="py-2">MODEL</th>
                <th class="py-2">STEMS</th>
                <th class="py-2">STATUS</th>
                <th class="py-2 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5 text-slate-300">
              @for (item of project.batchQueue(); track item.id) {
                <tr class="hover:bg-white/5">
                  <td class="py-3 font-semibold text-white flex items-center gap-2">
                    <mat-icon class="text-sm text-slate-400">audio_file</mat-icon>
                    <span>{{ item.fileName }}</span>
                  </td>
                  <td class="py-3 text-slate-400 tabular-nums">
                    {{ (item.fileSize / (1024 * 1024)).toFixed(1) }} MB
                  </td>
                  <td class="py-3 text-slate-400 tabular-nums">
                    {{ item.duration }}s
                  </td>
                  <td class="py-3 text-amber-300 text-[11px]">
                    {{ item.modelId }}
                  </td>
                  <td class="py-3">
                    <div class="flex gap-1 flex-wrap">
                      @for (s of item.stems; track s) {
                        <span class="text-[9px] px-1 py-0.5 rounded-xs bg-[#090b0f] text-slate-300 border border-white/5">
                          {{ s }}
                        </span>
                      }
                    </div>
                  </td>
                  <td class="py-3">
                    <div class="flex items-center gap-2">
                      <span
                        class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-xs"
                        [class]="item.status === 'completed' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : item.status === 'processing' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-white/5 text-slate-400'"
                      >
                        {{ item.status }}
                      </span>
                      @if (item.status === 'processing') {
                        <span class="text-amber-300 tabular-nums text-[10px]">{{ item.progress }}%</span>
                      }
                    </div>
                  </td>
                  <td class="py-3 text-right">
                    <button
                      (click)="removeQueueItem(item.id)"
                      class="w-6 h-6 rounded-md hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors inline-flex items-center justify-center cursor-pointer"
                      title="Remove from Queue"
                    >
                      <mat-icon class="text-xs">delete</mat-icon>
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class BatchView {
  readonly project = inject(ProjectState);

  readonly isQueueRunning = signal<boolean>(false);

  completedCount() {
    return this.project.batchQueue().filter(i => i.status === 'completed').length;
  }

  addQueueItem() {
    const nextIdx = this.project.batchQueue().length + 1;
    const item: BatchItem = {
      id: `batch-${Date.now()}`,
      fileName: `Session_Recording_Take_${nextIdx}.wav`,
      fileSize: 45000000 + Math.floor(Math.random() * 20000000),
      duration: 195,
      modelId: 'demucs-v4-ht',
      status: 'queued',
      progress: 0,
      stems: ['Vocals', 'Drums', 'Bass', 'Other']
    };
    this.project.batchQueue.update(q => [...q, item]);
    this.project.recordAction(`Added ${item.fileName} to batch queue`, 'edit');
  }

  removeQueueItem(id: string) {
    this.project.batchQueue.update(q => q.filter(i => i.id !== id));
  }

  async startBatchQueue() {
    if (this.isQueueRunning()) {
      this.isQueueRunning.set(false);
      return;
    }

    this.isQueueRunning.set(true);
    const queue = this.project.batchQueue();

    for (const item of queue) {
      if (!this.isQueueRunning()) break;
      if (item.status === 'completed') continue;

      // Mark processing
      this.project.batchQueue.update(q =>
        q.map(it => it.id === item.id ? { ...it, status: 'processing', progress: 10 } : it)
      );

      // Simulate steps
      for (let p = 25; p <= 100; p += 25) {
        await new Promise(r => setTimeout(r, 350));
        if (!this.isQueueRunning()) break;
        this.project.batchQueue.update(q =>
          q.map(it => it.id === item.id ? { ...it, progress: p } : it)
        );
      }

      // Mark completed
      this.project.batchQueue.update(q =>
        q.map(it => it.id === item.id ? { ...it, status: 'completed', progress: 100 } : it)
      );
      this.project.recordAction(`Batch processed: ${item.fileName}`, 'separation');
    }

    this.isQueueRunning.set(false);
  }
}
