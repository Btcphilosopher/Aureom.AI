import { ChangeDetectionStrategy, Component, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Header } from './components/header';
import { TransportBar } from './components/transport-bar';
import { TimelineEditor } from './components/timeline-editor';
import { MixerConsole } from './components/mixer-console';
import { EffectsInspector } from './components/effects-inspector';
import { SeparationView } from './components/separation-view';
import { SpectralView } from './components/spectral-view';
import { IntelligenceView } from './components/intelligence-view';
import { RestorationView } from './components/restoration-view';
import { BatchView } from './components/batch-view';
import { ExportView } from './components/export-view';
import { AuxiliaryViews } from './components/auxiliary-views';
import { AudioEngine } from './services/audio-engine';
import { ProjectState } from './services/project-state';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    Header,
    TransportBar,
    TimelineEditor,
    MixerConsole,
    EffectsInspector,
    SeparationView,
    SpectralView,
    IntelligenceView,
    RestorationView,
    BatchView,
    ExportView,
    AuxiliaryViews
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly project = inject(ProjectState);
  readonly engine = inject(AudioEngine);

  @HostListener('window:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    // Only capture space if not typing in an input
    const tag = (event.target as HTMLElement).tagName.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') {
      return;
    }

    if (event.code === 'Space') {
      event.preventDefault();
      if (this.engine.isPlaying()) {
        this.engine.pause();
      } else {
        this.engine.play();
      }
    }
  }
}

