'use client';

import React, { useState, useEffect } from 'react';
import { CustomCursor } from '@/components/custom-cursor';
import { OpeningLoader } from '@/components/opening-loader';
import { Navbar } from '@/components/navbar';
import { HeroSection } from '@/components/hero-section';
import { MusicSection } from '@/components/music-section';
import { MusicPlayer } from '@/components/music-player';
import { TourSection } from '@/components/tour-section';
import { VideoSection } from '@/components/video-section';
import { NewsSection } from '@/components/news-section';
import { AboutSection } from '@/components/about-section';
import { ShopSection } from '@/components/shop-section';
import { CartDrawer, CartItem } from '@/components/cart-drawer';
import { SearchModal } from '@/components/search-modal';
import { AccountModal } from '@/components/account-modal';
import { Footer } from '@/components/footer';
import { useAudioAmbient } from '@/hooks/use-audio-ambient';
import { Product, TRACKS_LIST } from '@/lib/data';

export default function Home() {
  const [loaderComplete, setLoaderComplete] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [activeTrackId, setActiveTrackId] = useState<string | null>(null);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);

  // Easter Egg: Midnight Visual Mode
  const [signatureClickCount, setSignatureClickCount] = useState(0);
  const [midnightMode, setMidnightMode] = useState(false);

  // Ambient Web Audio Hook
  const { soundEnabled, toggleSound, playHoverSound, playClickSound } = useAudioAmbient();

  // Handle Signature Click Easter Egg
  const handleSignatureClick = () => {
    setSignatureClickCount((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        setMidnightMode((m) => !m);
        return 0;
      }
      return next;
    });
  };

  // Cart actions
  const handleAddToCart = (product: Product, size?: string) => {
    playClickSound();
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.size === size
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += 1;
        return updated;
      }
      return [...prev, { product, size, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, size: string | undefined, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId && item.size === size) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (productId: string, size: string | undefined) => {
    setCartItems((prev) =>
      prev.filter((item) => !(item.product.id === productId && item.size === size))
    );
  };

  const handleClearCart = () => setCartItems([]);

  // Track player selection
  const handlePlayTrack = (trackId: string) => {
    playClickSound();
    setActiveTrackId(trackId);
  };

  const handleNavigateSection = (sectionId: string) => {
    const elem = document.querySelector(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Keyboard shortcut listener ('M' for music player, 'S' for shop, 'T' for tour)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key.toLowerCase() === 'm') {
        setActiveTrackId('track-1');
      } else if (e.key.toLowerCase() === 's') {
        handleNavigateSection('#shop');
      } else if (e.key.toLowerCase() === 't') {
        handleNavigateSection('#tour');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <main
      className={`min-h-screen bg-[#05070d] text-white relative font-sans transition-colors duration-1000 ${
        midnightMode ? 'filter grayscale brightness-110 contrast-125' : ''
      }`}
    >
      {/* Custom Mouse Cursor */}
      <CustomCursor />

      {/* Opening Loader */}
      {!loaderComplete && (
        <OpeningLoader onComplete={() => setLoaderComplete(true)} />
      )}

      {/* Main Navbar */}
      <Navbar
        activeSection={activeSection}
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
      />

      {/* Hero Section */}
      <HeroSection
        onPlayTrack={handlePlayTrack}
        onNavigateSection={handleNavigateSection}
        signatureClickCount={signatureClickCount}
        onSignatureClick={handleSignatureClick}
      />

      {/* Discography & Latest Music */}
      <MusicSection
        onPlayTrack={handlePlayTrack}
        onOpenFullPlayer={() => setActiveTrackId('track-1')}
      />

      {/* Tour Section */}
      <TourSection />

      {/* Video Gallery */}
      <VideoSection />

      {/* Editorial News */}
      <NewsSection />

      {/* About & Biography */}
      <AboutSection />

      {/* Storefront */}
      <ShopSection onAddToCart={handleAddToCart} />

      {/* Footer */}
      <Footer />

      {/* Floating & Fullscreen Music Player */}
      <MusicPlayer
        activeTrackId={activeTrackId}
        onClosePlayer={() => setActiveTrackId(null)}
        onSelectTrack={(id) => setActiveTrackId(id)}
      />

      {/* Slide-out Shopping Cart */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Search Overlay */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectTrack={handlePlayTrack}
      />

      {/* Account / VIP Access Pass Modal */}
      <AccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
      />
    </main>
  );
}
