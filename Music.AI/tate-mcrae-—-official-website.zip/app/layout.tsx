import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Tate McRae — Official Website',
  description: "The official world of Tate McRae. Explore 'So Close To What', Think Later Tour dates, discography, music videos, editorial news, and exclusive merchandise.",
  openGraph: {
    title: 'Tate McRae — Official Website',
    description: "The official world of Tate McRae. Explore 'So Close To What', Think Later Tour dates, discography, music videos, editorial news, and exclusive merchandise.",
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tate McRae — Official Website',
    description: "The official world of Tate McRae. Explore 'So Close To What', Think Later Tour dates, discography, music videos, editorial news, and exclusive merchandise.",
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Italianno&family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&family=Syne:wght@400..800&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#05070d] text-slate-100 antialiased selection:bg-blue-500/30 selection:text-white min-h-screen overflow-x-hidden font-sans" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
