export interface Track {
  id: string;
  title: string;
  duration: string;
  album: string;
  coverUrl: string;
  audioUrl?: string;
  lyrics?: string;
}

export interface Album {
  id: string;
  title: string;
  type: 'Album' | 'EP' | 'Single';
  year: string;
  coverUrl: string;
  description: string;
  spotifyUrl: string;
  appleMusicUrl: string;
  tracks: Track[];
}

export interface TourDate {
  id: string;
  date: string;
  month: string;
  day: string;
  year: string;
  city: string;
  country: string;
  venue: string;
  region: 'NORTH AMERICA' | 'UK & EUROPE' | 'AUSTRALIA' | 'LATIN AMERICA';
  status: 'ON SALE' | 'SOLD OUT' | 'FEW TICKETS' | 'PRESALE';
  ticketUrl: string;
  vipAvailable: boolean;
  heroImage: string;
}

export interface VideoItem {
  id: string;
  title: string;
  type: 'Official Video' | 'Live Performance' | 'Behind The Scenes' | 'Dance Visualizer';
  director: string;
  duration: string;
  thumbnailUrl: string;
  embedId: string;
  description: string;
  views: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  category: 'NEW MUSIC' | 'ON TOUR' | 'BEHIND THE SCENES' | 'EDITORIAL' | 'FASHION';
  date: string;
  readTime: string;
  imageUrl: string;
  excerpt: string;
  content: string;
  publisher: string;
}

export interface Product {
  id: string;
  name: string;
  category: 'Apparel' | 'Vinyl & Music' | 'Accessories' | 'Tour Special';
  price: number;
  imageUrl: string;
  hoverImageUrl: string;
  description: string;
  sizes?: string[];
  isExclusive?: boolean;
  isNew?: boolean;
}

// Curated high-res imagery matching Tate McRae aesthetic: dark cinematic photography, dusk blue & silver palette, fashion editorial
export const TATE_IMAGES = {
  // Main Hero image: Dusk cityscape with sleek sports car and pop star energy
  heroMain: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=2000&auto=format&fit=crop", // Dusk skyline / car moody
  heroPortrait: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1200&auto=format&fit=crop", // Pop star portrait
  sportsCarSingle: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?q=80&w=1000&auto=format&fit=crop", // Denim jacket pop aesthetic
  soCloseToWhatAlbum: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=1200&auto=format&fit=crop", // Deep blue studio light
  thinkLaterAlbum: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?q=80&w=1200&auto=format&fit=crop", // Concert stage dark blue
  tourConcert: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=1200&auto=format&fit=crop", // Stage lights blue atmosphere
  editorialPortrait1: "https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1200&auto=format&fit=crop", // Editorial fashion
  editorialPortrait2: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?q=80&w=1200&auto=format&fit=crop", // Moody studio shot
  danceStudio: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=1200&auto=format&fit=crop", // Dance rehearsal
  torontoSkyline: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?q=80&w=1600&auto=format&fit=crop", // Dusk skyline
  merchHoodie: "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=800&auto=format&fit=crop",
  merchVinyl: "https://images.unsplash.com/photo-1539185441755-769473a23570?q=80&w=800&auto=format&fit=crop",
  merchJacket: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=800&auto=format&fit=crop",
  merchCap: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=800&auto=format&fit=crop",
};

export const FEATURED_RELEASE = {
  title: "SO CLOSE TO WHAT",
  artist: "TATE MCRAE",
  releaseType: "THE NEW ALBUM",
  status: "OUT NOW",
  coverUrl: TATE_IMAGES.soCloseToWhatAlbum,
  description: "Tate McRae's highly anticipated sophomore studio era. Exploring raw vulnerability, high-energy dance anthems, and cinematic pop storytelling.",
  leadSingle: {
    title: "Sports Car",
    duration: "3:08",
    coverUrl: TATE_IMAGES.sportsCarSingle
  }
};

export const TRACKS_LIST: Track[] = [
  {
    id: "track-1",
    title: "Sports Car",
    duration: "3:08",
    album: "So Close To What",
    coverUrl: TATE_IMAGES.sportsCarSingle,
    lyrics: "Driving down the 401 at midnight\nThought I saw your face in every headlight\nYou said you loved the way I take control\nNow I'm speeding fast, losing all control..."
  },
  {
    id: "track-2",
    title: "It's ok I'm ok",
    duration: "2:54",
    album: "So Close To What",
    coverUrl: TATE_IMAGES.soCloseToWhatAlbum,
    lyrics: "It's ok, I'm ok, I don't care anyway\nYou can have him if you want him, he was fake\nIt's ok, I'm ok, watch me step out the frame..."
  },
  {
    id: "track-3",
    title: "2 hands",
    duration: "2:42",
    album: "So Close To What",
    coverUrl: TATE_IMAGES.soCloseToWhatAlbum,
    lyrics: "I need two hands on the wheel when I ride\nKeep your eyes on the road, keep your hands on my side..."
  },
  {
    id: "track-4",
    title: "Greedy",
    duration: "2:11",
    album: "Think Later",
    coverUrl: TATE_IMAGES.thinkLaterAlbum,
    lyrics: "I would want myself if I was you\nI would want myself if I was you..."
  },
  {
    id: "track-5",
    title: "Exes",
    duration: "2:39",
    album: "Think Later",
    coverUrl: TATE_IMAGES.thinkLaterAlbum,
    lyrics: "Kisses to my exes who I know are still obsessed with me..."
  },
  {
    id: "track-6",
    title: "So Close To What",
    duration: "3:22",
    album: "So Close To What",
    coverUrl: TATE_IMAGES.soCloseToWhatAlbum,
    lyrics: "Standing on the edge of everything I ever wanted\nAsking myself why I still feel haunted..."
  },
  {
    id: "track-7",
    title: "you broke me first",
    duration: "2:49",
    album: "TOO YOUNG TO BE SAD",
    coverUrl: TATE_IMAGES.editorialPortrait2,
    lyrics: "Maybe you don't like talking too much about yourself\nBut you shoulda told me that you were thinking 'bout someone else..."
  },
  {
    id: "track-8",
    title: "run for the hills",
    duration: "2:23",
    album: "Think Later",
    coverUrl: TATE_IMAGES.editorialPortrait1,
    lyrics: "We make a disaster look like art\nYou break my spirit, I break your heart..."
  }
];

export const ALBUMS: Album[] = [
  {
    id: "so-close-to-what",
    title: "So Close To What",
    type: "Album",
    year: "2025",
    coverUrl: TATE_IMAGES.soCloseToWhatAlbum,
    description: "The benchmark pop record of the decade. Fusing sleek high-octane production with Tate's signature introspective lyricism and flawless vocal production.",
    spotifyUrl: "https://spotify.com",
    appleMusicUrl: "https://apple.com",
    tracks: TRACKS_LIST.filter(t => t.album === "So Close To What")
  },
  {
    id: "think-later",
    title: "Think Later",
    type: "Album",
    year: "2023",
    coverUrl: TATE_IMAGES.thinkLaterAlbum,
    description: "The global breakout album featuring multi-platinum chart toppers 'Greedy' and 'Exes'. Executive produced by Ryan Tedder.",
    spotifyUrl: "https://spotify.com",
    appleMusicUrl: "https://apple.com",
    tracks: TRACKS_LIST.filter(t => t.album === "Think Later")
  },
  {
    id: "i-used-to-think-i-could-fly",
    title: "i used to think i could fly",
    type: "Album",
    year: "2022",
    coverUrl: TATE_IMAGES.editorialPortrait1,
    description: "Tate's acclaimed debut album featuring 'she's all i wanna be' and 'chaotic'.",
    spotifyUrl: "https://spotify.com",
    appleMusicUrl: "https://apple.com",
    tracks: TRACKS_LIST.slice(4, 8)
  },
  {
    id: "too-young-to-be-sad",
    title: "TOO YOUNG TO BE SAD",
    type: "EP",
    year: "2021",
    coverUrl: TATE_IMAGES.editorialPortrait2,
    description: "The record-breaking EP featuring the global megahit 'you broke me first'.",
    spotifyUrl: "https://spotify.com",
    appleMusicUrl: "https://apple.com",
    tracks: TRACKS_LIST.filter(t => t.album === "TOO YOUNG TO BE SAD")
  }
];

export const TOUR_DATES: TourDate[] = [
  {
    id: "tour-1",
    date: "NOV 12",
    month: "NOV",
    day: "12",
    year: "2025",
    city: "LONDON",
    country: "UNITED KINGDOM",
    venue: "THE O2 ARENA",
    region: "UK & EUROPE",
    status: "ON SALE",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.tourConcert
  },
  {
    id: "tour-2",
    date: "NOV 15",
    month: "NOV",
    day: "15",
    year: "2025",
    city: "PARIS",
    country: "FRANCE",
    venue: "ACCOR ARENA",
    region: "UK & EUROPE",
    status: "SOLD OUT",
    ticketUrl: "#tickets",
    vipAvailable: false,
    heroImage: TATE_IMAGES.heroMain
  },
  {
    id: "tour-3",
    date: "NOV 19",
    month: "NOV",
    day: "19",
    year: "2025",
    city: "AMSTERDAM",
    country: "NETHERLANDS",
    venue: "ZIGGO DOME",
    region: "UK & EUROPE",
    status: "FEW TICKETS",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.tourConcert
  },
  {
    id: "tour-4",
    date: "NOV 22",
    month: "NOV",
    day: "22",
    year: "2025",
    city: "BERLIN",
    country: "GERMANY",
    venue: "UBER ARENA",
    region: "UK & EUROPE",
    status: "ON SALE",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.editorialPortrait2
  },
  {
    id: "tour-5",
    date: "DEC 02",
    month: "DEC",
    day: "02",
    year: "2025",
    city: "NEW YORK",
    country: "UNITED STATES",
    venue: "MADISON SQUARE GARDEN",
    region: "NORTH AMERICA",
    status: "ON SALE",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.torontoSkyline
  },
  {
    id: "tour-6",
    date: "DEC 06",
    month: "DEC",
    day: "06",
    year: "2025",
    city: "LOS ANGELES",
    country: "UNITED STATES",
    venue: "KIA FORUM",
    region: "NORTH AMERICA",
    status: "SOLD OUT",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.sportsCarSingle
  },
  {
    id: "tour-7",
    date: "DEC 10",
    month: "DEC",
    day: "10",
    year: "2025",
    city: "TORONTO",
    country: "CANADA",
    venue: "SCOTIABANK ARENA",
    region: "NORTH AMERICA",
    status: "ON SALE",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.heroMain
  },
  {
    id: "tour-8",
    date: "JAN 20",
    month: "JAN",
    day: "20",
    year: "2026",
    city: "SYDNEY",
    country: "AUSTRALIA",
    venue: "QUDOS BANK ARENA",
    region: "AUSTRALIA",
    status: "ON SALE",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.tourConcert
  },
  {
    id: "tour-9",
    date: "JAN 24",
    month: "JAN",
    day: "24",
    year: "2026",
    city: "MELBOURNE",
    country: "AUSTRALIA",
    venue: "ROD LAVER ARENA",
    region: "AUSTRALIA",
    status: "FEW TICKETS",
    ticketUrl: "#tickets",
    vipAvailable: true,
    heroImage: TATE_IMAGES.editorialPortrait1
  }
];

export const VIDEOS: VideoItem[] = [
  {
    id: "video-1",
    title: "Sports Car (Official Music Video)",
    type: "Official Video",
    director: "Bardin & Tate McRae",
    duration: "3:15",
    thumbnailUrl: TATE_IMAGES.sportsCarSingle,
    embedId: "dQw4w9WgXcQ",
    description: "Shot on 35mm film across the twilight highways of Toronto. Directed by Bardin.",
    views: "42M views"
  },
  {
    id: "video-2",
    title: "It's ok I'm ok (Official Music Video)",
    type: "Official Video",
    director: "Hannah Lux Davis",
    duration: "3:02",
    thumbnailUrl: TATE_IMAGES.heroPortrait,
    embedId: "dQw4w9WgXcQ",
    description: "High-voltage choreography through the streets of New York City.",
    views: "89M views"
  },
  {
    id: "video-3",
    title: "Greedy (Official Music Video)",
    type: "Official Video",
    director: "Aeril",
    duration: "2:20",
    thumbnailUrl: TATE_IMAGES.thinkLaterAlbum,
    embedId: "dQw4w9WgXcQ",
    description: "Set inside an empty ice hockey arena. Tate's iconic dance break.",
    views: "210M views"
  },
  {
    id: "video-4",
    title: "2 hands (Official Music Video)",
    type: "Official Video",
    director: "Aeril",
    duration: "2:50",
    thumbnailUrl: TATE_IMAGES.editorialPortrait1,
    embedId: "dQw4w9WgXcQ",
    description: "Night racing aesthetics meet contemporary ballet.",
    views: "35M views"
  },
  {
    id: "video-5",
    title: "Think Later Tour — Live from MSG",
    type: "Live Performance",
    director: "Live Nation Visuals",
    duration: "4:45",
    thumbnailUrl: TATE_IMAGES.tourConcert,
    embedId: "dQw4w9WgXcQ",
    description: "Full arena crowd singalong live at Madison Square Garden.",
    views: "15M views"
  },
  {
    id: "video-6",
    title: "So Close To What: Making of the Album",
    type: "Behind The Scenes",
    director: "RCA Creative",
    duration: "12:10",
    thumbnailUrl: TATE_IMAGES.danceStudio,
    embedId: "dQw4w9WgXcQ",
    description: "Exclusive studio sessions in Los Angeles and London with Ryan Tedder and Jasper.",
    views: "8M views"
  }
];

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: "news-1",
    title: "Tate McRae Unveils New Era 'So Close To What'",
    category: "NEW MUSIC",
    date: "OCTOBER 18, 2025",
    readTime: "4 MIN READ",
    imageUrl: TATE_IMAGES.heroPortrait,
    excerpt: "With 'Sports Car' breaking streaming records worldwide, Tate McRae opens up about taking full creative control over her biggest album yet.",
    content: "Tate McRae continues her meteoric rise to global pop dominance with the release of 'So Close To What'. The record represents a pivotal evolution in her songwriting and dance artistry...",
    publisher: "VOGUE EDITORIAL"
  },
  {
    id: "news-2",
    title: "Think Later World Tour Sells Out 45 Arena Dates",
    category: "ON TOUR",
    date: "OCTOBER 10, 2025",
    readTime: "3 MIN READ",
    imageUrl: TATE_IMAGES.tourConcert,
    excerpt: "From London's O2 to New York's MSG, tickets for the global arena tour sold out in under 10 minutes across 3 continents.",
    content: "Pop sensation Tate McRae has shattered ticketing records for her upcoming 2025/2026 World Tour...",
    publisher: "BILLBOARD"
  },
  {
    id: "news-3",
    title: "The Fashion of Tate McRae: High Octane Leather & Modern Sensuality",
    category: "FASHION",
    date: "SEPTEMBER 28, 2025",
    readTime: "5 MIN READ",
    imageUrl: TATE_IMAGES.editorialPortrait1,
    excerpt: "A deep dive into Tate's signature aesthetic blending vintage motorsport silhouettes with haute couture elegance.",
    content: "In conversation with Vogue Style Editor, Tate discusses her visual collaborators, custom tour wardrobing, and aesthetic inspirations...",
    publisher: "HARPER'S BAZAAR"
  }
];

export const SHOP_PRODUCTS: Product[] = [
  {
    id: "prod-1",
    name: "SO CLOSE TO WHAT Oversized Heavyweight Hoodie",
    category: "Apparel",
    price: 95,
    imageUrl: TATE_IMAGES.merchHoodie,
    hoverImageUrl: TATE_IMAGES.editorialPortrait1,
    description: "100% 450gsm organic cotton hoodie with custom metallic silver puff print front and back graphics.",
    sizes: ["S", "M", "L", "XL", "2XL"],
    isNew: true
  },
  {
    id: "prod-2",
    name: "SPORTS CAR Vintage Wash Tour Tee",
    category: "Apparel",
    price: 45,
    imageUrl: TATE_IMAGES.sportsCarSingle,
    hoverImageUrl: TATE_IMAGES.heroMain,
    description: "Custom vintage enzyme washed tee with screenprinted photo portrait and 2025 tour cities.",
    sizes: ["S", "M", "L", "XL"],
    isNew: true
  },
  {
    id: "prod-3",
    name: "SO CLOSE TO WHAT Limited Edition Blue Smoke Vinyl",
    category: "Vinyl & Music",
    price: 38,
    imageUrl: TATE_IMAGES.merchVinyl,
    hoverImageUrl: TATE_IMAGES.soCloseToWhatAlbum,
    description: "180g translucent cobalt blue marble vinyl in gatefold jacket with 16-page photo booklet and signed art card.",
    isExclusive: true,
    isNew: true
  },
  {
    id: "prod-4",
    name: "THINK LATER World Tour Leather Bomber Jacket",
    category: "Apparel",
    price: 220,
    imageUrl: TATE_IMAGES.merchJacket,
    hoverImageUrl: TATE_IMAGES.editorialPortrait2,
    description: "Premium vegan leather jacket with embroidered silver signature, custom satin lining, and heavy metal hardware.",
    sizes: ["S", "M", "L", "XL"],
    isExclusive: true
  },
  {
    id: "prod-5",
    name: "TATE Metallic Embroidered Cap",
    category: "Accessories",
    price: 35,
    imageUrl: TATE_IMAGES.merchCap,
    hoverImageUrl: TATE_IMAGES.editorialPortrait1,
    description: "Structured 6-panel washed cotton cap featuring silver metallic thread embroidery and adjustable strap.",
    sizes: ["ONE SIZE"]
  },
  {
    id: "prod-6",
    name: "SO CLOSE TO WHAT Collector's Signed Poster Set",
    category: "Vinyl & Music",
    price: 30,
    imageUrl: TATE_IMAGES.heroPortrait,
    hoverImageUrl: TATE_IMAGES.editorialPortrait2,
    description: "Set of 3 metallic foil metallic lithograph posters (18x24 in) individually hand-signed by Tate McRae.",
    isExclusive: true
  }
];
