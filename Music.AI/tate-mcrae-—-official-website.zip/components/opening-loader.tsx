'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface OpeningLoaderProps {
  onComplete: () => void;
}

export function OpeningLoader({ onComplete }: OpeningLoaderProps) {
  const [progress, setProgress] = useState(0);
  const [isReady, setIsReady] = useState(false);
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    // Fast, smooth loading progress simulation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsReady(true);
          return 100;
        }
        return prev + Math.floor(Math.random() * 15) + 8;
      });
    }, 60);

    return () => clearInterval(interval);
  }, []);

  const handleEnter = () => {
    setIsDone(true);
    setTimeout(() => {
      onComplete();
    }, 800);
  };

  return (
    <AnimatePresence>
      {!isDone && (
        <motion.div
          key="loader-overlay"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-[10000] flex flex-col items-center justify-center bg-[#030508] text-white select-none px-6"
        >
          {/* Subtle Ambient Film Grain */}
          <div className="absolute inset-0 bg-grain pointer-events-none opacity-40" />

          {/* Glowing background halo */}
          <div className="absolute w-[500px] h-[500px] bg-blue-900/10 blur-[140px] rounded-full pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center max-w-sm w-full text-center">
            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="text-2xl sm:text-3xl tracking-[0.35em] font-syne font-light text-slate-100 uppercase mb-8"
            >
              TATE MCRAE
            </motion.h1>

            {/* Progress line */}
            <div className="w-full h-[1px] bg-white/10 rounded-full overflow-hidden relative mb-6">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-600 via-cyan-300 to-white shadow-[0_0_12px_rgba(0,180,255,0.8)]"
                style={{ width: `${progress}%` }}
                transition={{ ease: 'easeOut' }}
              />
            </div>

            {/* Subtext or Enter button */}
            <div className="h-10 flex items-center justify-center">
              {!isReady ? (
                <span className="text-[10px] tracking-[0.3em] text-slate-400 font-mono uppercase">
                  {progress}% · INITIALIZING AUDIOVISUAL WORLD
                </span>
              ) : (
                <motion.button
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.05, letterSpacing: '0.4em' }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleEnter}
                  data-cursor="ENTER"
                  className="px-8 py-2.5 rounded-full border border-white/30 bg-white/5 hover:bg-white/15 text-white text-xs font-syne tracking-[0.3em] uppercase transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(0,180,255,0.3)] hover:border-cyan-400/60"
                >
                  ENTER
                </motion.button>
              )}
            </div>
          </div>

          <div className="absolute bottom-8 left-0 right-0 text-center">
            <span className="text-[9px] tracking-[0.3em] text-slate-600 uppercase font-mono">
              SO CLOSE TO WHAT · WORLD TOUR 2025/2026
            </span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
