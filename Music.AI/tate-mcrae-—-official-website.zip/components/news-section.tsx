'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, X, Newspaper, Calendar, Clock } from 'lucide-react';
import { NEWS_ARTICLES, NewsArticle } from '@/lib/data';

export function NewsSection() {
  const [activeArticleModal, setActiveArticleModal] = useState<NewsArticle | null>(null);

  const primaryArticle = NEWS_ARTICLES[0];
  const secondaryArticles = NEWS_ARTICLES.slice(1);

  return (
    <section id="news" className="relative py-28 sm:py-36 bg-[#03050a] text-white overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-white/10 pb-8 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-syne text-cyan-400 uppercase font-medium block mb-2">
              EDITORIAL PRESS & ANNOUNCEMENTS
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-8xl font-syne font-light tracking-tight text-white uppercase">
              NEWS
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 uppercase tracking-widest max-w-xs">
            Vogue, Billboard, Rolling Stone &amp; Harper&apos;s Bazaar.
          </p>
        </div>

        {/* Asymmetric Editorial Magazine Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Hero Article (7 Cols) */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            onClick={() => setActiveArticleModal(primaryArticle)}
            data-cursor="READ"
            className="lg:col-span-7 group cursor-pointer border border-white/10 bg-[#080d19] rounded-sm overflow-hidden hover:border-cyan-400/60 transition-all duration-500 shadow-2xl flex flex-col justify-between"
          >
            <div className="relative aspect-[16/10] overflow-hidden">
              <img
                src={primaryArticle.imageUrl}
                alt={primaryArticle.title}
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-md px-3 py-1 rounded text-[10px] font-mono text-cyan-300 uppercase tracking-widest border border-white/10">
                {primaryArticle.category}
              </div>
            </div>

            <div className="p-8 sm:p-10 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center space-x-4 text-xs font-mono text-slate-400 uppercase mb-3">
                  <span>{primaryArticle.publisher}</span>
                  <span>·</span>
                  <span>{primaryArticle.date}</span>
                </div>
                <h3 className="text-2xl sm:text-4xl font-syne font-light uppercase text-white group-hover:text-cyan-300 transition-colors tracking-tight leading-snug mb-4">
                  {primaryArticle.title}
                </h3>
                <p className="text-sm text-slate-300 font-sans leading-relaxed font-light line-clamp-3">
                  {primaryArticle.excerpt}
                </p>
              </div>

              <div className="pt-8 flex items-center gap-2 text-xs font-syne tracking-[0.25em] text-white group-hover:text-cyan-300 font-semibold uppercase">
                <span>READ FULL STORY</span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </div>
            </div>
          </motion.div>

          {/* Secondary Articles Stack (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            {secondaryArticles.map((article) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                onClick={() => setActiveArticleModal(article)}
                data-cursor="READ"
                className="group cursor-pointer border border-white/10 bg-[#080d19] p-6 rounded-sm hover:border-cyan-400/60 transition-all duration-500 shadow-xl flex gap-6 items-center"
              >
                <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-sm overflow-hidden relative flex-shrink-0 border border-white/10">
                  <img
                    src={article.imageUrl}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest block mb-1">
                    {article.category} · {article.readTime}
                  </span>
                  <h4 className="text-lg font-syne font-semibold uppercase text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
                    {article.title}
                  </h4>
                  <span className="text-xs font-mono text-slate-400 block mt-2 uppercase">
                    {article.publisher}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* ARTICLE READER MODAL OVERLAY */}
      <AnimatePresence>
        {activeArticleModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[8000] bg-black/85 backdrop-blur-2xl flex items-center justify-center p-6"
            onClick={() => setActiveArticleModal(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#090f1f] border border-white/20 rounded-sm p-6 sm:p-12 max-w-3xl w-full text-white shadow-2xl relative max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-start border-b border-white/10 pb-6 mb-6">
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">
                    {activeArticleModal.publisher} · {activeArticleModal.date}
                  </span>
                  <h3 className="text-2xl sm:text-4xl font-syne font-light uppercase text-white mt-1">
                    {activeArticleModal.title}
                  </h3>
                </div>
                <button
                  onClick={() => setActiveArticleModal(null)}
                  className="p-2.5 rounded-full border border-white/20 bg-white/10 text-white"
                  aria-label="Close article"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6 text-slate-200 font-sans font-light leading-relaxed">
                <img
                  src={activeArticleModal.imageUrl}
                  alt={activeArticleModal.title}
                  className="w-full aspect-video object-cover rounded-sm border border-white/10"
                  referrerPolicy="no-referrer"
                />
                <p className="text-lg font-syne text-cyan-200 font-medium italic">
                  &quot;{activeArticleModal.excerpt}&quot;
                </p>
                <p>{activeArticleModal.content}</p>
                <p>
                  Tate McRae&apos;s artistic evolution continues to redefine modern pop culture, seamlessly combining physical dance discipline with authentic vulnerability.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
