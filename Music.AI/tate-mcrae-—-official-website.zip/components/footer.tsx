'use client';

import React, { useState } from 'react';
import { ArrowUp, Instagram, Music, Youtube, Check } from 'lucide-react';

export function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 3000);
      setEmail('');
    }
  };

  return (
    <footer className="relative bg-[#020306] text-white border-t border-white/10 pt-20 pb-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-10">
        {/* Top Newsletter & Brand Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-white/10 items-start">
          <div className="lg:col-span-6 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-syne font-light uppercase tracking-tight text-white">
              JOIN TATE&apos;S WORLD
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 font-sans max-w-md leading-relaxed font-light">
              Subscribe for instant notifications on surprise song drops, secret pop-up shows, tour ticket presales, and exclusive fashion merchandise.
            </p>
          </div>

          <div className="lg:col-span-6">
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ENTER YOUR EMAIL ADDRESS"
                className="flex-1 px-5 py-3.5 bg-white/5 border border-white/20 text-xs font-mono text-white placeholder:text-slate-500 uppercase focus:outline-none focus:border-cyan-400 rounded-sm"
              />
              <button
                type="submit"
                className="px-8 py-3.5 bg-white text-black hover:bg-cyan-300 font-syne text-xs font-bold tracking-[0.25em] uppercase transition-colors rounded-sm flex items-center justify-center gap-2"
              >
                {subscribed ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>SUBSCRIBED</span>
                  </>
                ) : (
                  <span>JOIN NETWORK</span>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Middle Navigation & Social Presence */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 py-16 border-b border-white/10 text-xs">
          <div>
            <span className="font-syne font-semibold tracking-widest uppercase text-cyan-400 block mb-4">
              MUSIC
            </span>
            <ul className="space-y-2.5 font-sans text-slate-400 font-light">
              <li><a href="#music" className="hover:text-white transition-colors">So Close To What</a></li>
              <li><a href="#music" className="hover:text-white transition-colors">Think Later</a></li>
              <li><a href="#music" className="hover:text-white transition-colors">i used to think i could fly</a></li>
              <li><a href="#music" className="hover:text-white transition-colors">TOO YOUNG TO BE SAD</a></li>
            </ul>
          </div>

          <div>
            <span className="font-syne font-semibold tracking-widest uppercase text-cyan-400 block mb-4">
              TOUR
            </span>
            <ul className="space-y-2.5 font-sans text-slate-400 font-light">
              <li><a href="#tour" className="hover:text-white transition-colors">North America</a></li>
              <li><a href="#tour" className="hover:text-white transition-colors">UK &amp; Europe</a></li>
              <li><a href="#tour" className="hover:text-white transition-colors">Australia &amp; NZ</a></li>
              <li><a href="#tour" className="hover:text-white transition-colors">VIP Packages</a></li>
            </ul>
          </div>

          <div>
            <span className="font-syne font-semibold tracking-widest uppercase text-cyan-400 block mb-4">
              STORE
            </span>
            <ul className="space-y-2.5 font-sans text-slate-400 font-light">
              <li><a href="#shop" className="hover:text-white transition-colors">Apparel &amp; Hoodies</a></li>
              <li><a href="#shop" className="hover:text-white transition-colors">Vinyl &amp; CDs</a></li>
              <li><a href="#shop" className="hover:text-white transition-colors">Tour Accessories</a></li>
              <li><a href="#shop" className="hover:text-white transition-colors">Signed Collectors</a></li>
            </ul>
          </div>

          <div>
            <span className="font-syne font-semibold tracking-widest uppercase text-cyan-400 block mb-4">
              SOCIAL
            </span>
            <ul className="space-y-2.5 font-sans text-slate-400 font-light">
              <li><a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">Instagram</a></li>
              <li><a href="https://tiktok.com" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">TikTok</a></li>
              <li><a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">YouTube</a></li>
              <li><a href="https://spotify.com" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">Spotify</a></li>
            </ul>
          </div>

          <div className="col-span-2 flex flex-col justify-between items-start md:items-end">
            <button
              onClick={scrollToTop}
              className="px-5 py-2.5 border border-white/20 bg-white/5 hover:bg-white/15 text-white font-syne text-[11px] tracking-widest uppercase rounded-sm flex items-center gap-2 transition-colors"
            >
              <span>BACK TO TOP</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
            <span className="font-signature text-4xl text-slate-400 pt-6">Tate McRae</span>
          </div>
        </div>

        {/* Bottom Bar matching screenshot footer design */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-400 gap-4">
          <div className="flex items-center space-x-6 text-slate-300">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-cyan-300 transition-colors">INSTAGRAM</a>
            <a href="https://tiktok.com" target="_blank" rel="noreferrer" className="hover:text-cyan-300 transition-colors">TIKTOK</a>
            <a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:text-cyan-300 transition-colors">YOUTUBE</a>
            <a href="https://spotify.com" target="_blank" rel="noreferrer" className="hover:text-cyan-300 transition-colors">SPOTIFY</a>
          </div>

          <div className="tracking-[0.25em] uppercase text-slate-400">
            MUSIC &nbsp;/&nbsp; ARTIST &nbsp;/&nbsp; DREAMER
          </div>
        </div>
      </div>
    </footer>
  );
}
