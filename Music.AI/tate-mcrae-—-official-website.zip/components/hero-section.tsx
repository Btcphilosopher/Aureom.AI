'use client';

import React, { useState, useEffect } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { Play, ArrowRight } from 'lucide-react';
import { TATE_IMAGES, FEATURED_RELEASE } from '@/lib/data';

interface HeroSectionProps {
  onPlayTrack: (trackId: string) => void;
  onNavigateSection: (sectionId: string) => void;
  signatureClickCount: number;
  onSignatureClick: () => void;
}

export function HeroSection({
  onPlayTrack,
  onNavigateSection,
  signatureClickCount,
  onSignatureClick,
}: HeroSectionProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  // Mouse position spring interpolation for layered cinematic parallax
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 30, stiffness: 100, mass: 0.5 };
  const smoothX = useSpring(mouseX, springConfig);
  const smoothY = useSpring(mouseY, springConfig);

  // Layer translations
  const backgroundX = useTransform(smoothX, [-0.5, 0.5], [-12, 12]);
  const backgroundY = useTransform(smoothY, [-0.5, 0.5], [-12, 12]);

  const tateLayerX = useTransform(smoothX, [-0.5, 0.5], [-24, 24]);
  const tateLayerY = useTransform(smoothY, [-0.5, 0.5], [-18, 18]);

  const typographyX = useTransform(smoothX, [-0.5, 0.5], [-8, 8]);
  const typographyY = useTransform(smoothY, [-0.5, 0.5], [-5, 5]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = e.clientX / innerWidth - 0.5;
      const y = e.clientY / innerHeight - 0.5;
      mouseX.set(x);
      mouseY.set(y);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <section className="relative w-full h-screen min-h-[750px] overflow-hidden bg-[#05070d] text-white flex flex-col justify-between select-none">
      {/* 1. CINEMATIC BACKGROUND LAYER (Toronto Dusk Skyline & Car) */}
      <motion.div
        style={{ x: backgroundX, y: backgroundY }}
        className="absolute inset-0 z-0 pointer-events-none"
      >
        <motion.div
          initial={{ scale: 1.08, opacity: 0 }}
          animate={{ scale: isLoaded ? 1.02 : 1.08, opacity: isLoaded ? 1 : 0 }}
          transition={{ duration: 2.4, ease: [0.16, 1, 0.3, 1] }}
          className="w-full h-full bg-cover bg-center bg-no-repeat filter brightness-90 contrast-[1.05]"
          style={{ backgroundImage: `url(${TATE_IMAGES.heroMain})` }}
        />
        {/* Deep blue / dark twilight vignette overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#05070d] via-[#05070d]/40 to-black/60" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#05070d]/80 via-transparent to-[#05070d]/60" />
      </motion.div>

      {/* 2. TATE MCRAE FOCAL LAYER (Moves independently for depth) */}
      <motion.div
        style={{ x: tateLayerX, y: tateLayerY }}
        className="absolute inset-0 z-1 pointer-events-none flex items-center justify-center"
      >
        <div className="w-full h-full max-w-7xl mx-auto relative">
          {/* Subtle lighting spotlight glow behind Tate */}
          <div className="absolute top-1/3 right-1/4 w-[450px] h-[450px] bg-cyan-500/10 rounded-full blur-[120px] animate-subtle-glow" />
        </div>
      </motion.div>

      {/* Subtle Grain Overlay */}
      <div className="absolute inset-0 z-2 bg-grain pointer-events-none opacity-30" />

      {/* 3. HERO TYPOGRAPHY & INTERFACE LAYER */}
      <motion.div
        style={{ x: typographyX, y: typographyY }}
        className="relative z-10 max-w-7xl mx-auto w-full px-6 sm:px-10 pt-28 sm:pt-36 flex-1 flex flex-col justify-between"
      >
        {/* Upper Hero Content (Left Album Title & Right Handwritten Signature) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start w-full">
          {/* Left Column: Title & Call to Action */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-4">
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="flex items-center gap-3"
            >
              <span className="w-8 h-[1px] bg-cyan-400" />
              <span className="text-xs sm:text-sm tracking-[0.35em] font-syne font-medium uppercase text-slate-300">
                {FEATURED_RELEASE.releaseType}
              </span>
            </motion.div>

            {/* Giant Title: SO CLOSE TO WHAT */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-syne font-light tracking-tight leading-[0.95] text-white uppercase relative group"
            >
              SO CLOSE TO <br />
              <span className="font-extralight italic text-slate-200 relative inline-block">
                WHAT
                {/* Light sweep animation line */}
                <span className="absolute bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-light-sweep opacity-80" />
              </span>
            </motion.h1>

            {/* Subtitle OUT NOW */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.8 }}
              className="text-xs sm:text-sm font-syne font-semibold tracking-[0.4em] text-cyan-300 uppercase pt-2"
            >
              {FEATURED_RELEASE.status}
            </motion.p>

            {/* LISTEN NOW Pill Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 1 }}
              className="pt-4"
            >
              <button
                onClick={() => onPlayTrack('track-1')}
                data-cursor="PLAY"
                className="group relative px-8 py-3.5 border border-white/30 bg-black/40 hover:bg-white text-white hover:text-black font-syne text-xs tracking-[0.3em] font-semibold uppercase transition-all duration-500 rounded-sm flex items-center gap-4 shadow-[0_0_30px_rgba(0,0,0,0.8)] hover:shadow-[0_0_30px_rgba(0,180,255,0.4)] hover:border-cyan-300"
              >
                <div className="w-6 h-6 rounded-full border border-white/40 group-hover:border-black flex items-center justify-center transition-colors">
                  <Play className="w-3 h-3 fill-current ml-0.5" />
                </div>
                <span>LISTEN NOW</span>
              </button>
            </motion.div>
          </div>

          {/* Right Column: Signature Graphic (Clickable Easter Egg) */}
          <div className="lg:col-span-5 flex justify-end items-start pt-4 lg:pt-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.4, delay: 0.9 }}
              onClick={onSignatureClick}
              data-cursor="EASTER EGG"
              className="cursor-pointer group relative select-none"
              title="Click signature for hidden visual mode"
            >
              <span className="font-signature text-6xl sm:text-8xl md:text-9xl text-white/80 group-hover:text-cyan-300 transition-colors duration-500 drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
                Tate McRae
              </span>
              {signatureClickCount > 0 && (
                <span className="block text-[9px] tracking-[0.25em] font-mono text-cyan-400 text-right uppercase">
                  MODE UNLOCKED [{signatureClickCount}/3]
                </span>
              )}
            </motion.div>
          </div>
        </div>

        {/* 4. BOTTOM FLOATING QUICK-CARDS (Matching Screenshot Layout) */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 md:grid-cols-3 gap-0 border border-white/10 bg-[#080d18]/85 backdrop-blur-xl mb-6 shadow-2xl rounded-sm overflow-hidden divide-y md:divide-y-0 md:divide-x divide-white/10"
        >
          {/* Card 1: LATEST MUSIC */}
          <div
            onClick={() => onPlayTrack('track-1')}
            data-cursor="PLAY"
            className="p-5 sm:p-6 group cursor-pointer hover:bg-white/[0.04] transition-colors duration-300 flex items-center gap-5"
          >
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-sm overflow-hidden relative flex-shrink-0 border border-white/10 group-hover:border-cyan-400/60 transition-colors">
              <img
                src={TATE_IMAGES.sportsCarSingle}
                alt="Sports Car"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                  <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                </div>
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-syne font-medium tracking-[0.25em] text-slate-400 uppercase block mb-1">
                LATEST MUSIC
              </span>
              <h3 className="text-base sm:text-lg font-syne font-semibold text-white tracking-wide truncate group-hover:text-cyan-300 transition-colors">
                Sports Car
              </h3>
              <p className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">
                TATE MCRAE
              </p>
              <div className="flex items-center gap-1.5 text-xs text-white group-hover:text-cyan-300 font-syne tracking-wider uppercase font-medium">
                <span>LISTEN NOW</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>

          {/* Card 2: TOUR DATES */}
          <div
            onClick={() => onNavigateSection('#tour')}
            data-cursor="TICKETS"
            className="p-5 sm:p-6 group cursor-pointer hover:bg-white/[0.04] transition-colors duration-300 flex items-center gap-5"
          >
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-sm overflow-hidden relative flex-shrink-0 border border-white/10 group-hover:border-cyan-400/60 transition-colors">
              <img
                src={TATE_IMAGES.tourConcert}
                alt="Think Later Tour"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter brightness-90"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-syne font-medium tracking-[0.25em] text-slate-400 uppercase block mb-1">
                TOUR DATES
              </span>
              <h3 className="text-base sm:text-lg font-syne font-semibold text-white tracking-wide truncate group-hover:text-cyan-300 transition-colors">
                Think Later Tour
              </h3>
              <p className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">
                UK & EUROPE 2025
              </p>
              <div className="flex items-center gap-1.5 text-xs text-white group-hover:text-cyan-300 font-syne tracking-wider uppercase font-medium">
                <span>VIEW DATES</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>

          {/* Card 3: LATEST NEWS */}
          <div
            onClick={() => onNavigateSection('#news')}
            data-cursor="READ"
            className="p-5 sm:p-6 group cursor-pointer hover:bg-white/[0.04] transition-colors duration-300 flex items-center gap-5"
          >
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-sm overflow-hidden relative flex-shrink-0 border border-white/10 group-hover:border-cyan-400/60 transition-colors">
              <img
                src={TATE_IMAGES.heroPortrait}
                alt="Editorial Portrait"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-syne font-medium tracking-[0.25em] text-slate-400 uppercase block mb-1">
                LATEST NEWS
              </span>
              <h3 className="text-base sm:text-lg font-syne font-semibold text-white tracking-wide truncate group-hover:text-cyan-300 transition-colors">
                New Album
              </h3>
              <p className="text-xs text-slate-300 line-clamp-1 mb-2 font-sans font-light">
                Tate&apos;s highly anticipated new album is out now.
              </p>
              <div className="flex items-center gap-1.5 text-xs text-white group-hover:text-cyan-300 font-syne tracking-wider uppercase font-medium">
                <span>READ MORE</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
