'use client';

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export function CustomCursor() {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [cursorText, setCursorText] = useState('');
  const [cursorVariant, setCursorVariant] = useState<'default' | 'hover' | 'active' | 'labeled'>('default');
  const [isVisible, setIsVisible] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Check mobile / touch device
    const checkMobile = () => {
      const isTouch = window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 768;
      setIsMobile(isTouch);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);

    const onMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);

      // Inspect hovered target for interactive labels or cursor modes
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const cursorTarget = target.closest('[data-cursor]') as HTMLElement | null;
      if (cursorTarget) {
        const label = cursorTarget.getAttribute('data-cursor');
        if (label) {
          setCursorText(label);
          setCursorVariant('labeled');
        } else {
          setCursorText('');
          setCursorVariant('hover');
        }
      } else if (target.closest('button, a, input, [role="button"]')) {
        setCursorText('');
        setCursorVariant('hover');
      } else {
        setCursorText('');
        setCursorVariant('default');
      }
    };

    const onMouseDown = () => setCursorVariant('active');
    const onMouseLeave = () => setIsVisible(false);
    const onMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    document.addEventListener('mouseleave', onMouseLeave);
    document.addEventListener('mouseenter', onMouseEnter);

    if (typeof document !== 'undefined') {
      document.body.classList.add('has-custom-cursor');
    }

    return () => {
      window.removeEventListener('resize', checkMobile);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      document.removeEventListener('mouseleave', onMouseLeave);
      document.removeEventListener('mouseenter', onMouseEnter);
      if (typeof document !== 'undefined') {
        document.body.classList.remove('has-custom-cursor');
      }
    };
  }, [isVisible]);

  if (isMobile || !isVisible) return null;

  const variants = {
    default: {
      x: position.x - 8,
      y: position.y - 8,
      width: 16,
      height: 16,
      backgroundColor: 'rgba(255, 255, 255, 0.9)',
      border: '1px solid rgba(255, 255, 255, 0.4)',
      boxShadow: '0 0 15px rgba(255, 255, 255, 0.4)',
      mixBlendMode: 'difference' as const,
    },
    hover: {
      x: position.x - 24,
      y: position.y - 24,
      width: 48,
      height: 48,
      backgroundColor: 'rgba(255, 255, 255, 0.15)',
      border: '1px solid rgba(255, 255, 255, 0.6)',
      boxShadow: '0 0 25px rgba(0, 102, 255, 0.3)',
      mixBlendMode: 'normal' as const,
    },
    active: {
      x: position.x - 16,
      y: position.y - 16,
      width: 32,
      height: 32,
      backgroundColor: 'rgba(255, 255, 255, 0.8)',
      border: '1px solid rgba(255, 255, 255, 1)',
      mixBlendMode: 'normal' as const,
    },
    labeled: {
      x: position.x - 36,
      y: position.y - 36,
      width: 72,
      height: 72,
      backgroundColor: 'rgba(10, 20, 35, 0.9)',
      border: '1px solid rgba(100, 180, 255, 0.7)',
      boxShadow: '0 0 30px rgba(0, 102, 255, 0.4)',
      mixBlendMode: 'normal' as const,
    },
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-[9999] overflow-hidden">
      <motion.div
        className="fixed top-0 left-0 rounded-full flex items-center justify-center text-[10px] tracking-[0.2em] font-semibold text-white uppercase backdrop-blur-md transition-colors duration-200"
        animate={cursorVariant}
        variants={variants}
        transition={{
          type: 'spring',
          damping: 28,
          stiffness: 400,
          mass: 0.3,
        }}
      >
        <AnimatePresence mode="wait">
          {cursorText && (
            <motion.span
              key={cursorText}
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.6 }}
              className="text-cyan-300 font-syne text-[10px] tracking-widest drop-shadow-[0_0_8px_rgba(0,180,255,0.8)]"
            >
              {cursorText}
            </motion.span>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
