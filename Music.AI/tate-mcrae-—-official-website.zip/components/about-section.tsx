'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Music2, Globe, Sparkles } from 'lucide-react';
import { TATE_IMAGES } from '@/lib/data';

export function AboutSection() {
  const milestones = [
    { year: '2020', title: 'GLOBAL BREAKTHROUGH', detail: "'you broke me first' becomes a 5x Platinum multi-billion stream anthem." },
    { year: '2022', title: 'DEBUT ALBUM LANDMARK', detail: "'i used to think i could fly' debuts Top 5 on Billboard 200." },
    { year: '2023', title: 'GLOBAL POP DOMINANCE', detail: "'Greedy' hits #1 on Spotify Global Chart & Billboard Pop Airplay." },
    { year: '2025', title: 'SO CLOSE TO WHAT', detail: "Sophomore album era and sold-out 45-date global arena world tour." }
  ];

  return (
    <section id="about" className="relative py-28 sm:py-36 bg-[#05070d] text-white overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-white/10 pb-8 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-syne text-cyan-400 uppercase font-medium block mb-2">
              BIOGRAPHY &amp; EDITORIAL PORTRAIT
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-8xl font-syne font-light tracking-tight text-white uppercase">
              ABOUT
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400 uppercase tracking-widest">
            CALGARY · LOS ANGELES · LONDON
          </span>
        </div>

        {/* Editorial Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-24">
          {/* Left Column: Portrait */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="lg:col-span-5 relative"
          >
            <div className="relative aspect-[3/4] w-full rounded-sm overflow-hidden border border-white/20 shadow-2xl group">
              <img
                src={TATE_IMAGES.editorialPortrait1}
                alt="Tate McRae Editorial"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#05070d] via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="font-signature text-5xl text-cyan-300 block">Tate McRae</span>
                <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">
                  PHOTOGRAPHED FOR VOGUE EDITORIAL
                </span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Narrative */}
          <div className="lg:col-span-7 space-y-8">
            <h3 className="text-3xl sm:text-5xl font-syne font-light uppercase text-white tracking-tight leading-snug">
              &quot;DANCE WAS MY FIRST LANGUAGE. MUSIC BECAME MY VOICE.&quot;
            </h3>

            <p className="text-base sm:text-lg text-slate-300 font-sans font-light leading-relaxed">
              Hailing from Calgary, Canada, Tate McRae has established herself as one of the defining pop forces of her generation. Beginning as a prodigy dancer at age eight, she transformed raw athletic discipline and emotive storytelling into a multi-platinum music career with over 10 Billion global streams.
            </p>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-3 gap-6 pt-6 border-t border-b border-white/10 py-6">
              <div>
                <span className="text-2xl sm:text-4xl font-syne font-bold text-cyan-300 block">10B+</span>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">GLOBAL STREAMS</span>
              </div>
              <div>
                <span className="text-2xl sm:text-4xl font-syne font-bold text-cyan-300 block">#1</span>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">BILLBOARD POP AIRPLAY</span>
              </div>
              <div>
                <span className="text-2xl sm:text-4xl font-syne font-bold text-cyan-300 block">45+</span>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">SOLD OUT ARENAS</span>
              </div>
            </div>
          </div>
        </div>

        {/* Milestone Timeline */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {milestones.map((ms) => (
            <div key={ms.year} className="p-6 rounded-sm border border-white/10 bg-[#080d19] space-y-2">
              <span className="text-xs font-mono font-bold text-cyan-400 block">{ms.year}</span>
              <h4 className="font-syne font-semibold text-white uppercase text-sm tracking-wide">{ms.title}</h4>
              <p className="text-xs text-slate-400 font-sans leading-relaxed">{ms.detail}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
