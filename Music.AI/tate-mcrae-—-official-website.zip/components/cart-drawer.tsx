'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Product } from '@/lib/data';

export interface CartItem {
  product: Product;
  size?: string;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, size: string | undefined, delta: number) => void;
  onRemoveItem: (productId: string, size: string | undefined) => void;
  onClearCart: () => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [promoCode, setPromoCode] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoMessage, setPromoMessage] = useState('');
  const [isCheckoutSuccess, setIsCheckoutSuccess] = useState(false);

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = (subtotal * promoDiscount) / 100;
  const shipping = subtotal > 100 || subtotal === 0 ? 0 : 15;
  const total = Math.max(0, subtotal - discountAmount + shipping);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'TATE2025' || promoCode.trim().toUpperCase() === 'SOCLOSE') {
      setPromoDiscount(15);
      setPromoMessage('15% VIP DISCOUNT APPLIED');
    } else {
      setPromoMessage('INVALID PROMO CODE');
    }
  };

  const handleCheckout = () => {
    setIsCheckoutSuccess(true);
    setTimeout(() => {
      onClearCart();
      setIsCheckoutSuccess(false);
      onClose();
    }, 3000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[9000] bg-black/80 backdrop-blur-md"
          />

          {/* Slide-out Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-[9100] w-full max-w-md bg-[#070b14] border-l border-white/20 text-white flex flex-col justify-between p-6 sm:p-8 shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-6">
              <div className="flex items-center space-x-3">
                <ShoppingBag className="w-5 h-5 text-cyan-400" />
                <h3 className="text-xl font-syne font-light tracking-widest uppercase">
                  SHOPPING BAG ({cartItems.reduce((a, b) => a + b.quantity, 0)})
                </h3>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full border border-white/10 hover:bg-white/10 text-white"
                aria-label="Close cart"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Area */}
            {isCheckoutSuccess ? (
              <div className="my-auto text-center py-12 space-y-4">
                <CheckCircle2 className="w-16 h-16 text-cyan-400 mx-auto animate-bounce" />
                <h3 className="text-2xl font-syne uppercase tracking-wider text-white">
                  ORDER CONFIRMED
                </h3>
                <p className="text-xs font-mono text-slate-300">
                  Thank you for your order! Your official Tate McRae merchandise order #TM-{Math.floor(Math.random()*899999 + 100000)} is being prepared.
                </p>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="my-auto text-center py-12 space-y-4">
                <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-sm font-syne uppercase tracking-widest text-slate-400">
                  YOUR BAG IS CURRENTLY EMPTY
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 border border-white/20 bg-white/5 hover:bg-white/15 text-white font-syne text-xs uppercase tracking-widest"
                >
                  EXPLORE MERCHANDISE
                </button>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto py-6 space-y-4">
                {cartItems.map((item, idx) => (
                  <div
                    key={`${item.product.id}-${item.size || 'nosize'}-${idx}`}
                    className="flex items-center justify-between p-3.5 border border-white/10 rounded-sm bg-white/5 gap-4"
                  >
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      className="w-16 h-16 rounded object-cover border border-white/10"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-syne font-semibold uppercase text-white truncate">
                        {item.product.name}
                      </h4>
                      {item.size && (
                        <span className="text-[10px] font-mono text-slate-400 uppercase block">
                          SIZE: {item.size}
                        </span>
                      )}
                      <span className="text-xs font-mono text-cyan-300 font-bold block mt-1">
                        ${item.product.price}.00
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.size, -1)}
                        className="w-6 h-6 border border-white/20 rounded flex items-center justify-center text-xs text-white hover:bg-white/10"
                      >
                        -
                      </button>
                      <span className="text-xs font-mono w-4 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.size, 1)}
                        className="w-6 h-6 border border-white/20 rounded flex items-center justify-center text-xs text-white hover:bg-white/10"
                      >
                        +
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.product.id, item.size)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Footer Calculation */}
            {cartItems.length > 0 && !isCheckoutSuccess && (
              <div className="border-t border-white/10 pt-6 space-y-4">
                {/* Promo Input */}
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="PROMO CODE (TRY 'TATE2025')"
                    className="flex-1 px-3 py-2 bg-black/50 border border-white/20 text-xs text-white font-mono placeholder:text-slate-500 uppercase focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 border border-white/20 bg-white/10 hover:bg-white/20 text-xs font-syne uppercase tracking-wider"
                  >
                    APPLY
                  </button>
                </form>
                {promoMessage && (
                  <span className="text-[10px] font-mono text-cyan-400 block uppercase">
                    {promoMessage}
                  </span>
                )}

                {/* Subtotal breakdown */}
                <div className="space-y-1.5 text-xs font-mono text-slate-300">
                  <div className="flex justify-between">
                    <span>SUBTOTAL</span>
                    <span>${subtotal}.00</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-cyan-400">
                      <span>VIP DISCOUNT ({promoDiscount}%)</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>SHIPPING</span>
                    <span>{shipping === 0 ? 'FREE' : `$${shipping}.00`}</span>
                  </div>
                  <div className="flex justify-between text-base font-syne font-bold text-white pt-2 border-t border-white/10">
                    <span>TOTAL</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  onClick={handleCheckout}
                  className="w-full py-4 bg-cyan-400 text-black hover:bg-white font-syne text-xs tracking-[0.25em] font-bold uppercase transition-colors shadow-[0_0_20px_rgba(0,180,255,0.4)] flex items-center justify-center gap-2"
                >
                  <span>CHECKOUT NOW</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
