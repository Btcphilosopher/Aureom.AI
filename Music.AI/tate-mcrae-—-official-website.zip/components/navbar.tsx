'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, User, ShoppingBag, Volume2, VolumeX, Menu, X, ArrowUpRight } from 'lucide-react';
import { TATE_IMAGES } from '@/lib/data';

interface NavbarProps {
  activeSection: string;
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onOpenAccount: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export function Navbar({
  activeSection,
  cartCount,
  onOpenCart,
  onOpenSearch,
  onOpenAccount,
  soundEnabled,
  onToggleSound,
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 80) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'MUSIC', href: '#music', label: 'PLAY' },
    { name: 'TOUR', href: '#tour', label: 'TICKETS' },
    { name: 'VIDEOS', href: '#videos', label: 'WATCH' },
    { name: 'ABOUT', href: '#about', label: 'EDITORIAL' },
    { name: 'SHOP', href: '#shop', label: 'SHOP' },
    { name: 'NEWS', href: '#news', label: 'READ' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'py-3 bg-[#05070d]/80 backdrop-blur-xl border-b border-white/10 shadow-2xl shadow-black/60'
            : 'py-6 bg-gradient-to-b from-black/80 via-black/30 to-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-10 flex items-center justify-between">
          {/* Logo */}
          <a
            href="#"
            data-cursor="HOME"
            className="group flex items-center gap-3 text-white transition-opacity duration-300 hover:opacity-90"
          >
            <span className="font-syne text-xl sm:text-2xl font-light tracking-[0.3em] uppercase text-slate-100 group-hover:text-cyan-300 transition-colors">
              TATE MCRAE
            </span>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center space-x-10">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                data-cursor={link.label}
                className={`relative text-xs tracking-[0.25em] font-syne font-medium uppercase transition-all duration-300 hover:text-cyan-300 py-1 ${
                  activeSection === link.name.toLowerCase()
                    ? 'text-cyan-300 font-semibold'
                    : 'text-slate-300/80 hover:text-white'
                }`}
              >
                {link.name}
                {activeSection === link.name.toLowerCase() && (
                  <motion.span
                    layoutId="activeNavIndicator"
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-cyan-400 shadow-[0_0_10px_rgba(0,180,255,0.8)]"
                  />
                )}
              </a>
            ))}
          </nav>

          {/* Utility Right Controls */}
          <div className="flex items-center space-x-4 sm:space-x-6">
            {/* Ambient Sound Toggle */}
            <button
              onClick={onToggleSound}
              data-cursor={soundEnabled ? 'MUTE' : 'SOUND'}
              aria-label="Toggle Ambient Sound"
              className="p-2 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-all duration-300 flex items-center gap-2 group"
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
              ) : (
                <VolumeX className="w-4 h-4 opacity-70 group-hover:opacity-100" />
              )}
              <span className="hidden xl:inline text-[9px] tracking-[0.2em] font-syne font-medium uppercase text-slate-400 group-hover:text-white">
                {soundEnabled ? 'SOUND ON' : 'SOUND OFF'}
              </span>
            </button>

            {/* Search Button */}
            <button
              onClick={onOpenSearch}
              data-cursor="SEARCH"
              aria-label="Search site"
              className="p-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-all duration-300"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Account / VIP Access */}
            <button
              onClick={onOpenAccount}
              data-cursor="ACCOUNT"
              aria-label="Account and VIP Pass"
              className="p-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-all duration-300"
            >
              <User className="w-4 h-4" />
            </button>

            {/* Shopping Bag Button */}
            <button
              onClick={onOpenCart}
              data-cursor="BAG"
              aria-label="View Shopping Cart"
              className="relative p-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-all duration-300 flex items-center justify-center"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-400 text-black text-[9px] font-bold flex items-center justify-center"
                >
                  {cartCount}
                </motion.span>
              )}
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2.5 rounded-full border border-white/10 bg-white/5 text-white"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Full-Screen Mobile Editorial Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[9000] bg-[#05070d] text-white flex flex-col justify-between p-8 sm:p-12 overflow-y-auto"
          >
            {/* Background Editorial Visual */}
            <div className="absolute inset-0 pointer-events-none opacity-20 bg-cover bg-center" style={{ backgroundImage: `url(${TATE_IMAGES.heroPortrait})` }} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#05070d] via-[#05070d]/90 to-transparent pointer-events-none" />

            {/* Mobile Menu Top Header */}
            <div className="relative z-10 flex items-center justify-between border-b border-white/10 pb-6">
              <span className="font-syne text-xl tracking-[0.3em] font-light uppercase">
                TATE MCRAE
              </span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-full border border-white/20 bg-white/10 hover:bg-white/20 text-white"
                aria-label="Close menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Mobile Navigation Links */}
            <div className="relative z-10 my-auto py-10 flex flex-col space-y-6">
              {navLinks.map((link, idx) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.08 + 0.1, duration: 0.5 }}
                  className="group flex items-center justify-between text-3xl sm:text-5xl font-syne font-light tracking-widest uppercase hover:text-cyan-300 transition-colors"
                >
                  <span>{link.name}</span>
                  <ArrowUpRight className="w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity text-cyan-300" />
                </motion.a>
              ))}
            </div>

            {/* Mobile Menu Footer Info */}
            <div className="relative z-10 border-t border-white/10 pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-slate-400 gap-4">
              <span className="font-mono tracking-widest uppercase">
                SO CLOSE TO WHAT · WORLD TOUR 2025/2026
              </span>
              <div className="flex items-center space-x-6 text-slate-300">
                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-white">INSTAGRAM</a>
                <a href="https://tiktok.com" target="_blank" rel="noreferrer" className="hover:text-white">TIKTOK</a>
                <a href="https://spotify.com" target="_blank" rel="noreferrer" className="hover:text-white">SPOTIFY</a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
