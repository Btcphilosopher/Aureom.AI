'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Eye, Sparkles, Check, X, Shield, ArrowRight } from 'lucide-react';
import { SHOP_PRODUCTS, Product } from '@/lib/data';

interface ShopSectionProps {
  onAddToCart: (product: Product, size?: string) => void;
}

export function ShopSection({ onAddToCart }: ShopSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'Apparel' | 'Vinyl & Music' | 'Accessories'>('ALL');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [selectedSize, setSelectedSize] = useState<string>('M');
  const [addedToast, setAddedToast] = useState(false);

  const filteredProducts = SHOP_PRODUCTS.filter((prod) => {
    if (selectedCategory === 'ALL') return true;
    return prod.category === selectedCategory;
  });

  const handleQuickAdd = (product: Product) => {
    onAddToCart(product, product.sizes ? selectedSize : undefined);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  return (
    <section id="shop" className="relative py-28 sm:py-36 bg-[#03050a] text-white overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-white/10 pb-8 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-syne text-cyan-400 uppercase font-medium block mb-2">
              EXCLUSIVE OFFICIAL STOREFRONT
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-8xl font-syne font-light tracking-tight text-white uppercase">
              SHOP
            </h2>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center space-x-2 sm:space-x-3 overflow-x-auto pb-2 sm:pb-0">
            {(['ALL', 'Apparel', 'Vinyl & Music', 'Accessories'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                data-cursor="FILTER"
                className={`px-5 py-2 rounded-full text-[11px] font-syne tracking-[0.25em] uppercase transition-all border ${
                  selectedCategory === cat
                    ? 'border-cyan-400/80 bg-cyan-400/10 text-cyan-300 shadow-[0_0_15px_rgba(0,180,255,0.2)] font-semibold'
                    : 'border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="group relative flex flex-col justify-between p-4 rounded-sm border border-white/10 bg-[#080d19] hover:border-cyan-400/60 transition-all duration-500 shadow-xl"
            >
              {/* Product Image with Alternate Image on Hover */}
              <div
                onClick={() => setQuickViewProduct(product)}
                data-cursor="SHOP"
                className="relative aspect-square w-full rounded-sm overflow-hidden mb-5 cursor-pointer bg-black border border-white/10"
              >
                {/* Primary Image */}
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:opacity-0 transition-opacity duration-500"
                  referrerPolicy="no-referrer"
                />
                {/* Alternate Image on Hover */}
                <img
                  src={product.hoverImageUrl}
                  alt={product.name}
                  className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />

                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col space-y-1">
                  {product.isNew && (
                    <span className="bg-cyan-400 text-black px-2.5 py-0.5 rounded text-[9px] font-syne font-bold uppercase tracking-widest">
                      NEW ERA
                    </span>
                  )}
                  {product.isExclusive && (
                    <span className="bg-purple-600 text-white px-2.5 py-0.5 rounded text-[9px] font-syne font-bold uppercase tracking-widest">
                      LIMITED
                    </span>
                  )}
                </div>

                {/* Quick View Button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                  <button className="px-5 py-2.5 bg-white text-black font-syne text-[11px] font-bold tracking-widest uppercase rounded-sm shadow-xl flex items-center gap-2 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                    <Eye className="w-3.5 h-3.5" />
                    <span>QUICK VIEW</span>
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div>
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest block mb-1">
                  {product.category}
                </span>
                <h3 className="text-base font-syne font-semibold uppercase text-white group-hover:text-cyan-300 transition-colors tracking-wide leading-snug">
                  {product.name}
                </h3>
              </div>

              {/* Price & Action */}
              <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-lg font-syne font-bold text-white tracking-wide">
                  ${product.price}.00
                </span>

                <button
                  onClick={() => handleQuickAdd(product)}
                  data-cursor="ADD"
                  className="px-5 py-2 border border-white/20 bg-white/5 hover:bg-cyan-300 hover:text-black hover:border-cyan-300 font-syne text-xs tracking-widest uppercase transition-all duration-300 flex items-center gap-2 font-semibold"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>ADD TO BAG</span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* QUICK VIEW MODAL OVERLAY */}
      <AnimatePresence>
        {quickViewProduct && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[8000] bg-black/85 backdrop-blur-xl flex items-center justify-center p-6"
            onClick={() => setQuickViewProduct(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#090f1f] border border-white/20 rounded-sm p-6 sm:p-10 max-w-3xl w-full text-white shadow-2xl relative overflow-y-auto max-h-[90vh]"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="aspect-square rounded-sm overflow-hidden border border-white/10">
                  <img src={quickViewProduct.imageUrl} alt={quickViewProduct.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>

                <div className="flex flex-col space-y-5">
                  <div>
                    <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">
                      OFFICIAL MERCHANDISE
                    </span>
                    <h3 className="text-2xl font-syne font-light uppercase text-white mt-1">
                      {quickViewProduct.name}
                    </h3>
                    <span className="text-2xl font-syne font-bold text-cyan-300 block mt-2">
                      ${quickViewProduct.price}.00
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-sans leading-relaxed">
                    {quickViewProduct.description}
                  </p>

                  {/* Size Selector */}
                  {quickViewProduct.sizes && (
                    <div>
                      <span className="text-xs font-syne tracking-widest text-slate-400 uppercase block mb-2">
                        SELECT SIZE
                      </span>
                      <div className="flex items-center space-x-2">
                        {quickViewProduct.sizes.map((sz) => (
                          <button
                            key={sz}
                            onClick={() => setSelectedSize(sz)}
                            className={`w-10 h-10 rounded border font-mono text-xs uppercase transition-colors ${
                              selectedSize === sz ? 'border-cyan-400 bg-cyan-400 text-black font-bold' : 'border-white/20 bg-white/5 text-slate-300'
                            }`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      handleQuickAdd(quickViewProduct);
                      setQuickViewProduct(null);
                    }}
                    className="w-full py-4 bg-cyan-400 text-black hover:bg-white font-syne text-xs tracking-[0.25em] font-bold uppercase transition-colors shadow-[0_0_20px_rgba(0,180,255,0.4)] flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>ADD TO SHOPPING BAG</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
