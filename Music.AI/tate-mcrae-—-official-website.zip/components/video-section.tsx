'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Eye, X, Film, Sparkles } from 'lucide-react';
import { VIDEOS, VideoItem } from '@/lib/data';

export function VideoSection() {
  const [hoveredVideo, setHoveredVideo] = useState<VideoItem | null>(null);
  const [activeVideoModal, setActiveVideoModal] = useState<VideoItem | null>(null);

  return (
    <section id="videos" className="relative py-28 sm:py-36 bg-[#05070d] text-white overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-white/10 pb-8 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-syne text-cyan-400 uppercase font-medium block mb-2">
              CINEMATIC VISUAL GALLERY
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-8xl font-syne font-light tracking-tight text-white uppercase">
              VIDEOS
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 uppercase tracking-widest max-w-xs">
            Directed by Bardin, Hannah Lux Davis, and Tate McRae.
          </p>
        </div>

        {/* Video Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {VIDEOS.map((video) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              onMouseEnter={() => setHoveredVideo(video)}
              onMouseLeave={() => setHoveredVideo(null)}
              onClick={() => setActiveVideoModal(video)}
              data-cursor="WATCH"
              className="group relative cursor-pointer rounded-sm overflow-hidden border border-white/10 bg-[#080d19] hover:border-cyan-400/60 transition-all duration-500 shadow-xl"
            >
              {/* Thumbnail Poster */}
              <div className="relative aspect-video w-full overflow-hidden">
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-110 filter brightness-90 group-hover:brightness-100 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />

                {/* Animated overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent group-hover:from-black/70 transition-colors" />

                {/* Animated Play Circle */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-14 h-14 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-[0_0_30px_rgba(0,180,255,0.8)] group-hover:scale-115 transition-transform duration-300">
                    <Play className="w-6 h-6 fill-current ml-0.5" />
                  </div>
                </div>

                {/* Duration Badge */}
                <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded text-[10px] font-mono text-cyan-300 tracking-widest uppercase border border-white/10">
                  {video.duration}
                </div>

                {/* Type Badge */}
                <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded text-[9px] font-mono text-slate-300 tracking-widest uppercase border border-white/10 flex items-center gap-1">
                  <Film className="w-3 h-3 text-cyan-400" />
                  <span>{video.type}</span>
                </div>
              </div>

              {/* Video Info */}
              <div className="p-6">
                <h3 className="text-lg font-syne font-semibold uppercase text-white group-hover:text-cyan-300 transition-colors tracking-wide">
                  {video.title}
                </h3>
                <p className="text-xs text-slate-400 font-mono tracking-widest mt-1 uppercase flex items-center justify-between">
                  <span>DIR. {video.director}</span>
                  <span>{video.views}</span>
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* FULLSCREEN CINEMATIC VIDEO OVERLAY */}
      <AnimatePresence>
        {activeVideoModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9800] bg-black/95 backdrop-blur-2xl flex flex-col justify-between p-6 sm:p-10"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">
                  CINEMATIC VISUAL EXPERIENCE · {activeVideoModal.type}
                </span>
                <h3 className="text-xl sm:text-2xl font-syne font-light text-white uppercase">
                  {activeVideoModal.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveVideoModal(null)}
                className="p-3 rounded-full border border-white/20 bg-white/10 hover:bg-white/20 text-white transition-colors"
                aria-label="Close video"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Video Player Frame Container */}
            <div className="my-auto max-w-5xl mx-auto w-full aspect-video rounded-sm overflow-hidden border border-white/20 shadow-2xl relative bg-black flex items-center justify-center">
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${activeVideoModal.embedId}?autoplay=1`}
                title={activeVideoModal.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>

            <div className="border-t border-white/10 pt-4 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>{activeVideoModal.description}</span>
              <span>DIRECTOR: {activeVideoModal.director}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
