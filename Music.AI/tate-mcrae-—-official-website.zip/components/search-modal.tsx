'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, Play, Ticket, Film, ShoppingBag, ArrowRight } from 'lucide-react';
import { TRACKS_LIST, TOUR_DATES, VIDEOS, SHOP_PRODUCTS } from '@/lib/data';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTrack: (id: string) => void;
}

export function SearchModal({ isOpen, onClose, onSelectTrack }: SearchModalProps) {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  const matchingTracks = q ? TRACKS_LIST.filter((t) => t.title.toLowerCase().includes(q) || t.album.toLowerCase().includes(q)) : [];
  const matchingTours = q ? TOUR_DATES.filter((d) => d.city.toLowerCase().includes(q) || d.country.toLowerCase().includes(q) || d.venue.toLowerCase().includes(q)) : [];
  const matchingVideos = q ? VIDEOS.filter((v) => v.title.toLowerCase().includes(q)) : [];
  const matchingProducts = q ? SHOP_PRODUCTS.filter((p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)) : [];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-[9500] bg-black/90 backdrop-blur-2xl flex items-start justify-center pt-20 px-6"
      >
        <motion.div
          initial={{ scale: 0.95, y: -20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: -20 }}
          onClick={(e) => e.stopPropagation()}
          className="max-w-3xl w-full bg-[#080d19] border border-white/20 rounded-sm p-6 sm:p-10 text-white shadow-2xl relative"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
            <div className="flex items-center space-x-3 flex-1">
              <Search className="w-6 h-6 text-cyan-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="SEARCH MUSIC, TOUR CITIES, VIDEOS, MERCH..."
                autoFocus
                className="w-full bg-transparent text-lg sm:text-xl font-syne uppercase tracking-wider text-white placeholder:text-slate-500 focus:outline-none"
              />
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full border border-white/10 hover:bg-white/10 text-slate-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Search Chips if empty */}
          {!query && (
            <div className="space-y-4 py-4">
              <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase block">
                POPULAR SEARCHES
              </span>
              <div className="flex flex-wrap gap-2">
                {['SPORTS CAR', 'THINK LATER TOUR', 'LONDON O2 ARENA', 'BLUE SMOKE VINYL', 'GREEDY'].map((term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="px-4 py-1.5 rounded border border-white/10 bg-white/5 hover:border-cyan-400/50 hover:bg-cyan-400/10 text-xs font-syne uppercase tracking-widest text-slate-300 transition-colors"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {query && (
            <div className="max-h-[60vh] overflow-y-auto space-y-6 pr-2">
              {matchingTracks.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase block mb-3">
                    TRACKS ({matchingTracks.length})
                  </span>
                  <div className="space-y-2">
                    {matchingTracks.map((tr) => (
                      <div
                        key={tr.id}
                        onClick={() => {
                          onSelectTrack(tr.id);
                          onClose();
                        }}
                        className="flex items-center justify-between p-3 rounded bg-white/5 hover:bg-white/10 cursor-pointer"
                      >
                        <div className="flex items-center space-x-3">
                          <Play className="w-4 h-4 text-cyan-400" />
                          <span className="font-syne text-sm uppercase">{tr.title}</span>
                        </div>
                        <span className="text-xs font-mono text-slate-400">{tr.duration}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {matchingTours.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase block mb-3">
                    TOUR CITIES ({matchingTours.length})
                  </span>
                  <div className="space-y-2">
                    {matchingTours.map((td) => (
                      <a
                        key={td.id}
                        href="#tour"
                        onClick={onClose}
                        className="flex items-center justify-between p-3 rounded bg-white/5 hover:bg-white/10 cursor-pointer"
                      >
                        <div className="flex items-center space-x-3">
                          <Ticket className="w-4 h-4 text-cyan-400" />
                          <span className="font-syne text-sm uppercase">{td.city} · {td.venue}</span>
                        </div>
                        <span className="text-xs font-mono text-slate-400">{td.date}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {matchingProducts.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase block mb-3">
                    MERCHANDISE ({matchingProducts.length})
                  </span>
                  <div className="space-y-2">
                    {matchingProducts.map((p) => (
                      <a
                        key={p.id}
                        href="#shop"
                        onClick={onClose}
                        className="flex items-center justify-between p-3 rounded bg-white/5 hover:bg-white/10 cursor-pointer"
                      >
                        <div className="flex items-center space-x-3">
                          <ShoppingBag className="w-4 h-4 text-cyan-400" />
                          <span className="font-syne text-sm uppercase">{p.name}</span>
                        </div>
                        <span className="text-xs font-mono text-cyan-300">${p.price}.00</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
