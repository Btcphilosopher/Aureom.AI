'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Maximize2, Minimize2, X, Music, Disc, List, AlignLeft, Sparkles } from 'lucide-react';
import { Track, TRACKS_LIST } from '@/lib/data';

interface MusicPlayerProps {
  activeTrackId: string | null;
  onClosePlayer: () => void;
  onSelectTrack: (id: string) => void;
}

export function MusicPlayer({ activeTrackId, onClosePlayer, onSelectTrack }: MusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(15);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<'PLAYER' | 'LYRICS' | 'QUEUE'>('PLAYER');

  const currentTrackIndex = TRACKS_LIST.findIndex((t) => t.id === activeTrackId);
  const track: Track = currentTrackIndex >= 0 ? TRACKS_LIST[currentTrackIndex] : TRACKS_LIST[0];

  const [prevTrackId, setPrevTrackId] = useState<string | null>(activeTrackId);
  if (activeTrackId !== prevTrackId) {
    setPrevTrackId(activeTrackId);
    if (activeTrackId) {
      setIsPlaying(true);
    }
  }

  // Audio Progress Simulation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 0.5));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleNextTrack = () => {
    const nextIdx = (currentTrackIndex + 1) % TRACKS_LIST.length;
    onSelectTrack(TRACKS_LIST[nextIdx].id);
  };

  const handlePrevTrack = () => {
    const prevIdx = (currentTrackIndex - 1 + TRACKS_LIST.length) % TRACKS_LIST.length;
    onSelectTrack(TRACKS_LIST[prevIdx].id);
  };

  if (!activeTrackId) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className={`fixed z-[9500] transition-all duration-500 ${
          isExpanded
            ? 'inset-0 bg-[#04070e]/95 backdrop-blur-2xl flex flex-col justify-between p-6 sm:p-12'
            : 'bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-md w-full glass-panel border border-white/20 rounded-xl p-4 shadow-[0_20px_50px_rgba(0,0,0,0.8)]'
        }`}
      >
        {/* EXPANDED FULL-SCREEN PLAYER MODE */}
        {isExpanded ? (
          <div className="relative z-10 max-w-5xl mx-auto w-full h-full flex flex-col justify-between">
            {/* Expanded Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-6">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                <span className="text-xs font-syne font-semibold tracking-[0.3em] uppercase text-cyan-300">
                  TATE MCRAE AUDIO PLAYER
                </span>
              </div>

              {/* View Switcher Tabs */}
              <div className="flex items-center space-x-2 bg-white/5 border border-white/10 rounded-full p-1">
                {(['PLAYER', 'LYRICS', 'QUEUE'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-1.5 rounded-full text-[10px] font-syne tracking-widest uppercase transition-all ${
                      activeTab === tab ? 'bg-cyan-400 text-black font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setIsExpanded(false)}
                  className="p-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white"
                  aria-label="Minimize player"
                >
                  <Minimize2 className="w-4 h-4" />
                </button>
                <button
                  onClick={onClosePlayer}
                  className="p-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white"
                  aria-label="Close player"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Expanded Tab Content */}
            <div className="my-auto py-8">
              {activeTab === 'PLAYER' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                  {/* Rotating Album Art */}
                  <div className="flex justify-center">
                    <div className="relative w-72 h-72 sm:w-96 sm:h-96 rounded-2xl overflow-hidden shadow-[0_0_60px_rgba(0,180,255,0.25)] border border-white/20 group">
                      <img
                        src={track.coverUrl}
                        alt={track.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
                        <span className="text-xs font-mono tracking-widest text-cyan-300 uppercase">
                          SO CLOSE TO WHAT · HIGH FIDELITY AUDIO
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Metadata & Controls */}
                  <div className="flex flex-col space-y-6">
                    <div>
                      <span className="text-xs font-mono tracking-widest text-cyan-400 uppercase block mb-1">
                        NOW PLAYING
                      </span>
                      <h2 className="text-4xl sm:text-6xl font-syne font-light uppercase text-white tracking-tight">
                        {track.title}
                      </h2>
                      <p className="text-base font-mono text-slate-400 uppercase tracking-widest mt-1">
                        TATE MCRAE — {track.album}
                      </p>
                    </div>

                    {/* Progress Bar */}
                    <div>
                      <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden cursor-pointer relative mb-2 group">
                        <div
                          className="h-full bg-cyan-400 rounded-full shadow-[0_0_15px_rgba(0,180,255,0.9)]"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs font-mono text-slate-400">
                        <span>0:45</span>
                        <span>{track.duration}</span>
                      </div>
                    </div>

                    {/* Audio Playback Controls */}
                    <div className="flex items-center justify-between pt-4">
                      <button
                        onClick={handlePrevTrack}
                        className="p-4 rounded-full border border-white/10 hover:border-cyan-400/50 hover:bg-white/10 text-white transition-all"
                        aria-label="Previous track"
                      >
                        <SkipBack className="w-6 h-6" />
                      </button>

                      <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="p-6 rounded-full bg-cyan-400 text-black hover:bg-white transition-all transform hover:scale-105 shadow-[0_0_30px_rgba(0,180,255,0.6)]"
                        aria-label={isPlaying ? 'Pause' : 'Play'}
                      >
                        {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
                      </button>

                      <button
                        onClick={handleNextTrack}
                        className="p-4 rounded-full border border-white/10 hover:border-cyan-400/50 hover:bg-white/10 text-white transition-all"
                        aria-label="Next track"
                      >
                        <SkipForward className="w-6 h-6" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'LYRICS' && (
                <div className="max-w-2xl mx-auto text-center py-6 space-y-6">
                  <span className="text-xs font-mono tracking-widest text-cyan-400 uppercase">
                    SYNCHRONIZED LYRICS
                  </span>
                  <p className="text-2xl sm:text-3xl font-syne font-light text-slate-200 leading-relaxed whitespace-pre-line italic">
                    {track.lyrics || "Driving down the 401 at midnight...\nThought I saw your face in every headlight..."}
                  </p>
                </div>
              )}

              {activeTab === 'QUEUE' && (
                <div className="max-w-3xl mx-auto space-y-3">
                  <h3 className="text-xs font-syne tracking-widest text-slate-400 uppercase mb-4">
                    PLAYLIST QUEUE ({TRACKS_LIST.length} TRACKS)
                  </h3>
                  {TRACKS_LIST.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => onSelectTrack(t.id)}
                      className={`flex items-center justify-between p-3.5 rounded-sm cursor-pointer transition-colors ${
                        t.id === track.id ? 'bg-cyan-400/10 border border-cyan-400/40 text-cyan-300' : 'hover:bg-white/5 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        <img src={t.coverUrl} alt={t.title} className="w-10 h-10 rounded-sm object-cover" referrerPolicy="no-referrer" />
                        <div>
                          <span className="font-syne font-medium text-sm block">{t.title}</span>
                          <span className="text-[10px] font-mono text-slate-500 uppercase">{t.album}</span>
                        </div>
                      </div>
                      <span className="text-xs font-mono">{t.duration}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="border-t border-white/10 pt-4 flex items-center justify-between text-xs text-slate-500 font-mono">
              <span>STREAM ON SPOTIFY · APPLE MUSIC · AMAZON · TIDAL</span>
              <span>© 2025 RCA RECORDS / TATE MCRAE ENTERTAINMENT</span>
            </div>
          </div>
        ) : (
          /* FLOATING COMPACT BOTTOM BAR PLAYER */
          <div className="flex items-center justify-between gap-4">
            {/* Artwork & Title */}
            <div className="flex items-center space-x-3 min-w-0">
              <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 border border-white/10">
                <img src={track.coverUrl} alt={track.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-syne font-semibold text-white truncate tracking-wide">
                  {track.title}
                </h4>
                <p className="text-[10px] font-mono text-slate-400 truncate uppercase">
                  TATE MCRAE
                </p>
              </div>
            </div>

            {/* Playback & Expand Controls */}
            <div className="flex items-center space-x-3">
              <button
                onClick={handlePrevTrack}
                className="p-1.5 text-slate-400 hover:text-white"
                aria-label="Previous"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-9 h-9 rounded-full bg-cyan-400 text-black flex items-center justify-center hover:scale-105 transition-transform"
                aria-label={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
              </button>

              <button
                onClick={handleNextTrack}
                className="p-1.5 text-slate-400 hover:text-white"
                aria-label="Next"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsExpanded(true)}
                className="p-2 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white"
                aria-label="Expand player"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onClosePlayer}
                className="p-2 text-slate-400 hover:text-white"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
