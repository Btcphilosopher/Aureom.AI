'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Disc, ExternalLink, ListMusic, Music2 } from 'lucide-react';
import { ALBUMS, Album, Track, FEATURED_RELEASE } from '@/lib/data';

interface MusicSectionProps {
  onPlayTrack: (trackId: string) => void;
  onOpenFullPlayer: () => void;
}

export function MusicSection({ onPlayTrack, onOpenFullPlayer }: MusicSectionProps) {
  const [activeTab, setActiveTab] = useState<'ALL' | 'ALBUMS' | 'EPS' | 'SINGLES'>('ALL');
  const [hoveredAlbum, setHoveredAlbum] = useState<Album | null>(null);
  const [selectedAlbumModal, setSelectedAlbumModal] = useState<Album | null>(null);

  const filteredAlbums = ALBUMS.filter((alb) => {
    if (activeTab === 'ALBUMS') return alb.type === 'Album';
    if (activeTab === 'EPS') return alb.type === 'EP';
    if (activeTab === 'SINGLES') return alb.type === 'Single';
    return true;
  });

  return (
    <section id="music" className="relative py-28 sm:py-36 bg-[#05070d] text-white overflow-hidden">
      {/* Background Lighting Shift when hovering album */}
      <div className="absolute inset-0 pointer-events-none transition-opacity duration-1000">
        <div
          className="absolute inset-0 bg-cover bg-center filter blur-3xl opacity-15 transition-all duration-1000 scale-110"
          style={{
            backgroundImage: `url(${hoveredAlbum ? hoveredAlbum.coverUrl : FEATURED_RELEASE.coverUrl})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#05070d] via-transparent to-[#05070d]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 sm:mb-20 border-b border-white/10 pb-8 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-syne text-cyan-400 uppercase font-medium block mb-2">
              DISCOGRAPHY & RELEASES
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-7xl font-syne font-light tracking-tight text-white uppercase">
              MUSIC
            </h2>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center space-x-2 sm:space-x-4 overflow-x-auto pb-2 sm:pb-0">
            {(['ALL', 'ALBUMS', 'EPS', 'SINGLES'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                data-cursor="FILTER"
                className={`px-5 py-2 rounded-full text-xs font-syne tracking-[0.25em] uppercase transition-all duration-300 border ${
                  activeTab === tab
                    ? 'border-cyan-400/80 bg-cyan-400/10 text-cyan-300 shadow-[0_0_15px_rgba(0,180,255,0.2)]'
                    : 'border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* FEATURED EDITORIAL ALBUM BANNER ("SO CLOSE TO WHAT") */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="relative rounded-sm overflow-hidden border border-white/15 bg-gradient-to-r from-[#0a1120] via-[#0d1628] to-[#080d18] p-8 sm:p-12 mb-20 shadow-2xl group"
        >
          {/* Subtle Ambient Light Glow inside feature */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 blur-[100px] pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
            {/* Artwork with hover effect */}
            <div className="lg:col-span-5 flex justify-center">
              <div
                onClick={onOpenFullPlayer}
                data-cursor="PLAY"
                className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-sm overflow-hidden shadow-2xl border border-white/20 cursor-pointer group/art"
              >
                <img
                  src={FEATURED_RELEASE.coverUrl}
                  alt={FEATURED_RELEASE.title}
                  className="w-full h-full object-cover group-hover/art:scale-108 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 group-hover/art:bg-black/10 transition-colors flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-cyan-400/90 text-black flex items-center justify-center shadow-[0_0_30px_rgba(0,180,255,0.8)] group-hover/art:scale-110 transition-transform">
                    <Play className="w-7 h-7 fill-current ml-1" />
                  </div>
                </div>
              </div>
            </div>

            {/* Editorial Metadata */}
            <div className="lg:col-span-7 flex flex-col items-start space-y-6">
              <div>
                <span className="text-xs font-syne font-semibold tracking-[0.3em] text-cyan-300 uppercase block mb-1">
                  FEATURED ALBUM
                </span>
                <h3 className="text-3xl sm:text-5xl lg:text-6xl font-syne font-light text-white tracking-tight uppercase leading-none">
                  SO CLOSE TO WHAT
                </h3>
                <p className="text-xs font-mono text-slate-400 uppercase tracking-widest mt-2">
                  TATE MCRAE · 2025 RELEASE
                </p>
              </div>

              <p className="text-sm sm:text-base text-slate-300 font-sans font-light leading-relaxed max-w-xl">
                {FEATURED_RELEASE.description}
              </p>

              {/* Action buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onPlayTrack('track-1')}
                  data-cursor="PLAY"
                  className="px-8 py-3.5 bg-white text-black hover:bg-cyan-300 font-syne text-xs tracking-[0.25em] font-semibold uppercase transition-all duration-300 rounded-sm flex items-center gap-3 shadow-[0_0_20px_rgba(255,255,255,0.2)]"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>LISTEN NOW</span>
                </button>

                <button
                  onClick={() => setSelectedAlbumModal(ALBUMS[0])}
                  data-cursor="TRACKS"
                  className="px-6 py-3.5 border border-white/20 bg-white/5 hover:bg-white/10 text-white font-syne text-xs tracking-[0.25em] uppercase transition-all duration-300 rounded-sm flex items-center gap-2"
                >
                  <ListMusic className="w-4 h-4 text-cyan-400" />
                  <span>VIEW TRACKLIST</span>
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* DISCOGRAPHY GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredAlbums.map((album) => (
            <motion.div
              key={album.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              onMouseEnter={() => setHoveredAlbum(album)}
              onMouseLeave={() => setHoveredAlbum(null)}
              className="group relative flex flex-col justify-between p-4 rounded-sm border border-white/10 bg-[#080e1b]/70 hover:bg-[#0e1628] transition-all duration-500 shadow-lg"
            >
              {/* Cover Art */}
              <div
                onClick={() => setSelectedAlbumModal(album)}
                data-cursor="PLAY"
                className="relative aspect-square w-full rounded-sm overflow-hidden mb-4 cursor-pointer border border-white/10 group-hover:border-cyan-400/50 transition-colors"
              >
                <img
                  src={album.coverUrl}
                  alt={album.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-[0_0_20px_rgba(0,180,255,0.6)] transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                </div>

                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-[9px] font-mono tracking-widest text-cyan-300 uppercase border border-white/10">
                  {album.type} · {album.year}
                </div>
              </div>

              {/* Title & info */}
              <div>
                <h4 className="text-lg font-syne font-semibold uppercase text-white group-hover:text-cyan-300 transition-colors tracking-wide">
                  {album.title}
                </h4>
                <p className="text-xs text-slate-400 font-mono tracking-widest mt-0.5 uppercase">
                  TATE MCRAE
                </p>
                <p className="text-xs text-slate-400 font-sans line-clamp-2 mt-2 leading-relaxed">
                  {album.description}
                </p>
              </div>

              {/* Card Footer Actions */}
              <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between">
                <button
                  onClick={() => onPlayTrack(album.tracks[0]?.id || 'track-1')}
                  className="text-xs font-syne tracking-widest text-slate-300 hover:text-white uppercase flex items-center gap-1.5"
                >
                  <Music2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>PLAY</span>
                </button>

                <button
                  onClick={() => setSelectedAlbumModal(album)}
                  className="text-xs font-syne tracking-widest text-slate-400 hover:text-cyan-300 uppercase flex items-center gap-1"
                >
                  <span>TRACKS</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* TRACKLIST MODAL OVERLAY */}
      <AnimatePresence>
        {selectedAlbumModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[8000] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6"
            onClick={() => setSelectedAlbumModal(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#090f1e] border border-white/20 rounded-sm p-6 sm:p-10 max-w-2xl w-full text-white shadow-2xl relative max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-start gap-6 border-b border-white/10 pb-6 mb-6">
                <img
                  src={selectedAlbumModal.coverUrl}
                  alt={selectedAlbumModal.title}
                  className="w-24 h-24 rounded-sm object-cover border border-white/10"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1">
                  <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase">
                    {selectedAlbumModal.type} · {selectedAlbumModal.year}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-syne font-light uppercase text-white mt-1">
                    {selectedAlbumModal.title}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono uppercase mt-1">
                    TATE MCRAE
                  </p>
                </div>
              </div>

              {/* Tracks Listing */}
              <div className="space-y-3">
                <h4 className="text-xs font-syne tracking-[0.25em] text-slate-400 uppercase mb-4">
                  TRACKLISTING ({selectedAlbumModal.tracks.length} TRACKS)
                </h4>
                {selectedAlbumModal.tracks.map((track, idx) => (
                  <div
                    key={track.id}
                    onClick={() => {
                      onPlayTrack(track.id);
                      setSelectedAlbumModal(null);
                    }}
                    data-cursor="PLAY"
                    className="flex items-center justify-between p-3 rounded-sm hover:bg-white/10 transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center space-x-4">
                      <span className="text-xs font-mono text-slate-500 w-5">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <div>
                        <span className="text-sm font-syne font-medium text-white group-hover:text-cyan-300 transition-colors block">
                          {track.title}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono uppercase">
                          {track.album}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <span className="text-xs font-mono text-slate-400">{track.duration}</span>
                      <div className="w-7 h-7 rounded-full bg-cyan-400/10 text-cyan-300 group-hover:bg-cyan-400 group-hover:text-black flex items-center justify-center transition-colors">
                        <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setSelectedAlbumModal(null)}
                className="mt-8 w-full py-3 border border-white/20 bg-white/5 hover:bg-white/10 text-white font-syne text-xs tracking-widest uppercase transition-colors"
              >
                CLOSE
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
