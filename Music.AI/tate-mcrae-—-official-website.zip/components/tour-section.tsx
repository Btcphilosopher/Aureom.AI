'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Ticket, MapPin, Sparkles, CheckCircle, ArrowUpRight, ShieldCheck, Clock } from 'lucide-react';
import { TOUR_DATES, TourDate, TATE_IMAGES } from '@/lib/data';

export function TourSection() {
  const [activeRegion, setActiveRegion] = useState<'ALL' | 'NORTH AMERICA' | 'UK & EUROPE' | 'AUSTRALIA'>('ALL');
  const [hoveredTour, setHoveredTour] = useState<TourDate | null>(null);
  const [selectedTicketModal, setSelectedTicketModal] = useState<TourDate | null>(null);
  const [ticketPackage, setTicketPackage] = useState<'STANDARD' | 'VIP_PIT' | 'MEET_GREET'>('STANDARD');
  const [purchaseSuccess, setPurchaseSuccess] = useState(false);

  const filteredDates = TOUR_DATES.filter((tour) => {
    if (activeRegion === 'ALL') return true;
    return tour.region === activeRegion;
  });

  const handleCompleteTicket = (e: React.FormEvent) => {
    e.preventDefault();
    setPurchaseSuccess(true);
    setTimeout(() => {
      setPurchaseSuccess(false);
      setSelectedTicketModal(null);
    }, 2500);
  };

  return (
    <section id="tour" className="relative py-28 sm:py-36 bg-[#03050a] text-white overflow-hidden">
      {/* Background Image Morph on Row Hover */}
      <div className="absolute inset-0 pointer-events-none transition-all duration-1000">
        <div
          className="absolute inset-0 bg-cover bg-center filter brightness-40 blur-lg transition-all duration-1000 scale-105"
          style={{
            backgroundImage: `url(${hoveredTour ? hoveredTour.heroImage : TATE_IMAGES.tourConcert})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#03050a] via-[#03050a]/70 to-[#03050a]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-white/10 pb-8 gap-6">
          <div>
            <span className="text-xs tracking-[0.35em] font-syne text-cyan-400 uppercase font-medium block mb-2">
              THINK LATER WORLD TOUR 2025 / 2026
            </span>
            <h2 className="text-4xl sm:text-6xl md:text-8xl font-syne font-light tracking-tight text-white uppercase">
              ON TOUR
            </h2>
          </div>

          {/* Region Filter Pills */}
          <div className="flex items-center space-x-2 sm:space-x-3 overflow-x-auto pb-2 sm:pb-0">
            {(['ALL', 'NORTH AMERICA', 'UK & EUROPE', 'AUSTRALIA'] as const).map((region) => (
              <button
                key={region}
                onClick={() => setActiveRegion(region)}
                data-cursor="FILTER"
                className={`px-5 py-2 rounded-full text-[11px] font-syne tracking-[0.25em] uppercase transition-all border ${
                  activeRegion === region
                    ? 'border-cyan-400/80 bg-cyan-400/10 text-cyan-300 shadow-[0_0_15px_rgba(0,180,255,0.2)] font-semibold'
                    : 'border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20'
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>

        {/* TOUR DATES ELEGANT HORIZONTAL ROWS */}
        <div className="space-y-3">
          {filteredDates.map((tour) => (
            <motion.div
              key={tour.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              onMouseEnter={() => setHoveredTour(tour)}
              onMouseLeave={() => setHoveredTour(null)}
              className="group relative p-6 sm:p-8 rounded-sm border border-white/10 bg-[#080d19]/80 hover:bg-[#0f182c] transition-all duration-500 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 overflow-hidden shadow-lg"
            >
              {/* Subtle Light Sweep Pass Effect on Hover */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 pointer-events-none" />

              {/* Date */}
              <div className="flex items-baseline space-x-3 min-w-[150px]">
                <span className="text-2xl sm:text-3xl font-syne font-bold text-cyan-300 tracking-wider">
                  {tour.month} {tour.day}
                </span>
                <span className="text-xs font-mono text-slate-400">
                  &apos;{tour.year.slice(2)}
                </span>
              </div>

              {/* City & Country */}
              <div className="flex-1 min-w-[200px]">
                <h3 className="text-xl sm:text-2xl font-syne font-medium text-white group-hover:text-cyan-300 transition-colors tracking-wide uppercase">
                  {tour.city}
                </h3>
                <span className="text-xs font-mono text-slate-400 uppercase tracking-widest block mt-0.5">
                  {tour.country}
                </span>
              </div>

              {/* Venue */}
              <div className="flex-1 min-w-[200px] flex items-center space-x-2 text-slate-300">
                <MapPin className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span className="text-sm font-syne tracking-wide uppercase">
                  {tour.venue}
                </span>
              </div>

              {/* Status Badge & Ticket Button */}
              <div className="flex items-center space-x-4 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 pt-4 md:pt-0 border-white/10">
                {tour.status === 'SOLD OUT' ? (
                  <span className="px-4 py-2 rounded border border-rose-500/40 bg-rose-500/10 text-rose-300 text-xs font-mono tracking-widest uppercase">
                    SOLD OUT
                  </span>
                ) : tour.status === 'FEW TICKETS' ? (
                  <span className="px-4 py-2 rounded border border-amber-500/40 bg-amber-500/10 text-amber-300 text-xs font-mono tracking-widest uppercase flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    FEW LEFT
                  </span>
                ) : (
                  <span className="px-4 py-2 rounded border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 text-xs font-mono tracking-widest uppercase">
                    AVAILABLE
                  </span>
                )}

                <button
                  onClick={() => setSelectedTicketModal(tour)}
                  disabled={tour.status === 'SOLD OUT'}
                  data-cursor="TICKETS"
                  className={`px-6 py-2.5 rounded-sm font-syne text-xs tracking-[0.25em] font-semibold uppercase transition-all duration-300 flex items-center gap-2 ${
                    tour.status === 'SOLD OUT'
                      ? 'bg-white/5 border border-white/10 text-slate-600 cursor-not-allowed'
                      : 'bg-white text-black hover:bg-cyan-300 shadow-[0_0_20px_rgba(255,255,255,0.2)]'
                  }`}
                >
                  <Ticket className="w-4 h-4" />
                  <span>{tour.status === 'SOLD OUT' ? 'NO TICKETS' : 'GET TICKETS'}</span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* TICKET / VIP PACKAGE CHECKOUT MODAL */}
      <AnimatePresence>
        {selectedTicketModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[8000] bg-black/85 backdrop-blur-xl flex items-center justify-center p-6"
            onClick={() => setSelectedTicketModal(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#090f1f] border border-white/20 rounded-sm p-6 sm:p-10 max-w-xl w-full text-white shadow-2xl relative overflow-y-auto max-h-[90vh]"
            >
              {purchaseSuccess ? (
                <div className="text-center py-12 space-y-4">
                  <CheckCircle className="w-16 h-16 text-cyan-400 mx-auto animate-bounce" />
                  <h3 className="text-2xl font-syne uppercase tracking-wider text-white">
                    TICKETS CONFIRMED
                  </h3>
                  <p className="text-xs font-mono text-slate-300">
                    Your official electronic tickets for {selectedTicketModal.city} ({selectedTicketModal.venue}) have been issued.
                  </p>
                </div>
              ) : (
                <>
                  <div className="border-b border-white/10 pb-6 mb-6">
                    <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase">
                      OFFICIAL TICKET RESERVATION
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-syne font-light uppercase text-white mt-1">
                      {selectedTicketModal.city} · {selectedTicketModal.venue}
                    </h3>
                    <p className="text-xs font-mono text-slate-400 uppercase mt-1">
                      {selectedTicketModal.date}, {selectedTicketModal.year} · {selectedTicketModal.country}
                    </p>
                  </div>

                  <form onSubmit={handleCompleteTicket} className="space-y-6">
                    {/* Ticket Package Selector */}
                    <div>
                      <label className="text-xs font-syne tracking-widest text-slate-300 uppercase block mb-3">
                        SELECT TICKET TYPE
                      </label>
                      <div className="space-y-3">
                        <label
                          onClick={() => setTicketPackage('STANDARD')}
                          className={`flex items-center justify-between p-4 rounded border cursor-pointer transition-colors ${
                            ticketPackage === 'STANDARD'
                              ? 'border-cyan-400 bg-cyan-400/10 text-white'
                              : 'border-white/10 bg-white/5 text-slate-400 hover:border-white/20'
                          }`}
                        >
                          <div>
                            <span className="font-syne font-semibold text-sm uppercase block">
                              GA Floor / General Admission
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">
                              Standing room GA floor access
                            </span>
                          </div>
                          <span className="font-syne font-bold text-cyan-300">$85.00</span>
                        </label>

                        <label
                          onClick={() => setTicketPackage('VIP_PIT')}
                          className={`flex items-center justify-between p-4 rounded border cursor-pointer transition-colors ${
                            ticketPackage === 'VIP_PIT'
                              ? 'border-cyan-400 bg-cyan-400/10 text-white'
                              : 'border-white/10 bg-white/5 text-slate-400 hover:border-white/20'
                          }`}
                        >
                          <div>
                            <span className="font-syne font-semibold text-sm uppercase block flex items-center gap-2">
                              <span>Early Entry Pit Pass</span>
                              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">
                              Front-row pit, early venue entry, tour laminate
                            </span>
                          </div>
                          <span className="font-syne font-bold text-cyan-300">$185.00</span>
                        </label>

                        <label
                          onClick={() => setTicketPackage('MEET_GREET')}
                          className={`flex items-center justify-between p-4 rounded border cursor-pointer transition-colors ${
                            ticketPackage === 'MEET_GREET'
                              ? 'border-cyan-400 bg-cyan-400/10 text-white'
                              : 'border-white/10 bg-white/5 text-slate-400 hover:border-white/20'
                          }`}
                        >
                          <div>
                            <span className="font-syne font-semibold text-sm uppercase block flex items-center gap-2">
                              <span>Ultimate Soundcheck & Meet VIP</span>
                              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">
                              Exclusive soundcheck access, photo with Tate, merch pack
                            </span>
                          </div>
                          <span className="font-syne font-bold text-cyan-300">$450.00</span>
                        </label>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-4 bg-cyan-400 text-black hover:bg-white font-syne text-xs tracking-[0.25em] font-semibold uppercase transition-colors shadow-[0_0_20px_rgba(0,180,255,0.4)]"
                    >
                      PROCEED TO SECURE CHECKOUT
                    </button>
                  </form>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
