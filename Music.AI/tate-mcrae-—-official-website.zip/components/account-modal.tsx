'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, ShieldCheck, X, Sparkles, Key, CheckCircle } from 'lucide-react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AccountModal({ isOpen, onClose }: AccountModalProps) {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-[9500] bg-black/90 backdrop-blur-2xl flex items-center justify-center p-6"
      >
        <motion.div
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="max-w-md w-full bg-[#080d19] border border-white/20 rounded-sm p-6 sm:p-10 text-white shadow-2xl relative"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
              <h3 className="text-xl font-syne font-light tracking-widest uppercase">
                VIP FAN CLUB ACCESS
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full border border-white/10 hover:bg-white/10 text-slate-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {isSubmitted ? (
            <div className="text-center py-8 space-y-4">
              <CheckCircle className="w-12 h-12 text-cyan-400 mx-auto" />
              <h4 className="text-lg font-syne font-semibold uppercase">PASS ACTIVATED</h4>
              <p className="text-xs font-mono text-slate-300">
                Your exclusive tour presale pass code is: <br />
                <span className="text-cyan-300 text-sm font-bold tracking-widest block my-2">
                  SOCLOSE-VIP-{Math.floor(Math.random()*8999+1000)}
                </span>
                Check {email} for early merch drops and soundcheck invitations.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                Join Tate&apos;s official VIP network for tour ticket presales, exclusive vinyl variants, and behind-the-scenes rehearsal streams.
              </p>

              <div>
                <label className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase block mb-1.5">
                  EMAIL ADDRESS
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="YOU@DOMAIN.COM"
                  className="w-full px-4 py-3 bg-black/60 border border-white/20 text-xs font-mono text-white placeholder:text-slate-500 uppercase focus:outline-none focus:border-cyan-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-cyan-400 text-black hover:bg-white font-syne text-xs tracking-[0.25em] font-bold uppercase transition-colors shadow-[0_0_20px_rgba(0,180,255,0.4)]"
              >
                GENERATE VIP PRESALE PASS
              </button>
            </form>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
