/* AARDVARK MUSIC — app.js
   Application state, routing, rendering, event wiring, keyboard
   controls. Everything else (Player, Queue, Playlists, Storage,
   MusicLibrary, Visualizer) is treated as a service this module
   composes through its public API. */
(function () {
  "use strict";

  /* ================= Icons (inline SVG, no icon font) ================= */
  const ICONS = {
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v9.5a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/></svg>',
    compass: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M14.5 9.5 10 14l-1 4 4-1 4.5-4.5-3-3z"/></svg>',
    library: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="4" height="16" rx="1"/><rect x="10" y="7" width="4" height="13" rx="1"/><path d="M17.5 4.5 21 5.5l-3.5 15-3.5-1z"/></svg>',
    disc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.4"/></svg>',
    mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
    list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="3.5" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="3.5" cy="18" r="1.3" fill="currentColor" stroke="none"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 20s-7.5-4.6-9.6-9A5 5 0 0 1 12 6a5 5 0 0 1 9.6 5c-2.1 4.4-9.6 9-9.6 9z"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>',
    prev: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h2v14H6zM20 6 9 12l11 6z"/></svg>',
    nextTrack: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 5h-2v14h2zM4 6l11 6-11 6z"/></svg>',
    shuffle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 6h3.5L15 18h4M3 18h3.5L11 12M18 6h1M22 6l-4-3v6zM22 18l-4 3v-6z"/></svg>',
    repeat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M4 7h13a3 3 0 0 1 3 3v2M20 17H7a3 3 0 0 1-3-3v-2M8 4 4 7l4 3M16 20l4-3-4-3"/></svg>',
    queue: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 7h11M4 12h11M4 17h7"/><path d="M18 9v10M14.5 15.5 18 19l3.5-3.5"/></svg>',
    volHigh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8 8 0 0 1 0 12"/></svg>',
    volMute: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 9l5 6M21 9l-5 6"/></svg>',
    more: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="6" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="18" r="1.6"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
    edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 20h4L19.5 8.5a2 2 0 0 0 0-2.8L18.3 4.5a2 2 0 0 0-2.8 0L4 16v4z"/></svg>',
    chevron: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 6l6 6-6 6"/></svg>',
    expand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 9l6 6 6-6"/></svg>',
  };
  function icon(name) {
    return ICONS[name] || "";
  }

  /* ================= Global application state ================= */
  const appState = {
    currentTrack: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.8,
    muted: false,
    shuffle: false,
    repeat: "off",
    queue: { items: [], index: -1 },
    playlists: [],
    likedTracks: [],
    recentlyPlayed: [],
    searchQuery: "",
    currentView: "home",
  };

  /* ================= DOM helpers ================= */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach((k) => {
        const v = attrs[k];
        if (v == null) return;
        if (k === "class") node.className = v;
        else if (k === "html") node.innerHTML = v;
        else if (k === "checked") node.checked = !!v;
        else node.setAttribute(k, v);
      });
    }
    (children || []).forEach((c) => {
      if (c == null) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  function artworkImg(src, alt, cls) {
    const img = el("img", { class: cls || "", alt: alt || "", loading: "lazy" });
    img.src = src || MusicLibrary.DEFAULT_ARTWORK;
    img.addEventListener("error", () => {
      img.onerror = null;
      img.src = MusicLibrary.DEFAULT_ARTWORK;
    });
    return img;
  }

  function toast(message, isError) {
    const stack = $("#toastStack");
    const node = el("div", { class: "toast" + (isError ? " error" : "") }, [message]);
    stack.appendChild(node);
    setTimeout(() => node.remove(), 4200);
  }

  /* ================= Router ================= */
  const routes = {};
  function route(pattern, handler) {
    routes[pattern] = handler;
  }
  function navigate(path) {
    location.hash = "#" + path;
  }
  function matchRoute(hash) {
    const path = (hash || "#/home").replace(/^#/, "") || "/home";
    const segments = path.split("/").filter(Boolean);
    for (const pattern in routes) {
      const pSegs = pattern.split("/").filter(Boolean);
      if (pSegs.length !== segments.length) continue;
      const params = {};
      let ok = true;
      for (let i = 0; i < pSegs.length; i++) {
        if (pSegs[i].startsWith(":")) params[pSegs[i].slice(1)] = decodeURIComponent(segments[i]);
        else if (pSegs[i] !== segments[i]) {
          ok = false;
          break;
        }
      }
      if (ok) return { handler: routes[pattern], params, path };
    }
    return null;
  }

  function renderRoute() {
    const match = matchRoute(location.hash);
    const content = $("#viewContent");
    content.scrollTop = 0;
    content.setAttribute("aria-busy", "true");
    if (!match) {
      content.innerHTML = "";
      content.appendChild(emptyState("Page not found", "Try a link from the sidebar."));
      content.removeAttribute("aria-busy");
      return;
    }
    appState.currentView = match.path.split("/")[1] || "home";
    content.innerHTML = "";
    content.appendChild(match.handler(match.params) || document.createDocumentFragment());
    content.removeAttribute("aria-busy");
    updateActiveNav();
  }

  window.addEventListener("hashchange", renderRoute);

  /* ================= Shared view fragments ================= */

  function emptyState(title, body, extra) {
    const wrap = el("div", { class: "empty-state" }, [
      el("strong", {}, [title]),
      el("span", {}, [body]),
    ]);
    if (extra) wrap.appendChild(extra);
    return wrap;
  }

  function sectionHead(title, linkText, linkRoute) {
    const head = el("div", { class: "section-head" }, [el("h2", { class: "section-title" }, [title])]);
    if (linkText) {
      const a = el("a", { class: "section-link", href: "#" + linkRoute }, [linkText]);
      head.appendChild(a);
    }
    return head;
  }

  function trackDuration(t) {
    return MusicLibrary.formatDuration(t.duration);
  }

  function nowPlayingBadge() {
    return el("span", { class: "now-playing-badge" }, [
      el("span"),
      el("span"),
      el("span"),
    ]);
  }

  function likeButton(trackId) {
    const liked = Storage.isLiked(trackId);
    const btn = el("button", {
      class: "like-btn" + (liked ? " liked" : ""),
      "aria-label": liked ? "Unlike" : "Like",
      "data-action": "toggle-like",
      "data-track-id": trackId,
      html: icon("heart"),
    });
    return btn;
  }

  function trackCard(track) {
    const isCurrent = Player.currentTrack() && Player.currentTrack().id === track.id;
    const card = el(
      "div",
      {
        class: "card" + (isCurrent ? " is-current" : ""),
        tabindex: "0",
        role: "button",
        "aria-label": "Play " + track.title,
        "data-action": "card-track",
        "data-track-id": track.id,
      },
      [
        el("div", { class: "card-art-wrap" }, [
          artworkImg(track.artwork, track.title, "card-art"),
          el("button", {
            class: "card-play",
            "aria-label": "Play",
            "data-action": "play-track-now",
            "data-track-id": track.id,
            html: icon("play"),
          }),
        ]),
        el("div", { class: "card-title" }, [track.title]),
        el("div", { class: "card-sub" }, [track.artist]),
      ]
    );
    return card;
  }

  function albumCard(album) {
    return el(
      "div",
      { class: "card", tabindex: "0", role: "button", "data-action": "nav", "data-route": "/album/" + album.id },
      [
        el("div", { class: "card-art-wrap" }, [
          artworkImg(album.artwork, album.title, "card-art"),
          el("button", {
            class: "card-play",
            "aria-label": "Play album",
            "data-action": "play-album",
            "data-album-id": album.id,
            html: icon("play"),
          }),
        ]),
        el("div", { class: "card-title" }, [album.title]),
        el("div", { class: "card-sub" }, [album.genre + " · " + album.year]),
      ]
    );
  }

  function artistCard(artist) {
    return el(
      "div",
      { class: "card", tabindex: "0", role: "button", "data-action": "nav", "data-route": "/artist/" + artist.id },
      [
        el("div", { class: "card-art-wrap" }, [artworkImg(artist.image, artist.name, "card-art")]),
        el("div", { class: "card-title" }, [artist.name]),
        el("div", { class: "card-sub" }, [artist.genres.join(", ")]),
      ]
    );
  }

  function playlistCard(playlist) {
    return el(
      "div",
      { class: "card", tabindex: "0", role: "button", "data-action": "nav", "data-route": "/playlist/" + playlist.id },
      [
        el("div", { class: "card-art-wrap" }, [
          artworkImg(playlist.artwork, playlist.name, "card-art"),
          el("button", {
            class: "card-play",
            "aria-label": "Play playlist",
            "data-action": "play-playlist",
            "data-playlist-id": playlist.id,
            html: icon("play"),
          }),
        ]),
        el("div", { class: "card-title" }, [playlist.name]),
        el("div", { class: "card-sub" }, [playlist.tracks.length + " tracks"]),
      ]
    );
  }

  function trackRow(track, index, opts) {
    opts = opts || {};
    const current = Player.currentTrack() && Player.currentTrack().id === track.id;
    const row = el(
      "div",
      {
        class: "track-row" + (current ? " is-current" : ""),
        "data-action": "play-track-row",
        "data-track-id": track.id,
        role: "button",
        tabindex: "0",
        draggable: opts.playlistId ? "true" : null,
      },
      [
        el("div", { class: "track-index" }, [
          current && Player.isPlaying()
            ? nowPlayingBadge()
            : el("span", { class: "track-index-num" }, [String(index != null ? index + 1 : "")]),
          el("span", { class: "track-index-play", html: icon("play") }),
        ]),
        el("div", { class: "track-thumb" }, [artworkImg(track.artwork, track.title)]),
        el("div", { class: "track-main" }, [
          el("div", { class: "track-title-line" }, [track.title]),
          el("div", { class: "track-artist-line" }, [track.artist + (opts.showAlbum ? " · " + track.album : "")]),
        ]),
        opts.showAlbumCol ? el("div", { class: "track-album-col" }, [track.album]) : el("div"),
        el("div", { class: "track-duration" }, [trackDuration(track)]),
        el("div", { style: "display:flex;align-items:center;gap:4px;" }, [
          likeButton(track.id),
          el("button", {
            class: "track-more",
            "aria-label": "More options",
            "data-action": "track-menu",
            "data-track-id": track.id,
            html: icon("more"),
          }),
        ]),
      ]
    );
    row.addEventListener("dblclick", () => Player.play(track.id));
    if (opts.playlistId) {
      row.addEventListener("dragstart", (e) => {
        e.dataTransfer.setData("text/plain", String(index));
        row.classList.add("is-dragging");
      });
      row.addEventListener("dragend", () => row.classList.remove("is-dragging"));
      row.addEventListener("dragover", (e) => e.preventDefault());
      row.addEventListener("drop", (e) => {
        e.preventDefault();
        const from = Number(e.dataTransfer.getData("text/plain"));
        Playlists.reorderTracks(opts.playlistId, from, index);
        renderRoute();
      });
    }
    return row;
  }

  function trackListContainer(tracks, opts) {
    const container = el("div", { class: "track-list" });
    if (!tracks.length) {
      container.appendChild(emptyState("No tracks here yet.", "Add music to see it listed."));
      return container;
    }
    tracks.forEach((t, i) => container.appendChild(trackRow(t, i, opts)));
    return container;
  }

  function heroSection({ eyebrow, title, meta, desc, artwork, onPlay, onQueue, trackId, liked }) {
    const actions = [
      el("button", { class: "btn btn-primary", "data-action": "hero-play", html: icon("play") + "<span>Play</span>" }),
      el("button", { class: "btn btn-ghost", "data-action": "hero-queue", html: icon("plus") + "<span>Add to Queue</span>" }),
    ];
    if (trackId) {
      actions.push(likeButton(trackId));
    }
    const hero = el("div", { class: "hero" }, [
      el("div", { class: "hero-artwork" }, [artworkImg(artwork, title)]),
      el("div", { class: "hero-body" }, [
        el("div", { class: "hero-eyebrow" }, [eyebrow]),
        el("h1", { class: "hero-title" }, [title]),
        el("div", { class: "hero-meta" }, [meta]),
        el("p", { class: "hero-desc" }, [desc]),
        el("div", { class: "hero-actions" }, actions),
      ]),
    ]);
    hero.querySelector('[data-action="hero-play"]').addEventListener("click", onPlay);
    hero.querySelector('[data-action="hero-queue"]').addEventListener("click", onQueue);
    return hero;
  }

  /* ================= View renderers ================= */

  function featuredAlbum() {
    const albums = MusicLibrary.getAlbums();
    return albums[Math.floor(Date.now() / 86400000) % albums.length];
  }

  function renderHome() {
    const frag = document.createDocumentFragment();
    const album = featuredAlbum();
    const featTrack = MusicLibrary.tracksForAlbum(album.id)[0];
    frag.appendChild(
      heroSection({
        eyebrow: "FEATURED ALBUM",
        title: album.title,
        meta: album.genre + " · " + MusicLibrary.getArtist(album.artistId).name + " · " + album.year,
        desc: album.description,
        artwork: album.artwork,
        trackId: featTrack ? featTrack.id : null,
        onPlay: () => Player.playAlbum(album.id),
        onQueue: () => {
          MusicLibrary.tracksForAlbum(album.id).forEach((t) => Player.addToQueue(t.id));
          toast("Added “" + album.title + "” to queue.");
        },
      })
    );

    const recent = Storage.getRecentlyPlayed()
      .slice(0, 8)
      .map((r) => MusicLibrary.getTrack(r.trackId))
      .filter(Boolean);
    const recentSec = el("div", { class: "section" }, [sectionHead("Recently Played", "See all", "/recent")]);
    const recentGrid = el("div", { class: "grid" });
    if (recent.length) recent.forEach((t) => recentGrid.appendChild(trackCard(t)));
    else recentGrid.appendChild(emptyState("Nothing played yet.", "Play a track and it will show up here."));
    recentSec.appendChild(recentGrid);
    frag.appendChild(recentSec);

    const releasesSec = el("div", { class: "section" }, [sectionHead("New Releases", "See all", "/albums")]);
    const releasesGrid = el("div", { class: "grid" });
    MusicLibrary.getAlbums()
      .slice()
      .sort((a, b) => b.year - a.year)
      .forEach((a) => releasesGrid.appendChild(albumCard(a)));
    releasesSec.appendChild(releasesGrid);
    frag.appendChild(releasesSec);

    const albumsSec = el("div", { class: "section" }, [sectionHead("Albums", "See all", "/albums")]);
    const albumsGrid = el("div", { class: "grid" });
    MusicLibrary.getAlbums().forEach((a) => albumsGrid.appendChild(albumCard(a)));
    albumsSec.appendChild(albumsGrid);
    frag.appendChild(albumsSec);

    const artistsSec = el("div", { class: "section" }, [sectionHead("Artists", "See all", "/artists")]);
    const artistsGrid = el("div", { class: "grid artists" });
    MusicLibrary.getArtists().forEach((a) => artistsGrid.appendChild(artistCard(a)));
    artistsSec.appendChild(artistsGrid);
    frag.appendChild(artistsSec);

    const plSec = el("div", { class: "section" }, [sectionHead("Your Playlists", "See all", "/playlists")]);
    const plGrid = el("div", { class: "grid" });
    Playlists.getAll().forEach((p) => plGrid.appendChild(playlistCard(p)));
    plSec.appendChild(plGrid);
    frag.appendChild(plSec);

    return wrapView("Home", frag, true);
  }

  function renderDiscover() {
    const frag = document.createDocumentFragment();
    MusicLibrary.getGenres().forEach((genre) => {
      const tracks = MusicLibrary.tracksForGenre(genre);
      const sec = el("div", { class: "section" }, [sectionHead(genre, null, null)]);
      const grid = el("div", { class: "grid" });
      tracks.forEach((t) => grid.appendChild(trackCard(t)));
      sec.appendChild(grid);
      frag.appendChild(sec);
    });
    return wrapView("Discover", frag);
  }

  function renderLibrary() {
    const frag = document.createDocumentFragment();
    frag.appendChild(
      trackListContainer(MusicLibrary.getAllTracks(), { showAlbum: true, showAlbumCol: true })
    );
    return wrapView("Library", frag);
  }

  function renderAlbums() {
    const frag = document.createDocumentFragment();
    const grid = el("div", { class: "grid" });
    MusicLibrary.getAlbums().forEach((a) => grid.appendChild(albumCard(a)));
    frag.appendChild(grid);
    return wrapView("Albums", frag);
  }

  function renderArtists() {
    const frag = document.createDocumentFragment();
    const grid = el("div", { class: "grid artists" });
    MusicLibrary.getArtists().forEach((a) => grid.appendChild(artistCard(a)));
    frag.appendChild(grid);
    return wrapView("Artists", frag);
  }

  function renderPlaylists() {
    const frag = document.createDocumentFragment();
    const grid = el("div", { class: "grid" });
    const createCard = el(
      "div",
      { class: "card", tabindex: "0", role: "button", "data-action": "open-create-playlist" },
      [
        el("div", { class: "card-art-wrap", style: "display:flex;align-items:center;justify-content:center;" }, [
          el("div", { html: icon("plus"), style: "width:28px;height:28px;color:var(--text-tertiary);" }),
        ]),
        el("div", { class: "card-title" }, ["New Playlist"]),
      ]
    );
    grid.appendChild(createCard);
    Playlists.getAll().forEach((p) => grid.appendChild(playlistCard(p)));
    frag.appendChild(grid);
    return wrapView("Playlists", frag);
  }

  function renderLiked() {
    const likedIds = Storage.getLikedTracks();
    const tracks = likedIds.map((id) => MusicLibrary.getTrack(id)).filter(Boolean);
    const frag = document.createDocumentFragment();
    if (tracks.length) {
      frag.appendChild(
        heroSection({
          eyebrow: "LIKED MUSIC",
          title: "Liked Music",
          meta: tracks.length + " tracks",
          desc: "Everything you've liked, in one place.",
          artwork: "assets/artwork/default.svg",
          onPlay: () => Player.playTrackList(tracks.map((t) => t.id)),
          onQueue: () => {
            tracks.forEach((t) => Player.addToQueue(t.id));
            toast("Added liked tracks to queue.");
          },
        })
      );
    }
    frag.appendChild(trackListContainer(tracks, { showAlbum: true, showAlbumCol: true }));
    return wrapView("Liked Music", frag, !tracks.length);
  }

  function renderRecent() {
    const recent = Storage.getRecentlyPlayed();
    const tracks = recent.map((r) => MusicLibrary.getTrack(r.trackId)).filter(Boolean);
    const frag = document.createDocumentFragment();
    frag.appendChild(trackListContainer(tracks, { showAlbum: true, showAlbumCol: true }));
    return wrapView("Recently Played", frag);
  }

  function renderStats() {
    const stats = Storage.getStats();
    const frag = document.createDocumentFragment();
    const grid = el("div", { class: "stats-grid" }, [
      statCard(stats.plays, "Plays"),
      statCard(formatClock(stats.secondsListened), "Listened"),
      statCard(stats.tracksCompleted, "Tracks Completed"),
      statCard(topKey(stats.artistPlays) || "—", "Top Artist"),
      statCard(topKey(stats.genrePlays) || "—", "Top Genre"),
    ]);
    frag.appendChild(grid);
    return wrapView("Listening Statistics", frag);
  }
  function statCard(value, label) {
    return el("div", { class: "stat-card" }, [
      el("div", { class: "stat-value" }, [String(value)]),
      el("div", { class: "stat-label" }, [label]),
    ]);
  }
  function topKey(obj) {
    let best = null,
      bestN = 0;
    Object.keys(obj || {}).forEach((k) => {
      if (obj[k] > bestN) {
        best = k;
        bestN = obj[k];
      }
    });
    return best;
  }
  function formatClock(totalSeconds) {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    return h ? h + "h " + m + "m" : m + "m";
  }

  function renderAlbumDetail(params) {
    const album = MusicLibrary.getAlbum(params.id);
    if (!album) return wrapView("Album not found", emptyState("Album not found.", "It may have been removed."));
    const artist = MusicLibrary.getArtist(album.artistId);
    const tracks = MusicLibrary.tracksForAlbum(album.id);
    const frag = document.createDocumentFragment();
    const head = el("div", { class: "detail-head" }, [
      el("div", { class: "detail-art" }, [artworkImg(album.artwork, album.title)]),
      el("div", {}, [
        el("div", { class: "detail-kind" }, ["ALBUM"]),
        el("h1", { class: "detail-title" }, [album.title]),
        el("div", { class: "detail-meta" }, [
          el("a", { href: "#/artist/" + artist.id }, [artist.name]),
          " · " + album.year + " · " + album.genre + " · " + tracks.length + " tracks",
        ]),
        el("p", { class: "detail-desc" }, [album.description || ""]),
        el("div", { class: "detail-actions" }, [
          el("button", { class: "btn btn-primary", "data-action": "play-album", "data-album-id": album.id, html: icon("play") + "<span>Play</span>" }),
          el("button", { class: "btn btn-ghost", "data-action": "shuffle-album", "data-album-id": album.id, html: icon("shuffle") + "<span>Shuffle</span>" }),
        ]),
      ]),
    ]);
    frag.appendChild(head);
    const th = el("div", { class: "table-head" }, [el("span", {}, ["#"]), el("span", {}, ["Title"]), el("span", {}, ["Time"]), el("span")]);
    frag.appendChild(th);
    frag.appendChild(trackListContainer(tracks));
    return wrapView(null, frag);
  }

  function renderArtistDetail(params) {
    const artist = MusicLibrary.getArtist(params.id);
    if (!artist) return wrapView("Artist not found", emptyState("Artist not found.", "It may have been removed."));
    const popular = MusicLibrary.tracksForArtist(artist.id).slice(0, 6);
    const albums = MusicLibrary.albumsForArtist(artist.id);
    const related = MusicLibrary.relatedArtists(artist.id, 6);
    const frag = document.createDocumentFragment();
    const head = el("div", { class: "detail-head" }, [
      el("div", { class: "detail-art round" }, [artworkImg(artist.image, artist.name)]),
      el("div", {}, [
        el("div", { class: "detail-kind" }, ["ARTIST"]),
        el("h1", { class: "detail-title" }, [artist.name]),
        el("div", { class: "detail-meta" }, [artist.genres.join(", ")]),
        el("p", { class: "detail-desc" }, [artist.bio || ""]),
        el("div", { class: "detail-actions" }, [
          el("button", {
            class: "btn btn-primary",
            "data-action": "play-tracklist",
            "data-ids": popular.map((t) => t.id).join(","),
            html: icon("play") + "<span>Play Popular</span>",
          }),
        ]),
      ]),
    ]);
    frag.appendChild(head);

    const popSec = el("div", { class: "section" }, [sectionHead("Popular Tracks", null, null)]);
    popSec.appendChild(trackListContainer(popular, { showAlbum: true, showAlbumCol: true }));
    frag.appendChild(popSec);

    const cols = el("div", { class: "cols-2" });
    const albumsSec = el("div", { class: "section" }, [sectionHead("Albums", null, null)]);
    const albumsGrid = el("div", { class: "grid" });
    if (albums.length) albums.forEach((a) => albumsGrid.appendChild(albumCard(a)));
    else albumsGrid.appendChild(emptyState("No albums yet.", "Singles only, for now."));
    albumsSec.appendChild(albumsGrid);
    cols.appendChild(albumsSec);

    const relSec = el("div", { class: "section" }, [sectionHead("Related Artists", null, null)]);
    const relGrid = el("div", { class: "grid artists" });
    if (related.length) related.forEach((a) => relGrid.appendChild(artistCard(a)));
    else relGrid.appendChild(emptyState("No related artists found.", "Try another genre."));
    relSec.appendChild(relGrid);
    cols.appendChild(relSec);

    frag.appendChild(cols);
    return wrapView(null, frag);
  }

  function renderPlaylistDetail(params) {
    const playlist = Playlists.getById(params.id);
    if (!playlist) return wrapView("Playlist not found", emptyState("Playlist not found.", "It may have been deleted."));
    const tracks = Playlists.tracksOf(playlist);
    const frag = document.createDocumentFragment();
    frag.appendChild(
      heroSection({
        eyebrow: "PLAYLIST",
        title: playlist.name,
        meta: tracks.length + " tracks",
        desc: playlist.description || "",
        artwork: playlist.artwork,
        onPlay: () => Player.playPlaylist(playlist.id),
        onQueue: () => {
          tracks.forEach((t) => Player.addToQueue(t.id));
          toast("Added “" + playlist.name + "” to queue.");
        },
      })
    );
    const actions = el("div", { class: "detail-actions", style: "margin:-24px 0 24px;" }, [
      el("button", { class: "btn btn-ghost", "data-action": "shuffle-playlist", "data-playlist-id": playlist.id, html: icon("shuffle") + "<span>Shuffle</span>" }),
      el("button", { class: "btn btn-ghost", "data-action": "rename-playlist", "data-playlist-id": playlist.id, html: icon("edit") + "<span>Edit</span>" }),
      el("button", { class: "btn btn-ghost modal-danger", "data-action": "delete-playlist", "data-playlist-id": playlist.id, html: icon("trash") + "<span>Delete</span>" }),
    ]);
    frag.appendChild(actions);
    frag.appendChild(
      trackListContainer(tracks, { showAlbum: true, showAlbumCol: true, playlistId: playlist.id })
    );
    return wrapView(null, frag);
  }

  function renderSearch(params, query) {
    const q = query != null ? query : appState.searchQuery;
    const results = MusicLibrary.search(q);
    const frag = document.createDocumentFragment();
    if (!q) {
      frag.appendChild(emptyState("Start typing to search.", "Search by track, artist, album, genre or year."));
      return wrapView("Search", frag);
    }
    const count = results.tracks.length + results.artists.length + results.albums.length;
    frag.appendChild(el("div", { class: "search-results-meta" }, [count + ' results for "' + q + '"']));

    if (results.artists.length) {
      const sec = el("div", { class: "section" }, [sectionHead("Artists", null, null)]);
      const grid = el("div", { class: "grid artists" });
      results.artists.forEach((a) => grid.appendChild(artistCard(a)));
      sec.appendChild(grid);
      frag.appendChild(sec);
    }
    if (results.albums.length) {
      const sec = el("div", { class: "section" }, [sectionHead("Albums", null, null)]);
      const grid = el("div", { class: "grid" });
      results.albums.forEach((a) => grid.appendChild(albumCard(a)));
      sec.appendChild(grid);
      frag.appendChild(sec);
    }
    if (results.tracks.length) {
      const sec = el("div", { class: "section" }, [sectionHead("Tracks", null, null)]);
      const list = el("div", { class: "track-list" });
      results.tracks.forEach((t, i) => {
        const row = trackRow(t, i, { showAlbum: true });
        const titleLine = row.querySelector(".track-title-line");
        titleLine.innerHTML = "";
        titleLine.appendChild(MusicLibrary.highlight(t.title, q));
        list.appendChild(row);
      });
      sec.appendChild(list);
      frag.appendChild(sec);
    }
    if (!count) frag.appendChild(emptyState("No results.", 'Nothing matched "' + q + '".'));
    return wrapView("Search", frag);
  }

  function wrapView(title, content, skipTitle) {
    const frag = document.createDocumentFragment();
    if (title && !skipTitle) frag.appendChild(el("h1", { class: "view-title" }, [title]));
    frag.appendChild(content);
    return frag;
  }

  route("/home", renderHome);
  route("/discover", renderDiscover);
  route("/library", renderLibrary);
  route("/albums", renderAlbums);
  route("/artists", renderArtists);
  route("/playlists", renderPlaylists);
  route("/liked", renderLiked);
  route("/recent", renderRecent);
  route("/stats", renderStats);
  route("/album/:id", renderAlbumDetail);
  route("/artist/:id", renderArtistDetail);
  route("/playlist/:id", renderPlaylistDetail);
  route("/search", (params) => renderSearch(params));

  function updateActiveNav() {
    const path = location.hash.replace(/^#/, "") || "/home";
    $$(".nav-link[data-route]").forEach((a) => {
      const r = a.getAttribute("data-route");
      a.classList.toggle("active", path === r || (r !== "/home" && path.startsWith(r)));
    });
    $$("#mobileNav a[data-route]").forEach((a) => {
      const r = a.getAttribute("data-route");
      a.classList.toggle("active", path === r || (r !== "/home" && path.startsWith(r)));
    });
  }

  /* ================= Persistent player UI ================= */

  function fmtTime(s) {
    return MusicLibrary.formatDuration(s);
  }

  function renderPlayerBar() {
    const track = Player.currentTrack();
    const playing = Player.isPlaying();

    const titleEl = $("#playerTitle");
    const artistEl = $("#playerArtist");
    const thumbEl = $("#playerThumb");
    const thumbImg = $("#playerThumb img");

    if (track) {
      titleEl.textContent = track.title;
      titleEl.classList.remove("is-empty");
      artistEl.innerHTML = "";
      artistEl.appendChild(el("a", { href: "#/artist/" + track.artistId }, [track.artist]));
      if (!thumbImg || thumbImg.dataset.src !== track.artwork) {
        thumbEl.innerHTML = "";
        const img = artworkImg(track.artwork, track.title);
        img.dataset.src = track.artwork;
        thumbEl.appendChild(img);
      }
      thumbEl.classList.toggle("is-playing", playing);
    } else {
      titleEl.textContent = "Nothing playing";
      titleEl.classList.add("is-empty");
      artistEl.textContent = "Select a track to begin";
      thumbEl.innerHTML = "";
      thumbEl.classList.remove("is-playing");
    }

    $("#btnPlayPause").innerHTML = icon(playing ? "pause" : "play");
    $("#btnPlayPause").setAttribute("aria-label", playing ? "Pause" : "Play");
    $("#btnShuffle").classList.toggle("is-active", Player.getShuffle());
    const repeat = Player.getRepeat();
    $("#btnRepeat").classList.toggle("is-active", repeat !== "off");
    $("#btnRepeat").innerHTML = icon("repeat") + (repeat === "one" ? '<span class="repeat-dot"></span>' : "");

    renderMiniPlayer(track, playing);
    renderNowPlayingMeta(track, playing);
  }

  function updateProgressUI() {
    const duration = Player.getDuration() || 0;
    const current = Player.getCurrentTime() || 0;
    const pct = duration ? (current / duration) * 100 : 0;
    $("#timeCurrent").textContent = fmtTime(current);
    $("#timeDuration").textContent = fmtTime(duration);
    $("#progressFill").style.width = pct + "%";
    if (!seekingNow) $("#progressKnob").style.left = pct + "%";
    $("#npTimeCurrent").textContent = fmtTime(current);
    $("#npTimeDuration").textContent = fmtTime(duration);
    $("#npProgressFill").style.width = pct + "%";
    $("#miniProgressFill").style.width = pct + "%";
  }

  function renderMiniPlayer(track, playing) {
    const thumb = $("#miniThumb");
    if (track) {
      thumb.innerHTML = "";
      thumb.appendChild(artworkImg(track.artwork, track.title));
      $("#miniTitle").textContent = track.title;
      $("#miniArtist").textContent = track.artist;
    } else {
      thumb.innerHTML = "";
      $("#miniTitle").textContent = "Nothing playing";
      $("#miniArtist").textContent = "";
    }
    $("#miniPlayBtn").innerHTML = icon(playing ? "pause" : "play");
  }

  function renderNowPlayingMeta(track, playing) {
    const artImg = $("#npArtwork img");
    const wrap = $("#npArtwork").parentElement;
    if (track) {
      if (!artImg || artImg.dataset.src !== track.artwork) {
        $("#npArtwork").innerHTML = "";
        const img = artworkImg(track.artwork, track.title);
        img.dataset.src = track.artwork;
        $("#npArtwork").appendChild(img);
      }
      $("#npBackdrop").innerHTML = "";
      $("#npBackdrop").appendChild(artworkImg(track.artwork, ""));
      $("#npTitle").textContent = track.title;
      $("#npArtist").innerHTML = "";
      $("#npArtist").appendChild(el("a", { href: "#/artist/" + track.artistId }, [track.artist]));
      $("#npAlbum").textContent = track.album || "";
      $("#npLyrics").style.display = track.lyrics ? "" : "none";
      $("#npLyrics").textContent = track.lyrics || "";
      updateAmbientBackground(track);
    } else {
      $("#npTitle").textContent = "Nothing playing";
      $("#npArtist").textContent = "";
      $("#npAlbum").textContent = "";
      $("#npLyrics").style.display = "none";
    }
    wrap.classList.toggle("is-playing", playing);
    $("#npPlayBtn").innerHTML = icon(playing ? "pause" : "play");
    $("#npShuffle").classList.toggle("is-active", Player.getShuffle());
    $("#npRepeat").classList.toggle("is-active", Player.getRepeat() !== "off");
  }

  /* ---------------- Dynamic ambient background ---------------- */
  const colorCache = new Map();
  function updateAmbientBackground(track) {
    const album = track.albumId ? MusicLibrary.getAlbum(track.albumId) : null;
    const fallback = (album && album.accent) || "91,124,153";
    if (colorCache.has(track.artwork)) {
      applyAmbient(colorCache.get(track.artwork));
      return;
    }
    extractDominantColor(track.artwork, fallback).then((rgb) => {
      colorCache.set(track.artwork, rgb);
      applyAmbient(rgb);
    });
  }
  function applyAmbient(rgb) {
    document.documentElement.style.setProperty("--amb-1", rgb);
  }
  function extractDominantColor(src, fallback) {
    return new Promise((resolve) => {
      try {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          try {
            const c = document.createElement("canvas");
            c.width = 24;
            c.height = 24;
            const cx = c.getContext("2d");
            cx.drawImage(img, 0, 0, 24, 24);
            const data = cx.getImageData(0, 0, 24, 24).data;
            let r = 0, g = 0, b = 0, n = 0;
            for (let i = 0; i < data.length; i += 4) {
              r += data[i];
              g += data[i + 1];
              b += data[i + 2];
              n++;
            }
            resolve(Math.round(r / n) + "," + Math.round(g / n) + "," + Math.round(b / n));
          } catch (err) {
            resolve(fallback); // canvas tainted (e.g. file:// origin) — fall back gracefully
          }
        };
        img.onerror = () => resolve(fallback);
        img.src = src;
      } catch (err) {
        resolve(fallback);
      }
    });
  }

  /* ---------------- Progress / volume interaction ---------------- */
  let seekingNow = false;

  function wireProgressBar() {
    const track = $("#progressTrack");
    function ratioFromEvent(e) {
      const rect = track.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      return Math.max(0, Math.min(1, x / rect.width));
    }
    function begin(e) {
      seekingNow = true;
      track.classList.add("is-seeking");
      move(e);
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", end);
      window.addEventListener("touchmove", move, { passive: false });
      window.addEventListener("touchend", end);
    }
    function move(e) {
      if (e.cancelable) e.preventDefault();
      const ratio = ratioFromEvent(e);
      $("#progressFill").style.width = ratio * 100 + "%";
      $("#progressKnob").style.left = ratio * 100 + "%";
      const duration = Player.getDuration() || 0;
      $("#timeCurrent").textContent = fmtTime(ratio * duration);
    }
    function end(e) {
      const ratio = ratioFromEvent(e.changedTouches ? { clientX: e.changedTouches[0].clientX } : e);
      const duration = Player.getDuration() || 0;
      Player.seek(ratio * duration);
      seekingNow = false;
      track.classList.remove("is-seeking");
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", end);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("touchend", end);
    }
    track.addEventListener("mousedown", begin);
    track.addEventListener("touchstart", begin, { passive: true });
    track.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") Player.seekBy(5);
      if (e.key === "ArrowLeft") Player.seekBy(-5);
    });

    const npTrack = $("#npProgressTrack");
    npTrack.addEventListener("click", (e) => {
      const rect = npTrack.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      Player.seek(ratio * (Player.getDuration() || 0));
    });
  }

  function wireVolume() {
    const track = $("#volumeTrack");
    function apply(e) {
      const rect = track.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      Player.setVolume(ratio);
    }
    function begin(e) {
      apply(e);
      window.addEventListener("mousemove", apply);
      window.addEventListener("mouseup", stop);
    }
    function stop() {
      window.removeEventListener("mousemove", apply);
      window.removeEventListener("mouseup", stop);
    }
    track.addEventListener("mousedown", begin);
  }

  function updateVolumeUI() {
    const v = Player.getMuted() ? 0 : Player.getVolume();
    $("#volumeFill").style.width = v * 100 + "%";
    $("#btnMute").innerHTML = icon(v === 0 ? "volMute" : "volHigh");
  }

  /* ---------------- Queue drawer ---------------- */

  function renderQueueDrawer() {
    const snap = Queue.snapshot();
    const current = snap.current ? MusicLibrary.getTrack(snap.current) : null;
    const upcoming = snap.upcoming.map((id) => MusicLibrary.getTrack(id)).filter(Boolean);
    $("#queueBadge").textContent = snap.upcoming.length;
    $("#queueBadge").style.display = snap.upcoming.length ? "flex" : "none";

    const body = $("#queueBody");
    body.innerHTML = "";

    body.appendChild(el("div", { class: "drawer-section-label" }, ["NOW PLAYING"]));
    if (current) body.appendChild(queueRow(current, -1, true));
    else body.appendChild(el("div", { class: "queue-empty" }, ["Nothing queued."]));

    body.appendChild(el("div", { class: "drawer-section-label" }, ["UP NEXT (" + upcoming.length + ")"]));
    if (!upcoming.length) {
      body.appendChild(el("div", { class: "queue-empty" }, ["Your queue is empty. Add tracks from any list."]));
    } else {
      upcoming.forEach((t, i) => body.appendChild(queueRow(t, i, false)));
    }
  }

  function queueRow(track, upcomingIndex, isCurrent) {
    const row = el(
      "div",
      {
        class: "queue-row" + (isCurrent ? " current" : ""),
        draggable: isCurrent ? "false" : "true",
        "data-upcoming-index": upcomingIndex,
      },
      [
        el("div", { class: "thumb" }, [artworkImg(track.artwork, track.title)]),
        el("div", { class: "meta" }, [
          el("div", { class: "t" }, [track.title]),
          el("div", { class: "a" }, [track.artist]),
        ]),
        isCurrent
          ? el("span", { class: "track-duration" }, [trackDuration(track)])
          : el("button", { class: "remove", "aria-label": "Remove from queue", html: icon("close") }),
      ]
    );
    if (!isCurrent) {
      row.querySelector(".remove").addEventListener("click", () => {
        const snap = Queue.snapshot();
        Queue.removeFromQueue(snap.index + 1 + upcomingIndex);
      });
      row.addEventListener("dragstart", (e) => {
        row.classList.add("is-dragging");
        e.dataTransfer.setData("text/plain", String(upcomingIndex));
      });
      row.addEventListener("dragend", () => row.classList.remove("is-dragging"));
      row.addEventListener("dragover", (e) => e.preventDefault());
      row.addEventListener("drop", (e) => {
        e.preventDefault();
        const from = Number(e.dataTransfer.getData("text/plain"));
        const snap = Queue.snapshot();
        Queue.reorder(snap.index + 1 + from, snap.index + 1 + upcomingIndex);
      });
    }
    return row;
  }

  function openQueueDrawer() {
    $("#queueDrawer").classList.add("open");
  }
  function closeQueueDrawer() {
    $("#queueDrawer").classList.remove("open");
  }

  /* ---------------- Now playing fullscreen ---------------- */
  function openNowPlaying() {
    $("#nowPlaying").classList.add("open");
    Visualizer.resume();
  }
  function closeNowPlaying() {
    $("#nowPlaying").classList.remove("open");
  }

  /* ---------------- Playlist modals ---------------- */
  function openModal(id) {
    $(id).classList.add("open");
  }
  function closeModal(id) {
    $(id).classList.remove("open");
  }

  function openCreatePlaylist() {
    $("#createPlaylistName").value = "";
    $("#createPlaylistDesc").value = "";
    openModal("#modalCreatePlaylist");
    $("#createPlaylistName").focus();
  }

  let renamingPlaylistId = null;
  function openRenamePlaylist(id) {
    const p = Playlists.getById(id);
    if (!p) return;
    renamingPlaylistId = id;
    $("#renamePlaylistName").value = p.name;
    $("#renamePlaylistDesc").value = p.description || "";
    openModal("#modalRenamePlaylist");
  }

  let addingTrackId = null;
  function openAddToPlaylist(trackId) {
    addingTrackId = trackId;
    const list = $("#addToPlaylistList");
    list.innerHTML = "";
    const playlists = Playlists.getAll();
    if (!playlists.length) {
      list.appendChild(emptyState("No playlists yet.", "Create one first."));
    } else {
      playlists.forEach((p) => {
        const row = el("label", { class: "playlist-pick-row" }, [
          el("input", { type: "checkbox", "data-playlist-id": p.id, checked: p.tracks.indexOf(trackId) !== -1 ? "checked" : null }),
          el("span", {}, [p.name]),
        ]);
        const checkbox = row.querySelector("input");
        checkbox.addEventListener("change", () => {
          if (checkbox.checked) {
            Playlists.addTrack(p.id, trackId);
            toast("Added to “" + p.name + "”.");
          } else {
            Playlists.removeTrack(p.id, trackId);
          }
        });
        list.appendChild(row);
      });
    }
    openModal("#modalAddToPlaylist");
  }

  /* ================= Event wiring (delegation) ================= */

  function wireGlobalClicks() {
    document.addEventListener("click", (e) => {
      const actionEl = e.target.closest("[data-action]");
      if (!actionEl) return;
      const action = actionEl.getAttribute("data-action");

      switch (action) {
        case "nav":
          navigate(actionEl.getAttribute("data-route"));
          break;
        case "card-track":
          if (e.target.closest('[data-action="play-track-now"]')) break;
          Player.cue(actionEl.getAttribute("data-track-id"));
          break;
        case "play-track-now":
          e.stopPropagation();
          Player.play(actionEl.getAttribute("data-track-id"));
          break;
        case "play-track-row":
          Player.play(actionEl.getAttribute("data-track-id"));
          break;
        case "play-album":
          Player.playAlbum(actionEl.getAttribute("data-album-id"));
          break;
        case "shuffle-album":
          Player.playAlbum(actionEl.getAttribute("data-album-id"), true);
          break;
        case "play-playlist":
          Player.playPlaylist(actionEl.getAttribute("data-playlist-id"));
          break;
        case "shuffle-playlist":
          Player.playPlaylist(actionEl.getAttribute("data-playlist-id"), true);
          break;
        case "play-tracklist":
          Player.playTrackList(actionEl.getAttribute("data-ids").split(","));
          break;
        case "toggle-like": {
          const id = actionEl.getAttribute("data-track-id");
          const liked = Storage.toggleLike(id);
          actionEl.classList.toggle("liked", liked);
          toast(liked ? "Added to Liked Music." : "Removed from Liked Music.");
          break;
        }
        case "track-menu":
          openAddToPlaylist(actionEl.getAttribute("data-track-id"));
          break;
        case "open-create-playlist":
          openCreatePlaylist();
          break;
        case "rename-playlist":
          openRenamePlaylist(actionEl.getAttribute("data-playlist-id"));
          break;
        case "delete-playlist": {
          const id = actionEl.getAttribute("data-playlist-id");
          const p = Playlists.getById(id);
          if (p && confirm('Delete playlist "' + p.name + '"? This cannot be undone.')) {
            Playlists.remove(id);
            toast("Playlist deleted.");
            navigate("/playlists");
          }
          break;
        }
        case "close-modal":
          closeModal("#" + actionEl.closest(".modal-backdrop").id);
          break;
      }
    });
  }

  function wireModals() {
    $$(".modal-backdrop").forEach((backdrop) => {
      backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) backdrop.classList.remove("open");
      });
    });
    $("#createPlaylistForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const p = Playlists.create($("#createPlaylistName").value, $("#createPlaylistDesc").value);
      closeModal("#modalCreatePlaylist");
      toast("Created playlist “" + p.name + "”.");
      navigate("/playlist/" + p.id);
    });
    $("#renamePlaylistForm").addEventListener("submit", (e) => {
      e.preventDefault();
      if (renamingPlaylistId) {
        Playlists.rename(renamingPlaylistId, $("#renamePlaylistName").value, $("#renamePlaylistDesc").value);
        closeModal("#modalRenamePlaylist");
        toast("Playlist updated.");
        renderRoute();
      }
    });
  }

  /* ---------------- Search ---------------- */
  function wireSearch() {
    const input = $("#searchInput");
    const clearBtn = $("#searchClear");
    let debounceTimer = null;
    input.addEventListener("input", () => {
      clearBtn.classList.toggle("visible", !!input.value);
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        appState.searchQuery = input.value.trim();
        if (appState.searchQuery) {
          if (!location.hash.startsWith("#/search")) navigate("/search");
          else renderRoute();
        }
      }, 180);
    });
    clearBtn.addEventListener("click", () => {
      input.value = "";
      clearBtn.classList.remove("visible");
      appState.searchQuery = "";
      input.focus();
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && input.value.trim()) navigate("/search");
    });
  }
  // patch router so /search reads current query directly
  routes["/search"] = () => renderSearch({}, appState.searchQuery);

  /* ---------------- Keyboard controls ---------------- */
  function wireKeyboard() {
    document.addEventListener("keydown", (e) => {
      const tag = (e.target.tagName || "").toLowerCase();
      if (tag === "input" || tag === "textarea" || e.target.isContentEditable) return;
      switch (e.key.toLowerCase()) {
        case " ":
          e.preventDefault();
          Player.toggle();
          break;
        case "arrowleft":
          Player.seekBy(-5);
          break;
        case "arrowright":
          Player.seekBy(5);
          break;
        case "arrowup":
          e.preventDefault();
          Player.setVolume(Math.min(1, Player.getVolume() + 0.05));
          break;
        case "arrowdown":
          e.preventDefault();
          Player.setVolume(Math.max(0, Player.getVolume() - 0.05));
          break;
        case "n":
          Player.next(true);
          break;
        case "p":
          Player.previous();
          break;
        case "m":
          Player.toggleMute();
          break;
        case "s":
          Player.toggleShuffle();
          break;
        case "escape":
          closeQueueDrawer();
          closeNowPlaying();
          $$(".modal-backdrop.open").forEach((m) => m.classList.remove("open"));
          break;
      }
    });
  }

  /* ---------------- Transport buttons ---------------- */
  function wireTransport() {
    $("#btnPlayPause").addEventListener("click", () => Player.toggle());
    $("#btnPrev").addEventListener("click", () => Player.previous());
    $("#btnNext").addEventListener("click", () => Player.next(true));
    $("#btnShuffle").addEventListener("click", () => Player.toggleShuffle());
    $("#btnRepeat").addEventListener("click", () => Player.cycleRepeat());
    $("#btnMute").addEventListener("click", () => Player.toggleMute());
    $("#btnQueue").addEventListener("click", () => {
      if ($("#queueDrawer").classList.contains("open")) closeQueueDrawer();
      else openQueueDrawer();
    });
    $("#btnQueueHeader").addEventListener("click", () => {
      if ($("#queueDrawer").classList.contains("open")) closeQueueDrawer();
      else openQueueDrawer();
    });
    $("#btnCloseQueue").addEventListener("click", closeQueueDrawer);
    $("#btnClearQueue").addEventListener("click", () => {
      Player.clearQueue();
      toast("Queue cleared.");
    });
    $("#playerThumb").addEventListener("click", openNowPlaying);
    $("#btnExpand").addEventListener("click", openNowPlaying);
    $("#btnCloseNowPlaying").addEventListener("click", closeNowPlaying);

    $("#npPlayBtn").addEventListener("click", () => Player.toggle());
    $("#npPrev").addEventListener("click", () => Player.previous());
    $("#npNext").addEventListener("click", () => Player.next(true));
    $("#npShuffle").addEventListener("click", () => Player.toggleShuffle());
    $("#npRepeat").addEventListener("click", () => Player.cycleRepeat());
    $("#npQueueBtn").addEventListener("click", openQueueDrawer);

    $("#miniPlayBtn").addEventListener("click", (e) => {
      e.stopPropagation();
      Player.toggle();
    });
    $("#miniNextBtn").addEventListener("click", (e) => {
      e.stopPropagation();
      Player.next(true);
    });
    $("#miniPlayer").addEventListener("click", openNowPlaying);

    $$(".np-vis-modes button").forEach((btn) => {
      btn.addEventListener("click", () => {
        Visualizer.setMode(btn.getAttribute("data-mode"));
        Storage.setPreferences({ visualizerMode: btn.getAttribute("data-mode") });
        $$(".np-vis-modes button").forEach((b) => b.classList.toggle("is-active", b === btn));
      });
    });

    $("#btnFullscreen").addEventListener("click", () => {
      const np = $("#nowPlaying");
      if (!document.fullscreenElement) np.requestFullscreen?.().catch(() => {});
      else document.exitFullscreen?.();
    });

    $("#sidebarToggle")?.addEventListener("click", () => {
      document.body.classList.toggle("sidebar-open");
    });
  }

  /* ================= Player event bindings ================= */
  function wirePlayerEvents() {
    Player.events.addEventListener("TRACK_CHANGED", () => renderPlayerBar());
    Player.events.addEventListener("TRACK_PLAYING", () => {
      renderPlayerBar();
      Visualizer.start(() => Player.isPlaying());
    });
    Player.events.addEventListener("TRACK_PAUSED", () => renderPlayerBar());
    Player.events.addEventListener("TIME_UPDATED", () => updateProgressUI());
    Player.events.addEventListener("VOLUME_CHANGED", () => updateVolumeUI());
    Player.events.addEventListener("SHUFFLE_CHANGED", () => renderPlayerBar());
    Player.events.addEventListener("REPEAT_CHANGED", () => renderPlayerBar());
    Player.events.addEventListener("TRACK_ERROR", (e) => {
      toast(e.detail.message, true);
      renderPlayerBar();
    });
    Player.events.addEventListener("TRACK_LOADED", () => {
      const current = Player.currentTrack();
      if (current && location.hash.startsWith("#/album/" + current.albumId)) renderRoute();
    });
    Queue.events.addEventListener("QUEUE_CHANGED", () => renderQueueDrawer());
    Playlists.events.addEventListener("PLAYLIST_CHANGED", () => {
      if (location.hash === "#/playlists") renderRoute();
    });
  }

  /* ================= Sidebar / mobile nav build ================= */
  function buildCounts() {
    $("#navLikedCount").textContent = Storage.getLikedTracks().length;
  }

  /* ================= Init ================= */
  async function init() {
    const { trackCount, invalidCount } = await MusicLibrary.load("data/library.json");
    if (invalidCount) toast(invalidCount + " track record(s) skipped (missing required fields).", true);
    if (!trackCount) {
      toast("Library is empty — check data/library.json.", true);
    }

    Playlists.init();
    Queue.restore();

    const prefs = Storage.getPreferences();
    Player.setVolume(prefs.volume);
    if (prefs.muted) Player.toggleMute();
    Player.setShuffle(prefs.shuffle);
    Player.setRepeat(prefs.repeat);
    $$(".np-vis-modes button").forEach((b) => b.classList.toggle("is-active", b.getAttribute("data-mode") === prefs.visualizerMode));
    Visualizer.setMode(prefs.visualizerMode || "bars");
    Visualizer.init(Player.getAudioElement(), $("#npVisCanvas"));

    wireGlobalClicks();
    wireModals();
    wireSearch();
    wireKeyboard();
    wireTransport();
    wireProgressBar();
    wireVolume();
    wirePlayerEvents();

    buildCounts();
    renderPlayerBar();
    updateVolumeUI();
    renderQueueDrawer();
    renderRoute();

    // Resume AudioContext on first user gesture (autoplay policy).
    document.addEventListener("click", () => Visualizer.resume(), { once: true });
    document.addEventListener("keydown", () => Visualizer.resume(), { once: true });

    if (!MusicLibrary.getAllTracks().some((t) => true)) {
      /* library empty is already surfaced via toast above */
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
