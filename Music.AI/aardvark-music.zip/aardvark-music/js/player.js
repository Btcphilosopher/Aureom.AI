/* AARDVARK MUSIC — player.js
   Wraps the <audio> element, exposes a clean Player API, drives the
   state machine, media transitions, repeat/shuffle and Media Session. */
(function (global) {
  "use strict";

  const STATES = Object.freeze({
    IDLE: "IDLE",
    LOADING: "LOADING",
    READY: "READY",
    PLAYING: "PLAYING",
    PAUSED: "PAUSED",
    SEEKING: "SEEKING",
    BUFFERING: "BUFFERING",
    ENDED: "ENDED",
    ERROR: "ERROR",
  });

  const ERROR_MESSAGES = {
    1: "Playback was interrupted.",
    2: "This track could not load — check your connection.",
    3: "This browser could not decode this audio format.",
    4: "The MP3 file could not be found. Add it to the /music/ folder.",
    default: "Unable to load track.",
  };

  function createPlayer() {
    const audio = document.getElementById("audioPlayer");
    const preloadAudio = new Audio();
    preloadAudio.preload = "auto";
    const target = new EventTarget();

    const prefs = Storage.getPreferences();
    let state = STATES.IDLE;
    let currentTrackId = null;
    let lastErrorMessage = null;
    let shuffle = !!prefs.shuffle;
    let repeat = prefs.repeat || "off"; // off | all | one
    let completedCreditedForTrack = null;
    let lastSecondMark = 0;

    audio.volume = clamp01(prefs.volume);
    audio.muted = !!prefs.muted;

    function clamp01(v) {
      return Math.max(0, Math.min(1, v == null ? 1 : v));
    }

    function setState(next) {
      state = next;
      target.dispatchEvent(new CustomEvent("STATE_CHANGED", { detail: { state } }));
    }

    function emit(name, detail) {
      target.dispatchEvent(new CustomEvent(name, { detail }));
    }

    function currentTrack() {
      return currentTrackId ? MusicLibrary.getTrack(currentTrackId) : null;
    }

    /* ---------------- Loading & track changes ---------------- */

    function loadTrack(trackId, autoplay) {
      const track = MusicLibrary.getTrack(trackId);
      if (!track) {
        lastErrorMessage = "This track no longer exists in the library.";
        setState(STATES.ERROR);
        emit("TRACK_ERROR", { trackId, message: lastErrorMessage });
        return;
      }
      currentTrackId = trackId;
      completedCreditedForTrack = null;
      lastErrorMessage = null;
      setState(STATES.LOADING);
      try {
        audio.src = track.source;
        audio.load();
        if (autoplay) {
          const p = audio.play();
          if (p && p.catch) p.catch(onPlayRejected);
        }
      } catch (err) {
        handleError(err);
      }
      emit("TRACK_CHANGED", { track });
      Storage.addRecentlyPlayed(trackId);
      updateMediaSessionMetadata(track);
      preloadNextTrack();
    }

    function onPlayRejected(err) {
      console.warn("[player] play() rejected", err);
      setState(STATES.PAUSED);
    }

    function preloadNextTrack() {
      const nextId = Queue.peekNext(shuffle);
      const track = nextId ? MusicLibrary.getTrack(nextId) : null;
      if (track) {
        try {
          preloadAudio.src = track.source;
          preloadAudio.preload = "auto";
        } catch (err) {
          /* best-effort only */
        }
      }
    }

    /* ---------------- Transport API ---------------- */

    function play(trackId) {
      if (trackId && trackId !== currentTrackId) {
        if (!Queue.has(trackId)) Queue.playNow(trackId);
        else jumpQueueTo(trackId);
        loadTrack(trackId, true);
        return;
      }
      if (!currentTrackId) {
        const cur = Queue.getCurrent();
        if (cur) {
          loadTrack(cur, true);
          return;
        }
      }
      const p = audio.play();
      if (p && p.catch) p.catch(onPlayRejected);
    }

    function cue(trackId) {
      if (!Queue.has(trackId)) Queue.playNow(trackId);
      else jumpQueueTo(trackId);
      loadTrack(trackId, false);
    }

    function jumpQueueTo(trackId) {
      const snap = Queue.snapshot();
      const idx = snap.items.indexOf(trackId);
      if (idx !== -1) Queue.setQueue(snap.items, idx);
    }

    function pause() {
      audio.pause();
    }

    function toggle() {
      if (audio.paused) play();
      else pause();
    }

    function playAlbum(albumId, shuffled) {
      const list = MusicLibrary.tracksForAlbum(albumId).map((t) => t.id);
      if (!list.length) return;
      const ids = shuffled ? shuffleArray(list) : list;
      Queue.setQueue(ids, 0);
      loadTrack(ids[0], true);
      if (shuffled) setShuffle(true);
    }

    function playPlaylist(playlistId, shuffled) {
      const playlist = Playlists.getById(playlistId);
      if (!playlist || !playlist.tracks.length) return;
      const ids = shuffled ? shuffleArray(playlist.tracks.slice()) : playlist.tracks.slice();
      Queue.setQueue(ids, 0);
      loadTrack(ids[0], true);
      if (shuffled) setShuffle(true);
    }

    function playTrackList(trackIds, startId) {
      if (!trackIds.length) return;
      const startIndex = startId ? Math.max(0, trackIds.indexOf(startId)) : 0;
      Queue.setQueue(trackIds, startIndex);
      loadTrack(trackIds[startIndex], true);
    }

    function shuffleArray(arr) {
      const a = arr.slice();
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    }

    function next(userInitiated) {
      if (repeat === "one" && !userInitiated) {
        seek(0);
        play();
        return;
      }
      const nextId = Queue.advance(shuffle);
      if (nextId) {
        loadTrack(nextId, true);
        return;
      }
      if (repeat === "all") {
        const restarted = Queue.wrapToStart();
        if (restarted) {
          loadTrack(restarted, true);
          return;
        }
      }
      setState(STATES.ENDED);
      pause();
    }

    function previous() {
      if (audio.currentTime > 3) {
        seek(0);
        return;
      }
      const prevId = Queue.retreat();
      if (prevId) loadTrack(prevId, true);
      else seek(0);
    }

    function seek(seconds) {
      if (!isFinite(audio.duration) || audio.duration <= 0) return;
      setState(STATES.SEEKING);
      audio.currentTime = Math.max(0, Math.min(seconds, audio.duration));
    }

    function seekBy(deltaSeconds) {
      seek(audio.currentTime + deltaSeconds);
    }

    function setVolume(value) {
      const v = clamp01(value);
      audio.volume = v;
      if (v > 0 && audio.muted) audio.muted = false;
      Storage.setPreferences({ volume: v, muted: audio.muted });
      emit("VOLUME_CHANGED", { volume: v, muted: audio.muted });
    }

    function toggleMute() {
      audio.muted = !audio.muted;
      Storage.setPreferences({ muted: audio.muted });
      emit("VOLUME_CHANGED", { volume: audio.volume, muted: audio.muted });
    }

    function setShuffle(value) {
      shuffle = !!value;
      Storage.setPreferences({ shuffle });
      emit("SHUFFLE_CHANGED", { shuffle });
      preloadNextTrack();
    }
    function toggleShuffle() {
      setShuffle(!shuffle);
    }

    function setRepeat(mode) {
      if (["off", "all", "one"].indexOf(mode) === -1) return;
      repeat = mode;
      Storage.setPreferences({ repeat });
      emit("REPEAT_CHANGED", { repeat });
    }
    function cycleRepeat() {
      setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off");
    }

    function addToQueue(trackId) {
      Queue.addToQueue(trackId);
      preloadNextTrack();
    }
    function playNext(trackId) {
      Queue.playNext(trackId);
      preloadNextTrack();
    }
    function removeFromQueue(index) {
      Queue.removeFromQueue(index);
    }
    function clearQueue() {
      Queue.clear();
    }

    /* ---------------- Native audio events ---------------- */

    audio.addEventListener("loadedmetadata", () => {
      if (!audio.duration || !isFinite(audio.duration) || audio.duration === 0) {
        console.warn("[player] zero/invalid duration metadata for", currentTrackId);
      }
      setState(audio.paused ? STATES.READY : STATES.PLAYING);
      emit("TRACK_LOADED", { track: currentTrack(), duration: audio.duration });
    });

    audio.addEventListener("play", () => {
      setState(STATES.PLAYING);
      emit("TRACK_PLAYING", { track: currentTrack() });
    });

    audio.addEventListener("pause", () => {
      if (state !== STATES.ENDED && state !== STATES.ERROR) setState(STATES.PAUSED);
      emit("TRACK_PAUSED", { track: currentTrack() });
    });

    audio.addEventListener("waiting", () => setState(STATES.BUFFERING));
    audio.addEventListener("canplay", () => {
      if (state === STATES.BUFFERING || state === STATES.LOADING) {
        setState(audio.paused ? STATES.READY : STATES.PLAYING);
      }
    });

    audio.addEventListener("timeupdate", () => {
      if (state === STATES.SEEKING) setState(audio.paused ? STATES.PAUSED : STATES.PLAYING);
      const t = Math.floor(audio.currentTime);
      if (t !== lastSecondMark) {
        lastSecondMark = t;
        Storage.recordSecondsListened(1);
      }
      const track = currentTrack();
      if (
        track &&
        completedCreditedForTrack !== currentTrackId &&
        audio.duration &&
        audio.currentTime / audio.duration > 0.9
      ) {
        completedCreditedForTrack = currentTrackId;
        Storage.recordCompleted();
      }
      emit("TIME_UPDATED", {
        currentTime: audio.currentTime,
        duration: audio.duration,
      });
    });

    audio.addEventListener("volumechange", () => {
      emit("VOLUME_CHANGED", { volume: audio.volume, muted: audio.muted });
    });

    audio.addEventListener("ended", () => {
      const track = currentTrack();
      if (track) Storage.recordPlay(track);
      emit("TRACK_ENDED", { track });
      next(false);
    });

    audio.addEventListener("error", () => {
      handleError(audio.error);
    });

    function handleError(mediaError) {
      const code = mediaError && mediaError.code;
      lastErrorMessage = (code && ERROR_MESSAGES[code]) || ERROR_MESSAGES.default;
      setState(STATES.ERROR);
      emit("TRACK_ERROR", { trackId: currentTrackId, message: lastErrorMessage, code });
    }

    /* ---------------- Media Session API ---------------- */

    function updateMediaSessionMetadata(track) {
      if (!("mediaSession" in navigator) || !track) return;
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: track.title,
          artist: track.artist,
          album: track.album || "",
          artwork: [
            { src: track.artwork, sizes: "512x512", type: "image/svg+xml" },
          ],
        });
      } catch (err) {
        console.warn("[player] media session metadata failed", err);
      }
    }

    function setupMediaSessionHandlers() {
      if (!("mediaSession" in navigator)) return;
      const ms = navigator.mediaSession;
      try {
        ms.setActionHandler("play", () => play());
        ms.setActionHandler("pause", () => pause());
        ms.setActionHandler("previoustrack", () => previous());
        ms.setActionHandler("nexttrack", () => next(true));
        ms.setActionHandler("seekbackward", (d) => seekBy(-(d.seekOffset || 10)));
        ms.setActionHandler("seekforward", (d) => seekBy(d.seekOffset || 10));
        ms.setActionHandler("seekto", (d) => {
          if (d.fastSeek && "fastSeek" in audio) audio.fastSeek(d.seekTime);
          else seek(d.seekTime);
        });
      } catch (err) {
        console.warn("[player] media session action handlers unsupported", err);
      }
    }
    setupMediaSessionHandlers();

    audio.addEventListener("play", () => {
      if ("mediaSession" in navigator) navigator.mediaSession.playbackState = "playing";
    });
    audio.addEventListener("pause", () => {
      if ("mediaSession" in navigator) navigator.mediaSession.playbackState = "paused";
    });

    /* ---------------- Public getters ---------------- */

    function getState() {
      return state;
    }
    function getLastError() {
      return lastErrorMessage;
    }
    function isPlaying() {
      return state === STATES.PLAYING;
    }
    function getShuffle() {
      return shuffle;
    }
    function getRepeat() {
      return repeat;
    }
    function getVolume() {
      return audio.volume;
    }
    function getMuted() {
      return audio.muted;
    }
    function getCurrentTime() {
      return audio.currentTime;
    }
    function getDuration() {
      return audio.duration;
    }
    function getAudioElement() {
      return audio;
    }

    return {
      STATES,
      events: target,
      audio,
      getAudioElement,
      play,
      cue,
      pause,
      toggle,
      next,
      previous,
      seek,
      seekBy,
      setVolume,
      toggleMute,
      toggleShuffle,
      setShuffle,
      setRepeat,
      cycleRepeat,
      addToQueue,
      playNext,
      removeFromQueue,
      clearQueue,
      playAlbum,
      playPlaylist,
      playTrackList,
      currentTrack,
      getState,
      getLastError,
      isPlaying,
      getShuffle,
      getRepeat,
      getVolume,
      getMuted,
      getCurrentTime,
      getDuration,
    };
  }

  global.Player = createPlayer();
})(window);
