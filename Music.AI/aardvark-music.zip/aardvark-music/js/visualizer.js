/* AARDVARK MUSIC — visualizer.js
   Web Audio API analyser driving a canvas. Modes: bars, waveform,
   circular, spectrum, minimal. Degrades gracefully if Web Audio or
   an AudioContext connection is unavailable. */
(function (global) {
  "use strict";

  function createVisualizer() {
    let ctx = null;
    let analyser = null;
    let sourceNode = null;
    let canvas = null;
    let canvasCtx = null;
    let rafId = null;
    let mode = "bars";
    let connected = false;
    let reduceMotion = global.matchMedia && global.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const freqData = { array: null };
    const timeData = { array: null };

    function init(audioEl, canvasEl) {
      canvas = canvasEl;
      canvasCtx = canvas.getContext("2d");
      try {
        const AudioContextCtor = global.AudioContext || global.webkitAudioContext;
        if (!AudioContextCtor) throw new Error("Web Audio API unavailable");
        ctx = new AudioContextCtor();
        sourceNode = ctx.createMediaElementSource(audioEl);
        analyser = ctx.createAnalyser();
        analyser.fftSize = 1024;
        analyser.smoothingTimeConstant = 0.8;
        sourceNode.connect(analyser);
        analyser.connect(ctx.destination);
        freqData.array = new Uint8Array(analyser.frequencyBinCount);
        timeData.array = new Uint8Array(analyser.fftSize);
        connected = true;
      } catch (err) {
        console.warn("[visualizer] falling back to idle visuals:", err.message);
        connected = false;
      }
    }

    function resume() {
      if (ctx && ctx.state === "suspended") ctx.resume().catch(() => {});
    }

    function setMode(next) {
      mode = next;
    }
    function getMode() {
      return mode;
    }

    function resizeCanvasForDPR() {
      const rect = canvas.getBoundingClientRect();
      const dpr = global.devicePixelRatio || 1;
      const w = Math.max(1, Math.round(rect.width * dpr));
      const h = Math.max(1, Math.round(rect.height * dpr));
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
    }

    function clear() {
      canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
    }

    function drawBars() {
      const n = 48;
      const step = Math.floor(freqData.array.length / n);
      const w = canvas.width / n;
      for (let i = 0; i < n; i++) {
        const v = freqData.array[i * step] / 255;
        const h = v * canvas.height * 0.85;
        const x = i * w;
        const y = canvas.height - h;
        canvasCtx.fillStyle = "rgba(242,237,230," + (0.15 + v * 0.55) + ")";
        canvasCtx.fillRect(x + w * 0.2, y, w * 0.6, h);
      }
    }

    function drawWaveform() {
      canvasCtx.lineWidth = Math.max(1, canvas.width / 400);
      canvasCtx.strokeStyle = "rgba(91,124,153,0.8)";
      canvasCtx.beginPath();
      const slice = canvas.width / timeData.array.length;
      let x = 0;
      for (let i = 0; i < timeData.array.length; i++) {
        const v = timeData.array[i] / 128 - 1;
        const y = canvas.height / 2 + v * canvas.height * 0.4;
        if (i === 0) canvasCtx.moveTo(x, y);
        else canvasCtx.lineTo(x, y);
        x += slice;
      }
      canvasCtx.stroke();
    }

    function drawCircular() {
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const baseR = Math.min(cx, cy) * 0.9;
      const n = 64;
      const step = Math.floor(freqData.array.length / n);
      canvasCtx.strokeStyle = "rgba(242,237,230,0.65)";
      canvasCtx.lineWidth = Math.max(1, canvas.width / 300);
      for (let i = 0; i < n; i++) {
        const v = freqData.array[i * step] / 255;
        const angle = (i / n) * Math.PI * 2;
        const r1 = baseR;
        const r2 = baseR + v * baseR * 0.25;
        const x1 = cx + Math.cos(angle) * r1;
        const y1 = cy + Math.sin(angle) * r1;
        const x2 = cx + Math.cos(angle) * r2;
        const y2 = cy + Math.sin(angle) * r2;
        canvasCtx.beginPath();
        canvasCtx.moveTo(x1, y1);
        canvasCtx.lineTo(x2, y2);
        canvasCtx.stroke();
      }
    }

    function drawSpectrum() {
      const n = freqData.array.length;
      const w = canvas.width / n;
      const grad = canvasCtx.createLinearGradient(0, canvas.height, 0, 0);
      grad.addColorStop(0, "rgba(91,124,153,0.85)");
      grad.addColorStop(1, "rgba(163,69,63,0.65)");
      canvasCtx.fillStyle = grad;
      for (let i = 0; i < n; i++) {
        const v = freqData.array[i] / 255;
        const h = v * canvas.height;
        canvasCtx.fillRect(i * w, canvas.height - h, Math.max(1, w), h);
      }
    }

    function drawMinimal() {
      let sum = 0;
      for (let i = 0; i < freqData.array.length; i++) sum += freqData.array[i];
      const avg = sum / freqData.array.length / 255;
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const r = Math.min(cx, cy) * (0.55 + avg * 0.35);
      canvasCtx.strokeStyle = "rgba(242,237,230," + (0.25 + avg * 0.4) + ")";
      canvasCtx.lineWidth = Math.max(1, canvas.width / 260);
      canvasCtx.beginPath();
      canvasCtx.arc(cx, cy, r, 0, Math.PI * 2);
      canvasCtx.stroke();
    }

    function idleFrame(isPlaying) {
      clear();
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const t = Date.now() / 1000;
      const pulse = isPlaying ? 0.5 + Math.sin(t * 1.4) * 0.5 : 0.25;
      canvasCtx.strokeStyle = "rgba(242,237,230," + (0.15 + pulse * 0.2) + ")";
      canvasCtx.lineWidth = Math.max(1, canvas.width / 260);
      canvasCtx.beginPath();
      canvasCtx.arc(cx, cy, Math.min(cx, cy) * (0.6 + pulse * 0.08), 0, Math.PI * 2);
      canvasCtx.stroke();
    }

    function frame(isPlaying) {
      if (!canvas) return;
      resizeCanvasForDPR();
      if (!connected || !analyser) {
        idleFrame(isPlaying);
        rafId = requestAnimationFrame(() => frame(isPlaying()));
        return;
      }
      analyser.getByteFrequencyData(freqData.array);
      analyser.getByteTimeDomainData(timeData.array);
      clear();
      if (reduceMotion) {
        drawMinimal();
      } else {
        switch (mode) {
          case "waveform":
            drawWaveform();
            break;
          case "circular":
            drawCircular();
            break;
          case "spectrum":
            drawSpectrum();
            break;
          case "minimal":
            drawMinimal();
            break;
          default:
            drawBars();
        }
      }
      rafId = requestAnimationFrame(() => frame(isPlayingRef()));
    }

    let isPlayingRef = () => false;

    function start(isPlayingFn) {
      isPlayingRef = isPlayingFn || (() => false);
      resume();
      if (rafId) cancelAnimationFrame(rafId);
      frame(isPlayingRef());
    }

    function stop() {
      if (rafId) cancelAnimationFrame(rafId);
      rafId = null;
      if (canvasCtx && canvas) clear();
    }

    function isConnected() {
      return connected;
    }

    return { init, start, stop, setMode, getMode, resume, isConnected };
  }

  global.Visualizer = createVisualizer();
})(window);
