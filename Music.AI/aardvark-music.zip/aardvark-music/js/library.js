/* AARDVARK MUSIC — library.js
   Loads data/library.json, validates records, derives albums/artists/
   genres, and provides search. */
(function (global) {
  "use strict";

  const DEFAULT_ARTWORK = "assets/artwork/default.svg";

  let tracks = [];
  let albums = [];
  let artists = [];
  let genres = [];
  let seedPlaylists = [];
  let tracksById = new Map();
  let albumsById = new Map();
  let artistsById = new Map();
  const invalidRecords = [];

  function isNonEmptyString(v) {
    return typeof v === "string" && v.trim().length > 0;
  }

  function validateTrack(raw, index) {
    const problems = [];
    if (!isNonEmptyString(raw.id)) problems.push("missing id");
    if (!isNonEmptyString(raw.title)) problems.push("missing title");
    if (!isNonEmptyString(raw.source)) problems.push("missing source");
    if (!isNonEmptyString(raw.artist)) problems.push("missing artist");
    if (typeof raw.duration !== "number" || !isFinite(raw.duration) || raw.duration <= 0) {
      problems.push("invalid duration");
    }
    if (problems.length) {
      invalidRecords.push({ index, id: raw.id || null, problems });
      return null;
    }
    return Object.assign(
      {
        album: "",
        albumId: null,
        albumArtist: raw.artist,
        genre: "Unknown",
        year: null,
        trackNumber: null,
        discNumber: 1,
        artwork: DEFAULT_ARTWORK,
        description: "",
        lyrics: null,
        composer: null,
        credits: null,
      },
      raw,
      {
        artwork: isNonEmptyString(raw.artwork) ? raw.artwork : DEFAULT_ARTWORK,
      }
    );
  }

  async function load(jsonPath) {
    jsonPath = jsonPath || "data/library.json";
    let data;
    try {
      const res = await fetch(jsonPath, { cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      data = await res.json();
    } catch (err) {
      console.error("[library] failed to load", jsonPath, err);
      data = { tracks: [], albums: [], artists: [], playlists: [] };
    }

    tracks = (data.tracks || [])
      .map((raw, i) => validateTrack(raw, i))
      .filter(Boolean);
    albums = data.albums || [];
    artists = data.artists || [];
    seedPlaylists = data.playlists || [];

    tracksById = new Map(tracks.map((t) => [t.id, t]));
    albumsById = new Map(albums.map((a) => [a.id, a]));
    artistsById = new Map(artists.map((a) => [a.id, a]));

    const genreSet = new Set();
    tracks.forEach((t) => genreSet.add(t.genre));
    genres = Array.from(genreSet).sort();

    if (invalidRecords.length) {
      console.warn("[library] skipped invalid track records:", invalidRecords);
    }

    return { trackCount: tracks.length, invalidCount: invalidRecords.length };
  }

  function getAllTracks() {
    return tracks.slice();
  }
  function getTrack(id) {
    return tracksById.get(id) || null;
  }
  function getAlbums() {
    return albums.slice();
  }
  function getAlbum(id) {
    return albumsById.get(id) || null;
  }
  function getArtists() {
    return artists.slice();
  }
  function getArtist(id) {
    return artistsById.get(id) || null;
  }
  function getGenres() {
    return genres.slice();
  }
  function getSeedPlaylists() {
    return seedPlaylists;
  }
  function getInvalidRecords() {
    return invalidRecords.slice();
  }

  function tracksForAlbum(albumId) {
    return tracks
      .filter((t) => t.albumId === albumId)
      .sort((a, b) => (a.trackNumber || 0) - (b.trackNumber || 0));
  }
  function tracksForArtist(artistId) {
    return tracks.filter((t) => t.artistId === artistId);
  }
  function albumsForArtist(artistId) {
    return albums.filter((a) => a.artistId === artistId);
  }
  function tracksForGenre(genre) {
    return tracks.filter((t) => t.genre === genre);
  }
  function relatedArtists(artistId, limit) {
    const artist = getArtist(artistId);
    if (!artist) return [];
    const shared = artists.filter(
      (a) => a.id !== artistId && a.genres.some((g) => artist.genres.includes(g))
    );
    return shared.slice(0, limit || 6);
  }

  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function matches(haystack, needle) {
    return haystack && haystack.toLowerCase().indexOf(needle) !== -1;
  }

  function search(query) {
    const q = (query || "").trim().toLowerCase();
    if (!q) return { query: "", tracks: [], artists: [], albums: [] };

    const matchedTracks = tracks.filter(
      (t) =>
        matches(t.title, q) ||
        matches(t.artist, q) ||
        matches(t.album, q) ||
        matches(t.genre, q) ||
        (t.year != null && String(t.year).indexOf(q) !== -1)
    );
    const matchedArtists = artists.filter((a) => matches(a.name, q));
    const matchedAlbums = albums.filter(
      (a) => matches(a.title, q) || matches(a.genre, q)
    );

    return {
      query,
      tracks: matchedTracks,
      artists: matchedArtists,
      albums: matchedAlbums,
    };
  }

  function highlight(text, query) {
    if (!query) return document.createTextNode(text == null ? "" : text);
    const frag = document.createDocumentFragment();
    const str = text == null ? "" : String(text);
    const re = new RegExp("(" + escapeRegExp(query) + ")", "ig");
    const parts = str.split(re);
    parts.forEach((part) => {
      if (part.toLowerCase() === query.toLowerCase()) {
        const mark = document.createElement("mark");
        mark.textContent = part;
        frag.appendChild(mark);
      } else if (part) {
        frag.appendChild(document.createTextNode(part));
      }
    });
    return frag;
  }

  function formatDuration(totalSeconds) {
    if (totalSeconds == null || !isFinite(totalSeconds) || totalSeconds < 0) return "--:--";
    const m = Math.floor(totalSeconds / 60);
    const s = Math.floor(totalSeconds % 60);
    return m + ":" + String(s).padStart(2, "0");
  }

  global.MusicLibrary = {
    DEFAULT_ARTWORK,
    load,
    getAllTracks,
    getTrack,
    getAlbums,
    getAlbum,
    getArtists,
    getArtist,
    getGenres,
    getSeedPlaylists,
    getInvalidRecords,
    tracksForAlbum,
    tracksForArtist,
    albumsForArtist,
    tracksForGenre,
    relatedArtists,
    search,
    highlight,
    formatDuration,
  };
})(window);
