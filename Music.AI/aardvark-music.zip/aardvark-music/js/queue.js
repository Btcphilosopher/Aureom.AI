/* AARDVARK MUSIC — queue.js
   Playback queue: current track, upcoming tracks, reordering.
   Persisted to localStorage so it survives reloads/navigation. */
(function (global) {
  "use strict";

  const EventTarget_ = global.EventTarget;

  function createQueue() {
    const target = new EventTarget_();
    let items = []; // array of track ids
    let index = -1; // pointer into items
    let shuffleHistory = [];

    function persist() {
      Storage.saveQueueState({ items, index });
    }

    function restore() {
      const saved = Storage.getQueueState();
      if (saved && Array.isArray(saved.items)) {
        items = saved.items.filter((id) => MusicLibrary.getTrack(id));
        index = typeof saved.index === "number" ? saved.index : -1;
        if (index >= items.length) index = items.length - 1;
      }
      emit();
    }

    function emit() {
      target.dispatchEvent(new CustomEvent("QUEUE_CHANGED", { detail: snapshot() }));
      persist();
    }

    function snapshot() {
      return {
        items: items.slice(),
        index,
        current: index >= 0 ? items[index] : null,
        upcoming: index >= 0 ? items.slice(index + 1) : items.slice(),
      };
    }

    function setQueue(trackIds, startIndex) {
      items = trackIds.slice();
      index = startIndex != null ? startIndex : items.length ? 0 : -1;
      emit();
    }

    function addToQueue(trackId) {
      items.push(trackId);
      if (index === -1) index = 0;
      emit();
    }

    function playNext(trackId) {
      const insertAt = index === -1 ? 0 : index + 1;
      items.splice(insertAt, 0, trackId);
      if (index === -1) index = 0;
      emit();
    }

    function playNow(trackId) {
      const insertAt = index === -1 ? 0 : index + 1;
      items.splice(insertAt, 0, trackId);
      index = insertAt;
      emit();
    }

    function removeFromQueue(i) {
      if (i < 0 || i >= items.length) return;
      items.splice(i, 1);
      if (i < index) index -= 1;
      else if (i === index) index = Math.min(index, items.length - 1);
      emit();
    }

    function clear() {
      const currentId = index >= 0 ? items[index] : null;
      items = currentId ? [currentId] : [];
      index = currentId ? 0 : -1;
      emit();
    }

    function reorder(fromIndex, toIndex) {
      if (fromIndex === toIndex) return;
      const [moved] = items.splice(fromIndex, 1);
      items.splice(toIndex, 0, moved);
      if (fromIndex === index) index = toIndex;
      else {
        if (fromIndex < index && toIndex >= index) index -= 1;
        else if (fromIndex > index && toIndex <= index) index += 1;
      }
      emit();
    }

    function getCurrent() {
      return index >= 0 ? items[index] : null;
    }

    function getUpcoming() {
      return index >= 0 ? items.slice(index + 1) : [];
    }

    function peekNext(shuffle) {
      if (!items.length) return null;
      if (shuffle) {
        const pool = items.filter((_, i) => i !== index);
        if (!pool.length) return items[index] || null;
        return pool[Math.floor(Math.random() * pool.length)];
      }
      if (index + 1 < items.length) return items[index + 1];
      return null;
    }

    function advance(shuffle) {
      if (!items.length) return null;
      if (shuffle) {
        const pool = items
          .map((id, i) => i)
          .filter((i) => i !== index);
        if (!pool.length) return getCurrent();
        index = pool[Math.floor(Math.random() * pool.length)];
      } else if (index + 1 < items.length) {
        index += 1;
      } else {
        return null; // end of queue
      }
      emit();
      return getCurrent();
    }

    function retreat() {
      if (index > 0) {
        index -= 1;
        emit();
        return getCurrent();
      }
      return null;
    }

    function wrapToStart() {
      index = items.length ? 0 : -1;
      emit();
      return getCurrent();
    }

    function has(trackId) {
      return items.indexOf(trackId) !== -1;
    }

    return {
      events: target,
      restore,
      setQueue,
      addToQueue,
      playNext,
      playNow,
      removeFromQueue,
      clear,
      reorder,
      getCurrent,
      getUpcoming,
      peekNext,
      advance,
      retreat,
      wrapToStart,
      has,
      snapshot,
    };
  }

  global.Queue = createQueue();
})(window);
