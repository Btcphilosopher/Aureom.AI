/* AARDVARK MUSIC — playlists.js
   Playlist CRUD on top of Storage, with change events for the UI. */
(function (global) {
  "use strict";

  const target = new EventTarget();

  function init() {
    Storage.seedPlaylistsIfEmpty(MusicLibrary.getSeedPlaylists());
  }

  function emit() {
    target.dispatchEvent(new CustomEvent("PLAYLIST_CHANGED", { detail: getAll() }));
  }

  function getAll() {
    return Storage.getPlaylists();
  }
  function getById(id) {
    return getAll().find((p) => p.id === id) || null;
  }
  function tracksOf(playlist) {
    return playlist.tracks.map((id) => MusicLibrary.getTrack(id)).filter(Boolean);
  }
  function create(name, description) {
    const p = Storage.createPlaylist(name, description);
    emit();
    return p;
  }
  function rename(id, name, description) {
    const p = Storage.renamePlaylist(id, name, description);
    emit();
    return p;
  }
  function remove(id) {
    Storage.deletePlaylist(id);
    emit();
  }
  function addTrack(id, trackId) {
    const ok = Storage.addTrackToPlaylist(id, trackId);
    emit();
    return ok;
  }
  function removeTrack(id, trackId) {
    const ok = Storage.removeTrackFromPlaylist(id, trackId);
    emit();
    return ok;
  }
  function reorderTracks(id, fromIndex, toIndex) {
    const ok = Storage.reorderPlaylistTracks(id, fromIndex, toIndex);
    emit();
    return ok;
  }

  global.Playlists = {
    events: target,
    init,
    getAll,
    getById,
    tracksOf,
    create,
    rename,
    remove,
    addTrack,
    removeTrack,
    reorderTracks,
  };
})(window);
