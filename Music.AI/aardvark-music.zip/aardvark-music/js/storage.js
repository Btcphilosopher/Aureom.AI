/* AARDVARK MUSIC — storage.js
   All localStorage access: preferences, likes, playlists, history, stats. */
(function (global) {
  "use strict";

  const KEYS = {
    PREFS: "aardvark.prefs.v1",
    LIKED: "aardvark.liked.v1",
    PLAYLISTS: "aardvark.playlists.v1",
    RECENT: "aardvark.recent.v1",
    STATS: "aardvark.stats.v1",
    SEEDED: "aardvark.seeded.v1",
    QUEUE: "aardvark.queue.v1",
  };

  const RECENT_LIMIT = 50;

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      if (raw == null) return fallback;
      const parsed = JSON.parse(raw);
      return parsed == null ? fallback : parsed;
    } catch (err) {
      console.warn("[storage] failed to read", key, err);
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.warn("[storage] failed to write", key, err);
      return false;
    }
  }

  const DEFAULT_PREFS = {
    volume: 0.8,
    muted: false,
    shuffle: false,
    repeat: "off", // off | all | one
    visualizerMode: "bars",
    reducedMotionOverride: null,
  };

  function getPreferences() {
    return Object.assign({}, DEFAULT_PREFS, readJSON(KEYS.PREFS, {}));
  }
  function setPreferences(patch) {
    const next = Object.assign({}, getPreferences(), patch);
    writeJSON(KEYS.PREFS, next);
    return next;
  }

  function getLikedTracks() {
    return readJSON(KEYS.LIKED, []);
  }
  function isLiked(trackId) {
    return getLikedTracks().indexOf(trackId) !== -1;
  }
  function toggleLike(trackId) {
    const liked = getLikedTracks();
    const idx = liked.indexOf(trackId);
    if (idx === -1) liked.unshift(trackId);
    else liked.splice(idx, 1);
    writeJSON(KEYS.LIKED, liked);
    return liked.indexOf(trackId) !== -1;
  }

  function getPlaylists() {
    return readJSON(KEYS.PLAYLISTS, []);
  }
  function savePlaylists(playlists) {
    writeJSON(KEYS.PLAYLISTS, playlists);
  }
  function seedPlaylistsIfEmpty(seedPlaylists) {
    const already = readJSON(KEYS.SEEDED, false);
    if (!already) {
      savePlaylists(seedPlaylists.map((p) => Object.assign({}, p, { tracks: p.tracks.slice() })));
      writeJSON(KEYS.SEEDED, true);
    }
  }
  function createPlaylist(name, description) {
    const playlists = getPlaylists();
    const playlist = {
      id: "playlist_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      name: (name || "New Playlist").trim() || "New Playlist",
      description: description || "",
      artwork: "assets/artwork/default.svg",
      tracks: [],
      createdAt: Date.now(),
    };
    playlists.unshift(playlist);
    savePlaylists(playlists);
    return playlist;
  }
  function renamePlaylist(id, name, description) {
    const playlists = getPlaylists();
    const p = playlists.find((pl) => pl.id === id);
    if (!p) return null;
    if (name != null) p.name = name.trim() || p.name;
    if (description != null) p.description = description;
    savePlaylists(playlists);
    return p;
  }
  function deletePlaylist(id) {
    savePlaylists(getPlaylists().filter((pl) => pl.id !== id));
  }
  function addTrackToPlaylist(id, trackId) {
    const playlists = getPlaylists();
    const p = playlists.find((pl) => pl.id === id);
    if (!p) return false;
    if (p.tracks.indexOf(trackId) !== -1) return false;
    p.tracks.push(trackId);
    savePlaylists(playlists);
    return true;
  }
  function removeTrackFromPlaylist(id, trackId) {
    const playlists = getPlaylists();
    const p = playlists.find((pl) => pl.id === id);
    if (!p) return false;
    p.tracks = p.tracks.filter((t) => t !== trackId);
    savePlaylists(playlists);
    return true;
  }
  function reorderPlaylistTracks(id, fromIndex, toIndex) {
    const playlists = getPlaylists();
    const p = playlists.find((pl) => pl.id === id);
    if (!p) return false;
    const [moved] = p.tracks.splice(fromIndex, 1);
    p.tracks.splice(toIndex, 0, moved);
    savePlaylists(playlists);
    return true;
  }

  function getRecentlyPlayed() {
    return readJSON(KEYS.RECENT, []);
  }
  function addRecentlyPlayed(trackId) {
    let recent = getRecentlyPlayed();
    recent = recent.filter((r) => r.trackId !== trackId);
    recent.unshift({ trackId, timestamp: Date.now() });
    if (recent.length > RECENT_LIMIT) recent = recent.slice(0, RECENT_LIMIT);
    writeJSON(KEYS.RECENT, recent);
  }
  function clearRecentlyPlayed() {
    writeJSON(KEYS.RECENT, []);
  }

  const DEFAULT_STATS = {
    plays: 0,
    secondsListened: 0,
    tracksCompleted: 0,
    artistPlays: {},
    genrePlays: {},
  };
  function getStats() {
    return Object.assign({}, DEFAULT_STATS, readJSON(KEYS.STATS, {}));
  }
  function recordPlay(track) {
    const stats = getStats();
    stats.plays += 1;
    if (track) {
      stats.artistPlays[track.artist] = (stats.artistPlays[track.artist] || 0) + 1;
      stats.genrePlays[track.genre] = (stats.genrePlays[track.genre] || 0) + 1;
    }
    writeJSON(KEYS.STATS, stats);
    return stats;
  }
  function recordSecondsListened(seconds) {
    const stats = getStats();
    stats.secondsListened += Math.max(0, seconds || 0);
    writeJSON(KEYS.STATS, stats);
  }
  function recordCompleted() {
    const stats = getStats();
    stats.tracksCompleted += 1;
    writeJSON(KEYS.STATS, stats);
  }

  function getQueueState() {
    return readJSON(KEYS.QUEUE, null);
  }
  function saveQueueState(state) {
    writeJSON(KEYS.QUEUE, state);
  }

  global.Storage = {
    KEYS,
    getPreferences,
    setPreferences,
    getLikedTracks,
    isLiked,
    toggleLike,
    getPlaylists,
    savePlaylists,
    seedPlaylistsIfEmpty,
    createPlaylist,
    renamePlaylist,
    deletePlaylist,
    addTrackToPlaylist,
    removeTrackFromPlaylist,
    reorderPlaylistTracks,
    getRecentlyPlayed,
    addRecentlyPlayed,
    clearRecentlyPlayed,
    getStats,
    recordPlay,
    recordSecondsListened,
    recordCompleted,
    getQueueState,
    saveQueueState,
  };
})(window);
