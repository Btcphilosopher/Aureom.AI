# AARDVARK MUSIC

A premium, browser-native music streaming and playback environment — built
with plain HTML, CSS and vanilla JavaScript around the HTML5 Audio API.
No backend, no framework, no build step.

## Running it locally

Opening `index.html` directly (double-click, `file://…`) works for browsing
the interface, but **two things need a local web server** to function
correctly in most browsers:

1. `fetch("data/library.json")` — some browsers block `fetch()` against
   `file://` URLs entirely.
2. Dynamic background colour extraction (reading pixels off the album
   artwork) — canvas pixel reads are blocked ("tainted canvas") under the
   `file://` origin. The app detects this and falls back to a fixed accent
   colour per album, so nothing breaks — you just get the real effect only
   over HTTP.

So, from this folder, run any static file server, for example:

```bash
python3 -m http.server 8080
# then open http://localhost:8080
```

or `npx serve .`, or any equivalent. No server-side code runs — this is
still a fully static, local-first site.

## Adding your own music

Drop MP3 files into `/music/` using the filenames already referenced in
`data/library.json` (`track-01.mp3` … `track-20.mp3`), or edit
`data/library.json` to point `source` at whatever files you add. Every
track needs a stable `id`, `title`, `artist`, `source` and a positive
`duration` (in seconds) — records missing any of these are skipped with a
console warning rather than crashing the app (see `js/library.js`).

**This demo ships with no MP3 files.** That's intentional — the project
should not pretend to ship music it doesn't have the rights to distribute.
With `/music/` empty, the interface is fully browsable: you'll see the
library, artwork, albums, artists, playlists and queue all working, and
attempting to play a track surfaces a clear, graceful error
("The MP3 file could not be found...") instead of breaking silently.
Add your own licensed/owned/public-domain MP3s to hear real playback.

## Project structure

```
aardvark-music/
  index.html
  css/
    main.css          design tokens, layout, cards, views
    player.css         persistent player, queue drawer, now-playing
    responsive.css     tablet/mobile breakpoints, mini player
  js/
    storage.js          localStorage: prefs, likes, playlists, history, stats
    library.js          loads + validates library.json, search, derived data
    queue.js            playback queue (current/next/upcoming, reorder)
    playlists.js        playlist CRUD on top of storage.js
    player.js           <audio> engine, player state machine, Media Session
    visualizer.js        Web Audio API analyser + canvas (5 modes)
    app.js              app state, router, rendering, events, keyboard
  data/
    library.json        20 tracks / 5 albums / 8 artists / 6 genres / 3 playlists
  assets/
    artwork/             generated SVG artwork (no external/network assets)
  music/
    (empty — add your own .mp3 files here)
```

## What's implemented

- Full HTML5 audio engine (play/pause/seek/volume/rate), with explicit
  player states (`IDLE → LOADING → READY/PLAYING/PAUSED/BUFFERING →
  ENDED/ERROR`) and graceful handling of missing/corrupt/unsupported files.
- Home, Discover, Library, Albums, Artists, Playlists, Liked Music,
  Recently Played and Statistics views, plus Album/Artist/Playlist detail
  pages — all hash-routed (`#/album/:id`, etc.), no framework.
- Instant client-side search across title/artist/album/genre/year, with
  match highlighting.
- Real playback queue (now playing / up next), drag-to-reorder, survives
  reload via localStorage.
- Playlists: create/rename/delete/add/remove/reorder/play/shuffle,
  persisted in localStorage.
- Shuffle, repeat (off/all/one), Liked Music, Recently Played (capped
  history), local listening statistics — nothing leaves the browser.
- Persistent desktop player bar + mobile mini-player + bottom tab nav;
  slide-out queue drawer; full-screen Now Playing view with lyrics
  (where present in the data) and a Web Audio visualizer (bars, waveform,
  circular, spectrum, minimal modes), Media Session integration for
  OS/lock-screen controls, and `prefers-reduced-motion` support throughout.
- Keyboard shortcuts: Space, ←/→ seek, ↑/↓ volume, N/P next/previous,
  M mute, S shuffle — all suppressed while typing in search/forms.

## Notes on the demo library

The 20 tracks / 5 albums / 8 artists / 3 playlists in `data/library.json`
are entirely fictional (names, bios, descriptions) — no real music,
artwork, or metadata is referenced. Artwork is generated procedurally as
SVG (see `assets/artwork/`), so the project ships with zero external
network dependencies and zero copyrighted media.
