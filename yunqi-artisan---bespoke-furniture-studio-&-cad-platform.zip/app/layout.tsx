import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '云栖家具 YUNQI | 东方美学实木定制平台 & CAD Studio',
  description: '以匠心·造物·传承千年东方家居智慧。集参数化3D/2D榫卯图纸、板材排版下料、空间模拟及Rust高性能木作工程计算引擎于一体的定制平台。',
  openGraph: {
    title: '云栖家具 YUNQI | 东方美学实木定制平台 & CAD Studio',
    description: '以匠心·造物·传承千年东方家居智慧。集参数化3D/2D榫卯图纸、板材排版下料、空间模拟及Rust高性能木作工程计算引擎于一体的定制平台。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '云栖家具 YUNQI | 东方美学实木定制平台 & CAD Studio',
    description: '以匠心·造物·传承千年东方家居智慧。集参数化3D/2D榫卯图纸、板材排版下料、空间模拟及Rust高性能木作工程计算引擎于一体的定制平台。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
