"use client";

import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Collections from "@/components/Collections";
import Craftsmanship from "@/components/Craftsmanship";
import FurnitureStudio from "@/components/studio/FurnitureStudio";
import KotlinPhysicsHUD from "@/components/KotlinPhysicsHUD";
import Footer from "@/components/Footer";
import {
  KotlinSpringConfig,
  KOTLIN_SPRING_PRESETS,
} from "@/lib/kotlin-animations";

export default function HomePage() {
  const [activeSpring, setActiveSpring] = useState<KotlinSpringConfig>(
    KOTLIN_SPRING_PRESETS.lowBouncy
  );
  const [selectedStudioTemplate, setSelectedStudioTemplate] = useState<string>("tea_table_01");

  const scrollToStudio = () => {
    const el = document.getElementById("custom-studio");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToCollections = () => {
    const el = document.getElementById("collections");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSelectCollection = (templateId: string) => {
    setSelectedStudioTemplate(templateId);
    scrollToStudio();
  };

  return (
    <div className="min-h-screen bg-[#121110] text-neutral-100 selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Brand Navbar */}
      <Navbar
        activeSpring={activeSpring}
        onOpenStudio={scrollToStudio}
      />

      {/* Hero Section matching screenshot banner & aesthetic */}
      <Hero
        onExploreClick={scrollToCollections}
        onStudioClick={scrollToStudio}
      />

      {/* Curated Collections Gallery matching 4 cards in screenshot */}
      <Collections onSelectCollection={handleSelectCollection} />

      {/* Craftsmanship & Mortise-and-Tenon Section matching bottom of screenshot */}
      <Craftsmanship />

      {/* Flatform Software for Mockup and Custom Designs for the Furniture Maker */}
      <FurnitureStudio
        key={selectedStudioTemplate}
        initialTemplateId={selectedStudioTemplate}
        activeSpring={activeSpring}
      />

      {/* Interactive Floating Kotlin Compose Animation Physics HUD */}
      <KotlinPhysicsHUD
        activeSpring={activeSpring}
        onUpdateSpring={setActiveSpring}
      />

      {/* Brand Footer */}
      <Footer />
    </div>
  );
}
