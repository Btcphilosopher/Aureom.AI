// Yunqi Artisan Bespoke Woodworking & Joinery Engineering Engine (Rust)
// Pure zero-dependency Rust implementation for high-speed parametric CAD,
// structural deflection analysis, 2D guillotine cut-list packing, and BOM estimation.

use std::env;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::thread;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone)]
struct FurnitureParams {
    id: String,
    name: String,
    length_mm: f64,
    width_mm: f64,
    height_mm: f64,
    top_thickness_mm: f64,
    leg_size_mm: f64,
    wood_type: String,   // walnut, teak, oak, rosewood, ash
    joint_type: String,  // dovetail, corner_mitre, bridle, shoulder
    finish_type: String, // beeswax, danish_oil, raw_matte, traditional_lacquer
    load_kg: f64,        // applied test load
}

impl Default for FurnitureParams {
    fn default() -> Self {
        Self {
            id: "tea_table_01".to_string(),
            name: "Zen Master Tea Table (明式茶台)".to_string(),
            length_mm: 1600.0,
            width_mm: 750.0,
            height_mm: 420.0,
            top_thickness_mm: 38.0,
            leg_size_mm: 68.0,
            wood_type: "walnut".to_string(),
            joint_type: "corner_mitre".to_string(),
            finish_type: "beeswax".to_string(),
            load_kg: 120.0,
        }
    }
}

// Wood mechanical properties database
struct WoodProps {
    name_cn: &'static str,
    name_en: &'static str,
    density_kg_m3: f64, // at 12% moisture content
    modulus_elasticity_mpa: f64, // MOE (E)
    bending_strength_mpa: f64,   // MOR
    shrinkage_radial_pct: f64,
    cost_per_board_foot_cny: f64,
    janka_hardness_n: f64,
}

fn get_wood_props(wood: &str) -> WoodProps {
    match wood.to_lowercase().as_str() {
        "walnut" | "black_walnut" => WoodProps {
            name_cn: "北美特级黑胡桃 (FAS Black Walnut)",
            name_en: "North American Black Walnut",
            density_kg_m3: 610.0,
            modulus_elasticity_mpa: 11500.0,
            bending_strength_mpa: 101.0,
            shrinkage_radial_pct: 5.5,
            cost_per_board_foot_cny: 48.0,
            janka_hardness_n: 4490.0,
        },
        "teak" | "burmese_teak" => WoodProps {
            name_cn: "缅甸金丝柚木 (Burmese Teak)",
            name_en: "Burmese Golden Teak",
            density_kg_m3: 650.0,
            modulus_elasticity_mpa: 12300.0,
            bending_strength_mpa: 98.0,
            shrinkage_radial_pct: 2.5,
            cost_per_board_foot_cny: 72.0,
            janka_hardness_n: 4740.0,
        },
        "oak" | "white_oak" => WoodProps {
            name_cn: "北美白橡木 (Quarter-Sawn White Oak)",
            name_en: "Quarter-Sawn White Oak",
            density_kg_m3: 750.0,
            modulus_elasticity_mpa: 12300.0,
            bending_strength_mpa: 105.0,
            shrinkage_radial_pct: 5.6,
            cost_per_board_foot_cny: 36.0,
            janka_hardness_n: 6050.0,
        },
        "rosewood" | "zitan" => WoodProps {
            name_cn: "小叶紫檀/大红酸枝 (Red Sandalwood)",
            name_en: "Red Sandalwood / Rosewood",
            density_kg_m3: 980.0,
            modulus_elasticity_mpa: 14800.0,
            bending_strength_mpa: 135.0,
            shrinkage_radial_pct: 3.2,
            cost_per_board_foot_cny: 160.0,
            janka_hardness_n: 8900.0,
        },
        "ash" | "white_ash" => WoodProps {
            name_cn: "俄罗斯特级白蜡木 (Russian White Ash)",
            name_en: "Russian White Ash",
            density_kg_m3: 680.0,
            modulus_elasticity_mpa: 12000.0,
            bending_strength_mpa: 103.0,
            shrinkage_radial_pct: 4.9,
            cost_per_board_foot_cny: 28.0,
            janka_hardness_n: 5870.0,
        },
        _ => WoodProps {
            name_cn: "北美特级黑胡桃 (FAS Black Walnut)",
            name_en: "North American Black Walnut",
            density_kg_m3: 610.0,
            modulus_elasticity_mpa: 11500.0,
            bending_strength_mpa: 101.0,
            shrinkage_radial_pct: 5.5,
            cost_per_board_foot_cny: 48.0,
            janka_hardness_n: 4490.0,
        },
    }
}

// Cut list part definition
#[derive(Debug, Clone)]
struct CutPart {
    part_id: String,
    name_cn: String,
    name_en: String,
    qty: usize,
    length_mm: f64,
    width_mm: f64,
    thickness_mm: f64,
    grain_dir: String,
    joinery_notes: String,
}

// 2D Nesting placed item
#[derive(Debug, Clone)]
struct PlacedPart {
    part_id: String,
    board_index: usize,
    x: f64,
    y: f64,
    width: f64,
    height: f64,
    rotated: bool,
}

fn calculate_furniture(params: &FurnitureParams) -> String {
    let start = Instant::now();
    let wood = get_wood_props(&params.wood_type);

    // Component Dimensions
    let top_len = params.length_mm;
    let top_wid = params.width_mm;
    let top_thk = params.top_thickness_mm;
    let leg_h = params.height_mm - top_thk;
    let leg_w = params.leg_size_mm;
    let apron_h = 75.0; // mm
    let apron_thk = 28.0; // mm
    let long_apron_l = (top_len - 2.0 * leg_w - 40.0).max(200.0);
    let short_apron_l = (top_wid - 2.0 * leg_w - 40.0).max(200.0);

    // Bill of Materials / Cut List
    let mut cut_list: Vec<CutPart> = Vec::new();
    // Tabletop is glued from multiple edge-glued FAS boards (standard ~180mm width each)
    let board_count = ((top_wid / 160.0).ceil() as usize).max(2);
    let board_width = top_wid / (board_count as f64);

    cut_list.push(CutPart {
        part_id: "P01_TOP_PLANKS".to_string(),
        name_cn: format!("桌面主板 (拼板 x{})", board_count),
        name_en: "Tabletop Planks (Edge-Glued)".to_string(),
        qty: board_count,
        length_mm: top_len + 30.0, // rough length with trim allowance
        width_mm: board_width + 10.0,
        thickness_mm: top_thk + 4.0, // rough thickness before planing
        grain_dir: "Longitudinal (纵向顺纹)".to_string(),
        joinery_notes: "穿带榫暗槽 (Sliding Dovetail Cleats), 饼干榫对拼".to_string(),
    });

    cut_list.push(CutPart {
        part_id: "P02_LEGS".to_string(),
        name_cn: "主桌腿 (四柱榫腿)".to_string(),
        name_en: "Main Column Legs".to_string(),
        qty: 4,
        length_mm: leg_h + 40.0, // include tenon allowance
        width_mm: leg_w,
        thickness_mm: leg_w,
        grain_dir: "Vertical (垂直顺纹)".to_string(),
        joinery_notes: match params.joint_type.as_str() {
            "corner_mitre" => "粽角榫三维交错榫卯 (3-Way Mitred M&T)".to_string(),
            "dovetail" => "暗燕尾大进小出榫 (Concealed Dovetail)".to_string(),
            "bridle" => "夹头榫双面开槽抱肩 (Bridle Lap Joint)".to_string(),
            _ => "抱肩榫霸王枨加固 (Waisted Shoulder Joint)".to_string(),
        },
    });

    cut_list.push(CutPart {
        part_id: "P03_LONG_APRONS".to_string(),
        name_cn: "纵向长牙条 (大边牙条)".to_string(),
        name_en: "Longitudinal Aprons".to_string(),
        qty: 2,
        length_mm: long_apron_l + 50.0, // includes double tenons
        width_mm: apron_h,
        thickness_mm: apron_thk,
        grain_dir: "Longitudinal (纵向)".to_string(),
        joinery_notes: "双头透榫/半透榫 (Double Stub Tenons)".to_string(),
    });

    cut_list.push(CutPart {
        part_id: "P04_SHORT_APRONS".to_string(),
        name_cn: "横向短牙条 (抹头牙板)".to_string(),
        name_en: "Transverse Short Aprons".to_string(),
        qty: 2,
        length_mm: short_apron_l + 50.0,
        width_mm: apron_h,
        thickness_mm: apron_thk,
        grain_dir: "Longitudinal (纵向)".to_string(),
        joinery_notes: "双头闷榫扣接 (Blind Stub Tenon)".to_string(),
    });

    // Sliding cross-grain breadboard cleats (穿带) to prevent cupping/warping
    let cleat_count = if top_len > 1400.0 { 3 } else { 2 };
    cut_list.push(CutPart {
        part_id: "P05_CLEATS".to_string(),
        name_cn: "防翘穿带 (底面伸缩扣榫)".to_string(),
        name_en: "Underside Anti-Warping Cleats".to_string(),
        qty: cleat_count,
        length_mm: top_wid - 80.0,
        width_mm: 55.0,
        thickness_mm: 32.0,
        grain_dir: "Cross-grain Expansion (梯形顺纹)".to_string(),
        joinery_notes: "燕尾穿带榫 (Sliding Tapered Dovetail)".to_string(),
    });

    // Corner braces / King supports (霸王枨)
    cut_list.push(CutPart {
        part_id: "P06_CORNER_BRACES".to_string(),
        name_cn: "霸王枨/角牙加固 (S形曲木撑)".to_string(),
        name_en: "Bawangcheng S-Curved Struts".to_string(),
        qty: 4,
        length_mm: 220.0,
        width_mm: 45.0,
        thickness_mm: 30.0,
        grain_dir: "Contour-aligned (顺纹曲线)".to_string(),
        joinery_notes: "钩挂榫加榫销 (Hook Tenon with Wooden Peg)".to_string(),
    });

    // Volume and Weight Calculations
    let mut total_finished_vol_m3 = 0.0;
    let mut total_rough_vol_m3 = 0.0;
    for p in &cut_list {
        let fin_vol = (p.length_mm / 1000.0) * (p.width_mm / 1000.0) * (p.thickness_mm / 1000.0) * (p.qty as f64);
        let rough_vol = fin_vol * 1.35; // 35% surfacing & squaring factor
        total_finished_vol_m3 += fin_vol;
        total_rough_vol_m3 += rough_vol;
    }

    // Board feet: 1 Board Foot = 144 cubic inches = 0.00235974 m3
    let board_feet = total_rough_vol_m3 / 0.00235974;
    let finished_weight_kg = total_finished_vol_m3 * wood.density_kg_m3;
    let packaged_weight_kg = finished_weight_kg * 1.15 + 4.5;

    // Structural Deflection (Euler-Bernoulli Beam Model)
    // Tabletop center deflection under distributed test load:
    // delta = 5 * q * L^4 / (384 * E * I)
    // Moment of inertia I = b * h^3 / 12 (mm4)
    let e_mpa = wood.modulus_elasticity_mpa; // N/mm2
    let b_mm = top_wid;
    let h_mm = top_thk;
    let i_mm4 = (b_mm * h_mm.powi(3)) / 12.0;
    let load_n = params.load_kg * 9.80665;
    let span_mm = top_len - 2.0 * leg_w;
    let q_n_per_mm = load_n / span_mm;
    let deflection_mm = (5.0 * q_n_per_mm * span_mm.powi(4)) / (384.0 * e_mpa * i_mm4);

    // Max Bending Stress sigma = M * y / I
    // M_max = q * L^2 / 8
    let m_max_n_mm = (q_n_per_mm * span_mm.powi(2)) / 8.0;
    let y_max_mm = h_mm / 2.0;
    let bending_stress_mpa = (m_max_n_mm * y_max_mm) / i_mm4;
    let safety_factor = wood.bending_strength_mpa / bending_stress_mpa.max(0.001);
    let max_safe_load_kg = (params.load_kg * (safety_factor / 2.5)).floor().max(50.0);

    // Mortise and Tenon Joint Metrics
    let mortise_count = 16 + (cleat_count * 2) + 8; // legs, aprons, cleats, braces
    let tenon_count = mortise_count;
    let joint_tolerance_mm = 0.15; // traditional Chinese hand-fit tolerance

    // 2D Nesting Calculation (arrange parts on FAS rough timber slabs)
    // Standard FAS rough timber board: 2440mm x 220mm x 45mm
    let slab_l = 2440.0;
    let slab_w = 220.0;
    let kerf = 3.5; // mm saw blade kerf

    let mut placed_parts: Vec<PlacedPart> = Vec::new();
    let mut current_board = 0;
    let mut current_x = 10.0;
    let mut current_y = 10.0;
    let mut line_height = 0.0;

    for part in &cut_list {
        for i in 0..part.qty {
            let pw = part.length_mm;
            let ph = part.width_mm;

            // Check if part fits on current board
            if current_x + pw + kerf > slab_l - 10.0 {
                // Move to next line on board
                current_x = 10.0;
                current_y += line_height + kerf;
                line_height = 0.0;
            }

            if current_y + ph + kerf > slab_w - 10.0 {
                // Move to next raw slab
                current_board += 1;
                current_x = 10.0;
                current_y = 10.0;
                line_height = 0.0;
            }

            placed_parts.push(PlacedPart {
                part_id: format!("{}_{}", part.part_id, i + 1),
                board_index: current_board,
                x: current_x,
                y: current_y,
                width: pw,
                height: ph,
                rotated: false,
            });

            current_x += pw + kerf;
            if ph > line_height {
                line_height = ph;
            }
        }
    }

    let total_slabs_used = current_board + 1;
    let total_slab_area_m2 = (total_slabs_used as f64) * (slab_l / 1000.0) * (slab_w / 1000.0);
    let mut parts_area_m2 = 0.0;
    for p in &cut_list {
        parts_area_m2 += (p.length_mm / 1000.0) * (p.width_mm / 1000.0) * (p.qty as f64);
    }
    let yield_efficiency_pct = ((parts_area_m2 / total_slab_area_m2.max(0.001)) * 100.0).clamp(65.0, 92.0);
    let waste_pct = 100.0 - yield_efficiency_pct;

    // Cost Breakdown (CNY)
    let raw_wood_cost = board_feet * wood.cost_per_board_foot_cny;
    let kiln_drying_cost = board_feet * 4.5;
    let craftsman_hours = 38.0 + (mortise_count as f64 * 0.45);
    let master_craft_labor = craftsman_hours * 85.0; // Master joiner rate
    let natural_oil_finish_cost = (top_len * top_wid * 2.0 / 1_000_000.0) * 120.0 + 80.0;
    let brass_hardware_cost = 180.0;
    let subtotal_cost = raw_wood_cost + kiln_drying_cost + master_craft_labor + natural_oil_finish_cost + brass_hardware_cost;
    let suggested_retail_cny = (subtotal_cost * 1.55).round();

    let elapsed = start.elapsed();
    let compute_time_us = elapsed.as_micros();

    // Construct valid JSON response
    let mut json = String::new();
    json.push_str("{\n");
    json.push_str("  \"engine\": \"Yunqi WoodEngine Rust v0.1.0\",\n");
    json.push_str("  \"runtime\": \"native-musl-x86_64\",\n");
    json.push_str(&format!("  \"compute_time_microseconds\": {},\n", compute_time_us));
    json.push_str(&format!("  \"compute_time_ms\": {:.3},\n", compute_time_us as f64 / 1000.0));
    json.push_str("  \"wood\": {\n");
    json.push_str(&format!("    \"name_cn\": \"{}\",\n", wood.name_cn));
    json.push_str(&format!("    \"name_en\": \"{}\",\n", wood.name_en));
    json.push_str(&format!("    \"density_kg_m3\": {},\n", wood.density_kg_m3));
    json.push_str(&format!("    \"modulus_elasticity_mpa\": {},\n", wood.modulus_elasticity_mpa));
    json.push_str(&format!("    \"bending_strength_mpa\": {},\n", wood.bending_strength_mpa));
    json.push_str(&format!("    \"janka_hardness_n\": {}\n", wood.janka_hardness_n));
    json.push_str("  },\n");

    json.push_str("  \"metrics\": {\n");
    json.push_str(&format!("    \"board_feet\": {:.2},\n", board_feet));
    json.push_str(&format!("    \"finished_volume_m3\": {:.4},\n", total_finished_vol_m3));
    json.push_str(&format!("    \"finished_weight_kg\": {:.2},\n", finished_weight_kg));
    json.push_str(&format!("    \"packaged_weight_kg\": {:.2},\n", packaged_weight_kg));
    json.push_str(&format!("    \"center_deflection_mm\": {:.3},\n", deflection_mm));
    json.push_str(&format!("    \"bending_stress_mpa\": {:.2},\n", bending_stress_mpa));
    json.push_str(&format!("    \"safety_factor\": {:.2},\n", safety_factor));
    json.push_str(&format!("    \"max_safe_load_kg\": {},\n", max_safe_load_kg));
    json.push_str(&format!("    \"mortise_tenon_count\": {},\n", mortise_count));
    json.push_str(&format!("    \"joint_tolerance_mm\": {},\n", joint_tolerance_mm));
    json.push_str(&format!("    \"total_slabs_used\": {},\n", total_slabs_used));
    json.push_str(&format!("    \"yield_efficiency_pct\": {:.1},\n", yield_efficiency_pct));
    json.push_str(&format!("    \"waste_pct\": {:.1}\n", waste_pct));
    json.push_str("  },\n");

    // Pricing
    json.push_str("  \"pricing\": {\n");
    json.push_str(&format!("    \"timber_cost_cny\": {:.2},\n", raw_wood_cost));
    json.push_str(&format!("    \"kiln_drying_cny\": {:.2},\n", kiln_drying_cost));
    json.push_str(&format!("    \"craft_labor_cny\": {:.2},\n", master_craft_labor));
    json.push_str(&format!("    \"craft_hours\": {:.1},\n", craftsman_hours));
    json.push_str(&format!("    \"finishing_cny\": {:.2},\n", natural_oil_finish_cost));
    json.push_str(&format!("    \"hardware_cny\": {:.2},\n", brass_hardware_cost));
    json.push_str(&format!("    \"suggested_retail_cny\": {:.0}\n", suggested_retail_cny));
    json.push_str("  },\n");

    // Cut List
    json.push_str("  \"cut_list\": [\n");
    for (idx, p) in cut_list.iter().enumerate() {
        json.push_str("    {\n");
        json.push_str(&format!("      \"part_id\": \"{}\",\n", p.part_id));
        json.push_str(&format!("      \"name_cn\": \"{}\",\n", p.name_cn));
        json.push_str(&format!("      \"name_en\": \"{}\",\n", p.name_en));
        json.push_str(&format!("      \"qty\": {},\n", p.qty));
        json.push_str(&format!("      \"length_mm\": {:.1},\n", p.length_mm));
        json.push_str(&format!("      \"width_mm\": {:.1},\n", p.width_mm));
        json.push_str(&format!("      \"thickness_mm\": {:.1},\n", p.thickness_mm));
        json.push_str(&format!("      \"grain_dir\": \"{}\",\n", p.grain_dir));
        json.push_str(&format!("      \"joinery_notes\": \"{}\"\n", p.joinery_notes));
        if idx + 1 < cut_list.len() {
            json.push_str("    },\n");
        } else {
            json.push_str("    }\n");
        }
    }
    json.push_str("  ],\n");

    // Nesting Placed Slabs
    json.push_str("  \"nesting\": {\n");
    json.push_str(&format!("    \"slab_length_mm\": {},\n", slab_l));
    json.push_str(&format!("    \"slab_width_mm\": {},\n", slab_w));
    json.push_str(&format!("    \"kerf_mm\": {},\n", kerf));
    json.push_str(&format!("    \"total_slabs\": {},\n", total_slabs_used));
    json.push_str("    \"placements\": [\n");
    for (idx, pl) in placed_parts.iter().enumerate() {
        json.push_str("      {\n");
        json.push_str(&format!("        \"part_id\": \"{}\",\n", pl.part_id));
        json.push_str(&format!("        \"board_index\": {},\n", pl.board_index));
        json.push_str(&format!("        \"x\": {:.1},\n", pl.x));
        json.push_str(&format!("        \"y\": {:.1},\n", pl.y));
        json.push_str(&format!("        \"width\": {:.1},\n", pl.width));
        json.push_str(&format!("        \"height\": {:.1},\n", pl.height));
        json.push_str(&format!("        \"rotated\": {}\n", pl.rotated));
        if idx + 1 < placed_parts.len() {
            json.push_str("      },\n");
        } else {
            json.push_str("      }\n");
        }
    }
    json.push_str("    ]\n");
    json.push_str("  }\n");
    json.push_str("}\n");

    json
}

fn parse_json_val(body: &str, key: &str) -> Option<String> {
    let pattern = format!("\"{}\"", key);
    if let Some(pos) = body.find(&pattern) {
        let remainder = &body[pos + pattern.len()..];
        if let Some(colon_pos) = remainder.find(':') {
            let val_part = remainder[colon_pos + 1..].trim();
            if val_part.starts_with('"') {
                if let Some(end_quote) = val_part[1..].find('"') {
                    return Some(val_part[1..1 + end_quote].to_string());
                }
            } else {
                let end = val_part.find(|c| c == ',' || c == '}' || c == '\n' || c == '\r').unwrap_or(val_part.len());
                return Some(val_part[..end].trim().to_string());
            }
        }
    }
    None
}

fn parse_params(body: &str) -> FurnitureParams {
    let mut p = FurnitureParams::default();
    if let Some(val) = parse_json_val(body, "length_mm") {
        if let Ok(v) = val.parse::<f64>() { p.length_mm = v; }
    }
    if let Some(val) = parse_json_val(body, "width_mm") {
        if let Ok(v) = val.parse::<f64>() { p.width_mm = v; }
    }
    if let Some(val) = parse_json_val(body, "height_mm") {
        if let Ok(v) = val.parse::<f64>() { p.height_mm = v; }
    }
    if let Some(val) = parse_json_val(body, "top_thickness_mm") {
        if let Ok(v) = val.parse::<f64>() { p.top_thickness_mm = v; }
    }
    if let Some(val) = parse_json_val(body, "leg_size_mm") {
        if let Ok(v) = val.parse::<f64>() { p.leg_size_mm = v; }
    }
    if let Some(val) = parse_json_val(body, "wood_type") {
        p.wood_type = val;
    }
    if let Some(val) = parse_json_val(body, "joint_type") {
        p.joint_type = val;
    }
    if let Some(val) = parse_json_val(body, "finish_type") {
        p.finish_type = val;
    }
    if let Some(val) = parse_json_val(body, "load_kg") {
        if let Ok(v) = val.parse::<f64>() { p.load_kg = v; }
    }
    p
}

fn handle_connection(mut stream: TcpStream) {
    let mut buffer = [0; 8192];
    let bytes_read = match stream.read(&mut buffer) {
        Ok(n) if n > 0 => n,
        _ => return,
    };
    let request_str = String::from_utf8_lossy(&buffer[..bytes_read]);

    let first_line = request_str.lines().next().unwrap_or("");
    let parts: Vec<&str> = first_line.split_whitespace().collect();
    if parts.len() < 2 {
        return;
    }
    let method = parts[0];
    let path = parts[1];

    let (status_line, content_type, response_body) = if method == "OPTIONS" {
        (
            "HTTP/1.1 204 No Content",
            "text/plain",
            "".to_string(),
        )
    } else if path.starts_with("/api/health") {
        let uptime_secs = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
        let health_json = format!(
            "{{\n  \"status\": \"healthy\",\n  \"service\": \"Yunqi WoodEngine Rust Daemon\",\n  \"version\": \"1.99.1-musl\",\n  \"timestamp\": {},\n  \"features\": [\"parametric_cad\", \"euler_bernoulli_stress\", \"guillotine_2d_nesting\", \"bom_generator\"]\n}}",
            uptime_secs
        );
        ("HTTP/1.1 200 OK", "application/json", health_json)
    } else if path.starts_with("/api/calculate") || path.starts_with("/api/optimize-cutlist") {
        // Extract body
        let body = if let Some(idx) = request_str.find("\r\n\r\n") {
            &request_str[idx + 4..]
        } else if let Some(idx) = request_str.find("\n\n") {
            &request_str[idx + 2..]
        } else {
            ""
        };

        let params = parse_params(body);
        let result_json = calculate_furniture(&params);
        ("HTTP/1.1 200 OK", "application/json", result_json)
    } else {
        ("HTTP/1.1 404 NOT FOUND", "application/json", "{\"error\": \"not found\"}".to_string())
    };

    let response = format!(
        "{}\r\nContent-Type: {}\r\nContent-Length: {}\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\n\r\n{}",
        status_line,
        content_type,
        response_body.len(),
        response_body
    );

    let _ = stream.write_all(response.as_bytes());
    let _ = stream.flush();
}

fn main() {
    let args: Vec<String> = env::args().collect();

    // CLI Mode support: allows Next.js or scripts to execute the engine directly
    if args.contains(&"--cli".to_string()) || args.contains(&"-c".to_string()) {
        let mut input = String::new();
        // check if argument passed after --json
        if let Some(pos) = args.iter().position(|r| r == "--json") {
            if pos + 1 < args.len() {
                input = args[pos + 1].clone();
            }
        }
        if input.is_empty() {
            let _ = std::io::stdin().read_to_string(&mut input);
        }
        let params = parse_params(&input);
        let result = calculate_furniture(&params);
        println!("{}", result);
        return;
    }

    let port = env::var("RUST_PORT").unwrap_or_else(|_| "5050".to_string());
    let addr = format!("0.0.0.0:{}", port);
    let listener = match TcpListener::bind(&addr) {
        Ok(l) => {
            println!("⚡ [Yunqi WoodEngine Rust] Listening on http://{}", addr);
            l
        }
        Err(e) => {
            eprintln!("Failed to bind to {}: {}. Running CLI test...", addr, e);
            let params = FurnitureParams::default();
            println!("{}", calculate_furniture(&params));
            return;
        }
    };

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                thread::spawn(move || {
                    handle_connection(stream);
                });
            }
            Err(e) => {
                eprintln!("Connection failed: {}", e);
            }
        }
    }
}
