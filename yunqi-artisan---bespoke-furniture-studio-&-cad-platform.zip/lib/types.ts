// Core types for Yunqi Furniture Studio, Flatform CAD, and Rust Backend

export type FurnitureCategory = "tea_table" | "armchair" | "daybed" | "credenza" | "console";

export interface FurnitureTemplate {
  id: string;
  category: FurnitureCategory;
  nameCn: string;
  nameEn: string;
  tagline: string;
  description: string;
  defaultDimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    topThicknessMm: number;
    legSizeMm: number;
  };
  dimensionRanges: {
    minLength: number;
    maxLength: number;
    minWidth: number;
    maxWidth: number;
    minHeight: number;
    maxHeight: number;
    minThickness: number;
    maxThickness: number;
  };
  defaultWood: string;
  defaultJoint: string;
  recommendedFinish: string;
  imageUrl?: string;
}

export interface WoodSpecies {
  id: string;
  nameCn: string;
  nameEn: string;
  colorHex: string;
  roughColorHex: string;
  density: number; // kg/m3
  moeMpa: number; // Modulus of Elasticity
  morMpa: number; // Bending Strength
  costPerBfCny: number;
  grainTexture: "cathedral" | "straight" | "figured" | "dense";
  description: string;
}

export interface JoineryType {
  id: string;
  nameCn: string;
  nameEn: string;
  historicalPeriod: string;
  difficultyRating: number; // 1-5
  strengthRating: number; // 1-5
  diagramSvgKey: string;
  description: string;
}

export interface CutListItem {
  part_id: string;
  name_cn: string;
  name_en: string;
  qty: number;
  length_mm: number;
  width_mm: number;
  thickness_mm: number;
  grain_dir: string;
  joinery_notes: string;
}

export interface PlacedSlabPart {
  part_id: string;
  board_index: number;
  x: number;
  y: number;
  width: number;
  height: number;
  rotated: boolean;
}

export interface RustCalculationResult {
  engine: string;
  runtime: string;
  compute_time_microseconds?: number;
  compute_time_ms: number;
  backend_channel?: string;
  wood: {
    name_cn: string;
    name_en: string;
    density_kg_m3: number;
    modulus_elasticity_mpa: number;
    bending_strength_mpa: number;
    janka_hardness_n?: number;
  };
  metrics: {
    board_feet: number;
    finished_volume_m3: number;
    finished_weight_kg: number;
    packaged_weight_kg: number;
    center_deflection_mm: number;
    bending_stress_mpa: number;
    safety_factor: number;
    max_safe_load_kg: number;
    mortise_tenon_count: number;
    joint_tolerance_mm: number;
    total_slabs_used: number;
    yield_efficiency_pct: number;
    waste_pct: number;
  };
  pricing: {
    timber_cost_cny: number;
    kiln_drying_cny: number;
    craft_labor_cny: number;
    craft_hours: number;
    finishing_cny: number;
    hardware_cny: number;
    suggested_retail_cny: number;
  };
  cut_list: CutListItem[];
  nesting: {
    slab_length_mm: number;
    slab_width_mm: number;
    kerf_mm: number;
    total_slabs: number;
    placements: PlacedSlabPart[];
  };
}

export const WOOD_SPECIES_LIST: WoodSpecies[] = [
  {
    id: "walnut",
    nameCn: "北美特级黑胡桃",
    nameEn: "FAS Black Walnut",
    colorHex: "#3e271e",
    roughColorHex: "#52372a",
    density: 610,
    moeMpa: 11500,
    morMpa: 101,
    costPerBfCny: 48,
    grainTexture: "cathedral",
    description: "温润沉稳，抛光性好，自然山水纹理细腻，是当代东方美学家具首选木料。",
  },
  {
    id: "teak",
    nameCn: "缅甸金丝柚木",
    nameEn: "Burmese Golden Teak",
    colorHex: "#6e4f2b",
    roughColorHex: "#886337",
    density: 650,
    moeMpa: 12300,
    morMpa: 98,
    costPerBfCny: 72,
    grainTexture: "straight",
    description: "含天然油脂，极耐水抗变形，金黄色泽历久弥新，茶室家具经典之选。",
  },
  {
    id: "oak",
    nameCn: "北美白橡木",
    nameEn: "Quarter-sawn White Oak",
    colorHex: "#8c7255",
    roughColorHex: "#a3886b",
    density: 750,
    moeMpa: 12300,
    morMpa: 105,
    costPerBfCny: 36,
    grainTexture: "figured",
    description: "质地坚硬沉重，虎斑髓线明显，结构力学强度极高，适合长久传家的大型构件。",
  },
  {
    id: "rosewood",
    nameCn: "小叶紫檀/红酸枝",
    nameEn: "Red Sandalwood",
    colorHex: "#3a1314",
    roughColorHex: "#4f1c1d",
    density: 980,
    moeMpa: 14800,
    morMpa: 135,
    costPerBfCny: 160,
    grainTexture: "dense",
    description: "重逾千钧，入水即沉，木性极其稳定，明清宫廷御用顶级硬木，包浆如琥珀。",
  },
  {
    id: "ash",
    nameCn: "俄罗斯特级白蜡木",
    nameEn: "Russian White Ash",
    colorHex: "#b59b7c",
    roughColorHex: "#cca887",
    density: 680,
    moeMpa: 12000,
    morMpa: 103,
    costPerBfCny: 28,
    grainTexture: "cathedral",
    description: "年轮分明，抗弯曲弹性极强，素雅清新，易于展现淡雅禅意生活。",
  },
];

export const JOINERY_TYPES_LIST: JoineryType[] = [
  {
    id: "corner_mitre",
    nameCn: "粽角榫 (三维三接)",
    nameEn: "Three-Way Mitred M&T Joint",
    historicalPeriod: "明代经典 (Ming Dynasty)",
    difficultyRating: 5,
    strengthRating: 5,
    diagramSvgKey: "corner_mitre",
    description: "家具三根方材交接于一角，外观仅见45度斜线，内部三向暗榫相互穿插咬合，平正坚固。",
  },
  {
    id: "dovetail",
    nameCn: "透/暗燕尾榫",
    nameEn: "Through & Half-Blind Dovetail",
    historicalPeriod: "宋元演进",
    difficultyRating: 4,
    strengthRating: 5,
    diagramSvgKey: "dovetail",
    description: "梯形榫头大进小出，具有极强抗拉力，常用在抽屉、柜框与大板边框角部拼合。",
  },
  {
    id: "bridle",
    nameCn: "夹头榫 (双面抱肩)",
    nameEn: "Bridle Lap Joint",
    historicalPeriod: "宋代案形结体",
    difficultyRating: 4,
    strengthRating: 4,
    diagramSvgKey: "bridle",
    description: "腿足上端开口夹住牙条与牙头，上承案面，结构雄浑洗练，是条案茶台的不朽形制。",
  },
  {
    id: "shoulder",
    nameCn: "抱肩榫与霸王枨",
    nameEn: "Waisted Shoulder with S-Strut",
    historicalPeriod: "明代有束腰体系",
    difficultyRating: 5,
    strengthRating: 5,
    diagramSvgKey: "shoulder",
    description: "桌面与腿足间带束腰，腿足内侧以S形霸王枨向内拉紧桌面穿带，外表不见任何枨条，通透灵动。",
  },
];

export const FURNITURE_TEMPLATES: FurnitureTemplate[] = [
  {
    id: "tea_table_01",
    category: "tea_table",
    nameCn: "禅意实木茶台",
    nameEn: "Zen Gongfu Tea Table",
    tagline: "一席茶香 · 一方天地",
    description: "大板拼宽，下设暗槽滑动穿带，粽角榫四柱扎实落地，预留功夫茶排水铜水盘空间。",
    defaultDimensions: {
      lengthMm: 1600,
      widthMm: 750,
      heightMm: 420,
      topThicknessMm: 38,
      legSizeMm: 68,
    },
    dimensionRanges: {
      minLength: 1200,
      maxLength: 2400,
      minWidth: 500,
      maxWidth: 1000,
      minHeight: 350,
      maxHeight: 750,
      minThickness: 30,
      maxThickness: 65,
    },
    defaultWood: "walnut",
    defaultJoint: "corner_mitre",
    recommendedFinish: "天然蜂蜡烫蜡",
  },
  {
    id: "armchair_02",
    category: "armchair",
    nameCn: "明式四出头官帽椅",
    nameEn: "Official's Hat Armchair",
    tagline: "简约 · 典雅 · 永恒",
    description: "S形曲线靠背板贴合脊椎，搭脑出头挺拔，烟袋锅榫连接，承托自然，气度从容。",
    defaultDimensions: {
      lengthMm: 620,
      widthMm: 560,
      heightMm: 980,
      topThicknessMm: 28,
      legSizeMm: 42,
    },
    dimensionRanges: {
      minLength: 540,
      maxLength: 720,
      minWidth: 480,
      maxWidth: 650,
      minHeight: 880,
      maxHeight: 1120,
      minThickness: 22,
      maxThickness: 38,
    },
    defaultWood: "rosewood",
    defaultJoint: "dovetail",
    recommendedFinish: "哑光木蜡油",
  },
  {
    id: "daybed_03",
    category: "daybed",
    nameCn: "明式三围栏罗汉榻",
    nameEn: "Mortise Luohan Daybed",
    tagline: "宁静 · 舒适 · 自然",
    description: "三面透空曲尺围子，宽榻面嵌硬木拼板，抱肩榫有束腰马蹄腿，闲坐对弈、倚卧读书。",
    defaultDimensions: {
      lengthMm: 2080,
      widthMm: 980,
      heightMm: 780,
      topThicknessMm: 45,
      legSizeMm: 78,
    },
    dimensionRanges: {
      minLength: 1800,
      maxLength: 2250,
      minWidth: 850,
      maxWidth: 1150,
      minHeight: 650,
      maxHeight: 880,
      minThickness: 35,
      maxThickness: 60,
    },
    defaultWood: "walnut",
    defaultJoint: "shoulder",
    recommendedFinish: "天然蜂蜡烫蜡",
  },
  {
    id: "credenza_04",
    category: "credenza",
    nameCn: "圆角木轴收纳边柜",
    nameEn: "Round-Corner Cabinet",
    tagline: "匠心工艺 · 实用美学",
    description: "无金属铰链，传统木门轴与白铜面页拉手，柜顶与柜足微倾收敛，线条含蓄隽永。",
    defaultDimensions: {
      lengthMm: 1180,
      widthMm: 480,
      heightMm: 1260,
      topThicknessMm: 32,
      legSizeMm: 52,
    },
    dimensionRanges: {
      minLength: 880,
      maxLength: 1600,
      minWidth: 380,
      maxWidth: 600,
      minHeight: 900,
      maxHeight: 1650,
      minThickness: 25,
      maxThickness: 45,
    },
    defaultWood: "teak",
    defaultJoint: "dovetail",
    recommendedFinish: "哑光木蜡油",
  },
];
