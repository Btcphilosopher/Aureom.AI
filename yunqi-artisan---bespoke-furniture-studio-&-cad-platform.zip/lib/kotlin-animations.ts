// Kotlin Jetpack Compose & Multiplatform Animation Physics Bridge
// Implements exact Kotlin Compose SpringSpec, TweenSpec, and Keyframe easing for Next.js

export interface KotlinSpringConfig {
  name: string;
  dampingRatio: number; // 0.2f (HighBouncy) to 1.0f (NoBouncy)
  stiffness: number;    // 50f (VeryLow) to 1500f (High)
  description: string;
}

// Canonical Jetpack Compose Spring Constants
export const KOTLIN_SPRING_PRESETS: Record<string, KotlinSpringConfig> = {
  mediumBouncy: {
    name: "Spring.DampingRatioMediumBouncy",
    dampingRatio: 0.5,
    stiffness: 450,
    description: "Compose default playful spring with natural overshoot",
  },
  lowBouncy: {
    name: "Spring.DampingRatioLowBouncy",
    dampingRatio: 0.75,
    stiffness: 350,
    description: "Compose subtle organic settling, ideal for craftsmanship cards",
  },
  noBouncy: {
    name: "Spring.DampingRatioNoBouncy",
    dampingRatio: 1.0,
    stiffness: 400,
    description: "Critically damped smooth transition without oscillation",
  },
  highStiffness: {
    name: "Spring.StiffnessHigh (Fast Snap)",
    dampingRatio: 0.82,
    stiffness: 850,
    description: "Snappy mechanical response for joinery toggles & cut-list edits",
  },
  zenGentle: {
    name: "Kotlin Gentle (Tea Room Serenity)",
    dampingRatio: 0.9,
    stiffness: 220,
    description: "Calm, slow-paced aesthetic glide matching Eastern tea philosophy",
  },
};

// Convert Kotlin Compose (dampingRatio, stiffness) to Framer Motion spring parameters
// In physics: damping = 2 * dampingRatio * sqrt(stiffness * mass)
export function composeToMotionSpring(dampingRatio: number, stiffness: number, mass: number = 1) {
  const damping = 2 * dampingRatio * Math.sqrt(stiffness * mass);
  return {
    type: "spring" as const,
    stiffness,
    damping,
    mass,
    restDelta: 0.001,
  };
}

// Canonical Jetpack Compose Cubic Bezier Easing Curves
export const KOTLIN_EASING = {
  fastOutSlowIn: [0.4, 0.0, 0.2, 1.0], // Compose standard decelerate
  linearOutSlowIn: [0.0, 0.0, 0.2, 1.0], // Compose incoming transition
  fastOutLinearIn: [0.4, 0.0, 1.0, 1.0], // Compose exit transition
};

export const getComposeVariants = (spring: KotlinSpringConfig = KOTLIN_SPRING_PRESETS.lowBouncy) => {
  const transition = composeToMotionSpring(spring.dampingRatio, spring.stiffness);

  return {
    fadeInUp: {
      initial: { opacity: 0, y: 24, scale: 0.98 },
      animate: { opacity: 1, y: 0, scale: 1, transition },
      exit: { opacity: 0, y: -16, transition: { duration: 0.25, ease: KOTLIN_EASING.fastOutLinearIn } },
    },
    staggerContainer: {
      initial: { opacity: 0 },
      animate: {
        opacity: 1,
        transition: {
          staggerChildren: 0.08,
          delayChildren: 0.05,
        },
      },
    },
    staggerItem: {
      initial: { opacity: 0, y: 20 },
      animate: { opacity: 1, y: 0, transition },
    },
    scalePress: {
      whileHover: { scale: 1.025, transition },
      whileTap: { scale: 0.975, transition },
    },
    explodedJoint: (offsetMm: number) => ({
      collapsed: { x: 0, y: 0, z: 0 },
      exploded: {
        x: offsetMm,
        transition,
      },
    }),
  };
};
