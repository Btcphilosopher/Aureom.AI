"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  KotlinSpringConfig,
  KOTLIN_SPRING_PRESETS,
  composeToMotionSpring,
} from "@/lib/kotlin-animations";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Sliders, ChevronDown, ChevronUp, Play, Activity } from "lucide-react";

interface KotlinPhysicsHUDProps {
  activeSpring: KotlinSpringConfig;
  onUpdateSpring: (config: KotlinSpringConfig) => void;
}

export default function KotlinPhysicsHUD({
  activeSpring,
  onUpdateSpring,
}: KotlinPhysicsHUDProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [testBouncing, setTestBouncing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw harmonic oscillator wave on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Draw baseline
    ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();

    // Harmonic oscillator equation: x(t) = exp(-zeta * w0 * t) * cos(wd * t)
    const zeta = activeSpring.dampingRatio;
    const k = activeSpring.stiffness;
    const w0 = Math.sqrt(k);
    const wd = zeta < 1 ? w0 * Math.sqrt(1 - zeta * zeta) : w0;

    ctx.strokeStyle = "#f59e0b"; // Amber color
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    const maxT = 1.6; // seconds
    for (let x = 0; x < w; x++) {
      const t = (x / w) * maxT;
      let val = 0;
      if (zeta < 1) {
        val = Math.exp(-zeta * w0 * t) * Math.cos(wd * t * 4);
      } else {
        val = Math.exp(-zeta * w0 * t);
      }
      const y = h / 2 - val * (h * 0.38);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }, [activeSpring]);

  const triggerTestBounce = () => {
    setTestBouncing(true);
    setTimeout(() => setTestBouncing(false), 900);
  };

  const currentMotionSpring = composeToMotionSpring(
    activeSpring.dampingRatio,
    activeSpring.stiffness
  );

  return (
    <div className="fixed bottom-4 right-4 z-50 select-none">
      <AnimatePresence>
        {isOpen ? (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1, transition: currentMotionSpring }}
            exit={{ opacity: 0, y: 15, scale: 0.95 }}
            className="w-80 sm:w-96 p-4 rounded-2xl bg-neutral-900/95 backdrop-blur-xl border border-amber-600/40 shadow-2xl text-neutral-200"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-[10px] font-bold text-white shadow">
                  K
                </div>
                <div>
                  <h4 className="text-xs font-bold text-neutral-100 flex items-center gap-1.5">
                    Kotlin Compose 物理动效引擎
                  </h4>
                  <p className="text-[10px] text-amber-400 font-mono">
                    Jetpack Compose SpringSpec 物理曲线
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>

            {/* Oscillation Waveform Canvas */}
            <div className="bg-neutral-950 rounded-xl p-2.5 border border-neutral-800/80 mb-3">
              <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1.5 font-mono">
                <span className="flex items-center gap-1 text-amber-300">
                  <Activity className="w-3 h-3" />
                  阻尼谐振曲线 (Damped Harmonic)
                </span>
                <span>t = 0 → 1.6s</span>
              </div>
              <canvas
                ref={canvasRef}
                width={330}
                height={65}
                className="w-full h-[65px] rounded bg-neutral-900/50"
              />
            </div>

            {/* Presets List */}
            <div className="space-y-1.5 mb-3">
              <label className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block">
                Compose 经典预设 (Presets):
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {Object.entries(KOTLIN_SPRING_PRESETS).map(([key, preset]) => {
                  const isActive = activeSpring.name === preset.name;
                  return (
                    <button
                      key={key}
                      onClick={() => onUpdateSpring(preset)}
                      className={`p-2 rounded-lg text-left border text-xs transition flex flex-col justify-between ${
                        isActive
                          ? "bg-amber-950/80 border-amber-500 text-amber-200 shadow"
                          : "bg-neutral-800/60 border-neutral-750 text-neutral-400 hover:text-neutral-200"
                      }`}
                    >
                      <span className="font-bold text-[11px] truncate">{preset.name.replace("Spring.", "")}</span>
                      <span className="text-[9px] font-mono text-neutral-500 mt-0.5">
                        ζ: {preset.dampingRatio} · k: {preset.stiffness}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Sliders */}
            <div className="space-y-2.5 bg-neutral-950/70 p-3 rounded-xl border border-neutral-800 mb-3 text-xs">
              <div>
                <div className="flex justify-between font-mono text-[11px] mb-1">
                  <span className="text-neutral-400">Damping Ratio (阻尼比 ζ):</span>
                  <span className="text-amber-400 font-bold">{activeSpring.dampingRatio.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={1.1}
                  step={0.05}
                  value={activeSpring.dampingRatio}
                  onChange={(e) =>
                    onUpdateSpring({
                      ...activeSpring,
                      dampingRatio: Number(e.target.value),
                    })
                  }
                  className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[9px] text-neutral-500 font-mono mt-0.5">
                  <span>0.2 (HighBouncy 弹性大)</span>
                  <span>1.0 (NoBouncy 临界阻尼)</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between font-mono text-[11px] mb-1">
                  <span className="text-neutral-400">Stiffness (刚度 k):</span>
                  <span className="text-amber-400 font-bold">{activeSpring.stiffness}</span>
                </div>
                <input
                  type="range"
                  min={100}
                  max={1200}
                  step={50}
                  value={activeSpring.stiffness}
                  onChange={(e) =>
                    onUpdateSpring({
                      ...activeSpring,
                      stiffness: Number(e.target.value),
                    })
                  }
                  className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[9px] text-neutral-500 font-mono mt-0.5">
                  <span>100 (柔和缓释)</span>
                  <span>1200 (极速干脆)</span>
                </div>
              </div>
            </div>

            {/* Live Physics Test Sandbox */}
            <div className="flex items-center justify-between bg-neutral-800/80 p-2.5 rounded-xl border border-neutral-700">
              <span className="text-xs text-neutral-300">测试当前物理手感:</span>
              <motion.button
                onClick={triggerTestBounce}
                whileTap={{ scale: 0.85 }}
                animate={
                  testBouncing
                    ? { y: [-15, 6, -3, 0], scale: [1, 1.15, 0.95, 1], rotate: [0, -6, 4, 0] }
                    : { y: 0, scale: 1, rotate: 0 }
                }
                transition={currentMotionSpring}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-950/40"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>触发榫卯震颤</span>
              </motion.button>
            </div>
          </motion.div>
        ) : (
          <motion.button
            onClick={() => setIsOpen(true)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={currentMotionSpring}
            className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-neutral-900/90 hover:bg-neutral-850 backdrop-blur-xl border border-amber-600/40 text-neutral-200 shadow-2xl text-xs font-medium cursor-pointer"
          >
            <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-[10px] font-bold text-white shadow">
              K
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[11px] font-semibold text-neutral-100 flex items-center gap-1">
                Kotlin 动效参数
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              </span>
              <span className="text-[9px] text-amber-400 font-mono">
                ζ: {activeSpring.dampingRatio} · k: {activeSpring.stiffness}
              </span>
            </div>
            <ChevronUp className="w-4 h-4 text-neutral-400" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
