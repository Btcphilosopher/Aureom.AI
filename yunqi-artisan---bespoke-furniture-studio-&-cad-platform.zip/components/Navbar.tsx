"use client";

import React, { useState } from "react";
import { Search, User, ShoppingBag, Menu, X, Cpu, Layers } from "lucide-react";
import { KotlinSpringConfig } from "@/lib/kotlin-animations";

interface NavbarProps {
  activeSpring: KotlinSpringConfig;
  onOpenStudio: () => void;
}

export default function Navbar({ onOpenStudio }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#141210]/90 backdrop-blur-md border-b border-neutral-800/80 text-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Monogram + Logo (matching image top-left) */}
        <a href="#hero" className="flex items-center gap-3 group">
          {/* Custom Mountain Cloud Monogram */}
          <div className="w-10 h-10 flex items-center justify-center text-amber-200">
            <svg viewBox="0 0 48 36" fill="none" className="w-9 h-7 stroke-current stroke-[1.75] transition group-hover:scale-105">
              <path d="M 6 30 L 16 12 L 26 30" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M 22 30 L 32 8 L 42 30" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M 12 22 L 20 22" strokeLinecap="round" />
              <path d="M 28 18 L 36 18" strokeLinecap="round" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-lg tracking-widest text-neutral-100 font-bold group-hover:text-amber-200 transition">
              云栖家具
            </span>
            <span className="text-[9px] tracking-[0.2em] text-neutral-400 font-mono -mt-0.5">
              YUNQI FURNITURE
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm">
          <a
            href="#hero"
            className="text-amber-400 font-medium relative py-1 after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-amber-400"
          >
            首页
          </a>
          <a
            href="#collections"
            className="text-neutral-400 hover:text-neutral-100 transition py-1"
          >
            产品系列
          </a>
          <a
            href="#craftsmanship"
            className="text-neutral-400 hover:text-neutral-100 transition py-1"
          >
            设计理念 & 榫卯
          </a>
          <a
            href="#custom-studio"
            className="text-amber-200 hover:text-amber-100 transition py-1 flex items-center gap-1.5 font-medium"
          >
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>定制平台 (Studio)</span>
          </a>
          <a
            href="#rust-engine"
            className="text-neutral-400 hover:text-neutral-100 transition py-1 flex items-center gap-1"
          >
            <Cpu className="w-3.5 h-3.5 text-orange-400" />
            <span>Rust引擎</span>
          </a>
        </nav>

        {/* Header Right Actions */}
        <div className="flex items-center gap-4">
          {/* Rust Status Pill */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-[11px] font-mono text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Rust 1.99 Engine</span>
          </div>

          <button
            title="搜索系列与木种"
            className="p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            title="匠人与客户中心"
            className="p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition"
          >
            <User className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenStudio}
            className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-neutral-950 font-bold text-xs tracking-wider transition shadow-lg shadow-amber-950/40"
          >
            <span>定制工坊</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-neutral-800 text-neutral-400"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#161412] border-b border-neutral-800 px-6 py-4 space-y-3 text-sm">
          <a
            href="#hero"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-amber-400 font-medium py-1"
          >
            首页 (Home)
          </a>
          <a
            href="#collections"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-neutral-300 py-1"
          >
            产品系列 (Collections)
          </a>
          <a
            href="#craftsmanship"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-neutral-300 py-1"
          >
            匠心工艺与设计理念
          </a>
          <a
            href="#custom-studio"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-amber-300 font-bold py-1"
          >
            3D/2D定制平台 (CAD Studio)
          </a>
          <a
            href="#rust-engine"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-orange-400 font-mono py-1"
          >
            Rust 木作力学后台
          </a>
        </div>
      )}
    </header>
  );
}
