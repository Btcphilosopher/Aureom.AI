"use client";

import React from "react";
import Image from "next/image";
import { ArrowRight, Sparkles, Layers } from "lucide-react";

interface CollectionsProps {
  onSelectCollection: (templateId: string) => void;
}

export default function Collections({ onSelectCollection }: CollectionsProps) {
  const collections = [
    {
      id: "armchair_02",
      titleCn: "明式系列",
      titleEn: "Ming Dynasty Series",
      subtitle: "简约 · 典雅 · 永恒",
      description: "汲取明代文人家具比例精髓，线条挺拔空灵，S形靠背板顺应人体脊椎曲线。",
      // Curated photography matching chair in screenshot
      image: "https://picsum.photos/seed/ming-chair-yunqi/600/700",
      tag: "文人坐具",
    },
    {
      id: "tea_table_01",
      titleCn: "茶室系列",
      titleEn: "Zen Tea Room Series",
      subtitle: "一席茶香 · 一方天地",
      description: "北美特级黑胡桃大板直拼，粽角暗榫扎实稳固，茶汤入杯，余韵悠长。",
      image: "https://picsum.photos/seed/zen-tea-table-yunqi/600/700",
      tag: "禅房茶台",
    },
    {
      id: "daybed_03",
      titleCn: "卧室系列",
      titleEn: "Serene Bedroom Series",
      subtitle: "宁静 · 舒适 · 自然",
      description: "全榫卯构架，三面透雕围子，天然蜂蜡烫蜡封孔，营造温润静谧的休憩之所。",
      image: "https://picsum.photos/seed/oriental-bedroom-bed/600/700",
      tag: "卧榻榻房",
    },
    {
      id: "credenza_04",
      titleCn: "收纳系列",
      titleEn: "Cabinet & Credenza Series",
      subtitle: "匠心工艺 · 实用美学",
      description: "传统木门轴开合，侧脚收分造型，白铜錾花面页拉手，大收纳量与优雅兼具。",
      image: "https://picsum.photos/seed/sideboard-cabinet-oriental/600/700",
      tag: "圆角边柜",
    },
  ];

  return (
    <section id="collections" className="relative w-full py-20 px-4 sm:px-6 lg:px-8 bg-[#f5f2eb] text-[#221f1c]">
      <div className="max-w-7xl mx-auto">
        {/* Top Header Block matching the screenshot layout */}
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-8 mb-14">
          <div className="max-w-md space-y-3">
            <span className="text-xs font-mono tracking-widest text-[#8c6b45] uppercase">
              精选系列 · CURATED COLLECTIONS
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-[#1f1a16] leading-tight">
              传承东方
              <br />
              经典再现
            </h2>
            <p className="text-sm text-[#5f5851] leading-relaxed font-serif">
              云栖家具汲取中国传统工艺精髓，结合现代生活方式，打造兼具艺术性与实用性的高端家居作品。
            </p>
            <a
              href="#custom-studio"
              className="inline-flex items-center gap-2 text-xs font-bold text-[#1f1a16] hover:text-[#b45309] tracking-wider transition group pt-2"
            >
              <span>查看全部系列与定制参数</span>
              <ArrowRight className="w-4 h-4 transition transform group-hover:translate-x-1" />
            </a>
          </div>

          <div className="hidden lg:flex items-center gap-3 self-end text-xs font-mono text-[#786d63] bg-[#ece7dd] px-4 py-2 rounded-lg border border-[#ded7cc]">
            <Sparkles className="w-4 h-4 text-[#b45309]" />
            <span>支持 100% 尺寸按需定制 · 4种名贵硬木任选 · 榫卯验算</span>
          </div>
        </div>

        {/* 4 Cards Grid exactly like screenshot */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((item) => (
            <div
              key={item.id}
              className="group flex flex-col bg-[#ede8df] rounded-xl overflow-hidden border border-[#ded6c9] hover:border-[#b45309]/50 transition-all duration-300 hover:shadow-xl"
            >
              {/* Image Container */}
              <div className="relative w-full aspect-[4/3] overflow-hidden bg-[#ded6c9]">
                <Image
                  src={item.image}
                  alt={item.titleCn}
                  fill
                  className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-[#1c1917]/70 backdrop-blur-sm text-[10px] font-mono text-amber-200">
                  {item.tag}
                </div>
              </div>

              {/* Text Info */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-lg font-serif font-bold text-[#1e1915]">
                    {item.titleCn}
                  </h3>
                  <p className="text-xs text-[#8c6b45] font-serif mt-0.5 font-medium">
                    {item.subtitle}
                  </p>
                  <p className="text-xs text-[#5e564f] mt-2 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <button
                  onClick={() => onSelectCollection(item.id)}
                  className="w-full mt-3 py-2 px-3 rounded-lg bg-[#dfd7ca] group-hover:bg-[#b45309] text-[#1e1915] group-hover:text-white text-xs font-medium transition flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>在定制平台中打开</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
