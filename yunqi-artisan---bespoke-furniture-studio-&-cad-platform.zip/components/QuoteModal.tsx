"use client";

import React, { useState } from "react";
import confetti from "canvas-confetti";
import { FurnitureTemplate, WoodSpecies, RustCalculationResult } from "@/lib/types";
import { KotlinSpringConfig, composeToMotionSpring } from "@/lib/kotlin-animations";
import { motion, AnimatePresence } from "motion/react";
import {
  X,
  CheckCircle2,
  Download,
  Printer,
  ShieldCheck,
  Cpu,
  Layers,
  Wrench,
  Clock,
  Sparkles,
} from "lucide-react";

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  template: FurnitureTemplate;
  dimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    topThicknessMm: number;
    legSizeMm: number;
  };
  wood: WoodSpecies;
  jointType: string;
  finish: string;
  rustData: RustCalculationResult | null;
  activeSpring: KotlinSpringConfig;
}

export default function QuoteModal({
  isOpen,
  onClose,
  template,
  dimensions,
  wood,
  jointType,
  finish,
  rustData,
  activeSpring,
}: QuoteModalProps) {
  const [submitted, setSubmitted] = useState(false);
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");

  const motionSpring = composeToMotionSpring(
    activeSpring.dampingRatio,
    activeSpring.stiffness
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#d97706", "#f59e0b", "#fbbf24", "#78350f"],
    });
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  const pricing = rustData?.pricing || {
    timber_cost_cny: 2400,
    kiln_drying_cny: 220,
    craft_labor_cny: 4200,
    craft_hours: 48,
    finishing_cny: 420,
    hardware_cny: 180,
    suggested_retail_cny: 11200,
  };

  const metrics = rustData?.metrics || {
    board_feet: 48.5,
    finished_weight_kg: 52.4,
    center_deflection_mm: 1.45,
    safety_factor: 78.4,
    mortise_tenon_count: 28,
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0, transition: motionSpring }}
          exit={{ opacity: 0, scale: 0.9, y: 30 }}
          className="relative w-full max-w-2xl bg-[#141211] border border-amber-600/40 rounded-2xl shadow-2xl text-neutral-200 overflow-hidden my-8"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 bg-gradient-to-r from-neutral-900 to-amber-950/40 border-b border-neutral-800">
            <div>
              <span className="text-[11px] font-mono tracking-widest text-amber-400 uppercase">
                YUNQI BESPOKE WORKSHOP · 定制工单
              </span>
              <h3 className="text-xl font-bold text-neutral-100 mt-0.5">
                {template.nameCn} · 匠人定制生产单
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
            {submitted ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-emerald-950 border-2 border-emerald-500/50 flex items-center justify-center text-emerald-400 shadow-xl">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-neutral-100">
                  定制工单已提交至云栖实木工坊！
                </h4>
                <p className="text-xs text-neutral-400 max-w-md mx-auto leading-relaxed">
                  工坊首席木作师将根据 Rust 结构力学校验报告与开料图纸进行 1:1 放样核实，并在 24 小时内与您预约选料与刨光样块确认。
                </p>
                <div className="pt-4 flex justify-center gap-3">
                  <button
                    onClick={handlePrint}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-xs text-neutral-200 border border-neutral-700 transition"
                  >
                    <Printer className="w-4 h-4" />
                    <span>打印生产图单</span>
                  </button>
                  <button
                    onClick={onClose}
                    className="px-5 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-neutral-950 font-bold text-xs transition"
                  >
                    返回定制工作室
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Specs Matrix */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-neutral-950/70 p-4 rounded-xl border border-neutral-800">
                  <div>
                    <span className="text-neutral-500 block">成品外廓尺寸</span>
                    <span className="font-mono font-bold text-amber-300">
                      {dimensions.lengthMm}×{dimensions.widthMm}×{dimensions.heightMm} mm
                    </span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">精选木料</span>
                    <span className="font-bold text-neutral-200">{wood.nameCn}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">榫卯工艺节点</span>
                    <span className="font-bold text-neutral-200">{jointType}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">涂装保养</span>
                    <span className="font-bold text-neutral-200">{finish}</span>
                  </div>
                </div>

                {/* Rust Verified Engineering Badges */}
                <div className="bg-neutral-900/60 p-4 rounded-xl border border-neutral-800 text-xs space-y-2">
                  <div className="flex items-center justify-between text-neutral-400 border-b border-neutral-800 pb-2">
                    <span className="flex items-center gap-1.5 text-amber-400 font-semibold">
                      <Cpu className="w-4 h-4" />
                      Rust WoodEngine 结构力学校验结论
                    </span>
                    <span className="font-mono text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      通过国际高档家具耐用标准
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px] pt-1">
                    <div>
                      <span className="text-neutral-500">毛料板尺:</span>{" "}
                      <strong className="text-neutral-200">{metrics.board_feet} BF</strong>
                    </div>
                    <div>
                      <span className="text-neutral-500">成品净重:</span>{" "}
                      <strong className="text-neutral-200">{metrics.finished_weight_kg} kg</strong>
                    </div>
                    <div>
                      <span className="text-neutral-500">中心挠度:</span>{" "}
                      <strong className="text-emerald-400">{metrics.center_deflection_mm} mm</strong>
                    </div>
                    <div>
                      <span className="text-neutral-500">安全倍数:</span>{" "}
                      <strong className="text-emerald-400">{metrics.safety_factor}x</strong>
                    </div>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-amber-400" />
                    <span>工坊直出成本明细 (Price Breakdown)</span>
                  </h4>
                  <div className="space-y-1.5 text-xs bg-neutral-950/90 p-4 rounded-xl border border-neutral-800 font-mono">
                    <div className="flex justify-between text-neutral-300">
                      <span>进口FAS级原木板料 ({metrics.board_feet} BF × ¥{wood.costPerBfCny}):</span>
                      <span>¥{pricing.timber_cost_cny.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-neutral-400">
                      <span>二次微波除湿窑干处理 (含水率恒定10-12%):</span>
                      <span>¥{pricing.kiln_drying_cny.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-neutral-300">
                      <span>老匠人手工榫卯加工与刮刨放样 ({pricing.craft_hours} 工时):</span>
                      <span>¥{pricing.craft_labor_cny.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-neutral-400">
                      <span>天然矿物与植物蜂蜡/木蜡油反复烫擦 (3度渗透):</span>
                      <span>¥{pricing.finishing_cny.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-neutral-400">
                      <span>手工錾刻白铜角件/面页五金配件:</span>
                      <span>¥{pricing.hardware_cny.toLocaleString()}</span>
                    </div>

                    <div className="border-t border-neutral-800 pt-2.5 mt-2 flex justify-between items-baseline font-sans">
                      <span className="text-sm font-bold text-neutral-100">
                        工坊定制全包指导价:
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-black text-amber-400 font-mono">
                          ¥{pricing.suggested_retail_cny.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-neutral-500 block">
                          含专属定制实木证书 · 终身免费上门烫蜡保养
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Contact Commission Form */}
                <form onSubmit={handleSubmit} className="space-y-3 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-neutral-400 block mb-1">
                        贵宾尊称 (Name):
                      </label>
                      <input
                        type="text"
                        required
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                        placeholder="例如: 林先生 / 王女士"
                        className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-700 text-xs text-neutral-100 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-neutral-400 block mb-1">
                        联系电话 (Mobile / WeChat):
                      </label>
                      <input
                        type="tel"
                        required
                        value={clientPhone}
                        onChange={(e) => setClientPhone(e.target.value)}
                        placeholder="用于工坊木样寄送确认"
                        className="w-full px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-700 text-xs text-neutral-100 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-neutral-950 font-bold text-xs tracking-wider uppercase transition shadow-xl shadow-amber-950/40"
                  >
                    确认提交工坊定制委托 (Book Workshop Commission)
                  </button>
                </form>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
