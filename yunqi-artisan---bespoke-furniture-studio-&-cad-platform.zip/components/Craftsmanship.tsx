"use client";

import React, { useState } from "react";
import Image from "next/image";
import { TreePine, Hammer, Award, ArrowRight, ShieldCheck, CheckCircle2 } from "lucide-react";

export default function Craftsmanship() {
  const [activeTab, setActiveTab] = useState<number>(0);

  const pillars = [
    {
      titleCn: "甄选木材",
      titleEn: "Master Timber Selection",
      subtitle: "北美黑胡桃 / 红木 / 榉木 / 柚木",
      desc: "只挑选FAS特级原木，严控纹理连贯性。历经60天二次微波除湿窑干，含水率稳定在10%—12%，彻底避免变形开裂。",
      icon: TreePine,
    },
    {
      titleCn: "传统工艺",
      titleEn: "Mortise & Tenon Architecture",
      subtitle: "榫卯结构 · 手工打磨",
      desc: "一榫一卯相互咬合，利用木材天然受力与胀缩自锁。摒弃金属螺钉，纯手工刮刨推光至1500目，呈现丝绸般原木肌理。",
      icon: Hammer,
    },
    {
      titleCn: "匠心传承",
      titleEn: "Generational Heritage",
      subtitle: "三代工匠 · 精益求精",
      desc: "承袭明式文人家具典范，平均工龄超25年的老木匠亲自开料、画线、凿卯与天然植物蜂蜡烫蜡，件件皆具传家价值。",
      icon: Award,
    },
  ];

  return (
    <section id="craftsmanship" className="relative w-full py-20 px-4 sm:px-6 lg:px-8 bg-[#121110] text-neutral-200 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Craft Workshop Macro Photos */}
          <div className="lg:col-span-4 grid grid-cols-2 gap-4">
            <div className="relative aspect-[3/4] rounded-xl overflow-hidden border border-neutral-800 shadow-xl bg-neutral-900">
              <Image
                src="https://picsum.photos/seed/wood-carving-chisel/600/800"
                alt="Wood Carving Craft"
                fill
                className="object-cover object-center filter brightness-90 hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3">
                <span className="text-[11px] font-mono text-amber-300">手工凿卯放样</span>
              </div>
            </div>

            <div className="relative aspect-[3/4] rounded-xl overflow-hidden border border-neutral-800 shadow-xl bg-neutral-900 mt-6">
              <Image
                src="https://picsum.photos/seed/wood-joinery-corner/600/800"
                alt="Mortise Tenon Joint"
                fill
                className="object-cover object-center filter brightness-90 hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3">
                <span className="text-[11px] font-mono text-amber-300">粽角榫精密合角</span>
              </div>
            </div>
          </div>

          {/* Middle Column: Philosophy Text matching screenshot */}
          <div className="lg:col-span-4 space-y-4 px-2 lg:px-4">
            <span className="text-xs font-mono tracking-widest text-amber-500 uppercase">
              CRAFTSMANSHIP & PHILOSOPHY
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-neutral-100">
              匠心工艺
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 font-serif leading-relaxed">
              每一件家具，都是时间与技艺的结晶。
              <br />
              我们坚持选用优质木材，采用传统榫卯工艺，让东方美学在现代生活中焕发新生。
            </p>
            <div className="pt-2">
              <a
                href="#custom-studio"
                className="inline-flex items-center gap-2 text-xs font-bold text-amber-400 hover:text-amber-300 tracking-wider transition group"
              >
                <span>了解我们的工艺并进入定制</span>
                <ArrowRight className="w-4 h-4 transition transform group-hover:translate-x-1" />
              </a>
            </div>
          </div>

          {/* Right Column: Three Pillars matching screenshot icons */}
          <div className="lg:col-span-4 space-y-4">
            {pillars.map((p, idx) => {
              const Icon = p.icon;
              const isSelected = activeTab === idx;
              return (
                <div
                  key={idx}
                  onClick={() => setActiveTab(idx)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? "bg-neutral-900/90 border-amber-500/80 shadow-lg shadow-amber-950/40"
                      : "bg-neutral-950/60 border-neutral-850 hover:border-neutral-750"
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-neutral-100 font-serif">
                          {p.titleCn}
                        </h4>
                        <span className="text-[10px] font-mono text-neutral-500">
                          {p.titleEn}
                        </span>
                      </div>
                      <p className="text-xs text-amber-400/90 font-mono">
                        {p.subtitle}
                      </p>
                      <p className="text-xs text-neutral-400 leading-relaxed pt-1">
                        {p.desc}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
