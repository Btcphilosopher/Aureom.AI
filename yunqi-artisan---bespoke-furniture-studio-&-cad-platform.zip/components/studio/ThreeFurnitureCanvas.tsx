"use client";

import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { FurnitureTemplate, WoodSpecies } from "@/lib/types";
import { KotlinSpringConfig } from "@/lib/kotlin-animations";

interface ThreeFurnitureCanvasProps {
  template: FurnitureTemplate;
  dimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    topThicknessMm: number;
    legSizeMm: number;
  };
  wood: WoodSpecies;
  jointType: string;
  explodedPct: number; // 0 to 100
  wireframe: boolean;
  lightingMood: "zen" | "workshop" | "evening" | "clay";
  showDimensions: boolean;
  activeSpring: KotlinSpringConfig;
}

export default function ThreeFurnitureCanvas({
  template,
  dimensions,
  wood,
  jointType: _jointType,
  explodedPct,
  wireframe,
  lightingMood,
  showDimensions,
}: ThreeFurnitureCanvasProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const furnitureGroupRef = useRef<THREE.Group | null>(null);
  const partsRef = useRef<{ [key: string]: THREE.Object3D }>({});
  const animationFrameId = useRef<number | null>(null);

  // Orbit state
  const isDragging = useRef(false);
  const previousMousePosition = useRef({ x: 0, y: 0 });
  const cameraAngle = useRef({ theta: Math.PI / 4, phi: Math.PI / 3.2, radius: 2.8 });

  const [fps, setFps] = useState<number>(60);
  const lastFpsTime = useRef<number>(performance.now());
  const frameCount = useRef<number>(0);

  // Initialize Scene
  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color("#131211");

    // Camera
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    cameraRef.current = camera;
    updateCameraPosition();

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    rendererRef.current = renderer;

    container.innerHTML = "";
    container.appendChild(renderer.domElement);

    // Floor Grid & Shadow receiver
    const floorGeo = new THREE.PlaneGeometry(10, 10);
    const floorMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.005;
    floor.receiveShadow = true;
    scene.add(floor);

    // Grid helper
    const grid = new THREE.GridHelper(4, 20, 0x5a4a3a, 0x24201d);
    grid.position.y = 0;
    scene.add(grid);

    // Setup Lighting
    setupLighting(scene, lightingMood);

    // Build Furniture Group
    const furnitureGroup = new THREE.Group();
    furnitureGroupRef.current = furnitureGroup;
    scene.add(furnitureGroup);

    // Mouse Controls
    const onMouseDown = (e: MouseEvent) => {
      isDragging.current = true;
      previousMousePosition.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging.current) return;
      const deltaX = e.clientX - previousMousePosition.current.x;
      const deltaY = e.clientY - previousMousePosition.current.y;
      previousMousePosition.current = { x: e.clientX, y: e.clientY };

      cameraAngle.current.theta -= deltaX * 0.007;
      cameraAngle.current.phi = Math.max(0.1, Math.min(Math.PI / 2.05, cameraAngle.current.phi - deltaY * 0.007));
      updateCameraPosition();
    };

    const onMouseUp = () => {
      isDragging.current = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      cameraAngle.current.radius = Math.max(1.2, Math.min(6.0, cameraAngle.current.radius + e.deltaY * 0.002));
      updateCameraPosition();
    };

    container.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    container.addEventListener("wheel", onWheel, { passive: false });

    // Resize Observer
    const resizeObserver = new ResizeObserver(() => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      cameraRef.current.aspect = newW / newH;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    });
    resizeObserver.observe(container);

    // Render loop
    const animate = () => {
      animationFrameId.current = requestAnimationFrame(animate);

      // FPS counter
      frameCount.current++;
      const now = performance.now();
      if (now - lastFpsTime.current >= 1000) {
        setFps(frameCount.current);
        frameCount.current = 0;
        lastFpsTime.current = now;
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();

    return () => {
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
      resizeObserver.disconnect();
      container.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      container.removeEventListener("wheel", onWheel);
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAngle.current;
    const x = radius * Math.sin(phi) * Math.sin(theta);
    const y = radius * Math.cos(phi);
    const z = radius * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.position.set(x, y + 0.3, z);
    cameraRef.current.lookAt(0, 0.35, 0);
  };

  const setupLighting = (scene: THREE.Scene, mood: string) => {
    // Remove existing lights
    const toRemove: THREE.Object3D[] = [];
    scene.traverse((child) => {
      if (child instanceof THREE.Light) toRemove.push(child);
    });
    toRemove.forEach((l) => scene.remove(l));

    if (mood === "zen") {
      // Warm tea sunlight
      const ambient = new THREE.AmbientLight(0xfff5eb, 0.7);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xffeed6, 1.6);
      sun.position.set(2.5, 4.0, 2.0);
      sun.castShadow = true;
      sun.shadow.mapSize.width = 1024;
      sun.shadow.mapSize.height = 1024;
      sun.shadow.bias = -0.0005;
      scene.add(sun);

      const teaLamp = new THREE.PointLight(0xffaa55, 0.8, 5);
      teaLamp.position.set(-1.5, 1.2, -1.0);
      scene.add(teaLamp);
    } else if (mood === "workshop") {
      // Bright crisp studio craft lighting
      const ambient = new THREE.AmbientLight(0xffffff, 0.85);
      scene.add(ambient);

      const mainLight = new THREE.DirectionalLight(0xf5f8ff, 1.8);
      mainLight.position.set(3, 5, 2.5);
      mainLight.castShadow = true;
      scene.add(mainLight);

      const fill = new THREE.DirectionalLight(0xe8eef5, 1.0);
      fill.position.set(-3, 3, -2);
      scene.add(fill);
    } else if (mood === "evening") {
      // Dim candlelight / scholar lamp
      const ambient = new THREE.AmbientLight(0x2a201b, 0.5);
      scene.add(ambient);

      const lantern = new THREE.PointLight(0xff9944, 2.2, 4);
      lantern.position.set(0.8, 1.5, 0.8);
      lantern.castShadow = true;
      scene.add(lantern);

      const rim = new THREE.DirectionalLight(0x445577, 0.6);
      rim.position.set(-2, 2, -2);
      scene.add(rim);
    } else {
      // Clay CAD
      const ambient = new THREE.AmbientLight(0xffffff, 1.0);
      scene.add(ambient);
      const dir = new THREE.DirectionalLight(0xffffff, 1.0);
      dir.position.set(2, 4, 3);
      scene.add(dir);
    }
  };

  // Re-run lighting when mood changes
  useEffect(() => {
    if (sceneRef.current) {
      setupLighting(sceneRef.current, lightingMood);
    }
  }, [lightingMood]);

  // Re-build 3D Furniture Model when dimensions/wood/template/wireframe changes
  useEffect(() => {
    if (!furnitureGroupRef.current) return;
    const group = furnitureGroupRef.current;

    // Clear previous children
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => m.dispose());
        } else {
          child.material.dispose();
        }
      }
    }
    partsRef.current = {};

    // Create Wood Material with Procedural Grain Look
    const woodColor = new THREE.Color(wood.colorHex);
    const material = wireframe
      ? new THREE.MeshBasicMaterial({ color: 0x38bdf8, wireframe: true })
      : lightingMood === "clay"
      ? new THREE.MeshStandardMaterial({ color: 0xd6cec3, roughness: 0.8, metalness: 0.05 })
      : new THREE.MeshStandardMaterial({
          color: woodColor,
          roughness: 0.38,
          metalness: 0.08,
          envMapIntensity: 0.85,
        });

    const brassMaterial = new THREE.MeshStandardMaterial({
      color: 0xc49e65,
      roughness: 0.25,
      metalness: 0.85,
    });

    const scale = 0.001; // mm to meters
    const L = dimensions.lengthMm * scale;
    const W = dimensions.widthMm * scale;
    const H = dimensions.heightMm * scale;
    const T = dimensions.topThicknessMm * scale;
    const legSize = dimensions.legSizeMm * scale;
    const apronHeight = 0.075;
    const apronThick = 0.026;
    const legH = H - T;

    if (template.category === "tea_table" || template.category === "console") {
      // 1. Tabletop
      const topGeo = new THREE.BoxGeometry(L, T, W);
      const topMesh = new THREE.Mesh(topGeo, material);
      topMesh.position.set(0, H - T / 2, 0);
      topMesh.castShadow = true;
      topMesh.receiveShadow = true;
      group.add(topMesh);
      partsRef.current["top"] = topMesh;

      // Tea table water tray inlay (brass/stone)
      if (template.category === "tea_table") {
        const trayGeo = new THREE.BoxGeometry(L * 0.45, 0.006, W * 0.4);
        const trayMesh = new THREE.Mesh(trayGeo, brassMaterial);
        trayMesh.position.set(0, H + 0.003, 0);
        trayMesh.castShadow = true;
        group.add(trayMesh);
        partsRef.current["tray"] = trayMesh;
      }

      // 2. Four Legs
      const legPositions = [
        { id: "leg_fl", x: -L / 2 + legSize / 2 + 0.015, z: W / 2 - legSize / 2 - 0.015 },
        { id: "leg_fr", x: L / 2 - legSize / 2 - 0.015, z: W / 2 - legSize / 2 - 0.015 },
        { id: "leg_bl", x: -L / 2 + legSize / 2 + 0.015, z: -W / 2 + legSize / 2 + 0.015 },
        { id: "leg_br", x: L / 2 - legSize / 2 - 0.015, z: -W / 2 + legSize / 2 + 0.015 },
      ];

      legPositions.forEach((pos) => {
        const legGeo = new THREE.BoxGeometry(legSize, legH, legSize);
        const legMesh = new THREE.Mesh(legGeo, material);
        legMesh.position.set(pos.x, legH / 2, pos.z);
        legMesh.castShadow = true;
        legMesh.receiveShadow = true;
        group.add(legMesh);
        partsRef.current[pos.id] = legMesh;

        // Brass foot sleeve (铜马蹄靴)
        const footGeo = new THREE.BoxGeometry(legSize * 1.02, 0.025, legSize * 1.02);
        const footMesh = new THREE.Mesh(footGeo, brassMaterial);
        footMesh.position.set(pos.x, 0.0125, pos.z);
        group.add(footMesh);
        partsRef.current[`${pos.id}_foot`] = footMesh;
      });

      // 3. Aprons (Longitudinal & Transverse)
      const apronY = H - T - apronHeight / 2;
      const innerL = L - 2 * legSize - 0.03;
      const innerW = W - 2 * legSize - 0.03;

      // Front apron
      const frontApronGeo = new THREE.BoxGeometry(innerL, apronHeight, apronThick);
      const frontApronMesh = new THREE.Mesh(frontApronGeo, material);
      frontApronMesh.position.set(0, apronY, W / 2 - apronThick / 2 - 0.015);
      frontApronMesh.castShadow = true;
      group.add(frontApronMesh);
      partsRef.current["apron_f"] = frontApronMesh;

      // Back apron
      const backApronMesh = new THREE.Mesh(frontApronGeo, material);
      backApronMesh.position.set(0, apronY, -W / 2 + apronThick / 2 + 0.015);
      backApronMesh.castShadow = true;
      group.add(backApronMesh);
      partsRef.current["apron_b"] = backApronMesh;

      // Left apron
      const sideApronGeo = new THREE.BoxGeometry(apronThick, apronHeight, innerW);
      const leftApronMesh = new THREE.Mesh(sideApronGeo, material);
      leftApronMesh.position.set(-L / 2 + apronThick / 2 + 0.015, apronY, 0);
      leftApronMesh.castShadow = true;
      group.add(leftApronMesh);
      partsRef.current["apron_l"] = leftApronMesh;

      // Right apron
      const rightApronMesh = new THREE.Mesh(sideApronGeo, material);
      rightApronMesh.position.set(L / 2 - apronThick / 2 - 0.015, apronY, 0);
      rightApronMesh.castShadow = true;
      group.add(rightApronMesh);
      partsRef.current["apron_r"] = rightApronMesh;

      // 4. Underside sliding dovetail cleats (穿带)
      const cleatCount = 3;
      for (let i = 0; i < cleatCount; i++) {
        const cleatGeo = new THREE.BoxGeometry(0.045, 0.03, W * 0.8);
        const cleatMesh = new THREE.Mesh(cleatGeo, material);
        const cx = (i - 1) * (L * 0.28);
        cleatMesh.position.set(cx, H - T - 0.015, 0);
        group.add(cleatMesh);
        partsRef.current[`cleat_${i}`] = cleatMesh;
      }
    } else if (template.category === "armchair") {
      // Ming Dynasty Official's Hat Chair
      const seatH = 0.48;
      const seatGeo = new THREE.BoxGeometry(L, 0.03, W);
      const seatMesh = new THREE.Mesh(seatGeo, material);
      seatMesh.position.set(0, seatH, 0);
      seatMesh.castShadow = true;
      group.add(seatMesh);
      partsRef.current["seat"] = seatMesh;

      // Legs
      const chairLegH = seatH;
      const lpos = [
        { id: "leg_fl", x: -L / 2 + 0.025, z: W / 2 - 0.025 },
        { id: "leg_fr", x: L / 2 - 0.025, z: W / 2 - 0.025 },
        { id: "leg_bl", x: -L / 2 + 0.025, z: -W / 2 + 0.025 },
        { id: "leg_br", x: L / 2 - 0.025, z: -W / 2 + 0.025 },
      ];
      lpos.forEach((p) => {
        const legGeo = new THREE.CylinderGeometry(0.02, 0.022, chairLegH, 16);
        const legMesh = new THREE.Mesh(legGeo, material);
        legMesh.position.set(p.x, chairLegH / 2, p.z);
        legMesh.castShadow = true;
        group.add(legMesh);
        partsRef.current[p.id] = legMesh;
      });

      // Curved Backrest Splat (S形靠背板)
      const splatGeo = new THREE.BoxGeometry(0.18, H - seatH, 0.022);
      const splatMesh = new THREE.Mesh(splatGeo, material);
      splatMesh.position.set(0, seatH + (H - seatH) / 2, -W / 2 + 0.035);
      splatMesh.rotation.x = -0.06;
      splatMesh.castShadow = true;
      group.add(splatMesh);
      partsRef.current["splat"] = splatMesh;

      // Crest Rail (搭脑)
      const crestGeo = new THREE.BoxGeometry(L * 1.25, 0.04, 0.04);
      const crestMesh = new THREE.Mesh(crestGeo, material);
      crestMesh.position.set(0, H, -W / 2 + 0.03);
      crestMesh.castShadow = true;
      group.add(crestMesh);
      partsRef.current["crest"] = crestMesh;

      // Armrests (扶手)
      const armGeo = new THREE.BoxGeometry(0.035, 0.035, W * 0.95);
      const leftArm = new THREE.Mesh(armGeo, material);
      leftArm.position.set(-L / 2 + 0.025, seatH + 0.22, 0);
      group.add(leftArm);
      partsRef.current["arm_l"] = leftArm;

      const rightArm = new THREE.Mesh(armGeo, material);
      rightArm.position.set(L / 2 - 0.025, seatH + 0.22, 0);
      group.add(rightArm);
      partsRef.current["arm_r"] = rightArm;
    } else if (template.category === "daybed") {
      // Luohan Daybed
      const bedH = 0.45;
      const platformGeo = new THREE.BoxGeometry(L, 0.06, W);
      const platformMesh = new THREE.Mesh(platformGeo, material);
      platformMesh.position.set(0, bedH, 0);
      platformMesh.castShadow = true;
      group.add(platformMesh);
      partsRef.current["platform"] = platformMesh;

      // 4 Heavy Legs
      const bedLegs = [
        { id: "leg_fl", x: -L / 2 + legSize / 2, z: W / 2 - legSize / 2 },
        { id: "leg_fr", x: L / 2 - legSize / 2, z: W / 2 - legSize / 2 },
        { id: "leg_bl", x: -L / 2 + legSize / 2, z: -W / 2 + legSize / 2 },
        { id: "leg_br", x: L / 2 - legSize / 2, z: -W / 2 + legSize / 2 },
      ];
      bedLegs.forEach((p) => {
        const legGeo = new THREE.BoxGeometry(legSize, bedH, legSize);
        const legMesh = new THREE.Mesh(legGeo, material);
        legMesh.position.set(p.x, bedH / 2, p.z);
        legMesh.castShadow = true;
        group.add(legMesh);
        partsRef.current[p.id] = legMesh;
      });

      // 3-sided Railing (三面围子)
      const railH = H - bedH;
      // Back railing
      const backRailGeo = new THREE.BoxGeometry(L, railH, 0.035);
      const backRail = new THREE.Mesh(backRailGeo, material);
      backRail.position.set(0, bedH + railH / 2, -W / 2 + 0.02);
      backRail.castShadow = true;
      group.add(backRail);
      partsRef.current["rail_b"] = backRail;

      // Side railings
      const sideRailGeo = new THREE.BoxGeometry(0.035, railH, W - 0.04);
      const leftRail = new THREE.Mesh(sideRailGeo, material);
      leftRail.position.set(-L / 2 + 0.02, bedH + railH / 2, 0);
      leftRail.castShadow = true;
      group.add(leftRail);
      partsRef.current["rail_l"] = leftRail;

      const rightRail = new THREE.Mesh(sideRailGeo, material);
      rightRail.position.set(L / 2 - 0.02, bedH + railH / 2, 0);
      rightRail.castShadow = true;
      group.add(rightRail);
      partsRef.current["rail_r"] = rightRail;
    } else {
      // Credenza / Round corner cabinet
      const bodyH = H - 0.15;
      const cabGeo = new THREE.BoxGeometry(L, bodyH, W);
      const cabMesh = new THREE.Mesh(cabGeo, material);
      cabMesh.position.set(0, 0.15 + bodyH / 2, 0);
      cabMesh.castShadow = true;
      group.add(cabMesh);
      partsRef.current["body"] = cabMesh;

      // Brass round door faceplate (铜面页)
      const brassPlateGeo = new THREE.CylinderGeometry(0.065, 0.065, 0.005, 32);
      const brassPlate = new THREE.Mesh(brassPlateGeo, brassMaterial);
      brassPlate.rotation.x = Math.PI / 2;
      brassPlate.position.set(0, 0.15 + bodyH / 2, W / 2 + 0.004);
      group.add(brassPlate);
      partsRef.current["plate"] = brassPlate;

      // Base Stand
      const standGeo = new THREE.BoxGeometry(L * 0.95, 0.15, W * 0.95);
      const standMesh = new THREE.Mesh(standGeo, material);
      standMesh.position.set(0, 0.075, 0);
      standMesh.castShadow = true;
      group.add(standMesh);
      partsRef.current["stand"] = standMesh;
    }

    // Dimension Helpers
    if (showDimensions) {
      const dimGroup = new THREE.Group();
      const lineMat = new THREE.LineBasicMaterial({ color: 0xc49e65 });

      // Length line
      const lPts = [
        new THREE.Vector3(-L / 2, H + 0.08, W / 2 + 0.05),
        new THREE.Vector3(L / 2, H + 0.08, W / 2 + 0.05),
      ];
      const lGeo = new THREE.BufferGeometry().setFromPoints(lPts);
      const lLine = new THREE.Line(lGeo, lineMat);
      dimGroup.add(lLine);

      group.add(dimGroup);
    }
  }, [dimensions, wood, template, wireframe, lightingMood, showDimensions]);

  // Handle Exploded View animation slider (Separating mortise & tenon joints in 3D)
  useEffect(() => {
    const p = partsRef.current;
    if (!p) return;
    const factor = explodedPct / 100;

    // Tabletop lifts upwards
    if (p["top"]) {
      p["top"].position.y = (dimensions.heightMm - dimensions.topThicknessMm / 2) * 0.001 + factor * 0.45;
    }
    if (p["tray"]) {
      p["tray"].position.y = (dimensions.heightMm + 3) * 0.001 + factor * 0.52;
    }

    // Legs move diagonally outward
    const legOffset = factor * 0.28;
    if (p["leg_fl"]) {
      p["leg_fl"].position.x = (-dimensions.lengthMm / 2 + dimensions.legSizeMm / 2 + 15) * 0.001 - legOffset;
      p["leg_fl"].position.z = (dimensions.widthMm / 2 - dimensions.legSizeMm / 2 - 15) * 0.001 + legOffset;
    }
    if (p["leg_fr"]) {
      p["leg_fr"].position.x = (dimensions.lengthMm / 2 - dimensions.legSizeMm / 2 - 15) * 0.001 + legOffset;
      p["leg_fr"].position.z = (dimensions.widthMm / 2 - dimensions.legSizeMm / 2 - 15) * 0.001 + legOffset;
    }
    if (p["leg_bl"]) {
      p["leg_bl"].position.x = (-dimensions.lengthMm / 2 + dimensions.legSizeMm / 2 + 15) * 0.001 - legOffset;
      p["leg_bl"].position.z = (-dimensions.widthMm / 2 + dimensions.legSizeMm / 2 + 15) * 0.001 - legOffset;
    }
    if (p["leg_br"]) {
      p["leg_br"].position.x = (dimensions.lengthMm / 2 - dimensions.legSizeMm / 2 - 15) * 0.001 + legOffset;
      p["leg_br"].position.z = (-dimensions.widthMm / 2 + dimensions.legSizeMm / 2 + 15) * 0.001 - legOffset;
    }

    // Aprons push outwards
    const apronOffset = factor * 0.22;
    if (p["apron_f"]) {
      p["apron_f"].position.z = (dimensions.widthMm / 2 - 28) * 0.001 + apronOffset;
    }
    if (p["apron_b"]) {
      p["apron_b"].position.z = (-dimensions.widthMm / 2 + 28) * 0.001 - apronOffset;
    }
    if (p["apron_l"]) {
      p["apron_l"].position.x = (-dimensions.lengthMm / 2 + 28) * 0.001 - apronOffset;
    }
    if (p["apron_r"]) {
      p["apron_r"].position.x = (dimensions.lengthMm / 2 - 28) * 0.001 + apronOffset;
    }

    // Cleats drop slightly down
    for (let i = 0; i < 3; i++) {
      if (p[`cleat_${i}`]) {
        p[`cleat_${i}`].position.y = (dimensions.heightMm - dimensions.topThicknessMm - 15) * 0.001 - factor * 0.2;
      }
    }
  }, [explodedPct, dimensions]);

  return (
    <div className="relative w-full h-full min-h-[460px] bg-[#121110] rounded-xl overflow-hidden select-none border border-neutral-800">
      {/* 3D Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating 3D Overlays */}
      <div className="absolute top-4 left-4 flex items-center gap-2 pointer-events-none">
        <div className="px-2.5 py-1 rounded-md bg-neutral-900/80 backdrop-blur-md border border-neutral-700/60 text-xs font-mono text-amber-200/90 flex items-center gap-1.5 shadow-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          WebGL 60FPS · Three.js
        </div>
        <div className="px-2.5 py-1 rounded-md bg-neutral-900/80 backdrop-blur-md border border-neutral-700/60 text-xs font-mono text-neutral-300">
          FPS: {fps}
        </div>
      </div>

      {/* Interaction Hint Overlay */}
      <div className="absolute bottom-3 left-3 text-[11px] text-neutral-400/80 bg-neutral-950/70 backdrop-blur-sm px-2.5 py-1 rounded border border-neutral-800/80 pointer-events-none">
        按住左键旋转 · 滚轮缩放 · 右键平移
      </div>

      {/* Exploded View Status Tag */}
      {explodedPct > 0 && (
        <div className="absolute top-4 right-4 px-3 py-1.5 rounded-lg bg-amber-950/80 backdrop-blur-md border border-amber-600/40 text-xs font-medium text-amber-300 shadow-xl flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping" />
          <span>榫卯三维爆炸分解: {explodedPct}%</span>
        </div>
      )}
    </div>
  );
}
