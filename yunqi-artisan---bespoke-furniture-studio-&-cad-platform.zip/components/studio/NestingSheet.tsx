"use client";

import React, { useState } from "react";
import { RustCalculationResult } from "@/lib/types";
import { Cpu, Layers, Scissors, Info, CheckCircle2, TrendingUp } from "lucide-react";

interface NestingSheetProps {
  rustData: RustCalculationResult | null;
  loading: boolean;
}

export default function NestingSheet({ rustData, loading }: NestingSheetProps) {
  const [selectedBoard, setSelectedBoard] = useState<number>(0);
  const [hoveredPart, setHoveredPart] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[460px] bg-[#141210] rounded-xl border border-neutral-800 text-neutral-400 p-8">
        <Cpu className="w-10 h-10 text-amber-500 animate-spin mb-3" />
        <p className="text-sm font-medium text-amber-200">Rust 2D Guillotine 切割排版算法优化中...</p>
        <p className="text-xs text-neutral-500 mt-1">计算出材率、锯缝裕量(Kerf)与大板损耗</p>
      </div>
    );
  }

  if (!rustData) {
    return null;
  }

  const { nesting, metrics, cut_list } = rustData;
  const totalSlabs = nesting.total_slabs || 1;

  // Filter parts for selected board
  const boardParts = nesting.placements.filter((p) => p.board_index === selectedBoard);

  // Group part types for color-coding
  const getPartColor = (partId: string) => {
    if (partId.includes("TOP")) return { bg: "bg-amber-800/80", border: "border-amber-400", hex: "#92400e" };
    if (partId.includes("LEGS")) return { bg: "bg-orange-800/80", border: "border-orange-400", hex: "#9a3412" };
    if (partId.includes("APRON")) return { bg: "bg-emerald-800/80", border: "border-emerald-400", hex: "#065f46" };
    if (partId.includes("CLEAT")) return { bg: "bg-cyan-800/80", border: "border-cyan-400", hex: "#155e75" };
    return { bg: "bg-purple-800/80", border: "border-purple-400", hex: "#6b21a8" };
  };

  return (
    <div className="flex flex-col h-full bg-[#141211] rounded-xl border border-neutral-800 overflow-hidden shadow-2xl">
      {/* Top Header & Analytics Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-neutral-900/90 border-b border-neutral-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-neutral-100">
                原木板材下料排版系统 (Flat-sheet Nesting)
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                Rust 2D Guillotine 优化
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              标准FAS级原木板规格: {nesting.slab_length_mm} x {nesting.slab_width_mm} mm · 锯片损耗: {nesting.kerf_mm}mm
            </p>
          </div>
        </div>

        {/* Metrics Badges */}
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center gap-2">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-neutral-400">出材率 (Yield):</span>
            <span className="text-emerald-400 font-bold text-sm">{metrics.yield_efficiency_pct}%</span>
          </div>

          <div className="px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center gap-2">
            <Scissors className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-neutral-400">边角余料:</span>
            <span className="text-amber-400 font-bold">{metrics.waste_pct}%</span>
          </div>

          <div className="px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center gap-2">
            <span className="text-neutral-400">需用毛料板:</span>
            <span className="text-neutral-200 font-bold">{totalSlabs} 块</span>
          </div>
        </div>
      </div>

      {/* Board Selector Tabs */}
      <div className="flex items-center gap-1.5 px-4 py-2.5 bg-neutral-950 border-b border-neutral-800 overflow-x-auto">
        <span className="text-xs text-neutral-500 mr-2 flex items-center gap-1">
          <Info className="w-3 h-3" /> 板材切换:
        </span>
        {Array.from({ length: totalSlabs }).map((_, idx) => {
          const count = nesting.placements.filter((p) => p.board_index === idx).length;
          const isSelected = selectedBoard === idx;
          return (
            <button
              key={idx}
              onClick={() => setSelectedBoard(idx)}
              className={`px-3 py-1 rounded text-xs font-medium transition flex items-center gap-1.5 ${
                isSelected
                  ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/30"
                  : "bg-neutral-900 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-850 border border-neutral-800"
              }`}
            >
              <span>板料 #{idx + 1}</span>
              <span className={`text-[10px] px-1 rounded ${isSelected ? "bg-amber-900/40 text-neutral-950" : "bg-neutral-800 text-neutral-400"}`}>
                {count}件
              </span>
            </button>
          );
        })}
      </div>

      {/* Visual Canvas of Selected Rough Slab */}
      <div className="flex-1 p-6 flex flex-col justify-center items-center bg-[#0d0c0b] overflow-auto">
        <div className="w-full max-w-5xl">
          {/* Slab Header */}
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
            <span className="font-mono">原木毛料板 #{selectedBoard + 1} (FAS级 烘干直拼材)</span>
            <span className="font-mono text-neutral-500">
              长度: 2440mm · 宽度: 220mm · 厚度: 45mm
            </span>
          </div>

          {/* SVG representation of the raw board */}
          <div className="relative w-full bg-[#2a1e16] border-2 border-amber-900/70 rounded-lg p-2 shadow-2xl">
            {/* Wood Grain subtle SVG pattern */}
            <svg
              viewBox="0 0 2440 220"
              className="w-full h-auto bg-[#382318] rounded border border-amber-800/50 shadow-inner"
            >
              <defs>
                {/* Wood growth rings background */}
                <linearGradient id="roughWood" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3d271c" />
                  <stop offset="50%" stopColor="#4a3022" />
                  <stop offset="100%" stopColor="#3d271c" />
                </linearGradient>
              </defs>

              <rect width="2440" height="220" fill="url(#roughWood)" />

              {/* Placed Parts on this board */}
              {boardParts.map((part) => {
                const color = getPartColor(part.part_id);
                const isHovered = hoveredPart === part.part_id;

                return (
                  <g
                    key={part.part_id}
                    onMouseEnter={() => setHoveredPart(part.part_id)}
                    onMouseLeave={() => setHoveredPart(null)}
                    className="cursor-pointer transition-all"
                  >
                    {/* Part Rectangle */}
                    <rect
                      x={part.x}
                      y={part.y}
                      width={part.width}
                      height={part.height}
                      fill={color.hex}
                      stroke={isHovered ? "#38bdf8" : "#fef08a"}
                      strokeWidth={isHovered ? "3" : "1.5"}
                      opacity={isHovered ? 1 : 0.9}
                      rx="2"
                    />

                    {/* Part Label */}
                    <text
                      x={part.x + part.width / 2}
                      y={part.y + part.height / 2 + 4}
                      fill="#ffffff"
                      fontSize="14"
                      fontWeight="bold"
                      textAnchor="middle"
                      fontFamily="monospace"
                      pointerEvents="none"
                    >
                      {part.part_id} ({Math.round(part.width)}x{Math.round(part.height)})
                    </text>
                  </g>
                );
              })}

              {/* Kerf saw cut guidelines */}
              {boardParts.map((part, i) => (
                <line
                  key={`kerf-${i}`}
                  x1={part.x + part.width}
                  y1={part.y}
                  x2={part.x + part.width}
                  y2={part.y + part.height}
                  stroke="#ef4444"
                  strokeWidth="2"
                  strokeDasharray="4,2"
                />
              ))}
            </svg>
          </div>

          {/* Color Legend & Part Info */}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs bg-neutral-900/60 p-3 rounded-lg border border-neutral-800">
            <div className="flex flex-wrap items-center gap-4">
              <span className="text-neutral-400">下料构件图例:</span>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-amber-700 border border-amber-400" />
                <span className="text-neutral-300">台面拼板 (Top)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-orange-700 border border-orange-400" />
                <span className="text-neutral-300">腿足方材 (Legs)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-emerald-700 border border-emerald-400" />
                <span className="text-neutral-300">牙条拉带 (Aprons)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-cyan-700 border border-cyan-400" />
                <span className="text-neutral-300">防翘穿带 (Cleats)</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-neutral-400">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>锯缝补偿: 3.5mm · 开料净公差: 0.5mm</span>
            </div>
          </div>
        </div>
      </div>

      {/* Part Inspector Drawer */}
      {hoveredPart && (
        <div className="bg-amber-950/80 border-t border-amber-700/40 px-4 py-2 flex items-center justify-between text-xs text-amber-200">
          <span className="font-mono font-bold">选中构件: {hoveredPart}</span>
          <span>
            {cut_list.find((c) => hoveredPart.startsWith(c.part_id))?.name_cn} ·{" "}
            {cut_list.find((c) => hoveredPart.startsWith(c.part_id))?.joinery_notes}
          </span>
        </div>
      )}
    </div>
  );
}
