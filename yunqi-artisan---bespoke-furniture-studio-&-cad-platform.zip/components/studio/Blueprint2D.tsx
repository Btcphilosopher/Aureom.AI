"use client";

import React, { useRef } from "react";
import { FurnitureTemplate, WoodSpecies } from "@/lib/types";
import { Download, Printer, ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

interface Blueprint2DProps {
  template: FurnitureTemplate;
  dimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    topThicknessMm: number;
    legSizeMm: number;
  };
  wood: WoodSpecies;
  jointType: string;
}

export default function Blueprint2D({
  template,
  dimensions,
  wood,
  jointType,
}: Blueprint2DProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [zoom, setZoom] = React.useState(1);

  const L = dimensions.lengthMm;
  const W = dimensions.widthMm;
  const H = dimensions.heightMm;
  const T = dimensions.topThicknessMm;
  const Leg = dimensions.legSizeMm;
  const ApronH = 75;

  const handleDownloadSvg = () => {
    if (!svgRef.current) return;
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Yunqi_Blueprint_${template.id}_${L}x${W}x${H}mm.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a1420] text-sky-100 rounded-xl border border-sky-900/50 overflow-hidden shadow-2xl">
      {/* Blueprint Toolbar */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#0d1d30] border-b border-sky-900/40 text-xs">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="font-mono text-cyan-300 font-semibold uppercase tracking-wider">
            FLATFORM CAD 2D · 正投影三视图工程图纸 (1:10)
          </span>
          <span className="text-sky-400/60 hidden sm:inline">|</span>
          <span className="text-sky-300/80 hidden sm:inline">
            公差: ±0.2mm · 榫眼深浅标定
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom((z) => Math.max(0.7, z - 0.1))}
            className="p-1.5 rounded bg-sky-950 hover:bg-sky-900 border border-sky-800/60 text-sky-300 transition"
            title="缩小"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoom((z) => Math.min(1.5, z + 0.1))}
            className="p-1.5 rounded bg-sky-950 hover:bg-sky-900 border border-sky-800/60 text-sky-300 transition"
            title="放大"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoom(1)}
            className="p-1.5 rounded bg-sky-950 hover:bg-sky-900 border border-sky-800/60 text-sky-300 transition"
            title="重置比例"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleDownloadSvg}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-medium transition shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出矢量图纸 (SVG)</span>
          </button>
        </div>
      </div>

      {/* SVG Canvas Workspace */}
      <div className="flex-1 overflow-auto p-4 sm:p-8 bg-blueprint-grid flex items-center justify-center min-h-[500px]">
        <div
          style={{ transform: `scale(${zoom})`, transformOrigin: "center center" }}
          className="transition-transform duration-200"
        >
          <svg
            ref={svgRef}
            viewBox="0 0 1100 750"
            className="w-[950px] h-[650px] bg-[#0c1929] border-2 border-cyan-500/60 shadow-2xl rounded"
          >
            {/* Grid Pattern in SVG */}
            <defs>
              <pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(34, 211, 238, 0.08)" strokeWidth="0.5" />
              </pattern>
              <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
                <rect width="100" height="100" fill="url(#smallGrid)" />
                <path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(34, 211, 238, 0.18)" strokeWidth="1" />
              </pattern>
              {/* Marker arrows */}
              <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#38bdf8" />
              </marker>
            </defs>

            <rect width="100%" height="100%" fill="url(#grid)" />

            {/* Inner Border Frame */}
            <rect x="20" y="20" width="1060" height="710" fill="none" stroke="#0284c7" strokeWidth="1.5" />
            <rect x="25" y="25" width="1050" height="700" fill="none" stroke="#0369a1" strokeWidth="0.75" />

            {/* 1. VIEW A: FRONT ELEVATION (正立面图) */}
            <g transform="translate(80, 110)">
              {/* Title */}
              <text x="0" y="-30" fill="#38bdf8" fontSize="13" fontWeight="bold" fontFamily="monospace">
                A. 正立面图 (FRONT ELEVATION) · 比例 1:10
              </text>

              {/* Front Drawing Scaled (factor: 0.22) */}
              {(() => {
                const s = 0.22;
                const sw = L * s;
                const sh = H * s;
                const st = T * s;
                const sLeg = Leg * s;
                const sApron = ApronH * s;

                return (
                  <g>
                    {/* Tabletop */}
                    <rect
                      x="0"
                      y="0"
                      width={sw}
                      height={st}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="2"
                    />
                    {/* Wood grain lines inside top */}
                    <line x1="10" y1={st / 2} x2={sw - 10} y2={st / 2} stroke="#0284c7" strokeDasharray="6,4" strokeWidth="0.75" />

                    {/* Left Leg */}
                    <rect
                      x="8"
                      y={st}
                      width={sLeg}
                      height={sh - st}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="1.5"
                    />
                    {/* Right Leg */}
                    <rect
                      x={sw - sLeg - 8}
                      y={st}
                      width={sLeg}
                      height={sh - st}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="1.5"
                    />

                    {/* Apron Rail */}
                    <rect
                      x={sLeg + 8}
                      y={st}
                      width={sw - 2 * sLeg - 16}
                      height={sApron}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="1.2"
                    />

                    {/* Mortise tenon hidden dashed lines */}
                    <rect
                      x="4"
                      y={st + 5}
                      width={sLeg + 8}
                      height={sApron - 10}
                      fill="none"
                      stroke="#e0f2fe"
                      strokeWidth="0.75"
                      strokeDasharray="3,3"
                    />
                    <rect
                      x={sw - sLeg - 12}
                      y={st + 5}
                      width={sLeg + 8}
                      height={sApron - 10}
                      fill="none"
                      stroke="#e0f2fe"
                      strokeWidth="0.75"
                      strokeDasharray="3,3"
                    />

                    {/* Dimension: Total Length */}
                    <line x1="0" y1="-14" x2={sw} y2="-14" stroke="#38bdf8" strokeWidth="1" markerStart="url(#arrow)" markerEnd="url(#arrow)" />
                    <text x={sw / 2} y="-18" fill="#e0f2fe" fontSize="11" textAnchor="middle" fontFamily="monospace">
                      长 L = {L} mm
                    </text>

                    {/* Dimension: Total Height */}
                    <line x1={sw + 25} y1="0" x2={sw + 25} y2={sh} stroke="#38bdf8" strokeWidth="1" markerStart="url(#arrow)" markerEnd="url(#arrow)" />
                    <text x={sw + 32} y={sh / 2} fill="#e0f2fe" fontSize="11" textAnchor="start" fontFamily="monospace">
                      高 H = {H} mm
                    </text>

                    {/* Dimension: Top Thickness */}
                    <line x1="-20" y1="0" x2="-20" y2={st} stroke="#38bdf8" strokeWidth="0.75" markerStart="url(#arrow)" markerEnd="url(#arrow)" />
                    <text x="-26" y={st / 2 + 3} fill="#e0f2fe" fontSize="9" textAnchor="end" fontFamily="monospace">
                      T={T}
                    </text>
                  </g>
                );
              })()}
            </g>

            {/* 2. VIEW B: SIDE ELEVATION (侧立面图) */}
            <g transform="translate(680, 110)">
              <text x="0" y="-30" fill="#38bdf8" fontSize="13" fontWeight="bold" fontFamily="monospace">
                B. 侧立面图 (SIDE ELEVATION)
              </text>
              {(() => {
                const s = 0.22;
                const sWid = W * s;
                const sh = H * s;
                const st = T * s;
                const sLeg = Leg * s;
                const sApron = ApronH * s;

                return (
                  <g>
                    {/* Top */}
                    <rect x="0" y="0" width={sWid} height={st} fill="none" stroke="#38bdf8" strokeWidth="2" />

                    {/* Left Leg */}
                    <rect x="6" y={st} width={sLeg} height={sh - st} fill="none" stroke="#38bdf8" strokeWidth="1.5" />
                    {/* Right Leg */}
                    <rect x={sWid - sLeg - 6} y={st} width={sLeg} height={sh - st} fill="none" stroke="#38bdf8" strokeWidth="1.5" />

                    {/* Short Apron Rail */}
                    <rect x={sLeg + 6} y={st} width={sWid - 2 * sLeg - 12} height={sApron} fill="none" stroke="#38bdf8" strokeWidth="1.2" />

                    {/* Dimension: Width */}
                    <line x1="0" y1="-14" x2={sWid} y2="-14" stroke="#38bdf8" strokeWidth="1" markerStart="url(#arrow)" markerEnd="url(#arrow)" />
                    <text x={sWid / 2} y="-18" fill="#e0f2fe" fontSize="11" textAnchor="middle" fontFamily="monospace">
                      宽 W = {W} mm
                    </text>

                    {/* Leg Size */}
                    <text x={sWid / 2} y={sh + 18} fill="#93c5fd" fontSize="9" textAnchor="middle" fontFamily="monospace">
                      方腿断面: {Leg}x{Leg} mm
                    </text>
                  </g>
                );
              })()}
            </g>

            {/* 3. VIEW C: PLAN / TOP VIEW (顶视俯视图) */}
            <g transform="translate(80, 390)">
              <text x="0" y="-20" fill="#38bdf8" fontSize="13" fontWeight="bold" fontFamily="monospace">
                C. 顶面俯视图 (PLAN VIEW) · 拼板纹理与穿带伸缩缝
              </text>
              {(() => {
                const s = 0.22;
                const sw = L * s;
                const sWid = W * s;
                const boards = 4;
                const boardH = sWid / boards;

                return (
                  <g>
                    {/* Outer Top Plate */}
                    <rect x="0" y="0" width={sw} height={sWid} fill="none" stroke="#38bdf8" strokeWidth="2" />

                    {/* Edge-glued board lines */}
                    {Array.from({ length: boards - 1 }).map((_, i) => (
                      <line
                        key={i}
                        x1="0"
                        y1={(i + 1) * boardH}
                        x2={sw}
                        y2={(i + 1) * boardH}
                        stroke="#0284c7"
                        strokeDasharray="4,2"
                        strokeWidth="0.8"
                      />
                    ))}

                    {/* Hidden sliding dovetail cleats (穿带) underneath */}
                    {[sw * 0.25, sw * 0.5, sw * 0.75].map((cx, idx) => (
                      <rect
                        key={idx}
                        x={cx - 5}
                        y="8"
                        width="10"
                        height={sWid - 16}
                        fill="none"
                        stroke="#f59e0b"
                        strokeWidth="1"
                        strokeDasharray="3,3"
                      />
                    ))}

                    {/* Grain Direction Indicator Arrow */}
                    <line x1="20" y1={sWid / 2} x2="120" y2={sWid / 2} stroke="#38bdf8" strokeWidth="1" markerEnd="url(#arrow)" />
                    <text x="130" y={sWid / 2 + 3} fill="#93c5fd" fontSize="9" fontFamily="monospace">
                      主木材纵向顺纹 (Longitudinal Grain)
                    </text>

                    <text x={sw - 120} y={sWid - 12} fill="#f59e0b" fontSize="8" fontFamily="monospace">
                      [--- 燕尾穿带暗槽 ---]
                    </text>
                  </g>
                );
              })()}
            </g>

            {/* ENGINEERING TITLE BLOCK (图纸标牌) */}
            <g transform="translate(620, 520)">
              <rect x="0" y="0" width="440" height="190" fill="#091424" stroke="#0284c7" strokeWidth="1.5" />
              <line x1="0" y1="40" x2="440" y2="40" stroke="#0284c7" strokeWidth="1" />
              <line x1="0" y1="80" x2="440" y2="80" stroke="#0284c7" strokeWidth="1" />
              <line x1="0" y1="130" x2="440" y2="130" stroke="#0284c7" strokeWidth="1" />
              <line x1="220" y1="40" x2="220" y2="130" stroke="#0284c7" strokeWidth="1" />

              {/* Title Block Texts */}
              <text x="15" y="26" fill="#e0f2fe" fontSize="14" fontWeight="bold" fontFamily="monospace">
                云栖定制家具工坊 · 榫卯工程详图
              </text>
              <text x="350" y="26" fill="#38bdf8" fontSize="12" fontFamily="monospace">
                DWG-01/01
              </text>

              <text x="15" y="60" fill="#94a3b8" fontSize="10">项目名称 (PROJECT):</text>
              <text x="15" y="74" fill="#38bdf8" fontSize="11" fontWeight="bold">{template.nameCn} ({template.nameEn})</text>

              <text x="235" y="60" fill="#94a3b8" fontSize="10">木料规格 (MATERIAL):</text>
              <text x="235" y="74" fill="#38bdf8" fontSize="11" fontWeight="bold">{wood.nameCn}</text>

              <text x="15" y="102" fill="#94a3b8" fontSize="10">榫卯工艺 (JOINERY):</text>
              <text x="15" y="118" fill="#f59e0b" fontSize="11" fontWeight="bold">{jointType}</text>

              <text x="235" y="102" fill="#94a3b8" fontSize="10">成品净尺寸 (OVERALL):</text>
              <text x="235" y="118" fill="#e0f2fe" fontSize="11" fontFamily="monospace">{L} x {W} x {H} mm</text>

              <text x="15" y="152" fill="#64748b" fontSize="9">审核引擎: Rust WoodEngine v0.1 (Euler-Bernoulli Stress Verified)</text>
              <text x="15" y="172" fill="#64748b" fontSize="9">比例: 1:10 · 尺寸单位: 毫米 (mm) · 密级: 匠人车间加工级</text>
              <text x="360" y="165" fill="#38bdf8" fontSize="10" fontWeight="bold">YUNQI CAD</text>
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}
