"use client";

import React from "react";
import {
  FurnitureTemplate,
  WoodSpecies,
  WOOD_SPECIES_LIST,
  JOINERY_TYPES_LIST,
  FURNITURE_TEMPLATES,
  RustCalculationResult,
} from "@/lib/types";
import {
  Sliders,
  TreePine,
  Wrench,
  Sparkles,
  Maximize2,
  Box,
  Layers,
  FileCheck2,
  Cpu,
} from "lucide-react";

interface ParametricSidebarProps {
  currentTemplate: FurnitureTemplate;
  onSelectTemplate: (tpl: FurnitureTemplate) => void;
  dimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    topThicknessMm: number;
    legSizeMm: number;
  };
  onDimensionChange: (key: string, value: number) => void;
  selectedWood: WoodSpecies;
  onSelectWood: (wood: WoodSpecies) => void;
  selectedJoint: string;
  onSelectJoint: (jointId: string) => void;
  selectedFinish: string;
  onSelectFinish: (finish: string) => void;
  explodedPct: number;
  onExplodedChange: (val: number) => void;
  wireframe: boolean;
  onToggleWireframe: () => void;
  lightingMood: "zen" | "workshop" | "evening" | "clay";
  onSelectLighting: (mood: "zen" | "workshop" | "evening" | "clay") => void;
  rustData: RustCalculationResult | null;
  onOpenQuote: () => void;
}

export default function ParametricSidebar({
  currentTemplate,
  onSelectTemplate,
  dimensions,
  onDimensionChange,
  selectedWood,
  onSelectWood,
  selectedJoint,
  onSelectJoint,
  selectedFinish,
  onSelectFinish,
  explodedPct,
  onExplodedChange,
  wireframe,
  onToggleWireframe,
  lightingMood,
  onSelectLighting,
  rustData,
  onOpenQuote,
}: ParametricSidebarProps) {
  const finishes = [
    { id: "天然蜂蜡烫蜡", name: "天然蜂蜡烫蜡", desc: "渗透保护，原木触感，呼吸透气" },
    { id: "哑光木蜡油", name: "植物哑光木蜡油", desc: "欧标环保，抗污耐磨，极低光泽" },
    { id: "生漆推光", name: "传统大漆推光", desc: "千年天然生漆，耐酸碱防潮抗腐" },
  ];

  return (
    <div className="flex flex-col h-full bg-[#161413] border-r border-neutral-800 text-neutral-200 overflow-y-auto w-full md:w-[380px] lg:w-[410px] shrink-0 p-5 space-y-6">
      {/* 1. Template Selector */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
          <Box className="w-3.5 h-3.5" />
          <span>家具器型选择 (Form Template)</span>
        </label>
        <div className="grid grid-cols-2 gap-2">
          {FURNITURE_TEMPLATES.map((tpl) => {
            const isSelected = tpl.id === currentTemplate.id;
            return (
              <button
                key={tpl.id}
                onClick={() => onSelectTemplate(tpl)}
                className={`p-2.5 rounded-lg text-left border transition text-xs flex flex-col justify-between ${
                  isSelected
                    ? "bg-amber-950/80 border-amber-500 text-amber-200 shadow-lg shadow-amber-950/50"
                    : "bg-neutral-900 border-neutral-800 hover:border-neutral-700 text-neutral-400"
                }`}
              >
                <span className="font-bold text-[13px] text-neutral-100">{tpl.nameCn}</span>
                <span className="text-[10px] text-neutral-400 font-mono mt-0.5">{tpl.nameEn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Parametric Dimension Sliders */}
      <div className="space-y-4 bg-neutral-900/60 p-4 rounded-xl border border-neutral-800">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5" />
            <span>参数化尺度 (Dimensions mm)</span>
          </label>
          <span className="text-[10px] text-neutral-500 font-mono">微调步长: 10mm</span>
        </div>

        {/* Length Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-neutral-400">长 (Length L):</span>
            <span className="font-bold text-amber-300">{dimensions.lengthMm} mm</span>
          </div>
          <input
            type="range"
            min={currentTemplate.dimensionRanges.minLength}
            max={currentTemplate.dimensionRanges.maxLength}
            step={10}
            value={dimensions.lengthMm}
            onChange={(e) => onDimensionChange("lengthMm", Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-neutral-600 font-mono">
            <span>{currentTemplate.dimensionRanges.minLength}</span>
            <span>{currentTemplate.dimensionRanges.maxLength} mm</span>
          </div>
        </div>

        {/* Width Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-neutral-400">宽 (Width W):</span>
            <span className="font-bold text-amber-300">{dimensions.widthMm} mm</span>
          </div>
          <input
            type="range"
            min={currentTemplate.dimensionRanges.minWidth}
            max={currentTemplate.dimensionRanges.maxWidth}
            step={10}
            value={dimensions.widthMm}
            onChange={(e) => onDimensionChange("widthMm", Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-neutral-600 font-mono">
            <span>{currentTemplate.dimensionRanges.minWidth}</span>
            <span>{currentTemplate.dimensionRanges.maxWidth} mm</span>
          </div>
        </div>

        {/* Height Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-neutral-400">高 (Height H):</span>
            <span className="font-bold text-amber-300">{dimensions.heightMm} mm</span>
          </div>
          <input
            type="range"
            min={currentTemplate.dimensionRanges.minHeight}
            max={currentTemplate.dimensionRanges.maxHeight}
            step={10}
            value={dimensions.heightMm}
            onChange={(e) => onDimensionChange("heightMm", Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-neutral-600 font-mono">
            <span>{currentTemplate.dimensionRanges.minHeight}</span>
            <span>{currentTemplate.dimensionRanges.maxHeight} mm</span>
          </div>
        </div>

        {/* Top Board Thickness */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-neutral-400">主板厚度 (Top T):</span>
            <span className="font-bold text-amber-300">{dimensions.topThicknessMm} mm</span>
          </div>
          <input
            type="range"
            min={currentTemplate.dimensionRanges.minThickness}
            max={currentTemplate.dimensionRanges.maxThickness}
            step={2}
            value={dimensions.topThicknessMm}
            onChange={(e) => onDimensionChange("topThicknessMm", Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
        </div>

        {/* Leg Cross-section */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-neutral-400">腿柱规格 (Leg Width):</span>
            <span className="font-bold text-amber-300">{dimensions.legSizeMm} x {dimensions.legSizeMm} mm</span>
          </div>
          <input
            type="range"
            min={42}
            max={90}
            step={2}
            value={dimensions.legSizeMm}
            onChange={(e) => onDimensionChange("legSizeMm", Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* 3. Wood Species Selector */}
      <div className="space-y-3">
        <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
          <TreePine className="w-3.5 h-3.5" />
          <span>原木材种精选 (Wood Species)</span>
        </label>
        <div className="space-y-2">
          {WOOD_SPECIES_LIST.map((w) => {
            const isSelected = w.id === selectedWood.id;
            return (
              <button
                key={w.id}
                onClick={() => onSelectWood(w)}
                className={`w-full p-2.5 rounded-lg text-left border transition flex items-center justify-between ${
                  isSelected
                    ? "bg-amber-950/70 border-amber-500 text-amber-100 shadow-md"
                    : "bg-neutral-900 border-neutral-800 hover:border-neutral-700 text-neutral-300"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    style={{ backgroundColor: w.colorHex }}
                    className="w-5 h-5 rounded-full border border-white/20 shadow-inner shrink-0"
                  />
                  <div>
                    <div className="text-xs font-bold">{w.nameCn}</div>
                    <div className="text-[10px] text-neutral-400 font-mono">{w.nameEn} · 密度 {w.density} kg/m³</div>
                  </div>
                </div>
                <div className="text-right font-mono text-xs">
                  <span className="text-amber-400 font-semibold">¥{w.costPerBfCny}</span>
                  <span className="text-[10px] text-neutral-500 block">/板尺</span>
                </div>
              </button>
            );
          })}
        </div>
        <p className="text-[11px] text-neutral-400 bg-neutral-900/40 p-2 rounded border border-neutral-800/60 leading-relaxed">
          {selectedWood.description}
        </p>
      </div>

      {/* 4. Joinery Structure Selector */}
      <div className="space-y-3">
        <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
          <Wrench className="w-3.5 h-3.5" />
          <span>传统榫卯结构 (Joinery Craft)</span>
        </label>
        <div className="grid grid-cols-2 gap-2">
          {JOINERY_TYPES_LIST.map((j) => {
            const isSelected = j.id === selectedJoint;
            return (
              <button
                key={j.id}
                onClick={() => onSelectJoint(j.id)}
                className={`p-2.5 rounded-lg text-left border transition text-xs flex flex-col justify-between ${
                  isSelected
                    ? "bg-amber-950/70 border-amber-500 text-amber-100 shadow-md"
                    : "bg-neutral-900 border-neutral-800 hover:border-neutral-700 text-neutral-400"
                }`}
              >
                <span className="font-bold text-neutral-100">{j.nameCn}</span>
                <span className="text-[10px] text-neutral-400 mt-1 font-mono">{j.historicalPeriod}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 5. Surface Finishing */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          <span>表面天然涂装 (Finishing)</span>
        </label>
        <div className="space-y-1.5">
          {finishes.map((f) => (
            <button
              key={f.id}
              onClick={() => onSelectFinish(f.id)}
              className={`w-full p-2 rounded text-left border text-xs transition flex items-center justify-between ${
                selectedFinish === f.id
                  ? "bg-amber-950/60 border-amber-500 text-amber-200"
                  : "bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-neutral-200"
              }`}
            >
              <span className="font-medium">{f.name}</span>
              <span className="text-[10px] text-neutral-500">{f.desc.slice(0, 10)}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 6. 3D Exploded View & Viewport Controls */}
      <div className="space-y-3 bg-neutral-900/60 p-4 rounded-xl border border-neutral-800">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" />
            <span>三维榫卯爆炸分解 (Exploded View)</span>
          </label>
          <span className="font-mono text-xs text-amber-300 font-bold">{explodedPct}%</span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={explodedPct}
          onChange={(e) => onExplodedChange(Number(e.target.value))}
          className="w-full accent-amber-500 h-2 bg-neutral-800 rounded-lg cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
          <span>完整成型 (0%)</span>
          <span>构件全分离 (100%)</span>
        </div>

        {/* Viewport Toggles */}
        <div className="pt-2 border-t border-neutral-800 flex items-center justify-between gap-2">
          <button
            onClick={onToggleWireframe}
            className={`flex-1 py-1.5 rounded text-xs border transition ${
              wireframe
                ? "bg-sky-950 border-sky-600 text-sky-300"
                : "bg-neutral-800 border-neutral-700 text-neutral-400"
            }`}
          >
            {wireframe ? "退出线框" : "线框模式 (Wireframe)"}
          </button>

          {/* Lighting Mode */}
          <select
            value={lightingMood}
            onChange={(e) => onSelectLighting(e.target.value as any)}
            className="flex-1 py-1.5 px-2 rounded bg-neutral-800 border border-neutral-700 text-xs text-neutral-200"
          >
            <option value="zen">晨光茶室 (Zen Light)</option>
            <option value="workshop">匠人工作台 (Studio)</option>
            <option value="evening">夜间微光 (Candle)</option>
            <option value="clay">CAD纯白模 (Clay)</option>
          </select>
        </div>
      </div>

      {/* Rust Engine Calculation Live Snippet */}
      {rustData && (
        <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 text-xs font-mono space-y-1.5">
          <div className="flex items-center justify-between text-neutral-400">
            <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-sans">
              <Cpu className="w-3 h-3" /> Rust 实时力学核算
            </span>
            <span className="text-[10px] text-neutral-500">{rustData.compute_time_ms} ms</span>
          </div>
          <div className="flex justify-between text-neutral-300">
            <span>中心承重挠度:</span>
            <span className="text-emerald-400">{rustData.metrics.center_deflection_mm} mm (极优)</span>
          </div>
          <div className="flex justify-between text-neutral-300">
            <span>毛料板尺/重量:</span>
            <span>{rustData.metrics.board_feet} BF · {rustData.metrics.finished_weight_kg} kg</span>
          </div>
          <div className="flex justify-between text-neutral-300 font-bold border-t border-neutral-800/80 pt-1">
            <span>定制工坊核算价:</span>
            <span className="text-amber-400 font-sans text-sm">¥{rustData.pricing.suggested_retail_cny.toLocaleString()}</span>
          </div>
        </div>
      )}

      {/* Order & Export CTA */}
      <button
        onClick={onOpenQuote}
        className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-neutral-950 font-bold text-sm tracking-wide shadow-xl shadow-amber-900/30 transition transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2"
      >
        <FileCheck2 className="w-4 h-4" />
        <span>生成车间定制单 & 矢量图纸</span>
      </button>
    </div>
  );
}
