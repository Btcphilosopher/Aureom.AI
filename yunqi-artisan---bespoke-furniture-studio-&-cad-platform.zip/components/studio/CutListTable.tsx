"use client";

import React, { useState } from "react";
import { CutListItem, RustCalculationResult } from "@/lib/types";
import { FileSpreadsheet, Copy, Check, Download, Layers } from "lucide-react";

interface CutListTableProps {
  rustData: RustCalculationResult | null;
  loading: boolean;
}

export default function CutListTable({ rustData, loading }: CutListTableProps) {
  const [copied, setCopied] = useState(false);

  if (loading || !rustData) {
    return (
      <div className="p-8 text-center text-neutral-400 bg-neutral-900/50 rounded-xl border border-neutral-800">
        <p className="text-sm">正在通过 Rust WoodEngine 生成开料清单与五金物料表 (BOM)...</p>
      </div>
    );
  }

  const { cut_list, metrics, pricing, wood } = rustData;

  const handleCopyBOM = () => {
    const text = cut_list
      .map(
        (c) =>
          `${c.part_id} | ${c.name_cn} | 数量: ${c.qty} | 净尺寸: ${c.length_mm}x${c.width_mm}x${c.thickness_mm}mm | 纹理: ${c.grain_dir} | 榫卯: ${c.joinery_notes}`
      )
      .join("\n");
    navigator.clipboard.writeText(
      `云栖实木家具工坊 - 构件开料清单 (BOM)\n木种: ${wood.name_cn}\n毛料板尺: ${metrics.board_feet} BF | 预估成品重: ${metrics.finished_weight_kg} kg\n\n` + text
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportCSV = () => {
    const header = "构件编号,名称(中文),Part Name,数量,长(mm),宽(mm),厚(mm),顺纹方向,榫卯加工要点\n";
    const rows = cut_list
      .map(
        (c) =>
          `"${c.part_id}","${c.name_cn}","${c.name_en}",${c.qty},${c.length_mm},${c.width_mm},${c.thickness_mm},"${c.grain_dir}","${c.joinery_notes}"`
      )
      .join("\n");
    const blob = new Blob(["\uFEFF" + header + rows], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Yunqi_CutList_${wood.name_en}_BOM.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col bg-[#141211] rounded-xl border border-neutral-800 overflow-hidden shadow-xl">
      {/* Table Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-neutral-900 border-b border-neutral-800">
        <div className="flex items-center gap-2.5">
          <FileSpreadsheet className="w-5 h-5 text-amber-500" />
          <div>
            <h4 className="text-sm font-semibold text-neutral-100">
              木工车间构件开料表 (Workshop Cut-List & BOM)
            </h4>
            <p className="text-xs text-neutral-400">
              按榫卯结合深浅与刨光损耗精算 · 共 {cut_list.reduce((sum, c) => sum + c.qty, 0)} 件实木构件
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyBOM}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 border border-neutral-700 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? "已复制BOM" : "复制文本清单"}</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-xs text-neutral-950 font-bold transition shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出锯工CSV</span>
          </button>
        </div>
      </div>

      {/* Responsive Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-neutral-300">
          <thead className="bg-neutral-950/80 text-[11px] uppercase tracking-wider text-neutral-400 border-b border-neutral-800">
            <tr>
              <th className="py-3 px-4">编号</th>
              <th className="py-3 px-4">构件名称</th>
              <th className="py-3 px-4">件数</th>
              <th className="py-3 px-4">成品下料规格 (L×W×T mm)</th>
              <th className="py-3 px-4">木材顺纹</th>
              <th className="py-3 px-4">榫卯工艺节点</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800/60 font-mono">
            {cut_list.map((item, idx) => (
              <tr key={item.part_id} className="hover:bg-neutral-850/50 transition">
                <td className="py-3 px-4 font-bold text-amber-400">
                  {item.part_id}
                </td>
                <td className="py-3 px-4 font-sans text-neutral-200">
                  <span className="font-medium">{item.name_cn}</span>
                  <span className="block text-[11px] text-neutral-500 font-mono">{item.name_en}</span>
                </td>
                <td className="py-3 px-4 text-center">
                  <span className="inline-block px-2 py-0.5 rounded bg-neutral-800 text-neutral-100 font-bold">
                    {item.qty}
                  </span>
                </td>
                <td className="py-3 px-4 text-emerald-300">
                  {item.length_mm} x {item.width_mm} x {item.thickness_mm}
                </td>
                <td className="py-3 px-4 text-neutral-400 font-sans">
                  {item.grain_dir}
                </td>
                <td className="py-3 px-4 text-amber-200/90 font-sans text-[11px]">
                  {item.joinery_notes}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Footer */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-neutral-950 border-t border-neutral-800 text-xs">
        <div className="flex items-center gap-4 text-neutral-400 font-mono">
          <span>毛料出板: <strong className="text-neutral-200">{metrics.board_feet} BF</strong></span>
          <span>·</span>
          <span>净体积: <strong className="text-neutral-200">{metrics.finished_volume_m3} m³</strong></span>
          <span>·</span>
          <span>预估重量: <strong className="text-neutral-200">{metrics.finished_weight_kg} kg</strong></span>
        </div>

        <div className="text-amber-400 font-medium font-sans">
          匠人手工开料工时: <strong className="font-mono text-sm">{pricing.craft_hours} 小时</strong>
        </div>
      </div>
    </div>
  );
}
