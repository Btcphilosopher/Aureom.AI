"use client";

import React, { useState } from "react";
import Image from "next/image";
import { FurnitureTemplate, WoodSpecies } from "@/lib/types";
import { Compass, Eye, Sparkles, UserCheck, Armchair } from "lucide-react";

interface RoomMockupProps {
  template: FurnitureTemplate;
  dimensions: {
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    topThicknessMm: number;
    legSizeMm: number;
  };
  wood: WoodSpecies;
}

export default function RoomMockup({
  template,
  dimensions,
  wood,
}: RoomMockupProps) {
  const [roomScene, setRoomScene] = useState<"zen_tearoom" | "mountain_living" | "scholar_study">("mountain_living");
  const [showScaleAvatar, setShowScaleAvatar] = useState<boolean>(true);
  const [accessories, setAccessories] = useState<boolean>(true);

  const scenes = [
    {
      id: "mountain_living",
      name: "东方山水客堂 (Master Living Room)",
      desc: "落地湖山长卷，沉稳黑胡桃与远山松风相映",
      image: "/assets/aistudio/99283a80-2cfd-4a96-b79a-36f7c5b371ac_c6825f15.png",
    },
    {
      id: "zen_tearoom",
      name: "水墨禅意茶室 (Zen Gongfu Tea Room)",
      desc: "榻榻米席面，格栅屏风，静听水沸茶烟",
      image: "https://picsum.photos/seed/zen-tearoom-yunqi/1200/800",
    },
    {
      id: "scholar_study",
      name: "文人雅集书房 (Scholar's Study)",
      desc: "博古书架，宣纸墨香，适于静心著述",
      image: "https://picsum.photos/seed/scholar-study-oriental/1200/800",
    },
  ];

  return (
    <div className="flex flex-col h-full bg-[#121110] rounded-xl border border-neutral-800 overflow-hidden shadow-2xl">
      {/* Scene Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-neutral-900 border-b border-neutral-800 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-neutral-400 font-medium">空间场景切换:</span>
          {scenes.map((s) => (
            <button
              key={s.id}
              onClick={() => setRoomScene(s.id as any)}
              className={`px-3 py-1.5 rounded-lg transition font-medium ${
                roomScene === s.id
                  ? "bg-amber-600 text-neutral-950 font-bold shadow-md"
                  : "bg-neutral-800 text-neutral-300 hover:bg-neutral-700"
              }`}
            >
              {s.name.split(" ")[0]}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowScaleAvatar(!showScaleAvatar)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition ${
              showScaleAvatar
                ? "bg-amber-950/80 border-amber-600/50 text-amber-300"
                : "bg-neutral-800/80 border-neutral-700 text-neutral-400"
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>人体尺度对比 (175cm)</span>
          </button>

          <button
            onClick={() => setAccessories(!accessories)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition ${
              accessories
                ? "bg-amber-950/80 border-amber-600/50 text-amber-300"
                : "bg-neutral-800/80 border-neutral-700 text-neutral-400"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>茶具与文房摆件</span>
          </button>
        </div>
      </div>

      {/* Main Room Viewport */}
      <div className="relative flex-1 min-h-[460px] bg-neutral-950 overflow-hidden flex items-center justify-center">
        {/* Background Room Photo */}
        <div className="absolute inset-0">
          <Image
            src={scenes.find((s) => s.id === roomScene)?.image || scenes[0].image}
            alt="Room Scene"
            fill
            className="object-cover opacity-60 filter brightness-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/40 to-neutral-950/60" />
        </div>

        {/* Spatial Placement Compositing */}
        <div className="relative z-10 flex flex-col items-center justify-end h-full pb-14 px-6 w-full max-w-4xl">
          {/* Furniture Mockup Rendering in Space */}
          <div className="relative flex items-end justify-center w-full">
            {/* Human Silhouette Scale Reference */}
            {showScaleAvatar && (
              <div className="absolute -left-12 sm:left-4 bottom-0 flex flex-col items-center pointer-events-none select-none opacity-85">
                <div className="w-10 h-10 rounded-full border-2 border-amber-300/80 bg-neutral-900/80 flex items-center justify-center text-amber-300 text-[10px] font-mono shadow-lg mb-1">
                  175cm
                </div>
                {/* Minimalist SVG Human figure */}
                <svg width="48" height="150" viewBox="0 0 50 160" className="drop-shadow-2xl">
                  <circle cx="25" cy="18" r="10" fill="#fcd34d" opacity="0.8" />
                  <path d="M 25 32 L 25 90 M 12 50 L 38 50 M 25 90 L 14 150 M 25 90 L 36 150" stroke="#fcd34d" strokeWidth="4" strokeLinecap="round" opacity="0.8" />
                </svg>
                <span className="text-[10px] font-mono text-amber-200/80 bg-neutral-950/90 px-1.5 py-0.5 rounded border border-neutral-700">
                  人体参照标尺
                </span>
              </div>
            )}

            {/* Custom Furniture Render Card */}
            <div className="relative flex flex-col items-center p-6 rounded-2xl bg-neutral-900/90 backdrop-blur-md border-2 border-amber-500/40 shadow-2xl max-w-xl w-full text-center">
              <div className="w-full flex items-center justify-between text-xs text-amber-400/90 mb-3 font-mono border-b border-neutral-800 pb-2">
                <span className="flex items-center gap-1.5">
                  <Armchair className="w-4 h-4 text-amber-500" />
                  {template.nameCn} · 实景置景
                </span>
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700/50">
                  {dimensions.lengthMm} x {dimensions.widthMm} x {dimensions.heightMm} mm
                </span>
              </div>

              {/* Graphic Mockup of the Table / Piece */}
              <div
                style={{ backgroundColor: wood.colorHex }}
                className="w-full h-32 rounded-lg shadow-2xl border border-amber-200/20 relative overflow-hidden flex items-center justify-center"
              >
                {/* Wood Grain Lines */}
                <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:12px_12px]" />

                {/* Table Accessories (Teapot / Cup / Scroll) */}
                {accessories && (
                  <div className="relative z-10 flex items-center gap-6 px-4 py-2 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 text-xs text-amber-200">
                    <span>🫖 宜兴紫砂西施壶</span>
                    <span className="text-white/20">|</span>
                    <span>🍵 龙泉青瓷茶盏</span>
                    <span className="text-white/20">|</span>
                    <span>📜 宣纸手卷</span>
                  </div>
                )}
              </div>

              {/* Four Sturdy Solid Wood Legs */}
              <div className="w-full flex justify-between px-6 -mt-1">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    style={{ backgroundColor: wood.colorHex }}
                    className="w-6 h-20 rounded-b shadow-lg border-x border-b border-black/40 flex flex-col justify-end items-center"
                  >
                    {/* Brass Shoe */}
                    <div className="w-full h-3 bg-amber-500/90 rounded-b" />
                  </div>
                ))}
              </div>

              {/* Specs Badge */}
              <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-xs text-neutral-300">
                <span className="text-neutral-400">木种材质: <strong className="text-amber-300">{wood.nameCn}</strong></span>
                <span className="text-neutral-500">·</span>
                <span className="text-neutral-400">座席离地空间: <strong className="text-neutral-200">{dimensions.heightMm - dimensions.topThicknessMm - 75} mm (膝部充裕)</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Current scene description bottom tag */}
        <div className="absolute bottom-3 right-3 text-xs text-neutral-300 bg-neutral-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-neutral-800">
          <span className="text-amber-400 font-medium">当前空间: </span>
          {scenes.find((s) => s.id === roomScene)?.desc}
        </div>
      </div>
    </div>
  );
}
