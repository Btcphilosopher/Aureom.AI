"use client";

import React, { useState, useEffect, useCallback, useTransition } from "react";
import {
  FurnitureTemplate,
  WoodSpecies,
  WOOD_SPECIES_LIST,
  FURNITURE_TEMPLATES,
  RustCalculationResult,
} from "@/lib/types";
import { KotlinSpringConfig, composeToMotionSpring } from "@/lib/kotlin-animations";
import { motion, AnimatePresence } from "motion/react";
import ThreeFurnitureCanvas from "./ThreeFurnitureCanvas";
import Blueprint2D from "./Blueprint2D";
import NestingSheet from "./NestingSheet";
import RoomMockup from "./RoomMockup";
import CutListTable from "./CutListTable";
import ParametricSidebar from "./ParametricSidebar";
import RustEngineMonitor from "../RustEngineMonitor";
import QuoteModal from "../QuoteModal";
import {
  Box,
  FileCode,
  Layers,
  Home,
  FileSpreadsheet,
  Cpu,
  Sparkles,
  Maximize,
  CheckCircle2,
} from "lucide-react";

interface FurnitureStudioProps {
  initialTemplateId?: string;
  activeSpring: KotlinSpringConfig;
}

export default function FurnitureStudio({
  initialTemplateId,
  activeSpring,
}: FurnitureStudioProps) {
  const [template, setTemplate] = useState<FurnitureTemplate>(() => {
    return (
      FURNITURE_TEMPLATES.find((t) => t.id === initialTemplateId) ||
      FURNITURE_TEMPLATES[0]
    );
  });

  const [dimensions, setDimensions] = useState({
    lengthMm: template.defaultDimensions.lengthMm,
    widthMm: template.defaultDimensions.widthMm,
    heightMm: template.defaultDimensions.heightMm,
    topThicknessMm: template.defaultDimensions.topThicknessMm,
    legSizeMm: template.defaultDimensions.legSizeMm,
  });

  const [selectedWood, setSelectedWood] = useState<WoodSpecies>(() => {
    return (
      WOOD_SPECIES_LIST.find((w) => w.id === template.defaultWood) ||
      WOOD_SPECIES_LIST[0]
    );
  });

  const [selectedJoint, setSelectedJoint] = useState<string>(template.defaultJoint);
  const [selectedFinish, setSelectedFinish] = useState<string>(template.recommendedFinish);
  const [explodedPct, setExplodedPct] = useState<number>(0);
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [lightingMood, setLightingMood] = useState<"zen" | "workshop" | "evening" | "clay">("zen");
  const [activeTab, setActiveTab] = useState<"3d" | "2d_cad" | "nesting" | "room" | "bom" | "rust">("3d");
  const [isQuoteOpen, setIsQuoteOpen] = useState<boolean>(false);

  // Rust backend data state
  const [rustData, setRustData] = useState<RustCalculationResult | null>(null);
  const [rustLoading, setRustLoading] = useState<boolean>(false);
  const [, startTransition] = useTransition();

  // Reset dimensions when template changes
  const handleSelectTemplate = (newTpl: FurnitureTemplate) => {
    setTemplate(newTpl);
    setDimensions({
      lengthMm: newTpl.defaultDimensions.lengthMm,
      widthMm: newTpl.defaultDimensions.widthMm,
      heightMm: newTpl.defaultDimensions.heightMm,
      topThicknessMm: newTpl.defaultDimensions.topThicknessMm,
      legSizeMm: newTpl.defaultDimensions.legSizeMm,
    });
    const matchWood = WOOD_SPECIES_LIST.find((w) => w.id === newTpl.defaultWood);
    if (matchWood) setSelectedWood(matchWood);
    setSelectedJoint(newTpl.defaultJoint);
    setSelectedFinish(newTpl.recommendedFinish);
    setExplodedPct(0);
  };

  const handleDimensionChange = (key: string, value: number) => {
    setDimensions((prev) => ({ ...prev, [key]: value }));
  };

  // Call Rust backend for engineering calculations (debounced)
  const queryRustBackend = useCallback(async () => {
    setRustLoading(true);
    try {
      const payload = {
        template_id: template.id,
        length_mm: dimensions.lengthMm,
        width_mm: dimensions.widthMm,
        height_mm: dimensions.heightMm,
        top_thickness_mm: dimensions.topThicknessMm,
        leg_size_mm: dimensions.legSizeMm,
        wood_type: selectedWood.id,
        joint_type: selectedJoint,
        finish_type: selectedFinish,
        load_kg: 120,
      };

      const res = await fetch("/api/rust", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        startTransition(() => {
          setRustData(data);
        });
      }
    } catch (e) {
      console.error("Failed to query Rust backend:", e);
    } finally {
      setRustLoading(false);
    }
  }, [template.id, dimensions, selectedWood.id, selectedJoint, selectedFinish]);

  // Initial and reactive calculation
  useEffect(() => {
    const timer = setTimeout(() => {
      queryRustBackend();
    }, 180);
    return () => clearTimeout(timer);
  }, [queryRustBackend]);

  const motionSpring = composeToMotionSpring(
    activeSpring.dampingRatio,
    activeSpring.stiffness
  );

  return (
    <section id="custom-studio" className="relative w-full py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Studio Header & Title */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-amber-500 uppercase">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span>YUNQI FLATFORM CAD & MOCKUP STUDIO</span>
            <span className="text-neutral-600">/</span>
            <span className="text-neutral-400">实木定制平台软件</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-neutral-100 mt-1">
            参数化实木器物定制工坊
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 mt-2 max-w-2xl leading-relaxed">
            三维爆炸分解、正投影2D施工图、原木板材下料排版以及 Rust 驱动的高性能木作力学引擎。
          </p>
        </div>

        {/* Quick Quick Specs Summary */}
        <div className="flex items-center gap-3 bg-neutral-900/80 px-4 py-2.5 rounded-xl border border-neutral-800 text-xs font-mono">
          <div className="flex items-center gap-1.5 text-neutral-300">
            <span className="text-neutral-500">当前器型:</span>
            <span className="text-amber-400 font-bold">{template.nameCn}</span>
          </div>
          <span className="text-neutral-700">|</span>
          <div className="flex items-center gap-1.5 text-neutral-300">
            <span className="text-neutral-500">尺寸:</span>
            <span>{dimensions.lengthMm}×{dimensions.widthMm}×{dimensions.heightMm}</span>
          </div>
        </div>
      </div>

      {/* Main Studio Frame */}
      <div className="flex flex-col lg:flex-row rounded-2xl bg-[#141211] border border-neutral-800 shadow-2xl overflow-hidden min-h-[720px]">
        {/* Left: Parametric Controls Sidebar */}
        <ParametricSidebar
          currentTemplate={template}
          onSelectTemplate={handleSelectTemplate}
          dimensions={dimensions}
          onDimensionChange={handleDimensionChange}
          selectedWood={selectedWood}
          onSelectWood={setSelectedWood}
          selectedJoint={selectedJoint}
          onSelectJoint={setSelectedJoint}
          selectedFinish={selectedFinish}
          onSelectFinish={setSelectedFinish}
          explodedPct={explodedPct}
          onExplodedChange={setExplodedPct}
          wireframe={wireframe}
          onToggleWireframe={() => setWireframe(!wireframe)}
          lightingMood={lightingMood}
          onSelectLighting={setLightingMood}
          rustData={rustData}
          onOpenQuote={() => setIsQuoteOpen(true)}
        />

        {/* Right / Center: Workspace Viewports */}
        <div className="flex-1 flex flex-col bg-[#0e0d0c] overflow-hidden min-w-0">
          {/* Workspace Tabs Navigation */}
          <div className="flex items-center justify-between px-4 py-2.5 bg-neutral-900/95 border-b border-neutral-800 overflow-x-auto text-xs">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setActiveTab("3d")}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition ${
                  activeTab === "3d"
                    ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/40"
                    : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
                }`}
              >
                <Box className="w-3.5 h-3.5" />
                <span>3D交互模型</span>
              </button>

              <button
                onClick={() => setActiveTab("2d_cad")}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition ${
                  activeTab === "2d_cad"
                    ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/40"
                    : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>2D施工蓝图</span>
              </button>

              <button
                onClick={() => setActiveTab("nesting")}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition ${
                  activeTab === "nesting"
                    ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/40"
                    : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>板材排版下料 (Nesting)</span>
              </button>

              <button
                onClick={() => setActiveTab("room")}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition ${
                  activeTab === "room"
                    ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/40"
                    : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
                }`}
              >
                <Home className="w-3.5 h-3.5" />
                <span>空间实景置景</span>
              </button>

              <button
                onClick={() => setActiveTab("bom")}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition ${
                  activeTab === "bom"
                    ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/40"
                    : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>构件开料表 (BOM)</span>
              </button>

              <button
                onClick={() => setActiveTab("rust")}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition ${
                  activeTab === "rust"
                    ? "bg-amber-600 text-neutral-950 font-bold shadow-md shadow-amber-900/40"
                    : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
                }`}
              >
                <Cpu className="w-3.5 h-3.5 text-orange-400" />
                <span>Rust力学引擎</span>
              </button>
            </div>

            {/* Quick status badge */}
            <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono text-neutral-500">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Rust IPC Online ({rustData?.compute_time_ms || 0.08}ms)</span>
            </div>
          </div>

          {/* Active Workspace Content Area with Motion Transitions */}
          <div className="flex-1 p-4 lg:p-6 overflow-auto">
            <AnimatePresence mode="wait">
              {activeTab === "3d" && (
                <motion.div
                  key="3d"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1, transition: motionSpring }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="w-full h-full min-h-[520px]"
                >
                  <ThreeFurnitureCanvas
                    template={template}
                    dimensions={dimensions}
                    wood={selectedWood}
                    jointType={selectedJoint}
                    explodedPct={explodedPct}
                    wireframe={wireframe}
                    lightingMood={lightingMood}
                    showDimensions={true}
                    activeSpring={activeSpring}
                  />
                </motion.div>
              )}

              {activeTab === "2d_cad" && (
                <motion.div
                  key="2d_cad"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1, transition: motionSpring }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="w-full h-full min-h-[520px]"
                >
                  <Blueprint2D
                    template={template}
                    dimensions={dimensions}
                    wood={selectedWood}
                    jointType={selectedJoint}
                  />
                </motion.div>
              )}

              {activeTab === "nesting" && (
                <motion.div
                  key="nesting"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1, transition: motionSpring }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="w-full h-full min-h-[520px]"
                >
                  <NestingSheet rustData={rustData} loading={rustLoading} />
                </motion.div>
              )}

              {activeTab === "room" && (
                <motion.div
                  key="room"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1, transition: motionSpring }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="w-full h-full min-h-[520px]"
                >
                  <RoomMockup
                    template={template}
                    dimensions={dimensions}
                    wood={selectedWood}
                  />
                </motion.div>
              )}

              {activeTab === "bom" && (
                <motion.div
                  key="bom"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1, transition: motionSpring }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="w-full h-full"
                >
                  <CutListTable rustData={rustData} loading={rustLoading} />
                </motion.div>
              )}

              {activeTab === "rust" && (
                <motion.div
                  key="rust"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1, transition: motionSpring }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="w-full h-full"
                >
                  <RustEngineMonitor
                    rustData={rustData}
                    onRefreshRust={queryRustBackend}
                    loading={rustLoading}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Quote & Order Commission Modal */}
      <QuoteModal
        isOpen={isQuoteOpen}
        onClose={() => setIsQuoteOpen(false)}
        template={template}
        dimensions={dimensions}
        wood={selectedWood}
        jointType={selectedJoint}
        finish={selectedFinish}
        rustData={rustData}
        activeSpring={activeSpring}
      />
    </section>
  );
}
