"use client";

import React, { useState } from "react";
import Image from "next/image";
import { ArrowRight, Compass, Sparkles, Layers } from "lucide-react";

interface HeroProps {
  onExploreClick: () => void;
  onStudioClick: () => void;
}

export default function Hero({ onExploreClick, onStudioClick }: HeroProps) {
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    {
      titleLine1: "东方美学",
      titleLine2: "融入现代生活",
      subtitle: "以匠心 · 造物 · 传承千年东方家居智慧",
      tag: "大隐于市 · 禅意茶居",
    },
    {
      titleLine1: "榫卯交错",
      titleLine2: "结构之美永恒",
      subtitle: "三维粽角暗榫 · 燕尾穿带 · 巧夺天工",
      tag: "明式经典 · 纯正手工",
    },
    {
      titleLine1: "北美黑胡桃",
      titleLine2: "自然山水长卷",
      subtitle: "FAS特级木料 · 二次窑干 · 恒定微湿",
      tag: "岁月包浆 · 传世之器",
    },
  ];

  const current = slides[activeSlide];

  return (
    <section id="hero" className="relative w-full min-h-[90vh] flex items-center justify-start overflow-hidden bg-[#121110]">
      {/* Background Image using user-uploaded asset */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/assets/aistudio/99283a80-2cfd-4a96-b79a-36f7c5b371ac_c6825f15.png"
          alt="Yunqi Eastern Aesthetic Bespoke Furniture"
          fill
          priority
          className="object-cover object-center filter brightness-[0.88] contrast-[1.03]"
          referrerPolicy="no-referrer"
        />
        {/* Cinematic Vignette & Ambient Gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-950/95 via-neutral-950/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#121110] via-transparent to-neutral-950/40" />
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 w-full py-20 flex flex-col justify-between min-h-[80vh]">
        <div className="max-w-2xl pt-8 sm:pt-14 space-y-6">
          {/* Subtle Tag */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900/80 backdrop-blur-md border border-neutral-700/60 text-xs font-mono text-amber-300">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>{current.tag}</span>
          </div>

          {/* Headline matching user's image */}
          <div className="space-y-1">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-medium tracking-tight text-neutral-100 leading-[1.15]">
              {current.titleLine1}
              <br />
              {current.titleLine2}
            </h1>
          </div>

          {/* Subtitle */}
          <p className="text-sm sm:text-lg text-neutral-300/90 font-serif tracking-wide leading-relaxed">
            {current.subtitle}
          </p>

          {/* Action Buttons */}
          <div className="pt-4 flex flex-wrap items-center gap-4">
            <button
              onClick={onExploreClick}
              className="group flex items-center gap-3 px-6 py-3.5 rounded-lg border border-neutral-400/60 bg-neutral-900/60 hover:bg-neutral-850/90 backdrop-blur-md text-neutral-100 text-sm font-medium tracking-wider transition hover:border-amber-400 shadow-xl"
            >
              <span>探索系列</span>
              <ArrowRight className="w-4 h-4 transition transform group-hover:translate-x-1 text-amber-300" />
            </button>

            <button
              onClick={onStudioClick}
              className="flex items-center gap-2.5 px-6 py-3.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-neutral-950 text-sm font-bold tracking-wider transition shadow-2xl shadow-amber-950/60 hover:-translate-y-0.5"
            >
              <Layers className="w-4 h-4" />
              <span>进入定制平台 (Mockup Studio)</span>
            </button>
          </div>
        </div>

        {/* Carousel Slide Switcher matching user image bottom right (01 — 02 — 03) */}
        <div className="flex items-center justify-between pt-12 border-t border-white/10 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-4">
            <span className="text-[11px] text-neutral-500 uppercase tracking-widest hidden sm:inline">
              东方榫卯实木家具 · 纯手工放样
            </span>
          </div>

          <div className="flex items-center gap-3 select-none">
            {slides.map((_, idx) => {
              const isActive = activeSlide === idx;
              return (
                <button
                  key={idx}
                  onClick={() => setActiveSlide(idx)}
                  className={`flex items-center gap-1.5 transition py-1 ${
                    isActive ? "text-amber-300 font-bold" : "text-neutral-500 hover:text-neutral-300"
                  }`}
                >
                  <span>0{idx + 1}</span>
                  {idx < slides.length - 1 && <span className="text-neutral-700 mx-1">—</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
