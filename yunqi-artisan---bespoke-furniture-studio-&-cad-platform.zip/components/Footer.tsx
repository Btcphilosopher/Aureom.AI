"use client";

import React from "react";
import { TreePine, ShieldCheck, HeartHandshake, Cpu, Sparkles } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative bg-[#0d0c0b] text-neutral-400 border-t border-neutral-800/80 pt-16 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-neutral-850">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 flex items-center justify-center text-amber-400">
                <svg viewBox="0 0 48 36" fill="none" className="w-8 h-6 stroke-current stroke-2">
                  <path d="M 6 30 L 16 12 L 26 30" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M 22 30 L 32 8 L 42 30" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M 12 22 L 20 22" strokeLinecap="round" />
                  <path d="M 28 18 L 36 18" strokeLinecap="round" />
                </svg>
              </div>
              <div>
                <span className="font-serif text-lg tracking-widest text-neutral-100 font-bold block">
                  云栖家具
                </span>
                <span className="text-[9px] tracking-[0.25em] text-neutral-500 font-mono">
                  YUNQI BESPOKE FURNITURE
                </span>
              </div>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed font-serif max-w-sm">
              融合宋明文人美学与现代参数化制造，以全榫卯结构、北美特级硬木与天然植物烫蜡，打造可传世百年的东方生活之器。
            </p>

            <div className="flex items-center gap-3 text-xs font-mono text-neutral-500 pt-1">
              <span className="flex items-center gap-1 text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" /> 终身质保维护
              </span>
              <span>·</span>
              <span className="flex items-center gap-1 text-amber-300">
                <TreePine className="w-3.5 h-3.5" /> FAS纯天然原木
              </span>
            </div>
          </div>

          {/* Col 2: Collections */}
          <div className="space-y-3 text-xs">
            <h4 className="font-serif font-bold text-neutral-200 tracking-wider">
              精选器型系列
            </h4>
            <ul className="space-y-2">
              <li><a href="#collections" className="hover:text-amber-400 transition">明式系列 (官帽椅/圈椅)</a></li>
              <li><a href="#collections" className="hover:text-amber-400 transition">茶室系列 (禅意功夫大茶台)</a></li>
              <li><a href="#collections" className="hover:text-amber-400 transition">卧室系列 (三围栏罗汉榻)</a></li>
              <li><a href="#collections" className="hover:text-amber-400 transition">收纳系列 (圆角木轴边柜)</a></li>
              <li><a href="#collections" className="hover:text-amber-400 transition">文房系列 (经典榫卯条案)</a></li>
            </ul>
          </div>

          {/* Col 3: Flatform Studio CAD */}
          <div className="space-y-3 text-xs">
            <h4 className="font-serif font-bold text-neutral-200 tracking-wider">
              定制平台系统
            </h4>
            <ul className="space-y-2 font-mono text-[11px]">
              <li><a href="#custom-studio" className="hover:text-amber-400 transition">3D参数化交互视口</a></li>
              <li><a href="#custom-studio" className="hover:text-amber-400 transition">正投影2D施工图纸生成</a></li>
              <li><a href="#custom-studio" className="hover:text-amber-400 transition">2D板材排版下料 (Nesting)</a></li>
              <li><a href="#custom-studio" className="hover:text-amber-400 transition">车间构件开料BOM导出</a></li>
              <li><a href="#custom-studio" className="hover:text-amber-400 transition">空间实景人体工学测算</a></li>
            </ul>
          </div>

          {/* Col 4: Engine & Tech */}
          <div className="space-y-3 text-xs">
            <h4 className="font-serif font-bold text-neutral-200 tracking-wider flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5 text-orange-400" />
              <span>底层技术架构</span>
            </h4>
            <ul className="space-y-2 font-mono text-[11px] text-neutral-500">
              <li className="text-orange-400">Rust 1.99 Native IPC Engine</li>
              <li className="text-amber-300">Kotlin Compose Physics (Spring)</li>
              <li className="text-neutral-400">Three.js WebGL 60FPS 3D CAD</li>
              <li className="text-neutral-400">Next.js 15 App Router & Tailwind</li>
              <li className="text-neutral-400">Euler-Bernoulli Deflection Model</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-neutral-600 font-mono gap-4">
          <p>© 2026 云栖家具 (YUNQI FURNITURE). 传承东方美学与匠心造物. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>鲁班木作标准检验认证</span>
            <span>·</span>
            <span>无甲醛纯植物蜂蜡涂装</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
