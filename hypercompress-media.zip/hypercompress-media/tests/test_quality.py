"""Tests for quality measurement.

The search is only as trustworthy as these numbers. Two properties matter more
than any individual value:

**Monotonicity.** A worse encode must score worse. A metric that is merely
correlated with quality is not enough to bisect on.

**Fast/full agreement.** The search measures quickly and the delivered file is
measured thoroughly. If those two disagree, the search optimises against a
number nobody will ever verify, and files ship below the floor the operator
configured. This was a real defect: the two passes sampled different windows,
and the gap ran to 0.43 before it was found. These tests exist so it cannot
come back silently.
"""

from __future__ import annotations

import math

import pytest

from hypercompress.analysis.media_probe import MediaProbe
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.quality.audio_quality import align_signals, audio_psnr, audio_score
from hypercompress.quality.psnr import psnr_from_arrays, psnr_to_score
from hypercompress.quality.scoring import (
    QualityScorer,
    audio_meets_floor,
    meets_floor,
    ms_ssim_to_score,
    video_meets_floor,
)
from hypercompress.quality.ssim import ms_ssim_from_arrays, ssim_from_arrays, ssim_to_score
from tests.conftest import Clip, requires_ffmpeg

np = pytest.importorskip("numpy")


class TestMetricPrimitives:
    def test_identical_frames_are_perfect(self) -> None:
        frame = np.random.default_rng(0).integers(0, 255, (64, 64), dtype=np.uint8)
        assert math.isinf(psnr_from_arrays(frame, frame))
        assert ssim_from_arrays(frame, frame) == pytest.approx(1.0, abs=1e-6)
        assert ms_ssim_from_arrays(frame, frame) == pytest.approx(1.0, abs=1e-6)

    def test_noise_degrades_every_metric_monotonically(self) -> None:
        rng = np.random.default_rng(1)
        base = rng.integers(40, 200, (128, 128), dtype=np.uint8).astype(np.float64)
        previous_psnr = math.inf
        previous_ssim = 1.0
        for sigma in (2, 6, 14, 30):
            noisy = np.clip(base + rng.normal(0, sigma, base.shape), 0, 255).astype(np.uint8)
            reference = base.astype(np.uint8)
            psnr = psnr_from_arrays(reference, noisy)
            ssim = ssim_from_arrays(reference, noisy)
            assert psnr < previous_psnr, "more noise must lower PSNR"
            assert ssim < previous_ssim, "more noise must lower SSIM"
            previous_psnr, previous_ssim = psnr, ssim

    def test_score_mappings_span_the_useful_range(self) -> None:
        # Calibrated against an AV1 CRF sweep. A transparent encode must reach
        # the top of the scale, and a clearly damaged one must not: a mapping
        # that returns 0.9 for both is useless for ranking candidates.
        assert ssim_to_score(0.9979) > 0.95
        assert ssim_to_score(0.9783) < 0.20
        assert ms_ssim_to_score(0.99964) > 0.95
        assert ms_ssim_to_score(0.99512) < 0.50
        assert psnr_to_score(50.0) == pytest.approx(1.0)
        assert psnr_to_score(30.0) < 0.25

    def test_score_mappings_clamp(self) -> None:
        assert ssim_to_score(0.1) == 0.0
        assert ssim_to_score(1.0) == 1.0
        assert psnr_to_score(math.inf) == 1.0
        assert ssim_to_score(None) is None


class TestAudioAlignment:
    def test_a_delayed_signal_is_realigned(self) -> None:
        # Every lossy audio codec introduces encoder delay. Comparing sample n
        # to sample n without correcting for it measures the delay, not the
        # damage — an untouched signal shifted by 6.5 ms reads as mangled.
        rng = np.random.default_rng(2)
        signal = rng.normal(0, 0.2, 48_000).astype(np.float32)
        delayed = np.concatenate([np.zeros(320, dtype=np.float32), signal])

        # What the comparison would say with no alignment at all.
        naive_mse = float(np.mean((signal - delayed[: len(signal)]) ** 2))
        naive_psnr = 10 * math.log10(1.0 / naive_mse)
        assert naive_psnr < 25.0, "the unaligned comparison should look terrible"

        left, right, lag = align_signals(signal, delayed)
        assert abs(lag) == pytest.approx(320, abs=8)

        # audio_psnr aligns internally, so the caller gets the right answer even
        # if they forget. That is deliberate: the failure mode of forgetting is
        # silent and severe.
        assert audio_psnr(signal, delayed) > 60.0
        assert audio_psnr(left, right) > 60.0

    def test_alignment_leaves_an_aligned_pair_alone(self) -> None:
        rng = np.random.default_rng(3)
        signal = rng.normal(0, 0.2, 24_000).astype(np.float32)
        left, right, lag = align_signals(signal, signal.copy())
        assert lag == 0
        assert math.isinf(audio_psnr(left, right))

    def test_audio_score_rewards_fidelity(self) -> None:
        assert audio_score(65.0, 0.955) > audio_score(50.0, 0.930)
        assert audio_score(49.0, 0.470) < 0.35


class TestFloorChecks:
    def test_video_and_audio_floors_are_independent(self) -> None:
        from hypercompress.config import QualityPolicy
        from hypercompress.core.types import QualityReport

        policy = QualityPolicy()
        report = QualityReport(video_score=0.99, audio_score=0.40, composite=0.84)

        # Split checks exist because the two are driven by different controls.
        # A failing audio track must not push the CRF search downwards forever.
        assert video_meets_floor(report, policy)[0] is True
        assert audio_meets_floor(report, policy)[0] is False
        assert meets_floor(report, policy)[0] is False

    def test_failures_explain_themselves(self) -> None:
        from hypercompress.config import QualityPolicy
        from hypercompress.core.types import QualityReport

        ok, reasons = meets_floor(QualityReport(composite=0.5, video_score=0.5), QualityPolicy())
        assert not ok
        assert reasons and all(isinstance(r, str) and r for r in reasons)
        # The search steers on these strings, so they must name the metric.
        assert any("composite" in r or "video" in r for r in reasons)

    def test_search_margin_is_stricter_than_delivery(self) -> None:
        from hypercompress.config import QualityPolicy

        policy = QualityPolicy()
        strict = policy.with_search_margin()
        assert strict.floor > policy.floor
        assert strict.search_margin == 0.0, "the margin must not compound"


@requires_ffmpeg
class TestMeasurementConsistency:
    def test_fast_and_full_agree(
        self, runner: FFmpegRunner, moving_clip: Clip, degraded_clip: Clip
    ) -> None:
        """The property the whole search depends on."""
        from hypercompress.config import HyperCompressConfig

        media = MediaProbe(runner).probe(moving_clip.path)
        scorer = QualityScorer(runner, HyperCompressConfig.load().quality)

        fast = scorer.measure(moving_clip.path, degraded_clip.path, media, fast=True)
        full = scorer.measure(moving_clip.path, degraded_clip.path, media, fast=False)

        assert fast.video_score is not None and full.video_score is not None
        gap = abs(fast.video_score - full.video_score)
        assert gap < 0.05, (
            f"fast and full measurement disagree by {gap:.4f}. The search optimises "
            f"against the fast number and the operator sees the full one, so a gap "
            f"this size means delivered files miss the floor that was searched for."
        )

    def test_both_passes_report_the_same_metrics(
        self, runner: FFmpegRunner, moving_clip: Clip, degraded_clip: Clip
    ) -> None:
        # Composites built from different metric baskets are not comparable,
        # however close the individual numbers look.
        from hypercompress.config import HyperCompressConfig

        media = MediaProbe(runner).probe(moving_clip.path)
        scorer = QualityScorer(runner, HyperCompressConfig.load().quality)
        fast = scorer.measure(moving_clip.path, degraded_clip.path, media, fast=True)
        full = scorer.measure(moving_clip.path, degraded_clip.path, media, fast=False)

        for field in ("ms_ssim", "ssim", "psnr"):
            assert (getattr(fast, field) is None) == (getattr(full, field) is None), (
                f"{field} is present in one pass and absent in the other"
            )

    def test_a_degraded_encode_scores_worse(
        self, runner: FFmpegRunner, moving_clip: Clip, degraded_clip: Clip
    ) -> None:
        from hypercompress.config import HyperCompressConfig

        media = MediaProbe(runner).probe(moving_clip.path)
        scorer = QualityScorer(runner, HyperCompressConfig.load().quality)

        against_itself = scorer.measure(moving_clip.path, moving_clip.path, media, fast=True)
        against_degraded = scorer.measure(moving_clip.path, degraded_clip.path, media, fast=True)

        assert against_itself.video_score > against_degraded.video_score

    def test_vmaf_is_never_fabricated(
        self, runner: FFmpegRunner, moving_clip: Clip, degraded_clip: Clip
    ) -> None:
        """An estimate must never occupy the measured field."""
        from hypercompress.config import HyperCompressConfig

        media = MediaProbe(runner).probe(moving_clip.path)
        scorer = QualityScorer(runner, HyperCompressConfig.load().quality)
        report = scorer.measure(moving_clip.path, degraded_clip.path, media, fast=True)

        if not runner.capabilities.has_vmaf:
            assert report.vmaf is None, "an estimated VMAF must not be reported as measured"
            assert any(note.startswith("vmaf_estimate=") for note in report.notes), (
                "the estimate should still be available, but labelled"
            )
