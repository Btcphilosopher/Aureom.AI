"""Shared fixtures.

The corpus is generated rather than committed. Binary test fixtures rot, bloat
the repository, and cannot be regenerated when a question comes up that the
original clips do not answer. Generating them from FFmpeg's synthetic sources
means every clip is reproducible, deterministic, and describable in one line.

Clips are cached for the session because encoding them takes real time, and
scoped to a temporary directory so a test run leaves nothing behind.
"""

from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

import pytest

from hypercompress.config import HyperCompressConfig
from hypercompress.core.ffmpeg import FFmpegRunner, detect_capabilities

FFMPEG = shutil.which("ffmpeg")
requires_ffmpeg = pytest.mark.skipif(FFMPEG is None, reason="ffmpeg is not installed")


@dataclass(frozen=True)
class Clip:
    """A generated test clip and what it is meant to exercise."""

    path: Path
    description: str


def _run(args: list[str]) -> None:
    subprocess.run([FFMPEG or "ffmpeg", "-v", "error", "-y", *args], check=True)


@pytest.fixture(scope="session")
def corpus_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    return tmp_path_factory.mktemp("corpus")


@pytest.fixture(scope="session")
def capabilities() -> object:
    return detect_capabilities()


@pytest.fixture(scope="session")
def runner(capabilities: object) -> FFmpegRunner:
    return FFmpegRunner(capabilities)  # type: ignore[arg-type]


@pytest.fixture
def config() -> HyperCompressConfig:
    """A configuration tuned for tests: small budgets, few iterations."""
    return HyperCompressConfig.load().merged_with(
        search={"max_iterations": 2, "max_candidates": 3, "compute_budget_ratio": 8.0},
        distributed={"queue_backend": "memory"},
    )


# --------------------------------------------------------------------------------------
# Generated clips
# --------------------------------------------------------------------------------------


@pytest.fixture(scope="session")
def moving_clip(corpus_dir: Path) -> Clip:
    """Video with motion and audio: the ordinary case."""
    path = corpus_dir / "moving.mp4"
    if not path.exists():
        _run(
            [
                "-f",
                "lavfi",
                "-i",
                "testsrc2=size=320x240:rate=25:duration=4",
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=440:duration=4:sample_rate=48000",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "18",
                "-c:a",
                "aac",
                "-b:a",
                "128k",
                "-shortest",
                str(path),
            ]
        )
    return Clip(path, "moving synthetic pattern with a sine tone")


@pytest.fixture(scope="session")
def static_clip(corpus_dir: Path) -> Clip:
    """A near-static picture. Should compress enormously."""
    path = corpus_dir / "static.mp4"
    if not path.exists():
        _run(
            [
                "-f",
                "lavfi",
                "-i",
                "color=c=navy:size=320x240:rate=25:duration=4",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "18",
                "-an",
                str(path),
            ]
        )
    return Clip(path, "flat colour, no motion")


@pytest.fixture(scope="session")
def noisy_clip(corpus_dir: Path) -> Clip:
    """Pure noise: incompressible, and the honest limit of what codecs can do."""
    path = corpus_dir / "noise.mp4"
    if not path.exists():
        _run(
            [
                "-f",
                "lavfi",
                "-i",
                "nullsrc=size=320x240:rate=25:duration=3",
                "-vf",
                "geq=random(1)*255:128:128",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "16",
                "-an",
                str(path),
            ]
        )
    return Clip(path, "random noise, essentially incompressible")


@pytest.fixture(scope="session")
def speech_clip(corpus_dir: Path) -> Clip:
    """Audio only, speech-shaped: amplitude-modulated band-limited noise."""
    path = corpus_dir / "speech.flac"
    if not path.exists():
        _run(
            [
                "-f",
                "lavfi",
                "-i",
                "anoisesrc=color=pink:duration=4:sample_rate=48000",
                "-af",
                "lowpass=f=4000,tremolo=f=4:d=0.8",
                "-c:a",
                "flac",
                str(path),
            ]
        )
    return Clip(path, "band-limited pink noise with syllabic modulation")


@pytest.fixture(scope="session")
def music_clip(corpus_dir: Path) -> Clip:
    """Audio only, wideband and tonal."""
    path = corpus_dir / "music.flac"
    if not path.exists():
        _run(
            [
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=220:duration=4:sample_rate=48000",
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=1320:duration=4:sample_rate=48000",
                "-filter_complex",
                "[0:a][1:a]amix=inputs=2,aformat=channel_layouts=stereo",
                "-c:a",
                "flac",
                str(path),
            ]
        )
    return Clip(path, "two-tone stereo mix")


@pytest.fixture(scope="session")
def degraded_clip(corpus_dir: Path, moving_clip: Clip) -> Clip:
    """A visibly damaged re-encode of ``moving_clip``, for metric tests."""
    path = corpus_dir / "degraded.mp4"
    if not path.exists():
        _run(
            [
                "-i",
                str(moving_clip.path),
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "40",
                "-c:a",
                "aac",
                "-b:a",
                "24k",
                str(path),
            ]
        )
    return Clip(path, "heavily degraded copy of the moving clip")
