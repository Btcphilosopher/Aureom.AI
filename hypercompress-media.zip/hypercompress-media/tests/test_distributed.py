"""Tests for the distributed layer.

Both queue backends are tested through the same suite, because they are meant
to be interchangeable and the only way to keep them so is to test them
identically. Divergent behaviour between an in-memory queue used in development
and a durable one used in production is the kind of bug that only appears under
load, on a Friday.
"""

from __future__ import annotations

import time

import pytest

from hypercompress.core.errors import (
    ConfigError,
    EncodeTimeout,
    QuotaExceeded,
    SchedulingError,
    StorageError,
    UnsupportedMediaError,
)
from hypercompress.core.types import JobPriority, JobSpec, JobState
from hypercompress.distributed.queue import MemoryQueue, SqliteQueue, build_queue
from hypercompress.distributed.worker import Scheduler, is_retryable


@pytest.fixture(params=["memory", "sqlite"])
def queue(request: pytest.FixtureRequest, tmp_path):  # type: ignore[no-untyped-def]
    if request.param == "memory":
        return MemoryQueue()
    return SqliteQueue(tmp_path / "queue.db")


def job(job_id: str, priority: JobPriority = JobPriority.NORMAL, **kwargs: object) -> JobSpec:
    return JobSpec(job_id=job_id, source_uri=f"/media/{job_id}.mkv", priority=priority, **kwargs)


class TestQueueContract:
    def test_submit_then_claim(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a"))
        lease = queue.claim("worker-1")
        assert lease is not None
        assert lease.job.job_id == "a"
        assert lease.attempt == 1
        assert queue.state_of("a") is JobState.RUNNING

    def test_empty_queue_yields_nothing(self, queue) -> None:  # type: ignore[no-untyped-def]
        assert queue.claim("worker-1") is None

    def test_a_job_is_claimed_only_once(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a"))
        first = queue.claim("worker-1")
        second = queue.claim("worker-2")
        assert first is not None
        assert second is None, "two workers must never hold the same job"

    def test_urgent_work_is_claimed_first(self, queue) -> None:  # type: ignore[no-untyped-def]
        # JobPriority weights ascend as urgency falls, so reading them the
        # obvious way round puts bulk work at the head of the queue. This test
        # is here because that is exactly what happened.
        queue.submit(job("bulk", JobPriority.BULK))
        queue.submit(job("urgent", JobPriority.CRITICAL))
        queue.submit(job("normal", JobPriority.NORMAL))

        order = [queue.claim(f"w{i}").job.job_id for i in range(3)]
        assert order == ["urgent", "normal", "bulk"]

    def test_completion_records_a_result(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a"))
        lease = queue.claim("worker-1")
        queue.complete(lease, payload={"output_size": 42})
        assert queue.state_of("a") is JobState.SUCCEEDED
        assert queue.result_of("a") == {"output_size": 42}

    def test_failure_requeues_until_the_attempt_limit(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a", max_attempts=2))

        first = queue.claim("worker-1")
        assert queue.fail(first, "transient") is True, "the first failure should retry"
        assert queue.state_of("a") is JobState.QUEUED

        second = queue.claim("worker-2")
        assert second.attempt == 2
        assert queue.fail(second, "again") is False, "the limit must be respected"
        assert queue.state_of("a") is JobState.FAILED

    def test_a_permanent_failure_is_not_requeued(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a", max_attempts=5))
        lease = queue.claim("worker-1")
        assert queue.fail(lease, "unsupported codec", retry=False) is False
        assert queue.state_of("a") is JobState.FAILED

    def test_expired_leases_return_to_the_queue(self, queue) -> None:  # type: ignore[no-untyped-def]
        # This is the whole crash-recovery story: a worker that dies simply
        # stops renewing, and looks identical to one that got slow.
        queue.submit(job("a"))
        queue.claim("doomed-worker", lease_seconds=0.01)
        time.sleep(0.05)

        assert queue.reap_expired() == 1
        recovered = queue.claim("healthy-worker")
        assert recovered is not None and recovered.job.job_id == "a"

    def test_renewal_keeps_a_lease_alive(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a"))
        lease = queue.claim("worker-1", lease_seconds=0.2)
        assert queue.renew(lease, lease_seconds=30.0) is True
        time.sleep(0.25)
        assert queue.reap_expired() == 0, "a renewed lease must not be reclaimed"

    def test_a_stale_lease_cannot_renew_or_complete(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a"))
        stale = queue.claim("slow-worker", lease_seconds=0.01)
        time.sleep(0.05)
        queue.reap_expired()
        queue.claim("new-worker")

        assert queue.renew(stale) is False
        with pytest.raises(SchedulingError):
            # Otherwise two workers both write output for one job and the
            # second silently overwrites the first.
            queue.complete(stale)

    def test_release_returns_work_without_burning_an_attempt(self, queue) -> None:  # type: ignore[no-untyped-def]
        queue.submit(job("a"))
        lease = queue.claim("worker-1")
        queue.release(lease)
        assert queue.state_of("a") is JobState.QUEUED
        assert queue.claim("worker-2").attempt == 1, "graceful shutdown must not cost an attempt"

    def test_stats_and_depth_track_reality(self, queue) -> None:  # type: ignore[no-untyped-def]
        for i in range(3):
            queue.submit(job(f"j{i}"))
        assert queue.depth() == 3

        lease = queue.claim("worker-1")
        queue.complete(lease)
        stats = queue.stats()
        assert stats["succeeded"] == 1
        assert stats["pending"] == 2
        assert stats["running"] == 0


class TestBuildQueue:
    def test_memory_backend(self) -> None:
        assert isinstance(build_queue("memory"), MemoryQueue)

    def test_sqlite_requires_a_path(self) -> None:
        with pytest.raises(SchedulingError):
            build_queue("sqlite")

    def test_unknown_backend_is_named_in_the_error(self) -> None:
        with pytest.raises(SchedulingError, match="redis"):
            build_queue("redis")


class TestRetryClassification:
    @pytest.mark.parametrize(
        "error",
        [UnsupportedMediaError("bad codec"), ConfigError("nonsense"), QuotaExceeded("too much")],
    )
    def test_permanent_errors_are_not_retried(self, error: Exception) -> None:
        # Retrying these spends the fleet's capacity to reach the same answer
        # three times.
        assert is_retryable(error) is False

    @pytest.mark.parametrize("error", [EncodeTimeout("slow"), StorageError("network blip")])
    def test_transient_errors_are_retried(self, error: Exception) -> None:
        assert is_retryable(error) is True


class TestScheduler:
    def test_backpressure_refuses_work_beyond_the_limit(self, config) -> None:  # type: ignore[no-untyped-def]
        queue = MemoryQueue()
        scheduler = Scheduler(queue, config.merged_with(distributed={"max_queue_depth": 2}))
        scheduler.submit(job("a"))
        scheduler.submit(job("b"))

        # Accepting unbounded work turns a queue into a black hole: latency
        # climbs without limit and nothing signals that anything is wrong.
        with pytest.raises(QuotaExceeded):
            scheduler.submit(job("c"))

    def test_drain_returns_when_the_queue_empties(self, config) -> None:  # type: ignore[no-untyped-def]
        queue = MemoryQueue()
        scheduler = Scheduler(queue, config)
        assert scheduler.drain(poll=0.01, timeout=1.0) is True

    def test_drain_times_out_while_work_remains(self, config) -> None:  # type: ignore[no-untyped-def]
        queue = MemoryQueue()
        queue.submit(job("a"))
        scheduler = Scheduler(queue, config)
        assert scheduler.drain(poll=0.01, timeout=0.1) is False
