"""Tests for the safety-critical edges: access control, storage, dedup, API.

Grouped together because they share a theme. Each protects a property whose
violation is quiet: a tenant reading another's library, a write that truncated,
a deletion plan that contradicts itself, an endpoint that leaks whether a job
exists. None of these announce themselves at the time.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from hypercompress.config import HyperCompressConfig, SecurityConfig
from hypercompress.core.errors import AuthorizationError, QuotaExceeded, SecurityError, StorageError
from hypercompress.dedup.scanner import Deduplicator, plan_reclaim
from hypercompress.security.access import (
    ROLES,
    PathGuard,
    Permission,
    SecurityContext,
    validate_tenant,
)
from hypercompress.storage.backends import LocalStorage, build_storage


@pytest.fixture
def security() -> SecurityContext:
    return SecurityContext(
        SecurityConfig(
            tokens={
                "op": "alice:operator:acme",
                "view": "bob:viewer:acme",
                "root": "admin:admin:default",
                "rival": "carol:operator:globex",
            },
            audit_log_path=None,
        )
    )


class TestAccessControl:
    def test_a_role_grants_only_its_permissions(self, security: SecurityContext) -> None:
        alice = security.authorise("op", Permission.SUBMIT_JOB)
        assert alice.name == "alice" and alice.tenant == "acme"
        with pytest.raises(AuthorizationError):
            security.authorise("view", Permission.SUBMIT_JOB)

    def test_admin_holds_every_permission(self, security: SecurityContext) -> None:
        for permission in Permission:
            assert security.authorise("root", permission).is_admin

    def test_roles_are_ordered_by_capability(self) -> None:
        assert ROLES["viewer"] < ROLES["operator"] < ROLES["admin"]

    def test_tenants_cannot_reach_each_other(self, security: SecurityContext) -> None:
        with pytest.raises(AuthorizationError):
            security.authorise("op", Permission.READ_JOB, tenant="globex")
        # An admin legitimately crosses tenants; that is what the role is for.
        assert security.authorise("root", Permission.READ_JOB, tenant="globex")

    def test_a_denial_reveals_nothing_about_the_estate(self, security: SecurityContext) -> None:
        with pytest.raises(AuthorizationError) as exc:
            security.authorise("op", Permission.READ_JOB, tenant="globex")
        # Naming the tenant would confirm it exists to someone not entitled to
        # know that.
        assert "globex" not in str(exc.value)

    @pytest.mark.parametrize("token", [None, "", "guessed", "op "])
    def test_bad_credentials_are_refused(
        self, security: SecurityContext, token: str | None
    ) -> None:
        with pytest.raises(AuthorizationError):
            security.authorise(token, Permission.READ_JOB)

    @pytest.mark.parametrize("tenant", ["ACME", "../etc", "a/b", "", "x" * 70, "-leading"])
    def test_dangerous_tenant_identifiers_are_refused(self, tenant: str) -> None:
        # Tenants become path components, so this is path traversal defence.
        with pytest.raises(SecurityError):
            validate_tenant(tenant)


class TestPathGuard:
    def test_paths_inside_a_root_are_allowed(self, tmp_path: Path) -> None:
        (tmp_path / "media").mkdir()
        target = tmp_path / "media" / "clip.mkv"
        target.write_bytes(b"x")
        assert PathGuard([tmp_path / "media"]).check(target) == target.resolve()

    def test_traversal_is_refused(self, tmp_path: Path) -> None:
        (tmp_path / "media").mkdir()
        guard = PathGuard([tmp_path / "media"])
        with pytest.raises(SecurityError):
            guard.check(tmp_path / "media" / ".." / "secret.txt")

    def test_a_symlink_out_of_the_root_is_refused(self, tmp_path: Path) -> None:
        # Resolution happens before the check for exactly this case: a string
        # prefix test passes here and a resolved one does not.
        media = tmp_path / "media"
        media.mkdir()
        secret = tmp_path / "secret.txt"
        secret.write_text("private")
        (media / "link.txt").symlink_to(secret)

        with pytest.raises(SecurityError):
            PathGuard([media]).check(media / "link.txt")

    def test_no_roots_means_unrestricted(self, tmp_path: Path) -> None:
        assert PathGuard([]).check(tmp_path / "anything")


class TestQuotas:
    def test_concurrency_is_capped(self, security: SecurityContext) -> None:
        limit = security.config.max_concurrent_jobs_per_tenant
        for _ in range(limit):
            security.quotas.record_submission("acme")
        with pytest.raises(QuotaExceeded):
            security.quotas.check_submission("acme")

    def test_completion_frees_capacity(self, security: SecurityContext) -> None:
        for _ in range(security.config.max_concurrent_jobs_per_tenant):
            security.quotas.record_submission("acme")
        security.quotas.record_completion("acme")
        security.quotas.check_submission("acme")

    def test_one_tenant_cannot_exhaust_another(self, security: SecurityContext) -> None:
        for _ in range(security.config.max_concurrent_jobs_per_tenant):
            security.quotas.record_submission("acme")
        security.quotas.check_submission("globex")


class TestStorage:
    def test_a_write_round_trips(self, tmp_path: Path) -> None:
        source = tmp_path / "in.bin"
        source.write_bytes(b"payload" * 1000)
        storage = LocalStorage(tmp_path / "store")

        stored = storage.put(source, "a/b/out.bin")
        assert stored.size == source.stat().st_size
        assert storage.exists("a/b/out.bin")

        fetched = storage.get("a/b/out.bin", tmp_path / "back.bin")
        assert fetched.read_bytes() == source.read_bytes()

    def test_a_source_is_never_overwritten(self, tmp_path: Path) -> None:
        # The failure this prevents destroys the only copy of something.
        storage = LocalStorage(tmp_path)
        source = tmp_path / "media.mkv"
        source.write_bytes(b"original")
        with pytest.raises(StorageError):
            storage.put(source, "media.mkv")
        assert source.read_bytes() == b"original"

    def test_keys_cannot_escape_the_root(self, tmp_path: Path) -> None:
        storage = LocalStorage(tmp_path / "store")
        source = tmp_path / "in.bin"
        source.write_bytes(b"x")
        with pytest.raises(StorageError):
            storage.put(source, "../../escaped.bin")

    def test_listing_ignores_staging_files(self, tmp_path: Path) -> None:
        storage = LocalStorage(tmp_path / "store")
        source = tmp_path / "in.bin"
        source.write_bytes(b"x")
        storage.put(source, "real.bin")
        (Path(storage.root) / ".hc-leftover.part").write_bytes(b"junk")

        assert list(storage.list()) == ["real.bin"]

    def test_missing_objects_raise_rather_than_return_empty(self, tmp_path: Path) -> None:
        storage = LocalStorage(tmp_path)
        with pytest.raises(StorageError):
            storage.get("absent.bin", tmp_path / "out.bin")

    def test_uri_scheme_selects_the_backend(self, tmp_path: Path) -> None:
        assert isinstance(build_storage(str(tmp_path)), LocalStorage)
        assert isinstance(build_storage(f"file://{tmp_path}"), LocalStorage)


class TestDedup:
    def test_identical_files_are_grouped(self, tmp_path: Path) -> None:
        payload = b"same content" * 5000
        for name in ("a.mkv", "b.mkv", "nested/c.mkv"):
            path = tmp_path / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(payload)
        (tmp_path / "different.mkv").write_bytes(b"other content" * 5000)

        report = Deduplicator().scan(tmp_path.rglob("*.mkv"), stream_level=False)
        assert len(report.exact) == 1
        assert report.exact[0].copies == 3
        assert report.exact[0].reclaimable == len(payload) * 2

    def test_files_of_different_sizes_are_never_compared(self, tmp_path: Path) -> None:
        (tmp_path / "a.mkv").write_bytes(b"x" * 100)
        (tmp_path / "b.mkv").write_bytes(b"x" * 200)
        report = Deduplicator().scan(tmp_path.glob("*.mkv"), stream_level=False)
        assert report.exact == []

    def test_the_reclaim_plan_never_contradicts_itself(self, tmp_path: Path) -> None:
        """A file must never be both kept and dropped.

        A file can belong to two groups at once — byte-identical to one and,
        after remuxing, stream-identical to another. Each group picks a keeper
        independently, and an operator applying the plan top to bottom would
        delete a file another line told them to keep.
        """
        payload = b"content" * 5000
        for name in ("a.mkv", "b.mkv", "c.mkv"):
            (tmp_path / name).write_bytes(payload)

        report = Deduplicator().scan(tmp_path.glob("*.mkv"), stream_level=False)
        plan = plan_reclaim(report)

        keepers = {keeper for keeper, _ in plan}
        drops = {drop for _, drops in plan for drop in drops}
        assert not (keepers & drops)

    def test_nothing_is_deleted(self, tmp_path: Path) -> None:
        payload = b"content" * 5000
        for name in ("a.mkv", "b.mkv"):
            (tmp_path / name).write_bytes(payload)

        Deduplicator().scan(tmp_path.glob("*.mkv"), stream_level=False)
        plan_reclaim(Deduplicator().scan(tmp_path.glob("*.mkv"), stream_level=False))

        assert (tmp_path / "a.mkv").exists() and (tmp_path / "b.mkv").exists()


class TestApiContract:
    @pytest.fixture
    def client(self, tmp_path: Path):  # type: ignore[no-untyped-def]
        fastapi_testclient = pytest.importorskip("fastapi.testclient")
        from hypercompress.api.service import create_app

        media = tmp_path / "media"
        media.mkdir()
        (media / "clip.mkv").write_bytes(b"not really a video")

        config = HyperCompressConfig.load().merged_with(
            security={
                "require_auth": True,
                "tokens": {"op": "alice:operator:acme", "view": "bob:viewer:acme"},
                "audit_log_path": None,
            },
            storage={"allowed_roots": [str(media)]},
            distributed={"queue_backend": "memory"},
        )
        return fastapi_testclient.TestClient(create_app(config)), media

    def test_health_is_open_and_states_its_caveats(self, client) -> None:  # type: ignore[no-untyped-def]
        api, _ = client
        response = api.get("/health")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] in {"ok", "degraded"}
        if not body["vmaf_available"]:
            assert any("vmaf" in note.lower() for note in body["notes"]), (
                "an operator must learn at deploy time that VMAF will be estimated"
            )

    def test_endpoints_require_a_token(self, client) -> None:  # type: ignore[no-untyped-def]
        api, _ = client
        for path in ("/profiles", "/workers"):
            assert api.get(path).status_code == 403

    def test_permissions_are_enforced_per_endpoint(self, client) -> None:  # type: ignore[no-untyped-def]
        api, media = client
        viewer = {"Authorization": "Bearer view"}
        assert api.get("/profiles", headers=viewer).status_code == 200
        assert (
            api.post("/jobs", json={"source": str(media / "clip.mkv")}, headers=viewer).status_code
            == 403
        )

    def test_paths_outside_the_allowed_roots_are_refused(self, client) -> None:  # type: ignore[no-untyped-def]
        api, _ = client
        response = api.post(
            "/jobs", json={"source": "/etc/passwd"}, headers={"Authorization": "Bearer op"}
        )
        assert response.status_code == 400

    def test_an_unknown_job_is_a_404(self, client) -> None:  # type: ignore[no-untyped-def]
        api, _ = client
        assert api.get("/jobs/nope", headers={"Authorization": "Bearer op"}).status_code == 404

    def test_the_tenant_comes_from_the_token_not_the_body(self, client) -> None:  # type: ignore[no-untyped-def]
        api, media = client
        response = api.post(
            "/jobs",
            json={"source": str(media / "clip.mkv"), "tenant": "globex"},
            headers={"Authorization": "Bearer op"},
        )
        assert response.status_code == 202
        workers = api.get("/workers", headers={"Authorization": "Bearer op"}).json()
        assert "acme" in workers["quotas"]
        assert "globex" not in workers["quotas"]


class TestCandidateSelection:
    """The audio ladder shares a trace with the video search.

    Audio candidates are deliberately encoded without video, because including
    the video re-encode would make an audio search unaffordable. That makes the
    trace a mixture, and any code picking a winner out of it can pick an
    audio-only plan for a film. The result is a soundtrack shipped where a
    picture should be, which validation catches only afterwards and cannot
    explain.
    """

    def _evaluator(self, has_video: bool):  # type: ignore[no-untyped-def]
        from types import SimpleNamespace

        from hypercompress.optimisation.search import CandidateEvaluator

        media = SimpleNamespace(
            primary_video=object() if has_video else None,
            primary_audio=object(),
        )
        evaluator = CandidateEvaluator.__new__(CandidateEvaluator)
        evaluator.media = media  # type: ignore[attr-defined]
        return evaluator

    def _result(self, *, video: bool, audio: bool):  # type: ignore[no-untyped-def]
        from types import SimpleNamespace

        plan = SimpleNamespace(
            video=object() if video else None,
            audio=object() if audio else None,
            copy_video=False,
            copy_audio=False,
        )
        return SimpleNamespace(candidate=SimpleNamespace(plan=plan))

    def test_an_audio_only_plan_is_rejected_for_a_video_source(self) -> None:
        evaluator = self._evaluator(has_video=True)
        assert evaluator.represents_source(self._result(video=False, audio=True)) is False

    def test_a_complete_plan_is_accepted(self) -> None:
        evaluator = self._evaluator(has_video=True)
        assert evaluator.represents_source(self._result(video=True, audio=True)) is True

    def test_an_audio_only_plan_is_fine_for_an_audio_source(self) -> None:
        evaluator = self._evaluator(has_video=False)
        assert evaluator.represents_source(self._result(video=False, audio=True)) is True

    def test_dropping_audio_from_a_source_that_has_it_is_rejected(self) -> None:
        evaluator = self._evaluator(has_video=True)
        assert evaluator.represents_source(self._result(video=True, audio=False)) is False
