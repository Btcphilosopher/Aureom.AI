# Kubernetes manifests

Apply in filename order:

```
kubectl apply -f 00-namespace.yaml -f 01-config.yaml -f 02-secret.yaml
kubectl apply -f api.yaml -f worker.yaml
```

Replace the token in `02-secret.yaml` first. It is a placeholder, and a
deployment that keeps it has no authentication at all.

Two decisions worth reading before you deploy these.

**Workers are a Deployment, not a Job or StatefulSet.** They are stateless by
construction — all durable state lives in the queue — so a worker that dies is
replaced and its lease simply expires. There is nothing to recover and no
identity to preserve.

**`terminationGracePeriodSeconds` is 3600, not the default 30.** A worker
finishes the encode it holds before exiting. Thirty seconds would SIGKILL it
mid-encode on every rollout, wasting the work *and* leaving the job for someone
else to retry. An hour covers a long 4K encode; anything beyond it is reclaimed
by lease expiry, which is the mechanism that failure mode was designed for.

**Rollouts are one worker at a time** (`maxUnavailable: 1`). Recreating the tier
wholesale would abandon every in-flight encode simultaneously. A slow deploy is
the correct trade against losing hours of compute.
