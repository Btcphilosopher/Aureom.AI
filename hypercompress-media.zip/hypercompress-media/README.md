# HYPERCOMPRESS MEDIA

Hyperscale media compression that measures what it delivers.

The platform re-encodes audio and video to the smallest size that still clears
a configured perceptual quality floor, across a distributed fleet, and reports
honestly on what the reduction cost.

---

## What this will not tell you

Start here, because it is the part most compression tooling gets wrong.

**There is no free lunch.** Past a codec's lossless mode, every byte saved is
paid for in fidelity. This platform's job is to find the settings where that
payment buys the most, not to pretend the payment isn't happening. A typical
result on live-action video is a 55–75% reduction at a quality most viewers
will not distinguish from the source — but "will not distinguish" is a measured
claim here, not a marketing one.

**A number that was estimated is never presented as measured.** This build's
FFmpeg has no `libvmaf`. The platform still computes a VMAF estimate from
MS-SSIM and PSNR, because it is genuinely useful — but it goes in a note reading
`vmaf_estimate=NN`, never in the `vmaf` field, and the manifest, the API and the
console all mark it as an estimate.

**Some files should be left alone.** Already-efficient media, and cold archives
nobody reads, can cost more in compute than they will ever save in storage. The
platform detects both and says so rather than burning CPU to make a file 3%
smaller.

**Nothing is deleted, ever.** `dedup` prints a plan. There is no `--replace`
flag. A media library is often the only copy of something.

---

## Quick start

```bash
pip install -e ".[dev]"

# What would happen to this file? Costs seconds, encodes nothing.
hypercompress inspect film.mkv

# Compress it.
hypercompress optimise film.mkv -o film.optimised.mkv --profile balanced

# Make it fit a budget, and say so plainly if that isn't possible.
hypercompress optimise film.mkv -o out.mkv --target-size 1GB

# A directory, across a worker pool.
hypercompress batch /media /media-optimised --workers 4

# What duplicates are in here? (Reports only.)
hypercompress dedup /media --streams

# Was any of it worth it?
hypercompress cost /media-optimised
```

`ffmpeg` and `ffprobe` must be on `PATH`. Python 3.12+.

---

## How it decides

Twelve phases, but three ideas carry most of the weight.

### 1. Content analysis drives everything

A podcast, a sports broadcast and a screen recording want completely different
settings, and the difference is worth far more than any codec tuning. The
classifier is a transparent scored ensemble — every decision comes with the
evidence behind it:

```
content    documentary (65% confidence)
           - general video baseline
```

### 2. The search measures rather than predicts

Bitrate calculators predict quality from a model. This searches: encode a
candidate, measure it against the source, adjust. Sampled during the search for
speed, then re-encoded and re-measured in full before anything is written.

Four strategies, chosen by profile:

| Situation | Strategy |
|---|---|
| A size target was given | CRF bisection on measured size, then resolution descent |
| Profile is `extreme` / `ultra` | Search across codecs *and* resolutions |
| Profile is `lossless` | One encode, verified bit-identical or rejected |
| Otherwise | CRF bisection against the quality floor |

Video and audio are searched with **separate controls** — CRF for one, a ladder
of complete parameter sets for the other. They are not interchangeable, and a
failing audio track must not drive the CRF search downwards forever.

### 3. Nothing counts until it validates

Encoders exit zero on truncated writes, dropped streams and wrong durations.
Every output must decode cleanly end to end, match the source duration, retain
the streams it was meant to, and — for lossless plans — decode bit-identically.
Only then is a manifest written.

---

## Profiles

Fifteen built in. `hypercompress profiles` lists them with descriptions.

The interesting ones: `archive` (encode time is nearly free when storage is
paid monthly for years), `extreme` (searches codecs and resolutions, reports the
trade-off rather than hiding it), `cinema` (preserves grain and HDR, because
removing grain is removing the photography), `surveillance` (long GOPs and low
frame rates for footage that is 99% static).

Site profiles can be dropped into `profiles_dir` as TOML or JSON.

---

## Architecture

```
hypercompress/
  core/          types, config, errors, hashing, process, ffmpeg  ← security boundary
  analysis/      probing, scene detection, content classification
  codecs/        AV1, HEVC, H.264, VP9, Opus, AAC, FLAC, hardware
  quality/       PSNR, SSIM, MS-SSIM, VMAF, audio metrics, scoring
  optimisation/  planner, profiles, and the four search strategies
  pipeline/      encode execution, validation, manifests
  distributed/   queues, workers, scheduling
  storage/       local and S3, never overwriting a source
  dedup/         exact, container-level and chunk-level
  analytics/     Prometheus metrics, cloud economics
  security/      identity, authorisation, isolation, quotas
  api/           FastAPI service
  cli.py         six verbs
dashboard/       React + TypeScript console
```

**FFmpeg is reachable only through `core/ffmpeg.py`.** Flags come from an
allowlist, values are validated against a character class, filter names are
checked against a set that excludes the ones which read paths or open network
connections. There is no code path that accepts encoder arguments from a
caller, at any privilege level — see `security/access.py` for why that is a
design property rather than an omission.

---

## Deployment

```bash
docker compose up          # API plus two workers
kubectl apply -f deploy/k8s/
```

Two details in the manifests worth knowing about:

**Workers get a one-hour termination grace period.** They handle `SIGTERM` by
finishing the encode in hand, so a rolling deploy costs one encode's latency
rather than one encode's work.

**Autoscaling is on queue depth, not CPU.** An encoding fleet is at 100% CPU by
design; CPU tells you nothing about whether it is keeping up.

Before exposing the API to anyone but yourself, set
`storage.allowed_roots` — empty means any readable path may be submitted, and
`/health` will say so.

---

## The console

```bash
cd dashboard && npm install && npm run dev
```

One view carries the whole thing: every delivered job plotted as size saved
against measured quality, with the configured floor drawn as a hard line.
Points below it are files that shipped worse than they were promised — the
failure nobody notices until the sources have been deleted, and the reason this
is the centrepiece instead of a row of throughput tiles.

The other rule the console follows is that **measured and estimated values never
look alike**. Cyan is only ever a number verified against the source. A VMAF
derived from MS-SSIM because libvmaf is absent renders in slate and says
"estimated". An interface that styles the two identically is lying on the
platform's behalf.

---

## Testing

```bash
pytest                      # ~110 tests
pytest -m "not slow"        # skip the ones that encode
```

The corpus is generated from FFmpeg's synthetic sources rather than committed:
reproducible, and extensible when a question comes up the original clips don't
answer.

The tests worth reading first are in `test_ffmpeg_args.py`, which is written as
attacks rather than happy paths, and `test_quality.py::TestMeasurementConsistency`,
which guards the property everything else depends on — that the fast measurement
the search optimises against agrees with the full measurement the operator sees.
That property did not hold at first, and the gap ran to 0.43.

---

## Documentation

- [`docs/architecture.md`](docs/architecture.md) — how the pieces fit
- [`docs/quality.md`](docs/quality.md) — what the metrics mean and how they were calibrated
- [`docs/operations.md`](docs/operations.md) — running a fleet
- [`docs/api.md`](docs/api.md) — endpoint reference

## Licence

MIT.
