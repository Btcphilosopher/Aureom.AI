"""Security: identity, authorisation, isolation and quotas (Phase 21).

Four separate concerns, deliberately kept separate because conflating them is
how multi-tenant systems leak:

**Identity** — who is calling. A bearer token maps to a :class:`Principal`.
Tokens are compared with a constant-time function, and only ever by digest, so
neither a timing signal nor a log line can leak one.

**Authorisation** — what that principal may do. Roles grant permissions; the
check is on the permission, never on the role name, so adding a role never
requires revisiting call sites.

**Isolation** — what that principal may see. Tenant scoping is applied to every
lookup rather than trusted to callers, because the failure mode of "the caller
remembered to filter by tenant" is one tenant reading another's library.

**Quotas** — how much they may consume. Encoding is expensive and unbounded work
is a denial of service against every other tenant on the fleet.

A note on what this module deliberately does *not* do. It does not accept
FFmpeg arguments, filter graphs or codec options from any caller at any
privilege level. There is no permission that grants it, because the safe way to
handle arbitrary encoder arguments is not to have a path for them at all —
FFmpeg's argument surface includes file writes, network protocols and process
behaviour that no allowlist audit could confidently cover. Every encode is built
from a typed :class:`~hypercompress.core.types.EncodePlan` by
:mod:`hypercompress.core.ffmpeg`.
"""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path

from hypercompress.config import SecurityConfig
from hypercompress.core.errors import AuthorizationError, QuotaExceeded, SecurityError
from hypercompress.core.logging import AuditLog, get_logger

log = get_logger(__name__)

#: Tenant identifiers become path components, so they are restricted to
#: characters that cannot traverse or escape a directory.
TENANT_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")


class Permission(StrEnum):
    """The things a caller can be allowed to do."""

    READ_JOB = "job:read"
    SUBMIT_JOB = "job:submit"
    CANCEL_JOB = "job:cancel"
    READ_PROFILE = "profile:read"
    WRITE_PROFILE = "profile:write"
    READ_METRICS = "metrics:read"
    ANALYSE = "media:analyse"
    ADMIN = "admin"


ROLES: dict[str, frozenset[Permission]] = {
    "viewer": frozenset({Permission.READ_JOB, Permission.READ_PROFILE}),
    "analyst": frozenset(
        {Permission.READ_JOB, Permission.READ_PROFILE, Permission.ANALYSE, Permission.READ_METRICS}
    ),
    "operator": frozenset(
        {
            Permission.READ_JOB,
            Permission.SUBMIT_JOB,
            Permission.CANCEL_JOB,
            Permission.READ_PROFILE,
            Permission.ANALYSE,
            Permission.READ_METRICS,
        }
    ),
    "admin": frozenset(Permission),
}


@dataclass(frozen=True, slots=True)
class Principal:
    """An authenticated caller."""

    name: str
    role: str
    tenant: str
    permissions: frozenset[Permission] = field(default_factory=frozenset)

    @property
    def is_admin(self) -> bool:
        return Permission.ADMIN in self.permissions

    def can(self, permission: Permission) -> bool:
        return permission in self.permissions

    def require(self, permission: Permission) -> None:
        if not self.can(permission):
            raise AuthorizationError(
                f"{self.name} holds the {self.role} role, which does not grant {permission.value}"
            )

    def owns(self, tenant: str) -> bool:
        """Whether this principal may act on ``tenant``'s data."""
        return self.is_admin or self.tenant == tenant

    def require_tenant(self, tenant: str) -> None:
        if not self.owns(tenant):
            # The message deliberately does not confirm whether the tenant
            # exists: an unauthorised caller learns nothing about the estate.
            raise AuthorizationError("this resource is not available to your tenant")

    def as_dict(self) -> dict[str, str]:
        return {"principal": self.name, "role": self.role, "tenant": self.tenant}


ANONYMOUS = Principal(
    name="anonymous", role="viewer", tenant="default", permissions=ROLES["viewer"]
)
SYSTEM = Principal(name="system", role="admin", tenant="default", permissions=ROLES["admin"])


def _digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


class Authenticator:
    """Resolves bearer tokens to principals.

    Tokens are held only as digests. A configuration file is a common thing to
    accidentally print, mount into a container image, or check into a
    repository; a digest in any of those places is not a credential.
    """

    def __init__(self, config: SecurityConfig) -> None:
        self.config = config
        self._by_digest: dict[str, Principal] = {}
        for token, descriptor in config.tokens.items():
            principal = self._parse(descriptor)
            self._by_digest[_digest(token)] = principal
        self.audit = AuditLog(config.audit_log_path) if config.audit_log_path else None

    def _parse(self, descriptor: str) -> Principal:
        parts = [p.strip() for p in descriptor.split(":")]
        if not parts or not parts[0]:
            raise SecurityError(f"malformed token descriptor: {descriptor!r}")
        name = parts[0]
        role = parts[1] if len(parts) > 1 and parts[1] else self.config.default_role
        tenant = parts[2] if len(parts) > 2 and parts[2] else "default"
        if role not in ROLES:
            raise SecurityError(
                f"unknown role {role!r} for {name}; known roles are {', '.join(sorted(ROLES))}"
            )
        validate_tenant(tenant)
        return Principal(name=name, role=role, tenant=tenant, permissions=ROLES[role])

    def authenticate(self, token: str | None) -> Principal:
        """Resolve a bearer token, or raise."""
        if not self.config.require_auth:
            return SYSTEM
        if not token:
            raise AuthorizationError("a bearer token is required")

        presented = _digest(token)
        # Compare against every known digest with a constant-time comparison and
        # without short-circuiting, so neither the number of configured tokens
        # nor how close a guess was can be inferred from response timing.
        matched: Principal | None = None
        for digest, principal in self._by_digest.items():
            if hmac.compare_digest(presented, digest):
                matched = principal
        if matched is None:
            self.record("auth.failed", ANONYMOUS, {"reason": "unknown token"})
            raise AuthorizationError("the supplied credentials were not recognised")
        return matched

    def record(
        self, action: str, principal: Principal, details: dict[str, object] | None = None
    ) -> None:
        """Append to the audit log, if one is configured."""
        if self.audit is None:
            return
        self.audit.record(
            action,
            principal=principal.name,
            tenant=principal.tenant,
            role=principal.role,
            **(details or {}),
        )

    @staticmethod
    def issue_token() -> str:
        """Generate a token with enough entropy to resist offline search."""
        return secrets.token_urlsafe(32)


def validate_tenant(tenant: str) -> str:
    """Reject a tenant identifier that could escape its own directory."""
    if not TENANT_RE.match(tenant):
        raise SecurityError(
            f"invalid tenant identifier {tenant!r}: use lowercase letters, digits, "
            f"hyphens and underscores only"
        )
    return tenant


class PathGuard:
    """Confines file access to configured roots.

    Job specifications carry filesystem paths, and a path is the easiest thing
    in the whole API to turn into an arbitrary read. Every path is resolved
    first — following symlinks — and then checked, because ``/allowed/link``
    pointing at ``/etc`` passes a string-prefix test and fails this one.
    """

    def __init__(self, roots: list[Path] | None = None) -> None:
        self.roots = [Path(r).expanduser().resolve() for r in (roots or [])]

    def check(self, path: str | Path, *, must_exist: bool = False) -> Path:
        candidate = Path(path).expanduser()
        try:
            resolved = candidate.resolve()
        except OSError as exc:
            raise SecurityError(f"path could not be resolved: {path}") from exc

        if must_exist and not resolved.exists():
            raise SecurityError(f"path does not exist: {path}")

        if not self.roots:
            return resolved
        for root in self.roots:
            if resolved == root or root in resolved.parents:
                return resolved
        raise SecurityError(
            f"path {resolved} lies outside every configured media root; "
            f"add it to storage.allowed_roots if this is intended"
        )

    def tenant_root(self, base: Path, tenant: str) -> Path:
        """The directory a tenant's outputs belong in."""
        validate_tenant(tenant)
        root = (Path(base) / tenant).resolve()
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        return root


@dataclass(slots=True)
class TenantUsage:
    """Consumption for one tenant."""

    jobs_submitted: int = 0
    jobs_running: int = 0
    bytes_processed: int = 0

    def as_dict(self) -> dict[str, int]:
        return {
            "jobs_submitted": self.jobs_submitted,
            "jobs_running": self.jobs_running,
            "bytes_processed": self.bytes_processed,
        }


class QuotaEnforcer:
    """Keeps one tenant from consuming the fleet.

    Checked at submission rather than at execution: rejecting a job when it is
    queued gives the caller an immediate, actionable error, whereas failing it
    an hour later after a worker has picked it up wastes both the caller's time
    and the fleet's.
    """

    def __init__(self, config: SecurityConfig) -> None:
        self.config = config
        self._usage: dict[str, TenantUsage] = {}

    def usage(self, tenant: str) -> TenantUsage:
        return self._usage.setdefault(tenant, TenantUsage())

    def check_submission(self, tenant: str, *, size_bytes: int = 0) -> None:
        usage = self.usage(tenant)
        if usage.jobs_submitted >= self.config.max_jobs_per_tenant:
            raise QuotaExceeded(
                f"tenant {tenant} has reached its limit of {self.config.max_jobs_per_tenant} jobs"
            )
        if usage.jobs_running >= self.config.max_concurrent_jobs_per_tenant:
            raise QuotaExceeded(
                f"tenant {tenant} already has "
                f"{self.config.max_concurrent_jobs_per_tenant} jobs in flight; "
                f"wait for one to finish"
            )
        if usage.bytes_processed + size_bytes > self.config.max_bytes_per_tenant:
            raise QuotaExceeded(f"tenant {tenant} has reached its byte allowance")

    def record_submission(self, tenant: str, *, size_bytes: int = 0) -> None:
        usage = self.usage(tenant)
        usage.jobs_submitted += 1
        usage.jobs_running += 1
        usage.bytes_processed += size_bytes

    def record_completion(self, tenant: str) -> None:
        usage = self.usage(tenant)
        usage.jobs_running = max(0, usage.jobs_running - 1)

    def snapshot(self) -> dict[str, dict[str, int]]:
        return {tenant: usage.as_dict() for tenant, usage in self._usage.items()}


def secure_scratch(base: Path, mode: int = 0o700) -> Path:
    """Create a scratch directory only its owner can read.

    Intermediate encodes are the plaintext of whatever was submitted. On a
    shared host a world-readable temp directory hands every other process on
    the box a copy of every tenant's media.
    """
    base = Path(base)
    base.mkdir(parents=True, exist_ok=True)
    base.chmod(mode)
    return base


class SecurityContext:
    """The security services, assembled once and passed around together."""

    def __init__(self, config: SecurityConfig, *, allowed_roots: list[Path] | None = None) -> None:
        self.config = config
        self.authenticator = Authenticator(config)
        self.paths = PathGuard(allowed_roots)
        self.quotas = QuotaEnforcer(config)

    def authorise(
        self,
        token: str | None,
        permission: Permission,
        *,
        tenant: str | None = None,
    ) -> Principal:
        """Authenticate, check the permission, and check tenant ownership."""
        principal = self.authenticator.authenticate(token)
        principal.require(permission)
        if tenant is not None and self.config.tenant_isolation:
            principal.require_tenant(tenant)
        return principal

    def audit(self, action: str, principal: Principal, **details: object) -> None:
        self.authenticator.record(action, principal, details)
