"""Identity, authorisation, isolation and quotas.

Four separate concerns, kept separate on purpose: conflating them is how
multi-tenant systems leak.
"""

from __future__ import annotations

from hypercompress.security.access import (
    ANONYMOUS,
    ROLES,
    SYSTEM,
    Authenticator,
    PathGuard,
    Permission,
    Principal,
    QuotaEnforcer,
    SecurityContext,
    validate_tenant,
)

__all__ = [
    "ANONYMOUS",
    "ROLES",
    "SYSTEM",
    "Authenticator",
    "PathGuard",
    "Permission",
    "Principal",
    "QuotaEnforcer",
    "SecurityContext",
    "validate_tenant",
]
