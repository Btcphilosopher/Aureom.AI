"""Output validation and packaging (Phases 11 and 12).

An encoder exiting zero is not evidence that it produced a usable file. FFmpeg
will happily return success on a truncated write, a stream it silently dropped,
or a container it muxed with a duration nowhere near the source's. At the scale
this platform is meant to run — deleting or tiering away the originals once the
optimised copy lands — that gap is the difference between saving storage and
losing the library.

So every output is checked before it is allowed to count:

* it decodes end to end, without errors, from first frame to last;
* its duration matches the source within tolerance;
* the streams that were meant to survive did survive;
* it is not implausibly small for its duration;
* for lossless plans, the decoded frames are bit-identical to the source.

Only then is a manifest written. The manifest is the durable record of what was
done and what it cost: source and output digests, the exact plan, the measured
quality, the resources consumed, and — importantly — the caveats. A manifest
that quietly omits "this was measured with an estimated VMAF" or "this sits
below the quality floor you configured" is worse than none at all, because
someone will trust it later.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from hypercompress.core.errors import ValidationError
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner
from hypercompress.core.hashing import file_digest
from hypercompress.core.logging import get_logger
from hypercompress.core.types import EncodePlan, Manifest, MediaProfile, QualityReport, RateControl
from hypercompress.core.units import format_size

log = get_logger(__name__)

#: Output duration may differ from the source by this fraction before it counts
#: as a truncation. Container timestamp rounding and encoder frame padding both
#: move the number slightly; anything beyond this is a real loss.
DURATION_TOLERANCE = 0.02

#: An output below this fraction of its predicted size is treated as suspect
#: even if it decodes, because the usual cause is a stream that vanished.
IMPLAUSIBLE_RATIO = 0.02


@dataclass(slots=True)
class ValidationReport:
    """Everything checked, and everything that failed."""

    path: Path
    ok: bool = True
    checks: list[str] = field(default_factory=list)
    failures: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    output_profile: MediaProfile | None = None
    decoded_frames: int = 0

    def passed(self, check: str) -> None:
        self.checks.append(check)

    def failed(self, reason: str) -> None:
        self.ok = False
        self.failures.append(reason)

    def warn(self, reason: str) -> None:
        self.warnings.append(reason)

    def raise_for_status(self) -> None:
        if not self.ok:
            raise ValidationError(
                f"{self.path.name} failed validation: " + "; ".join(self.failures)
            )


class OutputValidator:
    """Checks that an encode produced something worth keeping."""

    def __init__(self, runner: FFmpegRunner) -> None:
        self.runner = runner

    def validate(
        self,
        output: Path,
        source: MediaProfile,
        plan: EncodePlan,
        *,
        deep: bool = True,
        expect_lossless: bool = False,
    ) -> ValidationReport:
        report = ValidationReport(path=output)

        if not output.exists():
            report.failed("the output file does not exist")
            return report
        size = output.stat().st_size
        if size == 0:
            report.failed("the output file is empty")
            return report
        report.passed(f"file present, {format_size(size)}")

        try:
            from hypercompress.analysis.media_probe import MediaProbe

            profile = MediaProbe(self.runner).probe(output)
        except Exception as exc:  # noqa: BLE001 - an unprobeable file is a failed file
            report.failed(f"the output could not be probed: {exc}")
            return report
        report.output_profile = profile
        report.passed("container parses and streams are readable")

        self._check_streams(report, source, profile, plan)
        self._check_duration(report, source, profile)
        self._check_plausibility(report, source, profile, size)

        if deep:
            self._check_decodes(report, output)
        if expect_lossless:
            self._check_lossless(report, source, output)

        return report

    # -- individual checks -----------------------------------------------------------
    def _check_streams(
        self,
        report: ValidationReport,
        source: MediaProfile,
        output: MediaProfile,
        plan: EncodePlan,
    ) -> None:
        if source.primary_video is not None and output.primary_video is None:
            report.failed("the source has video but the output does not")
        elif source.primary_video is not None:
            report.passed("video stream present")

        if source.primary_audio is not None and output.primary_audio is None:
            report.failed("the source has audio but the output does not")
        elif source.primary_audio is not None:
            report.passed("audio stream present")

        if plan.keep_subtitles and source.subtitles and not output.subtitles:
            # A dropped subtitle track is a real loss but not a corrupt file, so
            # it is a warning: the operator should know, the job need not fail.
            report.warn(
                f"{len(source.subtitles)} subtitle track(s) did not survive into the output"
            )
        if plan.keep_chapters and source.chapters and not output.chapters:
            report.warn(f"{len(source.chapters)} chapter mark(s) were lost")
        if plan.keep_all_audio_tracks and len(output.audio) < len(source.audio):
            report.warn(f"only {len(output.audio)} of {len(source.audio)} audio tracks survived")

    def _check_duration(
        self, report: ValidationReport, source: MediaProfile, output: MediaProfile
    ) -> None:
        if source.duration <= 0:
            report.warn("the source duration is unknown; the length check was skipped")
            return
        drift = abs(output.duration - source.duration) / source.duration
        if drift > DURATION_TOLERANCE:
            report.failed(
                f"duration drifted by {drift:.1%} "
                f"({output.duration:.2f}s vs {source.duration:.2f}s) — the output is truncated "
                f"or the source was mis-timed"
            )
        else:
            report.passed(f"duration matches within {drift:.2%}")

    def _check_plausibility(
        self,
        report: ValidationReport,
        source: MediaProfile,
        output: MediaProfile,
        size: int,
    ) -> None:
        if source.size_bytes <= 0:
            return
        ratio = size / source.size_bytes
        if ratio < IMPLAUSIBLE_RATIO:
            report.warn(
                f"the output is {ratio:.2%} of the source, which is far beyond what encoding "
                f"alone normally achieves — check that no stream was dropped"
            )
        if size > source.size_bytes:
            report.warn(
                f"the output is larger than the source ({format_size(size)} vs "
                f"{format_size(source.size_bytes)}); the original is the better file to keep"
            )

    def _check_decodes(self, report: ValidationReport, output: Path) -> None:
        """Decode the whole file to the null sink and insist on a clean run."""
        args = (
            ArgBuilder()
            .opt("-v", "error")
            .path("-i", output)
            .flag("-sn")
            .flag("-dn")
            .opt("-f", "null")
        )
        args.path(None, "/dev/null")
        result = self.runner.run(args, check=False)
        if result.returncode != 0:
            report.failed(f"the output failed a full decode: {result.tail(6)}")
            return
        noise = [line for line in result.stderr.splitlines() if line.strip()]
        if noise:
            # Errors printed at -v error during a successful decode mean damaged
            # packets that the decoder concealed. The file plays, but not
            # faithfully, so it must not silently pass.
            report.failed("the output decoded with concealed errors: " + "; ".join(noise[:3]))
            return
        report.passed("full decode clean from first frame to last")

    def _check_lossless(self, report: ValidationReport, source: MediaProfile, output: Path) -> None:
        """Verify a lossless claim by comparing decoded frames, not file bytes.

        The container and the bitstream will differ; the pixels must not.
        """
        graph = "[0:v][1:v]psnr"
        args = (
            ArgBuilder()
            .opt("-v", "info")
            .path("-i", source.path)
            .path("-i", output)
            .opt("-lavfi", graph)
            .opt("-f", "null")
        )
        args.path(None, "/dev/null")
        result = self.runner.run(args, check=False)
        text = result.stderr + result.stdout
        if "inf" in text.lower() and "psnr" in text.lower():
            report.passed("decoded output is bit-identical to the source")
            return
        report.failed(
            "a lossless encode was requested but the decoded output differs from the source; "
            "the result has been rejected rather than shipped under a false promise"
        )


class Packager:
    """Writes the durable record of an optimisation."""

    def __init__(self, runner: FFmpegRunner) -> None:
        self.runner = runner

    def manifest(
        self,
        *,
        source: MediaProfile,
        output: Path,
        plan: EncodePlan,
        quality: QualityReport,
        validation: ValidationReport,
        profile_name: str,
        job_id: str,
        notes: list[str] | None = None,
        checksum_source: bool = True,
    ) -> Manifest:
        """Assemble a manifest, including the caveats."""
        output_digest = file_digest(output)
        source_digest = source.checksum or (
            file_digest(Path(source.path)) if checksum_source else None
        )

        caveats = list(notes or [])
        caveats.extend(validation.warnings)
        if quality.vmaf is None:
            caveats.append(
                "VMAF was not measured; any VMAF figure in this record is an estimate derived "
                "from MS-SSIM and PSNR"
            )
        if plan.video is not None and plan.video.rate_control is not RateControl.LOSSLESS:
            caveats.append(
                "this is a lossy encode: the output is not recoverable to the source, and the "
                "saving was paid for in fidelity"
            )

        output_size = output.stat().st_size
        return Manifest(
            job_id=job_id,
            created_at=datetime.now(UTC),
            profile=profile_name,
            source_path=str(source.path),
            source_size=source.size_bytes,
            source_checksum=source_digest,
            output_path=str(output),
            output_size=output_size,
            output_checksum=output_digest,
            compression_ratio=(source.size_bytes / output_size) if output_size else 1.0,
            size_reduction=1.0 - (output_size / source.size_bytes) if source.size_bytes else 0.0,
            plan=plan,
            quality=quality,
            lossless=plan.video is not None and plan.video.rate_control is RateControl.LOSSLESS,
            validated=validation.ok,
            validation_notes=list(validation.checks) + list(validation.warnings),
            validation_failures=list(validation.failures),
            caveats=caveats,
        )

    def write(self, manifest: Manifest, destination: Path) -> Path:
        """Write the manifest as JSON alongside the output."""
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = manifest.model_dump(mode="json")
        destination.write_text(
            json.dumps(payload, indent=2, sort_keys=False) + "\n", encoding="utf-8"
        )
        log.info("manifest written", extra={"path": str(destination), "job_id": manifest.job_id})
        return destination

    def sidecar_path(self, output: Path) -> Path:
        return output.with_suffix(output.suffix + ".manifest.json")
