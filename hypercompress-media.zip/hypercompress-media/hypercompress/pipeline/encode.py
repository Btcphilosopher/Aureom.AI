"""Encode execution (Phases 06 and 10).

This module is the only place in the platform that turns an :class:`EncodePlan`
into a running FFmpeg process. Everything upstream reasons about *policy* —
which codec, what CRF, which resolution — and hands that policy here as typed
data. Nothing here accepts a string of flags from a caller.

Three execution modes are supported:

``full``
    Encode the whole file. Used for the final winning candidate.
``segment``
    Encode a contiguous slice. Used by the search loop when the file is long
    enough that encoding it twelve times would cost more than it saves.
``sampled``
    Encode several short clips concatenated by the ``select`` filter into one
    output. This gives the search a size signal drawn from the whole running
    time rather than from whichever three minutes happen to sit at the front,
    which matters enormously for anything with a title sequence.

Two-pass encoding runs the analysis pass to the null sink and keeps the log in
scratch, so a crashed first pass can never leave a stale log that silently
corrupts the next attempt.
"""

from __future__ import annotations

import shutil
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from hypercompress.analysis.containers import container_supports_subtitles
from hypercompress.codecs import REGISTRY
from hypercompress.core.errors import EncodeError
from hypercompress.core.ffmpeg import (
    ArgBuilder,
    EncodeProgress,
    FFmpegRunner,
    build_filter_chain,
    build_window_select_graph,
)
from hypercompress.core.logging import get_logger
from hypercompress.core.process import CommandResult
from hypercompress.core.types import (
    EncodePlan,
    MediaProfile,
    RateControl,
    ResourceUsage,
    VideoEncodeParams,
)

log = get_logger(__name__)

ProgressCallback = Callable[[EncodeProgress], None]

#: Muxer names FFmpeg wants for our container aliases.
_MUXER = {
    "mkv": "matroska",
    "mp4": "mp4",
    "webm": "webm",
    "mov": "mov",
    "opus": "opus",
    "ogg": "ogg",
    "m4a": "ipod",
    "flac": "flac",
    "mp3": "mp3",
    "wav": "wav",
}

#: Subtitle codecs each container will actually accept.
_SUBTITLE_CODEC = {"mkv": "srt", "webm": "webvtt", "mp4": "mov_text", "mov": "mov_text"}


@dataclass(slots=True)
class SamplePlan:
    """A set of clips standing in for the whole file during the search."""

    offsets: tuple[float, ...]
    clip_seconds: float

    @property
    def total_seconds(self) -> float:
        return len(self.offsets) * self.clip_seconds

    def windows(self) -> list[tuple[float, float]]:
        return [(start, start + self.clip_seconds) for start in self.offsets]

    def fraction_of(self, duration: float) -> float:
        if duration <= 0:
            return 1.0
        return min(1.0, self.total_seconds / duration)


@dataclass(slots=True)
class EncodeRequest:
    """Everything needed to run one encode."""

    source: Path
    output: Path
    plan: EncodePlan
    profile: MediaProfile
    start: float | None = None
    duration: float | None = None
    sample: SamplePlan | None = None
    scene_bitrates: tuple[float, ...] = ()
    timeout: float | None = None
    on_progress: ProgressCallback | None = None

    @property
    def is_partial(self) -> bool:
        return self.sample is not None or self.start is not None or self.duration is not None

    @property
    def encoded_seconds(self) -> float:
        """How much running time this request actually covers."""
        if self.sample is not None:
            return min(self.sample.total_seconds, self.profile.duration)
        if self.duration is not None:
            return min(self.duration, self.profile.duration)
        return self.profile.duration


@dataclass(slots=True)
class EncodeOutcome:
    """The measured result of running one encode."""

    output: Path
    size: int
    usage: ResourceUsage
    encoded_seconds: float
    sampled: bool
    command: list[str] = field(default_factory=list)

    @property
    def bitrate(self) -> float:
        if self.encoded_seconds <= 0:
            return 0.0
        return self.size * 8 / self.encoded_seconds


def _video_filters(
    params: VideoEncodeParams, source: MediaProfile
) -> list[tuple[str, dict[str, object]] | str]:
    """Assemble the video filter chain in the order the pixels need it."""
    chain: list[tuple[str, dict[str, object]] | str] = []
    if params.deinterlace:
        # Deinterlace before scaling: scaling interlaced fields together is what
        # produces the comb artefacts people blame on the encoder.
        chain.append(("yadif", {"mode": 0, "parity": -1, "deint": 0}))
    if params.denoise:
        strength = max(0.0, min(8.0, params.denoise))
        chain.append(("hqdn3d", {"luma_spatial": round(strength, 2)}))
    if params.width and params.height:
        src_w = source.primary_video.width if source.primary_video else 0
        src_h = source.primary_video.height if source.primary_video else 0
        if (params.width, params.height) != (src_w, src_h):
            chain.append(("scale", {"w": params.width, "h": params.height, "flags": "lanczos"}))
    for extra in params.extra_filters:
        chain.append(extra)
    return chain


class Encoder:
    """Executes encode plans."""

    def __init__(self, runner: FFmpegRunner, scratch: Path) -> None:
        self.runner = runner
        self.scratch = Path(scratch)
        self.scratch.mkdir(parents=True, exist_ok=True)

    # -- public API ------------------------------------------------------------------
    def encode(self, request: EncodeRequest) -> EncodeOutcome:
        """Run ``request`` and return its measured outcome."""
        plan = request.plan
        started = time.monotonic()

        if plan.video is not None and plan.video.two_pass and not request.is_partial:
            usage = self._encode_two_pass(request)
        else:
            usage = self._encode_single(request)

        size = request.output.stat().st_size
        outcome = EncodeOutcome(
            output=request.output,
            size=size,
            usage=usage,
            encoded_seconds=request.encoded_seconds,
            sampled=request.sample is not None,
        )
        log.debug(
            "encode complete",
            extra={
                "fingerprint": plan.fingerprint,
                "size": size,
                "wall_seconds": round(time.monotonic() - started, 2),
                "sampled": outcome.sampled,
            },
        )
        return outcome

    def remux(self, source: Path, output: Path, container: str) -> EncodeOutcome:
        """Change container without touching the streams.

        Worth having as a first-class operation: when the planner decides the
        existing streams are already better than anything we would produce, the
        honest answer is to leave the bits alone.
        """
        args = ArgBuilder().path("-i", source)
        args.opt("-c:v", "copy").opt("-c:a", "copy")
        args.opt("-map", "0")
        args.opt("-c:s", "copy")
        args.opt("-f", _MUXER.get(container, container))
        if container in {"mp4", "mov", "m4a"}:
            args.opt("-movflags", "+faststart")
        result = self.runner.encode(args, output)
        return EncodeOutcome(
            output=output,
            size=output.stat().st_size,
            usage=_usage_from(result),
            encoded_seconds=0.0,
            sampled=False,
            command=result.argv,
        )

    def copy_through(self, source: Path, output: Path) -> EncodeOutcome:
        """Pass the source through untouched, still producing a real artefact."""
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, output)
        return EncodeOutcome(
            output=output,
            size=output.stat().st_size,
            usage=ResourceUsage(),
            encoded_seconds=0.0,
            sampled=False,
        )

    # -- argument assembly -----------------------------------------------------------
    def build_command(
        self, request: EncodeRequest, *, pass_number: int | None = None
    ) -> ArgBuilder:
        """Compose the complete validated argument list for one encode."""
        plan = request.plan
        caps = self.runner.capabilities
        args = ArgBuilder()

        # Seeking before -i is orders of magnitude faster than after it, and on
        # every modern FFmpeg it is still frame-accurate for encoding.
        if request.sample is None and request.start is not None:
            args.opt("-ss", f"{request.start:.3f}")

        args.path("-i", request.source)

        if request.sample is None and request.duration is not None:
            args.opt("-t", f"{request.duration:.3f}")

        args.extend(self._mapping_args(request))

        if plan.copy_video:
            args.opt("-c:v", "copy")
        elif plan.video is not None:
            args.extend(self._video_args(request, plan.video, pass_number=pass_number))
        elif request.profile.primary_video is not None:
            args.flag("-vn")

        if pass_number == 1:
            # The analysis pass needs no audio, no subtitles and no muxing.
            args.flag("-an").flag("-sn")
        elif plan.copy_audio:
            args.opt("-c:a", "copy")
        elif plan.audio is not None:
            codec = REGISTRY.get_audio(plan.audio.codec)
            args.extend(codec.build_args(plan.audio, caps))
            if request.sample is not None:
                args.extend(self._audio_sample_filter(request.sample))
            if plan.audio.normalize:
                args.opt(
                    "-af", build_filter_chain([("loudnorm", {"I": -16, "TP": -1.5, "LRA": 11})])
                )
        elif request.profile.primary_audio is not None:
            args.flag("-an")

        args.extend(self._container_args(request, pass_number=pass_number))
        return args

    # -- internals -------------------------------------------------------------------
    def _mapping_args(self, request: EncodeRequest) -> ArgBuilder:
        """Decide which source streams survive into the output."""
        plan = request.plan
        profile = request.profile
        args = ArgBuilder()

        if profile.primary_video is not None:
            args.opt("-map", "0:v:0")
        if profile.primary_audio is not None:
            # ``?`` makes the mapping optional so a file whose audio track index
            # shifts under stream selection does not abort the whole job.
            args.opt("-map", "0:a" if plan.keep_all_audio_tracks else "0:a:0?")

        keep_subs = (
            plan.keep_subtitles
            and profile.subtitles
            and request.sample is None
            and container_supports_subtitles(plan.container)
        )
        if keep_subs:
            args.opt("-map", "0:s?")
        else:
            args.flag("-sn")

        # Data and attachment streams are dropped: they survive remuxing badly
        # and contribute nothing a viewer will ever see.
        args.flag("-dn")
        return args

    def _video_args(
        self,
        request: EncodeRequest,
        params: VideoEncodeParams,
        *,
        pass_number: int | None,
    ) -> ArgBuilder:
        codec = REGISTRY.get_video(params.codec)
        caps = self.runner.capabilities
        pass_log = str(self.scratch / f"pass-{request.output.stem}") if pass_number else None
        args = codec.build_args(params, caps, pass_number=pass_number, pass_log=pass_log)

        filters = _video_filters(params, request.profile)
        if request.sample is not None:
            args.extend(self._video_sample_filter(request.sample, filters))
        elif filters:
            args.opt("-vf", build_filter_chain(filters))

        if params.preserve_hdr and request.profile.primary_video is not None:
            source_video = request.profile.primary_video
            if source_video.is_hdr:
                args.extend(codec._hdr_args(params, source_video.color_primaries))
        return args

    def _video_sample_filter(
        self,
        sample: SamplePlan,
        filters: list[tuple[str, dict[str, object]] | str],
    ) -> ArgBuilder:
        """Select several clips and stitch them into one continuous stream.

        ``select`` keeps the frames inside each window; ``setpts`` then rewrites
        the timestamps so the encoder sees a contiguous clip rather than one
        with multi-minute gaps that would wreck its rate control.
        """
        graph = build_window_select_graph(sample.windows(), filters)
        return ArgBuilder().opt("-vf", graph).opt("-fps_mode", "cfr")

    def _audio_sample_filter(self, sample: SamplePlan) -> ArgBuilder:
        return ArgBuilder().opt("-af", build_window_select_graph(sample.windows(), audio=True))

    def _container_args(self, request: EncodeRequest, *, pass_number: int | None) -> ArgBuilder:
        plan = request.plan
        args = ArgBuilder()

        if pass_number == 1:
            return args.opt("-f", "null")

        args.opt("-f", _MUXER.get(plan.container, plan.container))

        keep_subs = (
            plan.keep_subtitles
            and request.profile.subtitles
            and request.sample is None
            and container_supports_subtitles(plan.container)
        )
        if keep_subs:
            args.opt("-c:s", _SUBTITLE_CODEC.get(plan.container, "copy"))

        if plan.keep_chapters and request.profile.chapters and not request.is_partial:
            args.opt("-map_chapters", 0)
        else:
            args.opt("-map_chapters", -1)

        if plan.strip_metadata:
            args.opt("-map_metadata", -1)
        else:
            args.opt("-map_metadata", 0)

        if plan.faststart and plan.container in {"mp4", "mov", "m4a"}:
            args.opt("-movflags", "+faststart")

        # A generous muxing queue costs memory only when it is needed, and its
        # absence is the single most common cause of spurious mux failures on
        # files with badly interleaved streams.
        args.opt("-max_muxing_queue_size", 2048)
        return args

    def _encode_single(self, request: EncodeRequest) -> ResourceUsage:
        args = self.build_command(request)
        result = self.runner.encode(
            args,
            request.output,
            timeout=request.timeout,
            duration_hint=request.encoded_seconds,
            on_progress=request.on_progress,
        )
        return _usage_from(result)

    def _encode_two_pass(self, request: EncodeRequest) -> ResourceUsage:
        log_base = self.scratch / f"pass-{request.output.stem}"
        for stale in self.scratch.glob(f"{log_base.name}*"):
            stale.unlink(missing_ok=True)

        first = self.build_command(request, pass_number=1)
        first.path(None, "/dev/null")
        analysis = self.runner.run(
            first,
            timeout=request.timeout,
            duration_hint=request.encoded_seconds,
            on_progress=request.on_progress,
        )

        second = self.build_command(request, pass_number=2)
        final = self.runner.encode(
            second,
            request.output,
            timeout=request.timeout,
            duration_hint=request.encoded_seconds,
            on_progress=request.on_progress,
        )
        for leftover in self.scratch.glob(f"{log_base.name}*"):
            leftover.unlink(missing_ok=True)

        return analysis.usage.merge(final.usage)


def _usage_from(result: CommandResult) -> ResourceUsage:
    return result.usage


def verify_encodable(plan: EncodePlan, runner: FFmpegRunner) -> None:
    """Fail fast if the plan names an encoder this build does not have."""
    caps = runner.capabilities
    if plan.video is not None and not plan.copy_video:
        REGISTRY.get_video(plan.video.codec).encoder_name(caps, plan.video.hardware)
    if plan.audio is not None and not plan.copy_audio:
        REGISTRY.get_audio(plan.audio.codec).encoder_name(caps)
    if (
        plan.video is not None
        and plan.video.rate_control is RateControl.TWO_PASS
        and not plan.video.two_pass
    ):
        raise EncodeError("two-pass rate control requested without two_pass enabled")
