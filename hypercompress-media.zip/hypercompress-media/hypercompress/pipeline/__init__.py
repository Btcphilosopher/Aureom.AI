"""Encode execution, validation and packaging.

The only place a plan becomes a running FFmpeg process, and the only place an
output is allowed to count as finished.
"""

from __future__ import annotations

from hypercompress.pipeline.encode import EncodeOutcome, Encoder, EncodeRequest, SamplePlan
from hypercompress.pipeline.validate import OutputValidator, Packager, ValidationReport

__all__ = [
    "EncodeOutcome",
    "EncodeRequest",
    "Encoder",
    "OutputValidator",
    "Packager",
    "SamplePlan",
    "ValidationReport",
]
