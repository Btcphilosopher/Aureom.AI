"""Opus — the default lossy audio target.

Opus is transparent for music around 128 kbps stereo and remains intelligible
for speech below 24 kbps mono. For a speech library, moving from 128 kbps stereo
AAC to 32 kbps mono Opus is a 4x reduction that most listeners cannot detect,
which is the single largest easy win available on a podcast estate.
"""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, AudioCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import AudioEncodeParams, CodecFamily


class OpusCodec(AudioCodec):
    family = CodecFamily.OPUS
    encoders = ("libopus",)
    lossless = False
    efficiency = 0.62
    compatibility = 0.80
    #: libopus resamples everything to 48 kHz internally; these are the rates it accepts.
    supported_sample_rates: ClassVar[tuple[int, ...]] = (8_000, 12_000, 16_000, 24_000, 48_000)
    max_channels = 8

    def build_args(self, params: AudioEncodeParams, caps: FFmpegCapabilities) -> ArgBuilder:
        args = ArgBuilder().opt("-c:a", self.encoder_name(caps))
        args.opt_if(params.bitrate is not None, "-b:a", params.bitrate)
        args.opt("-vbr", "on" if params.vbr else "off")
        args.opt_if(params.channels is not None, "-ac", params.channels)
        if params.sample_rate is not None:
            args.opt("-ar", self.nearest_sample_rate(params.sample_rate))
        args.opt_if(params.application is not None, "-application", params.application)
        args.opt_if(params.cutoff is not None, "-cutoff", params.cutoff)
        args.opt_if(
            params.compression_level is not None, "-compression_level", params.compression_level
        )
        return args

    def transparent_bitrate(self, channels: int, *, speech: bool, sample_rate: int) -> int:
        """Measured transparency points for Opus, scaled for channel count."""
        per_channel = (24000 if sample_rate > 16000 else 16000) if speech else 64000
        if channels <= 1:
            return per_channel
        if channels == 2:
            # Joint stereo shares far more than nothing but less than everything.
            return int(per_channel * 1.75)
        return int(per_channel * (1.75 + 0.55 * (channels - 2)))


REGISTRY.register_audio(OpusCodec())
