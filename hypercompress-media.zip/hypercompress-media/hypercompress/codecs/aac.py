"""AAC — the compatibility audio target, and the only lossy codec MP4 delivery
can universally assume."""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, AudioCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import AudioEncodeParams, CodecFamily


class AACCodec(AudioCodec):
    family = CodecFamily.AAC
    #: libfdk_aac is materially better than the native encoder but is not in
    #: every build because of its licence, so the native encoder is the fallback.
    encoders = ("libfdk_aac", "aac")
    lossless = False
    efficiency = 1.0
    compatibility = 1.0
    supported_sample_rates: ClassVar[tuple[int, ...]] = (
        8_000,
        11_025,
        16_000,
        22_050,
        32_000,
        44_100,
        48_000,
        88_200,
        96_000,
    )
    max_channels = 8

    def build_args(self, params: AudioEncodeParams, caps: FFmpegCapabilities) -> ArgBuilder:
        encoder = self.encoder_name(caps)
        args = ArgBuilder().opt("-c:a", encoder)
        if params.quality is not None and encoder == "libfdk_aac":
            args.opt("-vbr", int(params.quality))
        elif params.quality is not None:
            args.opt("-q:a", f"{params.quality:g}")
        else:
            args.opt("-b:a", params.bitrate)
        args.opt_if(params.channels is not None, "-ac", params.channels)
        if params.sample_rate is not None:
            args.opt("-ar", self.nearest_sample_rate(params.sample_rate))
        args.opt_if(params.cutoff is not None and encoder == "libfdk_aac", "-cutoff", params.cutoff)
        if encoder == "aac":
            args.opt("-aac_coder", "twoloop")
        return args

    def transparent_bitrate(self, channels: int, *, speech: bool, sample_rate: int) -> int:
        per_channel = 40_000 if speech else 96_000
        if channels <= 1:
            return per_channel
        if channels == 2:
            return int(per_channel * 1.85)
        return int(per_channel * (1.85 + 0.7 * (channels - 2)))


REGISTRY.register_audio(AACCodec())
