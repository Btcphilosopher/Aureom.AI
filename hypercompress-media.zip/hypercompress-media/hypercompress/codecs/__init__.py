"""Codec implementations and the global registry.

Importing this package registers every codec, so ``REGISTRY`` is fully populated
after ``import hypercompress.codecs``.
"""

from __future__ import annotations

from hypercompress.codecs import aac, av1, flac, h264, hevc, opus, vp9  # noqa: F401
from hypercompress.codecs.base import (
    REGISTRY,
    AudioCodec,
    CodecRegistry,
    QualityAnchor,
    VideoCodec,
)
from hypercompress.codecs.hardware import (
    HARDWARE_BITRATE_PENALTY,
    HARDWARE_SPEEDUP,
    AccelerationDecision,
    choose_acceleration,
    detect_hardware,
)

__all__ = [
    "HARDWARE_BITRATE_PENALTY",
    "HARDWARE_SPEEDUP",
    "REGISTRY",
    "AccelerationDecision",
    "AudioCodec",
    "CodecRegistry",
    "QualityAnchor",
    "VideoCodec",
    "choose_acceleration",
    "detect_hardware",
]
