"""AV1 — the platform's default target for archival and storage-optimised work.

SVT-AV1 is preferred over libaom: at the presets that matter for a fleet it
reaches comparable efficiency an order of magnitude faster, which changes AV1
from a research curiosity into something you can run across a petabyte library.
"""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, QualityAnchor, VideoCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import CodecFamily, HardwareVendor, RateControl, VideoEncodeParams


class AV1Codec(VideoCodec):
    family = CodecFamily.AV1
    software_encoders = ("libsvtav1", "libaom-av1", "librav1e")
    hardware_encoders: ClassVar[dict[HardwareVendor, str]] = {
        HardwareVendor.NVIDIA: "av1_nvenc",
        HardwareVendor.INTEL: "av1_qsv",
        HardwareVendor.AMD: "av1_amf",
    }
    crf_range = (0.0, 63.0)
    default_crf = 32.0
    presets = ("0", "2", "4", "6", "8", "10", "12")
    default_preset = "6"
    efficiency = 0.50
    speed_cost = 4.0
    supports_10bit = True
    supports_hdr = True
    compatibility = 0.62
    quality_anchors = (
        QualityAnchor(18, 98.5),
        QualityAnchor(24, 96.5),
        QualityAnchor(30, 93.0),
        QualityAnchor(35, 88.0),
        QualityAnchor(40, 80.5),
        QualityAnchor(45, 70.0),
        QualityAnchor(50, 57.0),
        QualityAnchor(55, 43.0),
        QualityAnchor(63, 25.0),
    )
    preset_efficiency: ClassVar[dict[str, float]] = {
        "0": 60.0,
        "2": 18.0,
        "4": 5.0,
        "6": 1.0,
        "8": 0.42,
        "10": 0.18,
        "12": 0.08,
    }

    def build_args(
        self,
        params: VideoEncodeParams,
        caps: FFmpegCapabilities,
        *,
        pass_number: int | None = None,
        pass_log: str | None = None,
    ) -> ArgBuilder:
        encoder = self.encoder_name(caps, params.hardware)
        args = self._common_args(params, caps)

        if encoder == "libsvtav1":
            args.opt(
                "-preset", params.preset if params.preset in self.presets else self.default_preset
            )
            if params.rate_control is RateControl.CRF:
                args.opt("-crf", f"{params.crf:g}")
            svt_params: list[str] = []
            if params.tune:
                svt_params.append(f"tune={1 if params.tune == 'psnr' else 0}")
            if params.film_grain:
                svt_params.append(f"film-grain={params.film_grain}")
            if params.keyint:
                svt_params.append(f"keyint={params.keyint}")
            if params.rate_control is RateControl.CBR:
                svt_params.append("rc=2")
            if svt_params:
                args.opt("-svtav1-params", ":".join(svt_params))
        elif encoder == "libaom-av1":
            cpu_used = {"0": 0, "2": 1, "4": 3, "6": 5, "8": 6, "10": 7, "12": 8}.get(
                params.preset, 5
            )
            args.opt("-cpu-used", cpu_used).opt("-row-mt", 1)
            args.opt("-tile-columns", 2).opt("-tile-rows", 1)
            args.opt("-lag-in-frames", 25)
            if params.rate_control is RateControl.CRF:
                # libaom needs an explicit zero bitrate to enter constant-quality mode.
                args.opt("-crf", f"{params.crf:g}").opt("-b:v", 0)
        else:  # hardware AV1
            args.opt("-preset", "p5" if params.hardware is HardwareVendor.NVIDIA else "medium")
            if params.rate_control is RateControl.CRF:
                args.opt("-cq", f"{params.crf:g}").opt("-rc", "vbr").opt("-b:v", 0)

        if params.pix_fmt.endswith("10le"):
            args.opt("-profile:v", 0)
        if params.preserve_hdr and params.pix_fmt.endswith("10le"):
            args.extend(self._hdr_args(params))
        if pass_number is not None:
            args.opt("-pass", pass_number).opt("-passlogfile", pass_log or "hcpass")
        return args


REGISTRY.register_video(AV1Codec())
