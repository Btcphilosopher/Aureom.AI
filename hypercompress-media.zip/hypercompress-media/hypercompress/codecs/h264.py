"""H.264/AVC — the compatibility floor.

Nothing decodes more widely. The selector picks it when a delivery target
demands universal playback, when encode time is the binding constraint, or when
the source is short enough that codec efficiency will not repay the CPU.
"""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, QualityAnchor, VideoCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import CodecFamily, HardwareVendor, RateControl, VideoEncodeParams


class H264Codec(VideoCodec):
    family = CodecFamily.H264
    software_encoders = ("libx264",)
    hardware_encoders: ClassVar[dict[HardwareVendor, str]] = {
        HardwareVendor.NVIDIA: "h264_nvenc",
        HardwareVendor.INTEL: "h264_qsv",
        HardwareVendor.AMD: "h264_amf",
        HardwareVendor.APPLE: "h264_videotoolbox",
    }
    crf_range = (0.0, 51.0)
    default_crf = 23.0
    presets = (
        "ultrafast",
        "superfast",
        "veryfast",
        "faster",
        "fast",
        "medium",
        "slow",
        "slower",
        "veryslow",
    )
    default_preset = "medium"
    efficiency = 1.0
    speed_cost = 1.0
    supports_10bit = False
    supports_hdr = False
    compatibility = 1.0
    quality_anchors = (
        QualityAnchor(14, 98.6),
        QualityAnchor(18, 96.8),
        QualityAnchor(21, 94.2),
        QualityAnchor(23, 92.0),
        QualityAnchor(26, 87.5),
        QualityAnchor(30, 79.5),
        QualityAnchor(34, 68.0),
        QualityAnchor(38, 55.0),
        QualityAnchor(45, 33.0),
        QualityAnchor(51, 18.0),
    )
    preset_efficiency: ClassVar[dict[str, float]] = {
        "ultrafast": 0.06,
        "superfast": 0.10,
        "veryfast": 0.20,
        "faster": 0.38,
        "fast": 0.70,
        "medium": 1.0,
        "slow": 1.8,
        "slower": 3.6,
        "veryslow": 7.5,
    }

    def build_args(
        self,
        params: VideoEncodeParams,
        caps: FFmpegCapabilities,
        *,
        pass_number: int | None = None,
        pass_log: str | None = None,
    ) -> ArgBuilder:
        encoder = self.encoder_name(caps, params.hardware)
        args = self._common_args(params, caps)
        args.opt("-preset", params.preset if params.preset in self.presets else self.default_preset)
        args.opt_if(params.tune is not None, "-tune", params.tune)

        if encoder == "libx264":
            if params.rate_control is RateControl.LOSSLESS:
                # QP 0 in High 4:4:4 Predictive is mathematically lossless.
                args.opt("-qp", 0)
            elif params.rate_control is RateControl.CRF:
                args.opt("-crf", f"{params.crf:g}")
            x264: list[str] = []
            if params.keyint:
                x264.append(f"keyint={params.keyint}")
            if params.min_keyint:
                x264.append(f"min-keyint={params.min_keyint}")
            if not params.scene_cut:
                x264.append("scenecut=0")
            if params.b_frames is not None:
                x264.append(f"bframes={params.b_frames}")
            if params.ref_frames is not None:
                x264.append(f"ref={params.ref_frames}")
            if x264:
                args.opt("-x264-params", ":".join(x264))
            if pass_number is not None:
                args.opt("-pass", pass_number).opt("-passlogfile", pass_log or "hcpass")
        else:
            args.opt("-rc", "vbr")
            if params.rate_control is RateControl.CRF:
                args.opt("-cq", f"{params.crf:g}").opt("-b:v", 0)

        # H.264 High 10 exists but decodes almost nowhere; 8-bit protects the
        # compatibility promise that is the entire reason to choose this codec.
        if params.rate_control is not RateControl.LOSSLESS:
            args.opt("-profile:v", "high")
        return args


REGISTRY.register_video(H264Codec())
