"""Codec abstraction (Phase 04).

Each codec knows four things the optimiser needs:

* **How to be invoked** — the exact FFmpeg tokens for a typed parameter set.
* **How efficient it is** — bitrate multiplier to reach a fixed quality relative
  to H.264, from published BD-rate studies and our own benchmark corpus.
* **How expensive it is** — relative encode time at its default preset.
* **How quality responds to CRF** — an anchor curve used to seed the search.

The anchors are seeds, never verdicts. Every claim about size or quality that
leaves this platform has been measured on the actual file.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import ClassVar

import numpy as np

from hypercompress.core.errors import CodecUnavailableError
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import (
    AudioEncodeParams,
    CodecFamily,
    HardwareVendor,
    RateControl,
    VideoEncodeParams,
)


@dataclass(frozen=True, slots=True)
class QualityAnchor:
    """A measured (CRF, VMAF) point used to interpolate the quality curve."""

    crf: float
    vmaf: float


class VideoCodec(ABC):
    """Base class for every video codec the platform can target."""

    family: ClassVar[CodecFamily]
    software_encoders: ClassVar[tuple[str, ...]] = ()
    hardware_encoders: ClassVar[dict[HardwareVendor, str]] = {}
    crf_range: ClassVar[tuple[float, float]] = (0.0, 51.0)
    default_crf: ClassVar[float] = 23.0
    presets: ClassVar[tuple[str, ...]] = ()
    default_preset: ClassVar[str] = "medium"
    #: Bitrate multiplier versus H.264 at equal quality. Lower is better.
    efficiency: ClassVar[float] = 1.0
    #: Encode time multiplier versus H.264 veryfast at the default preset.
    speed_cost: ClassVar[float] = 1.0
    supports_10bit: ClassVar[bool] = True
    supports_hdr: ClassVar[bool] = True
    #: Playback support in the installed base, 0..1. Drives compatibility policy.
    compatibility: ClassVar[float] = 1.0
    quality_anchors: ClassVar[tuple[QualityAnchor, ...]] = ()
    #: Multiplier applied to preset speed; index-aligned with ``presets``.
    preset_efficiency: ClassVar[dict[str, float]] = {}

    # -- availability -------------------------------------------------------------
    def encoder_name(
        self,
        caps: FFmpegCapabilities,
        hardware: HardwareVendor = HardwareVendor.CPU,
    ) -> str:
        """Resolve the concrete FFmpeg encoder for this codec on this build."""
        if hardware is not HardwareVendor.CPU:
            candidate = self.hardware_encoders.get(hardware)
            if candidate and caps.has_encoder(candidate):
                return candidate
        for name in self.software_encoders:
            if caps.has_encoder(name):
                return name
        raise CodecUnavailableError(
            f"{self.family.value}: none of {self.software_encoders} present in this FFmpeg build"
        )

    def is_available(self, caps: FFmpegCapabilities) -> bool:
        return any(caps.has_encoder(name) for name in self.software_encoders)

    def available_hardware(self, caps: FFmpegCapabilities) -> list[HardwareVendor]:
        return [v for v, enc in self.hardware_encoders.items() if caps.has_encoder(enc)]

    # -- modelling ----------------------------------------------------------------
    def predicted_vmaf(self, crf: float) -> float:
        """Interpolate the anchor curve; extrapolate flat beyond the ends."""
        if not self.quality_anchors:
            return float(np.clip(100.0 - (crf - 18.0) * 1.8, 0.0, 100.0))
        xs = [a.crf for a in self.quality_anchors]
        ys = [a.vmaf for a in self.quality_anchors]
        return float(np.interp(crf, xs, ys))

    def crf_for_vmaf(self, target_vmaf: float) -> float:
        """Invert the anchor curve to seed a quality-targeted search."""
        if not self.quality_anchors:
            return float(np.clip(18.0 + (100.0 - target_vmaf) / 1.8, *self.crf_range))
        xs = [a.crf for a in reversed(self.quality_anchors)]
        ys = [a.vmaf for a in reversed(self.quality_anchors)]
        return float(np.clip(np.interp(target_vmaf, ys, xs), *self.crf_range))

    def preset_speed(self, preset: str) -> float:
        """Relative encode time for a preset (1.0 = this codec's default preset)."""
        return self.preset_efficiency.get(preset, 1.0)

    def estimate_bitrate(
        self,
        *,
        width: int,
        height: int,
        frame_rate: float,
        bits_per_pixel: float,
    ) -> float:
        """Seed bitrate for this codec at the requested per-pixel budget."""
        return width * height * max(frame_rate, 1.0) * bits_per_pixel * self.efficiency

    # -- argument construction ----------------------------------------------------
    @abstractmethod
    def build_args(
        self,
        params: VideoEncodeParams,
        caps: FFmpegCapabilities,
        *,
        pass_number: int | None = None,
        pass_log: str | None = None,
    ) -> ArgBuilder:
        """Emit the validated encoder tokens for ``params``."""

    # -- shared helpers -----------------------------------------------------------
    def _common_args(self, params: VideoEncodeParams, caps: FFmpegCapabilities) -> ArgBuilder:
        args = ArgBuilder().opt("-c:v", self.encoder_name(caps, params.hardware))
        args.opt_if(params.pix_fmt is not None, "-pix_fmt", params.pix_fmt)
        args.opt_if(
            params.frame_rate is not None,
            "-r",
            f"{params.frame_rate:g}" if params.frame_rate else None,
        )
        args.opt_if(params.keyint is not None, "-g", params.keyint)
        args.opt_if(bool(params.threads), "-threads", params.threads)
        if params.rate_control in {RateControl.ABR, RateControl.CBR, RateControl.TWO_PASS}:
            args.opt("-b:v", params.bitrate)
            args.opt_if(params.max_bitrate is not None, "-maxrate", params.max_bitrate)
            args.opt_if(params.buffer_size is not None, "-bufsize", params.buffer_size)
            if params.rate_control is RateControl.CBR:
                args.opt("-minrate", params.bitrate)
        return args

    def _hdr_args(
        self, params: VideoEncodeParams, source_primaries: str | None = None
    ) -> ArgBuilder:
        """Re-signal HDR metadata so a transcode does not silently become SDR."""
        args = ArgBuilder()
        if not params.preserve_hdr:
            return args
        return (
            args.opt("-color_primaries", source_primaries or "bt2020")
            .opt("-color_trc", "smpte2084")
            .opt("-colorspace", "bt2020nc")
        )

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.family.value}>"


class AudioCodec(ABC):
    """Base class for every audio codec the platform can target."""

    family: ClassVar[CodecFamily]
    encoders: ClassVar[tuple[str, ...]] = ()
    lossless: ClassVar[bool] = False
    #: Bitrate multiplier versus AAC-LC at equal perceived quality.
    efficiency: ClassVar[float] = 1.0
    compatibility: ClassVar[float] = 1.0
    supported_sample_rates: ClassVar[tuple[int, ...]] = (
        8_000,
        16_000,
        22_050,
        24_000,
        32_000,
        44_100,
        48_000,
    )
    max_channels: ClassVar[int] = 8

    def encoder_name(self, caps: FFmpegCapabilities) -> str:
        for name in self.encoders:
            if caps.has_encoder(name):
                return name
        raise CodecUnavailableError(f"{self.family.value}: no encoder available")

    def is_available(self, caps: FFmpegCapabilities) -> bool:
        return any(caps.has_encoder(name) for name in self.encoders)

    @abstractmethod
    def build_args(self, params: AudioEncodeParams, caps: FFmpegCapabilities) -> ArgBuilder:
        """Emit the validated encoder tokens for ``params``."""

    @abstractmethod
    def transparent_bitrate(self, channels: int, *, speech: bool, sample_rate: int) -> int:
        """Bitrate at which this codec is perceptually transparent for the content."""

    def nearest_sample_rate(self, requested: int) -> int:
        return min(self.supported_sample_rates, key=lambda r: abs(r - requested))

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.family.value}>"


# --------------------------------------------------------------------------------------
# Registry
# --------------------------------------------------------------------------------------


@dataclass(slots=True)
class CodecRegistry:
    """Central lookup for codec implementations."""

    video: dict[CodecFamily, VideoCodec] = field(default_factory=dict)
    audio: dict[CodecFamily, AudioCodec] = field(default_factory=dict)

    def register_video(self, codec: VideoCodec) -> VideoCodec:
        self.video[codec.family] = codec
        return codec

    def register_audio(self, codec: AudioCodec) -> AudioCodec:
        self.audio[codec.family] = codec
        return codec

    def get_video(self, family: CodecFamily) -> VideoCodec:
        try:
            return self.video[family]
        except KeyError:
            raise CodecUnavailableError(f"no video codec registered for {family}") from None

    def get_audio(self, family: CodecFamily) -> AudioCodec:
        try:
            return self.audio[family]
        except KeyError:
            raise CodecUnavailableError(f"no audio codec registered for {family}") from None

    def available_video(self, caps: FFmpegCapabilities) -> list[VideoCodec]:
        return [c for c in self.video.values() if c.is_available(caps)]

    def available_audio(self, caps: FFmpegCapabilities) -> list[AudioCodec]:
        return [c for c in self.audio.values() if c.is_available(caps)]


REGISTRY = CodecRegistry()
