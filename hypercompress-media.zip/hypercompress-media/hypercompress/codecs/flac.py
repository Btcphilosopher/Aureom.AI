"""FLAC — mathematically lossless audio.

FLAC exists in this platform to make an honest promise: when a profile says
LOSSLESS, the decoded samples are bit-identical to the source. Typical
reductions are 30–60% on music and rather more on speech, and no search over
encoder parameters will beat that by much — which is exactly why the LOSSLESS
profile does not run one.
"""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, AudioCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import AudioEncodeParams, CodecFamily


class FLACCodec(AudioCodec):
    family = CodecFamily.FLAC
    encoders = ("flac",)
    lossless = True
    efficiency = 5.0
    compatibility = 0.72
    supported_sample_rates: ClassVar[tuple[int, ...]] = (
        8_000,
        16_000,
        22_050,
        24_000,
        32_000,
        44_100,
        48_000,
        88_200,
        96_000,
        176_400,
        192_000,
    )
    max_channels = 8

    def build_args(self, params: AudioEncodeParams, caps: FFmpegCapabilities) -> ArgBuilder:
        args = ArgBuilder().opt("-c:a", self.encoder_name(caps))
        args.opt(
            "-compression_level",
            params.compression_level if params.compression_level is not None else 8,
        )
        args.opt_if(params.channels is not None, "-ac", params.channels)
        if params.sample_rate is not None:
            args.opt("-ar", self.nearest_sample_rate(params.sample_rate))
        return args

    def transparent_bitrate(
        self, channels: int, *, speech: bool, sample_rate: int, bit_depth: int = 16
    ) -> int:
        """FLAC is always transparent; this is the rate it typically lands on.

        Derived from the PCM rate and the ratio FLAC achieves on that material:
        speech and sparse mixes predict far better than dense mastered music.
        """
        pcm_bitrate = sample_rate * channels * bit_depth
        return int(pcm_bitrate * self.expected_ratio(speech=speech))

    def expected_ratio(self, *, speech: bool) -> float:
        """Fraction of the PCM size FLAC typically produces."""
        return 0.45 if speech else 0.62


REGISTRY.register_audio(FLACCodec())
