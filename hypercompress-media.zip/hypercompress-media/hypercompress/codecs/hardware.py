"""Hardware acceleration detection and CPU-versus-GPU economics.

A GPU encode is 10–40x faster and materially worse per bit. The right question
is never "is a GPU available" but "does this workload's value come from throughput
or from bytes saved", and that answer changes with the size of the library and
the price of the instance.
"""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from hypercompress.core.ffmpeg import FFmpegCapabilities
from hypercompress.core.logging import get_logger
from hypercompress.core.process import run_process
from hypercompress.core.types import CodecFamily, HardwareProfile, HardwareVendor

log = get_logger("codecs.hardware")

_VENDOR_ENCODER_HINTS: dict[HardwareVendor, tuple[str, ...]] = {
    HardwareVendor.NVIDIA: ("h264_nvenc", "hevc_nvenc", "av1_nvenc"),
    HardwareVendor.INTEL: ("h264_qsv", "hevc_qsv", "av1_qsv", "vp9_qsv"),
    HardwareVendor.AMD: ("h264_amf", "hevc_amf", "av1_amf"),
    HardwareVendor.APPLE: ("h264_videotoolbox", "hevc_videotoolbox"),
}

#: Quality cost of hardware encoding: bitrate multiplier to match a software
#: encode at the same perceptual quality.
HARDWARE_BITRATE_PENALTY: dict[HardwareVendor, float] = {
    HardwareVendor.CPU: 1.00,
    HardwareVendor.NVIDIA: 1.22,
    HardwareVendor.INTEL: 1.30,
    HardwareVendor.AMD: 1.38,
    HardwareVendor.APPLE: 1.28,
}

#: Wall-clock speedup versus a software encode at a comparable preset.
HARDWARE_SPEEDUP: dict[HardwareVendor, float] = {
    HardwareVendor.CPU: 1.0,
    HardwareVendor.NVIDIA: 18.0,
    HardwareVendor.INTEL: 14.0,
    HardwareVendor.AMD: 12.0,
    HardwareVendor.APPLE: 15.0,
}


def _total_memory() -> int:
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    except (ValueError, OSError, AttributeError):
        return 0


def _detect_vendor(caps: FFmpegCapabilities) -> tuple[HardwareVendor, list[str]]:
    """Trust device presence over encoder listings: FFmpeg advertises encoders
    that fail at runtime when no device is attached."""
    for vendor, encoders in _VENDOR_ENCODER_HINTS.items():
        present = [e for e in encoders if caps.has_encoder(e)]
        if not present:
            continue
        if vendor is HardwareVendor.NVIDIA and not _nvidia_present():
            continue
        if vendor is HardwareVendor.INTEL and not _render_node_present():
            continue
        if vendor is HardwareVendor.AMD and not _render_node_present():
            continue
        if vendor is HardwareVendor.APPLE and os.uname().sysname != "Darwin":
            continue
        return vendor, present
    return HardwareVendor.CPU, []


def _nvidia_present() -> bool:
    if shutil.which("nvidia-smi") is None:
        return False
    result = run_process(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], timeout=20)
    return result.ok and bool(result.stdout.strip())


def _render_node_present() -> bool:
    return any(Path("/dev/dri").glob("renderD*")) if Path("/dev/dri").exists() else False


@lru_cache(maxsize=2)
def detect_hardware(caps: FFmpegCapabilities) -> HardwareProfile:
    """Detect usable acceleration once per process."""
    vendor, encoders = _detect_vendor(caps)
    device = None
    if vendor is HardwareVendor.NVIDIA:
        result = run_process(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], timeout=20
        )
        device = (
            result.stdout.strip().splitlines()[0] if result.ok and result.stdout.strip() else None
        )
    elif vendor in {HardwareVendor.INTEL, HardwareVendor.AMD}:
        nodes = sorted(Path("/dev/dri").glob("renderD*")) if Path("/dev/dri").exists() else []
        device = str(nodes[0]) if nodes else None

    profile = HardwareProfile(
        vendor=vendor,
        encoders=encoders,
        decoders=[d for d in caps.decoders if d.endswith(("_cuvid", "_qsv", "_v4l2m2m"))][:16],
        device=device,
        cpu_count=os.cpu_count() or 1,
        total_memory_bytes=_total_memory(),
    )
    log.info(
        "hardware detected",
        extra={"vendor": vendor.value, "device": device, "cpus": profile.cpu_count},
    )
    return profile


@dataclass(frozen=True, slots=True)
class AccelerationDecision:
    """The scheduler's answer to 'CPU or GPU for this job?'."""

    vendor: HardwareVendor
    reason: str
    estimated_seconds: float
    estimated_cost: float
    estimated_size_penalty: float

    @property
    def uses_gpu(self) -> bool:
        return self.vendor is not HardwareVendor.CPU


def choose_acceleration(
    hardware: HardwareProfile,
    family: CodecFamily,
    *,
    estimated_cpu_seconds: float,
    cpu_price_per_core_hour: float,
    gpu_price_per_hour: float,
    storage_price_per_gb_month: float,
    retention_months: float,
    expected_output_bytes: int,
    throughput_urgent: bool = False,
) -> AccelerationDecision:
    """Decide CPU versus GPU by comparing compute saved against storage lost.

    A GPU encode finishes sooner but produces a larger file that is then paid for
    every month of retention. Over a long retention window the storage penalty
    usually dominates, which is why an archive tier should stay on CPU even when
    a GPU is sitting idle.
    """
    cpu_cost = (estimated_cpu_seconds / 3_600.0) * cpu_price_per_core_hour
    if not hardware.has_gpu or hardware.encoder_for(family) is None:
        return AccelerationDecision(
            vendor=HardwareVendor.CPU,
            reason="no compatible hardware encoder available",
            estimated_seconds=estimated_cpu_seconds,
            estimated_cost=cpu_cost,
            estimated_size_penalty=0.0,
        )

    vendor = hardware.vendor
    speedup = HARDWARE_SPEEDUP.get(vendor, 10.0)
    penalty = HARDWARE_BITRATE_PENALTY.get(vendor, 1.3)
    gpu_seconds = estimated_cpu_seconds / speedup
    gpu_cost = (gpu_seconds / 3_600.0) * gpu_price_per_hour
    extra_bytes = expected_output_bytes * (penalty - 1.0)
    storage_penalty = (extra_bytes / 1e9) * storage_price_per_gb_month * retention_months

    if throughput_urgent:
        return AccelerationDecision(
            vendor=vendor,
            reason="throughput prioritised by job policy",
            estimated_seconds=gpu_seconds,
            estimated_cost=gpu_cost + storage_penalty,
            estimated_size_penalty=extra_bytes,
        )
    if gpu_cost + storage_penalty < cpu_cost:
        return AccelerationDecision(
            vendor=vendor,
            reason=(
                f"gpu total cost {gpu_cost + storage_penalty:.4f} beats cpu {cpu_cost:.4f} "
                f"including {storage_penalty:.4f} of retained storage penalty"
            ),
            estimated_seconds=gpu_seconds,
            estimated_cost=gpu_cost + storage_penalty,
            estimated_size_penalty=extra_bytes,
        )
    return AccelerationDecision(
        vendor=HardwareVendor.CPU,
        reason=(
            f"cpu total cost {cpu_cost:.4f} beats gpu {gpu_cost + storage_penalty:.4f}; "
            f"the {penalty:.2f}x bitrate penalty is paid for {retention_months:.0f} months"
        ),
        estimated_seconds=estimated_cpu_seconds,
        estimated_cost=cpu_cost,
        estimated_size_penalty=0.0,
    )
