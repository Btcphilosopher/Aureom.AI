"""VP9 — royalty-free delivery for the web, and the WebM fallback where AV1
decode support cannot be assumed."""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, QualityAnchor, VideoCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import CodecFamily, HardwareVendor, RateControl, VideoEncodeParams


class VP9Codec(VideoCodec):
    family = CodecFamily.VP9
    software_encoders = ("libvpx-vp9",)
    hardware_encoders: ClassVar[dict[HardwareVendor, str]] = {HardwareVendor.INTEL: "vp9_qsv"}
    crf_range = (0.0, 63.0)
    default_crf = 31.0
    presets = ("best", "good", "realtime")
    default_preset = "good"
    efficiency = 0.68
    speed_cost = 3.2
    compatibility = 0.78
    quality_anchors = (
        QualityAnchor(18, 98.0),
        QualityAnchor(24, 95.5),
        QualityAnchor(28, 92.0),
        QualityAnchor(31, 88.5),
        QualityAnchor(36, 80.0),
        QualityAnchor(41, 68.0),
        QualityAnchor(46, 54.0),
        QualityAnchor(52, 38.0),
        QualityAnchor(63, 20.0),
    )
    preset_efficiency: ClassVar[dict[str, float]] = {"best": 3.5, "good": 1.0, "realtime": 0.15}

    def build_args(
        self,
        params: VideoEncodeParams,
        caps: FFmpegCapabilities,
        *,
        pass_number: int | None = None,
        pass_log: str | None = None,
    ) -> ArgBuilder:
        args = self._common_args(params, caps)
        deadline = params.preset if params.preset in self.presets else self.default_preset
        args.opt("-deadline", deadline)
        args.opt("-cpu-used", 2 if deadline == "good" else 0)
        args.opt("-row-mt", 1).opt("-tile-columns", 2)
        if params.rate_control is RateControl.LOSSLESS:
            args.opt("-crf", 0).opt("-b:v", 0).opt("-quality", "best")
        elif params.rate_control is RateControl.CRF:
            # libvpx enters constant-quality mode only when -b:v is zero.
            args.opt("-crf", f"{params.crf:g}").opt("-b:v", 0)
        if pass_number is not None:
            args.opt("-pass", pass_number).opt("-passlogfile", pass_log or "hcpass")
        if params.pix_fmt.endswith("10le"):
            args.opt("-profile:v", 2)
        return args


REGISTRY.register_video(VP9Codec())
