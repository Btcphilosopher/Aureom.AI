"""HEVC/H.265 — the pragmatic middle ground.

Roughly 40% better than H.264, decodes in hardware nearly everywhere, and
carries HDR10 static metadata cleanly. When a library must remain playable on
consumer devices today, this is usually the codec the selector picks.
"""

from __future__ import annotations

from typing import ClassVar

from hypercompress.codecs.base import REGISTRY, QualityAnchor, VideoCodec
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegCapabilities
from hypercompress.core.types import CodecFamily, HardwareVendor, RateControl, VideoEncodeParams


class HEVCCodec(VideoCodec):
    family = CodecFamily.HEVC
    software_encoders = ("libx265",)
    hardware_encoders: ClassVar[dict[HardwareVendor, str]] = {
        HardwareVendor.NVIDIA: "hevc_nvenc",
        HardwareVendor.INTEL: "hevc_qsv",
        HardwareVendor.AMD: "hevc_amf",
        HardwareVendor.APPLE: "hevc_videotoolbox",
    }
    crf_range = (0.0, 51.0)
    default_crf = 26.0
    presets = (
        "ultrafast",
        "superfast",
        "veryfast",
        "faster",
        "fast",
        "medium",
        "slow",
        "slower",
        "veryslow",
    )
    default_preset = "medium"
    efficiency = 0.62
    speed_cost = 2.5
    compatibility = 0.86
    quality_anchors = (
        QualityAnchor(16, 98.8),
        QualityAnchor(20, 97.2),
        QualityAnchor(24, 94.5),
        QualityAnchor(28, 89.5),
        QualityAnchor(32, 82.0),
        QualityAnchor(36, 72.0),
        QualityAnchor(40, 60.0),
        QualityAnchor(45, 44.0),
        QualityAnchor(51, 25.0),
    )
    preset_efficiency: ClassVar[dict[str, float]] = {
        "ultrafast": 0.08,
        "superfast": 0.13,
        "veryfast": 0.25,
        "faster": 0.45,
        "fast": 0.75,
        "medium": 1.0,
        "slow": 1.9,
        "slower": 4.2,
        "veryslow": 9.0,
    }

    def build_args(
        self,
        params: VideoEncodeParams,
        caps: FFmpegCapabilities,
        *,
        pass_number: int | None = None,
        pass_log: str | None = None,
    ) -> ArgBuilder:
        encoder = self.encoder_name(caps, params.hardware)
        args = self._common_args(params, caps)
        args.opt("-preset", params.preset if params.preset in self.presets else self.default_preset)
        args.opt_if(params.tune is not None, "-tune", params.tune)

        if encoder == "libx265":
            if params.rate_control is RateControl.CRF:
                args.opt("-crf", f"{params.crf:g}")
            x265: list[str] = []
            if params.rate_control is RateControl.LOSSLESS:
                x265.append("lossless=1")
            if params.keyint:
                x265.append(f"keyint={params.keyint}")
            if params.min_keyint:
                x265.append(f"min-keyint={params.min_keyint}")
            if not params.scene_cut:
                x265.append("scenecut=0")
            if params.b_frames is not None:
                x265.append(f"bframes={params.b_frames}")
            if params.ref_frames is not None:
                x265.append(f"ref={params.ref_frames}")
            if params.preserve_hdr and params.pix_fmt.endswith("10le"):
                x265.append("hdr-opt=1")
                x265.append("repeat-headers=1")
            if pass_number is not None:
                x265.append(f"pass={pass_number}")
                x265.append(f"stats={pass_log or 'hcpass'}")
            # libx265 chatters on stderr; quiet it so progress parsing stays clean.
            x265.append("log-level=error")
            args.opt("-x265-params", ":".join(x265))
        else:
            args.opt("-rc", "vbr")
            if params.rate_control is RateControl.CRF:
                args.opt("-cq", f"{params.crf:g}").opt("-b:v", 0)

        if params.pix_fmt.endswith("10le"):
            args.opt("-profile:v", "main10")
        if params.preserve_hdr and params.pix_fmt.endswith("10le"):
            args.extend(self._hdr_args(params))
        return args


REGISTRY.register_video(HEVCCodec())
