"""Job queues (Phase 14).

The scheduler needs four things from a queue and nothing more: hand me the next
job, let me extend my claim on it while I work, tell me it succeeded or failed,
and give it to someone else if I die holding it. Everything else — priorities,
retries, backpressure — is built on top of those four.

Two backends ship here:

:class:`MemoryQueue`
    Everything in one process. Used by the CLI, the tests, and any deployment
    small enough that a second machine would be overhead rather than help.

:class:`SqliteQueue`
    Durable and multi-process, with no server to run. The whole point is that a
    single-box deployment gets crash recovery without inheriting Redis. It uses
    WAL mode and an ``IMMEDIATE`` transaction around the claim so two workers
    cannot take the same job.

A Redis backend is defined by the same protocol and can be dropped in where
multi-machine throughput justifies the dependency.

The lease is the load-bearing idea. A claimed job carries an expiry; a worker
that is still alive renews it, and a worker that has crashed simply stops. Any
job whose lease has lapsed is reclaimable. That gives crash recovery without
heartbeat tables, liveness gossip, or a coordinator — a worker being killed
mid-encode looks exactly like a worker that got slow, and both resolve the same
way.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Protocol

from hypercompress.core.errors import SchedulingError
from hypercompress.core.logging import get_logger
from hypercompress.core.types import JobSpec, JobState

log = get_logger(__name__)

#: How long a claim is good for before another worker may take the job. Long
#: enough that a slow encode is not stolen mid-flight; short enough that a dead
#: worker's jobs come back in reasonable time. Workers renew, so this is a
#: ceiling on staleness, not on job duration.
DEFAULT_LEASE_SECONDS = 300.0


@dataclass(slots=True)
class Lease:
    """A claim on a job, held by one worker for a bounded time."""

    job: JobSpec
    token: str
    worker: str
    expires_at: datetime
    attempt: int = 1

    @property
    def expired(self) -> bool:
        return datetime.now(UTC) >= self.expires_at

    @property
    def remaining(self) -> float:
        return max(0.0, (self.expires_at - datetime.now(UTC)).total_seconds())


class JobQueue(Protocol):
    """The contract every backend implements."""

    def submit(self, job: JobSpec) -> str: ...

    def claim(
        self, worker: str, *, lease_seconds: float = DEFAULT_LEASE_SECONDS
    ) -> Lease | None: ...

    def renew(self, lease: Lease, *, lease_seconds: float = DEFAULT_LEASE_SECONDS) -> bool: ...

    def complete(self, lease: Lease, *, payload: dict[str, object] | None = None) -> None: ...

    def fail(self, lease: Lease, error: str, *, retry: bool = True) -> bool: ...

    def release(self, lease: Lease) -> None: ...

    def reap_expired(self) -> int: ...

    def stats(self) -> dict[str, int]: ...

    def depth(self) -> int: ...


def _priority_key(job: JobSpec) -> tuple[float, float]:
    """Most urgent first, then oldest first within a band.

    :class:`JobPriority` weights ascend as urgency falls — ``CRITICAL`` is 0 and
    ``BULK`` is 40 — so this sorts ascending. Reading the weight as "bigger is
    more important" is the obvious mistake here and puts bulk work at the front
    of the queue, which looks like the scheduler working right up until the
    urgent job never runs.


    Ordering by submission time within a band is what stops a steady trickle of
    high-priority work from starving everything beneath it indefinitely — the
    trickle still wins, but the queue behind it stays in a defined order rather
    than becoming a lottery.
    """
    return (job.priority.weight, job.created_at.timestamp())


# --------------------------------------------------------------------------------------
# In-memory
# --------------------------------------------------------------------------------------


class MemoryQueue:
    """A thread-safe queue for single-process deployments."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._pending: list[JobSpec] = []
        self._claimed: dict[str, Lease] = {}
        self._done: dict[str, JobState] = {}
        self._errors: dict[str, str] = {}
        self._attempts: dict[str, int] = {}
        self._results: dict[str, dict[str, object]] = {}

    def submit(self, job: JobSpec) -> str:
        with self._lock:
            self._pending.append(job)
            self._pending.sort(key=_priority_key)
            self._attempts.setdefault(job.job_id, 0)
        log.info("job submitted", extra={"job_id": job.job_id, "priority": job.priority.value})
        return job.job_id

    def claim(self, worker: str, *, lease_seconds: float = DEFAULT_LEASE_SECONDS) -> Lease | None:
        with self._lock:
            self.reap_expired()
            if not self._pending:
                return None
            job = self._pending.pop(0)
            self._attempts[job.job_id] = self._attempts.get(job.job_id, 0) + 1
            lease = Lease(
                job=job,
                token=uuid.uuid4().hex,
                worker=worker,
                expires_at=datetime.now(UTC) + timedelta(seconds=lease_seconds),
                attempt=self._attempts[job.job_id],
            )
            self._claimed[job.job_id] = lease
            return lease

    def renew(self, lease: Lease, *, lease_seconds: float = DEFAULT_LEASE_SECONDS) -> bool:
        with self._lock:
            held = self._claimed.get(lease.job.job_id)
            if held is None or held.token != lease.token:
                return False
            held.expires_at = datetime.now(UTC) + timedelta(seconds=lease_seconds)
            lease.expires_at = held.expires_at
            return True

    def complete(self, lease: Lease, *, payload: dict[str, object] | None = None) -> None:
        with self._lock:
            if (
                self._claimed.get(
                    lease.job.job_id, Lease(lease.job, "", "", datetime.now(UTC))
                ).token
                != lease.token
            ):
                raise SchedulingError("cannot complete a job whose lease is no longer held")
            self._claimed.pop(lease.job.job_id, None)
            self._done[lease.job.job_id] = JobState.SUCCEEDED
            if payload is not None:
                self._results[lease.job.job_id] = payload

    def fail(self, lease: Lease, error: str, *, retry: bool = True) -> bool:
        with self._lock:
            self._claimed.pop(lease.job.job_id, None)
            self._errors[lease.job.job_id] = error
            attempts = self._attempts.get(lease.job.job_id, 1)
            if retry and attempts < lease.job.max_attempts:
                self._pending.append(lease.job)
                self._pending.sort(key=_priority_key)
                return True
            self._done[lease.job.job_id] = JobState.FAILED
            return False

    def release(self, lease: Lease) -> None:
        """Give a job back untried — used on graceful shutdown."""
        with self._lock:
            if self._claimed.pop(lease.job.job_id, None) is not None:
                self._attempts[lease.job.job_id] = max(
                    0, self._attempts.get(lease.job.job_id, 1) - 1
                )
                self._pending.append(lease.job)
                self._pending.sort(key=_priority_key)

    def reap_expired(self) -> int:
        recovered = 0
        for job_id, lease in list(self._claimed.items()):
            if lease.expired:
                self._claimed.pop(job_id, None)
                self._pending.append(lease.job)
                recovered += 1
                log.warning(
                    "reclaiming a job whose lease expired",
                    extra={"job_id": job_id, "worker": lease.worker, "attempt": lease.attempt},
                )
        if recovered:
            self._pending.sort(key=_priority_key)
        return recovered

    def stats(self) -> dict[str, int]:
        with self._lock:
            return {
                "pending": len(self._pending),
                "running": len(self._claimed),
                "succeeded": sum(1 for s in self._done.values() if s is JobState.SUCCEEDED),
                "failed": sum(1 for s in self._done.values() if s is JobState.FAILED),
            }

    def depth(self) -> int:
        with self._lock:
            return len(self._pending)

    def state_of(self, job_id: str) -> JobState:
        with self._lock:
            if job_id in self._claimed:
                return JobState.RUNNING
            if job_id in self._done:
                return self._done[job_id]
            if any(j.job_id == job_id for j in self._pending):
                return JobState.QUEUED
            return JobState.PENDING

    def result_of(self, job_id: str) -> dict[str, object] | None:
        with self._lock:
            return self._results.get(job_id)

    def error_of(self, job_id: str) -> str | None:
        with self._lock:
            return self._errors.get(job_id)


# --------------------------------------------------------------------------------------
# SQLite
# --------------------------------------------------------------------------------------


_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    job_id       TEXT PRIMARY KEY,
    spec         TEXT NOT NULL,
    state        TEXT NOT NULL,
    priority     REAL NOT NULL,
    submitted_at REAL NOT NULL,
    attempts     INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    lease_token  TEXT,
    lease_worker TEXT,
    lease_expiry REAL,
    error        TEXT,
    result       TEXT,
    updated_at   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS jobs_ready ON jobs (state, priority ASC, submitted_at);
CREATE INDEX IF NOT EXISTS jobs_lease ON jobs (state, lease_expiry);
"""


class SqliteQueue:
    """A durable queue backed by a single SQLite file.

    Chosen over Redis as the default durable backend because it needs no server,
    survives a machine restart, and is safe across processes. Its ceiling is a
    few hundred jobs a second, which is far above what an encoding fleet can
    consume — every job here occupies a core for minutes.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        with self._connect() as conn:
            conn.executescript(_SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, timeout=30.0, isolation_level=None)
            conn.row_factory = sqlite3.Row
            # WAL lets readers proceed while a worker is claiming, which matters
            # when the API is polling job state during a busy encode.
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=30000")
            self._local.conn = conn
        return conn

    def submit(self, job: JobSpec) -> str:
        conn = self._connect()
        now = time.time()
        conn.execute(
            "INSERT OR REPLACE INTO jobs "
            "(job_id, spec, state, priority, submitted_at, attempts, max_attempts, updated_at) "
            "VALUES (?, ?, ?, ?, ?, COALESCE((SELECT attempts FROM jobs WHERE job_id = ?), 0), ?, ?)",
            (
                job.job_id,
                job.model_dump_json(),
                JobState.QUEUED.value,
                job.priority.weight,
                job.created_at.timestamp(),
                job.job_id,
                job.max_attempts,
                now,
            ),
        )
        return job.job_id

    def claim(self, worker: str, *, lease_seconds: float = DEFAULT_LEASE_SECONDS) -> Lease | None:
        conn = self._connect()
        self.reap_expired()
        token = uuid.uuid4().hex
        expiry = time.time() + lease_seconds
        try:
            # IMMEDIATE takes the write lock up front, so the select and the
            # update cannot interleave with another worker's claim.
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT job_id, spec, attempts FROM jobs WHERE state = ? "
                "ORDER BY priority ASC, submitted_at ASC LIMIT 1",
                (JobState.QUEUED.value,),
            ).fetchone()
            if row is None:
                conn.execute("COMMIT")
                return None
            conn.execute(
                "UPDATE jobs SET state = ?, lease_token = ?, lease_worker = ?, lease_expiry = ?, "
                "attempts = attempts + 1, updated_at = ? WHERE job_id = ?",
                (JobState.RUNNING.value, token, worker, expiry, time.time(), row["job_id"]),
            )
            conn.execute("COMMIT")
        except sqlite3.Error:
            conn.execute("ROLLBACK")
            raise

        job = JobSpec.model_validate_json(row["spec"])
        return Lease(
            job=job,
            token=token,
            worker=worker,
            expires_at=datetime.fromtimestamp(expiry, UTC),
            attempt=int(row["attempts"]) + 1,
        )

    def renew(self, lease: Lease, *, lease_seconds: float = DEFAULT_LEASE_SECONDS) -> bool:
        conn = self._connect()
        expiry = time.time() + lease_seconds
        cursor = conn.execute(
            "UPDATE jobs SET lease_expiry = ?, updated_at = ? WHERE job_id = ? AND lease_token = ?",
            (expiry, time.time(), lease.job.job_id, lease.token),
        )
        if cursor.rowcount:
            lease.expires_at = datetime.fromtimestamp(expiry, UTC)
            return True
        return False

    def complete(self, lease: Lease, *, payload: dict[str, object] | None = None) -> None:
        conn = self._connect()
        cursor = conn.execute(
            "UPDATE jobs SET state = ?, lease_token = NULL, lease_expiry = NULL, result = ?, "
            "updated_at = ? WHERE job_id = ? AND lease_token = ?",
            (
                JobState.SUCCEEDED.value,
                json.dumps(payload) if payload is not None else None,
                time.time(),
                lease.job.job_id,
                lease.token,
            ),
        )
        if not cursor.rowcount:
            raise SchedulingError(
                f"job {lease.job.job_id} was completed by a worker that no longer holds its lease"
            )

    def fail(self, lease: Lease, error: str, *, retry: bool = True) -> bool:
        conn = self._connect()
        row = conn.execute(
            "SELECT attempts, max_attempts FROM jobs WHERE job_id = ?", (lease.job.job_id,)
        ).fetchone()
        attempts = int(row["attempts"]) if row else lease.attempt
        limit = int(row["max_attempts"]) if row else lease.job.max_attempts
        requeue = retry and attempts < limit
        conn.execute(
            "UPDATE jobs SET state = ?, lease_token = NULL, lease_expiry = NULL, error = ?, "
            "updated_at = ? WHERE job_id = ?",
            (
                JobState.QUEUED.value if requeue else JobState.FAILED.value,
                error,
                time.time(),
                lease.job.job_id,
            ),
        )
        return requeue

    def release(self, lease: Lease) -> None:
        conn = self._connect()
        conn.execute(
            "UPDATE jobs SET state = ?, lease_token = NULL, lease_expiry = NULL, "
            "attempts = MAX(0, attempts - 1), updated_at = ? WHERE job_id = ? AND lease_token = ?",
            (JobState.QUEUED.value, time.time(), lease.job.job_id, lease.token),
        )

    def reap_expired(self) -> int:
        conn = self._connect()
        cursor = conn.execute(
            "UPDATE jobs SET state = ?, lease_token = NULL, lease_expiry = NULL, updated_at = ? "
            "WHERE state = ? AND lease_expiry IS NOT NULL AND lease_expiry < ?",
            (JobState.QUEUED.value, time.time(), JobState.RUNNING.value, time.time()),
        )
        if cursor.rowcount:
            log.warning("reclaimed expired leases", extra={"count": cursor.rowcount})
        return int(cursor.rowcount or 0)

    def stats(self) -> dict[str, int]:
        conn = self._connect()
        rows = conn.execute("SELECT state, COUNT(*) AS n FROM jobs GROUP BY state").fetchall()
        counts = {row["state"]: int(row["n"]) for row in rows}
        return {
            "pending": counts.get(JobState.QUEUED.value, 0),
            "running": counts.get(JobState.RUNNING.value, 0),
            "succeeded": counts.get(JobState.SUCCEEDED.value, 0),
            "failed": counts.get(JobState.FAILED.value, 0),
        }

    def depth(self) -> int:
        conn = self._connect()
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM jobs WHERE state = ?", (JobState.QUEUED.value,)
        ).fetchone()
        return int(row["n"])

    def state_of(self, job_id: str) -> JobState:
        conn = self._connect()
        row = conn.execute("SELECT state FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        return JobState(row["state"]) if row else JobState.PENDING

    def result_of(self, job_id: str) -> dict[str, object] | None:
        conn = self._connect()
        row = conn.execute("SELECT result FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        if row is None or row["result"] is None:
            return None
        return dict(json.loads(row["result"]))

    def error_of(self, job_id: str) -> str | None:
        conn = self._connect()
        row = conn.execute("SELECT error FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        return row["error"] if row else None

    def purge(
        self, *, states: Iterable[JobState] = (JobState.SUCCEEDED,), older_than: float = 0.0
    ) -> int:
        """Drop finished rows so the file does not grow without bound."""
        conn = self._connect()
        cutoff = time.time() - older_than
        placeholders = ",".join("?" for _ in states)
        cursor = conn.execute(
            f"DELETE FROM jobs WHERE state IN ({placeholders}) AND updated_at < ?",
            (*[s.value for s in states], cutoff),
        )
        return int(cursor.rowcount or 0)


def build_queue(backend: str, *, path: str | Path | None = None) -> JobQueue:
    """Construct the configured queue backend."""
    backend = backend.lower()
    if backend == "memory":
        return MemoryQueue()
    if backend == "sqlite":
        if path is None:
            raise SchedulingError("the sqlite queue backend requires a path")
        return SqliteQueue(path)
    raise SchedulingError(
        f"unknown queue backend {backend!r}; supported backends are 'memory' and 'sqlite'"
    )
