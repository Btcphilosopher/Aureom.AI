"""Workers and scheduling (Phase 14).

A worker is a loop: claim a job, renew the lease while encoding, report the
outcome. Everything interesting is in what happens when that goes wrong.

**Workers are stateless.** All the durable state lives in the queue. A worker
holds nothing that cannot be reconstructed by claiming the job again, which is
what makes killing one safe.

**Encodes are long, so the lease is renewed from a second thread.** A four-hour
4K encode cannot hold a five-minute lease without renewal, and it must not hold
a four-hour lease either — that would mean a crashed worker's job sits dead for
four hours. The heartbeat thread renews at a third of the lease interval and
stops the moment the encode returns, so a crash stops renewals within seconds.

**Idempotency comes from the output path, not from bookkeeping.** A retried job
writes to a temporary file and moves it into place only once it has validated.
A worker that dies mid-encode leaves a temp file, never a half-written output
that the next stage would treat as finished.

**Retries distinguish what is worth retrying.** A network timeout fetching the
source deserves another go; an unsupported codec does not, and retrying it three
times just burns the fleet's capacity to arrive at the same answer. The classes
in :mod:`hypercompress.core.errors` carry that distinction and
:func:`is_retryable` reads it.

**Shutdown is graceful by default.** On SIGTERM the worker finishes the job in
hand, releases anything it has not started, and exits — so a rolling deploy
costs one encode's latency rather than one encode's work.
"""

from __future__ import annotations

import os
import platform
import signal
import threading
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from hypercompress.config import HyperCompressConfig
from hypercompress.core.errors import (
    ConfigError,
    EncodeTimeout,
    HyperCompressError,
    QuotaExceeded,
    SecurityError,
    StorageError,
    UnsupportedMediaError,
    ValidationError,
)
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.logging import get_logger, log_context
from hypercompress.core.types import JobResult, JobSpec, JobState, Manifest
from hypercompress.distributed.queue import DEFAULT_LEASE_SECONDS, JobQueue, Lease
from hypercompress.optimisation.optimiser import OptimisationResult, Optimiser
from hypercompress.pipeline.validate import OutputValidator, Packager

log = get_logger(__name__)

#: Errors that will produce exactly the same failure on a second attempt. There
#: is nothing to gain from retrying a file whose codec we cannot read, and a
#: fleet that retries them anyway spends a third of its capacity on jobs that
#: are already decided.
PERMANENT_ERRORS: tuple[type[Exception], ...] = (
    UnsupportedMediaError,
    ConfigError,
    SecurityError,
    QuotaExceeded,
)


def is_retryable(error: BaseException) -> bool:
    """Whether another attempt could plausibly succeed."""
    if isinstance(error, PERMANENT_ERRORS):
        return False
    if isinstance(error, (EncodeTimeout, StorageError, ValidationError)):
        # Timeouts and storage faults are usually transient; a validation
        # failure often is too, since it is frequently the symptom of a
        # truncated write rather than an impossible request.
        return True
    return not isinstance(error, HyperCompressError) or True


@dataclass(slots=True)
class WorkerStats:
    """What one worker has done since it started."""

    claimed: int = 0
    succeeded: int = 0
    failed: int = 0
    retried: int = 0
    bytes_in: int = 0
    bytes_out: int = 0
    busy_seconds: float = 0.0
    started_at: float = field(default_factory=time.monotonic)

    @property
    def uptime(self) -> float:
        return time.monotonic() - self.started_at

    @property
    def utilisation(self) -> float:
        return min(1.0, self.busy_seconds / self.uptime) if self.uptime > 0 else 0.0

    @property
    def bytes_saved(self) -> int:
        return max(0, self.bytes_in - self.bytes_out)

    def as_dict(self) -> dict[str, float | int]:
        return {
            "claimed": self.claimed,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "retried": self.retried,
            "bytes_in": self.bytes_in,
            "bytes_out": self.bytes_out,
            "bytes_saved": self.bytes_saved,
            "uptime_seconds": round(self.uptime, 2),
            "utilisation": round(self.utilisation, 4),
        }


class LeaseHeartbeat:
    """Renews a lease on a background thread for the life of one encode."""

    def __init__(self, queue: JobQueue, lease: Lease, *, lease_seconds: float) -> None:
        self.queue = queue
        self.lease = lease
        self.lease_seconds = lease_seconds
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.lost = False

    def __enter__(self) -> LeaseHeartbeat:
        # A third of the lease gives two chances to renew before it lapses, so a
        # single slow database call does not cost the job.
        interval = max(5.0, self.lease_seconds / 3.0)

        def loop() -> None:
            while not self._stop.wait(interval):
                if not self.queue.renew(self.lease, lease_seconds=self.lease_seconds):
                    # Losing the lease means another worker has taken the job.
                    # Continuing would produce two outputs for one job.
                    self.lost = True
                    log.warning(
                        "lease lost while encoding",
                        extra={"job_id": self.lease.job.job_id, "worker": self.lease.worker},
                    )
                    return

        self._thread = threading.Thread(target=loop, name="lease-heartbeat", daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)


class Worker:
    """Executes jobs from a queue until told to stop."""

    def __init__(
        self,
        queue: JobQueue,
        config: HyperCompressConfig | None = None,
        *,
        name: str | None = None,
        runner: FFmpegRunner | None = None,
        lease_seconds: float = DEFAULT_LEASE_SECONDS,
        poll_seconds: float = 2.0,
    ) -> None:
        self.queue = queue
        self.config = config or HyperCompressConfig.load()
        self.name = name or f"{platform.node()}-{os.getpid()}-{uuid.uuid4().hex[:6]}"
        self.runner = runner or FFmpegRunner()
        self.lease_seconds = lease_seconds
        self.poll_seconds = poll_seconds
        self.stats = WorkerStats()
        self._stopping = threading.Event()
        self._current: Lease | None = None
        self.optimiser = Optimiser(self.config, self.runner)
        self.validator = OutputValidator(self.runner)
        self.packager = Packager(self.runner)

    # -- lifecycle -------------------------------------------------------------------
    def install_signal_handlers(self) -> None:
        """Finish the job in hand on SIGTERM/SIGINT, then exit."""

        def handler(signum: int, _frame: object) -> None:
            log.info(
                "shutdown requested; finishing the current job before exiting",
                extra={"worker": self.name, "signal": signum},
            )
            self._stopping.set()

        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, handler)

    def stop(self) -> None:
        self._stopping.set()

    @property
    def stopping(self) -> bool:
        return self._stopping.is_set()

    def run_forever(
        self, *, max_jobs: int | None = None, idle_timeout: float | None = None
    ) -> WorkerStats:
        """Claim and execute jobs until stopped, drained, or capped."""
        log.info("worker started", extra={"worker": self.name})
        idle_since: float | None = None
        processed = 0

        while not self.stopping:
            lease = self.queue.claim(self.name, lease_seconds=self.lease_seconds)
            if lease is None:
                if idle_since is None:
                    idle_since = time.monotonic()
                if idle_timeout is not None and time.monotonic() - idle_since >= idle_timeout:
                    log.info("worker idle; exiting", extra={"worker": self.name})
                    break
                if self._stopping.wait(self.poll_seconds):
                    break
                continue

            idle_since = None
            self.execute(lease)
            processed += 1
            if max_jobs is not None and processed >= max_jobs:
                break

        log.info("worker stopped", extra={"worker": self.name, **self.stats.as_dict()})
        return self.stats

    # -- execution -------------------------------------------------------------------
    def execute(self, lease: Lease) -> JobResult:
        """Run one job to a terminal state, reporting the outcome to the queue."""
        job = lease.job
        self._current = lease
        self.stats.claimed += 1
        started = time.monotonic()

        with log_context(job_id=job.job_id, tenant=job.tenant, worker=self.name):
            log.info("job started", extra={"source": job.source_uri, "attempt": lease.attempt})
            try:
                with LeaseHeartbeat(self.queue, lease, lease_seconds=self.lease_seconds) as beat:
                    result = self._process(job)
                    if beat.lost:
                        # The lease went to another worker mid-encode. Discard
                        # this result rather than write a second output.
                        raise HyperCompressError(
                            "lease was lost during the encode; another worker owns this job"
                        )
            except BaseException as exc:  # noqa: BLE001 - every failure must reach the queue
                self.stats.failed += 1
                self.stats.busy_seconds += time.monotonic() - started
                retryable = is_retryable(exc)
                requeued = self.queue.fail(lease, f"{type(exc).__name__}: {exc}", retry=retryable)
                if requeued:
                    self.stats.retried += 1
                log.error(
                    "job failed",
                    extra={
                        "error": str(exc),
                        "type": type(exc).__name__,
                        "retryable": retryable,
                        "requeued": requeued,
                    },
                )
                self._current = None
                return JobResult(
                    job_id=job.job_id,
                    state=JobState.RETRYING if requeued else JobState.FAILED,
                    error=str(exc),
                    worker=self.name,
                )

            elapsed = time.monotonic() - started
            self.stats.busy_seconds += elapsed
            self.stats.succeeded += 1
            self.stats.bytes_in += result.manifest.source_size if result.manifest else 0
            self.stats.bytes_out += result.manifest.output_size if result.manifest else 0
            self.queue.complete(
                lease,
                payload=result.manifest.model_dump(mode="json") if result.manifest else None,
            )
            log.info(
                "job complete",
                extra={
                    "seconds": round(elapsed, 2),
                    "saved": result.bytes_saved,
                },
            )
            self._current = None
            return result

    def _process(self, job: JobSpec) -> JobResult:
        """Optimise, validate, package. Any failure raises."""
        source = Path(job.source_uri)
        if not source.exists():
            raise StorageError(f"source not found: {source}")

        destination = (
            Path(job.destination_uri) if job.destination_uri else self._default_output(job, source)
        )
        if destination.resolve() == source.resolve():
            # Overwriting the source is never a legitimate outcome: a failed
            # encode would destroy the only copy.
            raise ConfigError("the destination must not be the source file")

        # Write to a temporary name and move into place only after validation,
        # so an interrupted worker never leaves something that looks finished.
        staging = destination.with_name(f".{destination.name}.{uuid.uuid4().hex[:8]}.partial")

        config = self.config
        if job.compute_budget_seconds is not None:
            config = config.merged_with(
                search={"compute_budget_seconds": job.compute_budget_seconds}
            )
        if job.quality_floor is not None:
            config = config.merged_with(quality={"floor": job.quality_floor})
        if job.overrides:
            config = config.merged_with(**job.overrides)

        optimiser = Optimiser(config, self.runner)
        try:
            outcome: OptimisationResult = optimiser.optimise(
                source,
                staging,
                profile=job.profile,
                target_size=job.target_size,
                job_id=job.job_id,
            )

            if outcome.skipped:
                staging.unlink(missing_ok=True)
                log.info("source left unchanged", extra={"reason": outcome.skip_reason})
                return JobResult(
                    job_id=job.job_id,
                    state=JobState.SUCCEEDED,
                    manifest=None,
                    worker=self.name,
                )

            if outcome.output is None:
                raise ValidationError(f"no output was produced: {outcome.stop_reason}")

            validation = self.validator.validate(
                staging,
                outcome.media,
                outcome.plan,
                deep=True,
                expect_lossless=job.profile == "lossless",
            )
            validation.raise_for_status()

            if job.dry_run:
                staging.unlink(missing_ok=True)
                log.info("dry run: output discarded after validation")
                return JobResult(job_id=job.job_id, state=JobState.SUCCEEDED, worker=self.name)

            destination.parent.mkdir(parents=True, exist_ok=True)
            staging.replace(destination)

            manifest: Manifest = self.packager.manifest(
                source=outcome.media,
                output=destination,
                plan=outcome.plan,
                quality=outcome.quality,
                validation=validation,
                profile_name=outcome.profile_name,
                job_id=job.job_id,
                notes=outcome.notes,
            )
            manifest.content_class = outcome.analysis.content_class
            manifest.usage = outcome.usage
            manifest.candidates_evaluated = len(outcome.candidates)
            manifest.search_log = outcome.candidates
            self.packager.write(manifest, self.packager.sidecar_path(destination))

            return JobResult(
                job_id=job.job_id,
                state=JobState.SUCCEEDED,
                manifest=manifest,
                worker=self.name,
            )
        finally:
            staging.unlink(missing_ok=True)

    def _default_output(self, job: JobSpec, source: Path) -> Path:
        root = self.config.work_dir / "outputs" / job.tenant
        return root / f"{source.stem}.mkv"


class WorkerPool:
    """Runs several workers in one process.

    Useful where one machine has more cores than a single encode can saturate.
    Encoders scale badly past a point — an x265 encode on 32 threads is far less
    than 32 times a single-thread encode — so two workers at 16 threads each
    routinely beat one at 32.
    """

    def __init__(
        self,
        queue: JobQueue,
        config: HyperCompressConfig | None = None,
        *,
        size: int = 2,
        lease_seconds: float = DEFAULT_LEASE_SECONDS,
    ) -> None:
        self.queue = queue
        self.config = config or HyperCompressConfig.load()
        self.size = max(1, size)
        self.lease_seconds = lease_seconds
        self.workers: list[Worker] = []
        self._threads: list[threading.Thread] = []

    def start(self, *, max_jobs: int | None = None, idle_timeout: float | None = None) -> None:
        for index in range(self.size):
            worker = Worker(
                self.queue,
                self.config,
                name=f"{platform.node()}-{os.getpid()}-{index}",
                lease_seconds=self.lease_seconds,
            )
            self.workers.append(worker)
            thread = threading.Thread(
                target=worker.run_forever,
                kwargs={"max_jobs": max_jobs, "idle_timeout": idle_timeout},
                name=f"worker-{index}",
                daemon=True,
            )
            thread.start()
            self._threads.append(thread)
        log.info("worker pool started", extra={"size": self.size})

    def stop(self, *, timeout: float = 600.0) -> None:
        for worker in self.workers:
            worker.stop()
        for thread in self._threads:
            thread.join(timeout=timeout)
        log.info("worker pool stopped", extra=self.stats())

    def stats(self) -> dict[str, float | int]:
        total: dict[str, float | int] = {}
        for worker in self.workers:
            for key, value in worker.stats.as_dict().items():
                if key == "utilisation":
                    continue
                total[key] = total.get(key, 0) + value
        total["workers"] = len(self.workers)
        return total


class Scheduler:
    """Submits work and reports on it.

    Deliberately thin. Ordering and fairness live in the queue, where they can
    be enforced across every worker rather than in one process's view of the
    world.
    """

    def __init__(self, queue: JobQueue, config: HyperCompressConfig | None = None) -> None:
        self.queue = queue
        self.config = config or HyperCompressConfig.load()

    def submit(self, job: JobSpec) -> str:
        self._check_backpressure()
        return self.queue.submit(job)

    def submit_many(self, jobs: list[JobSpec]) -> list[str]:
        self._check_backpressure()
        return [self.queue.submit(job) for job in jobs]

    def _check_backpressure(self) -> None:
        """Refuse new work when the queue is already deeper than the fleet can drain.

        Accepting unbounded work is how a queue turns into a black hole: jobs go
        in, latency climbs without limit, and nothing signals that anything is
        wrong until someone asks why yesterday's batch has not finished.
        """
        limit = self.config.distributed.max_queue_depth
        if limit and self.queue.depth() >= limit:
            raise QuotaExceeded(
                f"the queue is at its configured depth limit of {limit} jobs; "
                f"add workers or raise distributed.max_queue_depth"
            )

    def status(self) -> dict[str, int]:
        return self.queue.stats()

    def drain(self, *, poll: float = 2.0, timeout: float | None = None) -> bool:
        """Block until the queue is empty. Returns False on timeout."""
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            stats = self.queue.stats()
            if stats["pending"] == 0 and stats["running"] == 0:
                return True
            if deadline is not None and time.monotonic() >= deadline:
                return False
            time.sleep(poll)


ProgressHook = Callable[[JobResult], None]
