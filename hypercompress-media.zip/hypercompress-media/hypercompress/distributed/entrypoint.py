"""Worker process entrypoint.

Run as ``python -m hypercompress.distributed.entrypoint``. It exists so that a
container image can start a worker without a shell wrapper parsing environment
variables into command-line flags — the configuration already reads the
environment, so the entrypoint's only job is to build a pool, install signal
handlers, and block.

Exit codes are meaningful to an orchestrator:

``0``
    Stopped cleanly, either on SIGTERM or after draining an empty queue.
``1``
    Could not start — usually no usable encoder, which restarting will not fix.
"""

from __future__ import annotations

import signal
import threading

from hypercompress.config import HyperCompressConfig
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.logging import configure_logging, get_logger
from hypercompress.distributed.queue import build_queue
from hypercompress.distributed.worker import WorkerPool

log = get_logger(__name__)


def main() -> int:
    config = HyperCompressConfig.load()
    configure_logging(
        level=config.observability.log_level.upper(),
        json_logs=config.observability.json_logs,
    )

    runner = FFmpegRunner()
    encoders = [
        name
        for name in ("libsvtav1", "libaom-av1", "libx265", "libx264", "libvpx-vp9")
        if runner.capabilities.has_encoder(name)
    ]
    if not encoders:
        # Failing fast beats a worker that claims jobs and fails every one of
        # them. A crash-looping pod is a visible problem; a worker quietly
        # dead-lettering the whole queue is not.
        log.error("no usable video encoder is available; refusing to start")
        return 1

    log.info(
        "worker starting",
        extra={
            "encoders": encoders,
            "vmaf": runner.capabilities.has_vmaf,
            "concurrency": config.distributed.worker_concurrency,
        },
    )
    if not runner.capabilities.has_vmaf:
        log.warning("libvmaf is unavailable; VMAF figures will be estimates")

    queue = build_queue(config.distributed.queue_backend, path=config.distributed.sqlite_path)
    pool = WorkerPool(
        queue,
        config,
        size=config.distributed.worker_concurrency,
        lease_seconds=config.distributed.visibility_timeout_seconds,
    )
    pool.start()

    stopped = threading.Event()

    def handle(signum: int, _frame: object) -> None:
        log.info("shutdown signal received; finishing in-flight encodes", extra={"signal": signum})
        stopped.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, handle)

    stopped.wait()
    pool.stop(timeout=config.distributed.graceful_shutdown_seconds)
    log.info("worker stopped", extra=pool.stats())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
