"""Command-line interface (Phase 18).

Six verbs, each answering a question an operator actually asks:

``inspect``    What is this file, and what would you do to it?
``optimise``   Compress one file.
``batch``      Compress a directory, with workers.
``dedup``      What duplicates are in this library?
``cost``       Was that worth it?
``profiles``   What settings are available?

Two principles run through the whole interface.

**Dry runs are first-class.** ``inspect`` and ``optimise --dry-run`` answer
"what would happen" without spending an hour of CPU finding out. At library
scale that is the difference between a considered rollout and an expensive
surprise.

**Nothing is destructive.** There is no ``--replace`` flag and no delete verb.
``dedup`` prints a plan; removing files is left to the operator and to tools
that specialise in it. A media library is often the only copy of something.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections.abc import Sequence
from pathlib import Path

from hypercompress import __version__
from hypercompress.analysis.complexity import ContentAnalyser
from hypercompress.analysis.containers import is_media_extension
from hypercompress.analysis.media_probe import MediaProbe
from hypercompress.analytics.cost import CostBreakdown, FleetCostReport
from hypercompress.config import HyperCompressConfig
from hypercompress.core.errors import HyperCompressError
from hypercompress.core.ffmpeg import FFmpegRunner, detect_capabilities
from hypercompress.core.logging import configure_logging
from hypercompress.core.types import JobPriority, JobSpec, ResourceUsage
from hypercompress.core.units import format_duration, format_size, parse_size
from hypercompress.dedup.scanner import Deduplicator, plan_reclaim
from hypercompress.distributed.queue import build_queue
from hypercompress.distributed.worker import Scheduler, WorkerPool
from hypercompress.optimisation.optimiser import Optimiser
from hypercompress.optimisation.planner import EncodePlanner
from hypercompress.optimisation.profiles import all_profiles, get_profile, suggest_profile


def _runner(config: HyperCompressConfig) -> FFmpegRunner:
    return FFmpegRunner(detect_capabilities(config.ffmpeg.ffmpeg_path, config.ffmpeg.ffprobe_path))


def _media_files(root: Path, recursive: bool = True) -> list[Path]:
    if root.is_file():
        return [root]
    walker = root.rglob("*") if recursive else root.glob("*")
    return sorted(p for p in walker if p.is_file() and is_media_extension(p))


# --------------------------------------------------------------------------------------
# inspect
# --------------------------------------------------------------------------------------


def cmd_inspect(args: argparse.Namespace) -> int:
    config = HyperCompressConfig.load(args.config)
    runner = _runner(config)
    source = Path(args.source)

    media = MediaProbe(runner).probe(source, checksum=args.checksum)
    analysis = ContentAnalyser(runner).analyse(media)

    profile_name = args.profile or suggest_profile(analysis.content_class).name
    profile = get_profile(profile_name)
    planner = EncodePlanner(runner.capabilities, profile.apply(config), profile)
    plan = planner.initial_plan(media, analysis)
    predicted = planner.predict_size(media, analysis, plan)
    worth, reason = planner.worth_encoding(media, predicted)

    if args.json:
        print(
            json.dumps(
                {
                    "media": media.model_dump(mode="json"),
                    "analysis": analysis.model_dump(mode="json"),
                    "profile": profile_name,
                    "plan": plan.model_dump(mode="json"),
                    "predicted_size": predicted,
                    "worth_encoding": worth,
                    "reason": reason,
                },
                indent=2,
            )
        )
        return 0

    print(f"{source}")
    print(f"  {media.summary()}")
    print(f"  content    {analysis.content_class.value} ({analysis.confidence:.0%} confidence)")
    for line in analysis.rationale[:3]:
        print(f"             - {line}")
    print(f"  profile    {profile_name}" + ("" if args.profile else " (suggested)"))
    print(f"  plan       {plan.fingerprint}")
    print(
        f"  predicted  {format_size(predicted)} from {format_size(media.size_bytes)} "
        f"({1 - predicted / max(media.size_bytes, 1):.1%} smaller)"
    )
    print(f"  verdict    {'re-encode' if worth else 'leave alone'} — {reason}")
    print("\n  Prediction only. Nothing has been encoded and nothing measured.")
    return 0


# --------------------------------------------------------------------------------------
# optimise
# --------------------------------------------------------------------------------------


def cmd_optimise(args: argparse.Namespace) -> int:
    config = HyperCompressConfig.load(args.config)
    if args.budget is not None:
        config = config.merged_with(search={"compute_budget_seconds": args.budget})
    if args.floor is not None:
        config = config.merged_with(quality={"floor": args.floor})

    source = Path(args.source)
    output = Path(args.output) if args.output else source.with_name(f"{source.stem}.optimised.mkv")
    target = parse_size(args.target_size) if args.target_size else None

    started = time.monotonic()
    result = Optimiser(config).optimise(source, output, profile=args.profile, target_size=target)

    if args.json:
        print(
            json.dumps(
                {
                    "summary": result.summary(),
                    "source_size": result.source_size,
                    "output_size": result.output_size,
                    "ratio": round(result.ratio, 4),
                    "reduction": round(result.reduction, 4),
                    "quality": result.quality.model_dump(mode="json"),
                    "quality_met": result.quality_met,
                    "target_met": result.target_met,
                    "plan": result.plan.model_dump(mode="json") if result.plan else None,
                    "stop_reason": result.stop_reason,
                    "notes": result.notes,
                    "candidates": result.candidates,
                    "seconds": round(result.total_seconds, 2),
                },
                indent=2,
            )
        )
        return 0 if result.output_size else 1

    print(result.summary())
    if args.verbose:
        print(
            f"\n  searched {len(result.candidates)} candidates in "
            f"{format_duration(result.search_seconds)}, stopped: {result.stop_reason}"
        )
        for row in result.candidates:
            print(
                f"    {str(row.get('codec')):6s} crf {str(row.get('crf')):6s} "
                f"{format_size(int(row.get('output_size') or 0)):>10s}  "
                f"q {row.get('quality')}"
            )
    for note in result.notes:
        print(f"  ! {note}")
    print(f"\n  total {format_duration(time.monotonic() - started)}")
    return 0 if result.output_size or result.skipped else 1


# --------------------------------------------------------------------------------------
# batch
# --------------------------------------------------------------------------------------


def cmd_batch(args: argparse.Namespace) -> int:
    config = HyperCompressConfig.load(args.config)
    root = Path(args.source)
    destination = Path(args.output)
    files = _media_files(root, recursive=not args.no_recursive)
    if not files:
        print(f"no media files found under {root}", file=sys.stderr)
        return 1

    queue = build_queue(
        args.queue or config.distributed.queue_backend,
        path=config.distributed.sqlite_path,
    )
    scheduler = Scheduler(queue, config)
    target = parse_size(args.target_size) if args.target_size else None

    for index, path in enumerate(files):
        relative = path.relative_to(root) if root.is_dir() else Path(path.name)
        out = destination / relative.with_suffix(".mkv")
        scheduler.submit(
            JobSpec(
                job_id=f"{path.stem}-{index:05d}",
                source_uri=str(path),
                destination_uri=str(out),
                profile=args.profile,
                target_size=target,
                priority=JobPriority(args.priority),
                dry_run=args.dry_run,
            )
        )

    print(f"queued {len(files)} files ({format_size(sum(f.stat().st_size for f in files))})")
    pool = WorkerPool(queue, config, size=args.workers)
    pool.start(idle_timeout=5.0)

    try:
        while True:
            stats = queue.stats()
            done = stats["succeeded"] + stats["failed"]
            print(
                f"\r  {done}/{len(files)} done  "
                f"({stats['running']} running, {stats['pending']} queued, "
                f"{stats['failed']} failed)",
                end="",
                flush=True,
            )
            if stats["pending"] == 0 and stats["running"] == 0:
                break
            time.sleep(2.0)
    except KeyboardInterrupt:
        print("\ninterrupted; letting workers finish their current jobs")
    finally:
        pool.stop()

    stats = queue.stats()
    totals = pool.stats()
    print(
        f"\n{stats['succeeded']} succeeded, {stats['failed']} failed. "
        f"{format_size(int(totals.get('bytes_in', 0)))} -> "
        f"{format_size(int(totals.get('bytes_out', 0)))} "
        f"({format_size(int(totals.get('bytes_saved', 0)))} saved)"
    )
    return 0 if stats["failed"] == 0 else 1


# --------------------------------------------------------------------------------------
# dedup
# --------------------------------------------------------------------------------------


def cmd_dedup(args: argparse.Namespace) -> int:
    config = HyperCompressConfig.load(args.config)
    files = _media_files(Path(args.source))
    report = Deduplicator(_runner(config) if args.streams else None).scan(
        files, stream_level=args.streams, chunk_level=args.chunks
    )

    if args.json:
        print(json.dumps(report.as_dict(), indent=2))
        return 0

    print(report.summary())

    # Render the groups from the reconciled plan rather than from each group's
    # own keeper. A file can be the keeper of one group and a member of another,
    # and showing both views leaves the operator with two contradictory
    # instructions about the same file.
    plan = plan_reclaim(report)
    protected = {keeper for keeper, _ in plan}
    for group in report.groups:
        print(f"\n  {group.describe()}")
        for path in group.paths:
            marker = (
                "keep "
                if path in protected or path not in {d for _, ds in plan for d in ds}
                else "dup  "
            )
            print(f"     {marker} {path}")
    for overlap in report.partial:
        print(f"\n  {overlap.describe()}")

    if plan:
        print("\nProposed reclaim (nothing has been deleted; review before acting):")
        for keeper, drops in plan:
            print(f"  keep {keeper}")
            for drop in drops:
                print(f"    rm {drop}")
    return 0


# --------------------------------------------------------------------------------------
# cost
# --------------------------------------------------------------------------------------


def cmd_cost(args: argparse.Namespace) -> int:
    config = HyperCompressConfig.load(args.config)
    manifests = (
        [Path(args.source)]
        if Path(args.source).is_file()
        else sorted(Path(args.source).rglob("*.manifest.json"))
    )
    if not manifests:
        print(f"no manifests found under {args.source}", file=sys.stderr)
        return 1

    report = FleetCostReport(model=config.cost)
    for path in manifests:
        data = json.loads(path.read_text())
        usage = ResourceUsage.model_validate(data.get("usage") or {})
        report.add(
            CostBreakdown(
                source_bytes=int(data.get("source_size", 0)),
                output_bytes=int(data.get("output_size", 0)),
                usage=usage,
                model=config.cost,
                monthly_egress_multiple=args.egress,
            )
        )

    if args.json:
        print(
            json.dumps({**report.as_dict(), "items": [i.as_dict() for i in report.items]}, indent=2)
        )
        return 0

    print(report.summary())
    print(f"\n  carbon  {report.carbon_kg:.3f} kg CO2e (estimated from CPU time, not metered)")
    for item in report.uneconomic:
        print(f"  ! {item.verdict()}")
    return 0


# --------------------------------------------------------------------------------------
# profiles
# --------------------------------------------------------------------------------------


def cmd_profiles(args: argparse.Namespace) -> int:
    profiles = all_profiles(HyperCompressConfig.load(args.config))
    if args.json:
        print(
            json.dumps({name: p.model_dump(mode="json") for name, p in profiles.items()}, indent=2)
        )
        return 0
    width = max(len(name) for name in profiles)
    for name, profile in sorted(profiles.items()):
        flags = []
        if profile.lossless:
            flags.append("lossless")
        if profile.extreme:
            flags.append("extreme")
        if profile.target_size_ratio:
            flags.append(f"target {profile.target_size_ratio:.0%}")
        suffix = f"  [{', '.join(flags)}]" if flags else ""
        print(f"  {name:<{width}}  {profile.description}{suffix}")
    return 0


# --------------------------------------------------------------------------------------
# argument parsing
# --------------------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hypercompress",
        description="Hyperscale media compression with measured, not assumed, quality.",
    )
    parser.add_argument("--version", action="version", version=f"HYPERCOMPRESS MEDIA {__version__}")
    parser.add_argument("--config", type=Path, help="path to a TOML or JSON configuration file")
    parser.add_argument("--log-format", choices=["human", "json"], default="human")
    parser.add_argument("--log-level", default="warning")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("inspect", help="analyse a file and show what would be done to it")
    p.add_argument("source", type=Path)
    p.add_argument("--profile", help="profile to plan against (default: suggested from content)")
    p.add_argument("--checksum", action="store_true", help="compute a full-file digest")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_inspect)

    p = sub.add_parser("optimise", aliases=["optimize"], help="compress one file")
    p.add_argument("source", type=Path)
    p.add_argument("-o", "--output", type=Path)
    p.add_argument("--profile", default="balanced")
    p.add_argument("--target-size", help="byte target, e.g. 1GB or 750MiB")
    p.add_argument("--floor", type=float, help="override the composite quality floor")
    p.add_argument("--budget", type=float, help="search compute budget in seconds")
    p.add_argument("-v", "--verbose", action="store_true", help="show every candidate tried")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_optimise)

    p = sub.add_parser("batch", help="compress a directory using a worker pool")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--profile", default="balanced")
    p.add_argument("--target-size")
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--queue", choices=["memory", "sqlite"])
    p.add_argument("--priority", choices=[p.value for p in JobPriority], default="normal")
    p.add_argument("--no-recursive", action="store_true")
    p.add_argument("--dry-run", action="store_true", help="encode and validate, then discard")
    p.set_defaults(func=cmd_batch)

    p = sub.add_parser("dedup", help="report duplicate content; never deletes")
    p.add_argument("source", type=Path)
    p.add_argument("--streams", action="store_true", help="also match across containers")
    p.add_argument("--chunks", action="store_true", help="also report partial overlap")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_dedup)

    p = sub.add_parser("cost", help="economics of work already done, from its manifests")
    p.add_argument("source", type=Path, help="a manifest file or a directory of them")
    p.add_argument("--egress", type=float, help="downloads per object per month")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_cost)

    p = sub.add_parser("profiles", help="list the available compression profiles")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_profiles)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    configure_logging(level=args.log_level.upper(), json_logs=args.log_format == "json")
    try:
        return int(args.func(args))
    except HyperCompressError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return exc.exit_code
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
