"""Object storage.

A source is never overwritten and every write is verified before it is
reported as successful.
"""

from __future__ import annotations

from hypercompress.storage.backends import (
    LocalStorage,
    S3Storage,
    Storage,
    StoredObject,
    build_storage,
)

__all__ = ["LocalStorage", "S3Storage", "Storage", "StoredObject", "build_storage"]
