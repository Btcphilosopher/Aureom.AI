"""Object storage (Phase 15).

The platform's whole proposition is that the optimised copy can be trusted
enough to tier away the original. That makes the storage layer the last place a
mistake stays cheap, so three rules are enforced here rather than left to
callers:

**A source is never overwritten.** Not by configuration, not by an unlucky path
collision, not by a retried job. :meth:`Storage.put` refuses a destination that
resolves to the source, and the pipeline stages through a temporary name.

**Every write is verified.** The bytes are read back and digested before the
write is reported as successful. A write that silently truncated is the exact
failure that costs a library, and it costs one extra read to rule out.

**Writes are atomic from the reader's point of view.** Local writes land on a
temporary name in the same directory and are renamed into place; S3 writes are
single-object PUTs or completed multipart uploads. A reader never sees a partial
object.

Backends share one interface so the pipeline does not care where bytes live.
Local and S3 ship here; Azure and GCS follow the same protocol and are wired
through :func:`build_storage` when their optional dependencies are installed.
"""

from __future__ import annotations

import os
import shutil
import tempfile
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Protocol
from urllib.parse import urlparse

from hypercompress.core.errors import ConfigError, StorageError
from hypercompress.core.hashing import file_digest
from hypercompress.core.logging import get_logger
from hypercompress.core.units import format_size

log = get_logger(__name__)

#: Objects larger than this are uploaded in parts rather than in one request.
MULTIPART_THRESHOLD = 64 * 1024 * 1024
MULTIPART_CHUNK = 16 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class StoredObject:
    """What came back from a successful write."""

    uri: str
    size: int
    checksum: str
    storage_class: str = "standard"

    def __str__(self) -> str:
        return f"{self.uri} ({format_size(self.size)})"


class Storage(Protocol):
    """The interface every backend implements."""

    scheme: str

    def put(self, local: Path, key: str, *, verify: bool = True) -> StoredObject: ...

    def get(self, key: str, local: Path) -> Path: ...

    def exists(self, key: str) -> bool: ...

    def size(self, key: str) -> int: ...

    def delete(self, key: str) -> bool: ...

    def list(self, prefix: str = "") -> Iterator[str]: ...

    def uri(self, key: str) -> str: ...


def _guard_not_source(local: Path, destination: Path) -> None:
    """Refuse any write that would land on top of its own input."""
    try:
        same = local.resolve() == destination.resolve()
    except OSError:  # pragma: no cover - resolve on a missing parent
        same = False
    if same:
        raise StorageError(
            f"refusing to write {destination} over its own source; "
            f"an optimised copy must never replace the file it was made from"
        )


class LocalStorage:
    """Filesystem storage with atomic, verified writes."""

    scheme = "file"

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        # Keys are joined under the root and then checked, so a key containing
        # ``../`` cannot escape into the wider filesystem.
        candidate = (self.root / key.lstrip("/")).resolve()
        if not str(candidate).startswith(str(self.root)):
            raise StorageError(f"key {key!r} escapes the storage root")
        return candidate

    def put(self, local: Path, key: str, *, verify: bool = True) -> StoredObject:
        local = Path(local)
        if not local.exists():
            raise StorageError(f"nothing to store: {local} does not exist")
        destination = self._path(key)
        _guard_not_source(local, destination)
        destination.parent.mkdir(parents=True, exist_ok=True)

        # Stage in the destination directory so the rename is on one filesystem
        # and therefore atomic.
        handle, staging_name = tempfile.mkstemp(
            dir=destination.parent, prefix=".hc-", suffix=".part"
        )
        os.close(handle)
        staging = Path(staging_name)
        try:
            shutil.copyfile(local, staging)
            with staging.open("rb") as fh:
                os.fsync(fh.fileno())
            staging.replace(destination)
        except OSError as exc:
            staging.unlink(missing_ok=True)
            raise StorageError(f"failed to store {local} at {destination}: {exc}") from exc

        checksum = file_digest(destination)
        if verify:
            expected = file_digest(local)
            if checksum != expected or destination.stat().st_size != local.stat().st_size:
                destination.unlink(missing_ok=True)
                raise StorageError(
                    f"verification failed for {destination}: the stored copy does not match "
                    f"the source digest, so it has been removed rather than left in place"
                )
        return StoredObject(uri=self.uri(key), size=destination.stat().st_size, checksum=checksum)

    def get(self, key: str, local: Path) -> Path:
        source = self._path(key)
        if not source.exists():
            raise StorageError(f"object not found: {self.uri(key)}")
        local = Path(local)
        local.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, local)
        return local

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def size(self, key: str) -> int:
        path = self._path(key)
        if not path.exists():
            raise StorageError(f"object not found: {self.uri(key)}")
        return path.stat().st_size

    def delete(self, key: str) -> bool:
        path = self._path(key)
        if path.exists():
            path.unlink()
            return True
        return False

    def list(self, prefix: str = "") -> Iterator[str]:
        base = self.root / prefix.lstrip("/") if prefix else self.root
        search_root = base if base.is_dir() else self.root
        for path in sorted(search_root.rglob("*")):
            if path.is_file() and not path.name.startswith(".hc-"):
                key = str(path.relative_to(self.root))
                if key.startswith(prefix.lstrip("/")):
                    yield key

    def uri(self, key: str) -> str:
        return f"file://{self._path(key)}"


class S3Storage:
    """S3-compatible storage.

    Works against AWS S3, MinIO, Ceph RGW and anything else speaking the same
    API, which is why the endpoint is configurable rather than derived from a
    region. ``boto3`` is an optional dependency: the import happens here so a
    deployment that only uses local storage does not need it installed.
    """

    scheme = "s3"

    def __init__(
        self,
        bucket: str,
        *,
        prefix: str = "",
        endpoint_url: str | None = None,
        region: str | None = None,
        storage_class: str = "STANDARD",
    ) -> None:
        try:
            import boto3  # noqa: PLC0415 - optional dependency, imported on use
        except ImportError as exc:  # pragma: no cover - depends on the environment
            raise ConfigError(
                "S3 storage requires boto3; install the 's3' extra "
                "(pip install 'hypercompress-media[s3]')"
            ) from exc
        self.bucket = bucket
        self.prefix = prefix.strip("/")
        self.storage_class = storage_class
        self._client = boto3.client("s3", endpoint_url=endpoint_url, region_name=region)

    def _key(self, key: str) -> str:
        key = key.lstrip("/")
        return f"{self.prefix}/{key}" if self.prefix else key

    def put(self, local: Path, key: str, *, verify: bool = True) -> StoredObject:
        from botocore.exceptions import BotoCoreError, ClientError  # noqa: PLC0415

        local = Path(local)
        if not local.exists():
            raise StorageError(f"nothing to store: {local} does not exist")
        size = local.stat().st_size
        checksum = file_digest(local)
        target = self._key(key)

        extra = {
            "StorageClass": self.storage_class,
            # The digest travels with the object so a later integrity check does
            # not have to re-download the whole thing to know what it should be.
            "Metadata": {"hypercompress-sha256": checksum},
        }
        try:
            if size >= MULTIPART_THRESHOLD:
                self._client.upload_file(str(local), self.bucket, target, ExtraArgs=extra)
            else:
                with local.open("rb") as body:
                    self._client.put_object(Bucket=self.bucket, Key=target, Body=body, **extra)
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(
                f"failed to upload {local} to s3://{self.bucket}/{target}: {exc}"
            ) from exc

        if verify:
            stored = self._head(target)
            if stored.get("ContentLength") != size:
                raise StorageError(
                    f"verification failed for s3://{self.bucket}/{target}: stored "
                    f"{stored.get('ContentLength')} bytes, expected {size}"
                )
        return StoredObject(
            uri=self.uri(key), size=size, checksum=checksum, storage_class=self.storage_class
        )

    def _head(self, target: str) -> dict[str, object]:
        from botocore.exceptions import ClientError  # noqa: PLC0415

        try:
            return dict(self._client.head_object(Bucket=self.bucket, Key=target))
        except ClientError as exc:
            raise StorageError(f"object not found: s3://{self.bucket}/{target}") from exc

    def get(self, key: str, local: Path) -> Path:
        from botocore.exceptions import BotoCoreError, ClientError  # noqa: PLC0415

        local = Path(local)
        local.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._client.download_file(self.bucket, self._key(key), str(local))
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(f"failed to download {self.uri(key)}: {exc}") from exc
        return local

    def exists(self, key: str) -> bool:
        try:
            self._head(self._key(key))
            return True
        except StorageError:
            return False

    def size(self, key: str) -> int:
        return int(self._head(self._key(key)).get("ContentLength", 0))

    def delete(self, key: str) -> bool:
        from botocore.exceptions import ClientError  # noqa: PLC0415

        try:
            self._client.delete_object(Bucket=self.bucket, Key=self._key(key))
            return True
        except ClientError:
            return False

    def list(self, prefix: str = "") -> Iterator[str]:
        paginator = self._client.get_paginator("list_objects_v2")
        base = self._key(prefix) if prefix else self.prefix
        for page in paginator.paginate(Bucket=self.bucket, Prefix=base):
            for item in page.get("Contents", []):
                key = str(item["Key"])
                yield key[len(self.prefix) + 1 :] if self.prefix else key

    def uri(self, key: str) -> str:
        return f"s3://{self.bucket}/{self._key(key)}"


def build_storage(uri: str, **kwargs: object) -> Storage:
    """Construct a backend from a URI.

    ``/data/media`` and ``file:///data/media`` give local storage;
    ``s3://bucket/prefix`` gives S3.
    """
    parsed = urlparse(uri)
    scheme = parsed.scheme or "file"

    if scheme == "file":
        return LocalStorage(parsed.path or uri)
    if scheme == "s3":
        return S3Storage(
            parsed.netloc,
            prefix=parsed.path.lstrip("/"),
            endpoint_url=kwargs.get("endpoint_url"),  # type: ignore[arg-type]
            region=kwargs.get("region"),  # type: ignore[arg-type]
            storage_class=str(kwargs.get("storage_class", "STANDARD")),
        )
    raise ConfigError(
        f"unsupported storage scheme {scheme!r}; supported schemes are 'file' and 's3'"
    )


def open_stream(storage: Storage, key: str) -> BinaryIO:  # pragma: no cover - convenience
    """Fetch an object to a temporary file and return it open for reading."""
    handle = tempfile.NamedTemporaryFile(delete=False, suffix=Path(key).suffix)
    handle.close()
    storage.get(key, Path(handle.name))
    return Path(handle.name).open("rb")
