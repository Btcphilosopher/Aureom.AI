"""Metrics (Phase 19).

What to measure is a design decision, not an afterthought, and the choices here
follow from what an operator of this platform actually needs to answer at 3am:

*Is the fleet keeping up?* Queue depth and worker utilisation.

*Is it doing useful work?* Bytes in versus bytes out. A fleet at 100% CPU
producing a 3% reduction is a fleet wasting money, and CPU graphs alone will
never show that.

*Is it lying to anyone?* The count of outputs shipped below the quality floor.
This is the metric most systems of this kind do not have, and it is the one that
matters most: silent quality regression is invisible until a viewer complains
months later, by which time the sources may be gone.

Histogram buckets are chosen for the shape of the data rather than copied from
a default. Encode durations span seconds to hours, so the buckets are
exponential; compression ratios cluster between 0.1 and 1.0, so those are
linear across that range. Buckets that do not match the distribution produce
percentiles that are technically correct and practically useless.

``prometheus_client`` is optional. When it is absent every call here becomes a
no-op, because a metrics dependency that can break an encode is a worse trade
than no metrics.
"""

from __future__ import annotations

import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from hypercompress.core.logging import get_logger

log = get_logger(__name__)

try:  # pragma: no cover - depends on the environment
    from prometheus_client import (
        CollectorRegistry,
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )
    from prometheus_client.exposition import CONTENT_TYPE_LATEST

    PROMETHEUS_AVAILABLE = True
except ImportError:  # pragma: no cover
    PROMETHEUS_AVAILABLE = False
    CONTENT_TYPE_LATEST = "text/plain; version=0.0.4; charset=utf-8"

#: Encodes run from seconds to hours; linear buckets would put every real
#: encode in the last one.
DURATION_BUCKETS = (1, 5, 15, 60, 300, 900, 1800, 3600, 7200, 21600, float("inf"))

#: Output size as a fraction of input. Anything above 1.0 means the encode made
#: the file bigger, which is worth its own bucket rather than being lost in an
#: overflow.
RATIO_BUCKETS = (0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.65, 0.8, 1.0, 1.5, float("inf"))

#: Quality on the platform's composite scale, bucketed finely near the floor
#: because that is the only region where the value changes a decision.
QUALITY_BUCKETS = (0.5, 0.7, 0.8, 0.85, 0.88, 0.90, 0.92, 0.95, 0.98, 1.0)


class _NullMetric:
    """Stands in for a metric when prometheus_client is not installed."""

    def labels(self, *args: object, **kwargs: object) -> _NullMetric:
        return self

    def inc(self, amount: float = 1) -> None:
        return None

    def dec(self, amount: float = 1) -> None:
        return None

    def set(self, value: float) -> None:
        return None

    def observe(self, value: float) -> None:
        return None


@dataclass(slots=True)
class Metrics:
    """The platform's metric surface."""

    namespace: str = "hypercompress"
    registry: Any = None
    _metrics: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not PROMETHEUS_AVAILABLE:
            log.debug("prometheus_client not installed; metrics are disabled")
            return
        self.registry = self.registry or CollectorRegistry()
        ns = self.namespace

        def counter(name: str, doc: str, labels: tuple[str, ...] = ()) -> Any:
            return Counter(f"{ns}_{name}", doc, labels, registry=self.registry)

        def gauge(name: str, doc: str, labels: tuple[str, ...] = ()) -> Any:
            return Gauge(f"{ns}_{name}", doc, labels, registry=self.registry)

        def histogram(
            name: str, doc: str, buckets: tuple[float, ...], labels: tuple[str, ...] = ()
        ) -> Any:
            return Histogram(f"{ns}_{name}", doc, labels, buckets=buckets, registry=self.registry)

        self._metrics = {
            # -- throughput -------------------------------------------------------
            "jobs_total": counter(
                "jobs_total", "Jobs reaching a terminal state", ("state", "profile", "tenant")
            ),
            "bytes_in": counter("source_bytes_total", "Bytes read from sources", ("tenant",)),
            "bytes_out": counter("output_bytes_total", "Bytes written as outputs", ("tenant",)),
            "bytes_saved": counter("bytes_saved_total", "Bytes eliminated", ("tenant",)),
            # -- the honesty metrics ----------------------------------------------
            "below_floor": counter(
                "outputs_below_quality_floor_total",
                "Outputs shipped below the configured quality floor. Should be zero; "
                "a rising value means the platform is delivering less than it promises.",
                ("profile", "reason"),
            ),
            "target_missed": counter(
                "size_targets_missed_total",
                "Jobs whose requested size target could not be reached",
                ("profile",),
            ),
            "estimated_vmaf": counter(
                "estimated_vmaf_total",
                "Quality reports carrying an estimated rather than measured VMAF",
            ),
            # -- work shape --------------------------------------------------------
            "encode_seconds": histogram(
                "encode_duration_seconds", "Wall time per encode", DURATION_BUCKETS, ("profile",)
            ),
            "search_seconds": histogram(
                "search_duration_seconds",
                "Wall time spent searching",
                DURATION_BUCKETS,
                ("profile",),
            ),
            "ratio": histogram(
                "compression_ratio",
                "Output size as a fraction of source",
                RATIO_BUCKETS,
                ("profile",),
            ),
            "quality": histogram(
                "delivered_quality",
                "Composite quality of delivered outputs",
                QUALITY_BUCKETS,
                ("profile",),
            ),
            "candidates": histogram(
                "candidates_evaluated",
                "Candidates tried per job",
                (1, 2, 3, 5, 8, 12, 20, 40, float("inf")),
                ("profile",),
            ),
            # -- fleet -------------------------------------------------------------
            "queue_depth": gauge("queue_depth", "Jobs waiting to be claimed"),
            "workers_busy": gauge("workers_busy", "Workers currently encoding"),
            "worker_utilisation": gauge(
                "worker_utilisation", "Fraction of uptime spent encoding", ("worker",)
            ),
            "lease_expiries": counter(
                "lease_expiries_total",
                "Leases reclaimed after a worker stopped renewing — each one is a "
                "crashed or wedged worker",
            ),
            "retries": counter("job_retries_total", "Job attempts after a failure", ("reason",)),
            # -- economics ----------------------------------------------------------
            "compute_cost": counter("compute_cost_total", "Estimated compute spend", ("tenant",)),
            "monthly_saving": gauge(
                "projected_monthly_saving", "Projected storage saving per month"
            ),
        }

    def _metric(self, name: str) -> Any:
        return self._metrics.get(name, _NullMetric()) if PROMETHEUS_AVAILABLE else _NullMetric()

    # -- recording -------------------------------------------------------------------
    def job_finished(
        self,
        *,
        state: str,
        profile: str,
        tenant: str = "default",
        source_bytes: int = 0,
        output_bytes: int = 0,
        seconds: float = 0.0,
        search_seconds: float = 0.0,
        quality: float | None = None,
        candidates: int = 0,
        quality_met: bool = True,
        target_met: bool | None = None,
        floor_reason: str = "",
        vmaf_estimated: bool = False,
    ) -> None:
        """Record everything about one finished job in one call."""
        self._metric("jobs_total").labels(state=state, profile=profile, tenant=tenant).inc()
        if source_bytes:
            self._metric("bytes_in").labels(tenant=tenant).inc(source_bytes)
        if output_bytes:
            self._metric("bytes_out").labels(tenant=tenant).inc(output_bytes)
        if source_bytes > output_bytes:
            self._metric("bytes_saved").labels(tenant=tenant).inc(source_bytes - output_bytes)
        if seconds:
            self._metric("encode_seconds").labels(profile=profile).observe(seconds)
        if search_seconds:
            self._metric("search_seconds").labels(profile=profile).observe(search_seconds)
        if source_bytes and output_bytes:
            self._metric("ratio").labels(profile=profile).observe(output_bytes / source_bytes)
        if quality is not None:
            self._metric("quality").labels(profile=profile).observe(quality)
        if candidates:
            self._metric("candidates").labels(profile=profile).observe(candidates)
        if not quality_met:
            self._metric("below_floor").labels(
                profile=profile, reason=floor_reason or "unspecified"
            ).inc()
        if target_met is False:
            self._metric("target_missed").labels(profile=profile).inc()
        if vmaf_estimated:
            self._metric("estimated_vmaf").inc()

    def queue_depth(self, depth: int) -> None:
        self._metric("queue_depth").set(depth)

    def workers_busy(self, count: int) -> None:
        self._metric("workers_busy").set(count)

    def worker_utilisation(self, worker: str, fraction: float) -> None:
        self._metric("worker_utilisation").labels(worker=worker).set(fraction)

    def lease_expired(self, count: int = 1) -> None:
        self._metric("lease_expiries").inc(count)

    def retry(self, reason: str) -> None:
        self._metric("retries").labels(reason=reason).inc()

    def compute_cost(self, amount: float, tenant: str = "default") -> None:
        self._metric("compute_cost").labels(tenant=tenant).inc(amount)

    def monthly_saving(self, amount: float) -> None:
        self._metric("monthly_saving").set(amount)

    @contextmanager
    def time_encode(self, profile: str) -> Iterator[None]:
        started = time.monotonic()
        try:
            yield
        finally:
            self._metric("encode_seconds").labels(profile=profile).observe(
                time.monotonic() - started
            )

    # -- exposition ------------------------------------------------------------------
    def render(self) -> tuple[bytes, str]:
        """The Prometheus scrape payload and its content type."""
        if not PROMETHEUS_AVAILABLE or self.registry is None:
            return (
                b"# prometheus_client is not installed; metrics are disabled\n",
                CONTENT_TYPE_LATEST,
            )
        return (generate_latest(self.registry), CONTENT_TYPE_LATEST)


#: The process-wide metrics instance. A module-level singleton is right here:
#: Prometheus collectors are process-global by nature, and registering the same
#: metric twice raises.
METRICS = Metrics()


def record_optimisation(result: Any, *, tenant: str = "default") -> None:
    """Record an :class:`OptimisationResult` without importing it.

    Typed loosely to keep :mod:`hypercompress.analytics` free of a dependency on
    the optimiser, which already depends on nearly everything else.
    """
    reason = ""
    if not getattr(result, "quality_met", True):
        quality = getattr(result, "quality", None)
        composite = getattr(quality, "composite", None)
        reason = "composite" if composite is not None else "unmeasured"

    METRICS.job_finished(
        state="skipped" if getattr(result, "skipped", False) else "succeeded",
        profile=getattr(result, "profile_name", "unknown"),
        tenant=tenant,
        source_bytes=getattr(result, "source_size", 0),
        output_bytes=getattr(result, "output_size", 0),
        seconds=getattr(result, "total_seconds", 0.0),
        search_seconds=getattr(result, "search_seconds", 0.0),
        quality=getattr(getattr(result, "quality", None), "composite", None),
        candidates=len(getattr(result, "candidates", []) or []),
        quality_met=getattr(result, "quality_met", True),
        target_met=getattr(result, "target_met", None),
        floor_reason=reason,
        vmaf_estimated=getattr(getattr(result, "quality", None), "vmaf", None) is None,
    )
