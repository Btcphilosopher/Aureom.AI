"""Metrics and economics.

The question this package answers is not "is the fleet busy" but "is the fleet
doing something worth the money".
"""

from __future__ import annotations

from hypercompress.analytics.cost import CostBreakdown, FleetCostReport, preset_economics
from hypercompress.analytics.metrics import METRICS, Metrics, record_optimisation

__all__ = [
    "METRICS",
    "CostBreakdown",
    "FleetCostReport",
    "Metrics",
    "preset_economics",
    "record_optimisation",
]
