"""Cloud economics (Phase 17).

Compression is an investment: compute is spent once, storage and egress are
saved every month thereafter. Whether that is a good trade depends on numbers
this module makes explicit rather than assumed.

The central quantity is the **break-even point** — how long the optimised copy
must be retained before the storage saved pays back the compute spent. For a
film watched monthly by thousands, egress alone pays it back in days. For a
surveillance archive nobody ever reads, an expensive AV1 encode may never pay
back at all, and the honest recommendation is a cheaper preset or no re-encode.

Two conclusions fall out of this that contradict the instinct to always
compress harder:

* **Slow presets are often uneconomic.** AV1 preset 2 might beat preset 8 by 6%
  on size while costing eight times the compute. On a 36-month retention that
  can still win; on a 6-month retention it does not.
* **Cold data should be compressed cheaply, or not at all.** Archive tiers cost
  a tenth of standard storage, which divides the value of every byte saved by
  ten while leaving the compute cost untouched.

Every figure here is a projection from the configured price list, not a
measurement. The report says so.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from hypercompress.config import CostModel
from hypercompress.core.types import ResourceUsage
from hypercompress.core.units import format_duration, format_size

#: Seconds in an average month, used for storage cost arithmetic.
MONTH_SECONDS = 30.44 * 24 * 3600
GIB = 1024**3
GB = 1000**3


@dataclass(slots=True)
class CostBreakdown:
    """What one optimisation cost and what it will save."""

    source_bytes: int
    output_bytes: int
    usage: ResourceUsage
    model: CostModel
    monthly_egress_multiple: float | None = None
    """How many times the object is downloaded per month, on average.

    ``None`` falls back to the fleet-wide figure in the cost model. Egress is
    frequently the larger half of the saving, so leaving it at zero understates
    the value of compression for anything anyone actually watches.
    """

    # -- compute -------------------------------------------------------------------
    @property
    def cpu_cost(self) -> float:
        return (self.usage.cpu_seconds / 3600.0) * self.model.cpu_price_per_core_hour

    @property
    def gpu_cost(self) -> float:
        return (self.usage.gpu_seconds / 3600.0) * self.model.gpu_price_per_hour

    @property
    def energy_kwh(self) -> float:
        """Energy drawn, including datacentre overhead.

        Derived from CPU time and the configured per-core draw rather than
        measured at the wall, so it is an estimate — but a defensible one, and
        the only carbon figure available without instrumented hardware.
        """
        core_hours = self.usage.cpu_seconds / 3600.0
        return core_hours * self.model.cpu_watts_per_core / 1000.0 * self.model.pue

    @property
    def energy_cost(self) -> float:
        return self.energy_kwh * self.model.electricity_price_per_kwh

    @property
    def carbon_kg(self) -> float:
        return self.energy_kwh * self.model.carbon_kg_per_kwh

    @property
    def compute_cost(self) -> float:
        return self.cpu_cost + self.gpu_cost + self.energy_cost

    # -- storage -------------------------------------------------------------------
    @property
    def bytes_saved(self) -> int:
        return self.source_bytes - self.output_bytes

    @property
    def gb_saved(self) -> float:
        return self.bytes_saved / GB

    @property
    def monthly_storage_saving(self) -> float:
        return self.gb_saved * self.model.storage_price_per_gb_month

    @property
    def egress_multiple(self) -> float:
        if self.monthly_egress_multiple is not None:
            return self.monthly_egress_multiple
        return self.model.monthly_egress_multiplier

    @property
    def monthly_egress_saving(self) -> float:
        return self.gb_saved * self.model.egress_price_per_gb * self.egress_multiple

    @property
    def monthly_saving(self) -> float:
        return self.monthly_storage_saving + self.monthly_egress_saving

    # -- the verdict ---------------------------------------------------------------
    @property
    def break_even_months(self) -> float | None:
        """Months of retention before the encode pays for itself.

        ``None`` when it never does — either nothing was saved, or the file grew.
        """
        if self.monthly_saving <= 0:
            return None
        return self.compute_cost / self.monthly_saving

    @property
    def retention_saving(self) -> float:
        return self.monthly_saving * self.model.retention_months

    @property
    def net_benefit(self) -> float:
        return self.retention_saving - self.compute_cost

    @property
    def worthwhile(self) -> bool:
        return self.net_benefit > 0

    @property
    def roi(self) -> float | None:
        if self.compute_cost <= 0:
            return None
        return self.net_benefit / self.compute_cost

    def verdict(self) -> str:
        """A sentence an operator can act on."""
        if self.bytes_saved <= 0:
            return (
                "This encode made the file larger. The compute was spent for nothing and the "
                "original should be kept."
            )
        break_even = self.break_even_months
        if break_even is None:
            return "Nothing is saved by retaining this output."
        if not self.worthwhile:
            return (
                f"This encode does not pay for itself: it breaks even after "
                f"{break_even:.1f} months but the configured retention is only "
                f"{self.model.retention_months} months. A faster preset, or leaving the "
                f"source alone, would cost less overall."
            )
        return (
            f"Breaks even after {break_even:.1f} months and saves "
            f"${self.net_benefit:.4f} net over {self.model.retention_months} months "
            f"({format_size(self.bytes_saved)} reclaimed)."
        )

    def as_dict(self) -> dict[str, object]:
        return {
            "source_bytes": self.source_bytes,
            "output_bytes": self.output_bytes,
            "bytes_saved": self.bytes_saved,
            "compute": {
                "cpu_seconds": round(self.usage.cpu_seconds, 2),
                "gpu_seconds": round(self.usage.gpu_seconds, 2),
                "cpu_cost": round(self.cpu_cost, 6),
                "gpu_cost": round(self.gpu_cost, 6),
                "energy_kwh": round(self.energy_kwh, 6),
                "energy_cost": round(self.energy_cost, 6),
                "carbon_kg": round(self.carbon_kg, 6),
                "total": round(self.compute_cost, 6),
            },
            "savings": {
                "monthly_storage": round(self.monthly_storage_saving, 6),
                "monthly_egress": round(self.monthly_egress_saving, 6),
                "monthly_total": round(self.monthly_saving, 6),
                "over_retention": round(self.retention_saving, 6),
            },
            "break_even_months": None
            if self.break_even_months is None
            else round(self.break_even_months, 2),
            "net_benefit": round(self.net_benefit, 6),
            "roi": None if self.roi is None else round(self.roi, 3),
            "worthwhile": self.worthwhile,
            "verdict": self.verdict(),
            "basis": "projection from the configured price list, not a measured invoice",
        }


@dataclass(slots=True)
class FleetCostReport:
    """Aggregate economics across a batch or a whole library."""

    model: CostModel
    items: list[CostBreakdown] = field(default_factory=list)

    def add(self, breakdown: CostBreakdown) -> None:
        self.items.append(breakdown)

    @property
    def files(self) -> int:
        return len(self.items)

    @property
    def source_bytes(self) -> int:
        return sum(i.source_bytes for i in self.items)

    @property
    def output_bytes(self) -> int:
        return sum(i.output_bytes for i in self.items)

    @property
    def bytes_saved(self) -> int:
        return self.source_bytes - self.output_bytes

    @property
    def compute_cost(self) -> float:
        return sum(i.compute_cost for i in self.items)

    @property
    def monthly_saving(self) -> float:
        return sum(i.monthly_saving for i in self.items)

    @property
    def net_benefit(self) -> float:
        return sum(i.net_benefit for i in self.items)

    @property
    def carbon_kg(self) -> float:
        return sum(i.carbon_kg for i in self.items)

    @property
    def uneconomic(self) -> list[CostBreakdown]:
        """The files that cost more to compress than they will ever save."""
        return [i for i in self.items if not i.worthwhile]

    def summary(self) -> str:
        if not self.items:
            return "no files processed"
        reduction = self.bytes_saved / self.source_bytes if self.source_bytes else 0.0
        line = (
            f"{self.files} files: {format_size(self.source_bytes)} -> "
            f"{format_size(self.output_bytes)} ({reduction:.1%} smaller). "
            f"Compute ${self.compute_cost:.2f}, saving ${self.monthly_saving:.2f}/month, "
            f"net ${self.net_benefit:.2f} over {self.model.retention_months} months."
        )
        if self.uneconomic:
            line += (
                f" {len(self.uneconomic)} file(s) will not pay back their compute — "
                f"consider a faster preset for that material."
            )
        return line

    def as_dict(self) -> dict[str, object]:
        return {
            "files": self.files,
            "source_bytes": self.source_bytes,
            "output_bytes": self.output_bytes,
            "bytes_saved": self.bytes_saved,
            "compute_cost": round(self.compute_cost, 4),
            "monthly_saving": round(self.monthly_saving, 4),
            "net_benefit": round(self.net_benefit, 4),
            "carbon_kg": round(self.carbon_kg, 4),
            "uneconomic_files": len(self.uneconomic),
            "summary": self.summary(),
        }


def preset_economics(
    model: CostModel,
    *,
    bytes_saved_fast: int,
    cpu_seconds_fast: float,
    bytes_saved_slow: int,
    cpu_seconds_slow: float,
) -> str:
    """Compare two presets on total cost of ownership, not on size alone.

    This is the calculation that decides whether a slower preset is worth it,
    and it is the one most often skipped: a preset that wins on size can still
    lose on money.
    """

    def total(saved: int, cpu: float) -> float:
        compute = (cpu / 3600.0) * model.cpu_price_per_core_hour
        saving = (saved / GB) * model.storage_price_per_gb_month * model.retention_months
        return saving - compute

    fast = total(bytes_saved_fast, cpu_seconds_fast)
    slow = total(bytes_saved_slow, cpu_seconds_slow)
    extra_bytes = bytes_saved_slow - bytes_saved_fast
    extra_cpu = cpu_seconds_slow - cpu_seconds_fast

    if slow > fast:
        return (
            f"The slower preset is worth it: {format_size(extra_bytes)} more saved for "
            f"{format_duration(extra_cpu)} more CPU, ${slow - fast:.4f} better over "
            f"{model.retention_months} months."
        )
    return (
        f"The slower preset is not worth it here: {format_size(extra_bytes)} more saved costs "
        f"{format_duration(extra_cpu)} more CPU, leaving it ${fast - slow:.4f} worse over "
        f"{model.retention_months} months. Use the faster preset."
    )
