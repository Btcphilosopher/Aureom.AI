"""Structured JSON logging with job/worker/tenant context.

Every log record carries the contextual identifiers of the work in flight, which
is what makes a hyperscale fleet debuggable: one query over the log stream
reconstructs the full history of a single job across every worker that touched it.
"""

from __future__ import annotations

import contextvars
import json
import logging
import sys
import time
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from pathlib import Path
from typing import Any

#: Contextual fields merged into every log record.
#:
#: The default is ``None`` rather than ``{}`` because a mutable default on a
#: ContextVar is a single object shared by every context that never called
#: ``set``. Nothing here mutates it today — :func:`log_context` copies before
#: updating — but the failure mode if anyone ever does is one worker's job_id
#: appearing in another's logs, which is both confusing and, across tenants, a
#: disclosure.
_context: contextvars.ContextVar[dict[str, Any] | None] = contextvars.ContextVar(
    "hypercompress_log_context", default=None
)


def _current() -> dict[str, Any]:
    return _context.get() or {}


_RESERVED = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {
    "message",
    "asctime",
    "taskName",
}


class JsonFormatter(logging.Formatter):
    """One JSON object per line, with contextual fields merged in."""

    def __init__(self, service: str = "hypercompress-media") -> None:
        super().__init__()
        self.service = service

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created))
            + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "service": self.service,
            "message": record.getMessage(),
        }
        payload.update(_current())
        for key, value in record.__dict__.items():
            if key not in _RESERVED and not key.startswith("_"):
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, separators=(",", ":"))


class HumanFormatter(logging.Formatter):
    """Compact console format for interactive CLI use."""

    def format(self, record: logging.LogRecord) -> str:
        ctx = _current()
        prefix = f"[{ctx['job_id'][:8]}] " if ctx.get("job_id") else ""
        stamp = time.strftime("%H:%M:%S", time.localtime(record.created))
        return f"{stamp} {record.levelname[0]} {prefix}{record.getMessage()}"


def configure_logging(
    level: str = "INFO",
    json_logs: bool = True,
    log_file: Path | None = None,
    service: str = "hypercompress-media",
) -> None:
    """Install the platform's root handlers. Safe to call repeatedly."""
    root = logging.getLogger("hypercompress")
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.handlers.clear()
    root.propagate = False

    formatter: logging.Formatter = JsonFormatter(service) if json_logs else HumanFormatter()
    stream = logging.StreamHandler(sys.stderr)
    stream.setFormatter(formatter)
    root.addHandler(stream)

    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(JsonFormatter(service))
        root.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger below the ``hypercompress`` root."""
    return logging.getLogger(name if name.startswith("hypercompress") else f"hypercompress.{name}")


@contextmanager
def log_context(**fields: Any) -> Iterator[None]:
    """Bind contextual fields (job_id, tenant, worker, phase) for the duration."""
    current = dict(_current())
    current.update({k: v for k, v in fields.items() if v is not None})
    token = _context.set(current)
    try:
        yield
    finally:
        _context.reset(token)


def current_context() -> Mapping[str, Any]:
    return dict(_current())


class AuditLog:
    """Append-only JSONL audit trail for security-relevant events."""

    def __init__(self, path: Path | None) -> None:
        self.path = path
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, action: str, principal: str, tenant: str, **details: Any) -> dict[str, Any]:
        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "action": action,
            "principal": principal,
            "tenant": tenant,
            **details,
        }
        if self.path is not None:
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(entry, default=str) + "\n")
        get_logger("audit").info("audit", extra={"audit": entry})
        return entry
