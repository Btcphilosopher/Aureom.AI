"""Typed, injection-proof FFmpeg/ffprobe access layer.

Two rules govern this module:

1. **No raw arguments.** Callers never hand us a command string. They hand us
   typed values, and :class:`ArgBuilder` emits tokens only after validating both
   the flag (against an allowlist) and the value (against a type/pattern).
2. **Everything is measured.** Every invocation returns CPU seconds, peak RSS
   and wall time so the cost model and scheduler work from observation rather
   than guesswork.
"""

from __future__ import annotations

import json
import math
import re
import shutil
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Final

from hypercompress.core.errors import (
    CodecUnavailableError,
    EncodeError,
    EncodeTimeout,
    ProbeError,
    UnsafeArgumentError,
)
from hypercompress.core.process import CommandResult, run_process

# --------------------------------------------------------------------------------------
# Argument safety
# --------------------------------------------------------------------------------------

#: Every FFmpeg flag the platform is permitted to emit. Anything else raises.
ALLOWED_FLAGS: Final[frozenset[str]] = frozenset(
    {
        # global
        "-hide_banner",
        "-nostdin",
        "-y",
        "-n",
        "-loglevel",
        "-nostats",
        "-progress",
        "-threads",
        "-filter_threads",
        "-stats_period",
        "-benchmark",
        "-fflags",
        "-max_muxing_queue_size",
        "-hwaccel",
        "-hwaccel_device",
        "-hwaccel_output_format",
        "-init_hw_device",
        "-filter_hw_device",
        # input / output
        "-i",
        "-f",
        "-ss",
        "-t",
        "-to",
        "-map",
        "-map_metadata",
        "-map_chapters",
        "-shortest",
        "-r",
        "-s",
        "-pix_fmt",
        "-sn",
        "-an",
        "-vn",
        "-dn",
        "-copyts",
        "-avoid_negative_ts",
        "-movflags",
        "-frames:v",
        "-frames:a",
        # video
        "-c:v",
        "-b:v",
        "-maxrate",
        "-minrate",
        "-bufsize",
        "-crf",
        "-cq",
        "-qp",
        "-preset",
        "-tune",
        "-profile:v",
        "-level",
        "-g",
        "-keyint_min",
        "-sc_threshold",
        "-bf",
        "-refs",
        "-pass",
        "-passlogfile",
        "-x264-params",
        "-x265-params",
        "-svtav1-params",
        "-aom-params",
        "-cpu-used",
        "-row-mt",
        "-tile-columns",
        "-tile-rows",
        "-tiles",
        "-lag-in-frames",
        "-deadline",
        "-quality",
        "-rc",
        "-color_primaries",
        "-color_trc",
        "-colorspace",
        "-color_range",
        "-lavfi",
        "-master_display",
        "-max_cll",
        "-vf",
        "-vsync",
        "-fps_mode",
        "-video_track_timescale",
        "-film_grain",
        "-enable-overlays",
        "-b_ref_mode",
        # audio
        "-c:a",
        "-b:a",
        "-ar",
        "-ac",
        "-channel_layout",
        "-af",
        "-vbr",
        "-compression_level",
        "-application",
        "-cutoff",
        "-frame_duration",
        "-q:a",
        "-aac_coder",
        "-sample_fmt",
        # subtitles / attachments
        "-c:s",
        "-c:t",
        "-disposition:s:0",
        # metadata
        "-metadata",
        "-map_metadata:g",
        "-write_id3v2",
        # ffprobe
        "-v",
        "-print_format",
        "-show_format",
        "-show_streams",
        "-show_chapters",
        "-show_entries",
        "-show_frames",
        "-select_streams",
        "-read_intervals",
        "-count_frames",
        "-count_packets",
        "-of",
    }
)

#: Characters that may appear in a value token. Deliberately excludes shell
#: metacharacters even though we never invoke a shell — defence in depth.
#:
#: The pipe is excluded for a reason specific to FFmpeg rather than to shells:
#: ``-f tee|http://host/path`` makes the ``tee`` muxer write to a network
#: destination, so an unvalidated pipe in a value is an exfiltration primitive
#: even when no shell is ever involved.
_VALUE_RE: Final = re.compile(r"^[A-Za-z0-9_@%+=:,./^~\[\]{}()*?!'\"\\ -]*$")

_FILTER_NAME_RE: Final = re.compile(r"^[a-z0-9_]+$")

#: Filters that read or write outside the graph. FFmpeg's filter set is not
#: uniformly side-effect free: ``movie`` and ``amovie`` open an arbitrary path
#: or protocol and splice it into the graph, which is a file-read and
#: network-fetch primitive wearing the costume of a video filter. Nothing this
#: platform does needs them, so they are refused by name.
FORBIDDEN_FILTERS: Final[frozenset[str]] = frozenset(
    {
        "movie",
        "amovie",
        "concat",
        "sendcmd",
        "asendcmd",
        "zmq",
        "azmq",
        "frei0r",
        "frei0r_src",
        "ladspa",
        "lv2",
    }
)


class ArgBuilder:
    """Accumulates validated FFmpeg tokens.

    >>> ArgBuilder().flag("-y").opt("-c:v", "libx264").opt("-crf", 23).build()[-2:]
    ['-crf', '23']
    """

    __slots__ = ("_tokens",)

    def __init__(self, tokens: Iterable[str] | None = None) -> None:
        self._tokens: list[str] = []
        for tok in tokens or ():
            self._tokens.append(self._check_token(tok))

    # -- primitives ---------------------------------------------------------------
    @staticmethod
    def _check_flag(flag: str) -> str:
        base = flag.split(":", 1)[0] if flag.count(":") > 1 else flag
        if flag not in ALLOWED_FLAGS and base not in ALLOWED_FLAGS:
            raise UnsafeArgumentError(f"flag not permitted by security policy: {flag!r}")
        return flag

    @staticmethod
    def _check_token(value: Any) -> str:
        text = str(value)
        if "\x00" in text or "\n" in text:
            raise UnsafeArgumentError("argument contains a control character")
        if not _VALUE_RE.match(text):
            raise UnsafeArgumentError(f"argument contains forbidden characters: {text!r}")
        return text

    # -- fluent API ---------------------------------------------------------------
    def flag(self, flag: str) -> ArgBuilder:
        self._tokens.append(self._check_flag(flag))
        return self

    def opt(self, flag: str, value: Any) -> ArgBuilder:
        if value is None:
            return self
        self._tokens.append(self._check_flag(flag))
        self._tokens.append(self._check_token(value))
        return self

    def opt_if(self, condition: bool, flag: str, value: Any) -> ArgBuilder:
        return self.opt(flag, value) if condition else self

    def path(self, flag: str | None, value: str | Path) -> ArgBuilder:
        """Add a filesystem path. Paths bypass the character allowlist but are
        still checked for control characters and are never shell-interpreted."""
        text = str(value)
        if "\x00" in text or "\n" in text:
            raise UnsafeArgumentError("path contains a control character")
        if flag is not None:
            self._tokens.append(self._check_flag(flag))
        self._tokens.append(text)
        return self

    def raw_reject(self, _: str) -> None:
        """Explicitly refuse caller-supplied raw argument strings."""
        raise UnsafeArgumentError(
            "raw FFmpeg arguments are never accepted; build a typed EncodePlan instead"
        )

    def extend(self, other: ArgBuilder) -> ArgBuilder:
        self._tokens.extend(other._tokens)
        return self

    def build(self) -> list[str]:
        return list(self._tokens)

    def _adopt(self, tokens: list[str]) -> ArgBuilder:
        """Internal: take ownership of an already-validated token list.

        Used only by the quality module, which builds ``-lavfi`` graphs from
        constants rather than from caller input.
        """
        self._tokens = list(tokens)
        return self

    def __len__(self) -> int:
        return len(self._tokens)

    def __repr__(self) -> str:
        return f"ArgBuilder({self._tokens!r})"


def build_filter_chain(filters: Sequence[tuple[str, dict[str, Any]] | str]) -> str:
    """Compose a validated filtergraph string.

    Filter names must match ``[a-z0-9_]+``, must not appear in
    :data:`FORBIDDEN_FILTERS`, and parameter values are stringified and checked,
    so a malicious 'filter' cannot smuggle in ``,`` or ``;`` to append extra
    graph nodes.
    """
    parts: list[str] = []
    for item in filters:
        if isinstance(item, str):
            name, params = item, {}
        else:
            name, params = item
        if name in FORBIDDEN_FILTERS:
            raise UnsafeArgumentError(
                f"the {name!r} filter can read paths or protocols from inside a filtergraph "
                f"and is not permitted"
            )
        if not _FILTER_NAME_RE.match(name):
            raise UnsafeArgumentError(f"illegal filter name: {name!r}")
        if not params:
            parts.append(name)
            continue
        rendered = []
        for key, value in params.items():
            if not _FILTER_NAME_RE.match(key):
                raise UnsafeArgumentError(f"illegal filter parameter: {key!r}")
            text = str(value)
            if re.search(r"[;,\[\]'\"\\\s]", text):
                raise UnsafeArgumentError(f"illegal filter value: {text!r}")
            rendered.append(f"{key}={text}")
        parts.append(f"{name}=" + ":".join(rendered))
    return ",".join(parts)


def build_window_select_graph(
    windows: Sequence[tuple[float, float]],
    filters: Sequence[tuple[str, dict[str, Any]] | str] = (),
    *,
    audio: bool = False,
) -> str:
    """Build a ``select``/``aselect`` graph that keeps only the given time windows.

    A select expression legitimately contains commas, which :func:`build_filter_chain`
    refuses because a comma is how a filtergraph separates nodes. Rather than
    weakening that rule, this function constructs the expression itself from
    floats — no caller-supplied string ever reaches the graph — and wraps it in
    the single quotes FFmpeg uses to protect an option value.
    """
    if not windows:
        raise ValueError("at least one window is required")
    clauses: list[str] = []
    for start, end in windows:
        s, e = float(start), float(end)
        if not (math.isfinite(s) and math.isfinite(e)):
            raise UnsafeArgumentError("window bounds must be finite")
        if s < 0 or e <= s:
            raise UnsafeArgumentError(f"invalid sample window ({s}, {e})")
        clauses.append(f"between(t,{s:.3f},{e:.3f})")
    expr = "+".join(clauses)
    select = "aselect" if audio else "select"
    reset = "asetpts=N/SR/TB" if audio else "setpts=N/FRAME_RATE/TB"
    graph = f"{select}='{expr}',{reset}"
    tail = build_filter_chain(filters) if filters else ""
    return f"{graph},{tail}" if tail else graph


# --------------------------------------------------------------------------------------
# Capabilities
# --------------------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class FFmpegCapabilities:
    """What the locally installed FFmpeg build can actually do."""

    ffmpeg_path: str
    ffprobe_path: str
    version: str
    encoders: frozenset[str] = field(default_factory=frozenset)
    decoders: frozenset[str] = field(default_factory=frozenset)
    filters: frozenset[str] = field(default_factory=frozenset)
    hwaccels: frozenset[str] = field(default_factory=frozenset)
    muxers: frozenset[str] = field(default_factory=frozenset)

    def has_encoder(self, name: str) -> bool:
        return name in self.encoders

    def first_encoder(self, *names: str) -> str | None:
        for name in names:
            if name in self.encoders:
                return name
        return None

    def has_filter(self, name: str) -> bool:
        return name in self.filters

    @property
    def has_vmaf(self) -> bool:
        return "libvmaf" in self.filters

    @property
    def major_version(self) -> int:
        match = re.search(r"(\d+)", self.version)
        return int(match.group(1)) if match else 0


@lru_cache(maxsize=4)
def detect_capabilities(ffmpeg: str = "ffmpeg", ffprobe: str = "ffprobe") -> FFmpegCapabilities:
    """Probe the local FFmpeg build once and cache the answer."""
    ffmpeg_path = shutil.which(ffmpeg)
    ffprobe_path = shutil.which(ffprobe)
    if not ffmpeg_path or not ffprobe_path:
        raise CodecUnavailableError(
            "ffmpeg and ffprobe must be installed and on PATH for HYPERCOMPRESS MEDIA"
        )

    def _listing(kind: str, pattern: str) -> frozenset[str]:
        result = run_process([ffmpeg_path, "-hide_banner", f"-{kind}"], timeout=60)
        names: set[str] = set()
        for line in result.stdout.splitlines() + result.stderr.splitlines():
            match = re.match(pattern, line)
            if match:
                names.add(match.group(1))
        return frozenset(names)

    version_out = run_process([ffmpeg_path, "-version"], timeout=30).stdout
    version = (
        version_out.splitlines()[0].replace("ffmpeg version ", "") if version_out else "unknown"
    )

    hw = run_process([ffmpeg_path, "-hide_banner", "-hwaccels"], timeout=30)
    hwaccels = {
        line.strip()
        for line in (hw.stdout + hw.stderr).splitlines()[1:]
        if line.strip() and " " not in line.strip()
    }

    return FFmpegCapabilities(
        ffmpeg_path=ffmpeg_path,
        ffprobe_path=ffprobe_path,
        version=version,
        encoders=_listing("encoders", r"^\s*[VAS][\w.]{5}\s+(\S+)"),
        decoders=_listing("decoders", r"^\s*[VAS][\w.]{5}\s+(\S+)"),
        filters=_listing("filters", r"^\s*[TSC.]{3}\s+(\S+)"),
        muxers=_listing("muxers", r"^\s*[DE ]{2}\s+(\S+)"),
        hwaccels=frozenset(hwaccels),
    )


# --------------------------------------------------------------------------------------
# Runner
# --------------------------------------------------------------------------------------


@dataclass(slots=True)
class EncodeProgress:
    """Live progress emitted by ``-progress pipe:2``."""

    frame: int = 0
    fps: float = 0.0
    out_time_us: int = 0
    total_size: int = 0
    speed: float = 0.0
    bitrate: float = 0.0
    progress: str = "continue"

    @property
    def out_time_s(self) -> float:
        return self.out_time_us / 1e6

    def fraction(self, duration: float) -> float:
        if duration <= 0:
            return 0.0
        return min(1.0, self.out_time_s / duration)


ProgressCallback = Callable[[EncodeProgress], None]

_PROGRESS_KEYS = {
    "frame": ("frame", int),
    "fps": ("fps", float),
    "out_time_us": ("out_time_us", int),
    "total_size": ("total_size", int),
    "speed": ("speed", str),
    "bitrate": ("bitrate", str),
    "progress": ("progress", str),
}


class FFmpegRunner:
    """The single choke point through which FFmpeg is invoked."""

    def __init__(
        self,
        capabilities: FFmpegCapabilities | None = None,
        *,
        default_timeout: float | None = None,
        nice: int = 0,
    ) -> None:
        self.capabilities = capabilities or detect_capabilities()
        self.default_timeout = default_timeout
        self.nice = nice

    # -- probing ------------------------------------------------------------------
    def probe(
        self, path: str | Path, *, count_frames: bool = False, timeout: float = 120
    ) -> dict[str, Any]:
        """Run ffprobe and return parsed JSON, raising :class:`ProbeError` on failure."""
        args = (
            ArgBuilder()
            .opt("-v", "error")
            .opt("-print_format", "json")
            .flag("-show_format")
            .flag("-show_streams")
            .flag("-show_chapters")
        )
        if count_frames:
            args.flag("-count_frames")
        args.path(None, path)
        result = run_process([self.capabilities.ffprobe_path, *args.build()], timeout=timeout)
        if not result.ok:
            raise ProbeError(f"ffprobe failed for {path}: {result.tail()}")
        try:
            return dict(json.loads(result.stdout))
        except json.JSONDecodeError as exc:  # pragma: no cover - defensive
            raise ProbeError(f"ffprobe produced invalid JSON for {path}") from exc

    def probe_frames(
        self,
        path: str | Path,
        *,
        entries: str,
        select: str = "v:0",
        read_intervals: str | None = None,
        timeout: float = 300,
    ) -> list[dict[str, Any]]:
        """Frame-level probe used by scene detection and complexity analysis."""
        args = (
            ArgBuilder()
            .opt("-v", "error")
            .opt("-print_format", "json")
            .opt("-select_streams", select)
            .opt("-show_entries", entries)
        )
        if read_intervals:
            args.opt("-read_intervals", read_intervals)
        args.path(None, path)
        result = run_process([self.capabilities.ffprobe_path, *args.build()], timeout=timeout)
        if not result.ok:
            raise ProbeError(f"ffprobe frame analysis failed: {result.tail()}")
        payload = json.loads(result.stdout or "{}")
        return list(payload.get("frames", []))

    # -- execution ----------------------------------------------------------------
    def run(
        self,
        args: ArgBuilder | Sequence[str],
        *,
        timeout: float | None = None,
        duration_hint: float = 0.0,
        on_progress: ProgressCallback | None = None,
        check: bool = True,
    ) -> CommandResult:
        """Execute FFmpeg with validated arguments and live progress."""
        tokens = args.build() if isinstance(args, ArgBuilder) else [str(a) for a in args]
        argv = [self.capabilities.ffmpeg_path, "-hide_banner", "-nostdin", *tokens]
        if self.nice:
            argv = ["nice", "-n", str(self.nice), *argv]

        progress = EncodeProgress()
        callback = None
        if on_progress is not None:

            def callback(line: str) -> None:  # noqa: ANN202 - local closure
                if "=" not in line:
                    return
                key, _, value = line.partition("=")
                key = key.strip()
                spec = _PROGRESS_KEYS.get(key)
                if spec is None:
                    return
                attr, caster = spec
                try:
                    if caster is str and attr in {"speed", "bitrate"}:
                        cleaned = re.sub(r"[^0-9.eE+-]", "", value) or "0"
                        setattr(progress, attr, float(cleaned))
                    else:
                        setattr(progress, attr, caster(value.strip()))
                except (ValueError, TypeError):
                    return
                if key == "progress" or key == "out_time_us":
                    on_progress(progress)

        result = run_process(
            argv,
            timeout=timeout if timeout is not None else self.default_timeout,
            line_callback=callback,
        )
        if result.timed_out and check:
            raise EncodeTimeout(f"ffmpeg exceeded its budget: {result.command}")
        if check and not result.ok:
            raise EncodeError(f"ffmpeg failed (rc={result.returncode}):\n{result.tail()}")
        return result

    def encode(
        self,
        args: ArgBuilder,
        output: Path,
        *,
        timeout: float | None = None,
        duration_hint: float = 0.0,
        on_progress: ProgressCallback | None = None,
    ) -> CommandResult:
        """Run an encode that writes ``output``, verifying the file appeared."""
        output.parent.mkdir(parents=True, exist_ok=True)
        full = (
            ArgBuilder()
            .opt("-loglevel", "error")
            .flag("-nostats")
            .opt("-progress", "pipe:2")
            .flag("-y")
            .extend(args)
        )
        full.path(None, output)
        result = self.run(
            full,
            timeout=timeout,
            duration_hint=duration_hint,
            on_progress=on_progress,
        )
        if not output.exists() or output.stat().st_size == 0:
            raise EncodeError(f"encoder produced no output at {output}:\n{result.tail()}")
        return result

    # -- helpers ------------------------------------------------------------------
    def require_encoder(self, *names: str) -> str:
        encoder = self.capabilities.first_encoder(*names)
        if encoder is None:
            raise CodecUnavailableError(
                f"none of {names} are available in this FFmpeg build ({self.capabilities.version})"
            )
        return encoder

    def null_sink(self) -> list[str]:
        """The platform-appropriate discard target for measurement passes."""
        return ["-f", "null", "-"]

    # -- raw sample extraction ----------------------------------------------------
    def decode_raw(
        self,
        path: str | Path,
        *,
        args: ArgBuilder,
        timeout: float = 600.0,
        max_bytes: int = 512 * 1024 * 1024,
    ) -> bytes:
        """Decode to a raw byte stream on stdout (gray frames or PCM samples).

        Analysis needs pixels and samples, not files. This is the only place the
        platform reads binary from FFmpeg, and it caps the buffer so a bad
        interval specification cannot exhaust worker memory.
        """
        import subprocess  # local import keeps the module's public surface small

        argv = [
            self.capabilities.ffmpeg_path,
            "-hide_banner",
            "-nostdin",
            "-loglevel",
            "error",
            *args.build(),
        ]
        proc = subprocess.Popen(  # noqa: S603 - tokens validated by ArgBuilder
            argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        chunks: list[bytes] = []
        total = 0
        assert proc.stdout is not None
        try:
            while block := proc.stdout.read(1 << 20):
                total += len(block)
                if total > max_bytes:
                    _terminate(proc)
                    raise EncodeError("raw decode exceeded the memory cap")
                chunks.append(block)
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            _terminate(proc)
            raise EncodeTimeout(f"raw decode timed out for {path}") from exc
        stderr = proc.stderr.read().decode("utf-8", "ignore") if proc.stderr else ""
        if proc.returncode not in (0, None) and not chunks:
            raise EncodeError(f"raw decode failed for {path}: {stderr[-800:]}")
        return b"".join(chunks)


def _terminate(proc: Any) -> None:
    try:
        proc.kill()
        proc.wait(timeout=5)
    except Exception:  # noqa: BLE001 - best-effort cleanup
        pass
