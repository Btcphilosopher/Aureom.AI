"""Exception hierarchy for HYPERCOMPRESS MEDIA."""

from __future__ import annotations


class HyperCompressError(Exception):
    """Base class for every error raised by the platform."""

    exit_code: int = 1


class ConfigError(HyperCompressError):
    """Raised when configuration is internally inconsistent."""

    exit_code = 78


class ValidationError(HyperCompressError):
    """Raised when input or output fails validation."""

    exit_code = 65


class ProbeError(HyperCompressError):
    """Raised when ffprobe cannot describe a media file."""

    exit_code = 66


class UnsupportedMediaError(ProbeError):
    """Raised when a file is not recognised as processable media."""


class EncodeError(HyperCompressError):
    """Raised when an encoder invocation fails."""

    exit_code = 70


class EncodeTimeout(EncodeError):
    """Raised when an encoder exceeds its wall-clock budget."""


class CodecUnavailableError(HyperCompressError):
    """Raised when a requested codec is not present in the local FFmpeg build."""

    exit_code = 69


class QualityFloorViolation(HyperCompressError):
    """Raised when no candidate satisfies the configured quality floor."""

    exit_code = 75


class TargetUnreachable(HyperCompressError):
    """Raised when a target size cannot be met without breaching the quality floor."""

    exit_code = 75


class StorageError(HyperCompressError):
    """Raised when an object store operation fails."""

    exit_code = 74


class SchedulingError(HyperCompressError):
    """Raised for queue/scheduler faults."""

    exit_code = 73


class SecurityError(HyperCompressError):
    """Raised when an operation violates the security policy."""

    exit_code = 77


class UnsafeArgumentError(SecurityError):
    """Raised when a caller attempts to inject raw encoder arguments."""


class AuthorizationError(SecurityError):
    """Raised when a principal lacks the required role or tenant scope."""

    exit_code = 77


class QuotaExceeded(SecurityError):
    """Raised when a tenant exceeds a configured resource quota."""

    exit_code = 77
