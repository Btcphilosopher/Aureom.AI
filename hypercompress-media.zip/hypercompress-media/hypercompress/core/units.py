"""Byte / duration / bitrate value objects and human-readable parsing.

Every size in the platform is an explicit integer number of bytes. Strings such as
``"1GB"``, ``"1.5 GiB"`` or ``"800M"`` only exist at the boundary (CLI/API) and are
converted immediately.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Final

_SIZE_RE: Final = re.compile(
    r"^\s*(?P<value>[0-9]*\.?[0-9]+)\s*(?P<unit>[kKmMgGtTpPeE]?)(?P<binary>[iI]?)[bB]?\s*$"
)

_DECIMAL: Final[dict[str, int]] = {
    "": 1,
    "k": 10**3,
    "m": 10**6,
    "g": 10**9,
    "t": 10**12,
    "p": 10**15,
    "e": 10**18,
}
_BINARY: Final[dict[str, int]] = {
    "": 1,
    "k": 2**10,
    "m": 2**20,
    "g": 2**30,
    "t": 2**40,
    "p": 2**50,
    "e": 2**60,
}

_DURATION_RE: Final = re.compile(r"^\s*(?:(?P<h>\d+):)?(?:(?P<m>\d+):)?(?P<s>\d+(?:\.\d+)?)\s*$")


def parse_size(text: str | int | float) -> int:
    """Parse ``"1.5GB"`` / ``"700MiB"`` / ``1024`` into a byte count.

    Decimal prefixes (kB, MB, GB) are powers of 1000; an ``i`` (KiB, MiB, GiB)
    selects powers of 1024, matching IEC 80000-13.
    """
    if isinstance(text, (int, float)):
        if text < 0:
            raise ValueError("size must be non-negative")
        return int(text)
    match = _SIZE_RE.match(text)
    if match is None:
        raise ValueError(f"cannot parse size: {text!r}")
    value = float(match.group("value"))
    unit = match.group("unit").lower()
    table = _BINARY if match.group("binary") else _DECIMAL
    return int(round(value * table[unit]))


def parse_duration(text: str | int | float) -> float:
    """Parse ``"01:23:45.5"``, ``"90"`` or ``90.0`` into seconds."""
    if isinstance(text, (int, float)):
        return float(text)
    match = _DURATION_RE.match(text)
    if match is None:
        raise ValueError(f"cannot parse duration: {text!r}")
    hours = float(match.group("h") or 0)
    minutes = float(match.group("m") or 0)
    seconds = float(match.group("s"))
    if match.group("h") is None and match.group("m") is not None:
        hours, minutes = 0.0, minutes
    return hours * 3600 + minutes * 60 + seconds


def format_size(num_bytes: float, binary: bool = False) -> str:
    """Render a byte count for humans, e.g. ``8.40 GB``."""
    if num_bytes < 0:
        return "-" + format_size(-num_bytes, binary)
    base = 1024.0 if binary else 1000.0
    units = (
        ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB"]
        if binary
        else ["B", "kB", "MB", "GB", "TB", "PB", "EB"]
    )
    if num_bytes < base:
        return f"{int(num_bytes)} B"
    exponent = min(int(math.log(num_bytes, base)), len(units) - 1)
    return f"{num_bytes / base**exponent:.2f} {units[exponent]}"


def format_duration(seconds: float) -> str:
    """Render seconds as ``HH:MM:SS.mmm``."""
    if seconds < 0:
        return "-" + format_duration(-seconds)
    hours, rem = divmod(seconds, 3600.0)
    minutes, secs = divmod(rem, 60.0)
    return f"{int(hours):02d}:{int(minutes):02d}:{secs:06.3f}"


def format_bitrate(bits_per_second: float) -> str:
    """Render a bitrate as ``4.50 Mbps``."""
    for unit, scale in (("Gbps", 1e9), ("Mbps", 1e6), ("kbps", 1e3)):
        if bits_per_second >= scale:
            return f"{bits_per_second / scale:.2f} {unit}"
    return f"{bits_per_second:.0f} bps"


@dataclass(frozen=True, slots=True, order=True)
class ByteSize:
    """An immutable byte count that knows how to print itself."""

    value: int

    def __post_init__(self) -> None:
        if self.value < 0:
            raise ValueError("ByteSize must be non-negative")

    @classmethod
    def parse(cls, text: str | int | float) -> ByteSize:
        return cls(parse_size(text))

    @property
    def megabytes(self) -> float:
        return self.value / 1e6

    @property
    def gigabytes(self) -> float:
        return self.value / 1e9

    @property
    def terabytes(self) -> float:
        return self.value / 1e12

    def ratio_to(self, other: ByteSize | int) -> float:
        divisor = other.value if isinstance(other, ByteSize) else other
        if divisor == 0:
            return math.inf
        return self.value / divisor

    def __int__(self) -> int:
        return self.value

    def __str__(self) -> str:
        return format_size(self.value)

    def __add__(self, other: ByteSize | int) -> ByteSize:
        return ByteSize(self.value + int(other))

    def __sub__(self, other: ByteSize | int) -> ByteSize:
        return ByteSize(max(0, self.value - int(other)))


@dataclass(frozen=True, slots=True, order=True)
class Duration:
    """An immutable duration in seconds."""

    seconds: float

    @classmethod
    def parse(cls, text: str | int | float) -> Duration:
        return cls(parse_duration(text))

    @property
    def minutes(self) -> float:
        return self.seconds / 60.0

    @property
    def hours(self) -> float:
        return self.seconds / 3600.0

    def __float__(self) -> float:
        return self.seconds

    def __str__(self) -> str:
        return format_duration(self.seconds)


def bitrate_for_target(target_bytes: int, duration_s: float, overhead: float = 0.985) -> float:
    """Bits per second that fills ``target_bytes`` over ``duration_s``.

    ``overhead`` reserves container/muxing overhead (MP4/MKV headers, index,
    interleaving padding) so the muxed file lands under the requested target.
    """
    if duration_s <= 0:
        raise ValueError("duration must be positive")
    return (target_bytes * 8 * overhead) / duration_s


def size_for_bitrate(bits_per_second: float, duration_s: float) -> int:
    """Inverse of :func:`bitrate_for_target` (no overhead applied)."""
    return int(bits_per_second * duration_s / 8)
