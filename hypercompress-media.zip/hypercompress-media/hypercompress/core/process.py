"""Process execution with per-child CPU and memory accounting.

The platform needs real numbers for the cost model and the scheduler, so every
child process is sampled from ``/proc`` while it runs. On non-Linux hosts the
sampler degrades to wall-clock only rather than failing.
"""

from __future__ import annotations

import contextlib
import os
import shlex
import signal
import subprocess
import threading
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path

from hypercompress.core.types import ResourceUsage

_CLOCK_TICKS = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


@dataclass(slots=True)
class CommandResult:
    """Outcome of a child process invocation."""

    argv: list[str]
    returncode: int
    stdout: str
    stderr: str
    usage: ResourceUsage
    timed_out: bool = False

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    @property
    def command(self) -> str:
        return shlex.join(self.argv)

    def tail(self, lines: int = 12) -> str:
        return "\n".join(self.stderr.strip().splitlines()[-lines:])


@dataclass(slots=True)
class _Sampler:
    """Polls ``/proc/<pid>`` for CPU time and peak RSS of a process tree."""

    pid: int
    interval: float = 0.25
    cpu_seconds: float = 0.0
    peak_rss: int = 0
    _stop: threading.Event = field(default_factory=threading.Event)
    _thread: threading.Thread | None = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def _run(self) -> None:
        while not self._stop.wait(self.interval):
            self._sample()
        self._sample()

    def _sample(self) -> None:
        try:
            stat = Path(f"/proc/{self.pid}/stat").read_text()
            # utime/stime are fields 14/15 after the (comm) blob.
            tail = stat.rsplit(")", 1)[1].split()
            utime, stime = int(tail[11]), int(tail[12])
            cutime, cstime = int(tail[13]), int(tail[14])
            self.cpu_seconds = max(
                self.cpu_seconds, (utime + stime + cutime + cstime) / _CLOCK_TICKS
            )
            status = Path(f"/proc/{self.pid}/status").read_text()
            for line in status.splitlines():
                if line.startswith("VmHWM:"):
                    self.peak_rss = max(self.peak_rss, int(line.split()[1]) * 1024)
                    break
        except (OSError, ValueError, IndexError):
            return


def run_process(
    argv: Sequence[str],
    *,
    timeout: float | None = None,
    cwd: str | Path | None = None,
    env: dict[str, str] | None = None,
    stdin_data: bytes | None = None,
    line_callback: Callable[[str], None] | None = None,
    sample_interval: float = 0.25,
) -> CommandResult:
    """Run ``argv``, sampling CPU/RSS, returning a fully accounted result.

    ``line_callback`` receives stderr lines as they arrive, which is how encoder
    progress is surfaced without buffering an entire encode log in memory.
    """
    argv = [str(a) for a in argv]
    started = time.monotonic()
    child_env = {**os.environ, **(env or {})}
    proc = subprocess.Popen(  # noqa: S603 - argv is built from validated tokens only
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.PIPE if stdin_data is not None else subprocess.DEVNULL,
        cwd=str(cwd) if cwd else None,
        env=child_env,
        text=True,
        bufsize=1,
        start_new_session=True,
    )
    sampler = _Sampler(pid=proc.pid, interval=sample_interval)
    sampler.start()

    stderr_chunks: list[str] = []
    stdout_chunks: list[str] = []

    def _drain_stderr() -> None:
        assert proc.stderr is not None
        for raw in proc.stderr:
            stderr_chunks.append(raw)
            if line_callback is not None:
                try:
                    line_callback(raw.rstrip("\n"))
                except Exception:  # noqa: BLE001 - a bad callback must not kill an encode
                    pass

    def _drain_stdout() -> None:
        assert proc.stdout is not None
        stdout_chunks.append(proc.stdout.read())

    threads = [
        threading.Thread(target=_drain_stderr, daemon=True),
        threading.Thread(target=_drain_stdout, daemon=True),
    ]
    for t in threads:
        t.start()

    timed_out = False
    if stdin_data is not None and proc.stdin is not None:
        try:
            proc.stdin.write(stdin_data.decode("utf-8", "ignore"))
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        _terminate_tree(proc)
        proc.wait(timeout=10)
    finally:
        for t in threads:
            t.join(timeout=5.0)
        sampler.stop()

    wall = time.monotonic() - started
    usage = ResourceUsage(
        wall_seconds=wall,
        cpu_seconds=sampler.cpu_seconds or wall,
        peak_rss_bytes=sampler.peak_rss,
        threads=os.cpu_count() or 1,
    )
    return CommandResult(
        argv=list(argv),
        returncode=proc.returncode if proc.returncode is not None else -1,
        stdout="".join(stdout_chunks),
        stderr="".join(stderr_chunks),
        usage=usage,
        timed_out=timed_out,
    )


def _terminate_tree(proc: subprocess.Popen[str]) -> None:
    """SIGTERM then SIGKILL the whole session started by :func:`run_process`."""
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(os.getpgid(proc.pid), sig)
        except (ProcessLookupError, PermissionError, OSError):
            with contextlib.suppress(OSError):
                proc.kill()
            return
        try:
            proc.wait(timeout=5)
            return
        except subprocess.TimeoutExpired:
            continue
