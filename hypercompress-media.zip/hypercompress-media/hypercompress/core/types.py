"""The domain model of HYPERCOMPRESS MEDIA.

Everything that crosses a module boundary is one of these typed, serialisable
models. Nothing in the platform passes around loose dictionaries of ffprobe JSON.
"""

from __future__ import annotations

import math
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from hypercompress.core.units import format_bitrate, format_size

# --------------------------------------------------------------------------------------
# Enumerations
# --------------------------------------------------------------------------------------


class MediaKind(StrEnum):
    """Top-level classification of an input file."""

    VIDEO = "video"
    AUDIO = "audio"
    UNKNOWN = "unknown"


class StreamKind(StrEnum):
    VIDEO = "video"
    AUDIO = "audio"
    SUBTITLE = "subtitle"
    DATA = "data"
    ATTACHMENT = "attachment"


class CodecFamily(StrEnum):
    """Codec families the platform can target."""

    AV1 = "av1"
    HEVC = "hevc"
    H264 = "h264"
    VP9 = "vp9"
    OPUS = "opus"
    AAC = "aac"
    FLAC = "flac"
    COPY = "copy"


class RateControl(StrEnum):
    """Rate-control strategy for a video encode."""

    CRF = "crf"
    CQ = "cq"
    ABR = "abr"
    CBR = "cbr"
    TWO_PASS = "two_pass"
    LOSSLESS = "lossless"


class ContentClass(StrEnum):
    """What the media 'looks like', which drives encoding policy."""

    FILM = "film"
    DOCUMENTARY = "documentary"
    SPORTS = "sports"
    ANIMATION = "animation"
    GAMING = "gaming"
    SCREEN_RECORDING = "screen_recording"
    LECTURE = "lecture"
    PODCAST = "podcast"
    MUSIC = "music"
    AUDIOBOOK = "audiobook"
    INTERVIEW = "interview"
    CCTV = "cctv"
    TALKING_HEAD = "talking_head"
    UNKNOWN = "unknown"

    @property
    def is_audio_only(self) -> bool:
        return self in {
            ContentClass.PODCAST,
            ContentClass.MUSIC,
            ContentClass.AUDIOBOOK,
        }


class HardwareVendor(StrEnum):
    CPU = "cpu"
    NVIDIA = "nvidia"
    AMD = "amd"
    INTEL = "intel"
    APPLE = "apple"


class JobState(StrEnum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    VALIDATING = "validating"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRYING = "retrying"
    DEAD_LETTER = "dead_letter"

    @property
    def terminal(self) -> bool:
        return self in {
            JobState.SUCCEEDED,
            JobState.FAILED,
            JobState.CANCELLED,
            JobState.DEAD_LETTER,
        }


class JobPriority(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"
    BULK = "bulk"

    @property
    def weight(self) -> int:
        return {
            JobPriority.CRITICAL: 0,
            JobPriority.HIGH: 10,
            JobPriority.NORMAL: 20,
            JobPriority.LOW: 30,
            JobPriority.BULK: 40,
        }[self]


class QualityMetric(StrEnum):
    PSNR = "psnr"
    SSIM = "ssim"
    MS_SSIM = "ms_ssim"
    VMAF = "vmaf"
    AUDIO_PSNR = "audio_psnr"
    SPECTRAL = "spectral"


# --------------------------------------------------------------------------------------
# Stream / media description
# --------------------------------------------------------------------------------------


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class VideoStreamInfo(_Model):
    """A single decoded video stream as reported by ffprobe."""

    index: int
    codec: str
    codec_long_name: str = ""
    profile: str | None = None
    level: int | None = None
    width: int
    height: int
    coded_width: int | None = None
    coded_height: int | None = None
    pix_fmt: str = "yuv420p"
    bit_depth: int = 8
    frame_rate: float = 0.0
    avg_frame_rate: float = 0.0
    bit_rate: int | None = None
    nb_frames: int | None = None
    duration: float | None = None
    color_space: str | None = None
    color_transfer: str | None = None
    color_primaries: str | None = None
    color_range: str | None = None
    field_order: str | None = None
    sample_aspect_ratio: str | None = None
    display_aspect_ratio: str | None = None
    language: str | None = None
    title: str | None = None
    disposition: dict[str, int] = Field(default_factory=dict)
    side_data: list[dict[str, Any]] = Field(default_factory=list)

    @property
    def pixels(self) -> int:
        return self.width * self.height

    @property
    def megapixels(self) -> float:
        return self.pixels / 1e6

    @property
    def is_hdr(self) -> bool:
        """True when the stream carries HDR10, HLG or Dolby Vision signalling."""
        hdr_transfers = {"smpte2084", "arib-std-b67", "smpte428", "bt2020-10", "bt2020-12"}
        if (self.color_transfer or "").lower() in hdr_transfers:
            return True
        if (self.color_primaries or "").lower() == "bt2020":
            return True
        return any(
            "dovi" in str(sd.get("side_data_type", "")).lower()
            or "mastering display" in str(sd.get("side_data_type", "")).lower()
            or "content light" in str(sd.get("side_data_type", "")).lower()
            for sd in self.side_data
        )

    @property
    def is_interlaced(self) -> bool:
        return (self.field_order or "progressive") not in {"progressive", "unknown", ""}

    @property
    def resolution_label(self) -> str:
        return resolution_label(self.width, self.height)

    @property
    def bits_per_pixel(self) -> float:
        """Coding efficiency indicator: bits spent per pixel per second."""
        rate = self.frame_rate or self.avg_frame_rate
        if not self.bit_rate or not rate or not self.pixels:
            return 0.0
        return self.bit_rate / (self.pixels * rate)


class AudioStreamInfo(_Model):
    index: int
    codec: str
    codec_long_name: str = ""
    profile: str | None = None
    sample_rate: int = 48000
    channels: int = 2
    channel_layout: str | None = None
    bit_rate: int | None = None
    bits_per_raw_sample: int | None = None
    sample_fmt: str | None = None
    duration: float | None = None
    language: str | None = None
    title: str | None = None
    disposition: dict[str, int] = Field(default_factory=dict)

    @property
    def is_lossless(self) -> bool:
        return self.codec.lower() in {
            "flac",
            "alac",
            "pcm_s16le",
            "pcm_s24le",
            "pcm_s32le",
            "truehd",
            "mlp",
            "wavpack",
            "tta",
        }

    @property
    def is_surround(self) -> bool:
        return self.channels > 2

    @property
    def bits_per_channel_second(self) -> float:
        if not self.bit_rate or not self.channels:
            return 0.0
        return self.bit_rate / self.channels


class SubtitleStreamInfo(_Model):
    index: int
    codec: str
    language: str | None = None
    title: str | None = None
    forced: bool = False
    default: bool = False


class ChapterInfo(_Model):
    index: int
    start: float
    end: float
    title: str | None = None


class MediaProfile(_Model):
    """A complete, machine-readable description of an input file (Phase 02)."""

    path: str
    container: str
    format_long_name: str = ""
    size_bytes: int
    duration: float = 0.0
    overall_bit_rate: int | None = None
    video: list[VideoStreamInfo] = Field(default_factory=list)
    audio: list[AudioStreamInfo] = Field(default_factory=list)
    subtitles: list[SubtitleStreamInfo] = Field(default_factory=list)
    chapters: list[ChapterInfo] = Field(default_factory=list)
    attachments: int = 0
    metadata: dict[str, str] = Field(default_factory=dict)
    checksum: str | None = None
    probed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def kind(self) -> MediaKind:
        if self.video and not self._video_is_cover_art:
            return MediaKind.VIDEO
        if self.audio:
            return MediaKind.AUDIO
        return MediaKind.UNKNOWN

    @property
    def _video_is_cover_art(self) -> bool:
        """A single-frame mjpeg/png 'video' stream is album art, not video."""
        if not self.video:
            return False
        return all(
            (v.nb_frames or 0) <= 1
            or v.disposition.get("attached_pic", 0) == 1
            or v.codec in {"mjpeg", "png", "bmp", "gif"}
            for v in self.video
        )

    @property
    def primary_video(self) -> VideoStreamInfo | None:
        if not self.video or self._video_is_cover_art:
            return None
        return max(self.video, key=lambda v: v.pixels)

    @property
    def primary_audio(self) -> AudioStreamInfo | None:
        if not self.audio:
            return None
        return max(self.audio, key=lambda a: (a.channels, a.bit_rate or 0))

    @property
    def effective_bitrate(self) -> float:
        if self.overall_bit_rate:
            return float(self.overall_bit_rate)
        if self.duration > 0:
            return self.size_bytes * 8 / self.duration
        return 0.0

    @property
    def has_hdr(self) -> bool:
        return any(v.is_hdr for v in self.video)

    def summary(self) -> str:
        parts = [f"{self.container}  {format_size(self.size_bytes)}  {self.duration:.1f}s"]
        for v in self.video:
            parts.append(
                f"V:{v.codec} {v.width}x{v.height} {v.frame_rate:.3f}fps "
                f"{v.pix_fmt}/{v.bit_depth}bit{' HDR' if v.is_hdr else ''}"
            )
        for a in self.audio:
            parts.append(
                f"A:{a.codec} {a.sample_rate}Hz {a.channels}ch {format_bitrate(a.bit_rate or 0)}"
            )
        for s in self.subtitles:
            parts.append(f"S:{s.codec}{'/' + s.language if s.language else ''}")
        return "\n  ".join(parts)


# --------------------------------------------------------------------------------------
# Content analysis
# --------------------------------------------------------------------------------------


class Scene(_Model):
    """A detected shot boundary interval (Phase 06)."""

    index: int
    start: float
    end: float
    score: float = 0.0
    mean_luma: float = 0.0
    motion: float = 0.0
    spatial_energy: float = 0.0
    grain: float = 0.0
    is_dark: bool = False
    is_static: bool = False
    is_high_motion: bool = False
    has_text: bool = False

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)

    @property
    def complexity(self) -> float:
        """0..1 blend of motion and spatial energy used for bit allocation."""
        return min(1.0, 0.6 * self.motion + 0.4 * self.spatial_energy)


class VideoComplexity(_Model):
    """Aggregate video complexity signals (Phase 03)."""

    motion: float = 0.0
    spatial: float = 0.0
    temporal_variance: float = 0.0
    grain: float = 0.0
    dark_ratio: float = 0.0
    static_ratio: float = 0.0
    scene_change_rate: float = 0.0
    sampled_seconds: float = 0.0
    frames_sampled: int = 0

    @property
    def score(self) -> float:
        """Single 0..1 difficulty score; higher means more bits are required."""
        return float(
            min(
                1.0,
                0.45 * self.motion
                + 0.30 * self.spatial
                + 0.15 * self.grain
                + 0.10 * min(1.0, self.scene_change_rate / 0.5),
            )
        )


class AudioComplexity(_Model):
    """Aggregate audio signals (Phase 07)."""

    silence_ratio: float = 0.0
    dynamic_range_db: float = 0.0
    spectral_centroid_hz: float = 0.0
    spectral_rolloff_hz: float = 0.0
    high_freq_energy_ratio: float = 0.0
    stereo_correlation: float = 1.0
    speech_likelihood: float = 0.0
    music_likelihood: float = 0.0
    peak_dbfs: float = 0.0
    rms_dbfs: float = -30.0
    loudness_lufs: float | None = None
    sampled_seconds: float = 0.0

    @property
    def is_speech(self) -> bool:
        return self.speech_likelihood >= self.music_likelihood

    @property
    def is_effectively_mono(self) -> bool:
        return self.stereo_correlation >= 0.985

    @property
    def score(self) -> float:
        return float(min(1.0, 0.5 * self.music_likelihood + 0.5 * self.high_freq_energy_ratio))


class ContentAnalysis(_Model):
    """Phase 03 output."""

    content_class: ContentClass = ContentClass.UNKNOWN
    confidence: float = 0.0
    video: VideoComplexity | None = None
    audio: AudioComplexity | None = None
    scenes: list[Scene] = Field(default_factory=list)
    rationale: list[str] = Field(default_factory=list)

    @property
    def scene_count(self) -> int:
        return len(self.scenes)

    @property
    def difficulty(self) -> float:
        """0..1 overall encoding difficulty."""
        if self.video is not None:
            return self.video.score
        if self.audio is not None:
            return self.audio.score
        return 0.5


# --------------------------------------------------------------------------------------
# Encoding parameters
# --------------------------------------------------------------------------------------


class VideoEncodeParams(_Model):
    """A fully-specified, validated video encoder configuration (Phase 05)."""

    codec: CodecFamily = CodecFamily.AV1
    rate_control: RateControl = RateControl.CRF
    crf: float | None = 30.0
    bitrate: int | None = None
    max_bitrate: int | None = None
    buffer_size: int | None = None
    preset: str = "medium"
    width: int | None = None
    height: int | None = None
    frame_rate: float | None = None
    pix_fmt: str = "yuv420p"
    keyint: int | None = None
    min_keyint: int | None = None
    scene_cut: bool = True
    b_frames: int | None = None
    ref_frames: int | None = None
    tune: str | None = None
    film_grain: int | None = None
    tiles: str | None = None
    threads: int | None = None
    hardware: HardwareVendor = HardwareVendor.CPU
    two_pass: bool = False
    preserve_hdr: bool = True
    deinterlace: bool = False
    denoise: float | None = None
    extra_filters: list[str] = Field(default_factory=list)

    @field_validator("crf")
    @classmethod
    def _crf_range(cls, v: float | None) -> float | None:
        if v is not None and not (0 <= v <= 63):
            raise ValueError("crf must be within 0..63")
        return v

    @model_validator(mode="after")
    def _check_rate_control(self) -> Self:
        if self.rate_control in {RateControl.ABR, RateControl.CBR, RateControl.TWO_PASS}:
            if not self.bitrate:
                raise ValueError(f"{self.rate_control} requires an explicit bitrate")
        if self.rate_control is RateControl.CRF and self.crf is None:
            raise ValueError("CRF rate control requires a crf value")
        if (self.width is None) != (self.height is None):
            raise ValueError("width and height must be set together")
        return self

    @property
    def resolution(self) -> tuple[int, int] | None:
        if self.width is None or self.height is None:
            return None
        return (self.width, self.height)

    def fingerprint(self) -> str:
        res = f"{self.width}x{self.height}" if self.width else "source"
        rc = (
            f"crf{self.crf:g}"
            if self.rate_control is RateControl.CRF
            else f"{self.rate_control}{(self.bitrate or 0) // 1000}k"
        )
        return f"{self.codec}/{res}/{rc}/{self.preset}"


class AudioEncodeParams(_Model):
    """A fully-specified audio encoder configuration (Phase 07)."""

    codec: CodecFamily = CodecFamily.OPUS
    bitrate: int | None = 96_000
    vbr: bool = True
    quality: float | None = None
    sample_rate: int | None = None
    channels: int | None = None
    channel_layout: str | None = None
    compression_level: int | None = None
    application: Literal["voip", "audio", "lowdelay"] | None = None
    cutoff: int | None = None
    downmix_surround: bool = False
    normalize: bool = False

    @model_validator(mode="after")
    def _check(self) -> Self:
        if self.codec is CodecFamily.FLAC:
            if self.compression_level is not None and not 0 <= self.compression_level <= 12:
                raise ValueError("flac compression level must be 0..12")
        elif self.bitrate is None and self.quality is None:
            raise ValueError("lossy audio requires a bitrate or a quality value")
        if self.channels is not None and not 1 <= self.channels <= 16:
            raise ValueError("channels must be 1..16")
        return self

    def fingerprint(self) -> str:
        return (
            f"{self.codec}/"
            f"{(self.bitrate or 0) // 1000}k/"
            f"{self.channels or 'src'}ch/"
            f"{self.sample_rate or 'src'}Hz"
        )


class EncodePlan(_Model):
    """A complete encode specification: container + video + audio + stream policy."""

    container: str = "mkv"
    video: VideoEncodeParams | None = None
    audio: AudioEncodeParams | None = None
    copy_video: bool = False
    copy_audio: bool = False
    keep_subtitles: bool = True
    keep_chapters: bool = True
    keep_all_audio_tracks: bool = False
    strip_metadata: bool = False
    faststart: bool = True
    label: str = ""

    @property
    def fingerprint(self) -> str:
        v = "copy" if self.copy_video else (self.video.fingerprint() if self.video else "none")
        a = "copy" if self.copy_audio else (self.audio.fingerprint() if self.audio else "none")
        return f"{self.container}|{v}|{a}"


# --------------------------------------------------------------------------------------
# Quality / results
# --------------------------------------------------------------------------------------


class QualityReport(_Model):
    """Phase 10 measurement bundle."""

    psnr: float | None = None
    ssim: float | None = None
    """Gaussian-windowed luma SSIM, computed here rather than by FFmpeg.

    One implementation is used for every measurement so that a fast sampled
    pass and a full pass produce numbers on the same scale.
    """

    ssim_all_planes: float | None = None
    """FFmpeg's all-plane SSIM. Reported for reference; not scored.

    It carries a large constant chroma penalty — a visually transparent AV1
    encode still reports around 0.97 — so it never approaches its ceiling and
    makes a poor input to a quality score.
    """
    ms_ssim: float | None = None
    vmaf: float | None = None
    vmaf_low_percentile: float | None = None
    audio_psnr: float | None = None
    spectral_similarity: float | None = None
    video_score: float | None = None
    audio_score: float | None = None
    composite: float | None = None
    measured_frames: int = 0
    reference: str | None = None
    notes: list[str] = Field(default_factory=list)

    @property
    def has_video_measurement(self) -> bool:
        return any(v is not None for v in (self.psnr, self.ssim, self.ms_ssim, self.vmaf))

    @property
    def has_audio_measurement(self) -> bool:
        return any(v is not None for v in (self.audio_psnr, self.spectral_similarity))


class ResourceUsage(_Model):
    """Per-encode resource accounting used by the scheduler and cost model."""

    wall_seconds: float = 0.0
    cpu_seconds: float = 0.0
    gpu_seconds: float = 0.0
    peak_rss_bytes: int = 0
    threads: int = 1
    energy_joules: float = 0.0

    @property
    def cpu_utilisation(self) -> float:
        if self.wall_seconds <= 0:
            return 0.0
        return self.cpu_seconds / self.wall_seconds

    def merge(self, other: ResourceUsage) -> ResourceUsage:
        return ResourceUsage(
            wall_seconds=self.wall_seconds + other.wall_seconds,
            cpu_seconds=self.cpu_seconds + other.cpu_seconds,
            gpu_seconds=self.gpu_seconds + other.gpu_seconds,
            peak_rss_bytes=max(self.peak_rss_bytes, other.peak_rss_bytes),
            threads=max(self.threads, other.threads),
            energy_joules=self.energy_joules + other.energy_joules,
        )


class EncodeCandidate(_Model):
    """One point in the search space (Phase 08)."""

    plan: EncodePlan
    generation: int = 0
    origin: str = "seed"
    predicted_size: int | None = None
    predicted_quality: float | None = None

    @property
    def fingerprint(self) -> str:
        return self.plan.fingerprint


class CandidateResult(_Model):
    """The measured outcome of encoding one candidate."""

    candidate: EncodeCandidate
    output_path: str | None = None
    output_size: int = 0
    source_size: int = 0
    quality: QualityReport = Field(default_factory=QualityReport)
    usage: ResourceUsage = Field(default_factory=ResourceUsage)
    sampled: bool = False
    sample_fraction: float = 1.0
    extrapolated_size: int | None = None
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and self.output_size > 0

    @property
    def effective_size(self) -> int:
        """Full-length size: either measured or extrapolated from a sample encode."""
        if self.sampled and self.extrapolated_size is not None:
            return self.extrapolated_size
        return self.output_size

    @property
    def compression_ratio(self) -> float:
        if self.effective_size <= 0:
            return math.inf
        return self.source_size / self.effective_size

    @property
    def size_reduction(self) -> float:
        if self.source_size <= 0:
            return 0.0
        return 1.0 - (self.effective_size / self.source_size)

    @property
    def quality_score(self) -> float:
        return self.quality.composite if self.quality.composite is not None else 0.0

    def row(self) -> dict[str, Any]:
        """Flat record for benchmark tables (Phase 19)."""
        v = self.candidate.plan.video
        a = self.candidate.plan.audio
        return {
            "fingerprint": self.candidate.fingerprint,
            "codec": v.codec.value if v else (a.codec.value if a else "copy"),
            "resolution": f"{v.width}x{v.height}" if v and v.width else "source",
            "frame_rate": v.frame_rate if v else None,
            "bitrate": (v.bitrate if v else None) or (a.bitrate if a else None),
            "crf": v.crf if v else None,
            "preset": v.preset if v else None,
            "quality": round(self.quality_score, 3),
            "vmaf": self.quality.vmaf,
            "psnr": self.quality.psnr,
            "ssim": self.quality.ssim,
            "output_size": self.effective_size,
            "compression_ratio": round(self.compression_ratio, 3),
            "encoding_time": round(self.usage.wall_seconds, 3),
            "cpu_seconds": round(self.usage.cpu_seconds, 3),
            "gpu_seconds": round(self.usage.gpu_seconds, 3),
            "memory_usage": self.usage.peak_rss_bytes,
            "sampled": self.sampled,
            "error": self.error,
        }


# --------------------------------------------------------------------------------------
# Hardware
# --------------------------------------------------------------------------------------


class HardwareProfile(_Model):
    """Detected local acceleration capability (Phase 09/GPU support)."""

    vendor: HardwareVendor = HardwareVendor.CPU
    decoders: list[str] = Field(default_factory=list)
    encoders: list[str] = Field(default_factory=list)
    device: str | None = None
    cpu_count: int = 1
    total_memory_bytes: int = 0

    @property
    def has_gpu(self) -> bool:
        return self.vendor is not HardwareVendor.CPU and bool(self.encoders)

    def encoder_for(self, family: CodecFamily) -> str | None:
        for enc in self.encoders:
            if family.value in enc or (family is CodecFamily.HEVC and "hevc" in enc):
                return enc
        return None


# --------------------------------------------------------------------------------------
# Jobs & manifests
# --------------------------------------------------------------------------------------


class JobSpec(_Model):
    """A unit of work handed to the distributed layer."""

    job_id: str
    source_uri: str
    destination_uri: str | None = None
    profile: str = "balanced"
    target_size: int | None = None
    quality_floor: float | None = None
    priority: JobPriority = JobPriority.NORMAL
    tenant: str = "default"
    principal: str = "system"
    max_attempts: int = 3
    compute_budget_seconds: float | None = None
    dry_run: bool = False
    overrides: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def sort_key(self) -> tuple[int, float]:
        return (self.priority.weight, self.created_at.timestamp())


class JobAttempt(_Model):
    attempt: int
    worker: str
    started_at: datetime
    finished_at: datetime | None = None
    state: JobState = JobState.RUNNING
    error: str | None = None


class Manifest(_Model):
    """The permanent record written beside every output (Phase 11)."""

    engine: str = "HYPERCOMPRESS MEDIA"
    version: str = "1.0.0"
    job_id: str | None = None
    source_path: str
    output_path: str
    source_checksum: str | None = None
    output_checksum: str | None = None
    source_size: int = 0
    output_size: int = 0
    compression_ratio: float = 1.0
    size_reduction: float = 0.0
    profile: str = "balanced"
    content_class: ContentClass = ContentClass.UNKNOWN
    plan: EncodePlan | None = None
    encoder_arguments: list[str] = Field(default_factory=list)
    quality: QualityReport = Field(default_factory=QualityReport)
    usage: ResourceUsage = Field(default_factory=ResourceUsage)
    candidates_evaluated: int = 0
    search_log: list[dict[str, Any]] = Field(default_factory=list)
    validated: bool = False
    validation_notes: list[str] = Field(default_factory=list)
    validation_failures: list[str] = Field(default_factory=list)
    caveats: list[str] = Field(default_factory=list)
    """Everything a reader of this record needs to know before trusting it.

    Estimated rather than measured metrics, quality floors that were not met,
    streams that did not survive. A manifest that omits these is worse than no
    manifest, because it will be believed.
    """
    lossless: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    def to_json(self, indent: int = 2) -> str:
        return self.model_dump_json(indent=indent)


class JobResult(_Model):
    job_id: str
    state: JobState
    manifest: Manifest | None = None
    attempts: list[JobAttempt] = Field(default_factory=list)
    error: str | None = None
    worker: str | None = None
    queued_at: datetime | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None

    @property
    def bytes_saved(self) -> int:
        if self.manifest is None:
            return 0
        return max(0, self.manifest.source_size - self.manifest.output_size)


# --------------------------------------------------------------------------------------
# Resolution helpers
# --------------------------------------------------------------------------------------

RESOLUTION_LADDER: list[tuple[str, int, int]] = [
    ("8K", 7680, 4320),
    ("6K", 6144, 3456),
    ("4K", 3840, 2160),
    ("1440p", 2560, 1440),
    ("1080p", 1920, 1080),
    ("720p", 1280, 720),
    ("480p", 854, 480),
    ("360p", 640, 360),
]


def resolution_label(width: int, height: int) -> str:
    """Nearest standard rung of the ladder for an arbitrary frame size."""
    pixels = width * height
    best = min(RESOLUTION_LADDER, key=lambda r: abs(r[1] * r[2] - pixels))
    return best[0]


def ladder_below(
    width: int, height: int, include_current: bool = True
) -> list[tuple[str, int, int]]:
    """Ladder rungs at or below a given frame size, preserving aspect ratio downstream."""
    pixels = width * height
    out = []
    for label, w, h in RESOLUTION_LADDER:
        if w * h < pixels or (include_current and abs(w * h - pixels) / pixels < 0.02):
            out.append((label, w, h))
    return out


def scale_to_height(
    width: int, height: int, target_height: int, modulus: int = 2
) -> tuple[int, int]:
    """Scale preserving aspect ratio, snapping both dimensions to ``modulus``."""
    if height <= 0:
        raise ValueError("height must be positive")
    ratio = width / height
    new_h = int(round(target_height / modulus) * modulus)
    new_w = int(round((new_h * ratio) / modulus) * modulus)
    return max(modulus, new_w), max(modulus, new_h)
