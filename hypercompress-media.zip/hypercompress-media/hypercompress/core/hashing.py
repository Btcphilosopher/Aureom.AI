"""Checksums and content-defined chunking for the deduplication engine.

Whole-file digests answer "is this the same file?"; content-defined chunking
answers "how much of this file already exists elsewhere in the library?", which
is the interesting question once a media estate reaches petabyte scale.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Final

from hypercompress.core.errors import ProbeError

CHUNK_READ_SIZE: Final = 4 * 1024 * 1024

# Rolling-hash parameters for content-defined chunking (Rabin-style gear hash).
_GEAR: Final[tuple[int, ...]] = tuple(
    int(hashlib.sha256(bytes([i])).hexdigest()[:16], 16) & 0xFFFFFFFFFFFFFFFF for i in range(256)
)


def file_digest(
    path: str | Path, algorithm: str = "sha256", chunk_size: int = CHUNK_READ_SIZE
) -> str:
    """Streaming digest of a whole file. Never loads the file into memory."""
    hasher = hashlib.new(algorithm)
    with Path(path).open("rb") as handle:
        while block := handle.read(chunk_size):
            hasher.update(block)
    return hasher.hexdigest()


def quick_signature(path: str | Path, sample_bytes: int = 1 << 20) -> str:
    """Cheap probabilistic identity: size + head + tail digest.

    Used as a first-pass duplicate filter across millions of objects before
    paying for a full-file digest.
    """
    p = Path(path)
    size = p.stat().st_size
    hasher = hashlib.blake2b(digest_size=16)
    hasher.update(str(size).encode())
    with p.open("rb") as handle:
        hasher.update(handle.read(min(sample_bytes, size)))
        if size > sample_bytes * 2:
            handle.seek(-sample_bytes, 2)
            hasher.update(handle.read(sample_bytes))
    return f"{size:x}:{hasher.hexdigest()}"


def stream_digest(stream: BinaryIO, algorithm: str = "sha256") -> str:
    hasher = hashlib.new(algorithm)
    while block := stream.read(CHUNK_READ_SIZE):
        hasher.update(block)
    return hasher.hexdigest()


@dataclass(frozen=True, slots=True)
class Chunk:
    """One content-defined chunk of a file."""

    offset: int
    length: int
    digest: str

    @property
    def end(self) -> int:
        return self.offset + self.length


def media_stream_digest(runner: object, path: str | Path) -> str:
    """Digest the elementary streams, ignoring the container.

    The same episode as MP4, MKV and MOV are three different files with three
    different SHA-256s and identical content. FFmpeg's ``md5`` muxer hashes the
    packet payloads after a stream copy, so remuxing, retagging and chapter
    edits all collapse to the same digest while any actual change to the audio
    or video does not.

    ``runner`` is a :class:`~hypercompress.core.ffmpeg.FFmpegRunner`; it is typed
    loosely here to keep this module free of an import cycle.
    """
    from hypercompress.core.ffmpeg import ArgBuilder  # noqa: PLC0415 - avoids a cycle

    args = (
        ArgBuilder()
        .opt("-v", "error")
        .path("-i", path)
        .opt("-map", "0:v:0?")
        .opt("-map", "0:a:0?")
        .opt("-c:v", "copy")
        .opt("-c:a", "copy")
        .flag("-sn")
        .flag("-dn")
        .opt("-f", "md5")
    )
    args.path(None, "pipe:1")
    result = runner.run(args, check=False)  # type: ignore[attr-defined]
    text = (result.stdout or "") + (result.stderr or "")
    for line in text.splitlines():
        if line.startswith("MD5="):
            return line.split("=", 1)[1].strip()
    raise ProbeError(f"could not compute a stream digest for {path}")


def content_defined_chunks(
    path: str | Path,
    *,
    min_size: int = 256 * 1024,
    avg_size: int = 1024 * 1024,
    max_size: int = 4 * 1024 * 1024,
    algorithm: str = "blake2b",
) -> Iterator[Chunk]:
    """Split a file at content-defined boundaries using a gear rolling hash.

    Boundaries follow the data rather than fixed offsets, so inserting bytes near
    the start of a file does not invalidate every downstream chunk — the property
    that makes chunk-level dedup worthwhile for re-muxed or re-tagged media.
    """
    mask = (1 << (avg_size.bit_length() - 1)) - 1
    offset = 0
    with Path(path).open("rb") as handle:
        buffer = b""
        while True:
            if len(buffer) < max_size:
                block = handle.read(CHUNK_READ_SIZE)
                if block:
                    buffer += block
                elif not buffer:
                    return
            cut = _find_boundary(buffer, mask, min_size, max_size)
            piece, buffer = buffer[:cut], buffer[cut:]
            digest = (
                hashlib.new(algorithm, piece).hexdigest()[:32]
                if algorithm == "blake2b"
                else hashlib.new(algorithm, piece).hexdigest()
            )
            yield Chunk(offset=offset, length=len(piece), digest=digest)
            offset += len(piece)
            if not buffer and not block:
                return


def _find_boundary(data: bytes, mask: int, min_size: int, max_size: int) -> int:
    if len(data) <= min_size:
        return len(data)
    fingerprint = 0
    limit = min(len(data), max_size)
    for index in range(min_size, limit):
        fingerprint = ((fingerprint << 1) + _GEAR[data[index]]) & 0xFFFFFFFFFFFFFFFF
        if not fingerprint & mask:
            return index + 1
    return limit


def content_address(digest: str, prefix_depth: int = 2, prefix_width: int = 2) -> str:
    """Fan out a digest into a directory path: ``ab/cd/abcd...``."""
    parts = [digest[i * prefix_width : (i + 1) * prefix_width] for i in range(prefix_depth)]
    return "/".join([*parts, digest])
