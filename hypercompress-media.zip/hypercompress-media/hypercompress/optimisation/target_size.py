"""Target-size optimisation (Phase 08).

The request is simple to state — *make this 8.4 GB file fit in 1.0 GB* — and the
honest answer has three possible shapes:

1. The target is reachable without breaching the quality floor. Good.
2. The target is reachable only below the floor. The engine will hit the number
   and say plainly what it cost.
3. The target is not reachable at all at any setting the profile allows. The
   engine says so and returns the smallest thing it managed, rather than
   silently shipping something over budget or pretending otherwise.

The search proceeds in three stages, cheapest first:

**Budget split.** Audio is settled first, on its own ladder, because audio bits
are a fixed cost the video search has to work around. On a 1 GB target for a
two-hour film, a careless 384 kbps audio track eats a third of the budget.

**CRF bisection on size.** Size is monotone in CRF, and unlike quality it is
measured exactly rather than estimated, so the bisection converges quickly and
reliably.

**Resolution descent.** When the smallest CRF the codec allows still overshoots,
CRF is the wrong knob: a 1080p encode squeezed to a rate that suits 720p looks
worse than a clean 720p encode of the same size. The engine steps down the
resolution ladder and restarts the bisection, which is what a human encoder does
and for the same reason.
"""

from __future__ import annotations

from dataclasses import dataclass

from hypercompress.codecs import REGISTRY
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    CandidateResult,
    EncodeCandidate,
    EncodePlan,
    RateControl,
    ladder_below,
)
from hypercompress.core.units import format_size
from hypercompress.optimisation.audio_search import AudioSearch
from hypercompress.optimisation.quality_search import with_audio, with_crf
from hypercompress.optimisation.search import CandidateEvaluator, SearchOutcome, SearchTrace
from hypercompress.quality.scoring import video_meets_floor

log = get_logger(__name__)

#: Aim slightly under the target. Sampled extrapolation has a few percent of
#: spread, and being 1% under budget is free while being 1% over is a failure.
UNDERSHOOT = 0.985


@dataclass(slots=True)
class SizeTarget:
    """The byte budget for one file, and how strictly it binds."""

    bytes_: int
    tolerance: float = 0.02
    allow_quality_breach: bool = True

    @property
    def upper(self) -> int:
        return int(self.bytes_ * (1.0 + self.tolerance))

    @property
    def aim(self) -> int:
        return int(self.bytes_ * UNDERSHOOT)

    def contains(self, size: int) -> bool:
        return size <= self.upper


class TargetSizeSearch:
    """Drives an encode towards a byte budget."""

    def __init__(self, evaluator: CandidateEvaluator, trace: SearchTrace | None = None) -> None:
        self.evaluator = evaluator
        self.trace = trace or SearchTrace()

    # -- entry point -------------------------------------------------------------
    def run(self, seed: EncodePlan, target: SizeTarget) -> SearchOutcome:
        media = self.evaluator.media
        self.trace.note(
            f"target {format_size(target.bytes_)} from {format_size(media.size_bytes)} "
            f"({target.bytes_ / max(media.size_bytes, 1):.1%} of source)"
        )

        seed, audio_bytes = self._settle_audio(seed, target)
        if seed.video is None:
            return self._audio_only(seed, target)

        video_budget = max(0, target.aim - audio_bytes)
        if video_budget <= 0:
            self.trace.stop_reason = "audio alone exceeds the target size"
            self.trace.note(
                "the audio track alone does not fit the target; no video encode can rescue this. "
                "Either raise the target or allow a more aggressive audio profile."
            )
            return SearchOutcome(best=None, trace=self.trace, target_met=False)

        self.trace.note(
            f"budget split: {format_size(audio_bytes)} audio, {format_size(video_budget)} video"
        )

        best = self._descend(seed, target, video_budget)
        return self._finish(best, target)

    # -- stages ------------------------------------------------------------------
    def _settle_audio(self, seed: EncodePlan, target: SizeTarget) -> tuple[EncodePlan, int]:
        """Fix the audio track and work out what it costs the budget."""
        if seed.audio is None or seed.copy_audio:
            return (seed, 0)

        params, result = AudioSearch(self.evaluator, self.trace).run(seed)
        if params is not None and seed.audio is not None:
            seed = with_audio(seed, params, label=f"{seed.label}+audio")

        duration = max(self.evaluator.media.duration, 1e-6)
        if result is not None and result.ok:
            measured = result.effective_size
        else:
            measured = int((params.bitrate or 96_000) * duration / 8) if params else 0

        # If audio is eating an unreasonable share of a tight budget, push it
        # down the ladder: a slightly duller soundtrack is a better trade than a
        # visibly broken picture.
        share = measured / max(target.aim, 1)
        if share > 0.35 and params is not None and params.bitrate:
            reduced = params.model_copy(update={"bitrate": max(24_000, int(params.bitrate * 0.5))})
            self.trace.note(
                f"audio would take {share:.0%} of the budget; reducing it to "
                f"{(reduced.bitrate or 0) // 1000} kbps to leave room for the picture"
            )
            seed = with_audio(seed, reduced, label=f"{seed.label}+audio-reduced")
            measured = int((reduced.bitrate or 0) * duration / 8)

        return (seed, measured)

    def _descend(
        self, seed: EncodePlan, target: SizeTarget, video_budget: int
    ) -> CandidateResult | None:
        """Bisect CRF; drop a resolution rung when CRF alone cannot get there."""
        media = self.evaluator.media
        source_video = media.primary_video
        assert source_video is not None

        width = (seed.video.width if seed.video else None) or source_video.width
        height = (seed.video.height if seed.video else None) or source_video.height
        best: CandidateResult | None = None
        # The current rung plus everything beneath it, worst case a handful of
        # descents before the picture is too small to be worth shipping.
        rungs = [
            h
            for _, _, h in ladder_below(width, height)
            if h >= self.evaluator.config.quality.min_height
        ]
        rungs = rungs[:4] or [height]

        for rung_index, rung_height in enumerate(rungs):
            if self.evaluator.budget.exhausted:
                self.trace.stop_reason = "compute budget exhausted"
                break

            plan = self._at_height(seed, rung_height)
            if rung_index > 0:
                self.trace.note(
                    f"stepping down to {rung_height}p: CRF alone could not reach the target "
                    f"at the previous resolution"
                )

            candidate = self._bisect_crf(plan, target, video_budget)
            if candidate is not None and (
                best is None or candidate.effective_size < best.effective_size
            ):
                best = candidate
            if (
                candidate is not None
                and not target.contains(candidate.effective_size)
                and rung_index == len(rungs) - 1
            ):
                self.trace.note(
                    "the resolution ladder is exhausted; no rung this profile allows reaches the target"
                )
            if candidate is not None and target.contains(candidate.effective_size):
                floor_ok, _ = video_meets_floor(candidate.quality, self.evaluator.search_quality)
                if floor_ok or not target.allow_quality_breach:
                    self.trace.stop_reason = "target met"
                    return candidate
                # In budget but below the floor. A lower resolution often clears
                # both, so it is worth one more descent before giving up on
                # quality.
                self.trace.note(
                    "target met but below the quality floor; trying a lower resolution, "
                    "which usually looks better at the same bitrate"
                )
                continue
        return best

    def _bisect_crf(
        self,
        plan: EncodePlan,
        target: SizeTarget,
        video_budget: int,
    ) -> CandidateResult | None:
        """Find the lowest CRF whose measured size fits the video budget."""
        if plan.video is None:
            return None
        codec = REGISTRY.get_video(plan.video.codec)
        lo, hi = codec.crf_range
        low, high = max(lo, 14.0), min(hi, 55.0)
        policy = self.evaluator.config.search
        best: CandidateResult | None = None
        smallest: CandidateResult | None = None
        crf = float(plan.video.crf or 30.0)
        previous_size = 0

        for iteration in range(policy.max_iterations):
            if self.evaluator.budget.exhausted:
                self.trace.stop_reason = "compute budget exhausted"
                break

            attempt = with_crf(plan, crf, label=f"target:crf{crf:g}")
            result = self.trace.add(
                self.evaluator.evaluate(
                    EncodeCandidate(plan=attempt, generation=iteration, origin="target")
                )
            )
            self.trace.iterations += 1
            if not result.ok:
                low = crf + 1.0
                crf = (low + high) / 2.0
                continue

            size = result.effective_size
            if smallest is None or size < smallest.effective_size:
                smallest = result
            # The candidate is a muxed file, so it is measured against the whole
            # target rather than the video share of it. The split is what sized
            # the audio track; it is not a second budget to satisfy.
            fits = size <= target.aim
            self.trace.note(
                f"crf {crf:g} -> {format_size(size)} "
                f"({'fits' if fits else 'over'} the {format_size(target.aim)} working target; "
                f"video share {format_size(max(0, size - (target.aim - video_budget)))}), "
                f"video {result.quality.video_score or 0:.4f}"
            )

            if fits:
                if best is None or size > best.effective_size:
                    # Among the settings that fit, the largest is the best
                    # looking. Undershooting a size target wastes quality.
                    best = result
                high = crf
            else:
                low = crf

            if (
                previous_size
                and abs(size - previous_size) / max(previous_size, 1) < policy.size_tolerance
            ):
                self.trace.note("size stopped responding to CRF; further bisection would not help")
                break
            previous_size = size

            if high - low <= 0.75:
                break
            crf = (low + high) / 2.0

        # Returning the smallest attempt when nothing fits is what lets the
        # caller report how far short the request fell, instead of an empty
        # result that says only "no".
        return best or smallest

    def _at_height(self, plan: EncodePlan, height: int) -> EncodePlan:
        """The same plan re-planned for a different output height."""
        media = self.evaluator.media
        source_video = media.primary_video
        if plan.video is None or source_video is None:
            return plan
        if height >= source_video.height:
            return plan
        codec = REGISTRY.get_video(plan.video.codec)
        params = self.evaluator.planner.video_params(
            media,
            self.evaluator.analysis,
            codec,
            crf=plan.video.crf,
            height_override=height,
            hardware=plan.video.hardware,
        )
        return plan.model_copy(update={"video": params, "label": f"{plan.label}@{height}p"})

    def _audio_only(self, seed: EncodePlan, target: SizeTarget) -> SearchOutcome:
        """An audio file with a byte budget: bitrate follows directly."""
        duration = max(self.evaluator.media.duration, 1e-6)
        bitrate = int(target.aim * 8 / duration)
        if seed.audio is not None:
            seed = with_audio(
                seed,
                seed.audio.model_copy(update={"bitrate": max(6_000, bitrate)}),
                label=f"target:{bitrate // 1000}k",
            )
        result = self.trace.add(
            self.evaluator.evaluate(EncodeCandidate(plan=seed, origin="target"), audio_only=True)
        )
        self.trace.stop_reason = "audio bitrate derived directly from the target"
        return self._finish(result, target)

    def _finish(self, best: CandidateResult | None, target: SizeTarget) -> SearchOutcome:
        if best is None:
            self.trace.stop_reason = self.trace.stop_reason or "no candidate produced usable output"
            return SearchOutcome(best=None, trace=self.trace, target_met=False)

        met = target.contains(best.effective_size)
        floor_ok, reasons = video_meets_floor(best.quality, self.evaluator.search_quality)

        if met and floor_ok:
            self.trace.note(
                f"target met at {format_size(best.effective_size)} with the quality floor intact"
            )
        elif met:
            self.trace.note(
                f"target met at {format_size(best.effective_size)}, but below the quality floor "
                f"({'; '.join(reasons)}). This is a real, visible cost, not a rounding error."
            )
        else:
            shortfall = best.effective_size / max(target.bytes_, 1)
            self.trace.note(
                f"target NOT met: the smallest usable encode is {format_size(best.effective_size)}, "
                f"{shortfall:.2f}x the requested {format_size(target.bytes_)}. Reaching it would "
                f"require a lower resolution or frame rate than this profile permits."
            )
            if not self.trace.stop_reason:
                self.trace.stop_reason = "target unreachable within profile limits"

        if not self.trace.stop_reason:
            self.trace.stop_reason = "target met"

        return SearchOutcome(
            best=best,
            trace=self.trace,
            target_met=met,
            quality_met=floor_ok,
            achieved_ratio=best.effective_size / max(best.source_size, 1),
        )


def target_from_ratio(source_size: int, ratio: float) -> SizeTarget:
    """A byte target expressed as a fraction of the source."""
    return SizeTarget(bytes_=int(source_size * max(0.0, min(1.0, ratio))))


def rate_control_for_target(plan: EncodePlan, target_bits_per_second: int) -> EncodePlan:
    """Switch a plan to two-pass ABR at an explicit rate.

    CRF search is preferred because it allocates bits where the picture needs
    them, but when a hard cap must be respected exactly — a broadcast delivery
    spec, a device with a fixed buffer — two-pass ABR is the honest tool.
    """
    if plan.video is None:
        return plan
    video = plan.video.model_copy(
        update={
            "rate_control": RateControl.TWO_PASS,
            "bitrate": max(50_000, target_bits_per_second),
            "max_bitrate": int(target_bits_per_second * 1.45),
            "buffer_size": int(target_bits_per_second * 2.0),
            "two_pass": True,
            "crf": None,
        }
    )
    return plan.model_copy(update={"video": video, "label": f"{plan.label}+2pass"})
