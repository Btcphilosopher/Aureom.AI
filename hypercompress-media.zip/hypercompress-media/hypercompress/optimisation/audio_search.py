"""Audio parameter search.

Audio compression has no single knob. Bitrate matters, but so do channel count,
sample rate and low-pass cutoff, and they interact: 32 kbps of mono 16 kHz Opus
sounds better on speech than 32 kbps of stereo 48 kHz. Bisecting bitrate alone
would leave most of the available saving on the table for speech and would
mangle music.

So the search walks a **ladder**: an ordered list of complete parameter sets,
from most aggressive to most faithful. Ordering them means the same bisection
that works on CRF works here, at a cost of one integer index instead of four
interacting floats.

The ladder is generated from the source and the content analysis, so a stereo
48 kHz music track and a mono podcast get different ladders rather than a single
compromise. The planner's own choice is inserted into the ladder so a good first
guess is never lost.

Audio candidates are encoded **without video**. The video re-encode dominates
runtime by two orders of magnitude, and including it would make an audio search
unaffordable without changing a single audio measurement.
"""

from __future__ import annotations

from dataclasses import dataclass

from hypercompress.analysis.containers import audio_only_container
from hypercompress.codecs import REGISTRY
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    AudioEncodeParams,
    AudioStreamInfo,
    CandidateResult,
    CodecFamily,
    ContentAnalysis,
    EncodeCandidate,
    EncodePlan,
)
from hypercompress.optimisation.search import CandidateEvaluator, SearchTrace
from hypercompress.quality.scoring import audio_meets_floor

log = get_logger(__name__)

#: Bitrate per channel, in kbps, at each rung. Speech and music are scaled
#: differently because the codecs' efficiency curves differ so sharply between
#: them: Opus is transparent on speech at rates where music is still audibly
#: damaged.
_SPEECH_RUNGS: tuple[tuple[int, int, int | None], ...] = (
    # (kbps per channel, sample rate, cutoff)
    (12, 12_000, 4_000),
    (16, 16_000, 6_000),
    (24, 16_000, 8_000),
    (32, 24_000, 12_000),
    (48, 48_000, None),
    (64, 48_000, None),
)

_MUSIC_RUNGS: tuple[tuple[int, int, int | None], ...] = (
    (32, 24_000, 12_000),
    (48, 32_000, 15_000),
    (64, 48_000, None),
    (96, 48_000, None),
    (128, 48_000, None),
    (192, 48_000, None),
)


@dataclass(slots=True)
class AudioRung:
    """One rung of the ladder, with the reasoning that put it there."""

    params: AudioEncodeParams
    label: str

    @property
    def bitrate(self) -> int:
        return self.params.bitrate or 0


def build_ladder(
    source: AudioStreamInfo,
    analysis: ContentAnalysis,
    codec_family: CodecFamily,
    seed: AudioEncodeParams | None = None,
    *,
    max_channels: int | None = None,
) -> list[AudioRung]:
    """Ordered parameter sets from most aggressive to most faithful."""
    speech = bool(analysis.audio and analysis.audio.is_speech)
    mono_ok = bool(analysis.audio and analysis.audio.is_effectively_mono) or speech
    rungs_spec = _SPEECH_RUNGS if speech else _MUSIC_RUNGS

    source_channels = max(1, source.channels)
    ceiling = min(source_channels, max_channels or source_channels)
    codec = REGISTRY.get_audio(codec_family)

    ladder: list[AudioRung] = []
    for index, (kbps, rate, cutoff) in enumerate(rungs_spec):
        # The lowest rungs collapse to mono where the content permits it; the
        # upper rungs preserve the source layout so the ladder always ends
        # somewhere honest.
        channels = 1 if (mono_ok and index < len(rungs_spec) - 2) else ceiling
        rate = min(rate, source.sample_rate or rate)
        params = AudioEncodeParams(
            codec=codec_family,
            bitrate=max(6_000, kbps * 1_000 * channels),
            vbr=True,
            sample_rate=codec.nearest_sample_rate(rate),
            channels=channels,
            cutoff=cutoff if codec_family is CodecFamily.OPUS else None,
            application="voip"
            if (speech and codec_family is CodecFamily.OPUS and index < 3)
            else None,
        )
        ladder.append(
            AudioRung(
                params=params,
                label=f"{kbps}k/ch {channels}ch {params.sample_rate}Hz",
            )
        )

    if seed is not None:
        # Keep the planner's own choice in play: it encodes knowledge from the
        # content analysis that a generic ladder does not have.
        ladder.append(AudioRung(params=seed, label="planner"))
        ladder.sort(key=lambda rung: (rung.bitrate, rung.params.sample_rate or 0))

    # A ladder with duplicate rungs wastes encodes on identical settings.
    unique: list[AudioRung] = []
    seen: set[str] = set()
    for rung in ladder:
        key = rung.params.fingerprint()
        if key not in seen:
            seen.add(key)
            unique.append(rung)
    return unique


class AudioSearch:
    """Finds the lowest rung of the ladder that still clears the audio floor."""

    def __init__(self, evaluator: CandidateEvaluator, trace: SearchTrace | None = None) -> None:
        self.evaluator = evaluator
        self.trace = trace or SearchTrace()

    def run(self, seed: EncodePlan) -> tuple[AudioEncodeParams | None, CandidateResult | None]:
        media = self.evaluator.media
        source = media.primary_audio
        if source is None or seed.audio is None or seed.copy_audio:
            return (seed.audio, None)
        if seed.audio.codec is CodecFamily.FLAC:
            # Lossless audio has nothing to search: it either fits the policy or
            # the profile should not have asked for it.
            return (seed.audio, None)

        ladder = build_ladder(
            source,
            self.evaluator.analysis,
            seed.audio.codec,
            seed.audio,
            max_channels=self.evaluator.profile.audio_max_channels,
        )
        if not ladder:
            return (seed.audio, None)

        # Measure the ceiling first. Log-mel similarity saturates at a level
        # that depends on the material, so "is this good enough" can only be
        # answered against what this particular file can actually reach. One
        # extra audio-only encode buys a criterion that works on speech and on
        # orchestral music alike.
        ceiling_rung = ladder[-1]
        ceiling_result = self._evaluate(seed, ceiling_rung)
        ceiling = ceiling_result.quality.audio_score or 0.0
        tolerance = self.evaluator.search_quality.audio_relative_tolerance
        self.trace.note(f"audio ceiling for this file is {ceiling:.4f} at {ceiling_rung.label}")

        low, high = 0, len(ladder) - 2
        best_index: int | None = None
        best_result: CandidateResult | None = None
        budget = min(self.evaluator.config.search.max_iterations, 5)

        while low <= high and budget > 0:
            if self.evaluator.budget.exhausted:
                self.trace.note("audio search stopped: compute budget exhausted")
                break
            budget -= 1
            mid = (low + high) // 2
            rung = ladder[mid]
            result = self._evaluate(seed, rung)
            score = result.quality.audio_score or 0.0
            absolute, reasons = audio_meets_floor(result.quality, self.evaluator.search_quality)
            relative = score >= ceiling - tolerance
            passed = absolute or relative
            verdict = (
                "pass"
                if absolute
                else f"pass (within {tolerance:.3f} of ceiling)"
                if relative
                else "fail: " + "; ".join(reasons)
            )
            self.trace.note(f"audio {rung.label} -> {score:.4f} ({verdict})")
            if passed and result.ok:
                best_index, best_result = mid, result
                high = mid - 1
            else:
                low = mid + 1

        if best_index is None:
            # Nothing below the ceiling was acceptable, so the ceiling itself is
            # the answer. If that also failed the absolute floor, the caller
            # reports the shortfall rather than the platform quietly shipping
            # audio it cannot stand behind.
            self.trace.note(f"audio settled on the ceiling rung {ceiling_rung.label}")
            return (ceiling_rung.params, ceiling_result)

        chosen = ladder[best_index]
        self.trace.note(f"audio settled on {chosen.label}")
        return (chosen.params, best_result)

    def _evaluate(self, seed: EncodePlan, rung: AudioRung) -> CandidateResult:
        plan = EncodePlan(
            container=audio_only_container(rung.params.codec),
            video=None,
            audio=rung.params,
            keep_subtitles=False,
            keep_chapters=False,
            keep_all_audio_tracks=False,
            strip_metadata=seed.strip_metadata,
            faststart=False,
            label=f"audio:{rung.label}",
        )
        candidate = EncodeCandidate(plan=plan, origin="audio")
        return self.trace.add(self.evaluator.evaluate(candidate, audio_only=True))
