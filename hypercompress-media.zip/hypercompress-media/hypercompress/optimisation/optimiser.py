"""The optimiser facade.

Everything below this module is a mechanism; this is where policy chooses among
them. Given a source file, a profile and an optional size target, it decides
which search to run, runs it, and then re-encodes the winner over the full file
at full quality measurement.

That last step matters. The search works on samples for speed, and a sampled
measurement is an estimate. Shipping the sample-derived numbers as if they were
facts would be exactly the kind of quiet dishonesty this platform is supposed to
avoid, so the winning settings are always re-encoded and re-measured in full
before anything is written to the manifest.

The strategy table:

===================  ==============================================================
profile is lossless  encode once, verify the decoded output is bit-identical
target size given    :class:`~hypercompress.optimisation.target_size.TargetSizeSearch`
profile is EXTREME   :class:`~hypercompress.optimisation.extreme.ExtremeSearch`
otherwise            :class:`~hypercompress.optimisation.quality_search.QualitySearch`
===================  ==============================================================
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from hypercompress.analysis.complexity import ContentAnalyser
from hypercompress.analysis.media_probe import MediaProbe
from hypercompress.config import HyperCompressConfig
from hypercompress.core.errors import HyperCompressError, ValidationError
from hypercompress.core.ffmpeg import EncodeProgress, FFmpegRunner
from hypercompress.core.logging import get_logger, log_context
from hypercompress.core.types import (
    CandidateResult,
    ContentAnalysis,
    EncodePlan,
    MediaProfile,
    QualityReport,
    ResourceUsage,
)
from hypercompress.core.units import format_size
from hypercompress.optimisation.extreme import ExtremeSearch
from hypercompress.optimisation.planner import EncodePlanner
from hypercompress.optimisation.profiles import CompressionProfile, get_profile
from hypercompress.optimisation.quality_search import QualitySearch
from hypercompress.optimisation.search import (
    CandidateEvaluator,
    SearchBudget,
    SearchOutcome,
    SearchTrace,
)
from hypercompress.optimisation.target_size import SizeTarget, TargetSizeSearch
from hypercompress.quality.scoring import meets_floor

log = get_logger(__name__)

ProgressCallback = Callable[[EncodeProgress], None]


@dataclass(slots=True)
class OptimisationResult:
    """The complete, honest record of one optimisation."""

    source: Path
    output: Path | None
    media: MediaProfile
    analysis: ContentAnalysis
    profile_name: str
    plan: EncodePlan | None
    quality: QualityReport = field(default_factory=QualityReport)
    usage: ResourceUsage = field(default_factory=ResourceUsage)
    source_size: int = 0
    output_size: int = 0
    search_seconds: float = 0.0
    total_seconds: float = 0.0
    target_bytes: int | None = None
    target_met: bool | None = None
    quality_met: bool = False
    skipped: bool = False
    skip_reason: str = ""
    stop_reason: str = ""
    notes: list[str] = field(default_factory=list)
    candidates: list[dict[str, object]] = field(default_factory=list)

    @property
    def ratio(self) -> float:
        if self.source_size <= 0 or self.output_size <= 0:
            return 1.0
        return self.output_size / self.source_size

    @property
    def reduction(self) -> float:
        return 1.0 - self.ratio

    @property
    def bytes_saved(self) -> int:
        return max(0, self.source_size - self.output_size)

    def summary(self) -> str:
        if self.skipped:
            return f"{self.source.name}: left unchanged — {self.skip_reason}"
        if self.output is None:
            return f"{self.source.name}: no output produced — {self.stop_reason}"
        line = (
            f"{self.source.name}: {format_size(self.source_size)} -> "
            f"{format_size(self.output_size)} ({self.reduction:.1%} smaller)"
        )
        if self.quality.composite is not None:
            line += f", quality {self.quality.composite:.3f}"
        if not self.quality_met:
            line += " [below quality floor]"
        if self.target_met is False:
            line += " [target not met]"
        return line


class Optimiser:
    """End-to-end optimisation of a single file."""

    def __init__(
        self,
        config: HyperCompressConfig | None = None,
        runner: FFmpegRunner | None = None,
    ) -> None:
        self.base_config = config or HyperCompressConfig.load()
        self.runner = runner or FFmpegRunner()

    # -- public API ------------------------------------------------------------------
    def optimise(
        self,
        source: str | Path,
        output: str | Path,
        *,
        profile: str | CompressionProfile = "balanced",
        target_size: int | None = None,
        workdir: Path | None = None,
        on_progress: ProgressCallback | None = None,
        job_id: str | None = None,
    ) -> OptimisationResult:
        """Analyse, search, encode and verify one file."""
        started = time.monotonic()
        source = Path(source)
        output = Path(output)
        compression_profile = get_profile(profile) if isinstance(profile, str) else profile
        config = compression_profile.apply(self.base_config)

        with log_context(job_id=job_id or source.name):
            media = MediaProbe(self.runner).probe(source)
            analysis = ContentAnalyser(self.runner).analyse(media)
            log.info(
                "analysed source",
                extra={
                    "path": str(source),
                    "content_class": analysis.content_class.value,
                    "confidence": round(analysis.confidence, 3),
                    "size": media.size_bytes,
                },
            )

            result = OptimisationResult(
                source=source,
                output=None,
                media=media,
                analysis=analysis,
                profile_name=compression_profile.name,
                plan=None,
                source_size=media.size_bytes,
                target_bytes=target_size,
            )
            result.notes.append(
                f"classified as {analysis.content_class.value} "
                f"({analysis.confidence:.0%} confidence): {analysis.rationale[0] if analysis.rationale else ''}"
            )

            work = Path(workdir or config.scratch("search", source.stem))
            planner = EncodePlanner(self.runner.capabilities, config, compression_profile)
            seed = planner.initial_plan(media, analysis)
            result.plan = seed

            target = self._resolve_target(media, compression_profile, target_size, config)

            # A file that is already smaller than anything we would produce
            # should be left alone. Re-encoding it would cost compute and
            # quality to make it bigger.
            if target is None and compression_profile.copy_when_efficient:
                predicted = planner.predict_size(media, analysis, seed)
                worth, reason = planner.worth_encoding(media, predicted)
                if not worth:
                    result.skipped = True
                    result.skip_reason = reason
                    result.total_seconds = time.monotonic() - started
                    log.info("skipping re-encode", extra={"reason": reason})
                    return result

            evaluator = CandidateEvaluator(
                source=source,
                media=media,
                analysis=analysis,
                config=config,
                profile=compression_profile,
                runner=self.runner,
                workdir=work,
                budget=SearchBudget(self._budget_seconds(media, config)),
            )

            search_started = time.monotonic()
            outcome = self._search(evaluator, seed, compression_profile, target)
            result.search_seconds = time.monotonic() - search_started
            result.stop_reason = outcome.trace.stop_reason
            result.notes.extend(outcome.trace.notes)
            result.candidates = outcome.trace.rows()

            if outcome.best is None:
                result.total_seconds = time.monotonic() - started
                log.warning(
                    "optimisation produced no usable candidate",
                    extra={"stop_reason": result.stop_reason},
                )
                return result

            winner = outcome.best
            assert winner is not None
            result.plan = winner.candidate.plan

            final = self._final_encode(
                evaluator, winner, output, sampled=winner.sampled, on_progress=on_progress
            )
            result.output = Path(final.output_path) if final.output_path else None
            result.output_size = final.output_size
            result.quality = final.quality
            result.usage = final.usage.merge(self._search_usage(outcome.trace))
            result.quality_met = meets_floor(final.quality, config.quality)[0]
            if target is not None:
                result.target_met = target.contains(final.output_size)

            self._record_honest_notes(result, target, config)
            result.total_seconds = time.monotonic() - started
            log.info("optimisation complete", extra={"summary": result.summary()})
            return result

    # -- strategy --------------------------------------------------------------------
    def _search(
        self,
        evaluator: CandidateEvaluator,
        seed: EncodePlan,
        profile: CompressionProfile,
        target: SizeTarget | None,
    ) -> SearchOutcome:
        trace = SearchTrace()
        if profile.lossless:
            trace.note(
                "lossless profile: no search is possible or needed — the encoder either "
                "reproduces the input exactly or the result is rejected"
            )
            return QualitySearch(evaluator, trace).run(seed)
        if target is not None:
            return TargetSizeSearch(evaluator, trace).run(seed, target)
        if profile.extreme:
            return ExtremeSearch(evaluator, trace).run(seed)
        return QualitySearch(evaluator, trace).run(seed)

    def _resolve_target(
        self,
        media: MediaProfile,
        profile: CompressionProfile,
        target_size: int | None,
        config: HyperCompressConfig,
    ) -> SizeTarget | None:
        if target_size is not None:
            return SizeTarget(bytes_=target_size, tolerance=config.search.size_tolerance)
        if profile.target_size_ratio is not None:
            return SizeTarget(
                bytes_=int(media.size_bytes * profile.target_size_ratio),
                tolerance=config.search.size_tolerance,
            )
        return None

    def _budget_seconds(self, media: MediaProfile, config: HyperCompressConfig) -> float:
        policy = config.search
        if policy.compute_budget_seconds is not None:
            return policy.compute_budget_seconds
        return max(120.0, media.duration * policy.compute_budget_ratio)

    def _final_encode(
        self,
        evaluator: CandidateEvaluator,
        winner: CandidateResult,
        output: Path,
        *,
        sampled: bool,
        on_progress: ProgressCallback | None,
    ) -> CandidateResult:
        """Re-encode and re-measure the winning plan over the whole file.

        When the search already encoded the whole file, this is a copy of the
        winning artefact plus a full measurement rather than a wasted second
        encode.
        """
        plan = winner.candidate.plan
        if evaluator.media.primary_video is not None and plan.video is None and not plan.copy_video:
            # Reached only if a search nominated an audio-only candidate for a
            # file that has a picture. Failing loudly beats shipping a soundtrack
            # where a film should be, and beats validation catching it later with
            # no explanation of how it got there.
            raise ValidationError(
                "the search selected a plan with no video for a source that has video; "
                "this is a bug in candidate selection, not a property of the media"
            )
        if not sampled and winner.output_path and Path(winner.output_path).exists():
            output.parent.mkdir(parents=True, exist_ok=True)
            Path(winner.output_path).replace(output)
            final = winner.model_copy(update={"output_path": str(output)})
            final.quality = evaluator.measure_final(output)
            return final
        return evaluator.encode_final(plan, output, on_progress=on_progress)

    def _search_usage(self, trace: SearchTrace) -> ResourceUsage:
        total = ResourceUsage()
        for result in trace.results:
            total = total.merge(result.usage)
        return total

    def _record_honest_notes(
        self,
        result: OptimisationResult,
        target: SizeTarget | None,
        config: HyperCompressConfig,
    ) -> None:
        """Say plainly what the compression cost, in both directions."""
        if result.output_size <= 0:
            return

        if result.output_size >= result.source_size:
            result.notes.append(
                "the optimised file is no smaller than the source: this material is already "
                "efficiently encoded, and the original should be kept"
            )

        if not result.quality_met:
            _, reasons = meets_floor(result.quality, config.quality)
            result.notes.append(
                "the delivered file is below the configured quality floor ("
                + "; ".join(reasons)
                + ")"
            )

        if target is not None and result.target_met is False:
            result.notes.append(
                f"the {format_size(target.bytes_)} target was not reached; "
                f"{format_size(result.output_size)} is the smallest encode that this profile allows"
            )

        if result.quality.vmaf is None:
            estimate = next(
                (n for n in result.quality.notes if n.startswith("vmaf_estimate=")),
                None,
            )
            if estimate is not None:
                result.notes.append(
                    f"VMAF was not measured (libvmaf is not present in this FFmpeg build); "
                    f"the reported figure of {estimate.split('=', 1)[1]} is an estimate derived "
                    f"from MS-SSIM and PSNR, not a measurement"
                )


def optimise_file(
    source: str | Path,
    output: str | Path,
    *,
    profile: str = "balanced",
    target_size: int | None = None,
    config: HyperCompressConfig | None = None,
) -> OptimisationResult:
    """Convenience wrapper for one-shot optimisation."""
    try:
        return Optimiser(config).optimise(source, output, profile=profile, target_size=target_size)
    except HyperCompressError:
        raise
