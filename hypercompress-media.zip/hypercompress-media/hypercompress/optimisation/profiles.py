"""Compression profiles.

A profile is a *policy*, not a set of encoder flags. It says what the operator
cares about — bit-exactness, transparency, delivery size, ruthless reduction —
and the engine works out the flags for the specific file in front of it. Every
profile is data, so a site can ship its own without touching the engine.
"""

from __future__ import annotations

import json
import tomllib
from pathlib import Path
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from hypercompress.config import HyperCompressConfig
from hypercompress.core.errors import ConfigError
from hypercompress.core.types import CodecFamily, ContentClass


class CompressionProfile(BaseModel):
    """A named compression policy."""

    model_config = ConfigDict(extra="forbid")

    name: str
    description: str = ""
    lossless: bool = False
    """When true the engine guarantees bit-identical decoded output."""

    video_codecs: list[CodecFamily] = Field(
        default_factory=lambda: [CodecFamily.AV1, CodecFamily.HEVC]
    )
    audio_codecs: list[CodecFamily] = Field(
        default_factory=lambda: [CodecFamily.OPUS, CodecFamily.AAC]
    )
    container: str | None = None

    quality: dict[str, Any] = Field(default_factory=dict)
    """Overrides merged into :class:`~hypercompress.config.QualityPolicy`."""
    search: dict[str, Any] = Field(default_factory=dict)
    """Overrides merged into :class:`~hypercompress.config.SearchPolicy`."""

    preset_bias: float = 0.5
    """0 = fastest presets, 1 = slowest and most efficient."""
    target_size_ratio: float | None = None
    """When set, the engine aims for this fraction of the source size."""
    max_height: int | None = None
    max_frame_rate: float | None = None
    audio_bitrate_scale: float = 1.0
    audio_max_channels: int | None = None
    extreme: bool = False
    """Enables the iterative hard-compression search (Phase 09)."""
    copy_when_efficient: bool = True
    """Skip re-encoding when the source is already at or below the target rate."""
    two_pass: bool = False
    scene_aware: bool = True
    suits: list[ContentClass] = Field(default_factory=list)
    """Content classes this profile is the natural choice for."""

    @model_validator(mode="after")
    def _check(self) -> Self:
        if self.lossless and self.target_size_ratio is not None:
            raise ValueError("a lossless profile cannot promise a target size ratio")
        if not 0.0 <= self.preset_bias <= 1.0:
            raise ValueError("preset_bias must be within 0..1")
        return self

    def apply(self, config: HyperCompressConfig) -> HyperCompressConfig:
        """Return a configuration with this profile's policy merged in."""
        return config.merged_with(quality=self.quality, search=self.search, profile=self.name)


def _profile(name: str, description: str, **kwargs: Any) -> CompressionProfile:
    return CompressionProfile(name=name, description=description, **kwargs)


BUILT_IN_PROFILES: dict[str, CompressionProfile] = {
    "lossless": _profile(
        "lossless",
        "Bit-identical decoded output. Container and stream overhead are removed; "
        "the samples themselves are untouched.",
        lossless=True,
        video_codecs=[CodecFamily.HEVC, CodecFamily.H264],
        audio_codecs=[CodecFamily.FLAC],
        quality={
            "floor": 1.0,
            "vmaf_floor": None,
            "psnr_floor": None,
            "ssim_floor": None,
            "allow_resolution_reduction": False,
            "allow_channel_reduction": False,
            "allow_sample_rate_reduction": False,
            "preserve_all_audio_tracks": True,
        },
        search={"max_candidates": 1, "max_iterations": 1},
        preset_bias=0.8,
        copy_when_efficient=True,
        scene_aware=False,
    ),
    "archive": _profile(
        "archive",
        "Long-term cold storage. Maximum efficiency, encode time is nearly free "
        "because the file will be paid for every month for years.",
        video_codecs=[CodecFamily.AV1, CodecFamily.HEVC],
        audio_codecs=[CodecFamily.OPUS, CodecFamily.FLAC],
        quality={
            "floor": 0.93,
            "vmaf_floor": 95.0,
            "vmaf_low_percentile_floor": 90.0,
            "psnr_floor": 40.0,
            "ssim_floor": 0.975,
        },
        search={"max_candidates": 16, "max_iterations": 10, "compute_budget_ratio": 120.0},
        preset_bias=0.95,
        two_pass=False,
    ),
    "high_quality": _profile(
        "high_quality",
        "Visually transparent for critical viewing. Reduces size only where the "
        "reduction is genuinely invisible.",
        quality={
            "floor": 0.95,
            "vmaf_floor": 96.0,
            "vmaf_low_percentile_floor": 93.0,
            "psnr_floor": 42.0,
            "ssim_floor": 0.985,
        },
        search={"max_candidates": 10, "max_iterations": 7},
        preset_bias=0.75,
        suits=[ContentClass.FILM, ContentClass.DOCUMENTARY],
    ),
    "balanced": _profile(
        "balanced",
        "The default. Substantial reduction at a quality most viewers will not "
        "distinguish from the source.",
        quality={"floor": 0.90, "vmaf_floor": 93.0, "vmaf_low_percentile_floor": 88.0},
        search={"max_candidates": 8, "max_iterations": 6},
        preset_bias=0.5,
    ),
    "hard_compress": _profile(
        "hard_compress",
        "Aggressive reduction with a defended quality floor. Accepts visible "
        "softening on difficult content in exchange for large savings.",
        video_codecs=[CodecFamily.AV1, CodecFamily.HEVC],
        quality={
            "floor": 0.80,
            "vmaf_floor": 85.0,
            "vmaf_low_percentile_floor": 78.0,
            "psnr_floor": 34.0,
            "ssim_floor": 0.955,
            "allow_framerate_reduction": False,
        },
        search={"max_candidates": 14, "max_iterations": 9},
        preset_bias=0.7,
        audio_bitrate_scale=0.8,
    ),
    "extreme": _profile(
        "extreme",
        "Iterative search for the smallest representation that still clears the "
        "floor. Resolution reduction is permitted; the trade-off is measured and "
        "reported rather than hidden.",
        video_codecs=[CodecFamily.AV1, CodecFamily.HEVC, CodecFamily.VP9],
        quality={
            "floor": 0.72,
            "vmaf_floor": 78.0,
            "vmaf_low_percentile_floor": 68.0,
            "psnr_floor": 30.0,
            "ssim_floor": 0.93,
            "allow_resolution_reduction": True,
            "allow_channel_reduction": True,
            "min_height": 480,
        },
        search={
            "max_candidates": 24,
            "max_iterations": 14,
            "compute_budget_ratio": 200.0,
            "diminishing_returns_threshold": 0.008,
        },
        preset_bias=0.85,
        extreme=True,
        audio_bitrate_scale=0.65,
    ),
    "ultra": _profile(
        "ultra",
        "The smallest watchable representation. For bulk cold archives where "
        "storage cost dominates every other consideration.",
        video_codecs=[CodecFamily.AV1],
        quality={
            "floor": 0.55,
            "vmaf_floor": 62.0,
            "vmaf_low_percentile_floor": 50.0,
            "psnr_floor": 26.0,
            "ssim_floor": 0.90,
            "allow_resolution_reduction": True,
            "allow_framerate_reduction": True,
            "allow_channel_reduction": True,
            "allow_metadata_strip": True,
            "min_height": 360,
        },
        search={"max_candidates": 28, "max_iterations": 16, "compute_budget_ratio": 240.0},
        preset_bias=0.9,
        extreme=True,
        audio_bitrate_scale=0.5,
        max_height=1080,
    ),
    "mobile": _profile(
        "mobile",
        "Small screens and metered connections. Caps resolution at 720p and "
        "targets codecs every handset decodes in hardware.",
        video_codecs=[CodecFamily.HEVC, CodecFamily.H264],
        audio_codecs=[CodecFamily.AAC, CodecFamily.OPUS],
        container="mp4",
        quality={
            "floor": 0.82,
            "vmaf_floor": 88.0,
            "allow_resolution_reduction": True,
            "allow_channel_reduction": True,
            "min_height": 360,
        },
        search={"max_candidates": 8, "max_iterations": 6},
        preset_bias=0.4,
        max_height=720,
        audio_max_channels=2,
        audio_bitrate_scale=0.75,
    ),
    "web": _profile(
        "web",
        "Browser delivery. WebM-compatible codecs, faststart muxing and a 1080p ceiling.",
        video_codecs=[CodecFamily.AV1, CodecFamily.VP9, CodecFamily.H264],
        audio_codecs=[CodecFamily.OPUS, CodecFamily.AAC],
        quality={"floor": 0.86, "vmaf_floor": 91.0, "allow_resolution_reduction": True},
        search={"max_candidates": 10, "max_iterations": 6},
        preset_bias=0.55,
        max_height=1080,
    ),
    "streaming": _profile(
        "streaming",
        "Adaptive-bitrate origin. Fixed keyframe cadence and capped bitrate "
        "variability so segments align and buffers behave.",
        video_codecs=[CodecFamily.HEVC, CodecFamily.H264, CodecFamily.AV1],
        container="mp4",
        quality={"floor": 0.88, "vmaf_floor": 92.0, "vmaf_low_percentile_floor": 86.0},
        search={"max_candidates": 8, "max_iterations": 5},
        preset_bias=0.45,
        two_pass=True,
        scene_aware=False,
    ),
    "podcast": _profile(
        "podcast",
        "Speech-first audio. Mono where the channels are redundant, bandwidth "
        "limited to where the voice actually is.",
        audio_codecs=[CodecFamily.OPUS, CodecFamily.AAC],
        quality={
            "floor": 0.85,
            "audio_floor": 0.85,
            "audio_weight": 1.0,
            "video_weight": 0.0001,
            "allow_channel_reduction": True,
            "allow_sample_rate_reduction": True,
        },
        search={"max_candidates": 6, "max_iterations": 5},
        audio_bitrate_scale=0.55,
        audio_max_channels=1,
        suits=[ContentClass.PODCAST, ContentClass.INTERVIEW, ContentClass.LECTURE],
    ),
    "music": _profile(
        "music",
        "Preserves transients, stereo image and harmonic detail. Never collapses "
        "channels and never lowpasses aggressively.",
        audio_codecs=[CodecFamily.OPUS, CodecFamily.AAC],
        quality={
            "floor": 0.93,
            "audio_floor": 0.93,
            "audio_weight": 1.0,
            "video_weight": 0.0001,
            "allow_channel_reduction": False,
            "allow_sample_rate_reduction": False,
        },
        search={"max_candidates": 8, "max_iterations": 6},
        audio_bitrate_scale=1.15,
        suits=[ContentClass.MUSIC],
    ),
    "audiobook": _profile(
        "audiobook",
        "Long-form narration. The most compressible material there is: mono, "
        "band-limited, and heavily silence-padded.",
        audio_codecs=[CodecFamily.OPUS],
        quality={
            "floor": 0.80,
            "audio_floor": 0.80,
            "audio_weight": 1.0,
            "video_weight": 0.0001,
            "allow_channel_reduction": True,
            "allow_sample_rate_reduction": True,
        },
        search={"max_candidates": 6, "max_iterations": 5},
        audio_bitrate_scale=0.42,
        audio_max_channels=1,
        suits=[ContentClass.AUDIOBOOK],
    ),
    "cinema": _profile(
        "cinema",
        "Feature presentation masters. HDR and grain are preserved deliberately, "
        "because removing grain is removing the photography.",
        video_codecs=[CodecFamily.AV1, CodecFamily.HEVC],
        quality={
            "floor": 0.95,
            "vmaf_floor": 96.0,
            "vmaf_low_percentile_floor": 93.0,
            "preserve_hdr": True,
            "allow_resolution_reduction": False,
            "allow_framerate_reduction": False,
            "preserve_all_audio_tracks": True,
            "preserve_subtitles": True,
            "preserve_chapters": True,
        },
        search={"max_candidates": 12, "max_iterations": 8, "compute_budget_ratio": 150.0},
        preset_bias=0.9,
        suits=[ContentClass.FILM],
    ),
    "surveillance": _profile(
        "surveillance",
        "CCTV retention. Long GOPs, low frame rates and heavy reduction on the "
        "static majority of the footage, while keeping detail legible.",
        video_codecs=[CodecFamily.HEVC, CodecFamily.AV1],
        quality={
            "floor": 0.70,
            "vmaf_floor": 75.0,
            "psnr_floor": 30.0,
            "ssim_floor": 0.92,
            "allow_framerate_reduction": True,
            "allow_channel_reduction": True,
            "allow_metadata_strip": True,
            "min_frame_rate": 5.0,
        },
        search={"max_candidates": 10, "max_iterations": 7},
        preset_bias=0.8,
        max_frame_rate=15.0,
        audio_bitrate_scale=0.4,
        suits=[ContentClass.CCTV],
    ),
}


def load_profile_directory(directory: Path) -> dict[str, CompressionProfile]:
    """Load site-specific profiles from ``*.json`` / ``*.toml`` in a directory."""
    profiles: dict[str, CompressionProfile] = {}
    if not directory.exists():
        return profiles
    for path in sorted([*directory.glob("*.json"), *directory.glob("*.toml")]):
        try:
            if path.suffix == ".json":
                payload = json.loads(path.read_text())
            else:
                with path.open("rb") as handle:
                    payload = tomllib.load(handle)
        except (json.JSONDecodeError, tomllib.TOMLDecodeError) as exc:
            raise ConfigError(f"invalid profile file {path}: {exc}") from exc
        payload.setdefault("name", path.stem)
        profile = CompressionProfile(**payload)
        profiles[profile.name] = profile
    return profiles


def all_profiles(config: HyperCompressConfig | None = None) -> dict[str, CompressionProfile]:
    """Built-in profiles overlaid with any site-specific ones."""
    profiles = dict(BUILT_IN_PROFILES)
    if config is not None and config.profiles_dir is not None:
        profiles.update(load_profile_directory(config.profiles_dir))
    return profiles


def get_profile(name: str, config: HyperCompressConfig | None = None) -> CompressionProfile:
    profiles = all_profiles(config)
    key = name.strip().lower().replace("-", "_")
    if key not in profiles:
        raise ConfigError(f"unknown profile {name!r}. Available: {', '.join(sorted(profiles))}")
    return profiles[key]


def suggest_profile(
    content_class: ContentClass, config: HyperCompressConfig | None = None
) -> CompressionProfile:
    """The profile whose policy best matches a classified content type."""
    for profile in all_profiles(config).values():
        if content_class in profile.suits:
            return profile
    return BUILT_IN_PROFILES["balanced"]
