"""Phases 04, 05 and 07: turn analysis into a concrete encode plan.

This is where the platform's opinions live. Given what the file is, what it
contains and what the operator asked for, the planner selects codecs, geometry,
rate control, GOP structure and audio configuration — and, just as importantly,
decides when the honest answer is "leave this file alone".
"""

from __future__ import annotations

from dataclasses import dataclass, field

from hypercompress.analysis.audio_analysis import (
    recommended_channels,
    recommended_cutoff,
    recommended_sample_rate,
)
from hypercompress.analysis.containers import (
    audio_only_container,
    choose_container,
    container_supports,
)
from hypercompress.analysis.video_analysis import estimate_bits_per_pixel
from hypercompress.codecs.base import REGISTRY, AudioCodec, VideoCodec
from hypercompress.codecs.hardware import HARDWARE_BITRATE_PENALTY
from hypercompress.config import CodecPolicy, HyperCompressConfig
from hypercompress.core.ffmpeg import FFmpegCapabilities
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    AudioEncodeParams,
    CodecFamily,
    ContentAnalysis,
    ContentClass,
    EncodePlan,
    HardwareVendor,
    MediaKind,
    MediaProfile,
    RateControl,
    VideoEncodeParams,
    scale_to_height,
)
from hypercompress.optimisation.profiles import CompressionProfile

log = get_logger("optimisation.planner")

#: Software encoding throughput baseline: pixels per second for libx264 at
#: ``medium`` on one modern core. Everything else is scaled from this. The
#: benchmark suite recalibrates it per host.
BASELINE_PIXELS_PER_SECOND = 6.5e6


@dataclass(slots=True)
class CodecChoice:
    """A ranked codec selection with its reasoning."""

    codec: VideoCodec | AudioCodec
    score: float
    rationale: list[str] = field(default_factory=list)

    @property
    def family(self) -> CodecFamily:
        return self.codec.family


def estimate_encode_seconds(
    *,
    width: int,
    height: int,
    frame_rate: float,
    duration: float,
    codec: VideoCodec,
    preset: str,
    cpu_count: int = 1,
    hardware: HardwareVendor = HardwareVendor.CPU,
) -> float:
    """Predict wall-clock encode time for a video candidate."""
    pixels = width * height * max(frame_rate, 1.0) * max(duration, 0.0)
    throughput = BASELINE_PIXELS_PER_SECOND * max(1, cpu_count) * 0.75
    seconds = pixels / throughput * codec.speed_cost * codec.preset_speed(preset)
    if hardware is not HardwareVendor.CPU:
        from hypercompress.codecs.hardware import HARDWARE_SPEEDUP

        seconds /= HARDWARE_SPEEDUP.get(hardware, 10.0)
    return float(seconds)


class EncodePlanner:
    """Builds the initial encode plan and the seed candidates for the search."""

    def __init__(
        self,
        capabilities: FFmpegCapabilities,
        config: HyperCompressConfig,
        profile: CompressionProfile,
    ) -> None:
        self.caps = capabilities
        self.config = config
        self.profile = profile
        self.policy: CodecPolicy = config.codecs

    # -- Phase 04: codec selection ------------------------------------------------
    def rank_video_codecs(
        self,
        source: MediaProfile,
        analysis: ContentAnalysis,
        *,
        container: str | None = None,
    ) -> list[CodecChoice]:
        """Rank available video codecs for this specific file.

        Newer is not automatically better: AV1's efficiency is worthless if the
        job is a 20-second clip whose encode will cost more than the bytes it
        saves, or if the delivery target cannot decode it.
        """
        video = source.primary_video
        choices: list[CodecChoice] = []
        allowed = set(self.policy.video_allowlist)
        preference = {
            family: len(self.profile.video_codecs) - i
            for i, family in enumerate(self.profile.video_codecs)
        }

        for family in allowed:
            try:
                codec = REGISTRY.get_video(family)
            except Exception:  # noqa: BLE001 - unregistered codec
                continue
            if not codec.is_available(self.caps):
                continue
            rationale: list[str] = []
            if container and not container_supports(container, family):
                continue
            if video is not None and video.bit_depth > 8 and not codec.supports_10bit:
                continue
            if source.has_hdr and self.config.quality.preserve_hdr and not codec.supports_hdr:
                rationale.append("excluded: cannot carry HDR signalling")
                continue

            # Efficiency is the dominant term: it is the reason this platform exists.
            score = (1.0 - codec.efficiency) * 4.0
            rationale.append(
                f"{(1 - codec.efficiency) * 100:.0f}% fewer bits than H.264 at equal quality"
            )

            if self.policy.require_broad_compatibility:
                score += codec.compatibility * 3.0
                rationale.append(f"playback compatibility {codec.compatibility:.0%}")
            else:
                score += codec.compatibility * 0.6

            score += preference.get(family, 0) * 0.35
            if family in self.profile.video_codecs:
                rationale.append(f"preferred by the {self.profile.name} profile")

            # Encode cost, expressed against the duration it has to pay back.
            if video is not None and source.duration > 0:
                seconds = estimate_encode_seconds(
                    width=video.width,
                    height=video.height,
                    frame_rate=video.frame_rate or 25.0,
                    duration=source.duration,
                    codec=codec,
                    preset=self._preset_for(codec),
                    cpu_count=self.config.distributed.worker_concurrency,
                )
                realtime_ratio = seconds / max(source.duration, 1e-6)
                score -= min(realtime_ratio / self.policy.max_encode_speed_penalty, 1.2)
                rationale.append(f"~{realtime_ratio:.1f}x realtime to encode")

            if analysis.content_class in {ContentClass.ANIMATION, ContentClass.SCREEN_RECORDING}:
                if family in {CodecFamily.AV1, CodecFamily.VP9}:
                    score += 0.5
                    rationale.append("flat-region content suits AV1/VP9 transforms")
            if (
                analysis.video is not None
                and analysis.video.grain > 0.5
                and family is CodecFamily.AV1
            ):
                score += 0.4
                rationale.append("AV1 film-grain synthesis handles grainy sources efficiently")

            choices.append(CodecChoice(codec=codec, score=score, rationale=rationale))

        choices.sort(key=lambda c: c.score, reverse=True)
        return choices[: max(1, self.config.search.max_codecs_considered)]

    def rank_audio_codecs(
        self, source: MediaProfile, analysis: ContentAnalysis
    ) -> list[CodecChoice]:
        """Rank audio codecs, respecting lossless-source policy."""
        audio = source.primary_audio
        choices: list[CodecChoice] = []
        speech = analysis.audio.is_speech if analysis.audio else False
        preference = {
            family: len(self.profile.audio_codecs) - i
            for i, family in enumerate(self.profile.audio_codecs)
        }

        for family in self.policy.audio_allowlist:
            try:
                codec = REGISTRY.get_audio(family)
            except Exception:  # noqa: BLE001
                continue
            if not codec.is_available(self.caps):
                continue
            rationale: list[str] = []
            if self.profile.lossless and not codec.lossless:
                continue
            if (
                audio is not None
                and audio.is_lossless
                and self.policy.never_transcode_lossless_to_lossy
                and not codec.lossless
            ):
                continue

            score = (1.0 - min(codec.efficiency, 2.0)) * 2.0 + preference.get(family, 0) * 0.5
            if codec.lossless:
                score = 0.5 + preference.get(family, 0) * 0.5
                rationale.append("bit-exact reconstruction")
            else:
                rationale.append(
                    f"{(1 - codec.efficiency) * 100:.0f}% fewer bits than AAC at equal quality"
                )
            if speech and family is CodecFamily.OPUS:
                score += 1.2
                rationale.append("Opus is materially better than AAC for speech at low rates")
            if self.policy.require_broad_compatibility:
                score += codec.compatibility * 1.5
            choices.append(CodecChoice(codec=codec, score=score, rationale=rationale))

        choices.sort(key=lambda c: c.score, reverse=True)

        # A profile that names its container is prescriptive about delivery: its
        # codec ordering expresses a compatibility requirement, so it outranks
        # what the engine would otherwise pick on efficiency alone.
        if self.profile.container and self.profile.audio_codecs:
            order = {family: i for i, family in enumerate(self.profile.audio_codecs)}
            choices.sort(key=lambda c: (order.get(c.family, len(order)), -c.score))
            if choices and choices[0].family in order:
                choices[0].rationale.append(
                    f"the {self.profile.name} profile prescribes this codec for {self.profile.container} delivery"
                )
        return choices

    # -- Phase 05: video parameters ----------------------------------------------
    def _preset_for(self, codec: VideoCodec) -> str:
        """Map the profile's speed/efficiency bias onto this codec's preset list."""
        presets = codec.presets or (codec.default_preset,)
        # Presets are ordered fastest-to-slowest for x264/x265 and slowest-to-fastest
        # for SVT-AV1, so order by measured relative cost instead of list position.
        ordered = sorted(presets, key=lambda p: codec.preset_speed(p))
        index = int(round(self.profile.preset_bias * (len(ordered) - 1)))
        return ordered[max(0, min(index, len(ordered) - 1))]

    def video_params(
        self,
        source: MediaProfile,
        analysis: ContentAnalysis,
        codec: VideoCodec,
        *,
        crf: float | None = None,
        height_override: int | None = None,
        hardware: HardwareVendor = HardwareVendor.CPU,
    ) -> VideoEncodeParams:
        """Build a complete, validated video parameter set."""
        video = source.primary_video
        if video is None:
            raise ValueError("cannot build video parameters for a file with no video stream")

        quality = self.config.quality
        frame_rate = video.frame_rate or video.avg_frame_rate or 25.0
        width, height = video.width, video.height

        ceiling = (
            min(filter(None, [self.profile.max_height, height_override or None]))
            if (self.profile.max_height or height_override)
            else None
        )
        if height_override is not None:
            ceiling = height_override
        if ceiling is not None and height > ceiling:
            if quality.allow_resolution_reduction or self.profile.max_height is not None:
                width, height = scale_to_height(
                    video.width, video.height, max(ceiling, quality.min_height)
                )

        target_fps: float | None = None
        if (
            self.profile.max_frame_rate
            and frame_rate > self.profile.max_frame_rate
            and quality.allow_framerate_reduction
        ):
            target_fps = max(quality.min_frame_rate, self.profile.max_frame_rate)

        # 10-bit encoding of 8-bit sources reduces banding and usually costs
        # nothing in size, so it is preserved or promoted where the codec allows.
        pix_fmt = video.pix_fmt
        if codec.supports_10bit and video.bit_depth >= 10:
            pix_fmt = "yuv420p10le"
        elif not codec.supports_10bit or video.bit_depth <= 8:
            pix_fmt = "yuv420p"

        # Two seconds of GOP is the streaming convention; static content tolerates
        # far longer GOPs, which is where surveillance footage makes its savings.
        keyint = int(round(frame_rate * 2))
        if analysis.video is not None and analysis.video.static_ratio > 0.6:
            keyint = int(round(frame_rate * 10))
        if self.profile.name == "surveillance":
            keyint = int(round((target_fps or frame_rate) * 20))

        if self.profile.lossless:
            # A lossless profile makes a mathematical promise, so rate control is
            # taken out of the picture entirely rather than set to a low CRF.
            return VideoEncodeParams(
                codec=codec.family,
                rate_control=RateControl.LOSSLESS,
                crf=None,
                preset=self._preset_for(codec),
                pix_fmt=pix_fmt,
                keyint=int(round(frame_rate * 2)),
                threads=self.config.ffmpeg.threads or None,
                hardware=HardwareVendor.CPU,
                preserve_hdr=source.has_hdr,
                deinterlace=False,
            )

        crf_value = crf if crf is not None else codec.crf_for_vmaf(quality.vmaf_floor or 93.0)
        film_grain = None
        if (
            codec.family is CodecFamily.AV1
            and analysis.video is not None
            and analysis.video.grain > 0.5
        ):
            film_grain = int(min(50, analysis.video.grain * 40))

        return VideoEncodeParams(
            codec=codec.family,
            rate_control=RateControl.CRF,
            crf=float(min(max(crf_value, codec.crf_range[0]), codec.crf_range[1])),
            preset=self._preset_for(codec),
            width=width if (width, height) != (video.width, video.height) else None,
            height=height if (width, height) != (video.width, video.height) else None,
            frame_rate=target_fps,
            pix_fmt=pix_fmt,
            keyint=keyint,
            min_keyint=max(1, keyint // 4),
            scene_cut=self.profile.scene_aware,
            film_grain=film_grain,
            threads=self.config.ffmpeg.threads or None,
            hardware=hardware,
            preserve_hdr=quality.preserve_hdr and source.has_hdr,
            deinterlace=video.is_interlaced,
        )

    # -- Phase 07: audio parameters ----------------------------------------------
    def audio_params(
        self,
        source: MediaProfile,
        analysis: ContentAnalysis,
        codec: AudioCodec,
        *,
        bitrate_scale: float = 1.0,
    ) -> AudioEncodeParams:
        """Build a complete, validated audio parameter set."""
        audio = source.primary_audio
        if audio is None:
            raise ValueError("cannot build audio parameters for a file with no audio stream")

        quality = self.config.quality
        complexity = analysis.audio
        speech = complexity.is_speech if complexity else False

        channels = audio.channels
        if quality.allow_channel_reduction and complexity is not None:
            channels = recommended_channels(complexity, audio.channels)
        if self.profile.audio_max_channels:
            channels = min(channels, self.profile.audio_max_channels)

        sample_rate = audio.sample_rate
        if quality.allow_sample_rate_reduction and complexity is not None:
            sample_rate = recommended_sample_rate(complexity, audio.sample_rate)
        sample_rate = codec.nearest_sample_rate(sample_rate)

        if codec.lossless:
            return AudioEncodeParams(
                codec=codec.family,
                bitrate=None,
                quality=None,
                compression_level=8,
                channels=channels if channels != audio.channels else None,
                sample_rate=sample_rate if sample_rate != audio.sample_rate else None,
            )

        transparent = codec.transparent_bitrate(channels, speech=speech, sample_rate=sample_rate)
        bitrate = int(transparent * bitrate_scale * self.profile.audio_bitrate_scale)
        # Never spend more than the source already spends.
        if audio.bit_rate:
            bitrate = min(bitrate, int(audio.bit_rate * 0.95))
        bitrate = max(bitrate, 8_000 * max(1, channels))

        cutoff = None
        if complexity is not None and codec.family is CodecFamily.OPUS:
            cutoff = recommended_cutoff(complexity)

        return AudioEncodeParams(
            codec=codec.family,
            bitrate=bitrate,
            vbr=True,
            channels=channels,
            sample_rate=sample_rate,
            application="voip"
            if speech and codec.family is CodecFamily.OPUS
            else ("audio" if codec.family is CodecFamily.OPUS else None),
            cutoff=cutoff,
            downmix_surround=channels < audio.channels,
        )

    # -- assembly -----------------------------------------------------------------
    def initial_plan(
        self,
        source: MediaProfile,
        analysis: ContentAnalysis,
        *,
        hardware: HardwareVendor = HardwareVendor.CPU,
    ) -> EncodePlan:
        """The first plan the search starts from."""
        quality = self.config.quality
        video_family: CodecFamily | None = None
        audio_family: CodecFamily | None = None
        video_params = None
        audio_params = None

        if source.primary_audio is not None:
            audio_choices = self.rank_audio_codecs(source, analysis)
            if audio_choices:
                audio_codec = audio_choices[0].codec
                assert isinstance(audio_codec, AudioCodec)
                audio_family = audio_codec.family
                audio_params = self.audio_params(source, analysis, audio_codec)

        if source.primary_video is not None:
            container_hint = self.profile.container
            video_choices = self.rank_video_codecs(source, analysis, container=container_hint)
            if video_choices:
                video_codec = video_choices[0].codec
                assert isinstance(video_codec, VideoCodec)
                video_family = video_codec.family
                video_params = self.video_params(source, analysis, video_codec, hardware=hardware)

        need_subtitles = bool(source.subtitles) and quality.preserve_subtitles
        if source.kind is MediaKind.AUDIO and audio_family is not None:
            container = self.profile.container or audio_only_container(audio_family)
        else:
            container = choose_container(
                video_family,
                audio_family,
                preferred=self.profile.container,
                need_subtitles=need_subtitles,
            )

        return EncodePlan(
            container=container,
            video=video_params,
            audio=audio_params,
            keep_subtitles=need_subtitles,
            keep_chapters=quality.preserve_chapters and bool(source.chapters),
            keep_all_audio_tracks=quality.preserve_all_audio_tracks and len(source.audio) > 1,
            strip_metadata=quality.allow_metadata_strip,
            faststart=container == "mp4",
            label=f"{self.profile.name}:seed",
        )

    def container_for(self, video_family: CodecFamily | None, plan: EncodePlan) -> str:
        """The container to use when a plan's video codec changes underneath it.

        Swapping AV1 for HEVC inside an unchanged WebM container would produce a
        file that no player will open, so the container has to follow the codec.
        """
        audio_family = plan.audio.codec if plan.audio is not None else None
        if video_family is None and audio_family is not None:
            return self.profile.container or audio_only_container(audio_family)
        return choose_container(
            video_family,
            audio_family,
            preferred=self.profile.container,
            need_subtitles=plan.keep_subtitles,
        )

    # -- Phase 20: honesty about what is achievable -------------------------------
    def predict_size(
        self, source: MediaProfile, analysis: ContentAnalysis, plan: EncodePlan
    ) -> int:
        """Predict the output size of a plan before encoding anything."""
        duration = max(source.duration, 1e-6)
        total_bits = 0.0

        if plan.video is not None and source.primary_video is not None:
            video = source.primary_video
            codec = REGISTRY.get_video(plan.video.codec)
            width = plan.video.width or video.width
            height = plan.video.height or video.height
            fps = plan.video.frame_rate or video.frame_rate or 25.0
            bpp = (
                estimate_bits_per_pixel(analysis.video, quality_floor=self.config.quality.floor)
                if analysis.video is not None
                else 0.05
            )
            # CRF moves the rate away from the quality-floor anchor point.
            anchor_crf = codec.crf_for_vmaf(self.config.quality.vmaf_floor or 93.0)
            crf_delta = (plan.video.crf or anchor_crf) - anchor_crf
            crf_factor = 2.0 ** (-crf_delta / 6.0)
            bitrate = (
                codec.estimate_bitrate(
                    width=width, height=height, frame_rate=fps, bits_per_pixel=bpp
                )
                * crf_factor
            )
            bitrate *= HARDWARE_BITRATE_PENALTY.get(plan.video.hardware, 1.0)
            total_bits += bitrate * duration
        elif plan.copy_video and source.primary_video is not None:
            total_bits += (source.primary_video.bit_rate or 0) * duration

        if plan.audio is not None and source.primary_audio is not None:
            if plan.audio.codec is CodecFamily.FLAC:
                audio = source.primary_audio
                depth = audio.bits_per_raw_sample or 16
                channels = plan.audio.channels or audio.channels
                rate = plan.audio.sample_rate or audio.sample_rate
                speech = analysis.audio.is_speech if analysis.audio else False
                total_bits += rate * channels * depth * (0.45 if speech else 0.62) * duration
            else:
                total_bits += (plan.audio.bitrate or 0) * duration
        elif plan.copy_audio and source.primary_audio is not None:
            total_bits += (source.primary_audio.bit_rate or 0) * duration

        overhead = 1.006 if plan.container in {"mkv", "mp4"} else 1.002
        return int(total_bits / 8 * overhead)

    def worth_encoding(self, source: MediaProfile, predicted_size: int) -> tuple[bool, str]:
        """Decide whether a re-encode earns its compute.

        Re-encoding a file to save 2% burns CPU, risks generational quality loss
        and produces a new object to store and verify. The threshold makes that
        judgement explicit and configurable rather than implicit.
        """
        if source.size_bytes <= 0:
            return True, "unknown source size"
        saving = 1.0 - (predicted_size / source.size_bytes)
        if saving < self.policy.reencode_threshold:
            return False, (
                f"predicted saving {saving:.1%} is below the {self.policy.reencode_threshold:.1%} "
                "threshold; the source is already efficiently encoded"
            )
        return True, f"predicted saving {saving:.1%}"
