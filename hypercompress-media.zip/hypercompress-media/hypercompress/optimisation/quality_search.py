"""Quality-floor search.

The default question this platform answers is not "how small can this get" but
"how small can this get *while still looking the same*". That makes CRF the
control variable and the perceptual floor the constraint.

The search is a bracketed bisection rather than a scan. It starts from the
codec's anchor curve, which usually lands within two or three CRF points of the
answer, expands outwards until it has one passing and one failing setting, then
halves the interval. Each halving costs one encode, so the whole search
typically resolves in five or six encodes of a few seconds of footage.

Two details matter for correctness:

* **Monotonicity is assumed, but verified.** Quality falls as CRF rises. If a
  measurement contradicts that — which happens near the noise floor of the
  metrics — the bracket is not blindly trusted; the result is recorded and the
  bisection continues from the last consistent bound.
* **The bracket is returned, not just the winner.** Callers that need to hit a
  size target start from this bracket rather than from scratch.
"""

from __future__ import annotations

from dataclasses import dataclass

from hypercompress.codecs import REGISTRY
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    CandidateResult,
    EncodeCandidate,
    EncodePlan,
    RateControl,
)
from hypercompress.optimisation.audio_search import AudioSearch
from hypercompress.optimisation.search import CandidateEvaluator, SearchOutcome, SearchTrace
from hypercompress.quality.scoring import video_meets_floor

log = get_logger(__name__)

#: Stop bisecting once the bracket is this narrow; below it the size difference
#: is smaller than the run-to-run variance of the encoders themselves.
CRF_RESOLUTION = 0.6


@dataclass(slots=True)
class CrfBracket:
    """The interval the search has narrowed the answer to."""

    passing_crf: float | None = None
    failing_crf: float | None = None
    passing: CandidateResult | None = None
    failing: CandidateResult | None = None

    @property
    def resolved(self) -> bool:
        if self.passing_crf is None or self.failing_crf is None:
            return False
        return abs(self.failing_crf - self.passing_crf) <= CRF_RESOLUTION

    def midpoint(self) -> float | None:
        if self.passing_crf is None or self.failing_crf is None:
            return None
        return (self.passing_crf + self.failing_crf) / 2.0


def with_crf(plan: EncodePlan, crf: float, *, label: str) -> EncodePlan:
    """A copy of ``plan`` at a different CRF."""
    if plan.video is None:
        return plan
    codec = REGISTRY.get_video(plan.video.codec)
    lo, hi = codec.crf_range
    video = plan.video.model_copy(
        update={"crf": round(float(min(max(crf, lo), hi)), 1), "rate_control": RateControl.CRF}
    )
    return plan.model_copy(update={"video": video, "label": label})


def with_audio(plan: EncodePlan, audio: object, *, label: str) -> EncodePlan:
    """A copy of ``plan`` carrying a different audio parameter set."""
    return plan.model_copy(update={"audio": audio, "label": label})


class QualitySearch:
    """Finds the largest CRF whose measured quality still clears the floor."""

    def __init__(self, evaluator: CandidateEvaluator, trace: SearchTrace | None = None) -> None:
        self.evaluator = evaluator
        self.trace = trace or SearchTrace()

    def run(self, seed: EncodePlan, *, generation: int = 0) -> SearchOutcome:
        """Search around ``seed`` and return the smallest passing encode.

        Audio is settled first, on its own ladder and without video, because the
        two are driven by different controls and a failing audio track would
        otherwise drag the CRF search downwards without ever fixing the cause.
        """
        seed = self._settle_audio(seed)

        if seed.video is None or seed.video.rate_control is RateControl.LOSSLESS:
            return self._audio_only(seed, generation=generation)

        policy = self.evaluator.config.search
        bracket = CrfBracket()
        crf = float(seed.video.crf or 30.0)
        codec = REGISTRY.get_video(seed.video.codec)
        lo, hi = codec.crf_range

        for iteration in range(policy.max_iterations):
            if self.evaluator.budget.exhausted:
                self.trace.stop_reason = "compute budget exhausted"
                break

            plan = with_crf(seed, crf, label=f"quality:crf{crf:g}")
            result = self.trace.add(
                self.evaluator.evaluate(
                    EncodeCandidate(plan=plan, generation=generation, origin="quality")
                )
            )
            self.trace.iterations += 1

            if not result.ok:
                self.trace.note(f"crf {crf:g} failed to encode; treating as unusable")
                bracket.failing_crf, bracket.failing = crf, result
                crf = self._step_down(bracket, crf, lo)
                continue

            passed, reasons = video_meets_floor(result.quality, self.evaluator.search_quality)
            self.trace.note(
                f"crf {crf:g} -> video {result.quality.video_score or 0:.4f} "
                f"({'pass' if passed else 'fail: ' + '; '.join(reasons)}), "
                f"{result.effective_size / 1e6:.2f} MB"
            )

            if passed:
                if bracket.passing_crf is None or crf > bracket.passing_crf:
                    bracket.passing_crf, bracket.passing = crf, result
            else:
                if bracket.failing_crf is None or crf < bracket.failing_crf:
                    bracket.failing_crf, bracket.failing = crf, result

            if bracket.resolved:
                self.trace.stop_reason = "crf bracket resolved"
                break

            midpoint = bracket.midpoint()
            if midpoint is not None:
                crf = midpoint
            elif passed:
                crf = self._step_up(bracket, crf, hi)
            else:
                crf = self._step_down(bracket, crf, lo)

            if iteration == policy.max_iterations - 1:
                self.trace.stop_reason = "iteration limit reached"

        return self._finish(bracket, seed)

    # -- internals ---------------------------------------------------------------
    def _step_up(self, bracket: CrfBracket, crf: float, ceiling: float) -> float:
        """Nothing has failed yet, so reach for a coarser setting."""
        limit = bracket.failing_crf if bracket.failing_crf is not None else ceiling
        return (
            min(ceiling, min(limit - CRF_RESOLUTION, crf + 4.0))
            if limit > crf
            else min(ceiling, crf + 4.0)
        )

    def _step_down(self, bracket: CrfBracket, crf: float, floor: float) -> float:
        """Quality is short, so reach for a finer setting."""
        limit = bracket.passing_crf if bracket.passing_crf is not None else floor
        return (
            max(floor, max(limit + CRF_RESOLUTION, crf - 4.0))
            if limit < crf
            else max(floor, crf - 4.0)
        )

    def _settle_audio(self, seed: EncodePlan) -> EncodePlan:
        """Choose audio parameters before spending anything on video."""
        if seed.audio is None or seed.copy_audio:
            return seed
        params, _ = AudioSearch(self.evaluator, self.trace).run(seed)
        if params is None or params.fingerprint() == seed.audio.fingerprint():
            return seed
        return with_audio(seed, params, label=f"{seed.label}+audio")

    def _finish(self, bracket: CrfBracket, seed: EncodePlan) -> SearchOutcome:
        best = bracket.passing
        if best is None:
            # Nothing cleared the floor. The honest outcome is the highest
            # quality attempt we made, flagged as not meeting the policy, rather
            # than a silent pass on something that looks worse than promised.
            candidates = [
                r
                for r in self.trace.successful
                if r.candidate.origin == "quality" and self.evaluator.represents_source(r)
            ]
            best = (
                max(candidates, key=lambda r: r.quality.video_score or r.quality_score)
                if candidates
                else None
            )
            if best is not None:
                self.trace.note(
                    "no setting cleared the quality floor; returning the best measured attempt "
                    "and reporting the shortfall"
                )
        if not self.trace.stop_reason:
            self.trace.stop_reason = "search complete"

        quality_met = (
            best is not None and video_meets_floor(best.quality, self.evaluator.search_quality)[0]
        )
        ratio = (best.effective_size / best.source_size) if best and best.source_size else 1.0
        return SearchOutcome(
            best=best,
            trace=self.trace,
            target_met=False,
            quality_met=quality_met,
            achieved_ratio=ratio,
        )

    def _audio_only(self, seed: EncodePlan, *, generation: int) -> SearchOutcome:
        """No video to search: the plan is either lossless or pure audio."""
        result = self.trace.add(
            self.evaluator.evaluate(
                EncodeCandidate(plan=seed, generation=generation, origin="quality"),
                audio_only=seed.video is None,
            )
        )
        self.trace.iterations += 1
        if not self.trace.stop_reason:
            self.trace.stop_reason = (
                "lossless plan needs no search"
                if seed.video is not None
                else "audio settled on the ladder"
            )
        passed, reasons = self.evaluator.passes_floor(result)
        if reasons:
            self.trace.note("; ".join(reasons))
        return SearchOutcome(
            best=result,
            trace=self.trace,
            quality_met=passed,
            achieved_ratio=(result.effective_size / result.source_size)
            if result.source_size
            else 1.0,
        )
