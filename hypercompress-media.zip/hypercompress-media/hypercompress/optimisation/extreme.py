"""EXTREME hard-compression search (Phase 09).

The quality-floor search answers "what is the best CRF for this codec at this
resolution". EXTREME asks the broader question: *across every codec and every
resolution this profile permits, what is the smallest file that still clears the
floor?*

That is a bigger space, and the reason it is worth searching is that the answer
is frequently not the one CRF tuning would give. Dropping 1080p to 720p and
re-tuning often beats squeezing 1080p, because a codec starved of bits spends
them on blocking artefacts rather than on detail. Likewise AV1 usually wins on
size but not always: on short, high-motion, grainy content its overheads can
leave it behind a well-tuned HEVC encode.

The loop is explicit about when to stop, because an unbounded search on a large
library is a way to spend more on compute than the storage was ever worth:

* **target met** — a size target was supplied and has been reached;
* **floor reached** — every direction from here breaches the quality floor;
* **diminishing returns** — the last generation bought less than the configured
  fraction of the size;
* **budget exhausted** — the compute allowance for this file is spent;
* **space exhausted** — every permitted combination has been tried.

Nothing here promises lossless reduction. Every byte saved past the codec's
lossless mode is paid for in fidelity; the search's whole purpose is to find the
settings where that payment buys the most.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from hypercompress.codecs import REGISTRY
from hypercompress.codecs.base import VideoCodec
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    CandidateResult,
    CodecFamily,
    EncodePlan,
    HardwareVendor,
    ladder_below,
)
from hypercompress.core.units import format_size
from hypercompress.optimisation.quality_search import QualitySearch
from hypercompress.optimisation.search import (
    CandidateEvaluator,
    SearchOutcome,
    SearchTrace,
    diminishing,
)
from hypercompress.optimisation.target_size import SizeTarget

log = get_logger(__name__)


@dataclass(slots=True)
class Arm:
    """One (codec, resolution) branch of the search."""

    codec: CodecFamily
    height: int
    rationale: str = ""
    result: CandidateResult | None = None

    @property
    def label(self) -> str:
        return f"{self.codec.value}@{self.height}p"


@dataclass(slots=True)
class ExtremeReport:
    """What EXTREME learned, in a form worth showing a human."""

    arms: list[Arm] = field(default_factory=list)
    winner: Arm | None = None
    generations: int = 0

    def table(self) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        for arm in self.arms:
            if arm.result is None:
                continue
            row = arm.result.row()
            row["arm"] = arm.label
            row["winner"] = arm is self.winner
            rows.append(row)
        return rows


class ExtremeSearch:
    """Searches codecs and resolutions for the smallest encode at the floor."""

    def __init__(self, evaluator: CandidateEvaluator, trace: SearchTrace | None = None) -> None:
        self.evaluator = evaluator
        self.trace = trace or SearchTrace()
        self.report = ExtremeReport()

    def run(self, seed: EncodePlan, *, target: SizeTarget | None = None) -> SearchOutcome:
        if seed.video is None:
            # With no video there is no codec/resolution space to explore, so
            # the ordinary quality search is already the complete answer.
            return QualitySearch(self.evaluator, self.trace).run(seed)

        arms = self._plan_arms(seed)
        self.trace.note(
            f"EXTREME: {len(arms)} arms to explore — " + ", ".join(arm.label for arm in arms)
        )

        best: CandidateResult | None = None
        previous_best_size = 0

        for generation, arm in enumerate(arms):
            if self.evaluator.budget.exhausted:
                self.trace.stop_reason = "compute budget exhausted"
                break

            plan = self._plan_for(seed, arm)
            self.trace.note(f"--- arm {arm.label}: {arm.rationale}")
            outcome = QualitySearch(self.evaluator, self.trace).run(plan, generation=generation)
            arm.result = outcome.best
            self.report.arms.append(arm)
            self.report.generations = generation + 1

            if outcome.best is None or not outcome.quality_met:
                self.trace.note(f"{arm.label} could not clear the floor; abandoning this arm")
                continue

            size = outcome.best.effective_size
            self.trace.note(
                f"{arm.label} settles at {format_size(size)} "
                f"({outcome.best.size_reduction:.1%} smaller than source)"
            )

            if best is None or size < best.effective_size:
                best = outcome.best
                self.report.winner = arm

            if target is not None and target.contains(size):
                self.trace.stop_reason = "target met"
                break

            if (
                previous_best_size
                and best is not None
                and diminishing(
                    previous_best_size,
                    best.effective_size,
                    self.evaluator.config.search.diminishing_returns_threshold,
                )
            ):
                self.trace.stop_reason = "diminishing returns"
                self.trace.note(
                    f"the last arm improved on {format_size(previous_best_size)} by less than "
                    f"{self.evaluator.config.search.diminishing_returns_threshold:.1%}; "
                    f"further searching costs more compute than it saves storage"
                )
                break
            previous_best_size = best.effective_size if best else 0

        if not self.trace.stop_reason:
            self.trace.stop_reason = "search space exhausted"

        if best is None:
            self.trace.note(
                "no combination cleared the quality floor. The source is already close to the "
                "limit of what these codecs can do at this quality, or the floor is set higher "
                "than the source itself achieves."
            )
            successful = [r for r in self.trace.successful if self.evaluator.represents_source(r)]
            best = max(successful, key=lambda r: r.quality_score) if successful else None

        quality_met = best is not None and self.evaluator.passes_floor(best)[0]
        return SearchOutcome(
            best=best,
            trace=self.trace,
            target_met=bool(target and best and target.contains(best.effective_size)),
            quality_met=quality_met,
            achieved_ratio=(best.effective_size / max(best.source_size, 1)) if best else 1.0,
        )

    # -- arm planning ----------------------------------------------------------------
    def _plan_arms(self, seed: EncodePlan) -> list[Arm]:
        """Order the search space so the most promising arms run first.

        Order matters more than coverage here: the stop conditions mean later
        arms may never run, so the first arm should be the one most likely to
        win outright.
        """
        media = self.evaluator.media
        video = media.primary_video
        assert video is not None and seed.video is not None

        choices = self.evaluator.planner.rank_video_codecs(
            media, self.evaluator.analysis, container=self.evaluator.profile.container
        )
        max_codecs = max(1, self.evaluator.config.search.max_codecs_considered)
        codecs = [c for c in choices if isinstance(c.codec, VideoCodec)][:max_codecs]

        source_height = seed.video.height or video.height
        rungs = [h for _, _, h in ladder_below(video.width, source_height)]
        rungs = [h for h in rungs if h >= self.evaluator.config.quality.min_height] or [
            source_height
        ]

        arms: list[Arm] = []
        for index, choice in enumerate(codecs):
            family = choice.codec.family
            arms.append(
                Arm(
                    codec=family,
                    height=source_height,
                    rationale=(
                        "; ".join(choice.rationale)
                        if choice.rationale
                        else f"ranked {index + 1} on efficiency for this content"
                    ),
                )
            )

        # One resolution step down on the leading codec. This is where EXTREME
        # earns its name: at a fixed quality floor a clean 720p encode routinely
        # beats a starved 1080p one, and nothing in a CRF search can discover
        # that.
        if len(rungs) > 1 and self.evaluator.config.quality.allow_resolution_reduction:
            lower = rungs[1]
            arms.append(
                Arm(
                    codec=codecs[0].codec.family if codecs else seed.video.codec,
                    height=lower,
                    rationale=(
                        f"a clean {lower}p encode often clears the floor at a smaller size than "
                        f"a starved {source_height}p one"
                    ),
                )
            )
        return arms[: self.evaluator.config.search.max_candidates]

    def _plan_for(self, seed: EncodePlan, arm: Arm) -> EncodePlan:
        media = self.evaluator.media
        video = media.primary_video
        assert video is not None
        codec = REGISTRY.get_video(arm.codec)
        params = self.evaluator.planner.video_params(
            media,
            self.evaluator.analysis,
            codec,
            height_override=arm.height if arm.height < video.height else None,
            hardware=seed.video.hardware if seed.video is not None else HardwareVendor.CPU,
        )
        container = self.evaluator.planner.container_for(arm.codec, seed)
        return seed.model_copy(
            update={"video": params, "container": container, "label": f"extreme:{arm.label}"}
        )
