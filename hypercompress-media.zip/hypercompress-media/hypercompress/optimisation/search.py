"""The search harness (Phases 08 and 09).

Every optimiser in this package — quality-floor search, target-size search, and
the EXTREME iterative loop — sits on top of one primitive: *encode a candidate
and find out what actually happened*. That primitive lives here.

Two things make it non-trivial.

**Sampling.** Encoding a two-hour film twelve times to find the best settings
costs more compute than the storage it saves. So the search encodes a handful of
short clips drawn from across the running time and extrapolates. Naive
extrapolation is biased: every clip boundary forces a keyframe, so a sample
carries more I-frames per second than the real encode will. Rather than wave
that away, :func:`extrapolate_size` probes the sample's actual frame sizes and
subtracts the cost of the keyframes that only exist because we sampled.

**Comparability.** A sampled encode cannot be compared against the full source —
the frames do not line up. So the harness builds a lossless *reference sample*
using the identical window selection, caches it, and measures against that.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path

from hypercompress.analysis.frames import sample_offsets
from hypercompress.config import HyperCompressConfig
from hypercompress.core.errors import EncodeError, HyperCompressError
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner, build_window_select_graph
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    CandidateResult,
    ContentAnalysis,
    EncodeCandidate,
    EncodePlan,
    MediaProfile,
    QualityReport,
)
from hypercompress.optimisation.planner import EncodePlanner
from hypercompress.optimisation.profiles import CompressionProfile
from hypercompress.pipeline.encode import Encoder, EncodeRequest, SamplePlan
from hypercompress.quality.scoring import QualityScorer, meets_floor

log = get_logger(__name__)


@dataclass(slots=True)
class SearchBudget:
    """Wall-clock accounting for one optimisation run."""

    total_seconds: float
    spent_seconds: float = 0.0

    @property
    def remaining(self) -> float:
        return max(0.0, self.total_seconds - self.spent_seconds)

    @property
    def exhausted(self) -> bool:
        return self.spent_seconds >= self.total_seconds

    def charge(self, seconds: float) -> None:
        self.spent_seconds += max(0.0, seconds)

    def fraction_used(self) -> float:
        if self.total_seconds <= 0:
            return 1.0
        return min(1.0, self.spent_seconds / self.total_seconds)


@dataclass(slots=True)
class SearchTrace:
    """The full record of what the search tried and why it stopped."""

    results: list[CandidateResult] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    stop_reason: str = ""
    iterations: int = 0

    def add(self, result: CandidateResult) -> CandidateResult:
        self.results.append(result)
        return result

    def note(self, message: str) -> None:
        self.notes.append(message)
        log.debug("search note", extra={"note": message})

    @property
    def successful(self) -> list[CandidateResult]:
        return [r for r in self.results if r.ok]

    def rows(self) -> list[dict[str, object]]:
        return [r.row() for r in self.results]


@dataclass(slots=True)
class SearchOutcome:
    """What the search decided, and everything it learned on the way."""

    best: CandidateResult | None
    trace: SearchTrace
    target_met: bool = False
    quality_met: bool = False
    achieved_ratio: float = 1.0

    @property
    def ok(self) -> bool:
        return self.best is not None and self.best.ok


def extrapolate_size(
    sample_bytes: int,
    *,
    sample_seconds: float,
    full_seconds: float,
    windows: int,
    gop_seconds: float,
    frame_stats: tuple[float, float, int] | None = None,
) -> int:
    """Project a full-file size from a sampled encode.

    ``frame_stats`` is ``(mean_key_bytes, mean_inter_bytes, key_count)`` measured
    from the sample. When present, the keyframes that exist only because the
    sample was cut into windows are subtracted before scaling, which removes a
    bias that otherwise runs to several percent on short clips.
    """
    if sample_seconds <= 0 or full_seconds <= 0:
        return sample_bytes
    payload = float(sample_bytes)

    if frame_stats is not None and gop_seconds > 0:
        mean_key, mean_inter, key_count = frame_stats
        natural_keys = sample_seconds / gop_seconds
        excess = max(0.0, min(float(key_count), windows - 1.0, key_count - natural_keys))
        payload -= excess * max(0.0, mean_key - mean_inter)
        payload = max(payload, sample_bytes * 0.5)

    scaled = payload * (full_seconds / sample_seconds)
    return int(max(0.0, scaled))


class CandidateEvaluator:
    """Encodes and measures candidates, honouring the sampling policy."""

    def __init__(
        self,
        *,
        source: Path,
        media: MediaProfile,
        analysis: ContentAnalysis,
        config: HyperCompressConfig,
        profile: CompressionProfile,
        runner: FFmpegRunner,
        workdir: Path,
        budget: SearchBudget | None = None,
    ) -> None:
        self.source = Path(source)
        self.media = media
        self.analysis = analysis
        self.config = config
        self.profile = profile
        self.runner = runner
        self.workdir = Path(workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.encoder = Encoder(runner, self.workdir / "scratch")
        self.scorer = QualityScorer(runner, config.quality)
        #: The stricter policy the search judges candidates against, so that the
        #: file finally delivered clears the floor the operator actually set.
        self.search_quality = config.quality.with_search_margin()
        self.planner = EncodePlanner(runner.capabilities, config, profile)
        self.budget = budget or SearchBudget(self._default_budget())
        self._reference_sample: Path | None = None
        self._counter = 0
        self._seen: dict[str, CandidateResult] = {}

    # -- sampling policy ---------------------------------------------------------
    @property
    def sample_plan(self) -> SamplePlan | None:
        """The clip set used for search encodes, or ``None`` to encode in full."""
        policy = self.config.search
        duration = self.media.duration
        if duration <= policy.sample_min_source_seconds:
            return None
        clip_seconds = min(policy.sample_seconds, max(2.0, duration / (policy.sample_clips * 4)))
        offsets = sample_offsets(duration, policy.sample_clips, clip_seconds)
        if not offsets:
            return None
        return SamplePlan(offsets=tuple(offsets), clip_seconds=clip_seconds)

    def _default_budget(self) -> float:
        policy = self.config.search
        if policy.compute_budget_seconds is not None:
            return policy.compute_budget_seconds
        return max(60.0, self.media.duration * policy.compute_budget_ratio)

    # -- evaluation --------------------------------------------------------------
    def evaluate(
        self,
        candidate: EncodeCandidate,
        *,
        measure: bool = True,
        audio_only: bool = False,
    ) -> CandidateResult:
        """Encode ``candidate`` and measure what came out.

        Results are memoised on the plan fingerprint: the searches genuinely do
        revisit the same point, and re-encoding it would spend budget to learn
        something already known.
        """
        cached = self._seen.get(candidate.fingerprint)
        if cached is not None:
            return cached

        self._counter += 1
        sample = self.sample_plan
        output = self.workdir / f"cand-{self._counter:03d}.{candidate.plan.container}"
        result = CandidateResult(
            candidate=candidate,
            source_size=self.media.size_bytes,
            sampled=sample is not None,
            sample_fraction=sample.fraction_of(self.media.duration) if sample else 1.0,
        )

        request = EncodeRequest(
            source=self.source,
            output=output,
            plan=candidate.plan,
            profile=self.media,
            sample=sample,
            timeout=self._encode_timeout(),
        )
        try:
            outcome = self.encoder.encode(request)
        except (EncodeError, HyperCompressError) as exc:
            result.error = str(exc)
            self.budget.charge(1.0)
            self._seen[candidate.fingerprint] = result
            log.warning(
                "candidate failed", extra={"fingerprint": candidate.fingerprint, "error": str(exc)}
            )
            return result

        result.output_path = str(output)
        result.output_size = outcome.size
        result.usage = outcome.usage
        self.budget.charge(outcome.usage.wall_seconds)

        if sample is not None:
            result.extrapolated_size = extrapolate_size(
                outcome.size,
                sample_seconds=outcome.encoded_seconds,
                full_seconds=self.media.duration,
                windows=len(sample.offsets),
                gop_seconds=self._gop_seconds(candidate.plan),
                frame_stats=self._frame_stats(output),
            )

        if measure:
            result.quality = self._measure(output, sample, audio_only=audio_only)

        self._seen[candidate.fingerprint] = result
        return result

    def measure_final(self, path: Path) -> QualityReport:
        """Full-length measurement of the winning encode."""
        return self.scorer.measure(self.source, path, self.media, fast=False)

    def encode_final(self, plan: EncodePlan, output: Path, **kwargs: object) -> CandidateResult:
        """Encode the chosen plan over the whole file."""
        candidate = EncodeCandidate(plan=plan, origin="final")
        request = EncodeRequest(
            source=self.source,
            output=output,
            plan=plan,
            profile=self.media,
            timeout=self._encode_timeout(full=True),
            on_progress=kwargs.get("on_progress"),  # type: ignore[arg-type]
        )
        result = CandidateResult(candidate=candidate, source_size=self.media.size_bytes)
        outcome = self.encoder.encode(request)
        result.output_path = str(output)
        result.output_size = outcome.size
        result.usage = outcome.usage
        result.quality = self.measure_final(output)
        self.budget.charge(outcome.usage.wall_seconds)
        return result

    # -- internals ---------------------------------------------------------------
    def _encode_timeout(self, *, full: bool = False) -> float:
        """A per-encode ceiling so one pathological candidate cannot eat the run."""
        base = self.budget.remaining if self.budget.remaining > 0 else 120.0
        if full:
            return max(120.0, self.media.duration * 60.0)
        return max(60.0, min(base, self.media.duration * 20.0))

    def _gop_seconds(self, plan: EncodePlan) -> float:
        video = plan.video
        if video is None or not video.keyint:
            return 0.0
        source_video = self.media.primary_video
        fps = (video.frame_rate or (source_video.frame_rate if source_video else 25.0)) or 25.0
        return video.keyint / max(fps, 1.0)

    def _frame_stats(self, path: Path) -> tuple[float, float, int] | None:
        """Mean key / inter frame size from an encoded sample."""
        try:
            frames = self.runner.probe_frames(
                path, entries="frame=pkt_size,key_frame", select="v:0"
            )
        except HyperCompressError:
            return None
        keys: list[float] = []
        inters: list[float] = []
        for frame in frames:
            try:
                size = float(frame.get("pkt_size") or 0)
            except (TypeError, ValueError):
                continue
            if size <= 0:
                continue
            (keys if str(frame.get("key_frame")) == "1" else inters).append(size)
        if not keys or not inters:
            return None
        return (sum(keys) / len(keys), sum(inters) / len(inters), len(keys))

    def _reference_for(self, sample: SamplePlan) -> Path:
        """A lossless clip carrying exactly the sampled windows.

        Built once and reused: it is the only thing a sampled candidate can
        honestly be measured against.
        """
        if self._reference_sample is not None and self._reference_sample.exists():
            return self._reference_sample

        target = self.workdir / "reference-sample.mkv"
        args = ArgBuilder().path("-i", self.source)
        if self.media.primary_video is not None:
            args.opt("-map", "0:v:0")
            args.opt("-vf", build_window_select_graph(sample.windows()))
            args.opt("-fps_mode", "cfr")
            # FFV1 is lossless and fast to encode, so the reference costs the
            # search almost nothing and introduces no distortion of its own.
            encoder = "ffv1" if self.runner.capabilities.has_encoder("ffv1") else "libx264"
            args.opt("-c:v", encoder)
            if encoder == "libx264":
                args.opt("-qp", 0).opt("-preset", "ultrafast")
        else:
            args.flag("-vn")
        if self.media.primary_audio is not None:
            args.opt("-map", "0:a:0?")
            args.opt("-af", build_window_select_graph(sample.windows(), audio=True))
            args.opt("-c:a", "flac")
        else:
            args.flag("-an")
        args.flag("-sn").flag("-dn").opt("-f", "matroska").opt("-map_chapters", -1)
        self.runner.encode(args, target)
        self._reference_sample = target
        return target

    def _measure(
        self,
        output: Path,
        sample: SamplePlan | None,
        *,
        audio_only: bool = False,
    ) -> QualityReport:
        reference = self.source if sample is None else self._reference_for(sample)
        media = self.media
        if audio_only:
            # An audio-only candidate has no video to compare; presenting the
            # scorer with the full profile would send it looking for a stream
            # that deliberately is not there.
            media = media.model_copy(update={"video": []})
        duration = self.media.duration if sample is None else sample.total_seconds
        started = time.monotonic()
        try:
            report = self.scorer.measure(reference, output, media, fast=True, duration=duration)
        except HyperCompressError as exc:
            log.warning("quality measurement failed", extra={"error": str(exc)})
            return QualityReport(notes=[f"measurement failed: {exc}"])
        finally:
            self.budget.charge(time.monotonic() - started)
        return report

    # -- convenience -------------------------------------------------------------
    def passes_floor(self, result: CandidateResult) -> tuple[bool, list[str]]:
        return meets_floor(result.quality, self.search_quality)

    def represents_source(self, result: CandidateResult) -> bool:
        """Whether a candidate's plan keeps every stream kind the source has.

        The audio ladder deliberately evaluates audio-only plans, because
        including the video re-encode would make an audio search unaffordable.
        Those candidates share a trace with the video ones, so any code that
        picks a winner out of the trace can pick one — and an audio-only file
        moved into place as the final artefact silently loses the picture.
        """
        plan = result.candidate.plan
        loses_video = (
            self.media.primary_video is not None and plan.video is None and not plan.copy_video
        )
        loses_audio = (
            self.media.primary_audio is not None and plan.audio is None and not plan.copy_audio
        )
        return not (loses_video or loses_audio)

    def best_of(self, results: list[CandidateResult]) -> CandidateResult | None:
        """Smallest result that still clears the quality floor."""
        eligible = [
            r for r in results if r.ok and self.passes_floor(r)[0] and self.represents_source(r)
        ]
        if not eligible:
            return None
        return min(eligible, key=lambda r: r.effective_size)


def diminishing(previous: int, current: int, threshold: float) -> bool:
    """Whether the latest iteration bought less than ``threshold`` of the size."""
    if previous <= 0:
        return False
    gain = (previous - current) / previous
    return gain < threshold and not math.isclose(previous, current)
