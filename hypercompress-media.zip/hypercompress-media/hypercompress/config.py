"""Configuration for HYPERCOMPRESS MEDIA.

Every tunable is here: nothing in the engine hard-codes a price, a quality floor,
a codec preference or a bucket name. Configuration resolves in this order
(later wins):

1. Built-in defaults
2. ``hypercompress.toml`` / ``hypercompress.json`` on disk
3. ``HYPERCOMPRESS_*`` environment variables (``__`` for nesting)
4. Explicit keyword overrides
"""

from __future__ import annotations

import json
import os
import tomllib
from pathlib import Path
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from hypercompress.core.types import CodecFamily, HardwareVendor


class _Section(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


# --------------------------------------------------------------------------------------


class FFmpegConfig(_Section):
    """How the platform talks to FFmpeg."""

    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    threads: int = 0
    """0 lets the encoder decide; the scheduler may override per job."""
    nice: int = 0
    encode_timeout_seconds: float | None = 14_400.0
    probe_timeout_seconds: float = 180.0
    analysis_timeout_seconds: float = 900.0
    prefer_hardware: bool = False
    allowed_hardware: list[HardwareVendor] = Field(
        default_factory=lambda: [
            HardwareVendor.CPU,
            HardwareVendor.NVIDIA,
            HardwareVendor.INTEL,
            HardwareVendor.AMD,
            HardwareVendor.APPLE,
        ]
    )


class QualityPolicy(_Section):
    """The constraint side of the optimisation problem (Phase 10)."""

    floor: float = 0.90
    """Minimum acceptable composite quality, 0..1. Nothing ships below this."""
    vmaf_floor: float | None = 93.0
    vmaf_low_percentile_floor: float | None = 88.0
    psnr_floor: float | None = 38.0
    ssim_floor: float | None = 0.985
    """Luma SSIM floor, on the scale produced by this platform's own measurement.

    Not comparable with figures quoted from FFmpeg's ``ssim`` filter, which
    averages all three planes and reads roughly 0.02 lower on the same file.
    """
    search_margin: float = 0.010
    """Extra headroom demanded during the search, above the delivered floor.

    The search measures with a fast metric configuration and the final encode is
    measured in full. Once both passes were made to sample the same windows the
    two agree to within about 0.006 across the whole quality range, so a small
    margin is enough to keep the delivered guarantee honest without spending
    size on paranoia. Before that fix the gap ran to 0.4 and no plausible margin
    would have covered it — the right response to a large gap is to find out why
    the measurements disagree, not to inflate this number until it hides.
    """

    audio_relative_tolerance: float = 0.02
    """Accepted shortfall from the best audio score the file can actually reach.

    Log-mel similarity saturates at a level that depends on the material, so an
    absolute floor alone either passes damaged speech or fails transparent
    music. The search measures the ceiling and applies this tolerance to it.
    """

    audio_floor: float | None = 0.90

    video_weight: float = 0.75
    audio_weight: float = 0.25
    metric_weights: dict[str, float] = Field(
        default_factory=lambda: {"vmaf": 0.65, "ms_ssim": 0.15, "ssim": 0.10, "psnr": 0.10}
    )

    allow_resolution_reduction: bool = False
    allow_framerate_reduction: bool = False
    allow_channel_reduction: bool = False
    allow_sample_rate_reduction: bool = True
    min_height: int = 360
    min_frame_rate: float = 23.9
    preserve_hdr: bool = True
    preserve_subtitles: bool = True
    preserve_chapters: bool = True
    preserve_all_audio_tracks: bool = True
    allow_metadata_strip: bool = False

    measure_with_vmaf: bool = True
    measurement_frames: int = 0
    """0 measures every frame; >0 subsamples for speed."""

    @model_validator(mode="after")
    def _normalise(self) -> Self:
        total = self.video_weight + self.audio_weight
        if total <= 0:
            raise ValueError("video_weight + audio_weight must be positive")
        object.__setattr__(self, "video_weight", self.video_weight / total)
        object.__setattr__(self, "audio_weight", self.audio_weight / total)
        weight_sum = sum(self.metric_weights.values())
        if weight_sum <= 0:
            raise ValueError("metric_weights must sum to a positive number")
        return self

    def with_search_margin(self) -> QualityPolicy:
        """A stricter copy of this policy, used while searching.

        Sampled, fast measurement and full measurement of the same encode do not
        agree exactly. Searching against the delivered floor therefore ships
        files just below it roughly half the time. Searching against a slightly
        higher bar costs a percent or two of size and makes the delivered
        guarantee actually hold.
        """
        margin = self.search_margin
        if margin <= 0:
            return self
        return self.model_copy(
            update={
                "floor": min(0.999, self.floor + margin),
                "audio_floor": None
                if self.audio_floor is None
                else min(0.999, self.audio_floor + margin),
                "vmaf_floor": None
                if self.vmaf_floor is None
                else min(100.0, self.vmaf_floor + margin * 40),
                "ssim_floor": None
                if self.ssim_floor is None
                else min(0.9999, self.ssim_floor + margin * 0.1),
                "psnr_floor": None if self.psnr_floor is None else self.psnr_floor + margin * 30,
                "search_margin": 0.0,
            }
        )


class SearchPolicy(_Section):
    """The search side of the optimisation problem (Phases 08 & 09)."""

    max_candidates: int = 12
    max_iterations: int = 8
    max_codecs_considered: int = 3
    compute_budget_seconds: float | None = None
    compute_budget_ratio: float = 40.0
    """Wall-clock budget as a multiple of media duration when no absolute budget is set."""

    sample_clips: int = 3
    sample_seconds: float = 4.0
    sample_min_source_seconds: float = 45.0
    """Below this duration the engine encodes the whole file instead of sampling."""

    size_tolerance: float = 0.02
    quality_tolerance: float = 0.004
    diminishing_returns_threshold: float = 0.015
    """Stop when an extra iteration buys less than this fractional size reduction."""

    parallel_candidates: int = 1
    seed_from_history: bool = True
    refine_final_encode: bool = True


class CostModel(_Section):
    """Cloud economics inputs (Phase 10 of the deliverables list)."""

    currency: str = "USD"
    storage_price_per_gb_month: float = 0.023
    archive_storage_price_per_gb_month: float = 0.004
    egress_price_per_gb: float = 0.09
    cpu_price_per_core_hour: float = 0.042
    gpu_price_per_hour: float = 0.65
    memory_price_per_gb_hour: float = 0.005
    request_price_per_1000: float = 0.005
    electricity_price_per_kwh: float = 0.28
    cpu_watts_per_core: float = 12.0
    gpu_watts: float = 220.0
    pue: float = 1.2
    retention_months: float = 36.0
    monthly_egress_multiplier: float = 0.15
    """Fraction of the library that leaves the cloud each month."""
    carbon_kg_per_kwh: float = 0.233


class StorageConfig(_Section):
    backend: Literal["local", "s3", "azure", "gcs", "memory"] = "local"
    root: Path = Path("./hypercompress-data")
    bucket: str | None = None
    prefix: str = ""
    region: str | None = None
    endpoint_url: str | None = None
    storage_class: str | None = None
    multipart_threshold: int = 64 * 1024 * 1024
    max_concurrency: int = 8
    verify_after_write: bool = True
    write_manifests: bool = True
    never_overwrite_source: bool = True
    allowed_roots: list[Path] = Field(default_factory=list)
    """Directories the API may read from and write to.

    Empty means unrestricted, which is right for a single-user CLI and wrong for
    a multi-tenant service: any path in a job body would otherwise be a read of
    the worker's filesystem. Set this in every deployment that accepts requests
    from anyone but its operator.
    """


class DistributedConfig(_Section):
    queue_backend: Literal["memory", "redis", "sqlite"] = "memory"
    redis_url: str = "redis://localhost:6379/0"
    sqlite_path: Path = Path("./hypercompress-queue.db")
    worker_id: str | None = None
    worker_concurrency: int = max(1, (os.cpu_count() or 2) // 2)
    prefetch: int = 2
    max_queue_depth: int = 100_000
    backpressure_high_watermark: float = 0.85
    backpressure_low_watermark: float = 0.60
    heartbeat_seconds: float = 15.0
    visibility_timeout_seconds: float = 3_600.0
    max_attempts: int = 3
    retry_base_delay: float = 2.0
    retry_max_delay: float = 300.0
    retry_jitter: float = 0.3
    checkpoint_interval_seconds: float = 30.0
    graceful_shutdown_seconds: float = 120.0
    scratch_dir: Path = Path("/tmp/hypercompress")
    isolate_processes: bool = True


class SecurityConfig(_Section):
    require_auth: bool = True
    tokens: dict[str, str] = Field(default_factory=dict)
    """Mapping of bearer token -> ``principal:role:tenant``."""
    default_role: str = "viewer"
    tenant_isolation: bool = True
    audit_log_path: Path | None = Path("./hypercompress-audit.jsonl")
    tls_cert: Path | None = None
    tls_key: Path | None = None
    max_jobs_per_tenant: int = 10_000
    max_bytes_per_tenant: int = 10 * 1024**5
    max_concurrent_jobs_per_tenant: int = 64
    secure_temp_mode: int = 0o700
    allow_source_overwrite: bool = False


class ObservabilityConfig(_Section):
    log_level: str = "INFO"
    json_logs: bool = True
    log_file: Path | None = None
    prometheus_enabled: bool = True
    prometheus_port: int = 9_108
    otel_enabled: bool = False
    otel_endpoint: str | None = None
    service_name: str = "hypercompress-media"
    emit_candidate_telemetry: bool = True


class CodecPolicy(_Section):
    """Constraints on codec selection (Phase 04)."""

    video_allowlist: list[CodecFamily] = Field(
        default_factory=lambda: [
            CodecFamily.AV1,
            CodecFamily.HEVC,
            CodecFamily.H264,
            CodecFamily.VP9,
        ]
    )
    audio_allowlist: list[CodecFamily] = Field(
        default_factory=lambda: [CodecFamily.OPUS, CodecFamily.AAC, CodecFamily.FLAC]
    )
    require_broad_compatibility: bool = False
    """When true, the engine will not select AV1/VP9 for delivery targets."""
    max_encode_speed_penalty: float = 60.0
    """Reject a codec if it is more than N times slower than H.264 for the gain."""
    never_transcode_lossless_to_lossy: bool = False
    forbid_upscaling: bool = True
    reencode_threshold: float = 0.06
    """Skip re-encoding when predicted savings fall below this fraction."""


# --------------------------------------------------------------------------------------


class HyperCompressConfig(BaseSettings):
    """Root configuration object."""

    model_config = SettingsConfigDict(
        env_prefix="HYPERCOMPRESS_",
        env_nested_delimiter="__",
        extra="ignore",
    )

    profile: str = "balanced"
    work_dir: Path = Path("/tmp/hypercompress/work")
    output_dir: Path = Path("./hypercompress-output")
    profiles_dir: Path | None = None
    keep_intermediates: bool = False
    dry_run: bool = False

    ffmpeg: FFmpegConfig = Field(default_factory=FFmpegConfig)
    quality: QualityPolicy = Field(default_factory=QualityPolicy)
    search: SearchPolicy = Field(default_factory=SearchPolicy)
    cost: CostModel = Field(default_factory=CostModel)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    distributed: DistributedConfig = Field(default_factory=DistributedConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)
    codecs: CodecPolicy = Field(default_factory=CodecPolicy)

    # -- loading ------------------------------------------------------------------
    @classmethod
    def load(
        cls,
        path: str | Path | None = None,
        **overrides: Any,
    ) -> HyperCompressConfig:
        """Load configuration from a file plus environment plus overrides."""
        data: dict[str, Any] = {}
        candidate = Path(path) if path else _discover_config_file()
        if candidate and candidate.exists():
            data = _read_config_file(candidate)
        merged = _deep_merge(data, overrides)
        return cls(**merged)

    def merged_with(self, **overrides: Any) -> HyperCompressConfig:
        """Return a copy with a deep-merged override tree applied."""
        base = self.model_dump(mode="python")
        return HyperCompressConfig(**_deep_merge(base, overrides))

    def scratch(self, *parts: str) -> Path:
        target = self.work_dir.joinpath(*parts)
        target.mkdir(parents=True, exist_ok=True)
        target.chmod(self.security.secure_temp_mode)
        return target

    def to_json(self, indent: int = 2) -> str:
        return self.model_dump_json(indent=indent)


def _discover_config_file() -> Path | None:
    env = os.environ.get("HYPERCOMPRESS_CONFIG")
    if env:
        return Path(env)
    for name in ("hypercompress.toml", "hypercompress.json", ".hypercompress.toml"):
        candidate = Path.cwd() / name
        if candidate.exists():
            return candidate
    return None


def _read_config_file(path: Path) -> dict[str, Any]:
    if path.suffix == ".json":
        return dict(json.loads(path.read_text()))
    if path.suffix in {".toml", ".tml"}:
        with path.open("rb") as handle:
            return dict(tomllib.load(handle))
    raise ValueError(f"unsupported configuration format: {path.suffix}")


def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for key, value in overlay.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out
