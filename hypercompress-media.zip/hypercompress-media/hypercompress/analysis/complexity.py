"""Phase 03: content classification.

The classifier is a transparent scored ensemble rather than an opaque model:
every class accumulates evidence from measured signals, and the winning class
carries the reasons it won. Operators can read why a file was treated as CCTV
rather than film, and the rationale travels into the manifest.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from hypercompress.analysis.audio_analysis import analyse_audio
from hypercompress.analysis.frames import sample_audio, sample_video
from hypercompress.analysis.scene_detection import detect_scenes_sampled
from hypercompress.analysis.video_analysis import (
    analyse_video,
    detect_animation,
    detect_text_content,
)
from hypercompress.config import SearchPolicy
from hypercompress.core.errors import ProbeError
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    AudioComplexity,
    ContentAnalysis,
    ContentClass,
    MediaKind,
    MediaProfile,
    VideoComplexity,
)

log = get_logger("analysis.complexity")


@dataclass(slots=True)
class Evidence:
    """One rule's contribution to one content class."""

    content_class: ContentClass
    weight: float
    reason: str


@dataclass(slots=True)
class ClassificationInput:
    profile: MediaProfile
    video: VideoComplexity | None
    audio: AudioComplexity | None
    has_text: bool
    is_animation: bool
    scene_rate: float


Rule = Callable[[ClassificationInput], list[Evidence]]


def _video_rules(ctx: ClassificationInput) -> list[Evidence]:
    out: list[Evidence] = []
    v = ctx.video
    if v is None:
        return out
    if ctx.has_text:
        out.append(
            Evidence(ContentClass.SCREEN_RECORDING, 2.4, "high edge energy with near-static frames")
        )
        out.append(Evidence(ContentClass.LECTURE, 1.1, "slide-like text content"))
    if ctx.is_animation:
        out.append(
            Evidence(ContentClass.ANIMATION, 2.6, "flat regions, sharp edges, bursty motion")
        )
    if v.static_ratio > 0.75 and v.grain < 0.35:
        out.append(
            Evidence(ContentClass.CCTV, 2.2, f"static for {v.static_ratio:.0%} of sampled frames")
        )
    if v.motion > 0.55 and ctx.scene_rate > 0.20:
        out.append(Evidence(ContentClass.SPORTS, 2.0, "sustained high motion with frequent cuts"))
    if v.motion > 0.45 and v.spatial > 0.45 and v.grain < 0.25:
        out.append(
            Evidence(ContentClass.GAMING, 1.8, "high motion and detail with no sensor grain")
        )
    if v.grain > 0.45 and 0.10 < v.motion < 0.65:
        out.append(Evidence(ContentClass.FILM, 2.0, f"film grain present ({v.grain:.2f})"))
    if 0.05 < v.motion < 0.28 and v.spatial < 0.45 and not ctx.has_text:
        out.append(
            Evidence(ContentClass.TALKING_HEAD, 1.5, "low, steady motion with a simple frame")
        )
    if v.dark_ratio > 0.35 and v.grain > 0.3:
        out.append(Evidence(ContentClass.FILM, 0.8, "dark, grainy photography"))
    if 0.02 < ctx.scene_rate < 0.12 and 0.15 < v.motion < 0.6:
        out.append(Evidence(ContentClass.DOCUMENTARY, 1.0, "moderate cut rate and motion"))
    return out


def _audio_rules(ctx: ClassificationInput) -> list[Evidence]:
    out: list[Evidence] = []
    a = ctx.audio
    if a is None:
        return out
    audio_only = ctx.profile.kind is MediaKind.AUDIO
    if a.speech_likelihood > 0.55 and a.music_likelihood < 0.55:
        weight = 2.4 if audio_only else 1.0
        out.append(
            Evidence(
                ContentClass.PODCAST,
                weight,
                f"speech-dominant spectrum ({a.speech_likelihood:.2f})",
            )
        )
        if ctx.video is not None:
            out.append(Evidence(ContentClass.TALKING_HEAD, 0.9, "speech soundtrack"))
            out.append(Evidence(ContentClass.LECTURE, 0.7, "speech soundtrack"))
        if a.dynamic_range_db < 12 and a.is_effectively_mono and ctx.profile.duration > 1_800:
            out.append(Evidence(ContentClass.AUDIOBOOK, 2.6, "long, compressed, mono narration"))
    if a.music_likelihood > 0.6:
        weight = 2.6 if audio_only else 0.8
        out.append(
            Evidence(
                ContentClass.MUSIC,
                weight,
                f"broadband spectrum with strong high-frequency energy ({a.high_freq_energy_ratio:.2f})",
            )
        )
        if ctx.video is not None:
            out.append(Evidence(ContentClass.FILM, 0.6, "scored soundtrack"))
    if a.silence_ratio > 0.55 and ctx.video is not None:
        out.append(Evidence(ContentClass.CCTV, 1.2, f"soundtrack is {a.silence_ratio:.0%} silence"))
    if a.dynamic_range_db > 25 and a.music_likelihood > 0.5:
        out.append(Evidence(ContentClass.MUSIC, 0.8, "wide dynamic range"))
    return out


def _metadata_rules(ctx: ClassificationInput) -> list[Evidence]:
    """Filenames and tags are weak evidence, so they nudge rather than decide."""
    out: list[Evidence] = []
    haystack = " ".join(
        [Path(ctx.profile.path).name.lower(), *[v.lower() for v in ctx.profile.metadata.values()]]
    )
    hints = {
        ContentClass.PODCAST: ("podcast", "episode", "ep.", "interview"),
        ContentClass.MUSIC: ("album", "track", "song", "master", "mix"),
        ContentClass.AUDIOBOOK: ("audiobook", "chapter", "narrat"),
        ContentClass.CCTV: ("cctv", "cam", "surveillance", "dvr"),
        ContentClass.SCREEN_RECORDING: ("screen", "capture", "demo", "recording"),
        ContentClass.LECTURE: ("lecture", "seminar", "webinar", "course"),
        ContentClass.SPORTS: ("match", "game", "highlights", "fixture"),
        ContentClass.ANIMATION: ("anim", "cartoon", "render"),
        ContentClass.FILM: ("bluray", "remux", "1080p", "2160p", "web-dl"),
    }
    for content_class, needles in hints.items():
        if any(needle in haystack for needle in needles):
            out.append(Evidence(content_class, 0.6, "filename or metadata hint"))
    return out


RULES: list[Rule] = [_video_rules, _audio_rules, _metadata_rules]


def classify(ctx: ClassificationInput) -> tuple[ContentClass, float, list[str]]:
    """Score every class and return the winner, its confidence and its reasons."""
    scores: dict[ContentClass, float] = {}
    reasons: dict[ContentClass, list[str]] = {}
    for rule in RULES:
        for evidence in rule(ctx):
            scores[evidence.content_class] = (
                scores.get(evidence.content_class, 0.0) + evidence.weight
            )
            reasons.setdefault(evidence.content_class, []).append(evidence.reason)

    # A file with a real video stream is never a podcast, however speech-like its
    # soundtrack; audio-only classes stay out of the ranking for video media.
    if ctx.profile.kind is MediaKind.VIDEO:
        for audio_only_class in (ContentClass.PODCAST, ContentClass.MUSIC, ContentClass.AUDIOBOOK):
            scores.pop(audio_only_class, None)
            reasons.pop(audio_only_class, None)
        scores.setdefault(ContentClass.DOCUMENTARY, 0.0)
        scores[ContentClass.DOCUMENTARY] += 0.5
        reasons.setdefault(ContentClass.DOCUMENTARY, []).append("general video baseline")
    elif ctx.profile.kind is MediaKind.AUDIO:
        for video_class in (
            ContentClass.FILM,
            ContentClass.DOCUMENTARY,
            ContentClass.SPORTS,
            ContentClass.ANIMATION,
            ContentClass.GAMING,
            ContentClass.SCREEN_RECORDING,
            ContentClass.CCTV,
            ContentClass.TALKING_HEAD,
        ):
            scores.pop(video_class, None)
            reasons.pop(video_class, None)

    if not scores:
        if ctx.profile.kind is MediaKind.AUDIO and ctx.audio is not None:
            fallback = ContentClass.PODCAST if ctx.audio.is_speech else ContentClass.MUSIC
            return fallback, 0.25, ["weak signals; leaning on the speech/music balance"]
        fallback = (
            ContentClass.PODCAST
            if ctx.profile.kind is MediaKind.AUDIO
            else ContentClass.DOCUMENTARY
        )
        return fallback, 0.2, ["no distinguishing signals; defaulting conservatively"]

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    winner, top = ranked[0]
    runner_up = ranked[1][1] if len(ranked) > 1 else 0.0
    confidence = float(
        min(1.0, (top - runner_up) / max(top, 1e-6) * 0.6 + min(top / 4.0, 1.0) * 0.4)
    )
    return winner, confidence, reasons.get(winner, [])


class ContentAnalyser:
    """Phase 03 orchestrator: sample, measure, classify."""

    def __init__(self, runner: FFmpegRunner, policy: SearchPolicy | None = None) -> None:
        self.runner = runner
        self.policy = policy or SearchPolicy()

    def analyse(self, profile: MediaProfile, *, deep: bool = False) -> ContentAnalysis:
        video_complexity: VideoComplexity | None = None
        audio_complexity: AudioComplexity | None = None
        scenes = []
        metrics = []
        has_text = False
        is_animation = False

        clips = self.policy.sample_clips * (2 if deep else 1)
        clip_seconds = self.policy.sample_seconds

        if profile.primary_video is not None:
            try:
                windows = sample_video(
                    self.runner,
                    profile.path,
                    duration=profile.duration,
                    clips=clips,
                    clip_seconds=clip_seconds,
                )
                video_complexity, metrics = analyse_video(windows)
                scenes = detect_scenes_sampled(windows, metrics)
                video_complexity = video_complexity.model_copy(
                    update={
                        "scene_change_rate": len(scenes)
                        / max(video_complexity.sampled_seconds, 1e-6)
                    }
                )
                has_text = detect_text_content(metrics)
                is_animation = detect_animation(metrics)
            except (ProbeError, OSError) as exc:
                log.warning("video analysis failed", extra={"error": str(exc)})

        if profile.primary_audio is not None:
            try:
                audio_windows = sample_audio(
                    self.runner,
                    profile.path,
                    duration=profile.duration,
                    clips=clips,
                    clip_seconds=max(clip_seconds, 6.0),
                    channels=min(2, profile.primary_audio.channels),
                )
                audio_complexity = analyse_audio(audio_windows)
            except (ProbeError, OSError) as exc:
                log.warning("audio analysis failed", extra={"error": str(exc)})

        ctx = ClassificationInput(
            profile=profile,
            video=video_complexity,
            audio=audio_complexity,
            has_text=has_text,
            is_animation=is_animation,
            scene_rate=video_complexity.scene_change_rate if video_complexity else 0.0,
        )
        content_class, confidence, rationale = classify(ctx)
        log.info(
            "classified content",
            extra={"class": content_class.value, "confidence": round(confidence, 3)},
        )
        return ContentAnalysis(
            content_class=content_class,
            confidence=confidence,
            video=video_complexity,
            audio=audio_complexity,
            scenes=scenes,
            rationale=rationale,
        )
