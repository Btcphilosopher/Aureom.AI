"""Phase 01–02: ingest and media forensics.

Turns an arbitrary file into a :class:`MediaProfile`: every stream, every codec
parameter, colour and HDR signalling, chapters, metadata and (optionally) a
content digest. Everything downstream reads this object, never ffprobe JSON.
"""

from __future__ import annotations

from fractions import Fraction
from pathlib import Path
from typing import Any

from hypercompress.analysis.containers import container_from_format, is_media_extension
from hypercompress.core.errors import UnsupportedMediaError
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.hashing import file_digest, quick_signature
from hypercompress.core.logging import get_logger
from hypercompress.core.types import (
    AudioStreamInfo,
    ChapterInfo,
    MediaKind,
    MediaProfile,
    SubtitleStreamInfo,
    VideoStreamInfo,
)

log = get_logger("analysis.probe")

_BIT_DEPTH_BY_PIX_FMT: dict[str, int] = {
    "yuv420p": 8,
    "yuvj420p": 8,
    "nv12": 8,
    "yuv422p": 8,
    "yuv444p": 8,
    "gray": 8,
    "yuv420p10le": 10,
    "yuv422p10le": 10,
    "yuv444p10le": 10,
    "p010le": 10,
    "yuv420p12le": 12,
    "yuv422p12le": 12,
    "yuv444p12le": 12,
    "yuv420p16le": 16,
    "rgb24": 8,
    "gbrp": 8,
    "gbrp10le": 10,
}


def parse_rate(value: str | None) -> float:
    """Parse ffprobe's ``"30000/1001"`` rational rates safely."""
    if not value or value in {"0/0", "N/A"}:
        return 0.0
    try:
        return float(Fraction(value))
    except (ValueError, ZeroDivisionError):
        return 0.0


def _int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def bit_depth_for(stream: dict[str, Any]) -> int:
    explicit = _int(stream.get("bits_per_raw_sample"))
    if explicit:
        return explicit
    return _BIT_DEPTH_BY_PIX_FMT.get(str(stream.get("pix_fmt", "")), 8)


class MediaProbe:
    """Phase 01 + Phase 02: ingest and forensics."""

    def __init__(
        self, runner: FFmpegRunner, *, checksum: bool = False, quick_checksum: bool = True
    ) -> None:
        self.runner = runner
        self.checksum = checksum
        self.quick_checksum = quick_checksum

    def probe(self, path: str | Path, *, checksum: bool | None = None) -> MediaProfile:
        """Build a complete :class:`MediaProfile` for ``path``."""
        target = Path(path)
        if not target.exists():
            raise UnsupportedMediaError(f"input does not exist: {target}")
        if target.is_dir():
            raise UnsupportedMediaError(f"input is a directory: {target}")

        payload = self.runner.probe(target)
        fmt = payload.get("format", {})
        streams = payload.get("streams", [])
        if not streams:
            raise UnsupportedMediaError(f"no decodable streams in {target}")

        video, audio, subtitles = [], [], []
        attachments = 0
        for stream in streams:
            kind = stream.get("codec_type")
            if kind == "video":
                video.append(self._video_stream(stream))
            elif kind == "audio":
                audio.append(self._audio_stream(stream))
            elif kind == "subtitle":
                subtitles.append(self._subtitle_stream(stream))
            elif kind == "attachment":
                attachments += 1

        chapters = [
            ChapterInfo(
                index=idx,
                start=_float(ch.get("start_time")) or 0.0,
                end=_float(ch.get("end_time")) or 0.0,
                title=(ch.get("tags") or {}).get("title"),
            )
            for idx, ch in enumerate(payload.get("chapters", []))
        ]

        size = _int(fmt.get("size")) or target.stat().st_size
        duration = _float(fmt.get("duration")) or self._duration_fallback(video, audio)

        digest: str | None = None
        want_checksum = self.checksum if checksum is None else checksum
        if want_checksum:
            digest = file_digest(target)
        elif self.quick_checksum:
            digest = quick_signature(target)

        profile = MediaProfile(
            path=str(target.resolve()),
            container=container_from_format(str(fmt.get("format_name", ""))),
            format_long_name=str(fmt.get("format_long_name", "")),
            size_bytes=size,
            duration=duration,
            overall_bit_rate=_int(fmt.get("bit_rate")),
            video=video,
            audio=audio,
            subtitles=subtitles,
            chapters=chapters,
            attachments=attachments,
            metadata={str(k): str(v) for k, v in (fmt.get("tags") or {}).items()},
            checksum=digest,
        )
        if profile.kind is MediaKind.UNKNOWN and not is_media_extension(target):
            raise UnsupportedMediaError(f"{target} contains no usable audio or video streams")
        log.info(
            "probed media",
            extra={
                "path": str(target),
                "container": profile.container,
                "kind": profile.kind.value,
                "duration": round(profile.duration, 3),
                "size": profile.size_bytes,
            },
        )
        return profile

    # -- stream builders ----------------------------------------------------------
    def _video_stream(self, stream: dict[str, Any]) -> VideoStreamInfo:
        tags = stream.get("tags") or {}
        return VideoStreamInfo(
            index=_int(stream.get("index")) or 0,
            codec=str(stream.get("codec_name", "unknown")),
            codec_long_name=str(stream.get("codec_long_name", "")),
            profile=stream.get("profile"),
            level=_int(stream.get("level")),
            width=_int(stream.get("width")) or 0,
            height=_int(stream.get("height")) or 0,
            coded_width=_int(stream.get("coded_width")),
            coded_height=_int(stream.get("coded_height")),
            pix_fmt=str(stream.get("pix_fmt", "yuv420p")),
            bit_depth=bit_depth_for(stream),
            frame_rate=parse_rate(stream.get("r_frame_rate")),
            avg_frame_rate=parse_rate(stream.get("avg_frame_rate")),
            bit_rate=_int(stream.get("bit_rate")) or _int(tags.get("BPS")),
            nb_frames=_int(stream.get("nb_frames")) or _int(tags.get("NUMBER_OF_FRAMES")),
            duration=_float(stream.get("duration")),
            color_space=stream.get("color_space"),
            color_transfer=stream.get("color_transfer"),
            color_primaries=stream.get("color_primaries"),
            color_range=stream.get("color_range"),
            field_order=stream.get("field_order"),
            sample_aspect_ratio=stream.get("sample_aspect_ratio"),
            display_aspect_ratio=stream.get("display_aspect_ratio"),
            language=tags.get("language"),
            title=tags.get("title"),
            disposition={k: int(v) for k, v in (stream.get("disposition") or {}).items()},
            side_data=list(stream.get("side_data_list") or []),
        )

    def _audio_stream(self, stream: dict[str, Any]) -> AudioStreamInfo:
        tags = stream.get("tags") or {}
        return AudioStreamInfo(
            index=_int(stream.get("index")) or 0,
            codec=str(stream.get("codec_name", "unknown")),
            codec_long_name=str(stream.get("codec_long_name", "")),
            profile=stream.get("profile"),
            sample_rate=_int(stream.get("sample_rate")) or 48_000,
            channels=_int(stream.get("channels")) or 2,
            channel_layout=stream.get("channel_layout"),
            bit_rate=_int(stream.get("bit_rate")) or _int(tags.get("BPS")),
            bits_per_raw_sample=_int(stream.get("bits_per_raw_sample")),
            sample_fmt=stream.get("sample_fmt"),
            duration=_float(stream.get("duration")),
            language=tags.get("language"),
            title=tags.get("title"),
            disposition={k: int(v) for k, v in (stream.get("disposition") or {}).items()},
        )

    def _subtitle_stream(self, stream: dict[str, Any]) -> SubtitleStreamInfo:
        tags = stream.get("tags") or {}
        disposition = stream.get("disposition") or {}
        return SubtitleStreamInfo(
            index=_int(stream.get("index")) or 0,
            codec=str(stream.get("codec_name", "unknown")),
            language=tags.get("language"),
            title=tags.get("title"),
            forced=bool(disposition.get("forced")),
            default=bool(disposition.get("default")),
        )

    @staticmethod
    def _duration_fallback(video: list[VideoStreamInfo], audio: list[AudioStreamInfo]) -> float:
        durations = [s.duration for s in (*video, *audio) if s.duration]
        return max(durations) if durations else 0.0
