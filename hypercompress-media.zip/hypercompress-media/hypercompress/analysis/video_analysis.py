"""Phase 03 (video half): what is actually in these pixels?

Motion, spatial detail, film grain, darkness and staticness are the five signals
that determine how many bits a video genuinely needs. They are measured from
decoded luma samples rather than inferred from the container's bitrate, because
an over-bitrated source lies about its complexity — and those are exactly the
files with the most to give up.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from hypercompress.analysis.frames import FrameWindow
from hypercompress.core.types import VideoComplexity

#: Normalisation constants, calibrated against the benchmark corpus so that a
#: value of 1.0 means "as demanding as the hardest content we expect to see".
MOTION_FULL_SCALE = 0.085
SPATIAL_FULL_SCALE = 0.150
GRAIN_FULL_SCALE = 0.018
DARK_LUMA_THRESHOLD = 48.0
STATIC_MOTION_THRESHOLD = 0.004


@dataclass(slots=True)
class FrameMetrics:
    """Per-frame measurements retained for scene analysis."""

    timestamps: np.ndarray
    motion: np.ndarray
    spatial: np.ndarray
    luma: np.ndarray
    grain: np.ndarray

    @property
    def count(self) -> int:
        return int(self.timestamps.size)


def _box_blur(frames: np.ndarray) -> np.ndarray:
    """Separable 3x3 mean filter over a stack of frames."""
    padded = np.pad(frames, ((0, 0), (1, 1), (1, 1)), mode="edge").astype(np.float32)
    horizontal = (padded[:, :, :-2] + padded[:, :, 1:-1] + padded[:, :, 2:]) / 3.0
    return (horizontal[:, :-2, :] + horizontal[:, 1:-1, :] + horizontal[:, 2:, :]) / 3.0


def measure_window(window: FrameWindow) -> FrameMetrics:
    """Compute per-frame motion, edge energy, luma and grain for one window."""
    frames = window.frames.astype(np.float32)
    n = frames.shape[0]
    timestamps = np.array([window.timestamp(i) for i in range(n)], dtype=np.float64)

    if n > 1:
        diff = np.abs(frames[1:] - frames[:-1]).mean(axis=(1, 2)) / 255.0
        motion = np.concatenate([[diff[0]], diff])
    else:
        motion = np.zeros(1, dtype=np.float64)

    grad_x = np.abs(np.diff(frames, axis=2)).mean(axis=(1, 2))
    grad_y = np.abs(np.diff(frames, axis=1)).mean(axis=(1, 2))
    spatial = (grad_x + grad_y) / (2 * 255.0)

    luma = frames.mean(axis=(1, 2))

    blurred = _box_blur(window.frames)
    residual = frames - blurred
    # Grain lives in flat regions: mask out structured areas using local gradient.
    flat_mask = np.abs(residual) < 12.0
    counts = flat_mask.sum(axis=(1, 2)).clip(min=1)
    grain = np.sqrt(((residual**2) * flat_mask).sum(axis=(1, 2)) / counts) / 255.0

    return FrameMetrics(
        timestamps=timestamps,
        motion=motion.astype(np.float64),
        spatial=spatial.astype(np.float64),
        luma=luma.astype(np.float64),
        grain=grain.astype(np.float64),
    )


def analyse_video(
    windows: list[FrameWindow], scene_count: int = 0
) -> tuple[VideoComplexity, list[FrameMetrics]]:
    """Aggregate sampled windows into a :class:`VideoComplexity`."""
    metrics = [measure_window(w) for w in windows]
    motion = np.concatenate([m.motion for m in metrics])
    spatial = np.concatenate([m.spatial for m in metrics])
    luma = np.concatenate([m.luma for m in metrics])
    grain = np.concatenate([m.grain for m in metrics])
    sampled_seconds = sum(w.duration for w in windows)
    frames = int(motion.size)

    # Trimmed means resist single-cut outliers from the sampling boundaries.
    motion_mean = float(np.mean(np.sort(motion)[: max(1, int(motion.size * 0.95))]))
    spatial_mean = float(np.mean(spatial))
    grain_mean = float(np.median(grain))

    complexity = VideoComplexity(
        motion=float(np.clip(motion_mean / MOTION_FULL_SCALE, 0.0, 1.0)),
        spatial=float(np.clip(spatial_mean / SPATIAL_FULL_SCALE, 0.0, 1.0)),
        temporal_variance=float(np.var(motion) * 1000.0),
        grain=float(np.clip(grain_mean / GRAIN_FULL_SCALE, 0.0, 1.0)),
        dark_ratio=float(np.mean(luma < DARK_LUMA_THRESHOLD)),
        static_ratio=float(np.mean(motion < STATIC_MOTION_THRESHOLD)),
        scene_change_rate=(scene_count / sampled_seconds) if sampled_seconds > 0 else 0.0,
        sampled_seconds=sampled_seconds,
        frames_sampled=frames,
    )
    return complexity, metrics


def estimate_bits_per_pixel(complexity: VideoComplexity, quality_floor: float = 0.9) -> float:
    """Bits per pixel per second an efficient modern encoder needs for this content.

    Anchored on measured AV1/HEVC behaviour: near-static screen content survives
    on roughly 0.010 bpp, while grainy high-motion film needs about 0.115 bpp to
    hold a high-quality floor. The quality term scales the whole curve because
    rate rises steeply as the floor approaches transparency.
    """
    base = 0.010 + 0.105 * complexity.score
    grain_penalty = 1.0 + 0.35 * complexity.grain
    dark_bonus = 1.0 - 0.10 * complexity.dark_ratio
    quality_scale = 0.55 + 1.25 * max(0.0, min(1.0, quality_floor)) ** 2.2
    return float(base * grain_penalty * dark_bonus * quality_scale)


def detect_text_content(metrics: list[FrameMetrics]) -> bool:
    """Screen recordings and slides: very high edge energy with near-zero motion."""
    if not metrics:
        return False
    spatial = np.concatenate([m.spatial for m in metrics])
    motion = np.concatenate([m.motion for m in metrics])
    return bool(np.mean(spatial) > 0.055 and np.mean(motion) < 0.010)


def detect_animation(metrics: list[FrameMetrics]) -> bool:
    """Animation: large flat regions (low grain) with sharp edges and bursty motion."""
    if not metrics:
        return False
    grain = np.concatenate([m.grain for m in metrics])
    spatial = np.concatenate([m.spatial for m in metrics])
    motion = np.concatenate([m.motion for m in metrics])
    flat = float(np.median(grain)) < 0.0045
    bursty = float(np.std(motion)) > 0.6 * float(np.mean(motion) + 1e-9)
    return bool(flat and spatial.mean() > 0.02 and bursty)
