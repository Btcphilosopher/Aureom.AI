"""Phase 06: shot boundaries and per-scene character.

Two detectors are provided. The sampled detector works from the luma windows the
analysis stage already decoded, costing nothing extra. The full detector runs
FFmpeg's ``scdet`` across the whole file when the encoder is going to be given a
real per-scene bit allocation and needs exact boundaries.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from hypercompress.analysis.frames import FrameWindow
from hypercompress.analysis.video_analysis import FrameMetrics
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner, build_filter_chain
from hypercompress.core.logging import get_logger
from hypercompress.core.types import Scene

log = get_logger("analysis.scenes")

_SCD_TIME_RE = re.compile(r"lavfi\.scd\.time=([0-9.]+)")
_SCD_SCORE_RE = re.compile(r"lavfi\.scd\.score=([0-9.]+)")

DEFAULT_THRESHOLD = 0.115
"""Mean absolute luma difference above which a cut is declared."""


def detect_scenes_sampled(
    windows: list[FrameWindow],
    metrics: list[FrameMetrics],
    *,
    threshold: float = DEFAULT_THRESHOLD,
) -> list[Scene]:
    """Derive scenes from already-decoded sample windows.

    Boundaries are adaptive: a cut must exceed both an absolute floor and a
    multiple of the local median difference, so a high-motion sports sequence is
    not shredded into hundreds of false shots.
    """
    scenes: list[Scene] = []
    index = 0
    for window, metric in zip(windows, metrics, strict=False):
        if metric.count == 0:
            continue
        local_median = float(np.median(metric.motion)) or 1e-6
        adaptive = max(threshold, local_median * 3.5)
        cuts = [0]
        for i in range(1, metric.count):
            if metric.motion[i] >= adaptive:
                cuts.append(i)
        cuts.append(metric.count)
        for start_i, end_i in zip(cuts[:-1], cuts[1:], strict=False):
            if end_i <= start_i:
                continue
            segment = slice(start_i, end_i)
            motion = float(np.mean(metric.motion[segment]))
            spatial = float(np.mean(metric.spatial[segment]))
            luma = float(np.mean(metric.luma[segment]))
            grain = float(np.mean(metric.grain[segment]))
            scenes.append(
                Scene(
                    index=index,
                    start=float(metric.timestamps[start_i]),
                    end=float(metric.timestamps[end_i - 1] + 1.0 / (window.fps or 1)),
                    score=float(metric.motion[start_i]),
                    mean_luma=luma,
                    motion=float(np.clip(motion / 0.085, 0, 1)),
                    spatial_energy=float(np.clip(spatial / 0.150, 0, 1)),
                    grain=float(np.clip(grain / 0.018, 0, 1)),
                    is_dark=luma < 48.0,
                    is_static=motion < 0.004,
                    is_high_motion=motion > 0.045,
                    has_text=spatial > 0.055 and motion < 0.010,
                )
            )
            index += 1
    return scenes


def detect_scenes_full(
    runner: FFmpegRunner,
    path: str | Path,
    *,
    threshold: float = 10.0,
    timeout: float = 3_600.0,
) -> list[float]:
    """Exact cut timestamps from FFmpeg's ``scdet`` filter across the whole file."""
    chain = build_filter_chain(
        [("scdet", {"threshold": f"{threshold:g}"}), ("metadata", {"mode": "print", "file": "-"})]
    )
    args = (
        ArgBuilder()
        .path("-i", path)
        .opt("-vf", chain)
        .flag("-an")
        .opt("-f", "null")
        .path(None, "-")
    )
    result = runner.run(args, timeout=timeout, check=False)
    text = result.stdout + result.stderr
    times = [float(m) for m in _SCD_TIME_RE.findall(text)]
    log.info("scene detection complete", extra={"cuts": len(times), "path": str(path)})
    return sorted(set(times))


def scenes_from_cuts(cuts: list[float], duration: float) -> list[Scene]:
    """Turn a list of cut timestamps into contiguous :class:`Scene` intervals."""
    boundaries = [0.0, *[c for c in cuts if 0 < c < duration], duration]
    scenes = []
    for i, (start, end) in enumerate(zip(boundaries[:-1], boundaries[1:], strict=False)):
        if end - start <= 0:
            continue
        scenes.append(Scene(index=i, start=start, end=end))
    return scenes


def allocate_scene_bitrates(
    scenes: list[Scene], average_bitrate: float, *, spread: float = 0.55
) -> list[tuple[Scene, float]]:
    """Distribute a bit budget across scenes in proportion to complexity.

    The allocation is mean-preserving: the duration-weighted average of the
    per-scene bitrates equals ``average_bitrate``, so a scene-aware encode of a
    given target size still lands on that size. ``spread`` controls how far the
    hardest scene may exceed the easiest.
    """
    if not scenes:
        return []
    total_duration = sum(s.duration for s in scenes) or 1.0
    weights = np.array([1.0 + spread * (s.complexity - 0.5) * 2 for s in scenes])
    weights = np.clip(weights, 0.35, 2.5)
    durations = np.array([s.duration for s in scenes])
    weighted_mean = float((weights * durations).sum() / total_duration)
    normalised = weights / (weighted_mean or 1.0)
    return [
        (scene, float(average_bitrate * factor))
        for scene, factor in zip(scenes, normalised, strict=False)
    ]
