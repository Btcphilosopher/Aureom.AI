"""Phase 03 / Phase 07 (audio half): spectrum, dynamics and speech-vs-music.

Audio compression decisions hinge on three questions: how much bandwidth carries
real energy, how correlated the channels are, and whether the signal is speech or
music. A stereo podcast whose channels are 99% correlated and whose spectrum dies
at 7 kHz does not need 320 kbps stereo — it needs 32 kbps mono Opus, and this
module is what proves it.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from hypercompress.analysis.frames import AudioWindow
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner, build_filter_chain
from hypercompress.core.logging import get_logger
from hypercompress.core.types import AudioComplexity

log = get_logger("analysis.audio")

SILENCE_DBFS = -50.0
FRAME_SECONDS = 0.046
_LUFS_RE = re.compile(r"I:\s*(-?\d+\.?\d*)\s*LUFS")
_LRA_RE = re.compile(r"LRA:\s*(-?\d+\.?\d*)\s*LU")


def _dbfs(values: np.ndarray) -> np.ndarray:
    return 20.0 * np.log10(np.maximum(np.abs(values), 1e-9))


def _frame_signal(signal: np.ndarray, frame_len: int) -> np.ndarray:
    usable = (len(signal) // frame_len) * frame_len
    if usable == 0:
        return signal.reshape(1, -1)
    return signal[:usable].reshape(-1, frame_len)


def analyse_audio(windows: list[AudioWindow]) -> AudioComplexity:
    """Aggregate sampled PCM windows into an :class:`AudioComplexity`."""
    if not windows:
        return AudioComplexity()

    sample_rate = windows[0].sample_rate
    mono = np.concatenate([w.mono for w in windows]).astype(np.float32)
    if mono.size == 0:
        return AudioComplexity()

    frame_len = max(256, int(sample_rate * FRAME_SECONDS))
    frames = _frame_signal(mono, frame_len)
    rms = np.sqrt((frames.astype(np.float64) ** 2).mean(axis=1))
    rms_db = _dbfs(rms)
    active = rms_db > SILENCE_DBFS
    silence_ratio = float(1.0 - active.mean())

    active_db = rms_db[active] if active.any() else rms_db
    dynamic_range = (
        float(np.percentile(active_db, 95) - np.percentile(active_db, 10))
        if active_db.size > 4
        else 0.0
    )

    # Spectrum from Hann-windowed frames, averaged over active frames only.
    window_fn = np.hanning(frame_len).astype(np.float32)
    spectra = np.abs(np.fft.rfft(frames * window_fn, axis=1))
    if active.any():
        spectra = spectra[active]
    mean_spectrum = spectra.mean(axis=0)
    freqs = np.fft.rfftfreq(frame_len, 1.0 / sample_rate)
    energy = mean_spectrum**2
    total_energy = float(energy.sum()) or 1e-12

    centroid = float((freqs * energy).sum() / total_energy)
    cumulative = np.cumsum(energy)
    rolloff_index = int(np.searchsorted(cumulative, 0.85 * total_energy))
    rolloff = float(freqs[min(rolloff_index, len(freqs) - 1)])
    hf_cut = min(8_000.0, sample_rate / 2 - 1)
    hf_ratio = float(energy[freqs >= hf_cut].sum() / total_energy)

    # Speech has strong 4 Hz syllabic modulation of its envelope; music does not.
    envelope = rms - rms.mean()
    modulation = 0.0
    # A steady tone has no envelope to speak of; without this gate the FFT of
    # numerical noise would masquerade as syllabic modulation.
    modulation_depth = float(rms.std() / (rms.mean() + 1e-12))
    if envelope.size >= 16 and modulation_depth > 0.05:
        env_spectrum = np.abs(np.fft.rfft(envelope * np.hanning(envelope.size)))
        env_freqs = np.fft.rfftfreq(envelope.size, FRAME_SECONDS)
        band = (env_freqs >= 2.0) & (env_freqs <= 8.0)
        if band.any() and env_spectrum.sum() > 0:
            modulation = float(env_spectrum[band].sum() / env_spectrum.sum())

    speech_band = (freqs >= 100) & (freqs <= 4_000)
    speech_energy_ratio = float(energy[speech_band].sum() / total_energy)

    # Spectral flatness separates broadband voiced/unvoiced speech from pure
    # tones and test signals, whose energy collapses into a handful of bins.
    positive = energy[energy > 0]
    flatness = (
        float(np.exp(np.log(positive).mean()) / (positive.mean() + 1e-12)) if positive.size else 0.0
    )
    tonality = float(np.clip(1.0 - flatness * 40.0, 0.0, 1.0))
    speech_likelihood = float(
        np.clip(
            (
                0.42 * speech_energy_ratio
                + 0.28 * min(1.0, silence_ratio / 0.30)
                + 0.30 * min(1.0, modulation / 0.35)
            )
            * (1.0 - 0.85 * tonality),
            0.0,
            1.0,
        )
    )
    music_likelihood = float(
        np.clip(
            0.45 * min(1.0, hf_ratio / 0.12)
            + 0.30 * (1.0 - min(1.0, silence_ratio / 0.30))
            + 0.25 * min(1.0, centroid / 3_500.0),
            0.0,
            1.0,
        )
    )

    correlation = 1.0
    stereo = [w for w in windows if w.channels >= 2]
    if stereo:
        left = np.concatenate([w.samples[:, 0] for w in stereo])
        right = np.concatenate([w.samples[:, 1] for w in stereo])
        if left.std() > 1e-7 and right.std() > 1e-7:
            correlation = float(abs(np.corrcoef(left, right)[0, 1]))
        elif np.allclose(left, right, atol=1e-6):
            correlation = 1.0

    return AudioComplexity(
        silence_ratio=silence_ratio,
        dynamic_range_db=dynamic_range,
        spectral_centroid_hz=centroid,
        spectral_rolloff_hz=rolloff,
        high_freq_energy_ratio=hf_ratio,
        stereo_correlation=correlation,
        speech_likelihood=speech_likelihood,
        music_likelihood=music_likelihood,
        peak_dbfs=float(_dbfs(np.array([np.abs(mono).max()]))[0]),
        rms_dbfs=float(np.mean(rms_db[active])) if active.any() else float(np.mean(rms_db)),
        sampled_seconds=sum(w.duration for w in windows),
    )


def measure_loudness(
    runner: FFmpegRunner, path: str | Path, *, timeout: float = 900.0
) -> tuple[float | None, float | None]:
    """Integrated loudness (LUFS) and loudness range (LU) via EBU R128."""
    chain = build_filter_chain([("ebur128", {"framelog": "verbose"})])
    args = (
        ArgBuilder()
        .path("-i", path)
        .flag("-vn")
        .opt("-af", chain)
        .opt("-f", "null")
        .path(None, "-")
    )
    result = runner.run(args, timeout=timeout, check=False)
    text = result.stderr + result.stdout
    lufs = _LUFS_RE.findall(text)
    lra = _LRA_RE.findall(text)
    return (float(lufs[-1]) if lufs else None, float(lra[-1]) if lra else None)


def recommended_cutoff(complexity: AudioComplexity, *, headroom: float = 1.15) -> int:
    """Lowpass cutoff that preserves everything the source actually contains.

    Encoding bandwidth that holds no energy is pure waste; this returns the
    highest frequency worth spending bits on, snapped to a codec-friendly value.
    """
    target = complexity.spectral_rolloff_hz * headroom
    for cutoff in (4_000, 6_000, 8_000, 12_000, 16_000, 20_000):
        if target <= cutoff:
            return cutoff
    return 20_000


def recommended_sample_rate(complexity: AudioComplexity, source_rate: int) -> int:
    """Lowest standard sample rate that still contains the signal's bandwidth."""
    needed = complexity.spectral_rolloff_hz * 2.2
    for rate in (8_000, 12_000, 16_000, 24_000, 32_000, 44_100, 48_000):
        if rate >= needed and rate <= source_rate:
            return rate
    return source_rate


def recommended_channels(complexity: AudioComplexity, source_channels: int) -> int:
    """Collapse to mono only when the channels genuinely carry the same signal."""
    if source_channels <= 1:
        return 1
    if complexity.is_effectively_mono:
        return 1
    return source_channels
