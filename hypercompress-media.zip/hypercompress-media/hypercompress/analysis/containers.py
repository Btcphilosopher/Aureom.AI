"""Container knowledge: what FFmpeg calls a format versus what we call it, and
which codecs each container can legally carry."""

from __future__ import annotations

from pathlib import Path
from typing import Final

from hypercompress.core.types import CodecFamily

_FORMAT_ALIASES: Final[dict[str, str]] = {
    "mov,mp4,m4a,3gp,3g2,mj2": "mp4",
    "matroska,webm": "mkv",
    "mpegts": "ts",
    "asf": "wmv",
    "ogg": "ogg",
    "wav": "wav",
    "flac": "flac",
    "mp3": "mp3",
    "aac": "aac",
    "avi": "avi",
    "webm": "webm",
}

VIDEO_EXTENSIONS: Final[frozenset[str]] = frozenset(
    {
        ".mp4",
        ".mkv",
        ".mov",
        ".avi",
        ".webm",
        ".m4v",
        ".ts",
        ".mts",
        ".m2ts",
        ".wmv",
        ".flv",
        ".mpg",
        ".mpeg",
        ".vob",
        ".ogv",
        ".3gp",
        ".mxf",
    }
)
AUDIO_EXTENSIONS: Final[frozenset[str]] = frozenset(
    {
        ".wav",
        ".flac",
        ".mp3",
        ".aac",
        ".ogg",
        ".oga",
        ".m4a",
        ".opus",
        ".wma",
        ".aiff",
        ".aif",
        ".alac",
        ".ape",
        ".wv",
        ".dsf",
    }
)

#: Which codecs each output container accepts.
CONTAINER_SUPPORT: Final[dict[str, frozenset[CodecFamily]]] = {
    "mkv": frozenset(
        {
            CodecFamily.AV1,
            CodecFamily.HEVC,
            CodecFamily.H264,
            CodecFamily.VP9,
            CodecFamily.OPUS,
            CodecFamily.AAC,
            CodecFamily.FLAC,
        }
    ),
    "mp4": frozenset(
        {
            CodecFamily.AV1,
            CodecFamily.HEVC,
            CodecFamily.H264,
            CodecFamily.VP9,
            CodecFamily.OPUS,
            CodecFamily.AAC,
            CodecFamily.FLAC,
        }
    ),
    "webm": frozenset({CodecFamily.AV1, CodecFamily.VP9, CodecFamily.OPUS}),
    "opus": frozenset({CodecFamily.OPUS}),
    "m4a": frozenset({CodecFamily.AAC, CodecFamily.FLAC}),
    "flac": frozenset({CodecFamily.FLAC}),
    "ogg": frozenset({CodecFamily.OPUS, CodecFamily.FLAC}),
    "mka": frozenset({CodecFamily.OPUS, CodecFamily.AAC, CodecFamily.FLAC}),
}

#: Containers that can carry text subtitles and chapters.
RICH_CONTAINERS: Final[frozenset[str]] = frozenset({"mkv", "mp4", "webm"})


def container_from_format(format_name: str) -> str:
    """Normalise ffprobe's ``format_name`` to a single canonical container name."""
    if format_name in _FORMAT_ALIASES:
        return _FORMAT_ALIASES[format_name]
    first = format_name.split(",")[0].strip()
    return _FORMAT_ALIASES.get(first, first or "unknown")


def is_media_extension(path: str | Path) -> bool:
    suffix = Path(path).suffix.lower()
    return suffix in VIDEO_EXTENSIONS or suffix in AUDIO_EXTENSIONS


def container_supports(container: str, codec: CodecFamily) -> bool:
    allowed = CONTAINER_SUPPORT.get(container.lower())
    return True if allowed is None else codec in allowed


def choose_container(
    video: CodecFamily | None,
    audio: CodecFamily | None,
    *,
    preferred: str | None = None,
    need_subtitles: bool = False,
) -> str:
    """Pick the smallest container that carries everything required."""
    families = [c for c in (video, audio) if c is not None]
    candidates = [preferred] if preferred else []
    if video is None:
        candidates += ["opus", "m4a", "flac", "mka", "mkv"]
    else:
        candidates += ["mkv", "mp4", "webm"]
    for container in candidates:
        if not container:
            continue
        if need_subtitles and container not in RICH_CONTAINERS:
            continue
        if all(container_supports(container, family) for family in families):
            return container
    return "mkv"


def audio_only_container(codec: CodecFamily) -> str:
    return {
        CodecFamily.OPUS: "opus",
        CodecFamily.AAC: "m4a",
        CodecFamily.FLAC: "flac",
    }.get(codec, "mka")


#: Containers able to carry a subtitle track at all. WebM is restricted to
#: WebVTT, MP4 to the timed-text flavour, and the raw audio containers to none.
SUBTITLE_CAPABLE: Final[frozenset[str]] = frozenset({"mkv", "webm", "mp4", "mov"})


def container_supports_subtitles(container: str) -> bool:
    """Whether ``container`` can carry subtitles without losing them silently."""
    return container.lower() in SUBTITLE_CAPABLE
