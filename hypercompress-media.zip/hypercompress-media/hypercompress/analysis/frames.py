"""Frame and sample extraction — the eyes and ears of the analysis stage.

A single decode pass produces the luma planes and PCM samples that feed scene
detection, complexity estimation, grain measurement and audio classification.
Analysis never decodes a whole 4K feature: it samples evenly spaced windows and
extrapolates, which keeps analysis cost roughly constant regardless of runtime.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from hypercompress.core.errors import ProbeError
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner, build_filter_chain
from hypercompress.core.logging import get_logger

log = get_logger("analysis.frames")


@dataclass(slots=True)
class FrameWindow:
    """A decoded window of luma frames."""

    start: float
    fps: float
    width: int
    height: int
    frames: np.ndarray  # shape (n, height, width), dtype uint8

    @property
    def count(self) -> int:
        return int(self.frames.shape[0])

    @property
    def duration(self) -> float:
        return self.count / self.fps if self.fps else 0.0

    def timestamp(self, index: int) -> float:
        return self.start + (index / self.fps if self.fps else 0.0)


@dataclass(slots=True)
class AudioWindow:
    """A decoded window of PCM audio."""

    start: float
    sample_rate: int
    channels: int
    samples: np.ndarray  # shape (n, channels), dtype float32

    @property
    def duration(self) -> float:
        return len(self.samples) / self.sample_rate if self.sample_rate else 0.0

    @property
    def mono(self) -> np.ndarray:
        if self.channels == 1:
            return self.samples[:, 0]
        return self.samples.mean(axis=1)


def sample_offsets(
    duration: float, clips: int, clip_seconds: float, skip_edges: float = 0.03
) -> list[float]:
    """Evenly spaced sampling offsets that avoid leaders, credits and black frames."""
    if duration <= clip_seconds or clips <= 1:
        return [0.0]
    usable_start = duration * skip_edges
    usable_end = max(usable_start + clip_seconds, duration * (1 - skip_edges) - clip_seconds)
    span = usable_end - usable_start
    if span <= 0:
        return [0.0]
    return [usable_start + span * (i / (clips - 1)) for i in range(clips)]


def decode_luma_window(
    runner: FFmpegRunner,
    path: str | Path,
    *,
    start: float,
    duration: float,
    fps: float = 6.0,
    width: int = 320,
    height: int = 180,
) -> FrameWindow:
    """Decode a downscaled greyscale window into a numpy array."""
    chain = build_filter_chain(
        [
            ("fps", {"fps": f"{fps:g}"}),
            ("scale", {"width": width, "height": height, "flags": "bilinear"}),
            ("format", {"pix_fmts": "gray"}),
        ]
    )
    args = (
        ArgBuilder()
        .opt("-ss", f"{max(0.0, start):.3f}")
        .path("-i", path)
        .opt("-t", f"{duration:.3f}")
        .opt("-vf", chain)
        .flag("-an")
        .opt("-f", "rawvideo")
        .opt("-pix_fmt", "gray")
        .path(None, "pipe:1")
    )
    raw = runner.decode_raw(path, args=args)
    frame_bytes = width * height
    count = len(raw) // frame_bytes
    if count == 0:
        raise ProbeError(f"no frames decoded from {path} at offset {start:.1f}s")
    frames = np.frombuffer(raw[: count * frame_bytes], dtype=np.uint8).reshape(count, height, width)
    return FrameWindow(start=start, fps=fps, width=width, height=height, frames=frames)


def decode_audio_window(
    runner: FFmpegRunner,
    path: str | Path,
    *,
    start: float,
    duration: float,
    sample_rate: int = 24_000,
    channels: int = 2,
    stream_index: int | None = None,
) -> AudioWindow:
    """Decode a PCM window as float32."""
    args = ArgBuilder().opt("-ss", f"{max(0.0, start):.3f}").path("-i", path)
    if stream_index is not None:
        args.opt("-map", f"0:a:{stream_index}")
    args = (
        args.opt("-t", f"{duration:.3f}")
        .flag("-vn")
        .opt("-ac", channels)
        .opt("-ar", sample_rate)
        .opt("-f", "f32le")
        .opt("-c:a", "pcm_f32le")
        .path(None, "pipe:1")
    )
    raw = runner.decode_raw(path, args=args)
    if len(raw) < 4 * channels:
        raise ProbeError(f"no audio decoded from {path} at offset {start:.1f}s")
    flat = np.frombuffer(raw[: (len(raw) // (4 * channels)) * 4 * channels], dtype=np.float32)
    samples = flat.reshape(-1, channels)
    return AudioWindow(start=start, sample_rate=sample_rate, channels=channels, samples=samples)


def sample_video(
    runner: FFmpegRunner,
    path: str | Path,
    *,
    duration: float,
    clips: int = 3,
    clip_seconds: float = 4.0,
    fps: float = 6.0,
    width: int = 320,
    height: int = 180,
) -> list[FrameWindow]:
    """Decode several evenly spaced luma windows, tolerating individual failures."""
    windows: list[FrameWindow] = []
    for offset in sample_offsets(duration, clips, clip_seconds):
        try:
            windows.append(
                decode_luma_window(
                    runner,
                    path,
                    start=offset,
                    duration=min(clip_seconds, max(0.5, duration - offset)),
                    fps=fps,
                    width=width,
                    height=height,
                )
            )
        except (ProbeError, OSError) as exc:
            log.warning("luma window failed", extra={"offset": offset, "error": str(exc)})
    if not windows:
        raise ProbeError(f"video sampling produced nothing for {path}")
    return windows


def sample_audio(
    runner: FFmpegRunner,
    path: str | Path,
    *,
    duration: float,
    clips: int = 3,
    clip_seconds: float = 6.0,
    sample_rate: int = 24_000,
    channels: int = 2,
) -> list[AudioWindow]:
    windows: list[AudioWindow] = []
    for offset in sample_offsets(duration, clips, clip_seconds):
        try:
            windows.append(
                decode_audio_window(
                    runner,
                    path,
                    start=offset,
                    duration=min(clip_seconds, max(0.5, duration - offset)),
                    sample_rate=sample_rate,
                    channels=channels,
                )
            )
        except (ProbeError, OSError) as exc:
            log.warning("audio window failed", extra={"offset": offset, "error": str(exc)})
    if not windows:
        raise ProbeError(f"audio sampling produced nothing for {path}")
    return windows
