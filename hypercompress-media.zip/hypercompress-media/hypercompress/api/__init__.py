"""HTTP service.

See :mod:`hypercompress.api.service` for the endpoints and the reasoning
behind which of them are synchronous.
"""

from __future__ import annotations

from hypercompress.api.service import create_app, get_app

__all__ = ["create_app", "get_app"]
