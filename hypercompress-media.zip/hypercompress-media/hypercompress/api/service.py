"""HTTP API (Phase 20).

A thin, honest surface over the engine. Three decisions shape it:

**Optimisation is asynchronous, analysis is synchronous.** An encode takes
minutes to hours, so ``POST /jobs`` returns 202 with an identifier and the
caller polls. Analysis takes seconds, so ``POST /analyse`` answers directly —
and it is the endpoint that makes a considered rollout possible, because it
predicts what would happen without spending the compute to find out.

**Every response carries its caveats.** A job result includes whether the
quality floor was met, whether a size target was reached, and whether VMAF was
measured or estimated. A client that only reads ``output_size`` still gets a
correct number; a client that reads the whole body cannot be misled.

**Authorisation happens per request, on the permission.** There is no session,
no implicit tenant from a previous call, and no endpoint that trusts a tenant
identifier supplied in a body. The tenant comes from the token.

The service does not accept encoder arguments in any form. See
:mod:`hypercompress.security.access` for why that is a design property rather
than an omission.
"""

from __future__ import annotations

import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Annotated, Any

from fastapi import Depends, FastAPI, Header, HTTPException, Response, status
from pydantic import BaseModel, Field

from hypercompress import __version__
from hypercompress.analysis.complexity import ContentAnalyser
from hypercompress.analysis.media_probe import MediaProbe
from hypercompress.analytics.metrics import METRICS
from hypercompress.config import HyperCompressConfig
from hypercompress.core.errors import (
    AuthorizationError,
    ConfigError,
    HyperCompressError,
    QuotaExceeded,
    SecurityError,
    StorageError,
    UnsupportedMediaError,
    ValidationError,
)
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.logging import get_logger
from hypercompress.core.types import JobPriority, JobSpec, JobState
from hypercompress.core.units import parse_size
from hypercompress.distributed.queue import JobQueue, build_queue
from hypercompress.distributed.worker import Scheduler
from hypercompress.optimisation.planner import EncodePlanner
from hypercompress.optimisation.profiles import all_profiles, get_profile, suggest_profile
from hypercompress.security.access import Permission, Principal, SecurityContext

log = get_logger(__name__)


# --------------------------------------------------------------------------------------
# Request and response models
# --------------------------------------------------------------------------------------


class SubmitJobRequest(BaseModel):
    """A request to optimise one file."""

    source: str = Field(description="Path or URI of the file to optimise")
    destination: str | None = Field(default=None, description="Where to write the result")
    profile: str = Field(default="balanced")
    target_size: str | None = Field(
        default=None, description="Byte target such as '1GB' or '750MiB'"
    )
    quality_floor: float | None = Field(default=None, ge=0.0, le=1.0)
    priority: JobPriority = JobPriority.NORMAL
    compute_budget_seconds: float | None = Field(default=None, gt=0)
    dry_run: bool = Field(default=False, description="Encode and validate, then discard the output")


class SubmitJobResponse(BaseModel):
    job_id: str
    state: JobState
    queue_position: int


class JobStatusResponse(BaseModel):
    job_id: str
    state: JobState
    error: str | None = None
    source_size: int | None = None
    output_size: int | None = None
    reduction: float | None = None
    quality: dict[str, Any] | None = None
    quality_met: bool | None = None
    target_met: bool | None = None
    caveats: list[str] = Field(default_factory=list)


class AnalyseRequest(BaseModel):
    source: str
    profile: str | None = None


class AnalyseResponse(BaseModel):
    """What the platform thinks it would do, without doing it."""

    source: str
    duration: float
    size: int
    content_class: str
    confidence: float
    rationale: list[str]
    suggested_profile: str
    plan: str
    predicted_size: int
    predicted_reduction: float
    worth_encoding: bool
    reason: str
    disclaimer: str = (
        "A prediction from the content model, not a measurement. Nothing has been encoded."
    )


class ProfileResponse(BaseModel):
    name: str
    description: str
    lossless: bool
    extreme: bool
    quality_floor: float | None
    suits: list[str]


class HealthResponse(BaseModel):
    status: str
    version: str
    ffmpeg: str | None
    encoders: list[str]
    vmaf_available: bool
    queue: dict[str, int]
    notes: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------------------
# Application state
# --------------------------------------------------------------------------------------


class ServiceState:
    """Everything the request handlers need, built once."""

    def __init__(self, config: HyperCompressConfig | None = None) -> None:
        self.config = config or HyperCompressConfig.load()
        self.runner = FFmpegRunner()
        self.queue: JobQueue = build_queue(
            self.config.distributed.queue_backend, path=self.config.distributed.sqlite_path
        )
        self.scheduler = Scheduler(self.queue, self.config)
        self.security = SecurityContext(
            self.config.security,
            allowed_roots=list(self.config.storage.allowed_roots or []),
        )
        self.probe = MediaProbe(self.runner)
        self.analyser = ContentAnalyser(self.runner)


STATE: ServiceState | None = None


def get_state() -> ServiceState:
    if STATE is None:  # pragma: no cover - set during app construction
        raise HTTPException(status_code=503, detail="the service is not initialised")
    return STATE


#: Exceptions carry a process exit code for the CLI, which is a completely
#: different numbering scheme from HTTP status. Reusing one as the other returns
#: nonsense like ``77 Unknown`` to clients, so the two are mapped explicitly.
_HTTP_STATUS: dict[type[Exception], int] = {
    AuthorizationError: status.HTTP_403_FORBIDDEN,
    SecurityError: status.HTTP_400_BAD_REQUEST,
    QuotaExceeded: status.HTTP_429_TOO_MANY_REQUESTS,
    ValidationError: status.HTTP_400_BAD_REQUEST,
    UnsupportedMediaError: status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
    ConfigError: status.HTTP_400_BAD_REQUEST,
    StorageError: status.HTTP_404_NOT_FOUND,
}


def http_status_for(exc: HyperCompressError) -> int:
    """The HTTP status that corresponds to a platform error."""
    for error_type, code in _HTTP_STATUS.items():
        if isinstance(exc, error_type):
            return code
    return status.HTTP_400_BAD_REQUEST


def _principal(
    permission: Permission,
    authorization: str | None,
    state: ServiceState,
) -> Principal:
    token = None
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
    try:
        return state.security.authorise(token, permission)
    except HyperCompressError as exc:
        # Authentication and authorisation failures are reported identically so
        # that a caller cannot use the difference to enumerate valid tokens.
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc


def require(permission: Permission) -> Any:
    """Dependency factory binding an endpoint to one permission."""

    def dependency(
        authorization: Annotated[str | None, Header()] = None,
        state: ServiceState = Depends(get_state),
    ) -> Principal:
        return _principal(permission, authorization, state)

    return dependency


# --------------------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------------------


def create_app(config: HyperCompressConfig | None = None) -> FastAPI:
    """Build the service."""
    global STATE
    STATE = ServiceState(config)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        state = get_state()
        if not state.runner.capabilities.has_vmaf:
            # Logged at startup so an operator learns this at deploy time, and
            # also reported by /health so it cannot be missed later.
            log.warning(
                "libvmaf is not available; VMAF figures will be estimates",
                extra={"ffmpeg": state.runner.capabilities.version},
            )
        yield

    app = FastAPI(
        title="HYPERCOMPRESS MEDIA",
        version=__version__,
        description=(
            "Hyperscale media compression. Quality is measured, not assumed, and every "
            "response states what was measured and what was estimated."
        ),
        lifespan=lifespan,
    )

    # -- jobs ------------------------------------------------------------------------
    @app.post("/jobs", response_model=SubmitJobResponse, status_code=status.HTTP_202_ACCEPTED)
    def submit_job(
        request: SubmitJobRequest,
        principal: Principal = Depends(require(Permission.SUBMIT_JOB)),
        state: ServiceState = Depends(get_state),
    ) -> SubmitJobResponse:
        try:
            source = state.security.paths.check(request.source, must_exist=True)
            destination = (
                str(state.security.paths.check(request.destination))
                if request.destination
                else None
            )
            target = parse_size(request.target_size) if request.target_size else None
            size = source.stat().st_size
            state.security.quotas.check_submission(principal.tenant, size_bytes=size)

            job = JobSpec(
                job_id=uuid.uuid4().hex,
                source_uri=str(source),
                destination_uri=destination,
                profile=request.profile,
                target_size=target,
                quality_floor=request.quality_floor,
                priority=request.priority,
                # The tenant comes from the token, never from the request body.
                tenant=principal.tenant,
                principal=principal.name,
                compute_budget_seconds=request.compute_budget_seconds,
                dry_run=request.dry_run,
            )
            job_id = state.scheduler.submit(job)
            state.security.quotas.record_submission(principal.tenant, size_bytes=size)
            state.security.audit("job.submit", principal, job_id=job_id, source=str(source))
            METRICS.queue_depth(state.queue.depth())
            return SubmitJobResponse(
                job_id=job_id, state=JobState.QUEUED, queue_position=state.queue.depth()
            )
        except HyperCompressError as exc:
            raise HTTPException(status_code=http_status_for(exc), detail=str(exc)) from exc

    @app.get("/jobs/{job_id}", response_model=JobStatusResponse)
    def job_status(
        job_id: str,
        principal: Principal = Depends(require(Permission.READ_JOB)),
        state: ServiceState = Depends(get_state),
    ) -> JobStatusResponse:
        job_state = state.queue.state_of(job_id)
        if job_state is JobState.PENDING:
            raise HTTPException(status_code=404, detail="no such job")

        result = state.queue.result_of(job_id) or {}
        if result and state.config.security.tenant_isolation:
            # The manifest carries the owning tenant; a job belonging to another
            # tenant is reported as absent rather than as forbidden.
            owner = str(result.get("tenant", principal.tenant))
            if not principal.owns(owner):
                raise HTTPException(status_code=404, detail="no such job")

        quality = result.get("quality") if result else None
        source_size = result.get("source_size") if result else None
        output_size = result.get("output_size") if result else None
        reduction = None
        if source_size and output_size:
            reduction = 1.0 - (float(output_size) / float(source_size))

        return JobStatusResponse(
            job_id=job_id,
            state=job_state,
            error=state.queue.error_of(job_id),
            source_size=source_size,
            output_size=output_size,
            reduction=reduction,
            quality=quality,
            quality_met=result.get("validated") if result else None,
            caveats=list(result.get("caveats", [])) if result else [],
        )

    @app.get("/jobs/{job_id}/metrics")
    def job_metrics(
        job_id: str,
        principal: Principal = Depends(require(Permission.READ_METRICS)),
        state: ServiceState = Depends(get_state),
    ) -> dict[str, Any]:
        result = state.queue.result_of(job_id)
        if result is None:
            raise HTTPException(status_code=404, detail="no results for that job yet")
        return {
            "job_id": job_id,
            "usage": result.get("usage"),
            "candidates_evaluated": result.get("candidates_evaluated"),
            "search_log": result.get("search_log", []),
            "quality": result.get("quality"),
        }

    # -- analysis ---------------------------------------------------------------------
    @app.post("/analyse", response_model=AnalyseResponse)
    def analyse(
        request: AnalyseRequest,
        principal: Principal = Depends(require(Permission.ANALYSE)),
        state: ServiceState = Depends(get_state),
    ) -> AnalyseResponse:
        try:
            source = state.security.paths.check(request.source, must_exist=True)
            media = state.probe.probe(source)
            analysis = state.analyser.analyse(media)
            profile_name = request.profile or suggest_profile(analysis.content_class).name
            profile = get_profile(profile_name)
            planner = EncodePlanner(state.runner.capabilities, profile.apply(state.config), profile)
            plan = planner.initial_plan(media, analysis)
            predicted = planner.predict_size(media, analysis, plan)
            worth, reason = planner.worth_encoding(media, predicted)

            return AnalyseResponse(
                source=str(source),
                duration=media.duration,
                size=media.size_bytes,
                content_class=analysis.content_class.value,
                confidence=analysis.confidence,
                rationale=list(analysis.rationale),
                suggested_profile=profile_name,
                plan=plan.fingerprint,
                predicted_size=predicted,
                predicted_reduction=1.0 - (predicted / max(media.size_bytes, 1)),
                worth_encoding=worth,
                reason=reason,
            )
        except HyperCompressError as exc:
            raise HTTPException(status_code=http_status_for(exc), detail=str(exc)) from exc

    # -- profiles ---------------------------------------------------------------------
    @app.get("/profiles", response_model=list[ProfileResponse])
    def profiles(
        principal: Principal = Depends(require(Permission.READ_PROFILE)),
        state: ServiceState = Depends(get_state),
    ) -> list[ProfileResponse]:
        return [
            ProfileResponse(
                name=name,
                description=profile.description,
                lossless=profile.lossless,
                extreme=profile.extreme,
                quality_floor=profile.quality.get("floor") if profile.quality else None,
                suits=[c.value for c in profile.suits],
            )
            for name, profile in sorted(all_profiles(state.config).items())
        ]

    # -- fleet ------------------------------------------------------------------------
    @app.get("/workers")
    def workers(
        principal: Principal = Depends(require(Permission.READ_METRICS)),
        state: ServiceState = Depends(get_state),
    ) -> dict[str, Any]:
        return {
            "queue": state.queue.stats(),
            "depth": state.queue.depth(),
            "quotas": state.security.quotas.snapshot(),
        }

    @app.get("/metrics")
    def metrics(state: ServiceState = Depends(get_state)) -> Response:
        # Deliberately unauthenticated: Prometheus scrapers rarely carry bearer
        # tokens, and the endpoint exposes aggregate counters, not media or
        # paths. Restrict it at the network layer.
        body, content_type = METRICS.render()
        return Response(content=body, media_type=content_type)

    @app.get("/health", response_model=HealthResponse)
    def health(state: ServiceState = Depends(get_state)) -> HealthResponse:
        caps = state.runner.capabilities
        encoders = [
            name
            for name in ("libsvtav1", "libaom-av1", "libx265", "libx264", "libvpx-vp9", "libopus")
            if caps.has_encoder(name)
        ]
        healthy = bool(encoders)

        # Derived per request rather than cached at startup. The VMAF caveat is
        # the single most important thing this endpoint says, and tying it to
        # lifespan ordering means it silently disappears in any deployment or
        # test harness that constructs the app without running startup.
        notes: list[str] = []
        if not caps.has_vmaf:
            notes.append(
                "libvmaf is not present in this FFmpeg build; VMAF figures are estimated "
                "from MS-SSIM and PSNR and are labelled as estimates"
            )
        if not healthy:
            notes.append("no usable video encoder was found; this instance cannot encode")
        if not state.config.storage.allowed_roots:
            notes.append(
                "storage.allowed_roots is empty, so any readable path may be submitted; "
                "set it before exposing this service beyond its operator"
            )

        return HealthResponse(
            status="ok" if healthy else "degraded",
            version=__version__,
            ffmpeg=caps.version,
            encoders=encoders,
            vmaf_available=caps.has_vmaf,
            queue=state.queue.stats(),
            notes=notes,
        )

    return app


app = None


def get_app() -> FastAPI:  # pragma: no cover - entry point for uvicorn
    global app
    if app is None:
        app = create_app()
    return app
