"""HYPERCOMPRESS MEDIA — a compression operating system for the hyperscale media cloud.

The platform treats media compression as a constrained optimisation problem:

    minimise   output_size
    subject to quality_score >= quality_floor
               encode_time   <= compute_budget

Python owns intelligence, orchestration, search, scheduling and analytics.
Native encoders (x264/x265/SVT-AV1/libaom/libvpx/libopus/AAC/FLAC) driven through
FFmpeg own the computationally intensive work.
"""

from __future__ import annotations

__version__ = "1.0.0"
__engine__ = "HYPERCOMPRESS MEDIA"

from hypercompress.core.errors import (
    CodecUnavailableError,
    EncodeError,
    HyperCompressError,
    ProbeError,
    QualityFloorViolation,
    StorageError,
    ValidationError,
)
from hypercompress.core.units import ByteSize, Duration, parse_size

__all__ = [
    "ByteSize",
    "CodecUnavailableError",
    "Duration",
    "EncodeError",
    "HyperCompressError",
    "ProbeError",
    "QualityFloorViolation",
    "StorageError",
    "ValidationError",
    "__engine__",
    "__version__",
    "parse_size",
]
