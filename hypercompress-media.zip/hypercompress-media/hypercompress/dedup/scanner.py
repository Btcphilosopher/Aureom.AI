"""Deduplication (Phase 16).

On a real media library, duplicates are the cheapest saving available: no
quality is traded, no compute is spent re-encoding, and the bytes recovered are
recovered exactly. It is worth doing before compression, not after — a file
identified as a duplicate need never be encoded at all.

Three levels, in increasing cost and decreasing certainty of a match:

**Exact file.** Same size, same SHA-256. Two identical files. Certain.

**Object level.** Same decoded content in a different container — the same
episode as MKV and as MP4. Detected by digesting the *streams* rather than the
file, so remuxing does not hide a duplicate.

**Chunk level.** Content-defined chunking with a rolling hash, so shared regions
are found even when the files differ elsewhere: two encodes of the same source
with different intros, a director's cut against the theatrical release. This
reports *partial* overlap and is the only level where the answer is a
percentage rather than a yes.

**Nothing here deletes anything.** Every function returns a report. Reclaiming
space is a decision with consequences that only the operator can weigh — which
copy is canonical, what references it, whether the "duplicate" is someone's
only backup — and an automated deleter that is right 99% of the time is a
catastrophe at library scale. The report names the candidates and the bytes at
stake; the operator acts.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from pathlib import Path

from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.hashing import (
    content_defined_chunks,
    file_digest,
    media_stream_digest,
    quick_signature,
)
from hypercompress.core.logging import get_logger
from hypercompress.core.units import format_size

log = get_logger(__name__)


@dataclass(slots=True)
class DuplicateGroup:
    """A set of paths holding the same content."""

    digest: str
    paths: list[Path]
    size: int
    level: str = "exact"

    @property
    def copies(self) -> int:
        return len(self.paths)

    @property
    def reclaimable(self) -> int:
        """Bytes recoverable if all but one copy were removed."""
        return self.size * max(0, self.copies - 1)

    @property
    def keeper(self) -> Path:
        """The copy a human would most likely keep: shortest path, then oldest.

        A suggestion, not an instruction. Shortest path tends to be the
        canonical location rather than a copy in someone's downloads folder.
        """
        return min(self.paths, key=lambda p: (len(str(p)), str(p)))

    def describe(self) -> str:
        return (
            f"{self.copies} copies of {format_size(self.size)} ({self.level}); "
            f"{format_size(self.reclaimable)} reclaimable; suggested keeper: {self.keeper}"
        )


@dataclass(slots=True)
class PartialOverlap:
    """Two files sharing a meaningful fraction of their content."""

    left: Path
    right: Path
    shared_bytes: int
    left_size: int
    right_size: int

    @property
    def fraction(self) -> float:
        smaller = min(self.left_size, self.right_size)
        return self.shared_bytes / smaller if smaller else 0.0

    def describe(self) -> str:
        return (
            f"{self.left.name} and {self.right.name} share "
            f"{format_size(self.shared_bytes)} ({self.fraction:.0%} of the smaller file)"
        )


@dataclass(slots=True)
class DedupReport:
    """Everything found, and nothing done about it."""

    scanned: int = 0
    total_bytes: int = 0
    exact: list[DuplicateGroup] = field(default_factory=list)
    stream_level: list[DuplicateGroup] = field(default_factory=list)
    partial: list[PartialOverlap] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def groups(self) -> list[DuplicateGroup]:
        return [*self.exact, *self.stream_level]

    @property
    def reclaimable(self) -> int:
        return sum(group.reclaimable for group in self.groups)

    def summary(self) -> str:
        if not self.groups and not self.partial:
            return f"scanned {self.scanned} files ({format_size(self.total_bytes)}); no duplicates found"
        return (
            f"scanned {self.scanned} files ({format_size(self.total_bytes)}); "
            f"{len(self.exact)} exact and {len(self.stream_level)} container-level duplicate "
            f"groups, {format_size(self.reclaimable)} reclaimable, "
            f"{len(self.partial)} partial overlaps"
        )

    def as_dict(self) -> dict[str, object]:
        return {
            "scanned": self.scanned,
            "total_bytes": self.total_bytes,
            "reclaimable_bytes": self.reclaimable,
            "exact_groups": [
                {
                    "digest": g.digest,
                    "size": g.size,
                    "copies": g.copies,
                    "reclaimable": g.reclaimable,
                    "keeper": str(g.keeper),
                    "paths": [str(p) for p in g.paths],
                }
                for g in self.exact
            ],
            "stream_groups": [
                {
                    "digest": g.digest,
                    "size": g.size,
                    "copies": g.copies,
                    "reclaimable": g.reclaimable,
                    "keeper": str(g.keeper),
                    "paths": [str(p) for p in g.paths],
                }
                for g in self.stream_level
            ],
            "partial_overlaps": [
                {
                    "left": str(o.left),
                    "right": str(o.right),
                    "shared_bytes": o.shared_bytes,
                    "fraction": round(o.fraction, 4),
                }
                for o in self.partial
            ],
            "errors": self.errors,
        }


class Deduplicator:
    """Finds duplicates. Never removes them."""

    def __init__(self, runner: FFmpegRunner | None = None) -> None:
        self.runner = runner

    def scan(
        self,
        paths: Iterable[str | Path],
        *,
        stream_level: bool = True,
        chunk_level: bool = False,
        min_partial_fraction: float = 0.25,
    ) -> DedupReport:
        """Scan a set of files for duplication at the requested levels."""
        files = [Path(p) for p in paths if Path(p).is_file()]
        report = DedupReport(scanned=len(files))
        report.total_bytes = sum(f.stat().st_size for f in files)

        exact_map = self._exact_groups(files, report)
        report.exact = [g for g in exact_map if g.copies > 1]

        # Files already known to be byte-identical are represented by one
        # member from here on: hashing every copy's streams again would cost
        # real time and could not find anything new.
        representatives = [g.keeper for g in exact_map]

        if stream_level and self.runner is not None:
            report.stream_level = self._stream_groups(representatives, report)

        if chunk_level:
            report.partial = self._partial_overlaps(
                representatives, report, min_fraction=min_partial_fraction
            )

        log.info("dedup scan complete", extra={"summary": report.summary()})
        return report

    # -- levels ----------------------------------------------------------------------
    def _exact_groups(self, files: Sequence[Path], report: DedupReport) -> list[DuplicateGroup]:
        """Group byte-identical files, digesting only where it could matter.

        Files of different sizes cannot be identical, and a cheap head/tail
        signature separates most of the rest, so the full digest is computed
        only for genuine candidates. On a library this is the difference
        between reading every byte and reading almost none of them.
        """
        by_size: dict[int, list[Path]] = defaultdict(list)
        for path in files:
            by_size[path.stat().st_size].append(path)

        by_digest: dict[str, list[Path]] = defaultdict(list)
        for _size, candidates in by_size.items():
            if len(candidates) == 1:
                by_digest[f"unique:{candidates[0]}"] = candidates
                continue

            by_signature: dict[str, list[Path]] = defaultdict(list)
            for path in candidates:
                try:
                    by_signature[quick_signature(path)].append(path)
                except OSError as exc:
                    report.errors.append(f"{path}: {exc}")

            for _signature, group in by_signature.items():
                if len(group) == 1:
                    by_digest[f"unique:{group[0]}"] = group
                    continue
                for path in group:
                    try:
                        by_digest[file_digest(path)].append(path)
                    except OSError as exc:
                        report.errors.append(f"{path}: {exc}")

        return [
            DuplicateGroup(digest=digest, paths=paths, size=paths[0].stat().st_size, level="exact")
            for digest, paths in by_digest.items()
        ]

    def _stream_groups(self, files: Sequence[Path], report: DedupReport) -> list[DuplicateGroup]:
        """Find identical content wrapped in different containers."""
        assert self.runner is not None
        by_digest: dict[str, list[Path]] = defaultdict(list)
        for path in files:
            try:
                by_digest[media_stream_digest(self.runner, path)].append(path)
            except Exception as exc:  # noqa: BLE001 - one unreadable file must not stop the scan
                report.errors.append(f"{path}: stream digest failed: {exc}")
        return [
            DuplicateGroup(
                digest=digest,
                paths=paths,
                size=max(p.stat().st_size for p in paths),
                level="container",
            )
            for digest, paths in by_digest.items()
            if len(paths) > 1
        ]

    def _partial_overlaps(
        self,
        files: Sequence[Path],
        report: DedupReport,
        *,
        min_fraction: float,
    ) -> list[PartialOverlap]:
        """Find files sharing content-defined chunks.

        Note the limitation honestly: chunk-level overlap finds *byte* reuse.
        Two encodes of the same film at different bitrates share no bytes at
        all, so this will not find them — it finds copies with edits, appended
        or trimmed regions, and files assembled from common parts.
        """
        chunk_index: dict[str, set[int]] = defaultdict(set)
        sizes: dict[int, dict[str, int]] = {}

        for index, path in enumerate(files):
            try:
                chunks = content_defined_chunks(path)
            except OSError as exc:
                report.errors.append(f"{path}: {exc}")
                continue
            local: dict[str, int] = defaultdict(int)
            for chunk in chunks:
                chunk_index[chunk.digest].add(index)
                local[chunk.digest] += chunk.length
            sizes[index] = local

        shared: dict[tuple[int, int], int] = defaultdict(int)
        for digest, owners in chunk_index.items():
            if len(owners) < 2:
                continue
            ordered = sorted(owners)
            for i, left in enumerate(ordered):
                for right in ordered[i + 1 :]:
                    shared[(left, right)] += min(
                        sizes[left].get(digest, 0), sizes[right].get(digest, 0)
                    )

        overlaps: list[PartialOverlap] = []
        for (left, right), shared_bytes in shared.items():
            overlap = PartialOverlap(
                left=files[left],
                right=files[right],
                shared_bytes=shared_bytes,
                left_size=files[left].stat().st_size,
                right_size=files[right].stat().st_size,
            )
            if overlap.fraction >= min_fraction:
                overlaps.append(overlap)
        return sorted(overlaps, key=lambda o: o.shared_bytes, reverse=True)


def plan_reclaim(report: DedupReport) -> list[tuple[Path, list[Path]]]:
    """Turn a report into a keep/remove proposal for an operator to approve.

    Returned, never executed. The caller decides.

    The plan is made globally consistent before it is returned, which matters
    more than it sounds. A file can belong to two groups at once — byte-identical
    to one file and, after remuxing, stream-identical to another — and each group
    picks its own keeper independently. Left alone, the exact group can nominate
    a file as the one to keep while the container group lists that same file for
    deletion. An operator applying the plan top to bottom would delete it. So any
    file nominated as a keeper anywhere is removed from every drop list, and a
    group whose own keeper was claimed elsewhere defers to that choice.
    """
    keepers: set[Path] = {group.keeper for group in report.groups}

    plan: list[tuple[Path, list[Path]]] = []
    for group in report.groups:
        # Prefer a keeper this group shares with another group, so the two
        # agree rather than compete.
        shared = [p for p in group.paths if p in keepers]
        keeper = shared[0] if shared else group.keeper
        drops = [p for p in group.paths if p != keeper and p not in keepers]
        if drops:
            plan.append((keeper, drops))
    return plan
