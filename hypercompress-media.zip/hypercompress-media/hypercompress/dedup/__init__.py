"""Duplicate detection.

Reports only. Reclaiming space is an operator decision with consequences no
automated tool can weigh.
"""

from __future__ import annotations

from hypercompress.dedup.scanner import (
    Deduplicator,
    DedupReport,
    DuplicateGroup,
    PartialOverlap,
    plan_reclaim,
)

__all__ = [
    "DedupReport",
    "Deduplicator",
    "DuplicateGroup",
    "PartialOverlap",
    "plan_reclaim",
]
