"""VMAF, and an honest substitute when libvmaf is not installed.

VMAF is the metric the industry actually trusts for perceptual video quality, so
the platform uses it whenever the FFmpeg build provides ``libvmaf``. Many builds
do not. Rather than silently degrading to PSNR and calling the result "quality",
this module computes a clearly-labelled *estimate* from MS-SSIM and PSNR and
records in the report that it is an estimate. A number that pretends to be VMAF
when it is not would corrupt every downstream size/quality trade-off.
"""

from __future__ import annotations

import json
import math
import re
import tempfile
from pathlib import Path

import numpy as np

from hypercompress.analysis.frames import decode_luma_window, sample_offsets
from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner
from hypercompress.core.logging import get_logger
from hypercompress.quality.psnr import psnr_from_arrays
from hypercompress.quality.ssim import full_reference_graph, ms_ssim_from_arrays, ssim_from_arrays

log = get_logger("quality.vmaf")

_VMAF_RE = re.compile(r"VMAF score:\s*(\d+\.?\d*)")

#: MS-SSIM to VMAF mapping, fitted on the benchmark corpus. Used only when
#: libvmaf is unavailable, and always reported as an estimate.
_MS_SSIM_ANCHORS = (
    (0.700, 18.0),
    (0.800, 32.0),
    (0.880, 48.0),
    (0.920, 58.0),
    (0.950, 69.0),
    (0.970, 79.0),
    (0.980, 85.5),
    (0.990, 92.0),
    (0.995, 95.5),
    (0.999, 98.5),
    (1.0, 100.0),
)
_PSNR_ANCHORS = (
    (22.0, 20.0),
    (26.0, 38.0),
    (30.0, 55.0),
    (34.0, 70.0),
    (38.0, 82.0),
    (42.0, 90.0),
    (46.0, 95.0),
    (50.0, 98.0),
    (60.0, 100.0),
)


def vmaf_available(runner: FFmpegRunner) -> bool:
    return runner.capabilities.has_vmaf


def measure_vmaf(
    runner: FFmpegRunner,
    reference: str | Path,
    distorted: str | Path,
    *,
    model: str | None = None,
    threads: int = 0,
    frames: int = 0,
    timeout: float = 7_200.0,
) -> tuple[float | None, float | None]:
    """Measure VMAF, returning ``(mean, 5th-percentile)``.

    The low percentile matters more than the mean for delivery: a file that
    averages 94 but drops to 60 during its one hard scene is the file viewers
    complain about.
    """
    if not runner.capabilities.has_vmaf:
        return (None, None)

    with tempfile.TemporaryDirectory(prefix="hcvmaf-") as tmp:
        log_path = Path(tmp) / "vmaf.json"
        node = f"libvmaf=log_fmt=json:log_path={log_path}:n_threads={threads or 1}"
        if model:
            node += f":model=path={model}"
        tokens = [
            "-i",
            str(distorted),
            "-i",
            str(reference),
            "-lavfi",
            full_reference_graph() + node,
            "-an",
            "-sn",
        ]
        if frames:
            tokens += ["-frames:v", str(frames)]
        tokens += ["-f", "null", "-"]
        args = ArgBuilder.__new__(ArgBuilder)._adopt(tokens)
        result = runner.run(args, timeout=timeout, check=False)

        if log_path.exists():
            try:
                payload = json.loads(log_path.read_text())
                pooled = payload.get("pooled_metrics", {}).get("vmaf", {})
                per_frame = [
                    f.get("metrics", {}).get("vmaf")
                    for f in payload.get("frames", [])
                    if f.get("metrics", {}).get("vmaf") is not None
                ]
                mean = pooled.get("mean")
                low = float(np.percentile(per_frame, 5)) if per_frame else pooled.get("min")
                if mean is not None:
                    return (float(mean), float(low) if low is not None else None)
            except (json.JSONDecodeError, KeyError, ValueError) as exc:
                log.warning("could not parse libvmaf log", extra={"error": str(exc)})

        match = _VMAF_RE.search(result.stderr + result.stdout)
        return (float(match.group(1)), None) if match else (None, None)


def _interpolate(anchors: tuple[tuple[float, float], ...], value: float) -> float:
    xs = [a[0] for a in anchors]
    ys = [a[1] for a in anchors]
    return float(np.interp(value, xs, ys))


def estimate_vmaf(ms_ssim: float | None, psnr: float | None) -> float | None:
    """Estimate VMAF from structural and signal metrics.

    MS-SSIM dominates because it tracks perception; PSNR contributes a smaller
    correction that catches banding and blocking that structural similarity is
    relatively forgiving about.
    """
    estimates: list[tuple[float, float]] = []
    if ms_ssim is not None:
        estimates.append((_interpolate(_MS_SSIM_ANCHORS, ms_ssim), 0.75))
    if psnr is not None and not math.isinf(psnr):
        estimates.append((_interpolate(_PSNR_ANCHORS, psnr), 0.25))
    elif psnr is not None and math.isinf(psnr):
        estimates.append((100.0, 0.25))
    if not estimates:
        return None
    total_weight = sum(w for _, w in estimates)
    return float(np.clip(sum(v * w for v, w in estimates) / total_weight, 0.0, 100.0))


def sampled_frame_metrics(
    runner: FFmpegRunner,
    reference: str | Path,
    distorted: str | Path,
    *,
    duration: float,
    clips: int = 4,
    clip_seconds: float = 2.0,
    fps: float = 4.0,
    width: int = 960,
    height: int = 540,
) -> tuple[float | None, float | None, float | None, int]:
    """Compute MS-SSIM, SSIM and PSNR from matched sampled frames of both files.

    Both streams are decoded to identical geometry, so a candidate encoded at a
    lower resolution is compared on the upscaled result a viewer would see.

    The comparison geometry matters: measuring a 4K encode at 480p hides exactly
    the detail loss the measurement exists to catch, so callers should pass the
    source resolution capped at something affordable rather than accepting a
    small default. Returns ``(ms_ssim, ssim, psnr, frames_compared)``.

    Single-scale SSIM is returned alongside MS-SSIM because it costs nothing
    extra here — the frames are already decoded and in memory — and because the
    composite score must be built from the same set of metrics whether it was
    computed quickly or thoroughly. A fast pass that silently omits one metric
    produces a number that cannot be compared with a full pass, which is worse
    than no number at all.
    """
    ms_values: list[float] = []
    ssim_values: list[float] = []
    psnr_values: list[float] = []
    compared = 0

    for offset in sample_offsets(duration, clips, clip_seconds):
        window = min(clip_seconds, max(0.5, duration - offset))
        try:
            ref_window = decode_luma_window(
                runner,
                reference,
                start=offset,
                duration=window,
                fps=fps,
                width=width,
                height=height,
            )
            dist_window = decode_luma_window(
                runner,
                distorted,
                start=offset,
                duration=window,
                fps=fps,
                width=width,
                height=height,
            )
        except Exception as exc:  # noqa: BLE001 - a failed window must not abort measurement
            log.warning("metric window failed", extra={"offset": offset, "error": str(exc)})
            continue

        count = min(ref_window.count, dist_window.count)
        for i in range(count):
            ref_frame = ref_window.frames[i]
            dist_frame = dist_window.frames[i]
            ms_values.append(ms_ssim_from_arrays(ref_frame, dist_frame))
            ssim_values.append(ssim_from_arrays(ref_frame, dist_frame))
            psnr_values.append(psnr_from_arrays(ref_frame, dist_frame))
            compared += 1

    if not ms_values:
        return (None, None, None, 0)
    finite_psnr = [p for p in psnr_values if not math.isinf(p)]
    return (
        float(np.mean(ms_values)),
        float(np.mean(ssim_values)) if ssim_values else None,
        float(np.mean(finite_psnr)) if finite_psnr else math.inf,
        compared,
    )
