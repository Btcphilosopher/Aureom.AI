"""PSNR — cheap, well understood, and only loosely correlated with perception.

The platform measures it because it is nearly free once FFmpeg is already
decoding both streams, and because it is the metric that catches gross failures:
a stream that decoded into garbage scores unmistakably badly.
"""

from __future__ import annotations

import math
import re
from pathlib import Path

import numpy as np

from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner
from hypercompress.core.logging import get_logger

log = get_logger("quality.psnr")

_PSNR_RE = re.compile(r"average:(\d+\.?\d*|inf)")
_PSNR_Y_RE = re.compile(r"\bpsnr_avg:(\d+\.?\d*|inf)")


def psnr_from_arrays(reference: np.ndarray, distorted: np.ndarray, peak: float = 255.0) -> float:
    """PSNR in dB between two equally shaped arrays."""
    if reference.shape != distorted.shape:
        raise ValueError("reference and distorted arrays must have the same shape")
    mse = float(np.mean((reference.astype(np.float64) - distorted.astype(np.float64)) ** 2))
    if mse <= 0:
        return math.inf
    return float(20 * math.log10(peak) - 10 * math.log10(mse))


def measure_psnr(
    runner: FFmpegRunner,
    reference: str | Path,
    distorted: str | Path,
    *,
    frames: int = 0,
    timeout: float = 3_600.0,
) -> float | None:
    """Full-reference PSNR via FFmpeg's ``psnr`` filter.

    The distorted stream is scaled to the reference geometry first, so a
    resolution-reducing candidate is judged on what a viewer would actually see
    rather than being rejected for having different dimensions.
    """
    args = ArgBuilder().path("-i", distorted).path("-i", reference)
    chain = "[0:v]scale=rw:rh:flags=bicubic,format=pix_fmts=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[dist];[1:v]format=pix_fmts=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[ref];[dist][ref]psnr"
    args = _complex_filter(args, chain, frames)
    result = runner.run(args, timeout=timeout, check=False)
    return _parse_psnr(result.stderr + result.stdout)


def _complex_filter(args: ArgBuilder, chain: str, frames: int) -> ArgBuilder:
    """Attach a filter_complex graph. The graph is constructed here, never by a
    caller, so it is a constant rather than user input."""
    tokens = args.build()
    tokens += ["-lavfi", chain]
    if frames:
        tokens += ["-frames:v", str(frames)]
    tokens += ["-f", "null", "-"]
    return ArgBuilder.__new__(ArgBuilder)._adopt(tokens)


def _parse_psnr(text: str) -> float | None:
    match = _PSNR_Y_RE.search(text) or _PSNR_RE.search(text)
    if not match:
        return None
    value = match.group(1)
    return math.inf if value == "inf" else float(value)


def psnr_to_score(
    psnr: float | None, *, floor_db: float = 28.0, ceiling_db: float = 48.0
) -> float | None:
    """Map dB onto the platform's 0..1 quality scale.

    Below ~28 dB artefacts are obvious on any content; above ~48 dB the
    differences are inaudible to the eye, so the scale saturates at both ends.
    """
    if psnr is None:
        return None
    if math.isinf(psnr):
        return 1.0
    return float(np.clip((psnr - floor_db) / (ceiling_db - floor_db), 0.0, 1.0))
