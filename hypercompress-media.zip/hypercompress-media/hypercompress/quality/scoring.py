"""Phase 10: composite quality scoring and floor enforcement.

The composite is the number the optimiser is constrained by, so it has to be
both configurable and defensible. Operators choose the weights; the scorer
renormalises across whichever metrics were actually obtained, so a build without
libvmaf produces a comparable score rather than a silently different one.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from hypercompress.config import QualityPolicy
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.logging import get_logger
from hypercompress.core.types import MediaProfile, QualityReport
from hypercompress.quality.audio_quality import audio_score, measure_audio_quality
from hypercompress.quality.psnr import psnr_to_score
from hypercompress.quality.ssim import measure_ssim, ssim_to_score
from hypercompress.quality.vmaf import estimate_vmaf, measure_vmaf, sampled_frame_metrics

log = get_logger("quality.scoring")

#: Measurement geometry ceiling. Above this, full-reference measurement costs
#: more than the encode it is judging.
MAX_MEASURE_WIDTH = 1_280
MAX_MEASURE_HEIGHT = 720


def vmaf_to_score(
    vmaf: float | None, *, floor: float = 55.0, ceiling: float = 98.0
) -> float | None:
    """Map VMAF onto 0..1. 95+ is transparent for most viewers; below 55 is poor."""
    if vmaf is None:
        return None
    return float(np.clip((vmaf - floor) / (ceiling - floor), 0.0, 1.0))


def ms_ssim_to_score(
    ms_ssim: float | None,
    *,
    floor: float = 0.9930,
    ceiling: float = 0.99955,
) -> float | None:
    """Map MS-SSIM onto the platform's 0..1 scale.

    Multi-scale SSIM sits even closer to 1.0 than single-scale: the same sweep
    spans only 0.9996 (CRF 22) to 0.9951 (CRF 54). Bounds drawn from the
    textbook range would compress every real decision into the last two decimal
    places and make the metric useless for ranking candidates.
    """
    if ms_ssim is None:
        return None
    return float(np.clip((ms_ssim - floor) / (ceiling - floor), 0.0, 1.0))


def composite_video_score(report: QualityReport, policy: QualityPolicy) -> float | None:
    """Weighted blend of whichever video metrics are present."""
    contributions: list[tuple[float, float]] = []
    mapping = {
        "vmaf": vmaf_to_score(report.vmaf),
        "ms_ssim": ms_ssim_to_score(report.ms_ssim),
        "ssim": ssim_to_score(report.ssim),
        "psnr": psnr_to_score(report.psnr),
    }
    for metric, value in mapping.items():
        weight = policy.metric_weights.get(metric, 0.0)
        if value is not None and weight > 0:
            contributions.append((value, weight))
    if not contributions:
        return None
    total = sum(w for _, w in contributions)
    return float(sum(v * w for v, w in contributions) / total)


def composite_score(report: QualityReport, policy: QualityPolicy) -> float | None:
    """Blend video and audio scores according to the configured weighting."""
    parts: list[tuple[float, float]] = []
    if report.video_score is not None:
        parts.append((report.video_score, policy.video_weight))
    if report.audio_score is not None:
        parts.append((report.audio_score, policy.audio_weight))
    if not parts:
        return None
    total = sum(w for _, w in parts)
    return float(sum(v * w for v, w in parts) / total)


def meets_floor(report: QualityReport, policy: QualityPolicy) -> tuple[bool, list[str]]:
    """Check a report against every configured floor.

    Returns the verdict plus the specific reasons for a failure, which is what
    the search loop needs in order to decide which direction to move.
    """
    failures: list[str] = []
    if report.composite is not None and report.composite < policy.floor:
        failures.append(f"composite {report.composite:.4f} below floor {policy.floor:.4f}")
    if (
        policy.vmaf_floor is not None
        and report.vmaf is not None
        and report.vmaf < policy.vmaf_floor
    ):
        failures.append(f"vmaf {report.vmaf:.2f} below floor {policy.vmaf_floor:.2f}")
    if (
        policy.vmaf_low_percentile_floor is not None
        and report.vmaf_low_percentile is not None
        and report.vmaf_low_percentile < policy.vmaf_low_percentile_floor
    ):
        failures.append(
            f"vmaf 5th percentile {report.vmaf_low_percentile:.2f} below floor "
            f"{policy.vmaf_low_percentile_floor:.2f}"
        )
    if (
        policy.psnr_floor is not None
        and report.psnr is not None
        and not math.isinf(report.psnr)
        and report.psnr < policy.psnr_floor
    ):
        failures.append(f"psnr {report.psnr:.2f} dB below floor {policy.psnr_floor:.2f} dB")
    if (
        policy.ssim_floor is not None
        and report.ssim is not None
        and report.ssim < policy.ssim_floor
    ):
        failures.append(f"ssim {report.ssim:.4f} below floor {policy.ssim_floor:.4f}")
    if (
        policy.audio_floor is not None
        and report.audio_score is not None
        and report.audio_score < policy.audio_floor
    ):
        failures.append(
            f"audio score {report.audio_score:.4f} below floor {policy.audio_floor:.4f}"
        )
    return (not failures, failures)


#: Sample positions used by every video measurement, fast or full.
MEASUREMENT_CLIPS = 5

#: Length of each sampled window. Identical in both passes, deliberately.
#: Seeking lands on a keyframe, and reference and distorted files have different
#: keyframe positions, so the first frames of a window are not guaranteed to
#: correspond. A longer window dilutes that; a short one is dominated by it. The
#: fast pass therefore keeps the same windows and simply samples fewer frames
#: within them.
MEASUREMENT_CLIP_SECONDS = 3.0


class QualityScorer:
    """Runs the configured measurements and produces a :class:`QualityReport`."""

    def __init__(self, runner: FFmpegRunner, policy: QualityPolicy) -> None:
        self.runner = runner
        self.policy = policy

    def measure(
        self,
        reference: str | Path,
        distorted: str | Path,
        source: MediaProfile,
        *,
        fast: bool = False,
        duration: float | None = None,
    ) -> QualityReport:
        """Measure ``distorted`` against ``reference``.

        ``fast`` selects sampled measurement, which is what the inner search loop
        uses; the final winning candidate is always re-measured in full.
        """
        report = QualityReport(reference=str(reference))
        media_duration = duration if duration is not None else source.duration

        if source.primary_video is not None:
            self._measure_video(
                reference, distorted, source, report, fast=fast, duration=media_duration
            )
        if source.primary_audio is not None:
            self._measure_audio(reference, distorted, report, fast=fast, duration=media_duration)

        report.video_score = composite_video_score(report, self.policy)
        report.composite = composite_score(report, self.policy)
        return report

    # -- internals ----------------------------------------------------------------
    def _measure_video(
        self,
        reference: str | Path,
        distorted: str | Path,
        source: MediaProfile,
        report: QualityReport,
        *,
        fast: bool,
        duration: float,
    ) -> None:
        video = source.primary_video
        assert video is not None

        if self.policy.measure_with_vmaf and self.runner.capabilities.has_vmaf and not fast:
            mean, low = measure_vmaf(
                self.runner, reference, distorted, frames=self.policy.measurement_frames
            )
            report.vmaf, report.vmaf_low_percentile = mean, low

        width = min(video.width or MAX_MEASURE_WIDTH, MAX_MEASURE_WIDTH)
        height = min(video.height or MAX_MEASURE_HEIGHT, MAX_MEASURE_HEIGHT)
        # Preserve aspect ratio at the measurement geometry.
        if video.width and video.height:
            aspect = video.width / video.height
            height = int(min(height, width / aspect) // 2 * 2)
            width = int(min(width, height * aspect) // 2 * 2)

        ms_ssim, sampled_ssim, psnr, frames = sampled_frame_metrics(
            self.runner,
            reference,
            distorted,
            duration=duration,
            # Both passes sample the same five positions in the file and differ
            # only in how densely they sample each one. Varying the clip count
            # instead would move the sample positions entirely, so the fast and
            # full numbers would describe different parts of the film — which
            # shows up as the fast pass being systematically optimistic and the
            # delivered file missing the floor the search thought it had met.
            clips=MEASUREMENT_CLIPS,
            clip_seconds=MEASUREMENT_CLIP_SECONDS,
            fps=2.0 if fast else 6.0,
            width=max(64, width),
            height=max(64, height),
        )
        report.ms_ssim = ms_ssim
        report.psnr = psnr
        report.ssim = sampled_ssim
        report.measured_frames = frames

        if not fast:
            # FFmpeg's full-file SSIM is recorded for reference but deliberately
            # not scored: it averages all three planes, so chroma subsampling
            # imposes a constant penalty that leaves even a transparent encode
            # near 0.97. Scoring it would mark good encodes as failures and
            # would also make fast and full passes incomparable.
            report.ssim_all_planes = measure_ssim(self.runner, reference, distorted)

        if report.vmaf is None:
            estimated = estimate_vmaf(ms_ssim, psnr)
            if estimated is not None:
                report.notes.append(
                    f"libvmaf unavailable; video quality estimated at VMAF~{estimated:.1f} "
                    "from MS-SSIM and PSNR. Install a libvmaf-enabled FFmpeg for measured VMAF."
                )
                # The estimate informs the report but never populates the VMAF
                # field, which must only ever hold a measured value.
                report.notes.append(f"vmaf_estimate={estimated:.2f}")

    def _measure_audio(
        self,
        reference: str | Path,
        distorted: str | Path,
        report: QualityReport,
        *,
        fast: bool,
        duration: float,
    ) -> None:
        psnr_db, spectral = measure_audio_quality(
            self.runner,
            reference,
            distorted,
            duration=duration,
            clips=MEASUREMENT_CLIPS,
            clip_seconds=4.0,
        )
        report.audio_psnr = psnr_db
        report.spectral_similarity = spectral
        report.audio_score = audio_score(psnr_db, spectral)


def estimated_vmaf_from_report(report: QualityReport) -> float | None:
    """Read back the estimate recorded in the notes, if any."""
    for note in report.notes:
        if note.startswith("vmaf_estimate="):
            try:
                return float(note.split("=", 1)[1])
            except ValueError:
                return None
    return None


def video_meets_floor(report: QualityReport, policy: QualityPolicy) -> tuple[bool, list[str]]:
    """Check only the video floors.

    The searches move video and audio with different controls, so a combined
    verdict is useless to them: a failing audio track would otherwise drive the
    CRF search downwards forever without ever fixing the thing that failed.
    """
    failures: list[str] = []
    if report.video_score is not None and report.video_score < policy.floor:
        failures.append(f"video score {report.video_score:.4f} below floor {policy.floor:.4f}")
    if (
        policy.vmaf_floor is not None
        and report.vmaf is not None
        and report.vmaf < policy.vmaf_floor
    ):
        failures.append(f"vmaf {report.vmaf:.2f} below floor {policy.vmaf_floor:.2f}")
    if (
        policy.vmaf_low_percentile_floor is not None
        and report.vmaf_low_percentile is not None
        and report.vmaf_low_percentile < policy.vmaf_low_percentile_floor
    ):
        failures.append(
            f"vmaf 5th percentile {report.vmaf_low_percentile:.2f} below floor "
            f"{policy.vmaf_low_percentile_floor:.2f}"
        )
    if (
        policy.psnr_floor is not None
        and report.psnr is not None
        and not math.isinf(report.psnr)
        and report.psnr < policy.psnr_floor
    ):
        failures.append(f"psnr {report.psnr:.2f} dB below floor {policy.psnr_floor:.2f} dB")
    if (
        policy.ssim_floor is not None
        and report.ssim is not None
        and report.ssim < policy.ssim_floor
    ):
        failures.append(f"ssim {report.ssim:.4f} below floor {policy.ssim_floor:.4f}")
    return (not failures, failures)


def audio_meets_floor(report: QualityReport, policy: QualityPolicy) -> tuple[bool, list[str]]:
    """Check only the audio floor."""
    if policy.audio_floor is None or report.audio_score is None:
        return (True, [])
    if report.audio_score < policy.audio_floor:
        return (
            False,
            [f"audio score {report.audio_score:.4f} below floor {policy.audio_floor:.4f}"],
        )
    return (True, [])
