"""SSIM and MS-SSIM.

SSIM comes from FFmpeg when both files are on disk. MS-SSIM is computed here in
NumPy across five scales, because multi-scale structural similarity tracks
perceived quality far better than single-scale SSIM on downscaled candidates —
and the platform cannot assume a libvmaf-enabled FFmpeg build to provide it.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter, uniform_filter

from hypercompress.core.ffmpeg import ArgBuilder, FFmpegRunner
from hypercompress.core.logging import get_logger

log = get_logger("quality.ssim")

_SSIM_RE = re.compile(r"All:(\d+\.?\d*)")

#: Wang et al. (2003) empirical scale weights for MS-SSIM.
MS_SSIM_WEIGHTS = (0.0448, 0.2856, 0.3001, 0.2363, 0.1333)


def full_reference_graph(scale_to_reference: bool = True) -> str:
    """The filter graph used by every full-reference metric.

    Input 0 is the distorted stream, input 1 the reference. Both are normalised
    to a common timebase and pixel format, and the distorted stream is scaled
    back up to the reference geometry so resolution changes are judged the way a
    viewer experiences them.
    """
    head = (
        "[0:v]format=pix_fmts=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[dist];"
        "[1:v]format=pix_fmts=yuv420p,settb=AVTB,setpts=PTS-STARTPTS[ref];"
    )
    if scale_to_reference:
        return head + "[dist][ref]scale2ref=flags=bicubic[d2][r2];[d2][r2]"
    return head + "[dist][ref]"


def build_metric_args(
    reference: str | Path,
    distorted: str | Path,
    metric_node: str,
    *,
    frames: int = 0,
) -> ArgBuilder:
    """Assemble a validated full-reference measurement invocation."""
    tokens = [
        "-i",
        str(distorted),
        "-i",
        str(reference),
        "-lavfi",
        full_reference_graph() + metric_node,
        "-an",
        "-sn",
    ]
    if frames:
        tokens += ["-frames:v", str(frames)]
    tokens += ["-f", "null", "-"]
    return ArgBuilder.__new__(ArgBuilder)._adopt(tokens)


def measure_ssim(
    runner: FFmpegRunner,
    reference: str | Path,
    distorted: str | Path,
    *,
    frames: int = 0,
    timeout: float = 3_600.0,
) -> float | None:
    """Mean SSIM over all planes via FFmpeg's ``ssim`` filter."""
    result = runner.run(
        build_metric_args(reference, distorted, "ssim", frames=frames),
        timeout=timeout,
        check=False,
    )
    match = _SSIM_RE.search(result.stderr + result.stdout)
    return float(match.group(1)) if match else None


# --------------------------------------------------------------------------------------
# NumPy implementations, used for MS-SSIM and for testing without FFmpeg
# --------------------------------------------------------------------------------------


def ssim_from_arrays(
    reference: np.ndarray,
    distorted: np.ndarray,
    *,
    data_range: float = 255.0,
    gaussian: bool = True,
    sigma: float = 1.5,
) -> float:
    """Single-scale SSIM between two 2-D arrays."""
    if reference.shape != distorted.shape:
        raise ValueError("reference and distorted arrays must have the same shape")
    ref = reference.astype(np.float64)
    dist = distorted.astype(np.float64)

    def _filter(x: np.ndarray) -> np.ndarray:
        return gaussian_filter(x, sigma=sigma) if gaussian else uniform_filter(x, size=7)

    c1 = (0.01 * data_range) ** 2
    c2 = (0.03 * data_range) ** 2

    mu_x, mu_y = _filter(ref), _filter(dist)
    mu_xx, mu_yy, mu_xy = mu_x * mu_x, mu_y * mu_y, mu_x * mu_y
    sigma_xx = _filter(ref * ref) - mu_xx
    sigma_yy = _filter(dist * dist) - mu_yy
    sigma_xy = _filter(ref * dist) - mu_xy

    numerator = (2 * mu_xy + c1) * (2 * sigma_xy + c2)
    denominator = (mu_xx + mu_yy + c1) * (sigma_xx + sigma_yy + c2)
    return float(np.mean(numerator / np.maximum(denominator, 1e-12)))


def _ssim_components(
    ref: np.ndarray, dist: np.ndarray, data_range: float, sigma: float
) -> tuple[float, float]:
    """Return (luminance*structure combined SSIM, contrast-structure term)."""
    c1 = (0.01 * data_range) ** 2
    c2 = (0.03 * data_range) ** 2
    mu_x, mu_y = gaussian_filter(ref, sigma), gaussian_filter(dist, sigma)
    sigma_xx = gaussian_filter(ref * ref, sigma) - mu_x**2
    sigma_yy = gaussian_filter(dist * dist, sigma) - mu_y**2
    sigma_xy = gaussian_filter(ref * dist, sigma) - mu_x * mu_y
    luminance = (2 * mu_x * mu_y + c1) / np.maximum(mu_x**2 + mu_y**2 + c1, 1e-12)
    contrast_structure = (2 * sigma_xy + c2) / np.maximum(sigma_xx + sigma_yy + c2, 1e-12)
    return float(np.mean(luminance * contrast_structure)), float(np.mean(contrast_structure))


def _downsample(image: np.ndarray) -> np.ndarray:
    filtered = uniform_filter(image, size=2)
    return filtered[::2, ::2]


def ms_ssim_from_arrays(
    reference: np.ndarray,
    distorted: np.ndarray,
    *,
    data_range: float = 255.0,
    sigma: float = 1.5,
    weights: tuple[float, ...] = MS_SSIM_WEIGHTS,
) -> float:
    """Multi-scale SSIM. Falls back to fewer scales for small frames."""
    ref = reference.astype(np.float64)
    dist = distorted.astype(np.float64)
    levels = len(weights)
    smallest = min(ref.shape)
    max_levels = max(1, int(np.floor(np.log2(smallest / 16))) + 1)
    levels = min(levels, max_levels)
    used_weights = np.array(weights[:levels], dtype=np.float64)
    used_weights = used_weights / used_weights.sum()

    contrast_terms: list[float] = []
    combined = 1.0
    for level in range(levels):
        ssim_value, cs_value = _ssim_components(ref, dist, data_range, sigma)
        if level == levels - 1:
            combined = max(ssim_value, 1e-9)
        else:
            contrast_terms.append(max(cs_value, 1e-9))
            ref, dist = _downsample(ref), _downsample(dist)

    score = combined ** used_weights[-1]
    for weight, term in zip(used_weights[:-1], contrast_terms, strict=False):
        score *= term**weight
    return float(np.clip(score, 0.0, 1.0))


def ssim_to_score(
    ssim: float | None,
    *,
    floor: float = 0.9760,
    ceiling: float = 0.9980,
) -> float | None:
    """Map SSIM onto the platform's 0..1 scale.

    SSIM compresses violently at the top of its range: 0.98 and 0.995 look very
    different, while 0.30 and 0.50 are both simply broken. The rescale spends the
    output range where the decisions actually happen.

    The bounds come from an AV1 CRF sweep on the benchmark corpus, measured with
    :func:`ssim_from_arrays` on the luma plane: CRF 22 (visually transparent)
    reads 0.9979 and CRF 54 (obviously damaged, 37 dB PSNR) reads 0.9783. A
    ceiling of 0.995 — the textbook figure — would therefore mark a transparent
    encode as merely adequate.
    """
    if ssim is None:
        return None
    return float(np.clip((ssim - floor) / (ceiling - floor), 0.0, 1.0))
