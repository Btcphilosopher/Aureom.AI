"""Full-reference audio quality.

Perceptual audio metrics (PEAQ, ViSQOL) are not available in a stock FFmpeg
build, so the platform measures two things it can measure honestly: sample-domain
PSNR after alignment, and similarity of the mel-weighted spectra. The second is
the one that matters — a codec that discards inaudible high-frequency content
scores badly on sample PSNR and perfectly acceptably in a listening test, and
the spectral measure reflects that.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from hypercompress.analysis.frames import decode_audio_window, sample_offsets
from hypercompress.core.ffmpeg import FFmpegRunner
from hypercompress.core.logging import get_logger

log = get_logger("quality.audio")


def _mel_filterbank(sample_rate: int, n_fft: int, n_bands: int = 40) -> np.ndarray:
    """Triangular mel filterbank matrix of shape (n_bands, n_fft // 2 + 1)."""

    def hz_to_mel(hz: np.ndarray | float) -> np.ndarray | float:
        return 2595.0 * np.log10(1.0 + np.asarray(hz) / 700.0)

    def mel_to_hz(mel: np.ndarray) -> np.ndarray:
        return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)

    low_mel = float(hz_to_mel(20.0))
    high_mel = float(hz_to_mel(sample_rate / 2.0))
    points = mel_to_hz(np.linspace(low_mel, high_mel, n_bands + 2))
    bins = np.floor((n_fft + 1) * points / sample_rate).astype(int)
    bins = np.clip(bins, 0, n_fft // 2)

    filters = np.zeros((n_bands, n_fft // 2 + 1))
    for band in range(n_bands):
        left, centre, right = bins[band], bins[band + 1], bins[band + 2]
        if centre > left:
            filters[band, left:centre] = np.linspace(0, 1, centre - left, endpoint=False)
        if right > centre:
            filters[band, centre:right] = np.linspace(1, 0, right - centre, endpoint=False)
    return filters


def align_signals(
    reference: np.ndarray, distorted: np.ndarray, max_lag: int = 4_800
) -> tuple[np.ndarray, np.ndarray, int]:
    """Align two signals by cross-correlation over a bounded lag window.

    Encoder and decoder delay routinely shifts the output by a few milliseconds;
    without alignment a perfect encode measures as badly damaged.
    """
    n = min(len(reference), len(distorted))
    if n == 0:
        return reference, distorted, 0
    ref = reference[:n]
    dist = distorted[:n]
    probe = min(n, 48_000 * 3)
    correlation = np.correlate(
        dist[:probe] - dist[:probe].mean(),
        ref[:probe] - ref[:probe].mean(),
        mode="full",
    )
    centre = probe - 1
    window = slice(max(0, centre - max_lag), min(len(correlation), centre + max_lag))
    lag = int(np.argmax(correlation[window]) + window.start - centre)
    if lag > 0:
        dist = dist[lag:]
        ref = ref[: len(dist)]
    elif lag < 0:
        ref = ref[-lag:]
        dist = dist[: len(ref)]
    return ref, dist, lag


def audio_psnr(reference: np.ndarray, distorted: np.ndarray) -> float:
    """Sample-domain PSNR against a full-scale peak of 1.0."""
    ref, dist, _ = align_signals(reference, distorted)
    if len(ref) == 0:
        return 0.0
    mse = float(np.mean((ref - dist) ** 2))
    if mse <= 0:
        return math.inf
    return float(10 * math.log10(1.0 / mse))


def spectral_similarity(
    reference: np.ndarray,
    distorted: np.ndarray,
    sample_rate: int,
    *,
    n_fft: int = 2_048,
    n_bands: int = 40,
) -> float:
    """Cosine similarity of mel-band log spectra, 0..1.

    Comparing energy per critical band rather than per FFT bin is what makes this
    tolerant of the phase and fine-structure differences every lossy codec
    introduces, while remaining sensitive to genuine spectral damage.
    """
    ref, dist, _ = align_signals(reference, distorted)
    usable = (min(len(ref), len(dist)) // n_fft) * n_fft
    if usable < n_fft:
        return 0.0
    ref_frames = ref[:usable].reshape(-1, n_fft)
    dist_frames = dist[:usable].reshape(-1, n_fft)
    window = np.hanning(n_fft)

    filters = _mel_filterbank(sample_rate, n_fft, n_bands)
    ref_spec = np.abs(np.fft.rfft(ref_frames * window, axis=1)) ** 2
    dist_spec = np.abs(np.fft.rfft(dist_frames * window, axis=1)) ** 2
    ref_mel = np.log10(ref_spec @ filters.T + 1e-10)
    dist_mel = np.log10(dist_spec @ filters.T + 1e-10)

    # Frames that are silent in the reference carry no perceptual information.
    energy = ref_spec.sum(axis=1)
    active = energy > (energy.max() * 1e-6 if energy.size else 0)
    if not active.any():
        return 1.0
    ref_mel, dist_mel = ref_mel[active], dist_mel[active]

    ref_centred = ref_mel - ref_mel.mean(axis=1, keepdims=True)
    dist_centred = dist_mel - dist_mel.mean(axis=1, keepdims=True)
    numerator = (ref_centred * dist_centred).sum(axis=1)
    denominator = np.linalg.norm(ref_centred, axis=1) * np.linalg.norm(dist_centred, axis=1)
    similarity = numerator / np.maximum(denominator, 1e-12)
    return float(np.clip(np.mean(similarity), 0.0, 1.0))


def measure_audio_quality(
    runner: FFmpegRunner,
    reference: str | Path,
    distorted: str | Path,
    *,
    duration: float,
    clips: int = 3,
    clip_seconds: float = 8.0,
    sample_rate: int = 48_000,
) -> tuple[float | None, float | None]:
    """Return ``(audio_psnr_db, spectral_similarity)`` from sampled windows."""
    psnr_values: list[float] = []
    spectral_values: list[float] = []
    lags: list[int] = []

    # Asking for more clip-seconds than the file has produces overlapping,
    # clamped windows whose alignment is unreliable. Scale the request down to
    # what the material can actually supply.
    if duration > 0 and clips * clip_seconds > duration:
        clip_seconds = max(0.5, duration / max(clips, 1))

    for offset in sample_offsets(duration, clips, clip_seconds):
        window = min(clip_seconds, max(0.5, duration - offset))
        try:
            ref = decode_audio_window(
                runner,
                reference,
                start=offset,
                duration=window,
                sample_rate=sample_rate,
                channels=1,
            )
            dist = decode_audio_window(
                runner,
                distorted,
                start=offset,
                duration=window,
                sample_rate=sample_rate,
                channels=1,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("audio metric window failed", extra={"offset": offset, "error": str(exc)})
            continue
        # Every lossy audio codec introduces its own encoder delay, and muxing
        # into a container can add more. Comparing sample n of the reference
        # against sample n of the output without correcting for that measures
        # the delay, not the damage: an untouched signal shifted by 6.5 ms
        # scores as if it were badly mangled. Spectral similarity is
        # delay-tolerant and stays right either way, which is precisely how the
        # missing alignment stayed hidden — the two metrics disagreed only on
        # muxed files.
        # Aligned once here for both metrics. :func:`audio_psnr` aligns again
        # internally and will find a lag of zero, which costs one correlation
        # on already-aligned data; :func:`spectral_similarity` does no aligning
        # of its own and genuinely needs this.
        aligned_ref, aligned_dist, lag = align_signals(ref.mono, dist.mono)
        if len(aligned_ref) < sample_rate // 10:
            log.warning("audio window too short after alignment", extra={"offset": offset})
            continue
        lags.append(lag)
        psnr_values.append(audio_psnr(aligned_ref, aligned_dist))
        spectral_values.append(spectral_similarity(aligned_ref, aligned_dist, sample_rate))

    if not spectral_values:
        return (None, None)
    if lags and max(abs(lag) for lag in lags) > sample_rate // 20:
        log.warning(
            "large audio delay corrected during measurement",
            extra={"max_lag_samples": max(abs(lag) for lag in lags)},
        )
    finite = [p for p in psnr_values if not math.isinf(p)]
    return (
        float(np.mean(finite)) if finite else math.inf,
        float(np.mean(spectral_values)),
    )


def audio_score(psnr_db: float | None, spectral: float | None) -> float | None:
    """Composite 0..1 audio quality, weighted towards the perceptual measure."""
    parts: list[tuple[float, float]] = []
    if spectral is not None:
        # Calibrated against an Opus bitrate sweep on the benchmark corpus.
        # Log-mel cosine similarity saturates well below 1.0 even for encodes
        # that are demonstrably transparent by every other measure — the noise
        # floor of the silent and high-frequency bands never matches exactly —
        # so a ceiling of 0.995 would mark transparent audio as failing. The
        # ceiling here is where the sweep flattens; the floor is where damage
        # becomes obvious. Because the true asymptote is content-dependent,
        # :class:`~hypercompress.optimisation.audio_search.AudioSearch` also
        # applies a relative test against the best score the file can reach.
        parts.append((float(np.clip((spectral - 0.750) / (0.970 - 0.750), 0.0, 1.0)), 0.75))
    if psnr_db is not None:
        value = (
            1.0
            if math.isinf(psnr_db)
            else float(np.clip((psnr_db - 20.0) / (55.0 - 20.0), 0.0, 1.0))
        )
        parts.append((value, 0.25))
    if not parts:
        return None
    return float(sum(v * w for v, w in parts) / sum(w for _, w in parts))
