# Architecture

## The shape of the problem

Compression is a search, not a calculation. The settings that produce the
smallest acceptable file depend on the content in ways no formula captures: a
grainy night scene and a static talking head at the same resolution and bitrate
differ by an order of magnitude in how much they can be squeezed.

So the platform is built around a loop — encode, measure, adjust — with
everything else in service of making that loop affordable and its results
trustworthy.

```
     ┌──────────┐    ┌──────────┐    ┌──────────┐
     │ analyse  │───▶│  search  │───▶│ validate │
     └──────────┘    └────┬─────┘    └──────────┘
       content            │ encode/measure/adjust
       classification     └───▶ candidates
```

## Layers

**`core/`** — types, configuration, errors, hashing, process control, and
`ffmpeg.py`. This last one is the security boundary: every FFmpeg invocation in
the platform is built here from an allowlist, and nothing else in the codebase
constructs a command line.

**`analysis/`** — probing, frame and audio sampling, scene detection, and a
content classifier that produces a class plus the evidence for it. The
classifier matters more than any codec tuning: content type drives the whole
plan.

**`codecs/`** — one class per codec family, each carrying its efficiency
relative to H.264, a preset scale, and measured quality anchors. Adding a codec
means adding a class, not editing the planner.

**`quality/`** — PSNR, SSIM, MS-SSIM, VMAF, audio metrics, and the scoring that
combines them. See [quality.md](quality.md).

**`optimisation/`** — the planner (which codec, what resolution, which
container) and four search strategies. The planner proposes; the search
verifies. When they disagree the search wins, and the planner's proposal is
recorded so the disagreement is visible.

**`pipeline/`** — turning a plan into a running encode, then validating and
packaging the result.

**`distributed/`** — queues and workers. See below.

**`storage/`, `dedup/`, `analytics/`, `security/`, `api/`** — the operational
surface.

## Why the planner and the search are separate

The planner produces a starting point from a model of the content. The search
finds the answer by measurement. Keeping them apart means the model can be
wrong without the platform being wrong.

It regularly is wrong, and visibly so. On the test corpus the planner proposed
mono 8 kHz audio for a film clip; the search measured that at 0.37 against a
0.90 floor and settled on 64 kbps at 48 kHz instead. Both numbers end up in the
manifest.

## The distributed layer

Workers are stateless. Everything durable lives in the queue, which is what
makes killing a worker safe.

**Leases, not heartbeats.** A claimed job carries an expiry. A live worker
renews it from a background thread; a dead one simply stops. Any lapsed lease is
reclaimable. This means a crashed worker and a wedged worker resolve the same
way, with no liveness gossip and no coordinator.

**Two backends behind one protocol.** `MemoryQueue` for single-process work,
`SqliteQueue` for durability without running a server. Both pass the same test
suite, because interchangeable implementations only stay interchangeable if
tested identically. Redis fits the same protocol where multi-machine throughput
justifies the dependency.

**Idempotency comes from the filesystem.** A job writes to a temporary name and
moves it into place only after validation. An interrupted worker leaves a temp
file, never something that looks finished.

**Retries distinguish what is worth retrying.** A network timeout deserves
another attempt; an unsupported codec does not, and retrying it three times just
spends the fleet's capacity reaching the same answer.

## Data flow for one job

```
JobSpec ──▶ probe ──▶ classify ──▶ plan ──▶ search ──┐
                                                      │
   manifest ◀── package ◀── validate ◀── final encode ┘
```

The final encode is not optional even when the search already produced a whole
file. Search results are sampled estimates; shipping them as facts is the
dishonesty this platform exists to avoid.

## Extension points

- **A codec** — subclass `VideoCodec` or `AudioCodec`, register it.
- **A profile** — drop TOML or JSON into `profiles_dir`.
- **A storage backend** — implement the `Storage` protocol.
- **A queue backend** — implement `JobQueue` and pass its test suite.
- **A quality metric** — add it to `QualityReport` and give it a weight.

There is deliberately no extension point for encoder arguments.
