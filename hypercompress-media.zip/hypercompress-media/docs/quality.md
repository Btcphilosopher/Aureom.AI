# Quality measurement

Everything this platform does rests on the numbers in this document. If they
are wrong, the search optimises confidently towards the wrong answer and nobody
finds out until the sources are gone.

This document records what is measured, how the scales were calibrated, and —
at the end — four measurement bugs found during development, because the way
they were found is the most useful thing here.

---

## The composite score

A single number in `[0, 1]`, because the search needs something to bisect on.

```
composite = 0.75 × video_score + 0.25 × audio_score
```

The video score is a weighted blend over whichever metrics were available:

| Metric | Weight | Notes |
|---|---|---|
| VMAF | 0.65 | When `libvmaf` is present. Otherwise excluded and the rest renormalised. |
| MS-SSIM | 0.15 | Always available; computed here in NumPy. |
| SSIM | 0.10 | Luma only, Gaussian-windowed. |
| PSNR | 0.10 | Sanity check more than a perceptual measure. |

Renormalising over *available* metrics rather than substituting a default is
deliberate. A missing VMAF that silently becomes zero produces a score that
looks like catastrophic quality loss; one that silently becomes 100 produces a
score that hides real damage.

---

## Calibration

Textbook ranges for SSIM and MS-SSIM are useless for ranking encodes, because
real encodes live in the last two decimal places. The bounds below come from an
AV1 CRF sweep on the benchmark corpus:

| CRF | MS-SSIM | SSIM (luma) | PSNR | → video score |
|---:|---:|---:|---:|---:|
| 22 | 0.99964 | 0.99786 | 49.9 dB | 0.998 |
| 30 | 0.99936 | 0.99653 | 46.8 dB | 0.951 |
| 38 | 0.99839 | 0.99130 | 42.5 dB | 0.759 |
| 46 | 0.99688 | 0.98421 | 39.5 dB | 0.525 |
| 54 | 0.99512 | 0.97833 | 37.0 dB | 0.298 |

The resulting scales:

- **SSIM** → `0.9760` (zero) to `0.9980` (one)
- **MS-SSIM** → `0.9930` to `0.99955`
- **PSNR** → `28 dB` to `48 dB`

A ceiling of 0.995 for SSIM — the figure most references quote — would score a
visually transparent encode at 0.79 and mark it a failure.

### Audio

Log-mel cosine similarity plus sample-domain PSNR, weighted 0.75/0.25.

Log-mel similarity **saturates well below 1.0**. An Opus bitrate sweep on
material that is transparent by every other measure tops out around 0.954:

| Bitrate | Spectral similarity | PSNR |
|---:|---:|---:|
| 12k | 0.4692 | 49.2 dB |
| 24k | 0.9287 | 61.3 dB |
| 48k | 0.9504 | 64.5 dB |
| 128k | 0.9541 | 65.4 dB |
| 192k | 0.9541 | 65.5 dB |

The scale is therefore `0.750` to `0.970`. Because the true asymptote depends on
the material, the audio search **also** measures each file's own ceiling and
accepts settings within `audio_relative_tolerance` of it. An absolute floor
alone either passes damaged speech or fails transparent music.

---

## Which SSIM

Two SSIM values are recorded and only one is scored.

`ssim` is Gaussian-windowed, luma-only, computed here. `ssim_all_planes` comes
from FFmpeg's `ssim` filter and averages Y, U and V.

FFmpeg's version is reported for reference but **not scored**, because chroma
subsampling imposes a near-constant penalty: a transparent AV1 encode still
reads about 0.97, and the metric never approaches its own ceiling regardless of
how good the encode is. Scoring it would fail good encodes and, worse, would
make fast and full measurement passes incomparable.

---

## Fast and full passes

The search measures quickly; the delivered file is measured thoroughly.

|  | Clips | Clip length | Frame rate |
|---|---:|---:|---:|
| Fast | 5 | 3.0s | 2 fps |
| Full | 5 | 3.0s | 6 fps |

**Both passes sample the same windows.** Only the density within them differs.
This is load-bearing — see bug 3 below.

Because they still differ slightly, the search judges candidates against a
policy raised by `search_margin` (default 0.010), so the delivered file clears
the floor the operator actually configured. Measured agreement across the
quality range is within 0.006.

---

## Four bugs, and how they surfaced

Every one was found by two numbers disagreeing that should have matched. That
is the technique worth taking away: when a measurement can be taken two ways,
take it both ways and treat any gap as a finding rather than as noise.

### 1. Audio PSNR was never aligned

`align_signals` existed and was never called. Every lossy audio codec
introduces encoder delay, and muxing adds more; comparing sample *n* to sample
*n* measures the delay, not the damage. An untouched signal shifted by 6.5 ms
scored as badly mangled.

It hid for a long time because it **only affected muxed files**, and because
spectral similarity is delay-tolerant and stayed correct throughout. The two
metrics disagreed only in one specific case, which is exactly the shape of
evidence that gets dismissed as noise.

### 2. Log-mel similarity saturates

Covered above. The symptom was the audio ladder rejecting every rung including
its own ceiling, then falling back to the most faithful settings available —
correct behaviour, wrong conclusion, and the platform quietly shipping audio at
192 kbps that was transparent at 64.

### 3. Fast and full passes disagreed by 0.43

The largest and most consequential. The fast pass used different clip positions
*and* lengths from the full pass. Seeking lands on a keyframe, and reference and
distorted files have keyframes in different places, so the first frames of a
short window do not correspond. A three-second window dilutes that; a
one-second window is dominated by it.

The search was optimising against a number nobody would ever verify. Files
shipped at a measured 0.77 after a search that believed it had found 0.93.

The fix was to make both passes sample identical windows. The margin was then
*reduced* from 0.025 to 0.010 — the right response to a large gap is to find
out why the measurements disagree, not to inflate the margin until it hides.

### 4. Different metric baskets

The fast pass omitted SSIM entirely, so the composite renormalised over a
different set of metrics. The two numbers were never comparable, however close
the individual values looked. Both passes now report the same three metrics.

---

## Reading a quality report

```json
{
  "composite": 0.9304,
  "video_score": 0.9271,
  "audio_score": 0.9438,
  "vmaf": null,
  "ms_ssim": 0.99881,
  "ssim": 0.99402,
  "ssim_all_planes": 0.97108,
  "psnr": 44.31,
  "measured_frames": 30,
  "notes": ["vmaf_estimate=96.9"]
}
```

`vmaf` is `null` and the estimate is in `notes`. That is the shape to expect
whenever `libvmaf` is absent, and the platform will not fill the field in.
