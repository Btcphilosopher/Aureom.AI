# Operations

## What to watch

Four numbers, in order of importance.

**`hypercompress_outputs_below_quality_floor_total`** should be zero. It counts
files delivered below the floor that was configured for them. Silent quality
regression is invisible until a viewer complains months later, by which time the
sources may be gone. Alert on any increase.

**Bytes eliminated per compute hour.** A fleet at 100% CPU producing a 3%
reduction is a fleet wasting money, and every CPU graph ever drawn shows that as
healthy. Compare `bytes_saved_total` against `compute_cost_total`.

**`hypercompress_lease_expiries_total`.** Each one is a worker that crashed or
wedged mid-encode. A steady trickle usually means memory limits set below what
a 4K encode actually needs.

**Queue depth per worker.** The scaling signal. CPU is not.

## Scaling

Autoscale on `hypercompress_queue_depth`, targeting about five jobs per worker.
Scale up quickly and down slowly: a worker removed is a job delayed by however
long that job had left, which for a feature film is hours.

Give workers **equal CPU requests and limits** so they land in the Guaranteed
QoS class. A throttled encoder does not fail — it takes twice as long, which is
invisible on a dashboard and expensive on a bill.

Prefer more workers with fewer threads each over the reverse. Encoders scale
badly past a point: x265 on 32 threads is far less than 32× a single-thread
encode, so two workers at 16 threads routinely beat one at 32.

## Sizing scratch

Each worker needs room for the source, the candidates the search keeps, and the
final output. Budget roughly 3× the largest single file the fleet will handle.
A container filesystem filling mid-job produces failures far from the cause.

## Deploys

Workers handle `SIGTERM` by finishing the encode in hand and releasing anything
unstarted. Set `terminationGracePeriodSeconds` to your longest expected encode —
an hour is reasonable — and roll one pod at a time. A deploy that costs one
encode's latency is much better than one that costs one encode's work.

## Economics

`hypercompress cost <directory>` reads the manifests and reports break-even.

Two results that regularly surprise people:

**Slow presets are often uneconomic.** AV1 preset 2 might beat preset 8 by 6% on
size while costing eight times the compute. Over a 36-month retention that can
win; over six months it does not.

**Cold data should be compressed cheaply, or not at all.** Archive tiers cost a
tenth of standard storage, which divides the value of every byte saved by ten
while leaving the compute cost untouched. The report names files that will never
pay back their encode.

## Security checklist

Before exposing the API beyond its operator:

- [ ] `storage.allowed_roots` is set. Empty means any readable path may be
      submitted. `/health` will tell you if you forgot.
- [ ] `security.require_auth` is true and tokens are real, from
      `Authenticator.issue_token()`.
- [ ] Tenants have distinct identifiers. They become path components.
- [ ] `/metrics` is restricted at the network layer — it is intentionally
      unauthenticated so scrapers can reach it.
- [ ] Quotas are set to something your fleet can actually absorb.
- [ ] The audit log is being shipped somewhere durable.

## When something goes wrong

**Jobs failing immediately.** Check `/health` for encoders. A worker with no
usable encoder refuses to start rather than dead-lettering the queue.

**Everything below the quality floor.** Usually the floor is set higher than the
source itself achieves — a floor of 0.95 against a source that was already
heavily compressed is unsatisfiable. `hypercompress inspect` shows what the
source has to work with.

**Targets never reached.** The profile may forbid the resolution reduction that
would get there. The search says so explicitly rather than silently
overshooting.

**Outputs larger than sources.** The material is already efficiently encoded.
The platform flags this and recommends keeping the original; `copy_when_efficient`
avoids it in the first place.
