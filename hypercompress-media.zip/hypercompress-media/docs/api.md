# API reference

`uvicorn hypercompress.api.service:get_app --factory`

All endpoints except `/health` and `/metrics` require `Authorization: Bearer <token>`.

## Design

**Optimisation is asynchronous; analysis is synchronous.** An encode takes
minutes to hours, so `POST /jobs` returns 202 and the caller polls. Analysis
takes seconds, so `POST /analyse` answers directly — and it is the endpoint that
makes a considered rollout possible, because it predicts what would happen
without spending the compute to find out.

**The tenant comes from the token.** A `tenant` field in a request body is
ignored. There is no endpoint that trusts a caller's claim about who they are.

**Failures are indistinguishable.** An unknown token and an insufficient
permission both return 403 with the same shape; a job belonging to another
tenant returns 404, not 403, so a caller cannot enumerate what exists.

## Endpoints

### `POST /jobs` → 202

Requires `job:submit`.

```json
{
  "source": "/data/media/film.mkv",
  "destination": "/data/optimised/film.mkv",
  "profile": "balanced",
  "target_size": "1GB",
  "quality_floor": 0.92,
  "dry_run": false
}
```

Returns `{ "job_id": "...", "state": "queued", "queue_position": 3 }`.

`source` must resolve inside `storage.allowed_roots`. Symlinks are resolved
before the check.

### `GET /jobs/{id}`

Requires `job:read`. Returns state plus, once finished, sizes, the quality
report, whether the floor and target were met, and `caveats` — a list every
client should surface.

### `GET /jobs/{id}/metrics`

Requires `metrics:read`. Resource usage and the full search log: every candidate
tried, its size, and its measured quality.

### `POST /analyse`

Requires `media:analyse`. Probes, classifies, plans and predicts. Encodes
nothing. The response carries a `disclaimer` field saying so.

### `GET /profiles`

Requires `profile:read`.

### `GET /workers`

Requires `metrics:read`. Queue statistics, depth, and per-tenant quota usage.

### `GET /metrics`

Unauthenticated, for Prometheus. Restrict at the network layer.

### `GET /health`

Unauthenticated. Reports encoders, whether VMAF is available, and `notes`
listing anything an operator needs to know — including, prominently, when
quality figures will be estimates rather than measurements.

## Roles

| Role | Permissions |
|---|---|
| `viewer` | read jobs, read profiles |
| `analyst` | viewer + analyse + metrics |
| `operator` | analyst + submit, cancel |
| `admin` | everything, including crossing tenants |

Tokens are configured as `security.tokens`, mapping token to
`principal:role:tenant`. They are held only as digests and compared in constant
time.

## Status codes

| Code | Meaning |
|---|---|
| 400 | Bad path, bad configuration, or an unencodable request |
| 403 | Not authenticated, or the role lacks the permission |
| 404 | No such job, or not yours |
| 415 | Media the platform cannot decode |
| 429 | Tenant quota exceeded |

Platform errors carry a process exit code for the CLI, which is a different
numbering scheme from HTTP. The two are mapped explicitly — reusing one as the
other returns nonsense like `77`.
