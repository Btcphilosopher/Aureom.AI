/** Shapes returned by the HYPERCOMPRESS API.
 *
 * Kept deliberately close to the server's Pydantic models. Where a field can be
 * absent it is typed as nullable rather than optional, because the server sends
 * an explicit null when a thing was not measured — and "not measured" is
 * information the console is supposed to show, not hide.
 */

export type JobState =
  | "pending"
  | "queued"
  | "running"
  | "retrying"
  | "succeeded"
  | "failed"
  | "cancelled";

export interface QueueStats {
  pending: number;
  running: number;
  succeeded: number;
  failed: number;
}

export interface Health {
  status: "ok" | "degraded";
  version: string;
  ffmpeg: string | null;
  encoders: string[];
  vmaf_available: boolean;
  queue: QueueStats;
  notes: string[];
}

export interface QualityReport {
  composite: number | null;
  video_score: number | null;
  audio_score: number | null;
  vmaf: number | null;
  ms_ssim: number | null;
  ssim: number | null;
  psnr: number | null;
  notes: string[];
}

export interface JobStatus {
  job_id: string;
  state: JobState;
  error: string | null;
  source_size: number | null;
  output_size: number | null;
  reduction: number | null;
  quality: QualityReport | null;
  quality_met: boolean | null;
  target_met: boolean | null;
  caveats: string[];
}

export interface FleetSnapshot {
  queue: QueueStats;
  depth: number;
  quotas: Record<string, { jobs_submitted: number; jobs_running: number; bytes_processed: number }>;
}

export interface Profile {
  name: string;
  description: string;
  lossless: boolean;
  extreme: boolean;
  quality_floor: number | null;
  suits: string[];
}
