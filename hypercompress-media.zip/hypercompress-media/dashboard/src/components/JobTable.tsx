/** The job list.
 *
 * Sorted with unfinished work first, because a queued job is a thing an
 * operator may still act on and a finished one usually is not.
 */

import { formatPercent, formatScore, formatSize } from "../api";
import type { JobStatus } from "../types";

interface Props {
  jobs: JobStatus[];
  floor: number;
  selected: string | null;
  onSelect: (jobId: string) => void;
}

const ORDER: Record<string, number> = {
  failed: 0,
  retrying: 1,
  running: 2,
  queued: 3,
  succeeded: 4,
  cancelled: 5,
  pending: 6,
};

export function JobTable({ jobs, floor, selected, onSelect }: Props) {
  const sorted = [...jobs].sort(
    (a, b) => (ORDER[a.state] ?? 9) - (ORDER[b.state] ?? 9) || a.job_id.localeCompare(b.job_id),
  );

  if (sorted.length === 0) {
    return <p className="empty">No jobs yet. Submit one from the panel on the right.</p>;
  }

  return (
    <table>
      <thead>
        <tr>
          <th scope="col">Job</th>
          <th scope="col">State</th>
          <th scope="col" className="num">
            Source
          </th>
          <th scope="col" className="num">
            Output
          </th>
          <th scope="col" className="num">
            Saved
          </th>
          <th scope="col" className="num">
            Quality
          </th>
        </tr>
      </thead>
      <tbody>
        {sorted.map((job) => {
          const score = job.quality?.composite ?? null;
          const belowFloor = score !== null && score < floor;
          return (
            <tr
              key={job.job_id}
              aria-selected={job.job_id === selected}
              tabIndex={0}
              onClick={() => onSelect(job.job_id)}
              onKeyDown={(event) => {
                if (event.key === "Enter") onSelect(job.job_id);
              }}
            >
              <td>{job.job_id.slice(0, 12)}</td>
              <td>
                <span className={`state state-${job.state}`}>{job.state}</span>
              </td>
              <td className="num">{formatSize(job.source_size)}</td>
              <td className="num">{formatSize(job.output_size)}</td>
              <td className="num">{formatPercent(job.reduction)}</td>
              <td className="num" style={belowFloor ? { color: "var(--gold)" } : undefined}>
                {formatScore(score)}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
