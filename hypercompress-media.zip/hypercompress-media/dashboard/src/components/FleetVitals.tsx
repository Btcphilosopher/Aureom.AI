/** Left rail: is the fleet keeping up, and is it doing useful work?
 *
 * Bytes saved sits alongside queue depth deliberately. A fleet at full
 * utilisation producing a 3% reduction is a fleet burning money, and a CPU
 * graph will never say so.
 */

import { formatPercent, formatSize } from "../api";
import type { FleetSnapshot, Health } from "../types";

interface Props {
  health: Health | null;
  fleet: FleetSnapshot | null;
  bytesIn: number;
  bytesOut: number;
}

function Vital({
  label,
  value,
  tone = "plain",
}: {
  label: string;
  value: string | number;
  tone?: "plain" | "live" | "alert";
}) {
  return (
    <div className="vital">
      <span className="vital-label">{label}</span>
      <span className={`vital-value ${tone === "plain" ? "" : tone}`}>{value}</span>
    </div>
  );
}

export function FleetVitals({ health, fleet, bytesIn, bytesOut }: Props) {
  const queue = fleet?.queue ?? health?.queue ?? null;
  const saved = Math.max(0, bytesIn - bytesOut);

  return (
    <>
      <section className="panel">
        <h2 className="panel-title">Fleet</h2>
        <Vital label="Queued" value={queue?.pending ?? "—"} tone={(queue?.pending ?? 0) > 0 ? "live" : "plain"} />
        <Vital label="Encoding" value={queue?.running ?? "—"} tone={(queue?.running ?? 0) > 0 ? "live" : "plain"} />
        <Vital label="Finished" value={queue?.succeeded ?? "—"} />
        <Vital label="Failed" value={queue?.failed ?? "—"} tone={(queue?.failed ?? 0) > 0 ? "alert" : "plain"} />
      </section>

      <section className="panel">
        <h2 className="panel-title">Storage</h2>
        <Vital label="Read" value={formatSize(bytesIn)} />
        <Vital label="Written" value={formatSize(bytesOut)} />
        <Vital label="Saved" value={formatSize(saved)} tone={saved > 0 ? "live" : "plain"} />
        <Vital
          label="Reduction"
          value={bytesIn > 0 ? formatPercent(saved / bytesIn) : "—"}
          tone={bytesIn > 0 && saved / bytesIn < 0.1 ? "alert" : "plain"}
        />
      </section>

      <section className="panel">
        <h2 className="panel-title">Encoder</h2>
        <Vital label="FFmpeg" value={health?.ffmpeg?.split(" ")[0] ?? "—"} />
        <Vital
          label="VMAF"
          value={health?.vmaf_available ? "measured" : "estimated"}
          tone={health && !health.vmaf_available ? "alert" : "plain"}
        />
        <Vital label="Codecs" value={health?.encoders.length ?? "—"} />
        {health?.notes.map((note) => (
          <p className="caveat" key={note}>
            {note}
          </p>
        ))}
      </section>

      {fleet && Object.keys(fleet.quotas).length > 0 && (
        <section className="panel">
          <h2 className="panel-title">Tenants</h2>
          {Object.entries(fleet.quotas).map(([tenant, usage]) => (
            <div className="vital" key={tenant}>
              <span className="vital-label">{tenant}</span>
              <span className="vital-value">{usage.jobs_running}</span>
            </div>
          ))}
        </section>
      )}
    </>
  );
}
