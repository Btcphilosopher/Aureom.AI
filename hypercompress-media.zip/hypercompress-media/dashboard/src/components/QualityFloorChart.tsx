/** The console's signature view.
 *
 * Every finished job is one point: how much smaller it got (x) against how good
 * it still looks (y). The configured quality floor is drawn as a hard line.
 *
 * The reason this is the centrepiece rather than a row of KPI tiles is that it
 * makes the platform's central claim falsifiable at a glance. Aggregate
 * throughput numbers cannot show you that eleven files last night shipped below
 * the quality they were promised; a point under the line can, and it is the
 * failure mode nobody notices until the sources have been deleted.
 */

import type { JobStatus } from "../types";

interface Props {
  jobs: JobStatus[];
  floor: number;
  selected: string | null;
  onSelect: (jobId: string) => void;
}

const WIDTH = 640;
const HEIGHT = 340;
const MARGIN = { top: 16, right: 20, bottom: 44, left: 48 };

const PLOT_W = WIDTH - MARGIN.left - MARGIN.right;
const PLOT_H = HEIGHT - MARGIN.top - MARGIN.bottom;

/** Quality is plotted from 0.5 up: below that nothing is a judgement call. */
const Y_MIN = 0.5;

export function QualityFloorChart({ jobs, floor, selected, onSelect }: Props) {
  const plotted = jobs.filter(
    (job) => job.reduction !== null && job.quality?.composite !== null && job.quality !== null,
  );

  const x = (reduction: number) => MARGIN.left + Math.max(0, Math.min(1, reduction)) * PLOT_W;
  const y = (score: number) =>
    MARGIN.top + PLOT_H - ((Math.max(Y_MIN, Math.min(1, score)) - Y_MIN) / (1 - Y_MIN)) * PLOT_H;

  const below = plotted.filter((job) => (job.quality?.composite ?? 1) < floor).length;

  return (
    <div className="chart-frame">
      <h2 className="panel-title">Delivered quality against size saved</h2>
      <svg
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        width="100%"
        role="img"
        aria-label={`${plotted.length} finished jobs plotted by size reduction and delivered quality. ${below} below the quality floor of ${floor}.`}
      >
        {/* Axes */}
        <line
          className="axis-line"
          x1={MARGIN.left}
          y1={MARGIN.top + PLOT_H}
          x2={MARGIN.left + PLOT_W}
          y2={MARGIN.top + PLOT_H}
        />
        <line
          className="axis-line"
          x1={MARGIN.left}
          y1={MARGIN.top}
          x2={MARGIN.left}
          y2={MARGIN.top + PLOT_H}
        />

        {[0, 0.25, 0.5, 0.75, 1].map((tick) => (
          <text key={tick} className="axis-text" x={x(tick)} y={MARGIN.top + PLOT_H + 14} textAnchor="middle">
            {Math.round(tick * 100)}%
          </text>
        ))}
        {[0.5, 0.7, 0.8, 0.9, 1].map((tick) => (
          <text key={tick} className="axis-text" x={MARGIN.left - 8} y={y(tick) + 3} textAnchor="end">
            {tick.toFixed(2)}
          </text>
        ))}

        <text className="axis-title" x={MARGIN.left + PLOT_W / 2} y={HEIGHT - 8} textAnchor="middle">
          SIZE SAVED
        </text>
        <text
          className="axis-title"
          transform={`translate(13 ${MARGIN.top + PLOT_H / 2}) rotate(-90)`}
          textAnchor="middle"
        >
          QUALITY
        </text>

        {/* The floor. The whole point of the view. */}
        <line
          className="floor-line"
          x1={MARGIN.left}
          y1={y(floor)}
          x2={MARGIN.left + PLOT_W}
          y2={y(floor)}
        />
        <text className="floor-label" x={MARGIN.left + PLOT_W} y={y(floor) - 6} textAnchor="end">
          FLOOR {floor.toFixed(2)}
        </text>

        {plotted.map((job) => {
          const score = job.quality?.composite ?? 0;
          const isBelow = score < floor;
          return (
            <circle
              key={job.job_id}
              className={[
                "point",
                isBelow ? "point-below" : "point-ok",
                job.job_id === selected ? "point-selected" : "",
              ]
                .filter(Boolean)
                .join(" ")}
              cx={x(job.reduction ?? 0)}
              cy={y(score)}
              r={job.job_id === selected ? 7 : 5}
              tabIndex={0}
              role="button"
              aria-label={`Job ${job.job_id}: ${Math.round((job.reduction ?? 0) * 100)}% smaller, quality ${score.toFixed(3)}${isBelow ? ", below the floor" : ""}`}
              onClick={() => onSelect(job.job_id)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onSelect(job.job_id);
                }
              }}
            />
          );
        })}

        {plotted.length === 0 && (
          <text className="chart-empty" x={WIDTH / 2} y={HEIGHT / 2} textAnchor="middle">
            No finished jobs yet. Points appear here as work completes.
          </text>
        )}
      </svg>

      <p className="chart-caption">
        {below > 0
          ? `${below} of ${plotted.length} delivered files sit below the floor. Each one is smaller than it should be at the quality it was promised — open it to see which measurement fell short.`
          : `All ${plotted.length} delivered files cleared the floor. Points further right saved more; points near the line saved as much as the floor allows.`}
      </p>
    </div>
  );
}
