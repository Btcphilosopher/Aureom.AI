/** Right rail: one job, in full, including what it cost.
 *
 * The caveats are given the most visual weight on the panel. They are the part
 * an operator is most tempted to skip and most likely to need: an estimated
 * VMAF, a size target that was not reached, a subtitle track that did not
 * survive. Burying them under the headline numbers would defeat the point of
 * recording them.
 */

import { formatPercent, formatScore, formatSize } from "../api";
import type { JobStatus } from "../types";

interface Props {
  job: JobStatus | null;
  floor: number;
}

/** How much the console is willing to vouch for a number.
 *
 * Three states, not two. "Measured" and "estimated" are different facts about
 * where a number came from; "breach" is a judgement about the number itself. A
 * measured value that missed the floor and an estimated value that cleared it
 * are both worth flagging, for opposite reasons.
 */
type Confidence = "measured" | "estimated" | "breach" | "plain";

function Metric({
  label,
  value,
  confidence = "plain",
}: {
  label: string;
  value: string;
  confidence?: Confidence;
}) {
  return (
    <div className="metric-row">
      <dt>{label}</dt>
      <dd className={confidence === "plain" ? undefined : confidence}>
        {value}
        {confidence === "estimated" && <span aria-label=" (estimated)" />}
      </dd>
    </div>
  );
}

export function JobDetail({ job, floor }: Props) {
  if (!job) {
    return (
      <section className="panel">
        <h2 className="panel-title">Job</h2>
        <p className="empty">Pick a point on the chart or a row in the table.</p>
      </section>
    );
  }

  const quality = job.quality;
  const score = quality?.composite ?? null;
  const belowFloor = score !== null && score < floor;
  const vmafEstimated = quality !== null && quality.vmaf === null;
  const estimate = quality?.notes.find((note) => note.startsWith("vmaf_estimate="));

  return (
    <>
      <section className="panel">
        <h2 className="panel-title">Job</h2>
        <p className="detail-id">{job.job_id.slice(0, 16)}</p>
        <span className={`state state-${job.state}`}>{job.state}</span>
        {job.error && <p className="caveat">{job.error}</p>}
      </section>

      <section className="panel">
        <h2 className="panel-title">Result</h2>
        <dl style={{ margin: 0 }}>
          <Metric label="Source" value={formatSize(job.source_size)} />
          <Metric label="Output" value={formatSize(job.output_size)} confidence="measured" />
          <Metric label="Saved" value={formatPercent(job.reduction)} confidence="measured" />
          {job.target_met === false && (
            <Metric label="Size target" value="not reached" confidence="breach" />
          )}
        </dl>
      </section>

      {quality && (
        <section className="panel">
          <h2 className="panel-title">Measured quality</h2>
          <dl style={{ margin: 0 }}>
            <Metric
              label="Composite"
              value={formatScore(score)}
              confidence={belowFloor ? "breach" : "measured"}
            />
            <Metric label="Video" value={formatScore(quality.video_score)} confidence="measured" />
            <Metric label="Audio" value={formatScore(quality.audio_score)} confidence="measured" />
            <Metric
              label="VMAF"
              value={
                quality.vmaf !== null
                  ? quality.vmaf.toFixed(2)
                  : estimate
                    ? `${estimate.split("=")[1]} (estimated)`
                    : "not measured"
              }
              confidence={vmafEstimated ? "estimated" : "measured"}
            />
            <Metric label="MS-SSIM" value={formatScore(quality.ms_ssim)} confidence="measured" />
            <Metric label="SSIM" value={formatScore(quality.ssim)} confidence="measured" />
            <Metric
              label="PSNR"
              value={quality.psnr !== null ? `${quality.psnr.toFixed(2)} dB` : "—"}
              confidence="measured"
            />
          </dl>
        </section>
      )}

      {job.caveats.length > 0 && (
        <section className="panel">
          <h2 className="panel-title">What to know</h2>
          {job.caveats.map((caveat) => (
            <p className="caveat" key={caveat}>
              {caveat}
            </p>
          ))}
        </section>
      )}
    </>
  );
}
