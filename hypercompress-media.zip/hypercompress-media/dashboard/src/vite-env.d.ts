/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Where the API lives. Defaults to "/api", which the dev proxy forwards. */
  readonly VITE_API_BASE?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
