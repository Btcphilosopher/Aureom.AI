/** The console shell.
 *
 * Polling rather than websockets. Encodes take minutes to hours, so a two-second
 * poll is far inside the resolution anyone needs, and it means the console has
 * no connection state to get wrong — a reconnect storm during an incident is
 * the last thing an operator needs from their dashboard.
 *
 * The token is held in memory only. Putting it in localStorage would leave a
 * working credential on any shared machine long after the operator walked away.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { ApiError, api } from "./api";
import { FleetVitals } from "./components/FleetVitals";
import { JobDetail } from "./components/JobDetail";
import { JobTable } from "./components/JobTable";
import { QualityFloorChart } from "./components/QualityFloorChart";
import type { FleetSnapshot, Health, JobStatus, Profile } from "./types";

const POLL_MS = 2000;
const DEFAULT_FLOOR = 0.9;

export function App() {
  const [token, setToken] = useState("");
  const [draftToken, setDraftToken] = useState("");
  const [health, setHealth] = useState<Health | null>(null);
  const [fleet, setFleet] = useState<FleetSnapshot | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [jobs, setJobs] = useState<Record<string, JobStatus>>({});
  const [selected, setSelected] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Job identifiers are remembered across polls so the console can keep
  // reporting on work it submitted; the API lists no index of them.
  const tracked = useRef<Set<string>>(new Set());

  const jobList = useMemo(() => Object.values(jobs), [jobs]);

  const floor = useMemo(() => {
    const balanced = profiles.find((profile) => profile.name === "balanced");
    return balanced?.quality_floor ?? DEFAULT_FLOOR;
  }, [profiles]);

  const totals = useMemo(
    () =>
      jobList.reduce(
        (acc, job) => ({
          bytesIn: acc.bytesIn + (job.source_size ?? 0),
          bytesOut: acc.bytesOut + (job.output_size ?? 0),
        }),
        { bytesIn: 0, bytesOut: 0 },
      ),
    [jobList],
  );

  const connect = useCallback(async () => {
    setError(null);
    try {
      const [nextHealth, nextProfiles] = await Promise.all([
        api.health(draftToken),
        api.profiles(draftToken),
      ]);
      setHealth(nextHealth);
      setProfiles(nextProfiles);
      setToken(draftToken);
    } catch (exc) {
      setError(exc instanceof ApiError ? exc.message : "Could not reach the API.");
    }
  }, [draftToken]);

  useEffect(() => {
    if (!token) return undefined;
    let cancelled = false;

    const poll = async () => {
      try {
        const [nextHealth, nextFleet] = await Promise.all([api.health(token), api.fleet(token)]);
        if (cancelled) return;
        setHealth(nextHealth);
        setFleet(nextFleet);

        const updates = await Promise.all(
          [...tracked.current].map((id) => api.job(token, id).catch(() => null)),
        );
        if (cancelled) return;
        setJobs((current) => {
          const next = { ...current };
          for (const job of updates) if (job) next[job.job_id] = job;
          return next;
        });
        setError(null);
      } catch (exc) {
        if (!cancelled) {
          setError(exc instanceof ApiError ? exc.message : "Lost contact with the API.");
        }
      }
    };

    void poll();
    const timer = window.setInterval(() => void poll(), POLL_MS);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [token]);

  const submit = useCallback(
    async (source: string, profile: string) => {
      setError(null);
      try {
        const response = await api.submit(token, { source, profile });
        tracked.current.add(response.job_id);
        setSelected(response.job_id);
      } catch (exc) {
        setError(exc instanceof ApiError ? exc.message : "Could not queue that file.");
      }
    },
    [token],
  );

  if (!token) {
    return <TokenGate value={draftToken} onChange={setDraftToken} onConnect={connect} error={error} />;
  }

  return (
    <div className="shell">
      <header className="masthead">
        <span className="wordmark">
          HYPER<span>COMPRESS</span>
        </span>
        <span className="build">v{health?.version ?? "—"}</span>
        <span className="spacer" />
        {error && <span className="error">{error}</span>}
      </header>

      <div className="columns">
        <div className="column">
          <FleetVitals health={health} fleet={fleet} bytesIn={totals.bytesIn} bytesOut={totals.bytesOut} />
        </div>

        <div className="column">
          <QualityFloorChart jobs={jobList} floor={floor} selected={selected} onSelect={setSelected} />
          <JobTable jobs={jobList} floor={floor} selected={selected} onSelect={setSelected} />
        </div>

        <div className="column">
          <SubmitPanel profiles={profiles} onSubmit={submit} />
          <JobDetail job={selected ? (jobs[selected] ?? null) : null} floor={floor} />
        </div>
      </div>
    </div>
  );
}

function TokenGate({
  value,
  onChange,
  onConnect,
  error,
}: {
  value: string;
  onChange: (value: string) => void;
  onConnect: () => void;
  error: string | null;
}) {
  return (
    <div className="gate">
      <p className="wordmark">
        HYPER<span>COMPRESS</span>
      </p>
      <p>
        Paste an operator token to connect. It is held in memory for this tab only and is never
        written to disk.
      </p>
      <input
        type="password"
        value={value}
        autoComplete="off"
        aria-label="Operator token"
        placeholder="bearer token"
        onChange={(event) => onChange(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Enter") onConnect();
        }}
      />
      <p style={{ marginTop: 14 }}>
        <button type="button" onClick={onConnect} disabled={!value}>
          Connect
        </button>
      </p>
      {error && <p className="error">{error}</p>}
    </div>
  );
}

function SubmitPanel({
  profiles,
  onSubmit,
}: {
  profiles: Profile[];
  onSubmit: (source: string, profile: string) => void;
}) {
  const [source, setSource] = useState("");
  const [profile, setProfile] = useState("balanced");

  return (
    <section className="panel">
      <h2 className="panel-title">Queue a file</h2>
      <input
        type="text"
        value={source}
        aria-label="Path to the file"
        placeholder="/media/library/film.mkv"
        onChange={(event) => setSource(event.target.value)}
      />
      <p style={{ margin: "10px 0" }}>
        <select
          value={profile}
          aria-label="Compression profile"
          onChange={(event) => setProfile(event.target.value)}
          style={{
            width: "100%",
            background: "var(--void)",
            border: "1px solid var(--rule)",
            color: "var(--bone)",
            fontFamily: "var(--mono)",
            fontSize: 12,
            padding: "8px 10px",
          }}
        >
          {profiles.map((option) => (
            <option key={option.name} value={option.name}>
              {option.name} — {option.description}
            </option>
          ))}
        </select>
      </p>
      <button type="button" disabled={!source} onClick={() => onSubmit(source, profile)}>
        Queue file
      </button>
    </section>
  );
}
