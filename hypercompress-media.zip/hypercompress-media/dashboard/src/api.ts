/** The API client.
 *
 * One thing worth stating: every request carries the operator's bearer token
 * and nothing else. There is no session and no cached identity, because the
 * server derives the tenant from the token on every call — a console that kept
 * its own idea of "who I am" could show one tenant's data under another's
 * heading after a token change.
 */

import type { FleetSnapshot, Health, JobStatus, Profile } from "./types";

const BASE = import.meta.env.VITE_API_BASE ?? "/api";

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

async function request<T>(path: string, token: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init?.headers ?? {}),
    },
  });

  if (!response.ok) {
    // The server sends a human-readable reason; surfacing it verbatim is more
    // useful than a status code, and these messages are written to be shown.
    let detail = `${response.status} ${response.statusText}`;
    try {
      const body = (await response.json()) as { detail?: string };
      if (body.detail) detail = body.detail;
    } catch {
      // A non-JSON error body is still an error; the status line will do.
    }
    throw new ApiError(detail, response.status);
  }
  return (await response.json()) as T;
}

export const api = {
  health: (token: string) => request<Health>("/health", token),
  fleet: (token: string) => request<FleetSnapshot>("/workers", token),
  profiles: (token: string) => request<Profile[]>("/profiles", token),
  job: (token: string, id: string) => request<JobStatus>(`/jobs/${id}`, token),
  submit: (token: string, body: Record<string, unknown>) =>
    request<{ job_id: string; state: string; queue_position: number }>("/jobs", token, {
      method: "POST",
      body: JSON.stringify(body),
    }),
};

/** Format bytes the way an operator reads them, not the way a computer stores them. */
export function formatSize(bytes: number | null | undefined): string {
  if (bytes === null || bytes === undefined) return "—";
  const units = ["B", "kB", "MB", "GB", "TB", "PB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1000 && unit < units.length - 1) {
    value /= 1000;
    unit += 1;
  }
  return `${value.toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
}

export function formatPercent(fraction: number | null | undefined, digits = 1): string {
  if (fraction === null || fraction === undefined) return "—";
  return `${(fraction * 100).toFixed(digits)}%`;
}

export function formatScore(score: number | null | undefined): string {
  return score === null || score === undefined ? "—" : score.toFixed(4);
}
