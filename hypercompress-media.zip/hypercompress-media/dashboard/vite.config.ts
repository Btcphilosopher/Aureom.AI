import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    // The console is served separately from the API in development, so calls
    // are proxied rather than made cross-origin. In production both sit behind
    // one ingress and this proxy is unused.
    proxy: {
      "/api": {
        target: process.env.HYPERCOMPRESS_API ?? "http://localhost:8000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ""),
      },
    },
  },
  build: { outDir: "dist", sourcemap: true },
});
