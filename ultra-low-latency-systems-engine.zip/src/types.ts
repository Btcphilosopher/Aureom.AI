export interface EngineStatus {
  status: string;
  compilers: {
    gcc: string;
    rustc: string;
    cmake: string;
  };
  hardware: {
    architecture: string;
    platform: string;
    cpuModel: string;
    coreCount: number;
    totalMemoryBytes: number;
    freeMemoryBytes: number;
    cacheLineSizeBytes: number;
    simdCapabilities: string[];
    numaAware: boolean;
  };
  engineVersion: string;
}

export interface BenchmarkReport {
  engine: string;
  events: number;
  stdout: string;
  parsed: {
    throughputEps: number;
    elapsedSec: number;
    p50_ns: number;
    p95_ns: number;
    p99_ns: number;
    p99_9_ns: number;
    p99_99_ns: number;
    max_ns: number;
    cpuCyclesPerEvent: number;
    allocationsPerEvent: number;
    cacheMissRatioPct: number;
  };
}

export interface FileNode {
  name: string;
  path: string;
  type: "file" | "directory";
  size?: number;
  children?: FileNode[];
}

export type ActiveTab = "benchmarks" | "pipeline" | "algorithm" | "code" | "profiler" | "ai";
