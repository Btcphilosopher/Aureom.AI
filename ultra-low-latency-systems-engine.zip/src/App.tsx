import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { BenchmarkTab } from "./components/BenchmarkTab";
import { PipelineTab } from "./components/PipelineTab";
import { AlgorithmTab } from "./components/AlgorithmTab";
import { CodeTab } from "./components/CodeTab";
import { ProfilerTab } from "./components/ProfilerTab";
import { AITab } from "./components/AITab";
import { EngineStatus, ActiveTab } from "./types";
import { Activity, Cpu, Zap, Layers, Terminal } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("benchmarks");
  const [status, setStatus] = useState<EngineStatus | null>(null);

  useEffect(() => {
    fetch("/api/engine/status")
      .then((res) => res.json())
      .then((data) => setStatus(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="min-h-screen bg-[#0B0C10] text-[#D1D5DB] font-mono flex flex-col justify-between selection:bg-[#00FF41] selection:text-black">
      <div>
        {/* Navigation Header */}
        <Header status={status} activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Main Content Layout */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Tab View */}
          <div className="lg:col-span-9 space-y-6">
            {activeTab === "benchmarks" && <BenchmarkTab />}
            {activeTab === "pipeline" && <PipelineTab />}
            {activeTab === "algorithm" && <AlgorithmTab />}
            {activeTab === "code" && <CodeTab />}
            {activeTab === "profiler" && <ProfilerTab />}
            {activeTab === "ai" && <AITab />}
          </div>

          {/* System Telemetry Sidebar */}
          <aside className="lg:col-span-3 space-y-4">
            <div className="border border-[#374151] bg-[#111827]/50 p-4 flex flex-col justify-between">
              <div>
                <h2 className="text-[#00FF41] text-[10px] font-bold uppercase mb-4 border-b border-[#374151] pb-1 tracking-tighter">
                  SYSTEM_TELEMETRY
                </h2>
                <div className="text-[10px] space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#9CA3AF]">CPU_UTIL</span>
                      <span className="text-white font-bold">14.2%</span>
                    </div>
                    <div className="h-1 bg-[#374151]">
                      <div className="w-[14%] h-full bg-[#00FF41]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#9CA3AF]">RSS_MEM</span>
                      <span className="text-white font-bold">512.4 MB</span>
                    </div>
                    <div className="h-1 bg-[#374151]">
                      <div className="w-[40%] h-full bg-[#00E5FF]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#9CA3AF]">L1_CACHE_MISS</span>
                      <span className="text-white font-bold">0.04%</span>
                    </div>
                    <div className="h-1 bg-[#374151]">
                      <div className="w-[4%] h-full bg-amber-400"></div>
                    </div>
                  </div>

                  <div className="mt-4 p-2.5 border border-[#374151] bg-black/40 space-y-1">
                    <div className="text-[#9CA3AF] uppercase text-[9px] mb-1 font-bold">
                      Kernel Optimizations
                    </div>
                    <div className="text-[10px] text-[#00FF41]">[✓] SO_BUSY_POLL</div>
                    <div className="text-[10px] text-[#00FF41]">[✓] CPU_THREAD_PINNING</div>
                    <div className="text-[10px] text-amber-400">[!] IO_URING_IDLE</div>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <button
                  onClick={() => setActiveTab("benchmarks")}
                  className="w-full border border-[#00FF41] text-[#00FF41] py-2 text-[10px] uppercase font-bold hover:bg-[#00FF41] hover:text-black transition-colors"
                >
                  Run Benchmark Suite
                </button>
              </div>
            </div>
          </aside>
        </main>
      </div>

      {/* Terminal Telemetry Footer */}
      <footer className="border-t border-[#374151] bg-black/80 p-3 max-w-7xl mx-auto w-full text-[10px] font-mono leading-tight space-y-0.5">
        <div className="text-[#00E5FF]">
          [DEBUG] [2026-08-12T14:12:04.123Z] Initialized Rust-Core executor...
        </div>
        <div className="text-[#00FF41]">
          [INFO] [2026-08-12T14:12:04.124Z] Attached shared-memory IPC buffer at 0x70001
        </div>
        <div className="text-white">
          [TRACE] Event [EID:99283] -&gt; Pipeline -&gt; Decision: BUY (v:142.1) -&gt; Output Latency: 1.12µs
        </div>
        <div className="text-white">
          [TRACE] Event [EID:99284] -&gt; Pipeline -&gt; Decision: HOLD (v:0.0) -&gt; Output Latency: 0.98µs
        </div>
        <div className="text-[#9CA3AF]">
          [TRACE] Event [EID:99285] -&gt; Pipeline -&gt; Decision: SELL (v:21.5) -&gt; Output Latency: 1.05µs
        </div>
      </footer>
    </div>
  );
}
