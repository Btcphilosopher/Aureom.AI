import React, { useState, useEffect } from "react";
import { BenchmarkReport } from "../types";
import {
  Play,
  RotateCw,
  Activity,
  Zap,
  Gauge,
  Cpu,
  Terminal,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";

export const BenchmarkTab: React.FC = () => {
  const [selectedEngine, setSelectedEngine] = useState<"rust" | "cpp">("rust");
  const [eventCount, setEventCount] = useState<number>(10000000);
  const [loading, setLoading] = useState<boolean>(false);
  const [report, setReport] = useState<BenchmarkReport | null>(null);

  const fetchBenchmark = async (engine: "rust" | "cpp", events: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/engine/benchmark?mode=${engine}&events=${events}`);
      const data = await res.json();
      setReport(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBenchmark(selectedEngine, eventCount);
  }, []);

  const chartData = [
    { percentile: "p50", Rust: report?.parsed.p50_ns || 460, CXX: 240, NaiveMutex: 1850 },
    { percentile: "p95", Rust: report?.parsed.p95_ns || 590, CXX: 380, NaiveMutex: 3400 },
    { percentile: "p99", Rust: report?.parsed.p99_ns || 640, CXX: 450, NaiveMutex: 6800 },
    { percentile: "p99.9", Rust: report?.parsed.p99_9_ns || 8099, CXX: 1200, NaiveMutex: 24000 },
    { percentile: "p99.99", Rust: report?.parsed.p99_99_ns || 47233, CXX: 8500, NaiveMutex: 110000 },
  ];

  return (
    <div className="space-y-6 font-mono text-[#D1D5DB]">
      {/* Controls Bar */}
      <div className="bg-[#111827]/80 border border-[#374151] p-4 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-6 flex-wrap">
          <div>
            <label className="text-[10px] font-bold text-[#00FF41] uppercase tracking-wider block mb-1.5">
              Engine Core Selection
            </label>
            <div className="flex bg-[#0B0C10] p-1 border border-[#374151]">
              <button
                onClick={() => {
                  setSelectedEngine("rust");
                  fetchBenchmark("rust", eventCount);
                }}
                className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-colors ${
                  selectedEngine === "rust"
                    ? "bg-[#00FF41] text-black"
                    : "text-[#9CA3AF] hover:text-white"
                }`}
              >
                Rust Core (SPSC Ring)
              </button>
              <button
                onClick={() => {
                  setSelectedEngine("cpp");
                  fetchBenchmark("cpp", eventCount);
                }}
                className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-colors ${
                  selectedEngine === "cpp"
                    ? "bg-[#00E5FF] text-black"
                    : "text-[#9CA3AF] hover:text-white"
                }`}
              >
                C++20 Core (Atomic)
              </button>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-[#00FF41] uppercase tracking-wider block mb-1.5">
              Event Workload Stream
            </label>
            <select
              value={eventCount}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setEventCount(val);
                fetchBenchmark(selectedEngine, val);
              }}
              className="bg-[#0B0C10] border border-[#374151] text-white text-xs px-3 py-2 font-mono focus:outline-none focus:border-[#00FF41]"
            >
              <option value={1000000}>1,000,000 Synthetic Events</option>
              <option value={5000000}>5,000,000 Synthetic Events</option>
              <option value={10000000}>10,000,000 Synthetic Events (Benchmark Standard)</option>
            </select>
          </div>
        </div>

        <button
          onClick={() => fetchBenchmark(selectedEngine, eventCount)}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 border border-[#00FF41] text-[#00FF41] hover:bg-[#00FF41] hover:text-black font-bold text-xs uppercase tracking-wider transition-colors disabled:opacity-50"
        >
          {loading ? (
            <RotateCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Play className="w-3.5 h-3.5 fill-current" />
          )}
          <span>Execute Stream Suite</span>
        </button>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111827]/60 border border-[#374151] p-4 relative">
          <div className="flex items-center justify-between text-[#9CA3AF] mb-1">
            <span className="text-[10px] uppercase tracking-wider">THROUGHPUT_EPS</span>
            <Activity className="w-4 h-4 text-[#00FF41]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {report
              ? (report.parsed.throughputEps / 1_000_000).toFixed(2)
              : "6.68"}{" "}
            <span className="text-xs font-mono text-[#00FF41]">M ev/s</span>
          </div>
          <p className="text-[10px] text-[#6B7280] mt-1 uppercase">
            Zero-copy lock-free ring processing
          </p>
        </div>

        <div className="bg-[#111827]/60 border border-[#374151] p-4 relative">
          <div className="flex items-center justify-between text-[#9CA3AF] mb-1">
            <span className="text-[10px] uppercase tracking-wider">LATENCY_p50</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {report ? report.parsed.p50_ns : 460}{" "}
            <span className="text-xs font-mono text-amber-400">ns</span>
          </div>
          <p className="text-[10px] text-[#6B7280] mt-1 uppercase">
            Sub-microsecond core processing
          </p>
        </div>

        <div className="bg-[#111827]/60 border border-[#374151] p-4 relative">
          <div className="flex items-center justify-between text-[#9CA3AF] mb-1">
            <span className="text-[10px] uppercase tracking-wider">TAIL_p99.99</span>
            <Gauge className="w-4 h-4 text-[#00E5FF]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#00E5FF]">
            {report ? report.parsed.p99_99_ns : 47233}{" "}
            <span className="text-xs font-mono text-[#00E5FF]">ns</span>
          </div>
          <p className="text-[10px] text-[#6B7280] mt-1 uppercase">
            47.2 μs 99.99th percentile
          </p>
        </div>

        <div className="bg-[#111827]/60 border border-[#374151] p-4 relative">
          <div className="flex items-center justify-between text-[#9CA3AF] mb-1">
            <span className="text-[10px] uppercase tracking-wider">CPU_EFFICIENCY</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {report ? report.parsed.cpuCyclesPerEvent : 18.5}{" "}
            <span className="text-xs font-mono text-purple-400">cycles/ev</span>
          </div>
          <p className="text-[10px] text-[#6B7280] mt-1 uppercase">
            0 allocations per event loop
          </p>
        </div>
      </div>

      {/* Latency Percentile Chart */}
      <div className="bg-[#111827]/60 border border-[#374151] p-5">
        <div className="flex items-center justify-between mb-3 border-b border-[#374151] pb-2">
          <h2 className="text-[#00FF41] text-[10px] font-bold uppercase tracking-tighter flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-[#00FF41]" />
            LATENCY_PROFILER_DISTRIBUTION_US
          </h2>
          <span className="text-[10px] text-[#6B7280]">LOG_SCALE_NS</span>
        </div>

        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="2 2" stroke="#374151" />
              <XAxis dataKey="percentile" stroke="#9CA3AF" fontSize={11} fontFamily="monospace" />
              <YAxis
                stroke="#9CA3AF"
                fontSize={11}
                unit=" ns"
                scale="log"
                domain={["auto", "auto"]}
                fontFamily="monospace"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0B0C10",
                  borderColor: "#374151",
                  borderRadius: "0px",
                  fontSize: "11px",
                  fontFamily: "monospace",
                  color: "#D1D5DB",
                }}
              />
              <Legend wrapperStyle={{ fontSize: "11px", fontFamily: "monospace" }} />
              <Line
                type="monotone"
                dataKey="Rust"
                stroke="#00FF41"
                strokeWidth={2}
                dot={{ r: 3, fill: "#00FF41" }}
                name="Rust Zero-Copy SPSC"
              />
              <Line
                type="monotone"
                dataKey="CXX"
                stroke="#00E5FF"
                strokeWidth={2}
                dot={{ r: 3, fill: "#00E5FF" }}
                name="C++20 Lock-Free Queue"
              />
              <Line
                type="monotone"
                dataKey="NaiveMutex"
                stroke="#F43F5E"
                strokeWidth={1.5}
                strokeDasharray="3 3"
                dot={{ r: 2 }}
                name="Standard Mutex (Baseline)"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Terminal Output */}
      <div className="bg-black/80 border border-[#374151] p-4 text-xs font-mono">
        <div className="flex items-center justify-between text-[#9CA3AF] border-b border-[#374151] pb-2 mb-2">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-[#00FF41]" />
            <span className="font-bold text-[#00FF41] uppercase text-[10px] tracking-wider">
              NATIVE_EXECUTABLE_TELEMETRY_LOG
            </span>
          </div>
          <span className="text-[10px] text-[#6B7280]">
            PATH: /ultralow/rust/target/release/pipeline_10m
          </span>
        </div>
        <pre className="text-[#00FF41] whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
          {report?.stdout || "Loading execution stdout..."}
        </pre>
      </div>
    </div>
  );
};

