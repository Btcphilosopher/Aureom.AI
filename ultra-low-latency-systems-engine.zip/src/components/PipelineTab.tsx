import React, { useState } from "react";
import { Zap, ChevronRight, Play, CheckCircle2, ShieldCheck, Cpu } from "lucide-react";

export const PipelineTab: React.FC = () => {
  const [activeStage, setActiveStage] = useState<number>(3);

  const stages = [
    { id: 1, name: "INPUT_RING_INGEST", latency: "0.12 μs", desc: "SPSC Lock-Free Ring Buffer pre-fetch via CPU L1 cache", status: "PASS" },
    { id: 2, name: "AVX512_ZEROCOPY_DECODE", latency: "0.08 μs", desc: "SIMD parallel byte alignment & checksum validation", status: "PASS" },
    { id: 3, name: "RING_POINTER_CLAIM", latency: "0.15 μs", desc: "Atomic relaxed acquire pointer increment without bus locking", status: "ACTIVE" },
    { id: 4, name: "ORDER_BOOK_MATCH", latency: "0.45 μs", desc: "L3-aligned cache-friendly B-tree depth iteration", status: "READY" },
    { id: 5, name: "RISK_LIMIT_ASSERT", latency: "0.05 μs", desc: "Branch-predicted SIMD position threshold check", status: "READY" },
    { id: 6, name: "ARENA_PAYLOAD_GEN", latency: "0.04 μs", desc: "Slab allocator zero-allocation execution packet creation", status: "READY" },
    { id: 7, name: "KERNEL_BYPASS_TX", latency: "0.18 μs", desc: "Solarflare EF_VI / DPDK direct NIC ring write", status: "READY" },
    { id: 8, name: "TELEMETRY_RECORD", latency: "0.02 μs", desc: "Ring-allocated asynchronous non-blocking trace log", status: "READY" },
  ];

  return (
    <div className="space-y-6 font-mono text-[#D1D5DB]">
      {/* Overview Banner */}
      <div className="bg-[#111827]/80 border border-[#374151] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[#00FF41] text-[10px] font-bold uppercase tracking-tighter flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#00FF41]" />
            DETERMINISTIC_8_STAGE_ZEROCOPY_PIPELINE
          </h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">
            End-to-end event execution pipeline with SIMD vectorization and kernel bypass
          </p>
        </div>
        <div className="flex gap-4 text-xs font-mono">
          <div className="border border-[#374151] px-3 py-1.5 bg-[#0B0C10]">
            <span className="text-[#9CA3AF] text-[10px] block">TOTAL_PIPELINE_LATENCY</span>
            <span className="text-[#00FF41] font-bold">1.09 μs</span>
          </div>
          <div className="border border-[#374151] px-3 py-1.5 bg-[#0B0C10]">
            <span className="text-[#9CA3AF] text-[10px] block">CACHE_MISS_RATIO</span>
            <span className="text-white font-bold">0.02%</span>
          </div>
        </div>
      </div>

      {/* Hot Path Pipeline Flow Visualizer */}
      <div className="bg-[#111827]/60 border border-[#374151] p-5">
        <h3 className="text-[#00FF41] text-[10px] uppercase mb-4 tracking-tighter font-bold border-b border-[#374151] pb-2">
          HOT_PATH_STAGE_GRAPH
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {stages.map((stg) => {
            const isSelected = activeStage === stg.id;
            return (
              <div
                key={stg.id}
                onClick={() => setActiveStage(stg.id)}
                className={`p-3 border transition-colors cursor-pointer text-xs ${
                  isSelected
                    ? "border-[#00FF41] bg-[#00FF41]/10 text-white"
                    : "border-[#374151] bg-[#0B0C10]/60 text-[#9CA3AF] hover:border-[#6B7280]"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-bold text-[#6B7280]">
                    STAGE_0{stg.id}
                  </span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 font-bold ${
                      stg.status === "PASS"
                        ? "bg-[#00FF41]/20 text-[#00FF41]"
                        : stg.status === "ACTIVE"
                        ? "bg-[#00E5FF]/20 text-[#00E5FF]"
                        : "bg-[#374151] text-[#9CA3AF]"
                    }`}
                  >
                    {stg.status}
                  </span>
                </div>
                <div className="font-bold text-[#D1D5DB] truncate mb-1">
                  {stg.name}
                </div>
                <div className="text-[10px] text-[#00FF41] font-mono">
                  {stg.latency}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stage Detail Inspector */}
      {activeStage && (
        <div className="bg-[#111827]/80 border border-[#374151] p-5">
          <div className="flex justify-between items-center border-b border-[#374151] pb-2 mb-3">
            <h4 className="text-xs font-bold text-white uppercase flex items-center gap-2">
              <Cpu className="w-3.5 h-3.5 text-[#00E5FF]" />
              STAGE {activeStage}: {stages[activeStage - 1].name}
            </h4>
            <span className="text-[#00FF41] text-xs font-mono">
              ESTIMATED_CYCLE_COST: ~{Math.round(parseFloat(stages[activeStage - 1].latency) * 3200)} CYCLES
            </span>
          </div>
          <p className="text-xs text-[#9CA3AF] mb-4">
            {stages[activeStage - 1].desc}
          </p>
          <div className="bg-[#0B0C10] border border-[#374151] p-3 text-[11px] font-mono text-[#00FF41]">
            <code>
              {`// Zero-copy assembly instruction stream for Stage ${activeStage}\n`}
              {`vmovdqa64 zmm0, [rdi + 0x40]\n`}
              {`vpaddq    zmm1, zmm0, zmm2\n`}
              {`vptestmb  k1, zmm1, zmm1\n`}
              {`kmovw     eax, k1\n`}
              {`sfence    ; Ensure store order across cores`}
            </code>
          </div>
        </div>
      )}
    </div>
  );
};
