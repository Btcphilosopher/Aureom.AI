import React, { useState } from "react";
import { Code2, Folder, FileText, ChevronRight, Download } from "lucide-react";

export const CodeTab: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<string>("rust/core/src/ring.rs");

  const files = [
    { name: "rust/core/src/ring.rs", lang: "Rust", desc: "Zero-copy SPSC lock-free ring buffer implementation" },
    { name: "rust/engine/src/pipeline.rs", lang: "Rust", desc: "8-stage event pipeline coordinator" },
    { name: "cpp/hardware/cache_align.hpp", lang: "C++", desc: "64-byte cache line alignment structures" },
    { name: "c/primitives/slab_arena.c", lang: "C", desc: "Constant-time lockless arena allocator" },
    { name: "rust/networking/dpdk_bypass.rs", lang: "Rust", desc: "User-space DPDK network driver interface" },
  ];

  const codeSnippets: Record<string, string> = {
    "rust/core/src/ring.rs": `pub struct SpscRingBuffer<T, const CAP: usize> {
    buffer: [UnsafeCell<MaybeUninit<T>>; CAP],
    head: CachePadded<AtomicUsize>,
    tail: CachePadded<AtomicUsize>,
}

impl<T, const CAP: usize> SpscRingBuffer<T, CAP> {
    #[inline(always)]
    pub fn push(&self, value: T) -> Result<(), T> {
        let tail = self.tail.load(Ordering::Relaxed);
        let head = self.head.load(Ordering::Acquire);
        
        if tail.wrapping_sub(head) >= CAP {
            return Err(value);
        }
        
        unsafe {
            (*self.buffer[tail % CAP].get()).write(value);
        }
        self.tail.store(tail.wrapping_add(1), Ordering::Release);
        Ok(())
    }
}`,
    "rust/engine/src/pipeline.rs": `pub struct Pipeline<Alg: Algorithm, const RING_CAP: usize> {
    ring_buffer: SpscRingBuffer<Event, RING_CAP>,
    arena: Arena,
    algorithm: Alg,
}

impl<Alg: Algorithm, const RING_CAP: usize> Pipeline<Alg, RING_CAP> {
    #[inline(always)]
    pub fn process_next(&mut self) -> Option<ExecutionResult> {
        if let Some(event) = self.ring_buffer.pop() {
            let result = self.algorithm.evaluate(&event);
            return Some(result);
        }
        None
    }
}`,
    "cpp/hardware/cache_align.hpp": `#pragma once
#include <atomic>
#include <cstddef>

constexpr size_t HARDWARE_DESTRUCTIVE_INTERFERENCE_SIZE = 64;

template <typename T>
struct alignas(HARDWARE_DESTRUCTIVE_INTERFERENCE_SIZE) CacheAligned {
    T value;
};`,
    "c/primitives/slab_arena.c": `#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint8_t* memory_pool;
    size_t block_size;
    size_t free_index;
    size_t total_blocks;
} slab_arena_t;

void* slab_alloc(slab_arena_t* arena) {
    if (arena->free_index >= arena->total_blocks) return NULL;
    void* ptr = arena->memory_pool + (arena->free_index * arena->block_size);
    arena->free_index++;
    return ptr;
}`,
    "rust/networking/dpdk_bypass.rs": `pub struct DpdkNicRing {
    rx_ring: *mut rte_ring,
    tx_ring: *mut rte_ring,
}

impl DpdkNicRing {
    #[inline(always)]
    pub unsafe fn rx_burst(&self, rx_pkts: *mut *mut rte_mbuf, nb_pkts: u16) -> u16 {
        rte_eth_rx_burst(0, 0, rx_pkts, nb_pkts)
    }
}`,
  };

  return (
    <div className="space-y-6 font-mono text-[#D1D5DB]">
      {/* Header */}
      <div className="bg-[#111827]/80 border border-[#374151] p-4 flex justify-between items-center">
        <div>
          <h2 className="text-[#00FF41] text-[10px] font-bold uppercase tracking-tighter flex items-center gap-2">
            <Code2 className="w-4 h-4 text-[#00FF41]" />
            NATIVE_REPOSITORY_CODE_INSPECTOR
          </h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">
            Inspect zero-copy Rust, C++20, and C kernel implementations
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* File Tree Sidebar */}
        <div className="md:col-span-4 bg-[#111827]/60 border border-[#374151] p-3">
          <h3 className="text-[#00FF41] text-[10px] uppercase mb-3 border-b border-[#374151] pb-1 tracking-tighter font-bold">
            REPOSITORY_TREE
          </h3>
          <div className="space-y-1">
            {files.map((file) => (
              <button
                key={file.name}
                onClick={() => setSelectedFile(file.name)}
                className={`w-full text-left p-2 border transition-colors text-xs flex items-center justify-between ${
                  selectedFile === file.name
                    ? "border-[#00FF41] bg-[#00FF41]/10 text-white"
                    : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#0B0C10]"
                }`}
              >
                <div className="truncate">
                  <div className="font-bold text-white text-[11px] truncate">{file.name}</div>
                  <div className="text-[10px] text-[#6B7280] truncate">{file.desc}</div>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 bg-[#374151] text-[#00FF41] font-bold ml-2">
                  {file.lang}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Code View */}
        <div className="md:col-span-8 bg-[#0B0C10] border border-[#374151] p-4">
          <div className="flex justify-between items-center text-xs text-[#9CA3AF] border-b border-[#374151] pb-2 mb-3">
            <span className="font-bold text-white uppercase">{selectedFile}</span>
            <span className="text-[#00FF41] text-[10px]">CACHE-LINE ALIGNED 64B</span>
          </div>
          <pre className="text-xs text-[#00FF41] whitespace-pre-wrap leading-relaxed font-mono">
            {codeSnippets[selectedFile] || "// Select a file from the repository tree"}
          </pre>
        </div>
      </div>
    </div>
  );
};
