import React, { useState } from "react";
import { Terminal, Cpu, Play, CheckCircle2, ShieldCheck, Zap } from "lucide-react";

export const AlgorithmTab: React.FC = () => {
  const [selectedAlg, setSelectedAlg] = useState<"arbitrage" | "vwap" | "marketmaker">("arbitrage");

  return (
    <div className="space-y-6 font-mono text-[#D1D5DB]">
      {/* Header */}
      <div className="bg-[#111827]/80 border border-[#374151] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[#00FF41] text-[10px] font-bold uppercase tracking-tighter flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#00FF41]" />
            DETERMINISTIC_ALGORITHM_EXECUTION_ENGINE
          </h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">
            Zero-allocation Rust / C++ trading strategy kernels with guaranteed execution latency
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedAlg("arbitrage")}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-colors ${
              selectedAlg === "arbitrage"
                ? "bg-[#00FF41] text-black"
                : "border border-[#374151] text-[#9CA3AF] hover:text-white"
            }`}
          >
            Spatial Arbitrage
          </button>
          <button
            onClick={() => setSelectedAlg("vwap")}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-colors ${
              selectedAlg === "vwap"
                ? "bg-[#00E5FF] text-black"
                : "border border-[#374151] text-[#9CA3AF] hover:text-white"
            }`}
          >
            SIMD VWAP Slicer
          </button>
          <button
            onClick={() => setSelectedAlg("marketmaker")}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase transition-colors ${
              selectedAlg === "marketmaker"
                ? "bg-purple-500 text-black"
                : "border border-[#374151] text-[#9CA3AF] hover:text-white"
            }`}
          >
            HFT Market Maker
          </button>
        </div>
      </div>

      {/* Strategy Summary & Code */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Strategy Spec */}
        <div className="lg:col-span-4 bg-[#111827]/60 border border-[#374151] p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-[#00FF41] text-[10px] uppercase mb-3 border-b border-[#374151] pb-1 tracking-tighter font-bold">
              STRATEGY_SPECIFICATIONS
            </h3>
            <div className="space-y-3 text-xs">
              <div>
                <span className="text-[#6B7280] text-[10px] block uppercase">Target Latency Budget</span>
                <span className="text-white font-bold">&lt; 250 nanoseconds</span>
              </div>
              <div>
                <span className="text-[#6B7280] text-[10px] block uppercase">Memory Allocation</span>
                <span className="text-[#00FF41] font-bold">0 Bytes (Preallocated Ring)</span>
              </div>
              <div>
                <span className="text-[#6B7280] text-[10px] block uppercase">Instruction Cache Footprint</span>
                <span className="text-white font-bold">&lt; 4KB (Fits L1i Cache)</span>
              </div>
              <div>
                <span className="text-[#6B7280] text-[10px] block uppercase">Branch Predictor Misses</span>
                <span className="text-white font-bold">0.001% (Branchless Branch)</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-3 border-t border-[#374151]">
            <button className="w-full border border-[#00FF41] text-[#00FF41] py-2 text-[10px] uppercase font-bold hover:bg-[#00FF41] hover:text-black transition-colors">
              Compile & Inject Strategy Kernel
            </button>
          </div>
        </div>

        {/* Code View */}
        <div className="lg:col-span-8 bg-[#0B0C10] border border-[#374151] p-4">
          <div className="flex justify-between items-center text-xs text-[#9CA3AF] border-b border-[#374151] pb-2 mb-3">
            <span className="font-bold text-white uppercase">
              {selectedAlg === "arbitrage" ? "rust/algorithms/spatial_arb.rs" : selectedAlg === "vwap" ? "cpp/algorithms/simd_vwap.cpp" : "rust/algorithms/hft_mm.rs"}
            </span>
            <span className="text-[#00FF41] text-[10px]">OPTIMIZED -O3 -march=native</span>
          </div>
          <pre className="text-xs text-[#00FF41] whitespace-pre-wrap leading-relaxed font-mono">
{selectedAlg === "arbitrage" ? `#[inline(always)]
pub fn process_event(event: &Event, book: &mut OrderBook) -> Option<Order> {
    // Zero-copy branchless spatial arbitrage computation
    let best_bid = book.bids.get_unchecked(0);
    let best_ask = book.asks.get_unchecked(0);
    
    let spread = best_ask.price - best_bid.price;
    if spread < 0 {
        return Some(Order {
            id: event.id,
            side: Side::Buy,
            price: best_bid.price,
            qty: event.qty.min(best_bid.qty),
        });
    }
    None
}` : selectedAlg === "vwap" ? `// C++20 AVX-512 SIMD VWAP Accumulator
__attribute__((always_inline)) inline void accumulate_vwap(const Event* __restrict events, size_t count, double& volume_acc, double& vwap_acc) {
    __m512d v_vol = _mm512_setzero_pd();
    __m512d v_pv = _mm512_setzero_pd();
    
    for (size_t i = 0; i < count; i += 8) {
        __m512d p = _mm512_load_pd(&events[i].price);
        __m512d q = _mm512_load_pd(&events[i].quantity);
        v_vol = _mm512_add_pd(v_vol, q);
        v_pv  = _mm512_fmadd_pd(p, q, v_pv);
    }
    volume_acc += _mm512_reduce_add_pd(v_vol);
    vwap_acc   += _mm512_reduce_add_pd(v_pv);
}` : `#[inline(always)]
pub fn update_quotes(quote_state: &mut QuoteState, mid_price: f64) {
    // High-frequency market making inventory skew strategy
    let inventory_skew = quote_state.inventory as f64 * 0.005;
    let reservation_price = mid_price - inventory_skew;
    
    quote_state.bid_price = reservation_price - 0.01;
    quote_state.ask_price = reservation_price + 0.01;
}`}
          </pre>
        </div>
      </div>
    </div>
  );
};
