import React from "react";
import { Flame, Cpu, Layers, HardDrive, Gauge } from "lucide-react";

export const ProfilerTab: React.FC = () => {
  return (
    <div className="space-y-6 font-mono text-[#D1D5DB]">
      {/* Header */}
      <div className="bg-[#111827]/80 border border-[#374151] p-4 flex justify-between items-center">
        <div>
          <h2 className="text-[#00FF41] text-[10px] font-bold uppercase tracking-tighter flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            HARDWARE_PROFILER_AND_MEMORY_ARENA
          </h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">
            L1/L2/L3 cache miss telemetry and slab memory pool inspector
          </p>
        </div>
      </div>

      {/* Hardware Telemetry Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#111827]/60 border border-[#374151] p-4">
          <h3 className="text-[#00FF41] text-[10px] uppercase mb-3 border-b border-[#374151] pb-1 tracking-tighter font-bold">
            CPU_CACHE_MISS_RATIO
          </h3>
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#9CA3AF]">L1 Data Cache Miss</span>
                <span className="text-white font-bold">0.02%</span>
              </div>
              <div className="h-1.5 bg-[#374151]">
                <div className="w-[2%] h-full bg-[#00FF41]"></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#9CA3AF]">L2 Unified Cache Miss</span>
                <span className="text-white font-bold">0.08%</span>
              </div>
              <div className="h-1.5 bg-[#374151]">
                <div className="w-[8%] h-full bg-[#00E5FF]"></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#9CA3AF]">LLC / L3 Cache Miss</span>
                <span className="text-white font-bold">0.14%</span>
              </div>
              <div className="h-1.5 bg-[#374151]">
                <div className="w-[14%] h-full bg-amber-400"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#111827]/60 border border-[#374151] p-4">
          <h3 className="text-[#00FF41] text-[10px] uppercase mb-3 border-b border-[#374151] pb-1 tracking-tighter font-bold">
            SLAB_ARENA_ALLOCATOR
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Arena Capacity:</span>
              <span className="text-white font-bold">1,024,000 KB</span>
            </div>
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Used Arena Slab:</span>
              <span className="text-[#00FF41] font-bold">256,000 KB (25%)</span>
            </div>
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Allocation Latency:</span>
              <span className="text-white font-bold">0 ns (Preallocated)</span>
            </div>
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Page Fault Count:</span>
              <span className="text-[#00FF41] font-bold">0 (mlock all)</span>
            </div>
          </div>
        </div>

        <div className="bg-[#111827]/60 border border-[#374151] p-4">
          <h3 className="text-[#00FF41] text-[10px] uppercase mb-3 border-b border-[#374151] pb-1 tracking-tighter font-bold">
            KERNEL_OPTIMIZATIONS
          </h3>
          <div className="space-y-1.5 text-[11px]">
            <div className="text-[#00FF41] flex items-center gap-2">
              <span>[✓]</span>
              <span>SO_BUSY_POLL (Kernel Socket Polling)</span>
            </div>
            <div className="text-[#00FF41] flex items-center gap-2">
              <span>[✓]</span>
              <span>CPU_THREAD_PINNING (Core #2 & #3)</span>
            </div>
            <div className="text-[#00FF41] flex items-center gap-2">
              <span>[✓]</span>
              <span>HUGETLB_2MB_PAGES (TLB Optimization)</span>
            </div>
            <div className="text-amber-400 flex items-center gap-2">
              <span>[!]</span>
              <span>IO_URING_IDLE_TIMEOUT (10ms)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
