import React from "react";
import { EngineStatus, ActiveTab } from "../types";
import {
  Activity,
  Cpu,
  Zap,
  Code2,
  Terminal,
  Flame,
  Bot,
  CheckCircle2,
  Layers,
} from "lucide-react";

interface HeaderProps {
  status: EngineStatus | null;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  activeTab,
  setActiveTab,
}) => {
  return (
    <header className="bg-[#0B0C10] border-b border-[#374151] text-[#D1D5DB] font-mono select-none">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="bg-[#00FF41] text-black px-2 py-0.5 text-xs font-bold font-mono tracking-tight shadow-[0_0_12px_rgba(0,255,65,0.4)]">
            ULTRALOW CORE v1.0.4
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-bold tracking-wider text-white uppercase">
                Ultra-Low-Latency Engine
              </h1>
              <span className="text-[#6B7280] text-xs uppercase tracking-widest hidden sm:inline">
                0x7FF8A291
              </span>
            </div>
            <p className="text-[11px] text-[#9CA3AF]">
              Zero-Copy SPSC Ring Buffer • SIMD AVX-512 Pipeline
            </p>
          </div>
        </div>

        {/* System Hardware Badges */}
        <div className="flex items-center gap-4 text-[11px]">
          <div className="hidden lg:flex items-center gap-1.5 text-[#9CA3AF]">
            <Cpu className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>{status?.hardware?.cpuModel ? status.hardware.cpuModel.split("@")[0] : "x86_64 Core i9"}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
            <span className="text-[#9CA3AF]">NUMA_AWARE: TRUE</span>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00FF41]"></span>
            <span className="text-[#9CA3AF]">LTO: ENABLED</span>
          </div>
          <div className="text-[#00FF41] border border-[#00FF41]/40 bg-[#00FF41]/10 px-2 py-0.5 text-[11px] font-mono">
            UPTIME: 142:12:04
          </div>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex overflow-x-auto border-t border-[#374151] no-scrollbar">
        <button
          onClick={() => setActiveTab("benchmarks")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold uppercase border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "benchmarks"
              ? "border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10"
              : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#111827]/50"
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Benchmarks & Tail Latency</span>
        </button>

        <button
          onClick={() => setActiveTab("pipeline")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold uppercase border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "pipeline"
              ? "border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10"
              : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#111827]/50"
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>8-Stage Pipeline</span>
        </button>

        <button
          onClick={() => setActiveTab("algorithm")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold uppercase border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "algorithm"
              ? "border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10"
              : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#111827]/50"
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>Algorithm Engine</span>
        </button>

        <button
          onClick={() => setActiveTab("code")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold uppercase border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "code"
              ? "border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10"
              : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#111827]/50"
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>Code Inspector</span>
        </button>

        <button
          onClick={() => setActiveTab("profiler")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold uppercase border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "profiler"
              ? "border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10"
              : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#111827]/50"
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Profiler & Memory Arena</span>
        </button>

        <button
          onClick={() => setActiveTab("ai")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold uppercase border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "ai"
              ? "border-purple-400 text-purple-400 bg-purple-500/10"
              : "border-transparent text-[#9CA3AF] hover:text-white hover:bg-[#111827]/50"
          }`}
        >
          <Bot className="w-3.5 h-3.5 text-purple-400" />
          <span>AI Architecture Advisor</span>
        </button>
      </div>
    </header>
  );
};

