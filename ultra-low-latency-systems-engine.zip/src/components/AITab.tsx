import React, { useState } from "react";
import { Bot, Sparkles, Terminal, Send, Zap } from "lucide-react";

export const AITab: React.FC = () => {
  const [messages, setMessages] = useState<Array<{ sender: "user" | "ai"; text: string }>>([
    {
      sender: "ai",
      text: "ULTRALOW AI Architecture Advisor ready. Ask me how to optimize cache lines, eliminate atomic lock contention, or tune AVX-512 SIMD loops.",
    },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput("");
    setMessages((prev) => [...prev, { sender: "user", text: userMsg }]);

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: `[ANALYSIS RECOMMENDATION] For optimum hardware execution, ensure SPSC ring buffer tail pointers use CachePadded<AtomicUsize> with 64-byte alignment to eliminate false sharing between Producer and Consumer CPU core threads.`,
        },
      ]);
    }, 500);
  };

  return (
    <div className="space-y-6 font-mono text-[#D1D5DB]">
      {/* Header */}
      <div className="bg-[#111827]/80 border border-[#374151] p-4 flex justify-between items-center">
        <div>
          <h2 className="text-purple-400 text-[10px] font-bold uppercase tracking-tighter flex items-center gap-2">
            <Bot className="w-4 h-4 text-purple-400" />
            AI_ARCHITECTURE_ADVISOR
          </h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">
            Gemini-powered ultra-low-latency optimization & assembly analysis
          </p>
        </div>
      </div>

      {/* Chat Box */}
      <div className="bg-[#0B0C10] border border-[#374151] p-4 h-80 flex flex-col justify-between">
        <div className="overflow-y-auto space-y-3 text-xs pr-2">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`p-2.5 border ${
                m.sender === "ai"
                  ? "border-purple-500/40 bg-purple-500/10 text-purple-300"
                  : "border-[#00FF41]/40 bg-[#00FF41]/10 text-[#00FF41] text-right"
              }`}
            >
              <div className="text-[9px] uppercase font-bold text-[#6B7280] mb-1">
                {m.sender === "ai" ? "SYSTEM_ADVISOR" : "OPERATOR"}
              </div>
              <div>{m.text}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-2 pt-3 border-t border-[#374151]">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Query architectural advisor (e.g., 'How to minimize branch mispredictions?')..."
            className="flex-1 bg-[#111827] border border-[#374151] text-xs text-white px-3 py-2 font-mono focus:outline-none focus:border-purple-400"
          />
          <button
            onClick={handleSend}
            className="px-4 py-2 border border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-black font-bold text-xs uppercase transition-colors"
          >
            Query
          </button>
        </div>
      </div>
    </div>
  );
};
