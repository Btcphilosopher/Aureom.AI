//! Complete demonstration processing 10,000,000 synthetic events in Rust.

use ultralow_engine::core::{Event, EventPayload};
use ultralow_engine::engine::{DummyAlg, Pipeline};
use ultralow_engine::telemetry::get_nanos;

fn main() {
    println!("=== Ultra-Low-Latency Rust Event Processing Engine ===");
    println!("Initializing 10,000,000 synthetic event pipeline...");

    let mut pipeline = Pipeline::<_, 1048576>::new(DummyAlg);

    let total_events = 10_000_000u64;
    let start_ns = get_nanos();

    for i in 0..total_events {
        let ev = Event::new(i, 101, 150_5000_0000, 500, i);
        let _ = pipeline.push_event(ev);

        if i % 8 == 0 || i == total_events - 1 {
            while pipeline.process_next().is_some() {}
        }
    }

    let end_ns = get_nanos();
    let duration_sec = (end_ns - start_ns) as f64 / 1_000_000_000.0;
    let eps = total_events as f64 / duration_sec;

    let report = pipeline.histogram().compute_report();

    println!("\n--- Pipeline Execution Summary ---");
    println!("Total Events Processed: {}", report.total_samples);
    println!("Elapsed Time:          {:.4} seconds", duration_sec);
    println!("Throughput:            {:.2} M events/sec", eps / 1_000_000.0);
    println!("\n--- Nanosecond Latency Distribution ---");
    println!("p50:    {} ns", report.p50_ns);
    println!("p95:    {} ns", report.p95_ns);
    println!("p99:    {} ns", report.p99_ns);
    println!("p99.9:  {} ns", report.p99_9_ns);
    println!("p99.99: {} ns", report.p99_99_ns);
    println!("Max:    {} ns", report.max_ns);
}
