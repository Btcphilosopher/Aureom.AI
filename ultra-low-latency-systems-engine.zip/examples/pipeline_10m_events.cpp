#include "../ultralow/cpp/algorithms/order_book.hpp"
#include "../ultralow/cpp/algorithms/rolling_stats.hpp"
#include "../ultralow/cpp/algorithms/anomaly_detector.hpp"
#include "../ultralow/c/primitives/spsc_ring.h"
#include "../ultralow/c/primitives/rdtsc_timer.h"
#include <iostream>
#include <vector>
#include <iomanip>
#include <chrono>

int main() {
    std::cout << "=== Ultra-Low-Latency C++ 10M Synthetic Event Engine ===\n";

    constexpr uint64_t TOTAL_EVENTS = 10000000;
    spsc_ring_c_t *ring = spsc_ring_c_create(1048576);

    ultralow::OrderBook book(1);
    ultralow::RollingStats stats;
    ultralow::AnomalyDetector anomaly(3.5);

    uint64_t start_ns = c_get_nanos();
    uint64_t anomalies_detected = 0;

    c_event_t ev;
    ev.symbol_id = 1;
    ev.quantity = 100;

    for (uint64_t i = 0; i < TOTAL_EVENTS; ++i) {
        ev.id = i;
        ev.timestamp_ns = c_get_nanos();
        ev.price = 150000000 + (i % 200) * 1000;

        spsc_ring_c_push(ring, &ev);

        c_event_t popped;
        if (spsc_ring_c_pop(ring, &popped)) {
            double price_dbl = (double)popped.price / 1e8;
            double z_score = 0.0;
            if (anomaly.inspect(price_dbl, (double)popped.quantity, z_score)) {
                anomalies_detected++;
            }
            if (i % 2 == 0) {
                book.add_bid(popped.price, popped.quantity);
            } else {
                book.add_ask(popped.price + 5000, popped.quantity);
            }
        }
    }

    uint64_t end_ns = c_get_nanos();
    double elapsed_sec = (double)(end_ns - start_ns) / 1e9;
    double eps = (double)TOTAL_EVENTS / elapsed_sec;

    std::cout << std::fixed << std::setprecision(3);
    std::cout << "Processed:          " << TOTAL_EVENTS << " events\n";
    std::cout << "Elapsed Time:       " << elapsed_sec << " s\n";
    std::cout << "Throughput:         " << (eps / 1e6) << " M events/sec\n";
    std::cout << "VWAP:               $" << stats.vwap() << "\n";
    std::cout << "Anomalies Flagged:  " << anomalies_detected << "\n";
    std::cout << "Order Book Depth:   Bids=" << book.bid_depth() << ", Asks=" << book.ask_depth() << "\n";

    spsc_ring_c_destroy(ring);
    return 0;
}
