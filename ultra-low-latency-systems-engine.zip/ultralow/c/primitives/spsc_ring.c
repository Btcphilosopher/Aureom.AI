#include "spsc_ring.h"
#include <stdlib.h>
#include <string.h>

spsc_ring_c_t* spsc_ring_c_create(uint64_t capacity) {
    // Ensure capacity is power of 2
    if (capacity == 0 || (capacity & (capacity - 1)) != 0) {
        capacity = 1048576; // Default 1M elements
    }

    spsc_ring_c_t *ring = (spsc_ring_c_t*) aligned_alloc(CACHE_LINE_SIZE, sizeof(spsc_ring_c_t));
    if (!ring) return NULL;

    atomic_init(&ring->head, 0);
    atomic_init(&ring->tail, 0);
    ring->capacity = capacity;
    ring->mask = capacity - 1;

    size_t buf_size = sizeof(c_event_t) * capacity;
    ring->buffer = (c_event_t*) aligned_alloc(CACHE_LINE_SIZE, buf_size);
    if (!ring->buffer) {
        free(ring);
        return NULL;
    }
    memset(ring->buffer, 0, buf_size);

    return ring;
}

void spsc_ring_c_destroy(spsc_ring_c_t *ring) {
    if (ring) {
        if (ring->buffer) free(ring->buffer);
        free(ring);
    }
}

bool spsc_ring_c_push(spsc_ring_c_t *ring, const c_event_t *ev) {
    uint64_t head = atomic_load_explicit(&ring->head, memory_order_relaxed);
    uint64_t tail = atomic_load_explicit(&ring->tail, memory_order_acquire);

    if (head - tail >= ring->capacity) {
        return false; // Queue full
    }

    ring->buffer[head & ring->mask] = *ev;
    atomic_store_explicit(&ring->head, head + 1, memory_order_release);
    return true;
}

bool spsc_ring_c_pop(spsc_ring_c_t *ring, c_event_t *out_ev) {
    uint64_t tail = atomic_load_explicit(&ring->tail, memory_order_relaxed);
    uint64_t head = atomic_load_explicit(&ring->head, memory_order_acquire);

    if (tail == head) {
        return false; // Queue empty
    }

    *out_ev = ring->buffer[tail & ring->mask];
    atomic_store_explicit(&ring->tail, tail + 1, memory_order_release);
    return true;
}

uint64_t spsc_ring_c_len(spsc_ring_c_t *ring) {
    uint64_t head = atomic_load_explicit(&ring->head, memory_order_relaxed);
    uint64_t tail = atomic_load_explicit(&ring->tail, memory_order_relaxed);
    return head - tail;
}
