#ifndef ULTRALOW_SPSC_RING_H
#define ULTRALOW_SPSC_RING_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
#include <atomic>
#define ATOMIC_UINT64 std::atomic<uint64_t>
#define ALIGNAS_64 alignas(64)
extern "C" {
#else
#include <stdatomic.h>
#define ATOMIC_UINT64 _Atomic uint64_t
#define ALIGNAS_64 _Alignas(64)
#endif

#define CACHE_LINE_SIZE 64

typedef struct {
    uint64_t id;
    uint64_t timestamp_ns;
    uint32_t symbol_id;
    int64_t price;
    uint64_t quantity;
    uint32_t flags;
} c_event_t;

typedef struct {
    ALIGNAS_64 ATOMIC_UINT64 head;
    ALIGNAS_64 ATOMIC_UINT64 tail;
    uint64_t capacity;
    uint64_t mask;
    c_event_t *buffer;
} spsc_ring_c_t;

spsc_ring_c_t* spsc_ring_c_create(uint64_t capacity);
void spsc_ring_c_destroy(spsc_ring_c_t *ring);
bool spsc_ring_c_push(spsc_ring_c_t *ring, const c_event_t *ev);
bool spsc_ring_c_pop(spsc_ring_c_t *ring, c_event_t *out_ev);
uint64_t spsc_ring_c_len(spsc_ring_c_t *ring);

#ifdef __cplusplus
}
#endif

#endif // ULTRALOW_SPSC_RING_H
