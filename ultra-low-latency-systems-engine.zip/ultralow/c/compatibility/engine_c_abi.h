#ifndef ULTRALOW_ENGINE_C_ABI_H
#define ULTRALOW_ENGINE_C_ABI_H

#include "../primitives/spsc_ring.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint64_t processed_count;
    uint64_t p50_ns;
    uint64_t p95_ns;
    uint64_t p99_ns;
    uint64_t p99_9_ns;
    uint64_t p99_99_ns;
    uint64_t max_ns;
    double throughput_eps;
    double total_time_sec;
} engine_benchmark_result_t;

engine_benchmark_result_t run_c_engine_benchmark(uint64_t total_events, int num_threads);

#ifdef __cplusplus
}
#endif

#endif // ULTRALOW_ENGINE_C_ABI_H
