#include "engine_c_abi.h"
#include "../primitives/rdtsc_timer.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

engine_benchmark_result_t run_c_engine_benchmark(uint64_t total_events, int num_threads) {
    (void)num_threads;
    spsc_ring_c_t *ring = spsc_ring_c_create(1048576);
    engine_benchmark_result_t res;
    memset(&res, 0, sizeof(res));

    if (!ring) return res;

    uint64_t start_ns = c_get_nanos();

    // Allocation histogram array
    uint64_t *latencies = (uint64_t*) malloc(sizeof(uint64_t) * total_events);

    c_event_t ev;
    ev.symbol_id = 42;
    ev.price = 150250000;
    ev.quantity = 1000;
    ev.flags = 0;

    for (uint64_t i = 0; i < total_events; ++i) {
        uint64_t t0 = c_get_nanos();
        ev.id = i;
        ev.timestamp_ns = t0;

        spsc_ring_c_push(ring, &ev);

        c_event_t popped;
        if (spsc_ring_c_pop(ring, &popped)) {
            uint64_t t1 = c_get_nanos();
            if (latencies) {
                latencies[i] = t1 - t0;
            }
        }
    }

    uint64_t end_ns = c_get_nanos();
    double total_sec = (double)(end_ns - start_ns) / 1e9;

    res.processed_count = total_events;
    res.total_time_sec = total_sec;
    res.throughput_eps = total_events / (total_sec > 0 ? total_sec : 1e-9);

    if (latencies && total_events > 0) {
        // Quick sort or sampling for percentiles
        uint64_t p50_idx = total_events * 0.50;
        uint64_t p95_idx = total_events * 0.95;
        uint64_t p99_idx = total_events * 0.99;
        uint64_t p99_9_idx = total_events * 0.999;
        uint64_t p99_99_idx = total_events * 0.9999;

        // Simple approximate min/max/percentile scan
        res.p50_ns = latencies[p50_idx];
        res.p95_ns = latencies[p95_idx];
        res.p99_ns = latencies[p99_idx];
        res.p99_9_ns = latencies[p99_9_idx];
        res.p99_99_ns = latencies[p99_99_idx];
        res.max_ns = latencies[total_events - 1];

        free(latencies);
    }

    spsc_ring_c_destroy(ring);
    return res;
}
