//! Cache line alignment utilities to prevent false sharing across threads.

use core::ops::{Deref, DerefMut};

/// Cache line size for standard x86_64 / ARM64 processors (64 bytes).
pub const CACHE_LINE_SIZE: usize = 64;

/// Pads data to fit exactly onto its own 64-byte cache line boundary.
/// Prevents cross-core cache line bouncing / false sharing on lock-free queues.
#[repr(C, align(64))]
#[derive(Clone, Copy, Debug, Default)]
pub struct CachePadded<T> {
    pub value: T,
}

impl<T> CachePadded<T> {
    #[inline(always)]
    pub const fn new(value: T) -> Self {
        Self { value }
    }

    #[inline(always)]
    pub fn into_inner(self) -> T {
        self.value
    }
}

impl<T> Deref for CachePadded<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

impl<T> DerefMut for CachePadded<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}
