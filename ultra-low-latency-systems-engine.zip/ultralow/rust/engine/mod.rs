pub mod pipeline;

pub use pipeline::{Algorithm, DummyAlg, Pipeline};
