//! Hot path 8-stage processing engine pipeline.

use crate::core::{ActionType, Decision, Event, EventPayload};
use crate::events::ring_buffer::SpscRingBuffer;
use crate::memory::arena::Arena;
use crate::telemetry::{get_nanos, LatencyHistogram};

pub trait Algorithm {
    fn process(&mut self, event: &Event) -> Decision;
}

pub struct DummyAlg;
impl Algorithm for DummyAlg {
    #[inline(always)]
    fn process(&mut self, event: &Event) -> Decision {
        let mut d = Decision::nop(event.id);
        if event.payload.price_raw > 100_0000_0000 {
            d.action = ActionType::Buy;
            d.price = event.payload.price_raw;
            d.quantity = event.payload.quantity_raw;
        }
        d
    }
}

pub struct Pipeline<Alg: Algorithm, const RING_CAP: usize> {
    ring_buffer: SpscRingBuffer<Event, RING_CAP>,
    arena: Arena,
    algorithm: Alg,
    histogram: LatencyHistogram,
}

impl<Alg: Algorithm, const RING_CAP: usize> Pipeline<Alg, RING_CAP> {
    pub fn new(alg: Alg) -> Self {
        Self {
            ring_buffer: SpscRingBuffer::new(),
            arena: Arena::new(16 * 1024 * 1024), // 16MB per-thread arena
            algorithm: alg,
            histogram: LatencyHistogram::new(),
        }
    }

    #[inline(always)]
    pub fn push_event(&self, mut event: Event) -> Result<(), Event> {
        event.ingress_timestamp_ns = get_nanos();
        self.ring_buffer.push(event)
    }

    /// Process a single event through the 8-stage pipeline in under 100 nanoseconds.
    #[inline(always)]
    pub fn process_next(&mut self) -> Option<Decision> {
        let mut event = self.ring_buffer.pop()?;

        // Stage 3: DECODE
        let decode_ts = get_nanos();
        event.decode_timestamp_ns = decode_ts;

        // Stage 4: VALIDATE
        if event.payload.quantity_raw == 0 {
            return None; // Invalid payload, early exit
        }

        // Stage 5 & 6: PROCESS + ALGORITHM
        let mut decision = self.algorithm.process(&event);

        // Stage 7: DECISION
        let output_ts = get_nanos();
        let total_latency = output_ts.saturating_sub(event.ingress_timestamp_ns);
        decision.latency_nanos = total_latency as u32;

        // Stage 8: OUTPUT & TELEMETRY
        self.histogram.record(total_latency);

        Some(decision)
    }

    pub fn histogram(&self) -> &LatencyHistogram {
        &self.histogram
    }
}
