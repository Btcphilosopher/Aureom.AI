use crate::core::align::CachePadded;
use core::cell::UnsafeCell;
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct SpscRingBuffer<T, const CAP: usize> {
    buffer: Box<[CachePadded<UnsafeCellStorage<T>>]>,
    head: CachePadded<AtomicUsize>,
    tail: CachePadded<AtomicUsize>,
}

struct UnsafeCellStorage<T> {
    cell: UnsafeCell<Option<T>>,
}

impl<T> Default for UnsafeCellStorage<T> {
    fn default() -> Self {
        Self {
            cell: UnsafeCell::new(None),
        }
    }
}

unsafe impl<T: Send, const CAP: usize> Send for SpscRingBuffer<T, CAP> {}
unsafe impl<T: Send, const CAP: usize> Sync for SpscRingBuffer<T, CAP> {}

impl<T, const CAP: usize> SpscRingBuffer<T, CAP> {
    pub fn new() -> Self {
        assert!(CAP > 0 && (CAP & (CAP - 1)) == 0, "Capacity must be power of 2");

        let mut vec = Vec::with_capacity(CAP);
        for _ in 0..CAP {
            vec.push(CachePadded::new(UnsafeCellStorage::default()));
        }

        Self {
            buffer: vec.into_boxed_slice(),
            head: CachePadded::new(AtomicUsize::new(0)),
            tail: CachePadded::new(AtomicUsize::new(0)),
        }
    }

    #[inline(always)]
    pub fn push(&self, item: T) -> Result<(), T> {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Acquire);

        if head.wrapping_sub(tail) >= CAP {
            return Err(item);
        }

        let slot_idx = head & (CAP - 1);
        unsafe {
            let slot = self.buffer[slot_idx].cell.get();
            *slot = Some(item);
        }

        self.head.store(head.wrapping_add(1), Ordering::Release);
        Ok(())
    }

    #[inline(always)]
    pub fn pop(&self) -> Option<T> {
        let tail = self.tail.load(Ordering::Relaxed);
        let head = self.head.load(Ordering::Acquire);

        if tail == head {
            return None;
        }

        let slot_idx = tail & (CAP - 1);
        let item = unsafe {
            let slot = self.buffer[slot_idx].cell.get();
            (*slot).take()
        };

        self.tail.store(tail.wrapping_add(1), Ordering::Release);
        item
    }

    #[inline(always)]
    pub fn len(&self) -> usize {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Relaxed);
        head.wrapping_sub(tail)
    }

    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}
