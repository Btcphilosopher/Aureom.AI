use crate::core::EventPayload;

pub struct ZeroCopyView<'a> {
    raw_buffer: &'a [u8],
}

impl<'a> ZeroCopyView<'a> {
    #[inline(always)]
    pub fn from_bytes(slice: &'a [u8]) -> Result<Self, &'static str> {
        if slice.len() < std::mem::size_of::<EventPayload>() {
            return Err("Buffer too short for ZeroCopyView");
        }
        Ok(Self { raw_buffer: slice })
    }

    #[inline(always)]
    pub fn parse_payload(&self) -> &'a EventPayload {
        unsafe { &*(self.raw_buffer.as_ptr() as *const EventPayload) }
    }

    #[inline(always)]
    pub fn raw_bytes(&self) -> &'a [u8] {
        self.raw_buffer
    }
}
