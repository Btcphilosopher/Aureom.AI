pub mod clock;
pub mod metrics;

pub use clock::{get_nanos, get_tsc};
pub use metrics::{LatencyHistogram, LatencyReport};
