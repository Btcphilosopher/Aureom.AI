#[derive(Clone, Debug)]
pub struct EngineConfig {
    pub num_workers: usize,
    pub ring_buffer_capacity: usize,
    pub arena_capacity_bytes: usize,
    pub pin_cpu_cores: Vec<usize>,
    pub enable_so_busy_poll: bool,
    pub zero_copy_mode: bool,
}

impl Default for EngineConfig {
    fn default() -> Self {
        Self {
            num_workers: 2,
            ring_buffer_capacity: 1048576,
            arena_capacity_bytes: 64 * 1024 * 1024,
            pin_cpu_cores: vec![1, 2, 3],
            enable_so_busy_poll: true,
            zero_copy_mode: true,
        }
    }
}
