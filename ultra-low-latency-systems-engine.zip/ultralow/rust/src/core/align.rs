use core::ops::{Deref, DerefMut};

pub const CACHE_LINE_SIZE: usize = 64;

#[repr(C, align(64))]
#[derive(Clone, Copy, Debug, Default)]
pub struct CachePadded<T> {
    pub value: T,
}

impl<T> CachePadded<T> {
    #[inline(always)]
    pub const fn new(value: T) -> Self {
        Self { value }
    }

    #[inline(always)]
    pub fn into_inner(self) -> T {
        self.value
    }
}

impl<T> Deref for CachePadded<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

impl<T> DerefMut for CachePadded<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}
