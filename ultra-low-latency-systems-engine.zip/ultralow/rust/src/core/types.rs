//! Core data types with strict memory layout guarantees for microsecond latency.

pub type EventId = u64;
pub type TimestampNs = u64;

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ActionType {
    Nop = 0,
    Buy = 1,
    Sell = 2,
    Cancel = 3,
    Modify = 4,
    Alert = 5,
    Drop = 6,
}

#[repr(C, align(64))]
#[derive(Clone, Copy, Debug)]
pub struct EventPayload {
    pub symbol_id: u32,
    pub price_raw: i64,      // Fixed point 8 decimals
    pub quantity_raw: u64,   // Fixed point 4 decimals
    pub sequence_num: u64,
    pub flags: u32,
    pub reserved: [u8; 32],  // Padding to preserve 64-byte cache line alignment
}

impl Default for EventPayload {
    fn default() -> Self {
        Self {
            symbol_id: 0,
            price_raw: 0,
            quantity_raw: 0,
            sequence_num: 0,
            flags: 0,
            reserved: [0u8; 32],
        }
    }
}

#[repr(C, align(64))]
#[derive(Clone, Copy, Debug)]
pub struct Event {
    pub id: EventId,
    pub ingress_timestamp_ns: TimestampNs,
    pub decode_timestamp_ns: TimestampNs,
    pub payload: EventPayload,
}

impl Event {
    #[inline(always)]
    pub fn new(id: EventId, symbol_id: u32, price_raw: i64, quantity_raw: u64, seq: u64) -> Self {
        Self {
            id,
            ingress_timestamp_ns: 0,
            decode_timestamp_ns: 0,
            payload: EventPayload {
                symbol_id,
                price_raw,
                quantity_raw,
                sequence_num: seq,
                flags: 0,
                reserved: [0u8; 32],
            },
        }
    }
}

#[repr(C, align(64))]
#[derive(Clone, Copy, Debug)]
pub struct Decision {
    pub event_id: EventId,
    pub action: ActionType,
    pub target_symbol_id: u32,
    pub price: i64,
    pub quantity: u64,
    pub latency_nanos: u32,
    pub algorithm_id: u16,
    pub execution_flags: u16,
}

impl Decision {
    #[inline(always)]
    pub fn nop(event_id: EventId) -> Self {
        Self {
            event_id,
            action: ActionType::Nop,
            target_symbol_id: 0,
            price: 0,
            quantity: 0,
            latency_nanos: 0,
            algorithm_id: 0,
            execution_flags: 0,
        }
    }
}
