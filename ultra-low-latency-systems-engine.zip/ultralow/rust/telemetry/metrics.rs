//! Lock-free high-dynamic-range nanosecond latency histogram accumulator.

use std::sync::atomic::{AtomicU64, Ordering};

const NUM_BUCKETS: usize = 100_000; // 0 to 100,000 nanoseconds (100 us) at 1ns resolution

pub struct LatencyHistogram {
    buckets: Box<[AtomicU64; NUM_BUCKETS]>,
    overflow: AtomicU64,
    total_samples: AtomicU64,
    min_latency_ns: AtomicU64,
    max_latency_ns: AtomicU64,
}

#[derive(Debug, Clone, Copy)]
pub struct LatencyReport {
    pub total_samples: u64,
    pub p50_ns: u64,
    pub p95_ns: u64,
    pub p99_ns: u64,
    pub p99_9_ns: u64,
    pub p99_99_ns: u64,
    pub min_ns: u64,
    pub max_ns: u64,
}

impl LatencyHistogram {
    pub fn new() -> Self {
        let buckets = Box::new(std::array::from_fn(|_| AtomicU64::new(0)));
        Self {
            buckets,
            overflow: AtomicU64::new(0),
            total_samples: AtomicU64::new(0),
            min_latency_ns: AtomicU64::new(u64::MAX),
            max_latency_ns: AtomicU64::new(0),
        }
    }

    #[inline(always)]
    pub fn record(&self, latency_ns: u64) {
        self.total_samples.fetch_add(1, Ordering::Relaxed);

        if latency_ns < NUM_BUCKETS as u64 {
            self.buckets[latency_ns as usize].fetch_add(1, Ordering::Relaxed);
        } else {
            self.overflow.fetch_add(1, Ordering::Relaxed);
        }

        // Min update
        let mut curr_min = self.min_latency_ns.load(Ordering::Relaxed);
        while latency_ns < curr_min {
            match self.min_latency_ns.compare_exchange_weak(
                curr_min,
                latency_ns,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(actual) => curr_min = actual,
            }
        }

        // Max update
        let mut curr_max = self.max_latency_ns.load(Ordering::Relaxed);
        while latency_ns > curr_max {
            match self.max_latency_ns.compare_exchange_weak(
                curr_max,
                latency_ns,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(actual) => curr_max = actual,
            }
        }
    }

    pub fn compute_report(&self) -> LatencyReport {
        let total = self.total_samples.load(Ordering::Relaxed);
        if total == 0 {
            return LatencyReport {
                total_samples: 0,
                p50_ns: 0,
                p95_ns: 0,
                p99_ns: 0,
                p99_9_ns: 0,
                p99_99_ns: 0,
                min_ns: 0,
                max_ns: 0,
            };
        }

        let target_p50 = (total as f64 * 0.50) as u64;
        let target_p95 = (total as f64 * 0.95) as u64;
        let target_p99 = (total as f64 * 0.99) as u64;
        let target_p99_9 = (total as f64 * 0.999) as u64;
        let target_p99_99 = (total as f64 * 0.9999) as u64;

        let mut cumulative = 0u64;
        let mut p50 = 0u64;
        let mut p95 = 0u64;
        let mut p99 = 0u64;
        let mut p99_9 = 0u64;
        let mut p99_99 = 0u64;

        for (ns, bucket) in self.buckets.iter().enumerate() {
            let count = bucket.load(Ordering::Relaxed);
            cumulative += count;

            if cumulative >= target_p50 && p50 == 0 {
                p50 = ns as u64;
            }
            if cumulative >= target_p95 && p95 == 0 {
                p95 = ns as u64;
            }
            if cumulative >= target_p99 && p99 == 0 {
                p99 = ns as u64;
            }
            if cumulative >= target_p99_9 && p99_9 == 0 {
                p99_9 = ns as u64;
            }
            if cumulative >= target_p99_99 && p99_99 == 0 {
                p99_99 = ns as u64;
                break;
            }
        }

        let min_val = self.min_latency_ns.load(Ordering::Relaxed);
        let max_val = self.max_latency_ns.load(Ordering::Relaxed);

        LatencyReport {
            total_samples: total,
            p50_ns: if p50 == 0 { min_val } else { p50 },
            p95_ns: if p95 == 0 { p50 } else { p95 },
            p99_ns: if p99 == 0 { p95 } else { p99 },
            p99_9_ns: if p99_9 == 0 { p99 } else { p99_9 },
            p99_99_ns: if p99_99 == 0 { p99_9 } else { p99_99 },
            min_ns: if min_val == u64::MAX { 0 } else { min_val },
            max_ns: max_val,
        }
    }
}
