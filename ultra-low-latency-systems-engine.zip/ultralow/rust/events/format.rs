//! High-speed packed binary protocol encoder/decoder with zero heap allocations.

use crate::core::{Event, EventPayload};

pub struct EventWireDecoder;

impl EventWireDecoder {
    #[inline(always)]
    pub fn decode_in_place(buf: &[u8], event: &mut Event) -> Result<(), &'static str> {
        if buf.len() < std::mem::size_of::<EventPayload>() {
            return Err("Buffer underflow");
        }

        unsafe {
            let src_ptr = buf.as_ptr() as *const EventPayload;
            std::ptr::copy_nonoverlapping(src_ptr, &mut event.payload as *mut EventPayload, 1);
        }

        Ok(())
    }
}
