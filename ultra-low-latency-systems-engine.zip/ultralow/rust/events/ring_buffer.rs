//! High-throughput Lock-Free Single-Producer Single-Consumer (SPSC) Ring Buffer.
//! Designed with cache line padding to prevent false sharing and cache-bouncing across cores.

use crate::core::align::CachePadded;
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct SpscRingBuffer<T, const CAP: usize> {
    buffer: Box<[CachePadded<UnsafeCellStorage<T>>; CAP]>,
    head: CachePadded<AtomicUsize>, // Written by Producer, read by Consumer
    tail: CachePadded<AtomicUsize>, // Written by Consumer, read by Producer
}

struct UnsafeCellStorage<T> {
    cell: core::cell::UnsafeCell<Option<T>>,
}

impl<T> Default for UnsafeCellStorage<T> {
    fn default() -> Self {
        Self {
            cell: core::cell::UnsafeCell::new(None),
        }
    }
}

unsafe impl<T: Send, const CAP: usize> Send for SpscRingBuffer<T, CAP> {}
unsafe impl<T: Send, const CAP: usize> Sync for SpscRingBuffer<T, CAP> {}

impl<T, const CAP: usize> SpscRingBuffer<T, CAP> {
    pub fn new() -> Self {
        assert!(CAP > 0 && (CAP & (CAP - 1)) == 0, "Capacity must be a power of 2");

        let buffer = Box::new(std::array::from_fn(|_| {
            CachePadded::new(UnsafeCellStorage::default())
        }));

        Self {
            buffer,
            head: CachePadded::new(AtomicUsize::new(0)),
            tail: CachePadded::new(AtomicUsize::new(0)),
        }
    }

    /// Push an item onto the ring buffer without acquiring locks.
    #[inline(always)]
    pub fn push(&self, item: T) -> Result<(), T> {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Acquire);

        if head.wrapping_sub(tail) >= CAP {
            return Err(item); // Queue Full
        }

        let slot_idx = head & (CAP - 1);
        unsafe {
            let slot = self.buffer[slot_idx].cell.get();
            *slot = Some(item);
        }

        self.head.store(head.wrapping_add(1), Ordering::Release);
        Ok(())
    }

    /// Pop an item off the ring buffer without acquiring locks.
    #[inline(always)]
    pub fn pop(&self) -> Option<T> {
        let tail = self.tail.load(Ordering::Relaxed);
        let head = self.head.load(Ordering::Acquire);

        if tail == head {
            return None; // Queue Empty
        }

        let slot_idx = tail & (CAP - 1);
        let item = unsafe {
            let slot = self.buffer[slot_idx].cell.get();
            (*slot).take()
        };

        self.tail.store(tail.wrapping_add(1), Ordering::Release);
        item
    }

    #[inline(always)]
    pub fn len(&self) -> usize {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Relaxed);
        head.wrapping_sub(tail)
    }

    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn capacity(&self) -> usize {
        CAP
    }
}
