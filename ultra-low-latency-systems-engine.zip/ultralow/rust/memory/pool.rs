//! Lock-free Object Pool for recycling fixed-capacity objects without GC or system heap calls.

use std::sync::atomic::{AtomicUsize, Ordering};

pub struct ObjectPool<T: Default + Send, const N: usize> {
    storage: Box<[T; N]>,
    available_indices: Box<[AtomicUsize; N]>,
    head: AtomicUsize,
    tail: AtomicUsize,
}

impl<T: Default + Send, const N: usize> ObjectPool<T, N> {
    pub fn new() -> Self {
        let storage = Box::new(std::array::from_fn(|_| T::default()));
        let indices = Box::new(std::array::from_fn(|i| AtomicUsize::new(i)));

        Self {
            storage,
            available_indices: indices,
            head: AtomicUsize::new(0),
            tail: AtomicUsize::new(N),
        }
    }

    #[inline(always)]
    pub fn acquire(&self) -> Option<(usize, &T)> {
        let head = self.head.fetch_add(1, Ordering::AcqRel);
        if head >= N {
            self.head.fetch_sub(1, Ordering::Relaxed);
            return None;
        }
        let slot = self.available_indices[head % N].load(Ordering::Acquire);
        Some((slot, &self.storage[slot]))
    }

    #[inline(always)]
    pub fn release(&self, slot: usize) {
        let tail = self.tail.fetch_add(1, Ordering::AcqRel);
        self.available_indices[tail % N].store(slot, Ordering::Release);
    }
}
