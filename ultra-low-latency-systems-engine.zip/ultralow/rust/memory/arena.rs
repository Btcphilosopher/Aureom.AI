//! High-speed bump-pointer arena for zero-heap-allocation per-event processing.

use std::alloc::{alloc, dealloc, Layout};
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct Arena {
    memory: *mut u8,
    capacity: usize,
    offset: AtomicUsize,
    layout: Layout,
}

unsafe impl Send for Arena {}
unsafe impl Sync for Arena {}

impl Arena {
    pub fn new(capacity: usize) -> Self {
        let align = 64; // Cache-line aligned memory
        let layout = Layout::from_size_align(capacity, align).expect("Invalid layout for Arena");
        let memory = unsafe { alloc(layout) };
        if memory.is_null() {
            panic!("Failed to allocate {} bytes for Arena", capacity);
        }

        Self {
            memory,
            capacity,
            offset: AtomicUsize::new(0),
            layout,
        }
    }

    /// Fast bump allocation on preallocated buffer.
    #[inline(always)]
    pub fn alloc_slice<T: Copy>(&self, count: usize) -> Option<&mut [T]> {
        let size = count * std::mem::size_of::<T>();
        let align = std::mem::align_of::<T>();

        let mut current = self.offset.load(Ordering::Relaxed);
        loop {
            let aligned = (current + align - 1) & !(align - 1);
            let next = aligned + size;

            if next > self.capacity {
                return None;
            }

            match self.offset.compare_exchange_weak(
                current,
                next,
                Ordering::AcqRel,
                Ordering::Relaxed,
            ) {
                Ok(_) => {
                    let ptr = unsafe { self.memory.add(aligned) as *mut T };
                    return Some(unsafe { std::slice::from_raw_parts_mut(ptr, count) });
                }
                Err(actual) => current = actual,
            }
        }
    }

    /// Reset arena pointer to zero for the next batch without freeing underlying memory block.
    #[inline(always)]
    pub fn reset(&self) {
        self.offset.store(0, Ordering::Release);
    }

    pub fn used_bytes(&self) -> usize {
        self.offset.load(Ordering::Relaxed)
    }

    pub fn capacity_bytes(&self) -> usize {
        self.capacity
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        unsafe {
            dealloc(self.memory, self.layout);
        }
    }
}
