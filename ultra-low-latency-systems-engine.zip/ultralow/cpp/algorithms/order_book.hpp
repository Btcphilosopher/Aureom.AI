#ifndef ULTRALOW_ORDER_BOOK_HPP
#define ULTRALOW_ORDER_BOOK_HPP

#include <array>
#include <cstdint>
#include <algorithm>
#include <iostream>

namespace ultralow {

constexpr size_t MAX_LEVELS = 20;

struct PriceLevel {
    int64_t price{0};
    uint64_t quantity{0};
    uint32_t order_count{0};
};

struct MatchResult {
    uint64_t matched_qty{0};
    int64_t execution_price{0};
    bool fully_filled{false};
};

/// High-speed O(1) Limit Order Book using fixed-size cache-aligned arrays
class alignas(64) OrderBook {
private:
    std::array<PriceLevel, MAX_LEVELS> bids_{};
    std::array<PriceLevel, MAX_LEVELS> asks_{};
    size_t bid_depth_{0};
    size_t ask_depth_{0};
    uint32_t symbol_id_{0};

public:
    explicit OrderBook(uint32_t symbol_id = 1) : symbol_id_(symbol_id) {}

    inline void add_bid(int64_t price, uint64_t qty) {
        for (size_t i = 0; i < bid_depth_; ++i) {
            if (bids_[i].price == price) {
                bids_[i].quantity += qty;
                bids_[i].order_count++;
                return;
            }
        }
        if (bid_depth_ < MAX_LEVELS) {
            bids_[bid_depth_] = {price, qty, 1};
            bid_depth_++;
            // Keep bids sorted descending
            std::sort(bids_.begin(), bids_.begin() + bid_depth_, [](const PriceLevel& a, const PriceLevel& b) {
                return a.price > b.price;
            });
        }
    }

    inline void add_ask(int64_t price, uint64_t qty) {
        for (size_t i = 0; i < ask_depth_; ++i) {
            if (asks_[i].price == price) {
                asks_[i].quantity += qty;
                asks_[i].order_count++;
                return;
            }
        }
        if (ask_depth_ < MAX_LEVELS) {
            asks_[ask_depth_] = {price, qty, 1};
            ask_depth_++;
            // Keep asks sorted ascending
            std::sort(asks_.begin(), asks_.begin() + ask_depth_, [](const PriceLevel& a, const PriceLevel& b) {
                return a.price < b.price;
            });
        }
    }

    inline MatchResult match_market_buy(uint64_t target_qty) {
        MatchResult res{};
        uint64_t remaining = target_qty;

        size_t i = 0;
        while (i < ask_depth_ && remaining > 0) {
            if (asks_[i].quantity <= remaining) {
                remaining -= asks_[i].quantity;
                res.matched_qty += asks_[i].quantity;
                res.execution_price = asks_[i].price;
                // Shift asks
                for (size_t j = i; j < ask_depth_ - 1; ++j) {
                    asks_[j] = asks_[j + 1];
                }
                ask_depth_--;
            } else {
                asks_[i].quantity -= remaining;
                res.matched_qty += remaining;
                res.execution_price = asks_[i].price;
                remaining = 0;
            }
        }
        res.fully_filled = (remaining == 0);
        return res;
    }

    inline int64_t get_best_bid() const {
        return bid_depth_ > 0 ? bids_[0].price : 0;
    }

    inline int64_t get_best_ask() const {
        return ask_depth_ > 0 ? asks_[0].price : 0;
    }

    inline size_t bid_depth() const { return bid_depth_; }
    inline size_t ask_depth() const { return ask_depth_; }
    inline const std::array<PriceLevel, MAX_LEVELS>& bids() const { return bids_; }
    inline const std::array<PriceLevel, MAX_LEVELS>& asks() const { return asks_; }
};

} // namespace ultralow

#endif // ULTRALOW_ORDER_BOOK_HPP
