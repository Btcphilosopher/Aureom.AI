#ifndef ULTRALOW_ANOMALY_DETECTOR_HPP
#define ULTRALOW_ANOMALY_DETECTOR_HPP

#include "rolling_stats.hpp"

namespace ultralow {

class AnomalyDetector {
private:
    RollingStats stats_;
    double z_threshold_{3.0};

public:
    explicit AnomalyDetector(double z_threshold = 3.0) : z_threshold_(z_threshold) {}

    inline bool inspect(double price, double volume, double& out_z_score) {
        if (stats_.count() < 10) {
            stats_.update(price, volume);
            out_z_score = 0.0;
            return false;
        }

        double std_dev = stats_.stdev();
        if (std_dev < 1e-9) {
            stats_.update(price, volume);
            out_z_score = 0.0;
            return false;
        }

        out_z_score = std::abs(price - stats_.mean()) / std_dev;
        bool is_anomaly = (out_z_score > z_threshold_);

        stats_.update(price, volume);
        return is_anomaly;
    }
};

} // namespace ultralow

#endif // ULTRALOW_ANOMALY_DETECTOR_HPP
