#ifndef ULTRALOW_ROLLING_STATS_HPP
#define ULTRALOW_ROLLING_STATS_HPP

#include <cstdint>
#include <cmath>

namespace ultralow {

/// Zero-allocation online Welford algorithm for microsecond rolling mean, variance & VWAP
class RollingStats {
private:
    uint64_t count_{0};
    double mean_{0.0};
    double M2_{0.0};
    double total_volume_{0.0};
    double price_volume_sum_{0.0};

public:
    inline void update(double price, double volume) {
        count_++;
        double delta = price - mean_;
        mean_ += delta / count_;
        double delta2 = price - mean_;
        M2_ += delta * delta2;

        total_volume_ += volume;
        price_volume_sum_ += price * volume;
    }

    inline double mean() const { return mean_; }
    inline double variance() const { return count_ > 1 ? M2_ / (count_ - 1) : 0.0; }
    inline double stdev() const { return std::sqrt(variance()); }
    inline double vwap() const { return total_volume_ > 0.0 ? price_volume_sum_ / total_volume_ : mean_; }
    inline uint64_t count() const { return count_; }

    inline void reset() {
        count_ = 0;
        mean_ = 0.0;
        M2_ = 0.0;
        total_volume_ = 0.0;
        price_volume_sum_ = 0.0;
    }
};

} // namespace ultralow

#endif // ULTRALOW_ROLLING_STATS_HPP
