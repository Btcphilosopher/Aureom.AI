#ifndef ULTRALOW_CPU_AFFINITY_HPP
#define ULTRALOW_CPU_AFFINITY_HPP

#include <pthread.h>
#include <sched.h>
#include <iostream>

namespace ultralow {

inline bool pin_current_thread_to_core(int core_id) {
#if defined(__linux__)
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(core_id, &cpuset);

    pthread_t current_thread = pthread_self();
    int rc = pthread_setaffinity_np(current_thread, sizeof(cpu_set_t), &cpuset);
    if (rc != 0) {
        std::cerr << "[Engine] Failed to pin thread to core " << core_id << "\n";
        return false;
    }
    return true;
#else
    (void)core_id;
    return false;
#endif
}

} // namespace ultralow

#endif // ULTRALOW_CPU_AFFINITY_HPP
