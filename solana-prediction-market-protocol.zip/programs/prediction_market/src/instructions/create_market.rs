use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Mint, Transfer, transfer};
use anchor_spl::associated_token::AssociatedToken;
use crate::state::{ProtocolConfig, Market, MarketStatus};
use crate::errors::PredictionMarketError;
use crate::events::MarketCreated;

#[derive(Accounts)]
#[instruction(
    title: String,
    outcome_yes: String,
    outcome_no: String,
    trading_deadline: i64,
    volume_threshold: u64,
    creator_bonus_amount: u64,
    oracle: Pubkey,
)]
pub struct CreateMarket<'info> {
    #[account(mut, seeds = [b"protocol-config"], bump)]
    pub config: Account<'info, ProtocolConfig>,

    #[account(
        init,
        payer = creator,
        space = Market::LEN,
        seeds = [b"market", config.market_count.to_le_bytes().as_ref()],
        bump
    )]
    pub market: Account<'info, Market>,

    pub token_mint: Account<'info, Mint>,

    #[account(
        init,
        payer = creator,
        associated_token::mint = token_mint,
        associated_token::authority = market,
    )]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub creator_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub creator: Signer<'info>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<CreateMarket>,
    title: String,
    outcome_yes: String,
    outcome_no: String,
    trading_deadline: i64,
    volume_threshold: u64,
    creator_bonus_amount: u64,
    oracle: Pubkey,
) -> Result<()> {
    let clock = Clock::get()?;
    require!(
        trading_deadline > clock.unix_timestamp,
        PredictionMarketError::TradingDeadlinePassed
    );

    let config = &mut ctx.accounts.config;
    let market = &mut ctx.accounts.market;

    market.creator = ctx.accounts.creator.key();
    market.oracle = oracle;
    market.token_mint = ctx.accounts.token_mint.key();
    market.vault = ctx.accounts.vault.key();
    market.id = config.market_count;
    market.status = MarketStatus::Created;
    market.final_outcome = None;
    market.reserve_yes = 0;
    market.reserve_no = 0;
    market.total_volume = 0;
    market.volume_threshold = volume_threshold;
    market.creator_bonus_amount = creator_bonus_amount;
    market.creator_bonus_unlocked = false;
    market.creator_bonus_claimed = false;
    market.trading_deadline = trading_deadline;
    market.bump = ctx.bumps.market;
    market.title = title.clone();
    market.outcome_yes = outcome_yes;
    market.outcome_no = outcome_no;

    // Increment market count in global config
    config.market_count = config.market_count.checked_add(1)
        .ok_or(PredictionMarketError::Overflow)?;

    // Escrow creator bonus amount if specified
    if creator_bonus_amount > 0 {
        let cpi_accounts = Transfer {
            from: ctx.accounts.creator_token_account.to_account_info(),
            to: ctx.accounts.vault.to_account_info(),
            authority: ctx.accounts.creator.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        transfer(cpi_ctx, creator_bonus_amount)?;
    }

    emit!(MarketCreated {
        market: market.key(),
        creator: market.creator,
        id: market.id,
        title,
        token_mint: market.token_mint,
        volume_threshold,
        creator_bonus_amount,
    });

    Ok(())
}
