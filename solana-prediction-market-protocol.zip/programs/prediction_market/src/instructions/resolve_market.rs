use anchor_lang::prelude::*;
use crate::state::{Market, MarketStatus};
use crate::errors::PredictionMarketError;
use crate::events::MarketResolved;

#[derive(Accounts)]
pub struct ResolveMarket<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(constraint = oracle.key() == market.oracle @ PredictionMarketError::Unauthorized)]
    pub oracle: Signer<'info>,
}

pub fn handler(
    ctx: Context<ResolveMarket>,
    winning_outcome: bool, // true = YES wins, false = NO wins
) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;

    require!(
        market.status != MarketStatus::Resolved,
        PredictionMarketError::MarketAlreadyResolved
    );

    // Update status and final outcome
    market.status = MarketStatus::Resolved;
    market.final_outcome = Some(winning_outcome);

    emit!(MarketResolved {
        market: market.key(),
        resolver: ctx.accounts.oracle.key(),
        winning_outcome,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}
