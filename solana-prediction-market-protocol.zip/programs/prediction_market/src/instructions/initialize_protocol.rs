use anchor_lang::prelude::*;
use crate::state::ProtocolConfig;

#[derive(Accounts)]
pub struct InitializeProtocol<'info> {
    #[account(
        init,
        payer = payer,
        space = ProtocolConfig::LEN,
        seeds = [b"protocol-config"],
        bump
    )]
    pub config: Account<'info, ProtocolConfig>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<InitializeProtocol>,
    admin: Pubkey,
    fee_receiver: Pubkey,
) -> Result<()> {
    let config = &mut ctx.accounts.config;
    config.admin = admin;
    config.fee_receiver = fee_receiver;
    config.market_count = 0;
    config.reserved = [0u8; 32];
    Ok(())
}
