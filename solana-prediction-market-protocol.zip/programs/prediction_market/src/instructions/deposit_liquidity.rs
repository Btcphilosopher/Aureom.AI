use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{Market, MarketStatus, LiquidityProvider};
use crate::errors::PredictionMarketError;
use crate::events::{LiquidityDeposited, MarketActivated};

#[derive(Accounts)]
pub struct DepositLiquidity<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(
        init,
        payer = provider,
        space = LiquidityProvider::LEN,
        seeds = [b"lp", market.key().as_ref(), provider.key().as_ref()],
        bump
    )]
    pub lp: Account<'info, LiquidityProvider>,

    #[account(mut, constraint = vault.key() == market.vault @ PredictionMarketError::InvalidVault)]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub provider_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub provider: Signer<'info>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<DepositLiquidity>,
    amount: u64,
) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;

    require!(
        market.status == MarketStatus::Created,
        PredictionMarketError::InvalidStateTransition
    );
    require!(
        amount > 0,
        PredictionMarketError::ZeroValueTransaction
    );
    require!(
        market.trading_deadline > clock.unix_timestamp,
        PredictionMarketError::TradingDeadlinePassed
    );

    // Transfer collateral to market vault
    let cpi_accounts = Transfer {
        from: ctx.accounts.provider_token_account.to_account_info(),
        to: ctx.accounts.vault.to_account_info(),
        authority: ctx.accounts.provider.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
    transfer(cpi_ctx, amount)?;

    // Record liquidity provider state
    let lp = &mut ctx.accounts.lp;
    lp.user = ctx.accounts.provider.key();
    lp.market = market.key();
    lp.collateral_amount = amount;
    lp.bump = ctx.bumps.lp;

    // Seed pool reserves and activate market
    market.reserve_yes = amount;
    market.reserve_no = amount;
    market.initial_liquidity_reserve = amount;
    market.status = MarketStatus::Active;

    emit!(LiquidityDeposited {
        market: market.key(),
        provider: lp.user,
        amount,
        reserve_yes: market.reserve_yes,
        reserve_no: market.reserve_no,
        timestamp: clock.unix_timestamp,
    });

    emit!(MarketActivated {
        market: market.key(),
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}
