use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{Market, MarketStatus, UserPosition, LiquidityProvider};
use crate::errors::PredictionMarketError;
use crate::events::PositionRedeemed;

#[derive(Accounts)]
pub struct Redeem<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(mut, seeds = [b"position", market.key().as_ref(), user.key().as_ref()], bump = position.bump)]
    pub position: Account<'info, UserPosition>,

    #[account(mut, constraint = vault.key() == market.vault @ PredictionMarketError::InvalidVault)]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub user: Signer<'info>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct RedeemLiquidity<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(mut, seeds = [b"lp", market.key().as_ref(), provider.key().as_ref()], bump = lp.bump)]
    pub lp: Account<'info, LiquidityProvider>,

    #[account(mut, constraint = vault.key() == market.vault @ PredictionMarketError::InvalidVault)]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub provider_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub provider: Signer<'info>,

    pub token_program: Program<'info, Token>,
}

pub fn redeem_handler(ctx: Context<Redeem>) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;
    let position = &mut ctx.accounts.position;

    require!(
        market.status == MarketStatus::Resolved,
        PredictionMarketError::MarketNotResolved
    );

    let winning_outcome = market.final_outcome
        .ok_or(PredictionMarketError::MarketNotResolved)?;

    // Determine winning shares
    let payout_amount = if winning_outcome {
        let amt = position.shares_yes;
        position.shares_yes = 0; // Prevent double redemption
        amt
    } else {
        let amt = position.shares_no;
        position.shares_no = 0; // Prevent double redemption
        amt
    };

    require!(
        payout_amount > 0,
        PredictionMarketError::NoSharesToRedeem
    );

    // Transfer collateral out of market vault
    let seeds = &[
        b"market",
        market.id.to_le_bytes().as_ref(),
        &[market.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let transfer_accounts = Transfer {
        from: ctx.accounts.vault.to_account_info(),
        to: ctx.accounts.user_token_account.to_account_info(),
        authority: market.to_account_info(),
    };
    let cpi_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.to_account_info(),
        transfer_accounts,
        signer_seeds
    );
    transfer(cpi_ctx, payout_amount)?;

    emit!(PositionRedeemed {
        market: market.key(),
        user: position.user,
        shares_redeemed: payout_amount,
        payout_amount,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

pub fn redeem_liquidity_handler(ctx: Context<RedeemLiquidity>) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;
    let lp = &mut ctx.accounts.lp;

    require!(
        market.status == MarketStatus::Resolved,
        PredictionMarketError::MarketNotResolved
    );
    require!(
        lp.collateral_amount > 0,
        PredictionMarketError::NoSharesToRedeem
    );

    let winning_outcome = market.final_outcome
        .ok_or(PredictionMarketError::MarketNotResolved)?;

    // Winning reserve of the pool
    let winning_reserve = if winning_outcome {
        market.reserve_yes
    } else {
        market.reserve_no
    };

    // Mathematically proportional LP payout:
    // payout = (lp_collateral * winning_reserve) / initial_liquidity_reserve
    let lp_payout = (lp.collateral_amount as u128)
        .checked_mul(winning_reserve as u128)
        .ok_or(PredictionMarketError::Overflow)?
        .checked_div(market.initial_liquidity_reserve as u128)
        .ok_or(PredictionMarketError::Overflow)? as u64;

    require!(
        lp_payout > 0,
        PredictionMarketError::NoSharesToRedeem
    );

    // Reset lp collateral to prevent double redemption
    lp.collateral_amount = 0;

    // Transfer collateral out of market vault to provider
    let seeds = &[
        b"market",
        market.id.to_le_bytes().as_ref(),
        &[market.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let transfer_accounts = Transfer {
        from: ctx.accounts.vault.to_account_info(),
        to: ctx.accounts.provider_token_account.to_account_info(),
        authority: market.to_account_info(),
    };
    let cpi_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.to_account_info(),
        transfer_accounts,
        signer_seeds
    );
    transfer(cpi_ctx, lp_payout)?;

    emit!(PositionRedeemed {
        market: market.key(),
        user: lp.user,
        shares_redeemed: lp_payout,
        payout_amount: lp_payout,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}
