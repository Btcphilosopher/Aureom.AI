use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{Market, MarketStatus};
use crate::errors::PredictionMarketError;
use crate::events::CreatorBonusClaimed;

#[derive(Accounts)]
pub struct ClaimCreatorBonus<'info> {
    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(mut, constraint = vault.key() == market.vault @ PredictionMarketError::InvalidVault)]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub creator_token_account: Account<'info, TokenAccount>,

    #[account(mut, constraint = creator.key() == market.creator @ PredictionMarketError::Unauthorized)]
    pub creator: Signer<'info>,

    pub token_program: Program<'info, Token>,
}

pub fn handler(ctx: Context<ClaimCreatorBonus>) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;

    require!(
        !market.creator_bonus_claimed,
        PredictionMarketError::CreatorBonusAlreadyClaimed
    );

    let is_bonus_claim = market.creator_bonus_unlocked;
    let is_refund_claim = market.status == MarketStatus::Resolved && !market.creator_bonus_unlocked;

    // Must be either a valid unlocked bonus claim OR a post-resolution refund claim
    require!(
        is_bonus_claim || is_refund_claim,
        PredictionMarketError::CreatorBonusNotUnlocked
    );

    let claim_amount = market.creator_bonus_amount;
    require!(
        claim_amount > 0,
        PredictionMarketError::ZeroValueTransaction
    );

    // Mark as claimed
    market.creator_bonus_claimed = true;

    // Transfer escrowed bonus/refund from market vault to creator's token account
    let seeds = &[
        b"market",
        market.id.to_le_bytes().as_ref(),
        &[market.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let transfer_accounts = Transfer {
        from: ctx.accounts.vault.to_account_info(),
        to: ctx.accounts.creator_token_account.to_account_info(),
        authority: market.to_account_info(),
    };
    let cpi_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.to_account_info(),
        transfer_accounts,
        signer_seeds
    );
    transfer(cpi_ctx, claim_amount)?;

    emit!(CreatorBonusClaimed {
        market: market.key(),
        creator: market.creator,
        bonus_amount: claim_amount,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}
