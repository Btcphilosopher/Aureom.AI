use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{ProtocolConfig, Market, MarketStatus, UserPosition};
use crate::errors::PredictionMarketError;
use crate::events::{SharePurchased, ShareSold, CreatorBonusUnlocked};

// Simple and fast Babylonian method for integer square root
pub fn integer_sqrt(val: u128) -> u128 {
    if val == 0 {
        return 0;
    }
    let mut temp = (val + 1) / 2;
    let mut result = val;
    while temp < result {
        result = temp;
        temp = (val / temp + temp) / 2;
    }
    result
}

#[derive(Accounts)]
pub struct BuyShares<'info> {
    #[account(mut, seeds = [b"protocol-config"], bump)]
    pub config: Account<'info, ProtocolConfig>,

    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(
        init_if_needed,
        payer = buyer,
        space = UserPosition::LEN,
        seeds = [b"position", market.key().as_ref(), buyer.key().as_ref()],
        bump
    )]
    pub position: Account<'info, UserPosition>,

    #[account(mut, constraint = vault.key() == market.vault @ PredictionMarketError::InvalidVault)]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub buyer_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub fee_receiver_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub buyer: Signer<'info>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SellShares<'info> {
    #[account(mut, seeds = [b"protocol-config"], bump)]
    pub config: Account<'info, ProtocolConfig>,

    #[account(mut)]
    pub market: Account<'info, Market>,

    #[account(mut, seeds = [b"position", market.key().as_ref(), seller.key().as_ref()], bump = position.bump)]
    pub position: Account<'info, UserPosition>,

    #[account(mut, constraint = vault.key() == market.vault @ PredictionMarketError::InvalidVault)]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub seller_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub fee_receiver_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub seller: Signer<'info>,

    pub token_program: Program<'info, Token>,
}

pub fn buy_shares_handler(
    ctx: Context<BuyShares>,
    is_yes: bool,
    collateral_amount: u64,
) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;

    require!(
        market.status == MarketStatus::Active,
        PredictionMarketError::MarketNotActive
    );
    require!(
        market.trading_deadline > clock.unix_timestamp,
        PredictionMarketError::TradingDeadlinePassed
    );
    require!(
        collateral_amount > 0,
        PredictionMarketError::ZeroValueTransaction
    );

    // Calculate trading fees: 1.0% fee
    let fee = collateral_amount.checked_div(100)
        .ok_or(PredictionMarketError::Overflow)?;
    let collateral_to_trade = collateral_amount.checked_sub(fee)
        .ok_or(PredictionMarketError::Overflow)?;

    // Split fee: 50% to protocol fee_receiver, 50% left in vault for creator reward
    let protocol_fee = fee.checked_div(2)
        .ok_or(PredictionMarketError::Overflow)?;

    // Transfer full collateral from buyer to market vault
    let transfer_to_vault_accounts = Transfer {
        from: ctx.accounts.buyer_token_account.to_account_info(),
        to: ctx.accounts.vault.to_account_info(),
        authority: ctx.accounts.buyer.to_account_info(),
    };
    let transfer_ctx = CpiContext::new(
        ctx.accounts.token_program.to_account_info(),
        transfer_to_vault_accounts
    );
    transfer(transfer_ctx, collateral_amount)?;

    // Transfer protocol fee from vault to protocol fee_receiver
    // Need market seeds to sign the transfer out of the vault
    let seeds = &[
        b"market",
        market.id.to_le_bytes().as_ref(),
        &[market.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    if protocol_fee > 0 {
        let transfer_fee_accounts = Transfer {
            from: ctx.accounts.vault.to_account_info(),
            to: ctx.accounts.fee_receiver_token_account.to_account_info(),
            authority: market.to_account_info(),
        };
        let fee_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            transfer_fee_accounts,
            signer_seeds
        );
        transfer(fee_ctx, protocol_fee)?;
    }

    // Pricing CPMM calculations:
    // Buy YES: R_no' = R_no + C_trade, R_yes' = K / R_no', received_shares = C_trade + (R_yes - R_yes')
    let r_yes_u128 = market.reserve_yes as u128;
    let r_no_u128 = market.reserve_no as u128;
    let k = r_yes_u128.checked_mul(r_no_u128)
        .ok_or(PredictionMarketError::Overflow)?;

    let shares_received: u64;
    let new_reserve_yes: u64;
    let new_reserve_no: u64;

    if is_yes {
        let new_no_u128 = r_no_u128.checked_add(collateral_to_trade as u128)
            .ok_or(PredictionMarketError::Overflow)?;
        let new_yes_u128 = k.checked_div(new_no_u128)
            .ok_or(PredictionMarketError::Overflow)?;
        
        let dy_pool = r_yes_u128.checked_sub(new_yes_u128)
            .ok_or(PredictionMarketError::Overflow)?;
        
        let total_received = (collateral_to_trade as u128)
            .checked_add(dy_pool)
            .ok_or(PredictionMarketError::Overflow)?;

        shares_received = total_received as u64;
        new_reserve_yes = new_yes_u128 as u64;
        new_reserve_no = new_no_u128 as u64;
    } else {
        let new_yes_u128 = r_yes_u128.checked_add(collateral_to_trade as u128)
            .ok_or(PredictionMarketError::Overflow)?;
        let new_no_u128 = k.checked_div(new_yes_u128)
            .ok_or(PredictionMarketError::Overflow)?;
        
        let dn_pool = r_no_u128.checked_sub(new_no_u128)
            .ok_or(PredictionMarketError::Overflow)?;
        
        let total_received = (collateral_to_trade as u128)
            .checked_add(dn_pool)
            .ok_or(PredictionMarketError::Overflow)?;

        shares_received = total_received as u64;
        new_reserve_yes = new_yes_u128 as u64;
        new_reserve_no = new_no_u128 as u64;
    }

    // Ensure the pool has sufficient reserves
    require!(
        new_reserve_yes > 0 && new_reserve_no > 0,
        PredictionMarketError::InsufficientLiquidity
    );

    // Update pool reserves
    market.reserve_yes = new_reserve_yes;
    market.reserve_no = new_reserve_no;

    // Update user position
    let position = &mut ctx.accounts.position;
    position.user = ctx.accounts.buyer.key();
    position.market = market.key();
    position.bump = ctx.bumps.position;

    if is_yes {
        position.shares_yes = position.shares_yes.checked_add(shares_received)
            .ok_or(PredictionMarketError::Overflow)?;
    } else {
        position.shares_no = position.shares_no.checked_add(shares_received)
            .ok_or(PredictionMarketError::Overflow)?;
    }

    // Cumulative volume and creator bonus checks
    market.total_volume = market.total_volume.checked_add(collateral_amount)
        .ok_or(PredictionMarketError::Overflow)?;

    if market.total_volume >= market.volume_threshold && !market.creator_bonus_unlocked {
        market.creator_bonus_unlocked = true;
        emit!(CreatorBonusUnlocked {
            market: market.key(),
            creator: market.creator,
            current_volume: market.total_volume,
            threshold: market.volume_threshold,
            timestamp: clock.unix_timestamp,
        });
    }

    emit!(SharePurchased {
        market: market.key(),
        buyer: position.user,
        is_yes,
        collateral_spent: collateral_amount,
        shares_received,
        fee_collected: fee,
        new_reserve_yes,
        new_reserve_no,
        cumulative_volume: market.total_volume,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

pub fn sell_shares_handler(
    ctx: Context<SellShares>,
    is_yes: bool,
    shares_to_sell: u64,
) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;
    let position = &mut ctx.accounts.position;

    require!(
        market.status == MarketStatus::Active,
        PredictionMarketError::MarketNotActive
    );
    require!(
        market.trading_deadline > clock.unix_timestamp,
        PredictionMarketError::TradingDeadlinePassed
    );
    require!(
        shares_to_sell > 0,
        PredictionMarketError::ZeroValueTransaction
    );

    if is_yes {
        require!(
            position.shares_yes >= shares_to_sell,
            PredictionMarketError::InsufficientLiquidity
        );
    } else {
        require!(
            position.shares_no >= shares_to_sell,
            PredictionMarketError::InsufficientLiquidity
        );
    }

    // Quadratic Pricing formula for Selling YES/NO shares:
    // b = R_yes + R_no + S
    // c = S * R_counter
    // C = (b - sqrt(b^2 - 4c)) / 2
    let r_yes_u128 = market.reserve_yes as u128;
    let r_no_u128 = market.reserve_no as u128;
    let s_u128 = shares_to_sell as u128;

    let b = r_yes_u128.checked_add(r_no_u128)
        .ok_or(PredictionMarketError::Overflow)?
        .checked_add(s_u128)
        .ok_or(PredictionMarketError::Overflow)?;

    let r_counter = if is_yes { r_no_u128 } else { r_yes_u128 };
    let c = s_u128.checked_mul(r_counter)
        .ok_or(PredictionMarketError::Overflow)?;

    let b_squared = b.checked_mul(b)
        .ok_or(PredictionMarketError::Overflow)?;
    let four_c = c.checked_mul(4)
        .ok_or(PredictionMarketError::Overflow)?;

    require!(b_squared >= four_c, PredictionMarketError::Overflow);
    let sqrt_term = integer_sqrt(b_squared - four_c);

    let gross_collateral = b.checked_sub(sqrt_term)
        .ok_or(PredictionMarketError::Overflow)?
        .checked_div(2)
        .ok_or(PredictionMarketError::Overflow)? as u64;

    require!(gross_collateral > 0, PredictionMarketError::ZeroValueTransaction);

    // Calculate fees: 1% fee on gross collateral
    let fee = gross_collateral.checked_div(100)
        .ok_or(PredictionMarketError::Overflow)?;
    let net_collateral_to_return = gross_collateral.checked_sub(fee)
        .ok_or(PredictionMarketError::Overflow)?;

    let protocol_fee = fee.checked_div(2)
        .ok_or(PredictionMarketError::Overflow)?;

    // Update reserves
    let new_reserve_yes: u64;
    let new_reserve_no: u64;

    if is_yes {
        // Pool gets YES shares back, but releases collateral (represented as withdrawing from both reserves)
        new_reserve_yes = (r_yes_u128 + s_u128 - gross_collateral as u128) as u64;
        new_reserve_no = (r_no_u128 - gross_collateral as u128) as u64;
    } else {
        new_reserve_yes = (r_yes_u128 - gross_collateral as u128) as u64;
        new_reserve_no = (r_no_u128 + s_u128 - gross_collateral as u128) as u64;
    }

    require!(
        new_reserve_yes > 0 && new_reserve_no > 0,
        PredictionMarketError::InsufficientLiquidity
    );

    market.reserve_yes = new_reserve_yes;
    market.reserve_no = new_reserve_no;

    // Deduct user shares
    if is_yes {
        position.shares_yes = position.shares_yes.checked_sub(shares_to_sell)
            .ok_or(PredictionMarketError::Overflow)?;
    } else {
        position.shares_no = position.shares_no.checked_sub(shares_to_sell)
            .ok_or(PredictionMarketError::Overflow)?;
    }

    // Execute CPI transfers
    let seeds = &[
        b"market",
        market.id.to_le_bytes().as_ref(),
        &[market.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    // 1. Transfer net collateral to user
    let transfer_user_accounts = Transfer {
        from: ctx.accounts.vault.to_account_info(),
        to: ctx.accounts.seller_token_account.to_account_info(),
        authority: market.to_account_info(),
    };
    let user_transfer_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.to_account_info(),
        transfer_user_accounts,
        signer_seeds
    );
    transfer(user_transfer_ctx, net_collateral_to_return)?;

    // 2. Transfer protocol fee to fee_receiver
    if protocol_fee > 0 {
        let transfer_fee_accounts = Transfer {
            from: ctx.accounts.vault.to_account_info(),
            to: ctx.accounts.fee_receiver_token_account.to_account_info(),
            authority: market.to_account_info(),
        };
        let fee_transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            transfer_fee_accounts,
            signer_seeds
        );
        transfer(fee_transfer_ctx, protocol_fee)?;
    }

    // Accumulate volume
    market.total_volume = market.total_volume.checked_add(gross_collateral)
        .ok_or(PredictionMarketError::Overflow)?;

    if market.total_volume >= market.volume_threshold && !market.creator_bonus_unlocked {
        market.creator_bonus_unlocked = true;
        emit!(CreatorBonusUnlocked {
            market: market.key(),
            creator: market.creator,
            current_volume: market.total_volume,
            threshold: market.volume_threshold,
            timestamp: clock.unix_timestamp,
        });
    }

    emit!(ShareSold {
        market: market.key(),
        seller: position.user,
        is_yes,
        shares_sold: shares_to_sell,
        collateral_received: net_collateral_to_return,
        fee_collected: fee,
        new_reserve_yes,
        new_reserve_no,
        cumulative_volume: market.total_volume,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}
