use anchor_lang::prelude::*;

#[event]
pub struct MarketCreated {
    pub market: Pubkey,
    pub creator: Pubkey,
    pub id: u64,
    pub title: String,
    pub token_mint: Pubkey,
    pub volume_threshold: u64,
    pub creator_bonus_amount: u64,
}

#[event]
pub struct MarketActivated {
    pub market: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct LiquidityDeposited {
    pub market: Pubkey,
    pub provider: Pubkey,
    pub amount: u64,
    pub reserve_yes: u64,
    pub reserve_no: u64,
    pub timestamp: i64,
}

#[event]
pub struct SharePurchased {
    pub market: Pubkey,
    pub buyer: Pubkey,
    pub is_yes: bool,
    pub collateral_spent: u64,
    pub shares_received: u64,
    pub fee_collected: u64,
    pub new_reserve_yes: u64,
    pub new_reserve_no: u64,
    pub cumulative_volume: u64,
    pub timestamp: i64,
}

#[event]
pub struct ShareSold {
    pub market: Pubkey,
    pub seller: Pubkey,
    pub is_yes: bool,
    pub shares_sold: u64,
    pub collateral_received: u64,
    pub fee_collected: u64,
    pub new_reserve_yes: u64,
    pub new_reserve_no: u64,
    pub cumulative_volume: u64,
    pub timestamp: i64,
}

#[event]
pub struct MarketTradingClosed {
    pub market: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct MarketResolved {
    pub market: Pubkey,
    pub resolver: Pubkey,
    pub winning_outcome: bool, // true = YES, false = NO
    pub timestamp: i64,
}

#[event]
pub struct PositionRedeemed {
    pub market: Pubkey,
    pub user: Pubkey,
    pub shares_redeemed: u64,
    pub payout_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct CreatorBonusUnlocked {
    pub market: Pubkey,
    pub creator: Pubkey,
    pub current_volume: u64,
    pub threshold: u64,
    pub timestamp: i64,
}

#[event]
pub struct CreatorBonusClaimed {
    pub market: Pubkey,
    pub creator: Pubkey,
    pub bonus_amount: u64,
    pub timestamp: i64,
}
