use anchor_lang::prelude::*;

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq)]
pub enum MarketStatus {
    Created,
    Active,
    TradingClosed,
    Resolved,
}

#[account]
pub struct ProtocolConfig {
    pub admin: Pubkey,
    pub fee_receiver: Pubkey,
    pub market_count: u64,
    pub reserved: [u8; 32],
}

impl ProtocolConfig {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 32;
}

#[account]
pub struct Market {
    pub creator: Pubkey,
    pub oracle: Pubkey,
    pub token_mint: Pubkey,
    pub vault: Pubkey,
    pub id: u64,
    pub status: MarketStatus,
    pub final_outcome: Option<bool>, // Some(true) = YES wins, Some(false) = NO wins
    pub reserve_yes: u64,
    pub reserve_no: u64,
    pub initial_liquidity_reserve: u64,
    pub total_volume: u64,
    pub volume_threshold: u64,
    pub creator_bonus_amount: u64,
    pub creator_bonus_unlocked: bool,
    pub creator_bonus_claimed: bool,
    pub trading_deadline: i64,
    pub bump: u8,
    pub title: String,
    pub outcome_yes: String,
    pub outcome_no: String,
}

impl Market {
    // 8 + 32*4 + 8 + 1 + 2 + 8*5 + 1 + 1 + 8 + 1 + (4+128) + (4+32) + (4+32) + 64 (buffer)
    pub const LEN: usize = 8 + 128 + 8 + 1 + 2 + 40 + 1 + 1 + 8 + 1 + 132 + 36 + 36 + 64;
}

#[account]
pub struct UserPosition {
    pub user: Pubkey,
    pub market: Pubkey,
    pub shares_yes: u64,
    pub shares_no: u64,
    pub bump: u8,
}

impl UserPosition {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 8 + 1;
}

#[account]
pub struct LiquidityProvider {
    pub user: Pubkey,
    pub market: Pubkey,
    pub collateral_amount: u64,
    pub bump: u8,
}

impl LiquidityProvider {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 1;
}
