use anchor_lang::prelude::*;

pub mod errors;
pub mod events;
pub mod state;
pub mod instructions;

use instructions::*;

declare_id!("PMkt111111111111111111111111111111111111111");

#[program]
pub mod prediction_market {
    use super::*;

    /// Initializes the global protocol configuration, defining administrative roles and fee settings.
    pub fn initialize_protocol(
        ctx: Context<InitializeProtocol>,
        admin: Pubkey,
        fee_receiver: Pubkey,
    ) -> Result<()> {
        instructions::initialize_protocol::handler(ctx, admin, fee_receiver)
    }

    /// Creates a new binary outcome prediction market.
    /// If creator_bonus_amount > 0, the creator must escrow this amount of collateral to back the bonus pool.
    pub fn create_market(
        ctx: Context<CreateMarket>,
        title: String,
        outcome_yes: String,
        outcome_no: String,
        trading_deadline: i64,
        volume_threshold: u64,
        creator_bonus_amount: u64,
        oracle: Pubkey,
    ) -> Result<()> {
        instructions::create_market::handler(
            ctx,
            title,
            outcome_yes,
            outcome_no,
            trading_deadline,
            volume_threshold,
            creator_bonus_amount,
            oracle,
        )
    }

    /// Seeds initial liquidity into the market reserves, setting reserve_yes = amount and reserve_no = amount.
    /// This advances the market lifecycle status from Created to Active.
    pub fn deposit_liquidity(
        ctx: Context<DepositLiquidity>,
        amount: u64,
    ) -> Result<()> {
        instructions::deposit_liquidity::handler(ctx, amount)
    }

    /// Purchases YES or NO shares from the AMM pool.
    /// Charges a 1.0% trade fee: 0.5% immediately routed to protocol fee_receiver, 0.5% retained in pool.
    pub fn buy_shares(
        ctx: Context<BuyShares>,
        is_yes: bool,
        collateral_amount: u64,
    ) -> Result<()> {
        instructions::trade::buy_shares_handler(ctx, is_yes, collateral_amount)
    }

    /// Sells YES or NO shares back to the AMM pool using the quadratic pricing model.
    /// Charges a 1.0% fee on returned collateral.
    pub fn sell_shares(
        ctx: Context<SellShares>,
        is_yes: bool,
        shares_to_sell: u64,
    ) -> Result<()> {
        instructions::trade::sell_shares_handler(ctx, is_yes, shares_to_sell)
    }

    /// Resolves the market, transitioning status to Resolved and setting the final winning outcome.
    /// Restricted strictly to the configured oracle signer.
    pub fn resolve_market(
        ctx: Context<ResolveMarket>,
        winning_outcome: bool,
    ) -> Result<()> {
        instructions::resolve_market::handler(ctx, winning_outcome)
    }

    /// Redeems a trader's winning shares (YES or NO) 1-to-1 for collateral.
    pub fn redeem(ctx: Context<Redeem>) -> Result<()> {
        instructions::redeem::redeem_handler(ctx)
    }

    /// Redeems a liquidity provider's share of the remaining winning collateral in the pool.
    pub fn redeem_liquidity(ctx: Context<RedeemLiquidity>) -> Result<()> {
        instructions::redeem::redeem_liquidity_handler(ctx)
    }

    /// Claims the escrowed creator bonus if the volume threshold was successfully crossed,
    /// or refunds the bonus back to the creator if the market resolved without crossing the threshold.
    pub fn claim_creator_bonus(ctx: Context<ClaimCreatorBonus>) -> Result<()> {
        instructions::claim_creator_bonus::handler(ctx)
    }
}
