use anchor_lang::prelude::*;

#[error_code]
pub enum PredictionMarketError {
    #[msg("You are not authorized to perform this operation.")]
    Unauthorized,

    #[msg("The market is not in the Active state.")]
    MarketNotActive,

    #[msg("The market trading deadline has passed.")]
    TradingDeadlinePassed,

    #[msg("The provided resolution outcome is invalid.")]
    InvalidOutcome,

    #[msg("This market has already been resolved.")]
    MarketAlreadyResolved,

    #[msg("The market must be resolved before redeeming winnings.")]
    MarketNotResolved,

    #[msg("Your position did not win. Losing positions cannot be redeemed.")]
    LosingPosition,

    #[msg("You have no winning shares to redeem.")]
    NoSharesToRedeem,

    #[msg("The requested state transition is invalid.")]
    InvalidStateTransition,

    #[msg("A mathematical overflow or underflow occurred.")]
    Overflow,

    #[msg("The market pool currently has zero liquidity.")]
    ZeroLiquidity,

    #[msg("The pool does not have sufficient liquidity for this trade size.")]
    InsufficientLiquidity,

    #[msg("The creator volume threshold has not been reached yet.")]
    CreatorBonusNotUnlocked,

    #[msg("The creator bonus has already been claimed for this market.")]
    CreatorBonusAlreadyClaimed,

    #[msg("The provided token mint is invalid for this market.")]
    InvalidTokenMint,

    #[msg("The provided token vault PDA is invalid.")]
    InvalidVault,

    #[msg("The transaction amount must be greater than zero.")]
    ZeroValueTransaction,

    #[msg("Proportional liquidity deposit is required when pool is already active.")]
    ProportionalLiquidityRequired,

    #[msg("Liquidity can only be seeded once when the market is in Created state.")]
    MarketAlreadySeeded,
}
