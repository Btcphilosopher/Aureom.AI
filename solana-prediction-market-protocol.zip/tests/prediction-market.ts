import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { assert, expect } from "chai";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  createMint,
  createAccount,
  mintTo,
  getAccount,
} from "@solana/spl-token";

describe("Solana Binary Prediction Market", () => {
  // Configure the client to use the local cluster or devnet.
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  // The program to test
  const program = anchor.workspace.PredictionMarket as Program<any>;

  // Keypairs
  const admin = Keypair.generate();
  const oracle = Keypair.generate();
  const creator = Keypair.generate();
  const lpProvider = Keypair.generate();
  const trader1 = Keypair.generate();
  const trader2 = Keypair.generate();

  // Mints & Token Accounts
  let collateralMint: PublicKey;
  let creatorTokenAccount: PublicKey;
  let lpTokenAccount: PublicKey;
  let trader1TokenAccount: PublicKey;
  let trader2TokenAccount: PublicKey;
  let feeReceiverTokenAccount: PublicKey;

  // PDAs
  let protocolConfigPda: PublicKey;
  let marketPda: PublicKey;
  let vaultPda: PublicKey;
  let lpPda: PublicKey;
  let position1Pda: PublicKey;
  let position2Pda: PublicKey;

  // Test parameters
  const marketId = new anchor.BN(0);
  const volumeThreshold = new anchor.BN(100_000_000); // 100 USDC volume threshold
  const creatorBonusAmount = new anchor.BN(10_000_000); // 10 USDC escrowed bonus
  const tradingDeadline = new anchor.BN(Math.floor(Date.now() / 1000) + 1000); // 1000s in the future

  before(async () => {
    // 1. Airdrop SOL to signers
    const signers = [creator, lpProvider, trader1, trader2, admin, oracle];
    for (const signer of signers) {
      const signature = await provider.connection.requestAirdrop(
        signer.publicKey,
        2 * LAMPORTS_PER_SOL
      );
      await provider.connection.confirmTransaction(signature);
    }

    // 2. Create USDC Mock Collateral Mint
    collateralMint = await createMint(
      provider.connection,
      creator, // payer
      creator.publicKey, // mint authority
      null, // freeze authority
      6 // 6 decimals for USDC
    );

    // 3. Create Token Accounts
    creatorTokenAccount = await createAccount(
      provider.connection,
      creator,
      collateralMint,
      creator.publicKey
    );

    lpTokenAccount = await createAccount(
      provider.connection,
      lpProvider,
      collateralMint,
      lpProvider.publicKey
    );

    trader1TokenAccount = await createAccount(
      provider.connection,
      trader1,
      collateralMint,
      trader1.publicKey
    );

    trader2TokenAccount = await createAccount(
      provider.connection,
      trader2,
      collateralMint,
      trader2.publicKey
    );

    feeReceiverTokenAccount = await createAccount(
      provider.connection,
      admin,
      collateralMint,
      admin.publicKey
    );

    // 4. Mint tokens to users
    await mintTo(
      provider.connection,
      creator,
      collateralMint,
      creatorTokenAccount,
      creator,
      200_000_000 // 200 USDC
    );

    await mintTo(
      provider.connection,
      creator,
      collateralMint,
      lpTokenAccount,
      creator,
      500_000_000 // 500 USDC
    );

    await mintTo(
      provider.connection,
      creator,
      collateralMint,
      trader1TokenAccount,
      creator,
      100_000_000 // 100 USDC
    );

    await mintTo(
      provider.connection,
      creator,
      collateralMint,
      trader2TokenAccount,
      creator,
      100_000_000 // 100 USDC
    );

    // 5. Derive PDAs
    [protocolConfigPda] = PublicKey.findProgramAddressSync(
      [Buffer.from("protocol-config")],
      program.programId
    );

    [marketPda] = PublicKey.findProgramAddressSync(
      [Buffer.from("market"), marketId.toArrayLike(Buffer, "le", 8)],
      program.programId
    );

    // Derive Associated Token Vault for market
    // In our Anchor program: AssociatedToken PDA with authority = market
    const [associatedVault] = PublicKey.findProgramAddressSync(
      [
        marketPda.toBuffer(),
        TOKEN_PROGRAM_ID.toBuffer(),
        collateralMint.toBuffer(),
      ],
      new PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL") // Associated Token Program ID
    );
    vaultPda = associatedVault;

    [lpPda] = PublicKey.findProgramAddressSync(
      [Buffer.from("lp"), marketPda.toBuffer(), lpProvider.publicKey.toBuffer()],
      program.programId
    );

    [position1Pda] = PublicKey.findProgramAddressSync(
      [Buffer.from("position"), marketPda.toBuffer(), trader1.publicKey.toBuffer()],
      program.programId
    );

    [position2Pda] = PublicKey.findProgramAddressSync(
      [Buffer.from("position"), marketPda.toBuffer(), trader2.publicKey.toBuffer()],
      program.programId
    );
  });

  it("Initializes the Protocol", async () => {
    await program.methods
      .initializeProtocol(admin.publicKey, admin.publicKey)
      .accounts({
        config: protocolConfigPda,
        payer: creator.publicKey,
        systemProgram: SystemProgram.programId,
      })
      .signers([creator])
      .rpc();

    const config = await program.account.protocolConfig.fetch(protocolConfigPda);
    expect(config.admin.toBase58()).to.equal(admin.publicKey.toBase58());
    expect(config.marketCount.toNumber()).to.equal(0);
  });

  it("Creates a Prediction Market with Escrowed Bonus", async () => {
    await program.methods
      .createMarket(
        "Will Solana reach $500 in 2026?",
        "YES",
        "NO",
        tradingDeadline,
        volumeThreshold,
        creatorBonusAmount,
        oracle.publicKey
      )
      .accounts({
        config: protocolConfigPda,
        market: marketPda,
        tokenMint: collateralMint,
        vault: vaultPda,
        creatorTokenAccount: creatorTokenAccount,
        creator: creator.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: new PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"),
        systemProgram: SystemProgram.programId,
      })
      .signers([creator])
      .rpc();

    const market = await program.account.market.fetch(marketPda);
    expect(market.title).to.equal("Will Solana reach $500 in 2026?");
    expect(market.oracle.toBase58()).to.equal(oracle.publicKey.toBase58());
    expect(market.creatorBonusAmount.toNumber()).to.equal(creatorBonusAmount.toNumber());
    expect(market.creatorBonusUnlocked).to.be.false;

    // Verify creator bonus escrow transfer occurred
    const vaultTokenAccount = await getAccount(provider.connection, vaultPda);
    expect(Number(vaultTokenAccount.amount)).to.equal(creatorBonusAmount.toNumber());
  });

  it("Seeds Liquidity & Activates Market (Created -> Active)", async () => {
    const seedAmount = new anchor.BN(200_000_000); // 200 USDC seed

    await program.methods
      .depositLiquidity(seedAmount)
      .accounts({
        market: marketPda,
        lp: lpPda,
        vault: vaultPda,
        providerTokenAccount: lpTokenAccount,
        provider: lpProvider.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([lpProvider])
      .rpc();

    const market = await program.account.market.fetch(marketPda);
    // Market status enum should map to Active (1)
    expect(market.status).to.have.property("active");
    expect(market.reserveYes.toNumber()).to.equal(seedAmount.toNumber());
    expect(market.reserveNo.toNumber()).to.equal(seedAmount.toNumber());
    expect(market.initialLiquidityReserve.toNumber()).to.equal(seedAmount.toNumber());

    const lpAccount = await program.account.liquidityProvider.fetch(lpPda);
    expect(lpAccount.collateralAmount.toNumber()).to.equal(seedAmount.toNumber());
  });

  it("Trader 1 Buys YES shares", async () => {
    const buyAmount = new anchor.BN(50_000_000); // 50 USDC buy
    // Expected fee = 0.5 USDC (1%), 0.25 USDC immediately routed to feeReceiver, 0.25 USDC kept in vault

    await program.methods
      .buyShares(true, buyAmount)
      .accounts({
        config: protocolConfigPda,
        market: marketPda,
        position: position1Pda,
        vault: vaultPda,
        buyerTokenAccount: trader1TokenAccount,
        feeReceiverTokenAccount: feeReceiverTokenAccount,
        buyer: trader1.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([trader1])
      .rpc();

    const position = await program.account.userPosition.fetch(position1Pda);
    expect(position.sharesYes.toNumber()).to.be.greaterThan(0);
    expect(position.sharesNo.toNumber()).to.equal(0);

    const market = await program.account.market.fetch(marketPda);
    expect(market.totalVolume.toNumber()).to.equal(buyAmount.toNumber());
  });

  it("Trader 2 Buys NO shares, crossing the volume threshold", async () => {
    const buyAmount = new anchor.BN(60_000_000); // 60 USDC buy (total cumulative volume = 110 USDC > 100 USDC threshold)

    await program.methods
      .buyShares(false, buyAmount)
      .accounts({
        config: protocolConfigPda,
        market: marketPda,
        position: position2Pda,
        vault: vaultPda,
        buyerTokenAccount: trader2TokenAccount,
        feeReceiverTokenAccount: feeReceiverTokenAccount,
        buyer: trader2.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([trader2])
      .rpc();

    const market = await program.account.market.fetch(marketPda);
    expect(market.totalVolume.toNumber()).to.equal(110_000_000);
    expect(market.creatorBonusUnlocked).to.be.true; // Threshold crossed!
  });

  it("Claims the Unlocked Creator Bonus", async () => {
    await program.methods
      .claimCreatorBonus()
      .accounts({
        market: marketPda,
        vault: vaultPda,
        creatorTokenAccount: creatorTokenAccount,
        creator: creator.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .signers([creator])
      .rpc();

    const market = await program.account.market.fetch(marketPda);
    expect(market.creatorBonusClaimed).to.be.true;
  });

  it("Resolves the Market through Oracle Signer (YES Wins)", async () => {
    await program.methods
      .resolveMarket(true) // YES wins!
      .accounts({
        market: marketPda,
        oracle: oracle.publicKey,
      })
      .signers([oracle])
      .rpc();

    const market = await program.account.market.fetch(marketPda);
    expect(market.status).to.have.property("resolved");
    expect(market.finalOutcome).to.be.true;
  });

  it("Trader 1 Redeems YES Winnings", async () => {
    const beforeBalance = await getAccount(provider.connection, trader1TokenAccount);

    await program.methods
      .redeem()
      .accounts({
        market: marketPda,
        position: position1Pda,
        vault: vaultPda,
        userTokenAccount: trader1TokenAccount,
        user: trader1.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .signers([trader1])
      .rpc();

    const afterBalance = await getAccount(provider.connection, trader1TokenAccount);
    expect(Number(afterBalance.amount)).to.be.greaterThan(Number(beforeBalance.amount));

    const position = await program.account.userPosition.fetch(position1Pda);
    expect(position.sharesYes.toNumber()).to.equal(0); // Set to 0 after claim
  });

  it("Trader 2 Fails to Redeem Losing Position (NO)", async () => {
    try {
      await program.methods
        .redeem()
        .accounts({
          market: marketPda,
          position: position2Pda,
          vault: vaultPda,
          userTokenAccount: trader2TokenAccount,
          user: trader2.publicKey,
          tokenProgram: TOKEN_PROGRAM_ID,
        })
        .signers([trader2])
        .rpc();
      assert.fail("Should have failed to redeem a losing position");
    } catch (err: any) {
      expect(err.message).to.contain("NoSharesToRedeem");
    }
  });
});
