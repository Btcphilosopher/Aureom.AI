#!/bin/bash

# Exit on any error
set -e

echo "===================================================================="
echo "      ⚠️  SOLANA PREDICTION MARKET: MAINNET DEPLOYMENT ENGINE  ⚠️  "
echo "===================================================================="
echo ""
echo "This script contains strict safety gates. Do NOT run this unless you are"
echo "fully authorized and prepared to deploy production funds to Solana Mainnet-Beta."
echo ""

# Helper function to prompt for safety checks
confirm_step() {
    read -p "❓ $1 (y/N): " response
    if [[ ! "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        echo "❌ Deployment halted. Failed safety gate."
        exit 1
    fi
}

# Gate 1: Build Verification
echo "🛡️  GATE 1/7: Build Verification"
confirm_step "Did the clean build 'anchor build' compile successfully with zero warnings?"

# Gate 2: Test Suite Verification
echo "🛡️  GATE 2/7: Test Suite Verification"
confirm_step "Did you run the complete test suite on Localnet/Devnet, and did all tests pass successfully?"

# Gate 3: Independent Security Audit
echo "🛡️  GATE 3/7: Independent Security Audit Verification"
confirm_step "Has the smart contract code been audited by an independent Solana security agency and all critical issues resolved?"

# Gate 4: Devnet Acceptance Criteria
echo "🛡️  GATE 4/7: Devnet Acceptance Criteria"
confirm_step "Has the client interface successfully completed the visual acceptance tests on Solana Devnet?"

# Gate 5: Configuration Double-Check
echo "🛡️  GATE 5/7: Mainnet Configuration Checks"
confirm_step "Have you verified that the protocol admin and fee receiver addresses in Anchor.toml/environment match final Mainnet keys?"

# Gate 6: Upgrade Authority Secure Setup
echo "🛡️  GATE 6/7: Upgrade Authority Setup"
confirm_step "Is the Program Upgrade Authority owned by a multisig (such as a Squads Multisig or Ledger cold storage wallet) instead of a hot wallet?"

# Gate 7: Final Execution Agreement
echo "🛡️  GATE 7/7: Final Execution Agreement"
confirm_step "YOU ARE ABOUT TO DEPLOY TO SOLANA MAINNET. Are you absolutely certain you want to proceed?"

# Check Solana CLI is on mainnet
CURRENT_CLUSTER=$(solana config get | grep "RPC URL" || true)
echo "Current CLI Network: $CURRENT_CLUSTER"

read -p "Type 'CONFIRM-DEPLOY-MAINNET' to execute the deploy command: " confirm_text
if [ "$confirm_text" != "CONFIRM-DEPLOY-MAINNET" ]; then
    echo "❌ Input mismatch. Mainnet deployment aborted."
    exit 1
fi

echo "🚀 Deploying to Solana Mainnet-Beta..."
anchor deploy --provider.cluster mainnet

echo "===================================================================="
echo "🎉 DEPLOYMENT COMPLETE TO MAINNET-BETA!"
echo "Please verify and publish your source code on Solana FM or Solana Explorer."
echo "===================================================================="
