#!/bin/bash

# Exit on any error
set -e

echo "===================================================================="
echo "          SOLANA PREDICTION MARKET: DEVNET DEPLOYMENT ENGINE        "
echo "===================================================================="

# Step 1: Ensure anchor CLI is installed
if ! command -v anchor &> /dev/null
then
    echo "❌ Error: anchor-cli is not installed."
    echo "Please install it by running: cargo install --git https://github.com/coral-xyz/anchor anchor-cli --locked"
    exit 1
fi

# Step 2: Ensure solana CLI is installed
if ! command -v solana &> /dev/null
then
    echo "❌ Error: solana-cli is not installed."
    echo "Please install from: https://docs.solana.com/cli/install-solana-cli-tools"
    exit 1
fi

echo "✔ Found Anchor and Solana CLI. Continuing..."

# Step 3: Configure solana for Devnet
echo "⚙ Setting Solana CLI configuration to devnet..."
solana config set --url https://api.devnet.solana.com

# Step 4: Check if local wallet exists, generate if missing
WALLET_PATH="$HOME/.config/solana/id.json"
if [ ! -f "$WALLET_PATH" ]; then
    echo "⚠️ Wallet not found at $WALLET_PATH. Generating a new keypair..."
    mkdir -p "$HOME/.config/solana"
    solana-keygen new --no-bip39-passphrase -o "$WALLET_PATH"
fi
echo "✔ Using wallet: $(solana address)"

# Step 5: Request Airdrop on Devnet
echo "💧 Requesting Devnet SOL airdrop..."
solana airdrop 2 || echo "⚠️ Airdrop rate limit hit. If deployment fails, please fund $(solana address) manually."

# Step 6: Build the Anchor Program
echo "🔨 Building prediction market program..."
anchor build

# Step 7: Retrieve Program ID from Keypair
PROGRAM_ID_FILE="./target/deploy/prediction_market-keypair.json"
if [ -f "$PROGRAM_ID_FILE" ]; then
    PROGRAM_ID=$(solana address -k "$PROGRAM_ID_FILE")
    echo "✔ Derived Program ID from build keypair: $PROGRAM_ID"
else
    PROGRAM_ID="PMkt111111111111111111111111111111111111111"
    echo "⚠️ Deploy keypair not found. Defaulting to: $PROGRAM_ID"
fi

# Step 8: Deploy the program
echo "🚀 Deploying to Devnet..."
anchor deploy --provider.cluster devnet

echo "===================================================================="
echo "🎯 DEPLOYMENT SUCCESSFUL!"
echo "Program ID: $PROGRAM_ID"
echo "Check your program on Solana Explorer:"
echo "https://explorer.solana.com/address/$PROGRAM_ID?cluster=devnet"
echo "===================================================================="
