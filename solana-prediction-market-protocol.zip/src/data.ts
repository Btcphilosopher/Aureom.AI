import { MarketState, SimulatedWallet, WalletPositions } from "./types";

export const INITIAL_WALLETS: SimulatedWallet[] = [
  {
    publicKey: "Phan7vWfA3oU111111111111111111111111111111",
    name: "Alpha Trader (Phantom)",
    usdcBalance: 500.00,
    solBalance: 12.4,
    avatar: "🦅"
  },
  {
    publicKey: "Back9JnXwT22222222222222222222222222222222",
    name: "Whale Trader (Backpack)",
    usdcBalance: 25000.00,
    solBalance: 245.8,
    avatar: "🐋"
  },
  {
    publicKey: "SolflareLPPool5k11111111111111111111111111",
    name: "Primary LP (Solflare)",
    usdcBalance: 1500.00,
    solBalance: 45.2,
    avatar: "🌊"
  },
  {
    publicKey: "CreaTx8zM444444444444444444444444444444444",
    name: "Market Deployer (Ledger)",
    usdcBalance: 350.00,
    solBalance: 8.7,
    avatar: "🛠️"
  },
  {
    publicKey: "OracSign4y111111111111111111111111111111111",
    name: "Oracle Validator",
    usdcBalance: 100.00,
    solBalance: 150.0,
    avatar: "🔮"
  }
];

export const INITIAL_MARKETS: MarketState[] = [
  {
    id: 0,
    title: "Will Solana (SOL) cross $250 by Dec 31, 2026?",
    category: "Crypto",
    status: "Active",
    outcomeYes: "YES",
    outcomeNo: "NO",
    reserveYes: 580,
    reserveNo: 420,
    initialLiquidityReserve: 1000,
    totalVolume: 4210.00,
    volumeThreshold: 1000.00,
    creatorBonusAmount: 50.00,
    creatorBonusUnlocked: true,
    creatorBonusClaimed: false,
    oracle: "OracSign4y111111111111111111111111111111111",
    finalOutcome: null,
    closingDate: "Dec 31, 2026",
    description: "This market resolves to YES if Solana (SOL) reaches or exceeds a price of $250.00 USD at any point before December 31, 2026, 11:59 PM UTC, based on Binance spot exchange data.",
    priceHistory: [
      { time: "10:00", yesPrice: 0.35, noPrice: 0.65 },
      { time: "11:00", yesPrice: 0.42, noPrice: 0.58 },
      { time: "12:00", yesPrice: 0.40, noPrice: 0.60 },
      { time: "13:00", yesPrice: 0.49, noPrice: 0.51 },
      { time: "14:00", yesPrice: 0.53, noPrice: 0.47 },
      { time: "15:00", yesPrice: 0.58, noPrice: 0.42 }
    ]
  },
  {
    id: 1,
    title: "Will Donald Trump establish a US Helium Reserve in 2026?",
    category: "Politics",
    status: "Active",
    outcomeYes: "YES",
    outcomeNo: "NO",
    reserveYes: 300,
    reserveNo: 700,
    initialLiquidityReserve: 1000,
    totalVolume: 850.00,
    volumeThreshold: 1500.00,
    creatorBonusAmount: 15.00,
    creatorBonusUnlocked: false,
    creatorBonusClaimed: false,
    oracle: "OracSign4y111111111111111111111111111111111",
    finalOutcome: null,
    closingDate: "Nov 15, 2026",
    description: "This market resolves to YES if the US federal government formally signs a bill or launches an executive order creating a Strategic Helium Reserve before Nov 15, 2026.",
    priceHistory: [
      { time: "10:00", yesPrice: 0.50, noPrice: 0.50 },
      { time: "11:00", yesPrice: 0.45, noPrice: 0.55 },
      { time: "12:00", yesPrice: 0.38, noPrice: 0.62 },
      { time: "13:00", yesPrice: 0.35, noPrice: 0.65 },
      { time: "14:00", yesPrice: 0.32, noPrice: 0.68 },
      { time: "15:00", yesPrice: 0.30, noPrice: 0.70 }
    ]
  },
  {
    id: 2,
    title: "Will Gemini 2.0 release fully autonomous coding agents by Q4?",
    category: "AI",
    status: "Active",
    outcomeYes: "YES",
    outcomeNo: "NO",
    reserveYes: 550,
    reserveNo: 550,
    initialLiquidityReserve: 1100,
    totalVolume: 2200.00,
    volumeThreshold: 2000.00,
    creatorBonusAmount: 30.00,
    creatorBonusUnlocked: true,
    creatorBonusClaimed: false,
    oracle: "OracSign4y111111111111111111111111111111111",
    finalOutcome: null,
    closingDate: "Sep 30, 2026",
    description: "This market resolves to YES if Google AI Studio or Google Cloud announces a natively integrated autonomous agent workspace that builds, tests, and deploys code with zero developer oversight.",
    priceHistory: [
      { time: "10:00", yesPrice: 0.50, noPrice: 0.50 },
      { time: "11:00", yesPrice: 0.52, noPrice: 0.48 },
      { time: "12:00", yesPrice: 0.51, noPrice: 0.49 },
      { time: "13:00", yesPrice: 0.48, noPrice: 0.52 },
      { time: "14:00", yesPrice: 0.49, noPrice: 0.51 },
      { time: "15:00", yesPrice: 0.50, noPrice: 0.50 }
    ]
  },
  {
    id: 3,
    title: "Will SpaceX land both Mars Starship flight 8 stages successfully?",
    category: "Science",
    status: "Active",
    outcomeYes: "YES",
    outcomeNo: "NO",
    reserveYes: 800,
    reserveNo: 200,
    initialLiquidityReserve: 1000,
    totalVolume: 4100.00,
    volumeThreshold: 3000.00,
    creatorBonusAmount: 50.00,
    creatorBonusUnlocked: true,
    creatorBonusClaimed: false,
    oracle: "OracSign4y111111111111111111111111111111111",
    finalOutcome: null,
    closingDate: "Oct 1, 2026",
    description: "Resolves to YES if SpaceX Starship Integrated Flight Test 8 recovers/catches both the Super Heavy booster stage and the Starship upper stage during its orbital run.",
    priceHistory: [
      { time: "10:00", yesPrice: 0.60, noPrice: 0.40 },
      { time: "11:00", yesPrice: 0.68, noPrice: 0.32 },
      { time: "12:00", yesPrice: 0.72, noPrice: 0.28 },
      { time: "13:00", yesPrice: 0.75, noPrice: 0.25 },
      { time: "14:00", yesPrice: 0.78, noPrice: 0.22 },
      { time: "15:00", yesPrice: 0.80, noPrice: 0.20 }
    ]
  },
  {
    id: 4,
    title: "Will a Solana meme coin enter the top 5 global cryptocurrencies?",
    category: "Crypto",
    status: "Active",
    outcomeYes: "YES",
    outcomeNo: "NO",
    reserveYes: 250,
    reserveNo: 750,
    initialLiquidityReserve: 1000,
    totalVolume: 500.00,
    volumeThreshold: 2500.00,
    creatorBonusAmount: 10.00,
    creatorBonusUnlocked: false,
    creatorBonusClaimed: false,
    oracle: "OracSign4y111111111111111111111111111111111",
    finalOutcome: null,
    closingDate: "Dec 31, 2026",
    description: "Resolves to YES if any SPL token commonly designated as a meme token achieves a top 5 ranking by market capitalization on CoinGecko at any moment in 2026.",
    priceHistory: [
      { time: "10:00", yesPrice: 0.40, noPrice: 0.60 },
      { time: "11:00", yesPrice: 0.35, noPrice: 0.65 },
      { time: "12:00", yesPrice: 0.32, noPrice: 0.68 },
      { time: "13:00", yesPrice: 0.29, noPrice: 0.71 },
      { time: "14:00", yesPrice: 0.27, noPrice: 0.73 },
      { time: "15:00", yesPrice: 0.25, noPrice: 0.75 }
    ]
  }
];

export const INITIAL_POSITIONS: WalletPositions = {
  // Alpha Trader (Phantom)
  "Phan7vWfA3oU111111111111111111111111111111": {
    0: { sharesYes: 150.00, sharesNo: 0, avgPricePaidYes: 0.42, avgPricePaidNo: 0 },
    1: { sharesYes: 0, sharesNo: 200.00, avgPricePaidYes: 0, avgPricePaidNo: 0.55 },
    2: { sharesYes: 50.00, sharesNo: 0, avgPricePaidYes: 0.50, avgPricePaidNo: 0 }
  },
  // Whale Trader (Backpack)
  "Back9JnXwT22222222222222222222222222222222": {
    0: { sharesYes: 2000.00, sharesNo: 0, avgPricePaidYes: 0.48, avgPricePaidNo: 0 },
    3: { sharesYes: 5000.00, sharesNo: 0, avgPricePaidYes: 0.65, avgPricePaidNo: 0 }
  },
  // Primary LP (Solflare)
  "SolflareLPPool5k11111111111111111111111111": {},
  // Market Creator
  "CreaTx8zM444444444444444444444444444444444": {},
  // Oracle Validator
  "OracSign4y111111111111111111111111111111111": {}
};
