export const CODE_TEMPLATES = {
  "lib.rs": `use anchor_lang::prelude::*;

pub mod errors;
pub mod events;
pub mod state;
pub mod instructions;

use instructions::*;

declare_id!("PMkt111111111111111111111111111111111111111");

#[program]
pub mod prediction_market {
    use super::*;

    /// Initializes the global protocol configuration.
    pub fn initialize_protocol(
        ctx: Context<InitializeProtocol>,
        admin: Pubkey,
        fee_receiver: Pubkey,
    ) -> Result<()> {
        instructions::initialize_protocol::handler(ctx, admin, fee_receiver)
    }

    /// Creates a new binary outcome prediction market.
    pub fn create_market(
        ctx: Context<CreateMarket>,
        title: String,
        outcome_yes: String,
        outcome_no: String,
        trading_deadline: i64,
        volume_threshold: u64,
        creator_bonus_amount: u64,
        oracle: Pubkey,
    ) -> Result<()> {
        instructions::create_market::handler(
            ctx,
            title,
            outcome_yes,
            outcome_no,
            trading_deadline,
            volume_threshold,
            creator_bonus_amount,
            oracle,
        )
    }

    /// Seeds initial liquidity into the market reserves.
    pub fn deposit_liquidity(
        ctx: Context<DepositLiquidity>,
        amount: u64,
    ) -> Result<()> {
        instructions::deposit_liquidity::handler(ctx, amount)
    }

    /// Purchases YES or NO shares from the AMM pool.
    pub fn buy_shares(
        ctx: Context<BuyShares>,
        is_yes: bool,
        collateral_amount: u64,
    ) -> Result<()> {
        instructions::trade::buy_shares_handler(ctx, is_yes, collateral_amount)
    }

    /// Sells YES or NO shares back to the AMM pool.
    pub fn sell_shares(
        ctx: Context<SellShares>,
        is_yes: bool,
        shares_to_sell: u64,
    ) -> Result<()> {
        instructions::trade::sell_shares_handler(ctx, is_yes, shares_to_sell)
    }

    /// Resolves the market, setting the final outcome.
    pub fn resolve_market(
        ctx: Context<ResolveMarket>,
        winning_outcome: bool,
    ) -> Result<()> {
        instructions::resolve_market::handler(ctx, winning_outcome)
    }

    /// Redeems a trader's winning shares (YES or NO) 1-to-1 for collateral.
    pub fn redeem(ctx: Context<Redeem>) -> Result<()> {
        instructions::redeem::redeem_handler(ctx)
    }

    /// Redeems a liquidity provider's share of the remaining winning collateral.
    pub fn redeem_liquidity(ctx: Context<RedeemLiquidity>) -> Result<()> {
        instructions::redeem::redeem_liquidity_handler(ctx)
    }

    /// Claims the creator bonus.
    pub fn claim_creator_bonus(ctx: Context<ClaimCreatorBonus>) -> Result<()> {
        instructions::claim_creator_bonus::handler(ctx)
    }
}`,

  "state.rs": `use anchor_lang::prelude::*;

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq)]
pub enum MarketStatus {
    Created,
    Active,
    TradingClosed,
    Resolved,
}

#[account]
pub struct ProtocolConfig {
    pub admin: Pubkey,
    pub fee_receiver: Pubkey,
    pub market_count: u64,
    pub reserved: [u8; 32],
}

impl ProtocolConfig {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 32;
}

#[account]
pub struct Market {
    pub creator: Pubkey,
    pub oracle: Pubkey,
    pub token_mint: Pubkey,
    pub vault: Pubkey,
    pub id: u64,
    pub status: MarketStatus,
    pub final_outcome: Option<bool>,
    pub reserve_yes: u64,
    pub reserve_no: u64,
    pub initial_liquidity_reserve: u64,
    pub total_volume: u64,
    pub volume_threshold: u64,
    pub creator_bonus_amount: u64,
    pub creator_bonus_unlocked: bool,
    pub creator_bonus_claimed: bool,
    pub trading_deadline: i64,
    pub bump: u8,
    pub title: String,
    pub outcome_yes: String,
    pub outcome_no: String,
}

impl Market {
    pub const LEN: usize = 8 + 128 + 8 + 1 + 2 + 40 + 1 + 1 + 8 + 1 + 132 + 36 + 36 + 64;
}

#[account]
pub struct UserPosition {
    pub user: Pubkey,
    pub market: Pubkey,
    pub shares_yes: u64,
    pub shares_no: u64,
    pub bump: u8,
}

impl UserPosition {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 8 + 1;
}

#[account]
pub struct LiquidityProvider {
    pub user: Pubkey,
    pub market: Pubkey,
    pub collateral_amount: u64,
    pub bump: u8,
}

impl LiquidityProvider {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 1;
}`,

  "errors.rs": `use anchor_lang::prelude::*;

#[error_code]
pub enum PredictionMarketError {
    #[msg("You are not authorized to perform this operation.")]
    Unauthorized,
    #[msg("The market is not in the Active state.")]
    MarketNotActive,
    #[msg("The market trading deadline has passed.")]
    TradingDeadlinePassed,
    #[msg("The provided resolution outcome is invalid.")]
    InvalidOutcome,
    #[msg("This market has already been resolved.")]
    MarketAlreadyResolved,
    #[msg("The market must be resolved before redeeming winnings.")]
    MarketNotResolved,
    #[msg("Your position did not win. Losing positions cannot be redeemed.")]
    LosingPosition,
    #[msg("You have no winning shares to redeem.")]
    NoSharesToRedeem,
    #[msg("The requested state transition is invalid.")]
    InvalidStateTransition,
    #[msg("A mathematical overflow or underflow occurred.")]
    Overflow,
    #[msg("The market pool currently has zero liquidity.")]
    ZeroLiquidity,
    #[msg("The pool does not have sufficient liquidity for this trade size.")]
    InsufficientLiquidity,
    #[msg("The creator volume threshold has not been reached yet.")]
    CreatorBonusNotUnlocked,
    #[msg("The creator bonus has already been claimed for this market.")]
    CreatorBonusAlreadyClaimed,
    #[msg("The provided token mint is invalid for this market.")]
    InvalidTokenMint,
    #[msg("The provided token vault PDA is invalid.")]
    InvalidVault,
    #[msg("The transaction amount must be greater than zero.")]
    ZeroValueTransaction,
    #[msg("Proportional liquidity deposit is required when pool is already active.")]
    ProportionalLiquidityRequired,
    #[msg("Liquidity can only be seeded once when the market is in Created state.")]
    MarketAlreadySeeded,
}`,

  "events.rs": `use anchor_lang::prelude::*;

#[event]
pub struct MarketCreated {
    pub market: Pubkey,
    pub creator: Pubkey,
    pub id: u64,
    pub title: String,
    pub token_mint: Pubkey,
    pub volume_threshold: u64,
    pub creator_bonus_amount: u64,
}

#[event]
pub struct LiquidityDeposited {
    pub market: Pubkey,
    pub provider: Pubkey,
    pub amount: u64,
    pub reserve_yes: u64,
    pub reserve_no: u64,
    pub timestamp: i64,
}

#[event]
pub struct SharePurchased {
    pub market: Pubkey,
    pub buyer: Pubkey,
    pub is_yes: bool,
    pub collateral_spent: u64,
    pub shares_received: u64,
    pub fee_collected: u64,
    pub new_reserve_yes: u64,
    pub new_reserve_no: u64,
    pub cumulative_volume: u64,
    pub timestamp: i64,
}

#[event]
pub struct ShareSold {
    pub market: Pubkey,
    pub seller: Pubkey,
    pub is_yes: bool,
    pub shares_sold: u64,
    pub collateral_received: u64,
    pub fee_collected: u64,
    pub new_reserve_yes: u64,
    pub new_reserve_no: u64,
    pub cumulative_volume: u64,
    pub timestamp: i64,
}

#[event]
pub struct MarketResolved {
    pub market: Pubkey,
    pub resolver: Pubkey,
    pub winning_outcome: bool,
    pub timestamp: i64,
}

#[event]
pub struct PositionRedeemed {
    pub market: Pubkey,
    pub user: Pubkey,
    pub shares_redeemed: u64,
    pub payout_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct CreatorBonusUnlocked {
    pub market: Pubkey,
    pub creator: Pubkey,
    pub current_volume: u64,
    pub threshold: u64,
    pub timestamp: i64,
}

#[event]
pub struct CreatorBonusClaimed {
    pub market: Pubkey,
    pub creator: Pubkey,
    pub bonus_amount: u64,
    pub timestamp: i64,
}`,

  "trade.rs": `use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{ProtocolConfig, Market, MarketStatus, UserPosition};
use crate::errors::PredictionMarketError;
use crate::events::{SharePurchased, ShareSold, CreatorBonusUnlocked};

pub fn integer_sqrt(val: u128) -> u128 {
    if val == 0 { return 0; }
    let mut temp = (val + 1) / 2;
    let mut result = val;
    while temp < result {
        result = temp;
        temp = (val / temp + temp) / 2;
    }
    result
}

pub fn buy_shares_handler(ctx: Context<BuyShares>, is_yes: bool, collateral_amount: u64) -> Result<()> {
    let clock = Clock::get()?;
    let market = &mut ctx.accounts.market;

    require!(market.status == MarketStatus::Active, PredictionMarketError::MarketNotActive);
    require!(market.trading_deadline > clock.unix_timestamp, PredictionMarketError::TradingDeadlinePassed);
    require!(collateral_amount > 0, PredictionMarketError::ZeroValueTransaction);

    let fee = collateral_amount.checked_div(100).ok_or(PredictionMarketError::Overflow)?;
    let collateral_to_trade = collateral_amount.checked_sub(fee).ok_or(PredictionMarketError::Overflow)?;
    let protocol_fee = fee.checked_div(2).ok_or(PredictionMarketError::Overflow)?;

    // CPI to Vault
    let transfer_ctx = CpiContext::new(
        ctx.accounts.token_program.to_account_info(),
        Transfer {
            from: ctx.accounts.buyer_token_account.to_account_info(),
            to: ctx.accounts.vault.to_account_info(),
            authority: ctx.accounts.buyer.to_account_info(),
        }
    );
    transfer(transfer_ctx, collateral_amount)?;

    // CPI to Fee Receiver
    let seeds = &[b"market", market.id.to_le_bytes().as_ref(), &[market.bump]];
    if protocol_fee > 0 {
        transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.fee_receiver_token_account.to_account_info(),
                    authority: market.to_account_info(),
                },
                &[&seeds[..]]
            ),
            protocol_fee
        )?;
    }

    // CPMM Math
    let r_yes_u128 = market.reserve_yes as u128;
    let r_no_u128 = market.reserve_no as u128;
    let k = r_yes_u128.checked_mul(r_no_u128).ok_or(PredictionMarketError::Overflow)?;

    let shares_received: u64;
    let new_reserve_yes: u64;
    let new_reserve_no: u64;

    if is_yes {
        let new_no_u128 = r_no_u128 + collateral_to_trade as u128;
        let new_yes_u128 = k / new_no_u128;
        shares_received = (collateral_to_trade as u128 + r_yes_u128 - new_yes_u128) as u64;
        new_reserve_yes = new_yes_u128 as u64;
        new_reserve_no = new_no_u128 as u64;
    } else {
        let new_yes_u128 = r_yes_u128 + collateral_to_trade as u128;
        let new_no_u128 = k / new_yes_u128;
        shares_received = (collateral_to_trade as u128 + r_no_u128 - new_no_u128) as u64;
        new_reserve_yes = new_yes_u128 as u64;
        new_reserve_no = new_no_u128 as u64;
    }

    market.reserve_yes = new_reserve_yes;
    market.reserve_no = new_reserve_no;

    let position = &mut ctx.accounts.position;
    position.user = ctx.accounts.buyer.key();
    position.market = market.key();
    position.bump = ctx.bumps.position;

    if is_yes {
        position.shares_yes += shares_received;
    } else {
        position.shares_no += shares_received;
    }

    market.total_volume += collateral_amount;

    if market.total_volume >= market.volume_threshold && !market.creator_bonus_unlocked {
        market.creator_bonus_unlocked = true;
        emit!(CreatorBonusUnlocked {
            market: market.key(),
            creator: market.creator,
            current_volume: market.total_volume,
            threshold: market.volume_threshold,
            timestamp: clock.unix_timestamp,
        });
    }

    Ok(())
}`,

  "create_market.rs": `use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Mint, Transfer, transfer};
use crate::state::{ProtocolConfig, Market, MarketStatus};
use crate::errors::PredictionMarketError;
use crate::events::MarketCreated;

pub fn handler(
    ctx: Context<CreateMarket>,
    title: String,
    outcome_yes: String,
    outcome_no: String,
    trading_deadline: i64,
    volume_threshold: u64,
    creator_bonus_amount: u64,
    oracle: Pubkey,
) -> Result<()> {
    let clock = Clock::get()?;
    require!(trading_deadline > clock.unix_timestamp, PredictionMarketError::TradingDeadlinePassed);

    let config = &mut ctx.accounts.config;
    let market = &mut ctx.accounts.market;

    market.creator = ctx.accounts.creator.key();
    market.oracle = oracle;
    market.token_mint = ctx.accounts.token_mint.key();
    market.vault = ctx.accounts.vault.key();
    market.id = config.market_count;
    market.status = MarketStatus::Created;
    market.reserve_yes = 0;
    market.reserve_no = 0;
    market.total_volume = 0;
    market.volume_threshold = volume_threshold;
    market.creator_bonus_amount = creator_bonus_amount;
    market.trading_deadline = trading_deadline;
    market.bump = ctx.bumps.market;
    market.title = title.clone();
    market.outcome_yes = outcome_yes;
    market.outcome_no = outcome_no;

    config.market_count += 1;

    if creator_bonus_amount > 0 {
        transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.creator_token_account.to_account_info(),
                    to: ctx.accounts.vault.to_account_info(),
                    authority: ctx.accounts.creator.to_account_info(),
                }
            ),
            creator_bonus_amount
        )?;
    }

    emit!(MarketCreated {
        market: market.key(),
        creator: market.creator,
        id: market.id,
        title,
        token_mint: market.token_mint,
        volume_threshold,
        creator_bonus_amount,
    });

    Ok(())
}`,

  "redeem.rs": `use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{Market, MarketStatus, UserPosition, LiquidityProvider};
use crate::errors::PredictionMarketError;

pub fn redeem_handler(ctx: Context<Redeem>) -> Result<()> {
    let market = &mut ctx.accounts.market;
    let position = &mut ctx.accounts.position;

    require!(market.status == MarketStatus::Resolved, PredictionMarketError::MarketNotResolved);
    let winning_outcome = market.final_outcome.ok_or(PredictionMarketError::MarketNotResolved)?;

    let payout_amount = if winning_outcome {
        let amt = position.shares_yes;
        position.shares_yes = 0;
        amt
    } else {
        let amt = position.shares_no;
        position.shares_no = 0;
        amt
    };

    require!(payout_amount > 0, PredictionMarketError::NoSharesToRedeem);

    let seeds = &[b"market", market.id.to_le_bytes().as_ref(), &[market.bump]];
    transfer(
        CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.vault.to_account_info(),
                to: ctx.accounts.user_token_account.to_account_info(),
                authority: market.to_account_info(),
            },
            &[&seeds[..]]
        ),
        payout_amount
    )?;

    Ok(())
}`,

  "claim_creator_bonus.rs": `use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, transfer};
use crate::state::{Market, MarketStatus};
use crate::errors::PredictionMarketError;

pub fn handler(ctx: Context<ClaimCreatorBonus>) -> Result<()> {
    let market = &mut ctx.accounts.market;

    require!(!market.creator_bonus_claimed, PredictionMarketError::CreatorBonusAlreadyClaimed);

    let is_bonus_claim = market.creator_bonus_unlocked;
    let is_refund_claim = market.status == MarketStatus::Resolved && !market.creator_bonus_unlocked;

    require!(is_bonus_claim || is_refund_claim, PredictionMarketError::CreatorBonusNotUnlocked);

    let claim_amount = market.creator_bonus_amount;
    require!(claim_amount > 0, PredictionMarketError::ZeroValueTransaction);

    market.creator_bonus_claimed = true;

    let seeds = &[b"market", market.id.to_le_bytes().as_ref(), &[market.bump]];
    transfer(
        CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.vault.to_account_info(),
                to: ctx.accounts.creator_token_account.to_account_info(),
                authority: market.to_account_info(),
            },
            &[&seeds[..]]
        ),
        claim_amount
    )?;

    Ok(())
}`,

  "prediction-market.ts": `// Full automated integration test suite using @coral-xyz/anchor
// (See complete file: /tests/prediction-market.ts)`,

  "deploy-devnet.sh": `# Devnet Deployment Bash Script
# (See complete script: /scripts/deploy-devnet.sh)`
};
