export interface LogMessage {
  id: string;
  type: "info" | "success" | "error" | "tx" | "event";
  message: string;
  txSig?: string;
  timestamp: string;
}

export interface SimulatedWallet {
  publicKey: string;
  name: string;
  usdcBalance: number;
  solBalance: number;
  avatar: string;
}

export interface PricePoint {
  time: string;
  yesPrice: number;
  noPrice: number;
}

export interface MarketState {
  id: number;
  title: string;
  category: "Crypto" | "Politics" | "AI" | "Science" | "Pop Culture" | "Sports";
  status: "Created" | "Active" | "Resolved";
  outcomeYes: string;
  outcomeNo: string;
  reserveYes: number;
  reserveNo: number;
  initialLiquidityReserve: number;
  totalVolume: number;
  volumeThreshold: number;
  creatorBonusAmount: number;
  creatorBonusUnlocked: boolean;
  creatorBonusClaimed: boolean;
  oracle: string;
  finalOutcome: boolean | null;
  closingDate: string;
  description: string;
  priceHistory: PricePoint[];
}

export interface MarketPosition {
  sharesYes: number;
  sharesNo: number;
  avgPricePaidYes: number;
  avgPricePaidNo: number;
}

export interface WalletPositions {
  [walletPubKey: string]: {
    [marketId: number]: MarketPosition;
  };
}
