# Solana Prediction Market Protocol: Architecture & Technical Specification

This document provides a comprehensive technical overview of the production-grade Solana binary-outcome prediction market protocol built using the Anchor framework.

---

## 1. Protocol Design Overview

The protocol implements a fully collateralized, non-custodial, on-chain binary prediction market. For any market created, the outcome resolves to a simple binary state: **YES** or **NO**. 

Every YES/NO share is minted directly against a collateral token (e.g., USDC, representing 6 decimal precision). At resolution, exactly one outcome becomes worth **1.00 USDC**, and the losing outcome becomes worth **0.00 USDC**. Since YES and NO are complementary, 1 YES share + 1 NO share is always worth exactly 1.00 USDC in total collateral backing.

---

## 2. Market Lifecycle State Machine

Each market is represented by a strict, one-way state machine enforced at the program level:

```
[Created] ──(Deposit Liquidity)──> [Active] ──(Trading / Sells)──> [Trading Deadline]
                                                                        │
[Redeemable] <──(Redeem / LP Claims)── [Resolved] <──(Oracle Sign) ─────┘
```

### State Guardrails
- **Trading Constraint**: No buy or sell trades can occur when status is `Created` or `Resolved`, or after the `trading_deadline` has passed.
- **Oracle Resolution**: Only the authorized `oracle` pubkey stored on the market account can sign the resolution transaction.
- **Single Resolution**: A market can be resolved exactly once; once resolved, the final outcome and state are permanently locked.
- **Payout Security**: Redemption of winning shares can only occur when status is `Resolved`. Losing positions cannot be redeemed and default to 0 value.

---

## 3. AMM Pricing Mathematical Model

The protocol utilizes a high-performance **Constant Product Market Maker (CPMM)** model tailored for binary options. This provides continuous liquidity and deterministic, fully collateralized pricing without relying on external off-chain market makers.

### Pool Reserves
The pool maintains reserves of YES and NO shares:
- $R_{yes}$: Reserve of YES shares in the pool.
- $R_{no}$: Reserve of NO shares in the pool.
- $K = R_{yes} \times R_{no}$ (Constant Product Invariant).

### A. Seeding Liquidity
An LP provides $L$ collateral tokens. The contract mints $L$ YES and $L$ NO shares and adds them to the pool:
- $R_{yes} = L$
- $R_{no} = L$
- Initial $K = L^2$
The market status is advanced to `Active`.

### B. Buying YES/NO Shares
When a user buys YES shares with collateral $C$:
1. We collect a 1% fee $F = C / 100$.
2. The remaining collateral $C_{trade} = C - F$ is used to mint $C_{trade}$ YES and $C_{trade}$ NO shares.
3. The $C_{trade}$ NO shares are added to the pool's reserves: 
   $$R_{no}' = R_{no} + C_{trade}$$
4. To maintain $R_{yes}' \times R_{no}' = K$, the pool's new YES reserve must be:
   $$R_{yes}' = \frac{K}{R_{no}'}$$
5. The amount of YES shares taken out of the pool is:
   $$dy_{pool} = R_{yes} - R_{yes}'$$
6. The user receives the $C_{trade}$ YES shares minted in step 2 plus the $dy_{pool}$ YES shares taken from the pool:
   $$Shares_{received} = C_{trade} + R_{yes} - \frac{R_{yes} \times R_{no}}{R_{no} + C_{trade}}$$

*This formula is symmetric for buying NO shares.*

### C. Selling YES/NO Shares (Quadratic Formula)
When a user sells $S$ YES shares back to the pool to reclaim collateral, we must calculate the returned collateral $C$ while maintaining the constant product invariant.

The system solves the following quadratic equation:
$$(R_{yes} + S - C) \times (R_{no} - C) = K$$

By expanding, we get:
$$C^2 - bC + c = 0$$
where:
- $b = R_{yes} + R_{no} + S$
- $c = S \times R_{no}$

The returned gross collateral $C$ is the smaller root of the quadratic equation:
$$C = \frac{b - \sqrt{b^2 - 4c}}{2}$$

1. We calculate $C$ using safe integer arithmetic.
2. We charge a 1% fee on the returned collateral: $F = C / 100$.
3. The user is transferred $C_{net} = C - F$ collateral.
4. The reserves are updated:
   - $R_{yes}' = R_{yes} + S - C$
   - $R_{no}' = R_{no} - C$

---

## 4. Accounts & PDA Derivations

All accounts are derived deterministically using Program Derived Addresses (PDAs):

| Account Type | Seed Pattern | Description |
|---|---|---|
| **ProtocolConfig** | `["protocol-config"]` | Global configuration and fee receiver keys. |
| **Market** | `["market", market_id_le_bytes]` | Specific market settings, reserves, and volume trackers. |
| **UserPosition** | `["position", market_pubkey, user_pubkey]` | User position tracking YES and NO share balances. |
| **LiquidityProvider** | `["lp", market_pubkey, user_pubkey]` | Tracks initial capital deposited by each LP. |
| **Vault** | Associated Token Account of `Market` | The token account holding the collateral tokens (USDC). |

---

## 5. Creator Incentive & Fee System

Every market implements the mandatory **Volume Threshold Creator Bonus**:
- **Trading Fee**: A 1.0% fee is charged on every trade size.
- **Fee Split**:
  - 50% ($0.5\%$ of trade) is immediately transferred via CPI to the protocol's global `fee_receiver`.
  - 50% ($0.5\%$ of trade) is left in the vault as an extra reserve.
- **Volume Threshold**: At market creation, a `volume_threshold` (e.g., $100,000$ USDC) and `creator_bonus_amount` are configured.
- **Bonus Claims**:
  - If the cumulative volume crosses the threshold, `creator_bonus_unlocked` is set to `true`. The creator can claim the escrowed `creator_bonus_amount` exactly once.
  - If the market resolves without meeting the threshold, the creator can claim a full **refund** of their escrowed bonus, ensuring zero lost capital for market sponsors.
