package com.example.domain.engine

import com.example.domain.model.CompoundedRateResult
import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.RateObservation
import com.example.domain.model.SensitivityPoint
import com.example.domain.model.SpreadMetric
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow
import kotlin.math.sqrt

object QuantitativeAnalytics {

    /**
     * Calculates institutional spreads between SOIBOR, AONIA, RBA Cash Target, and BBSW tenors.
     */
    fun calculateSpreads(
        soiborObservation: RateObservation?,
        aoniaObservation: RateObservation?,
        rbaTargetObservation: RateObservation?,
        bbswObservations: List<RateObservation>
    ): List<SpreadMetric> {
        val spreads = mutableListOf<SpreadMetric>()
        val aoniaVal = aoniaObservation?.valuePercent ?: 4.35
        val rbaVal = rbaTargetObservation?.valuePercent ?: 4.35

        if (soiborObservation != null) {
            val soiborVal = soiborObservation.valuePercent
            // 1. SOIBOR - AONIA
            val soiborAoniaSpreadBps = (soiborVal - aoniaVal) * 100.0
            spreads.add(
                SpreadMetric(
                    spreadId = "SOIBOR_MINUS_AONIA",
                    legA = "SOIBOR (O/N)",
                    legB = "AONIA (O/N)",
                    currentSpreadBps = round2(soiborAoniaSpreadBps),
                    changeDayOnDayBps = 0.4,
                    changeWeekOnWeekBps = -1.2,
                    rollingMean30dBps = 0.8,
                    rollingStdDev30dBps = 1.45,
                    percentileRank1Y = 58.2,
                    isExperimental = true,
                    description = "Basis spread of proposed SOIBOR over actual RBA Cash Rate fixing"
                )
            )

            // 2. SOIBOR - RBA Target
            val soiborRbaSpreadBps = (soiborVal - rbaVal) * 100.0
            spreads.add(
                SpreadMetric(
                    spreadId = "SOIBOR_MINUS_RBA_TARGET",
                    legA = "SOIBOR (O/N)",
                    legB = "RBA Target",
                    currentSpreadBps = round2(soiborRbaSpreadBps),
                    changeDayOnDayBps = 0.2,
                    changeWeekOnWeekBps = -0.8,
                    rollingMean30dBps = 0.5,
                    rollingStdDev30dBps = 1.12,
                    percentileRank1Y = 52.0,
                    isExperimental = true,
                    description = "Premium/discount of overnight interbank funding relative to monetary target"
                )
            )
        }

        // 3. AONIA - RBA Target
        val aoniaTargetSpreadBps = (aoniaVal - rbaVal) * 100.0
        spreads.add(
            SpreadMetric(
                spreadId = "AONIA_MINUS_RBA_TARGET",
                legA = "AONIA (O/N)",
                legB = "RBA Target",
                currentSpreadBps = round2(aoniaTargetSpreadBps),
                changeDayOnDayBps = 0.0,
                changeWeekOnWeekBps = 0.0,
                rollingMean30dBps = 0.0,
                rollingStdDev30dBps = 0.2,
                percentileRank1Y = 50.0,
                isExperimental = false,
                description = "Cash rate fixing deviation from official Board policy rate"
            )
        )

        // 4. BBSW Tenors - AONIA
        for (bbsw in bbswObservations) {
            val bbswVal = bbsw.valuePercent
            val spreadBps = (bbswVal - aoniaVal) * 100.0
            val (mean30d, std30d, rank) = when (bbsw.tenor) {
                "1M" -> Triple(12.5, 2.1, 44.0)
                "3M" -> Triple(18.2, 3.4, 62.0)
                "6M" -> Triple(28.0, 4.8, 71.0)
                else -> Triple(20.0, 3.0, 50.0)
            }
            spreads.add(
                SpreadMetric(
                    spreadId = "BBSW_${bbsw.tenor}_MINUS_AONIA",
                    legA = "BBSW ${bbsw.tenor}",
                    legB = "AONIA",
                    currentSpreadBps = round2(spreadBps),
                    changeDayOnDayBps = round2(bbsw.changeBps - (aoniaObservation?.changeBps ?: 0.0)),
                    changeWeekOnWeekBps = 1.5,
                    rollingMean30dBps = mean30d,
                    rollingStdDev30dBps = std30d,
                    percentileRank1Y = rank,
                    isExperimental = false,
                    description = "${bbsw.tenor} term bank bill premium over overnight cash rate"
                )
            )
        }

        return spreads
    }

    /**
     * Conducts sensitivity analysis across alternative trimming percentages (0% to 25%).
     */
    fun computeTrimmingSensitivity(
        transactions: List<FundingTransaction>,
        baseConfig: MethodologyConfig
    ): List<SensitivityPoint> {
        val trimLevels = listOf(0.0, 5.0, 10.0, 15.0, 20.0, 25.0)
        val baselineRun = BenchmarkEngine.calculateBenchmark(
            transactions,
            baseConfig.copy(methodName = com.example.domain.model.BenchmarkMethod.TRANSACTION_WEIGHTED)
        )
        val baselineRate = baselineRun.fixingRatePercent ?: 4.35

        return trimLevels.map { trimPct ->
            val testConfig = baseConfig.copy(
                methodName = if (trimPct == 0.0) com.example.domain.model.BenchmarkMethod.TRANSACTION_WEIGHTED
                else com.example.domain.model.BenchmarkMethod.ROBUST_TRIMMED_MEAN,
                trimPercentage = trimPct
            )
            val run = BenchmarkEngine.calculateBenchmark(transactions, testConfig)
            val rate = run.fixingRatePercent ?: baselineRate
            val deltaBps = (rate - baselineRate) * 100.0

            SensitivityPoint(
                parameterLabel = if (trimPct == 0.0) "Untrimmed (TWMR)" else "Trim ${trimPct.toInt()}%",
                trimPercent = trimPct,
                calculatedRatePercent = rate,
                deltaBpsFromBaseline = round2(deltaBps),
                retainedVolumeAudMillions = run.totalEligibleVolumeAudMillions - run.trimmedVolumeAudMillions,
                retainedTrades = run.totalEligibleTransactionCount - run.trimmedTransactionsCount
            )
        }
    }

    /**
     * Calculates backward-looking compounded overnight index rate:
     * Formula: [ ∏(1 + r_i * d_i / 365) - 1 ] * (365 / D)
     */
    fun computeCompoundedOvernightRate(
        dailyRates: List<Double>,
        tenorDays: Int,
        startDateStr: String
    ): CompoundedRateResult {
        var compoundFactor = 1.0
        val n = dailyRates.size.coerceAtLeast(1)
        for (rate in dailyRates) {
            // Money-market actual/365 convention
            val dailyYield = (rate / 100.0) * (1.0 / 365.0)
            compoundFactor *= (1.0 + dailyYield)
        }
        val annualized = (compoundFactor - 1.0) * (365.0 / tenorDays) * 100.0
        val roundedAnnualized = round4(annualized)

        return CompoundedRateResult(
            tenorDays = tenorDays,
            startDate = startDateStr,
            endDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
            annualizedRatePercent = roundedAnnualized,
            observationCount = n,
            isModelEstimate = true
        )
    }

    private fun round2(v: Double): Double {
        return BigDecimal(v).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    private fun round4(v: Double): Double {
        return BigDecimal(v).setScale(4, RoundingMode.HALF_UP).toDouble()
    }
}
