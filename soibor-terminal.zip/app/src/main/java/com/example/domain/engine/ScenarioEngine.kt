package com.example.domain.engine

import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.ScenarioDefinition
import com.example.domain.model.ScenarioResult
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ScenarioEngine {

    val PRESET_SCENARIOS = listOf(
        ScenarioDefinition(
            scenarioId = "SCEN_RBA_HIKE_25",
            name = "RBA Policy Tightening (+25 bps)",
            description = "Simulates RBA Board increasing cash rate target by 25 bps. Interbank funding rates shift upward accordingly.",
            rbaTargetShiftBps = 25.0,
            liquidityVolumeMultiplier = 1.0,
            dispersionWideningFactor = 1.0,
            tailOutlierCount = 0,
            isStressScenario = false
        ),
        ScenarioDefinition(
            scenarioId = "SCEN_RBA_CUT_25",
            name = "RBA Policy Easing (-25 bps)",
            description = "Simulates RBA Board cutting cash rate target by 25 bps.",
            rbaTargetShiftBps = -25.0,
            liquidityVolumeMultiplier = 1.0,
            dispersionWideningFactor = 1.0,
            tailOutlierCount = 0,
            isStressScenario = false
        ),
        ScenarioDefinition(
            scenarioId = "SCEN_LIQUIDITY_SQUEEZE",
            name = "Quarter-End Balance Sheet Squeeze",
            description = "Severe collateral and balance sheet pressure. Transaction volume contracts 40% and dispersion widens 2.2x with distress borrowing.",
            rbaTargetShiftBps = 0.0,
            liquidityVolumeMultiplier = 0.6,
            dispersionWideningFactor = 2.2,
            tailOutlierCount = 2,
            isStressScenario = true
        ),
        ScenarioDefinition(
            scenarioId = "SCEN_MARKET_DISLOCATION",
            name = "Acute Interbank Credit Dislocation",
            description = "Tier-2 institutions experience liquidity drought. Rate dispersion widens 3.5x with extreme tail funding rates.",
            rbaTargetShiftBps = 10.0,
            liquidityVolumeMultiplier = 0.45,
            dispersionWideningFactor = 3.5,
            tailOutlierCount = 4,
            isStressScenario = true
        )
    )

    fun runScenario(
        baselineTransactions: List<FundingTransaction>,
        baselineConfig: MethodologyConfig,
        scenario: ScenarioDefinition
    ): ScenarioResult {
        val baseRun = BenchmarkEngine.calculateBenchmark(baselineTransactions, baselineConfig)
        val baseRate = baseRun.fixingRatePercent ?: 4.35
        val baseVolume = baseRun.totalEligibleVolumeAudMillions

        // Transform transactions under scenario assumptions
        val simulatedTransactions = baselineTransactions.mapIndexed { idx, tx ->
            val shiftPercent = scenario.rbaTargetShiftBps / 100.0
            val dispersionShift = (tx.ratePercent - baseRate) * (scenario.dispersionWideningFactor - 1.0)
            val newRate = tx.ratePercent + shiftPercent + dispersionShift
            val newVolume = tx.volumeAudMillions * scenario.liquidityVolumeMultiplier

            tx.copy(
                transactionId = "SIM-${tx.transactionId}",
                ratePercent = BigDecimal(newRate).setScale(4, RoundingMode.HALF_UP).toDouble(),
                volumeAudMillions = BigDecimal(newVolume).setScale(2, RoundingMode.HALF_UP).toDouble()
            )
        }.toMutableList()

        // Inject extreme tail trades if specified in scenario
        if (scenario.tailOutlierCount > 0) {
            for (i in 1..scenario.tailOutlierCount) {
                simulatedTransactions.add(
                    FundingTransaction(
                        transactionId = "SIM-TAIL-00$i",
                        tradeTimestamp = "16:45:00 AEDT",
                        ratePercent = baseRate + (scenario.rbaTargetShiftBps / 100.0) + 0.35 + (i * 0.08),
                        volumeAudMillions = 40.0,
                        counterpartyBorrower = "Regional Bank Group $i",
                        counterpartyLender = "Major Australian Bank A",
                        transactionType = "UNSECURED_INTERBANK_DEPOSIT",
                        tenor = "O/N",
                        currency = "AUD"
                    )
                )
            }
        }

        val simRun = BenchmarkEngine.calculateBenchmark(
            simulatedTransactions,
            baselineConfig,
            datasetName = "Scenario: ${scenario.name}"
        )

        val simRate = simRun.fixingRatePercent ?: (baseRate + scenario.rbaTargetShiftBps / 100.0)
        val simVolume = simRun.totalEligibleVolumeAudMillions
        val targetBaseline = 4.35 + (scenario.rbaTargetShiftBps / 100.0)
        val spreadToTarget = (simRate - targetBaseline) * 100.0
        val spreadToBase = (simRate - baseRate) * 100.0

        val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'AEDT'", Locale.US).format(Date())

        return ScenarioResult(
            scenario = scenario,
            baselineRatePercent = baseRate,
            simulatedRatePercent = BigDecimal(simRate).setScale(4, RoundingMode.HALF_UP).toDouble(),
            baselineVolumeAudMillions = baseVolume,
            simulatedVolumeAudMillions = BigDecimal(simVolume).setScale(1, RoundingMode.HALF_UP).toDouble(),
            simulatedTradeCount = simRun.totalEligibleTransactionCount,
            spreadToRbaTargetBps = BigDecimal(spreadToTarget).setScale(2, RoundingMode.HALF_UP).toDouble(),
            spreadToBaselineBps = BigDecimal(spreadToBase).setScale(2, RoundingMode.HALF_UP).toDouble(),
            simulationStatus = "SIMULATED — NOT AN OBSERVED BENCHMARK FIXING",
            calculatedAtSydney = currentTime
        )
    }
}
