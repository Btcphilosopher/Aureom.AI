package com.example.domain.model

data class FundingTransaction(
    val transactionId: String,
    val tradeTimestamp: String,
    val ratePercent: Double,
    val volumeAudMillions: Double,
    val counterpartyBorrower: String,
    val counterpartyLender: String,
    val transactionType: String = "UNSECURED_INTERBANK_DEPOSIT",
    val tenor: String = "O/N",
    val settlementConvention: String = "T+0",
    val currency: String = "AUD",
    val isEligible: Boolean = true,
    val exclusionReason: String? = null,
    val isOutlier: Boolean = false,
    val isTrimmed: Boolean = false
) {
    val totalVolumeAud: Double
        get() = volumeAudMillions * 1_000_000.0
}
