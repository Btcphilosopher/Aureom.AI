package com.example.domain.model

data class ScenarioDefinition(
    val scenarioId: String,
    val name: String,
    val description: String,
    val rbaTargetShiftBps: Double,
    val liquidityVolumeMultiplier: Double,
    val dispersionWideningFactor: Double,
    val tailOutlierCount: Int = 0,
    val isStressScenario: Boolean = false
)

data class ScenarioResult(
    val scenario: ScenarioDefinition,
    val baselineRatePercent: Double,
    val simulatedRatePercent: Double,
    val baselineVolumeAudMillions: Double,
    val simulatedVolumeAudMillions: Double,
    val simulatedTradeCount: Int,
    val spreadToRbaTargetBps: Double,
    val spreadToBaselineBps: Double,
    val simulationStatus: String = "SIMULATED — HYPOTHETICAL ONLY",
    val calculatedAtSydney: String
)
