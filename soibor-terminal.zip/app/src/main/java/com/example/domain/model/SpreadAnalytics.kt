package com.example.domain.model

data class SpreadMetric(
    val spreadId: String,
    val legA: String,
    val legB: String,
    val currentSpreadBps: Double,
    val changeDayOnDayBps: Double,
    val changeWeekOnWeekBps: Double,
    val rollingMean30dBps: Double,
    val rollingStdDev30dBps: Double,
    val percentileRank1Y: Double, // 0 - 100%
    val isExperimental: Boolean = false,
    val description: String
)

data class DispersionStatistics(
    val date: String,
    val weightedMeanPercent: Double,
    val simpleMeanPercent: Double,
    val medianPercent: Double,
    val weightedStdDevBps: Double,
    val iqrBps: Double,
    val minRatePercent: Double,
    val maxRatePercent: Double,
    val rangeBps: Double,
    val totalVolumeAudMillions: Double,
    val transactionCount: Int,
    val top3ConcentrationPercent: Double,
    val hhiIndex: Double
)

data class SensitivityPoint(
    val parameterLabel: String,
    val trimPercent: Double,
    val calculatedRatePercent: Double,
    val deltaBpsFromBaseline: Double,
    val retainedVolumeAudMillions: Double,
    val retainedTrades: Int
)
