package com.example.domain.model

data class AuditEvent(
    val eventId: String,
    val timestampSydney: String,
    val userRole: UserRole,
    val actionType: String, // "CALCULATION_RUN", "METHODOLOGY_UPDATED", "SCENARIO_EXECUTED", "DATA_INGESTION", "SECURITY_VERIFICATION"
    val summary: String,
    val details: String,
    val checksum: String,
    val isTamperEvident: Boolean = true
)

data class DataQualityReport(
    val reportId: String,
    val reportDateSydney: String,
    val sourceAoniaHealth: String,
    val sourceBbswHealth: String,
    val syntheticFeedHealth: String,
    val duplicateTradesDetected: Int,
    val currencyViolationsDetected: Int,
    val tenorViolationsDetected: Int,
    val statisticalOutliersCount: Int,
    val missingDataDaysCount: Int,
    val statusSummary: String,
    val warnings: List<String>
)
