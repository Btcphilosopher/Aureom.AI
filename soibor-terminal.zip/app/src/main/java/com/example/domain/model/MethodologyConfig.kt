package com.example.domain.model

enum class BenchmarkMethod(val code: String, val title: String, val formula: String) {
    TRANSACTION_WEIGHTED(
        "METHOD_A",
        "Transaction-Weighted Overnight Mean",
        "R_t = Σ(V_i * r_i) / Σ(V_i)"
    ),
    ROBUST_TRIMMED_MEAN(
        "METHOD_B",
        "Robust Volume-Trimmed Mean",
        "R_t = Trimmed-Mean[α%] of eligible volume tails"
    )
}

enum class OutlierMethod(val label: String) {
    Z_SCORE("Z-Score Threshold (±2.5σ)"),
    MAD("Median Absolute Deviation (3×MAD)"),
    BPS_BAND("Absolute Spread Band (±20 bps)"),
    NONE("No Outlier Filtering")
}

data class MethodologyConfig(
    val versionId: String = "v1.2.0-PROPOSED",
    val methodName: BenchmarkMethod = BenchmarkMethod.TRANSACTION_WEIGHTED,
    val trimPercentage: Double = 10.0, // Used if ROBUST_TRIMMED_MEAN
    val minAggregateVolumeAudMillions: Double = 500.0,
    val minTransactionCount: Int = 5,
    val outlierMethod: OutlierMethod = OutlierMethod.Z_SCORE,
    val outlierThreshold: Double = 2.5,
    val publicationPrecisionDecimals: Int = 4,
    val allowedTenors: Set<String> = setOf("O/N"),
    val allowedCurrencies: Set<String> = setOf("AUD"),
    val allowedTransactionTypes: Set<String> = setOf(
        "UNSECURED_INTERBANK_DEPOSIT",
        "CALL_DEPOSIT"
    ),
    val deduplicateByTradeId: Boolean = true,
    val dayCountConvention: String = "Actual/365 AUD",
    val publicationCutoffTimeSydney: String = "17:00 AEST"
)
