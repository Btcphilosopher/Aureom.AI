package com.example.domain.model

enum class DataStatus(val label: String, val description: String) {
    OBSERVED("OBSERVED", "Officially observed transaction or verified market fixing"),
    DELAYED("DELAYED", "Verified market data with authorized publication delay"),
    ESTIMATED("ESTIMATED", "Model-derived estimate based on observable parameters"),
    SIMULATED("SIMULATED", "Hypothetical scenario projection; not actual market data"),
    STALE("STALE", "Data superseded or beyond standard publication freshness window"),
    MISSING("MISSING", "Observation unavailable or failed publication threshold")
}

enum class RateFamily(val code: String, val displayName: String, val authoritativeSource: String) {
    SOIBOR("SOIBOR", "Sydney Overnight Interbank Offered Rate (Proposed)", "Sydney Benchmark Methodology Lab"),
    AONIA("AONIA", "Australian Interbank Cash Rate", "Reserve Bank of Australia (RBA)"),
    BBSW("BBSW", "Bank Bill Swap Reference Rates", "ASX Benchmarks / Authorized Providers")
}

enum class UserRole(val label: String) {
    ANALYST("Analyst (Read-Only)"),
    QUANT("Quantitative Researcher"),
    ADMIN("Benchmark Administrator")
}
