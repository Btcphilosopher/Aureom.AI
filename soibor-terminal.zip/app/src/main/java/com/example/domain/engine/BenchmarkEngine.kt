package com.example.domain.engine

import com.example.domain.model.BenchmarkMethod
import com.example.domain.model.CalculationRun
import com.example.domain.model.CalculationStatus
import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.OutlierMethod
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

object BenchmarkEngine {

    /**
     * Executes the SOIBOR benchmark calculation according to the specified methodology configuration.
     * Guaranteed deterministic and reproducible.
     */
    fun calculateBenchmark(
        rawTransactions: List<FundingTransaction>,
        config: MethodologyConfig,
        datasetName: String = "Interbank Activity Blotter"
    ): CalculationRun {
        val warnings = mutableListOf<String>()
        val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'AEDT'", Locale.US).format(Date())
        val runId = "CR-" + UUID.randomUUID().toString().take(8).uppercase()

        // 1. Deduplication
        val seenIds = mutableSetOf<String>()
        val deduplicated = mutableListOf<FundingTransaction>()
        var duplicateCount = 0

        for (tx in rawTransactions) {
            if (config.deduplicateByTradeId && seenIds.contains(tx.transactionId)) {
                duplicateCount++
                deduplicated.add(
                    tx.copy(
                        isEligible = false,
                        exclusionReason = "DUPLICATE_TRANSACTION_ID: ${tx.transactionId}"
                    )
                )
            } else {
                seenIds.add(tx.transactionId)
                deduplicated.add(tx)
            }
        }
        if (duplicateCount > 0) {
            warnings.add("Detected and excluded $duplicateCount duplicate transaction(s).")
        }

        // 2. Eligibility filtering (Currency, Tenor, Transaction Type)
        val filteredTxList = deduplicated.map { tx ->
            if (!tx.isEligible) {
                tx
            } else if (!config.allowedCurrencies.contains(tx.currency.uppercase())) {
                tx.copy(isEligible = false, exclusionReason = "INELIGIBLE_CURRENCY: ${tx.currency} (Required AUD)")
            } else if (!config.allowedTenors.contains(tx.tenor.uppercase())) {
                tx.copy(isEligible = false, exclusionReason = "INELIGIBLE_TENOR: ${tx.tenor} (Required O/N)")
            } else if (!config.allowedTransactionTypes.contains(tx.transactionType.uppercase())) {
                tx.copy(isEligible = false, exclusionReason = "INELIGIBLE_TX_TYPE: ${tx.transactionType}")
            } else {
                tx
            }
        }

        val initiallyEligible = filteredTxList.filter { it.isEligible }

        // 3. Outlier Detection
        val (afterOutlierTxList, outlierCount) = detectAndFilterOutliers(initiallyEligible, config)
        if (outlierCount > 0) {
            warnings.add("Detected and excluded $outlierCount statistical outlier transaction(s) using ${config.outlierMethod.label}.")
        }

        // Combine all transactions with proper eligibility flags
        val candidateEligible = afterOutlierTxList.filter { it.isEligible && !it.isOutlier }

        // 4. Activity Threshold Validations
        val totalEligibleVolume = candidateEligible.sumOf { it.volumeAudMillions }
        val totalEligibleCount = candidateEligible.size

        if (totalEligibleVolume <= 0.0) {
            return buildRunFailure(
                runId = runId,
                timestamp = currentTime,
                datasetName = datasetName,
                config = config,
                status = CalculationStatus.INSUFFICIENT_VOLUME,
                warning = "CRITICAL: Zero eligible transaction volume. Publication rejected.",
                allTransactions = filteredTxList,
                rawEligible = candidateEligible
            )
        }

        if (totalEligibleVolume < config.minAggregateVolumeAudMillions) {
            return buildRunFailure(
                runId = runId,
                timestamp = currentTime,
                datasetName = datasetName,
                config = config,
                status = CalculationStatus.INSUFFICIENT_VOLUME,
                warning = "Aggregate eligible volume (A$${String.format(Locale.US, "%.1f", totalEligibleVolume)}M) is below methodology threshold (A$${config.minAggregateVolumeAudMillions}M).",
                allTransactions = filteredTxList,
                rawEligible = candidateEligible
            )
        }

        if (totalEligibleCount < config.minTransactionCount) {
            return buildRunFailure(
                runId = runId,
                timestamp = currentTime,
                datasetName = datasetName,
                config = config,
                status = CalculationStatus.INSUFFICIENT_TRANSACTIONS,
                warning = "Eligible transaction count ($totalEligibleCount) is below minimum threshold (${config.minTransactionCount}).",
                allTransactions = filteredTxList,
                rawEligible = candidateEligible
            )
        }

        // 5. Rate Calculations according to selected methodology
        val (finalRateUnrounded, trimmedVolume, trimmedCount, finalizedConstituents) = when (config.methodName) {
            BenchmarkMethod.TRANSACTION_WEIGHTED -> {
                // Method A: Standard Volume-Weighted Mean
                val sumVolumeXRate = candidateEligible.sumOf { it.volumeAudMillions * it.ratePercent }
                val weightedMean = sumVolumeXRate / totalEligibleVolume
                CalculationTuple(weightedMean, 0.0, 0, candidateEligible)
            }
            BenchmarkMethod.ROBUST_TRIMMED_MEAN -> {
                // Method B: Robust Trimmed-Mean Estimator
                calculateTrimmedMean(candidateEligible, config.trimPercentage)
            }
        }

        // Publication precision rounding
        val precision = config.publicationPrecisionDecimals
        val roundedFixing = BigDecimal(finalRateUnrounded)
            .setScale(precision, RoundingMode.HALF_UP)
            .toDouble()

        // 6. Descriptive Statistics & Market Dispersion
        val rawWeightedRate = candidateEligible.sumOf { it.volumeAudMillions * it.ratePercent } / totalEligibleVolume
        val simpleAverageRate = candidateEligible.map { it.ratePercent }.average()
        val sortedRates = candidateEligible.map { it.ratePercent }.sorted()
        val minRate = sortedRates.firstOrNull() ?: 0.0
        val maxRate = sortedRates.lastOrNull() ?: 0.0
        val rangeBps = (maxRate - minRate) * 100.0

        val medianRate = if (sortedRates.size % 2 == 1) {
            sortedRates[sortedRates.size / 2]
        } else {
            (sortedRates[sortedRates.size / 2 - 1] + sortedRates[sortedRates.size / 2]) / 2.0
        }

        val q1 = sortedRates[((sortedRates.size - 1) * 0.25).roundToInt()]
        val q3 = sortedRates[((sortedRates.size - 1) * 0.75).roundToInt()]
        val iqrBps = (q3 - q1) * 100.0

        // Weighted variance & std dev in basis points
        val weightedVariance = candidateEligible.sumOf {
            it.volumeAudMillions * (it.ratePercent - rawWeightedRate).pow(2)
        } / totalEligibleVolume
        val weightedStdDevBps = sqrt(weightedVariance) * 100.0

        // Counterparty concentration (HHI)
        val counterpartyVolumes = mutableMapOf<String, Double>()
        candidateEligible.forEach {
            val key = it.counterpartyBorrower
            counterpartyVolumes[key] = (counterpartyVolumes[key] ?: 0.0) + it.volumeAudMillions
        }
        val hhi = counterpartyVolumes.values.sumOf { (it / totalEligibleVolume * 100.0).pow(2) }

        if (hhi > 3000.0) {
            warnings.add("High counterparty concentration detected (HHI: ${String.format(Locale.US, "%.0f", hhi)}).")
        }

        val calculationStatus = if (totalEligibleVolume < config.minAggregateVolumeAudMillions * 1.2) {
            CalculationStatus.LOW_LIQUIDITY_WARNING
        } else {
            CalculationStatus.PUBLISHED
        }

        // Build deterministic checksum
        val checksumPayload = "$runId|${config.versionId}|$roundedFixing|$totalEligibleVolume|$totalEligibleCount"
        val checksum = "SHA256-" + Integer.toHexString(checksumPayload.hashCode()).uppercase()

        // Assemble full constituent transactions list with accurate flags
        val outlierMap = afterOutlierTxList.associateBy { it.transactionId }
        val fullWithOutliers = filteredTxList.map { tx -> outlierMap[tx.transactionId] ?: tx }
        val finalTransactionMap = finalizedConstituents.associateBy { it.transactionId }
        val fullReportTx = fullWithOutliers.map { tx ->
            finalTransactionMap[tx.transactionId] ?: tx
        }

        return CalculationRun(
            runId = runId,
            timestampSydney = currentTime,
            datasetName = datasetName,
            methodologyConfig = config,
            status = calculationStatus,
            fixingRatePercent = roundedFixing,
            rawWeightedRatePercent = rawWeightedRate,
            simpleAverageRatePercent = simpleAverageRate,
            totalEligibleVolumeAudMillions = totalEligibleVolume,
            totalEligibleTransactionCount = totalEligibleCount,
            totalSubmittedTransactions = rawTransactions.size,
            excludedTransactionsCount = rawTransactions.size - totalEligibleCount,
            trimmedTransactionsCount = trimmedCount,
            trimmedVolumeAudMillions = trimmedVolume,
            rateDispersionStdDevBps = weightedStdDevBps,
            rateRangeBps = rangeBps,
            minRatePercent = minRate,
            maxRatePercent = maxRate,
            medianRatePercent = medianRate,
            iqrBps = iqrBps,
            hhiConcentrationIndex = hhi,
            warnings = warnings,
            isFallback = false,
            auditChecksum = checksum,
            constituentTransactions = fullReportTx
        )
    }

    private data class CalculationTuple(
        val rate: Double,
        val trimmedVolume: Double,
        val trimmedCount: Int,
        val constituents: List<FundingTransaction>
    )

    /**
     * Implements Method B: Robust trimmed-mean estimator.
     * Orders transactions by rate ascending, trims alpha/2 volume from lower tail and alpha/2 volume from upper tail.
     */
    private fun calculateTrimmedMean(
        eligibleTx: List<FundingTransaction>,
        trimPercent: Double
    ): CalculationTuple {
        val totalVolume = eligibleTx.sumOf { it.volumeAudMillions }
        val trimFraction = (trimPercent / 100.0).coerceIn(0.0, 0.45)
        val lowerCutoffVol = totalVolume * (trimFraction / 2.0)
        val upperCutoffVol = totalVolume * (1.0 - trimFraction / 2.0)

        val sortedTx = eligibleTx.sortedBy { it.ratePercent }
        var cumulativeVol = 0.0

        val retainedTx = mutableListOf<FundingTransaction>()
        var trimmedVol = 0.0
        var trimmedCount = 0

        for (tx in sortedTx) {
            val startVol = cumulativeVol
            val endVol = cumulativeVol + tx.volumeAudMillions
            cumulativeVol = endVol

            // Check if transaction falls into lower or upper tail
            val inLowerTail = startVol < lowerCutoffVol && sortedTx.size > 2
            val inUpperTail = endVol > upperCutoffVol && sortedTx.size > 2

            if (inLowerTail || inUpperTail) {
                // Trimmed from estimator
                trimmedVol += tx.volumeAudMillions
                trimmedCount++
                retainedTx.add(tx.copy(isTrimmed = true, exclusionReason = "METHOD_B_TRIMMED_TAIL"))
            } else {
                // Interior retained
                retainedTx.add(tx.copy(isTrimmed = false))
            }
        }

        val effectiveTrades = retainedTx.filter { !it.isTrimmed }
        val effectiveVolume = effectiveTrades.sumOf { it.volumeAudMillions }

        val rate = if (effectiveVolume > 0.0) {
            effectiveTrades.sumOf { it.volumeAudMillions * it.ratePercent } / effectiveVolume
        } else {
            eligibleTx.sumOf { it.volumeAudMillions * it.ratePercent } / totalVolume
        }

        return CalculationTuple(rate, trimmedVol, trimmedCount, retainedTx)
    }

    private fun detectAndFilterOutliers(
        eligibleTx: List<FundingTransaction>,
        config: MethodologyConfig
    ): Pair<List<FundingTransaction>, Int> {
        if (config.outlierMethod == OutlierMethod.NONE || eligibleTx.size < 4) {
            return Pair(eligibleTx, 0)
        }

        var outlierCount = 0
        val results = mutableListOf<FundingTransaction>()

        when (config.outlierMethod) {
            OutlierMethod.Z_SCORE -> {
                val mean = eligibleTx.map { it.ratePercent }.average()
                val variance = eligibleTx.map { (it.ratePercent - mean).pow(2) }.average()
                val stdDev = sqrt(variance)

                for (tx in eligibleTx) {
                    val zScore = if (stdDev > 0.00001) abs(tx.ratePercent - mean) / stdDev else 0.0
                    if (zScore > config.outlierThreshold) {
                        outlierCount++
                        results.add(
                            tx.copy(
                                isOutlier = true,
                                isEligible = false,
                                exclusionReason = "STATISTICAL_OUTLIER: Z-score ${String.format(Locale.US, "%.2f", zScore)} > ${config.outlierThreshold}"
                            )
                        )
                    } else {
                        results.add(tx)
                    }
                }
            }
            OutlierMethod.MAD -> {
                val sortedRates = eligibleTx.map { it.ratePercent }.sorted()
                val median = sortedRates[sortedRates.size / 2]
                val absDeviations = sortedRates.map { abs(it - median) }.sorted()
                val mad = absDeviations[absDeviations.size / 2]
                val threshold = 3.0 * (mad * 1.4826)

                for (tx in eligibleTx) {
                    if (threshold > 0.0001 && abs(tx.ratePercent - median) > threshold) {
                        outlierCount++
                        results.add(
                            tx.copy(
                                isOutlier = true,
                                isEligible = false,
                                exclusionReason = "OUTLIER_MAD: Deviation > 3×MAD"
                            )
                        )
                    } else {
                        results.add(tx)
                    }
                }
            }
            OutlierMethod.BPS_BAND -> {
                val sortedRates = eligibleTx.map { it.ratePercent }.sorted()
                val median = sortedRates[sortedRates.size / 2]
                val maxSpreadBps = 20.0 // 20 bps

                for (tx in eligibleTx) {
                    val spreadBps = abs(tx.ratePercent - median) * 100.0
                    if (spreadBps > maxSpreadBps) {
                        outlierCount++
                        results.add(
                            tx.copy(
                                isOutlier = true,
                                isEligible = false,
                                exclusionReason = "OUTLIER_BAND: Spread ${String.format(Locale.US, "%.1f", spreadBps)} bps > 20 bps"
                            )
                        )
                    } else {
                        results.add(tx)
                    }
                }
            }
            OutlierMethod.NONE -> {
                return Pair(eligibleTx, 0)
            }
        }

        return Pair(results, outlierCount)
    }

    private fun buildRunFailure(
        runId: String,
        timestamp: String,
        datasetName: String,
        config: MethodologyConfig,
        status: CalculationStatus,
        warning: String,
        allTransactions: List<FundingTransaction>,
        rawEligible: List<FundingTransaction>
    ): CalculationRun {
        val totalEligibleVolume = rawEligible.sumOf { it.volumeAudMillions }
        val rawWeightedRate = if (totalEligibleVolume > 0.0) {
            rawEligible.sumOf { it.volumeAudMillions * it.ratePercent } / totalEligibleVolume
        } else 0.0

        return CalculationRun(
            runId = runId,
            timestampSydney = timestamp,
            datasetName = datasetName,
            methodologyConfig = config,
            status = status,
            fixingRatePercent = null, // Explicit null - never fallback silently
            rawWeightedRatePercent = rawWeightedRate,
            simpleAverageRatePercent = rawEligible.map { it.ratePercent }.average().takeIf { !it.isNaN() } ?: 0.0,
            totalEligibleVolumeAudMillions = totalEligibleVolume,
            totalEligibleTransactionCount = rawEligible.size,
            totalSubmittedTransactions = allTransactions.size,
            excludedTransactionsCount = allTransactions.size - rawEligible.size,
            trimmedTransactionsCount = 0,
            trimmedVolumeAudMillions = 0.0,
            rateDispersionStdDevBps = 0.0,
            rateRangeBps = 0.0,
            minRatePercent = 0.0,
            maxRatePercent = 0.0,
            medianRatePercent = 0.0,
            iqrBps = 0.0,
            hhiConcentrationIndex = 0.0,
            warnings = listOf(warning),
            isFallback = true,
            auditChecksum = "FAIL-" + UUID.randomUUID().toString().take(8).uppercase(),
            constituentTransactions = allTransactions
        )
    }
}
