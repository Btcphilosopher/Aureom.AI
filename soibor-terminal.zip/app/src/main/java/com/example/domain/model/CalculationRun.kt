package com.example.domain.model

data class CalculationRun(
    val runId: String,
    val timestampSydney: String,
    val datasetName: String,
    val methodologyConfig: MethodologyConfig,
    val status: CalculationStatus,
    val fixingRatePercent: Double?,
    val rawWeightedRatePercent: Double,
    val simpleAverageRatePercent: Double,
    val totalEligibleVolumeAudMillions: Double,
    val totalEligibleTransactionCount: Int,
    val totalSubmittedTransactions: Int,
    val excludedTransactionsCount: Int,
    val trimmedTransactionsCount: Int,
    val trimmedVolumeAudMillions: Double,
    val rateDispersionStdDevBps: Double,
    val rateRangeBps: Double,
    val minRatePercent: Double,
    val maxRatePercent: Double,
    val medianRatePercent: Double,
    val iqrBps: Double,
    val hhiConcentrationIndex: Double,
    val warnings: List<String>,
    val isFallback: Boolean,
    val auditChecksum: String,
    val constituentTransactions: List<FundingTransaction> = emptyList()
)

enum class CalculationStatus(val label: String, val isSuccess: Boolean) {
    PUBLISHED("Calculated & Verified", true),
    INSUFFICIENT_VOLUME("Insufficient Aggregate Volume", false),
    INSUFFICIENT_TRANSACTIONS("Insufficient Trade Count", false),
    LOW_LIQUIDITY_WARNING("Published with Low Liquidity Flag", true),
    FALLBACK_APPLIED("Methodology Fallback Invoked", false),
    OUTLIER_FAILURE("Data Quality Rejection", false)
}
