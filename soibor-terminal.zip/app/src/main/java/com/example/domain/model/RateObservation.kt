package com.example.domain.model

data class RateObservation(
    val benchmarkId: String,
    val rateFamily: RateFamily,
    val tenor: String,
    val observationDate: String,
    val valuePercent: Double,
    val changeBps: Double,
    val unit: String = "% p.a.",
    val annualisationConvention: String = "Actual/365 AUD",
    val source: String,
    val sourcePublicationTimestamp: String?,
    val ingestionTimestamp: String,
    val status: DataStatus,
    val methodologyVersion: String? = null,
    val revisionIdentifier: String? = null,
    val volumeAudMillions: Double? = null,
    val transactionCount: Int? = null,
    val isExperimental: Boolean = false
)

data class BenchmarkDefinition(
    val benchmarkId: String,
    val name: String,
    val rateFamily: RateFamily,
    val tenor: String,
    val authoritativeSource: String,
    val officialUrl: String,
    val methodologySummary: String,
    val dayCountConvention: String = "Actual/365 AUD",
    val publicationTime: String,
    val isProposed: Boolean = false,
    val latestObservation: RateObservation? = null
)
