package com.example.domain.model

data class CurveNode(
    val tenor: String,
    val tenorDays: Int,
    val ratePercent: Double,
    val changeBps: Double,
    val instrumentType: String // "BBSW", "OIS"
)

data class YieldCurveSnapshot(
    val curveId: String,
    val curveName: String,
    val asOfDate: String,
    val source: String,
    val nodes: List<CurveNode>,
    val steepness3M1MBps: Double,
    val steepness6M1MBps: Double,
    val isModelDerived: Boolean = false
)

data class CompoundedRateResult(
    val tenorDays: Int,
    val startDate: String,
    val endDate: String,
    val annualizedRatePercent: Double,
    val observationCount: Int,
    val formulaUsed: String = "∏(1 + r_i * d_i / 365) - 1 * (365 / D)",
    val isModelEstimate: Boolean = true
)
