package com.example.data

import com.example.domain.engine.BenchmarkEngine
import com.example.domain.engine.QuantitativeAnalytics
import com.example.domain.engine.ScenarioEngine
import com.example.domain.model.AuditEvent
import com.example.domain.model.BenchmarkDefinition
import com.example.domain.model.CalculationRun
import com.example.domain.model.CurveNode
import com.example.domain.model.DataQualityReport
import com.example.domain.model.DataStatus
import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.RateFamily
import com.example.domain.model.RateObservation
import com.example.domain.model.ScenarioDefinition
import com.example.domain.model.ScenarioResult
import com.example.domain.model.SensitivityPoint
import com.example.domain.model.SpreadMetric
import com.example.domain.model.UserRole
import com.example.domain.model.YieldCurveSnapshot
import java.math.BigDecimal
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BenchmarkRepository {

    private val _currentUserRole = MutableStateFlow(UserRole.ANALYST)
    val currentUserRole: StateFlow<UserRole> = _currentUserRole.asStateFlow()

    private val _activeMethodology = MutableStateFlow(MethodologyConfig())
    val activeMethodology: StateFlow<MethodologyConfig> = _activeMethodology.asStateFlow()

    private val _latestCalculationRun = MutableStateFlow<CalculationRun?>(null)
    val latestCalculationRun: StateFlow<CalculationRun?> = _latestCalculationRun.asStateFlow()

    private val _calculationHistory = MutableStateFlow<List<CalculationRun>>(emptyList())
    val calculationHistory: StateFlow<List<CalculationRun>> = _calculationHistory.asStateFlow()

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents.asStateFlow()

    private val _activeDatasetName = MutableStateFlow("Baseline Interbank Session")
    val activeDatasetName: StateFlow<String> = _activeDatasetName.asStateFlow()

    private val _currentTransactions = MutableStateFlow<List<FundingTransaction>>(emptyList())
    val currentTransactions: StateFlow<List<FundingTransaction>> = _currentTransactions.asStateFlow()

    init {
        // Initialize with default datasets and baseline calculation
        val initialTx = getDatasetByName("Baseline Interbank Session")
        _currentTransactions.value = initialTx
        val baselineRun = BenchmarkEngine.calculateBenchmark(initialTx, _activeMethodology.value, "Baseline Interbank Session")
        _latestCalculationRun.value = baselineRun
        _calculationHistory.value = listOf(baselineRun)

        addAuditEvent(
            actionType = "SYSTEM_INITIALIZATION",
            summary = "SOIBOR Terminal Engine Initialized",
            details = "Initialized baseline Australian Dollar money market datasets. Default role set to Analyst.",
            role = UserRole.ADMIN
        )
    }

    fun setUserRole(role: UserRole) {
        _currentUserRole.value = role
        addAuditEvent(
            actionType = "ROLE_CHANGED",
            summary = "User role switched to ${role.label}",
            details = "Permissions updated. Methodology edits ${if (role != UserRole.ANALYST) "enabled" else "locked"}.",
            role = role
        )
    }

    fun updateMethodology(config: MethodologyConfig) {
        _activeMethodology.value = config
        // Re-execute benchmark calculation with new methodology
        val run = BenchmarkEngine.calculateBenchmark(_currentTransactions.value, config, _activeDatasetName.value)
        _latestCalculationRun.value = run
        _calculationHistory.value = listOf(run) + _calculationHistory.value.take(20)

        addAuditEvent(
            actionType = "METHODOLOGY_UPDATED",
            summary = "Benchmark methodology modified: ${config.methodName.title}",
            details = "Version: ${config.versionId}, Trim: ${config.trimPercentage}%, MinVol: A$${config.minAggregateVolumeAudMillions}M, Outlier: ${config.outlierMethod.label}",
            role = _currentUserRole.value
        )
    }

    fun selectDataset(datasetName: String) {
        _activeDatasetName.value = datasetName
        val tx = getDatasetByName(datasetName)
        _currentTransactions.value = tx
        val run = BenchmarkEngine.calculateBenchmark(tx, _activeMethodology.value, datasetName)
        _latestCalculationRun.value = run
        _calculationHistory.value = listOf(run) + _calculationHistory.value.take(20)

        addAuditEvent(
            actionType = "DATASET_LOADED",
            summary = "Loaded dataset '$datasetName'",
            details = "Total transactions: ${tx.size}. Re-executed benchmark calculation.",
            role = _currentUserRole.value
        )
    }

    fun executeManualCalculation(): CalculationRun {
        val run = BenchmarkEngine.calculateBenchmark(_currentTransactions.value, _activeMethodology.value, _activeDatasetName.value)
        _latestCalculationRun.value = run
        _calculationHistory.value = listOf(run) + _calculationHistory.value.take(20)

        addAuditEvent(
            actionType = "CALCULATION_RUN",
            summary = "Calculation executed for run ID ${run.runId}",
            details = "Fixing: ${run.fixingRatePercent ?: "INSUFFICIENT_DATA"}%, Status: ${run.status.label}, Eligible Vol: A$${run.totalEligibleVolumeAudMillions}M",
            role = _currentUserRole.value
        )
        return run
    }

    fun addAuditEvent(actionType: String, summary: String, details: String, role: UserRole = _currentUserRole.value) {
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'AEDT'", Locale.US).format(Date())
        val eventId = "AUD-" + UUID.randomUUID().toString().take(8).uppercase()
        val checksum = "CHK-" + Integer.toHexString("$eventId|$timestamp|$summary".hashCode()).uppercase()

        val event = AuditEvent(
            eventId = eventId,
            timestampSydney = timestamp,
            userRole = role,
            actionType = actionType,
            summary = summary,
            details = details,
            checksum = checksum
        )
        _auditEvents.value = listOf(event) + _auditEvents.value
    }

    fun getBenchmarkDefinitions(): List<BenchmarkDefinition> {
        val soiborRun = _latestCalculationRun.value
        val soiborObs = RateObservation(
            benchmarkId = "SOIBOR_ON",
            rateFamily = RateFamily.SOIBOR,
            tenor = "O/N",
            observationDate = "2026-10-09",
            valuePercent = soiborRun?.fixingRatePercent ?: 4.3520,
            changeBps = 0.2,
            unit = "% p.a.",
            annualisationConvention = "Actual/365 AUD",
            source = "Sydney Benchmark Methodology Lab",
            sourcePublicationTimestamp = soiborRun?.timestampSydney ?: "16:45:00 AEDT",
            ingestionTimestamp = "16:45:02 AEDT",
            status = if (soiborRun?.fixingRatePercent != null) DataStatus.ESTIMATED else DataStatus.MISSING,
            methodologyVersion = _activeMethodology.value.versionId,
            revisionIdentifier = "REV-01",
            volumeAudMillions = soiborRun?.totalEligibleVolumeAudMillions ?: 4350.0,
            transactionCount = soiborRun?.totalEligibleTransactionCount ?: 16,
            isExperimental = true
        )

        val aoniaObs = getLatestAoniaObservation()
        val bbswObs = getLatestBbswObservations()

        return listOf(
            BenchmarkDefinition(
                benchmarkId = "SOIBOR_ON",
                name = "SOIBOR (Sydney Overnight Interbank Offered Rate)",
                rateFamily = RateFamily.SOIBOR,
                tenor = "O/N",
                authoritativeSource = "Sydney Benchmark Methodology Lab (Proposed)",
                officialUrl = "https://soibor.local/methodology",
                methodologySummary = "Transaction-weighted overnight unsecured interbank deposits with outlier & volume trimming.",
                publicationTime = "17:00 AEST / AEDT",
                isProposed = true,
                latestObservation = soiborObs
            ),
            BenchmarkDefinition(
                benchmarkId = "AONIA_ON",
                name = "AONIA (Australian Interbank Cash Rate)",
                rateFamily = RateFamily.AONIA,
                tenor = "O/N",
                authoritativeSource = "Reserve Bank of Australia (RBA)",
                officialUrl = "https://www.rba.gov.au/mkt-operations/resources/cash-rate-methodology/overview.html",
                methodologySummary = "Official Australian Cash Rate benchmark administered by RBA based on interbank Cash Market transactions.",
                publicationTime = "09:00 AEST / AEDT (T+1)",
                isProposed = false,
                latestObservation = aoniaObs
            ),
            BenchmarkDefinition(
                benchmarkId = "BBSW_3M",
                name = "BBSW 3-Month (Bank Bill Swap Rate)",
                rateFamily = RateFamily.BBSW,
                tenor = "3M",
                authoritativeSource = "ASX Benchmarks / Authorized Providers",
                officialUrl = "https://www.asx.com.au/connectivity-and-data/information-services/benchmarks/benchmark-data",
                methodologySummary = "Primary interest rate benchmark for Australian dollar credit, administered by ASX Benchmarks.",
                publicationTime = "10:15 AEST / AEDT",
                isProposed = false,
                latestObservation = bbswObs.find { it.tenor == "3M" }
            )
        )
    }

    fun getLatestAoniaObservation(): RateObservation {
        return RateObservation(
            benchmarkId = "AONIA_ON",
            rateFamily = RateFamily.AONIA,
            tenor = "O/N",
            observationDate = "2026-10-09",
            valuePercent = 4.3500,
            changeBps = 0.0,
            unit = "% p.a.",
            annualisationConvention = "Actual/365 AUD",
            source = "Reserve Bank of Australia (RBA)",
            sourcePublicationTimestamp = "2026-10-09 09:00:14 AEDT",
            ingestionTimestamp = "2026-10-09 09:02:00 AEDT",
            status = DataStatus.OBSERVED,
            methodologyVersion = "RBA-CR-2020",
            volumeAudMillions = 5120.0,
            transactionCount = 22,
            isExperimental = false
        )
    }

    fun getRbaTargetObservation(): RateObservation {
        return RateObservation(
            benchmarkId = "RBA_TARGET",
            rateFamily = RateFamily.AONIA,
            tenor = "Target",
            observationDate = "2026-10-09",
            valuePercent = 4.3500,
            changeBps = 0.0,
            unit = "% p.a.",
            annualisationConvention = "Actual/365 AUD",
            source = "Reserve Bank of Australia (Board Decision)",
            sourcePublicationTimestamp = "2026-10-06 14:30:00 AEDT",
            ingestionTimestamp = "2026-10-06 14:30:05 AEDT",
            status = DataStatus.OBSERVED,
            methodologyVersion = "RBA-TARGET",
            isExperimental = false
        )
    }

    fun getLatestBbswObservations(): List<RateObservation> {
        val tenors = listOf(
            Triple("1M", 4.3820, 0.4),
            Triple("2M", 4.4150, 0.5),
            Triple("3M", 4.4680, 0.8),
            Triple("4M", 4.5020, 0.6),
            Triple("5M", 4.5290, 0.4),
            Triple("6M", 4.5610, 0.9)
        )
        return tenors.map { (tenor, rate, chg) ->
            RateObservation(
                benchmarkId = "BBSW_$tenor",
                rateFamily = RateFamily.BBSW,
                tenor = tenor,
                observationDate = "2026-10-09",
                valuePercent = rate,
                changeBps = chg,
                unit = "% p.a.",
                annualisationConvention = "Actual/365 AUD",
                source = "ASX Benchmark Data (Authorized License)",
                sourcePublicationTimestamp = "2026-10-09 10:15:32 AEDT",
                ingestionTimestamp = "2026-10-09 10:16:01 AEDT",
                status = DataStatus.OBSERVED,
                methodologyVersion = "ASX-BBSW-v3",
                isExperimental = false
            )
        }
    }

    fun getHistoricalRatesSeries(timeWindowDays: Int): List<HistoricalDataPoint> {
        // Generates consistent multi-series historical points for charts
        val points = mutableListOf<HistoricalDataPoint>()
        val baseDate = Date(System.currentTimeMillis() - timeWindowDays * 86400000L)
        val sdf = SimpleDateFormat("dd MMM", Locale.US)

        for (i in 0 until timeWindowDays) {
            val d = Date(baseDate.time + i * 86400000L)
            val dateLabel = sdf.format(d)
            // Realistic cyclical variation in AUD money market around 4.35%
            val dayFraction = i.toDouble() / timeWindowDays.toDouble()
            val noise = kotlin.math.sin(dayFraction * 12.0) * 0.02
            val soiborVal = 4.350 + noise + (if (i % 7 == 0) 0.015 else 0.003) // month-end bumps
            val aoniaVal = 4.350 + (if (i > timeWindowDays - 5) 0.0 else (noise * 0.4))
            val targetVal = 4.350
            val bbsw3mVal = 4.460 + (noise * 0.8) + (dayFraction * 0.02)

            points.add(
                HistoricalDataPoint(
                    dateLabel = dateLabel,
                    soiborPercent = BigDecimal(soiborVal).setScale(3, java.math.RoundingMode.HALF_UP).toDouble(),
                    aoniaPercent = BigDecimal(aoniaVal).setScale(3, java.math.RoundingMode.HALF_UP).toDouble(),
                    rbaTargetPercent = targetVal,
                    bbsw3MPercent = BigDecimal(bbsw3mVal).setScale(3, java.math.RoundingMode.HALF_UP).toDouble(),
                    hasRbaEvent = (i == timeWindowDays / 2)
                )
            )
        }
        return points
    }

    fun getYieldCurveSnapshot(): YieldCurveSnapshot {
        val bbswObs = getLatestBbswObservations()
        val nodes = listOf(
            CurveNode("1M", 30, bbswObs[0].valuePercent, bbswObs[0].changeBps, "BBSW"),
            CurveNode("2M", 60, bbswObs[1].valuePercent, bbswObs[1].changeBps, "BBSW"),
            CurveNode("3M", 90, bbswObs[2].valuePercent, bbswObs[2].changeBps, "BBSW"),
            CurveNode("4M", 120, bbswObs[3].valuePercent, bbswObs[3].changeBps, "BBSW"),
            CurveNode("5M", 150, bbswObs[4].valuePercent, bbswObs[4].changeBps, "BBSW"),
            CurveNode("6M", 180, bbswObs[5].valuePercent, bbswObs[5].changeBps, "BBSW")
        )

        val steepness3M1M = (nodes[2].ratePercent - nodes[0].ratePercent) * 100.0
        val steepness6M1M = (nodes[5].ratePercent - nodes[0].ratePercent) * 100.0

        return YieldCurveSnapshot(
            curveId = "BBSW_TERM_STRUCTURE",
            curveName = "BBSW Benchmark Term Curve",
            asOfDate = "2026-10-09",
            source = "ASX Benchmarks",
            nodes = nodes,
            steepness3M1MBps = steepness3M1M,
            steepness6M1MBps = steepness6M1M,
            isModelDerived = false
        )
    }

    fun getAudOisCurve(): YieldCurveSnapshot {
        val nodes = listOf(
            CurveNode("1M", 30, 4.350, 0.0, "OIS"),
            CurveNode("3M", 90, 4.340, -0.5, "OIS"),
            CurveNode("6M", 180, 4.280, -1.2, "OIS"),
            CurveNode("1Y", 365, 4.150, -2.0, "OIS"),
            CurveNode("2Y", 730, 3.980, -2.5, "OIS")
        )
        return YieldCurveSnapshot(
            curveId = "AUD_OIS_CURVE",
            curveName = "AUD Overnight Indexed Swap (OIS) Curve",
            asOfDate = "2026-10-09",
            source = "Authorized Broker Consensus Feed",
            nodes = nodes,
            steepness3M1MBps = -1.0,
            steepness6M1MBps = -7.0,
            isModelDerived = true
        )
    }

    fun getSpreads(): List<SpreadMetric> {
        val soiborObs = getBenchmarkDefinitions().first { it.benchmarkId == "SOIBOR_ON" }.latestObservation
        val aoniaObs = getLatestAoniaObservation()
        val rbaTargetObs = getRbaTargetObservation()
        val bbswObs = getLatestBbswObservations()
        return QuantitativeAnalytics.calculateSpreads(soiborObs, aoniaObs, rbaTargetObs, bbswObs)
    }

    fun getTrimmingSensitivity(): List<SensitivityPoint> {
        return QuantitativeAnalytics.computeTrimmingSensitivity(_currentTransactions.value, _activeMethodology.value)
    }

    fun runScenario(scenario: ScenarioDefinition): ScenarioResult {
        val result = ScenarioEngine.runScenario(_currentTransactions.value, _activeMethodology.value, scenario)
        addAuditEvent(
            actionType = "SCENARIO_EXECUTED",
            summary = "Executed Scenario '${scenario.name}'",
            details = "Simulated Rate: ${result.simulatedRatePercent}%, Shift: ${result.spreadToBaselineBps} bps, Volume: A$${result.simulatedVolumeAudMillions}M",
            role = _currentUserRole.value
        )
        return result
    }

    fun getDataQualityReport(): DataQualityReport {
        val transactions = _currentTransactions.value
        val duplicates = transactions.groupBy { it.transactionId }.filter { it.value.size > 1 }.size
        val outliers = transactions.count { it.isOutlier }
        val ineligibleCurrency = transactions.count { it.currency != "AUD" }
        val ineligibleTenor = transactions.count { it.tenor != "O/N" }

        return DataQualityReport(
            reportId = "DQR-20261009-01",
            reportDateSydney = "2026-10-09 17:00 AEDT",
            sourceAoniaHealth = "OPERATIONAL (RBA Feed Latency: 12ms)",
            sourceBbswHealth = "OPERATIONAL (ASX Feed Latency: 18ms)",
            syntheticFeedHealth = "VALIDATED & ISOLATED",
            duplicateTradesDetected = duplicates,
            currencyViolationsDetected = ineligibleCurrency,
            tenorViolationsDetected = ineligibleTenor,
            statisticalOutliersCount = outliers,
            missingDataDaysCount = 0,
            statusSummary = "ALL SYSTEMS COMPLIANT — BENCHMARK INTEGRITY VERIFIED",
            warnings = listOf(
                "Notice: SOIBOR methodology remains experimental and proposed; not recognized as official ASIC/IOSCO benchmark fixing.",
                "Market data feeds for AONIA and BBSW are sourced from authorized delayed endpoints."
            )
        )
    }

    fun getAvailableDatasets(): List<String> {
        return listOf(
            "Baseline Interbank Session",
            "Month-End Liquidity Squeeze",
            "Outlier Contamination Stress",
            "Low Liquidity / Dry Market"
        )
    }

    private fun getDatasetByName(name: String): List<FundingTransaction> {
        return when (name) {
            "Month-End Liquidity Squeeze" -> generateMonthEndDataset()
            "Outlier Contamination Stress" -> generateOutlierContaminationDataset()
            "Low Liquidity / Dry Market" -> generateLowLiquidityDataset()
            else -> generateBaselineDataset()
        }
    }

    private fun generateBaselineDataset(): List<FundingTransaction> {
        return listOf(
            FundingTransaction("TX-2601", "08:45:12 AEDT", 4.350, 450.0, "Commonwealth Bank of Australia", "National Australia Bank"),
            FundingTransaction("TX-2602", "09:12:44 AEDT", 4.355, 300.0, "Westpac Banking Corporation", "ANZ Banking Group"),
            FundingTransaction("TX-2603", "10:04:19 AEDT", 4.345, 550.0, "Macquarie Bank Limited", "Commonwealth Bank of Australia"),
            FundingTransaction("TX-2604", "11:22:05 AEDT", 4.350, 600.0, "National Australia Bank", "Westpac Banking Corporation"),
            FundingTransaction("TX-2605", "12:15:33 AEDT", 4.360, 250.0, "Bendigo & Adelaide Bank", "Macquarie Bank Limited"),
            FundingTransaction("TX-2606", "13:40:11 AEDT", 4.350, 400.0, "ANZ Banking Group", "Commonwealth Bank of Australia"),
            FundingTransaction("TX-2607", "14:18:29 AEDT", 4.355, 350.0, "Bank of Queensland", "Westpac Banking Corporation"),
            FundingTransaction("TX-2608", "14:55:02 AEDT", 4.340, 500.0, "Westpac Banking Corporation", "National Australia Bank"),
            FundingTransaction("TX-2609", "15:20:47 AEDT", 4.355, 280.0, "Suncorp Bank", "ANZ Banking Group"),
            FundingTransaction("TX-2610", "15:45:10 AEDT", 4.350, 320.0, "Commonwealth Bank of Australia", "Bendigo & Adelaide Bank"),
            FundingTransaction("TX-2611", "16:05:38 AEDT", 4.365, 180.0, "AMP Bank", "Macquarie Bank Limited"),
            FundingTransaction("TX-2612", "16:22:15 AEDT", 4.350, 220.0, "National Australia Bank", "Commonwealth Bank of Australia")
        )
    }

    private fun generateMonthEndDataset(): List<FundingTransaction> {
        return listOf(
            FundingTransaction("ME-401", "08:30:10 AEDT", 4.370, 750.0, "Commonwealth Bank of Australia", "National Australia Bank"),
            FundingTransaction("ME-402", "09:15:22 AEDT", 4.385, 600.0, "Westpac Banking Corporation", "ANZ Banking Group"),
            FundingTransaction("ME-403", "10:10:05 AEDT", 4.375, 800.0, "Macquarie Bank Limited", "Commonwealth Bank of Australia"),
            FundingTransaction("ME-404", "11:45:30 AEDT", 4.390, 450.0, "Bendigo & Adelaide Bank", "Westpac Banking Corporation"),
            FundingTransaction("ME-405", "13:20:18 AEDT", 4.380, 950.0, "National Australia Bank", "Macquarie Bank Limited"),
            FundingTransaction("ME-406", "14:50:41 AEDT", 4.395, 380.0, "Bank of Queensland", "Commonwealth Bank of Australia"),
            FundingTransaction("ME-407", "15:35:12 AEDT", 4.410, 250.0, "AMP Bank", "National Australia Bank"),
            FundingTransaction("ME-408", "16:15:00 AEDT", 4.385, 520.0, "ANZ Banking Group", "Westpac Banking Corporation")
        )
    }

    private fun generateOutlierContaminationDataset(): List<FundingTransaction> {
        return listOf(
            FundingTransaction("OT-801", "09:00:00 AEDT", 4.350, 400.0, "Commonwealth Bank of Australia", "National Australia Bank"),
            FundingTransaction("OT-802", "10:15:00 AEDT", 4.355, 350.0, "Westpac Banking Corporation", "ANZ Banking Group"),
            FundingTransaction("OT-803", "11:30:00 AEDT", 4.345, 500.0, "National Australia Bank", "Macquarie Bank Limited"),
            FundingTransaction("OT-804", "13:00:00 AEDT", 4.850, 30.0, "Tier 3 Foreign Branch", "Macquarie Bank Limited"), // Intentional extreme outlier rate (+50 bps fat-finger)
            FundingTransaction("OT-805", "14:00:00 AEDT", 3.900, 25.0, "Distressed Institution Z", "Westpac Banking Corporation"), // Intentional low outlier
            FundingTransaction("OT-806", "14:45:00 AEDT", 4.350, 450.0, "ANZ Banking Group", "Commonwealth Bank of Australia"),
            FundingTransaction("OT-807", "15:30:00 AEDT", 4.352, 600.0, "Commonwealth Bank of Australia", "National Australia Bank"),
            FundingTransaction("OT-807", "15:30:00 AEDT", 4.352, 600.0, "Commonwealth Bank of Australia", "National Australia Bank"), // Duplicate trade ID
            FundingTransaction("OT-808", "16:10:00 AEDT", 4.350, 300.0, "Macquarie Bank Limited", "ANZ Banking Group"),
            FundingTransaction("OT-809", "16:20:00 AEDT", 4.350, 200.0, "US Dollar Desk", "ANZ Banking Group", currency = "USD") // Currency violation
        )
    }

    private fun generateLowLiquidityDataset(): List<FundingTransaction> {
        return listOf(
            FundingTransaction("LL-101", "10:00:00 AEDT", 4.350, 120.0, "Bendigo & Adelaide Bank", "Macquarie Bank Limited"),
            FundingTransaction("LL-102", "14:30:00 AEDT", 4.355, 150.0, "Bank of Queensland", "Westpac Banking Corporation")
            // Only 2 trades and $270M total volume - will trigger insufficient volume/trade count threshold!
        )
    }
}

data class HistoricalDataPoint(
    val dateLabel: String,
    val soiborPercent: Double,
    val aoniaPercent: Double,
    val rbaTargetPercent: Double,
    val bbsw3MPercent: Double,
    val hasRbaEvent: Boolean = false
)
