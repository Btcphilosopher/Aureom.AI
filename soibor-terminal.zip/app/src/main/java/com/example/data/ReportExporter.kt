package com.example.data

import com.example.domain.model.CalculationRun
import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.SpreadMetric
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {

    fun generateInstitutionalReport(
        run: CalculationRun?,
        config: MethodologyConfig,
        spreads: List<SpreadMetric>,
        transactions: List<FundingTransaction>
    ): String {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'AEDT'", Locale.US).format(Date())
        val builder = StringBuilder()

        builder.appendLine("================================================================================")
        builder.appendLine("                     SOIBOR BENCHMARK RESEARCH REPORT")
        builder.appendLine("       SYDNEY OVERNIGHT INTERBANK OFFERED RATE (PROPOSED BENCHMARK)")
        builder.appendLine("================================================================================")
        builder.appendLine("Report Generated     : $now")
        builder.appendLine("Jurisdiction         : Commonwealth of Australia (Sydney Market Convention)")
        builder.appendLine("Currency / Day Count : AUD / Actual/365")
        builder.appendLine("Benchmark Status     : PROPOSED / EXPERIMENTAL RESEARCH BENCHMARK")
        builder.appendLine("Regulatory Status    : NOT AN ASIC-LICENSED ADMINISTRATOR NOR IOSCO VERIFIED")
        builder.appendLine("Environment          : DEMO DATASET — SIMULATED & ISOLATED ENVIRONMENT")
        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine("1. EXECUTIVE FIXING SUMMARY")
        builder.appendLine("--------------------------------------------------------------------------------")
        if (run != null) {
            builder.appendLine("Calculation Run ID   : ${run.runId}")
            builder.appendLine("Fixing Result        : ${run.fixingRatePercent?.let { "$it % p.a." } ?: "INSUFFICIENT DATA / UNPUBLISHED"}")
            builder.appendLine("Calculation Status   : ${run.status.label}")
            builder.appendLine("Methodology Version  : ${config.versionId}")
            builder.appendLine("Methodology Type     : ${config.methodName.title}")
            builder.appendLine("Calculation Timestamp: ${run.timestampSydney}")
            builder.appendLine("Audit Checksum       : ${run.auditChecksum}")
            builder.appendLine("Eligible Volume      : A$ ${String.format(Locale.US, "%,.1f", run.totalEligibleVolumeAudMillions)} Million")
            builder.appendLine("Eligible Trade Count : ${run.totalEligibleTransactionCount}")
            builder.appendLine("Trimmed Volume       : A$ ${String.format(Locale.US, "%,.1f", run.trimmedVolumeAudMillions)} Million (${run.trimmedTransactionsCount} trades)")
            builder.appendLine("Weighted Rate Disp.  : ${String.format(Locale.US, "%.2f", run.rateDispersionStdDevBps)} bps (StdDev)")
            builder.appendLine("Rate Range           : ${String.format(Locale.US, "%.2f", run.rateRangeBps)} bps (${run.minRatePercent}% - ${run.maxRatePercent}%)")
            builder.appendLine("Interquartile Range  : ${String.format(Locale.US, "%.2f", run.iqrBps)} bps")
            builder.appendLine("HHI Concentration    : ${String.format(Locale.US, "%.0f", run.hhiConcentrationIndex)}")
        } else {
            builder.appendLine("No active calculation run available.")
        }

        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine("2. METHODOLOGY CONFIGURATION")
        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine("Formula              : ${config.methodName.formula}")
        builder.appendLine("Trimming Parameter   : ${config.trimPercentage}%")
        builder.appendLine("Min Aggregate Volume : A$ ${config.minAggregateVolumeAudMillions}M")
        builder.appendLine("Min Transaction Count: ${config.minTransactionCount}")
        builder.appendLine("Outlier Method       : ${config.outlierMethod.label}")
        builder.appendLine("Precision Decimals   : ${config.publicationPrecisionDecimals} (Rounding: HALF_UP)")
        builder.appendLine("Allowed Tenors       : ${config.allowedTenors.joinToString(", ")}")
        builder.appendLine("Allowed Currencies   : ${config.allowedCurrencies.joinToString(", ")}")
        builder.appendLine("Publication Cut-off  : ${config.publicationCutoffTimeSydney}")

        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine("3. RELATIVE SPREAD ANALYTICS (BASIS POINTS)")
        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine(String.format("%-28s | %-12s | %-10s | %-12s", "SPREAD PAIR", "CURRENT (bps)", "DoD (bps)", "30D MEAN"))
        builder.appendLine("--------------------------------------------------------------------------------")
        for (sp in spreads) {
            builder.appendLine(
                String.format(
                    "%-28s | %12.2f | %10.2f | %12.2f",
                    "${sp.legA} vs ${sp.legB}",
                    sp.currentSpreadBps,
                    sp.changeDayOnDayBps,
                    sp.rollingMean30dBps
                )
            )
        }

        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine("4. DATA QUALITY & INTEGRITY WARNINGS")
        builder.appendLine("--------------------------------------------------------------------------------")
        if (run?.warnings.isNullOrEmpty()) {
            builder.appendLine("No anomalies or threshold exceptions detected.")
        } else {
            run?.warnings?.forEach { w -> builder.appendLine("WARNING: $w") }
        }

        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine("5. CONSTITUENT TRANSACTIONS SUMMARY (Top Blotter Entries)")
        builder.appendLine("--------------------------------------------------------------------------------")
        builder.appendLine(String.format("%-10s | %-12s | %-8s | %-12s | %-10s", "TRADE ID", "RATE (%)", "VOL (AUD M)", "BORROWER", "STATUS"))
        builder.appendLine("--------------------------------------------------------------------------------")
        transactions.take(15).forEach { tx ->
            val status = when {
                !tx.isEligible -> "EXCLUDED"
                tx.isTrimmed -> "TRIMMED"
                tx.isOutlier -> "OUTLIER"
                else -> "ELIGIBLE"
            }
            builder.appendLine(
                String.format(
                    "%-10s | %12.4f | %8.1f | %-12s | %-10s",
                    tx.transactionId,
                    tx.ratePercent,
                    tx.volumeAudMillions,
                    tx.counterpartyBorrower.take(12),
                    status
                )
            )
        }

        builder.appendLine("================================================================================")
        builder.appendLine("DISCLOSURE: Generated by SOIBOR Terminal. All rates are research simulations.")
        builder.appendLine("Official Australian Cash Rate (AONIA) remains administered exclusively by RBA.")
        builder.appendLine("================================================================================")

        return builder.toString()
    }

    fun exportTransactionsCsv(transactions: List<FundingTransaction>): String {
        val sb = StringBuilder()
        sb.appendLine("transaction_id,timestamp_sydney,rate_percent,volume_aud_millions,borrower,lender,tenor,currency,is_eligible,exclusion_reason,is_outlier,is_trimmed")
        for (t in transactions) {
            sb.appendLine("${t.transactionId},\"${t.tradeTimestamp}\",${t.ratePercent},${t.volumeAudMillions},\"${t.counterpartyBorrower}\",\"${t.counterpartyLender}\",${t.tenor},${t.currency},${t.isEligible},\"${t.exclusionReason ?: ""}\",${t.isOutlier},${t.isTrimmed}")
        }
        return sb.toString()
    }

    fun exportRatesJson(run: CalculationRun?, spreads: List<SpreadMetric>): String {
        return """
        {
          "report_metadata": {
            "title": "SOIBOR Research Benchmark Run",
            "jurisdiction": "AUD",
            "convention": "Actual/365",
            "disclaimer": "SIMULATED / RESEARCH ENVIRONMENT - NOT OFFICIAL MARKET DATA"
          },
          "calculation_run": {
            "run_id": "${run?.runId ?: ""}",
            "fixing_rate_percent": ${run?.fixingRatePercent ?: "null"},
            "status": "${run?.status?.name ?: ""}",
            "eligible_volume_aud_millions": ${run?.totalEligibleVolumeAudMillions ?: 0.0},
            "eligible_transaction_count": ${run?.totalEligibleTransactionCount ?: 0},
            "checksum": "${run?.auditChecksum ?: ""}"
          },
          "spreads": [
            ${spreads.joinToString(",\n            ") { """{"id":"${it.spreadId}","spread_bps":${it.currentSpreadBps},"is_experimental":${it.isExperimental}}""" }}
          ]
        }
        """.trimIndent()
    }
}
