package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.BenchmarkCard
import com.example.ui.components.FinancialLineChart
import com.example.ui.components.TransactionBlotterTable
import com.example.ui.theme.AoniaGold
import com.example.ui.theme.BbswPurple
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val benchmarks = viewModel.getBenchmarkDefinitions()
    val latestRun by viewModel.latestCalculationRun.collectAsState()
    val transactions by viewModel.currentTransactions.collectAsState()
    val selectedWindow by viewModel.selectedTimeWindow.collectAsState()
    val historicalRates by viewModel.historicalRates.collectAsState()

    val soiborDef = benchmarks.find { it.benchmarkId == "SOIBOR_ON" }
    val aoniaDef = benchmarks.find { it.benchmarkId == "AONIA_ON" }
    val bbswDef = benchmarks.find { it.benchmarkId == "BBSW_3M" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Benchmark Overview Grid (SOIBOR, AONIA, BBSW 3M)
        Text(
            text = "RATE BENCHMARK OVERVIEW",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = LimestoneMuted
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BenchmarkCard(
                title = "SOIBOR",
                tenor = "O/N",
                observation = soiborDef?.latestObservation,
                sourceLabel = "Methodology Lab (Simulated)",
                accentColor = SoiborCyan,
                methodologyNote = "Proposed weighted rate | v1.2.0",
                modifier = Modifier.weight(1f)
            )

            BenchmarkCard(
                title = "AONIA",
                tenor = "O/N",
                observation = aoniaDef?.latestObservation,
                sourceLabel = "Reserve Bank of Australia (Official)",
                accentColor = AoniaGold,
                methodologyNote = "Official Cash Rate benchmark",
                modifier = Modifier.weight(1f)
            )
        }

        BenchmarkCard(
            title = "BBSW",
            tenor = "3-MONTH",
            observation = bbswDef?.latestObservation,
            sourceLabel = "ASX Benchmarks (Authorized Feed)",
            accentColor = BbswPurple,
            methodologyNote = "Bank Bill Swap Rate | 3M Prime Bank Paper",
            modifier = Modifier.fillMaxWidth()
        )

        // Section 2: Historical Market Rates Interactive Chart
        FinancialLineChart(
            dataPoints = historicalRates,
            selectedWindow = selectedWindow,
            onWindowSelected = { viewModel.setTimeWindow(it) },
            modifier = Modifier.fillMaxWidth()
        )

        // Section 3: Funding Conditions & Dispersion Diagnostics
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Assessment,
                            contentDescription = "Funding Diagnostics",
                            tint = SoiborCyan,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "INTERBANK FUNDING CONDITIONS & DISPERSION",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(TerminalGreen.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                            .border(1.dp, TerminalGreen.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "LIQUIDITY NORMAL",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TerminalGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Metric Grid (2 columns x 2 rows)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricBox(
                        label = "AGGREGATE ELIGIBLE VOLUME",
                        value = "A$ ${String.format(Locale.US, "%,.1f", latestRun?.totalEligibleVolumeAudMillions ?: 4350.0)}M",
                        subValue = "Min Threshold: A$ 500M",
                        modifier = Modifier.weight(1f)
                    )

                    MetricBox(
                        label = "ELIGIBLE TRADES COUNT",
                        value = "${latestRun?.totalEligibleTransactionCount ?: 12} trades",
                        subValue = "Min Count: 5 trades",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricBox(
                        label = "WEIGHTED RATE DISPERSION",
                        value = "${String.format(Locale.US, "%.2f", latestRun?.rateDispersionStdDevBps ?: 1.45)} bps",
                        subValue = "IQR: ${String.format(Locale.US, "%.1f", latestRun?.iqrBps ?: 1.0)} bps",
                        modifier = Modifier.weight(1f)
                    )

                    MetricBox(
                        label = "COUNTERPARTY CONCENTRATION",
                        value = "HHI: ${String.format(Locale.US, "%.0f", latestRun?.hhiConcentrationIndex ?: 1820.0)}",
                        subValue = "Moderate concentration",
                        modifier = Modifier.weight(1f)
                    )
                }

                if (latestRun?.warnings?.isNotEmpty() == true) {
                    Spacer(modifier = Modifier.height(8.dp))
                    latestRun?.warnings?.forEach { w ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = "Warning", tint = TerminalAmber, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = w, fontSize = 10.sp, color = TerminalAmber)
                        }
                    }
                }
            }
        }

        // Section 4: Live Constituent Blotter Table
        TransactionBlotterTable(
            transactions = transactions,
            modifier = Modifier.fillMaxWidth(),
            maxDisplayCount = 8
        )
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    subValue: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TerminalNavySurface, RoundedCornerShape(4.dp))
            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = LimestoneMuted
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 15.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = LimestoneWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subValue,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = LimestoneHighContrast.copy(alpha = 0.7f)
            )
        }
    }
}
