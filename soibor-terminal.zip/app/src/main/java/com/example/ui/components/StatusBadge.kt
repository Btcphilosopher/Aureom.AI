package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DataStatus
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed

@Composable
fun StatusBadge(
    status: DataStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderColor) = when (status) {
        DataStatus.OBSERVED -> Triple(Color(0xFF064E3B), TerminalGreen, Color(0xFF059669))
        DataStatus.DELAYED -> Triple(Color(0xFF1E3A5F), TerminalBlue, Color(0xFF2563EB))
        DataStatus.ESTIMATED -> Triple(Color(0xFF451A03), TerminalAmber, Color(0xFFD97706))
        DataStatus.SIMULATED -> Triple(Color(0xFF3B1D54), Color(0xFFC084FC), Color(0xFF9333EA))
        DataStatus.STALE -> Triple(Color(0xFF451A03), TerminalAmber, Color(0xFFD97706))
        DataStatus.MISSING -> Triple(Color(0xFF450A0A), TerminalRed, Color(0xFFDC2626))
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .border(1.dp, borderColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .background(textColor, CircleShape)
            )
            Text(
                text = " " + status.label,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

@Composable
fun ExperimentalBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color(0xFF3F2D04), RoundedCornerShape(4.dp))
            .border(1.dp, TerminalAmber.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "EXPERIMENTAL / PROPOSED",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = TerminalAmber
        )
    }
}
