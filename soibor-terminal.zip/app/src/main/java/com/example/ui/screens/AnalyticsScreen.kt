package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.ExperimentalBadge
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import com.example.ui.theme.TerminalRed
import java.util.Locale

@Composable
fun AnalyticsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val spreads = viewModel.getSpreads()
    val sensitivityPoints = viewModel.getTrimmingSensitivity()
    val latestRun by viewModel.latestCalculationRun.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Institutional Spreads Matrix
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShowChart, contentDescription = "Spreads", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "RELATIVE SPREADS & BASIS DYNAMICS",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }
                    Text(
                        text = "BASIS POINTS (bps)",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = LimestoneMuted
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "SPREAD LEG PAIR", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.8f))
                    Text(text = "SPREAD", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.0f))
                    Text(text = "DoD", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(0.9f))
                    Text(text = "30D μ", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(0.9f))
                    Text(text = "1Y %ILE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(0.9f))
                }

                Spacer(modifier = Modifier.height(4.dp))

                spreads.forEachIndexed { idx, sp ->
                    val isEven = idx % 2 == 0
                    val rowBg = if (isEven) Color.Transparent else TerminalNavySurface.copy(alpha = 0.3f)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(
                                text = "${sp.legA} vs ${sp.legB}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = LimestoneHighContrast
                            )
                            if (sp.isExperimental) {
                                Text(
                                    text = "EXPERIMENTAL BENCHMARK SPREAD",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalAmber
                                )
                            }
                        }

                        Text(
                            text = "${if (sp.currentSpreadBps > 0) "+" else ""}${String.format(Locale.US, "%.1f", sp.currentSpreadBps)}",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                sp.currentSpreadBps > 0 -> SoiborCyan
                                sp.currentSpreadBps < 0 -> TerminalAmber
                                else -> LimestoneHighContrast
                            },
                            modifier = Modifier.weight(1.0f)
                        )

                        Text(
                            text = "${if (sp.changeDayOnDayBps > 0) "+" else ""}${String.format(Locale.US, "%.1f", sp.changeDayOnDayBps)}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = when {
                                sp.changeDayOnDayBps > 0 -> TerminalGreen
                                sp.changeDayOnDayBps < 0 -> TerminalRed
                                else -> LimestoneMuted
                            },
                            modifier = Modifier.weight(0.9f)
                        )

                        Text(
                            text = String.format(Locale.US, "%.1f", sp.rollingMean30dBps),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneMuted,
                            modifier = Modifier.weight(0.9f)
                        )

                        Text(
                            text = "${String.format(Locale.US, "%.0f", sp.percentileRank1Y)}%",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneHighContrast,
                            modifier = Modifier.weight(0.9f)
                        )
                    }
                }
            }
        }

        // Section 2: Trimming Sensitivity Analysis Table
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = "Sensitivity", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "TRIMMING SENSITIVITY MATRIX",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }
                    Text(
                        text = "METHOD B STRESS",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalAmber
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Evaluates rate stability when adjusting volume tail trimming percentage (α). Quantifies tail distortion vs liquidity preservation.",
                    fontSize = 10.sp,
                    color = LimestoneMuted,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sensitivity Columns
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "PARAM LEVEL", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.3f))
                    Text(text = "RATE (%)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.1f))
                    Text(text = "Δ BASELINE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.1f))
                    Text(text = "VOL RETAINED", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.3f))
                }

                Spacer(modifier = Modifier.height(4.dp))

                sensitivityPoints.forEachIndexed { idx, pt ->
                    val isEven = idx % 2 == 0
                    val rowBg = if (isEven) Color.Transparent else TerminalNavySurface.copy(alpha = 0.3f)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = pt.parameterLabel,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = LimestoneHighContrast,
                            modifier = Modifier.weight(1.3f)
                        )

                        Text(
                            text = String.format(Locale.US, "%.4f", pt.calculatedRatePercent) + "%",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite,
                            modifier = Modifier.weight(1.1f)
                        )

                        Text(
                            text = "${if (pt.deltaBpsFromBaseline > 0) "+" else ""}${String.format(Locale.US, "%.2f", pt.deltaBpsFromBaseline)} bps",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (pt.deltaBpsFromBaseline == 0.0) LimestoneMuted else TerminalAmber,
                            modifier = Modifier.weight(1.1f)
                        )

                        Text(
                            text = "A$ ${String.format(Locale.US, "%,.0f", pt.retainedVolumeAudMillions)}M (${pt.retainedTrades}t)",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneHighContrast,
                            modifier = Modifier.weight(1.3f)
                        )
                    }
                }
            }
        }
    }
}
