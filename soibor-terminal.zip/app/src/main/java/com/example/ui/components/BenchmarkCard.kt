package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.RateObservation
import com.example.ui.theme.AoniaGold
import com.example.ui.theme.BbswPurple
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalRed
import java.util.Locale

@Composable
fun BenchmarkCard(
    title: String,
    tenor: String,
    observation: RateObservation?,
    sourceLabel: String,
    modifier: Modifier = Modifier,
    accentColor: Color = SoiborCyan,
    methodologyNote: String? = null
) {
    Box(
        modifier = modifier
            .background(TerminalNavyCard, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            // Header Row: Title, Tenor, and Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(width = 3.dp, height = 16.dp)
                            .background(accentColor, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(TerminalNavyCardBorder, RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = tenor,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneHighContrast
                        )
                    }
                }

                if (observation != null) {
                    StatusBadge(status = observation.status)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Rate Value & DoD Change
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    val rateFormatted = if (observation != null) {
                        String.format(Locale.US, "%.4f", observation.valuePercent)
                    } else {
                        "---.----"
                    }
                    Text(
                        text = rateFormatted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = LimestoneWhite
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "% p.a.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = LimestoneMuted
                    )
                }

                // Change in basis points
                if (observation != null) {
                    val chg = observation.changeBps
                    val chgColor = when {
                        chg > 0 -> TerminalGreen
                        chg < 0 -> TerminalRed
                        else -> LimestoneMuted
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (chg > 0) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "Up", tint = chgColor, modifier = Modifier.size(12.dp))
                        } else if (chg < 0) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = "Down", tint = chgColor, modifier = Modifier.size(12.dp))
                        }
                        Text(
                            text = "${if (chg > 0) "+" else ""}${String.format(Locale.US, "%.1f", chg)} bps",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = chgColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Volume & Transaction Details
            if (observation?.volumeAudMillions != null || observation?.transactionCount != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    observation.volumeAudMillions?.let { vol ->
                        Text(
                            text = "Eligible Vol: A$ ${String.format(Locale.US, "%,.1f", vol)}M",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = LimestoneMuted
                        )
                    }
                    observation.transactionCount?.let { cnt ->
                        Text(
                            text = "Trades: $cnt",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = LimestoneMuted
                        )
                    }
                }
            }

            // Methodology or Experimental Tag
            if (observation?.isExperimental == true) {
                Spacer(modifier = Modifier.height(6.dp))
                ExperimentalBadge()
            }

            if (methodologyNote != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = methodologyNote,
                    fontSize = 10.sp,
                    color = LimestoneSubtle,
                    lineHeight = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            // Source & Provenance
            Text(
                text = "Source: $sourceLabel",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = LimestoneSubtle
            )
        }
    }
}
