package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.YieldCurveSnapshot
import com.example.ui.theme.AoniaGold
import com.example.ui.theme.BbswPurple
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import java.util.Locale

@Composable
fun YieldCurveChart(
    bbswCurve: YieldCurveSnapshot,
    oisCurve: YieldCurveSnapshot,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TerminalNavyCard, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AUD TERM MONEY MARKET STRUCTURE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                    Text(
                        text = "BBSW Term Fixings vs Overnight Indexed Swap (OIS) Expectations",
                        fontSize = 10.sp,
                        color = LimestoneMuted
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(6.dp).background(BbswPurple, CircleShape))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "BBSW", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(6.dp).background(AoniaGold, CircleShape))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "OIS Curve", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Canvas Chart for BBSW Term Structure
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val leftMargin = 35.dp.toPx()
                    val rightMargin = 15.dp.toPx()
                    val topMargin = 15.dp.toPx()
                    val bottomMargin = 20.dp.toPx()

                    val chartWidth = size.width - leftMargin - rightMargin
                    val chartHeight = size.height - topMargin - bottomMargin

                    val minRate = 4.20
                    val maxRate = 4.65
                    val range = maxRate - minRate

                    // Draw gridlines
                    for (i in 0..4) {
                        val y = topMargin + chartHeight * (i.toFloat() / 4f)
                        drawLine(
                            color = TerminalNavyCardBorder.copy(alpha = 0.5f),
                            start = Offset(leftMargin, y),
                            end = Offset(size.width - rightMargin, y),
                            strokeWidth = 1f
                        )
                    }

                    val bbswNodes = bbswCurve.nodes
                    if (bbswNodes.isNotEmpty()) {
                        val bbswPath = Path()
                        bbswNodes.forEachIndexed { idx, node ->
                            val x = leftMargin + chartWidth * (idx.toFloat() / (bbswNodes.size - 1))
                            val y = topMargin + chartHeight * (1f - ((node.ratePercent - minRate) / range).toFloat())
                            if (idx == 0) bbswPath.moveTo(x, y) else bbswPath.lineTo(x, y)
                            // Draw node point
                            drawCircle(color = BbswPurple, radius = 4.dp.toPx(), center = Offset(x, y))
                            drawCircle(color = LimestoneWhite, radius = 2.dp.toPx(), center = Offset(x, y))
                        }
                        drawPath(path = bbswPath, color = BbswPurple, style = Stroke(width = 2.5.dp.toPx()))
                    }

                    // Draw OIS Nodes if present
                    val oisNodes = oisCurve.nodes
                    if (oisNodes.isNotEmpty()) {
                        val oisPath = Path()
                        oisNodes.forEachIndexed { idx, node ->
                            val x = leftMargin + chartWidth * (idx.toFloat() / (oisNodes.size - 1))
                            val y = topMargin + chartHeight * (1f - ((node.ratePercent - minRate) / range).toFloat())
                            if (idx == 0) oisPath.moveTo(x, y) else oisPath.lineTo(x, y)
                            drawCircle(color = AoniaGold, radius = 3.dp.toPx(), center = Offset(x, y))
                        }
                        drawPath(
                            path = oisPath,
                            color = AoniaGold,
                            style = Stroke(
                                width = 1.5.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                            )
                        )
                    }
                }
            }

            // X-Axis Tenor Labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 35.dp, end = 15.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                bbswCurve.nodes.forEach { node ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = node.tenor,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                        Text(
                            text = String.format(Locale.US, "%.3f", node.ratePercent) + "%",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = BbswPurple
                        )
                    }
                }
            }
        }
    }
}
