package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
    primary = TerminalBlue,
    onPrimary = TerminalNavyDarkest,
    primaryContainer = TerminalNavyCard,
    onPrimaryContainer = TerminalBlue,
    secondary = TerminalAmber,
    onSecondary = TerminalNavyDarkest,
    tertiary = TerminalGreen,
    background = TerminalNavyBackground,
    onBackground = LimestoneWhite,
    surface = TerminalNavySurface,
    onSurface = LimestoneHighContrast,
    surfaceVariant = TerminalNavyCard,
    onSurfaceVariant = LimestoneMuted,
    outline = TerminalNavyCardBorder,
    error = TerminalRed,
    onError = LimestoneWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
