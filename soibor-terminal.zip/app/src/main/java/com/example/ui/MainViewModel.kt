package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.data.BenchmarkRepository
import com.example.data.HistoricalDataPoint
import com.example.data.ReportExporter
import com.example.domain.model.CalculationRun
import com.example.domain.model.DataQualityReport
import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.ScenarioDefinition
import com.example.domain.model.ScenarioResult
import com.example.domain.model.SensitivityPoint
import com.example.domain.model.SpreadMetric
import com.example.domain.model.UserRole
import com.example.domain.model.YieldCurveSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel(
    val repository: BenchmarkRepository = BenchmarkRepository()
) : ViewModel() {

    val currentUserRole: StateFlow<UserRole> = repository.currentUserRole
    val activeMethodology: StateFlow<MethodologyConfig> = repository.activeMethodology
    val latestCalculationRun: StateFlow<CalculationRun?> = repository.latestCalculationRun
    val calculationHistory: StateFlow<List<CalculationRun>> = repository.calculationHistory
    val auditEvents = repository.auditEvents
    val activeDatasetName: StateFlow<String> = repository.activeDatasetName
    val currentTransactions: StateFlow<List<FundingTransaction>> = repository.currentTransactions

    private val _selectedTimeWindow = MutableStateFlow("1M")
    val selectedTimeWindow: StateFlow<String> = _selectedTimeWindow.asStateFlow()

    private val _historicalRates = MutableStateFlow<List<HistoricalDataPoint>>(emptyList())
    val historicalRates: StateFlow<List<HistoricalDataPoint>> = _historicalRates.asStateFlow()

    private val _selectedScenario = MutableStateFlow<ScenarioDefinition>(
        com.example.domain.engine.ScenarioEngine.PRESET_SCENARIOS.first()
    )
    val selectedScenario: StateFlow<ScenarioDefinition> = _selectedScenario.asStateFlow()

    private val _scenarioResult = MutableStateFlow<ScenarioResult?>(null)
    val scenarioResult: StateFlow<ScenarioResult?> = _scenarioResult.asStateFlow()

    init {
        loadHistoricalRates("1M")
        runSelectedScenario(_selectedScenario.value)
    }

    fun setTimeWindow(window: String) {
        _selectedTimeWindow.value = window
        val days = when (window) {
            "1W" -> 7
            "1M" -> 30
            "3M" -> 90
            "6M" -> 180
            "1Y" -> 365
            "5Y" -> 500
            else -> 30
        }
        loadHistoricalRates(window, days)
    }

    private fun loadHistoricalRates(window: String, days: Int = 30) {
        _historicalRates.value = repository.getHistoricalRatesSeries(days)
    }

    fun setUserRole(role: UserRole) {
        repository.setUserRole(role)
    }

    fun updateMethodology(config: MethodologyConfig) {
        repository.updateMethodology(config)
    }

    fun selectDataset(datasetName: String) {
        repository.selectDataset(datasetName)
    }

    fun executeCalculation(): CalculationRun {
        return repository.executeManualCalculation()
    }

    fun getBenchmarkDefinitions() = repository.getBenchmarkDefinitions()

    fun getSpreads(): List<SpreadMetric> = repository.getSpreads()

    fun getYieldCurve(): YieldCurveSnapshot = repository.getYieldCurveSnapshot()

    fun getAudOisCurve(): YieldCurveSnapshot = repository.getAudOisCurve()

    fun getTrimmingSensitivity(): List<SensitivityPoint> = repository.getTrimmingSensitivity()

    fun getDataQualityReport(): DataQualityReport = repository.getDataQualityReport()

    fun getAvailableDatasets(): List<String> = repository.getAvailableDatasets()

    fun selectScenario(scenario: ScenarioDefinition) {
        _selectedScenario.value = scenario
        runSelectedScenario(scenario)
    }

    private fun runSelectedScenario(scenario: ScenarioDefinition) {
        _scenarioResult.value = repository.runScenario(scenario)
    }

    fun generateFullReport(): String {
        return ReportExporter.generateInstitutionalReport(
            latestCalculationRun.value,
            activeMethodology.value,
            getSpreads(),
            currentTransactions.value
        )
    }

    fun exportCsv(): String {
        return ReportExporter.exportTransactionsCsv(currentTransactions.value)
    }

    fun exportJson(): String {
        return ReportExporter.exportRatesJson(latestCalculationRun.value, getSpreads())
    }
}
