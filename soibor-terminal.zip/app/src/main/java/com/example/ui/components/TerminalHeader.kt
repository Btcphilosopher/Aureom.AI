package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.UserRole
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavyDarkest
import com.example.ui.theme.TerminalNavySurface
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun TerminalHeader(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit,
    modifier: Modifier = Modifier
) {
    var currentTimeSydney by remember { mutableStateOf("") }
    var roleMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm:ss 'AEDT'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("Australia/Sydney")
        while (true) {
            currentTimeSydney = sdf.format(Date())
            delay(1000L)
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        // Institutional Watermark & Integrity Warning Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF281806))
                .border(1.dp, TerminalAmber.copy(alpha = 0.5f))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Warning",
                        tint = TerminalAmber,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "DEMO DATASET — SIMULATED & ISOLATED ENVIRONMENT | SOIBOR IS A PROPOSED BENCHMARK",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalAmber
                    )
                }
                Text(
                    text = "NOT REGULATORY-APPROVED",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LimestoneMuted
                )
            }
        }

        // Main Institutional Top Navigation Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyDarkest)
                .border(1.dp, TerminalNavyCardBorder)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Title and Sydney Clock
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SOIBOR",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TerminalBlue
                    )
                    Text(
                        text = " TERMINAL",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(TerminalGreen, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SYDNEY $currentTimeSydney",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = LimestoneHighContrast
                            )
                        }
                    }
                }

                // Status Ticker & Role Selector
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Feed Status
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "Data Feed Health",
                            tint = TerminalGreen,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "FEEDS: RBA 4.35% | ASX OK",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LimestoneMuted
                        )
                    }

                    // Role Selector Dropdown
                    Box {
                        Box(
                            modifier = Modifier
                                .testTag("role_selector_button")
                                .background(TerminalNavyCard, RoundedCornerShape(4.dp))
                                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                                .clickable { roleMenuExpanded = true }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = "User Role",
                                    tint = TerminalBlue,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentRole.label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = LimestoneHighContrast
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Select Role",
                                    tint = LimestoneMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = roleMenuExpanded,
                            onDismissRequest = { roleMenuExpanded = false },
                            modifier = Modifier.background(TerminalNavySurface)
                        ) {
                            UserRole.entries.forEach { role ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = role.label,
                                            fontSize = 12.sp,
                                            color = if (role == currentRole) TerminalBlue else LimestoneHighContrast
                                        )
                                    },
                                    onClick = {
                                        onRoleSelected(role)
                                        roleMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
