package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FundingTransaction
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import com.example.ui.theme.TerminalRed
import java.util.Locale

@Composable
fun TransactionBlotterTable(
    transactions: List<FundingTransaction>,
    modifier: Modifier = Modifier,
    maxDisplayCount: Int = 20
) {
    var filterType by remember { mutableStateOf("ALL") } // ALL, ELIGIBLE, OUTLIERS, TRIMMED
    var selectedTxForDetails by remember { mutableStateOf<FundingTransaction?>(null) }

    val filteredList = when (filterType) {
        "ELIGIBLE" -> transactions.filter { it.isEligible && !it.isTrimmed && !it.isOutlier }
        "OUTLIERS" -> transactions.filter { it.isOutlier }
        "TRIMMED" -> transactions.filter { it.isTrimmed }
        else -> transactions
    }

    Box(
        modifier = modifier
            .background(TerminalNavyCard, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            // Blotter Header and Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "OVERNIGHT FUNDING BLOTTER",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                    Text(
                        text = "Eligible Interbank Deposit Observations (${filteredList.size} displayed)",
                        fontSize = 10.sp,
                        color = LimestoneMuted
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("ALL", "ELIGIBLE", "OUTLIERS", "TRIMMED").forEach { tag ->
                        val isSel = filterType == tag
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSel) SoiborCyan.copy(alpha = 0.2f) else TerminalNavySurface,
                                    RoundedCornerShape(3.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSel) SoiborCyan else TerminalNavyCardBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .clickable { filterType = tag }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = tag,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) SoiborCyan else LimestoneMuted
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Table Column Headers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "TRADE ID / TIME", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.3f))
                Text(text = "RATE (%)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.0f))
                Text(text = "VOL (AUD M)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.0f))
                Text(text = "COUNTERPARTY", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.5f))
                Text(text = "STATUS", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneMuted, modifier = Modifier.weight(1.1f))
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Table Rows
            Column(modifier = Modifier.fillMaxWidth()) {
                filteredList.take(maxDisplayCount).forEachIndexed { idx, tx ->
                    val isEven = idx % 2 == 0
                    val rowBg = if (isEven) Color.Transparent else TerminalNavySurface.copy(alpha = 0.35f)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .clickable { selectedTxForDetails = tx }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Text(text = tx.transactionId, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = LimestoneHighContrast)
                            Text(text = tx.tradeTimestamp.take(8), fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
                        }

                        Text(
                            text = String.format(Locale.US, "%.4f", tx.ratePercent),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                tx.isOutlier -> TerminalAmber
                                !tx.isEligible -> TerminalRed
                                else -> LimestoneWhite
                            },
                            modifier = Modifier.weight(1.0f)
                        )

                        Text(
                            text = "A$ ${String.format(Locale.US, "%.1f", tx.volumeAudMillions)}M",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneHighContrast,
                            modifier = Modifier.weight(1.0f)
                        )

                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(text = tx.counterpartyBorrower.take(16), fontSize = 10.sp, maxLines = 1, color = LimestoneHighContrast)
                            Text(text = "vs ${tx.counterpartyLender.take(14)}", fontSize = 9.sp, maxLines = 1, color = LimestoneSubtle)
                        }

                        // Status Tag
                        val (statusText, statusColor, statusBg) = when {
                            tx.isOutlier -> Triple("OUTLIER", TerminalAmber, Color(0xFF451A03))
                            tx.isTrimmed -> Triple("TRIMMED", Color(0xFFC084FC), Color(0xFF3B1D54))
                            !tx.isEligible -> Triple("EXCLUDED", TerminalRed, Color(0xFF450A0A))
                            else -> Triple("ELIGIBLE", TerminalGreen, Color(0xFF064E3B))
                        }

                        Box(
                            modifier = Modifier
                                .weight(1.1f)
                                .background(statusBg, RoundedCornerShape(3.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = statusText,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }
                    }
                }
            }

            // Expanded Transaction Details Dialog/Pill
            selectedTxForDetails?.let { tx ->
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                        .border(1.dp, SoiborCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "TRADE AUDIT AUD-TRACE: ${tx.transactionId}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = SoiborCyan
                            )
                            Text(
                                text = "TAP TO CLOSE",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = LimestoneMuted,
                                modifier = Modifier.clickable { selectedTxForDetails = null }
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Borrower: ${tx.counterpartyBorrower} | Lender: ${tx.counterpartyLender}",
                            fontSize = 10.sp,
                            color = LimestoneHighContrast
                        )
                        Text(
                            text = "Tenor: ${tx.tenor} | Settle: ${tx.settlementConvention} | Ccy: ${tx.currency} | Type: ${tx.transactionType}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneMuted
                        )
                        if (tx.exclusionReason != null) {
                            Text(
                                text = "Exclusion Reason: ${tx.exclusionReason}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TerminalAmber
                            )
                        }
                    }
                }
            }
        }
    }
}
