package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.QuantitativeAnalytics
import com.example.ui.MainViewModel
import com.example.ui.components.YieldCurveChart
import com.example.ui.theme.AoniaGold
import com.example.ui.theme.BbswPurple
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import java.util.Locale

@Composable
fun YieldCurveScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val bbswCurve = viewModel.getYieldCurve()
    val oisCurve = viewModel.getAudOisCurve()

    var selectedCompoundingTenor by remember { mutableStateOf(90) }
    val sampleDailyRates = remember { List(180) { 4.350 + (it % 5) * 0.002 } }
    val compoundedResult = remember(selectedCompoundingTenor) {
        QuantitativeAnalytics.computeCompoundedOvernightRate(
            sampleDailyRates.take(selectedCompoundingTenor),
            selectedCompoundingTenor,
            "2026-07-11"
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Yield Curve Visualizer Chart
        YieldCurveChart(
            bbswCurve = bbswCurve,
            oisCurve = oisCurve,
            modifier = Modifier.fillMaxWidth()
        )

        // Section 2: Curve Steepness & Tenor Spreads Analysis
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, contentDescription = "Curve", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "TERM STRUCTURE SLOPE & SPREADS",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }
                    Text(
                        text = "Actual/365 AUD",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = LimestoneMuted
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CurveStatBox(
                        title = "3M - 1M BBSW SPREAD",
                        value = "${String.format(Locale.US, "+%.1f", bbswCurve.steepness3M1MBps)} bps",
                        sub = "Mild upward slope",
                        modifier = Modifier.weight(1f)
                    )
                    CurveStatBox(
                        title = "6M - 1M BBSW SPREAD",
                        value = "${String.format(Locale.US, "+%.1f", bbswCurve.steepness6M1MBps)} bps",
                        sub = "Standard liquidity curve",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CurveStatBox(
                        title = "1Y OIS vs CASH TARGET",
                        value = "-20.0 bps",
                        sub = "Rate cuts priced in market",
                        modifier = Modifier.weight(1f)
                    )
                    CurveStatBox(
                        title = "3M BBSW vs 3M OIS",
                        value = "+12.8 bps",
                        sub = "Bank credit risk premium",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Section 3: Backward-Looking Compounded Index Calculator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Calculate, contentDescription = "Compounding", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "COMPOUNDED OVERNIGHT RATE CALCULATOR",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(TerminalAmber.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "MODEL ESTIMATE",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TerminalAmber
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Derives backward-looking compounded money-market rates over standardized lookback tenors according to market conventions.",
                    fontSize = 10.sp,
                    color = LimestoneMuted,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Tenor Selector Buttons (30d, 90d, 180d)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30 to "30-Day (1M)", 90 to "90-Day (3M)", 180 to "180-Day (6M)").forEach { (tenor, label) ->
                        val isSel = selectedCompoundingTenor == tenor
                        Button(
                            onClick = { selectedCompoundingTenor = tenor },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) SoiborCyan.copy(alpha = 0.25f) else TerminalNavySurface,
                                contentColor = if (isSel) SoiborCyan else LimestoneMuted
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .border(1.dp, if (isSel) SoiborCyan else TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                                .height(32.dp)
                        ) {
                            Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Calculated Output Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                        .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Compounded Annualized Yield ($selectedCompoundingTenor Days):",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = LimestoneHighContrast
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.4f", compoundedResult.annualizedRatePercent)} % p.a.",
                                fontSize = 15.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = SoiborCyan
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Formula: ${compoundedResult.formulaUsed}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneSubtle
                        )
                        Text(
                            text = "Observations: ${compoundedResult.observationCount} daily fixings compounded Actual/365",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneSubtle
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CurveStatBox(
    title: String,
    value: String,
    sub: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TerminalNavySurface, RoundedCornerShape(4.dp))
            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(text = title, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = sub, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
        }
    }
}
