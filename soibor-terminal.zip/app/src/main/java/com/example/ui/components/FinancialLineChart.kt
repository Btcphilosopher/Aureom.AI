package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HistoricalDataPoint
import com.example.ui.theme.AoniaGold
import com.example.ui.theme.BbswPurple
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.RbaIndicator
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import java.util.Locale

@Composable
fun FinancialLineChart(
    dataPoints: List<HistoricalDataPoint>,
    selectedWindow: String,
    onWindowSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val windows = listOf("1W", "1M", "3M", "6M", "1Y", "5Y")

    Box(
        modifier = modifier
            .background(TerminalNavyCard, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            // Chart Header & Time Window Selectors
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HISTORICAL BENCHMARK DYNAMICS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                    Text(
                        text = "Multi-Series Term Comparison (AUD Overnight & BBSW Tenors)",
                        fontSize = 10.sp,
                        color = LimestoneMuted
                    )
                }

                // Window Filter Buttons
                Row(
                    modifier = Modifier
                        .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                        .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                        .padding(2.dp)
                ) {
                    windows.forEach { win ->
                        val isSelected = win == selectedWindow
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) SoiborCyan.copy(alpha = 0.2f) else Color.Transparent,
                                    RoundedCornerShape(3.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) SoiborCyan else Color.Transparent,
                                    RoundedCornerShape(3.dp)
                                )
                                .pointerInput(Unit) {
                                    detectTapGestures { onWindowSelected(win) }
                                }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = win,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) SoiborCyan else LimestoneMuted
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Series Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem(color = SoiborCyan, label = "SOIBOR (Proposed O/N)")
                LegendItem(color = AoniaGold, label = "AONIA (Official RBA O/N)")
                LegendItem(color = BbswPurple, label = "BBSW 3M")
                LegendItem(color = RbaIndicator, label = "RBA Target (4.35%)", isDashed = true)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive Inspection Pill if tapped
            if (selectedIndex != null && selectedIndex!! in dataPoints.indices) {
                val pt = dataPoints[selectedIndex!!]
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                        .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Date: ${pt.dateLabel}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "SOIBOR: ${String.format(Locale.US, "%.3f", pt.soiborPercent)}%",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = SoiborCyan
                            )
                            Text(
                                text = "AONIA: ${String.format(Locale.US, "%.3f", pt.aoniaPercent)}%",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = AoniaGold
                            )
                            Text(
                                text = "3M BBSW: ${String.format(Locale.US, "%.3f", pt.bbsw3MPercent)}%",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = BbswPurple
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Canvas Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .pointerInput(dataPoints) {
                        detectTapGestures { offset ->
                            if (dataPoints.isNotEmpty()) {
                                val chartWidth = size.width - 50.dp.toPx()
                                val relativeX = (offset.x - 45.dp.toPx()).coerceIn(0f, chartWidth)
                                val idx = ((relativeX / chartWidth) * (dataPoints.size - 1)).toInt()
                                selectedIndex = idx.coerceIn(0, dataPoints.size - 1)
                            }
                        }
                    }
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    if (dataPoints.size < 2) return@Canvas

                    val leftMargin = 45.dp.toPx()
                    val rightMargin = 10.dp.toPx()
                    val topMargin = 15.dp.toPx()
                    val bottomMargin = 25.dp.toPx()

                    val chartWidth = size.width - leftMargin - rightMargin
                    val chartHeight = size.height - topMargin - bottomMargin

                    // Min and Max values for scale
                    val allVals = dataPoints.flatMap { listOf(it.soiborPercent, it.aoniaPercent, it.rbaTargetPercent, it.bbsw3MPercent) }
                    val minVal = (allVals.minOrNull() ?: 4.30) - 0.02
                    val maxVal = (allVals.maxOrNull() ?: 4.55) + 0.02
                    val valRange = (maxVal - minVal).coerceAtLeast(0.01)

                    // Draw Horizontal Gridlines (4 levels)
                    val gridSteps = 4
                    for (i in 0..gridSteps) {
                        val gridY = topMargin + chartHeight * (i.toFloat() / gridSteps)
                        val rateVal = maxVal - (valRange * (i.toDouble() / gridSteps))

                        drawLine(
                            color = TerminalNavyCardBorder.copy(alpha = 0.6f),
                            start = Offset(leftMargin, gridY),
                            end = Offset(size.width - rightMargin, gridY),
                            strokeWidth = 1f
                        )
                    }

                    // Helper function to map data to Canvas coordinates
                    fun getCoord(idx: Int, value: Double): Offset {
                        val x = leftMargin + chartWidth * (idx.toFloat() / (dataPoints.size - 1))
                        val y = topMargin + chartHeight * (1f - ((value - minVal) / valRange).toFloat())
                        return Offset(x, y)
                    }

                    // Draw RBA Target Line (Emerald, dashed)
                    val rbaPath = Path()
                    dataPoints.forEachIndexed { idx, pt ->
                        val coord = getCoord(idx, pt.rbaTargetPercent)
                        if (idx == 0) rbaPath.moveTo(coord.x, coord.y) else rbaPath.lineTo(coord.x, coord.y)
                    }
                    drawPath(
                        path = rbaPath,
                        color = RbaIndicator.copy(alpha = 0.8f),
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                    )

                    // Draw BBSW 3M Path (Purple)
                    val bbswPath = Path()
                    dataPoints.forEachIndexed { idx, pt ->
                        val coord = getCoord(idx, pt.bbsw3MPercent)
                        if (idx == 0) bbswPath.moveTo(coord.x, coord.y) else bbswPath.lineTo(coord.x, coord.y)
                    }
                    drawPath(path = bbswPath, color = BbswPurple, style = Stroke(width = 2.dp.toPx()))

                    // Draw AONIA Path (Gold)
                    val aoniaPath = Path()
                    dataPoints.forEachIndexed { idx, pt ->
                        val coord = getCoord(idx, pt.aoniaPercent)
                        if (idx == 0) aoniaPath.moveTo(coord.x, coord.y) else aoniaPath.lineTo(coord.x, coord.y)
                    }
                    drawPath(path = aoniaPath, color = AoniaGold, style = Stroke(width = 2.dp.toPx()))

                    // Draw SOIBOR Path (Cyan, Bold)
                    val soiborPath = Path()
                    dataPoints.forEachIndexed { idx, pt ->
                        val coord = getCoord(idx, pt.soiborPercent)
                        if (idx == 0) soiborPath.moveTo(coord.x, coord.y) else soiborPath.lineTo(coord.x, coord.y)
                    }
                    drawPath(path = soiborPath, color = SoiborCyan, style = Stroke(width = 3.dp.toPx()))

                    // Draw RBA Board meeting event marker
                    dataPoints.forEachIndexed { idx, pt ->
                        if (pt.hasRbaEvent) {
                            val coord = getCoord(idx, pt.rbaTargetPercent)
                            drawLine(
                                color = TerminalAmber,
                                start = Offset(coord.x, topMargin),
                                end = Offset(coord.x, topMargin + chartHeight),
                                strokeWidth = 1.5f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                            )
                            drawCircle(
                                color = TerminalAmber,
                                radius = 4.dp.toPx(),
                                center = Offset(coord.x, topMargin + 8.dp.toPx())
                            )
                        }
                    }

                    // Draw Crosshair Indicator if touched
                    selectedIndex?.let { idx ->
                        if (idx in dataPoints.indices) {
                            val coord = getCoord(idx, dataPoints[idx].soiborPercent)
                            drawLine(
                                color = LimestoneWhite.copy(alpha = 0.5f),
                                start = Offset(coord.x, topMargin),
                                end = Offset(coord.x, topMargin + chartHeight),
                                strokeWidth = 1.dp.toPx()
                            )
                            drawCircle(
                                color = SoiborCyan,
                                radius = 5.dp.toPx(),
                                center = coord
                            )
                        }
                    }
                }
            }

            // Bottom X-Axis Labels (first, middle, last)
            if (dataPoints.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 45.dp, end = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = dataPoints.first().dateLabel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
                    if (dataPoints.size > 2) {
                        Text(text = dataPoints[dataPoints.size / 2].dateLabel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
                    }
                    Text(text = dataPoints.last().dateLabel, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
                }
            }
        }
    }
}

@Composable
private fun LegendItem(
    color: Color,
    label: String,
    isDashed: Boolean = false
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (isDashed) {
            Box(
                modifier = Modifier
                    .size(width = 12.dp, height = 3.dp)
                    .background(color, RoundedCornerShape(1.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(color, CircleShape)
            )
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = LimestoneMuted
        )
    }
}
