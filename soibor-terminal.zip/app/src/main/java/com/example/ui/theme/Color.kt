package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Sydney Terminal Palette
val TerminalNavyDarkest = Color(0xFF070D18)
val TerminalNavyBackground = Color(0xFF0A1220)
val TerminalNavySurface = Color(0xFF0F1B2F)
val TerminalNavyCard = Color(0xFF14243D)
val TerminalNavyCardBorder = Color(0xFF1E3557)
val TerminalNavyHover = Color(0xFF1B2E4D)

// Limestone and slate typography
val LimestoneWhite = Color(0xFFF8FAFC)
val LimestoneHighContrast = Color(0xFFE2E8F0)
val LimestoneMuted = Color(0xFF94A3B8)
val LimestoneSubtle = Color(0xFF64748B)

// Financial accents
val TerminalBlue = Color(0xFF38BDF8)
val TerminalBlueMuted = Color(0xFF0284C7)
val TerminalAmber = Color(0xFFF59E0B)
val TerminalAmberMuted = Color(0xFFB45309)
val TerminalGreen = Color(0xFF10B981)
val TerminalGreenDark = Color(0xFF047857)
val TerminalRed = Color(0xFFEF4444)
val TerminalRedDark = Color(0xFFB91C1C)

// Rate family identifiers
val SoiborCyan = Color(0xFF06B6D4)
val AoniaGold = Color(0xFFFBBF24)
val BbswPurple = Color(0xFFA78BFA)
val RbaIndicator = Color(0xFF34D399)
