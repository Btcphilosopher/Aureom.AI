package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface

@Composable
fun AuditProvenanceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val auditEvents by viewModel.auditEvents.collectAsState()
    val qualityReport = viewModel.getDataQualityReport()
    val context = LocalContext.current

    var copyNotification by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Copy Notification Banner
        copyNotification?.let { msg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalGreen, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Verified, contentDescription = "Copied", tint = TerminalGreen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = msg, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                }
            }
        }

        // Section 1: Institutional Export & Publication Tools
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Download, contentDescription = "Exports", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RESEARCH REPORT & DATA EXPORT ENGINE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Generate and export auditable fixing reports, constituent trade records (CSV), and machine-readable JSON rate curves with provenance tags.",
                    fontSize = 10.sp,
                    color = LimestoneMuted,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val report = viewModel.generateFullReport()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("SOIBOR Research Report", report))
                            copyNotification = "Institutional Research Report copied to clipboard!"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SoiborCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("copy_report_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "COPY REPORT", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = {
                            val csv = viewModel.exportCsv()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Transactions CSV", csv))
                            copyNotification = "Transactions CSV exported & copied to clipboard!"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalNavySurface, contentColor = LimestoneWhite),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                            .height(36.dp)
                            .testTag("export_csv_button")
                    ) {
                        Text(text = "CSV BLOTTER", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val json = viewModel.exportJson()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Rates JSON", json))
                            copyNotification = "Fixing & Spreads JSON copied to clipboard!"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalNavySurface, contentColor = LimestoneWhite),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                            .height(36.dp)
                            .testTag("export_json_button")
                    ) {
                        Text(text = "JSON FEED", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section 2: Data Quality & Provenance Health
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HealthAndSafety, contentDescription = "Health", tint = TerminalGreen, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "DATA INGESTION & QUALITY MONITORING",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                QualityRow(label = "RBA Official Ingestion Feed", status = qualityReport.sourceAoniaHealth, isGood = true)
                QualityRow(label = "ASX Authorized BBSW Feed", status = qualityReport.sourceBbswHealth, isGood = true)
                QualityRow(label = "Synthetic Blotter Isolation", status = qualityReport.syntheticFeedHealth, isGood = true)
                QualityRow(label = "Duplicate Check Violations", status = "${qualityReport.duplicateTradesDetected} rejected", isGood = qualityReport.duplicateTradesDetected == 0)
                QualityRow(label = "Currency Non-AUD Violations", status = "${qualityReport.currencyViolationsDetected} filtered", isGood = qualityReport.currencyViolationsDetected == 0)
                QualityRow(label = "Tenor Ineligibility Filters", status = "${qualityReport.tenorViolationsDetected} filtered", isGood = qualityReport.tenorViolationsDetected == 0)
                QualityRow(label = "Statistical Outlier Triggers", status = "${qualityReport.statisticalOutliersCount} flagged", isGood = true)
            }
        }

        // Section 3: Immutable Governance Audit Log
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = "Audit", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "IMMUTABLE AUDIT TRAIL LOG",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }
                    Text(
                        text = "${auditEvents.size} EVENTS RECORDED",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = LimestoneMuted
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                auditEvents.take(15).forEachIndexed { idx, ev ->
                    val isEven = idx % 2 == 0
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .background(if (isEven) Color.Transparent else TerminalNavySurface.copy(alpha = 0.4f))
                            .padding(6.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "[${ev.timestampSydney.take(19)}] ${ev.actionType}",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = SoiborCyan
                                )
                                Text(
                                    text = ev.checksum,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = LimestoneSubtle
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = ev.summary,
                                fontSize = 10.sp,
                                color = LimestoneHighContrast
                            )
                            Text(
                                text = "Role: ${ev.userRole.label} | ${ev.details}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = LimestoneMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QualityRow(
    label: String,
    status: String,
    isGood: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = LimestoneHighContrast)
        Text(
            text = status,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isGood) TerminalGreen else TerminalAmber
        )
    }
}
