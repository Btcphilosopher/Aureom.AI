package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.ScenarioEngine
import com.example.domain.model.ScenarioDefinition
import com.example.ui.MainViewModel
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import com.example.ui.theme.TerminalRed
import java.util.Locale

@Composable
fun ScenarioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val selectedScenario by viewModel.selectedScenario.collectAsState()
    val result by viewModel.scenarioResult.collectAsState()

    val presets = ScenarioEngine.PRESET_SCENARIOS

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Critical Simulation Watermark Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF381504), RoundedCornerShape(4.dp))
                .border(1.dp, TerminalAmber, RoundedCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = "Simulated", tint = TerminalAmber, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "HYPOTHETICAL STRESS SCENARIO ENVIRONMENT",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TerminalAmber
                    )
                    Text(
                        text = "Outputs are labelled SIMULATED and are never stored or exported as observed benchmark fixings.",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = LimestoneHighContrast
                    )
                }
            }
        }

        // Section 1: Scenario Presets Selector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CrisisAlert, contentDescription = "Scenarios", tint = SoiborCyan, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "MONEY MARKET STRESS SCENARIOS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LimestoneWhite
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                presets.forEach { scen ->
                    val isSelected = selectedScenario.scenarioId == scen.scenarioId
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                if (isSelected) SoiborCyan.copy(alpha = 0.15f) else TerminalNavySurface,
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                1.dp,
                                if (isSelected) SoiborCyan else TerminalNavyCardBorder,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { viewModel.selectScenario(scen) }
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = scen.name,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) SoiborCyan else LimestoneWhite
                                )
                                if (scen.isStressScenario) {
                                    Box(
                                        modifier = Modifier
                                            .background(TerminalRed.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "STRESS", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TerminalRed)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = scen.description,
                                fontSize = 10.sp,
                                color = LimestoneMuted,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Simulated Output Comparison
        result?.let { res ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SIMULATION RESPONSE ESTIMATE",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                        Text(
                            text = res.calculatedAtSydney,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Side by Side: Baseline vs Simulated
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Baseline
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "BASELINE RATE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${String.format(Locale.US, "%.4f", res.baselineRatePercent)}%",
                                    fontSize = 18.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = LimestoneWhite
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = "Vol: A$ ${String.format(Locale.US, "%,.0f", res.baselineVolumeAudMillions)}M", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
                            }
                        }

                        // Simulated
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0xFF28183B), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFFC084FC).copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(10.dp)
                        ) {
                            Column {
                                Text(text = "SIMULATED FIXING", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFC084FC))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${String.format(Locale.US, "%.4f", res.simulatedRatePercent)}%",
                                    fontSize = 18.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE9D5FF)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = "Vol: A$ ${String.format(Locale.US, "%,.0f", res.simulatedVolumeAudMillions)}M (${res.simulatedTradeCount}t)", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneSubtle)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Spread Impact Box
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "SHIFT VS BASELINE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
                                Text(
                                    text = "${if (res.spreadToBaselineBps > 0) "+" else ""}${String.format(Locale.US, "%.1f", res.spreadToBaselineBps)} bps",
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (res.spreadToBaselineBps != 0.0) TerminalAmber else LimestoneHighContrast
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(text = "SPREAD TO RBA TARGET", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
                                Text(
                                    text = "${if (res.spreadToRbaTargetBps > 0) "+" else ""}${String.format(Locale.US, "%.1f", res.spreadToRbaTargetBps)} bps",
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = SoiborCyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
