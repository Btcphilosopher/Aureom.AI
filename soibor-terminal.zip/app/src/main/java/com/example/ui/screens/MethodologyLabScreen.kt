package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BenchmarkMethod
import com.example.domain.model.CalculationStatus
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.OutlierMethod
import com.example.domain.model.UserRole
import com.example.ui.MainViewModel
import com.example.ui.components.StatusBadge
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.LimestoneSubtle
import com.example.ui.theme.LimestoneWhite
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavySurface
import com.example.ui.theme.TerminalRed
import java.util.Locale

@Composable
fun MethodologyLabScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val currentRole by viewModel.currentUserRole.collectAsState()
    val activeConfig by viewModel.activeMethodology.collectAsState()
    val latestRun by viewModel.latestCalculationRun.collectAsState()
    val activeDataset by viewModel.activeDatasetName.collectAsState()
    val availableDatasets = viewModel.getAvailableDatasets()

    val canEdit = currentRole != UserRole.ANALYST

    var editingConfig by remember(activeConfig) { mutableStateOf(activeConfig) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Permission Banner
        if (!canEdit) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF241C10), RoundedCornerShape(4.dp))
                    .border(1.dp, TerminalAmber.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = TerminalAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "READ-ONLY ANALYST ROLE: Switch to Quantitative Researcher or Admin in the top header to modify parameters.",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalAmber
                    )
                }
            }
        }

        // Section 1: Methodology Formulation Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Biotech, contentDescription = "Lab", tint = SoiborCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ESTIMATOR METHODOLOGY FORMULATION",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LimestoneWhite
                        )
                    }
                    Text(
                        text = editingConfig.versionId,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SoiborCyan
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Method A vs Method B Selector
                Text(
                    text = "SELECT AGGREGATION ESTIMATOR:",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = LimestoneMuted
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Method A Button
                    val isMethodA = editingConfig.methodName == BenchmarkMethod.TRANSACTION_WEIGHTED
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("method_a_button")
                            .background(
                                if (isMethodA) SoiborCyan.copy(alpha = 0.2f) else TerminalNavySurface,
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                1.dp,
                                if (isMethodA) SoiborCyan else TerminalNavyCardBorder,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable(enabled = canEdit) {
                                editingConfig = editingConfig.copy(
                                    methodName = BenchmarkMethod.TRANSACTION_WEIGHTED,
                                    versionId = "v1.2.0-TWMR"
                                )
                            }
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "METHOD A: VOLUME-WEIGHTED",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isMethodA) SoiborCyan else LimestoneHighContrast
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "R_t = Σ(V_i * r_i) / Σ(V_i)",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = LimestoneSubtle
                            )
                        }
                    }

                    // Method B Button
                    val isMethodB = editingConfig.methodName == BenchmarkMethod.ROBUST_TRIMMED_MEAN
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("method_b_button")
                            .background(
                                if (isMethodB) SoiborCyan.copy(alpha = 0.2f) else TerminalNavySurface,
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                1.dp,
                                if (isMethodB) SoiborCyan else TerminalNavyCardBorder,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable(enabled = canEdit) {
                                editingConfig = editingConfig.copy(
                                    methodName = BenchmarkMethod.ROBUST_TRIMMED_MEAN,
                                    versionId = "v1.2.0-TRIMMED"
                                )
                            }
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "METHOD B: TRIMMED-MEAN",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isMethodB) SoiborCyan else LimestoneHighContrast
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Volume-trimmed tails (${editingConfig.trimPercentage.toInt()}%)",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = LimestoneSubtle
                            )
                        }
                    }
                }

                if (editingConfig.methodName == BenchmarkMethod.ROBUST_TRIMMED_MEAN) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Trimming Percentage (α): ${editingConfig.trimPercentage.toInt()}% (Tail Cut: ${editingConfig.trimPercentage / 2.0}%)",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = LimestoneHighContrast
                    )
                    Slider(
                        value = editingConfig.trimPercentage.toFloat(),
                        onValueChange = { editingConfig = editingConfig.copy(trimPercentage = it.toDouble()) },
                        valueRange = 0f..30f,
                        steps = 5,
                        enabled = canEdit,
                        colors = SliderDefaults.colors(
                            thumbColor = SoiborCyan,
                            activeTrackColor = SoiborCyan,
                            inactiveTrackColor = TerminalNavySurface
                        ),
                        modifier = Modifier.testTag("trimming_slider")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Minimum Activity Thresholds Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "MIN AGGREGATE VOL:",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(200.0, 500.0, 1000.0).forEach { vol ->
                                val sel = editingConfig.minAggregateVolumeAudMillions == vol
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(if (sel) SoiborCyan.copy(alpha = 0.2f) else TerminalNavySurface, RoundedCornerShape(3.dp))
                                        .border(1.dp, if (sel) SoiborCyan else TerminalNavyCardBorder, RoundedCornerShape(3.dp))
                                        .clickable(enabled = canEdit) {
                                            editingConfig = editingConfig.copy(minAggregateVolumeAudMillions = vol)
                                        }
                                        .padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "A$ ${vol.toInt()}M",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (sel) SoiborCyan else LimestoneMuted
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "MIN TRADE COUNT:",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = LimestoneMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(3, 5, 8).forEach { cnt ->
                                val sel = editingConfig.minTransactionCount == cnt
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(if (sel) SoiborCyan.copy(alpha = 0.2f) else TerminalNavySurface, RoundedCornerShape(3.dp))
                                        .border(1.dp, if (sel) SoiborCyan else TerminalNavyCardBorder, RoundedCornerShape(3.dp))
                                        .clickable(enabled = canEdit) {
                                            editingConfig = editingConfig.copy(minTransactionCount = cnt)
                                        }
                                        .padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$cnt trades",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (sel) SoiborCyan else LimestoneMuted
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Outlier Filter Selector
                Text(
                    text = "OUTLIER FILTER CONVENTION:",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = LimestoneMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlierMethod.entries.forEach { method ->
                        val sel = editingConfig.outlierMethod == method
                        val shortLabel = when (method) {
                            OutlierMethod.Z_SCORE -> "Z-Score (2.5σ)"
                            OutlierMethod.MAD -> "3× MAD"
                            OutlierMethod.BPS_BAND -> "±20 bps Band"
                            OutlierMethod.NONE -> "None"
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (sel) SoiborCyan.copy(alpha = 0.2f) else TerminalNavySurface, RoundedCornerShape(3.dp))
                                .border(1.dp, if (sel) SoiborCyan else TerminalNavyCardBorder, RoundedCornerShape(3.dp))
                                .clickable(enabled = canEdit) {
                                    editingConfig = editingConfig.copy(outlierMethod = method)
                                }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = shortLabel,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                color = if (sel) SoiborCyan else LimestoneMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Dataset Selector
                Text(
                    text = "TEST DATASET SOURCE:",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = LimestoneMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    availableDatasets.forEach { ds ->
                        val isDsSel = activeDataset == ds
                        val shortTitle = when (ds) {
                            "Baseline Interbank Session" -> "Baseline"
                            "Month-End Liquidity Squeeze" -> "Month-End"
                            "Outlier Contamination Stress" -> "Outliers"
                            "Low Liquidity / Dry Market" -> "Low Liquidity"
                            else -> ds
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isDsSel) TerminalAmber.copy(alpha = 0.2f) else TerminalNavySurface, RoundedCornerShape(3.dp))
                                .border(1.dp, if (isDsSel) TerminalAmber else TerminalNavyCardBorder, RoundedCornerShape(3.dp))
                                .clickable { viewModel.selectDataset(ds) }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = shortTitle,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isDsSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isDsSel) TerminalAmber else LimestoneMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Execute Recalculation Button
                Button(
                    onClick = {
                        viewModel.updateMethodology(editingConfig)
                        viewModel.executeCalculation()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SoiborCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("execute_calculation_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Refresh, contentDescription = "Run", modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "APPLY METHODOLOGY & RECALCULATE FIXING",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section 2: Calculation Run Breakdown & Audit Checksum
        latestRun?.let { run ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalNavyCard, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CALCULATION RUN AUDIT CERTIFICATE",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = LimestoneWhite
                            )
                            Text(
                                text = "Run ID: ${run.runId} | ${run.timestampSydney}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = LimestoneMuted
                            )
                        }

                        val (statusColor, statusBg) = if (run.status.isSuccess) {
                            Pair(TerminalGreen, Color(0xFF064E3B))
                        } else {
                            Pair(TerminalRed, Color(0xFF450A0A))
                        }

                        Box(
                            modifier = Modifier
                                .background(statusBg, RoundedCornerShape(3.dp))
                                .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = run.status.label,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Fixing Result Display
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalNavySurface, RoundedCornerShape(4.dp))
                            .border(1.dp, TerminalNavyCardBorder, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "SOIBOR Proposed Fixing Rate:",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = LimestoneHighContrast
                                )
                                Text(
                                    text = "Checksum: ${run.auditChecksum}",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = LimestoneSubtle
                                )
                            }

                            if (run.fixingRatePercent != null) {
                                Text(
                                    text = "${String.format(Locale.US, "%.4f", run.fixingRatePercent)} %",
                                    fontSize = 20.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = SoiborCyan
                                )
                            } else {
                                Text(
                                    text = "UNPUBLISHED",
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalRed
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Constituent Audit Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RunStatItem(
                            label = "ELIGIBLE VOL",
                            value = "A$ ${String.format(Locale.US, "%,.0f", run.totalEligibleVolumeAudMillions)}M",
                            modifier = Modifier.weight(1f)
                        )
                        RunStatItem(
                            label = "TRADES USED",
                            value = "${run.totalEligibleTransactionCount} / ${run.totalSubmittedTransactions}",
                            modifier = Modifier.weight(1f)
                        )
                        RunStatItem(
                            label = "TRIMMED VOL",
                            value = "A$ ${String.format(Locale.US, "%,.0f", run.trimmedVolumeAudMillions)}M",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (run.warnings.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        run.warnings.forEach { w ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = "Warning", tint = TerminalAmber, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = w, fontSize = 10.sp, color = TerminalAmber)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RunStatItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(TerminalNavySurface, RoundedCornerShape(3.dp))
            .padding(6.dp)
    ) {
        Column {
            Text(text = label, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = LimestoneMuted)
            Text(text = value, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LimestoneWhite)
        }
    }
}
