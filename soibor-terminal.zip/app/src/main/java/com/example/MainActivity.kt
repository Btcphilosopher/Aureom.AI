package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.components.TerminalHeader
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AuditProvenanceScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MethodologyLabScreen
import com.example.ui.screens.ScenarioScreen
import com.example.ui.screens.YieldCurveScreen
import com.example.ui.theme.LimestoneHighContrast
import com.example.ui.theme.LimestoneMuted
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SoiborCyan
import com.example.ui.theme.TerminalNavyBackground
import com.example.ui.theme.TerminalNavyCard
import com.example.ui.theme.TerminalNavyCardBorder
import com.example.ui.theme.TerminalNavyDarkest

enum class TerminalWorkspaceTab(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    DASHBOARD("OVERVIEW", Icons.Default.Dashboard, "tab_dashboard"),
    ANALYTICS("SPREADS", Icons.Default.Analytics, "tab_analytics"),
    YIELD_CURVE("CURVES", Icons.Default.Timeline, "tab_yield_curve"),
    METHODOLOGY_LAB("LAB", Icons.Default.Biotech, "tab_methodology_lab"),
    GOVERNANCE("GOVERNANCE", Icons.Default.Security, "tab_governance")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SoiborTerminalApp()
            }
        }
    }
}

@Composable
fun SoiborTerminalApp(
    viewModel: MainViewModel = viewModel()
) {
    var selectedTab by remember { mutableStateOf(TerminalWorkspaceTab.DASHBOARD) }
    val currentRole by viewModel.currentUserRole.collectAsState()

    // Handle Android system Back button: if not on DASHBOARD, return to DASHBOARD
    BackHandler(enabled = selectedTab != TerminalWorkspaceTab.DASHBOARD) {
        selectedTab = TerminalWorkspaceTab.DASHBOARD
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalNavyBackground),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            Column(modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)) {
                TerminalHeader(
                    currentRole = currentRole,
                    onRoleSelected = { viewModel.setUserRole(it) }
                )
            }
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .fillMaxWidth()
                    .background(TerminalNavyDarkest)
                    .border(1.dp, TerminalNavyCardBorder)
            ) {
                NavigationBar(
                    containerColor = TerminalNavyDarkest,
                    modifier = Modifier.height(58.dp)
                ) {
                    TerminalWorkspaceTab.entries.forEach { tab ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SoiborCyan,
                                selectedTextColor = SoiborCyan,
                                unselectedIconColor = LimestoneMuted,
                                unselectedTextColor = LimestoneMuted,
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                TerminalWorkspaceTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                TerminalWorkspaceTab.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                TerminalWorkspaceTab.YIELD_CURVE -> YieldCurveScreen(viewModel = viewModel)
                TerminalWorkspaceTab.METHODOLOGY_LAB -> MethodologyLabScreen(viewModel = viewModel)
                TerminalWorkspaceTab.GOVERNANCE -> GovernanceAndExportScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun GovernanceAndExportScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var subTab by remember { mutableStateOf("AUDIT_EXPORT") } // "AUDIT_EXPORT" or "SCENARIOS"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalNavyBackground)
    ) {
        // Sub-navigation Switcher
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalNavyCard)
                .border(1.dp, TerminalNavyCardBorder)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isAudit = subTab == "AUDIT_EXPORT"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isAudit) SoiborCyan.copy(alpha = 0.2f) else TerminalNavyDarkest,
                            RoundedCornerShape(4.dp)
                        )
                        .border(
                            1.dp,
                            if (isAudit) SoiborCyan else TerminalNavyCardBorder,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { subTab = "AUDIT_EXPORT" }
                        .padding(vertical = 6.dp),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text(
                        text = "AUDIT & EXPORT ENGINE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isAudit) FontWeight.Bold else FontWeight.Normal,
                        color = if (isAudit) SoiborCyan else LimestoneHighContrast
                    )
                }

                val isScen = subTab == "SCENARIOS"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isScen) SoiborCyan.copy(alpha = 0.2f) else TerminalNavyDarkest,
                            RoundedCornerShape(4.dp)
                        )
                        .border(
                            1.dp,
                            if (isScen) SoiborCyan else TerminalNavyCardBorder,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { subTab = "SCENARIOS" }
                        .padding(vertical = 6.dp),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text(
                        text = "STRESS SCENARIO LAB",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isScen) FontWeight.Bold else FontWeight.Normal,
                        color = if (isScen) SoiborCyan else LimestoneHighContrast
                    )
                }
            }
        }

        if (subTab == "AUDIT_EXPORT") {
            AuditProvenanceScreen(viewModel = viewModel)
        } else {
            ScenarioScreen(viewModel = viewModel)
        }
    }
}
