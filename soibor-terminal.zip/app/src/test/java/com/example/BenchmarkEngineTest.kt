package com.example

import com.example.domain.engine.BenchmarkEngine
import com.example.domain.model.BenchmarkMethod
import com.example.domain.model.CalculationStatus
import com.example.domain.model.FundingTransaction
import com.example.domain.model.MethodologyConfig
import com.example.domain.model.OutlierMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BenchmarkEngineTest {

    @Test
    fun testTransactionWeightedRate_matchesKnownSample() {
        val transactions = listOf(
            FundingTransaction("TX-1", "09:00 AEDT", 4.3000, 100.0, "Bank A", "Bank B"),
            FundingTransaction("TX-2", "10:00 AEDT", 4.4000, 200.0, "Bank B", "Bank C"),
            FundingTransaction("TX-3", "11:00 AEDT", 4.3500, 300.0, "Bank C", "Bank D"),
            FundingTransaction("TX-4", "12:00 AEDT", 4.3800, 400.0, "Bank D", "Bank E"),
            FundingTransaction("TX-5", "13:00 AEDT", 4.3600, 500.0, "Bank E", "Bank A")
        )

        val config = MethodologyConfig(
            methodName = BenchmarkMethod.TRANSACTION_WEIGHTED,
            minAggregateVolumeAudMillions = 500.0,
            minTransactionCount = 5,
            publicationPrecisionDecimals = 4,
            outlierMethod = OutlierMethod.NONE
        )

        val run = BenchmarkEngine.calculateBenchmark(transactions, config)

        assertEquals(CalculationStatus.PUBLISHED, run.status)
        assertNotNull(run.fixingRatePercent)
        // 6547.0 / 1500.0 = 4.3646666... -> rounded to 4 decimals = 4.3647
        assertEquals(4.3647, run.fixingRatePercent!!, 0.0001)
        assertEquals(1500.0, run.totalEligibleVolumeAudMillions, 0.01)
        assertEquals(5, run.totalEligibleTransactionCount)
        assertTrue(run.auditChecksum.startsWith("SHA256-"))
    }

    @Test
    fun testZeroEligibleVolume_returnsExplicitInsufficientVolumeStatus() {
        val emptyTransactions = emptyList<FundingTransaction>()
        val config = MethodologyConfig()

        val run = BenchmarkEngine.calculateBenchmark(emptyTransactions, config)

        assertEquals(CalculationStatus.INSUFFICIENT_VOLUME, run.status)
        assertNull(run.fixingRatePercent) // Never fallback silently to model estimate
        assertTrue(run.isFallback)
        assertTrue(run.warnings.isNotEmpty())
    }

    @Test
    fun testDuplicateTransactions_areDetectedAndExcluded() {
        val transactions = listOf(
            FundingTransaction("TX-SAME", "09:00 AEDT", 4.3500, 200.0, "Bank A", "Bank B"),
            FundingTransaction("TX-SAME", "09:00 AEDT", 4.3500, 200.0, "Bank A", "Bank B"), // Duplicate
            FundingTransaction("TX-UNIQUE-1", "10:00 AEDT", 4.3550, 200.0, "Bank B", "Bank C"),
            FundingTransaction("TX-UNIQUE-2", "11:00 AEDT", 4.3520, 200.0, "Bank C", "Bank D"),
            FundingTransaction("TX-UNIQUE-3", "12:00 AEDT", 4.3500, 200.0, "Bank D", "Bank E"),
            FundingTransaction("TX-UNIQUE-4", "13:00 AEDT", 4.3500, 200.0, "Bank E", "Bank A")
        )

        val config = MethodologyConfig(
            deduplicateByTradeId = true,
            minAggregateVolumeAudMillions = 500.0,
            minTransactionCount = 5
        )

        val run = BenchmarkEngine.calculateBenchmark(transactions, config)

        assertEquals(6, run.totalSubmittedTransactions)
        assertEquals(5, run.totalEligibleTransactionCount)
        assertEquals(1, run.excludedTransactionsCount)
        assertTrue(run.warnings.any { it.contains("duplicate") })
    }

    @Test
    fun testOutlierDetection_filtersExtremeObservation() {
        val normalRate = 4.3500
        val transactions = mutableListOf(
            FundingTransaction("TX-1", "09:00 AEDT", normalRate, 200.0, "Bank A", "Bank B"),
            FundingTransaction("TX-2", "10:00 AEDT", normalRate + 0.002, 200.0, "Bank B", "Bank C"),
            FundingTransaction("TX-3", "11:00 AEDT", normalRate - 0.002, 200.0, "Bank C", "Bank D"),
            FundingTransaction("TX-4", "12:00 AEDT", normalRate, 200.0, "Bank D", "Bank E"),
            FundingTransaction("TX-5", "13:00 AEDT", normalRate, 200.0, "Bank E", "Bank A"),
            FundingTransaction("TX-OUTLIER", "14:00 AEDT", 5.2500, 100.0, "Bank X", "Bank Y") // Massive outlier (+90 bps)
        )

        val config = MethodologyConfig(
            outlierMethod = OutlierMethod.Z_SCORE,
            outlierThreshold = 2.0,
            minAggregateVolumeAudMillions = 500.0,
            minTransactionCount = 5
        )

        val run = BenchmarkEngine.calculateBenchmark(transactions, config)

        val outlierTx = run.constituentTransactions.find { it.transactionId == "TX-OUTLIER" }
        assertNotNull(outlierTx)
        assertTrue(outlierTx!!.isOutlier)
        assertFalse(outlierTx.isEligible)
        assertTrue(run.warnings.any { it.contains("statistical outlier") })
    }

    @Test
    fun testIneligibleCurrencyAndTenor_areFiltered() {
        val transactions = listOf(
            FundingTransaction("TX-1", "09:00 AEDT", 4.3500, 200.0, "Bank A", "Bank B", currency = "USD"), // Foreign ccy
            FundingTransaction("TX-2", "10:00 AEDT", 4.3500, 200.0, "Bank B", "Bank C", tenor = "1M"), // Term tenor
            FundingTransaction("TX-3", "11:00 AEDT", 4.3500, 200.0, "Bank C", "Bank D"),
            FundingTransaction("TX-4", "12:00 AEDT", 4.3500, 200.0, "Bank D", "Bank E"),
            FundingTransaction("TX-5", "13:00 AEDT", 4.3500, 200.0, "Bank E", "Bank A"),
            FundingTransaction("TX-6", "14:00 AEDT", 4.3500, 200.0, "Bank A", "Bank C"),
            FundingTransaction("TX-7", "15:00 AEDT", 4.3500, 200.0, "Bank B", "Bank D")
        )

        val config = MethodologyConfig(
            minAggregateVolumeAudMillions = 500.0,
            minTransactionCount = 5
        )

        val run = BenchmarkEngine.calculateBenchmark(transactions, config)

        assertEquals(5, run.totalEligibleTransactionCount)
        assertEquals(2, run.excludedTransactionsCount)
    }

    @Test
    fun testMethodB_robustTrimmedMean_recordsTrimmedStats() {
        val transactions = listOf(
            FundingTransaction("TX-LOW", "09:00 AEDT", 4.3000, 100.0, "Bank A", "Bank B"),
            FundingTransaction("TX-MID1", "10:00 AEDT", 4.3500, 300.0, "Bank B", "Bank C"),
            FundingTransaction("TX-MID2", "11:00 AEDT", 4.3500, 300.0, "Bank C", "Bank D"),
            FundingTransaction("TX-MID3", "12:00 AEDT", 4.3500, 300.0, "Bank D", "Bank E"),
            FundingTransaction("TX-HIGH", "13:00 AEDT", 4.4000, 100.0, "Bank E", "Bank A")
        )

        val config = MethodologyConfig(
            methodName = BenchmarkMethod.ROBUST_TRIMMED_MEAN,
            trimPercentage = 18.0,
            minAggregateVolumeAudMillions = 500.0,
            minTransactionCount = 3,
            outlierMethod = OutlierMethod.NONE
        )

        val run = BenchmarkEngine.calculateBenchmark(transactions, config)

        assertEquals(CalculationStatus.PUBLISHED, run.status)
        assertTrue(run.trimmedVolumeAudMillions > 0.0)
        assertTrue(run.trimmedTransactionsCount > 0)
        assertNotNull(run.fixingRatePercent)
    }
}
