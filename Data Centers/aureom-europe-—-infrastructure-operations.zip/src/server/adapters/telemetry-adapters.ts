import {DataSourceType, TelemetryIngestionSample} from '../../shared/models';

/**
 * Adapter interface definitions aligned with official protocol specifications:
 * - DMTF Redfish v1 (/redfish/v1/Chassis/{id}/ThermalSubsystem)
 * - SNMPv3 Read-Only (IF-MIB::ifHCInOctets, ENTITY-SENSOR-MIB)
 * - Prometheus / OpenMetrics exposition (/metrics, DCGM_FI_DEV_*)
 * - BMS Modbus/BACnet Read-Only Gateway (strictly isolated from safety interlocks)
 * - Slurm REST API (slurmrestd v0.0.40 /slurm/v0.0.40/nodes & /jobs)
 * - Storage Management API (Ceph MGR / NetApp ONTAP REST / Lustre LNet)
 */
export interface TelemetryCollectorAdapter {
  readonly adapterId: string;
  readonly sourceType: DataSourceType;
  readonly protocolReference: string;
  readonly readOnly: boolean;
  collectSamples(nowIso: string): TelemetryIngestionSample[];
}

export class RedfishCollectorAdapter implements TelemetryCollectorAdapter {
  readonly adapterId = 'redfish-ro-collector';
  readonly sourceType: DataSourceType = 'Redfish';
  readonly protocolReference = 'DMTF DSP0266 Redfish v1.18 (Read-Only ServiceAccount)';
  readonly readOnly = true;

  collectSamples(nowIso: string): TelemetryIngestionSample[] {
    const jitter = (base: number, amp: number) =>
      Number((base + (Math.random() - 0.5) * amp).toFixed(2));
    return [
      {
        equipmentId: 'cpu-fra-a01-01',
        metricKey: 'inlet_temp_c',
        label: 'Inlet Temperature',
        value: jitter(22.4, 0.8),
        unit: '°C',
        source: 'Redfish',
        observedAt: nowIso,
      },
      {
        equipmentId: 'cpu-fra-a01-01',
        metricKey: 'power_w',
        label: 'System Input Power',
        value: jitter(410, 24),
        unit: 'W',
        source: 'Redfish',
        observedAt: nowIso,
      },
      {
        equipmentId: 'gpu-fra-b09-01',
        metricKey: 'power_w',
        label: 'Chassis Input Power',
        value: jitter(6450, 180),
        unit: 'W',
        source: 'Redfish',
        observedAt: nowIso,
      },
    ];
  }
}

export class PrometheusDcgmAdapter implements TelemetryCollectorAdapter {
  readonly adapterId = 'prom-dcgm-collector';
  readonly sourceType: DataSourceType = 'Prometheus';
  readonly protocolReference = 'OpenMetrics 1.0 / NVIDIA DCGM Exporter v3.3';
  readonly readOnly = true;

  collectSamples(nowIso: string): TelemetryIngestionSample[] {
    const jitter = (base: number, amp: number) =>
      Number((base + (Math.random() - 0.5) * amp).toFixed(1));
    return [
      {
        equipmentId: 'cpu-fra-a01-01',
        metricKey: 'cpu_util_pct',
        label: 'CPU Utilisation',
        value: jitter(64.2, 6),
        unit: '%',
        source: 'Prometheus',
        observedAt: nowIso,
      },
      {
        equipmentId: 'gpu-fra-b09-01',
        metricKey: 'gpu_util_pct',
        label: 'GPU SM Utilisation',
        value: jitter(91.5, 4),
        unit: '%',
        source: 'Prometheus',
        observedAt: nowIso,
      },
    ];
  }
}

export class SnmpNetworkAdapter implements TelemetryCollectorAdapter {
  readonly adapterId = 'snmpv3-ifmib-collector';
  readonly sourceType: DataSourceType = 'SNMPv3';
  readonly protocolReference = 'RFC 3414 SNMPv3 AuthPriv / IF-MIB 64-bit Counters';
  readonly readOnly = true;
  private counter = 984_210_000_000;

  collectSamples(nowIso: string): TelemetryIngestionSample[] {
    this.counter += Math.floor(Math.random() * 5_000_000);
    return [
      {
        equipmentId: 'net-fra-a01-leaf1',
        metricKey: 'uplink_rx_gbps',
        label: 'Uplink Rx Throughput',
        value: Number((142.8 + (Math.random() - 0.5) * 8).toFixed(2)),
        unit: 'Gbps',
        source: 'SNMPv3',
        observedAt: nowIso,
        rawCounter: this.counter,
        counterMax: Number.MAX_SAFE_INTEGER,
      },
    ];
  }
}

export interface WriteControlAdapter {
  readonly adapterId: string;
  readonly mode: 'MockAdapter' | 'LiveNetconf';
  readonly allowArbitraryCli: false;
  applyProposedConfig(proposalId: string, switchId: string): {
    acknowledged: boolean;
    verifiedOperational: boolean;
    message: string;
  };
}

export class MockNetworkWriteAdapter implements WriteControlAdapter {
  readonly adapterId = 'mock-netconf-change-adapter';
  readonly mode = 'MockAdapter' as const;
  readonly allowArbitraryCli = false as const;

  applyProposedConfig(proposalId: string, switchId: string) {
    return {
      acknowledged: true,
      verifiedOperational: true,
      message: `Mock NETCONF candidate commit ${proposalId} acknowledged by ${switchId} and verified against operational YANG state.`,
    };
  }
}
