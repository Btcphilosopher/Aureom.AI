import {
  AuditEntry,
  AutomationActionType,
  AutomationState,
  AutomationWorkflow,
  CustomerWorkload,
  Equipment,
  Incident,
  IncidentEvidence,
  IncidentSeverity,
  SecuritySession,
} from '../../shared/models';

export interface AlarmSignal {
  dedupKey: string;
  correlationGroup?: string;
  siteId: string;
  title: string;
  severity: IncidentSeverity;
  assetId: string;
  metricKey: string;
  source: IncidentEvidence['source'];
  summary: string;
  observedAt: string;
  affectedWorkloadIds: string[];
}

/**
 * Deduplicates repeated alarms matching the same dedupKey, or correlates related
 * symptoms in the same correlationGroup without suppressing any raw evidence.
 */
export function ingestAlarmIntoIncidents(
  incidents: Incident[],
  alarm: AlarmSignal,
): {incident: Incident; deduplicated: boolean; correlated: boolean} {
  const nowIso = new Date().toISOString();

  const exactExisting = incidents.find(
    (inc) => inc.dedupKey === alarm.dedupKey && inc.status !== 'Resolved',
  );

  const evidenceItem: IncidentEvidence = {
    id: `EV-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: alarm.observedAt,
    source: alarm.source,
    assetId: alarm.assetId,
    metricKey: alarm.metricKey,
    summary: alarm.summary,
  };

  if (exactExisting) {
    exactExisting.occurrenceCount += 1;
    exactExisting.lastSeenAt = alarm.observedAt;
    exactExisting.evidence.unshift(evidenceItem);
    if (!exactExisting.affectedAssetIds.includes(alarm.assetId)) {
      exactExisting.affectedAssetIds.push(alarm.assetId);
    }
    for (const wid of alarm.affectedWorkloadIds) {
      if (!exactExisting.affectedWorkloadIds.includes(wid)) {
        exactExisting.affectedWorkloadIds.push(wid);
      }
    }
    return {incident: exactExisting, deduplicated: true, correlated: false};
  }

  if (alarm.correlationGroup) {
    const relatedParent = incidents.find(
      (inc) =>
        inc.siteId === alarm.siteId &&
        inc.status !== 'Resolved' &&
        inc.dedupKey.startsWith(alarm.correlationGroup ?? ''),
    );
    if (relatedParent) {
      relatedParent.occurrenceCount += 1;
      relatedParent.lastSeenAt = alarm.observedAt;
      relatedParent.evidence.unshift(evidenceItem);
      if (!relatedParent.correlatedSymptoms.includes(alarm.title)) {
        relatedParent.correlatedSymptoms.push(alarm.title);
      }
      if (!relatedParent.affectedAssetIds.includes(alarm.assetId)) {
        relatedParent.affectedAssetIds.push(alarm.assetId);
      }
      for (const wid of alarm.affectedWorkloadIds) {
        if (!relatedParent.affectedWorkloadIds.includes(wid)) {
          relatedParent.affectedWorkloadIds.push(wid);
        }
      }
      relatedParent.timeline.unshift({
        id: `TL-${Date.now().toString(36)}`,
        timestamp: nowIso,
        actor: 'CorrelationEngine',
        action: 'SymptomCorrelated',
        note: `Correlated alarm "${alarm.title}" on ${alarm.assetId} without suppressing evidence.`,
      });
      return {incident: relatedParent, deduplicated: false, correlated: true};
    }
  }

  const created: Incident = {
    id: `INC-2026-${String(incidents.length + 42).padStart(3, '0')}`,
    dedupKey: alarm.dedupKey,
    siteId: alarm.siteId,
    title: alarm.title,
    severity: alarm.severity,
    status: 'Open',
    occurrenceCount: 1,
    firstSeenAt: alarm.observedAt,
    lastSeenAt: alarm.observedAt,
    affectedAssetIds: [alarm.assetId],
    affectedWorkloadIds: [...alarm.affectedWorkloadIds],
    correlatedSymptoms: [alarm.title],
    assignee: alarm.siteId === 'PAR-02' ? 'oncall-par@aureom.eu' : 'oncall-fra@aureom.eu',
    evidence: [evidenceItem],
    timeline: [
      {
        id: `TL-${Date.now().toString(36)}`,
        timestamp: nowIso,
        actor: 'AlertIngestion',
        action: 'IncidentOpened',
        note: alarm.summary,
      },
    ],
  };

  incidents.unshift(created);
  return {incident: created, deduplicated: false, correlated: false};
}

const NEXT_AUTOMATION_STATE: Record<AutomationState, AutomationState | null> = {
  Proposed: 'Validated',
  Validated: 'Approved',
  Approved: 'Scheduled',
  Scheduled: 'Executing',
  Executing: 'Verified',
  Verified: 'Completed',
  Completed: null,
  Failed: null,
};

export function createControlledWorkflow(
  equipment: Equipment,
  actionType: AutomationActionType,
  idempotencyKey: string,
  session: SecuritySession,
  workloads: CustomerWorkload[],
  existingWorkflows: AutomationWorkflow[],
  simulateFailure = false,
): {ok: boolean; workflow?: AutomationWorkflow; error?: string; deduplicated?: boolean} {
  // Idempotency guard
  const duplicate = existingWorkflows.find(
    (w) => w.idempotencyKey === idempotencyKey,
  );
  if (duplicate) {
    return {ok: true, workflow: duplicate, deduplicated: true};
  }

  if (!session.siteScopes.includes(equipment.siteId) && session.role !== 'SuperAdmin') {
    return {
      ok: false,
      error: `RBAC denied: operator role ${session.role} does not hold site scope for ${equipment.siteId}.`,
    };
  }

  const activeWorkloads = workloads.filter(
    (w) => w.equipmentId === equipment.id && w.customerStatus === 'RUNNING',
  );
  const nonMigratable = activeWorkloads.filter((w) => !w.migratable);

  const preflightChecks = [
    {
      name: 'Active Workload Inspection',
      passed:
        actionType !== 'request_workload_migration' ||
        nonMigratable.length === 0,
      detail:
        activeWorkloads.length === 0
          ? 'No active customer workloads running on target host.'
          : nonMigratable.length > 0
            ? `${nonMigratable.length} non-migratable workload(s): ${nonMigratable
                .map((w) => `${w.resourceName} (${w.migrationConstraintReason ?? 'Pinned'})`)
                .join('; ')}`
            : `${activeWorkloads.length} workload(s) eligible for graceful drain/migration.`,
    },
    {
      name: 'Safety Interlock Boundary',
      passed: true,
      detail:
        'Action scoped to compute/service plane; electrical EPO, fire, and chiller interlocks isolated.',
    },
    {
      name: 'Rollback & Compensation Plan',
      passed: true,
      detail:
        actionType === 'drain_node'
          ? 'Compensating action: `scontrol update NodeName=' + equipment.name + ' State=RESUME` after thermal check.'
          : 'Compensating action: Revert host service state and escalate to site duty engineer.',
    },
  ];

  if (actionType === 'request_workload_migration' && nonMigratable.length > 0) {
    return {
      ok: false,
      error: `Migration preflight blocked: ${nonMigratable[0].resourceName} cannot live-migrate (${nonMigratable[0].migrationConstraintReason}). Drain or checkpoint required.`,
    };
  }

  const now = new Date().toISOString();
  const wf: AutomationWorkflow = {
    id: `WF-${Date.now().toString(36).toUpperCase()}`,
    idempotencyKey,
    siteId: equipment.siteId,
    targetEquipmentId: equipment.id,
    targetEquipmentName: equipment.name,
    actionType,
    state: 'Proposed',
    requestedBy: session.operatorName,
    createdAt: now,
    updatedAt: now,
    preflightChecks,
    compensatingAction:
      actionType === 'drain_node'
        ? `Resume Slurm node ${equipment.name} via scontrol RESUME once inlet temperature < 27°C.`
        : `Manual verification & rollback runbook for ${equipment.name}.`,
    simulateFailure,
  };

  existingWorkflows.unshift(wf);
  return {ok: true, workflow: wf};
}

export function advanceWorkflowState(
  wf: AutomationWorkflow,
  session: SecuritySession,
  equipment: Equipment | undefined,
): {ok: boolean; workflow: AutomationWorkflow; error?: string; auditOutcome: AuditEntry['outcome']} {
  const nextState = NEXT_AUTOMATION_STATE[wf.state];
  if (!nextState) {
    return {
      ok: false,
      workflow: wf,
      error: `Workflow ${wf.id} is already in terminal state ${wf.state}.`,
      auditOutcome: 'Denied',
    };
  }

  // Enforce RBAC + MFA on Approval & Execution
  if (
    (nextState === 'Approved' || nextState === 'Executing') &&
    (!session.canApproveChanges || !session.mfaVerified)
  ) {
    return {
      ok: false,
      workflow: wf,
      error: !session.canApproveChanges
        ? `Authority denied: role ${session.role} is read-only or lacks operational approval privilege.`
        : 'MFA verification required before approving or executing infrastructure actions.',
      auditOutcome: 'Denied',
    };
  }

  if (
    !session.siteScopes.includes(wf.siteId) &&
    session.role !== 'SuperAdmin'
  ) {
    return {
      ok: false,
      workflow: wf,
      error: `Site-scope denied: operator lacks authority in ${wf.siteId}.`,
      auditOutcome: 'Denied',
    };
  }

  if (nextState === 'Approved') {
    wf.approvedBy = session.operatorName;
  }

  if (nextState === 'Executing' && wf.simulateFailure) {
    wf.state = 'Failed';
    wf.failureReason =
      'Simulated device execution timeout on out-of-band Redfish/Slurm adapter. Compensating action required.';
    wf.updatedAt = new Date().toISOString();
    return {ok: true, workflow: wf, auditOutcome: 'Allowed'};
  }

  wf.state = nextState;
  wf.updatedAt = new Date().toISOString();

  if (equipment && nextState === 'Completed') {
    if (wf.actionType === 'drain_node') {
      equipment.schedulerNodeState = 'DRAIN';
      equipment.operationalStatus = 'Maintenance';
      equipment.lifecycleStatus = 'Maintenance';
    } else if (wf.actionType === 'schedule_maintenance') {
      equipment.operationalStatus = 'Maintenance';
      equipment.lifecycleStatus = 'Maintenance';
    }
  }

  return {ok: true, workflow: wf, auditOutcome: 'Allowed'};
}

export function redactWorkloadsForSession(
  workloads: CustomerWorkload[],
  session: SecuritySession,
): CustomerWorkload[] {
  return workloads.map((w) => {
    const hasSiteAccess =
      session.role === 'SuperAdmin' || session.siteScopes.includes(w.siteId);
    if (w.isRestrictedTenant && (!session.canViewRestrictedTenantDetails || !hasSiteAccess)) {
      return {
        ...w,
        orgName: '[REDACTED-SOVEREIGN-TENANT]',
        projectName: '[REDACTED-PROJECT]',
        resourceName: `workload-${w.id.toLowerCase()}`,
        networkSegment: '[REDACTED-VRF]',
      };
    }
    return w;
  });
}
