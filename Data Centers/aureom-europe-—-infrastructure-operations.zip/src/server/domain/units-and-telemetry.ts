import {
  MetricObservation,
  QualityFlag,
  TelemetryIngestionSample,
} from '../../shared/models';

export function convertUnit(
  value: number,
  fromUnit: string,
  toUnit: string,
): number {
  if (fromUnit === toUnit) return value;

  // Power
  if (fromUnit === 'W' && toUnit === 'kW') return Number((value / 1000).toFixed(4));
  if (fromUnit === 'kW' && toUnit === 'W') return Number((value * 1000).toFixed(2));

  // Temperature
  if (fromUnit === 'F' && toUnit === 'C')
    return Number((((value - 32) * 5) / 9).toFixed(2));
  if (fromUnit === 'C' && toUnit === 'F')
    return Number(((value * 9) / 5 + 32).toFixed(2));

  // Binary storage (TiB / GiB) vs decimal TB
  if (fromUnit === 'GiB' && toUnit === 'TiB') return Number((value / 1024).toFixed(4));
  if (fromUnit === 'TiB' && toUnit === 'GiB') return Number((value * 1024).toFixed(2));
  if (fromUnit === 'TB' && toUnit === 'TiB')
    return Number(((value * 1e12) / Math.pow(1024, 4)).toFixed(4));

  // Network throughput
  if (fromUnit === 'bps' && toUnit === 'Gbps') return Number((value / 1e9).toFixed(4));
  if (fromUnit === 'Mbps' && toUnit === 'Gbps') return Number((value / 1000).toFixed(4));
  if (fromUnit === 'Gbps' && toUnit === 'Mbps') return Number((value * 1000).toFixed(2));

  throw new Error(`Unsupported unit conversion from ${fromUnit} to ${toUnit}`);
}

export function computeQualityFlag(
  observedAtIso: string,
  nowMs: number,
  staleThresholdSeconds: number,
  resetDetected = false,
): {quality: QualityFlag; ageSeconds: number} {
  const observedMs = Date.parse(observedAtIso);
  if (Number.isNaN(observedMs)) {
    return {quality: 'UNAVAILABLE', ageSeconds: Number.POSITIVE_INFINITY};
  }
  const ageSeconds = Math.max(0, Math.round((nowMs - observedMs) / 1000));
  if (resetDetected) {
    return {quality: 'COUNTER_RESET', ageSeconds};
  }
  if (ageSeconds > staleThresholdSeconds) {
    return {quality: 'STALE', ageSeconds};
  }
  if (ageSeconds > Math.floor(staleThresholdSeconds / 3)) {
    return {quality: 'DELAYED', ageSeconds};
  }
  return {quality: 'FRESH', ageSeconds};
}

export interface TelemetryIngestOutcome {
  accepted: boolean;
  reason: 'ingested' | 'duplicate_dropped' | 'delayed_older_than_current' | 'counter_reset_handled';
  observation: MetricObservation<number>;
}

/**
 * Ingests a telemetry observation into an existing metric map for a single device.
 * - Drops duplicate samples with identical observedAt and value
 * - Rejects delayed out-of-order samples older than the current stored observation
 * - Detects SNMP/interface counter wraps or resets without emitting negative deltas
 * - Updates ONLY the targeted metricKey so fresh telemetry on one metric never marks
 *   other metrics on the same device as fresh.
 */
export function ingestMetricObservation(
  existingMetrics: Record<string, MetricObservation<number | string>>,
  sample: TelemetryIngestionSample,
  nowMs: number,
  staleThresholdSeconds: number,
): TelemetryIngestOutcome {
  const current = existingMetrics[sample.metricKey] as
    | MetricObservation<number>
    | undefined;
  const receivedAt = new Date(nowMs).toISOString();
  const sampleTs = Date.parse(sample.observedAt);

  if (current) {
    const currentTs = Date.parse(current.observedAt);
    if (sampleTs === currentTs && Number(current.value) === sample.value) {
      return {
        accepted: false,
        reason: 'duplicate_dropped',
        observation: current,
      };
    }
    if (sampleTs < currentTs) {
      return {
        accepted: false,
        reason: 'delayed_older_than_current',
        observation: current,
      };
    }
  }

  let resetDetected = false;
  let normalizedValue = sample.value;
  if (
    sample.rawCounter !== undefined &&
    current?.rawCounter !== undefined &&
    sample.rawCounter < current.rawCounter
  ) {
    resetDetected = true;
    // Counter reset/wrap detected: preserve positive rate instead of negative delta
    if (sample.counterMax && sample.counterMax > current.rawCounter) {
      const wrappedDelta = sample.counterMax - current.rawCounter + sample.rawCounter;
      normalizedValue = Number((wrappedDelta > 0 ? sample.value : 0).toFixed(3));
    } else {
      normalizedValue = Math.max(0, sample.value);
    }
  }

  const {quality, ageSeconds} = computeQualityFlag(
    sample.observedAt,
    nowMs,
    staleThresholdSeconds,
    resetDetected,
  );

  const nextObs: MetricObservation<number> = {
    key: sample.metricKey,
    label: sample.label,
    value: normalizedValue,
    unit: sample.unit,
    source: sample.source,
    observedAt: sample.observedAt,
    receivedAt,
    quality,
    ageSeconds,
    rawCounter: sample.rawCounter,
    resetDetected,
  };

  existingMetrics[sample.metricKey] = nextObs;

  return {
    accepted: true,
    reason: resetDetected ? 'counter_reset_handled' : 'ingested',
    observation: nextObs,
  };
}

export function refreshAllMetricFreshness(
  metrics: Record<string, MetricObservation<number | string>>,
  nowMs: number,
  staleThresholdSeconds: number,
): void {
  for (const key of Object.keys(metrics)) {
    const obs = metrics[key];
    if (!obs) continue;
    const {quality, ageSeconds} = computeQualityFlag(
      obs.observedAt,
      nowMs,
      staleThresholdSeconds,
      obs.resetDetected ?? false,
    );
    obs.quality = quality;
    obs.ageSeconds = ageSeconds;
  }
}
