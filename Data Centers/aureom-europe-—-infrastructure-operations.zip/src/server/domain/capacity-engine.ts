import {
  CapacityEvaluationInput,
  CapacityForecastPoint,
  CapacityReservation,
  Equipment,
  PuePeriodWindow,
  Rack,
  RackFeasibilityResult,
  Room,
  StoragePool,
  UpstreamPowerNode,
} from '../../shared/models';
import {
  analyzeRackPowerIndependence,
  findContiguousAvailableU,
  validateRackPlacement,
} from './topology-and-rack';

export function evaluatePlacementFeasibility(
  input: CapacityEvaluationInput,
  racks: Rack[],
  rooms: Room[],
  equipment: Equipment[],
  storagePools: StoragePool[],
  upstreamNodes: UpstreamPowerNode[],
): RackFeasibilityResult[] {
  const roomMap = new Map(rooms.map((r) => [r.id, r]));
  const siteStorageFreeTiB = storagePools
    .filter((p) => p.siteId === input.siteId)
    .reduce((acc, p) => acc + Math.max(0, p.usableTiB - p.reservedBufferTiB - p.allocatedTiB), 0);

  return racks
    .filter((rack) => {
      if (rack.siteId !== input.siteId) return false;
      if (input.roomId && rack.roomId !== input.roomId) return false;
      return true;
    })
    .map((rack) => {
      const reasons: string[] = [];
      const rackEquipment = equipment.filter((e) => e.rackId === rack.id);

      // U-space calculation
      const usedU = rackEquipment.reduce(
        (sum, eq) => sum + (eq.uEnd - eq.uStart + 1),
        0,
      );
      const reservedU = rack.reservedSlots.reduce(
        (sum, s) => sum + (s.uEnd - s.uStart + 1),
        0,
      );
      const availableU = Math.max(0, rack.uTotal - usedU - reservedU);
      const suggestedUStart = findContiguousAvailableU(
        rack,
        rackEquipment,
        input.requiredU,
      );

      if (input.requiredU > 0 && suggestedUStart === undefined) {
        reasons.push(
          `Insufficient contiguous rack space: requires ${input.requiredU}U contiguous (${availableU}U fragmented/free).`,
        );
      }

      // Weight limit
      const usedWeight = rackEquipment.reduce((sum, eq) => sum + eq.weightKg, 0);
      const remainingWeightKg = Math.max(0, rack.maxWeightKg - usedWeight);
      if (input.weightKg > remainingWeightKg) {
        reasons.push(
          `Exceeds rack weight limit: needs ${input.weightKg} kg, ${remainingWeightKg} kg remaining (max ${rack.maxWeightKg} kg).`,
        );
      }

      // Power budget
      const reservedPowerKw = rack.reservedSlots.length * 4.5; // conservative per reservation slot if unallocated
      const remainingPowerKw = Number(
        Math.max(0, rack.powerBudgetKw - rack.powerDrawKw.value - reservedPowerKw).toFixed(2),
      );
      if (input.powerKw > remainingPowerKw) {
        reasons.push(
          `Exceeds rack PDU power budget: needs ${input.powerKw} kW, ${remainingPowerKw} kW headroom available.`,
        );
      }

      // Cooling assumption
      const room = roomMap.get(rack.roomId);
      const coolingHeadroom = Number(
        Math.max(0, rack.coolingBudgetKw - rack.powerDrawKw.value).toFixed(2),
      );
      if (input.coolingKw > coolingHeadroom) {
        reasons.push(
          `Exceeds rack cooling capacity (${room?.coolingArchitecture ?? 'Room'}): needs ${input.coolingKw} kW thermal rejection, ${coolingHeadroom} kW remaining.`,
        );
      }

      // Data-location sovereignty constraint
      if (rack.dataLocation !== input.dataLocation) {
        reasons.push(
          `Data-location restriction mismatch: workload requires ${input.dataLocation}, rack is located in ${rack.dataLocation}.`,
        );
      }

      // Resilience & upstream SPOF check
      const powerAnalysis = analyzeRackPowerIndependence(rack, upstreamNodes);
      if (input.resilience === '2N' && !powerAnalysis.independentDualFeed) {
        reasons.push(
          `Fails 2N resilience requirement: ${
            powerAnalysis.sharedAncestor
              ? `shared upstream ${powerAnalysis.sharedAncestor.name}`
              : 'incomplete dual-feed topology'
          }.`,
        );
      }

      // Compute & GPU headroom in rack
      if (input.gpuCount > 0) {
        const freeGpusInRack = rackEquipment
          .flatMap((e) => e.gpus ?? [])
          .filter((g) => !g.schedulerAllocated).length;
        if (freeGpusInRack < input.gpuCount && input.requiredU === 0) {
          reasons.push(
            `Insufficient unallocated GPUs in rack: needs ${input.gpuCount}, ${freeGpusInRack} available.`,
          );
        }
      }

      if (input.cpuCores > 0 && input.requiredU === 0) {
        const freeCores = rackEquipment.reduce(
          (sum, e) =>
            sum + Math.max(0, (e.cpuCores ?? 0) - (e.schedulerAllocatedCores ?? 0)),
          0,
        );
        if (freeCores < input.cpuCores) {
          reasons.push(
            `Insufficient unallocated CPU cores in rack: needs ${input.cpuCores}, ${freeCores} available.`,
          );
        }
      }

      if (input.storageTiB > siteStorageFreeTiB) {
        reasons.push(
          `Insufficient site usable storage pool headroom: needs ${input.storageTiB} TiB, ${siteStorageFreeTiB.toFixed(1)} TiB available.`,
        );
      }

      if (input.networkPorts > 0) {
        const hasTorSwitch = rackEquipment.some((e) => e.category === 'network') || rack.roomId.includes('RM');
        if (!hasTorSwitch) {
          reasons.push('No available leaf switch port capacity mapped.');
        }
      }

      return {
        rackId: rack.id,
        rackCode: rack.code,
        roomId: rack.roomId,
        siteId: rack.siteId,
        feasible: reasons.length === 0,
        availableU,
        remainingWeightKg,
        remainingPowerKw,
        remainingCoolingKw: coolingHeadroom,
        hasIndependentDualFeed: powerAnalysis.independentDualFeed,
        reasons,
        suggestedUStart,
      };
    });
}

export function createTransactionalReservation(
  request: Omit<CapacityReservation, 'id' | 'createdAt' | 'status'>,
  rack: Rack,
  rackEquipment: Equipment[],
  existingReservations: CapacityReservation[],
): {ok: boolean; reservation?: CapacityReservation; errors: string[]} {
  // Check U-slot occupancy & existing reservations
  const placementCheck = validateRackPlacement(
    rack,
    {
      rackId: rack.id,
      uStart: request.uStart,
      uEnd: request.uEnd,
      face: 'full',
    },
    rackEquipment,
  );
  const errors = [...placementCheck.errors];

  // Prevent simultaneous active/approved reservations from exhausting power budget
  const activeRackRes = existingReservations.filter(
    (r) =>
      r.rackId === rack.id &&
      (r.status === 'Proposed' || r.status === 'Approved' || r.status === 'Active'),
  );
  const reservedPowerSum = activeRackRes.reduce((acc, r) => acc + r.powerKw, 0);
  if (rack.powerDrawKw.value + reservedPowerSum + request.powerKw > rack.powerBudgetKw) {
    errors.push(
      `Power budget conflict: current draw (${rack.powerDrawKw.value} kW) + existing reservations (${reservedPowerSum.toFixed(1)} kW) + requested (${request.powerKw} kW) exceeds ${rack.powerBudgetKw} kW.`,
    );
  }

  if (request.dataLocation !== rack.dataLocation) {
    errors.push(
      `Sovereignty mismatch: reservation requires ${request.dataLocation}, rack is ${rack.dataLocation}.`,
    );
  }

  if (errors.length > 0) {
    return {ok: false, errors};
  }

  const reservation: CapacityReservation = {
    ...request,
    id: `RES-${Date.now().toString(36).toUpperCase()}`,
    status: 'Approved',
    createdAt: new Date().toISOString(),
  };

  rack.reservedSlots.push({
    reservationId: reservation.id,
    uStart: reservation.uStart,
    uEnd: reservation.uEnd,
    owner: reservation.owner,
    expiresAt: reservation.expiresAt,
  });

  return {ok: true, reservation, errors: []};
}

/**
 * Calculates Period-Energy PUE strictly from integrated total facility energy
 * and IT equipment energy over the identical defined time period and boundary.
 */
export function computePeriodEnergyPue(
  totalFacilityEnergyKwh: number,
  itEquipmentEnergyKwh: number,
  startAtIso: string,
  endAtIso: string,
): {valid: boolean; pue?: number; error?: string} {
  const start = Date.parse(startAtIso);
  const end = Date.parse(endAtIso);
  if (Number.isNaN(start) || Number.isNaN(end) || end <= start) {
    return {valid: false, error: 'Invalid or non-positive integration period.'};
  }
  if (itEquipmentEnergyKwh <= 0 || totalFacilityEnergyKwh < itEquipmentEnergyKwh) {
    return {
      valid: false,
      error:
        'Total facility energy must be >= IT equipment energy and IT energy must be > 0.',
    };
  }
  const pue = Number((totalFacilityEnergyKwh / itEquipmentEnergyKwh).toFixed(3));
  return {valid: true, pue};
}

export function validatePueInputs(window: PuePeriodWindow): boolean {
  const res = computePeriodEnergyPue(
    window.totalFacilityEnergyKwh,
    window.itEquipmentEnergyKwh,
    window.startAt,
    window.endAt,
  );
  return res.valid;
}

export function buildForecastSeries(
  basePowerKw: number,
  maxPowerKw: number,
  baseGpuCount: number,
  maxGpuCount: number,
): CapacityForecastPoint[] {
  const months = ['2026-12', '2027-01', '2027-02', '2027-03', '2027-04', '2027-05'];
  return months.map((monthLabel, idx) => {
    const step = idx + 1;
    const growth = 1 + step * 0.055;
    const uncertainty = 0.04 + step * 0.025;
    const powerUsedKw = Number((basePowerKw * growth).toFixed(1));
    const powerLowerBoundKw = Number((powerUsedKw * (1 - uncertainty)).toFixed(1));
    const powerUpperBoundKw = Number((powerUsedKw * (1 + uncertainty)).toFixed(1));

    const gpuGrowth = Math.round(baseGpuCount * (1 + step * 0.07));
    const gpuUnc = Math.max(2, Math.round(gpuGrowth * uncertainty));

    return {
      monthLabel,
      powerUsedKw,
      powerLowerBoundKw,
      powerUpperBoundKw,
      powerCapacityKw: maxPowerKw,
      gpuUsedCount: gpuGrowth,
      gpuLowerBound: Math.max(0, gpuGrowth - gpuUnc),
      gpuUpperBound: gpuGrowth + gpuUnc,
      gpuCapacityCount: maxGpuCount,
    };
  });
}
