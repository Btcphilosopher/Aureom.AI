import {
  Equipment,
  Rack,
  TopologyDependencyWarning,
  UpstreamPowerNode,
} from '../../shared/models';

export interface RackPlacementCandidate {
  id?: string;
  rackId: string;
  uStart: number;
  uEnd: number;
  face: 'front' | 'rear' | 'full';
}

export interface OccupancyValidationResult {
  valid: boolean;
  errors: string[];
}

function facesConflict(
  a: 'front' | 'rear' | 'full',
  b: 'front' | 'rear' | 'full',
): boolean {
  if (a === 'full' || b === 'full') return true;
  return a === b;
}

function uRangesOverlap(
  aStart: number,
  aEnd: number,
  bStart: number,
  bEnd: number,
): boolean {
  return aStart <= bEnd && bStart <= aEnd;
}

export function validateRackPlacement(
  rack: Rack,
  candidate: RackPlacementCandidate,
  existingEquipmentInRack: Equipment[],
): OccupancyValidationResult {
  const errors: string[] = [];

  if (!Number.isInteger(candidate.uStart) || !Number.isInteger(candidate.uEnd)) {
    errors.push('Rack unit coordinates must be integers.');
  }
  if (candidate.uStart < 1 || candidate.uEnd < candidate.uStart) {
    errors.push(
      `Invalid U-range U${candidate.uStart}-U${candidate.uEnd}: uStart must be >= 1 and <= uEnd.`,
    );
  }
  if (candidate.uEnd > rack.uTotal) {
    errors.push(
      `Placement U${candidate.uStart}-U${candidate.uEnd} exceeds rack ${rack.code} height (${rack.uTotal}U).`,
    );
  }

  for (const eq of existingEquipmentInRack) {
    if (candidate.id && eq.id === candidate.id) continue;
    if (
      uRangesOverlap(candidate.uStart, candidate.uEnd, eq.uStart, eq.uEnd) &&
      facesConflict(candidate.face, eq.face)
    ) {
      errors.push(
        `Overlap conflict with ${eq.name} (${eq.assetTag}) at U${eq.uStart}-U${eq.uEnd} (${eq.face}).`,
      );
    }
  }

  for (const res of rack.reservedSlots) {
    if (uRangesOverlap(candidate.uStart, candidate.uEnd, res.uStart, res.uEnd)) {
      errors.push(
        `Conflicts with active reservation ${res.reservationId} (${res.owner}) at U${res.uStart}-U${res.uEnd}.`,
      );
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

export function tracePowerAncestry(
  startNodeId: string,
  nodeMap: Map<string, UpstreamPowerNode>,
): UpstreamPowerNode[] {
  const chain: UpstreamPowerNode[] = [];
  const visited = new Set<string>();
  let currentId: string | undefined = startNodeId;

  while (currentId && !visited.has(currentId)) {
    visited.add(currentId);
    const node = nodeMap.get(currentId);
    if (!node) break;
    chain.push(node);
    currentId = node.parentId;
  }
  return chain;
}

export function analyzeRackPowerIndependence(
  rack: Rack,
  upstreamNodes: UpstreamPowerNode[],
): {
  independentDualFeed: boolean;
  sharedAncestor?: UpstreamPowerNode;
  feedAChain: UpstreamPowerNode[];
  feedBChain: UpstreamPowerNode[];
} {
  const nodeMap = new Map<string, UpstreamPowerNode>(
    upstreamNodes.map((n) => [n.id, n]),
  );
  const feedAChain = tracePowerAncestry(rack.feedAPathId, nodeMap);
  const feedBChain = tracePowerAncestry(rack.feedBPathId, nodeMap);

  if (feedAChain.length === 0 || feedBChain.length === 0) {
    return {
      independentDualFeed: false,
      feedAChain,
      feedBChain,
    };
  }

  const aIds = new Set(feedAChain.map((n) => n.id));
  const shared = feedBChain.find((n) => aIds.has(n.id));

  return {
    independentDualFeed: !shared,
    sharedAncestor: shared,
    feedAChain,
    feedBChain,
  };
}

export function buildTopologyWarnings(
  racks: Rack[],
  upstreamNodes: UpstreamPowerNode[],
): TopologyDependencyWarning[] {
  const warnings: TopologyDependencyWarning[] = [];

  for (const rack of racks) {
    const analysis = analyzeRackPowerIndependence(rack, upstreamNodes);
    if (!analysis.independentDualFeed) {
      if (analysis.sharedAncestor) {
        warnings.push({
          rackId: rack.id,
          rackCode: rack.code,
          severity: 'warning',
          type: 'shared_upstream_spof',
          sharedNodeId: analysis.sharedAncestor.id,
          sharedNodeName: analysis.sharedAncestor.name,
          message: `Dual feeds converge on shared upstream dependency: ${analysis.sharedAncestor.name} (${analysis.sharedAncestor.type.toUpperCase()}). Single point of failure.`,
        });
      } else {
        warnings.push({
          rackId: rack.id,
          rackCode: rack.code,
          severity: 'warning',
          type: 'missing_topology',
          message: `Incomplete upstream power path definition for ${rack.code}.`,
          missingFields: ['feedAPathId / feedBPathId'],
        });
      }
    }

    if (rack.missingTopologyFields.length > 0) {
      warnings.push({
        rackId: rack.id,
        rackCode: rack.code,
        severity: 'info',
        type: 'missing_topology',
        message: `Unverified topology links on ${rack.code}: ${rack.missingTopologyFields.join(', ')}.`,
        missingFields: rack.missingTopologyFields,
      });
    }
  }

  return warnings;
}

export function findContiguousAvailableU(
  rack: Rack,
  equipmentInRack: Equipment[],
  requiredU: number,
): number | undefined {
  const occupied = new Set<number>();
  for (const eq of equipmentInRack) {
    if (eq.rackId !== rack.id) continue;
    for (let u = eq.uStart; u <= eq.uEnd; u++) {
      occupied.add(u);
    }
  }
  for (const res of rack.reservedSlots) {
    for (let u = res.uStart; u <= res.uEnd; u++) {
      occupied.add(u);
    }
  }

  let run = 0;
  for (let u = 1; u <= rack.uTotal; u++) {
    if (!occupied.has(u)) {
      run++;
      if (run >= requiredU) {
        return u - requiredU + 1;
      }
    } else {
      run = 0;
    }
  }
  return undefined;
}
