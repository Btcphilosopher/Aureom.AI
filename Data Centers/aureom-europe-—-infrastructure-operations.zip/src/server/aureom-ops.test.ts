import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {describe, expect, it} from 'vitest';
import {MetricObservation} from '../shared/models';
import {createSeedFacilityState} from './data/seed-facility';
import {
  advanceWorkflowState,
  createControlledWorkflow,
  ingestAlarmIntoIncidents,
  redactWorkloadsForSession,
} from './domain/automation-and-incidents';
import {
  computePeriodEnergyPue,
  createTransactionalReservation,
  evaluatePlacementFeasibility,
} from './domain/capacity-engine';
import {
  analyzeRackPowerIndependence,
  buildTopologyWarnings,
  validateRackPlacement,
} from './domain/topology-and-rack';
import {
  convertUnit,
  ingestMetricObservation,
  refreshAllMetricFreshness,
} from './domain/units-and-telemetry';
import {AureomOperationsStore} from './store/aureom-store';

describe('Aureom Europe Infrastructure Operations Domain & Store', () => {
  it('1. validates unit conversions across power, temperature, storage, and network', () => {
    expect(convertUnit(6450, 'W', 'kW')).toBe(6.45);
    expect(convertUnit(6.45, 'kW', 'W')).toBe(6450);
    expect(convertUnit(25, 'C', 'F')).toBe(77);
    expect(convertUnit(77, 'F', 'C')).toBe(25);
    expect(convertUnit(2048, 'GiB', 'TiB')).toBe(2);
    expect(convertUnit(100_000_000_000, 'bps', 'Gbps')).toBe(100);
  });

  it('2. validates rack occupancy, prevents overlaps, and respects front/rear isolation', () => {
    const state = createSeedFacilityState();
    const rack1 = state.racks.find((r) => r.id === 'rack-fra-01')!;
    const eqInRack1 = state.equipment.filter((e) => e.rackId === rack1.id);

    const overlap = validateRackPlacement(
      rack1,
      {rackId: rack1.id, uStart: 11, uEnd: 12, face: 'full'},
      eqInRack1,
    );
    expect(overlap.valid).toBe(false);
    expect(overlap.errors.some((e) => e.includes('Overlap conflict'))).toBe(true);

    const outOfBounds = validateRackPlacement(
      rack1,
      {rackId: rack1.id, uStart: 42, uEnd: 43, face: 'front'},
      eqInRack1,
    );
    expect(outOfBounds.valid).toBe(false);

    const rearValid = validateRackPlacement(
      rack1,
      {rackId: rack1.id, uStart: 41, uEnd: 42, face: 'rear'},
      eqInRack1,
    );
    expect(rearValid.valid).toBe(true);
  });

  it('3. handles telemetry deduplication, delayed out-of-order samples, counter resets, and independent per-metric freshness', () => {
    const nowMs = Date.now();
    const metrics: Record<string, MetricObservation<number | string>> = {};

    const t1 = new Date(nowMs - 60_000).toISOString();
    const t2 = new Date(nowMs - 10_000).toISOString();
    const tStale = new Date(nowMs - 600_000).toISOString();

    const r1 = ingestMetricObservation(
      metrics,
      {
        equipmentId: 'sw-1',
        metricKey: 'inlet_temp_c',
        label: 'Inlet Temp',
        value: 23.1,
        unit: '°C',
        source: 'Redfish',
        observedAt: t2,
      },
      nowMs,
      180,
    );
    expect(r1.accepted).toBe(true);
    expect(r1.observation.quality).toBe('FRESH');

    const dup = ingestMetricObservation(
      metrics,
      {
        equipmentId: 'sw-1',
        metricKey: 'inlet_temp_c',
        label: 'Inlet Temp',
        value: 23.1,
        unit: '°C',
        source: 'Redfish',
        observedAt: t2,
      },
      nowMs,
      180,
    );
    expect(dup.accepted).toBe(false);
    expect(dup.reason).toBe('duplicate_dropped');

    const delayed = ingestMetricObservation(
      metrics,
      {
        equipmentId: 'sw-1',
        metricKey: 'inlet_temp_c',
        label: 'Inlet Temp',
        value: 21.0,
        unit: '°C',
        source: 'Redfish',
        observedAt: t1,
      },
      nowMs,
      180,
    );
    expect(delayed.accepted).toBe(false);
    expect(delayed.reason).toBe('delayed_older_than_current');

    ingestMetricObservation(
      metrics,
      {
        equipmentId: 'sw-1',
        metricKey: 'pdu_kw',
        label: 'PDU Load',
        value: 5.5,
        unit: 'kW',
        source: 'SNMPv3',
        observedAt: tStale,
        rawCounter: 5000,
      },
      nowMs,
      180,
    );
    refreshAllMetricFreshness(metrics, nowMs, 180);
    expect(metrics['inlet_temp_c'].quality).toBe('FRESH');
    expect(metrics['pdu_kw'].quality).toBe('STALE');

    const resetRes = ingestMetricObservation(
      metrics,
      {
        equipmentId: 'sw-1',
        metricKey: 'pdu_kw',
        label: 'PDU Load',
        value: 5.8,
        unit: 'kW',
        source: 'SNMPv3',
        observedAt: new Date(nowMs - 5_000).toISOString(),
        rawCounter: 120,
        counterMax: 10000,
      },
      nowMs,
      180,
    );
    expect(resetRes.reason).toBe('counter_reset_handled');
    expect(resetRes.observation.quality).toBe('COUNTER_RESET');
  });

  it('4. detects shared upstream SPOF dependencies and missing topology info', () => {
    const state = createSeedFacilityState();
    const rack8 = state.racks.find((r) => r.id === 'rack-fra-08')!;
    const rack9 = state.racks.find((r) => r.id === 'rack-fra-09')!;

    const r8Check = analyzeRackPowerIndependence(rack8, state.upstreamPowerNodes);
    expect(r8Check.independentDualFeed).toBe(false);
    expect(r8Check.sharedAncestor?.id).toBe('TX-FRA-02');

    const r9Check = analyzeRackPowerIndependence(rack9, state.upstreamPowerNodes);
    expect(r9Check.independentDualFeed).toBe(true);

    const warnings = buildTopologyWarnings(state.racks, state.upstreamPowerNodes);
    expect(warnings.some((w) => w.rackCode === 'FRA-01-R08' && w.type === 'shared_upstream_spof')).toBe(true);
    expect(warnings.some((w) => w.rackCode === 'FRA-01-R04' && w.type === 'missing_topology')).toBe(true);
  });

  it('5. evaluates capacity infeasibility, enforces transactional reservations, and computes period-energy PUE', () => {
    const state = createSeedFacilityState();
    const results = evaluatePlacementFeasibility(
      {
        siteId: 'FRA-01',
        requiredU: 8,
        weightKg: 140,
        powerKw: 10,
        coolingKw: 10,
        cpuCores: 0,
        ramGiB: 0,
        gpuCount: 0,
        storageTiB: 10,
        networkPorts: 2,
        resilience: '2N',
        dataLocation: 'EU-DE',
      },
      state.racks,
      state.rooms,
      state.equipment,
      state.storagePools,
      state.upstreamPowerNodes,
    );

    const r8Res = results.find((r) => r.rackCode === 'FRA-01-R08')!;
    expect(r8Res.feasible).toBe(false);
    expect(r8Res.reasons.some((msg) => msg.includes('2N resilience'))).toBe(true);

    const r10 = state.racks.find((r) => r.id === 'rack-fra-10')!;
    const r10Eq = state.equipment.filter((e) => e.rackId === r10.id);

    const first = createTransactionalReservation(
      {
        siteId: 'FRA-01',
        roomId: r10.roomId,
        rackId: r10.id,
        rackCode: r10.code,
        uStart: 20,
        uEnd: 27,
        powerKw: 10,
        coolingKw: 10,
        gpuCount: 8,
        storageTiB: 10,
        owner: 'Tenant A',
        purpose: 'Test A',
        dataLocation: 'EU-DE',
        expiresAt: '2026-12-31T00:00:00Z',
      },
      r10,
      r10Eq,
      state.reservations,
    );
    expect(first.ok).toBe(true);

    const conflict = createTransactionalReservation(
      {
        siteId: 'FRA-01',
        roomId: r10.roomId,
        rackId: r10.id,
        rackCode: r10.code,
        uStart: 24,
        uEnd: 30,
        powerKw: 8,
        coolingKw: 8,
        gpuCount: 0,
        storageTiB: 10,
        owner: 'Tenant B',
        purpose: 'Test B',
        dataLocation: 'EU-DE',
        expiresAt: '2026-12-31T00:00:00Z',
      },
      r10,
      r10Eq,
      state.reservations,
    );
    expect(conflict.ok).toBe(false);

    const pueOk = computePeriodEnergyPue(
      8942.4,
      7041.2,
      '2026-11-19T00:00:00Z',
      '2026-11-20T00:00:00Z',
    );
    expect(pueOk.valid).toBe(true);
    expect(pueOk.pue).toBeCloseTo(1.27, 2);

    const pueBad = computePeriodEnergyPue(
      5000,
      7000,
      '2026-11-19T00:00:00Z',
      '2026-11-20T00:00:00Z',
    );
    expect(pueBad.valid).toBe(false);
  });

  it('6. enforces tenant redaction and RBAC + MFA approvals & failed action compensation', () => {
    const dir = mkdtempSync(join(tmpdir(), 'aureom-test-'));
    try {
      const store = new AureomOperationsStore(dir);
      const raw = store.getRawSnapshot();

      const auditorSession = store.resolveSession('ReadOnlyAuditor', 'true');
      const redacted = redactWorkloadsForSession(raw.workloads, auditorSession);
      const seineRedacted = redacted.find((w) => w.id === 'WL-SEINE-SEC-01')!;
      expect(seineRedacted.orgName).toBe('[REDACTED-SOVEREIGN-TENANT]');

      const adminSession = store.resolveSession('SuperAdmin', 'true');
      const unredacted = redactWorkloadsForSession(raw.workloads, adminSession);
      expect(unredacted.find((w) => w.id === 'WL-SEINE-SEC-01')!.orgName).toBe(
        'Seine FinTech Cloud SA',
      );

      const gpu9 = raw.equipment.find((e) => e.id === 'gpu-fra-b09-01')!;
      const migBlocked = createControlledWorkflow(
        gpu9,
        'request_workload_migration',
        'idem-mig-1',
        adminSession,
        raw.workloads,
        raw.workflows,
      );
      expect(migBlocked.ok).toBe(false);

      const wfCreate = createControlledWorkflow(
        gpu9,
        'drain_node',
        'idem-drain-1',
        adminSession,
        raw.workloads,
        raw.workflows,
      );
      expect(wfCreate.ok).toBe(true);
      const dupWf = createControlledWorkflow(
        gpu9,
        'drain_node',
        'idem-drain-1',
        adminSession,
        raw.workloads,
        raw.workflows,
      );
      expect(dupWf.deduplicated).toBe(true);

      advanceWorkflowState(wfCreate.workflow!, auditorSession, gpu9);
      const deniedApprove = advanceWorkflowState(
        wfCreate.workflow!,
        auditorSession,
        gpu9,
      );
      expect(deniedApprove.ok).toBe(false);
      expect(deniedApprove.auditOutcome).toBe('Denied');

      const noMfaAdmin = store.resolveSession('SuperAdmin', 'false');
      const deniedMfa = advanceWorkflowState(wfCreate.workflow!, noMfaAdmin, gpu9);
      expect(deniedMfa.ok).toBe(false);

      const cpu2 = raw.equipment.find((e) => e.id === 'cpu-fra-a01-02')!;
      const failWf = createControlledWorkflow(
        cpu2,
        'run_diagnostic',
        'idem-fail-1',
        adminSession,
        raw.workloads,
        raw.workflows,
        true,
      ).workflow!;
      advanceWorkflowState(failWf, adminSession, cpu2);
      advanceWorkflowState(failWf, adminSession, cpu2);
      advanceWorkflowState(failWf, adminSession, cpu2);
      advanceWorkflowState(failWf, adminSession, cpu2);
      expect(failWf.state).toBe('Failed');
      expect(failWf.compensatingAction).toBeTruthy();
    } finally {
      rmSync(dir, {recursive: true, force: true});
    }
  });

  it('7. deduplicates repeated alarms, correlates related symptoms, and recovers persisted state across restarts', () => {
    const dir = mkdtempSync(join(tmpdir(), 'aureom-persist-'));
    try {
      const store1 = new AureomOperationsStore(dir);
      const raw = store1.getRawSnapshot();
      const baseCount = raw.incidents.length;

      const alarm1 = ingestAlarmIntoIncidents(raw.incidents, {
        dedupKey: 'thermal::rack-fra-09::inlet',
        correlationGroup: 'thermal::rack-fra-09',
        siteId: 'FRA-01',
        title: 'Inlet Temperature 38.4C on gpu-fra-b09-01',
        severity: 'SEV-1',
        assetId: 'gpu-fra-b09-01',
        metricKey: 'inlet_temp_c',
        source: 'Redfish',
        summary: 'Spike 38.4C',
        observedAt: new Date().toISOString(),
        affectedWorkloadIds: ['WL-MISTRAL-88412'],
      });
      expect(alarm1.deduplicated).toBe(false);
      expect(raw.incidents.length).toBe(baseCount + 1);

      const alarm2 = ingestAlarmIntoIncidents(raw.incidents, {
        dedupKey: 'thermal::rack-fra-09::inlet',
        correlationGroup: 'thermal::rack-fra-09',
        siteId: 'FRA-01',
        title: 'Inlet Temperature 38.7C on gpu-fra-b09-01',
        severity: 'SEV-1',
        assetId: 'gpu-fra-b09-01',
        metricKey: 'inlet_temp_c',
        source: 'Redfish',
        summary: 'Spike 38.7C',
        observedAt: new Date().toISOString(),
        affectedWorkloadIds: ['WL-MISTRAL-88412'],
      });
      expect(alarm2.deduplicated).toBe(true);
      expect(alarm2.incident.occurrenceCount).toBe(2);
      expect(alarm2.incident.evidence.length).toBe(2);

      const session = store1.resolveSession('SuperAdmin', 'true');
      store1.executeDemoStep(5, session);

      const store2 = new AureomOperationsStore(dir);
      const recovered = store2.getRawSnapshot();
      expect(recovered.demoState.completedSteps).toContain(5);
      expect(recovered.incidents.some((i) => i.affectedAssetIds.includes('gpu-fra-b09-01'))).toBe(true);
    } finally {
      rmSync(dir, {recursive: true, force: true});
    }
  });
});
