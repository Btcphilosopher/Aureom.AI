import {existsSync, mkdirSync, readFileSync, renameSync, writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {
  AuditEntry,
  AutomationActionType,
  CapacityEvaluationInput,
  CapacityReservation,
  ChangeRequest,
  Equipment,
  Incident,
  IncidentSeverity,
  OperatorRole,
  PlatformStateSnapshot,
  SecuritySession,
  TelemetryIngestionSample,
} from '../../shared/models';
import {
  MockNetworkWriteAdapter,
  PrometheusDcgmAdapter,
  RedfishCollectorAdapter,
  SnmpNetworkAdapter,
} from '../adapters/telemetry-adapters';
import {createSeedFacilityState} from '../data/seed-facility';
import {
  advanceWorkflowState,
  createControlledWorkflow,
  ingestAlarmIntoIncidents,
  redactWorkloadsForSession,
} from '../domain/automation-and-incidents';
import {
  createTransactionalReservation,
  evaluatePlacementFeasibility,
} from '../domain/capacity-engine';
import {
  buildTopologyWarnings,
  validateRackPlacement,
} from '../domain/topology-and-rack';
import {
  ingestMetricObservation,
  refreshAllMetricFreshness,
} from '../domain/units-and-telemetry';

export interface SseListener {
  id: string;
  send: (event: string, payload: unknown) => void;
}

export class AureomOperationsStore {
  private state: PlatformStateSnapshot;
  private readonly dataFile: string;
  private readonly listeners = new Map<string, SseListener>();
  private readonly redfish = new RedfishCollectorAdapter();
  private readonly prometheus = new PrometheusDcgmAdapter();
  private readonly snmp = new SnmpNetworkAdapter();
  private readonly mockNetWrite = new MockNetworkWriteAdapter();
  private pollerHandle?: ReturnType<typeof setInterval>;

  constructor(dataDir = process.env['AUREOM_DATA_DIR'] || '.aureom-data') {
    const resolvedDir = join(process.cwd(), dataDir);
    if (!existsSync(resolvedDir)) {
      mkdirSync(resolvedDir, {recursive: true});
    }
    this.dataFile = join(resolvedDir, 'aureom-state.json');
    this.state = this.loadOrSeed();
  }

  private loadOrSeed(): PlatformStateSnapshot {
    if (existsSync(this.dataFile)) {
      try {
        const raw = readFileSync(this.dataFile, 'utf-8');
        const parsed = JSON.parse(raw) as PlatformStateSnapshot;
        if (parsed && Array.isArray(parsed.racks) && parsed.racks.length >= 12) {
          return parsed;
        }
      } catch {
        // Fallback to clean seed if state file is corrupted
      }
    }
    const seed = createSeedFacilityState();
    this.persistSync(seed);
    return seed;
  }

  private persistSync(snapshot: PlatformStateSnapshot = this.state): void {
    snapshot.generatedAt = new Date().toISOString();
    const tmp = `${this.dataFile}.tmp`;
    writeFileSync(tmp, JSON.stringify(snapshot, null, 2), 'utf-8');
    renameSync(tmp, this.dataFile);
  }

  startBackgroundCollector(intervalMs = 15000): void {
    if (this.pollerHandle) return;
    this.pollerHandle = setInterval(() => {
      this.runCollectorTick();
    }, intervalMs);
    if (typeof this.pollerHandle.unref === 'function') {
      this.pollerHandle.unref();
    }
  }

  stopBackgroundCollector(): void {
    if (this.pollerHandle) {
      clearInterval(this.pollerHandle);
      this.pollerHandle = undefined;
    }
  }

  runCollectorTick(): void {
    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();
    const samples = [
      ...this.redfish.collectSamples(nowIso),
      ...this.prometheus.collectSamples(nowIso),
      ...this.snmp.collectSamples(nowIso),
    ];
    for (const s of samples) {
      const eq = this.state.equipment.find((e) => e.id === s.equipmentId);
      if (!eq) continue;
      // Do not overwrite an injected thermal fault during demo steps 5..10
      if (
        eq.id === 'gpu-fra-b09-01' &&
        this.state.demoState.completedSteps.includes(5) &&
        !this.state.demoState.completedSteps.includes(11) &&
        s.metricKey === 'inlet_temp_c'
      ) {
        continue;
      }
      ingestMetricObservation(
        eq.metrics,
        s,
        nowMs,
        this.state.staleThresholdSeconds,
      );
    }
    this.refreshFreshness(nowMs);
    this.persistSync();
    this.broadcast('telemetry:tick', {
      generatedAt: this.state.generatedAt,
      updatedEquipmentIds: Array.from(new Set(samples.map((s) => s.equipmentId))),
    });
  }

  private refreshFreshness(nowMs = Date.now()): void {
    for (const eq of this.state.equipment) {
      refreshAllMetricFreshness(
        eq.metrics,
        nowMs,
        this.state.staleThresholdSeconds,
      );
    }
    for (const rack of this.state.racks) {
      const rackMap = {
        inlet: rack.inletTempC,
        outlet: rack.outletTempC,
        power: rack.powerDrawKw,
      };
      refreshAllMetricFreshness(rackMap, nowMs, this.state.staleThresholdSeconds);
    }
  }

  addListener(listener: SseListener): void {
    this.listeners.set(listener.id, listener);
  }

  removeListener(id: string): void {
    this.listeners.delete(id);
  }

  private broadcast(event: string, payload: unknown): void {
    for (const listener of this.listeners.values()) {
      try {
        listener.send(event, payload);
      } catch {
        // Ignore broken SSE pipe
      }
    }
  }

  resolveSession(
    roleHeader?: string,
    mfaHeader?: string,
  ): SecuritySession {
    const validRoles: OperatorRole[] = [
      'SuperAdmin',
      'SiteOps-FRA',
      'SiteOps-PAR',
      'NetworkEng',
      'CapacityPlanner',
      'ReadOnlyAuditor',
      'TenantSupport',
    ];
    const role: OperatorRole = validRoles.includes(roleHeader as OperatorRole)
      ? (roleHeader as OperatorRole)
      : 'SuperAdmin';
    const mfaVerified = mfaHeader !== 'false';

    const scopeByRole: Record<OperatorRole, string[]> = {
      SuperAdmin: ['FRA-01', 'PAR-02'],
      'SiteOps-FRA': ['FRA-01'],
      'SiteOps-PAR': ['PAR-02'],
      NetworkEng: ['FRA-01', 'PAR-02'],
      CapacityPlanner: ['FRA-01', 'PAR-02'],
      ReadOnlyAuditor: ['FRA-01', 'PAR-02'],
      TenantSupport: ['FRA-01'],
    };

    const nameByRole: Record<OperatorRole, string> = {
      SuperAdmin: 'c.dubois@aureom.eu',
      'SiteOps-FRA': 'l.schmidt@aureom.eu',
      'SiteOps-PAR': 'a.moreau@aureom.eu',
      NetworkEng: 'm.weber@aureom.eu',
      CapacityPlanner: 'k.hoffmann@aureom.eu',
      ReadOnlyAuditor: 'auditor.ext@aureom.eu',
      TenantSupport: 'support.de@aureom.eu',
    };

    return {
      operatorId: `OP-${role.toUpperCase()}`,
      operatorName: nameByRole[role],
      role,
      siteScopes: scopeByRole[role],
      mfaVerified,
      ssoIssuer: process.env['AUREOM_OIDC_ISSUER'] || 'https://sso.aureom.eu/realms/infra-ops',
      sessionExpiresAt: new Date(Date.now() + 8 * 3600 * 1000).toISOString(),
      canApproveChanges: role !== 'ReadOnlyAuditor' && role !== 'TenantSupport',
      canExecuteAutomation:
        role === 'SuperAdmin' || role === 'SiteOps-FRA' || role === 'SiteOps-PAR',
      canViewRestrictedTenantDetails: role === 'SuperAdmin' || role === 'SiteOps-PAR',
    };
  }

  getSnapshotForSession(session: SecuritySession): PlatformStateSnapshot {
    this.refreshFreshness();
    return {
      ...this.state,
      workloads: redactWorkloadsForSession(this.state.workloads, session),
    };
  }

  getRawSnapshot(): PlatformStateSnapshot {
    return this.state;
  }

  private recordAudit(
    session: SecuritySession,
    siteId: string,
    action: string,
    targetId: string,
    outcome: AuditEntry['outcome'],
    detail: string,
  ): void {
    this.state.auditLog.unshift({
      id: `AUD-${Date.now().toString(36).toUpperCase()}`,
      timestamp: new Date().toISOString(),
      actor: session.operatorName,
      role: session.role,
      siteId,
      action,
      targetId,
      outcome,
      detail,
    });
  }

  importEquipment(
    items: Partial<Equipment>[],
    session: SecuritySession,
  ): {ok: boolean; imported: Equipment[]; errors: string[]} {
    if (!session.canApproveChanges) {
      this.recordAudit(session, 'FRA-01', 'ImportInventory', 'batch', 'Denied', 'Read-only role attempted inventory import.');
      return {ok: false, imported: [], errors: ['RBAC denied: role cannot modify authoritative inventory.']};
    }

    const imported: Equipment[] = [];
    const errors: string[] = [];

    for (const item of items) {
      const rack = this.state.racks.find((r) => r.id === item.rackId || r.code === item.rackId);
      if (!rack) {
        errors.push(`Unknown rack reference: ${item.rackId}`);
        continue;
      }
      const existingInRack = this.state.equipment.filter((e) => e.rackId === rack.id);
      const uStart = Number(item.uStart ?? 1);
      const uEnd = Number(item.uEnd ?? uStart + 1);
      const face = item.face ?? 'full';

      const check = validateRackPlacement(
        rack,
        {rackId: rack.id, uStart, uEnd, face},
        existingInRack,
      );
      if (!check.valid) {
        errors.push(...check.errors);
        continue;
      }

      const nowIso = new Date().toISOString();
      const created: Equipment = {
        id: item.id || `eq-${Date.now().toString(36)}-${imported.length}`,
        siteId: rack.siteId,
        roomId: rack.roomId,
        rackId: rack.id,
        name: item.name || `node-${rack.code.toLowerCase()}-u${uStart}`,
        category: item.category || 'compute',
        uStart,
        uEnd,
        face,
        weightKg: Number(item.weightKg ?? 28),
        ratedPowerW: Number(item.ratedPowerW ?? 800),
        manufacturer: item.manufacturer || 'Dell Technologies',
        model: item.model || 'PowerEdge R760',
        serialNumber: item.serialNumber || `SN-IMP-${Date.now().toString().slice(-5)}`,
        assetTag: item.assetTag || `EUR-IMP-${Math.floor(1000 + Math.random() * 9000)}`,
        managementIp: item.managementIp || '10.240.12.240',
        managementNetwork: rack.siteId === 'PAR-02' ? 'OOB-MGMT-PAR' : 'OOB-MGMT-FRA',
        lifecycleStatus: item.lifecycleStatus || 'Active',
        operationalStatus: 'Nominal',
        ownerTeam: item.ownerTeam || 'Cloud Compute Platform',
        warrantyExpiresAt: item.warrantyExpiresAt || '2029-12-31',
        supportContract: item.supportContract || 'ProSupport 4h',
        psuAFeedId: rack.feedAPathId,
        psuBFeedId: rack.feedBPathId,
        cpuModel: item.cpuModel || '2x Intel Xeon 8592+',
        cpuCores: Number(item.cpuCores ?? 128),
        ramGiB: Number(item.ramGiB ?? 1024),
        schedulerNodeState: 'IDLE',
        schedulerAllocatedCores: 0,
        schedulerAllocatedRamGiB: 0,
        nics: [],
        metrics: {
          inlet_temp_c: {
            key: 'inlet_temp_c',
            label: 'Inlet Temperature',
            value: 22.0,
            unit: '°C',
            source: 'Inventory-Verified',
            observedAt: nowIso,
            receivedAt: nowIso,
            quality: 'FRESH',
            ageSeconds: 0,
          },
        },
        discoveredDiffs: [],
        history: [
          {
            id: `HIS-${Date.now().toString(36)}`,
            timestamp: nowIso,
            actor: session.operatorName,
            action: 'Imported',
            detail: `Authoritative record created in ${rack.code} U${uStart}-U${uEnd}.`,
          },
        ],
      };

      this.state.equipment.push(created);
      imported.push(created);
      this.recordAudit(session, rack.siteId, 'ImportInventory', created.id, 'Allowed', `Placed ${created.name} in ${rack.code} U${uStart}-U${uEnd}.`);
    }

    if (imported.length > 0) {
      this.persistSync();
      this.broadcast('state:updated', {reason: 'inventory_import'});
    }

    return {ok: errors.length === 0, imported, errors};
  }

  reconcileDiscoveredDiff(
    equipmentId: string,
    diffId: string,
    decision: 'accept' | 'reject',
    session: SecuritySession,
  ): {ok: boolean; error?: string} {
    if (!session.canApproveChanges) {
      return {ok: false, error: 'RBAC denied: cannot reconcile authoritative inventory.'};
    }
    const eq = this.state.equipment.find((e) => e.id === equipmentId);
    if (!eq) return {ok: false, error: 'Equipment not found.'};
    const diff = eq.discoveredDiffs.find((d) => d.id === diffId);
    if (!diff) return {ok: false, error: 'Observation diff not found.'};

    const now = new Date().toISOString();
    diff.status = decision === 'accept' ? 'accepted' : 'rejected';
    diff.reviewedBy = session.operatorName;
    diff.reviewedAt = now;
    if (decision === 'accept') {
      diff.approvedValue = diff.discoveredValue;
    }
    eq.history.unshift({
      id: `HIS-${Date.now().toString(36)}`,
      timestamp: now,
      actor: session.operatorName,
      action: decision === 'accept' ? 'AcceptedDiscoveredValue' : 'RejectedDiscoveredValue',
      detail: `${diff.field}: ${decision === 'accept' ? diff.discoveredValue : 'kept ' + diff.approvedValue}`,
    });
    this.recordAudit(session, eq.siteId, 'ReconcileInventory', eq.id, 'Allowed', `${decision} ${diff.field}`);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'inventory_reconcile'});
    return {ok: true};
  }

  ingestTelemetrySamples(samples: TelemetryIngestionSample[]) {
    const nowMs = Date.now();
    const results = [];
    for (const sample of samples) {
      const eq = this.state.equipment.find((e) => e.id === sample.equipmentId);
      if (!eq) continue;
      const outcome = ingestMetricObservation(
        eq.metrics,
        sample,
        nowMs,
        this.state.staleThresholdSeconds,
      );
      results.push({equipmentId: eq.id, ...outcome});

      // Automatic threshold check for temperature exceptions
      if (
        outcome.accepted &&
        sample.metricKey === 'inlet_temp_c' &&
        sample.value >= 33.0
      ) {
        eq.operationalStatus = sample.value >= 36.0 ? 'Critical' : 'Warning';
        const rack = this.state.racks.find((r) => r.id === eq.rackId);
        if (rack) {
          rack.inletTempC = {
            ...outcome.observation,
            key: 'rack_inlet_temp_c',
            label: 'Rack Inlet Temp',
          };
        }
        const affectedWorkloads = this.state.workloads
          .filter((w) => w.equipmentId === eq.id)
          .map((w) => w.id);
        ingestAlarmIntoIncidents(this.state.incidents, {
          dedupKey: `thermal-high::${eq.id}::inlet_temp_c`,
          correlationGroup: `thermal::${eq.rackId}`,
          siteId: eq.siteId,
          title: `High Inlet Temperature Exception (${sample.value}°C) on ${eq.name}`,
          severity: sample.value >= 36 ? 'SEV-1' : 'SEV-2',
          assetId: eq.id,
          metricKey: sample.metricKey,
          source: sample.source,
          summary: `Redfish inlet sensor reported ${sample.value}°C (threshold 28.0°C) in rack ${rack?.code ?? eq.rackId}.`,
          observedAt: sample.observedAt,
          affectedWorkloadIds: affectedWorkloads,
        });
      }
    }
    this.persistSync();
    this.broadcast('telemetry:tick', {generatedAt: this.state.generatedAt});
    return results;
  }

  evaluateCapacity(input: CapacityEvaluationInput) {
    return evaluatePlacementFeasibility(
      input,
      this.state.racks,
      this.state.rooms,
      this.state.equipment,
      this.state.storagePools,
      this.state.upstreamPowerNodes,
    );
  }

  createReservation(
    req: Omit<CapacityReservation, 'id' | 'createdAt' | 'status'>,
    session: SecuritySession,
  ) {
    if (!session.canApproveChanges) {
      this.recordAudit(session, req.siteId, 'CreateReservation', req.rackId, 'Denied', 'Insufficient role privilege.');
      return {ok: false, errors: ['RBAC denied: operator role cannot reserve capacity.']};
    }
    const rack = this.state.racks.find((r) => r.id === req.rackId);
    if (!rack) return {ok: false, errors: ['Rack not found.']};
    const rackEq = this.state.equipment.filter((e) => e.rackId === rack.id);
    const result = createTransactionalReservation(
      req,
      rack,
      rackEq,
      this.state.reservations,
    );
    if (result.ok && result.reservation) {
      this.state.reservations.unshift(result.reservation);
      this.recordAudit(
        session,
        rack.siteId,
        'CreateReservation',
        result.reservation.id,
        'Allowed',
        `Reserved ${rack.code} U${req.uStart}-U${req.uEnd} (${req.powerKw} kW) for ${req.owner}.`,
      );
      this.persistSync();
      this.broadcast('state:updated', {reason: 'reservation_created'});
    }
    return result;
  }

  releaseReservation(reservationId: string, session: SecuritySession) {
    if (!session.canApproveChanges) {
      return {ok: false, error: 'RBAC denied.'};
    }
    const res = this.state.reservations.find((r) => r.id === reservationId);
    if (!res) return {ok: false, error: 'Reservation not found.'};
    res.status = 'Released';
    const rack = this.state.racks.find((r) => r.id === res.rackId);
    if (rack) {
      rack.reservedSlots = rack.reservedSlots.filter(
        (s) => s.reservationId !== res.id,
      );
    }
    this.recordAudit(session, res.siteId, 'ReleaseReservation', res.id, 'Allowed', `Released ${res.rackCode} U${res.uStart}-U${res.uEnd}.`);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'reservation_released'});
    return {ok: true};
  }

  openManualIncident(
    payload: {
      siteId: string;
      title: string;
      severity: IncidentSeverity;
      assetId: string;
      summary: string;
      correlationGroup?: string;
    },
    session: SecuritySession,
  ) {
    const affectedWorkloads = this.state.workloads
      .filter((w) => w.equipmentId === payload.assetId)
      .map((w) => w.id);
    const result = ingestAlarmIntoIncidents(this.state.incidents, {
      dedupKey: `manual::${payload.assetId}::${payload.title.toLowerCase().slice(0, 24)}`,
      correlationGroup: payload.correlationGroup,
      siteId: payload.siteId,
      title: payload.title,
      severity: payload.severity,
      assetId: payload.assetId,
      metricKey: 'operator_report',
      source: 'Inventory-Verified',
      summary: payload.summary,
      observedAt: new Date().toISOString(),
      affectedWorkloadIds: affectedWorkloads,
    });
    this.recordAudit(session, payload.siteId, 'OpenIncident', result.incident.id, 'Allowed', payload.title);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'incident_updated'});
    return result;
  }

  transitionIncident(
    incidentId: string,
    status: Incident['status'],
    note: string,
    session: SecuritySession,
  ) {
    const inc = this.state.incidents.find((i) => i.id === incidentId);
    if (!inc) return {ok: false, error: 'Incident not found.'};
    inc.status = status;
    if (status === 'Resolved') {
      inc.resolutionNote = note || 'Resolved and verified against live telemetry.';
    }
    inc.timeline.unshift({
      id: `TL-${Date.now().toString(36)}`,
      timestamp: new Date().toISOString(),
      actor: session.operatorName,
      action: `Status->${status}`,
      note: note || `Transitioned to ${status}.`,
    });
    this.recordAudit(session, inc.siteId, 'TransitionIncident', inc.id, 'Allowed', `${status}: ${note}`);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'incident_transition'});
    return {ok: true, incident: inc};
  }

  createChangeRequest(
    payload: Omit<ChangeRequest, 'id' | 'createdAt' | 'status' | 'requestedBy'>,
    session: SecuritySession,
  ) {
    if (!session.canApproveChanges) {
      return {ok: false, error: 'RBAC denied: read-only role cannot propose changes.'};
    }
    const chg: ChangeRequest = {
      ...payload,
      id: `CHG-2026-${String(this.state.changes.length + 119)}`,
      status: 'Proposed',
      requestedBy: session.operatorName,
      createdAt: new Date().toISOString(),
    };
    this.state.changes.unshift(chg);
    this.recordAudit(session, chg.siteId, 'ProposeChange', chg.id, 'Allowed', chg.title);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'change_created'});
    return {ok: true, change: chg};
  }

  transitionChangeRequest(
    changeId: string,
    status: ChangeRequest['status'],
    session: SecuritySession,
  ) {
    if (!session.canApproveChanges || (status === 'Approved' && !session.mfaVerified)) {
      this.recordAudit(session, 'FRA-01', 'TransitionChange', changeId, 'Denied', 'Requires approval privilege and verified MFA.');
      return {ok: false, error: 'Authority or MFA verification required to approve/execute changes.'};
    }
    const chg = this.state.changes.find((c) => c.id === changeId);
    if (!chg) return {ok: false, error: 'Change request not found.'};
    if (!session.siteScopes.includes(chg.siteId) && session.role !== 'SuperAdmin') {
      this.recordAudit(session, chg.siteId, 'TransitionChange', changeId, 'Denied', 'Site scope mismatch.');
      return {ok: false, error: `Site scope denied for ${chg.siteId}.`};
    }
    chg.status = status;
    if (status === 'Approved') {
      chg.approvedBy = session.operatorName;
    }
    this.recordAudit(session, chg.siteId, 'TransitionChange', chg.id, 'Allowed', `Status -> ${status}`);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'change_transition'});
    return {ok: true, change: chg};
  }

  createAutomationWorkflow(
    payload: {
      equipmentId: string;
      actionType: AutomationActionType;
      idempotencyKey: string;
      simulateFailure?: boolean;
    },
    session: SecuritySession,
  ) {
    const eq = this.state.equipment.find((e) => e.id === payload.equipmentId);
    if (!eq) return {ok: false, error: 'Equipment not found.'};
    const res = createControlledWorkflow(
      eq,
      payload.actionType,
      payload.idempotencyKey,
      session,
      this.state.workloads,
      this.state.workflows,
      payload.simulateFailure ?? false,
    );
    this.recordAudit(
      session,
      eq.siteId,
      'CreateAutomationWorkflow',
      eq.id,
      res.ok ? 'Allowed' : 'Denied',
      res.ok ? `${payload.actionType} (${res.workflow?.id})` : (res.error ?? 'Blocked'),
    );
    if (res.ok) {
      this.persistSync();
      this.broadcast('state:updated', {reason: 'workflow_created'});
    }
    return res;
  }

  advanceAutomationWorkflow(workflowId: string, session: SecuritySession) {
    const wf = this.state.workflows.find((w) => w.id === workflowId);
    if (!wf) return {ok: false, error: 'Workflow not found.'};
    const eq = this.state.equipment.find((e) => e.id === wf.targetEquipmentId);
    const res = advanceWorkflowState(wf, session, eq);
    this.recordAudit(
      session,
      wf.siteId,
      'AdvanceAutomationWorkflow',
      wf.id,
      res.auditOutcome,
      res.ok ? `State -> ${wf.state}` : (res.error ?? 'Denied'),
    );
    this.persistSync();
    this.broadcast('state:updated', {reason: 'workflow_advanced'});
    return res;
  }

  executeNetworkProposalAction(
    proposalId: string,
    action: 'approve' | 'commit_mock',
    session: SecuritySession,
  ) {
    const prop = this.state.networkProposals.find((p) => p.id === proposalId);
    if (!prop) return {ok: false, error: 'Proposal not found.'};
    if (!session.canApproveChanges || !session.mfaVerified) {
      this.recordAudit(session, prop.siteId, 'NetworkProposalAction', prop.id, 'Denied', 'MFA & change role required.');
      return {ok: false, error: 'Authority or MFA required.'};
    }
    if (action === 'approve') {
      prop.requestStatus = 'Approved';
    } else if (action === 'commit_mock') {
      if (prop.requestStatus !== 'Approved') {
        return {ok: false, error: 'Proposal must be Approved before applying via MockAdapter.'};
      }
      const outcome = this.mockNetWrite.applyProposedConfig(prop.id, prop.switchName);
      prop.deviceAckStatus = outcome.acknowledged ? 'Acknowledged' : 'RejectedByDevice';
      prop.verifiedOperationalState = outcome.verifiedOperational ? 'VerifiedMatch' : 'DriftDetected';
      prop.runningConfigSnippet = prop.proposedConfigSnippet;
    }
    this.recordAudit(session, prop.siteId, 'NetworkProposalAction', prop.id, 'Allowed', `${action} completed`);
    this.persistSync();
    this.broadcast('state:updated', {reason: 'network_proposal'});
    return {ok: true, proposal: prop};
  }

  executeDemoStep(stepNumber: number, session: SecuritySession): {
    step: number;
    message: string;
    routeHint: string;
  } {
    const nowIso = new Date().toISOString();
    const markStep = (n: number, message: string, routeHint: string) => {
      if (!this.state.demoState.completedSteps.includes(n)) {
        this.state.demoState.completedSteps.push(n);
      }
      this.state.demoState.currentStep = Math.min(12, n + 1);
      this.state.demoState.lastStepMessage = message;
      this.state.topologyWarnings = buildTopologyWarnings(
        this.state.racks,
        this.state.upstreamPowerNodes,
      );
      this.persistSync();
      this.broadcast('state:updated', {reason: `demo_step_${n}`});
      return {step: n, message, routeHint};
    };

    switch (stepNumber) {
      case 1: {
        // Import inventory into FRA-01-R02
        const exists = this.state.equipment.some((e) => e.id === 'cpu-fra-a02-demo');
        if (!exists) {
          this.importEquipment(
            [
              {
                id: 'cpu-fra-a02-demo',
                rackId: 'rack-fra-02',
                name: 'cmp-fra-a02-02-imported',
                category: 'compute',
                uStart: 14,
                uEnd: 15,
                face: 'full',
                weightKg: 29,
                ratedPowerW: 850,
                manufacturer: 'Dell Technologies',
                model: 'PowerEdge R760',
                serialNumber: 'SN-DEL-DEMO-2026',
                assetTag: 'EUR-CMP-0299',
                cpuCores: 128,
                ramGiB: 1024,
              },
            ],
            session,
          );
        }
        return markStep(1, 'Imported authoritative server cmp-fra-a02-02-imported into FRA-01-R02 U14-U15 with occupancy validation.', '/sites');
      }
      case 2:
        return markStep(2, 'Rendered front & rear 42U rack elevations across Rooms A & B (R01–R12) with SPOF & missing topology markers.', '/racks');
      case 3:
        this.runCollectorTick();
        return markStep(3, 'Ingested live Redfish, Prometheus DCGM, and SNMPv3 telemetry with source & timestamp provenance.', '/overview');
      case 4: {
        const pdu = this.state.equipment.find((e) => e.id === 'pdu-fra-a04-b');
        if (pdu && pdu.metrics['phase_load_kw']) {
          pdu.metrics['phase_load_kw'].observedAt = new Date(Date.now() - 1200 * 1000).toISOString();
          pdu.metrics['phase_load_kw'].quality = 'STALE';
          pdu.metrics['phase_load_kw'].ageSeconds = 1200;
        }
        return markStep(4, 'Identified STALE SNMPv3 power telemetry (20m old) on pdu-fra-a04-b while adjacent BMS humidity sensor stays FRESH.', '/power-cooling');
      }
      case 5: {
        this.ingestTelemetrySamples([
          {
            equipmentId: 'gpu-fra-b09-01',
            metricKey: 'inlet_temp_c',
            label: 'Inlet Temperature',
            value: 38.4,
            unit: '°C',
            source: 'Redfish',
            observedAt: nowIso,
          },
        ]);
        return markStep(5, 'Injected Redfish thermal spike (38.4°C) on gpu-fra-b09-01 in FRA-01-R09.', '/power-cooling');
      }
      case 6:
        return markStep(6, 'Correlated temperature exception into SEV-1 Incident with full timestamped evidence.', '/incidents');
      case 7:
        return markStep(7, 'Identified affected customer workload: Mistral Lattice SAS (slurm-job-88412, pinned RDMA GPU ranks, non-migratable).', '/gpus');
      case 8: {
        const chg = this.createChangeRequest(
          {
            siteId: 'FRA-01',
            title: 'Emergency Thermal Drain & RDHx Inspection on gpu-fra-b09-01 (FRA-01-R09)',
            risk: 'Medium',
            targetAssetIds: ['gpu-fra-b09-01', 'rack-fra-09'],
            linkedIncidentId: this.state.incidents[0]?.id,
            maintenanceWindowStart: nowIso,
            maintenanceWindowEnd: new Date(Date.now() + 2 * 3600 * 1000).toISOString(),
            executionPlan: [
              'Drain Slurm node gpu-fra-b09-01 gracefully after checkpoint.',
              'Inspect Rear-Door Heat Exchanger differential valve in Room B R09.',
            ],
            verificationChecks: ['Verify inlet_temp_c returns below 26.0°C via Redfish.'],
            rollbackPlan: ['Resume Slurm node once thermal margin restored.'],
          },
          session,
        );
        if (chg.ok && chg.change) {
          this.transitionChangeRequest(chg.change.id, 'Approved', session);
        }
        return markStep(8, 'Created and MFA-approved maintenance Change Request for FRA-01-R09.', '/changes');
      }
      case 9: {
        const wfRes = this.createAutomationWorkflow(
          {
            equipmentId: 'gpu-fra-b09-01',
            actionType: 'drain_node',
            idempotencyKey: 'demo-drain-gpu-b09-01',
          },
          session,
        );
        if (wfRes.workflow) {
          while (
            wfRes.workflow.state !== 'Completed' &&
            wfRes.workflow.state !== 'Failed'
          ) {
            this.advanceAutomationWorkflow(wfRes.workflow.id, session);
          }
        }
        return markStep(9, 'Executed controlled automation workflow Proposed → Validated → Approved → Scheduled → Executing → Verified → Completed to drain gpu-fra-b09-01.', '/changes');
      }
      case 10: {
        const existsRes = this.state.reservations.some((r) => r.id === 'RES-DEMO-R10');
        if (!existsRes) {
          const rack10 = this.state.racks.find((r) => r.id === 'rack-fra-10');
          if (rack10) {
            const res = createTransactionalReservation(
              {
                siteId: 'FRA-01',
                roomId: 'FRA-01-RM-B',
                rackId: 'rack-fra-10',
                rackCode: 'FRA-01-R10',
                uStart: 20,
                uEnd: 27,
                powerKw: 10.2,
                coolingKw: 10.2,
                gpuCount: 8,
                storageTiB: 20,
                owner: 'Mistral Lattice SAS (Failover)',
                purpose: 'Replacement 8x GPU capacity during R09 thermal remediation',
                dataLocation: 'EU-DE',
                expiresAt: '2026-12-01T00:00:00Z',
              },
              rack10,
              this.state.equipment.filter((e) => e.rackId === rack10.id),
              this.state.reservations,
            );
            if (res.ok && res.reservation) {
              this.state.reservations.unshift(res.reservation);
            }
          }
        }
        return markStep(10, 'Reserved replacement 8U / 10.2 kW capacity in FRA-01-R10 (2N verified) with transactional lock.', '/capacity');
      }
      case 11: {
        const gpuNode = this.state.equipment.find((e) => e.id === 'gpu-fra-b09-01');
        if (gpuNode) {
          gpuNode.operationalStatus = 'Nominal';
          gpuNode.lifecycleStatus = 'Active';
          gpuNode.schedulerNodeState = 'IDLE';
        }
        this.ingestTelemetrySamples([
          {
            equipmentId: 'gpu-fra-b09-01',
            metricKey: 'inlet_temp_c',
            label: 'Inlet Temperature',
            value: 24.1,
            unit: '°C',
            source: 'Redfish',
            observedAt: nowIso,
          },
        ]);
        const thermalInc = this.state.incidents.find((i) =>
          i.dedupKey.includes('gpu-fra-b09-01'),
        );
        if (thermalInc) {
          this.transitionIncident(
            thermalInc.id,
            'Resolved',
            'RDHx valve balanced; Redfish inlet temperature stabilized at 24.1°C.',
            session,
          );
        }
        return markStep(11, 'Verified thermal recovery (24.1°C) and resolved correlated incident with timestamped evidence.', '/incidents');
      }
      case 12:
      default:
        return markStep(12, 'Multilingual Executive & Operational Report ready for export in English, Français, and Deutsch.', '/reports');
    }
  }

  resetDemoState(): PlatformStateSnapshot {
    this.state = createSeedFacilityState();
    this.persistSync();
    this.broadcast('state:updated', {reason: 'demo_reset'});
    return this.state;
  }
}
