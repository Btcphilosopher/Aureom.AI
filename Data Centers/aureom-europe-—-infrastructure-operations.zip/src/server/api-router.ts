import express, {Request, Response} from 'express';
import {
  AutomationActionType,
  CapacityEvaluationInput,
  IncidentSeverity,
  LanguageCode,
} from '../shared/models';
import {AiAssistRequest, runAiOperationsAssistant} from './ai/ops-assistant';
import {AureomOperationsStore} from './store/aureom-store';

export function createApiRouter(store: AureomOperationsStore): express.Router {
  const router = express.Router();
  router.use(express.json({limit: '2mb'}));

  const getSession = (req: Request) =>
    store.resolveSession(
      req.header('x-aureom-role'),
      req.header('x-aureom-mfa'),
    );

  router.get('/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'aureom-europe-ops',
      timestamp: new Date().toISOString(),
      staleThresholdSeconds: store.getRawSnapshot().staleThresholdSeconds,
    });
  });

  router.get('/docs', (_req: Request, res: Response) => {
    res.json({
      openapi: '3.1.0',
      info: {
        title: 'Aureom Europe — Infrastructure Operations & Cloud Integration API',
        version: '1.0.0',
        description:
          'Authoritative inventory, telemetry ingestion, placement capacity evaluation, controlled automation, and customer resource correlation API.',
      },
      paths: {
        '/api/state': {get: {summary: 'Fetch RBAC-scoped infrastructure snapshot'}},
        '/api/telemetry/stream': {get: {summary: 'SSE live telemetry and state delta stream'}},
        '/api/telemetry/ingest': {post: {summary: 'Ingest normalized Redfish/SNMP/Prometheus/BMS samples'}},
        '/api/inventory/import': {post: {summary: 'Import validated equipment placements'}},
        '/api/inventory/equipment/{id}/reconcile': {post: {summary: 'Accept or reject discovered inventory observation'}},
        '/api/capacity/evaluate': {post: {summary: 'Evaluate rack placement feasibility with infeasibility reasons'}},
        '/api/reservations': {post: {summary: 'Create transactional capacity reservation'}},
        '/api/incidents': {post: {summary: 'Open or deduplicate operational incident'}},
        '/api/changes': {post: {summary: 'Propose maintenance change request'}},
        '/api/automation/workflows': {post: {summary: 'Initiate controlled automation workflow'}},
        '/api/ai/assist': {post: {summary: 'Query read-only Gemini 4.0 Operations Assistant'}},
      },
    });
  });

  router.get('/state', (req: Request, res: Response) => {
    const session = getSession(req);
    res.json({
      session,
      snapshot: store.getSnapshotForSession(session),
    });
  });

  router.get('/telemetry/stream', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const listenerId = `sse-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const send = (event: string, payload: unknown) => {
      res.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`);
    };

    store.addListener({id: listenerId, send});
    send('connected', {listenerId, timestamp: new Date().toISOString()});

    const heartbeat = setInterval(() => {
      res.write(': heartbeat\n\n');
    }, 20000);

    req.on('close', () => {
      clearInterval(heartbeat);
      store.removeListener(listenerId);
    });
  });

  router.post('/telemetry/ingest', (req: Request, res: Response) => {
    const samples = Array.isArray(req.body?.samples) ? req.body.samples : [];
    const results = store.ingestTelemetrySamples(samples);
    res.json({ingestedCount: results.length, results});
  });

  router.post('/inventory/import', (req: Request, res: Response) => {
    const session = getSession(req);
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    const result = store.importEquipment(items, session);
    res.status(result.ok ? 200 : 400).json(result);
  });

  router.post('/inventory/equipment/:id/reconcile', (req: Request, res: Response) => {
    const session = getSession(req);
    const id = String(req.params['id'] ?? '');
    const {diffId, decision} = req.body ?? {};
    const result = store.reconcileDiscoveredDiff(
      id,
      String(diffId ?? ''),
      decision === 'accept' ? 'accept' : 'reject',
      session,
    );
    res.status(result.ok ? 200 : 400).json(result);
  });

  router.post('/capacity/evaluate', (req: Request, res: Response) => {
    const input = req.body as CapacityEvaluationInput;
    const results = store.evaluateCapacity(input);
    res.json({results});
  });

  router.post('/reservations', (req: Request, res: Response) => {
    const session = getSession(req);
    const result = store.createReservation(req.body, session);
    res.status(result.ok ? 201 : 409).json(result);
  });

  router.post('/reservations/:id/release', (req: Request, res: Response) => {
    const session = getSession(req);
    const id = String(req.params['id'] ?? '');
    const result = store.releaseReservation(id, session);
    res.status(result.ok ? 200 : 400).json(result);
  });

  router.post('/incidents', (req: Request, res: Response) => {
    const session = getSession(req);
    const body = req.body as {
      siteId: string;
      title: string;
      severity: IncidentSeverity;
      assetId: string;
      summary: string;
      correlationGroup?: string;
    };
    const result = store.openManualIncident(body, session);
    res.status(201).json(result);
  });

  router.post('/incidents/:id/transition', (req: Request, res: Response) => {
    const session = getSession(req);
    const id = String(req.params['id'] ?? '');
    const {status, note} = req.body ?? {};
    const result = store.transitionIncident(id, status, String(note ?? ''), session);
    res.status(result.ok ? 200 : 400).json(result);
  });

  router.post('/changes', (req: Request, res: Response) => {
    const session = getSession(req);
    const result = store.createChangeRequest(req.body, session);
    res.status(result.ok ? 201 : 403).json(result);
  });

  router.post('/changes/:id/transition', (req: Request, res: Response) => {
    const session = getSession(req);
    const id = String(req.params['id'] ?? '');
    const {status} = req.body ?? {};
    const result = store.transitionChangeRequest(id, status, session);
    res.status(result.ok ? 200 : 403).json(result);
  });

  router.post('/automation/workflows', (req: Request, res: Response) => {
    const session = getSession(req);
    const {equipmentId, actionType, idempotencyKey, simulateFailure} = req.body ?? {};
    const result = store.createAutomationWorkflow(
      {
        equipmentId: String(equipmentId ?? ''),
        actionType: actionType as AutomationActionType,
        idempotencyKey: String(idempotencyKey ?? `key-${Date.now()}`),
        simulateFailure: Boolean(simulateFailure),
      },
      session,
    );
    res.status(result.ok ? 201 : 403).json(result);
  });

  router.post('/automation/workflows/:id/advance', (req: Request, res: Response) => {
    const session = getSession(req);
    const id = String(req.params['id'] ?? '');
    const result = store.advanceAutomationWorkflow(id, session);
    res.status(result.ok ? 200 : 403).json(result);
  });

  router.post('/network/proposals/:id/action', (req: Request, res: Response) => {
    const session = getSession(req);
    const id = String(req.params['id'] ?? '');
    const action = req.body?.action === 'commit_mock' ? 'commit_mock' : 'approve';
    const result = store.executeNetworkProposalAction(id, action, session);
    res.status(result.ok ? 200 : 403).json(result);
  });

  router.post('/demo/step/:stepNumber', (req: Request, res: Response) => {
    const session = getSession(req);
    const step = Number(req.params['stepNumber']);
    const result = store.executeDemoStep(step, session);
    res.json(result);
  });

  router.post('/demo/reset', (_req: Request, res: Response) => {
    const snapshot = store.resetDemoState();
    res.json({ok: true, generatedAt: snapshot.generatedAt});
  });

  router.post('/ai/assist', async (req: Request, res: Response) => {
    const session = getSession(req);
    const body = req.body as AiAssistRequest;
    const lang: LanguageCode =
      body?.language === 'fr' || body?.language === 'de' ? body.language : 'en';
    try {
      const result = await runAiOperationsAssistant(
        {
          prompt: String(body?.prompt ?? 'Summarize current infrastructure status.'),
          taskType: body?.taskType || 'general_query',
          language: lang,
          siteId: body?.siteId,
        },
        store.getSnapshotForSession(session),
      );
      res.json(result);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'AI assistant invocation failed.';
      res.status(502).json({error: msg});
    }
  });

  return router;
}
