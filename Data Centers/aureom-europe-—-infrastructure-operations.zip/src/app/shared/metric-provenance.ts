import {ChangeDetectionStrategy, Component, computed, inject, input} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {MetricObservation} from '../../shared/models';
import {I18nService} from '../core/services/i18n.service';

@Component({
  selector: 'app-metric-provenance',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (metric(); as m) {
      <div class="flex flex-col gap-0.5">
        <div class="flex items-baseline gap-1.5 font-mono tabular-nums">
          <span class="font-semibold text-slate-900 dark:text-slate-100">
            {{ formattedValue() }}
          </span>
          <span class="text-xs text-slate-500 dark:text-slate-400">{{ m.unit }}</span>
        </div>
        <div
          class="flex flex-wrap items-center gap-1.5 text-[11px] leading-tight"
          [class]="qualityTextClass()"
        >
          <mat-icon class="!text-[13px] !w-3.5 !h-3.5">{{ qualityIcon() }}</mat-icon>
          <span>{{ qualityLabel() }}</span>
          <span aria-hidden="true" class="text-slate-400 dark:text-slate-600">·</span>
          <span class="font-mono text-slate-500 dark:text-slate-400">{{ m.source }}</span>
          <span aria-hidden="true" class="text-slate-400 dark:text-slate-600">·</span>
          <span class="font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {{ i18n.formatRelativeAge(m.ageSeconds) }}
          </span>
        </div>
      </div>
    }
  `,
})
export class MetricProvenance {
  readonly i18n = inject(I18nService);
  readonly metric = input<MetricObservation<number | string> | undefined>();

  readonly formattedValue = computed(() => {
    const m = this.metric();
    if (!m) return '—';
    if (typeof m.value === 'number') {
      return this.i18n.formatNumber(m.value, 2);
    }
    return String(m.value);
  });

  readonly qualityLabel = computed(() => {
    const m = this.metric();
    if (!m) return '';
    return this.i18n.t().quality[m.quality];
  });

  readonly qualityIcon = computed(() => {
    const q = this.metric()?.quality;
    if (q === 'FRESH') return 'check_circle';
    if (q === 'DELAYED') return 'schedule';
    if (q === 'STALE') return 'warning';
    if (q === 'COUNTER_RESET') return 'restart_alt';
    return 'error_outline';
  });

  readonly qualityTextClass = computed(() => {
    const q = this.metric()?.quality;
    if (q === 'FRESH') return 'text-emerald-600 dark:text-emerald-400';
    if (q === 'DELAYED' || q === 'COUNTER_RESET') return 'text-amber-600 dark:text-amber-400';
    if (q === 'STALE' || q === 'UNAVAILABLE') return 'text-rose-600 dark:text-rose-400';
    return 'text-slate-500';
  });
}
