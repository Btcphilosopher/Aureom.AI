import {Injectable, signal} from '@angular/core';
import {LanguageCode, TimezoneId} from '../../../shared/models';

export const TRANSLATIONS = {
  en: {
    brand: 'Aureom Europe',
    platformSubtitle: 'Infrastructure Operations',
    nav: {
      overview: 'Overview',
      sites: 'Sites',
      racks: 'Racks',
      compute: 'Compute',
      gpus: 'GPUs',
      storage: 'Storage',
      network: 'Network',
      powerCooling: 'Power & Cooling',
      capacity: 'Capacity',
      incidents: 'Incidents',
      changes: 'Changes',
      reports: 'Reports',
    },
    controls: {
      demoWalkthrough: 'Demo Walkthrough',
      aiAssistant: 'AI Operations Assistant',
      themeDark: 'Dark',
      themeLight: 'Light',
      densityCompact: 'Compact',
      densityStandard: 'Standard',
      siteAll: 'All EU Sites',
      mfaVerified: 'MFA Verified',
      mfaUnverified: 'MFA Missing',
      searchPlaceholder: 'Filter racks, nodes, serials, workloads...',
      refresh: 'Refresh',
      safetyBoundaryTitle: 'Safety Boundary Enforced',
      safetyBoundaryText:
        'Facility telemetry is strictly read-only. Electrical breakers, EPO, fire suppression, and safety interlocks cannot be overridden.',
    },
    quality: {
      FRESH: 'Fresh',
      DELAYED: 'Delayed',
      STALE: 'Stale',
      COUNTER_RESET: 'Counter Reset',
      UNAVAILABLE: 'Unavailable',
    },
    overview: {
      title: 'European Infrastructure Command',
      subtitle:
        'Live facility telemetry, authoritative inventory, capacity headroom, and controlled operations across Frankfurt (FRA-01) and Paris (PAR-02).',
      kpiPower: 'Measured IT Load',
      kpiPue: '24h Period-Energy PUE',
      kpiIncidents: 'Active Incidents',
      kpiStale: 'Stale Telemetry Metrics',
      kpiGpus: 'Allocated / Total GPUs',
      staleWatchlist: 'Telemetry Freshness & Source Watchlist',
      topologyAlerts: 'Topology & Upstream Dependency Alerts',
      activeIncidents: 'Active & Correlated Incidents',
      demoBannerTitle: '12-Step Operational Demonstration',
      demoBannerDesc:
        'Execute or inspect the end-to-end European facility workflow from inventory import through thermal incident remediation and multilingual reporting.',
      openWalkthrough: 'Open Walkthrough',
    },
    sites: {
      title: 'Sites, Rooms & Authoritative Inventory',
      subtitle:
        'Hierarchical mapping from sovereign European campuses to rooms, racks, equipment, and customer workloads.',
      importBtn: 'Import Equipment',
      importTitle: 'Authoritative Inventory Import',
      reconcileTitle: 'Discovered vs Approved Observations',
      accept: 'Accept Observation',
      reject: 'Keep Approved',
      noDrifts: 'All discovered hardware observations match approved inventory records.',
    },
    racks: {
      title: 'Interactive Rack Elevations (Front & Rear)',
      subtitle:
        'Click any unit to inspect equipment specs, independent metric freshness, power feeds, and controlled actions.',
      frontView: 'Front Elevation',
      rearView: 'Rear Elevation',
      availableU: 'Available U',
      reservedU: 'Reserved Space',
      powerBudget: 'Power Budget',
      weightLimit: 'Weight Limit',
      inspector: 'Equipment Inspector',
      noSelection: 'Select a rack unit or device to inspect hardware specifications and telemetry.',
      discoveredDiffWarning: 'Unreviewed Discovery Drift',
      missingTopo: 'Missing Topology Info',
    },
    compute: {
      title: 'Compute Nodes & Scheduler Alignment',
      subtitle:
        'Distinguishing Slurm/Cloud scheduler allocations from measured Prometheus & Redfish hardware telemetry.',
      schedulerState: 'Scheduler State',
      measuredUtil: 'Measured Utilisation',
      oobMgmt: 'OOB Management',
      drainAction: 'Initiate Drain Workflow',
    },
    gpus: {
      title: 'GPU & AI Accelerator Operations',
      subtitle:
        'Physical device health, MIG/vGPU partitioning support, ECC counters, and customer workload boundaries.',
      partitionSupport: 'Partitioning Support',
      passthroughOnly: 'Passthrough Only (No MIG/Partitioning)',
      schedulerVsMeasured: 'Scheduler Alloc vs Measured Util',
    },
    storage: {
      title: 'Storage Pools, Durability & Restore Verification',
      subtitle:
        'Raw, usable, allocated, and consumed capacities separated cleanly; snapshots tracked independently from verified restore tests.',
      raw: 'Raw',
      usable: 'Usable',
      allocated: 'Allocated',
      consumed: 'Consumed',
      snapshotVsRestore: 'Snapshot vs Independent Backup & Restore Test',
    },
    network: {
      title: 'Network Fabric, VLANs & Config Change Proposals',
      subtitle:
        'Switches, port throughput, OOB separation, logical topology SPOFs, and pre-deployment configuration diffs.',
      runningVsProposed: 'Running vs Proposed Configuration Diff',
      approveProposal: 'Approve Proposal',
      commitMock: 'Apply via Mock NETCONF Adapter',
      noCliWarning: 'Arbitrary CLI execution is disabled. All changes use reviewed config diffs.',
    },
    powerCooling: {
      title: 'Power Distribution, Cooling & Period-Energy PUE',
      subtitle:
        'Utility feeds, UPS buses, PDUs, thermal headroom, and boundary-verified energy PUE.',
      injectTempSpike: 'Simulate Thermal Spike (38.4°C on R09)',
      pueFormulaNote: 'PUE computed strictly from integrated kWh over identical window & boundary.',
    },
    capacity: {
      title: 'Capacity Planning, Placement & Transactional Reservations',
      subtitle:
        'Evaluate multi-constraint placement feasibility, lock reservations atomically, and inspect uncertainty-banded forecasts.',
      evaluateBtn: 'Evaluate Placement Feasibility',
      reserveBtn: 'Reserve Selected Rack',
      feasible: 'Feasible',
      infeasible: 'Infeasible',
      forecastTitle: '6-Month Power & GPU Capacity Forecast (With Uncertainty Band)',
    },
    incidents: {
      title: 'Incident Management & Alarm Correlation',
      subtitle:
        'Deduplicated alarms, correlated symptoms with preserved raw evidence, customer impact, and multilingual notifications.',
      openIncidentBtn: 'Open Manual Incident',
      simulateDupAlarm: 'Simulate Repeated Thermal Alarm (Test Dedup)',
      resolveBtn: 'Mark Resolved',
      notificationPreview: 'Localized Notification Template',
    },
    changes: {
      title: 'Change Requests, Controlled Automation & Security RBAC',
      subtitle:
        'Separate change control records, pre-flight dependency checks, state-machine workflows, and RBAC audit trail.',
      advanceState: 'Advance Workflow State',
      triggerFailTest: 'Test Failed Action + Compensation',
      proposeChange: 'Propose Change Request',
    },
    reports: {
      title: 'Multilingual Reports, Sustainability, Cost & API Docs',
      subtitle:
        'Executive & operational exports, measured vs allocated vs billed cost accounting, location vs market-based emissions, and OpenAPI docs.',
      exportMarkdown: 'Download Localized Report (.md)',
      exportJson: 'Download State Snapshot (.json)',
      syntheticDisclaimer:
        'Synthetic Demonstration Data — Cost allocations and emissions factors are modeled for demonstration and are not audited financial or regulatory filings.',
    },
    ai: {
      title: 'Gemini 4.0 Operations Assistant',
      subtitle: 'Read-only advisory grounded in deterministic inventory and telemetry.',
      placeholder: 'Ask about active incidents, stale sensors, capacity constraints, or draft a change request...',
      send: 'Analyze',
      quickSummarize: 'Summarize Incidents',
      quickCapacity: 'Explain Capacity & SPOFs',
      quickMissing: 'Find Missing Inventory & Drift',
      quickChange: 'Draft R09 Maintenance Change',
      citations: 'Source Citations',
    },
  },
  fr: {
    brand: 'Aureom Europe',
    platformSubtitle: 'Opérations d’Infrastructure',
    nav: {
      overview: 'Vue d’ensemble',
      sites: 'Sites',
      racks: 'Baies',
      compute: 'Calcul',
      gpus: 'GPU',
      storage: 'Stockage',
      network: 'Réseau',
      powerCooling: 'Énergie & Refroidissement',
      capacity: 'Capacité',
      incidents: 'Incidents',
      changes: 'Changements',
      reports: 'Rapports',
    },
    controls: {
      demoWalkthrough: 'Parcours Démo',
      aiAssistant: 'Assistant IA Opérations',
      themeDark: 'Sombre',
      themeLight: 'Clair',
      densityCompact: 'Compacte',
      densityStandard: 'Standard',
      siteAll: 'Tous les sites UE',
      mfaVerified: 'MFA Vérifiée',
      mfaUnverified: 'MFA Requise',
      searchPlaceholder: 'Filtrer baies, nœuds, séries, charges...',
      refresh: 'Actualiser',
      safetyBoundaryTitle: 'Limite de Sûreté Appliquée',
      safetyBoundaryText:
        'La télémétrie d’infrastructure est strictement en lecture seule. Les disjoncteurs, AU, extinction incendie et verrouillages de sûreté sont isolés.',
    },
    quality: {
      FRESH: 'Frais',
      DELAYED: 'Retardé',
      STALE: 'Obsolète',
      COUNTER_RESET: 'Réinit. Compteur',
      UNAVAILABLE: 'Indisponible',
    },
    overview: {
      title: 'Centre de Commandement Européen',
      subtitle:
        'Télémétrie temps réel, inventaire autoritatif, marge de capacité et automatisation contrôlée sur Francfort (FRA-01) et Paris (PAR-02).',
      kpiPower: 'Charge IT Mesurée',
      kpiPue: 'PUE Énergie 24h',
      kpiIncidents: 'Incidents Actifs',
      kpiStale: 'Métriques Obsolètes',
      kpiGpus: 'GPU Alloués / Total',
      staleWatchlist: 'Surveillance Fraîcheur & Sources Télémétrie',
      topologyAlerts: 'Alertes Topologie & Dépendances Amont',
      activeIncidents: 'Incidents Actifs & Corrélés',
      demoBannerTitle: 'Démonstration Opérationnelle en 12 Étapes',
      demoBannerDesc:
        'Exécutez ou inspectez le scénario complet de bout en bout : import d’inventaire, anomalie thermique, drainage et rapport multilingue.',
      openWalkthrough: 'Ouvrir le Parcours',
    },
    sites: {
      title: 'Sites, Salles & Inventaire Autoritatif',
      subtitle:
        'Hiérarchie souveraine des campus européens vers les salles, baies, équipements et ressources clients.',
      importBtn: 'Importer Équipement',
      importTitle: 'Import d’Inventaire Autoritatif',
      reconcileTitle: 'Observations Découvertes vs Approuvées',
      accept: 'Accepter l’Observation',
      reject: 'Conserver Approuvé',
      noDrifts: 'Toutes les observations matérielles découvertes concordent avec l’inventaire approuvé.',
    },
    racks: {
      title: 'Élévations Interactives des Baies (Avant & Arrière)',
      subtitle:
        'Sélectionnez un équipement pour inspecter ses spécifications, la fraîcheur par métrique, les alimentations et les actions contrôlées.',
      frontView: 'Vue Avant',
      rearView: 'Vue Arrière',
      availableU: 'U Disponibles',
      reservedU: 'Espace Réservé',
      powerBudget: 'Budget Électrique',
      weightLimit: 'Charge Maximale',
      inspector: 'Inspecteur d’Équipement',
      noSelection: 'Sélectionnez une unité U ou un serveur pour afficher ses détails.',
      discoveredDiffWarning: 'Écart Découvert Non Revu',
      missingTopo: 'Topologie Incomplète',
    },
    compute: {
      title: 'Nœuds de Calcul & Alignement Ordonnanceur',
      subtitle:
        'Séparation explicite entre allocation Slurm/Cloud et utilisation matérielle mesurée via Prometheus et Redfish.',
      schedulerState: 'État Ordonnanceur',
      measuredUtil: 'Utilisation Mesurée',
      oobMgmt: 'Gestion OOB',
      drainAction: 'Initier Drainage Contrôlé',
    },
    gpus: {
      title: 'Opérations GPU & Accélérateurs IA',
      subtitle:
        'Santé physique, prise en charge du partitionnement MIG/vGPU, erreurs ECC et isolation des charges clients.',
      partitionSupport: 'Support Partitionnement',
      passthroughOnly: 'Passthrough Uniquement (Sans MIG)',
      schedulerVsMeasured: 'Alloué Ordonnanceur vs Mesuré',
    },
    storage: {
      title: 'Stockage, Durabilité & Tests de Restauration',
      subtitle:
        'Capacités brute, utile, allouée et consommée distinctes ; instantanés séparés des sauvegardes et tests de restauration.',
      raw: 'Brut',
      usable: 'Utile',
      allocated: 'Alloué',
      consumed: 'Consommé',
      snapshotVsRestore: 'Instantané vs Sauvegarde Indépendante & Test de Restauration',
    },
    network: {
      title: 'Réseau, VLANs & Propositions de Changement',
      subtitle:
        'Commutateurs, trafic ports, séparation OOB, SPOF topologiques et comparaison de configuration avant déploiement.',
      runningVsProposed: 'Diff Configuration Active vs Proposée',
      approveProposal: 'Approuver la Proposition',
      commitMock: 'Appliquer via Adaptateur Mock NETCONF',
      noCliWarning: 'L’exécution CLI arbitraire est désactivée. Tous les changements passent par revue de diff.',
    },
    powerCooling: {
      title: 'Alimentation, Refroidissement & PUE Énergie',
      subtitle:
        'Arrivées utilitaires, onduleurs UPS, PDU, marge thermique et PUE calculé sur énergie intégrée.',
      injectTempSpike: 'Simuler Pic Thermique (38.4°C sur R09)',
      pueFormulaNote: 'PUE calculé strictement par kWh installation / kWh IT sur la même fenêtre et frontière.',
    },
    capacity: {
      title: 'Planification Capacité, Placement & Réservations',
      subtitle:
        'Évaluation multi-contraintes, réservations transactionnelles et prévisions avec bande d’incertitude.',
      evaluateBtn: 'Évaluer la Faisabilité',
      reserveBtn: 'Réserver la Baie Sélectionnée',
      feasible: 'Faisable',
      infeasible: 'Infaisable',
      forecastTitle: 'Prévision Puissance & GPU à 6 Mois (Avec Bande d’Incertitude)',
    },
    incidents: {
      title: 'Gestion des Incidents & Corrélation d’Alarmes',
      subtitle:
        'Alarmes dédupliquées, symptômes corrélés sans suppression de preuves, impact client et notifications localisées.',
      openIncidentBtn: 'Ouvrir un Incident Manuel',
      simulateDupAlarm: 'Simuler Alarme Répétée (Test Dédup)',
      resolveBtn: 'Marquer Résolu',
      notificationPreview: 'Modèle de Notification Localisé',
    },
    changes: {
      title: 'Changements, Automatisation Contrôlée & Sécurité RBAC',
      subtitle:
        'Demandes de changement séparées, vérifications préalables, workflows à états et journal d’audit RBAC.',
      advanceState: 'Avancer l’État du Workflow',
      triggerFailTest: 'Tester Échec + Action Compensatoire',
      proposeChange: 'Proposer un Changement',
    },
    reports: {
      title: 'Rapports Multilingues, Durabilité, Coûts & API',
      subtitle:
        'Exports exécutifs, comptabilité mesurée vs allouée vs facturée, émissions localisation vs marché et OpenAPI.',
      exportMarkdown: 'Télécharger Rapport Localisé (.md)',
      exportJson: 'Télécharger Instantané (.json)',
      syntheticDisclaimer:
        'Données Synthétiques de Démonstration — Les coûts et facteurs d’émissions sont modélisés pour la démo et ne constituent pas un audit certifié.',
    },
    ai: {
      title: 'Assistant Opérations Gemini 4.0',
      subtitle: 'Conseiller en lecture seule fondé sur l’inventaire et la télémétrie déterministes.',
      placeholder: 'Interrogez sur les incidents actifs, capteurs obsolètes, contraintes ou rédigez un changement...',
      send: 'Analyser',
      quickSummarize: 'Résumer les Incidents',
      quickCapacity: 'Expliquer Capacité & SPOFs',
      quickMissing: 'Détecter Écarts & Manques',
      quickChange: 'Rédiger Changement R09',
      citations: 'Sources Citées',
    },
  },
  de: {
    brand: 'Aureom Europe',
    platformSubtitle: 'Infrastrukturbetrieb',
    nav: {
      overview: 'Übersicht',
      sites: 'Standorte',
      racks: 'Racks',
      compute: 'Compute',
      gpus: 'GPUs',
      storage: 'Speicher',
      network: 'Netzwerk',
      powerCooling: 'Strom & Kühlung',
      capacity: 'Kapazität',
      incidents: 'Vorfälle',
      changes: 'Änderungen',
      reports: 'Berichte',
    },
    controls: {
      demoWalkthrough: 'Demo-Durchlauf',
      aiAssistant: 'KI-Betriebsassistent',
      themeDark: 'Dunkel',
      themeLight: 'Hell',
      densityCompact: 'Kompakt',
      densityStandard: 'Standard',
      siteAll: 'Alle EU-Standorte',
      mfaVerified: 'MFA Verifiziert',
      mfaUnverified: 'MFA Fehlt',
      searchPlaceholder: 'Racks, Nodes, Seriennummern, Workloads filtern...',
      refresh: 'Aktualisieren',
      safetyBoundaryTitle: 'Sicherheitsgrenze Aktiv',
      safetyBoundaryText:
        'Die Gebäudetelemetrie ist strikt schreibgeschützt. Schutzschalter, Not-Aus, Löschanlagen und Sicherheitsverriegelungen sind isoliert.',
    },
    quality: {
      FRESH: 'Aktuell',
      DELAYED: 'Verzögert',
      STALE: 'Veraltet',
      COUNTER_RESET: 'Zähler-Reset',
      UNAVAILABLE: 'Nicht verfügbar',
    },
    overview: {
      title: 'Europäische Infrastruktur-Leitstelle',
      subtitle:
        'Live-Telemetrie, autoritatives Inventar, Kapazitätsreserven und kontrollierte Automatisierung für Frankfurt (FRA-01) und Paris (PAR-02).',
      kpiPower: 'Gemessene IT-Last',
      kpiPue: '24h Perioden-Energie-PUE',
      kpiIncidents: 'Aktive Vorfälle',
      kpiStale: 'Veraltete Messwerte',
      kpiGpus: 'Belegte / Gesamte GPUs',
      staleWatchlist: 'Telemetrie-Aktualität & Quellenprüfung',
      topologyAlerts: 'Topologie- & Upstream-Abhängigkeiten',
      activeIncidents: 'Aktive & Korrelierte Vorfälle',
      demoBannerTitle: '12-Schritte-Betriebsdemonstration',
      demoBannerDesc:
        'Führen Sie den gesamten Ablauf vom Inventarimport über Temperaturausnahme und Node-Drain bis zum mehrsprachigen Bericht aus.',
      openWalkthrough: 'Durchlauf Öffnen',
    },
    sites: {
      title: 'Standorte, Räume & Autorisiertes Inventar',
      subtitle:
        'Hierarchische Abbildung von europäischen Standorten über Räume und Racks bis zu Geräten und Kundenressourcen.',
      importBtn: 'Gerät Importieren',
      importTitle: 'Autoritativer Inventarimport',
      reconcileTitle: 'Erkannte vs. Freigegebene Beobachtungen',
      accept: 'Beobachtung Übernehmen',
      reject: 'Freigegebenen Wert Behalten',
      noDrifts: 'Alle erkannten Hardware-Beobachtungen stimmen mit dem freigegebenen Inventar überein.',
    },
    racks: {
      title: 'Interaktive Rack-Ansichten (Front & Rückseite)',
      subtitle:
        'Wählen Sie eine Höheneinheit für Gerätespezifikationen, Metrik-Aktualität, Strompfade und kontrollierte Aktionen.',
      frontView: 'Vorderansicht',
      rearView: 'Rückansicht',
      availableU: 'Freie HE',
      reservedU: 'Reservierter Bereich',
      powerBudget: 'Leistungsbudget',
      weightLimit: 'Gewichtslimit',
      inspector: 'Geräte-Inspektor',
      noSelection: 'Wählen Sie ein Rack-Element aus, um Spezifikationen und Telemetrie zu prüfen.',
      discoveredDiffWarning: 'Ungeprüfte Inventar-Abweichung',
      missingTopo: 'Fehlende Topologie-Daten',
    },
    compute: {
      title: 'Compute-Nodes & Scheduler-Abgleich',
      subtitle:
        'Klare Trennung zwischen Slurm/Cloud-Zuweisung und gemessener Prometheus-/Redfish-Hardwareauslastung.',
      schedulerState: 'Scheduler-Status',
      measuredUtil: 'Gemessene Auslastung',
      oobMgmt: 'OOB-Management',
      drainAction: 'Drain-Workflow Starten',
    },
    gpus: {
      title: 'GPU- & KI-Beschleunigerbetrieb',
      subtitle:
        'Physischer Gerätestatus, MIG/vGPU-Partitionierungsfähigkeit, ECC-Fehler und Mandantenabgrenzung.',
      partitionSupport: 'Partitionierung',
      passthroughOnly: 'Nur Passthrough (Kein MIG)',
      schedulerVsMeasured: 'Scheduler-Belegung vs. Gemessen',
    },
    storage: {
      title: 'Speicherpools, Haltbarkeit & Wiederherstellungstests',
      subtitle:
        'Getrennte Anzeige von Brutto, Netto, zugewiesen und belegt; Snapshots getrennt von unabhängigen Restore-Tests.',
      raw: 'Brutto',
      usable: 'Nutzbar',
      allocated: 'Zugewiesen',
      consumed: 'Verbraucht',
      snapshotVsRestore: 'Snapshot vs. Unabhängiges Backup & Restore-Test',
    },
    network: {
      title: 'Netzwerk-Fabric, VLANs & Änderungsentwürfe',
      subtitle:
        'Switches, Port-Durchsatz, OOB-Trennung, Topologie-SPOFs und Konfigurations-Diffs vor der Bereitstellung.',
      runningVsProposed: 'Diff: Aktive vs. Vorgeschlagene Konfiguration',
      approveProposal: 'Entwurf Freigeben',
      commitMock: 'Über Mock-NETCONF-Adapter Anwenden',
      noCliWarning: 'Beliebige CLI-Befehle sind gesperrt. Alle Änderungen erfolgen über geprüfte Diffs.',
    },
    powerCooling: {
      title: 'Stromversorgung, Kühlung & Perioden-Energie-PUE',
      subtitle:
        'Einspeisungen, USV-Systeme, PDUs, thermische Reserve und grenzgenau berechneter Energie-PUE.',
      injectTempSpike: 'Temperaturspitze Simulieren (38.4°C auf R09)',
      pueFormulaNote: 'PUE strikt aus integrierten kWh-Werten über identischen Zeitraum und Bilanzkreis berechnet.',
    },
    capacity: {
      title: 'Kapazitätsplanung, Platzierung & Transaktionale Reservierungen',
      subtitle:
        'Mehrdimensionale Machbarkeitsprüfung, transaktionale Sperrreservierungen und Prognosen mit Unsicherheitsband.',
      evaluateBtn: 'Platzierung Prüfen',
      reserveBtn: 'Gewähltes Rack Reservieren',
      feasible: 'Machbar',
      infeasible: 'Nicht Machbar',
      forecastTitle: '6-Monats-Leistungs- & GPU-Prognose (Mit Unsicherheitsband)',
    },
    incidents: {
      title: 'Vorfallsmanagement & Alarmkorrelation',
      subtitle:
        'Deduplizierte Alarme, korrelierte Symptome mit vollständigen Nachweisen, Kundenauswirkung und Benachrichtigungen.',
      openIncidentBtn: 'Manuellen Vorfall Erstellen',
      simulateDupAlarm: 'Wiederholten Alarm Simulieren (Dedup-Test)',
      resolveBtn: 'Als Gelöst Markieren',
      notificationPreview: 'Lokalisierte Benachrichtigungsvorlage',
    },
    changes: {
      title: 'Änderungen, Kontrollierte Automatisierung & RBAC-Sicherheit',
      subtitle:
        'Getrennte Change-Records, Vorabprüfungen, Zustandsautomaten und unveränderliches RBAC-Audit-Protokoll.',
      advanceState: 'Workflow-Schritt Weiterführen',
      triggerFailTest: 'Fehlerfall + Kompensation Testen',
      proposeChange: 'Change Beantragen',
    },
    reports: {
      title: 'Mehrsprachige Berichte, Nachhaltigkeit, Kosten & API-Doku',
      subtitle:
        'Exporte in EN/FR/DE, getrennte Kostenrechnung, standort- vs. marktbasierte Emissionen und OpenAPI-Spezifikation.',
      exportMarkdown: 'Lokalisierten Bericht Laden (.md)',
      exportJson: 'Zustands-Snapshot Laden (.json)',
      syntheticDisclaimer:
        'Synthetische Demonstrationsdaten — Kostenallokationen und Emissionsfaktoren dienen der Demonstration und sind keine geprüfte Bilanzierung.',
    },
    ai: {
      title: 'Gemini 4.0 Betriebsassistent',
      subtitle: 'Schreibgeschützte Beratung auf Basis deterministischer Inventar- und Telemetriedaten.',
      placeholder: 'Fragen zu Vorfällen, veralteten Sensoren, Kapazitätsengpässen oder Change-Entwürfen...',
      send: 'Analysieren',
      quickSummarize: 'Vorfälle Zusammenfassen',
      quickCapacity: 'Kapazität & SPOFs Erklären',
      quickMissing: 'Fehlende Daten & Drift Prüfen',
      quickChange: 'R09-Wartungs-Change Entwerfen',
      citations: 'Quellenverweise',
    },
  },
} as const;

@Injectable({providedIn: 'root'})
export class I18nService {
  readonly language = signal<LanguageCode>('en');
  readonly timezone = signal<TimezoneId>('Europe/Berlin');

  t(): (typeof TRANSLATIONS)['en'] {
    return TRANSLATIONS[this.language()] as unknown as (typeof TRANSLATIONS)['en'];
  }

  setLanguage(lang: LanguageCode): void {
    this.language.set(lang);
  }

  setTimezone(tz: TimezoneId): void {
    this.timezone.set(tz);
  }

  private getLocaleTag(): string {
    const lang = this.language();
    if (lang === 'fr') return 'fr-FR';
    if (lang === 'de') return 'de-DE';
    return 'en-GB';
  }

  formatDateTime(isoString: string | undefined): string {
    if (!isoString) return '—';
    const d = new Date(isoString);
    if (Number.isNaN(d.getTime())) return isoString;
    return new Intl.DateTimeFormat(this.getLocaleTag(), {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: this.timezone(),
      timeZoneName: 'short',
    }).format(d);
  }

  formatNumber(value: number, maxDecimals = 2): string {
    return new Intl.NumberFormat(this.getLocaleTag(), {
      maximumFractionDigits: maxDecimals,
    }).format(value);
  }

  formatCurrencyEur(value: number): string {
    return new Intl.NumberFormat(this.getLocaleTag(), {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(value);
  }

  formatRelativeAge(ageSeconds: number | undefined): string {
    if (ageSeconds === undefined || !Number.isFinite(ageSeconds)) return '—';
    const lang = this.language();
    if (ageSeconds < 60) {
      return lang === 'fr'
        ? `il y a ${ageSeconds}s`
        : lang === 'de'
          ? `vor ${ageSeconds}s`
          : `${ageSeconds}s ago`;
    }
    const mins = Math.floor(ageSeconds / 60);
    return lang === 'fr'
      ? `il y a ${mins}m`
      : lang === 'de'
        ? `vor ${mins}m`
        : `${mins}m ago`;
  }
}
