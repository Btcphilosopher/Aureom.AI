import {DOCUMENT, isPlatformBrowser} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {computed, inject, Injectable, PLATFORM_ID, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import {
  AutomationActionType,
  CapacityEvaluationInput,
  DensityMode,
  OperatorRole,
  PlatformStateSnapshot,
  RackFeasibilityResult,
  SecuritySession,
  ThemeMode,
} from '../../../shared/models';
import {I18nService} from './i18n.service';

export interface AiResponsePayload {
  answer: string;
  model: string;
  generatedAt: string;
  citations: {recordId: string; recordType: string; timestamp: string}[];
  safetyNotice: string;
}

@Injectable({providedIn: 'root'})
export class OpsStateService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly document = inject(DOCUMENT);
  private readonly i18n = inject(I18nService);

  readonly snapshot = signal<PlatformStateSnapshot | null>(null);
  readonly session = signal<SecuritySession | null>(null);
  readonly loading = signal<boolean>(true);
  readonly errorBanner = signal<string | null>(null);
  readonly toastMessage = signal<string | null>(null);

  // UI Preferences
  readonly theme = signal<ThemeMode>('dark');
  readonly density = signal<DensityMode>('standard');
  readonly selectedSiteFilter = signal<string>('ALL');
  readonly globalSearch = signal<string>('');
  readonly activeRole = signal<OperatorRole>('SuperAdmin');
  readonly mfaVerified = signal<boolean>(true);
  readonly sseConnected = signal<boolean>(false);

  // Contextual Drawers & Selections
  readonly selectedRackId = signal<string>('rack-fra-09');
  readonly selectedEquipmentId = signal<string>('gpu-fra-b09-01');
  readonly aiDrawerOpen = signal<boolean>(false);
  readonly demoDrawerOpen = signal<boolean>(false);

  // Computed operational metrics
  readonly filteredRacks = computed(() => {
    const snap = this.snapshot();
    if (!snap) return [];
    const site = this.selectedSiteFilter();
    const q = this.globalSearch().trim().toLowerCase();
    return snap.racks.filter((r) => {
      if (site !== 'ALL' && r.siteId !== site) return false;
      if (q && !r.code.toLowerCase().includes(q) && !r.roomId.toLowerCase().includes(q)) {
        const hasMatchingEq = snap.equipment.some(
          (e) =>
            e.rackId === r.id &&
            (e.name.toLowerCase().includes(q) ||
              e.assetTag.toLowerCase().includes(q) ||
              e.serialNumber.toLowerCase().includes(q)),
        );
        return hasMatchingEq;
      }
      return true;
    });
  });

  readonly filteredEquipment = computed(() => {
    const snap = this.snapshot();
    if (!snap) return [];
    const site = this.selectedSiteFilter();
    const q = this.globalSearch().trim().toLowerCase();
    return snap.equipment.filter((e) => {
      if (site !== 'ALL' && e.siteId !== site) return false;
      if (!q) return true;
      return (
        e.name.toLowerCase().includes(q) ||
        e.model.toLowerCase().includes(q) ||
        e.assetTag.toLowerCase().includes(q) ||
        e.serialNumber.toLowerCase().includes(q)
      );
    });
  });

  readonly openIncidentsCount = computed(() => {
    const snap = this.snapshot();
    if (!snap) return 0;
    return snap.incidents.filter((i) => i.status !== 'Resolved').length;
  });

  readonly staleMetricsList = computed(() => {
    const snap = this.snapshot();
    if (!snap) return [];
    const list: {
      equipmentId: string;
      equipmentName: string;
      rackId: string;
      metricKey: string;
      label: string;
      value: string | number;
      unit: string;
      source: string;
      quality: string;
      observedAt: string;
      ageSeconds?: number;
    }[] = [];

    for (const eq of snap.equipment) {
      for (const m of Object.values(eq.metrics)) {
        if (m.quality === 'STALE' || m.quality === 'DELAYED' || m.quality === 'COUNTER_RESET') {
          list.push({
            equipmentId: eq.id,
            equipmentName: eq.name,
            rackId: eq.rackId,
            metricKey: m.key,
            label: m.label,
            value: m.value,
            unit: m.unit,
            source: m.source,
            quality: m.quality,
            observedAt: m.observedAt,
            ageSeconds: m.ageSeconds,
          });
        }
      }
    }
    return list;
  });

  private eventSource?: EventSource;

  private authHeaders(): HttpHeaders {
    return new HttpHeaders({
      'x-aureom-role': this.activeRole(),
      'x-aureom-mfa': this.mfaVerified() ? 'true' : 'false',
    });
  }

  init(): void {
    void this.refreshState();
    if (isPlatformBrowser(this.platformId)) {
      this.connectSse();
    }
  }

  private connectSse(): void {
    if (this.eventSource) {
      this.eventSource.close();
    }
    try {
      this.eventSource = new EventSource('/api/telemetry/stream');
      this.eventSource.addEventListener('connected', () => {
        this.sseConnected.set(true);
      });
      this.eventSource.addEventListener('telemetry:tick', () => {
        void this.refreshState(false);
      });
      this.eventSource.addEventListener('state:updated', () => {
        void this.refreshState(false);
      });
      this.eventSource.onerror = () => {
        this.sseConnected.set(false);
      };
    } catch {
      this.sseConnected.set(false);
    }
  }

  toggleTheme(): void {
    const next: ThemeMode = this.theme() === 'dark' ? 'light' : 'dark';
    this.theme.set(next);
    if (isPlatformBrowser(this.platformId)) {
      const root = this.document.documentElement;
      if (next === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }

  setDensity(mode: DensityMode): void {
    this.density.set(mode);
  }

  setRole(role: OperatorRole): void {
    this.activeRole.set(role);
    void this.refreshState(false);
  }

  toggleMfa(): void {
    this.mfaVerified.update((v) => !v);
    void this.refreshState(false);
  }

  showToast(msg: string): void {
    this.toastMessage.set(msg);
    setTimeout(() => {
      if (this.toastMessage() === msg) {
        this.toastMessage.set(null);
      }
    }, 5000);
  }

  async refreshState(showLoader = true): Promise<void> {
    if (showLoader) this.loading.set(true);
    try {
      const res = await firstValueFrom(
        this.http.get<{session: SecuritySession; snapshot: PlatformStateSnapshot}>(
          '/api/state',
          {headers: this.authHeaders()},
        ),
      );
      this.session.set(res.session);
      this.snapshot.set(res.snapshot);
      this.errorBanner.set(null);
    } catch (err) {
      this.errorBanner.set(
        err instanceof Error ? err.message : 'Failed to load infrastructure state.',
      );
    } finally {
      this.loading.set(false);
    }
  }

  async importEquipment(items: Record<string, unknown>[]): Promise<{ok: boolean; errors: string[]}> {
    try {
      const res = await firstValueFrom(
        this.http.post<{ok: boolean; errors: string[]}>(
          '/api/inventory/import',
          {items},
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
      this.showToast('Authoritative equipment record imported.');
      return res;
    } catch (err: unknown) {
      const msg =
        (err as {error?: {errors?: string[]}})?.error?.errors?.join(' ') ||
        'Import failed.';
      this.showToast(msg);
      return {ok: false, errors: [msg]};
    }
  }

  async reconcileDiff(
    equipmentId: string,
    diffId: string,
    decision: 'accept' | 'reject',
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/inventory/equipment/${equipmentId}/reconcile`,
          {diffId, decision},
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
      this.showToast(
        decision === 'accept'
          ? 'Discovered observation promoted to approved inventory.'
          : 'Discovered observation rejected; approved record preserved.',
      );
    } catch {
      this.showToast('RBAC denied or reconciliation failed.');
    }
  }

  async evaluateCapacity(input: CapacityEvaluationInput): Promise<RackFeasibilityResult[]> {
    const res = await firstValueFrom(
      this.http.post<{results: RackFeasibilityResult[]}>(
        '/api/capacity/evaluate',
        input,
        {headers: this.authHeaders()},
      ),
    );
    return res.results;
  }

  async createReservation(payload: Record<string, unknown>): Promise<{ok: boolean; errors?: string[]}> {
    try {
      const res = await firstValueFrom(
        this.http.post<{ok: boolean; errors?: string[]}>(
          '/api/reservations',
          payload,
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
      this.showToast('Transactional capacity reservation locked.');
      return res;
    } catch (err: unknown) {
      const errors = (err as {error?: {errors?: string[]}})?.error?.errors || [
        'Reservation rejected due to conflict or RBAC.',
      ];
      this.showToast(errors[0]);
      return {ok: false, errors};
    }
  }

  async releaseReservation(id: string): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/reservations/${id}/release`, {}, {headers: this.authHeaders()}),
    );
    await this.refreshState(false);
    this.showToast(`Reservation ${id} released.`);
  }

  async injectThermalSpike(equipmentId = 'gpu-fra-b09-01', tempC = 38.4): Promise<void> {
    await firstValueFrom(
      this.http.post(
        '/api/telemetry/ingest',
        {
          samples: [
            {
              equipmentId,
              metricKey: 'inlet_temp_c',
              label: 'Inlet Temperature',
              value: tempC,
              unit: '°C',
              source: 'Redfish',
              observedAt: new Date().toISOString(),
            },
          ],
        },
        {headers: this.authHeaders()},
      ),
    );
    await this.refreshState(false);
    this.showToast(`Redfish sample ${tempC}°C ingested for ${equipmentId}.`);
  }

  async openManualIncident(payload: {
    siteId: string;
    title: string;
    severity: string;
    assetId: string;
    summary: string;
    correlationGroup?: string;
  }): Promise<void> {
    await firstValueFrom(
      this.http.post('/api/incidents', payload, {headers: this.authHeaders()}),
    );
    await this.refreshState(false);
    this.showToast('Incident processed through deduplication & correlation engine.');
  }

  async transitionIncident(id: string, status: string, note: string): Promise<void> {
    await firstValueFrom(
      this.http.post(
        `/api/incidents/${id}/transition`,
        {status, note},
        {headers: this.authHeaders()},
      ),
    );
    await this.refreshState(false);
    this.showToast(`Incident ${id} updated to ${status}.`);
  }

  async createChangeRequest(payload: Record<string, unknown>): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post('/api/changes', payload, {headers: this.authHeaders()}),
      );
      await this.refreshState(false);
      this.showToast('Change request created.');
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || 'Denied.';
      this.showToast(msg);
    }
  }

  async transitionChangeRequest(id: string, status: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/changes/${id}/transition`,
          {status},
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
      this.showToast(`Change ${id} transitioned to ${status}.`);
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || 'Authority or MFA denied.';
      this.showToast(msg);
    }
  }

  async createAutomationWorkflow(
    equipmentId: string,
    actionType: AutomationActionType,
    simulateFailure = false,
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          '/api/automation/workflows',
          {
            equipmentId,
            actionType,
            idempotencyKey: `wf-${equipmentId}-${actionType}-${Date.now()}`,
            simulateFailure,
          },
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
      this.showToast('Controlled automation workflow proposed.');
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || 'Workflow blocked.';
      this.showToast(msg);
    }
  }

  async advanceWorkflow(id: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/automation/workflows/${id}/advance`,
          {},
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || 'Step denied (check RBAC/MFA).';
      this.showToast(msg);
      await this.refreshState(false);
    }
  }

  async networkProposalAction(id: string, action: 'approve' | 'commit_mock'): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          `/api/network/proposals/${id}/action`,
          {action},
          {headers: this.authHeaders()},
        ),
      );
      await this.refreshState(false);
      this.showToast(`Network proposal ${id}: ${action} applied.`);
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || 'Denied.';
      this.showToast(msg);
    }
  }

  async executeDemoStep(stepNumber: number): Promise<{step: number; message: string; routeHint: string}> {
    const res = await firstValueFrom(
      this.http.post<{step: number; message: string; routeHint: string}>(
        `/api/demo/step/${stepNumber}`,
        {},
        {headers: this.authHeaders()},
      ),
    );
    await this.refreshState(false);
    this.showToast(`Step ${res.step}: ${res.message}`);
    return res;
  }

  async resetDemo(): Promise<void> {
    await firstValueFrom(
      this.http.post('/api/demo/reset', {}, {headers: this.authHeaders()}),
    );
    await this.refreshState(false);
    this.showToast('Facility demonstration state reset to baseline.');
  }

  async askAiAssistant(
    prompt: string,
    taskType: string,
  ): Promise<AiResponsePayload> {
    return firstValueFrom(
      this.http.post<AiResponsePayload>(
        '/api/ai/assist',
        {
          prompt,
          taskType,
          language: this.i18n.language(),
          siteId: this.selectedSiteFilter() === 'ALL' ? undefined : this.selectedSiteFilter(),
        },
        {headers: this.authHeaders()},
      ),
    );
  }
}
