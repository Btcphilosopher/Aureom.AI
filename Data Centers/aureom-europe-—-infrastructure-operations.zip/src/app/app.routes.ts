import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'overview',
  },
  {
    path: 'overview',
    loadComponent: () => import('./views/overview-view').then((m) => m.OverviewView),
  },
  {
    path: 'sites',
    loadComponent: () => import('./views/sites-view').then((m) => m.SitesView),
  },
  {
    path: 'racks',
    loadComponent: () => import('./views/racks-view').then((m) => m.RacksView),
  },
  {
    path: 'compute',
    loadComponent: () => import('./views/compute-view').then((m) => m.ComputeView),
  },
  {
    path: 'gpus',
    loadComponent: () => import('./views/gpus-view').then((m) => m.GpusView),
  },
  {
    path: 'storage',
    loadComponent: () => import('./views/storage-view').then((m) => m.StorageView),
  },
  {
    path: 'network',
    loadComponent: () => import('./views/network-view').then((m) => m.NetworkView),
  },
  {
    path: 'power-cooling',
    loadComponent: () =>
      import('./views/power-cooling-view').then((m) => m.PowerCoolingView),
  },
  {
    path: 'capacity',
    loadComponent: () => import('./views/capacity-view').then((m) => m.CapacityView),
  },
  {
    path: 'incidents',
    loadComponent: () => import('./views/incidents-view').then((m) => m.IncidentsView),
  },
  {
    path: 'changes',
    loadComponent: () => import('./views/changes-view').then((m) => m.ChangesView),
  },
  {
    path: 'reports',
    loadComponent: () => import('./views/reports-view').then((m) => m.ReportsView),
  },
  {
    path: '**',
    redirectTo: 'overview',
  },
];
