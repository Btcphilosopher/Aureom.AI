import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Equipment, RackReservationSlot} from '../../shared/models';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';
import {MetricProvenance} from '../shared/metric-provenance';

interface RackUnitRow {
  u: number;
  equipment?: Equipment;
  isTopOfDevice: boolean;
  uSpan: number;
  reservation?: RackReservationSlot;
}

@Component({
  selector: 'app-racks-view',
  imports: [MatIconModule, MetricProvenance],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().racks.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().racks.subtitle }}
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <div class="inline-flex rounded-lg border border-slate-200 bg-slate-100 p-1 dark:border-slate-800 dark:bg-slate-900">
            <button
              type="button"
              (click)="faceView.set('front')"
              class="rounded-md px-3 py-1.5 text-xs font-medium transition-colors"
              [class]="faceView() === 'front' ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-800 dark:text-slate-100' : 'text-slate-600 dark:text-slate-400'"
            >
              {{ i18n.t().racks.frontView }}
            </button>
            <button
              type="button"
              (click)="faceView.set('rear')"
              class="rounded-md px-3 py-1.5 text-xs font-medium transition-colors"
              [class]="faceView() === 'rear' ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-800 dark:text-slate-100' : 'text-slate-600 dark:text-slate-400'"
            >
              {{ i18n.t().racks.rearView }}
            </button>
          </div>
        </div>
      </div>

      <!-- Rack Selector Strip -->
      <div class="flex flex-wrap gap-1.5 rounded-xl border border-slate-200 bg-white p-2 dark:border-slate-800 dark:bg-[#0F1624]">
        @for (r of ops.filteredRacks(); track r.id) {
          <button
            type="button"
            (click)="selectRack(r.id)"
            class="rounded-lg px-3 py-1.5 font-mono text-xs font-medium transition-colors whitespace-nowrap"
            [class]="ops.selectedRackId() === r.id
              ? 'bg-blue-600 text-white'
              : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'"
          >
            {{ r.code }}
          </button>
        }
      </div>

      @if (activeRack(); as rack) {
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <!-- Left: 42U Elevation Diagram -->
          <div class="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0F1624]">
            <div class="mb-3 flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <div>
                <h2 class="font-mono text-base font-semibold text-slate-900 dark:text-slate-50">
                  {{ rack.code }} ({{ faceView() === 'front' ? 'Front' : 'Rear' }})
                </h2>
                <div class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {{ rack.dataLocation }} · {{ rack.uTotal }}U · {{ rackWeightKg() }}/{{ rack.maxWeightKg }} kg
                </div>
              </div>
              <div class="text-right font-mono text-xs tabular-nums">
                <div>{{ rack.powerDrawKw.value }} / {{ rack.powerBudgetKw }} kW</div>
                <div class="text-slate-500">Inlet {{ rack.inletTempC.value }}°C</div>
              </div>
            </div>

            @for (w of rackWarnings(); track w.type + w.message) {
              <div class="mb-3 flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5 text-xs text-amber-800 dark:text-amber-200">
                <mat-icon class="!text-[16px] !w-4 !h-4 shrink-0 mt-0.5">warning</mat-icon>
                <span>{{ w.message }}</span>
              </div>
            }

            <!-- 42U Elevation Chassis -->
            <div class="overflow-hidden rounded-lg border border-slate-300 bg-slate-100 dark:border-slate-700 dark:bg-[#090D16]">
              @for (row of elevationRows(); track row.u) {
                <div class="flex items-stretch border-b border-slate-200/80 last:border-b-0 dark:border-slate-800/70">
                  <div class="flex w-10 shrink-0 items-center justify-center border-r border-slate-200 bg-slate-50 py-1 font-mono text-[10px] tabular-nums text-slate-500 dark:border-slate-800 dark:bg-[#0C121E]">
                    U{{ row.u }}
                  </div>
                  @if (row.equipment; as eq) {
                    @if (row.isTopOfDevice) {
                      <button
                        type="button"
                        (click)="ops.selectedEquipmentId.set(eq.id)"
                        class="flex flex-1 items-center justify-between gap-2 px-3 py-1.5 text-left text-xs transition-colors"
                        [class]="ops.selectedEquipmentId() === eq.id
                          ? 'bg-blue-600/20 text-blue-900 dark:bg-blue-500/25 dark:text-slate-50'
                          : eq.operationalStatus === 'Critical'
                            ? 'bg-rose-500/15 text-rose-900 dark:text-rose-200'
                            : eq.operationalStatus === 'Warning'
                              ? 'bg-amber-500/15 text-amber-900 dark:text-amber-200'
                              : eq.operationalStatus === 'Maintenance'
                                ? 'bg-violet-500/15 text-violet-900 dark:text-violet-200'
                                : 'bg-slate-200/70 text-slate-900 hover:bg-slate-300/60 dark:bg-[#182236] dark:text-slate-100 dark:hover:bg-[#1E2B44]'"
                      >
                        <div class="min-w-0 truncate">
                          <span class="font-mono font-semibold">{{ eq.name }}</span>
                          <span class="ml-2 text-[11px] text-slate-500 dark:text-slate-400">
                            {{ eq.model }} ({{ row.uSpan }}U · {{ eq.face }})
                          </span>
                        </div>
                        <span class="shrink-0 font-mono text-[11px]">
                          {{ eq.operationalStatus }}
                        </span>
                      </button>
                    } @else {
                      <button
                        type="button"
                        (click)="ops.selectedEquipmentId.set(eq.id)"
                        class="flex flex-1 items-center px-3 py-0.5 text-[10px] font-mono text-slate-400 dark:bg-[#141D2F]/80"
                      >
                        ↳ {{ eq.name }} (U{{ eq.uStart }}–U{{ eq.uEnd }})
                      </button>
                    }
                  } @else if (row.reservation; as res) {
                    <div class="flex flex-1 items-center justify-between bg-cyan-500/10 px-3 py-1 text-[11px] text-cyan-800 dark:text-cyan-300">
                      <span class="font-mono">RESERVED · {{ res.reservationId }}</span>
                      <span class="truncate">{{ res.owner }}</span>
                    </div>
                  } @else {
                    <div class="flex-1 px-3 py-1 text-[10px] font-mono text-slate-400 dark:text-slate-600">
                      {{ i18n.t().racks.availableU }}
                    </div>
                  }
                </div>
              }
            </div>
          </div>

          <!-- Right: Equipment Inspector & Dependencies -->
          <div class="lg:col-span-7 space-y-6">
            @if (selectedEquipment(); as eq) {
              <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-5 dark:border-slate-800 dark:bg-[#0F1624]">
                <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
                  <div>
                    <div class="flex items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400">
                      <span>{{ eq.assetTag }}</span>
                      <span aria-hidden="true">·</span>
                      <span>{{ eq.serialNumber }}</span>
                      <span aria-hidden="true">·</span>
                      <span>U{{ eq.uStart }}–U{{ eq.uEnd }} ({{ eq.face }})</span>
                    </div>
                    <h2 class="mt-1 font-mono text-xl font-semibold text-slate-900 dark:text-slate-50">
                      {{ eq.name }}
                    </h2>
                    <div class="mt-0.5 text-sm text-slate-600 dark:text-slate-400">
                      {{ eq.manufacturer }} {{ eq.model }} · {{ eq.ownerTeam }}
                    </div>
                  </div>
                  <div class="text-right">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Status</div>
                    <div
                      class="font-mono text-sm font-semibold"
                      [class]="eq.operationalStatus === 'Critical' ? 'text-rose-500' : eq.operationalStatus === 'Warning' ? 'text-amber-500' : eq.operationalStatus === 'Maintenance' ? 'text-violet-400' : 'text-emerald-500'"
                    >
                      {{ eq.operationalStatus }} ({{ eq.lifecycleStatus }})
                    </div>
                  </div>
                </div>

                <!-- Authoritative Specifications -->
                <div class="grid grid-cols-2 gap-4 text-xs sm:grid-cols-4">
                  <div>
                    <div class="text-slate-500">OOB Management</div>
                    <div class="mt-0.5 font-mono font-medium">{{ eq.managementIp }}</div>
                    <div class="text-[11px] text-slate-500">{{ eq.managementNetwork }}</div>
                  </div>
                  <div>
                    <div class="text-slate-500">Power Feeds</div>
                    <div class="mt-0.5 font-mono font-medium">A: {{ eq.psuAFeedId || 'Missing' }}</div>
                    <div class="font-mono text-[11px] text-slate-500">B: {{ eq.psuBFeedId || 'Missing' }}</div>
                  </div>
                  <div>
                    <div class="text-slate-500">Weight / Rated</div>
                    <div class="mt-0.5 font-mono tabular-nums">{{ eq.weightKg }} kg · {{ eq.ratedPowerW }} W</div>
                  </div>
                  <div>
                    <div class="text-slate-500">Warranty & Support</div>
                    <div class="mt-0.5 font-mono">{{ eq.warrantyExpiresAt }}</div>
                    <div class="text-[11px] text-slate-500">{{ eq.supportContract }}</div>
                  </div>
                </div>

                <!-- Independent Per-Metric Telemetry Provenance -->
                <div class="space-y-2.5">
                  <h3 class="text-xs font-semibold text-slate-600 dark:text-slate-300">
                    Telemetry Observations (Per-Metric Source & Freshness)
                  </h3>
                  <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    @for (m of metricList(eq); track m.key) {
                      <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                        <div class="mb-1 text-xs text-slate-500 dark:text-slate-400">{{ m.label }}</div>
                        <app-metric-provenance [metric]="m" />
                      </div>
                    }
                  </div>
                </div>

                <!-- Controlled Actions -->
                <div class="flex flex-wrap items-center gap-3 border-t border-slate-200 pt-4 dark:border-slate-800">
                  <button
                    type="button"
                    (click)="ops.createAutomationWorkflow(eq.id, 'run_diagnostic')"
                    class="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
                  >
                    <mat-icon class="!text-[16px] !w-4 !h-4">fact_check</mat-icon>
                    <span>Run Diagnostic</span>
                  </button>
                  <button
                    type="button"
                    (click)="ops.createAutomationWorkflow(eq.id, 'drain_node')"
                    class="inline-flex items-center gap-1.5 rounded-lg bg-amber-600 px-3 py-2 text-xs font-medium text-white hover:bg-amber-700"
                  >
                    <mat-icon class="!text-[16px] !w-4 !h-4">pause_circle</mat-icon>
                    <span>Propose Node Drain</span>
                  </button>
                </div>

                <!-- Change History -->
                @if (eq.history.length > 0) {
                  <div class="space-y-2 border-t border-slate-200 pt-4 dark:border-slate-800">
                    <h3 class="text-xs font-semibold text-slate-600 dark:text-slate-300">Asset Change History</h3>
                    @for (h of eq.history; track h.id) {
                      <div class="flex items-start justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
                        <div>
                          <span class="font-mono font-medium text-slate-800 dark:text-slate-200">{{ h.action }}</span>
                          — {{ h.detail }}
                        </div>
                        <span class="shrink-0 font-mono tabular-nums">{{ i18n.formatDateTime(h.timestamp) }}</span>
                      </div>
                    }
                  </div>
                }
              </section>
            } @else {
              <div class="rounded-xl border border-slate-200 bg-white p-8 text-sm text-slate-500 dark:border-slate-800 dark:bg-[#0F1624]">
                {{ i18n.t().racks.noSelection }}
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class RacksView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
  readonly faceView = signal<'front' | 'rear'>('front');

  readonly activeRack = computed(() => {
    const snap = this.ops.snapshot();
    if (!snap) return undefined;
    return snap.racks.find((r) => r.id === this.ops.selectedRackId()) ?? snap.racks[0];
  });

  readonly rackEquipment = computed(() => {
    const rack = this.activeRack();
    const snap = this.ops.snapshot();
    if (!rack || !snap) return [];
    const face = this.faceView();
    return snap.equipment.filter(
      (e) => e.rackId === rack.id && (e.face === 'full' || e.face === face),
    );
  });

  readonly rackWeightKg = computed(() => {
    const rack = this.activeRack();
    const snap = this.ops.snapshot();
    if (!rack || !snap) return 0;
    return snap.equipment
      .filter((e) => e.rackId === rack.id)
      .reduce((acc, e) => acc + e.weightKg, 0);
  });

  readonly rackWarnings = computed(() => {
    const rack = this.activeRack();
    if (!rack) return [];
    return (this.ops.snapshot()?.topologyWarnings ?? []).filter((w) => w.rackId === rack.id);
  });

  readonly elevationRows = computed<RackUnitRow[]>(() => {
    const rack = this.activeRack();
    if (!rack) return [];
    const eqs = this.rackEquipment();
    const rows: RackUnitRow[] = [];
    for (let u = rack.uTotal; u >= 1; u--) {
      const eq = eqs.find((e) => u >= e.uStart && u <= e.uEnd);
      const res = rack.reservedSlots.find((r) => u >= r.uStart && u <= r.uEnd);
      rows.push({
        u,
        equipment: eq,
        isTopOfDevice: eq ? eq.uEnd === u : false,
        uSpan: eq ? eq.uEnd - eq.uStart + 1 : 1,
        reservation: res,
      });
    }
    return rows;
  });

  readonly selectedEquipment = computed(() => {
    const snap = this.ops.snapshot();
    if (!snap) return undefined;
    const eq = snap.equipment.find((e) => e.id === this.ops.selectedEquipmentId());
    if (eq) return eq;
    return this.rackEquipment()[0];
  });

  selectRack(rackId: string): void {
    this.ops.selectedRackId.set(rackId);
    const first = (this.ops.snapshot()?.equipment ?? []).find((e) => e.rackId === rackId);
    if (first) {
      this.ops.selectedEquipmentId.set(first.id);
    }
  }

  metricList(eq: Equipment) {
    return Object.values(eq.metrics);
  }
}
