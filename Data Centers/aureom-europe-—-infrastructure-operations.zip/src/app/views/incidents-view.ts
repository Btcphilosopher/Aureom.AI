import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Incident} from '../../shared/models';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-incidents-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().incidents.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().incidents.subtitle }}
          </p>
        </div>

        <button
          type="button"
          (click)="simulateDuplicateAlarm()"
          class="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
        >
          <mat-icon class="!text-[16px] !w-4 !h-4">filter_none</mat-icon>
          <span>{{ i18n.t().incidents.simulateDupAlarm }}</span>
        </button>
      </div>

      <div class="space-y-4">
        @for (inc of ops.snapshot()?.incidents ?? []; track inc.id) {
          <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]">
            <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
              <div>
                <div class="flex flex-wrap items-center gap-2 font-mono text-xs">
                  <span class="font-semibold text-blue-600 dark:text-cyan-400">{{ inc.id }}</span>
                  <span aria-hidden="true">·</span>
                  <span
                    class="font-semibold"
                    [class]="inc.severity === 'SEV-1' ? 'text-rose-500' : inc.severity === 'SEV-2' ? 'text-amber-500' : 'text-slate-500'"
                  >
                    {{ inc.severity }}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>Status: <strong>{{ inc.status }}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span class="tabular-nums">Occurrences: <strong>{{ inc.occurrenceCount }}</strong></span>
                </div>
                <h2 class="mt-1 text-base font-semibold text-slate-900 dark:text-slate-50">
                  {{ inc.title }}
                </h2>
                <div class="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Assignee: <span class="font-mono">{{ inc.assignee }}</span> ·
                  Assets: <span class="font-mono">{{ inc.affectedAssetIds.join(', ') }}</span> ·
                  Customer Workloads: <span class="font-mono">{{ inc.affectedWorkloadIds.length > 0 ? inc.affectedWorkloadIds.join(', ') : 'None' }}</span>
                </div>
              </div>

              @if (inc.status !== 'Resolved') {
                <button
                  type="button"
                  (click)="ops.transitionIncident(inc.id, 'Resolved', 'Verified telemetry recovery by operator.')"
                  class="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
                >
                  <mat-icon class="!text-[16px] !w-4 !h-4">check_circle</mat-icon>
                  <span>{{ i18n.t().incidents.resolveBtn }}</span>
                </button>
              }
            </div>

            <!-- Preserved Evidence & Timeline -->
            <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <div class="space-y-2">
                <h3 class="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Preserved Evidence Samples (Never Suppressed)
                </h3>
                <div class="space-y-2">
                  @for (ev of inc.evidence; track ev.id) {
                    <div class="rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800 dark:bg-[#141D2F]">
                      <div class="flex justify-between font-mono text-[11px] text-slate-500">
                        <span>{{ ev.source }} · {{ ev.assetId }} · {{ ev.metricKey }}</span>
                        <span>{{ i18n.formatDateTime(ev.timestamp) }}</span>
                      </div>
                      <p class="mt-1 text-slate-800 dark:text-slate-200">{{ ev.summary }}</p>
                    </div>
                  }
                </div>
              </div>

              <div class="space-y-2">
                <h3 class="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {{ i18n.t().incidents.notificationPreview }} ({{ i18n.language().toUpperCase() }})
                </h3>
                <div class="rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs leading-relaxed text-slate-700 dark:border-slate-800 dark:bg-[#090D16] dark:text-slate-300">
                  {{ buildLocalizedNotification(inc) }}
                </div>
              </div>
            </div>
          </section>
        }
      </div>
    </div>
  `,
})
export class IncidentsView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  async simulateDuplicateAlarm(): Promise<void> {
    await this.ops.injectThermalSpike('gpu-fra-b09-01', 38.7);
  }

  buildLocalizedNotification(inc: Incident): string {
    const lang = this.i18n.language();
    const assets = inc.affectedAssetIds.join(', ');
    if (lang === 'fr') {
      return `[Aureom Europe NOC] Alerte ${inc.severity} (${inc.id}) sur le site ${inc.siteId}. Équipements concernés : ${assets}. Symptôme : ${inc.title}. État actuel : ${inc.status}. Dernière observation : ${this.i18n.formatDateTime(inc.lastSeenAt)}.`;
    }
    if (lang === 'de') {
      return `[Aureom Europe NOC] Meldung ${inc.severity} (${inc.id}) am Standort ${inc.siteId}. Betroffene Komponenten: ${assets}. Ereignis: ${inc.title}. Status: ${inc.status}. Letzte Erfassung: ${this.i18n.formatDateTime(inc.lastSeenAt)}.`;
    }
    return `[Aureom Europe NOC] Advisory ${inc.severity} (${inc.id}) at site ${inc.siteId}. Affected assets: ${assets}. Event: ${inc.title}. Current status: ${inc.status}. Last observed: ${this.i18n.formatDateTime(inc.lastSeenAt)}.`;
  }
}
