import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';
import {MetricProvenance} from '../shared/metric-provenance';

@Component({
  selector: 'app-network-view',
  imports: [MatIconModule, MetricProvenance],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          {{ i18n.t().network.title }}
        </h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {{ i18n.t().network.subtitle }}
        </p>
      </div>

      <div class="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-xs text-amber-800 dark:text-amber-200">
        <mat-icon class="!text-[16px] !w-4 !h-4">security</mat-icon>
        <span>{{ i18n.t().network.noCliWarning }}</span>
      </div>

      <!-- Switches Table -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Switches & Fabric Uplinks</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5 font-medium">Switch</th>
                <th class="px-5 py-2.5 font-medium">Model</th>
                <th class="px-5 py-2.5 font-medium">OOB Management</th>
                <th class="px-5 py-2.5 font-medium">Observed Traffic</th>
                <th class="px-5 py-2.5 font-medium">ASIC Temp</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (sw of switches(); track sw.id) {
                <tr>
                  <td class="px-5 py-3 font-mono font-semibold">{{ sw.name }}</td>
                  <td class="px-5 py-3 text-xs">{{ sw.manufacturer }} {{ sw.model }}</td>
                  <td class="px-5 py-3 font-mono text-xs">{{ sw.managementIp }} ({{ sw.managementNetwork }})</td>
                  <td class="px-5 py-3">
                    <app-metric-provenance [metric]="sw.metrics['uplink_rx_gbps'] || sw.metrics['fabric_rx_gbps']" />
                  </td>
                  <td class="px-5 py-3">
                    <app-metric-provenance [metric]="sw.metrics['asic_temp_c']" />
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- VLANs & Network Segmentation -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">VLANs, Project Networks & OOB Isolation</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5 font-medium">VLAN ID</th>
                <th class="px-5 py-2.5 font-medium">Site</th>
                <th class="px-5 py-2.5 font-medium">Segment Name</th>
                <th class="px-5 py-2.5 font-medium">CIDR</th>
                <th class="px-5 py-2.5 font-medium">Purpose / Tenant</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (vl of ops.snapshot()?.vlans ?? []; track vl.id) {
                <tr>
                  <td class="px-5 py-2.5 font-mono font-semibold">{{ vl.vlanId }}</td>
                  <td class="px-5 py-2.5 font-mono text-xs">{{ vl.siteId }}</td>
                  <td class="px-5 py-2.5 font-mono text-xs">{{ vl.name }}</td>
                  <td class="px-5 py-2.5 font-mono text-xs tabular-nums">{{ vl.cidr }}</td>
                  <td class="px-5 py-2.5 text-xs">
                    {{ vl.purpose }} {{ vl.projectName ? '· ' + vl.projectName : '' }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Configuration Change Proposals & Running vs Proposed Diff -->
      @for (prop of ops.snapshot()?.networkProposals ?? []; track prop.id) {
        <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div class="font-mono text-xs text-blue-600 dark:text-cyan-400">
                {{ prop.id }} · {{ prop.switchName }} · Mode: {{ prop.writeMode }}
              </div>
              <h2 class="mt-1 text-base font-semibold">{{ prop.title }}</h2>
              <div class="mt-1 flex flex-wrap gap-3 text-xs text-slate-500">
                <span>Request: <strong class="font-mono text-slate-800 dark:text-slate-200">{{ prop.requestStatus }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Device Ack: <strong class="font-mono text-slate-800 dark:text-slate-200">{{ prop.deviceAckStatus }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Operational Verify: <strong class="font-mono text-emerald-600 dark:text-emerald-400">{{ prop.verifiedOperationalState }}</strong></span>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="ops.networkProposalAction(prop.id, 'approve')"
                [disabled]="prop.requestStatus === 'Approved'"
                class="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                {{ i18n.t().network.approveProposal }}
              </button>
              <button
                type="button"
                (click)="ops.networkProposalAction(prop.id, 'commit_mock')"
                [disabled]="prop.requestStatus !== 'Approved' || prop.verifiedOperationalState === 'VerifiedMatch'"
                class="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-40"
              >
                {{ i18n.t().network.commitMock }}
              </button>
            </div>
          </div>

          <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#090D16]">
              <div class="mb-2 text-xs font-semibold text-slate-500">Running Config (Authoritative)</div>
              <pre class="overflow-x-auto font-mono text-xs text-slate-700 dark:text-slate-300">{{ prop.runningConfigSnippet }}</pre>
            </div>
            <div class="rounded-lg border border-cyan-500/30 p-3 dark:bg-[#090D16]">
              <div class="mb-2 text-xs font-semibold text-cyan-600 dark:text-cyan-400">Proposed Config</div>
              <pre class="overflow-x-auto font-mono text-xs text-slate-900 dark:text-cyan-100">{{ prop.proposedConfigSnippet }}</pre>
            </div>
          </div>
        </section>
      }
    </div>
  `,
})
export class NetworkView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  readonly switches = computed(() =>
    this.ops.filteredEquipment().filter((e) => e.category === 'network'),
  );
}
