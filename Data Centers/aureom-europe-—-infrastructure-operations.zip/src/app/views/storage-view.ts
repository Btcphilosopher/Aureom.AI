import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';
import {MetricProvenance} from '../shared/metric-provenance';

@Component({
  selector: 'app-storage-view',
  imports: [MatIconModule, MetricProvenance],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          {{ i18n.t().storage.title }}
        </h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {{ i18n.t().storage.subtitle }}
        </p>
      </div>

      <div class="space-y-4">
        @for (pool of ops.snapshot()?.storagePools ?? []; track pool.id) {
          <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]">
            <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
              <div>
                <div class="font-mono text-xs text-blue-600 dark:text-cyan-400">
                  {{ pool.siteId }} · {{ pool.technology }} · Replication: {{ pool.replicationState }}
                </div>
                <h2 class="mt-1 font-mono text-lg font-semibold text-slate-900 dark:text-slate-50">
                  {{ pool.name }}
                </h2>
                <p class="mt-1 text-xs text-slate-600 dark:text-slate-400">
                  {{ pool.redundancyScheme }} — {{ pool.durabilityNote }}
                </p>
              </div>
              <div class="flex gap-6">
                <app-metric-provenance [metric]="pool.latencyMs" />
                <app-metric-provenance [metric]="pool.throughputGBps" />
              </div>
            </div>

            <!-- Distinct Capacity Tiers (No Double-Counting) -->
            <div class="grid grid-cols-2 gap-4 sm:grid-cols-5 font-mono tabular-nums">
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-[11px] text-slate-500">{{ i18n.t().storage.raw }}</div>
                <div class="mt-1 text-base font-semibold">{{ pool.rawTiB }} TiB</div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-[11px] text-slate-500">{{ i18n.t().storage.usable }}</div>
                <div class="mt-1 text-base font-semibold text-cyan-600 dark:text-cyan-400">{{ pool.usableTiB }} TiB</div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-[11px] text-slate-500">Reserved Buffer</div>
                <div class="mt-1 text-base font-semibold">{{ pool.reservedBufferTiB }} TiB</div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-[11px] text-slate-500">{{ i18n.t().storage.allocated }}</div>
                <div class="mt-1 text-base font-semibold text-violet-600 dark:text-violet-400">{{ pool.allocatedTiB }} TiB</div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-[11px] text-slate-500">{{ i18n.t().storage.consumed }}</div>
                <div class="mt-1 text-base font-semibold text-emerald-600 dark:text-emerald-400">{{ pool.consumedTiB }} TiB</div>
              </div>
            </div>

            <!-- Separate Snapshot vs Backup & Restore-Test Status -->
            <div class="flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 pt-3 text-xs dark:border-slate-800">
              <div class="flex flex-wrap items-center gap-4">
                <span>
                  Last Local Snapshot:
                  <strong class="font-mono">{{ i18n.formatDateTime(pool.lastSnapshotAt) }}</strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Independent Backup:
                  <strong class="font-mono">{{ pool.lastBackupAt.includes('T') ? i18n.formatDateTime(pool.lastBackupAt) : pool.lastBackupAt }}</strong>
                </span>
              </div>
              <div class="flex items-center gap-2 font-mono">
                <mat-icon
                  class="!text-[16px] !w-4 !h-4"
                  [class]="pool.lastRestoreTestStatus === 'Passed' ? 'text-emerald-500' : 'text-amber-500'"
                >
                  {{ pool.lastRestoreTestStatus === 'Passed' ? 'verified' : 'warning' }}
                </mat-icon>
                <span>
                  Restore Test: {{ pool.lastRestoreTestStatus }}
                  ({{ pool.lastRestoreTestAt.includes('T') ? i18n.formatDateTime(pool.lastRestoreTestAt) : pool.lastRestoreTestAt }})
                </span>
              </div>
            </div>
          </section>
        }
      </div>
    </div>
  `,
})
export class StorageView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
}
