import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';
import {MetricProvenance} from '../shared/metric-provenance';

@Component({
  selector: 'app-gpus-view',
  imports: [MatIconModule, MetricProvenance],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          {{ i18n.t().gpus.title }}
        </h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {{ i18n.t().gpus.subtitle }}
        </p>
      </div>

      @for (node of gpuNodes(); track node.id) {
        <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
            <div>
              <div class="flex items-center gap-2 font-mono text-xs text-slate-500 dark:text-slate-400">
                <span>{{ node.assetTag }}</span>
                <span aria-hidden="true">·</span>
                <span>Slurm: {{ node.schedulerNodeState }}</span>
                <span aria-hidden="true">·</span>
                <span>Hardware: {{ node.operationalStatus }}</span>
              </div>
              <h2 class="mt-1 font-mono text-lg font-semibold text-slate-900 dark:text-slate-50">
                {{ node.name }} — {{ node.model }}
              </h2>
              <div class="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                <span>Driver: <strong class="font-mono text-slate-700 dark:text-slate-200">{{ node.gpus?.[0]?.driverVersion }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Runtime: <strong class="font-mono text-slate-700 dark:text-slate-200">{{ node.gpus?.[0]?.runtimeVersion }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>
                  {{ i18n.t().gpus.partitionSupport }}:
                  @if ((node.gpus?.[0]?.partitionSupport?.length ?? 0) > 0) {
                    <strong class="font-mono text-cyan-600 dark:text-cyan-400">{{ node.gpus?.[0]?.partitionSupport?.join(', ') }}</strong>
                  } @else {
                    <strong class="text-amber-600 dark:text-amber-400">{{ i18n.t().gpus.passthroughOnly }}</strong>
                  }
                </span>
              </div>
            </div>

            <div class="flex items-center gap-4">
              <app-metric-provenance [metric]="node.metrics['inlet_temp_c']" />
              <app-metric-provenance [metric]="node.metrics['power_w']" />
              <button
                type="button"
                (click)="ops.createAutomationWorkflow(node.id, 'drain_node')"
                class="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <mat-icon class="!text-[16px] !w-4 !h-4">pause_circle</mat-icon>
                <span>Drain Node</span>
              </button>
            </div>
          </div>

          <!-- Mapped Customer Workloads (Separate from Hardware Health) -->
          @for (wl of workloadsForNode(node.id); track wl.id) {
            <div class="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-violet-500/25 bg-violet-500/5 px-4 py-2.5 text-xs">
              <div class="flex flex-wrap items-center gap-2">
                <span class="font-semibold text-violet-700 dark:text-violet-300">{{ wl.orgName }}</span>
                <span aria-hidden="true">·</span>
                <span class="font-mono">{{ wl.resourceName }}</span>
                <span aria-hidden="true">·</span>
                <span>Customer Status: <strong class="font-mono">{{ wl.customerStatus }}</strong></span>
              </div>
              <div class="font-mono text-slate-600 dark:text-slate-300">
                {{ wl.migratable ? 'Live-Migratable' : 'Non-Migratable (' + (wl.migrationConstraintReason || 'Pinned') + ')' }}
              </div>
            </div>
          }

          <!-- Per-Accelerator Grid -->
          <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            @for (gpu of node.gpus ?? []; track gpu.index) {
              <div class="rounded-lg border border-slate-200 p-3 text-xs space-y-2 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="flex items-center justify-between">
                  <span class="font-mono font-semibold text-slate-900 dark:text-slate-100">
                    GPU #{{ gpu.index }} · {{ gpu.architecture }}
                  </span>
                  <span
                    class="font-mono text-[11px]"
                    [class]="gpu.schedulerAllocated ? 'text-violet-600 dark:text-violet-400' : 'text-slate-500'"
                  >
                    {{ gpu.schedulerAllocated ? 'Slurm ALLOC' : 'Slurm IDLE' }}
                  </span>
                </div>
                <div class="text-[11px] text-slate-500 dark:text-slate-400">
                  Mode: <span class="font-mono text-slate-700 dark:text-slate-200">{{ gpu.activePartitionMode }}</span>
                </div>
                <div class="grid grid-cols-2 gap-2 pt-1 font-mono tabular-nums">
                  <div>
                    <div class="text-[10px] text-slate-500">DCGM Util</div>
                    <div class="font-semibold">{{ gpu.utilisationPct.value }}%</div>
                  </div>
                  <div>
                    <div class="text-[10px] text-slate-500">VRAM</div>
                    <div class="font-semibold">{{ gpu.vramUsedGiB.value }}/{{ gpu.vramGiB }} GiB</div>
                  </div>
                  <div>
                    <div class="text-[10px] text-slate-500">Temp / Power</div>
                    <div>{{ gpu.tempC.value }}°C · {{ gpu.powerW.value }}W</div>
                  </div>
                  <div>
                    <div class="text-[10px] text-slate-500">ECC Errors</div>
                    <div [class]="gpu.eccErrors.value > 0 ? 'text-rose-500 font-semibold' : 'text-emerald-500'">
                      {{ gpu.eccErrors.value }}
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>
        </section>
      }
    </div>
  `,
})
export class GpusView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  readonly gpuNodes = computed(() =>
    this.ops.filteredEquipment().filter((e) => e.category === 'gpu'),
  );

  workloadsForNode(equipmentId: string) {
    return (this.ops.snapshot()?.workloads ?? []).filter((w) => w.equipmentId === equipmentId);
  }
}
