import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-sites-view',
  imports: [MatIconModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().sites.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().sites.subtitle }}
          </p>
        </div>
        <button
          type="button"
          (click)="toggleImportForm()"
          class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
        >
          <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">add_box</mat-icon>
          <span>{{ i18n.t().sites.importBtn }}</span>
        </button>
      </div>

      <!-- Inventory Import Form -->
      @if (showImportForm()) {
        <form
          [formGroup]="importForm"
          (submit)="submitImport($event)"
          class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]"
        >
          <div class="flex items-center justify-between">
            <h2 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {{ i18n.t().sites.importTitle }}
            </h2>
            <button type="button" (click)="showImportForm.set(false)" class="text-xs text-slate-500 hover:underline">
              Cancel
            </button>
          </div>
          <div class="grid grid-cols-1 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <label class="block text-xs">
              <span class="text-slate-500 dark:text-slate-400">Rack</span>
              <select
                formControlName="rackId"
                class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900"
              >
                @for (r of ops.snapshot()?.racks ?? []; track r.id) {
                  <option [value]="r.id">{{ r.code }}</option>
                }
              </select>
            </label>
            <label class="block text-xs">
              <span class="text-slate-500 dark:text-slate-400">Hostname</span>
              <input formControlName="name" type="text" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
            </label>
            <label class="block text-xs">
              <span class="text-slate-500 dark:text-slate-400">U Start</span>
              <input formControlName="uStart" type="number" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
            </label>
            <label class="block text-xs">
              <span class="text-slate-500 dark:text-slate-400">U End</span>
              <input formControlName="uEnd" type="number" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
            </label>
            <label class="block text-xs">
              <span class="text-slate-500 dark:text-slate-400">Face</span>
              <select formControlName="face" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
                <option value="full">Full Depth</option>
                <option value="front">Front Only</option>
                <option value="rear">Rear Only</option>
              </select>
            </label>
            <label class="block text-xs">
              <span class="text-slate-500 dark:text-slate-400">Serial Number</span>
              <input formControlName="serialNumber" type="text" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
            </label>
          </div>
          @if (importErrors().length > 0) {
            <div class="rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-700 dark:text-rose-300">
              @for (err of importErrors(); track err) {
                <div>{{ err }}</div>
              }
            </div>
          }
          <div class="flex justify-end">
            <button type="submit" class="rounded-lg bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-700">
              Validate Occupancy & Import
            </button>
          </div>
        </form>
      }

      <!-- Sites -> Buildings -> Rooms Hierarchy -->
      @for (site of ops.snapshot()?.sites ?? []; track site.id) {
        <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-5 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
            <div>
              <div class="flex items-center gap-2 text-xs font-mono text-blue-600 dark:text-cyan-400">
                <span>{{ site.code }}</span>
                <span aria-hidden="true">·</span>
                <span>{{ site.dataLocation }}</span>
                <span aria-hidden="true">·</span>
                <span>{{ site.tierClassification }}</span>
              </div>
              <h2 class="mt-1 text-lg font-semibold text-slate-900 dark:text-slate-50">
                {{ site.name }} — {{ site.city }}, {{ site.country }}
              </h2>
            </div>
            <div class="text-xs text-slate-500 dark:text-slate-400">
              Grid Operator: <span class="font-medium text-slate-800 dark:text-slate-200">{{ site.gridOperator }}</span>
            </div>
          </div>

          @for (room of roomsForSite(site.id); track room.id) {
            <div class="space-y-3">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {{ room.name }}
                  </h3>
                  <div class="text-xs text-slate-500 dark:text-slate-400">
                    {{ room.coolingArchitecture }} · Design {{ room.designPowerKw }} kW / Floor {{ room.maxFloorLoadKgM2 }} kg/m²
                  </div>
                </div>
                <span class="font-mono text-xs text-slate-500">
                  Target Inlet: {{ room.targetInletTempMinC }}–{{ room.targetInletTempMaxC }}°C
                </span>
              </div>

              <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                @for (rack of racksForRoom(room.id); track rack.id) {
                  <button
                    type="button"
                    (click)="inspectRack(rack.id)"
                    class="flex flex-col justify-between rounded-lg border border-slate-200 p-3 text-left transition-colors hover:border-blue-500 dark:border-slate-800 dark:bg-[#141D2F] dark:hover:border-cyan-400"
                  >
                    <div class="flex items-center justify-between">
                      <span class="font-mono text-xs font-semibold text-slate-900 dark:text-slate-100">
                        {{ rack.code }}
                      </span>
                      <span class="font-mono text-[11px] tabular-nums text-slate-500">
                        {{ equipmentCountInRack(rack.id) }} dev
                      </span>
                    </div>
                    <div class="mt-3 space-y-1 font-mono text-xs tabular-nums">
                      <div class="flex justify-between">
                        <span class="text-slate-500">Power</span>
                        <span>{{ rack.powerDrawKw.value }} / {{ rack.powerBudgetKw }} kW</span>
                      </div>
                      <div class="flex justify-between">
                        <span class="text-slate-500">Inlet</span>
                        <span
                          [class]="rack.inletTempC.value >= 30 ? 'text-rose-500 font-semibold' : ''"
                        >
                          {{ rack.inletTempC.value }}°C
                        </span>
                      </div>
                    </div>
                  </button>
                }
              </div>
            </div>
          }
        </section>
      }

      <!-- Discovered vs Approved Inventory Drift Queue -->
      <section class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
            {{ i18n.t().sites.reconcileTitle }}
          </h2>
          <p class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            Discovery observations never silently overwrite approved inventory records.
          </p>
        </div>
        <div class="divide-y divide-slate-200 dark:divide-slate-800">
          @for (item of pendingDrifts(); track item.diff.id) {
            <div class="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 text-sm">
              <div>
                <div class="font-mono text-xs font-semibold text-slate-900 dark:text-slate-100">
                  {{ item.equipmentName }} · {{ item.diff.field }}
                </div>
                <div class="mt-1 flex flex-wrap items-center gap-3 text-xs">
                  <span class="text-slate-500">Approved: <strong class="font-mono text-slate-800 dark:text-slate-200">{{ item.diff.approvedValue }}</strong></span>
                  <span aria-hidden="true">→</span>
                  <span class="text-amber-600 dark:text-amber-400">Discovered ({{ item.diff.source }}): <strong class="font-mono">{{ item.diff.discoveredValue }}</strong></span>
                </div>
              </div>
              <div class="flex items-center gap-2">
                <button
                  type="button"
                  (click)="ops.reconcileDiff(item.equipmentId, item.diff.id, 'accept')"
                  class="rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700"
                >
                  {{ i18n.t().sites.accept }}
                </button>
                <button
                  type="button"
                  (click)="ops.reconcileDiff(item.equipmentId, item.diff.id, 'reject')"
                  class="rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  {{ i18n.t().sites.reject }}
                </button>
              </div>
            </div>
          } @empty {
            <div class="px-5 py-5 text-sm text-slate-500 dark:text-slate-400">
              {{ i18n.t().sites.noDrifts }}
            </div>
          }
        </div>
      </section>
    </div>
  `,
})
export class SitesView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
  private readonly router = inject(Router);

  readonly showImportForm = signal(false);
  readonly importErrors = signal<string[]>([]);

  readonly importForm = new FormGroup({
    rackId: new FormControl('rack-fra-02', {nonNullable: true, validators: [Validators.required]}),
    name: new FormControl('cmp-fra-a02-new', {nonNullable: true, validators: [Validators.required]}),
    uStart: new FormControl(18, {nonNullable: true, validators: [Validators.required]}),
    uEnd: new FormControl(19, {nonNullable: true, validators: [Validators.required]}),
    face: new FormControl<'full' | 'front' | 'rear'>('full', {nonNullable: true}),
    serialNumber: new FormControl('SN-DEL-NEW-9012', {nonNullable: true, validators: [Validators.required]}),
  });

  readonly pendingDrifts = computed(() => {
    const eqs = this.ops.snapshot()?.equipment ?? [];
    const out: {equipmentId: string; equipmentName: string; diff: (typeof eqs)[number]['discoveredDiffs'][number]}[] = [];
    for (const eq of eqs) {
      for (const d of eq.discoveredDiffs) {
        if (d.status === 'pending') {
          out.push({equipmentId: eq.id, equipmentName: eq.name, diff: d});
        }
      }
    }
    return out;
  });

  roomsForSite(siteId: string) {
    return (this.ops.snapshot()?.rooms ?? []).filter((r) => r.siteId === siteId);
  }

  racksForRoom(roomId: string) {
    return (this.ops.snapshot()?.racks ?? []).filter((r) => r.roomId === roomId);
  }

  equipmentCountInRack(rackId: string): number {
    return (this.ops.snapshot()?.equipment ?? []).filter((e) => e.rackId === rackId).length;
  }

  toggleImportForm(): void {
    this.showImportForm.update((v) => !v);
  }

  inspectRack(rackId: string): void {
    this.ops.selectedRackId.set(rackId);
    void this.router.navigateByUrl('/racks');
  }

  async submitImport(event: Event): Promise<void> {
    event.preventDefault();
    this.importErrors.set([]);
    const val = this.importForm.getRawValue();
    const res = await this.ops.importEquipment([val]);
    if (!res.ok) {
      this.importErrors.set(res.errors);
    } else {
      this.showImportForm.set(false);
    }
  }
}
