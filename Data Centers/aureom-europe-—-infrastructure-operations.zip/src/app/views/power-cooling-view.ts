import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';
import {MetricProvenance} from '../shared/metric-provenance';

@Component({
  selector: 'app-power-cooling-view',
  imports: [MatIconModule, MetricProvenance],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().powerCooling.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().powerCooling.subtitle }}
          </p>
        </div>
        <button
          type="button"
          (click)="ops.injectThermalSpike('gpu-fra-b09-01', 38.4)"
          class="inline-flex items-center gap-2 rounded-lg bg-amber-600 px-4 py-2 text-xs font-medium text-white hover:bg-amber-700"
        >
          <mat-icon class="!text-[16px] !w-4 !h-4">thermostat</mat-icon>
          <span>{{ i18n.t().powerCooling.injectTempSpike }}</span>
        </button>
      </div>

      <!-- Safety-Critical Facility Isolation Notice -->
      <div class="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-800 dark:text-amber-200">
        <mat-icon class="!text-[18px] !w-[18px] !h-[18px] shrink-0">shield</mat-icon>
        <div>
          <span class="font-semibold">{{ i18n.t().controls.safetyBoundaryTitle }}:</span>
          {{ i18n.t().controls.safetyBoundaryText }}
        </div>
      </div>

      <!-- Period-Energy PUE Windows -->
      <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
        @for (pue of ops.snapshot()?.pueWindows ?? []; track pue.siteId) {
          <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-3 dark:border-slate-800 dark:bg-[#0F1624]">
            <div class="flex items-center justify-between">
              <div>
                <div class="font-mono text-xs text-cyan-600 dark:text-cyan-400">
                  {{ pue.siteId }} · {{ pue.windowLabel }}
                </div>
                <h2 class="mt-0.5 text-sm font-semibold">{{ pue.boundaryDescription }}</h2>
              </div>
              <div class="text-right font-mono tabular-nums">
                <div class="text-2xl font-semibold text-cyan-600 dark:text-cyan-400">
                  {{ i18n.formatNumber(pue.computedPue, 3) }}
                </div>
                <div class="text-[11px] text-slate-500">PUE ({{ pue.source }})</div>
              </div>
            </div>
            <div class="grid grid-cols-2 gap-4 border-t border-slate-200 pt-3 font-mono text-xs tabular-nums dark:border-slate-800">
              <div>
                <span class="text-slate-500">Total Facility Energy:</span>
                <strong class="ml-1">{{ i18n.formatNumber(pue.totalFacilityEnergyKwh, 1) }} kWh</strong>
              </div>
              <div>
                <span class="text-slate-500">IT Equipment Energy:</span>
                <strong class="ml-1">{{ i18n.formatNumber(pue.itEquipmentEnergyKwh, 1) }} kWh</strong>
              </div>
            </div>
            <p class="text-xs text-slate-500 dark:text-slate-400">{{ pue.methodologyNote }}</p>
          </section>
        }
      </div>

      <!-- Upstream Utility / Transformer / UPS / PDU Chain -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Power Distribution Hierarchy & Rated Capacity vs Measured Load</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5 font-medium">Node</th>
                <th class="px-5 py-2.5 font-medium">Tier / Parent</th>
                <th class="px-5 py-2.5 font-medium">Measured Load</th>
                <th class="px-5 py-2.5 text-right font-medium">Rated Capacity</th>
                <th class="px-5 py-2.5 text-right font-medium">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (node of ops.snapshot()?.upstreamPowerNodes ?? []; track node.id) {
                <tr>
                  <td class="px-5 py-3 font-mono text-xs font-semibold">{{ node.name }}</td>
                  <td class="px-5 py-3 font-mono text-xs text-slate-500">
                    {{ node.type.toUpperCase() }} {{ node.parentId ? '← ' + node.parentId : '(Root)' }}
                  </td>
                  <td class="px-5 py-3">
                    <app-metric-provenance [metric]="node.measuredLoadKw" />
                  </td>
                  <td class="px-5 py-3 text-right font-mono text-xs tabular-nums">
                    {{ node.ratedCapacityKva }} kVA
                  </td>
                  <td class="px-5 py-3 text-right font-mono text-xs font-semibold">
                    <span [class]="node.status === 'Warning' ? 'text-amber-500' : 'text-emerald-500'">
                      {{ node.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Rack Power & Thermal Headroom -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Rack Thermal & Power Telemetry (Independent Metric Freshness)</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5 font-medium">Rack</th>
                <th class="px-5 py-2.5 font-medium">Inlet Temp</th>
                <th class="px-5 py-2.5 font-medium">Outlet Temp</th>
                <th class="px-5 py-2.5 font-medium">Active Power</th>
                <th class="px-5 py-2.5 text-right font-medium">Power Headroom</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (rack of ops.filteredRacks(); track rack.id) {
                <tr>
                  <td class="px-5 py-3 font-mono text-xs font-semibold">{{ rack.code }}</td>
                  <td class="px-5 py-3"><app-metric-provenance [metric]="rack.inletTempC" /></td>
                  <td class="px-5 py-3"><app-metric-provenance [metric]="rack.outletTempC" /></td>
                  <td class="px-5 py-3"><app-metric-provenance [metric]="rack.powerDrawKw" /></td>
                  <td class="px-5 py-3 text-right font-mono text-xs tabular-nums">
                    {{ i18n.formatNumber(rack.powerBudgetKw - rack.powerDrawKw.value, 1) }} kW free / {{ rack.powerBudgetKw }} kW
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class PowerCoolingView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
}
