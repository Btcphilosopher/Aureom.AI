import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-overview-view',
  imports: [MatIconModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().overview.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().overview.subtitle }}
          </p>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
          <span class="font-mono tabular-nums">
            Snapshot: {{ i18n.formatDateTime(ops.snapshot()?.generatedAt) }}
          </span>
          <span aria-hidden="true">·</span>
          <span>{{ ops.sseConnected() ? 'SSE Live Stream Active' : 'Polling Mode' }}</span>
        </div>
      </div>

      <!-- KPI Strip -->
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <div class="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="text-xs font-medium text-slate-500 dark:text-slate-400">
            {{ i18n.t().overview.kpiPower }}
          </div>
          <div class="mt-2 flex items-baseline gap-1.5 font-mono tabular-nums">
            <span class="text-2xl font-semibold text-slate-900 dark:text-slate-50">
              {{ i18n.formatNumber(totalItPowerKw(), 1) }}
            </span>
            <span class="text-xs text-slate-500">kW</span>
          </div>
          <div class="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            SNMPv3 + Redfish · {{ filteredRacksCount() }} racks
          </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="text-xs font-medium text-slate-500 dark:text-slate-400">
            {{ i18n.t().overview.kpiPue }}
          </div>
          <div class="mt-2 flex items-baseline gap-1.5 font-mono tabular-nums">
            <span class="text-2xl font-semibold text-cyan-600 dark:text-cyan-400">
              {{ primaryPue() }}
            </span>
            <span class="text-xs text-slate-500">kWh/kWh</span>
          </div>
          <div class="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            BMS-Modbus-RO · Integrated 24h boundary
          </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="text-xs font-medium text-slate-500 dark:text-slate-400">
            {{ i18n.t().overview.kpiIncidents }}
          </div>
          <div class="mt-2 flex items-baseline gap-2 font-mono tabular-nums">
            <span
              class="text-2xl font-semibold"
              [class]="ops.openIncidentsCount() > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'"
            >
              {{ ops.openIncidentsCount() }}
            </span>
            <span class="text-xs text-slate-500">open</span>
          </div>
          <div class="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            Deduplicated & correlated alert stream
          </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="text-xs font-medium text-slate-500 dark:text-slate-400">
            {{ i18n.t().overview.kpiStale }}
          </div>
          <div class="mt-2 flex items-baseline gap-2 font-mono tabular-nums">
            <span
              class="text-2xl font-semibold"
              [class]="ops.staleMetricsList().length > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'"
            >
              {{ ops.staleMetricsList().length }}
            </span>
            <span class="text-xs text-slate-500">metrics</span>
          </div>
          <div class="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            Per-metric independent freshness (&gt;180s)
          </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="text-xs font-medium text-slate-500 dark:text-slate-400">
            {{ i18n.t().overview.kpiGpus }}
          </div>
          <div class="mt-2 flex items-baseline gap-1.5 font-mono tabular-nums">
            <span class="text-2xl font-semibold text-violet-600 dark:text-violet-400">
              {{ gpuSummary().allocated }} / {{ gpuSummary().total }}
            </span>
          </div>
          <div class="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            Slurm-REST + DCGM · H100 / MI300X / L40S
          </div>
        </div>
      </div>

      <!-- 12-Step Demonstration Launch Banner -->
      <div class="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-blue-500/25 bg-blue-50/70 p-5 dark:border-blue-500/20 dark:bg-[#111B30]">
        <div class="max-w-3xl space-y-1">
          <h2 class="text-base font-semibold text-slate-900 dark:text-slate-50">
            {{ i18n.t().overview.demoBannerTitle }}
          </h2>
          <p class="text-sm text-slate-600 dark:text-slate-300">
            {{ i18n.t().overview.demoBannerDesc }}
          </p>
        </div>
        <button
          type="button"
          (click)="ops.demoDrawerOpen.set(true)"
          class="inline-flex items-center gap-2 whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-700"
        >
          <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">play_circle</mat-icon>
          <span>{{ i18n.t().overview.openWalkthrough }}</span>
        </button>
      </div>

      <!-- Two-Column Watchlists -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <!-- Stale & Delayed Telemetry Watchlist -->
        <section class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
            <h2 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {{ i18n.t().overview.staleWatchlist }}
            </h2>
            <a routerLink="/power-cooling" class="text-xs font-medium text-blue-600 hover:underline dark:text-cyan-400">
              Power & Cooling →
            </a>
          </div>
          <div class="divide-y divide-slate-200 dark:divide-slate-800">
            @for (item of ops.staleMetricsList(); track item.equipmentId + item.metricKey) {
              <div class="flex items-center justify-between gap-4 px-5 py-3 text-sm">
                <div>
                  <div class="flex items-center gap-2 font-medium text-slate-900 dark:text-slate-100">
                    <mat-icon class="!text-[16px] !w-4 !h-4 text-rose-500">warning</mat-icon>
                    <span class="font-mono">{{ item.equipmentName }}</span>
                    <span class="text-xs text-slate-500">· {{ item.label }}</span>
                  </div>
                  <div class="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    {{ item.source }} · Observed {{ i18n.formatDateTime(item.observedAt) }}
                  </div>
                </div>
                <div class="text-right font-mono tabular-nums">
                  <div class="font-semibold text-slate-900 dark:text-slate-100">
                    {{ item.value }} {{ item.unit }}
                  </div>
                  <div class="text-xs font-medium text-rose-600 dark:text-rose-400">
                    {{ item.quality }} ({{ i18n.formatRelativeAge(item.ageSeconds) }})
                  </div>
                </div>
              </div>
            } @empty {
              <div class="px-5 py-6 text-sm text-slate-500 dark:text-slate-400">
                All polled Redfish, Prometheus, SNMPv3, and BMS metrics are within freshness SLA (&le;180s).
              </div>
            }
          </div>
        </section>

        <!-- Topology & Upstream SPOF Alerts -->
        <section class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
            <h2 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {{ i18n.t().overview.topologyAlerts }}
            </h2>
            <a routerLink="/racks" class="text-xs font-medium text-blue-600 hover:underline dark:text-cyan-400">
              Rack Elevations →
            </a>
          </div>
          <div class="divide-y divide-slate-200 dark:divide-slate-800">
            @for (warn of ops.snapshot()?.topologyWarnings ?? []; track warn.rackId + warn.type) {
              <div class="flex items-start gap-3 px-5 py-3 text-sm">
                <mat-icon
                  class="!text-[18px] !w-[18px] !h-[18px] mt-0.5 shrink-0"
                  [class]="warn.severity === 'warning' ? 'text-amber-500' : 'text-cyan-500'"
                >
                  {{ warn.severity === 'warning' ? 'bolt' : 'info' }}
                </mat-icon>
                <div class="space-y-0.5">
                  <div class="font-mono text-xs font-semibold text-slate-900 dark:text-slate-100">
                    {{ warn.rackCode }} · {{ warn.type === 'shared_upstream_spof' ? 'SHARED UPSTREAM SPOF' : 'MISSING TOPOLOGY' }}
                  </div>
                  <p class="text-xs text-slate-600 dark:text-slate-400">{{ warn.message }}</p>
                </div>
              </div>
            }
          </div>
        </section>
      </div>

      <!-- Active Incidents Table -->
      <section class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
            {{ i18n.t().overview.activeIncidents }}
          </h2>
          <a routerLink="/incidents" class="text-xs font-medium text-blue-600 hover:underline dark:text-cyan-400">
            Manage Incidents →
          </a>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5 font-medium">ID</th>
                <th class="px-5 py-2.5 font-medium">Severity</th>
                <th class="px-5 py-2.5 font-medium">Title</th>
                <th class="px-5 py-2.5 font-medium">Status</th>
                <th class="px-5 py-2.5 text-right font-medium">Occurrences</th>
                <th class="px-5 py-2.5 text-right font-medium">Last Seen</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (inc of ops.snapshot()?.incidents ?? []; track inc.id) {
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td class="px-5 py-3 font-mono text-xs font-semibold text-blue-600 dark:text-cyan-400">
                    {{ inc.id }}
                  </td>
                  <td class="px-5 py-3 font-mono text-xs font-semibold">
                    <span
                      [class]="inc.severity === 'SEV-1' ? 'text-rose-600 dark:text-rose-400' : inc.severity === 'SEV-2' ? 'text-amber-600 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'"
                    >
                      {{ inc.severity }}
                    </span>
                  </td>
                  <td class="px-5 py-3 text-slate-900 dark:text-slate-100">{{ inc.title }}</td>
                  <td class="px-5 py-3 text-xs font-medium">{{ inc.status }}</td>
                  <td class="px-5 py-3 text-right font-mono tabular-nums">{{ inc.occurrenceCount }}</td>
                  <td class="px-5 py-3 text-right font-mono text-xs tabular-nums text-slate-500">
                    {{ i18n.formatDateTime(inc.lastSeenAt) }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class OverviewView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  readonly filteredRacksCount = computed(() => this.ops.filteredRacks().length);

  readonly totalItPowerKw = computed(() =>
    this.ops.filteredRacks().reduce((acc, r) => acc + r.powerDrawKw.value, 0),
  );

  readonly primaryPue = computed(() => {
    const site = this.ops.selectedSiteFilter();
    const windows = this.ops.snapshot()?.pueWindows ?? [];
    const match = windows.find((w) => site === 'ALL' || w.siteId === site);
    return match ? this.i18n.formatNumber(match.computedPue, 3) : '—';
  });

  readonly gpuSummary = computed(() => {
    const eqs = this.ops.filteredEquipment();
    const gpus = eqs.flatMap((e) => e.gpus ?? []);
    return {
      total: gpus.length,
      allocated: gpus.filter((g) => g.schedulerAllocated).length,
    };
  });
}
