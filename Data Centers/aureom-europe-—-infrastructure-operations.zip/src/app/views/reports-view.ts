import {DOCUMENT, isPlatformBrowser} from '@angular/common';
import {ChangeDetectionStrategy, Component, inject, PLATFORM_ID} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-reports-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().reports.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().reports.subtitle }}
          </p>
        </div>

        <div class="flex flex-wrap gap-2">
          <button
            type="button"
            (click)="downloadMarkdownReport()"
            class="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-medium text-white hover:bg-blue-700"
          >
            <mat-icon class="!text-[16px] !w-4 !h-4">download</mat-icon>
            <span>{{ i18n.t().reports.exportMarkdown }}</span>
          </button>
          <button
            type="button"
            (click)="downloadJsonSnapshot()"
            class="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            <mat-icon class="!text-[16px] !w-4 !h-4">code</mat-icon>
            <span>{{ i18n.t().reports.exportJson }}</span>
          </button>
        </div>
      </div>

      <!-- Synthetic Environmental Disclaimer -->
      <div class="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-800 dark:text-amber-200">
        {{ i18n.t().reports.syntheticDisclaimer }}
      </div>

      <!-- Sustainability & Cost Accounting (Measured vs Estimated vs Billed + Location vs Market Emissions) -->
      <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        @for (sc of ops.snapshot()?.sustainabilityCosts ?? []; track sc.siteId) {
          <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <div>
                <div class="font-mono text-xs text-cyan-600 dark:text-cyan-400">{{ sc.siteId }}</div>
                <h2 class="text-base font-semibold">{{ sc.periodLabel }}</h2>
              </div>
              <span class="font-mono text-xs text-amber-600 dark:text-amber-400">Synthetic Modeled Data</span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-xs font-mono tabular-nums">
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-slate-500">Measured IT Energy</div>
                <div class="mt-1 font-semibold">{{ i18n.formatNumber(sc.measuredItEnergyKwh, 0) }} kWh</div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-slate-500">Est. Facility Overhead</div>
                <div class="mt-1 font-semibold">{{ i18n.formatNumber(sc.estimatedFacilityOverheadKwh, 0) }} kWh</div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-slate-500">Allocated Infra Cost</div>
                <div class="mt-1 font-semibold">{{ i18n.formatCurrencyEur(sc.totalAllocatedCostEur) }}</div>
                <div class="text-[10px] text-slate-500">
                  Elec {{ i18n.formatCurrencyEur(sc.monthlyElectricityCostEur) }} · Depr {{ i18n.formatCurrencyEur(sc.monthlyDepreciationEur) }}
                </div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800 dark:bg-[#141D2F]">
                <div class="text-slate-500">Customer Billed (Separate)</div>
                <div class="mt-1 font-semibold text-emerald-600 dark:text-emerald-400">{{ i18n.formatCurrencyEur(sc.totalCustomerBilledEur) }}</div>
              </div>
            </div>

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div class="font-semibold">Location-Based Emissions</div>
                <div class="mt-1 font-mono text-base font-semibold tabular-nums">
                  {{ sc.locationBasedEmissionsTonnes }} tCO₂e
                </div>
                <div class="mt-0.5 text-[11px] text-slate-500">
                  {{ sc.locationBasedGridFactorGCo2PerKwh }} gCO₂e/kWh · {{ sc.locationBasedSource }}
                </div>
              </div>
              <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div class="font-semibold">Market-Based Emissions</div>
                <div class="mt-1 font-mono text-base font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">
                  {{ sc.marketBasedEmissionsTonnes }} tCO₂e
                </div>
                <div class="mt-0.5 text-[11px] text-slate-500">
                  {{ sc.marketBasedFactorGCo2PerKwh }} gCO₂e/kWh · {{ sc.marketBasedSource }}
                </div>
              </div>
            </div>

            <p class="text-xs text-slate-500 dark:text-slate-400">{{ sc.methodologyNote }}</p>
          </section>
        }
      </div>

      <!-- Customer Cloud & HPC Platform Mapping -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Aureom Europe Customer Cloud & Slurm HPC Resource Mapping</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5">Customer Org / Project</th>
                <th class="px-5 py-2.5">Workload</th>
                <th class="px-5 py-2.5">Physical Host / Rack</th>
                <th class="px-5 py-2.5">Customer Status</th>
                <th class="px-5 py-2.5">Sovereignty</th>
                <th class="px-5 py-2.5 text-right">Billed / mo</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (wl of ops.snapshot()?.workloads ?? []; track wl.id) {
                <tr>
                  <td class="px-5 py-3">
                    <div class="font-semibold">{{ wl.orgName }}</div>
                    <div class="text-slate-500">{{ wl.projectName }}</div>
                  </td>
                  <td class="px-5 py-3 font-mono">{{ wl.resourceName }}</td>
                  <td class="px-5 py-3 font-mono">{{ wl.equipmentId }} ({{ wl.siteId }})</td>
                  <td class="px-5 py-3 font-mono font-semibold">{{ wl.customerStatus }}</td>
                  <td class="px-5 py-3 font-mono">{{ wl.dataLocation }}</td>
                  <td class="px-5 py-3 text-right font-mono tabular-nums">{{ i18n.formatCurrencyEur(wl.monthlyBillingEur) }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class ReportsView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly document = inject(DOCUMENT);

  downloadMarkdownReport(): void {
    const snap = this.ops.snapshot();
    if (!snap || !isPlatformBrowser(this.platformId)) return;
    const lang = this.i18n.language();
    const title =
      lang === 'fr'
        ? 'Rapport Opérationnel Aureom Europe'
        : lang === 'de'
          ? 'Aureom Europe Betriebsbericht'
          : 'Aureom Europe Infrastructure Operations Report';
    const lines = [
      `# ${title}`,
      `Generated: ${this.i18n.formatDateTime(snap.generatedAt)} (${this.i18n.timezone()})`,
      `Language: ${lang.toUpperCase()}`,
      '',
      `## Sites & Racks`,
      `- Sites: ${snap.sites.map((s) => s.code).join(', ')}`,
      `- Racks monitored: ${snap.racks.length}`,
      `- Active Incidents: ${snap.incidents.filter((i) => i.status !== 'Resolved').length}`,
      `- Change Requests: ${snap.changes.length}`,
      '',
      `## Topology & Resilience Warnings`,
      ...snap.topologyWarnings.map((w) => `- [${w.rackCode}] ${w.message}`),
      '',
      `## Period-Energy PUE`,
      ...snap.pueWindows.map(
        (p) => `- ${p.siteId}: ${p.computedPue} (${p.totalFacilityEnergyKwh} kWh / ${p.itEquipmentEnergyKwh} kWh)`,
      ),
      '',
      `## Disclaimer`,
      this.i18n.t().reports.syntheticDisclaimer,
    ];
    this.triggerDownload(`aureom-report-${lang}.md`, lines.join('\n'), 'text/markdown');
  }

  downloadJsonSnapshot(): void {
    const snap = this.ops.snapshot();
    if (!snap || !isPlatformBrowser(this.platformId)) return;
    this.triggerDownload(
      'aureom-ops-snapshot.json',
      JSON.stringify(snap, null, 2),
      'application/json',
    );
  }

  private triggerDownload(filename: string, content: string, mime: string): void {
    const blob = new Blob([content], {type: mime});
    const url = URL.createObjectURL(blob);
    const a = this.document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
