import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-changes-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            {{ i18n.t().changes.title }}
          </h1>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {{ i18n.t().changes.subtitle }}
          </p>
        </div>

        <div class="flex flex-wrap gap-2">
          <button
            type="button"
            (click)="ops.createAutomationWorkflow('cpu-fra-a01-02', 'run_diagnostic', true)"
            class="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-500/10 dark:text-rose-400"
          >
            <mat-icon class="!text-[16px] !w-4 !h-4">error_outline</mat-icon>
            <span>{{ i18n.t().changes.triggerFailTest }}</span>
          </button>
          <button
            type="button"
            (click)="ops.createAutomationWorkflow('gpu-fra-b09-01', 'request_workload_migration', false)"
            class="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            <mat-icon class="!text-[16px] !w-4 !h-4">swap_horiz</mat-icon>
            <span>Test Pinned Workload Migration Guard</span>
          </button>
        </div>
      </div>

      <!-- Controlled Automation State Machine Workflows -->
      <section class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">
            Controlled Automation Workflows (Proposed → Validated → Approved → Scheduled → Executing → Verified → Completed / Failed)
          </h2>
        </div>
        <div class="divide-y divide-slate-200 dark:divide-slate-800">
          @for (wf of ops.snapshot()?.workflows ?? []; track wf.id) {
            <div class="p-5 space-y-3">
              <div class="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div class="flex items-center gap-2 font-mono text-xs">
                    <span class="font-semibold text-blue-600 dark:text-cyan-400">{{ wf.id }}</span>
                    <span aria-hidden="true">·</span>
                    <span>{{ wf.targetEquipmentName }}</span>
                    <span aria-hidden="true">·</span>
                    <span>{{ wf.actionType }}</span>
                    <span aria-hidden="true">·</span>
                    <span
                      class="font-semibold"
                      [class]="wf.state === 'Failed' ? 'text-rose-500' : wf.state === 'Completed' ? 'text-emerald-500' : 'text-amber-500'"
                    >
                      {{ wf.state }}
                    </span>
                  </div>
                  <div class="mt-1 text-xs text-slate-500">
                    Idempotency: <span class="font-mono">{{ wf.idempotencyKey }}</span> · Requested by {{ wf.requestedBy }}
                    @if (wf.approvedBy) {
                      · Approved by {{ wf.approvedBy }}
                    }
                  </div>
                </div>

                @if (wf.state !== 'Completed' && wf.state !== 'Failed') {
                  <button
                    type="button"
                    (click)="ops.advanceWorkflow(wf.id)"
                    class="rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-medium text-white hover:bg-blue-700"
                  >
                    {{ i18n.t().changes.advanceState }}
                  </button>
                }
              </div>

              @if (wf.failureReason) {
                <div class="rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-700 dark:text-rose-300">
                  <strong>Execution Failed:</strong> {{ wf.failureReason }}
                </div>
              }

              <div class="grid grid-cols-1 gap-2 sm:grid-cols-3 text-xs">
                @for (chk of wf.preflightChecks; track chk.name) {
                  <div class="rounded-lg border border-slate-200 p-2.5 dark:border-slate-800 dark:bg-[#141D2F]">
                    <div class="font-semibold" [class]="chk.passed ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'">
                      {{ chk.name }} ({{ chk.passed ? 'PASS' : 'BLOCKED' }})
                    </div>
                    <div class="mt-0.5 text-slate-500 dark:text-slate-400">{{ chk.detail }}</div>
                  </div>
                }
              </div>
              <div class="text-xs text-slate-500">
                <strong>Compensating Action:</strong> {{ wf.compensatingAction }}
              </div>
            </div>
          } @empty {
            <div class="px-5 py-6 text-sm text-slate-500">
              No automation workflows initiated yet. Launch a diagnostic or node drain from Racks, Compute, GPUs, or test buttons above.
            </div>
          }
        </div>
      </section>

      <!-- Change Requests (Separate from Incidents) -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Change Control Records (Independent of Incident Resolution)</h2>
        </div>
        <div class="divide-y divide-slate-200 dark:divide-slate-800">
          @for (chg of ops.snapshot()?.changes ?? []; track chg.id) {
            <div class="p-5 space-y-2">
              <div class="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div class="font-mono text-xs text-slate-500">
                    {{ chg.id }} · {{ chg.siteId }} · Risk: {{ chg.risk }} · Status: <strong class="text-slate-900 dark:text-slate-100">{{ chg.status }}</strong>
                  </div>
                  <h3 class="mt-0.5 text-sm font-semibold">{{ chg.title }}</h3>
                </div>
                <div class="flex gap-2">
                  @if (chg.status === 'Proposed') {
                    <button
                      type="button"
                      (click)="ops.transitionChangeRequest(chg.id, 'Approved')"
                      class="rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700"
                    >
                      Approve (MFA)
                    </button>
                  }
                  @if (chg.status === 'Approved') {
                    <button
                      type="button"
                      (click)="ops.transitionChangeRequest(chg.id, 'Completed')"
                      class="rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
                    >
                      Mark Completed
                    </button>
                  }
                </div>
              </div>
              <div class="grid grid-cols-1 gap-3 pt-2 text-xs md:grid-cols-2">
                <div>
                  <span class="font-semibold text-slate-600 dark:text-slate-300">Execution Plan:</span>
                  <ul class="mt-1 list-disc pl-4 text-slate-500 dark:text-slate-400">
                    @for (step of chg.executionPlan; track step) {
                      <li>{{ step }}</li>
                    }
                  </ul>
                </div>
                <div>
                  <span class="font-semibold text-slate-600 dark:text-slate-300">Rollback Plan:</span>
                  <ul class="mt-1 list-disc pl-4 text-slate-500 dark:text-slate-400">
                    @for (rb of chg.rollbackPlan; track rb) {
                      <li>{{ rb }}</li>
                    }
                  </ul>
                </div>
              </div>
            </div>
          }
        </div>
      </section>

      <!-- RBAC & Security Audit Log -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Security Boundary & Immutable Audit Trail</h2>
          <span class="font-mono text-xs text-slate-500">
            SSO: {{ ops.session()?.ssoIssuer }} · Secret Vault: Redacted References Only
          </span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5">Timestamp</th>
                <th class="px-5 py-2.5">Actor / Role</th>
                <th class="px-5 py-2.5">Action</th>
                <th class="px-5 py-2.5">Target</th>
                <th class="px-5 py-2.5">Outcome</th>
                <th class="px-5 py-2.5">Detail</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (aud of (ops.snapshot()?.auditLog ?? []).slice(0, 12); track aud.id) {
                <tr>
                  <td class="px-5 py-2.5 font-mono tabular-nums text-slate-500">{{ i18n.formatDateTime(aud.timestamp) }}</td>
                  <td class="px-5 py-2.5 font-mono">{{ aud.actor }} ({{ aud.role }})</td>
                  <td class="px-5 py-2.5 font-mono">{{ aud.action }}</td>
                  <td class="px-5 py-2.5 font-mono">{{ aud.targetId }}</td>
                  <td class="px-5 py-2.5 font-mono font-semibold" [class]="aud.outcome === 'Denied' ? 'text-rose-500' : 'text-emerald-500'">
                    {{ aud.outcome }}
                  </td>
                  <td class="px-5 py-2.5 text-slate-600 dark:text-slate-400">{{ aud.detail }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class ChangesView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
}
