import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {DataLocationCode, RackFeasibilityResult} from '../../shared/models';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-capacity-view',
  imports: [MatIconModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          {{ i18n.t().capacity.title }}
        </h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {{ i18n.t().capacity.subtitle }}
        </p>
      </div>

      <!-- Placement Evaluator Form -->
      <form
        [formGroup]="evalForm"
        (submit)="runEvaluate($event)"
        class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]"
      >
        <h2 class="text-sm font-semibold text-slate-900 dark:text-slate-100">
          Multi-Constraint Placement Evaluator
        </h2>
        <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          <label class="block text-xs">
            <span class="text-slate-500">Site</span>
            <select formControlName="siteId" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="FRA-01">FRA-01 (Frankfurt)</option>
              <option value="PAR-02">PAR-02 (Paris)</option>
            </select>
          </label>
          <label class="block text-xs">
            <span class="text-slate-500">Data Location</span>
            <select formControlName="dataLocation" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="EU-DE">EU-DE (Germany)</option>
              <option value="EU-FR">EU-FR (France)</option>
            </select>
          </label>
          <label class="block text-xs">
            <span class="text-slate-500">Resilience</span>
            <select formControlName="resilience" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="2N">2N (Independent Upstream)</option>
              <option value="N+1">N+1</option>
              <option value="N">N</option>
            </select>
          </label>
          <label class="block text-xs">
            <span class="text-slate-500">Required U</span>
            <input formControlName="requiredU" type="number" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
          </label>
          <label class="block text-xs">
            <span class="text-slate-500">Weight (kg)</span>
            <input formControlName="weightKg" type="number" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
          </label>
          <label class="block text-xs">
            <span class="text-slate-500">Power / Cooling (kW)</span>
            <input formControlName="powerKw" type="number" step="0.5" class="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm font-mono dark:border-slate-700 dark:bg-slate-900" />
          </label>
        </div>

        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="flex flex-wrap items-center gap-4 text-xs">
            <label class="flex items-center gap-2">
              <span class="text-slate-500">Owner:</span>
              <input formControlName="owner" type="text" class="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-900" />
            </label>
            <label class="flex items-center gap-2">
              <span class="text-slate-500">Storage (TiB):</span>
              <input formControlName="storageTiB" type="number" class="w-20 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-mono dark:border-slate-700 dark:bg-slate-900" />
            </label>
          </div>
          <button
            type="submit"
            class="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-700"
          >
            <mat-icon class="!text-[16px] !w-4 !h-4">calculate</mat-icon>
            <span>{{ i18n.t().capacity.evaluateBtn }}</span>
          </button>
        </div>
      </form>

      <!-- Evaluation Results -->
      @if (results().length > 0) {
        <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
          <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
            <h2 class="text-sm font-semibold">Placement Feasibility Matrix & Infeasibility Explanations</h2>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <tr>
                  <th class="px-5 py-2.5 font-medium">Rack</th>
                  <th class="px-5 py-2.5 font-medium">Result</th>
                  <th class="px-5 py-2.5 font-medium">Headroom (U / kg / kW)</th>
                  <th class="px-5 py-2.5 font-medium">2N Diverse Feed</th>
                  <th class="px-5 py-2.5 font-medium">Explanation</th>
                  <th class="px-5 py-2.5 text-right font-medium">Reserve</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                @for (r of results(); track r.rackId) {
                  <tr>
                    <td class="px-5 py-3 font-mono text-xs font-semibold">{{ r.rackCode }}</td>
                    <td class="px-5 py-3 font-mono text-xs font-semibold">
                      <span [class]="r.feasible ? 'text-emerald-500' : 'text-rose-500'">
                        {{ r.feasible ? i18n.t().capacity.feasible : i18n.t().capacity.infeasible }}
                      </span>
                    </td>
                    <td class="px-5 py-3 font-mono text-xs tabular-nums">
                      {{ r.availableU }}U · {{ r.remainingWeightKg }}kg · {{ r.remainingPowerKw }}kW
                    </td>
                    <td class="px-5 py-3 font-mono text-xs">
                      <span [class]="r.hasIndependentDualFeed ? 'text-emerald-500' : 'text-amber-500'">
                        {{ r.hasIndependentDualFeed ? 'Verified 2N' : 'SPOF / Incomplete' }}
                      </span>
                    </td>
                    <td class="px-5 py-3 text-xs text-slate-600 dark:text-slate-400">
                      @if (r.feasible) {
                        <span class="text-emerald-600 dark:text-emerald-400">
                          Suggested placement U{{ r.suggestedUStart }}–U{{ (r.suggestedUStart ?? 1) + evalForm.controls.requiredU.value - 1 }}
                        </span>
                      } @else {
                        {{ r.reasons.join(' ') }}
                      }
                    </td>
                    <td class="px-5 py-3 text-right">
                      @if (r.feasible && r.suggestedUStart) {
                        <button
                          type="button"
                          (click)="reserveRack(r)"
                          class="rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700"
                        >
                          Reserve U{{ r.suggestedUStart }}
                        </button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      }

      <!-- Active Transactional Reservations -->
      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 class="text-sm font-semibold">Transactional Capacity Reservations</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-2.5 font-medium">ID</th>
                <th class="px-5 py-2.5 font-medium">Rack / U-Slots</th>
                <th class="px-5 py-2.5 font-medium">Owner</th>
                <th class="px-5 py-2.5 font-medium">Resources</th>
                <th class="px-5 py-2.5 font-medium">Status</th>
                <th class="px-5 py-2.5 font-medium">Expires</th>
                <th class="px-5 py-2.5 text-right font-medium">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (res of ops.snapshot()?.reservations ?? []; track res.id) {
                <tr>
                  <td class="px-5 py-3 font-mono text-xs font-semibold">{{ res.id }}</td>
                  <td class="px-5 py-3 font-mono text-xs">{{ res.rackCode }} · U{{ res.uStart }}–U{{ res.uEnd }}</td>
                  <td class="px-5 py-3 text-xs">{{ res.owner }}</td>
                  <td class="px-5 py-3 font-mono text-xs tabular-nums">{{ res.powerKw }} kW · {{ res.dataLocation }}</td>
                  <td class="px-5 py-3 font-mono text-xs">{{ res.status }}</td>
                  <td class="px-5 py-3 font-mono text-xs tabular-nums text-slate-500">{{ i18n.formatDateTime(res.expiresAt) }}</td>
                  <td class="px-5 py-3 text-right">
                    @if (res.status !== 'Released') {
                      <button
                        type="button"
                        (click)="ops.releaseReservation(res.id)"
                        class="rounded-md border border-slate-300 px-2.5 py-1 text-xs hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
                      >
                        Release
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Uncertainty-Banded Forecast -->
      <section class="rounded-xl border border-slate-200 bg-white p-5 space-y-4 dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 class="text-sm font-semibold">{{ i18n.t().capacity.forecastTitle }}</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400">
              FRA-01 linear trend with expanding ±7.5%–19% demand uncertainty cone. Forecasts never claim an exact exhaustion date.
            </p>
          </div>
          <span class="font-mono text-xs text-slate-500">Design Ceiling: 720 kW</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono tabular-nums">
            <thead class="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="py-2 pr-4">Month</th>
                <th class="py-2 pr-4">Projected Power (kW)</th>
                <th class="py-2 pr-4">Uncertainty Band (kW)</th>
                <th class="py-2 pr-4">Projected GPUs</th>
                <th class="py-2">GPU Confidence Band</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (pt of fraForecast(); track pt.monthLabel) {
                <tr>
                  <td class="py-2 pr-4 font-semibold">{{ pt.monthLabel }}</td>
                  <td class="py-2 pr-4 text-cyan-600 dark:text-cyan-400">{{ pt.powerUsedKw }} / {{ pt.powerCapacityKw }} kW</td>
                  <td class="py-2 pr-4 text-slate-500">[{{ pt.powerLowerBoundKw }} – {{ pt.powerUpperBoundKw }}] kW</td>
                  <td class="py-2 pr-4 text-violet-600 dark:text-violet-400">{{ pt.gpuUsedCount }} / {{ pt.gpuCapacityCount }}</td>
                  <td class="py-2 text-slate-500">[{{ pt.gpuLowerBound }} – {{ pt.gpuUpperBound }}] GPUs</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class CapacityView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  readonly results = signal<RackFeasibilityResult[]>([]);

  readonly evalForm = new FormGroup({
    siteId: new FormControl('FRA-01', {nonNullable: true}),
    dataLocation: new FormControl<DataLocationCode>('EU-DE', {nonNullable: true}),
    resilience: new FormControl<'N' | 'N+1' | '2N'>('2N', {nonNullable: true}),
    requiredU: new FormControl(8, {nonNullable: true}),
    weightKg: new FormControl(140, {nonNullable: true}),
    powerKw: new FormControl(10.5, {nonNullable: true}),
    storageTiB: new FormControl(20, {nonNullable: true}),
    owner: new FormControl('Mistral Lattice SAS', {nonNullable: true}),
  });

  readonly fraForecast = computed(
    () => this.ops.snapshot()?.forecasts?.['FRA-01'] ?? [],
  );

  async runEvaluate(event: Event): Promise<void> {
    event.preventDefault();
    const v = this.evalForm.getRawValue();
    const res = await this.ops.evaluateCapacity({
      siteId: v.siteId,
      requiredU: Number(v.requiredU),
      weightKg: Number(v.weightKg),
      powerKw: Number(v.powerKw),
      coolingKw: Number(v.powerKw),
      cpuCores: 0,
      ramGiB: 0,
      gpuCount: 0,
      storageTiB: Number(v.storageTiB),
      networkPorts: 2,
      resilience: v.resilience,
      dataLocation: v.dataLocation,
    });
    this.results.set(res);
  }

  async reserveRack(r: RackFeasibilityResult): Promise<void> {
    const v = this.evalForm.getRawValue();
    const uStart = r.suggestedUStart ?? 1;
    await this.ops.createReservation({
      siteId: r.siteId,
      roomId: r.roomId,
      rackId: r.rackId,
      rackCode: r.rackCode,
      uStart,
      uEnd: uStart + Number(v.requiredU) - 1,
      powerKw: Number(v.powerKw),
      coolingKw: Number(v.powerKw),
      gpuCount: 0,
      storageTiB: Number(v.storageTiB),
      owner: v.owner,
      purpose: 'Capacity Evaluator Placement Reservation',
      dataLocation: v.dataLocation,
      expiresAt: '2026-12-31T23:59:00Z',
    });
    await this.runEvaluate(new Event('submit'));
  }
}
