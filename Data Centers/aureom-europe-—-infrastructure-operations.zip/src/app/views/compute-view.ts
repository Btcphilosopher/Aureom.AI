import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';
import {MetricProvenance} from '../shared/metric-provenance';

@Component({
  selector: 'app-compute-view',
  imports: [MatIconModule, MetricProvenance],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          {{ i18n.t().compute.title }}
        </h1>
        <p class="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {{ i18n.t().compute.subtitle }}
        </p>
      </div>

      <section class="rounded-xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-[#0F1624]">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="border-b border-slate-200 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <tr>
                <th class="px-5 py-3 font-medium">Host / Rack</th>
                <th class="px-5 py-3 font-medium">Hardware</th>
                <th class="px-5 py-3 font-medium">{{ i18n.t().compute.schedulerState }}</th>
                <th class="px-5 py-3 font-medium">{{ i18n.t().compute.measuredUtil }}</th>
                <th class="px-5 py-3 font-medium">Inlet & Power</th>
                <th class="px-5 py-3 font-medium">{{ i18n.t().compute.oobMgmt }}</th>
                <th class="px-5 py-3 text-right font-medium">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
              @for (node of computeNodes(); track node.id) {
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                  <td class="px-5 py-3.5">
                    <div class="font-mono font-semibold text-slate-900 dark:text-slate-100">{{ node.name }}</div>
                    <div class="text-xs font-mono text-slate-500">{{ node.assetTag }} · {{ node.operationalStatus }}</div>
                  </td>
                  <td class="px-5 py-3.5 text-xs">
                    <div class="font-medium text-slate-800 dark:text-slate-200">{{ node.model }}</div>
                    <div class="text-slate-500">{{ node.cpuModel }} · {{ node.ramGiB }} GiB</div>
                  </td>
                  <td class="px-5 py-3.5 font-mono text-xs tabular-nums">
                    <div class="font-semibold text-blue-600 dark:text-cyan-400">{{ node.schedulerNodeState }}</div>
                    <div class="text-slate-500">
                      {{ node.schedulerAllocatedCores ?? 0 }}/{{ node.cpuCores ?? 0 }} cores · {{ node.schedulerAllocatedRamGiB ?? 0 }}/{{ node.ramGiB ?? 0 }} GiB
                    </div>
                  </td>
                  <td class="px-5 py-3.5">
                    <app-metric-provenance [metric]="node.metrics['cpu_util_pct']" />
                  </td>
                  <td class="px-5 py-3.5 space-y-2">
                    <app-metric-provenance [metric]="node.metrics['inlet_temp_c']" />
                    <app-metric-provenance [metric]="node.metrics['power_w']" />
                  </td>
                  <td class="px-5 py-3.5 font-mono text-xs">
                    <div>{{ node.managementIp }}</div>
                    <div class="text-slate-500">{{ node.managementNetwork }}</div>
                  </td>
                  <td class="px-5 py-3.5 text-right">
                    <button
                      type="button"
                      (click)="ops.createAutomationWorkflow(node.id, 'drain_node')"
                      class="inline-flex items-center gap-1 rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
                    >
                      <mat-icon class="!text-[15px] !w-4 !h-4">pause_circle</mat-icon>
                      <span>{{ i18n.t().compute.drainAction }}</span>
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class ComputeView {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  readonly computeNodes = computed(() =>
    this.ops
      .filteredEquipment()
      .filter((e) => e.category === 'compute' || e.category === 'gpu'),
  );
}
