import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {I18nService} from '../core/services/i18n.service';
import {OpsStateService} from '../core/services/ops-state.service';

interface DemoStepDef {
  step: number;
  title: string;
  detail: string;
}

const DEMO_STEPS: DemoStepDef[] = [
  {step: 1, title: 'Import Authoritative Inventory', detail: 'Add cmp-fra-a02-02-imported into FRA-01-R02 U14-U15 with overlap validation.'},
  {step: 2, title: 'Render Front & Rear Rack Elevations', detail: 'Inspect 12 racks across Rooms A & B with SPOF & missing topology indicators.'},
  {step: 3, title: 'Receive Live Telemetry', detail: 'Run Redfish, Prometheus DCGM & SNMPv3 collectors with provenance tags.'},
  {step: 4, title: 'Identify Stale Source', detail: 'Verify pdu-fra-a04-b SNMPv3 metric flagged STALE while BMS stays FRESH.'},
  {step: 5, title: 'Detect Temperature Exception', detail: 'Inject 38.4°C Redfish inlet spike on gpu-fra-b09-01 (FRA-01-R09).'},
  {step: 6, title: 'Open Correlated Incident', detail: 'Auto-open SEV-1 incident with timestamped telemetry evidence.'},
  {step: 7, title: 'Identify Affected Workloads', detail: 'Correlate Mistral Lattice SAS Slurm job (non-migratable RDMA ranks).'},
  {step: 8, title: 'Approve Maintenance Change', detail: 'Create and MFA-approve Change Request for FRA-01-R09 RDHx check.'},
  {step: 9, title: 'Drain Simulated Node', detail: 'Execute Proposed → Validated → Approved → Executing → Completed drain.'},
  {step: 10, title: 'Reserve Replacement Capacity', detail: 'Lock 8U / 10.2 kW capacity in FRA-01-R10 (2N verified).'},
  {step: 11, title: 'Verify Recovery', detail: 'Restore 24.1°C nominal inlet temp and resolve the incident.'},
  {step: 12, title: 'Produce Multilingual Report', detail: 'Open Reports & export localized EN/FR/DE operational summary.'},
];

@Component({
  selector: 'app-demo-walkthrough-drawer',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (ops.demoDrawerOpen()) {
      <div
        class="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-[2px]"
        role="dialog"
        aria-modal="true"
        aria-label="12-Step Operational Demonstration"
      >
        <div
          class="flex h-full w-full max-w-lg flex-col border-l border-slate-200 bg-white text-slate-900 shadow-2xl dark:border-slate-800 dark:bg-[#0D1320] dark:text-slate-100"
        >
          <div class="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
            <div>
              <h2 class="text-base font-semibold tracking-tight">{{ i18n.t().overview.demoBannerTitle }}</h2>
              <p class="text-xs text-slate-500 dark:text-slate-400">
                FRA-01 (Rooms A & B, 12 Racks) · End-to-End Verification
              </p>
            </div>
            <button
              type="button"
              (click)="ops.demoDrawerOpen.set(false)"
              class="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Close Walkthrough"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <div class="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3 dark:border-slate-800 dark:bg-[#11192B]">
            <span class="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
              Completed: {{ ops.snapshot()?.demoState?.completedSteps?.length ?? 0 }} / 12
            </span>
            <button
              type="button"
              (click)="ops.resetDemo()"
              class="inline-flex items-center gap-1 rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-200/60 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <mat-icon class="!text-[15px] !w-4 !h-4">restart_alt</mat-icon>
              <span>Reset Baseline</span>
            </button>
          </div>

          <div class="flex-1 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800">
            @for (item of steps; track item.step) {
              @let done = isCompleted(item.step);
              <div class="flex items-start justify-between gap-4 px-6 py-3.5">
                <div class="space-y-1">
                  <div class="flex items-center gap-2">
                    <span class="font-mono text-xs font-semibold text-blue-600 dark:text-cyan-400">
                      {{ item.step < 10 ? '0' + item.step : item.step }}.
                    </span>
                    <span class="text-sm font-medium">{{ item.title }}</span>
                    @if (done) {
                      <mat-icon class="!text-[16px] !w-4 !h-4 text-emerald-500">check_circle</mat-icon>
                    }
                  </div>
                  <p class="text-xs text-slate-500 dark:text-slate-400">{{ item.detail }}</p>
                </div>
                <button
                  type="button"
                  [disabled]="busyStep() === item.step"
                  (click)="runStep(item.step)"
                  class="shrink-0 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors"
                  [class]="done
                    ? 'border border-slate-300 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800'
                    : 'bg-blue-600 text-white hover:bg-blue-700'"
                >
                  {{ done ? 'Inspect' : 'Run Step' }}
                </button>
              </div>
            }
          </div>
        </div>
      </div>
    }
  `,
})
export class DemoWalkthroughDrawer {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
  private readonly router = inject(Router);

  readonly steps = DEMO_STEPS;
  readonly busyStep = signal<number | null>(null);

  isCompleted(step: number): boolean {
    return this.ops.snapshot()?.demoState?.completedSteps?.includes(step) ?? false;
  }

  async runStep(step: number): Promise<void> {
    this.busyStep.set(step);
    try {
      const res = await this.ops.executeDemoStep(step);
      await this.router.navigateByUrl(res.routeHint);
    } finally {
      this.busyStep.set(null);
    }
  }
}
