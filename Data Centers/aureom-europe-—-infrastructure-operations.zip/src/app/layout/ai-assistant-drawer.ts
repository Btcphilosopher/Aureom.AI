import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {I18nService} from '../core/services/i18n.service';
import {AiResponsePayload, OpsStateService} from '../core/services/ops-state.service';

@Component({
  selector: 'app-ai-assistant-drawer',
  imports: [MatIconModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (ops.aiDrawerOpen()) {
      <div
        class="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-[2px]"
        role="dialog"
        aria-modal="true"
        aria-label="Gemini 4.0 Operations Assistant"
      >
        <div
          class="flex h-full w-full max-w-xl flex-col border-l border-slate-200 bg-white text-slate-900 shadow-2xl dark:border-slate-800 dark:bg-[#0D1320] dark:text-slate-100"
        >
          <div class="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
            <div>
              <h2 class="text-base font-semibold tracking-tight">{{ i18n.t().ai.title }}</h2>
              <p class="text-xs text-slate-500 dark:text-slate-400">{{ i18n.t().ai.subtitle }}</p>
            </div>
            <button
              type="button"
              (click)="ops.aiDrawerOpen.set(false)"
              class="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Close AI Assistant"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <div class="border-b border-amber-500/20 bg-amber-500/5 px-6 py-2.5 text-xs text-amber-700 dark:text-amber-300">
            <span class="font-medium">Read-Only Advisory Boundary:</span>
            AI cannot power off hosts, alter networks, delete storage, disable alarms, or modify RBAC permissions.
          </div>

          <div class="flex flex-wrap gap-2 border-b border-slate-200 px-6 py-3 dark:border-slate-800">
            <button
              type="button"
              (click)="runPreset('summarize_incidents', 'Summarize active incidents, affected workloads, and root-cause evidence.')"
              class="rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {{ i18n.t().ai.quickSummarize }}
            </button>
            <button
              type="button"
              (click)="runPreset('explain_capacity', 'Explain current power/cooling capacity constraints and any dual-feed SPOF warnings.')"
              class="rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {{ i18n.t().ai.quickCapacity }}
            </button>
            <button
              type="button"
              (click)="runPreset('identify_missing_inventory', 'Identify missing topology fields, stale telemetry metrics, and unreviewed discovery drifts.')"
              class="rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {{ i18n.t().ai.quickMissing }}
            </button>
            <button
              type="button"
              (click)="runPreset('draft_change_request', 'Draft a structured maintenance change request for rack FRA-01-R09 including verification and rollback steps.')"
              class="rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {{ i18n.t().ai.quickChange }}
            </button>
          </div>

          <div class="flex-1 overflow-y-auto px-6 py-5 space-y-4">
            @if (loading()) {
              <div class="flex items-center gap-3 rounded-lg border border-slate-200 p-4 text-sm text-slate-600 dark:border-slate-800 dark:text-slate-300">
                <mat-icon class="animate-spin text-blue-500">sync</mat-icon>
                <span>Querying Gemini 4.0 (gemini-4-hydrogen) with deterministic snapshot...</span>
              </div>
            }

            @if (errorMsg(); as err) {
              <div class="rounded-lg border border-rose-500/30 bg-rose-500/10 p-4 text-sm text-rose-700 dark:text-rose-300">
                {{ err }}
              </div>
            }

            @if (response(); as res) {
              <div class="space-y-4">
                <div class="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span class="font-mono">{{ res.model }}</span>
                  <span class="font-mono tabular-nums">{{ i18n.formatDateTime(res.generatedAt) }}</span>
                </div>
                <div class="whitespace-pre-wrap rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm leading-relaxed text-slate-800 dark:border-slate-800 dark:bg-[#11192B] dark:text-slate-200">
                  {{ res.answer }}
                </div>

                @if (res.citations.length > 0) {
                  <div class="space-y-2">
                    <h3 class="text-xs font-semibold text-slate-600 dark:text-slate-400">
                      {{ i18n.t().ai.citations }}
                    </h3>
                    <div class="divide-y divide-slate-200 rounded-lg border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
                      @for (c of res.citations; track c.recordId + c.timestamp) {
                        <div class="flex items-center justify-between px-3 py-2 text-xs">
                          <div class="flex items-center gap-2">
                            <span class="font-mono font-semibold text-blue-600 dark:text-cyan-400">{{ c.recordId }}</span>
                            <span class="text-slate-500 dark:text-slate-400">{{ c.recordType }}</span>
                          </div>
                          <span class="font-mono tabular-nums text-slate-500 dark:text-slate-400">
                            {{ i18n.formatDateTime(c.timestamp) }}
                          </span>
                        </div>
                      }
                    </div>
                  </div>
                }
              </div>
            } @else if (!loading()) {
              <p class="text-sm text-slate-500 dark:text-slate-400">
                Select a diagnostic quick action above or enter an operational query below.
              </p>
            }
          </div>

          <form
            (submit)="onSubmit($event)"
            class="border-t border-slate-200 p-4 dark:border-slate-800"
          >
            <div class="flex gap-2">
              <input
                type="text"
                [formControl]="promptCtrl"
                [placeholder]="i18n.t().ai.placeholder"
                class="flex-1 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              />
              <button
                type="submit"
                [disabled]="loading()"
                class="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
              >
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">send</mat-icon>
                <span>{{ i18n.t().ai.send }}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    }
  `,
})
export class AiAssistantDrawer {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);

  readonly promptCtrl = new FormControl('', {nonNullable: true});
  readonly loading = signal(false);
  readonly errorMsg = signal<string | null>(null);
  readonly response = signal<AiResponsePayload | null>(null);

  async runPreset(taskType: string, prompt: string): Promise<void> {
    this.promptCtrl.setValue(prompt);
    await this.query(prompt, taskType);
  }

  async onSubmit(event: Event): Promise<void> {
    event.preventDefault();
    const text = this.promptCtrl.value.trim();
    if (!text) return;
    await this.query(text, 'general_query');
  }

  private async query(prompt: string, taskType: string): Promise<void> {
    this.loading.set(true);
    this.errorMsg.set(null);
    try {
      const res = await this.ops.askAiAssistant(prompt, taskType);
      this.response.set(res);
    } catch (err: unknown) {
      const msg =
        (err as {error?: {error?: string}})?.error?.error ||
        (err instanceof Error ? err.message : 'Failed to reach Gemini 4.0 assistant.');
      this.errorMsg.set(msg);
    } finally {
      this.loading.set(false);
    }
  }
}
