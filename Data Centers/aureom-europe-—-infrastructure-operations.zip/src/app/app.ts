import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {LanguageCode, OperatorRole, TimezoneId} from '../shared/models';
import {I18nService} from './core/services/i18n.service';
import {OpsStateService} from './core/services/ops-state.service';
import {AiAssistantDrawer} from './layout/ai-assistant-drawer';
import {DemoWalkthroughDrawer} from './layout/demo-walkthrough-drawer';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    MatIconModule,
    AiAssistantDrawer,
    DemoWalkthroughDrawer,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    '(window:keydown)': 'onGlobalKeydown($event)',
  },
})
export class App implements OnInit {
  readonly ops = inject(OpsStateService);
  readonly i18n = inject(I18nService);
  readonly mobileNavOpen = signal(false);

  readonly roles: OperatorRole[] = [
    'SuperAdmin',
    'SiteOps-FRA',
    'SiteOps-PAR',
    'NetworkEng',
    'CapacityPlanner',
    'ReadOnlyAuditor',
    'TenantSupport',
  ];

  ngOnInit(): void {
    this.ops.init();
  }

  onGlobalKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      this.ops.aiDrawerOpen.set(false);
      this.ops.demoDrawerOpen.set(false);
      this.mobileNavOpen.set(false);
    }
  }

  onLanguageChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as LanguageCode;
    this.i18n.setLanguage(val);
  }

  onTimezoneChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as TimezoneId;
    this.i18n.setTimezone(val);
  }

  onSiteChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.ops.selectedSiteFilter.set(val);
  }

  onRoleChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as OperatorRole;
    this.ops.setRole(val);
  }

  onSearchInput(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.ops.globalSearch.set(val);
  }
}
