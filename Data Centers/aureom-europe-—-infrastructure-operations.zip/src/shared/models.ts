export type LanguageCode = 'en' | 'fr' | 'de';

export type TimezoneId =
  | 'UTC'
  | 'Europe/Paris'
  | 'Europe/Berlin'
  | 'Europe/Zurich';

export type ThemeMode = 'dark' | 'light';
export type DensityMode = 'compact' | 'standard';

export type DataSourceType =
  | 'Redfish'
  | 'SNMPv3'
  | 'Prometheus'
  | 'BMS-Modbus-RO'
  | 'Storage-API'
  | 'Slurm-REST'
  | 'Inventory-Verified'
  | 'Discovered-Pending';

export type QualityFlag =
  | 'FRESH'
  | 'DELAYED'
  | 'STALE'
  | 'COUNTER_RESET'
  | 'UNAVAILABLE';

export interface MetricObservation<T = number | string> {
  key: string;
  label: string;
  value: T;
  unit: string;
  source: DataSourceType;
  observedAt: string;
  receivedAt: string;
  quality: QualityFlag;
  ageSeconds?: number;
  rawCounter?: number;
  resetDetected?: boolean;
  boundary?: string;
}

export type LifecycleStatus =
  | 'Ordered'
  | 'Staged'
  | 'Active'
  | 'Maintenance'
  | 'Decommissioned';

export type EquipmentOperationalStatus =
  | 'Nominal'
  | 'Warning'
  | 'Critical'
  | 'Maintenance'
  | 'Offline';

export type EquipmentCategory =
  | 'compute'
  | 'gpu'
  | 'storage'
  | 'network'
  | 'pdu'
  | 'ups'
  | 'cooling';

export type DataLocationCode = 'EU-DE' | 'EU-FR';

export interface Site {
  id: string;
  code: string;
  name: string;
  city: string;
  country: string;
  dataLocation: DataLocationCode;
  tierClassification: string;
  gridOperator: string;
  buildings: Building[];
}

export interface Building {
  id: string;
  siteId: string;
  name: string;
  utilityFeeds: string[];
  rooms: Room[];
}

export interface Room {
  id: string;
  buildingId: string;
  siteId: string;
  name: string;
  coolingArchitecture: string;
  maxFloorLoadKgM2: number;
  designPowerKw: number;
  designCoolingKw: number;
  targetInletTempMinC: number;
  targetInletTempMaxC: number;
  racksCount: number;
}

export interface RackReservationSlot {
  reservationId: string;
  uStart: number;
  uEnd: number;
  owner: string;
  expiresAt: string;
}

export interface Rack {
  id: string;
  roomId: string;
  siteId: string;
  code: string;
  uTotal: number;
  maxWeightKg: number;
  powerBudgetKw: number;
  coolingBudgetKw: number;
  feedAPathId: string;
  feedBPathId: string;
  inletTempC: MetricObservation<number>;
  outletTempC: MetricObservation<number>;
  powerDrawKw: MetricObservation<number>;
  reservedSlots: RackReservationSlot[];
  missingTopologyFields: string[];
  dataLocation: DataLocationCode;
}

export interface DiscoveredObservation {
  id: string;
  field: string;
  approvedValue: string;
  discoveredValue: string;
  source: DataSourceType;
  discoveredAt: string;
  status: 'pending' | 'accepted' | 'rejected';
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface AssetHistoryEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  detail: string;
}

export interface NicInterface {
  name: string;
  speedGbps: number;
  switchId: string;
  switchPort: string;
  vlan: number;
  rxGbps: MetricObservation<number>;
  txGbps: MetricObservation<number>;
  crcErrors: MetricObservation<number>;
  rawCounterOctets?: number;
}

export interface GpuDeviceSpec {
  index: number;
  model: string;
  architecture: string;
  vramGiB: number;
  partitionSupport: string[]; // empty if passthrough-only
  activePartitionMode: string;
  driverVersion: string;
  runtimeVersion: string;
  utilisationPct: MetricObservation<number>;
  vramUsedGiB: MetricObservation<number>;
  tempC: MetricObservation<number>;
  powerW: MetricObservation<number>;
  eccErrors: MetricObservation<number>;
  schedulerAllocated: boolean;
  allocatedWorkloadId?: string;
}

export interface Equipment {
  id: string;
  siteId: string;
  roomId: string;
  rackId: string;
  name: string;
  category: EquipmentCategory;
  uStart: number;
  uEnd: number;
  face: 'front' | 'rear' | 'full';
  weightKg: number;
  ratedPowerW: number;
  manufacturer: string;
  model: string;
  serialNumber: string;
  assetTag: string;
  managementIp: string;
  managementNetwork: string;
  lifecycleStatus: LifecycleStatus;
  operationalStatus: EquipmentOperationalStatus;
  ownerTeam: string;
  warrantyExpiresAt: string;
  supportContract: string;
  psuAFeedId?: string;
  psuBFeedId?: string;
  cpuModel?: string;
  cpuCores?: number;
  ramGiB?: number;
  schedulerNodeState?: 'IDLE' | 'ALLOC' | 'MIXED' | 'DRAIN' | 'DOWN' | 'N/A';
  schedulerAllocatedCores?: number;
  schedulerAllocatedRamGiB?: number;
  gpus?: GpuDeviceSpec[];
  nics: NicInterface[];
  metrics: Record<string, MetricObservation<number | string>>;
  discoveredDiffs: DiscoveredObservation[];
  history: AssetHistoryEntry[];
}

export interface UpstreamPowerNode {
  id: string;
  siteId: string;
  name: string;
  type: 'utility' | 'transformer' | 'ups' | 'pdu';
  parentId?: string;
  ratedCapacityKva: number;
  measuredLoadKw: MetricObservation<number>;
  status: EquipmentOperationalStatus;
}

export interface TopologyDependencyWarning {
  rackId: string;
  rackCode: string;
  severity: 'warning' | 'info';
  type: 'shared_upstream_spof' | 'missing_topology';
  sharedNodeId?: string;
  sharedNodeName?: string;
  message: string;
  missingFields?: string[];
}

export interface CustomerWorkload {
  id: string;
  orgId: string;
  orgName: string;
  projectId: string;
  projectName: string;
  resourceType: 'slurm_job' | 'cloud_vm' | 'managed_storage';
  resourceName: string;
  equipmentId: string;
  rackId: string;
  siteId: string;
  dataLocation: DataLocationCode;
  customerStatus: 'RUNNING' | 'HEALTHY' | 'DEGRADED' | 'QUEUED' | 'STOPPED';
  migratable: boolean;
  migrationConstraintReason?: string;
  allocatedCores: number;
  allocatedRamGiB: number;
  allocatedGpus: number;
  networkSegment: string;
  monthlyBillingEur: number;
  isRestrictedTenant?: boolean;
}

export interface StoragePool {
  id: string;
  siteId: string;
  equipmentId: string;
  name: string;
  technology: 'Ceph-NVMe' | 'Lustre-HPC' | 'S3-Object' | 'NetApp-ONTAP';
  redundancyScheme: string;
  durabilityNote: string;
  rawTiB: number;
  usableTiB: number;
  reservedBufferTiB: number;
  allocatedTiB: number;
  consumedTiB: number;
  latencyMs: MetricObservation<number>;
  throughputGBps: MetricObservation<number>;
  replicationState: 'InSync' | 'Degraded' | 'AsyncLag' | 'LocalOnly';
  lastSnapshotAt: string;
  lastBackupAt: string;
  lastRestoreTestAt: string;
  lastRestoreTestStatus: 'Passed' | 'Failed' | 'Overdue';
  source: DataSourceType;
}

export interface NetworkVlan {
  id: string;
  siteId: string;
  vlanId: number;
  name: string;
  cidr: string;
  purpose: 'customer_tenant' | 'hpc_fabric' | 'storage_replication' | 'oob_management';
  projectName?: string;
}

export interface NetworkConfigProposal {
  id: string;
  switchId: string;
  switchName: string;
  siteId: string;
  title: string;
  author: string;
  createdAt: string;
  runningConfigSnippet: string;
  proposedConfigSnippet: string;
  requestStatus: 'Draft' | 'Proposed' | 'Approved' | 'Rejected';
  deviceAckStatus: 'NotSent' | 'Acknowledged' | 'RejectedByDevice';
  verifiedOperationalState: 'Unverified' | 'VerifiedMatch' | 'DriftDetected';
  writeMode: 'MockAdapter' | 'LiveNetconf';
}

export interface PuePeriodWindow {
  siteId: string;
  windowLabel: string;
  boundaryDescription: string;
  startAt: string;
  endAt: string;
  totalFacilityEnergyKwh: number;
  itEquipmentEnergyKwh: number;
  computedPue: number;
  source: DataSourceType;
  quality: QualityFlag;
  methodologyNote: string;
}

export interface CapacityEvaluationInput {
  siteId: string;
  roomId?: string;
  requiredU: number;
  weightKg: number;
  powerKw: number;
  coolingKw: number;
  cpuCores: number;
  ramGiB: number;
  gpuCount: number;
  storageTiB: number;
  networkPorts: number;
  resilience: 'N' | 'N+1' | '2N';
  dataLocation: DataLocationCode;
}

export interface RackFeasibilityResult {
  rackId: string;
  rackCode: string;
  roomId: string;
  siteId: string;
  feasible: boolean;
  availableU: number;
  remainingWeightKg: number;
  remainingPowerKw: number;
  remainingCoolingKw: number;
  hasIndependentDualFeed: boolean;
  reasons: string[];
  suggestedUStart?: number;
}

export interface CapacityForecastPoint {
  monthLabel: string;
  powerUsedKw: number;
  powerLowerBoundKw: number;
  powerUpperBoundKw: number;
  powerCapacityKw: number;
  gpuUsedCount: number;
  gpuLowerBound: number;
  gpuUpperBound: number;
  gpuCapacityCount: number;
}

export interface CapacityReservation {
  id: string;
  siteId: string;
  roomId: string;
  rackId: string;
  rackCode: string;
  uStart: number;
  uEnd: number;
  powerKw: number;
  coolingKw: number;
  gpuCount: number;
  storageTiB: number;
  owner: string;
  purpose: string;
  dataLocation: DataLocationCode;
  status: 'Proposed' | 'Approved' | 'Active' | 'Released' | 'Expired';
  createdAt: string;
  expiresAt: string;
}

export type IncidentSeverity = 'SEV-1' | 'SEV-2' | 'SEV-3' | 'SEV-4';
export type IncidentStatus = 'Open' | 'Investigating' | 'Mitigated' | 'Resolved';

export interface IncidentEvidence {
  id: string;
  timestamp: string;
  source: DataSourceType;
  assetId: string;
  metricKey: string;
  summary: string;
}

export interface IncidentTimelineEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  note: string;
}

export interface Incident {
  id: string;
  dedupKey: string;
  siteId: string;
  title: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  occurrenceCount: number;
  firstSeenAt: string;
  lastSeenAt: string;
  affectedAssetIds: string[];
  affectedWorkloadIds: string[];
  correlatedSymptoms: string[];
  assignee: string;
  evidence: IncidentEvidence[];
  timeline: IncidentTimelineEntry[];
  resolutionNote?: string;
  postIncidentReview?: string;
}

export interface ChangeRequest {
  id: string;
  siteId: string;
  title: string;
  risk: 'Low' | 'Medium' | 'High';
  status: 'Proposed' | 'Approved' | 'Scheduled' | 'Completed' | 'Failed' | 'RolledBack';
  requestedBy: string;
  approvedBy?: string;
  targetAssetIds: string[];
  linkedIncidentId?: string;
  maintenanceWindowStart: string;
  maintenanceWindowEnd: string;
  executionPlan: string[];
  verificationChecks: string[];
  rollbackPlan: string[];
  createdAt: string;
}

export type AutomationState =
  | 'Proposed'
  | 'Validated'
  | 'Approved'
  | 'Scheduled'
  | 'Executing'
  | 'Verified'
  | 'Completed'
  | 'Failed';

export type AutomationActionType =
  | 'schedule_maintenance'
  | 'drain_node'
  | 'request_workload_migration'
  | 'run_diagnostic'
  | 'restart_non_critical_service'
  | 'controlled_device_action';

export interface AutomationWorkflow {
  id: string;
  idempotencyKey: string;
  siteId: string;
  targetEquipmentId: string;
  targetEquipmentName: string;
  actionType: AutomationActionType;
  state: AutomationState;
  requestedBy: string;
  approvedBy?: string;
  changeRequestId?: string;
  createdAt: string;
  updatedAt: string;
  preflightChecks: {
    name: string;
    passed: boolean;
    detail: string;
  }[];
  compensatingAction: string;
  failureReason?: string;
  simulateFailure?: boolean;
}

export type OperatorRole =
  | 'SuperAdmin'
  | 'SiteOps-FRA'
  | 'SiteOps-PAR'
  | 'NetworkEng'
  | 'CapacityPlanner'
  | 'ReadOnlyAuditor'
  | 'TenantSupport';

export interface SecuritySession {
  operatorId: string;
  operatorName: string;
  role: OperatorRole;
  siteScopes: string[];
  mfaVerified: boolean;
  ssoIssuer: string;
  sessionExpiresAt: string;
  canApproveChanges: boolean;
  canExecuteAutomation: boolean;
  canViewRestrictedTenantDetails: boolean;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  actor: string;
  role: OperatorRole;
  siteId: string;
  action: string;
  targetId: string;
  outcome: 'Allowed' | 'Denied';
  detail: string;
}

export interface SustainabilityCostSummary {
  siteId: string;
  periodLabel: string;
  isSyntheticData: boolean;
  electricityRateEurPerKwh: number;
  measuredItEnergyKwh: number;
  estimatedFacilityOverheadKwh: number;
  monthlyElectricityCostEur: number;
  monthlyDepreciationEur: number;
  monthlyMaintenanceEur: number;
  monthlyNetworkTransferEur: number;
  totalAllocatedCostEur: number;
  totalCustomerBilledEur: number;
  locationBasedGridFactorGCo2PerKwh: number;
  locationBasedSource: string;
  locationBasedEmissionsTonnes: number;
  marketBasedFactorGCo2PerKwh: number;
  marketBasedSource: string;
  marketBasedEmissionsTonnes: number;
  methodologyNote: string;
}

export interface TelemetryIngestionSample {
  equipmentId: string;
  metricKey: string;
  label: string;
  value: number;
  unit: string;
  source: DataSourceType;
  observedAt: string;
  rawCounter?: number;
  counterMax?: number;
}

export interface DemoWalkthroughState {
  completedSteps: number[];
  currentStep: number;
  lastStepMessage?: string;
}

export interface PlatformStateSnapshot {
  generatedAt: string;
  staleThresholdSeconds: number;
  sites: Site[];
  rooms: Room[];
  racks: Rack[];
  equipment: Equipment[];
  upstreamPowerNodes: UpstreamPowerNode[];
  topologyWarnings: TopologyDependencyWarning[];
  workloads: CustomerWorkload[];
  storagePools: StoragePool[];
  vlans: NetworkVlan[];
  networkProposals: NetworkConfigProposal[];
  pueWindows: PuePeriodWindow[];
  reservations: CapacityReservation[];
  incidents: Incident[];
  changes: ChangeRequest[];
  workflows: AutomationWorkflow[];
  auditLog: AuditEntry[];
  sustainabilityCosts: SustainabilityCostSummary[];
  forecasts: Record<string, CapacityForecastPoint[]>;
  demoState: DemoWalkthroughState;
}
