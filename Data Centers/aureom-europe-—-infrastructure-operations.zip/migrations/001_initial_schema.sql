-- Aureom Europe — Infrastructure Operations PostgreSQL Reference Migration
-- Matches the domain aggregates persisted by AureomOperationsStore

CREATE TABLE IF NOT EXISTS sites (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  country TEXT NOT NULL,
  data_location TEXT NOT NULL CHECK (data_location IN ('EU-DE', 'EU-FR')),
  tier_classification TEXT NOT NULL,
  grid_operator TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES sites(id),
  building_id TEXT NOT NULL,
  name TEXT NOT NULL,
  cooling_architecture TEXT NOT NULL,
  max_floor_load_kg_m2 NUMERIC NOT NULL,
  design_power_kw NUMERIC NOT NULL,
  design_cooling_kw NUMERIC NOT NULL
);

CREATE TABLE IF NOT EXISTS racks (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  site_id TEXT NOT NULL REFERENCES sites(id),
  code TEXT NOT NULL UNIQUE,
  u_total INTEGER NOT NULL CHECK (u_total > 0),
  max_weight_kg NUMERIC NOT NULL,
  power_budget_kw NUMERIC NOT NULL,
  cooling_budget_kw NUMERIC NOT NULL,
  feed_a_path_id TEXT NOT NULL,
  feed_b_path_id TEXT NOT NULL,
  data_location TEXT NOT NULL CHECK (data_location IN ('EU-DE', 'EU-FR'))
);

CREATE TABLE IF NOT EXISTS equipment (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES sites(id),
  room_id TEXT NOT NULL REFERENCES rooms(id),
  rack_id TEXT NOT NULL REFERENCES racks(id),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  u_start INTEGER NOT NULL,
  u_end INTEGER NOT NULL,
  face TEXT NOT NULL CHECK (face IN ('front', 'rear', 'full')),
  weight_kg NUMERIC NOT NULL,
  rated_power_w NUMERIC NOT NULL,
  manufacturer TEXT NOT NULL,
  model TEXT NOT NULL,
  serial_number TEXT NOT NULL UNIQUE,
  asset_tag TEXT NOT NULL UNIQUE,
  management_ip INET NOT NULL,
  management_network TEXT NOT NULL,
  lifecycle_status TEXT NOT NULL,
  operational_status TEXT NOT NULL,
  owner_team TEXT NOT NULL,
  CHECK (u_start >= 1 AND u_end >= u_start)
);

CREATE TABLE IF NOT EXISTS telemetry_observations (
  id BIGSERIAL PRIMARY KEY,
  equipment_id TEXT NOT NULL REFERENCES equipment(id),
  metric_key TEXT NOT NULL,
  numeric_value DOUBLE PRECISION NOT NULL,
  unit TEXT NOT NULL,
  source TEXT NOT NULL,
  observed_at TIMESTAMPTZ NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  quality TEXT NOT NULL,
  raw_counter BIGINT,
  UNIQUE (equipment_id, metric_key, observed_at)
);

CREATE TABLE IF NOT EXISTS capacity_reservations (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES sites(id),
  rack_id TEXT NOT NULL REFERENCES racks(id),
  u_start INTEGER NOT NULL,
  u_end INTEGER NOT NULL,
  power_kw NUMERIC NOT NULL,
  cooling_kw NUMERIC NOT NULL,
  gpu_count INTEGER NOT NULL DEFAULT 0,
  storage_tib NUMERIC NOT NULL DEFAULT 0,
  owner TEXT NOT NULL,
  data_location TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS incidents (
  id TEXT PRIMARY KEY,
  dedup_key TEXT NOT NULL,
  site_id TEXT NOT NULL REFERENCES sites(id),
  title TEXT NOT NULL,
  severity TEXT NOT NULL,
  status TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL DEFAULT 1,
  first_seen_at TIMESTAMPTZ NOT NULL,
  last_seen_at TIMESTAMPTZ NOT NULL,
  assignee TEXT NOT NULL,
  resolution_note TEXT
);

CREATE TABLE IF NOT EXISTS change_requests (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES sites(id),
  title TEXT NOT NULL,
  risk TEXT NOT NULL,
  status TEXT NOT NULL,
  requested_by TEXT NOT NULL,
  approved_by TEXT,
  maintenance_window_start TIMESTAMPTZ NOT NULL,
  maintenance_window_end TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS automation_workflows (
  id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  site_id TEXT NOT NULL REFERENCES sites(id),
  target_equipment_id TEXT NOT NULL REFERENCES equipment(id),
  action_type TEXT NOT NULL,
  state TEXT NOT NULL,
  requested_by TEXT NOT NULL,
  approved_by TEXT,
  compensating_action TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  actor TEXT NOT NULL,
  role TEXT NOT NULL,
  site_id TEXT NOT NULL,
  action TEXT NOT NULL,
  target_id TEXT NOT NULL,
  outcome TEXT NOT NULL,
  detail TEXT NOT NULL
);
