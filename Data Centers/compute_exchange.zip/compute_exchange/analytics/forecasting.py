"""
Price forecasting (section 57) -- optional, modular, and NEVER represented
as a guaranteed future price. Ships with rolling-average / EWMA / linear
trend methods; `method` is a strategy hook so ARIMA, Prophet or gradient
boosting can be dropped in later without changing the public interface.
"""
from dataclasses import dataclass
from typing import List, Literal, Sequence

import numpy as np

ForecastMethod = Literal["rolling_average", "ewma", "linear_trend"]


@dataclass
class ForecastPoint:
    step: int
    value: float


@dataclass
class ForecastResult:
    method: ForecastMethod
    horizon: int
    points: List[ForecastPoint]
    disclaimer: str = (
        "This is a statistical projection based on historical observations, "
        "not a guaranteed future price. COMPUTE.EXCHANGE makes no warranty "
        "that actual prices will follow this trend."
    )


class ForecastEngine:
    def rolling_average(self, series: Sequence[float], window: int = 7) -> float:
        if not series:
            return 0.0
        w = min(window, len(series))
        return float(np.mean(series[-w:]))

    def ewma(self, series: Sequence[float], alpha: float = 0.3) -> float:
        if not series:
            return 0.0
        value = series[0]
        for x in series[1:]:
            value = alpha * x + (1 - alpha) * value
        return float(value)

    def linear_trend_slope(self, series: Sequence[float]) -> float:
        if len(series) < 2:
            return 0.0
        x = np.arange(len(series))
        slope, _intercept = np.polyfit(x, series, 1)
        return float(slope)

    def forecast(
        self, series: Sequence[float], horizon: int = 7, method: ForecastMethod = "ewma",
    ) -> ForecastResult:
        series = list(series)
        points: List[ForecastPoint] = []

        if not series:
            return ForecastResult(method=method, horizon=horizon, points=points)

        if method == "rolling_average":
            base = self.rolling_average(series)
            for step in range(1, horizon + 1):
                points.append(ForecastPoint(step=step, value=round(base, 4)))

        elif method == "linear_trend":
            slope = self.linear_trend_slope(series)
            last = series[-1]
            for step in range(1, horizon + 1):
                points.append(ForecastPoint(step=step, value=round(last + slope * step, 4)))

        else:  # ewma default
            level = self.ewma(series)
            for step in range(1, horizon + 1):
                points.append(ForecastPoint(step=step, value=round(level, 4)))

        return ForecastResult(method=method, horizon=horizon, points=points)
