"""Price spread (section 23) and distribution (section 24) statistics."""
from typing import List, Sequence

import numpy as np

from models.market import PriceSpreadStats


class PriceSpreadEngine:
    @staticmethod
    def compute(gpu_model: str, prices: Sequence[float], unit: str = "USD/GPU-hour") -> PriceSpreadStats:
        if not prices:
            return PriceSpreadStats(
                gpu_model=gpu_model, minimum=0, p10=0, p25=0, median=0, mean=0,
                p75=0, p90=0, maximum=0, std_dev=0, coefficient_of_variation=0,
                sample_size=0, unit=unit,
            )
        arr = np.array(prices, dtype=float)
        mean = float(np.mean(arr))
        std = float(np.std(arr))
        cv = round(std / mean, 4) if mean else 0.0

        return PriceSpreadStats(
            gpu_model=gpu_model,
            minimum=round(float(np.min(arr)), 4),
            p10=round(float(np.percentile(arr, 10)), 4),
            p25=round(float(np.percentile(arr, 25)), 4),
            median=round(float(np.median(arr)), 4),
            mean=round(mean, 4),
            p75=round(float(np.percentile(arr, 75)), 4),
            p90=round(float(np.percentile(arr, 90)), 4),
            maximum=round(float(np.max(arr)), 4),
            std_dev=round(std, 4),
            coefficient_of_variation=cv,
            sample_size=len(arr),
            unit=unit,
        )
