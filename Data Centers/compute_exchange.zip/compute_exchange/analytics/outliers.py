"""
Outlier detection (section 25).

Flags offers as UNUSUALLY_CHEAP, UNUSUALLY_EXPENSIVE, STALE, MISSING or
SUSPICIOUS -- always with a stated reason, and never an automatic fraud
determination. A cheap offer is a PRICE_OUTLIER to be reviewed, not a
"scam" -- humans (or downstream systems) decide what to do with the flag.
"""
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import List, Optional, Sequence

import numpy as np

from config.settings import get_settings
from models.offer import ComputeOffer


class OutlierType(str, Enum):
    UNUSUALLY_CHEAP = "UNUSUALLY_CHEAP"
    UNUSUALLY_EXPENSIVE = "UNUSUALLY_EXPENSIVE"
    STALE = "STALE"
    MISSING = "MISSING"
    SUSPICIOUS = "SUSPICIOUS"


@dataclass
class OutlierFlag:
    offer_id: str
    outlier_type: OutlierType
    reason: str
    z_score: Optional[float] = None


class OutlierDetector:
    def __init__(self, z_threshold: float = 2.0):
        self.z_threshold = z_threshold
        self.settings = get_settings()

    def detect(self, offers: Sequence[ComputeOffer], gpu_hour_prices: Sequence[float]) -> List[OutlierFlag]:
        flags: List[OutlierFlag] = []
        if not offers:
            return flags

        arr = np.array(gpu_hour_prices, dtype=float)
        mean = float(np.mean(arr)) if len(arr) else 0.0
        std = float(np.std(arr)) if len(arr) else 0.0

        now = datetime.utcnow()

        for offer, price in zip(offers, gpu_hour_prices):
            age_seconds = (now - offer.observed_at).total_seconds()

            if std > 0:
                z = (price - mean) / std
                if z <= -self.z_threshold:
                    flags.append(OutlierFlag(
                        offer_id=offer.offer_id, outlier_type=OutlierType.UNUSUALLY_CHEAP,
                        reason=f"{abs(z):.1f} standard deviations below the market mean "
                               f"(${price:.4f} vs mean ${mean:.4f}). Not automatically flagged as fraudulent.",
                        z_score=round(z, 3),
                    ))
                elif z >= self.z_threshold:
                    flags.append(OutlierFlag(
                        offer_id=offer.offer_id, outlier_type=OutlierType.UNUSUALLY_EXPENSIVE,
                        reason=f"{z:.1f} standard deviations above the market mean "
                               f"(${price:.4f} vs mean ${mean:.4f}).",
                        z_score=round(z, 3),
                    ))

            if age_seconds > self.settings.freshness_stale_seconds:
                flags.append(OutlierFlag(
                    offer_id=offer.offer_id, outlier_type=OutlierType.STALE,
                    reason=f"Last observed {age_seconds / 3600:.1f} hours ago -- "
                           f"exceeds the {self.settings.freshness_stale_seconds / 3600:.0f}h staleness threshold.",
                ))

            missing_fields = [
                name for name, value in (
                    ("cpu_cores", offer.cpu_cores), ("ram_gb", offer.ram_gb),
                    ("storage_gb", offer.storage_gb), ("network_gbps", offer.network_gbps),
                ) if value is None
            ]
            if missing_fields:
                flags.append(OutlierFlag(
                    offer_id=offer.offer_id, outlier_type=OutlierType.MISSING,
                    reason=f"Missing fields: {', '.join(missing_fields)}.",
                ))

            if offer.price == 0 and offer.gpu_count > 0:
                flags.append(OutlierFlag(
                    offer_id=offer.offer_id, outlier_type=OutlierType.SUSPICIOUS,
                    reason="Zero price on a GPU-bearing offer -- verify against source before trusting.",
                ))

        return flags
