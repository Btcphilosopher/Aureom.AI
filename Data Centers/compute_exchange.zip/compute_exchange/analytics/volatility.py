"""Price change engine (section 20) and market volatility (section 58)."""
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class PricePoint:
    timestamp: datetime
    price: float


@dataclass
class PriceChangeResult:
    current_price: float
    absolute_change_7d: Optional[float]
    percentage_change_7d: Optional[float]
    absolute_change_30d: Optional[float]
    percentage_change_30d: Optional[float]


class PriceChangeEngine:
    @staticmethod
    def _price_at_or_before(history: Sequence[PricePoint], cutoff: datetime) -> Optional[float]:
        candidates = [p for p in history if p.timestamp <= cutoff]
        if not candidates:
            return None
        return max(candidates, key=lambda p: p.timestamp).price

    def calculate(self, history: Sequence[PricePoint]) -> PriceChangeResult:
        if not history:
            return PriceChangeResult(0.0, None, None, None, None)

        ordered = sorted(history, key=lambda p: p.timestamp)
        current = ordered[-1].price
        now = ordered[-1].timestamp

        price_7d = self._price_at_or_before(ordered, now - timedelta(days=7))
        price_30d = self._price_at_or_before(ordered, now - timedelta(days=30))

        def _changes(old: Optional[float]) -> Tuple[Optional[float], Optional[float]]:
            if old is None or old == 0:
                return None, None
            abs_change = round(current - old, 4)
            pct_change = round((current - old) / old * 100, 2)
            return abs_change, pct_change

        abs7, pct7 = _changes(price_7d)
        abs30, pct30 = _changes(price_30d)

        return PriceChangeResult(
            current_price=current,
            absolute_change_7d=abs7, percentage_change_7d=pct7,
            absolute_change_30d=abs30, percentage_change_30d=pct30,
        )


@dataclass
class VolatilityResult:
    window_days: int
    volatility_pct: float
    classification: str  # LOW | MEDIUM | HIGH


class VolatilityEngine:
    """
    Volatility is computed as the standard deviation of period-over-period
    percentage returns within the window, expressed as a percentage --
    this is a descriptive statistic, not a guarantee of future behaviour.
    """

    LOW_THRESHOLD = 5.0
    HIGH_THRESHOLD = 15.0

    def calculate(self, history: Sequence[PricePoint], window_days: int) -> VolatilityResult:
        if len(history) < 2:
            return VolatilityResult(window_days=window_days, volatility_pct=0.0, classification="LOW")

        ordered = sorted(history, key=lambda p: p.timestamp)
        cutoff = ordered[-1].timestamp - timedelta(days=window_days)
        window = [p.price for p in ordered if p.timestamp >= cutoff]
        if len(window) < 2:
            return VolatilityResult(window_days=window_days, volatility_pct=0.0, classification="LOW")

        arr = np.array(window, dtype=float)
        returns = np.diff(arr) / arr[:-1]
        vol_pct = round(float(np.std(returns)) * 100, 2)

        if vol_pct < self.LOW_THRESHOLD:
            classification = "LOW"
        elif vol_pct < self.HIGH_THRESHOLD:
            classification = "MEDIUM"
        else:
            classification = "HIGH"

        return VolatilityResult(window_days=window_days, volatility_pct=vol_pct, classification=classification)
