"""
Market index (section 21) and regional index (section 22).

Methodology (documented, never hidden): the COMPUTE PRICE INDEX for a GPU
model is the GPU-count-weighted median of USD/GPU-hour across all
AVAILABLE, ON_DEMAND offers for that GPU. Weighting by gpu_count
approximates weighting by traded volume, since larger offers move more
capacity through the market.
"""
from typing import List, Optional, Sequence, Tuple

import numpy as np

from models.market import MarketIndexPoint, RegionalIndexPoint


def _weighted_median(values: Sequence[float], weights: Sequence[float]) -> float:
    if not values:
        return 0.0
    order = np.argsort(values)
    v = np.array(values)[order]
    w = np.array(weights)[order]
    cum_weight = np.cumsum(w)
    cutoff = cum_weight[-1] / 2.0
    idx = np.searchsorted(cum_weight, cutoff)
    idx = min(idx, len(v) - 1)
    return float(v[idx])


class MarketIndexEngine:
    METHODOLOGY = "GPU-count-weighted median of USD/GPU-hour across AVAILABLE, ON_DEMAND offers"

    def compute(
        self,
        gpu_model: str,
        gpu_hour_prices: Sequence[float],
        weights: Sequence[float],
        change_7d_pct: Optional[float] = None,
        change_30d_pct: Optional[float] = None,
    ) -> MarketIndexPoint:
        index_value = round(_weighted_median(gpu_hour_prices, weights), 4) if gpu_hour_prices else 0.0
        return MarketIndexPoint(
            gpu_model=gpu_model,
            index_value=index_value,
            sample_size=len(gpu_hour_prices),
            methodology=self.METHODOLOGY,
            change_7d_pct=change_7d_pct,
            change_30d_pct=change_30d_pct,
        )


class RegionalIndexEngine:
    def compute(
        self,
        region: str,
        gpu_model: str,
        regional_prices: Sequence[float],
        regional_weights: Sequence[float],
        global_index_value: float,
    ) -> RegionalIndexPoint:
        regional_value = round(_weighted_median(regional_prices, regional_weights), 4) if regional_prices else 0.0
        premium_pct = (
            round((regional_value - global_index_value) / global_index_value * 100, 2)
            if global_index_value else 0.0
        )
        return RegionalIndexPoint(
            region=region,
            gpu_model=gpu_model,
            index_value=regional_value,
            global_index_value=round(global_index_value, 4),
            premium_pct=premium_pct,
            sample_size=len(regional_prices),
        )
