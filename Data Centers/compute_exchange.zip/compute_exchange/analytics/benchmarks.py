"""
Benchmark normalisation (section 15) -- performance-adjusted price metrics
that allow architectural comparison across GPU generations, not just raw
$/hour.
"""
from typing import Optional

from catalogue.gpu_catalogue import get_gpu
from models.gpu import GPU


def performance_adjusted_metrics(gpu: GPU, gpu_hour_price: float) -> dict:
    """
    Returns $/TFLOP, $/BF16-TFLOP-hour, $/FP8-TFLOP-hour, $/TB-VRAM-hour and
    $/GB/s-bandwidth-hour for one GPU at the given effective GPU-hour price.
    Any metric whose underlying spec is unavailable for this GPU is omitted
    (never fabricated).
    """
    metrics: dict[str, Optional[float]] = {
        "gpu_id": gpu.id,
        "gpu_hour_price": round(gpu_hour_price, 6),
    }

    if gpu.fp16_tflops:
        metrics["usd_per_fp16_tflop_hour"] = round(gpu_hour_price / gpu.fp16_tflops, 8)
    if gpu.bf16_tflops:
        metrics["usd_per_bf16_tflop_hour"] = round(gpu_hour_price / gpu.bf16_tflops, 8)
    if gpu.fp8_tflops:
        metrics["usd_per_fp8_tflop_hour"] = round(gpu_hour_price / gpu.fp8_tflops, 8)
    if gpu.fp4_tflops:
        metrics["usd_per_fp4_tflop_hour"] = round(gpu_hour_price / gpu.fp4_tflops, 8)
    if gpu.vram_gb:
        metrics["usd_per_tb_vram_hour"] = round(gpu_hour_price / (gpu.vram_gb / 1000.0), 6)
    if gpu.memory_bandwidth_gbps:
        metrics["usd_per_gbps_bandwidth_hour"] = round(gpu_hour_price / gpu.memory_bandwidth_gbps, 8)

    return metrics


def performance_adjusted_metrics_by_id(gpu_id: str, gpu_hour_price: float) -> Optional[dict]:
    gpu = get_gpu(gpu_id)
    if gpu is None:
        return None
    return performance_adjusted_metrics(gpu, gpu_hour_price)
