"""
Ranking engine (section 18), built on the Compute Value Score (section 16).

Weights are never hidden: every RankedOffer carries the full
ComputeScoreResult breakdown (price/performance/reliability/availability/
network/billing-flexibility) alongside the total, and the weights used to
produce it.
"""
from typing import Dict, List, Optional, Sequence

from pydantic import BaseModel

from catalogue.gpu_catalogue import get_gpu
from models.market import ComputeScoreResult, ComputeScoreWeights
from models.offer import AvailabilityState, ComputeOffer
from models.pricing import BillingModel

_AVAILABILITY_SCORE = {
    AvailabilityState.AVAILABLE: 100.0,
    AvailabilityState.LIMITED: 70.0,
    AvailabilityState.UNKNOWN: 50.0,
    AvailabilityState.WAITLIST: 35.0,
    AvailabilityState.OUT_OF_STOCK: 0.0,
}

_BILLING_FLEXIBILITY_SCORE = {
    BillingModel.SPOT: 100.0,
    BillingModel.SERVERLESS: 95.0,
    BillingModel.ON_DEMAND: 90.0,
    BillingModel.PREEMPTIBLE: 85.0,
    BillingModel.AUCTION: 70.0,
    BillingModel.DEDICATED: 60.0,
    BillingModel.NEGOTIATED: 55.0,
    BillingModel.RESERVED: 50.0,
    BillingModel.COMMITTED: 40.0,
}


def _network_score(offer: ComputeOffer) -> float:
    from models.offer import NetworkFabric
    return {
        NetworkFabric.INFINIBAND: 100.0,
        NetworkFabric.ROCE: 85.0,
        NetworkFabric.ETHERNET: 55.0,
        NetworkFabric.UNKNOWN: 40.0,
    }.get(offer.network_fabric, 40.0)


def _min_max_score(value: float, lo: float, hi: float, invert: bool = False) -> float:
    if hi <= lo:
        return 50.0
    score = (value - lo) / (hi - lo) * 100.0
    score = max(0.0, min(100.0, score))
    return 100.0 - score if invert else score


def score_offer(
    offer: ComputeOffer,
    gpu_hour_price: float,
    weights: ComputeScoreWeights,
    price_range: tuple[float, float],
    performance_range: tuple[float, float],
    require_multi_node: bool = False,
) -> ComputeScoreResult:
    w = weights.normalised()

    price_score = _min_max_score(gpu_hour_price, *price_range, invert=True)

    gpu = get_gpu(offer.gpu_model) if offer.gpu_model else None
    perf_value = gpu.bf16_tflops if gpu and gpu.bf16_tflops else 0.0
    performance_score = _min_max_score(perf_value, *performance_range) if perf_value else 50.0

    reliability_score = offer.reliability_score if offer.reliability_score is not None else 70.0
    availability_score = _AVAILABILITY_SCORE.get(offer.availability, 50.0)
    network_score = _network_score(offer)
    if require_multi_node and not offer.multi_node_capable:
        network_score = 0.0
    billing_flexibility_score = _BILLING_FLEXIBILITY_SCORE.get(offer.billing_model, 50.0)

    total = (
        price_score * w.price_weight
        + performance_score * w.performance_weight
        + reliability_score * w.reliability_weight
        + availability_score * w.availability_weight
        + network_score * w.network_weight
        + billing_flexibility_score * w.billing_flexibility_weight
    )

    return ComputeScoreResult(
        offer_id=offer.offer_id,
        price_score=round(price_score, 2),
        performance_score=round(performance_score, 2),
        reliability_score=round(reliability_score, 2),
        availability_score=round(availability_score, 2),
        network_score=round(network_score, 2),
        billing_flexibility_score=round(billing_flexibility_score, 2),
        total_score=round(total, 2),
        weights_used=w,
    )


class RankedOffer(BaseModel):
    rank: int
    offer_id: str
    provider_id: str
    gpu_model: Optional[str]
    gpu_count: int
    region: str
    price: float
    gpu_hour_price: Optional[float]
    effective_price: Optional[float] = None
    availability: AvailabilityState
    score: ComputeScoreResult


class RankingEngine:
    def __init__(self, weights: Optional[ComputeScoreWeights] = None):
        self.weights = weights or ComputeScoreWeights()

    def rank(
        self,
        offers: Sequence[ComputeOffer],
        effective_prices: Optional[Dict[str, float]] = None,
        require_multi_node: bool = False,
    ) -> List[RankedOffer]:
        if not offers:
            return []

        gpu_hour_prices = {o.offer_id: (o.gpu_hour_price or o.price) for o in offers}
        prices = list(gpu_hour_prices.values())
        price_range = (min(prices), max(prices))

        perf_values = []
        for o in offers:
            gpu = get_gpu(o.gpu_model) if o.gpu_model else None
            if gpu and gpu.bf16_tflops:
                perf_values.append(gpu.bf16_tflops)
        performance_range = (min(perf_values), max(perf_values)) if perf_values else (0.0, 1.0)

        scored: List[RankedOffer] = []
        for offer in offers:
            gpu_hour_price = gpu_hour_prices[offer.offer_id]
            score = score_offer(
                offer, gpu_hour_price, self.weights, price_range, performance_range,
                require_multi_node=require_multi_node,
            )
            effective_price = (effective_prices or {}).get(offer.offer_id)
            scored.append(RankedOffer(
                rank=0, offer_id=offer.offer_id, provider_id=offer.provider_id,
                gpu_model=offer.gpu_model, gpu_count=offer.gpu_count, region=offer.region,
                price=offer.price, gpu_hour_price=offer.gpu_hour_price,
                effective_price=effective_price, availability=offer.availability, score=score,
            ))

        scored.sort(key=lambda r: r.score.total_score, reverse=True)
        for i, r in enumerate(scored, start=1):
            r.rank = i
        return scored

    def cheapest(self, offers: Sequence[ComputeOffer]) -> List[RankedOffer]:
        ranked = [
            RankedOffer(
                rank=0, offer_id=o.offer_id, provider_id=o.provider_id, gpu_model=o.gpu_model,
                gpu_count=o.gpu_count, region=o.region, price=o.price, gpu_hour_price=o.gpu_hour_price,
                availability=o.availability,
                score=score_offer(o, o.gpu_hour_price or o.price, self.weights, (0, 1), (0, 1)),
            )
            for o in offers
        ]
        ranked.sort(key=lambda r: (r.gpu_hour_price if r.gpu_hour_price is not None else r.price))
        for i, r in enumerate(ranked, start=1):
            r.rank = i
        return ranked
