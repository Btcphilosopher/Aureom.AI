"""
/ws/market -- live market ticker feed (sections 39/40).

Every message is tagged `"simulated": true` while the market-tick loop is
running on the synthetic simulator (section 54) -- a Kotlin/web front end
should render a SIMULATION badge whenever that flag is set.
"""
import asyncio
import json
import logging
from typing import List, Sequence

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from simulation.market import MarketEvent

logger = logging.getLogger(__name__)
router = APIRouter()


class ConnectionManager:
    def __init__(self):
        self._connections: List[WebSocket] = []
        self._lock = asyncio.Lock()

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        async with self._lock:
            self._connections.append(ws)

    async def disconnect(self, ws: WebSocket) -> None:
        async with self._lock:
            if ws in self._connections:
                self._connections.remove(ws)

    async def broadcast(self, message: dict) -> None:
        payload = json.dumps(message, default=str)
        async with self._lock:
            dead = []
            for ws in self._connections:
                try:
                    await ws.send_text(payload)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self._connections.remove(ws)


manager = ConnectionManager()


def _event_to_message(event: MarketEvent) -> dict:
    return {
        "type": event.event_type,
        "title": event.title,
        "offer_id": event.offer_id,
        "provider_id": event.provider_id,
        "gpu_model": event.gpu_model,
        "region": event.region,
        "detail": event.detail,
        "timestamp": event.timestamp.isoformat(),
        "simulated": event.simulated,
    }


async def broadcast_events(events: Sequence[MarketEvent]) -> None:
    for event in events:
        await manager.broadcast(_event_to_message(event))


@router.websocket("/ws/market")
async def market_feed(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        await websocket.send_text(json.dumps({
            "type": "CONNECTED",
            "title": "[COMPUTE.EXCHANGE] MARKET FEED CONNECTED",
            "simulated": True,
        }))
        while True:
            # We don't expect client -> server messages, but reading keeps
            # the connection alive and lets us detect disconnects promptly.
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(websocket)
