"""
Market scenarios (section 55/56) -- named perturbations the simulator can
apply on top of the baseline synthetic market. Each scenario returns a
per-tick (price_multiplier_delta, inventory_factor, event_names) effect;
the simulator applies it and emits MARKET EVENT records.
"""
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class MarketScenario(str, Enum):
    NORMAL_MARKET = "NORMAL_MARKET"
    GPU_SHORTAGE = "GPU_SHORTAGE"
    DEMAND_SPIKE = "DEMAND_SPIKE"
    OVERSUPPLY = "OVERSUPPLY"
    POWER_PRICE_SHOCK = "POWER_PRICE_SHOCK"
    NEW_GPU_RELEASE = "NEW_GPU_RELEASE"


@dataclass
class ScenarioEffect:
    price_drift_pct: float          # applied per tick, e.g. +0.004 == +0.4%/tick
    price_volatility_pct: float     # random noise applied per tick
    inventory_drift_pct: float      # applied to free inventory per tick
    affected_gpu_models: Optional[List[str]] = None  # None == all GPUs
    affected_regions: Optional[List[str]] = None      # None == all regions
    event_name: str = ""


SCENARIOS = {
    MarketScenario.NORMAL_MARKET: ScenarioEffect(
        price_drift_pct=0.0, price_volatility_pct=0.006, inventory_drift_pct=0.0,
        event_name="MARKET STABLE",
    ),
    MarketScenario.GPU_SHORTAGE: ScenarioEffect(
        price_drift_pct=0.012, price_volatility_pct=0.015, inventory_drift_pct=-0.06,
        affected_gpu_models=["h100-sxm-80gb", "h200-sxm-141gb", "b200-192gb"],
        event_name="GPU SHORTAGE",
    ),
    MarketScenario.DEMAND_SPIKE: ScenarioEffect(
        price_drift_pct=0.02, price_volatility_pct=0.02, inventory_drift_pct=-0.10,
        event_name="DEMAND SPIKE",
    ),
    MarketScenario.OVERSUPPLY: ScenarioEffect(
        price_drift_pct=-0.015, price_volatility_pct=0.01, inventory_drift_pct=0.08,
        event_name="INVENTORY SURGE",
    ),
    MarketScenario.POWER_PRICE_SHOCK: ScenarioEffect(
        price_drift_pct=0.008, price_volatility_pct=0.012, inventory_drift_pct=-0.01,
        event_name="POWER PRICE SHOCK",
    ),
    MarketScenario.NEW_GPU_RELEASE: ScenarioEffect(
        price_drift_pct=-0.03, price_volatility_pct=0.02, inventory_drift_pct=0.0,
        affected_gpu_models=["a100-sxm-80gb", "h100-sxm-80gb"],
        event_name="NEW GPU RELEASE -- PRICE PRESSURE ON PRIOR GENERATION",
    ),
}
