"""
Synthetic provider roster and offer generation.

This is the data backbone of the market simulator (section 55) and of the
demo `connectors/providers/*` adapters (section 30) that run before real,
credentialed connectors are wired up. Every offer produced here is stamped
`pricing_type=SIMULATED` and a `source` starting with `SIMULATED:` -- it is
never presented to a user as a live provider quote (section 54).
"""
import random
from dataclasses import dataclass, field
from typing import List, Optional

from catalogue.gpu_catalogue import all_gpus
from models.offer import (
    AvailabilityState, BillingUnit, ComputeOffer, NetworkFabric, StorageType,
)
from models.pricing import BillingModel, Currency
from models.provider import Provider, ProviderCategory

REGIONS = {
    "UK": {"name": "United Kingdom", "country": "GB", "continent": "Europe", "lat": 51.5, "lon": -0.1},
    "EU": {"name": "European Union", "country": "DE", "continent": "Europe", "lat": 50.1, "lon": 8.7},
    "US-EAST": {"name": "US East", "country": "US", "continent": "North America", "lat": 39.0, "lon": -77.5},
    "US-WEST": {"name": "US West", "country": "US", "continent": "North America", "lat": 37.4, "lon": -122.1},
    "ASIA": {"name": "Asia Pacific", "country": "SG", "continent": "Asia", "lat": 1.35, "lon": 103.8},
    "MIDDLE-EAST": {"name": "Middle East", "country": "AE", "continent": "Asia", "lat": 25.2, "lon": 55.3},
}


@dataclass
class ProviderProfile:
    provider_id: str
    name: str
    category: ProviderCategory
    regions: List[str]
    gpu_models: List[str]
    price_tier: float          # multiplier applied to a reference GPU-hour price; <1.0 = cheaper
    enterprise: bool = False
    marketplace: bool = False
    reliability_baseline: float = 90.0
    data_quality_baseline: float = 90.0
    sla: Optional[str] = None
    spot_discount_pct: float = 0.55     # spot ~ this fraction of on-demand
    reserved_discount_pct: float = 0.70  # reserved ~ this fraction of on-demand
    network_fabric: NetworkFabric = NetworkFabric.ETHERNET
    max_cluster_size: int = 8


# Reference on-demand USD/GPU-hour by GPU id, used as the anchor price that
# each provider's `price_tier` multiplies. These are illustrative midpoints,
# not a live feed -- see docs on PricingType.SIMULATED.
_REFERENCE_GPU_HOUR = {
    "h100-sxm-80gb": 2.75, "h200-sxm-141gb": 3.60, "b100-192gb": 4.40,
    "b200-192gb": 5.10, "b300-288gb": 6.20, "a100-sxm-80gb": 1.35,
    "a40-48gb": 0.55, "l40-48gb": 0.75, "l40s-48gb": 0.95,
    "rtx4090-24gb": 0.45, "rtx5090-32gb": 0.85, "rtxpro6000-96gb": 1.55,
    "mi300x-192gb": 2.10, "mi325x-256gb": 2.60, "mi350-288gb": 3.40,
    "v100-32gb": 0.40, "t4-16gb": 0.18, "a10-24gb": 0.30, "a6000-48gb": 0.50, "l4-24gb": 0.35,
}

_ALL_GPU_IDS = [g.id for g in all_gpus()]


def _profiles() -> List[ProviderProfile]:
    hyperscalers = [
        ProviderProfile("aws", "Amazon Web Services", ProviderCategory.HYPERSCALER,
                         ["UK", "EU", "US-EAST", "US-WEST", "ASIA"], _ALL_GPU_IDS[:10],
                         price_tier=1.35, enterprise=True, reliability_baseline=98,
                         data_quality_baseline=97, sla="99.99%", network_fabric=NetworkFabric.ETHERNET),
        ProviderProfile("azure", "Microsoft Azure", ProviderCategory.HYPERSCALER,
                         ["UK", "EU", "US-EAST", "US-WEST", "ASIA"], _ALL_GPU_IDS[:9],
                         price_tier=1.32, enterprise=True, reliability_baseline=98,
                         data_quality_baseline=96, sla="99.95%"),
        ProviderProfile("gcp", "Google Cloud Platform", ProviderCategory.HYPERSCALER,
                         ["EU", "US-EAST", "US-WEST", "ASIA"], _ALL_GPU_IDS[:8],
                         price_tier=1.30, enterprise=True, reliability_baseline=97,
                         data_quality_baseline=97, sla="99.95%"),
        ProviderProfile("oracle-oci", "Oracle Cloud Infrastructure", ProviderCategory.HYPERSCALER,
                         ["UK", "EU", "US-EAST"], ["h100-sxm-80gb", "a100-sxm-80gb", "a10-24gb"],
                         price_tier=1.10, enterprise=True, reliability_baseline=95, sla="99.9%"),
        ProviderProfile("ibm-cloud", "IBM Cloud", ProviderCategory.HYPERSCALER,
                         ["EU", "US-EAST"], ["a100-sxm-80gb", "v100-32gb", "t4-16gb"],
                         price_tier=1.15, enterprise=True, reliability_baseline=94, sla="99.9%"),
    ]

    neoclouds = [
        ProviderProfile("coreweave", "CoreWeave", ProviderCategory.NEOCLOUD,
                         ["US-EAST", "US-WEST", "EU"], _ALL_GPU_IDS[:12],
                         price_tier=0.78, enterprise=True, reliability_baseline=93,
                         network_fabric=NetworkFabric.INFINIBAND, max_cluster_size=1024),
        ProviderProfile("lambda-labs", "Lambda Labs", ProviderCategory.NEOCLOUD,
                         ["US-EAST", "US-WEST"], _ALL_GPU_IDS[:11],
                         price_tier=0.82, reliability_baseline=91,
                         network_fabric=NetworkFabric.INFINIBAND, max_cluster_size=512),
        ProviderProfile("crusoe", "Crusoe Energy", ProviderCategory.NEOCLOUD,
                         ["US-EAST", "EU"], ["h100-sxm-80gb", "a100-sxm-80gb", "l40s-48gb"],
                         price_tier=0.80, reliability_baseline=90, network_fabric=NetworkFabric.INFINIBAND),
        ProviderProfile("nebius", "Nebius AI Cloud", ProviderCategory.NEOCLOUD,
                         ["EU", "US-EAST"], ["h100-sxm-80gb", "h200-sxm-141gb", "l40s-48gb"],
                         price_tier=0.83, reliability_baseline=90, network_fabric=NetworkFabric.INFINIBAND),
        ProviderProfile("together-ai", "Together AI", ProviderCategory.NEOCLOUD,
                         ["US-EAST", "EU"], ["h100-sxm-80gb", "a100-sxm-80gb"],
                         price_tier=0.85, reliability_baseline=89),
        ProviderProfile("voltage-park", "Voltage Park", ProviderCategory.NEOCLOUD,
                         ["US-EAST", "US-WEST"], ["h100-sxm-80gb", "a100-sxm-80gb"],
                         price_tier=0.79, reliability_baseline=88, network_fabric=NetworkFabric.INFINIBAND),
        ProviderProfile("fluidstack", "FluidStack", ProviderCategory.NEOCLOUD,
                         ["UK", "EU", "US-EAST"], ["h100-sxm-80gb", "a100-sxm-80gb", "l40-48gb"],
                         price_tier=0.81, reliability_baseline=88),
        ProviderProfile("hydra-host", "Hydra Host", ProviderCategory.NEOCLOUD,
                         ["EU", "ASIA"], ["h100-sxm-80gb", "a100-sxm-80gb"],
                         price_tier=0.84, reliability_baseline=86),
    ]

    marketplaces = [
        ProviderProfile("vast-ai", "Vast.ai", ProviderCategory.GPU_MARKETPLACE,
                         ["US-EAST", "US-WEST", "EU", "ASIA"], _ALL_GPU_IDS,
                         price_tier=0.55, marketplace=True, reliability_baseline=72,
                         spot_discount_pct=0.40),
        ProviderProfile("runpod", "RunPod", ProviderCategory.GPU_MARKETPLACE,
                         ["US-EAST", "US-WEST", "EU", "ASIA"], _ALL_GPU_IDS[:15],
                         price_tier=0.62, marketplace=True, reliability_baseline=80,
                         spot_discount_pct=0.45),
        ProviderProfile("salad-cloud", "SaladCloud", ProviderCategory.GPU_MARKETPLACE,
                         ["US-EAST", "EU"], ["rtx4090-24gb", "rtx5090-32gb", "a10-24gb", "t4-16gb", "l4-24gb"],
                         price_tier=0.40, marketplace=True, reliability_baseline=68,
                         spot_discount_pct=0.35),
        ProviderProfile("io-net", "io.net", ProviderCategory.GPU_MARKETPLACE,
                         ["US-EAST", "EU", "ASIA"], _ALL_GPU_IDS[:14],
                         price_tier=0.58, marketplace=True, reliability_baseline=70),
    ]

    bare_metal = [
        ProviderProfile("hetzner", "Hetzner", ProviderCategory.BARE_METAL,
                         ["EU"], ["rtx4090-24gb", "l40s-48gb", "a100-sxm-80gb"],
                         price_tier=0.60, reliability_baseline=92, sla="99.9%"),
        ProviderProfile("ovhcloud", "OVHcloud", ProviderCategory.BARE_METAL,
                         ["UK", "EU"], ["a100-sxm-80gb", "l40-48gb", "t4-16gb"],
                         price_tier=0.68, reliability_baseline=90, sla="99.9%"),
        ProviderProfile("leaseweb", "Leaseweb", ProviderCategory.BARE_METAL,
                         ["EU", "US-EAST"], ["a10-24gb", "t4-16gb", "a6000-48gb"],
                         price_tier=0.70, reliability_baseline=89),
        ProviderProfile("latitude-sh", "Latitude.sh", ProviderCategory.BARE_METAL,
                         ["US-EAST", "EU"], ["a100-sxm-80gb", "l40s-48gb"],
                         price_tier=0.72, reliability_baseline=87),
        ProviderProfile("scaleway", "Scaleway", ProviderCategory.BARE_METAL,
                         ["EU"], ["h100-sxm-80gb", "l40s-48gb", "l40-48gb"],
                         price_tier=0.75, reliability_baseline=88),
    ]

    serverless = [
        ProviderProfile("replicate", "Replicate", ProviderCategory.SERVERLESS,
                         ["US-EAST", "EU"], ["a100-sxm-80gb", "l40s-48gb", "t4-16gb"],
                         price_tier=0.95, reliability_baseline=90),
        ProviderProfile("baseten", "Baseten", ProviderCategory.SERVERLESS,
                         ["US-EAST", "EU"], ["a100-sxm-80gb", "h100-sxm-80gb", "l40-48gb"],
                         price_tier=0.98, reliability_baseline=90),
        ProviderProfile("modal", "Modal", ProviderCategory.SERVERLESS,
                         ["US-EAST", "EU"], ["h100-sxm-80gb", "a100-sxm-80gb", "t4-16gb"],
                         price_tier=1.00, reliability_baseline=91),
        ProviderProfile("fireworks-ai", "Fireworks AI", ProviderCategory.SERVERLESS,
                         ["US-EAST"], ["h100-sxm-80gb", "a100-sxm-80gb"],
                         price_tier=0.97, reliability_baseline=90),
    ]

    hpc = [
        ProviderProfile("cudo-compute", "Cudo Compute", ProviderCategory.HPC,
                         ["UK", "EU", "ASIA"], ["h100-sxm-80gb", "a100-sxm-80gb", "mi300x-192gb"],
                         price_tier=0.74, reliability_baseline=86, network_fabric=NetworkFabric.INFINIBAND),
        ProviderProfile("e-infra-uk", "UK e-Infrastructure Consortium", ProviderCategory.HPC,
                         ["UK"], ["a100-sxm-80gb", "v100-32gb"],
                         price_tier=0.65, enterprise=True, reliability_baseline=90,
                         network_fabric=NetworkFabric.INFINIBAND),
        ProviderProfile("genesis-cloud", "Genesis Cloud", ProviderCategory.HPC,
                         ["EU"], ["h100-sxm-80gb", "rtx4090-24gb"],
                         price_tier=0.77, reliability_baseline=85),
    ]

    edge = [
        ProviderProfile("edge-gpu-net", "EdgeGPU Network", ProviderCategory.EDGE,
                         ["UK", "EU", "US-EAST", "ASIA"], ["t4-16gb", "a10-24gb", "l40-48gb"],
                         price_tier=0.66, marketplace=True, reliability_baseline=76),
        ProviderProfile("zeta-edge", "Zeta Edge Compute", ProviderCategory.EDGE,
                         ["MIDDLE-EAST", "ASIA"], ["a10-24gb", "t4-16gb"],
                         price_tier=0.60, marketplace=True, reliability_baseline=74),
    ]

    return hyperscalers + neoclouds + marketplaces + bare_metal + serverless + hpc + edge


PROVIDER_PROFILES: List[ProviderProfile] = _profiles()


def profile_to_provider(profile: ProviderProfile) -> Provider:
    return Provider(
        provider_id=profile.provider_id,
        name=profile.name,
        category=profile.category,
        website=f"https://{profile.provider_id.replace('_', '-')}.example",
        regions=profile.regions,
        billing_models=["ON_DEMAND", "SPOT", "RESERVED"] if not profile.marketplace else ["ON_DEMAND", "SPOT"],
        gpu_models=profile.gpu_models,
        enterprise=profile.enterprise,
        marketplace=profile.marketplace,
        sla=profile.sla,
        reliability_score=profile.reliability_baseline,
        data_quality_score=profile.data_quality_baseline,
    )


def _cluster_sizes(max_size: int) -> List[int]:
    ladder = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
    return [n for n in ladder if n <= max_size]


def generate_offers_for_provider(
    profile: ProviderProfile, rng: random.Random, simulated: bool = True,
) -> List[ComputeOffer]:
    """
    Generate a realistic, non-uniform spread of offers for one provider
    across its supported GPUs, regions and cluster sizes.
    """
    offers: List[ComputeOffer] = []
    source_tag = f"SIMULATED:{profile.provider_id}" if simulated else profile.provider_id

    for gpu_id in profile.gpu_models:
        reference = _REFERENCE_GPU_HOUR.get(gpu_id)
        if reference is None:
            continue
        for region in profile.regions:
            region_premium = {
                "UK": 1.05, "EU": 1.00, "US-EAST": 0.98, "US-WEST": 1.02,
                "ASIA": 1.08, "MIDDLE-EAST": 1.12,
            }.get(region, 1.0)

            # Idiosyncratic noise per provider/gpu/region so prices aren't identical.
            noise = rng.uniform(0.92, 1.10)
            on_demand_gpu_hour = round(reference * profile.price_tier * region_premium * noise, 4)
            spot_gpu_hour = round(on_demand_gpu_hour * profile.spot_discount_pct * rng.uniform(0.95, 1.05), 4)
            reserved_gpu_hour = round(on_demand_gpu_hour * profile.reserved_discount_pct, 4)

            availability_roll = rng.random()
            if availability_roll < 0.65:
                availability = AvailabilityState.AVAILABLE
            elif availability_roll < 0.82:
                availability = AvailabilityState.LIMITED
            elif availability_roll < 0.93:
                availability = AvailabilityState.WAITLIST
            else:
                availability = AvailabilityState.OUT_OF_STOCK

            for cluster_size in _cluster_sizes(profile.max_cluster_size):
                if cluster_size > 8 and not profile.enterprise and profile.category not in (
                    ProviderCategory.NEOCLOUD, ProviderCategory.HPC,
                ):
                    continue  # small marketplaces rarely offer huge clusters
                if rng.random() < 0.5 and cluster_size not in (1, 8, 64):
                    continue  # thin out the ladder so we don't explode row counts

                cluster_premium = 1.0
                if cluster_size >= 16:
                    cluster_premium = 1.0 + min(0.15, 0.01 * (cluster_size ** 0.5))

                instance_price = round(on_demand_gpu_hour * cluster_size * cluster_premium, 4)
                offer_id = f"{profile.provider_id}:{gpu_id}:{region}:{cluster_size}:od"

                offers.append(ComputeOffer(
                    offer_id=offer_id,
                    provider_id=profile.provider_id,
                    instance_id=f"{gpu_id}-x{cluster_size}",
                    gpu_model=gpu_id,
                    gpu_count=cluster_size,
                    cpu_model="AMD EPYC 9654" if cluster_size >= 8 else "Intel Xeon Platinum 8480+",
                    cpu_cores=int(16 * cluster_size ** 0.5) or 8,
                    ram_gb=float(128 * max(cluster_size, 1)),
                    storage_gb=float(2000 * max(cluster_size, 1)),
                    storage_type=StorageType.NVME,
                    network_gbps=400.0 if cluster_size >= 8 else 100.0,
                    network_fabric=profile.network_fabric if cluster_size > 1 else NetworkFabric.ETHERNET,
                    multi_node_capable=cluster_size >= 8 and profile.network_fabric != NetworkFabric.ETHERNET,
                    region=region,
                    country=REGIONS[region]["country"],
                    city=None,
                    latitude=REGIONS[region]["lat"],
                    longitude=REGIONS[region]["lon"],
                    availability=availability,
                    billing_unit=BillingUnit.PER_HOUR,
                    billing_model=BillingModel.ON_DEMAND,
                    price=instance_price,
                    currency=Currency.USD,
                    spot_price=round(spot_gpu_hour * cluster_size, 4),
                    reserved_price=round(reserved_gpu_hour * cluster_size, 4),
                    on_demand_price=instance_price,
                    minimum_term="1 hour",
                    maximum_term=None,
                    egress_price_per_tb=0.0 if profile.category == ProviderCategory.NEOCLOUD else round(rng.uniform(20, 120), 2),
                    ingress_price_per_tb=0.0,
                    setup_fee=0.0 if not profile.enterprise else round(rng.uniform(0, 250), 2),
                    commitment=None,
                    reliability_score=round(min(99.9, max(50.0, rng.gauss(profile.reliability_baseline, 3))), 1),
                    source=source_tag,
                    source_url=f"https://{profile.provider_id}.example/pricing",
                    parser_version="sim-1.0.0",
                ))
    return offers
