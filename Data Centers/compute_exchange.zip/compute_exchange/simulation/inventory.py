"""
Synthetic inventory tracking -- how many GPUs of each model a provider has
free in a region right now. Used to derive AvailabilityState and to react
to scenarios like GPU_SHORTAGE realistically (falling inventory -> LIMITED
-> WAITLIST -> OUT_OF_STOCK).
"""
import random
from dataclasses import dataclass, field
from typing import Dict, Tuple

from models.offer import AvailabilityState


@dataclass
class InventoryLedger:
    # key: (provider_id, gpu_model, region) -> gpus free
    _capacity: Dict[Tuple[str, str, str], int] = field(default_factory=dict)
    _free: Dict[Tuple[str, str, str], int] = field(default_factory=dict)

    def seed(self, provider_id: str, gpu_model: str, region: str, capacity: int, rng: random.Random) -> None:
        key = (provider_id, gpu_model, region)
        self._capacity[key] = capacity
        self._free[key] = int(capacity * rng.uniform(0.15, 0.85))

    def adjust(self, provider_id: str, gpu_model: str, region: str, delta: int) -> None:
        key = (provider_id, gpu_model, region)
        cap = self._capacity.get(key, max(delta, 1))
        current = self._free.get(key, 0)
        self._free[key] = max(0, min(cap, current + delta))

    def scale_capacity(self, provider_id: str, gpu_model: str, region: str, factor: float) -> None:
        key = (provider_id, gpu_model, region)
        cap = self._capacity.get(key)
        if cap is None:
            return
        new_cap = max(1, int(cap * factor))
        self._capacity[key] = new_cap
        self._free[key] = min(self._free.get(key, 0), new_cap)

    def availability_state(self, provider_id: str, gpu_model: str, region: str) -> AvailabilityState:
        key = (provider_id, gpu_model, region)
        cap = self._capacity.get(key)
        free = self._free.get(key)
        if cap is None or free is None or cap == 0:
            return AvailabilityState.UNKNOWN
        ratio = free / cap
        if free == 0:
            return AvailabilityState.OUT_OF_STOCK
        if ratio < 0.05:
            return AvailabilityState.WAITLIST
        if ratio < 0.25:
            return AvailabilityState.LIMITED
        return AvailabilityState.AVAILABLE

    def total_inventory(self, gpu_model: str) -> int:
        return sum(cap for (pid, gpu, region), cap in self._capacity.items() if gpu == gpu_model)

    def free_inventory(self, gpu_model: str) -> int:
        return sum(free for (pid, gpu, region), free in self._free.items() if gpu == gpu_model)
