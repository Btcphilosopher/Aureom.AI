"""
Market simulator (section 55).

Generates a synthetic compute market -- providers, GPU inventory, prices,
demand, availability -- and evolves it tick over tick under a selectable
scenario. This lets the rest of the platform (analytics, ranking, alerts,
websocket feed) be built and tested before any real, credentialed
connector is wired up. Every offer/event produced here is clearly tagged
SIMULATED (section 54) -- it must never be presented as a live provider
quote.
"""
import random
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

from models.offer import AvailabilityState, ComputeOffer
from simulation.inventory import InventoryLedger
from simulation.providers import PROVIDER_PROFILES, generate_offers_for_provider, profile_to_provider
from simulation.scenarios import SCENARIOS, MarketScenario


@dataclass
class MarketEvent:
    event_type: str          # NEW_OFFER | PRICE_CHANGE | AVAILABILITY_CHANGE | PROVIDER_UPDATE | MARKET_INDEX_UPDATE
    title: str
    offer_id: Optional[str] = None
    provider_id: Optional[str] = None
    gpu_model: Optional[str] = None
    region: Optional[str] = None
    detail: Optional[dict] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    simulated: bool = True


class MarketSimulator:
    def __init__(self, seed: Optional[int] = None):
        self.rng = random.Random(seed)
        self.scenario = MarketScenario.NORMAL_MARKET
        self.inventory = InventoryLedger()
        self.offers: Dict[str, ComputeOffer] = {}
        self.tick_count = 0
        self._seed_market()

    # -- setup ---------------------------------------------------------
    def _seed_market(self) -> None:
        for profile in PROVIDER_PROFILES:
            offers = generate_offers_for_provider(profile, self.rng)
            for offer in offers:
                self.offers[offer.offer_id] = offer
                if offer.gpu_count == 1:
                    capacity = self.rng.randint(20, 400)
                    self.inventory.seed(profile.provider_id, offer.gpu_model, offer.region, capacity, self.rng)

    def providers(self):
        return [profile_to_provider(p) for p in PROVIDER_PROFILES]

    def set_scenario(self, scenario: MarketScenario) -> None:
        self.scenario = scenario

    def get_offers(self) -> List[ComputeOffer]:
        return list(self.offers.values())

    # -- evolution -------------------------------------------------------
    def tick(self) -> List[MarketEvent]:
        """
        Advance the market by one step, applying the active scenario's
        drift/volatility, and return the list of events produced -- these
        feed both the ingestion pipeline (so they land in price_history)
        and the /ws/market ticker.
        """
        self.tick_count += 1
        effect = SCENARIOS[self.scenario]
        events: List[MarketEvent] = []

        for offer in self.offers.values():
            if effect.affected_gpu_models and offer.gpu_model not in effect.affected_gpu_models:
                drift, vol = 0.0, 0.005
            else:
                drift, vol = effect.price_drift_pct, effect.price_volatility_pct

            noise = self.rng.gauss(0, vol)
            multiplier = 1.0 + drift + noise
            multiplier = max(0.5, min(1.5, multiplier))
            old_price = offer.price
            new_price = round(old_price * multiplier, 4)
            if new_price != old_price:
                pct_change = (new_price - old_price) / old_price if old_price else 0.0
                offer.price = new_price
                offer.observed_at = datetime.utcnow()
                if abs(pct_change) > 0.001:
                    events.append(MarketEvent(
                        event_type="PRICE_CHANGE",
                        title=f"{offer.gpu_model} @ {offer.provider_id} {'▲' if pct_change > 0 else '▼'} "
                              f"{abs(pct_change) * 100:.1f}%",
                        offer_id=offer.offer_id, provider_id=offer.provider_id,
                        gpu_model=offer.gpu_model, region=offer.region,
                        detail={"old_price": old_price, "new_price": new_price, "pct_change": pct_change},
                    ))

            if offer.gpu_count == 1:
                inv_delta_pct = effect.inventory_drift_pct + self.rng.gauss(0, 0.02)
                if effect.affected_regions and offer.region not in effect.affected_regions:
                    inv_delta_pct *= 0.2
                self.inventory.scale_capacity(offer.provider_id, offer.gpu_model, offer.region, 1.0 + inv_delta_pct)
                delta = int(self.rng.gauss(0, 3))
                self.inventory.adjust(offer.provider_id, offer.gpu_model, offer.region, delta)

                new_state = self.inventory.availability_state(offer.provider_id, offer.gpu_model, offer.region)
                if new_state != offer.availability:
                    old_state = offer.availability
                    offer.availability = new_state
                    events.append(MarketEvent(
                        event_type="AVAILABILITY_CHANGE",
                        title=f"{offer.gpu_model} @ {offer.provider_id} [{offer.region}] "
                              f"{old_state.value} -> {new_state.value}",
                        offer_id=offer.offer_id, provider_id=offer.provider_id,
                        gpu_model=offer.gpu_model, region=offer.region,
                        detail={"old_state": old_state.value, "new_state": new_state.value},
                    ))

        if effect.event_name and self.tick_count % 12 == 0:
            events.append(MarketEvent(
                event_type="MARKET_EVENT",
                title=effect.event_name,
                detail={"scenario": self.scenario.value},
            ))

        return events


# A process-wide singleton used by the API/websocket layer so all requests
# see the same evolving synthetic market.
_default_simulator: Optional[MarketSimulator] = None


def get_default_simulator() -> MarketSimulator:
    global _default_simulator
    if _default_simulator is None:
        _default_simulator = MarketSimulator(seed=42)
    return _default_simulator
