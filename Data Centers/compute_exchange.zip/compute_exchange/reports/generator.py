"""
Report generation (section 60).

Builds structured report payloads (dicts of sections/rows) and exports them
to JSON, CSV or PDF. Report *builders* below (daily market, weekly GPU
price, regional, provider comparison, workload cost, volatility) all
return the same {title, generated_at, sections: [...]} shape so the export
functions are report-agnostic -- add a new report type by writing one more
`build_*` method, no changes needed to `export_*`.
"""
import csv
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List

from sqlalchemy.orm import Session

from analytics.market_index import MarketIndexEngine, RegionalIndexEngine
from analytics.spreads import PriceSpreadEngine
from analytics.volatility import PriceChangeEngine, PricePoint, VolatilityEngine
from database.repositories.offer_repo import OfferRepository
from database.repositories.provider_repo import ProviderRepository
from simulation.providers import REGIONS


class ReportGenerator:
    def __init__(self, db: Session):
        self.db = db
        self.offer_repo = OfferRepository(db)
        self.provider_repo = ProviderRepository(db)

    # -- builders --------------------------------------------------------
    def daily_market_report(self) -> Dict[str, Any]:
        gpu_models = self.offer_repo.all_gpu_models_in_market()
        rows = []
        for gpu in sorted(gpu_models):
            offers = [self.offer_repo.to_domain(r) for r in self.offer_repo.list(
                gpu_model=gpu, availability="AVAILABLE", billing_model="ON_DEMAND", limit=2000)]
            prices = [o.gpu_hour_price for o in offers if o.gpu_hour_price]
            weights = [o.gpu_count for o in offers if o.gpu_hour_price]
            index = MarketIndexEngine().compute(gpu, prices, weights)
            spread = PriceSpreadEngine.compute(gpu, prices)
            rows.append({
                "gpu_model": gpu, "index_usd_gpu_hour": index.index_value,
                "sample_size": index.sample_size, "min": spread.minimum,
                "median": spread.median, "max": spread.maximum,
            })
        return self._wrap("Daily Compute Market Report", [{"name": "GPU Market Snapshot", "rows": rows}])

    def weekly_gpu_price_report(self) -> Dict[str, Any]:
        gpu_models = self.offer_repo.all_gpu_models_in_market()
        rows = []
        for gpu in sorted(gpu_models):
            history = self.offer_repo.price_history(gpu_model=gpu, limit=5000)
            points = [PricePoint(timestamp=r.timestamp, price=r.price) for r in history]
            change = PriceChangeEngine().calculate(points)
            rows.append({
                "gpu_model": gpu, "current_price": change.current_price,
                "change_7d_pct": change.percentage_change_7d, "change_30d_pct": change.percentage_change_30d,
            })
        return self._wrap("Weekly GPU Price Report", [{"name": "7D / 30D Price Change", "rows": rows}])

    def regional_compute_report(self, gpu_model: str) -> Dict[str, Any]:
        all_offers = [self.offer_repo.to_domain(r) for r in self.offer_repo.list(
            gpu_model=gpu_model, availability="AVAILABLE", billing_model="ON_DEMAND", limit=5000)]
        global_prices = [o.gpu_hour_price for o in all_offers if o.gpu_hour_price]
        global_weights = [o.gpu_count for o in all_offers if o.gpu_hour_price]
        global_index = MarketIndexEngine().compute(gpu_model, global_prices, global_weights).index_value

        rows = []
        engine = RegionalIndexEngine()
        for region in REGIONS:
            regional = [o for o in all_offers if o.region == region]
            prices = [o.gpu_hour_price for o in regional if o.gpu_hour_price]
            weights = [o.gpu_count for o in regional if o.gpu_hour_price]
            if not prices:
                continue
            point = engine.compute(region, gpu_model, prices, weights, global_index)
            rows.append(point.model_dump(mode="json"))
        return self._wrap(f"Regional Compute Report -- {gpu_model}", [{"name": "Regional Index", "rows": rows}])

    def provider_comparison_report(self) -> Dict[str, Any]:
        providers = self.provider_repo.list()
        rows = [
            {
                "provider_id": p.provider_id, "name": p.name, "category": p.category,
                "reliability_score": p.reliability_score, "data_quality_score": p.data_quality_score,
                "regions": ", ".join(p.regions or []),
            }
            for p in providers
        ]
        return self._wrap("Provider Comparison Report", [{"name": "Providers", "rows": rows}])

    def volatility_report(self) -> Dict[str, Any]:
        gpu_models = self.offer_repo.all_gpu_models_in_market()
        rows = []
        for gpu in sorted(gpu_models):
            history = self.offer_repo.price_history(gpu_model=gpu, limit=5000)
            points = [PricePoint(timestamp=r.timestamp, price=r.price) for r in history]
            vol_7d = VolatilityEngine().calculate(points, window_days=7)
            vol_30d = VolatilityEngine().calculate(points, window_days=30)
            rows.append({
                "gpu_model": gpu, "volatility_7d_pct": vol_7d.volatility_pct, "classification_7d": vol_7d.classification,
                "volatility_30d_pct": vol_30d.volatility_pct, "classification_30d": vol_30d.classification,
            })
        return self._wrap("Market Volatility Report", [{"name": "Volatility by GPU", "rows": rows}])

    @staticmethod
    def _wrap(title: str, sections: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {"title": title, "generated_at": datetime.utcnow().isoformat(), "sections": sections}

    # -- exporters ---------------------------------------------------------
    @staticmethod
    def export_json(report: Dict[str, Any], path: str) -> str:
        Path(path).write_text(json.dumps(report, indent=2, default=str))
        return path

    @staticmethod
    def export_csv(report: Dict[str, Any], path: str) -> str:
        rows: List[Dict[str, Any]] = []
        for section in report["sections"]:
            rows.extend(section["rows"])
        if not rows:
            Path(path).write_text("")
            return path
        with open(path, "w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        return path

    @staticmethod
    def export_pdf(report: Dict[str, Any], path: str) -> str:
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Table, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet

        styles = getSampleStyleSheet()
        doc = SimpleDocTemplate(path, pagesize=letter)
        story = [Paragraph(f"COMPUTE.EXCHANGE -- {report['title']}", styles["Title"]),
                 Paragraph(f"Generated {report['generated_at']}", styles["Normal"]), Spacer(1, 12)]

        for section in report["sections"]:
            story.append(Paragraph(section["name"], styles["Heading2"]))
            rows = section["rows"]
            if rows:
                header = list(rows[0].keys())
                table_data = [header] + [[str(r.get(h, "")) for h in header] for r in rows]
                story.append(Table(table_data, hAlign="LEFT"))
            story.append(Spacer(1, 12))

        doc.build(story)
        return path
