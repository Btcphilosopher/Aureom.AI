"""
Central application configuration.

All runtime configuration is sourced from environment variables (or a .env
file). Nothing here should hold provider credentials -- those belong to the
per-connector secret configuration described in connectors/base.py, and are
never surfaced through the API (see api/security.py).
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "COMPUTE.EXCHANGE"
    environment: str = "development"

    database_url: str = "sqlite:///./compute_exchange.db"
    base_currency: str = "USD"

    api_keys: str = "dev-key-local-only"
    rate_limit_per_minute: int = 120

    freshness_live_seconds: int = 60
    freshness_recent_seconds: int = 900
    freshness_stale_seconds: int = 86400

    simulation_enabled: bool = True
    simulation_tick_seconds: int = 5

    log_level: str = "INFO"

    @property
    def api_key_list(self) -> List[str]:
        return [k.strip() for k in self.api_keys.split(",") if k.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
