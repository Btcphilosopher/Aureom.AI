"""Generic CSV connector -- ingest a provider rate card published as CSV."""
import csv
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from connectors.base import ConnectorMetadata, ProviderConnector
from models.offer import AvailabilityState, ComputeOffer


class CSVConnector(ProviderConnector):
    """
    Reads a CSV file where each row is one offer. `row_mapper` converts a
    raw CSV row (dict[str, str]) into a ComputeOffer -- callers supply this
    since column names vary per provider; the connector itself is dumb by
    design (section 30: "do not hard-code the system around a handful of
    providers").
    """

    def __init__(
        self,
        provider_id: str,
        file_path: str,
        row_mapper: Callable[[Dict[str, str]], Optional[ComputeOffer]],
        source_url: Optional[str] = None,
        credentials: Optional[Dict[str, str]] = None,
    ):
        super().__init__(credentials)
        self.file_path = file_path
        self.row_mapper = row_mapper
        self.metadata = ConnectorMetadata(
            provider_id=provider_id, connector_type="csv", source_url=source_url or file_path,
        )

    async def fetch_offers(self) -> List[ComputeOffer]:
        offers: List[ComputeOffer] = []
        path = Path(self.file_path)
        if not path.exists():
            return offers
        with path.open(newline="", encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                offer = self.row_mapper(row)
                if offer is not None:
                    offers.append(offer)
        return offers

    async def fetch_availability(self) -> Dict[str, AvailabilityState]:
        offers = await self.fetch_offers()
        return {o.offer_id: o.availability for o in offers}

    async def fetch_metadata(self) -> Dict[str, Any]:
        return {
            "provider_id": self.metadata.provider_id,
            "connector_type": self.metadata.connector_type,
            "source_url": self.metadata.source_url,
        }
