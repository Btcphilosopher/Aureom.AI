"""
Connector interface (section 31).

New providers are added as plug-in adapters implementing this interface --
nothing in ingestion/, pricing/ or analytics/ needs to know a provider
exists ahead of time. A connector's only job is to produce canonical
ComputeOffer objects (or raw dicts a Parser can turn into one); everything
downstream (normalisation, validation, storage, analytics) is generic.

Provider credentials (API keys, tokens) belong on the connector instance
only -- see `credentials` below -- and must never be echoed back through
`fetch_metadata()` or logged. The API layer (api/security.py) enforces that
no endpoint can ever return a connector's raw credential.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from models.offer import AvailabilityState, ComputeOffer


@dataclass
class ConnectorMetadata:
    provider_id: str
    connector_type: str  # e.g. "rest", "csv", "json", "simulated"
    parser_version: str = "1.0.0"
    source_url: Optional[str] = None
    notes: Optional[str] = None


class ProviderConnector(ABC):
    """Base class every provider adapter must implement."""

    metadata: ConnectorMetadata

    def __init__(self, credentials: Optional[Dict[str, str]] = None):
        # Never logged, never returned by the API.
        self._credentials = credentials or {}

    @abstractmethod
    async def fetch_offers(self) -> List[ComputeOffer]:
        """Return the current canonical offers published by this provider."""
        raise NotImplementedError

    @abstractmethod
    async def fetch_availability(self) -> Dict[str, AvailabilityState]:
        """Return {offer_id: AvailabilityState} for offers this provider publishes."""
        raise NotImplementedError

    @abstractmethod
    async def fetch_metadata(self) -> Dict[str, Any]:
        """
        Return non-sensitive provider metadata (regions, SLA, gpu models
        supported, etc). MUST NOT include self._credentials.
        """
        raise NotImplementedError

    def redacted_config(self) -> Dict[str, str]:
        """Safe-to-log view of connector configuration (credentials masked)."""
        return {k: "****" for k in self._credentials}
