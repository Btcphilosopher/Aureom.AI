"""Generic authenticated REST connector -- for providers with a live pricing API."""
from typing import Any, Callable, Dict, List, Optional

import httpx

from connectors.base import ConnectorMetadata, ProviderConnector
from models.offer import AvailabilityState, ComputeOffer


class RESTConnector(ProviderConnector):
    """
    Calls a provider's HTTP API and maps the JSON response into canonical
    ComputeOffer objects via `record_mapper`. Credentials (API keys, bearer
    tokens) are injected as request headers and are never exposed outside
    this class -- fetch_metadata() only reports non-sensitive config.
    """

    def __init__(
        self,
        provider_id: str,
        base_url: str,
        offers_path: str,
        record_mapper: Callable[[Dict[str, Any]], Optional[ComputeOffer]],
        records_key: Optional[str] = None,
        credentials: Optional[Dict[str, str]] = None,
        auth_header: Optional[str] = "Authorization",
        timeout_seconds: float = 15.0,
    ):
        super().__init__(credentials)
        self.base_url = base_url.rstrip("/")
        self.offers_path = offers_path
        self.record_mapper = record_mapper
        self.records_key = records_key
        self.auth_header = auth_header
        self.timeout_seconds = timeout_seconds
        self.metadata = ConnectorMetadata(
            provider_id=provider_id, connector_type="rest",
            source_url=f"{self.base_url}{self.offers_path}",
        )

    def _headers(self) -> Dict[str, str]:
        headers = {"Accept": "application/json"}
        token = self._credentials.get("api_key") or self._credentials.get("token")
        if token and self.auth_header:
            headers[self.auth_header] = f"Bearer {token}"
        return headers

    async def _get(self, path: str) -> Any:
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            resp = await client.get(f"{self.base_url}{path}", headers=self._headers())
            resp.raise_for_status()
            return resp.json()

    async def fetch_offers(self) -> List[ComputeOffer]:
        data = await self._get(self.offers_path)
        records = data.get(self.records_key, []) if self.records_key else data
        offers: List[ComputeOffer] = []
        for record in records:
            offer = self.record_mapper(record)
            if offer is not None:
                offers.append(offer)
        return offers

    async def fetch_availability(self) -> Dict[str, AvailabilityState]:
        offers = await self.fetch_offers()
        return {o.offer_id: o.availability for o in offers}

    async def fetch_metadata(self) -> Dict[str, Any]:
        return {
            "provider_id": self.metadata.provider_id,
            "connector_type": self.metadata.connector_type,
            "source_url": self.metadata.source_url,
        }
