"""Vast.ai connector. See aws.py for the demo-vs-production note."""
from typing import Dict, Optional

from connectors.providers.generic import SimulatedProviderConnector


class VastConnector(SimulatedProviderConnector):
    def __init__(self, credentials: Optional[Dict[str, str]] = None, seed: Optional[int] = None):
        super().__init__(provider_id="vast-ai", credentials=credentials, seed=seed)
