"""GCP connector. See aws.py for the demo-vs-production note."""
from typing import Dict, Optional

from connectors.providers.generic import SimulatedProviderConnector


class GCPConnector(SimulatedProviderConnector):
    def __init__(self, credentials: Optional[Dict[str, str]] = None, seed: Optional[int] = None):
        super().__init__(provider_id="gcp", credentials=credentials, seed=seed)
