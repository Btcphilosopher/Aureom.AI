"""
Lambda Labs connector. See aws.py for the demo-vs-production note.

Named `lambda_labs.py` rather than `lambda.py` because `lambda` is a Python
reserved word and cannot be a module name.
"""
from typing import Dict, Optional

from connectors.providers.generic import SimulatedProviderConnector


class LambdaLabsConnector(SimulatedProviderConnector):
    def __init__(self, credentials: Optional[Dict[str, str]] = None, seed: Optional[int] = None):
        super().__init__(provider_id="lambda-labs", credentials=credentials, seed=seed)
