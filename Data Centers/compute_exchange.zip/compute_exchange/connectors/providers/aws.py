"""
AWS connector.

Demo mode (default): generates SIMULATED offers from the 'aws' profile.
Production mode: pass `credentials={"api_key": ...}` and point this at
AWS Pricing API / EC2 DescribeSpotPriceHistory via connectors.rest.RESTConnector
-- construct that connector directly with an AWS-specific record_mapper
rather than modifying this class.
"""
from typing import Dict, Optional

from connectors.providers.generic import SimulatedProviderConnector


class AWSConnector(SimulatedProviderConnector):
    def __init__(self, credentials: Optional[Dict[str, str]] = None, seed: Optional[int] = None):
        super().__init__(provider_id="aws", credentials=credentials, seed=seed)
