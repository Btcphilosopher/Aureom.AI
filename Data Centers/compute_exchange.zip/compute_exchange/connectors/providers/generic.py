"""
Simulated provider connector.

Every named connector in this package (aws.py, azure.py, gcp.py, ...)
subclasses this. Today they generate deterministic, clearly-labelled
SIMULATED offers from the provider's profile in `simulation/providers.py`
(section 55) -- this makes the whole platform runnable end-to-end without
any live credentials. Swapping a provider onto real data means replacing
its connector body with a `RESTConnector` / `CSVConnector` call against
that provider's actual rate-card API, with no change required anywhere
else in the system (ingestion, pricing, analytics, API are all connector-
agnostic -- section 30/31).
"""
import random
from typing import Any, Dict, List, Optional

from connectors.base import ConnectorMetadata, ProviderConnector
from models.offer import AvailabilityState, ComputeOffer
from simulation.providers import PROVIDER_PROFILES, ProviderProfile, generate_offers_for_provider


class SimulatedProviderConnector(ProviderConnector):
    def __init__(self, provider_id: str, credentials: Optional[Dict[str, str]] = None, seed: Optional[int] = None):
        super().__init__(credentials)
        profile = next((p for p in PROVIDER_PROFILES if p.provider_id == provider_id), None)
        if profile is None:
            raise ValueError(f"No simulation profile registered for provider_id={provider_id!r}")
        self.profile: ProviderProfile = profile
        self.rng = random.Random(seed if seed is not None else hash(provider_id) & 0xFFFFFFFF)
        self.metadata = ConnectorMetadata(
            provider_id=provider_id,
            connector_type="simulated",
            source_url=f"https://{provider_id}.example/pricing",
            notes="Demo adapter -- generates SIMULATED offers, not a live provider quote. "
                  "Replace with connectors.rest.RESTConnector / connectors.csv.CSVConnector "
                  "against the provider's real rate-card API for production use.",
        )

    async def fetch_offers(self) -> List[ComputeOffer]:
        return generate_offers_for_provider(self.profile, self.rng, simulated=True)

    async def fetch_availability(self) -> Dict[str, AvailabilityState]:
        offers = await self.fetch_offers()
        return {o.offer_id: o.availability for o in offers}

    async def fetch_metadata(self) -> Dict[str, Any]:
        return {
            "provider_id": self.profile.provider_id,
            "name": self.profile.name,
            "category": self.profile.category.value,
            "regions": self.profile.regions,
            "gpu_models": self.profile.gpu_models,
            "connector_type": self.metadata.connector_type,
            "note": self.metadata.notes,
        }
