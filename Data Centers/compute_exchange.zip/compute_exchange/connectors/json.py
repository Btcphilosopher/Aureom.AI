"""Generic JSON connector -- ingest a provider rate card published as JSON."""
import json as _json
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from connectors.base import ConnectorMetadata, ProviderConnector
from models.offer import AvailabilityState, ComputeOffer


class JSONConnector(ProviderConnector):
    """
    Reads a JSON file containing a list of raw offer records. `record_mapper`
    converts one raw record (dict) into a ComputeOffer.
    """

    def __init__(
        self,
        provider_id: str,
        file_path: str,
        record_mapper: Callable[[Dict[str, Any]], Optional[ComputeOffer]],
        records_key: Optional[str] = None,
        source_url: Optional[str] = None,
        credentials: Optional[Dict[str, str]] = None,
    ):
        super().__init__(credentials)
        self.file_path = file_path
        self.record_mapper = record_mapper
        self.records_key = records_key
        self.metadata = ConnectorMetadata(
            provider_id=provider_id, connector_type="json", source_url=source_url or file_path,
        )

    async def fetch_offers(self) -> List[ComputeOffer]:
        path = Path(self.file_path)
        if not path.exists():
            return []
        data = _json.loads(path.read_text(encoding="utf-8"))
        records = data.get(self.records_key, []) if self.records_key else data
        offers: List[ComputeOffer] = []
        for record in records:
            offer = self.record_mapper(record)
            if offer is not None:
                offers.append(offer)
        return offers

    async def fetch_availability(self) -> Dict[str, AvailabilityState]:
        offers = await self.fetch_offers()
        return {o.offer_id: o.availability for o in offers}

    async def fetch_metadata(self) -> Dict[str, Any]:
        return {
            "provider_id": self.metadata.provider_id,
            "connector_type": self.metadata.connector_type,
            "source_url": self.metadata.source_url,
        }
