# COMPUTE.EXCHANGE

**Industrial Compute Price Discovery, Comparison & Market Intelligence Platform.**

COMPUTE.EXCHANGE treats compute capacity as a commodity. Providers publish
capacity; the engine normalises it into canonical units; the cost engine
prices workloads against it; the ranking/optimisation layer routes a
workload to the best available capacity. It is built to behave like an
industrial logistics/freight exchange or a Bloomberg-style market-data
terminal, not a consumer shopping-comparison site.

> **SIMULATION NOTICE**: this build ships with a market simulator
> (`simulation/`) that generates a realistic synthetic market -- 31
> providers, 20 GPU models, thousands of offers -- so the whole platform
> runs end-to-end with zero external credentials. Every simulated record
> is stamped `pricing_type: "SIMULATED"` and a `source` starting with
> `SIMULATED:`. Nothing in this build should be read as a live quote from
> AWS, CoreWeave, RunPod, etc. See "Going from simulated to live data" below.

---

## Core question

> "I need 64 H100 GPUs in Europe for 72 hours. Where can I get them, at
> what effective price, with what network/storage costs, and what are the
> trade-offs?"

The system answers this by walking the full pricing hierarchy on every
query:

```
ADVERTISED RATE -> NORMALISED RATE -> WORKLOAD COST -> EFFECTIVE COST
    -> PERFORMANCE-ADJUSTED COST -> RISK-ADJUSTED COST
```

Every price figure at every stage carries `source`, `timestamp`,
`pricing_type` (OBSERVED / CALCULATED / ESTIMATED / SIMULATED /
HISTORICAL) and `confidence` -- an estimate is never presented as a
provider's quoted price.

---

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env

# Run the API (auto-seeds a synthetic market on first boot):
python app.py
# -> http://localhost:8000/docs for interactive OpenAPI docs
# -> ws://localhost:8000/ws/market for the live ticker feed

# Or seed the synthetic market standalone (no server):
python -m scripts.seed_synthetic_data

# Run tests:
pytest
```

### Docker

```bash
docker compose up --build
```

Runs the API against PostgreSQL (`docker-compose.yml`). Local development
defaults to SQLite (`DATABASE_URL=sqlite:///./compute_exchange.db`) --
switching to PostgreSQL is a one-line env var change; see
`database/migrations/README.md`.

### Demo query

```bash
curl -X POST localhost:8000/compare \
  -H "Content-Type: application/json" \
  -d '{"gpu": "h100-sxm-80gb", "count": 64, "runtime_hours": 168, "region": "EU", "billing": "on_demand"}'

curl -X POST localhost:8000/workloads/calculate \
  -H "Content-Type: application/json" \
  -d '{"gpu_model": "h100-sxm-80gb", "gpu_count": 64, "runtime_hours": 168, "region": "EU", "storage_tb": 10, "egress_tb": 5}'
```

`/workloads/calculate` returns `best_price`, `best_value`,
`best_reliability`, `best_availability` and `best_performance` routes plus
cluster-premium analysis, matching the worked example in section 66/67 of
the product brief.

---

## Architecture

```
                    COMPUTE SUPPLY
                         |
        +----------------+----------------+
        v                v                v
   Provider A       Provider B       Provider C     (connectors/)
        |                |                |
        +----------------+----------------+
                         v
                  DATA INGESTION           (ingestion/pipeline.py)
                         v
                   NORMALISATION           (pricing/normalizer.py, pricing/currency.py)
                         v
                  PRICE DATABASE           (database/ -- SQLite dev, PostgreSQL-ready)
                         v
        +----------------+----------------+
        v                v                v
     PRICING          MARKET          AVAILABILITY
     ENGINE          ANALYTICS          ENGINE      (pricing/, analytics/)
        |                |                |
        +----------------+----------------+
                         v
                 WORKLOAD ROUTER          (optimization/workload_router.py)
                         v
                  RANKING ENGINE          (analytics/ranking.py)
                         v
                    FASTAPI               (api/, websocket/)
                         v
              Kotlin / web front end
```

### Project layout

```
compute_exchange/
├── app.py                   entry point (uvicorn)
├── config/                  settings, logging
├── catalogue/                canonical GPU definitions (pure data)
├── models/                   Pydantic domain models (GPU, Provider, Offer, Pricing, Workload, Market)
├── database/                  SQLAlchemy ORM + repositories (SQLite dev / PostgreSQL prod)
├── connectors/                provider adapter interface + csv/json/rest + per-provider adapters
├── ingestion/                 pipeline: validate -> normalise -> persist, with full provenance
├── pricing/                   currency, unit normalisation, cost engine, workload/training/inference cost, effective price
├── analytics/                 ranking, benchmarks, market/regional index, volatility, spreads, outliers, forecasting
├── optimization/              objective-function profiles, optimizer, workload router
├── simulation/                synthetic market: providers, inventory, scenarios, market engine
├── alerts/                    alert types/rules + engine
├── api/                       FastAPI routers (section 37 endpoints)
├── websocket/                 /ws/market live ticker feed
├── reports/                   Daily/Weekly/Regional/Provider/Volatility reports -> JSON/CSV/PDF
├── scripts/                   seed_synthetic_data.py
└── tests/                     pytest suite
```

---

## Key abstractions

- **`models.gpu.GPU`** -- canonical GPU spec (VRAM, bandwidth, FP16/BF16/FP8/FP4 TFLOPs,
  power). New GPUs are added purely as data in `catalogue/gpu_catalogue.py`;
  nothing in pricing or analytics changes.
- **`models.offer.ComputeOffer`** -- the canonical unit every connector must
  produce: GPU/CPU/RAM/storage/network specs, region, availability,
  billing model/unit, price, and full provenance (`source`, `source_url`,
  `parser_version`, `observed_at`).
- **`models.pricing.PriceRecord`** -- `original_price`/`original_currency`
  are *never* mutated; `normalised_price` is a separate, clearly-derived
  figure with its own `exchange_rate` and `exchange_timestamp`.
- **`pricing.cost_engine.CostEngine`** -- turns one offer + a runtime/
  storage/egress envelope into a full breakdown (`compute_cost`,
  `storage_cost`, `egress_cost`, ..., `estimated_total`,
  `effective_gpu_hour`), tagging every line item with the `PricingType`
  that produced it.
- **`analytics.ranking.RankingEngine`** -- the Compute Value Score
  (price/performance/reliability/availability/network/billing-flexibility),
  with weights always exposed on every result, never hidden.
- **`optimization.workload_router.WorkloadRouter`** -- given a `Workload`,
  returns BEST_PRICE / BEST_VALUE / BEST_RELIABILITY / BEST_AVAILABILITY /
  BEST_PERFORMANCE routes, plus cluster-premium analysis (is an 8x cluster
  more expensive per-GPU than a single GPU from the same provider?).
- **`simulation.market.MarketSimulator`** -- generates and evolves a
  synthetic market under selectable scenarios (`GPU_SHORTAGE`,
  `DEMAND_SPIKE`, `OVERSUPPLY`, `POWER_PRICE_SHOCK`, `NEW_GPU_RELEASE`,
  `NORMAL_MARKET`), emitting the same `MarketEvent` stream the real
  ingestion pipeline would produce.

---

## API surface (section 37)

All endpoints (except `/health` and, if `API_KEYS` is set, everything else)
require an `X-API-Key` header. See `.env.example` / `api/security.py`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | liveness + simulation-mode flag |
| GET | `/providers`, `/providers/{id}` | provider directory |
| GET | `/gpus`, `/gpus/{id}` | canonical GPU catalogue |
| GET | `/offers`, `/offers/{id}` | canonical offers, with freshness state |
| GET | `/prices`, `/prices/latest`, `/prices/history` | normalised price snapshots, cheapest-per-GPU ticker feed, and 1H/24H/7D/30D/90D/1Y history |
| GET | `/rankings`, `/rankings/cheapest` | Compute Value Score rankings, and pure cheapest-first |
| GET | `/market/index`, `/market/spread`, `/market/regional` | COMPUTE PRICE INDEX, price spread/distribution, regional premium/discount |
| GET | `/regions` | region directory (UK/EU/US-EAST/US-WEST/ASIA/MIDDLE-EAST) |
| POST | `/workloads/calculate` | full workload routing (best price/value/reliability/availability/performance) |
| POST | `/compare` | ranked offer comparison for a GPU/count/runtime/region/billing query |
| POST | `/rank` | Compute Value Score ranking with custom or preset weights |
| GET | `/alerts`, POST `/alerts/rules` | recent alerts, and standing user price-alert rules |
| WS | `/ws/market` | live ticker: new offer / price change / availability change / market events |

Every list response is paginated (`limit`/`offset`) and every JSON offer
includes `freshness_state` (`LIVE`/`RECENT`/`STALE`/`EXPIRED`) and
`is_simulated`. The API is presentation-agnostic by design (section 68) --
it returns data, not formatted strings, so a Kotlin/web client owns the
market-ticker/terminal aesthetic.

---

## Going from simulated to live data

Real providers plug in as connectors implementing
`connectors.base.ProviderConnector` (`fetch_offers` / `fetch_availability`
/ `fetch_metadata`, all returning canonical `ComputeOffer`s). Three ways in:

1. **`connectors.rest.RESTConnector`** -- point it at a provider's pricing
   API with a `record_mapper` function and (optionally) an API key.
2. **`connectors.csv.CSVConnector`** / **`connectors.json.JSONConnector`**
   -- for providers that publish a static rate card file.
3. Swap the body of the matching adapter in `connectors/providers/` (e.g.
   `connectors/providers/aws.py`) from `SimulatedProviderConnector` to a
   `RESTConnector` call -- nothing else in the system needs to change.

Then feed connectors through `ingestion.pipeline.IngestionPipeline.ingest()`,
which validates (section 33), normalises (currency + units), and persists
with full provenance and append-only price history.

Provider credentials live only on the connector instance
(`ProviderConnector._credentials`) and are never returned by any API
endpoint or logged in the clear (`redacted_config()`).

---

## Testing

```bash
pytest -v
```

Covers the GPU catalogue, currency conversion (never mutates inputs),
the cost engine (compute/storage/egress line items + their PricingType
labels), training/inference cost models and the token-economics formula,
the ranking engine (weights always exposed, cheapest-first, availability
scoring), outlier detection (flags cheap/expensive/stale/missing --
never "fraud"), market/regional index math, ingestion validation
(rejects, never repairs), and an end-to-end API smoke test against the
seeded synthetic market.

## License

Internal project scaffold -- no license file included; add one appropriate
to your organisation before distributing.
