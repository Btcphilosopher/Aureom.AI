"""Alert types (section 41) and user-defined price alert rules (section 42)."""
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class AlertType(str, Enum):
    PRICE_DROP = "PRICE_DROP"
    PRICE_SPIKE = "PRICE_SPIKE"
    NEW_LOW = "NEW_LOW"
    NEW_HIGH = "NEW_HIGH"
    AVAILABILITY_CHANGE = "AVAILABILITY_CHANGE"
    PROVIDER_OFFLINE = "PROVIDER_OFFLINE"
    DATA_STALE = "DATA_STALE"
    MARKET_VOLATILITY = "MARKET_VOLATILITY"
    USER_RULE_TRIGGERED = "USER_RULE_TRIGGERED"


@dataclass
class PriceAlertRule:
    """
    'Alert me when H100 < $2.00/hr', 'UK H200 < $4.00/hr', etc.
    comparison is 'lt' (below threshold) or 'gt' (above threshold).
    """
    gpu_model: Optional[str]
    region: Optional[str]
    comparison: str  # "lt" | "gt"
    threshold_price: float
    owner: Optional[str] = None

    def is_triggered(self, gpu_model: str, region: Optional[str], price: float) -> bool:
        if self.gpu_model and self.gpu_model != gpu_model:
            return False
        if self.region and region and self.region != region:
            return False
        if self.comparison == "lt":
            return price < self.threshold_price
        return price > self.threshold_price


# Significant-change thresholds used by AlertEngine's automatic detectors.
PRICE_SPIKE_PCT = 8.0
PRICE_DROP_PCT = -8.0
