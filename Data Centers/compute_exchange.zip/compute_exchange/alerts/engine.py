"""
Alert engine (section 41/42).

Consumes market events (from the simulator or a real ingestion tick) and
user-defined PriceAlertRules, and produces TriggeredAlert records ready to
persist via database.repositories.alert_repo.AlertRepository.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Sequence

from alerts.rules import PRICE_DROP_PCT, PRICE_SPIKE_PCT, AlertType, PriceAlertRule
from analytics.volatility import VolatilityResult
from simulation.market import MarketEvent


@dataclass
class TriggeredAlert:
    alert_type: AlertType
    severity: str
    message: str
    gpu_model: Optional[str] = None
    region: Optional[str] = None
    provider_id: Optional[str] = None
    offer_id: Optional[str] = None
    threshold_price: Optional[float] = None
    observed_value: Optional[float] = None
    triggered_at: datetime = field(default_factory=datetime.utcnow)


class AlertEngine:
    def from_market_events(self, events: Sequence[MarketEvent]) -> List[TriggeredAlert]:
        alerts: List[TriggeredAlert] = []
        for event in events:
            if event.event_type == "PRICE_CHANGE" and event.detail:
                pct = event.detail.get("pct_change", 0.0) * 100
                if pct <= PRICE_DROP_PCT:
                    alerts.append(TriggeredAlert(
                        alert_type=AlertType.PRICE_DROP, severity="INFO",
                        message=f"{event.gpu_model} @ {event.provider_id} dropped {abs(pct):.1f}%.",
                        gpu_model=event.gpu_model, region=event.region, provider_id=event.provider_id,
                        offer_id=event.offer_id, observed_value=event.detail.get("new_price"),
                    ))
                elif pct >= PRICE_SPIKE_PCT:
                    alerts.append(TriggeredAlert(
                        alert_type=AlertType.PRICE_SPIKE, severity="WARNING",
                        message=f"{event.gpu_model} @ {event.provider_id} spiked {pct:.1f}%.",
                        gpu_model=event.gpu_model, region=event.region, provider_id=event.provider_id,
                        offer_id=event.offer_id, observed_value=event.detail.get("new_price"),
                    ))
            elif event.event_type == "AVAILABILITY_CHANGE":
                alerts.append(TriggeredAlert(
                    alert_type=AlertType.AVAILABILITY_CHANGE, severity="INFO",
                    message=event.title, gpu_model=event.gpu_model, region=event.region,
                    provider_id=event.provider_id, offer_id=event.offer_id,
                ))
            elif event.event_type == "MARKET_EVENT":
                alerts.append(TriggeredAlert(
                    alert_type=AlertType.MARKET_VOLATILITY, severity="INFO", message=event.title,
                ))
        return alerts

    def check_new_extremes(
        self, gpu_model: str, region: str, current_price: float,
        historical_min: Optional[float], historical_max: Optional[float],
    ) -> List[TriggeredAlert]:
        alerts: List[TriggeredAlert] = []
        if historical_min is not None and current_price < historical_min:
            pct = (current_price - historical_min) / historical_min * 100 if historical_min else 0.0
            alerts.append(TriggeredAlert(
                alert_type=AlertType.NEW_LOW, severity="INFO",
                message=f"{gpu_model} [{region}] hit a new low: ${current_price:.4f}/hr "
                        f"({pct:+.1f}% vs prior 7-day median).",
                gpu_model=gpu_model, region=region, observed_value=current_price,
            ))
        if historical_max is not None and current_price > historical_max:
            alerts.append(TriggeredAlert(
                alert_type=AlertType.NEW_HIGH, severity="WARNING",
                message=f"{gpu_model} [{region}] hit a new high: ${current_price:.4f}/hr.",
                gpu_model=gpu_model, region=region, observed_value=current_price,
            ))
        return alerts

    def check_staleness(self, offer_id: str, gpu_model: str, age_seconds: float, stale_threshold_seconds: float) -> List[TriggeredAlert]:
        if age_seconds <= stale_threshold_seconds:
            return []
        return [TriggeredAlert(
            alert_type=AlertType.DATA_STALE, severity="WARNING",
            message=f"{gpu_model} offer {offer_id} has not updated in {age_seconds / 3600:.1f} hours.",
            gpu_model=gpu_model, offer_id=offer_id, observed_value=age_seconds,
        )]

    def check_volatility(self, gpu_model: str, volatility: VolatilityResult) -> List[TriggeredAlert]:
        if volatility.classification != "HIGH":
            return []
        return [TriggeredAlert(
            alert_type=AlertType.MARKET_VOLATILITY, severity="WARNING",
            message=f"{gpu_model} {volatility.window_days}D volatility is HIGH "
                    f"(±{volatility.volatility_pct:.1f}%).",
            gpu_model=gpu_model, observed_value=volatility.volatility_pct,
        )]

    def check_user_rules(
        self, rules: Sequence[PriceAlertRule], gpu_model: str, region: Optional[str], price: float,
    ) -> List[TriggeredAlert]:
        alerts: List[TriggeredAlert] = []
        for rule in rules:
            if rule.is_triggered(gpu_model, region, price):
                direction = "below" if rule.comparison == "lt" else "above"
                alerts.append(TriggeredAlert(
                    alert_type=AlertType.USER_RULE_TRIGGERED, severity="INFO",
                    message=f"{gpu_model}{' [' + region + ']' if region else ''} is {direction} "
                            f"your threshold of ${rule.threshold_price:.2f}/hr (currently ${price:.4f}/hr).",
                    gpu_model=gpu_model, region=region, threshold_price=rule.threshold_price,
                    observed_value=price,
                ))
        return alerts
