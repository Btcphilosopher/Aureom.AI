"""
COMPUTE.EXCHANGE entry point.

    python app.py                 # runs the API with uvicorn
    uvicorn app:app --reload      # equivalent, dev-mode with autoreload

`app` is re-exported from api.main so both invocation styles work.
"""
from api.main import app  # noqa: F401 -- re-exported for `uvicorn app:app`

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "api.main:app", host="0.0.0.0", port=8000, reload=True,
        reload_excludes=["*.db", "*.db-journal"],
    )
