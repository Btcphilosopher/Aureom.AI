import pytest

from ingestion.validator import OfferValidationError, validate_offer
from tests.factories import make_offer


def test_valid_offer_passes():
    validate_offer(make_offer())  # should not raise


def test_unknown_gpu_is_rejected():
    offer = make_offer(gpu_model="totally-fake-gpu-9000")
    with pytest.raises(OfferValidationError) as exc_info:
        validate_offer(offer)
    assert "unknown GPU model" in str(exc_info.value)


def test_unknown_region_is_rejected():
    offer = make_offer(region="MOON-BASE-1")
    with pytest.raises(OfferValidationError):
        validate_offer(offer)


def test_malformed_record_is_never_silently_repaired():
    """Section 33: reject, don't auto-correct. Two independent problems both surface."""
    offer = make_offer(gpu_model="fake-gpu", region="NOWHERE")
    with pytest.raises(OfferValidationError) as exc_info:
        validate_offer(offer)
    assert len(exc_info.value.reasons) >= 2
