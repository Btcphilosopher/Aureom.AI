from analytics.ranking import RankingEngine
from models.market import ComputeScoreWeights
from tests.factories import make_offer


def test_cheapest_ranking_orders_by_gpu_hour_price():
    cheap = make_offer(offer_id="cheap", price=8.0, gpu_count=8)
    expensive = make_offer(offer_id="expensive", price=40.0, gpu_count=8)

    ranked = RankingEngine().cheapest([expensive, cheap])
    assert [r.offer_id for r in ranked] == ["cheap", "expensive"]
    assert ranked[0].rank == 1


def test_weights_are_always_exposed_on_every_result():
    offers = [make_offer(offer_id="a"), make_offer(offer_id="b", price=10.0)]
    ranked = RankingEngine(weights=ComputeScoreWeights(price_weight=0.9)).rank(offers)
    for r in ranked:
        assert r.score.weights_used.price_weight > 0
        assert r.score.total_score >= 0


def test_cheapest_price_wins_under_a_cheapest_only_profile():
    cheap = make_offer(offer_id="cheap", price=8.0, gpu_count=8, reliability_score=50.0)
    expensive_reliable = make_offer(offer_id="reliable", price=40.0, gpu_count=8, reliability_score=99.0)

    weights = ComputeScoreWeights(price_weight=1.0, performance_weight=0, reliability_weight=0,
                                   availability_weight=0, network_weight=0, billing_flexibility_weight=0)
    ranked = RankingEngine(weights=weights).rank([expensive_reliable, cheap])
    assert ranked[0].offer_id == "cheap"


def test_out_of_stock_offer_scores_lower_availability():
    from models.offer import AvailabilityState
    available = make_offer(offer_id="avail", availability=AvailabilityState.AVAILABLE)
    oos = make_offer(offer_id="oos", availability=AvailabilityState.OUT_OF_STOCK)
    ranked = RankingEngine().rank([available, oos])
    by_id = {r.offer_id: r for r in ranked}
    assert by_id["avail"].score.availability_score > by_id["oos"].score.availability_score
