import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    from api.main import app
    with TestClient(app) as c:
        yield c


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "OK"


def test_gpus_catalogue_endpoint(client):
    resp = client.get("/gpus")
    assert resp.status_code == 200
    body = resp.json()
    assert body["count"] >= 20
    assert any(g["model"] == "H100" for g in body["results"])


def test_providers_seeded_on_startup(client):
    resp = client.get("/providers")
    assert resp.status_code == 200
    body = resp.json()
    assert body["count"] >= 30


def test_offers_endpoint_filters_by_gpu(client):
    resp = client.get("/offers", params={"gpu": "h100-sxm-80gb", "limit": 20})
    assert resp.status_code == 200
    body = resp.json()
    assert body["count"] > 0
    for offer in body["results"]:
        assert offer["gpu_model"] == "h100-sxm-80gb"
        assert "freshness_state" in offer
        assert "is_simulated" in offer


def test_compare_endpoint_returns_ranked_results():
    from api.main import app
    with TestClient(app) as client:
        resp = client.post("/compare", json={
            "gpu": "h100-sxm-80gb", "count": 8, "runtime_hours": 72, "region": "EU",
        })
    assert resp.status_code == 200
    body = resp.json()
    assert body["currency"] == "USD"
    if body["results"]:
        assert body["results"][0]["rank"] == 1
        assert body["results"][0]["estimated_total"] <= body["results"][-1]["estimated_total"]


def test_market_index_endpoint(client):
    resp = client.get("/market/index", params={"gpu": "h100-sxm-80gb"})
    assert resp.status_code == 200
    assert resp.json()["gpu_model"] == "h100-sxm-80gb"


def test_rankings_cheapest(client):
    resp = client.get("/rankings/cheapest", params={"gpu": "h100-sxm-80gb"})
    assert resp.status_code == 200
    results = resp.json()["results"]
    if len(results) > 1:
        assert results[0]["gpu_hour_price"] <= results[1]["gpu_hour_price"]


def test_alerts_endpoint_is_reachable(client):
    resp = client.get("/alerts")
    assert resp.status_code == 200
    assert "results" in resp.json()
