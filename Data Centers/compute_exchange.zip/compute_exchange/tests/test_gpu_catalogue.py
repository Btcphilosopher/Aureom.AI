from catalogue.gpu_catalogue import all_gpus, find_by_model_name, get_gpu, gpu_exists


def test_catalogue_has_at_least_twenty_gpus():
    assert len(all_gpus()) >= 20


def test_get_gpu_known_id():
    gpu = get_gpu("h100-sxm-80gb")
    assert gpu is not None
    assert gpu.model == "H100"
    assert gpu.vram_gb == 80


def test_gpu_exists():
    assert gpu_exists("h100-sxm-80gb")
    assert not gpu_exists("made-up-gpu")


def test_find_by_model_name_is_lenient():
    gpu = find_by_model_name("h100")
    assert gpu is not None
    assert gpu.id == "h100-sxm-80gb"

    gpu2 = find_by_model_name("RTX 4090")
    assert gpu2 is not None
    assert gpu2.model == "RTX 4090"


def test_adding_a_new_gpu_requires_no_pricing_changes():
    """
    Sanity check on the design constraint from section 4: the catalogue is
    pure data. Every entry must expose the fields pricing/analytics rely on.
    """
    for gpu in all_gpus():
        assert gpu.id
        assert gpu.vram_gb > 0
        assert gpu.memory_bandwidth_gbps > 0
