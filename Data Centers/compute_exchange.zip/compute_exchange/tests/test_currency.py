from models.pricing import Currency
from pricing.currency import CurrencyConverter


def test_identity_conversion():
    converter = CurrencyConverter()
    amount, rate, _ = converter.convert(100.0, Currency.USD, Currency.USD)
    assert amount == 100.0
    assert rate == 1.0


def test_round_trip_conversion_is_approximately_identity():
    converter = CurrencyConverter()
    usd = 100.0
    gbp, rate_to_gbp, _ = converter.convert(usd, Currency.USD, Currency.GBP)
    back_to_usd, rate_to_usd, _ = converter.convert(gbp, Currency.GBP, Currency.USD)
    assert abs(back_to_usd - usd) < 0.01


def test_conversion_never_mutates_inputs():
    converter = CurrencyConverter()
    original_rates = dict(converter._rates)
    converter.convert(50.0, Currency.EUR, Currency.JPY)
    assert converter._rates == original_rates
