import pytest

from models.workload import InferenceWorkload, TrainingWorkload
from pricing.workload_cost import InferenceCostModel, TrainingCostModel, cost_per_million_tokens


def test_training_cost_model_basic():
    workload = TrainingWorkload(
        model_size_params_b=70, gpu_model="h100-sxm-80gb", gpu_count=64,
        training_hours=168, utilisation=0.9, checkpoint_storage_tb=5, network_traffic_tb=2,
    )
    result = TrainingCostModel().calculate(workload, gpu_hour_price=2.75)

    assert result.gpu_cost == pytest.approx(2.75 * 64 * 168)
    assert result.estimated_training_cost >= result.gpu_cost
    # Lower utilisation should always increase the effective (idle-adjusted) cost/GPU-hour.
    assert result.cost_per_gpu_hour_effective > result.cost_per_gpu_hour_billed


def test_utilisation_assumption_changes_effective_cost():
    workload_full = TrainingWorkload(model_size_params_b=7, gpu_model="a100-sxm-80gb", gpu_count=8,
                                      training_hours=24, utilisation=1.0)
    workload_partial = TrainingWorkload(model_size_params_b=7, gpu_model="a100-sxm-80gb", gpu_count=8,
                                         training_hours=24, utilisation=0.6)

    full = TrainingCostModel().calculate(workload_full, gpu_hour_price=1.35)
    partial = TrainingCostModel().calculate(workload_partial, gpu_hour_price=1.35)

    assert full.cost_per_gpu_hour_effective == pytest.approx(1.35)
    assert partial.cost_per_gpu_hour_effective == pytest.approx(1.35 / 0.6)


def test_cost_per_million_tokens_formula():
    # 1000 tokens/sec at 100% utilisation, $1/GPU-hour:
    # tokens/hour = 3,600,000 -> cost/token = 1/3,600,000 -> cost/1M tokens = 1,000,000/3,600,000
    result = cost_per_million_tokens(gpu_hour_price=1.0, tokens_per_second=1000, utilisation=1.0)
    assert result == pytest.approx(1_000_000 / 3_600_000, rel=1e-4)


def test_cost_per_million_tokens_scales_with_utilisation():
    full = cost_per_million_tokens(gpu_hour_price=2.0, tokens_per_second=500, utilisation=1.0)
    half = cost_per_million_tokens(gpu_hour_price=2.0, tokens_per_second=500, utilisation=0.5)
    assert half == pytest.approx(full * 2, rel=1e-6)


def test_inference_cost_model_flags_undercapacity():
    workload = InferenceWorkload(
        model_name="test-llm", gpu_model="h100-sxm-80gb", gpu_count=1,
        requests_per_second=1000, avg_input_tokens=500, avg_output_tokens=500,
        tokens_per_second_per_gpu=50, utilisation=0.8,
    )
    result = InferenceCostModel().calculate(workload, gpu_hour_price=2.75)
    assert result.capacity_utilisation_ratio > 1.0
    assert any("exceeds" in a for a in result.assumptions)
