from pricing.cost_engine import CostEngine
from tests.factories import make_offer


def test_basic_compute_only_cost():
    offer = make_offer(price=22.0, gpu_count=8)
    breakdown = CostEngine().calculate(offer, runtime_hours=72)

    assert breakdown.compute_cost == 22.0 * 72
    assert breakdown.storage_cost == 0.0
    assert breakdown.estimated_total == breakdown.compute_cost
    assert breakdown.effective_gpu_hour == round(breakdown.estimated_total / (8 * 72), 6)


def test_storage_cost_is_estimated_and_labelled():
    offer = make_offer()
    breakdown = CostEngine().calculate(offer, runtime_hours=730, storage_tb=10)

    assert breakdown.storage_cost > 0
    assert breakdown.line_item_pricing_type["storage_cost"] == "ESTIMATED"
    assert any("Storage cost assumes" in note for note in breakdown.notes)


def test_egress_uses_observed_provider_rate_when_available():
    offer = make_offer(egress_price_per_tb=45.0)
    breakdown = CostEngine().calculate(offer, runtime_hours=1, egress_tb=5)

    assert breakdown.egress_cost == 45.0 * 5
    assert breakdown.line_item_pricing_type["egress_cost"] == "OBSERVED"


def test_effective_gpu_hour_never_conflates_instance_and_gpu_price():
    offer = make_offer(price=40.0, gpu_count=8)
    assert offer.gpu_hour_price == 5.0
    assert offer.price == 40.0  # instance price stays distinct from GPU-hour price
