"""
Pytest configuration.

Points the app at an isolated temp-file SQLite database *before* any
application module is imported, since database.connection builds its
engine at import time from config.settings.get_settings(). This keeps
test runs from touching a developer's local compute_exchange.db.
"""
import os
import tempfile

_tmp_db = tempfile.NamedTemporaryFile(prefix="compute_exchange_test_", suffix=".db", delete=False)
_tmp_db.close()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp_db.name}"
os.environ["API_KEYS"] = ""  # disable auth for the test suite
os.environ["SIMULATION_ENABLED"] = "false"

import pytest  # noqa: E402

from database.connection import SessionLocal, init_db  # noqa: E402
from database.orm import (  # noqa: E402
    AlertORM, AlertRuleORM, AvailabilityORM, BenchmarkORM, OfferORM,
    PriceHistoryORM, PriceORM, ProviderORM, RankingORM, SourceORM,
)


@pytest.fixture(scope="session", autouse=True)
def _setup_db():
    init_db()
    yield
    os.unlink(_tmp_db.name)


@pytest.fixture()
def db_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        # Keep tests isolated from each other's writes.
        for model in (
            PriceHistoryORM, AvailabilityORM, PriceORM, OfferORM, AlertORM,
            AlertRuleORM, RankingORM, BenchmarkORM, SourceORM, ProviderORM,
        ):
            session.query(model).delete()
        session.commit()
        session.close()
