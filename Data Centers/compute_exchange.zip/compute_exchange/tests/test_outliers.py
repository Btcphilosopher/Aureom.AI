from datetime import datetime, timedelta

from analytics.outliers import OutlierDetector, OutlierType
from tests.factories import make_offer


def test_unusually_cheap_offer_is_flagged_not_condemned():
    normal_prices = [2.7, 2.75, 2.8, 2.72, 2.78, 2.76, 2.74, 2.79]
    cheap_price = 0.5
    offers = [make_offer(offer_id=f"n{i}") for i in range(len(normal_prices))] + [make_offer(offer_id="cheap")]
    prices = normal_prices + [cheap_price]

    flags = OutlierDetector(z_threshold=2.0).detect(offers, prices)
    cheap_flags = [f for f in flags if f.offer_id == "cheap"]
    assert cheap_flags
    assert cheap_flags[0].outlier_type == OutlierType.UNUSUALLY_CHEAP
    assert "Not automatically flagged as fraudulent" in cheap_flags[0].reason


def test_stale_offer_is_flagged():
    stale = make_offer(offer_id="stale", observed_at=datetime.utcnow() - timedelta(days=5))
    flags = OutlierDetector().detect([stale], [2.75])
    assert any(f.outlier_type == OutlierType.STALE for f in flags)


def test_missing_fields_are_flagged():
    incomplete = make_offer(offer_id="incomplete", cpu_cores=None, ram_gb=None)
    flags = OutlierDetector().detect([incomplete], [2.75])
    missing = [f for f in flags if f.outlier_type == OutlierType.MISSING]
    assert missing
    assert "cpu_cores" in missing[0].reason
