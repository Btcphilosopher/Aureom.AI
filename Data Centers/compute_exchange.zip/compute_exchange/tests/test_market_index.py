from analytics.market_index import MarketIndexEngine, RegionalIndexEngine
from analytics.spreads import PriceSpreadEngine


def test_weighted_median_favours_higher_volume_offers():
    prices = [1.0, 2.0, 3.0]
    weights = [1, 1, 100]  # the $3.00 offer dominates by volume
    index = MarketIndexEngine().compute("h100-sxm-80gb", prices, weights)
    assert index.index_value == 3.0
    assert index.sample_size == 3


def test_market_index_methodology_is_documented():
    index = MarketIndexEngine().compute("h100-sxm-80gb", [], [])
    assert "weighted" in index.methodology.lower()


def test_regional_index_premium_sign():
    engine = RegionalIndexEngine()
    point = engine.compute("MIDDLE-EAST", "h100-sxm-80gb", [4.0, 4.2], [8, 8], global_index_value=3.0)
    assert point.premium_pct > 0  # more expensive than global -> premium

    point_cheap = engine.compute("US-EAST", "h100-sxm-80gb", [2.0, 2.1], [8, 8], global_index_value=3.0)
    assert point_cheap.premium_pct < 0  # cheaper than global -> discount


def test_price_spread_statistics():
    stats = PriceSpreadEngine.compute("h100-sxm-80gb", [1.87, 2.5, 3.42, 5.0, 8.10])
    assert stats.minimum == 1.87
    assert stats.maximum == 8.10
    assert stats.sample_size == 5
    assert stats.median == 3.42
