"""Shared test-only factories for building canonical ComputeOffer objects."""
from datetime import datetime

from models.offer import AvailabilityState, BillingUnit, ComputeOffer, NetworkFabric, StorageType
from models.pricing import BillingModel, Currency


def make_offer(**overrides) -> ComputeOffer:
    defaults = dict(
        offer_id="test:h100:eu:8:od",
        provider_id="test-provider",
        instance_id="h100-x8",
        gpu_model="h100-sxm-80gb",
        gpu_count=8,
        cpu_model="AMD EPYC 9654",
        cpu_cores=64,
        ram_gb=1024.0,
        storage_gb=16000.0,
        storage_type=StorageType.NVME,
        network_gbps=400.0,
        network_fabric=NetworkFabric.INFINIBAND,
        multi_node_capable=True,
        region="EU",
        country="DE",
        availability=AvailabilityState.AVAILABLE,
        billing_unit=BillingUnit.PER_HOUR,
        billing_model=BillingModel.ON_DEMAND,
        price=22.0,
        currency=Currency.USD,
        egress_price_per_tb=0.0,
        setup_fee=0.0,
        reliability_score=95.0,
        source="test-provider",
        source_url="https://test-provider.example/pricing",
        observed_at=datetime.utcnow(),
    )
    defaults.update(overrides)
    return ComputeOffer(**defaults)
