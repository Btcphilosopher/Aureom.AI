"""GET /gpus, GET /gpus/{id} -- section 37, backed by the canonical catalogue."""
from fastapi import APIRouter, HTTPException

from api.security import ApiKeyDep
from catalogue.gpu_catalogue import all_gpus, get_gpu

router = APIRouter(prefix="/gpus", tags=["gpus"])


@router.get("")
def list_gpus(_=ApiKeyDep):
    gpus = all_gpus()
    return {"count": len(gpus), "results": [g.model_dump(mode="json") for g in gpus]}


@router.get("/{gpu_id}")
def get_gpu_detail(gpu_id: str, _=ApiKeyDep):
    gpu = get_gpu(gpu_id)
    if gpu is None:
        raise HTTPException(status_code=404, detail="GPU not found in catalogue")
    return gpu.model_dump(mode="json")
