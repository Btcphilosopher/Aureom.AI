"""GET /alerts -- section 37/41/42."""
from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from api.deps import get_db
from api.security import ApiKeyDep
from database.repositories.alert_repo import AlertRepository

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("")
def list_alerts(limit: int = 50, acknowledged: Optional[bool] = None, db=Depends(get_db), _=ApiKeyDep):
    repo = AlertRepository(db)
    rows = repo.recent(limit=limit, acknowledged=acknowledged)
    return {
        "count": len(rows),
        "results": [
            {
                "id": r.id, "alert_type": r.alert_type, "severity": r.severity,
                "gpu_model": r.gpu_model, "region": r.region, "provider_id": r.provider_id,
                "offer_id": r.offer_id, "message": r.message, "threshold_price": r.threshold_price,
                "observed_value": r.observed_value, "triggered_at": r.triggered_at.isoformat(),
                "acknowledged": r.acknowledged,
            }
            for r in rows
        ],
    }


class RuleRequest(BaseModel):
    gpu_model: Optional[str] = None
    region: Optional[str] = None
    comparison: str = "lt"
    threshold_price: float
    owner: Optional[str] = None


@router.post("/rules")
def create_rule(payload: RuleRequest, db=Depends(get_db), _=ApiKeyDep):
    """Section 42: 'Alert me when H100 < $2.00/hr' -- persists a standing user rule."""
    repo = AlertRepository(db)
    row = repo.add_rule(
        threshold_price=payload.threshold_price, comparison=payload.comparison,
        gpu_model=payload.gpu_model, region=payload.region, owner=payload.owner,
    )
    db.commit()
    return {"id": row.id, "status": "active"}
