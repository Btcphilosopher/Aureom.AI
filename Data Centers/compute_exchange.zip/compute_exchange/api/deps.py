"""Shared FastAPI dependencies and presentation helpers."""
from datetime import datetime
from typing import Iterator

from fastapi import Query
from sqlalchemy.orm import Session

from config.settings import get_settings
from database.connection import SessionLocal
from simulation.market import MarketSimulator, get_default_simulator


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_simulator() -> MarketSimulator:
    return get_default_simulator()


class Pagination:
    def __init__(self, limit: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0)):
        self.limit = limit
        self.offset = offset


def freshness_state(observed_at: datetime) -> tuple[str, float]:
    """Section 29 DATA FRESHNESS -- LIVE / RECENT / STALE / EXPIRED."""
    settings = get_settings()
    age_seconds = (datetime.utcnow() - observed_at).total_seconds()
    if age_seconds <= settings.freshness_live_seconds:
        state = "LIVE"
    elif age_seconds <= settings.freshness_recent_seconds:
        state = "RECENT"
    elif age_seconds <= settings.freshness_stale_seconds:
        state = "STALE"
    else:
        state = "EXPIRED"
    return state, round(age_seconds, 1)
