"""GET /offers, GET /offers/{id} -- section 37."""
from fastapi import APIRouter, Depends, HTTPException

from api.deps import Pagination, freshness_state, get_db
from api.security import ApiKeyDep
from database.repositories.offer_repo import OfferRepository

router = APIRouter(prefix="/offers", tags=["offers"])


def offer_to_json(offer, freshness=True) -> dict:
    data = offer.model_dump(mode="json")
    data["gpu_hour_price"] = offer.gpu_hour_price
    data["is_simulated"] = offer.source.startswith("SIMULATED")
    if freshness:
        state, age = freshness_state(offer.observed_at)
        data["freshness_state"] = state
        data["age_seconds"] = age
    return data


@router.get("")
def list_offers(
    gpu: str | None = None,
    region: str | None = None,
    billing: str | None = None,
    provider: str | None = None,
    availability: str | None = None,
    pagination: Pagination = Depends(),
    db=Depends(get_db),
    _=ApiKeyDep,
):
    repo = OfferRepository(db)
    rows = repo.list(
        gpu_model=gpu, region=region, billing_model=billing, provider_id=provider,
        availability=availability, limit=pagination.limit, offset=pagination.offset,
    )
    total = repo.count(gpu_model=gpu, region=region, billing_model=billing)
    offers = [repo.to_domain(r) for r in rows]
    return {
        "count": len(offers), "total": total, "limit": pagination.limit, "offset": pagination.offset,
        "results": [offer_to_json(o) for o in offers],
    }


@router.get("/{offer_id}")
def get_offer(offer_id: str, db=Depends(get_db), _=ApiKeyDep):
    repo = OfferRepository(db)
    row = repo.get(offer_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Offer not found")
    return offer_to_json(repo.to_domain(row))
