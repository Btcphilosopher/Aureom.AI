"""GET /market/index, GET /market/spread, GET /regions -- sections 21-24, 37, 50."""
from datetime import datetime

from fastapi import APIRouter, Depends

from analytics.market_index import MarketIndexEngine, RegionalIndexEngine
from analytics.spreads import PriceSpreadEngine
from analytics.volatility import PriceChangeEngine, PricePoint
from api.deps import get_db
from api.security import ApiKeyDep
from database.repositories.offer_repo import OfferRepository
from simulation.providers import REGIONS

router = APIRouter(tags=["market"])


@router.get("/market/index")
def market_index(gpu: str, db=Depends(get_db), _=ApiKeyDep):
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=gpu, availability="AVAILABLE", billing_model="ON_DEMAND", limit=2000)
    offers = [repo.to_domain(r) for r in rows]
    prices = [o.gpu_hour_price for o in offers if o.gpu_hour_price is not None]
    weights = [o.gpu_count for o in offers if o.gpu_hour_price is not None]

    history_rows = repo.price_history(gpu_model=gpu, limit=5000)
    points = [PricePoint(timestamp=r.timestamp, price=r.price) for r in history_rows]
    change = PriceChangeEngine().calculate(points)

    index = MarketIndexEngine().compute(
        gpu, prices, weights,
        change_7d_pct=change.percentage_change_7d, change_30d_pct=change.percentage_change_30d,
    )
    return index.model_dump(mode="json")


@router.get("/market/spread")
def market_spread(gpu: str, region: str | None = None, db=Depends(get_db), _=ApiKeyDep):
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=gpu, region=region, availability="AVAILABLE", limit=2000)
    offers = [repo.to_domain(r) for r in rows]
    prices = [o.gpu_hour_price for o in offers if o.gpu_hour_price is not None]
    return PriceSpreadEngine.compute(gpu, prices).model_dump(mode="json")


@router.get("/market/regional")
def market_regional(gpu: str, db=Depends(get_db), _=ApiKeyDep):
    repo = OfferRepository(db)
    all_rows = repo.list(gpu_model=gpu, availability="AVAILABLE", billing_model="ON_DEMAND", limit=5000)
    all_offers = [repo.to_domain(r) for r in all_rows]
    global_prices = [o.gpu_hour_price for o in all_offers if o.gpu_hour_price is not None]
    global_weights = [o.gpu_count for o in all_offers if o.gpu_hour_price is not None]
    global_index = MarketIndexEngine().compute(gpu, global_prices, global_weights).index_value

    engine = RegionalIndexEngine()
    results = []
    for region in REGIONS:
        regional_offers = [o for o in all_offers if o.region == region]
        prices = [o.gpu_hour_price for o in regional_offers if o.gpu_hour_price is not None]
        weights = [o.gpu_count for o in regional_offers if o.gpu_hour_price is not None]
        if not prices:
            continue
        results.append(engine.compute(region, gpu, prices, weights, global_index).model_dump(mode="json"))

    return {"gpu": gpu, "global_index": global_index, "regions": results}


@router.get("/regions")
def list_regions(_=ApiKeyDep):
    return {
        "count": len(REGIONS),
        "results": [{"code": code, **meta} for code, meta in REGIONS.items()],
    }
