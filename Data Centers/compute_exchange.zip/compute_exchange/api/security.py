"""
Section 64 SECURITY.

- API key authentication via the `X-API-Key` header.
- Simple in-memory sliding-window rate limiting per key (swap for
  Redis-backed limiting in a multi-process deployment).
- Audit logging of every authenticated request.
- Provider credentials are never accessible through any endpoint --
  connectors only expose `redacted_config()` (see connectors/base.py).
"""
import logging
import time
from collections import defaultdict, deque
from typing import Deque, Dict

from fastapi import Depends, Header, HTTPException, Request, status

from config.settings import get_settings

audit_logger = logging.getLogger("compute_exchange.audit")

_request_log: Dict[str, Deque[float]] = defaultdict(deque)


def _rate_limit_ok(api_key: str, limit_per_minute: int) -> bool:
    now = time.time()
    window = _request_log[api_key]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= limit_per_minute:
        return False
    window.append(now)
    return True


async def require_api_key(request: Request, x_api_key: str | None = Header(default=None)) -> str:
    settings = get_settings()

    if not settings.api_key_list:
        # Auth disabled -- development only, per .env.example guidance.
        return "anonymous"

    if not x_api_key or x_api_key not in settings.api_key_list:
        audit_logger.warning("Rejected request to %s: invalid or missing API key", request.url.path)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")

    if not _rate_limit_ok(x_api_key, settings.rate_limit_per_minute):
        audit_logger.warning("Rate limit exceeded for key ending in ...%s", x_api_key[-4:])
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Rate limit exceeded")

    audit_logger.info("%s %s (key ...%s)", request.method, request.url.path, x_api_key[-4:])
    return x_api_key


ApiKeyDep = Depends(require_api_key)
