"""
COMPUTE.EXCHANGE FastAPI application.

Assembles every router (section 37), runs the background market-tick loop
that drives both price_history/alerts and the /ws/market feed, and exposes
GET /health.
"""
import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from alerts.engine import AlertEngine
from api import alerts as alerts_router
from api import gpus as gpus_router
from api import market as market_router
from api import offers as offers_router
from api import pricing as pricing_router
from api import providers as providers_router
from api import rankings as rankings_router
from api import workloads as workloads_router
from config.logging import configure_logging
from config.settings import get_settings
from database.connection import SessionLocal, init_db
from database.repositories.alert_repo import AlertRepository
from database.repositories.offer_repo import OfferRepository
from simulation.market import get_default_simulator
from websocket.market_feed import broadcast_events, router as websocket_router

settings = get_settings()
configure_logging(settings.log_level)
logger = logging.getLogger("compute_exchange")

_background_task: asyncio.Task | None = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global _background_task
    init_db()

    # Seed once if the offers table is empty -- see scripts/seed_synthetic_data.py
    # for the standalone CLI version of this same seeding logic.
    with contextlib.closing(SessionLocal()) as db:
        offer_repo = OfferRepository(db)
        if offer_repo.count() == 0:
            logger.info("Offers table empty -- seeding synthetic market data")
            from scripts.seed_synthetic_data import seed
            seed(db)

    if settings.simulation_enabled:
        _background_task = asyncio.create_task(_market_tick_loop())
        logger.info("Market simulator tick loop started (SIMULATED data -- see section 54)")

    yield

    if _background_task:
        _background_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await _background_task


app = FastAPI(
    title="COMPUTE.EXCHANGE",
    description="Industrial Compute Price Discovery, Comparison & Market Intelligence Platform",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

health_router = APIRouter()


@health_router.get("/health")
def health():
    return {
        "status": "OK",
        "service": "COMPUTE.EXCHANGE",
        "time": datetime.utcnow().isoformat(),
        "simulation_enabled": settings.simulation_enabled,
    }


app.include_router(health_router)
app.include_router(providers_router.router)
app.include_router(gpus_router.router)
app.include_router(offers_router.router)
app.include_router(pricing_router.router)
app.include_router(rankings_router.router)
app.include_router(workloads_router.router)
app.include_router(market_router.router)
app.include_router(alerts_router.router)
app.include_router(websocket_router)


async def _market_tick_loop() -> None:
    """
    Advances the synthetic market (section 55), persists price_history /
    availability changes, raises alerts, and pushes ticks to the
    /ws/market feed. Disabled entirely if SIMULATION_ENABLED=false --
    at that point only real connector ingestion (ingestion/pipeline.py)
    would populate the market.
    """
    simulator = get_default_simulator()
    alert_engine = AlertEngine()

    while True:
        try:
            events = simulator.tick()

            with contextlib.closing(SessionLocal()) as db:
                offer_repo = OfferRepository(db)
                for offer in simulator.get_offers():
                    offer_repo.upsert(offer)
                db.commit()

                if events:
                    alert_repo = AlertRepository(db)
                    for alert in alert_engine.from_market_events(events):
                        alert_repo.create_alert(
                            alert_type=alert.alert_type.value, message=alert.message,
                            severity=alert.severity, gpu_model=alert.gpu_model, region=alert.region,
                            provider_id=alert.provider_id, offer_id=alert.offer_id,
                            threshold_price=alert.threshold_price, observed_value=alert.observed_value,
                        )
                    db.commit()

            await broadcast_events(events)
        except Exception:
            logger.exception("Market tick failed")

        await asyncio.sleep(settings.simulation_tick_seconds)
