"""GET /prices, /prices/latest, /prices/history -- section 37/19."""
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Query

from api.deps import Pagination, freshness_state, get_db
from api.security import ApiKeyDep
from database.repositories.offer_repo import OfferRepository
from database.repositories.price_repo import PriceRepository

router = APIRouter(prefix="/prices", tags=["pricing"])


@router.get("")
def list_prices(pagination: Pagination = Depends(), db=Depends(get_db), _=ApiKeyDep):
    """Normalised price snapshots (the `prices` table) -- always paired with pricing_type/confidence."""
    repo = PriceRepository(db)
    rows = repo.latest(limit=pagination.limit)
    return {
        "count": len(rows),
        "results": [
            {
                "offer_id": r.offer_id,
                "normalised_price": r.normalised_price,
                "normalised_currency": r.normalised_currency,
                "normalised_unit": r.normalised_unit,
                "exchange_rate": r.exchange_rate,
                "pricing_type": r.pricing_type,
                "confidence": r.confidence,
                "updated_at": r.updated_at.isoformat(),
            }
            for r in rows
        ],
    }


@router.get("/latest")
def latest_prices_by_gpu(region: str | None = None, db=Depends(get_db), _=ApiKeyDep):
    """
    Cheapest currently AVAILABLE, ON_DEMAND price per GPU model -- powers the
    market ticker (section 40).
    """
    offer_repo = OfferRepository(db)
    gpu_models = offer_repo.all_gpu_models_in_market()

    results = []
    for gpu_model in gpu_models:
        rows = offer_repo.list(gpu_model=gpu_model, region=region, availability="AVAILABLE", limit=1000)
        if not rows:
            continue
        best = min(rows, key=lambda r: r.price / max(r.gpu_count, 1))
        offer = offer_repo.to_domain(best)
        state, age = freshness_state(offer.observed_at)
        results.append({
            "gpu_model": gpu_model,
            "gpu_hour_price": offer.gpu_hour_price,
            "provider_id": offer.provider_id,
            "region": offer.region,
            "is_simulated": offer.source.startswith("SIMULATED"),
            "freshness_state": state,
            "age_seconds": age,
        })

    results.sort(key=lambda r: r["gpu_model"])
    return {"count": len(results), "results": results}


@router.get("/history")
def price_history(
    offer_id: str | None = None,
    gpu: str | None = None,
    window: str = Query("24H", pattern="^(1H|24H|7D|30D|90D|1Y)$"),
    db=Depends(get_db),
    _=ApiKeyDep,
):
    """Section 19: 1H/24H/7D/30D/90D/1Y price charts, from the append-only price_history log."""
    window_deltas = {
        "1H": timedelta(hours=1), "24H": timedelta(hours=24), "7D": timedelta(days=7),
        "30D": timedelta(days=30), "90D": timedelta(days=90), "1Y": timedelta(days=365),
    }
    since = datetime.utcnow() - window_deltas[window]
    repo = OfferRepository(db)
    rows = repo.price_history(offer_id=offer_id, gpu_model=gpu, since=since, limit=5000)
    return {
        "window": window,
        "count": len(rows),
        "results": [
            {
                "timestamp": r.timestamp.isoformat(),
                "provider_id": r.provider_id,
                "offer_id": r.offer_id,
                "gpu_model": r.gpu_model,
                "region": r.region,
                "price": r.price,
                "currency": r.currency,
                "availability": r.availability,
                "pricing_type": r.pricing_type,
            }
            for r in rows
        ],
    }
