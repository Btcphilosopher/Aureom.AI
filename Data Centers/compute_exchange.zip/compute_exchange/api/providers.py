"""GET /providers, GET /providers/{id} -- section 37."""
from fastapi import APIRouter, Depends, HTTPException

from api.deps import get_db
from api.security import ApiKeyDep
from database.repositories.provider_repo import ProviderRepository

router = APIRouter(prefix="/providers", tags=["providers"])


@router.get("")
def list_providers(category: str | None = None, db=Depends(get_db), _=ApiKeyDep):
    repo = ProviderRepository(db)
    rows = repo.list(category=category)
    return {"count": len(rows), "results": [repo.to_domain(r).model_dump(mode="json") for r in rows]}


@router.get("/{provider_id}")
def get_provider(provider_id: str, db=Depends(get_db), _=ApiKeyDep):
    repo = ProviderRepository(db)
    row = repo.get(provider_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Provider not found")
    # Never expose connector credentials -- only public provider metadata (section 64).
    return repo.to_domain(row).model_dump(mode="json")
