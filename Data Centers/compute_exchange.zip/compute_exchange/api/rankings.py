"""GET /rankings, GET /rankings/cheapest, POST /rank -- sections 18/37/38."""
from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from analytics.ranking import RankingEngine
from api.deps import get_db
from api.security import ApiKeyDep
from database.repositories.offer_repo import OfferRepository
from models.market import ComputeScoreWeights, OptimizationProfileName
from optimization.optimizer import Optimizer
from optimization.profiles import get_profile

router = APIRouter(tags=["rankings"])


@router.get("/rankings")
def rankings(
    gpu: str, region: Optional[str] = None, billing: Optional[str] = None,
    profile: OptimizationProfileName = OptimizationProfileName.BEST_VALUE,
    db=Depends(get_db), _=ApiKeyDep,
):
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=gpu, region=region, billing_model=billing, availability=None, limit=200)
    offers = [repo.to_domain(r) for r in rows]

    opt_profile = get_profile(profile)
    ranked = Optimizer().apply(offers, opt_profile)
    return {"gpu": gpu, "profile": profile.value, "count": len(ranked), "results": [r.model_dump(mode="json") for r in ranked]}


@router.get("/rankings/cheapest")
def cheapest(gpu: str, region: Optional[str] = None, limit: int = 10, db=Depends(get_db), _=ApiKeyDep):
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=gpu, region=region, availability="AVAILABLE", limit=500)
    offers = [repo.to_domain(r) for r in rows]
    ranked = RankingEngine().cheapest(offers)[:limit]
    return {"gpu": gpu, "count": len(ranked), "results": [r.model_dump(mode="json") for r in ranked]}


class RankRequest(BaseModel):
    gpu: str
    region: Optional[str] = None
    billing: Optional[str] = None
    weights: Optional[ComputeScoreWeights] = None
    profile: Optional[OptimizationProfileName] = None
    require_multi_node: bool = False


@router.post("/rank")
def rank(payload: RankRequest, db=Depends(get_db), _=ApiKeyDep):
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=payload.gpu, region=payload.region, billing_model=payload.billing, limit=500)
    offers = [repo.to_domain(r) for r in rows]

    weights = payload.weights
    if weights is None and payload.profile is not None:
        weights = get_profile(payload.profile).weights

    engine = RankingEngine(weights=weights or ComputeScoreWeights())
    ranked = engine.rank(offers, require_multi_node=payload.require_multi_node)
    return {"gpu": payload.gpu, "count": len(ranked), "results": [r.model_dump(mode="json") for r in ranked]}
