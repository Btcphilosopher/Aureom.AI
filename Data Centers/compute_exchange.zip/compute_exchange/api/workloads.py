"""
POST /workloads/calculate, POST /compare -- sections 11, 38, 43, 66, 67.
"""
from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from api.deps import get_db
from api.security import ApiKeyDep
from database.repositories.offer_repo import OfferRepository
from models.pricing import BillingModel, Currency
from models.workload import Workload
from optimization.workload_router import WorkloadRouter

router = APIRouter(tags=["workloads"])


@router.post("/workloads/calculate")
def calculate_workload(workload: Workload, db=Depends(get_db), _=ApiKeyDep):
    """
    Section 43 WORKLOAD ROUTER -- returns BEST PRICE, BEST VALUE, BEST
    RELIABILITY, BEST AVAILABILITY and BEST PERFORMANCE routes for the
    given workload, plus cluster economics (section 44/45).
    """
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=workload.gpu_model, region=workload.region, limit=1000)
    offers = [repo.to_domain(r) for r in rows]

    result = WorkloadRouter().route(workload, offers)
    return result.model_dump(mode="json")


class CompareRequest(BaseModel):
    gpu: str
    count: int
    runtime_hours: float
    region: Optional[str] = None
    billing: Optional[BillingModel] = None
    currency: Currency = Currency.USD


@router.post("/compare")
def compare(payload: CompareRequest, db=Depends(get_db), _=ApiKeyDep):
    """Section 38 COMPARISON API."""
    workload = Workload(
        gpu_model=payload.gpu, gpu_count=payload.count, runtime_hours=payload.runtime_hours,
        region=payload.region, billing_model=payload.billing,
    )
    repo = OfferRepository(db)
    rows = repo.list(gpu_model=payload.gpu, region=payload.region, billing_model=payload.billing.value if payload.billing else None, limit=1000)
    offers = [repo.to_domain(r) for r in rows]

    router_ = WorkloadRouter()
    pool, exact = router_.filter_candidates(workload, offers)

    results = []
    for offer in pool:
        cost = router_.cost_engine.calculate(offer, runtime_hours=payload.runtime_hours)
        results.append({
            "provider": offer.provider_id,
            "offer_id": offer.offer_id,
            "gpu_hour": offer.gpu_hour_price,
            "total_compute": cost.compute_cost,
            "estimated_total": cost.estimated_total,
            "availability": offer.availability.value,
            "is_simulated": offer.source.startswith("SIMULATED"),
        })
    results.sort(key=lambda r: r["estimated_total"])
    for i, r in enumerate(results, start=1):
        r["rank"] = i

    return {"currency": payload.currency.value, "exact_cluster_match": exact, "results": results}
