"""Provider (marketplace participant) domain model."""
from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class ProviderCategory(str, Enum):
    HYPERSCALER = "HYPERSCALER"
    NEOCLOUD = "NEOCLOUD"
    GPU_MARKETPLACE = "GPU_MARKETPLACE"
    BARE_METAL = "BARE_METAL"
    SERVERLESS = "SERVERLESS"
    HPC = "HPC"
    EDGE = "EDGE"


class Provider(BaseModel):
    provider_id: str
    name: str
    category: ProviderCategory
    website: Optional[str] = None
    regions: List[str] = Field(default_factory=list)
    billing_models: List[str] = Field(default_factory=list)
    gpu_models: List[str] = Field(default_factory=list)
    enterprise: bool = False
    marketplace: bool = False
    sla: Optional[str] = Field(None, description="e.g. '99.9%' -- as published by the provider")

    # COMPUTE.EXCHANGE internal scoring -- never presented as an official
    # provider rating. See analytics reliability scoring for methodology.
    reliability_score: Optional[float] = Field(None, ge=0, le=100)
    data_quality_score: Optional[float] = Field(None, ge=0, le=100)

    last_updated: Optional[datetime] = None
