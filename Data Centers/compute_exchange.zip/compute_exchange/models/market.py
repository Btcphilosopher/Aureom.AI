"""Market-level structures: scoring, optimisation profiles, indices, spreads."""
from datetime import datetime
from enum import Enum
from typing import Dict, Optional

from pydantic import BaseModel, Field


class ComputeScoreWeights(BaseModel):
    """Section 16 COMPUTE VALUE SCORE -- weights are always exposed, never hidden."""

    price_weight: float = 0.40
    performance_weight: float = 0.20
    reliability_weight: float = 0.20
    availability_weight: float = 0.10
    network_weight: float = 0.05
    billing_flexibility_weight: float = 0.05

    def normalised(self) -> "ComputeScoreWeights":
        total = (
            self.price_weight
            + self.performance_weight
            + self.reliability_weight
            + self.availability_weight
            + self.network_weight
            + self.billing_flexibility_weight
        )
        if total <= 0:
            return self
        return ComputeScoreWeights(
            price_weight=self.price_weight / total,
            performance_weight=self.performance_weight / total,
            reliability_weight=self.reliability_weight / total,
            availability_weight=self.availability_weight / total,
            network_weight=self.network_weight / total,
            billing_flexibility_weight=self.billing_flexibility_weight / total,
        )


class ComputeScoreResult(BaseModel):
    offer_id: str
    price_score: float
    performance_score: float
    reliability_score: float
    availability_score: float
    network_score: float
    billing_flexibility_score: float
    total_score: float
    weights_used: ComputeScoreWeights


class OptimizationProfileName(str, Enum):
    CHEAPEST = "CHEAPEST"
    FASTEST = "FASTEST"
    MOST_RELIABLE = "MOST_RELIABLE"
    BEST_VALUE = "BEST_VALUE"
    LOWEST_CARBON = "LOWEST_CARBON"
    LOWEST_LATENCY = "LOWEST_LATENCY"
    EUROPEAN_ONLY = "EUROPEAN_ONLY"
    UK_ONLY = "UK_ONLY"
    ENTERPRISE_ONLY = "ENTERPRISE_ONLY"
    CUSTOM = "CUSTOM"


class OptimizationProfile(BaseModel):
    name: OptimizationProfileName = OptimizationProfileName.BEST_VALUE
    weights: ComputeScoreWeights = Field(default_factory=ComputeScoreWeights)
    region_filter: Optional[str] = None
    enterprise_only: bool = False
    max_carbon_intensity: Optional[float] = None
    max_latency_ms: Optional[float] = None


class MarketIndexPoint(BaseModel):
    """Section 21 MARKET INDEX -- weighted market price for one GPU model."""

    gpu_model: str
    index_value: float
    unit: str = "USD/GPU-hour"
    sample_size: int
    methodology: str = "volume-weighted median of AVAILABLE on-demand offers"
    change_7d_pct: Optional[float] = None
    change_30d_pct: Optional[float] = None
    as_of: datetime = Field(default_factory=datetime.utcnow)


class RegionalIndexPoint(BaseModel):
    """Section 22 REGIONAL INDEX."""

    region: str
    gpu_model: str
    index_value: float
    global_index_value: float
    premium_pct: float = Field(..., description="Positive = premium vs global index, negative = discount")
    sample_size: int
    as_of: datetime = Field(default_factory=datetime.utcnow)


class PriceSpreadStats(BaseModel):
    """Section 23/24 PRICE SPREAD & DISTRIBUTION."""

    gpu_model: str
    minimum: float
    p10: float
    p25: float
    median: float
    mean: float
    p75: float
    p90: float
    maximum: float
    std_dev: float
    coefficient_of_variation: float
    sample_size: int
    unit: str = "USD/GPU-hour"
