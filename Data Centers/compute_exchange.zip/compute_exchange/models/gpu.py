"""
Canonical GPU definitions.

New accelerators are added purely as data (see catalogue/gpu_catalogue.py) --
nothing in the pricing/analytics layers needs to change to support a new GPU.
"""
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Manufacturer(str, Enum):
    NVIDIA = "NVIDIA"
    AMD = "AMD"
    INTEL = "INTEL"
    OTHER = "OTHER"


class GPU(BaseModel):
    id: str = Field(..., description="Canonical stable identifier, e.g. 'h100-sxm-80gb'")
    manufacturer: Manufacturer
    model: str = Field(..., description="Human readable model name, e.g. 'H100'")
    architecture: str = Field(..., description="Architecture codename, e.g. 'Hopper'")
    vram_gb: float
    memory_bandwidth_gbps: float
    fp16_tflops: Optional[float] = None
    bf16_tflops: Optional[float] = None
    fp8_tflops: Optional[float] = None
    fp4_tflops: Optional[float] = None
    tensor_cores: Optional[int] = None
    power_watts: Optional[float] = None
    release_year: Optional[int] = None

    model_config = ConfigDict(frozen=True)

    def performance_metric(self, precision: str) -> Optional[float]:
        """Return TFLOPs for a given precision key: fp16, bf16, fp8, fp4."""
        return getattr(self, f"{precision.lower()}_tflops", None)
