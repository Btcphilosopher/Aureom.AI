"""Workload definitions -- what a user actually wants to run."""
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from models.pricing import BillingModel


class UtilisationAssumption(float, Enum):
    P100 = 1.00
    P90 = 0.90
    P80 = 0.80
    P70 = 0.70
    P60 = 0.60


class Workload(BaseModel):
    """Generic compute workload -- section 11 WORKLOAD COST MODEL."""

    gpu_model: str
    gpu_count: int = Field(..., gt=0)
    runtime_hours: float = Field(..., gt=0)
    region: Optional[str] = Field(None, description="e.g. 'EU', 'US-EAST', or 'ANY'")
    storage_tb: float = 0.0
    egress_tb: float = 0.0
    ingress_tb: float = 0.0
    billing_model: Optional[BillingModel] = None  # None == ANY
    multi_node_required: bool = False


class TrainingWorkload(BaseModel):
    """Section 12 AI TRAINING COST MODEL."""

    model_config = ConfigDict(protected_namespaces=())

    model_size_params_b: float = Field(..., description="Model size in billions of parameters")
    gpu_model: str
    gpu_count: int = Field(..., gt=0)
    training_hours: float = Field(..., gt=0)
    utilisation: float = Field(0.9, ge=0.1, le=1.0)
    checkpoint_storage_tb: float = 0.0
    network_traffic_tb: float = 0.0
    region: Optional[str] = None


class InferenceWorkload(BaseModel):
    """Section 13 INFERENCE COST MODEL / section 14 TOKEN ECONOMICS."""

    model_config = ConfigDict(protected_namespaces=())

    model_name: str
    model_size_params_b: Optional[float] = None
    gpu_model: str
    gpu_count: int = Field(..., gt=0)
    requests_per_second: float = Field(..., ge=0)
    avg_input_tokens: int = Field(..., ge=0)
    avg_output_tokens: int = Field(..., ge=0)
    tokens_per_second_per_gpu: float = Field(
        ..., description="Model-assumption throughput. Must be supplied or benchmarked; never invented silently."
    )
    utilisation: float = Field(0.8, ge=0.1, le=1.0)
    runtime_hours: float = Field(730.0, description="Default: one month (24*30.42h)")
    region: Optional[str] = None
