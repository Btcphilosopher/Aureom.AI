"""Canonical ComputeOffer -- the unit every connector must resolve to."""
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field

from models.pricing import BillingModel, Currency


class BillingUnit(str, Enum):
    PER_HOUR = "PER_HOUR"
    PER_GPU_HOUR = "PER_GPU_HOUR"
    PER_SECOND = "PER_SECOND"
    PER_MILLION_TOKENS = "PER_MILLION_TOKENS"
    PER_TB_MONTH = "PER_TB_MONTH"
    PER_TB_EGRESS = "PER_TB_EGRESS"
    PER_CPU_HOUR = "PER_CPU_HOUR"
    PER_GB_RAM_HOUR = "PER_GB_RAM_HOUR"


class AvailabilityState(str, Enum):
    AVAILABLE = "AVAILABLE"
    LIMITED = "LIMITED"
    WAITLIST = "WAITLIST"
    UNKNOWN = "UNKNOWN"
    OUT_OF_STOCK = "OUT_OF_STOCK"


class StorageType(str, Enum):
    NVME = "NVME"
    SSD = "SSD"
    HDD = "HDD"
    NETWORK_BLOCK = "NETWORK_BLOCK"
    OBJECT = "OBJECT"
    NONE = "NONE"


class NetworkFabric(str, Enum):
    ETHERNET = "ETHERNET"
    ROCE = "ROCE"
    INFINIBAND = "INFINIBAND"
    UNKNOWN = "UNKNOWN"


class ComputeOffer(BaseModel):
    offer_id: str
    provider_id: str
    instance_id: str

    gpu_model: Optional[str] = Field(None, description="Canonical GPU.id, null for CPU-only offers")
    gpu_count: int = 0

    cpu_model: Optional[str] = None
    cpu_cores: Optional[int] = None
    ram_gb: Optional[float] = None

    storage_gb: Optional[float] = None
    storage_type: StorageType = StorageType.NONE

    network_gbps: Optional[float] = None
    network_fabric: NetworkFabric = NetworkFabric.UNKNOWN
    multi_node_capable: bool = False

    region: str
    country: Optional[str] = None
    city: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None

    availability: AvailabilityState = AvailabilityState.UNKNOWN

    billing_unit: BillingUnit
    billing_model: BillingModel

    price: float = Field(..., ge=0)
    currency: Currency = Currency.USD

    spot_price: Optional[float] = None
    reserved_price: Optional[float] = None
    on_demand_price: Optional[float] = None

    minimum_term: Optional[str] = Field(None, description="e.g. '1 hour', '1 month'")
    maximum_term: Optional[str] = None

    egress_price_per_tb: Optional[float] = None
    ingress_price_per_tb: Optional[float] = None
    setup_fee: Optional[float] = 0.0
    commitment: Optional[str] = None

    reliability_score: Optional[float] = Field(None, ge=0, le=100)

    # Provenance -- see ingestion/provenance.py
    source: str
    source_url: Optional[str] = None
    parser_version: Optional[str] = None
    observed_at: datetime = Field(default_factory=datetime.utcnow)

    @property
    def gpu_hour_price(self) -> Optional[float]:
        """Instance price divided across GPUs. See pricing/normalizer.py GpuHourEngine."""
        if self.gpu_count and self.gpu_count > 0:
            return round(self.price / self.gpu_count, 6)
        return None
