"""
Pricing primitives shared across the whole engine.

The core philosophy (see README "Product Philosophy"): OBSERVED PRICE,
CALCULATED PRICE and ESTIMATED TOTAL COST are never conflated. Every price
figure that flows through the system carries a `pricing_type`, a `source`,
a `confidence` and a `timestamp`.
"""
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Currency(str, Enum):
    USD = "USD"
    GBP = "GBP"
    EUR = "EUR"
    CAD = "CAD"
    AUD = "AUD"
    JPY = "JPY"
    CHF = "CHF"
    SGD = "SGD"


class PricingType(str, Enum):
    """
    How a price figure was produced -- never mixed silently.

    OBSERVED    -- taken directly from a provider's published rate card / API.
    CALCULATED  -- derived deterministically from observed inputs (e.g. GPU-hour
                   from instance-hour / gpu_count).
    ESTIMATED   -- model-assumption-driven (utilisation, token throughput, etc).
    SIMULATED   -- produced by the market simulator, never a real quote.
    HISTORICAL  -- a past OBSERVED/CALCULATED value replayed from price_history.
    """
    OBSERVED = "OBSERVED"
    CALCULATED = "CALCULATED"
    ESTIMATED = "ESTIMATED"
    SIMULATED = "SIMULATED"
    HISTORICAL = "HISTORICAL"


class BillingModel(str, Enum):
    ON_DEMAND = "ON_DEMAND"
    SPOT = "SPOT"
    PREEMPTIBLE = "PREEMPTIBLE"
    RESERVED = "RESERVED"
    COMMITTED = "COMMITTED"
    DEDICATED = "DEDICATED"
    SERVERLESS = "SERVERLESS"
    AUCTION = "AUCTION"
    NEGOTIATED = "NEGOTIATED"


class ConfidenceLevel(str, Enum):
    HIGH = "HIGH"       # direct provider API / official rate card
    MEDIUM = "MEDIUM"   # scraped / community-reported, cross-checked
    LOW = "LOW"         # single unverified source
    MODELLED = "MODELLED"  # derived/estimated, not observed at all


class PriceRecord(BaseModel):
    """A single normalised price observation, always traceable to its source."""

    original_price: float
    original_currency: Currency
    original_unit: str = Field(..., description="e.g. 'USD/instance-hour', 'USD/1M-tokens'")

    normalised_price: float
    normalised_currency: Currency = Currency.USD
    normalised_unit: str = Field(default="USD/GPU-hour")

    exchange_rate: float = Field(1.0, description="original_currency -> normalised_currency")
    exchange_timestamp: Optional[datetime] = None

    pricing_type: PricingType
    billing_model: BillingModel
    confidence: ConfidenceLevel

    source: str
    observed_at: datetime = Field(default_factory=datetime.utcnow)
