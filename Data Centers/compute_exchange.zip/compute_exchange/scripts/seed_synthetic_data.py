"""
Synthetic test data seeding (section 65).

Populates: 30+ providers, 20 GPU models, 500+ offers across multiple
regions and billing types, plus initial price_history/availability rows
(written automatically by OfferRepository.upsert). Every seeded offer is
tagged `source="SIMULATED:<provider>"` -- section 54 NO FAKE LIVE DATA.

Run standalone:
    python -m scripts.seed_synthetic_data
Or it runs automatically on first API startup if the `offers` table is
empty (see api/main.py on_startup).
"""
import logging

from sqlalchemy.orm import Session

from catalogue.gpu_catalogue import all_gpus
from database.connection import SessionLocal, init_db
from database.repositories.gpu_repo import GPURepository
from database.repositories.offer_repo import OfferRepository
from database.repositories.price_repo import PriceRepository
from database.repositories.provider_repo import ProviderRepository
from ingestion.normalizer import normalize
from ingestion.provenance import source_record
from ingestion.validator import OfferValidationError, validate_offer
from models.pricing import ConfidenceLevel
from simulation.market import MarketSimulator
from simulation.providers import PROVIDER_PROFILES, profile_to_provider

logger = logging.getLogger(__name__)


def seed(db: Session) -> dict:
    gpu_repo = GPURepository(db)
    for gpu in all_gpus():
        gpu_repo.upsert(gpu)

    provider_repo = ProviderRepository(db)
    for profile in PROVIDER_PROFILES:
        provider_repo.upsert(profile_to_provider(profile))
    db.commit()

    simulator = MarketSimulator(seed=42)
    offer_repo = OfferRepository(db)
    price_repo = PriceRepository(db)

    accepted, rejected = 0, 0
    for offer in simulator.get_offers():
        try:
            validate_offer(offer)
        except OfferValidationError as exc:
            rejected += 1
            logger.debug("Skipped invalid seed offer: %s", exc)
            continue
        offer_repo.upsert(offer)
        price_record = normalize(offer, confidence=ConfidenceLevel.MODELLED)
        price_repo.upsert(offer.offer_id, price_record)
        accepted += 1

    for profile in PROVIDER_PROFILES:
        from connectors.base import ConnectorMetadata
        db.add(source_record(ConnectorMetadata(
            provider_id=profile.provider_id, connector_type="simulated",
            source_url=f"https://{profile.provider_id}.example/pricing",
            notes="Synthetic seed data -- see simulation/providers.py",
        )))

    db.commit()

    summary = {
        "providers": len(PROVIDER_PROFILES),
        "gpus": len(all_gpus()),
        "offers_accepted": accepted,
        "offers_rejected": rejected,
    }
    logger.info("Seed complete: %s", summary)
    return summary


def main() -> None:
    from config.logging import configure_logging
    configure_logging("INFO")
    init_db()
    db = SessionLocal()
    try:
        summary = seed(db)
        print(f"[COMPUTE.EXCHANGE] Seeded synthetic market: {summary}")
    finally:
        db.close()


if __name__ == "__main__":
    main()
