"""User objective functions (section 17) -- named presets over ComputeScoreWeights,
plus fully custom weighting."""
from models.market import ComputeScoreWeights, OptimizationProfile, OptimizationProfileName

PROFILE_PRESETS: dict[OptimizationProfileName, OptimizationProfile] = {
    OptimizationProfileName.CHEAPEST: OptimizationProfile(
        name=OptimizationProfileName.CHEAPEST,
        weights=ComputeScoreWeights(
            price_weight=0.85, performance_weight=0.02, reliability_weight=0.05,
            availability_weight=0.05, network_weight=0.01, billing_flexibility_weight=0.02,
        ),
    ),
    OptimizationProfileName.FASTEST: OptimizationProfile(
        name=OptimizationProfileName.FASTEST,
        weights=ComputeScoreWeights(
            price_weight=0.10, performance_weight=0.55, reliability_weight=0.10,
            availability_weight=0.10, network_weight=0.13, billing_flexibility_weight=0.02,
        ),
    ),
    OptimizationProfileName.MOST_RELIABLE: OptimizationProfile(
        name=OptimizationProfileName.MOST_RELIABLE,
        weights=ComputeScoreWeights(
            price_weight=0.15, performance_weight=0.10, reliability_weight=0.55,
            availability_weight=0.15, network_weight=0.03, billing_flexibility_weight=0.02,
        ),
    ),
    OptimizationProfileName.BEST_VALUE: OptimizationProfile(
        name=OptimizationProfileName.BEST_VALUE,
        weights=ComputeScoreWeights(
            price_weight=0.40, performance_weight=0.20, reliability_weight=0.20,
            availability_weight=0.10, network_weight=0.05, billing_flexibility_weight=0.05,
        ),
    ),
    OptimizationProfileName.LOWEST_CARBON: OptimizationProfile(
        name=OptimizationProfileName.LOWEST_CARBON,
        weights=ComputeScoreWeights(
            price_weight=0.30, performance_weight=0.10, reliability_weight=0.15,
            availability_weight=0.10, network_weight=0.05, billing_flexibility_weight=0.05,
        ),
        max_carbon_intensity=200.0,  # gCO2e/kWh -- see carbon.py for how this filters offers
    ),
    OptimizationProfileName.LOWEST_LATENCY: OptimizationProfile(
        name=OptimizationProfileName.LOWEST_LATENCY,
        weights=ComputeScoreWeights(
            price_weight=0.15, performance_weight=0.15, reliability_weight=0.15,
            availability_weight=0.15, network_weight=0.35, billing_flexibility_weight=0.05,
        ),
        max_latency_ms=30.0,
    ),
    OptimizationProfileName.EUROPEAN_ONLY: OptimizationProfile(
        name=OptimizationProfileName.EUROPEAN_ONLY,
        weights=ComputeScoreWeights(),
        region_filter="EU",
    ),
    OptimizationProfileName.UK_ONLY: OptimizationProfile(
        name=OptimizationProfileName.UK_ONLY,
        weights=ComputeScoreWeights(),
        region_filter="UK",
    ),
    OptimizationProfileName.ENTERPRISE_ONLY: OptimizationProfile(
        name=OptimizationProfileName.ENTERPRISE_ONLY,
        weights=ComputeScoreWeights(reliability_weight=0.30, price_weight=0.30, performance_weight=0.20,
                                     availability_weight=0.15, network_weight=0.03, billing_flexibility_weight=0.02),
        enterprise_only=True,
    ),
}


def get_profile(name: OptimizationProfileName) -> OptimizationProfile:
    return PROFILE_PRESETS.get(name, PROFILE_PRESETS[OptimizationProfileName.BEST_VALUE])
