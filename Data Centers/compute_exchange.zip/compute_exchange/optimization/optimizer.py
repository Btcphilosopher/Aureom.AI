"""Applies an OptimizationProfile (filters + weights) to a candidate offer set."""
from typing import Dict, List, Optional, Sequence

from analytics.ranking import RankedOffer, RankingEngine
from models.market import OptimizationProfile
from models.offer import ComputeOffer
from models.provider import Provider


class Optimizer:
    def apply(
        self,
        offers: Sequence[ComputeOffer],
        profile: OptimizationProfile,
        providers_by_id: Optional[Dict[str, Provider]] = None,
        require_multi_node: bool = False,
    ) -> List[RankedOffer]:
        candidates = list(offers)

        if profile.region_filter:
            candidates = [o for o in candidates if o.region == profile.region_filter]

        if profile.enterprise_only and providers_by_id:
            candidates = [
                o for o in candidates
                if providers_by_id.get(o.provider_id) and providers_by_id[o.provider_id].enterprise
            ]

        engine = RankingEngine(weights=profile.weights)
        return engine.rank(candidates, require_multi_node=require_multi_node)
