"""
Workload router (section 43) -- given a workload description, finds the
best routes across BEST PRICE, BEST VALUE, BEST RELIABILITY,
BEST AVAILABILITY and BEST PERFORMANCE, and (section 44/45) exposes
cluster economics: whether a multi-GPU configuration carries a premium
over the same GPU priced individually.
"""
from typing import List, Optional, Sequence

from pydantic import BaseModel

from analytics.ranking import RankingEngine
from models.market import ComputeScoreWeights
from models.offer import AvailabilityState, ComputeOffer
from models.workload import Workload
from pricing.cost_engine import CostBreakdown, CostEngine


class ClusterPremium(BaseModel):
    gpu_model: str
    provider_id: str
    region: str
    single_gpu_hour_price: Optional[float]
    cluster_gpu_hour_price: Optional[float]
    cluster_size: int
    premium_pct: Optional[float]  # positive == multi-GPU costs more per GPU-hour than a single GPU


class RoutedOffer(BaseModel):
    offer_id: str
    provider_id: str
    gpu_model: Optional[str]
    gpu_count: int
    region: str
    availability: AvailabilityState
    cost: CostBreakdown
    total_score: Optional[float] = None


class WorkloadRoutingResult(BaseModel):
    candidates_considered: int
    exact_cluster_match: bool
    best_price: Optional[RoutedOffer]
    best_value: Optional[RoutedOffer]
    best_reliability: Optional[RoutedOffer]
    best_availability: Optional[RoutedOffer]
    best_performance: Optional[RoutedOffer]
    cluster_premium: Optional[ClusterPremium] = None
    notes: List[str] = []


class WorkloadRouter:
    def __init__(self, cost_engine: Optional[CostEngine] = None):
        self.cost_engine = cost_engine or CostEngine()

    def filter_candidates(self, workload: Workload, offers: Sequence[ComputeOffer]) -> tuple[List[ComputeOffer], bool]:
        """Public entry point for callers (e.g. the /compare API) that only need the matched offer pool."""
        return self._filter_candidates(workload, offers)

    def _filter_candidates(self, workload: Workload, offers: Sequence[ComputeOffer]) -> tuple[List[ComputeOffer], bool]:
        pool = [o for o in offers if o.gpu_model == workload.gpu_model]
        if workload.region and workload.region.upper() != "ANY":
            pool = [o for o in pool if o.region == workload.region]
        if workload.billing_model is not None:
            pool = [o for o in pool if o.billing_model == workload.billing_model]
        if workload.multi_node_required:
            pool = [o for o in pool if o.multi_node_capable]

        exact = [o for o in pool if o.gpu_count == workload.gpu_count]
        if exact:
            return exact, True
        return pool, False

    def cluster_premium(self, gpu_model: str, provider_id: str, region: str, offers: Sequence[ComputeOffer]) -> Optional[ClusterPremium]:
        provider_offers = [o for o in offers if o.gpu_model == gpu_model and o.provider_id == provider_id and o.region == region]
        singles = [o for o in provider_offers if o.gpu_count == 1]
        clusters = sorted([o for o in provider_offers if o.gpu_count > 1], key=lambda o: o.gpu_count, reverse=True)
        if not singles or not clusters:
            return None
        single_price = singles[0].gpu_hour_price
        cluster = clusters[0]
        cluster_price = cluster.gpu_hour_price
        premium_pct = (
            round((cluster_price - single_price) / single_price * 100, 2)
            if single_price and cluster_price else None
        )
        return ClusterPremium(
            gpu_model=gpu_model, provider_id=provider_id, region=region,
            single_gpu_hour_price=single_price, cluster_gpu_hour_price=cluster_price,
            cluster_size=cluster.gpu_count, premium_pct=premium_pct,
        )

    def route(self, workload: Workload, offers: Sequence[ComputeOffer]) -> WorkloadRoutingResult:
        pool, exact_match = self._filter_candidates(workload, offers)
        notes: List[str] = []
        if not exact_match and pool:
            notes.append(
                f"No offer exactly matches {workload.gpu_count}x {workload.gpu_model}; "
                "showing the closest available cluster sizes instead."
            )
        if not pool:
            return WorkloadRoutingResult(
                candidates_considered=0, exact_cluster_match=False,
                best_price=None, best_value=None, best_reliability=None,
                best_availability=None, best_performance=None,
                notes=["No matching offers found for this workload's GPU/region/billing constraints."],
            )

        routed: List[RoutedOffer] = []
        for offer in pool:
            cost = self.cost_engine.calculate(
                offer, runtime_hours=workload.runtime_hours, storage_tb=workload.storage_tb,
                egress_tb=workload.egress_tb, ingress_tb=workload.ingress_tb,
            )
            routed.append(RoutedOffer(
                offer_id=offer.offer_id, provider_id=offer.provider_id, gpu_model=offer.gpu_model,
                gpu_count=offer.gpu_count, region=offer.region, availability=offer.availability, cost=cost,
            ))

        best_price = min(routed, key=lambda r: r.cost.estimated_total)

        value_engine = RankingEngine(weights=ComputeScoreWeights())
        ranked_value = value_engine.rank(pool, require_multi_node=workload.multi_node_required)
        best_value = self._match_routed(ranked_value[0].offer_id, routed) if ranked_value else None
        if best_value:
            best_value.total_score = ranked_value[0].score.total_score

        reliability_engine = RankingEngine(weights=ComputeScoreWeights(
            price_weight=0.05, performance_weight=0.05, reliability_weight=0.75,
            availability_weight=0.10, network_weight=0.03, billing_flexibility_weight=0.02,
        ))
        ranked_reliability = reliability_engine.rank(pool)
        best_reliability = self._match_routed(ranked_reliability[0].offer_id, routed) if ranked_reliability else None
        if best_reliability:
            best_reliability.total_score = ranked_reliability[0].score.total_score

        availability_priority = {
            AvailabilityState.AVAILABLE: 0, AvailabilityState.LIMITED: 1,
            AvailabilityState.UNKNOWN: 2, AvailabilityState.WAITLIST: 3,
            AvailabilityState.OUT_OF_STOCK: 4,
        }
        best_availability = min(
            routed, key=lambda r: (availability_priority.get(r.availability, 5), r.cost.estimated_total)
        )

        performance_engine = RankingEngine(weights=ComputeScoreWeights(
            price_weight=0.05, performance_weight=0.75, reliability_weight=0.05,
            availability_weight=0.05, network_weight=0.08, billing_flexibility_weight=0.02,
        ))
        ranked_perf = performance_engine.rank(pool, require_multi_node=workload.multi_node_required)
        best_performance = self._match_routed(ranked_perf[0].offer_id, routed) if ranked_perf else None
        if best_performance:
            best_performance.total_score = ranked_perf[0].score.total_score

        premium = None
        if best_price:
            premium = self.cluster_premium(workload.gpu_model, best_price.provider_id, best_price.region, offers)

        return WorkloadRoutingResult(
            candidates_considered=len(pool),
            exact_cluster_match=exact_match,
            best_price=best_price,
            best_value=best_value,
            best_reliability=best_reliability,
            best_availability=best_availability,
            best_performance=best_performance,
            cluster_premium=premium,
            notes=notes,
        )

    @staticmethod
    def _match_routed(offer_id: str, routed: List[RoutedOffer]) -> Optional[RoutedOffer]:
        return next((r for r in routed if r.offer_id == offer_id), None)
