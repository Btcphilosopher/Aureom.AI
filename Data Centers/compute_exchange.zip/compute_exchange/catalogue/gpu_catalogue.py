"""
Canonical GPU catalogue -- section 4 of the spec.

This is pure data. To add a new GPU, add a new `GPU(...)` entry below; no
other module needs to change. Figures are publicly-published vendor
specifications (or best-available approximations for unreleased/limited
disclosure parts) and are intended for *relative* architectural comparison
(see analytics/benchmarks.py $/TFLOP metrics), not as certified benchmark
results.
"""
from models.gpu import GPU, Manufacturer

_RAW: list[dict] = [
    dict(id="h100-sxm-80gb", manufacturer=Manufacturer.NVIDIA, model="H100", architecture="Hopper",
         vram_gb=80, memory_bandwidth_gbps=3350, fp16_tflops=1979, bf16_tflops=1979, fp8_tflops=3958,
         fp4_tflops=None, tensor_cores=528, power_watts=700, release_year=2022),
    dict(id="h200-sxm-141gb", manufacturer=Manufacturer.NVIDIA, model="H200", architecture="Hopper",
         vram_gb=141, memory_bandwidth_gbps=4800, fp16_tflops=1979, bf16_tflops=1979, fp8_tflops=3958,
         fp4_tflops=None, tensor_cores=528, power_watts=700, release_year=2024),
    dict(id="b100-192gb", manufacturer=Manufacturer.NVIDIA, model="B100", architecture="Blackwell",
         vram_gb=192, memory_bandwidth_gbps=8000, fp16_tflops=1800, bf16_tflops=1800, fp8_tflops=3500,
         fp4_tflops=7000, tensor_cores=None, power_watts=700, release_year=2024),
    dict(id="b200-192gb", manufacturer=Manufacturer.NVIDIA, model="B200", architecture="Blackwell",
         vram_gb=192, memory_bandwidth_gbps=8000, fp16_tflops=2250, bf16_tflops=2250, fp8_tflops=4500,
         fp4_tflops=9000, tensor_cores=None, power_watts=1000, release_year=2024),
    dict(id="b300-288gb", manufacturer=Manufacturer.NVIDIA, model="B300", architecture="Blackwell Ultra",
         vram_gb=288, memory_bandwidth_gbps=8000, fp16_tflops=2500, bf16_tflops=2500, fp8_tflops=5000,
         fp4_tflops=10000, tensor_cores=None, power_watts=1100, release_year=2025),
    dict(id="a100-sxm-80gb", manufacturer=Manufacturer.NVIDIA, model="A100", architecture="Ampere",
         vram_gb=80, memory_bandwidth_gbps=2039, fp16_tflops=312, bf16_tflops=312, fp8_tflops=None,
         fp4_tflops=None, tensor_cores=432, power_watts=400, release_year=2020),
    dict(id="a40-48gb", manufacturer=Manufacturer.NVIDIA, model="A40", architecture="Ampere",
         vram_gb=48, memory_bandwidth_gbps=696, fp16_tflops=149.7, bf16_tflops=149.7, fp8_tflops=None,
         fp4_tflops=None, tensor_cores=336, power_watts=300, release_year=2020),
    dict(id="l40-48gb", manufacturer=Manufacturer.NVIDIA, model="L40", architecture="Ada Lovelace",
         vram_gb=48, memory_bandwidth_gbps=864, fp16_tflops=181, bf16_tflops=181, fp8_tflops=362,
         fp4_tflops=None, tensor_cores=568, power_watts=300, release_year=2022),
    dict(id="l40s-48gb", manufacturer=Manufacturer.NVIDIA, model="L40S", architecture="Ada Lovelace",
         vram_gb=48, memory_bandwidth_gbps=864, fp16_tflops=362, bf16_tflops=362, fp8_tflops=733,
         fp4_tflops=None, tensor_cores=568, power_watts=350, release_year=2023),
    dict(id="rtx4090-24gb", manufacturer=Manufacturer.NVIDIA, model="RTX 4090", architecture="Ada Lovelace",
         vram_gb=24, memory_bandwidth_gbps=1008, fp16_tflops=165.2, bf16_tflops=165.2, fp8_tflops=330.3,
         fp4_tflops=None, tensor_cores=512, power_watts=450, release_year=2022),
    dict(id="rtx5090-32gb", manufacturer=Manufacturer.NVIDIA, model="RTX 5090", architecture="Blackwell",
         vram_gb=32, memory_bandwidth_gbps=1792, fp16_tflops=209.5, bf16_tflops=209.5, fp8_tflops=419,
         fp4_tflops=838, tensor_cores=680, power_watts=575, release_year=2025),
    dict(id="rtxpro6000-96gb", manufacturer=Manufacturer.NVIDIA, model="RTX PRO 6000", architecture="Blackwell",
         vram_gb=96, memory_bandwidth_gbps=1792, fp16_tflops=250, bf16_tflops=250, fp8_tflops=500,
         fp4_tflops=1000, tensor_cores=752, power_watts=600, release_year=2025),
    dict(id="mi300x-192gb", manufacturer=Manufacturer.AMD, model="MI300X", architecture="CDNA 3",
         vram_gb=192, memory_bandwidth_gbps=5300, fp16_tflops=1307, bf16_tflops=1307, fp8_tflops=2615,
         fp4_tflops=None, tensor_cores=None, power_watts=750, release_year=2023),
    dict(id="mi325x-256gb", manufacturer=Manufacturer.AMD, model="MI325X", architecture="CDNA 3",
         vram_gb=256, memory_bandwidth_gbps=6000, fp16_tflops=1307, bf16_tflops=1307, fp8_tflops=2615,
         fp4_tflops=None, tensor_cores=None, power_watts=1000, release_year=2024),
    dict(id="mi350-288gb", manufacturer=Manufacturer.AMD, model="MI350", architecture="CDNA 4",
         vram_gb=288, memory_bandwidth_gbps=8000, fp16_tflops=2300, bf16_tflops=2300, fp8_tflops=4600,
         fp4_tflops=9200, tensor_cores=None, power_watts=1000, release_year=2025),
    dict(id="v100-32gb", manufacturer=Manufacturer.NVIDIA, model="V100", architecture="Volta",
         vram_gb=32, memory_bandwidth_gbps=900, fp16_tflops=125, bf16_tflops=None, fp8_tflops=None,
         fp4_tflops=None, tensor_cores=640, power_watts=300, release_year=2017),
    dict(id="t4-16gb", manufacturer=Manufacturer.NVIDIA, model="T4", architecture="Turing",
         vram_gb=16, memory_bandwidth_gbps=320, fp16_tflops=65, bf16_tflops=None, fp8_tflops=None,
         fp4_tflops=None, tensor_cores=320, power_watts=70, release_year=2018),
    dict(id="a10-24gb", manufacturer=Manufacturer.NVIDIA, model="A10", architecture="Ampere",
         vram_gb=24, memory_bandwidth_gbps=600, fp16_tflops=125, bf16_tflops=125, fp8_tflops=None,
         fp4_tflops=None, tensor_cores=288, power_watts=150, release_year=2021),
    dict(id="a6000-48gb", manufacturer=Manufacturer.NVIDIA, model="A6000", architecture="Ampere",
         vram_gb=48, memory_bandwidth_gbps=768, fp16_tflops=154.8, bf16_tflops=154.8, fp8_tflops=None,
         fp4_tflops=None, tensor_cores=336, power_watts=300, release_year=2020),
    dict(id="l4-24gb", manufacturer=Manufacturer.NVIDIA, model="L4", architecture="Ada Lovelace",
         vram_gb=24, memory_bandwidth_gbps=300, fp16_tflops=121, bf16_tflops=121, fp8_tflops=242,
         fp4_tflops=None, tensor_cores=240, power_watts=72, release_year=2023),
]

GPU_CATALOGUE: dict[str, GPU] = {row["id"]: GPU(**row) for row in _RAW}


def get_gpu(gpu_id: str) -> GPU | None:
    return GPU_CATALOGUE.get(gpu_id)


def gpu_exists(gpu_id: str) -> bool:
    return gpu_id in GPU_CATALOGUE


def all_gpus() -> list[GPU]:
    return list(GPU_CATALOGUE.values())


def find_by_model_name(model_name: str) -> GPU | None:
    """Lenient lookup by human model name, e.g. 'H100' -> h100-sxm-80gb."""
    needle = model_name.strip().lower().replace(" ", "")
    for gpu in GPU_CATALOGUE.values():
        if gpu.model.lower().replace(" ", "") == needle or gpu.id == model_name:
            return gpu
    return None
