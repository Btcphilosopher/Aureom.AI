"""
Total Cost Engine (section 10).

Turns a single offer + a runtime/storage/network/egress envelope into a
full cost breakdown. Every line item is tagged with the PricingType that
produced it, so a caller can always tell an OBSERVED egress rate from an
ESTIMATED storage assumption -- never presented as if it were quoted.
"""
from typing import Dict, Optional

from pydantic import BaseModel

from models.offer import ComputeOffer
from models.pricing import Currency, PricingType

# Default storage rate assumption when a provider doesn't publish one
# separately from the instance price. This is always an ESTIMATE.
DEFAULT_STORAGE_USD_PER_TB_MONTH = 90.0
HOURS_PER_MONTH = 730.0


class CostBreakdown(BaseModel):
    offer_id: str
    provider_id: str
    currency: Currency

    runtime_hours: float
    gpu_count: int

    compute_cost: float
    storage_cost: float
    network_cost: float
    egress_cost: float
    ingress_cost: float
    setup_cost: float
    commitment_cost: float

    estimated_total: float

    effective_gpu_hour: float
    effective_compute_hour: float

    line_item_pricing_type: Dict[str, str]
    notes: list[str] = []


class CostEngine:
    def __init__(self, default_storage_rate_per_tb_month: float = DEFAULT_STORAGE_USD_PER_TB_MONTH):
        self.default_storage_rate = default_storage_rate_per_tb_month

    def calculate(
        self,
        offer: ComputeOffer,
        runtime_hours: float,
        storage_tb: float = 0.0,
        egress_tb: float = 0.0,
        ingress_tb: float = 0.0,
        include_setup_fee: bool = True,
        commitment_months: Optional[float] = None,
    ) -> CostBreakdown:
        notes: list[str] = []
        line_types: Dict[str, str] = {}

        # -- compute --------------------------------------------------
        compute_cost = round(offer.price * runtime_hours, 4)
        line_types["compute_cost"] = PricingType.OBSERVED.value if not offer.source.startswith("SIMULATED") \
            else PricingType.SIMULATED.value

        # -- storage ----------------------------------------------------
        if storage_tb > 0:
            storage_rate = self.default_storage_rate
            line_types["storage_cost"] = PricingType.ESTIMATED.value
            notes.append(
                f"Storage cost assumes ${storage_rate:.2f}/TB-month (no provider-specific rate available)."
            )
            storage_cost = round(storage_rate * storage_tb * (runtime_hours / HOURS_PER_MONTH), 4)
        else:
            storage_cost = 0.0
            line_types["storage_cost"] = PricingType.CALCULATED.value

        # -- network / egress / ingress ---------------------------------
        if egress_tb > 0 and offer.egress_price_per_tb is not None:
            egress_cost = round(offer.egress_price_per_tb * egress_tb, 4)
            line_types["egress_cost"] = PricingType.OBSERVED.value
        elif egress_tb > 0:
            egress_cost = round(egress_tb * 50.0, 4)  # conservative fallback estimate
            line_types["egress_cost"] = PricingType.ESTIMATED.value
            notes.append("Egress cost estimated at $50/TB -- provider does not publish an egress rate.")
        else:
            egress_cost = 0.0
            line_types["egress_cost"] = PricingType.CALCULATED.value

        if ingress_tb > 0 and offer.ingress_price_per_tb is not None:
            ingress_cost = round(offer.ingress_price_per_tb * ingress_tb, 4)
            line_types["ingress_cost"] = PricingType.OBSERVED.value
        else:
            ingress_cost = 0.0
            line_types["ingress_cost"] = PricingType.CALCULATED.value

        network_cost = 0.0  # reserved for future dedicated-bandwidth line items
        line_types["network_cost"] = PricingType.CALCULATED.value

        # -- setup / commitment ------------------------------------------
        setup_cost = round(offer.setup_fee or 0.0, 4) if include_setup_fee else 0.0
        line_types["setup_cost"] = PricingType.OBSERVED.value

        commitment_cost = 0.0
        if commitment_months and offer.reserved_price:
            commitment_cost = round(offer.reserved_price * HOURS_PER_MONTH * commitment_months, 4)
            line_types["commitment_cost"] = PricingType.CALCULATED.value
            notes.append(f"Commitment cost calculated over {commitment_months} month(s) at the reserved rate.")
        else:
            line_types["commitment_cost"] = PricingType.CALCULATED.value

        estimated_total = round(
            compute_cost + storage_cost + network_cost + egress_cost + ingress_cost + setup_cost + commitment_cost, 4
        )

        effective_gpu_hour = round(estimated_total / (offer.gpu_count * runtime_hours), 6) \
            if offer.gpu_count and runtime_hours else 0.0
        effective_compute_hour = round(estimated_total / runtime_hours, 6) if runtime_hours else 0.0

        return CostBreakdown(
            offer_id=offer.offer_id,
            provider_id=offer.provider_id,
            currency=offer.currency,
            runtime_hours=runtime_hours,
            gpu_count=offer.gpu_count,
            compute_cost=compute_cost,
            storage_cost=storage_cost,
            network_cost=network_cost,
            egress_cost=egress_cost,
            ingress_cost=ingress_cost,
            setup_cost=setup_cost,
            commitment_cost=commitment_cost,
            estimated_total=estimated_total,
            effective_gpu_hour=effective_gpu_hour,
            effective_compute_hour=effective_compute_hour,
            line_item_pricing_type=line_types,
            notes=notes,
        )
