"""
Currency conversion (section 8).

Exchange rates are kept entirely separate from provider pricing data, and
an offer's `original_price` / `original_currency` are never mutated -- only
a derived, clearly-labelled normalised figure is produced alongside them.

The static table below is an illustrative snapshot for the development /
simulated market. In production, replace `CurrencyConverter._rates` with a
feed from a real FX data provider (refreshed on a schedule) without
changing any caller -- everything downstream only calls `.convert()`.
"""
from datetime import datetime
from typing import Dict, Tuple

from models.pricing import Currency


class CurrencyConverter:
    # Illustrative USD-quoted rates (units of currency per 1 USD), snapshot
    # timestamp below. NOT a live feed.
    _RATES_PER_USD: Dict[Currency, float] = {
        Currency.USD: 1.0,
        Currency.GBP: 0.79,
        Currency.EUR: 0.92,
        Currency.CAD: 1.37,
        Currency.AUD: 1.52,
        Currency.JPY: 149.50,
        Currency.CHF: 0.88,
        Currency.SGD: 1.34,
    }
    _SNAPSHOT_AT = datetime(2026, 1, 1)

    def __init__(self, rates_per_usd: Dict[Currency, float] | None = None, as_of: datetime | None = None):
        self._rates = dict(rates_per_usd or self._RATES_PER_USD)
        self._as_of = as_of or self._SNAPSHOT_AT

    def rate(self, from_currency: Currency, to_currency: Currency) -> float:
        """Units of to_currency per 1 unit of from_currency."""
        if from_currency == to_currency:
            return 1.0
        usd_per_from = 1.0 / self._rates[from_currency]
        return usd_per_from * self._rates[to_currency]

    def convert(self, amount: float, from_currency: Currency, to_currency: Currency) -> Tuple[float, float, datetime]:
        """Returns (converted_amount, exchange_rate_used, exchange_timestamp). Pure function -- no mutation."""
        rate = self.rate(from_currency, to_currency)
        return round(amount * rate, 6), rate, self._as_of
