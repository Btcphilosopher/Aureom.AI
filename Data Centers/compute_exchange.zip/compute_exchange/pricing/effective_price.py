"""
Effective compute price (section 48) and risk adjustment -- the last two
rungs of the pricing hierarchy described in section 69:

    ADVERTISED RATE -> NORMALISED RATE -> WORKLOAD COST -> EFFECTIVE COST
        -> PERFORMANCE-ADJUSTED COST -> RISK-ADJUSTED COST
"""
from typing import Optional

from pydantic import BaseModel


class EffectivePriceResult(BaseModel):
    effective_gpu_hour: float
    components: dict


def effective_compute_price(
    compute: float,
    storage: float = 0.0,
    networking: float = 0.0,
    egress: float = 0.0,
    commitment: float = 0.0,
    estimated_overhead: float = 0.0,
    gpu_count: int = 1,
    runtime_hours: float = 1.0,
) -> EffectivePriceResult:
    """
    effective cost = compute + storage + networking + egress + commitment + estimated_overhead
    effective $/GPU-hour = effective cost / (gpu_count * runtime_hours)
    """
    total = compute + storage + networking + egress + commitment + estimated_overhead
    denominator = max(gpu_count, 1) * max(runtime_hours, 1e-9)
    return EffectivePriceResult(
        effective_gpu_hour=round(total / denominator, 6),
        components={
            "compute": compute,
            "storage": storage,
            "networking": networking,
            "egress": egress,
            "commitment": commitment,
            "estimated_overhead": estimated_overhead,
            "total": round(total, 6),
        },
    )


def risk_adjusted_price(
    effective_gpu_hour: float,
    reliability_score: Optional[float],
    availability_penalty: float = 0.0,
) -> float:
    """
    A heuristic, clearly-labelled ESTIMATE that inflates the effective price
    to account for provider reliability and availability risk -- e.g. a
    cheap but unreliable/limited-availability offer carries hidden
    operational risk that a raw price comparison hides (section 28/69).

    risk_multiplier = 1 + (1 - reliability/100) * 0.5 + availability_penalty

    A reliability_score of 100 and no availability penalty leaves the price
    unchanged; a reliability_score of 60 inflates it by ~20%.
    """
    reliability = reliability_score if reliability_score is not None else 85.0
    risk_multiplier = 1.0 + (1.0 - reliability / 100.0) * 0.5 + availability_penalty
    return round(effective_gpu_hour * risk_multiplier, 6)
