"""
Workload cost model (section 11), AI training cost model (section 12),
inference cost model (section 13), and token economics (section 14).

Every figure produced here that depends on a modelling assumption
(utilisation, tokens/sec throughput, storage rate) is explicitly labelled
as such in the result's `notes` / `assumptions` -- never presented as an
observed price.
"""
from typing import List, Optional

from pydantic import BaseModel, ConfigDict

from models.offer import ComputeOffer
from models.workload import InferenceWorkload, TrainingWorkload, Workload
from pricing.cost_engine import DEFAULT_STORAGE_USD_PER_TB_MONTH, HOURS_PER_MONTH, CostBreakdown, CostEngine

DEFAULT_NETWORK_EGRESS_RATE_USD_PER_TB = 50.0
HOURS_PER_YEAR = 8760.0


class WorkloadCostEngine:
    """Section 11 -- generic WORKLOAD -> BASE COMPUTE / STORAGE / EGRESS / TOTAL / EFFECTIVE GPU-HOUR."""

    def __init__(self, cost_engine: Optional[CostEngine] = None):
        self.cost_engine = cost_engine or CostEngine()

    def calculate(self, workload: Workload, offer: ComputeOffer) -> CostBreakdown:
        return self.cost_engine.calculate(
            offer=offer,
            runtime_hours=workload.runtime_hours,
            storage_tb=workload.storage_tb,
            egress_tb=workload.egress_tb,
            ingress_tb=workload.ingress_tb,
        )


class TrainingCostResult(BaseModel):
    offer_id: str
    gpu_model: str
    gpu_count: int
    training_hours: float
    utilisation: float

    gpu_cost: float
    storage_cost: float
    network_cost: float
    estimated_training_cost: float

    cost_per_training_hour: float
    cost_per_gpu_hour_billed: float
    cost_per_gpu_hour_effective: float  # idle-adjusted: billed_rate / utilisation

    assumptions: List[str]


class TrainingCostModel:
    """Section 12 -- AI TRAINING COST MODEL."""

    def calculate(
        self,
        workload: TrainingWorkload,
        gpu_hour_price: float,
        offer_id: str = "n/a",
        storage_rate_per_tb_month: float = DEFAULT_STORAGE_USD_PER_TB_MONTH,
        network_rate_per_tb: float = DEFAULT_NETWORK_EGRESS_RATE_USD_PER_TB,
    ) -> TrainingCostResult:
        assumptions = [
            f"GPU utilisation assumption: {workload.utilisation * 100:.0f}%.",
            f"Checkpoint storage costed at ${storage_rate_per_tb_month:.2f}/TB-month (ESTIMATED).",
            f"Network traffic costed at ${network_rate_per_tb:.2f}/TB (ESTIMATED).",
        ]

        gpu_cost = round(gpu_hour_price * workload.gpu_count * workload.training_hours, 4)
        storage_cost = round(
            storage_rate_per_tb_month * workload.checkpoint_storage_tb * (workload.training_hours / HOURS_PER_MONTH), 4
        )
        network_cost = round(network_rate_per_tb * workload.network_traffic_tb, 4)
        estimated_training_cost = round(gpu_cost + storage_cost + network_cost, 4)

        cost_per_training_hour = round(estimated_training_cost / workload.training_hours, 6) \
            if workload.training_hours else 0.0
        cost_per_gpu_hour_effective = round(gpu_hour_price / workload.utilisation, 6) if workload.utilisation else gpu_hour_price

        return TrainingCostResult(
            offer_id=offer_id,
            gpu_model=workload.gpu_model,
            gpu_count=workload.gpu_count,
            training_hours=workload.training_hours,
            utilisation=workload.utilisation,
            gpu_cost=gpu_cost,
            storage_cost=storage_cost,
            network_cost=network_cost,
            estimated_training_cost=estimated_training_cost,
            cost_per_training_hour=cost_per_training_hour,
            cost_per_gpu_hour_billed=round(gpu_hour_price, 6),
            cost_per_gpu_hour_effective=cost_per_gpu_hour_effective,
            assumptions=assumptions,
        )


def cost_per_million_tokens(gpu_hour_price: float, tokens_per_second: float, utilisation: float) -> float:
    """
    Section 14 TOKEN ECONOMICS.

    cost_per_million_tokens(gpu_hour_price, tokens_per_second, utilisation)

    `tokens_per_second` is the raw (100% utilisation) throughput of a single
    GPU for the model in question -- an ESTIMATED model assumption unless
    it comes from a measured benchmark. The result is always labelled a
    model assumption by the caller (InferenceCostModel), never a quoted rate.
    """
    if tokens_per_second <= 0 or utilisation <= 0:
        return 0.0
    effective_tokens_per_second = tokens_per_second * utilisation
    tokens_per_hour = effective_tokens_per_second * 3600
    if tokens_per_hour <= 0:
        return 0.0
    cost_per_token = gpu_hour_price / tokens_per_hour
    return round(cost_per_token * 1_000_000, 6)


class InferenceCostResult(BaseModel):
    model_config = ConfigDict(protected_namespaces=())

    offer_id: str
    model_name: str
    gpu_model: str
    gpu_count: int

    gpu_cost_per_hour: float
    cost_per_request: float
    cost_per_million_tokens: float
    monthly_cost: float
    annual_cost: float

    capacity_tokens_per_second: float
    demand_tokens_per_second: float
    capacity_utilisation_ratio: Optional[float]

    assumptions: List[str]


class InferenceCostModel:
    """Section 13 -- INFERENCE COST MODEL, built on the token economics function above."""

    def calculate(
        self, workload: InferenceWorkload, gpu_hour_price: float, offer_id: str = "n/a",
    ) -> InferenceCostResult:
        assumptions = [
            f"Throughput assumption: {workload.tokens_per_second_per_gpu:.1f} tokens/sec/GPU at 100% utilisation "
            "(model assumption -- supply your own benchmark for higher confidence).",
            f"GPU utilisation assumption: {workload.utilisation * 100:.0f}%.",
        ]

        gpu_cost_per_hour = round(gpu_hour_price * workload.gpu_count, 6)

        per_gpu_cost_per_million = cost_per_million_tokens(
            gpu_hour_price, workload.tokens_per_second_per_gpu, workload.utilisation
        )

        tokens_per_request = workload.avg_input_tokens + workload.avg_output_tokens
        cost_per_request = round((tokens_per_request / 1_000_000) * per_gpu_cost_per_million, 8)

        monthly_cost = round(gpu_cost_per_hour * workload.runtime_hours, 4)
        annual_cost = round(gpu_cost_per_hour * HOURS_PER_YEAR, 4)

        capacity_tokens_per_second = round(
            workload.tokens_per_second_per_gpu * workload.gpu_count * workload.utilisation, 2
        )
        demand_tokens_per_second = round(workload.requests_per_second * tokens_per_request, 2)
        capacity_ratio = (
            round(demand_tokens_per_second / capacity_tokens_per_second, 4)
            if capacity_tokens_per_second > 0 else None
        )
        if capacity_ratio is not None and capacity_ratio > 1.0:
            assumptions.append(
                "WARNING: modelled demand exceeds modelled capacity at this GPU count -- "
                "additional GPUs would be required to sustain this request rate."
            )

        return InferenceCostResult(
            offer_id=offer_id,
            model_name=workload.model_name,
            gpu_model=workload.gpu_model,
            gpu_count=workload.gpu_count,
            gpu_cost_per_hour=gpu_cost_per_hour,
            cost_per_request=cost_per_request,
            cost_per_million_tokens=per_gpu_cost_per_million,
            monthly_cost=monthly_cost,
            annual_cost=annual_cost,
            capacity_tokens_per_second=capacity_tokens_per_second,
            demand_tokens_per_second=demand_tokens_per_second,
            capacity_utilisation_ratio=capacity_ratio,
            assumptions=assumptions,
        )
