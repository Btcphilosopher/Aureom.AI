"""
Price normalisation (section 8) and the GPU-hour engine (section 9).

Converts whatever unit/currency a provider publishes into COMPUTE.EXCHANGE's
canonical units, while always retaining the original figures alongside the
normalised one (models.pricing.PriceRecord).
"""
from datetime import datetime

from models.offer import BillingUnit, ComputeOffer
from models.pricing import BillingModel, ConfidenceLevel, Currency, PriceRecord, PricingType
from pricing.currency import CurrencyConverter

# Canonical unit each BillingUnit normalises to.
_CANONICAL_UNIT = {
    BillingUnit.PER_HOUR: "USD/GPU-hour",       # instance price divided by gpu_count when gpu_count > 0
    BillingUnit.PER_GPU_HOUR: "USD/GPU-hour",
    BillingUnit.PER_SECOND: "USD/GPU-hour",
    BillingUnit.PER_MILLION_TOKENS: "USD/1M-tokens",
    BillingUnit.PER_TB_MONTH: "USD/TB-month",
    BillingUnit.PER_TB_EGRESS: "USD/TB-egress",
    BillingUnit.PER_CPU_HOUR: "USD/CPU-hour",
    BillingUnit.PER_GB_RAM_HOUR: "USD/GB-RAM-hour",
}


class GpuHourEngine:
    """
    Section 9: gpu_hour_price = total_hourly_price / gpu_count, while
    keeping the *instance* hourly price around too -- the two must never be
    silently conflated.
    """

    @staticmethod
    def instance_hourly_price(offer: ComputeOffer) -> float:
        return offer.price

    @staticmethod
    def gpu_hourly_price(offer: ComputeOffer) -> float | None:
        if offer.gpu_count and offer.gpu_count > 0:
            return round(offer.price / offer.gpu_count, 6)
        return None


class PriceNormalizer:
    def __init__(self, converter: CurrencyConverter | None = None, base_currency: Currency = Currency.USD):
        self.converter = converter or CurrencyConverter()
        self.base_currency = base_currency

    def normalize_offer(
        self, offer: ComputeOffer, confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM,
    ) -> PriceRecord:
        canonical_unit = _CANONICAL_UNIT.get(offer.billing_unit, "USD/GPU-hour")

        if offer.billing_unit == BillingUnit.PER_SECOND:
            raw_hourly = offer.price * 3600
        else:
            raw_hourly = offer.price

        if canonical_unit == "USD/GPU-hour" and offer.gpu_count and offer.gpu_count > 0:
            raw_value = raw_hourly / offer.gpu_count
        else:
            raw_value = raw_hourly

        converted, rate, ts = self.converter.convert(raw_value, offer.currency, self.base_currency)

        pricing_type = PricingType.SIMULATED if offer.source.startswith("SIMULATED") else PricingType.OBSERVED

        return PriceRecord(
            original_price=offer.price,
            original_currency=offer.currency,
            original_unit=f"{offer.currency.value}/{offer.billing_unit.value.lower()}",
            normalised_price=converted,
            normalised_currency=self.base_currency,
            normalised_unit=canonical_unit,
            exchange_rate=rate,
            exchange_timestamp=ts,
            pricing_type=pricing_type,
            billing_model=offer.billing_model,
            confidence=confidence,
            source=offer.source,
            observed_at=offer.observed_at,
        )
