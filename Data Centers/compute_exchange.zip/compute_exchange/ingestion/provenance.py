"""
Provenance (section 32) -- every offer must retain provider, source,
source_url, retrieved_at and parser_version so the platform can always
answer "where did this number come from?".
"""
from datetime import datetime

from connectors.base import ConnectorMetadata
from database.orm import SourceORM
from models.offer import ComputeOffer


def stamp_provenance(offer: ComputeOffer, metadata: ConnectorMetadata) -> ComputeOffer:
    """Returns a copy of `offer` with provenance fields filled from connector metadata."""
    return offer.model_copy(update={
        "source": offer.source or metadata.provider_id,
        "source_url": offer.source_url or metadata.source_url,
        "parser_version": offer.parser_version or metadata.parser_version,
        "observed_at": offer.observed_at or datetime.utcnow(),
    })


def source_record(metadata: ConnectorMetadata) -> SourceORM:
    """Builds a `sources` table row describing where a connector's data comes from."""
    return SourceORM(
        source_id=f"{metadata.provider_id}:{metadata.connector_type}",
        provider_id=metadata.provider_id,
        name=f"{metadata.provider_id} ({metadata.connector_type})",
        url=metadata.source_url,
        connector_type=metadata.connector_type,
        last_fetched_at=datetime.utcnow(),
        parser_version=metadata.parser_version,
        reliability_note=metadata.notes,
    )
