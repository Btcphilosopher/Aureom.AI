"""
Ingestion pipeline (section 34):

    SOURCE -> RAW RECORD -> PARSER -> NORMALISER -> VALIDATOR ->
    CANONICAL OFFER -> PRICE DATABASE -> ANALYTICS -> API

Raw connector output (already parsed into canonical ComputeOffer objects by
the connector) is validated, normalised into the `prices` snapshot table,
and persisted -- with price_history/availability logs appended
automatically by OfferRepository (never overwritten, per section 19).
"""
import logging
from dataclasses import dataclass, field
from typing import List

from sqlalchemy.orm import Session

from connectors.base import ProviderConnector
from database.repositories.offer_repo import OfferRepository
from database.repositories.price_repo import PriceRepository
from database.repositories.provider_repo import ProviderRepository
from ingestion.normalizer import normalize
from ingestion.provenance import source_record, stamp_provenance
from ingestion.validator import OfferValidationError, validate_offer
from models.pricing import ConfidenceLevel
from models.provider import Provider, ProviderCategory

logger = logging.getLogger(__name__)


@dataclass
class IngestionResult:
    provider_id: str
    fetched: int = 0
    accepted: int = 0
    rejected: int = 0
    rejection_reasons: List[str] = field(default_factory=list)


class IngestionPipeline:
    def __init__(self, db: Session):
        self.db = db
        self.offer_repo = OfferRepository(db)
        self.price_repo = PriceRepository(db)
        self.provider_repo = ProviderRepository(db)

    async def ingest(self, connector: ProviderConnector, confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM) -> IngestionResult:
        result = IngestionResult(provider_id=connector.metadata.provider_id)

        meta = await connector.fetch_metadata()
        self._ensure_provider(connector.metadata.provider_id, meta)

        raw_offers = await connector.fetch_offers()
        result.fetched = len(raw_offers)

        for raw_offer in raw_offers:
            offer = stamp_provenance(raw_offer, connector.metadata)
            try:
                validate_offer(offer)
            except OfferValidationError as exc:
                result.rejected += 1
                result.rejection_reasons.append(str(exc))
                logger.warning("Rejected offer %s: %s", offer.offer_id, exc)
                continue

            self.offer_repo.upsert(offer)
            price_record = normalize(offer, confidence=confidence)
            self.price_repo.upsert(offer.offer_id, price_record)
            result.accepted += 1

        self.db.add(source_record(connector.metadata))
        self.db.commit()
        return result

    def _ensure_provider(self, provider_id: str, meta: dict) -> None:
        if self.provider_repo.get(provider_id) is not None:
            return
        category = meta.get("category", ProviderCategory.NEOCLOUD.value)
        try:
            category_enum = ProviderCategory(category)
        except ValueError:
            category_enum = ProviderCategory.NEOCLOUD
        provider = Provider(
            provider_id=provider_id,
            name=meta.get("name", provider_id),
            category=category_enum,
            regions=meta.get("regions", []),
            gpu_models=meta.get("gpu_models", []),
        )
        self.provider_repo.upsert(provider)

    async def ingest_many(self, connectors: List[ProviderConnector]) -> List[IngestionResult]:
        return [await self.ingest(c) for c in connectors]
