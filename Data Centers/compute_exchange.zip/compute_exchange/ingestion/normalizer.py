"""
Ingestion-side normalisation step (section 34: RAW RECORD -> PARSER ->
NORMALISER -> VALIDATOR -> CANONICAL OFFER). Connectors already do
parsing/unit-mapping into a canonical ComputeOffer; this module's job is
the currency/unit normalisation pass that produces the PriceRecord stored
in the fast-read `prices` table -- see pricing/normalizer.py for the
actual conversion logic, which this simply wraps for the pipeline.
"""
from models.offer import ComputeOffer
from models.pricing import ConfidenceLevel, PriceRecord
from pricing.normalizer import PriceNormalizer

_normalizer = PriceNormalizer()


def normalize(offer: ComputeOffer, confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM) -> PriceRecord:
    return _normalizer.normalize_offer(offer, confidence=confidence)
