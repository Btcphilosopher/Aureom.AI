"""
Data validation (section 33).

Malformed records are rejected outright -- never silently repaired. A
caller that wants to know *why* a record was rejected gets a list of
specific reasons; there is no auto-correction path.
"""
from datetime import datetime, timedelta
from typing import Iterable, List

from catalogue.gpu_catalogue import gpu_exists
from models.offer import ComputeOffer

KNOWN_REGIONS = {"UK", "EU", "US-EAST", "US-WEST", "ASIA", "MIDDLE-EAST"}


class OfferValidationError(ValueError):
    def __init__(self, offer_id: str, reasons: List[str]):
        self.offer_id = offer_id
        self.reasons = reasons
        super().__init__(f"Offer {offer_id!r} failed validation: {'; '.join(reasons)}")


def validate_offer(offer: ComputeOffer, known_regions: Iterable[str] = KNOWN_REGIONS) -> None:
    """Raises OfferValidationError if `offer` is not fit to insert."""
    reasons: List[str] = []

    if offer.gpu_model is not None and not gpu_exists(offer.gpu_model):
        reasons.append(f"unknown GPU model '{offer.gpu_model}' -- not present in the canonical catalogue")

    if offer.gpu_model is not None and offer.gpu_count <= 0:
        reasons.append("gpu_count must be > 0 for a GPU-bearing offer")

    if offer.price < 0:
        reasons.append("price must be >= 0")

    if offer.region not in known_regions:
        reasons.append(f"unrecognised region '{offer.region}'")

    now = datetime.utcnow()
    if offer.observed_at > now + timedelta(minutes=5):
        reasons.append("observed_at is in the future")
    if offer.observed_at < now - timedelta(days=3650):
        reasons.append("observed_at is implausibly old")

    if not offer.provider_id:
        reasons.append("provider_id is required")
    if not offer.source:
        reasons.append("source is required for provenance")

    if reasons:
        raise OfferValidationError(offer.offer_id, reasons)
