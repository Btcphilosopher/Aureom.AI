# Migrations

This project ships with a working schema created directly from the ORM
(`database.connection.init_db()`), which is sufficient for development on
SQLite.

For production on PostgreSQL, wire up Alembic against `database.base.Base.metadata`:

```bash
pip install alembic
alembic init database/migrations
# In alembic.ini set sqlalchemy.url to your PostgreSQL DSN (or read it from
# config.settings.get_settings().database_url in env.py).
# In migrations/env.py:
#   from database.base import Base
#   import database.orm  # noqa -- registers all tables
#   target_metadata = Base.metadata
alembic revision --autogenerate -m "initial schema"
alembic upgrade head
```

Because every repository in `database/repositories/` talks to the ORM
through the SQLAlchemy Core query builder (no raw SQL, no SQLite-specific
functions), switching `DATABASE_URL` from `sqlite:///...` to
`postgresql+psycopg2://...` requires no application code changes.
