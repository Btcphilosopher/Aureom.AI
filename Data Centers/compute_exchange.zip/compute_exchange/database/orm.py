"""
SQLAlchemy ORM tables.

Table list matches section 35 of the spec: providers, gpus, regions, offers,
prices, price_history, availability, benchmarks, workloads, rankings,
alerts, sources.

`offers` holds the current canonical state of each offer; `price_history`
and `availability` are append-only logs -- prices are never overwritten,
only superseded (section 19).
"""
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    Index,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database.base import Base


class ProviderORM(Base):
    __tablename__ = "providers"

    provider_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    category: Mapped[str] = mapped_column(String(32))
    website: Mapped[str | None] = mapped_column(String(256), nullable=True)
    regions: Mapped[list] = mapped_column(JSON, default=list)
    billing_models: Mapped[list] = mapped_column(JSON, default=list)
    gpu_models: Mapped[list] = mapped_column(JSON, default=list)
    enterprise: Mapped[bool] = mapped_column(Boolean, default=False)
    marketplace: Mapped[bool] = mapped_column(Boolean, default=False)
    sla: Mapped[str | None] = mapped_column(String(32), nullable=True)
    reliability_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    data_quality_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_updated: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    offers: Mapped[list["OfferORM"]] = relationship(back_populates="provider")


class GPUORM(Base):
    __tablename__ = "gpus"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    manufacturer: Mapped[str] = mapped_column(String(16))
    model: Mapped[str] = mapped_column(String(64))
    architecture: Mapped[str] = mapped_column(String(64))
    vram_gb: Mapped[float] = mapped_column(Float)
    memory_bandwidth_gbps: Mapped[float] = mapped_column(Float)
    fp16_tflops: Mapped[float | None] = mapped_column(Float, nullable=True)
    bf16_tflops: Mapped[float | None] = mapped_column(Float, nullable=True)
    fp8_tflops: Mapped[float | None] = mapped_column(Float, nullable=True)
    fp4_tflops: Mapped[float | None] = mapped_column(Float, nullable=True)
    tensor_cores: Mapped[int | None] = mapped_column(Integer, nullable=True)
    power_watts: Mapped[float | None] = mapped_column(Float, nullable=True)
    release_year: Mapped[int | None] = mapped_column(Integer, nullable=True)


class RegionORM(Base):
    __tablename__ = "regions"

    code: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(64))
    country: Mapped[str | None] = mapped_column(String(64), nullable=True)
    continent: Mapped[str | None] = mapped_column(String(32), nullable=True)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)


class OfferORM(Base):
    __tablename__ = "offers"

    offer_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    provider_id: Mapped[str] = mapped_column(ForeignKey("providers.provider_id"), index=True)
    instance_id: Mapped[str] = mapped_column(String(128))

    gpu_model: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    gpu_count: Mapped[int] = mapped_column(Integer, default=0)

    cpu_model: Mapped[str | None] = mapped_column(String(128), nullable=True)
    cpu_cores: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ram_gb: Mapped[float | None] = mapped_column(Float, nullable=True)

    storage_gb: Mapped[float | None] = mapped_column(Float, nullable=True)
    storage_type: Mapped[str] = mapped_column(String(16), default="NONE")

    network_gbps: Mapped[float | None] = mapped_column(Float, nullable=True)
    network_fabric: Mapped[str] = mapped_column(String(16), default="UNKNOWN")
    multi_node_capable: Mapped[bool] = mapped_column(Boolean, default=False)

    region: Mapped[str] = mapped_column(String(32), index=True)
    country: Mapped[str | None] = mapped_column(String(64), nullable=True)
    city: Mapped[str | None] = mapped_column(String(64), nullable=True)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)

    availability: Mapped[str] = mapped_column(String(16), default="UNKNOWN")

    billing_unit: Mapped[str] = mapped_column(String(32))
    billing_model: Mapped[str] = mapped_column(String(32), index=True)

    price: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(8), default="USD")

    spot_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    reserved_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    on_demand_price: Mapped[float | None] = mapped_column(Float, nullable=True)

    minimum_term: Mapped[str | None] = mapped_column(String(32), nullable=True)
    maximum_term: Mapped[str | None] = mapped_column(String(32), nullable=True)

    egress_price_per_tb: Mapped[float | None] = mapped_column(Float, nullable=True)
    ingress_price_per_tb: Mapped[float | None] = mapped_column(Float, nullable=True)
    setup_fee: Mapped[float] = mapped_column(Float, default=0.0)
    commitment: Mapped[str | None] = mapped_column(String(64), nullable=True)

    reliability_score: Mapped[float | None] = mapped_column(Float, nullable=True)

    source: Mapped[str] = mapped_column(String(64))
    source_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    parser_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    observed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    provider: Mapped["ProviderORM"] = relationship(back_populates="offers")

    __table_args__ = (
        Index("ix_offers_gpu_region_billing", "gpu_model", "region", "billing_model"),
    )


class PriceORM(Base):
    """Latest normalised price snapshot per offer -- fast reads for 'latest prices'."""

    __tablename__ = "prices"

    offer_id: Mapped[str] = mapped_column(ForeignKey("offers.offer_id"), primary_key=True)
    normalised_price: Mapped[float] = mapped_column(Float)
    normalised_currency: Mapped[str] = mapped_column(String(8), default="USD")
    normalised_unit: Mapped[str] = mapped_column(String(32), default="USD/GPU-hour")
    exchange_rate: Mapped[float] = mapped_column(Float, default=1.0)
    pricing_type: Mapped[str] = mapped_column(String(16))
    confidence: Mapped[str] = mapped_column(String(16))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class PriceHistoryORM(Base):
    """Append-only. Every observed/calculated price ever seen. Never overwritten."""

    __tablename__ = "price_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    provider_id: Mapped[str] = mapped_column(String(64), index=True)
    offer_id: Mapped[str] = mapped_column(String(128), index=True)
    gpu_model: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    region: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    price: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(8), default="USD")
    availability: Mapped[str] = mapped_column(String(16), default="UNKNOWN")
    pricing_type: Mapped[str] = mapped_column(String(16))


class AvailabilityORM(Base):
    """Append-only log of availability state observations."""

    __tablename__ = "availability"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    offer_id: Mapped[str] = mapped_column(String(128), index=True)
    state: Mapped[str] = mapped_column(String(16))
    checked_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class BenchmarkORM(Base):
    __tablename__ = "benchmarks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    gpu_id: Mapped[str] = mapped_column(String(64), index=True)
    metric: Mapped[str] = mapped_column(String(64))
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(32))
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class WorkloadORM(Base):
    __tablename__ = "workloads"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    label: Mapped[str | None] = mapped_column(String(128), nullable=True)
    gpu_model: Mapped[str] = mapped_column(String(64))
    gpu_count: Mapped[int] = mapped_column(Integer)
    runtime_hours: Mapped[float] = mapped_column(Float)
    region: Mapped[str | None] = mapped_column(String(32), nullable=True)
    storage_tb: Mapped[float] = mapped_column(Float, default=0.0)
    egress_tb: Mapped[float] = mapped_column(Float, default=0.0)
    ingress_tb: Mapped[float] = mapped_column(Float, default=0.0)
    billing_model: Mapped[str | None] = mapped_column(String(32), nullable=True)
    multi_node_required: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class RankingORM(Base):
    __tablename__ = "rankings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    query_label: Mapped[str] = mapped_column(String(128), index=True)
    offer_id: Mapped[str] = mapped_column(String(128))
    provider_id: Mapped[str] = mapped_column(String(64))
    rank: Mapped[int] = mapped_column(Integer)
    score: Mapped[float] = mapped_column(Float)
    price: Mapped[float] = mapped_column(Float)
    effective_price: Mapped[float] = mapped_column(Float)
    availability: Mapped[str] = mapped_column(String(16))
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class AlertORM(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    alert_type: Mapped[str] = mapped_column(String(32))
    severity: Mapped[str] = mapped_column(String(16), default="INFO")
    gpu_model: Mapped[str | None] = mapped_column(String(64), nullable=True)
    region: Mapped[str | None] = mapped_column(String(32), nullable=True)
    provider_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    offer_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    message: Mapped[str] = mapped_column(Text)
    threshold_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    observed_value: Mapped[float | None] = mapped_column(Float, nullable=True)
    triggered_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)


class SourceORM(Base):
    __tablename__ = "sources"

    source_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    provider_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    name: Mapped[str] = mapped_column(String(128))
    url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    connector_type: Mapped[str] = mapped_column(String(32))
    last_fetched_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    parser_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    reliability_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class AlertRuleORM(Base):
    """User-defined price alert rule, section 42."""

    __tablename__ = "alert_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    owner: Mapped[str | None] = mapped_column(String(128), nullable=True)
    gpu_model: Mapped[str | None] = mapped_column(String(64), nullable=True)
    region: Mapped[str | None] = mapped_column(String(32), nullable=True)
    comparison: Mapped[str] = mapped_column(String(4), default="lt")  # 'lt' or 'gt'
    threshold_price: Mapped[float] = mapped_column(Float)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
