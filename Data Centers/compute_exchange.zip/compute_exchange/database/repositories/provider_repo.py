from datetime import datetime
from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from database.orm import ProviderORM
from models.provider import Provider


class ProviderRepository:
    def __init__(self, db: Session):
        self.db = db

    def upsert(self, provider: Provider) -> ProviderORM:
        row = self.db.get(ProviderORM, provider.provider_id)
        if row is None:
            row = ProviderORM(provider_id=provider.provider_id)
            self.db.add(row)
        row.name = provider.name
        row.category = provider.category.value
        row.website = provider.website
        row.regions = provider.regions
        row.billing_models = provider.billing_models
        row.gpu_models = provider.gpu_models
        row.enterprise = provider.enterprise
        row.marketplace = provider.marketplace
        row.sla = provider.sla
        row.reliability_score = provider.reliability_score
        row.data_quality_score = provider.data_quality_score
        row.last_updated = provider.last_updated or datetime.utcnow()
        self.db.flush()
        return row

    def get(self, provider_id: str) -> Optional[ProviderORM]:
        return self.db.get(ProviderORM, provider_id)

    def list(self, category: Optional[str] = None) -> Sequence[ProviderORM]:
        stmt = select(ProviderORM)
        if category:
            stmt = stmt.where(ProviderORM.category == category)
        return self.db.execute(stmt.order_by(ProviderORM.name)).scalars().all()

    @staticmethod
    def to_domain(row: ProviderORM) -> Provider:
        return Provider(
            provider_id=row.provider_id,
            name=row.name,
            category=row.category,
            website=row.website,
            regions=row.regions or [],
            billing_models=row.billing_models or [],
            gpu_models=row.gpu_models or [],
            enterprise=row.enterprise,
            marketplace=row.marketplace,
            sla=row.sla,
            reliability_score=row.reliability_score,
            data_quality_score=row.data_quality_score,
            last_updated=row.last_updated,
        )
