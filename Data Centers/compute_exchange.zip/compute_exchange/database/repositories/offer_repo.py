from datetime import datetime, timedelta
from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from database.orm import OfferORM, PriceHistoryORM, AvailabilityORM
from models.offer import ComputeOffer


class OfferRepository:
    def __init__(self, db: Session):
        self.db = db

    def upsert(self, offer: ComputeOffer) -> OfferORM:
        """
        Insert or update the canonical offer row, and *append* to
        price_history / availability. Prices are never overwritten in
        history -- only the current-state `offers` row is mutated.
        """
        row = self.db.get(OfferORM, offer.offer_id)
        is_new = row is None
        previous_price = row.price if row else None
        previous_availability = row.availability if row else None

        if row is None:
            row = OfferORM(offer_id=offer.offer_id)
            self.db.add(row)

        for field in (
            "provider_id", "instance_id", "gpu_model", "gpu_count", "cpu_model",
            "cpu_cores", "ram_gb", "storage_gb", "network_gbps", "multi_node_capable",
            "region", "country", "city", "latitude", "longitude", "price",
            "minimum_term", "maximum_term", "egress_price_per_tb", "ingress_price_per_tb",
            "setup_fee", "commitment", "reliability_score", "source", "source_url",
            "parser_version", "observed_at", "spot_price", "reserved_price", "on_demand_price",
        ):
            setattr(row, field, getattr(offer, field))

        row.storage_type = offer.storage_type.value
        row.network_fabric = offer.network_fabric.value
        row.availability = offer.availability.value
        row.billing_unit = offer.billing_unit.value
        row.billing_model = offer.billing_model.value
        row.currency = offer.currency.value

        self.db.flush()

        # Append-only price history: always log, so nothing is ever lost.
        if is_new or previous_price != offer.price:
            self.db.add(PriceHistoryORM(
                timestamp=offer.observed_at,
                provider_id=offer.provider_id,
                offer_id=offer.offer_id,
                gpu_model=offer.gpu_model,
                region=offer.region,
                price=offer.price,
                currency=offer.currency.value,
                availability=offer.availability.value,
                pricing_type="OBSERVED",
            ))

        if is_new or previous_availability != offer.availability.value:
            self.db.add(AvailabilityORM(
                offer_id=offer.offer_id,
                state=offer.availability.value,
                checked_at=offer.observed_at,
            ))

        self.db.flush()
        return row

    def get(self, offer_id: str) -> Optional[OfferORM]:
        return self.db.get(OfferORM, offer_id)

    def list(
        self,
        gpu_model: Optional[str] = None,
        region: Optional[str] = None,
        billing_model: Optional[str] = None,
        provider_id: Optional[str] = None,
        availability: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Sequence[OfferORM]:
        stmt = select(OfferORM)
        if gpu_model:
            stmt = stmt.where(OfferORM.gpu_model == gpu_model)
        if region and region.upper() != "ANY":
            stmt = stmt.where(OfferORM.region == region)
        if billing_model and billing_model.upper() != "ANY":
            stmt = stmt.where(OfferORM.billing_model == billing_model)
        if provider_id:
            stmt = stmt.where(OfferORM.provider_id == provider_id)
        if availability:
            stmt = stmt.where(OfferORM.availability == availability)
        stmt = stmt.order_by(OfferORM.price.asc()).limit(limit).offset(offset)
        return self.db.execute(stmt).scalars().all()

    def count(
        self,
        gpu_model: Optional[str] = None,
        region: Optional[str] = None,
        billing_model: Optional[str] = None,
    ) -> int:
        from sqlalchemy import func
        stmt = select(func.count(OfferORM.offer_id))
        if gpu_model:
            stmt = stmt.where(OfferORM.gpu_model == gpu_model)
        if region and region.upper() != "ANY":
            stmt = stmt.where(OfferORM.region == region)
        if billing_model and billing_model.upper() != "ANY":
            stmt = stmt.where(OfferORM.billing_model == billing_model)
        return self.db.execute(stmt).scalar_one()

    def price_history(
        self, offer_id: Optional[str] = None, gpu_model: Optional[str] = None,
        since: Optional[datetime] = None, limit: int = 1000,
    ) -> Sequence[PriceHistoryORM]:
        stmt = select(PriceHistoryORM)
        if offer_id:
            stmt = stmt.where(PriceHistoryORM.offer_id == offer_id)
        if gpu_model:
            stmt = stmt.where(PriceHistoryORM.gpu_model == gpu_model)
        if since:
            stmt = stmt.where(PriceHistoryORM.timestamp >= since)
        stmt = stmt.order_by(PriceHistoryORM.timestamp.desc()).limit(limit)
        return self.db.execute(stmt).scalars().all()

    def all_gpu_models_in_market(self) -> Sequence[str]:
        stmt = select(OfferORM.gpu_model).where(OfferORM.gpu_model.is_not(None)).distinct()
        return [r[0] for r in self.db.execute(stmt).all()]

    def all_regions(self) -> Sequence[str]:
        stmt = select(OfferORM.region).distinct()
        return [r[0] for r in self.db.execute(stmt).all()]

    @staticmethod
    def to_domain(row: OfferORM) -> ComputeOffer:
        return ComputeOffer(
            offer_id=row.offer_id,
            provider_id=row.provider_id,
            instance_id=row.instance_id,
            gpu_model=row.gpu_model,
            gpu_count=row.gpu_count,
            cpu_model=row.cpu_model,
            cpu_cores=row.cpu_cores,
            ram_gb=row.ram_gb,
            storage_gb=row.storage_gb,
            storage_type=row.storage_type,
            network_gbps=row.network_gbps,
            network_fabric=row.network_fabric,
            multi_node_capable=row.multi_node_capable,
            region=row.region,
            country=row.country,
            city=row.city,
            latitude=row.latitude,
            longitude=row.longitude,
            availability=row.availability,
            billing_unit=row.billing_unit,
            billing_model=row.billing_model,
            price=row.price,
            currency=row.currency,
            spot_price=row.spot_price,
            reserved_price=row.reserved_price,
            on_demand_price=row.on_demand_price,
            minimum_term=row.minimum_term,
            maximum_term=row.maximum_term,
            egress_price_per_tb=row.egress_price_per_tb,
            ingress_price_per_tb=row.ingress_price_per_tb,
            setup_fee=row.setup_fee,
            commitment=row.commitment,
            reliability_score=row.reliability_score,
            source=row.source,
            source_url=row.source_url,
            parser_version=row.parser_version,
            observed_at=row.observed_at,
        )
