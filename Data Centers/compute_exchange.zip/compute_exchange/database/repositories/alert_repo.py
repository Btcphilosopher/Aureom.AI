from datetime import datetime
from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from database.orm import AlertORM, AlertRuleORM


class AlertRepository:
    def __init__(self, db: Session):
        self.db = db

    def create_alert(
        self, alert_type: str, message: str, severity: str = "INFO",
        gpu_model: Optional[str] = None, region: Optional[str] = None,
        provider_id: Optional[str] = None, offer_id: Optional[str] = None,
        threshold_price: Optional[float] = None, observed_value: Optional[float] = None,
    ) -> AlertORM:
        row = AlertORM(
            alert_type=alert_type, severity=severity, message=message,
            gpu_model=gpu_model, region=region, provider_id=provider_id,
            offer_id=offer_id, threshold_price=threshold_price,
            observed_value=observed_value, triggered_at=datetime.utcnow(),
        )
        self.db.add(row)
        self.db.flush()
        return row

    def recent(self, limit: int = 50, acknowledged: Optional[bool] = None) -> Sequence[AlertORM]:
        stmt = select(AlertORM)
        if acknowledged is not None:
            stmt = stmt.where(AlertORM.acknowledged == acknowledged)
        stmt = stmt.order_by(AlertORM.triggered_at.desc()).limit(limit)
        return self.db.execute(stmt).scalars().all()

    def add_rule(
        self, threshold_price: float, comparison: str = "lt",
        gpu_model: Optional[str] = None, region: Optional[str] = None,
        owner: Optional[str] = None,
    ) -> AlertRuleORM:
        row = AlertRuleORM(
            threshold_price=threshold_price, comparison=comparison,
            gpu_model=gpu_model, region=region, owner=owner,
        )
        self.db.add(row)
        self.db.flush()
        return row

    def active_rules(self) -> Sequence[AlertRuleORM]:
        stmt = select(AlertRuleORM).where(AlertRuleORM.active.is_(True))
        return self.db.execute(stmt).scalars().all()
