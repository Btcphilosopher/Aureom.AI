from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from database.orm import GPUORM
from models.gpu import GPU


class GPURepository:
    def __init__(self, db: Session):
        self.db = db

    def upsert(self, gpu: GPU) -> GPUORM:
        row = self.db.get(GPUORM, gpu.id)
        if row is None:
            row = GPUORM(id=gpu.id)
            self.db.add(row)
        row.manufacturer = gpu.manufacturer.value
        row.model = gpu.model
        row.architecture = gpu.architecture
        row.vram_gb = gpu.vram_gb
        row.memory_bandwidth_gbps = gpu.memory_bandwidth_gbps
        row.fp16_tflops = gpu.fp16_tflops
        row.bf16_tflops = gpu.bf16_tflops
        row.fp8_tflops = gpu.fp8_tflops
        row.fp4_tflops = gpu.fp4_tflops
        row.tensor_cores = gpu.tensor_cores
        row.power_watts = gpu.power_watts
        row.release_year = gpu.release_year
        self.db.flush()
        return row

    def get(self, gpu_id: str) -> Optional[GPUORM]:
        return self.db.get(GPUORM, gpu_id)

    def list(self) -> Sequence[GPUORM]:
        return self.db.execute(select(GPUORM).order_by(GPUORM.model)).scalars().all()

    @staticmethod
    def to_domain(row: GPUORM) -> GPU:
        return GPU(
            id=row.id,
            manufacturer=row.manufacturer,
            model=row.model,
            architecture=row.architecture,
            vram_gb=row.vram_gb,
            memory_bandwidth_gbps=row.memory_bandwidth_gbps,
            fp16_tflops=row.fp16_tflops,
            bf16_tflops=row.bf16_tflops,
            fp8_tflops=row.fp8_tflops,
            fp4_tflops=row.fp4_tflops,
            tensor_cores=row.tensor_cores,
            power_watts=row.power_watts,
            release_year=row.release_year,
        )
