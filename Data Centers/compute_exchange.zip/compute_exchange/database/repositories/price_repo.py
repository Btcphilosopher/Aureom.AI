from datetime import datetime
from typing import Optional, Sequence

from sqlalchemy.orm import Session

from database.orm import PriceORM
from models.pricing import PriceRecord


class PriceRepository:
    """Manages the `prices` table: one fast-read snapshot row per offer."""

    def __init__(self, db: Session):
        self.db = db

    def upsert(self, offer_id: str, record: PriceRecord) -> PriceORM:
        row = self.db.get(PriceORM, offer_id)
        if row is None:
            row = PriceORM(offer_id=offer_id)
            self.db.add(row)
        row.normalised_price = record.normalised_price
        row.normalised_currency = record.normalised_currency.value
        row.normalised_unit = record.normalised_unit
        row.exchange_rate = record.exchange_rate
        row.pricing_type = record.pricing_type.value
        row.confidence = record.confidence.value
        row.updated_at = datetime.utcnow()
        self.db.flush()
        return row

    def get(self, offer_id: str) -> Optional[PriceORM]:
        return self.db.get(PriceORM, offer_id)

    def latest(self, limit: int = 100) -> Sequence[PriceORM]:
        from sqlalchemy import select
        stmt = select(PriceORM).order_by(PriceORM.updated_at.desc()).limit(limit)
        return self.db.execute(stmt).scalars().all()
