# Compute Market OS

**Compute Capacity Exchange & Pricing Engine**

A programmable market for cloud compute capacity — GPU, CPU, TPU/AI
accelerators, RAM, NVMe, network bandwidth, bare metal, VMs, AI inference,
and AI training — where buyers and providers discover, price, reserve,
auction, optimise and monitor compute capacity.

> **⚠️ SIMULATED MARKET — NOT LIVE MARKET DATA.** The bundled
> configuration and synthetic data generator produce demonstration data
> only. No component in this repository connects to a real cloud
> provider, GPU marketplace, or live pricing feed.

The central abstraction:

```
COMPUTE = CAPACITY + TIME + LOCATION + PERFORMANCE + ENERGY + NETWORK
```

The central market question the engine answers:

> "What is the cheapest / fastest / highest-quality unit of compute
> available at this moment, in this location, for this workload?"

---

## Architecture

```
                    COMPUTE MARKET OS
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
    PROVIDERS            BUYERS             MARKET
        │                  │                  │
        ▼                  ▼                  ▼
   DATACENTERS          WORKLOADS         ORDER BOOK
        │                  │                  │
        └──────────────────┼──────────────────┘
                           ▼
                    MATCHING ENGINE
                           │
              ┌────────────┼─────────────┐
              ▼            ▼             ▼
           SPOT         AUCTION        FORWARD
              │            │             │
              └────────────┼─────────────┘
                           ▼
                    PRICING ENGINE
                           │
              ┌────────────┼─────────────┐
              ▼            ▼             ▼
          FORECAST       INDEX        OPTIMISER
              │            │             │
              └────────────┼─────────────┘
                           ▼
                    MARKET DATABASE
                           │
                           ▼
                     FASTAPI / WS
                           │
                           ▼
                  MARKET TERMINAL UI (bring your own frontend)
```

### Package layout

```
compute_market_os/
  core/            SQLAlchemy models, Pydantic schemas, config loader,
                    internal event bus, DB session management
  domain/           ComputeHardware + Compute Performance Index (CPI),
                    ComputeProvider, DataCenter + PowerConstraint,
                    ComputeUnit commodity model, inventory/utilisation
  market/           Order, OrderBook, MatchingEngine, ComputeMarket
                    orchestrator, Spot/Forward/Reservation markets,
                    AuctionEngine
  pricing/          PricingEngine (cost-plus + scarcity), EnergyCostEngine,
                    CarbonAwareScheduler, VWAP, Compute Price Index,
                    Forward Curve
  optimisation/     NetworkLatencyEngine (NetworkX region graph),
                    ClusterOptimizer, BuyerOptimizer (+ OR-Tools CP-SAT
                    multi-source allocation), ProviderOptimizer,
                    ProviderRevenueOptimizer (SciPy LP), ArbitrageEngine,
                    MarketEquilibriumEngine, ElasticityEngine
  ai_markets/        InferenceMarket, TrainingMarket
  forecasting/       PriceForecastEngine, CapacityForecastEngine
                    (statistical models with explicit uncertainty bands)
  simulation/        SimPy-based ComputeMarketSimulation, buyer/provider
                    agents, MarketShock model, OutageEngine
  ops/               SLAEngine, UsageMeter, BillingEngine,
                    SettlementEngine, ComputeContract,
                    MarketSurveillanceEngine
  analyst/           ComputeMarketAnalyst — answers the canonical market
                    questions strictly from supplied data
  security/          JWT/OAuth2 + RBAC, API-key support, rate limiting
  api/               FastAPI app, routers, WebSocket channels,
                    Prometheus metrics
  cli/               Typer CLI (compute-market ...)
  data/synthetic/    Synthetic demonstration market generator

config/              YAML configuration — hardware catalog, pricing model,
                    regions/network graph, benchmark profiles, market
                    rules. Nothing economic is hard-coded in Python.
tests/               91 tests: unit + property-based (Hypothesis)
```

---

## Requirements

- Python 3.11+ (3.13 recommended, per the brief)
- PostgreSQL for production (SQLite is used automatically for local
  dev/tests — same schema, zero setup)
- Redis is optional; without it the event bus and rate limiter fall back
  to in-process implementations (fine for a single-process deployment,
  not for multi-worker horizontal scaling — see notes below)

## Installation

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# or: pip install -e .
```

Copy `.env.example` to `.env` and adjust (defaults work out of the box
with SQLite):

```bash
cp .env.example .env
```

## Quickstart

```bash
# 1. Load the synthetic demonstration market (10 providers, 20
#    datacenters, 5 regions, 6 accelerator types, 10,000+ GPU units)
compute-market seed-demo

# 2. Start the API
compute-market start
# → http://localhost:8000/docs (OpenAPI/Swagger)
# → ws://localhost:8000/ws/market (and /orderbook /prices /capacity
#   /trades /datacenters)

# 3. Explore from the CLI
compute-market prices --hardware-id hw-h100-sxm --utilisation 0.8
compute-market capacity
compute-market auction --auction-type reverse
compute-market forecast
compute-market index --index-code CPI-TW
compute-market simulate --num-buyers 40 --num-providers 20 \
    --duration-hours 168 --shock "ai_demand_spike:0.4:24"
```

Or drive the engine directly from Python (section 75 of the spec):

```python
from compute_market_os.market.market import ComputeMarket

market = ComputeMarket()
market.submit_order(side="BUY", hardware="H100", region="Taiwan",
                     quantity=32, duration_hours=24, limit_price=2.40)
market.submit_order(side="SELL", hardware="H100", region="Taiwan",
                     quantity=64, duration_hours=24, limit_price=2.20)
trades = market.match()
```

## Running tests

```bash
pip install -r requirements.txt   # includes pytest/hypothesis/httpx
pytest -q
```

91 tests cover order matching (incl. Hypothesis property tests for
price-time-priority invariants), capacity reservation + double-booking
prevention, pricing decomposition, spot/forward/reservation pricing,
auction clearing (English/sealed-bid/reverse/uniform-price capacity),
billing/settlement, SLA compliance, outages, market surveillance,
forecasting, optimisation (buyer/provider/revenue/arbitrage/equilibrium/
elasticity), the SimPy market simulator, the analyst, and the FastAPI
layer end-to-end (`fastapi.testclient`).

## API surface

`GET /health`, `/ready`, `/metrics` (Prometheus) plus, under `/api/`:
`market`, `prices` (+`/quote`, `/vwap`), `orderbook`, `capacity`
(+`/reservations`, row-locked against double-booking), `providers`
(+`/{id}/capacity` publish), `datacenters` (+`/inventory`, `/power`),
`hardware`, `regions` (+`/routes`), `contracts` (forward market),
`auctions` (+`/bids`, `/clear`), `inference` (+`/offers`, `/quote`,
`/best`), `training` (+`/estimate`), `forecast` (+`/price`, `/capacity`,
`/curve`), `index`, `optimise` (+`/buyer`, `/provider`, `/arbitrage`,
`/equilibrium`).

WebSockets: `/ws/market`, `/ws/orderbook`, `/ws/prices`, `/ws/capacity`,
`/ws/trades`, `/ws/datacenters` — each streams the relevant slice of the
internal event bus (`OrderSubmitted`, `TradeExecuted`, `PriceUpdated`,
`CapacityAdded`, `OutageDetected`, ...) as JSON.

## Configuration, not hard-coding

Every economic parameter lives in `config/*.yaml`:
`hardware.yaml` (vendor-neutral accelerator/CPU catalog + benchmark
fields), `pricing.yaml` (depreciation, energy/cooling/network/ops/risk/
margin, scarcity curve, spot/reservation/forward/auction dynamics, index
baskets), `regions.yaml` (region graph: latency/bandwidth/cost/
availability edges, grid carbon intensity, electricity price),
`benchmarks.yaml` (Compute Performance Index profiles),
`markets.yaml` (SLA tiers, surveillance thresholds, billing/tax).

## Design notes & honest limitations

- **In-memory exchange engines, durable ledger.** The order book,
  matching engine, spot ticker, auctions, and forward/reservation
  markets are pure, dependency-light Python objects — deterministic and
  easy to unit test — held in one process's memory (see the scale note
  in `market/orderbook.py`). Orders/trades/contracts/reservations are
  also persisted to PostgreSQL/SQLite via SQLAlchemy for durability and
  querying. A multi-worker/horizontally-scaled deployment would move the
  live book state into Redis (sorted sets) with Postgres as the system
  of record — the same interfaces are designed to support that swap.
- **Redis is optional.** Without `REDIS_URL` set, the event bus and rate
  limiter use in-process fallbacks — correct for one process, not shared
  across workers.
- **OR-Tools** is used for a real combinatorial problem (multi-source
  capacity allocation via CP-SAT in `BuyerOptimizer.allocate_multi_source`)
  rather than token inclusion; **SciPy** solves the provider revenue LP;
  **NetworkX** backs the region/latency graph; **SimPy** drives the
  market simulator's discrete-event agents.
- **Forecasting is statistical by design** (EWMA/random-walk-with-drift
  for price, trend+seasonality for capacity), always reports an
  uncertainty band, and refuses to run below a minimum-observations
  threshold rather than fabricate a forecast. ML is an intentional
  non-goal here, per the brief ("statistical models first, ML optional
  later").
- **Elasticity is never fabricated** — `ElasticityEngine` raises if fewer
  than 3 (price, quantity) observations are supplied.
- **The analyst answers only from supplied data.** `ComputeMarketAnalyst`
  methods are computations over caller-supplied price/inventory/offer
  data, not free-form generation.
- **Security is a real but reference implementation**: JWT/OAuth2 +
  RBAC (`ADMIN/PROVIDER/BUYER/BROKER/ANALYST/AUDITOR`) and an in-memory
  rate limiter are wired and tested; production hardening (secret
  rotation, audit-log shipping, DB-level encryption at rest) is
  deployment-specific and left to the hosting environment.
- **Market surveillance flags, never accuses.** `MarketSurveillanceEngine`
  outputs NORMAL/WATCH/ANOMALY/CRITICAL with reason + evidence for human
  review — it never auto-blocks a user.
- **The outage engine never touches real infrastructure.** It only
  marks capacity offline in the market model, per the brief's explicit
  safety constraint.

## Disclaimer

This is a demonstration/reference implementation built to a detailed
specification. `data/synthetic/generator.py` and `simulation/` explicitly
label their output **SIMULATED MARKET — NOT LIVE MARKET DATA**. Nothing
here should be used to make real purchasing, financial, or legal
(e.g. actual forward-contract) decisions without independent review.
