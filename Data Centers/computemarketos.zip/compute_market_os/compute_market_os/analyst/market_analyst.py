"""ComputeMarketAnalyst (section 78).

Answers the canonical market questions strictly from data the caller
supplies (price history, inventory snapshots, capacity offers, ...) —
every method here is a computation over that data, never an invented
observation. Callers in the API layer are responsible for pulling the
underlying rows from the database.
"""

from __future__ import annotations

import dataclasses
import datetime as dt

from compute_market_os.domain.inventory import InventorySnapshot
from compute_market_os.optimisation.buyer_optimizer import CapacityOffer
from compute_market_os.optimisation.equilibrium_engine import LinearCurve, MarketEquilibriumEngine
from compute_market_os.optimisation.network_latency_engine import NetworkLatencyEngine


@dataclasses.dataclass(slots=True, frozen=True)
class AnalystAnswer:
    question: str
    answer: str
    evidence: dict


class ComputeMarketAnalyst:
    def __init__(self, equilibrium_engine: MarketEquilibriumEngine | None = None, latency_engine: NetworkLatencyEngine | None = None) -> None:
        self.equilibrium_engine = equilibrium_engine or MarketEquilibriumEngine()
        self.latency_engine = latency_engine or NetworkLatencyEngine()

    def why_did_price_move(self, price_points: list[tuple[dt.datetime, float]], utilisation_points: list[tuple[dt.datetime, float]]) -> AnalystAnswer:
        if len(price_points) < 2:
            return AnalystAnswer("Why did the price move?", "Not enough price history to explain a move.", {})
        history = sorted(price_points, key=lambda p: p[0])
        (t0, p0), (t1, p1) = history[0], history[-1]
        pct = (p1 - p0) / p0 if p0 else 0.0

        util_note = ""
        if len(utilisation_points) >= 2:
            u_hist = sorted(utilisation_points, key=lambda p: p[0])
            u0, u1 = u_hist[0][1], u_hist[-1][1]
            util_note = f" Utilisation moved from {u0:.1%} to {u1:.1%} over the same window."

        direction = "increased" if pct > 0 else "decreased" if pct < 0 else "was flat"
        answer = (
            f"Price {direction} {abs(pct):.2%} between {t0.isoformat()} and {t1.isoformat()} "
            f"(from {p0:.4f} to {p1:.4f}).{util_note}"
        )
        return AnalystAnswer(
            "Why did the price move?",
            answer,
            {"start_price": p0, "end_price": p1, "pct_change": round(pct, 4), "n_points": len(history)},
        )

    def cheapest_available_region(self, offers: list[CapacityOffer]) -> AnalystAnswer:
        if not offers:
            return AnalystAnswer("Which region has the cheapest available compute?", "No offers available.", {})
        cheapest = min(offers, key=lambda o: o.price_per_hour)
        return AnalystAnswer(
            "Which region has the cheapest available compute?",
            f"{cheapest.region} at {cheapest.price_per_hour:.4f}/hour ({cheapest.hardware_id}, provider {cheapest.provider_id}).",
            {"region": cheapest.region, "price_per_hour": cheapest.price_per_hour, "hardware_id": cheapest.hardware_id, "provider_id": cheapest.provider_id},
        )

    def scarce_regions(self, snapshots: list[InventorySnapshot], utilisation_threshold: float = 85.0) -> AnalystAnswer:
        scarce = [s for s in snapshots if s.utilisation_pct >= utilisation_threshold]
        scarce.sort(key=lambda s: s.utilisation_pct, reverse=True)
        if not scarce:
            return AnalystAnswer(
                "Where is capacity becoming scarce?",
                f"No datacenter is currently above {utilisation_threshold:.0f}% utilisation.",
                {"threshold_pct": utilisation_threshold},
            )
        top = scarce[:5]
        answer = "; ".join(f"{s.datacenter_id}/{s.hardware_id} at {s.utilisation_pct:.1f}%" for s in top)
        return AnalystAnswer(
            "Where is capacity becoming scarce?",
            answer,
            {"threshold_pct": utilisation_threshold, "matches": [s.as_dict() for s in top]},
        )

    def excess_capacity_datacenters(self, snapshots: list[InventorySnapshot], utilisation_threshold: float = 40.0) -> AnalystAnswer:
        excess = [s for s in snapshots if s.installed > 0 and s.utilisation_pct <= utilisation_threshold]
        excess.sort(key=lambda s: s.utilisation_pct)
        if not excess:
            return AnalystAnswer(
                "Which datacenters have excess capacity?",
                f"No datacenter is currently below {utilisation_threshold:.0f}% utilisation.",
                {"threshold_pct": utilisation_threshold},
            )
        answer = "; ".join(f"{s.datacenter_id}/{s.hardware_id} at {s.utilisation_pct:.1f}% utilised ({s.available} available)" for s in excess[:5])
        return AnalystAnswer(
            "Which datacenters have excess capacity?",
            answer,
            {"threshold_pct": utilisation_threshold, "matches": [s.as_dict() for s in excess[:5]]},
        )

    def best_price_performance_provider(self, offers: list[CapacityOffer]) -> AnalystAnswer:
        scored = [o for o in offers if o.performance_score > 0]
        if not scored:
            return AnalystAnswer("Which provider has the best price/performance?", "No offers carry a performance score.", {})
        best = max(scored, key=lambda o: o.performance_score / o.price_per_hour)
        ratio = best.performance_score / best.price_per_hour
        return AnalystAnswer(
            "Which provider has the best price/performance?",
            f"Provider {best.provider_id} ({best.hardware_id} in {best.region}): {ratio:.4f} performance-units per £/hour.",
            {"provider_id": best.provider_id, "hardware_id": best.hardware_id, "region": best.region, "score_per_price": round(ratio, 6)},
        )

    def demand_shock_impact(self, demand: LinearCurve, supply: LinearCurve, pct_change: float) -> AnalystAnswer:
        baseline = self.equilibrium_engine.solve(demand, supply)
        shocked_demand = self.equilibrium_engine.apply_demand_shock(demand, pct_change)
        shocked = self.equilibrium_engine.solve(shocked_demand, supply)
        price_delta = shocked.price - baseline.price
        qty_delta = shocked.quantity - baseline.quantity
        return AnalystAnswer(
            f"What happens if demand increases {pct_change:+.0%}?",
            f"Equilibrium price moves from {baseline.price:.4f} to {shocked.price:.4f} "
            f"({price_delta:+.4f}); equilibrium quantity moves from {baseline.quantity:.1f} to {shocked.quantity:.1f} "
            f"({qty_delta:+.1f}).",
            {
                "baseline_price": baseline.price,
                "shocked_price": shocked.price,
                "baseline_quantity": baseline.quantity,
                "shocked_quantity": shocked.quantity,
            },
        )

    def best_cluster_location(self, candidate_regions: list[str], offers: list[CapacityOffer], origin_region: str | None = None) -> AnalystAnswer:
        candidates = [o for o in offers if o.region in candidate_regions]
        if not candidates:
            return AnalystAnswer("Where should a large GPU cluster be located?", "No offers found in the candidate regions.", {})
        if origin_region:
            ranked = sorted(
                candidates,
                key=lambda o: (self._latency_to(origin_region, o.region), o.price_per_hour),
            )
        else:
            ranked = sorted(candidates, key=lambda o: o.price_per_hour)
        best = ranked[0]
        return AnalystAnswer(
            "Where should a large GPU cluster be located?",
            f"{best.region} — {best.quantity_available} units of {best.hardware_id} available at {best.price_per_hour:.4f}/hour from provider {best.provider_id}.",
            {"region": best.region, "hardware_id": best.hardware_id, "price_per_hour": best.price_per_hour, "quantity_available": best.quantity_available},
        )

    def _latency_to(self, origin: str, region: str) -> float:
        route = self.latency_engine.route(origin, region)
        return route.latency_ms if route else float("inf")

    def workloads_suited_to_spot(self, workload_latency_sensitivity: dict[str, float], max_tolerable_ms: float = 250.0) -> AnalystAnswer:
        """`workload_latency_sensitivity` maps workload name -> its
        required latency ceiling (ms); workloads with a ceiling above
        `max_tolerable_ms` tolerate spot's variability and interruption
        risk, so they are the ones the analyst recommends moving to spot."""
        suited = [w for w, ms in workload_latency_sensitivity.items() if ms >= max_tolerable_ms]
        if not suited:
            return AnalystAnswer("Which workloads should move to spot capacity?", "No workloads in the supplied set tolerate spot's latency/interruption profile.", {})
        return AnalystAnswer(
            "Which workloads should move to spot capacity?",
            f"{', '.join(suited)} — each tolerates >= {max_tolerable_ms:.0f}ms latency, making them good spot candidates.",
            {"suited_workloads": suited, "threshold_ms": max_tolerable_ms},
        )
