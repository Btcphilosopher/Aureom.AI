"""Volume-Weighted Average Price (section 66).

Works over any iterable of "trade-like" objects/dicts exposing
`price`, `quantity`, `duration_hours` (volume = quantity * duration_hours,
i.e. GPU-hours traded), `hardware_id`, `region`, `seller_provider_id` /
`provider_id`, and a timestamp attribute.
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Iterable


def _get(trade: Any, field: str):
    if isinstance(trade, dict):
        return trade.get(field)
    return getattr(trade, field, None)


def _volume(trade: Any) -> float:
    quantity = _get(trade, "quantity") or 0
    duration = _get(trade, "duration_hours")
    if duration is None:
        duration = 1.0
    return float(quantity) * float(duration)


def calculate_vwap(trades: Iterable[Any]) -> float | None:
    total_notional = 0.0
    total_volume = 0.0
    for t in trades:
        price = _get(t, "price")
        if price is None:
            continue
        volume = _volume(t)
        total_notional += price * volume
        total_volume += volume
    if total_volume <= 0:
        return None
    return round(total_notional / total_volume, 6)


def vwap_by(
    trades: Iterable[Any],
    hardware_id: str | None = None,
    region: str | None = None,
    provider_id: str | None = None,
    since: dt.datetime | None = None,
    timestamp_field: str = "timestamp",
) -> float | None:
    def matches(t: Any) -> bool:
        if hardware_id and _get(t, "hardware_id") != hardware_id:
            return False
        if region and _get(t, "region") != region:
            return False
        if provider_id and _get(t, "seller_provider_id") != provider_id and _get(t, "provider_id") != provider_id:
            return False
        if since is not None:
            ts = _get(t, timestamp_field)
            if ts is not None and ts < since:
                return False
        return True

    filtered = [t for t in trades if matches(t)]
    return calculate_vwap(filtered)
