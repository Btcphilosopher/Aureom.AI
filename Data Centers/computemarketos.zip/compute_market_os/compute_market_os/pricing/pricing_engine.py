"""PricingEngine (sections 14-15).

    Compute Price =
        Hardware Cost
        + Energy Cost
        + Cooling Cost
        + Network Cost
        + Operations
        + Risk
        + Margin

anchored to a cost-plus basis, then modulated by a scarcity multiplier
driven by utilisation (section 15: supply/demand/utilisation/scarcity).
Every coefficient is read from config/pricing.yaml — nothing here is
hard-coded.
"""

from __future__ import annotations

import dataclasses
import math

from compute_market_os.core.config import load_yaml_config
from compute_market_os.domain.hardware import ComputeHardware, load_hardware_catalog
from compute_market_os.pricing.energy_cost_engine import EnergyCostEngine


@dataclasses.dataclass(slots=True, frozen=True)
class PriceBreakdown:
    hardware_id: str
    hardware_cost_per_hour: float
    energy_cost_per_hour: float
    cooling_cost_per_hour: float
    network_cost_per_hour: float
    operations_cost_per_hour: float
    risk_premium_per_hour: float
    margin_per_hour: float
    scarcity_multiplier: float
    utilisation: float
    cost_plus_price_per_hour: float
    total_price_per_hour: float

    def as_dict(self) -> dict:
        return dataclasses.asdict(self)


class PricingEngine:
    def __init__(self) -> None:
        cfg = load_yaml_config("pricing")
        self._cost_cfg = cfg["cost_model"]
        self._dynamics_cfg = cfg["market_dynamics"]
        self._energy_engine = EnergyCostEngine()
        self._catalog = load_hardware_catalog()

    # -- cost components -----------------------------------------------------

    def hardware_depreciation_per_hour(self, hardware: ComputeHardware) -> float:
        dep = self._cost_cfg["depreciation"]
        capex = dep["default_capex_by_category"].get(hardware.category, 10000)
        useful_life_hours = dep["default_useful_life_years"] * 8760
        residual = dep["residual_value_fraction"]
        return round((capex * (1 - residual)) / useful_life_hours, 6)

    def scarcity_multiplier(self, utilisation: float) -> float:
        curve = self._dynamics_cfg["scarcity_curve"]
        midpoint = curve["midpoint_utilisation"]
        steepness = curve["steepness"]
        lo, hi = curve["min_scarcity_multiplier"], curve["max_scarcity_multiplier"]
        utilisation = min(max(utilisation, 0.0), 1.0)
        logistic = 1.0 / (1.0 + math.exp(-steepness * (utilisation - midpoint)))
        return round(lo + (hi - lo) * logistic, 6)

    # -- full compute price ----------------------------------------------------

    def compute_price(
        self,
        hardware_id: str,
        utilisation: float,
        electricity_price_per_kwh: float | None = None,
        pue: float | None = None,
        margin_fraction: float | None = None,
        volatility_fraction: float = 0.0,
    ) -> PriceBreakdown:
        hardware = self._catalog.get(hardware_id)
        if hardware is None:
            raise KeyError(f"Unknown hardware_id: {hardware_id!r}")

        electricity_price = (
            electricity_price_per_kwh if electricity_price_per_kwh is not None else 0.15
        )
        energy = self._energy_engine.cost_per_unit_hour(hardware, electricity_price, pue)

        hardware_cost = self.hardware_depreciation_per_hour(hardware)
        network_cost = self._cost_cfg["network"]["cost_per_gpu_hour"]
        ops_cfg = self._cost_cfg["operations"]
        operations_cost = (
            ops_cfg["staffing_and_ops_cost_per_gpu_hour"] + ops_cfg["insurance_and_facilities_per_gpu_hour"]
        )

        base_cost = (
            hardware_cost
            + energy.raw_energy_cost_per_hour
            + energy.cooling_cost_per_hour
            + network_cost
            + operations_cost
        )

        risk_cfg = self._cost_cfg["risk"]
        risk_fraction = risk_cfg["base_risk_premium_fraction"] + risk_cfg["volatility_risk_multiplier"] * volatility_fraction
        risk = base_cost * risk_fraction

        margin_cfg = self._cost_cfg["provider_margin"]
        margin_fraction = margin_fraction if margin_fraction is not None else margin_cfg["default_margin_fraction"]
        margin_fraction = min(max(margin_fraction, margin_cfg["min_margin_fraction"]), margin_cfg["max_margin_fraction"])
        margin = (base_cost + risk) * margin_fraction

        cost_plus_price = base_cost + risk + margin
        scarcity = self.scarcity_multiplier(utilisation)
        total_price = cost_plus_price * scarcity

        return PriceBreakdown(
            hardware_id=hardware_id,
            hardware_cost_per_hour=hardware_cost,
            energy_cost_per_hour=energy.raw_energy_cost_per_hour,
            cooling_cost_per_hour=energy.cooling_cost_per_hour,
            network_cost_per_hour=network_cost,
            operations_cost_per_hour=operations_cost,
            risk_premium_per_hour=round(risk, 6),
            margin_per_hour=round(margin, 6),
            scarcity_multiplier=scarcity,
            utilisation=utilisation,
            cost_plus_price_per_hour=round(cost_plus_price, 6),
            total_price_per_hour=round(total_price, 6),
        )

    # -- segment-specific prices ------------------------------------------------

    def on_demand_price(self, hardware_id: str, utilisation: float, **kwargs) -> float:
        return self.compute_price(hardware_id, utilisation, **kwargs).total_price_per_hour

    def spot_price(self, hardware_id: str, utilisation: float, **kwargs) -> float:
        # Spot tracks the cost-plus/scarcity anchor directly; smoothing is
        # applied by market.spot_market.SpotMarket across ticks.
        return self.compute_price(hardware_id, utilisation, **kwargs).total_price_per_hour

    def reservation_price(
        self, hardware_id: str, utilisation: float, duration_hours: float, **kwargs
    ) -> float:
        from compute_market_os.market.reservation_market import ReservationMarket

        spot = self.spot_price(hardware_id, utilisation, **kwargs)
        premium = ReservationMarket().premium_fraction(duration_hours)
        return round(spot * (1 + premium), 6)

    def forward_price(self, hardware_id: str, utilisation: float, days_ahead: float, **kwargs) -> float:
        fwd_cfg = self._dynamics_cfg["forward"]
        spot = self.spot_price(hardware_id, utilisation, **kwargs)
        contango = fwd_cfg["contango_fraction_per_90_days"] * (days_ahead / 90.0)
        return round(spot * (1 + contango), 6)

    def auction_reserve_price(self, hardware_id: str, utilisation: float, **kwargs) -> float:
        auction_cfg = self._dynamics_cfg["auction"]
        breakdown = self.compute_price(hardware_id, utilisation, **kwargs)
        return round(breakdown.cost_plus_price_per_hour * auction_cfg["reserve_price_fraction_of_cost"], 6)
