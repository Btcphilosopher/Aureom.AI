"""Compute Forward Curve (section 60).

Generates NOW / +1 DAY / +7 DAYS / +30 DAYS / +90 DAYS / +180 DAYS forward
prices for whichever hardware is actually configured (never hard-coded to
H100/A100/B200 specifically — those just happen to be in the demo
catalog). Uncertainty widens with horizon per
`market_dynamics.forward.uncertainty_growth_per_90_days`.
"""

from __future__ import annotations

import dataclasses

from compute_market_os.core.config import load_yaml_config
from compute_market_os.pricing.pricing_engine import PricingEngine

HORIZON_DAYS: dict[str, float] = {
    "NOW": 0,
    "+1_DAY": 1,
    "+7_DAYS": 7,
    "+30_DAYS": 30,
    "+90_DAYS": 90,
    "+180_DAYS": 180,
}


@dataclasses.dataclass(slots=True, frozen=True)
class CurvePoint:
    horizon: str
    days_ahead: float
    price: float
    lower_bound: float
    upper_bound: float


class ComputeForwardCurve:
    def __init__(self, pricing_engine: PricingEngine | None = None) -> None:
        self.pricing_engine = pricing_engine or PricingEngine()
        self._uncertainty_growth = load_yaml_config("pricing")["market_dynamics"]["forward"][
            "uncertainty_growth_per_90_days"
        ]

    def curve_for_hardware(
        self,
        hardware_id: str,
        utilisation: float,
        electricity_price_per_kwh: float | None = None,
        pue: float | None = None,
    ) -> list[CurvePoint]:
        points = []
        for horizon, days in HORIZON_DAYS.items():
            price = self.pricing_engine.forward_price(
                hardware_id,
                utilisation,
                days_ahead=days,
                electricity_price_per_kwh=electricity_price_per_kwh,
                pue=pue,
            )
            uncertainty_fraction = self._uncertainty_growth * (days / 90.0)
            points.append(
                CurvePoint(
                    horizon=horizon,
                    days_ahead=days,
                    price=price,
                    lower_bound=round(price * (1 - uncertainty_fraction), 6),
                    upper_bound=round(price * (1 + uncertainty_fraction), 6),
                )
            )
        return points

    def curve_for_hardware_list(
        self, hardware_ids: list[str], utilisation_by_hardware: dict[str, float], **kwargs
    ) -> dict[str, list[CurvePoint]]:
        return {
            hw_id: self.curve_for_hardware(hw_id, utilisation_by_hardware.get(hw_id, 0.7), **kwargs)
            for hw_id in hardware_ids
        }
