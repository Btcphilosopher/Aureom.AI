"""CarbonAwareScheduler (section 27).

kgCO2e / GPU-hour = (power draw in kW) * PUE * (grid carbon intensity in
gCO2e/kWh) / 1000

Grid intensities are configured per-region in config/regions.yaml —
illustrative averages for the simulated market, not live grid data.
"""

from __future__ import annotations

import dataclasses
import functools

from compute_market_os.core.config import load_yaml_config
from compute_market_os.domain.hardware import ComputeHardware


@dataclasses.dataclass(slots=True, frozen=True)
class CarbonEstimate:
    region: str
    kgco2e_per_gpu_hour: float
    grid_intensity_gco2_per_kwh: float
    pue: float


@functools.lru_cache
def _region_lookup() -> dict[str, dict]:
    raw = load_yaml_config("regions")
    return {r["code"]: r for r in raw.get("regions", [])}


class CarbonAwareScheduler:
    def __init__(self) -> None:
        self._default_pue = load_yaml_config("pricing")["cost_model"]["default_pue"]

    def region_intensity(self, region: str) -> float | None:
        entry = _region_lookup().get(region)
        return entry["grid_carbon_intensity_gco2_per_kwh"] if entry else None

    def estimate(self, hardware: ComputeHardware, region: str, pue: float | None = None) -> CarbonEstimate | None:
        intensity = self.region_intensity(region)
        if intensity is None:
            return None
        pue = pue if pue is not None else self._default_pue
        it_power_kw = hardware.power_watts / 1000.0
        total_power_kw = it_power_kw * pue
        kg_per_hour = total_power_kw * intensity / 1000.0
        return CarbonEstimate(
            region=region,
            kgco2e_per_gpu_hour=round(kg_per_hour, 6),
            grid_intensity_gco2_per_kwh=intensity,
            pue=pue,
        )

    def workload_emissions(
        self, hardware: ComputeHardware, region: str, quantity: int, runtime_hours: float, pue: float | None = None
    ) -> float | None:
        estimate = self.estimate(hardware, region, pue)
        if estimate is None:
            return None
        return round(estimate.kgco2e_per_gpu_hour * quantity * runtime_hours, 4)

    def filter_regions_within_limit(self, candidate_regions: list[str], max_intensity_gco2_per_kwh: float) -> list[str]:
        return [r for r in candidate_regions if (self.region_intensity(r) or float("inf")) <= max_intensity_gco2_per_kwh]
