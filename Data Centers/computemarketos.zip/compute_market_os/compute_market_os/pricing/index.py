"""Compute Price Index (sections 32 + 67).

    Index = Σ(weight_i × normalised_price_i)

Baskets (e.g. CPI-TW, CPI-EU, CPI-US, CPI-APAC) are fully configurable in
config/pricing.yaml (`index_baskets`) — component weights, not values, are
documented there. `normalised_price_i` is `price_i / base_price_i`, so the
index reads as "100 = basket price at the caller-supplied base date" when a
base is provided; without one it returns the weighted-average £/hour price
of the basket (still fully documented, just not rebased to 100).
"""

from __future__ import annotations

import dataclasses

from compute_market_os.core.config import load_yaml_config


@dataclasses.dataclass(slots=True, frozen=True)
class IndexResult:
    index_code: str
    value: float
    components: dict[str, float]  # component -> weighted contribution
    missing_components: list[str]


class ComputePriceIndexEngine:
    def __init__(self) -> None:
        self._baskets = load_yaml_config("pricing")["index_baskets"]

    def basket(self, index_code: str) -> dict:
        if index_code not in self._baskets:
            raise KeyError(f"Unknown index basket: {index_code!r}")
        return self._baskets[index_code]

    def available_indices(self) -> list[str]:
        return list(self._baskets.keys())

    def compute(
        self,
        index_code: str,
        component_prices: dict[str, float],
        base_component_prices: dict[str, float] | None = None,
    ) -> IndexResult:
        basket = self.basket(index_code)
        weights: dict[str, float] = basket["weights"]

        components: dict[str, float] = {}
        missing: list[str] = []
        value = 0.0
        for component, weight in weights.items():
            price = component_prices.get(component)
            if price is None:
                missing.append(component)
                continue
            if base_component_prices:
                base = base_component_prices.get(component)
                normalised = (price / base) * 100.0 if base else price
            else:
                normalised = price
            contribution = weight * normalised
            components[component] = round(contribution, 6)
            value += contribution

        return IndexResult(
            index_code=index_code,
            value=round(value, 6),
            components=components,
            missing_components=missing,
        )
