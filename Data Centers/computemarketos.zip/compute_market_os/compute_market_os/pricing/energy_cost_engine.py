"""EnergyCostEngine (section 28).

energy_cost_per_compute_hour = (
    (GPU/CPU/accelerator power draw converted to £/hour at the regional
     electricity price) * PUE
)

PUE captures cooling + facility overhead as a multiplier on IT power draw,
which is the standard datacenter convention (PUE = Total Facility Power /
IT Equipment Power) and matches the DataCenter domain model in
domain/datacenter.py.
"""

from __future__ import annotations

import dataclasses

from compute_market_os.core.config import load_yaml_config
from compute_market_os.domain.hardware import ComputeHardware


@dataclasses.dataclass(slots=True, frozen=True)
class EnergyCostBreakdown:
    it_power_kw: float
    raw_energy_cost_per_hour: float
    cooling_cost_per_hour: float

    @property
    def total_energy_cost_per_hour(self) -> float:
        return self.raw_energy_cost_per_hour + self.cooling_cost_per_hour


class EnergyCostEngine:
    def __init__(self) -> None:
        self._default_pue = load_yaml_config("pricing")["cost_model"]["default_pue"]

    def cost_per_unit_hour(
        self,
        hardware: ComputeHardware,
        electricity_price_per_kwh: float,
        pue: float | None = None,
    ) -> EnergyCostBreakdown:
        pue = pue if pue is not None else self._default_pue
        it_power_kw = hardware.power_watts / 1000.0
        raw_energy_cost = it_power_kw * electricity_price_per_kwh
        cooling_cost = raw_energy_cost * max(pue - 1.0, 0.0)
        return EnergyCostBreakdown(
            it_power_kw=it_power_kw,
            raw_energy_cost_per_hour=round(raw_energy_cost, 6),
            cooling_cost_per_hour=round(cooling_cost, 6),
        )
