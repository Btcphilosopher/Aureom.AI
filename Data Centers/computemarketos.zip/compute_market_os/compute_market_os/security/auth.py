"""OAuth2/JWT + RBAC + API keys (section 54).

Roles: ADMIN, PROVIDER, BUYER, BROKER, ANALYST, AUDITOR.

Kept dependency-light: password hashing via passlib[bcrypt], tokens via
python-jose. FastAPI wiring (OAuth2PasswordBearer, `Depends(require_role(...))`)
lives here so routers just declare the roles they need.
"""

from __future__ import annotations

import datetime as dt
import secrets

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext

from compute_market_os.core.config import get_settings
from compute_market_os.core.enums import Role

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token", auto_error=False)


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)


def generate_api_key() -> str:
    return secrets.token_hex(32)


def create_access_token(subject: str, role: str, expires_minutes: int | None = None) -> str:
    settings = get_settings()
    expire = dt.datetime.now(dt.timezone.utc) + dt.timedelta(
        minutes=expires_minutes or settings.jwt_expire_minutes
    )
    payload = {"sub": subject, "role": role, "exp": expire}
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def decode_access_token(token: str) -> dict:
    settings = get_settings()
    try:
        return jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    except JWTError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid or expired token") from exc


class CurrentUser:
    def __init__(self, subject: str, role: str) -> None:
        self.subject = subject
        self.role = role


def get_current_user(token: str | None = Depends(oauth2_scheme)) -> CurrentUser:
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="not authenticated")
    payload = decode_access_token(token)
    return CurrentUser(subject=payload["sub"], role=payload.get("role", Role.BUYER.value))


def require_role(*allowed_roles: Role):
    allowed = {r.value for r in allowed_roles}

    def _dependency(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in allowed and user.role != Role.ADMIN.value:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"role {user.role!r} is not permitted; requires one of {sorted(allowed)}",
            )
        return user

    return _dependency
