"""Rate limiting (section 54).

A simple in-memory sliding-window limiter usable as a FastAPI dependency.
Swap the store for Redis (`INCR` + `EXPIRE` / a sorted set) in a
multi-worker deployment — the interface is intentionally tiny so that
swap doesn't touch call sites.
"""

from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request, status


class InMemoryRateLimiter:
    def __init__(self, max_requests: int = 120, window_seconds: float = 60.0) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        bucket = self._hits[key]
        while bucket and now - bucket[0] > self.window_seconds:
            bucket.popleft()
        if len(bucket) >= self.max_requests:
            return False
        bucket.append(now)
        return True


default_limiter = InMemoryRateLimiter()


async def rate_limit_dependency(request: Request) -> None:
    key = request.headers.get("x-api-key") or (request.client.host if request.client else "unknown")
    if not default_limiter.allow(key):
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="rate limit exceeded")
