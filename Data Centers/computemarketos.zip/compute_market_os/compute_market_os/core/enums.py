"""Shared enumerations used across the whole platform."""

from __future__ import annotations

import enum


class HardwareCategory(str, enum.Enum):
    CPU = "CPU"
    GPU = "GPU"
    AI_ACCELERATOR = "AI_ACCELERATOR"
    TPU = "TPU"
    ASIC = "ASIC"
    FPGA = "FPGA"


class ProviderType(str, enum.Enum):
    HYPERSCALER = "hyperscaler"
    GPU_CLOUD = "gpu_cloud"
    COLOCATION = "colocation_provider"
    AI_CLOUD = "ai_cloud"
    ENTERPRISE_DATACENTER = "enterprise_datacenter"
    UNIVERSITY_CLUSTER = "university_cluster"
    PRIVATE_OPERATOR = "private_operator"
    EDGE_PROVIDER = "edge_provider"


class MarketSegment(str, enum.Enum):
    SPOT = "SPOT"
    RESERVED = "RESERVED"
    ON_DEMAND = "ON_DEMAND"
    AUCTION = "AUCTION"
    FORWARD = "FORWARD"
    LONG_TERM_CONTRACT = "LONG_TERM_CONTRACT"


class OrderSide(str, enum.Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, enum.Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    RESERVATION = "reservation"
    FORWARD_CONTRACT = "forward_contract"
    CAPACITY_REQUEST = "capacity_request"
    CAPACITY_OFFER = "capacity_offer"


class OrderStatus(str, enum.Enum):
    OPEN = "open"
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REJECTED = "rejected"


class AuctionType(str, enum.Enum):
    ENGLISH = "english"
    SEALED_BID = "sealed_bid"
    REVERSE = "reverse"
    CAPACITY_AUCTION = "capacity_auction"


class AuctionStatus(str, enum.Enum):
    OPEN = "open"
    CLEARED = "cleared"
    CANCELLED = "cancelled"
    FAILED = "failed"


class ContractStatus(str, enum.Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    BREACHED = "breached"
    CANCELLED = "cancelled"


class OutageType(str, enum.Enum):
    DATACENTER_OUTAGE = "datacenter_outage"
    RACK_OUTAGE = "rack_outage"
    GPU_FAILURE = "gpu_failure"
    NETWORK_OUTAGE = "network_outage"
    COOLING_FAILURE = "cooling_failure"
    POWER_EVENT = "power_event"


class SurveillanceLevel(str, enum.Enum):
    NORMAL = "normal"
    WATCH = "watch"
    ANOMALY = "anomaly"
    CRITICAL = "critical"


class Role(str, enum.Enum):
    ADMIN = "ADMIN"
    PROVIDER = "PROVIDER"
    BUYER = "BUYER"
    BROKER = "BROKER"
    ANALYST = "ANALYST"
    AUDITOR = "AUDITOR"


class WorkloadType(str, enum.Enum):
    LLM_TRAINING = "llm_training"
    LLM_INFERENCE = "llm_inference"
    RENDERING = "rendering"
    SIMULATION = "simulation"
    SCIENTIFIC_COMPUTING = "scientific_computing"
    ENTERPRISE = "enterprise_workloads"


class OptimisationGoal(str, enum.Enum):
    BEST_PRICE = "BEST_PRICE"
    FASTEST = "FASTEST"
    BEST_PERFORMANCE = "BEST_PERFORMANCE"
    LOWEST_CARBON = "LOWEST_CARBON"
    BEST_VALUE = "BEST_VALUE"
    BEST_LATENCY = "BEST_LATENCY"
