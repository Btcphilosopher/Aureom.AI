"""Application configuration.

Runtime settings (database URL, secrets, tick intervals) come from
environment variables / `.env` via pydantic-settings. Economic and market
configuration (hardware catalog, pricing model, regions, baskets, SLA
tiers ...) comes from the YAML files in `config/` — never hard-coded in
application code, per project requirements.
"""

from __future__ import annotations

import functools
import os
from pathlib import Path
from typing import Any

import yaml
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    environment: str = "development"
    log_level: str = "INFO"

    database_url: str = "sqlite:///./compute_market.db"
    redis_url: str = ""

    jwt_secret_key: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60

    market_tick_seconds: int = 5
    spot_price_update_seconds: int = 30

    config_dir: str = "config"


@functools.lru_cache
def get_settings() -> Settings:
    return Settings()


def _config_root() -> Path:
    settings = get_settings()
    here = Path(__file__).resolve()
    # compute_market_os/core/config.py -> project root is two levels up
    project_root = here.parents[2]
    candidate = project_root / settings.config_dir
    if candidate.exists():
        return candidate
    # fallback: relative to cwd (useful when installed as a package)
    return Path(settings.config_dir)


@functools.lru_cache
def load_yaml_config(name: str) -> dict[str, Any]:
    """Load a YAML file from the config/ directory, e.g. load_yaml_config('pricing')."""
    root = _config_root()
    path = root / f"{name}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def reload_configs() -> None:
    """Clear cached config so tests/tools can hot-reload YAML edits."""
    load_yaml_config.cache_clear()
