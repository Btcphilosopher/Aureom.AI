"""Internal event bus.

A light, dependency-free pub/sub bus used to decouple the matching engine,
pricing engine, ledger, and API/WebSocket layer. In production the same
interface can be backed by Redis pub/sub (see `broadcast()` usage in the
websocket router) — here it is in-process so the whole platform runs
without external services for tests and local development.
"""

from __future__ import annotations

import asyncio
import dataclasses
import datetime as dt
import enum
import logging
from collections import defaultdict
from typing import Any, Awaitable, Callable, DefaultDict

logger = logging.getLogger("compute_market_os.events")


class EventType(str, enum.Enum):
    CAPACITY_ADDED = "CapacityAdded"
    CAPACITY_REMOVED = "CapacityRemoved"
    ORDER_SUBMITTED = "OrderSubmitted"
    ORDER_CANCELLED = "OrderCancelled"
    ORDER_MATCHED = "OrderMatched"
    TRADE_EXECUTED = "TradeExecuted"
    RESERVATION_CREATED = "ReservationCreated"
    CONTRACT_CREATED = "ContractCreated"
    OUTAGE_DETECTED = "OutageDetected"
    PRICE_UPDATED = "PriceUpdated"
    USAGE_RECORDED = "UsageRecorded"
    INVOICE_GENERATED = "InvoiceGenerated"
    AUCTION_CLEARED = "AuctionCleared"
    SURVEILLANCE_FLAG = "SurveillanceFlag"


@dataclasses.dataclass(slots=True)
class MarketEvent:
    type: EventType
    payload: dict[str, Any]
    timestamp: dt.datetime = dataclasses.field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc)
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.type.value,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat(),
        }


Handler = Callable[[MarketEvent], Awaitable[None] | None]


class EventBus:
    """A minimal synchronous-or-async pub/sub bus.

    `publish` fans out to subscribers immediately (sync handlers run inline,
    async handlers are scheduled). All published events are also appended
    to an in-memory ring buffer so REST/WebSocket consumers can replay
    recent market activity without a separate log store.
    """

    def __init__(self, history_size: int = 5000) -> None:
        self._subscribers: DefaultDict[EventType, list[Handler]] = defaultdict(list)
        self._global_subscribers: list[Handler] = []
        self._history: list[MarketEvent] = []
        self._history_size = history_size

    def subscribe(self, event_type: EventType, handler: Handler) -> None:
        self._subscribers[event_type].append(handler)

    def unsubscribe(self, event_type: EventType, handler: Handler) -> None:
        try:
            self._subscribers[event_type].remove(handler)
        except ValueError:
            pass

    def subscribe_all(self, handler: Handler) -> None:
        self._global_subscribers.append(handler)

    def unsubscribe_all(self, handler: Handler) -> None:
        try:
            self._global_subscribers.remove(handler)
        except ValueError:
            pass

    def history(self, event_type: EventType | None = None, limit: int = 100) -> list[MarketEvent]:
        events = self._history
        if event_type is not None:
            events = [e for e in events if e.type == event_type]
        return events[-limit:]

    def publish(self, event: MarketEvent) -> None:
        self._history.append(event)
        if len(self._history) > self._history_size:
            self._history = self._history[-self._history_size :]

        for handler in self._subscribers.get(event.type, []) + self._global_subscribers:
            try:
                result = handler(event)
                if asyncio.iscoroutine(result):
                    try:
                        loop = asyncio.get_running_loop()
                        loop.create_task(result)
                    except RuntimeError:
                        asyncio.run(result)
            except Exception:  # noqa: BLE001 — a bad subscriber must not break the market
                logger.exception("event handler failed for %s", event.type)

    def emit(self, event_type: EventType, **payload: Any) -> MarketEvent:
        event = MarketEvent(type=event_type, payload=payload)
        self.publish(event)
        return event


# A process-wide default bus. Tests may construct their own EventBus()
# instance instead of relying on shared global state.
default_bus = EventBus()
