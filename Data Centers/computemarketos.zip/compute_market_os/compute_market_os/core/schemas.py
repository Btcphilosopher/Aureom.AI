"""Pydantic (v2) schemas — request/response contracts for the API layer.

Kept separate from the SQLAlchemy models (core.models) so the wire format
can evolve independently of storage, and so in-memory domain objects
(orderbook, matching engine) can share the same validated shapes.
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Hardware / providers / datacenters / inventory
# ---------------------------------------------------------------------------


class HardwareOut(ORMModel):
    id: str
    manufacturer: str
    model: str
    category: str
    memory_gb: float
    memory_bandwidth_gbps: float
    power_watts: float
    benchmarks: dict[str, float] = Field(default_factory=dict)


class ProviderOut(ORMModel):
    id: str
    name: str
    provider_type: str
    country: str
    region: str
    reliability: float


class DataCenterOut(ORMModel):
    id: str
    provider_id: str
    code: str
    region: str
    location: str
    latitude: float
    longitude: float
    power_capacity_mw: float
    it_load_mw: float
    cooling_capacity_mw: float
    network_capacity_tbps: float
    pue: float
    availability: float


class InventoryOut(ORMModel):
    id: str
    datacenter_id: str
    hardware_id: str
    installed_quantity: int
    available_quantity: int
    reserved_quantity: int
    running_quantity: int
    offline_quantity: int

    @property
    def utilisation(self) -> float:
        if self.installed_quantity == 0:
            return 0.0
        return self.running_quantity / self.installed_quantity


# ---------------------------------------------------------------------------
# Orders / trades
# ---------------------------------------------------------------------------


class OrderCreate(BaseModel):
    side: str  # BUY / SELL
    order_type: str = "limit"
    market_segment: str = "SPOT"
    hardware_id: str
    region: str
    quantity: int = Field(gt=0)
    duration_hours: float = Field(gt=0)
    limit_price: Optional[float] = None
    min_performance_score: Optional[float] = None
    min_memory_gb: Optional[float] = None
    max_latency_ms: Optional[float] = None
    start_time: Optional[dt.datetime] = None
    buyer_id: Optional[str] = None
    provider_id: Optional[str] = None


class OrderOut(ORMModel):
    id: str
    side: str
    order_type: str
    market_segment: str
    hardware_id: str
    region: str
    quantity: int
    filled_quantity: int
    duration_hours: float
    limit_price: Optional[float]
    status: str
    created_at: dt.datetime


class TradeOut(ORMModel):
    id: str
    buy_order_id: str
    sell_order_id: str
    hardware_id: str
    region: str
    quantity: int
    price: float
    duration_hours: float
    executed_at: dt.datetime


# ---------------------------------------------------------------------------
# Order book / market snapshot
# ---------------------------------------------------------------------------


class OrderBookLevel(BaseModel):
    price: float
    quantity: int
    order_count: int


class OrderBookSnapshot(BaseModel):
    hardware_id: str
    region: str
    bids: list[OrderBookLevel]
    asks: list[OrderBookLevel]
    best_bid: Optional[float]
    best_ask: Optional[float]
    spread: Optional[float]
    mid_price: Optional[float]
    depth: int
    liquidity: float
    timestamp: dt.datetime = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))


# ---------------------------------------------------------------------------
# Reservations / contracts
# ---------------------------------------------------------------------------


class ReservationCreate(BaseModel):
    buyer_id: Optional[str] = None
    provider_id: str
    datacenter_id: str
    hardware_id: str
    quantity: int = Field(gt=0)
    start_time: dt.datetime
    end_time: dt.datetime
    daily_window_start_hour: Optional[int] = None
    daily_window_end_hour: Optional[int] = None


class ReservationOut(ORMModel):
    id: str
    provider_id: str
    datacenter_id: str
    hardware_id: str
    quantity: int
    start_time: dt.datetime
    end_time: dt.datetime
    base_price_per_hour: float
    premium_fraction: float
    total_price_per_hour: float
    status: str


class ContractCreate(BaseModel):
    contract_type: str = "FORWARD"
    buyer_id: Optional[str] = None
    provider_id: str
    hardware_id: str
    quantity: int = Field(gt=0)
    region: str
    delivery_start: dt.datetime
    delivery_end: dt.datetime
    strike_price_per_hour: float
    sla_tier: str = "STANDARD"


class ContractOut(ORMModel):
    id: str
    contract_type: str
    provider_id: str
    hardware_id: str
    quantity: int
    region: str
    delivery_start: dt.datetime
    delivery_end: dt.datetime
    strike_price_per_hour: float
    gpu_hours_total: float
    gpu_hours_delivered: float
    sla_tier: str
    status: str


# ---------------------------------------------------------------------------
# Auctions
# ---------------------------------------------------------------------------


class AuctionCreate(BaseModel):
    auction_type: str = "sealed_bid"
    hardware_id: str
    region: str
    quantity_gpu_hours: float = Field(gt=0)
    provider_id: Optional[str] = None
    reserve_price: Optional[float] = None
    duration_minutes: int = 60


class BidCreate(BaseModel):
    bidder_id: str
    price: float = Field(gt=0)
    quantity: float = Field(gt=0)
    performance_score: Optional[float] = None


class AuctionOut(ORMModel):
    id: str
    auction_type: str
    hardware_id: str
    region: str
    quantity_gpu_hours: float
    reserve_price: float
    status: str
    clearing_price: Optional[float]
    winning_bidder_id: Optional[str]
    closes_at: dt.datetime


# ---------------------------------------------------------------------------
# AI markets
# ---------------------------------------------------------------------------


class InferenceOfferCreate(BaseModel):
    provider_id: str
    model_name: str
    quantisation: str = "fp16"
    hardware_id: str
    region: str
    tokens_per_second: float
    first_token_latency_ms: float
    price_per_1m_input_tokens: float
    price_per_1m_output_tokens: float


class InferenceRequest(BaseModel):
    model_name: str
    est_input_tokens: float
    est_output_tokens: float
    max_latency_ms: Optional[float] = None
    region: Optional[str] = None
    budget: Optional[float] = None


class TrainingRequest(BaseModel):
    model_name: str
    model_params_billion: float
    gpu_count: int = Field(gt=0)
    hardware_id: str
    tokens_billion: float
    interconnect: str = "infiniband"
    region: Optional[str] = None
    budget: Optional[float] = None


# ---------------------------------------------------------------------------
# Forecast / index
# ---------------------------------------------------------------------------


class ForecastPointOut(BaseModel):
    horizon: str
    target_time: dt.datetime
    predicted_value: float
    lower_bound: float
    upper_bound: float
    model_name: str


class IndexOut(BaseModel):
    index_code: str
    value: float
    components: dict[str, float]
    timestamp: dt.datetime


# ---------------------------------------------------------------------------
# Misc / market data
# ---------------------------------------------------------------------------


class MarketSummary(BaseModel):
    global_compute_price: float
    supply: float
    demand: float
    utilisation: float
    open_interest: float
    trade_volume_24h: float
    average_price_24h: float
    price_change_24h_pct: float
    disclaimer: str = "SIMULATED MARKET — NOT LIVE MARKET DATA"


class BuyerRequest(BaseModel):
    hardware_id: str
    quantity: int = Field(gt=0)
    duration_hours: float = Field(gt=0)
    region: Optional[str] = None
    preferred_regions: list[str] = Field(default_factory=list)
    max_price_per_hour: Optional[float] = None
    min_memory_gb: Optional[float] = None
    max_latency_ms: Optional[float] = None
    max_carbon_intensity: Optional[float] = None
    workload: Optional[str] = None
    deadline_hours: Optional[float] = None
    budget: Optional[float] = None


class RecommendationOut(BaseModel):
    label: str
    provider_id: str
    datacenter_id: str
    hardware_id: str
    region: str
    quantity: int
    price_per_hour: float
    total_cost: float
    estimated_performance_score: float
    estimated_latency_ms: Optional[float]
    estimated_carbon_kgco2e: Optional[float]
    notes: str = ""
