"""SQLAlchemy ORM models — the Market Database (section 51).

Tables: providers, datacenters, hardware, inventory, users (buyers/brokers/
etc.), orders, trades, reservations, contracts, usage, pricing (price
points), auctions + bids, market_indices, forecast, outages, sla, invoices,
surveillance flags, audit log.

IDs are UUID4 hex strings rather than DB-native UUID types so the same
schema runs unmodified on SQLite (dev/tests) and PostgreSQL (production).
"""

from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _uuid() -> str:
    return uuid.uuid4().hex


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(32), default="BUYER", index=True)
    organisation: Mapped[str | None] = mapped_column(String(255), nullable=True)
    api_key: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    actor_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    action: Mapped[str] = mapped_column(String(128))
    resource: Mapped[str] = mapped_column(String(255))
    extra: Mapped[dict] = mapped_column(JSON, default=dict)
    timestamp: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


# ---------------------------------------------------------------------------
# Providers / datacenters / hardware / inventory
# ---------------------------------------------------------------------------


class Provider(Base):
    __tablename__ = "providers"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(255))
    provider_type: Mapped[str] = mapped_column(String(64))
    country: Mapped[str] = mapped_column(String(8))
    region: Mapped[str] = mapped_column(String(16), index=True)
    reliability: Mapped[float] = mapped_column(Float, default=0.99)
    pricing_model: Mapped[dict] = mapped_column(JSON, default=dict)
    owner_user_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    datacenters: Mapped[list["DataCenter"]] = relationship(back_populates="provider")


class DataCenter(Base):
    __tablename__ = "datacenters"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    provider_id: Mapped[str] = mapped_column(String(32), ForeignKey("providers.id"), index=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    region: Mapped[str] = mapped_column(String(16), index=True)
    location: Mapped[str] = mapped_column(String(255))
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    power_capacity_mw: Mapped[float] = mapped_column(Float)
    it_load_mw: Mapped[float] = mapped_column(Float, default=0.0)
    cooling_capacity_mw: Mapped[float] = mapped_column(Float)
    network_capacity_tbps: Mapped[float] = mapped_column(Float)
    pue: Mapped[float] = mapped_column(Float, default=1.35)
    availability: Mapped[float] = mapped_column(Float, default=0.999)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    provider: Mapped["Provider"] = relationship(back_populates="datacenters")
    inventory: Mapped[list["InventoryItem"]] = relationship(back_populates="datacenter")


class Hardware(Base):
    __tablename__ = "hardware"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)  # matches config id, e.g. hw-h100-sxm
    manufacturer: Mapped[str] = mapped_column(String(64))
    model: Mapped[str] = mapped_column(String(128))
    category: Mapped[str] = mapped_column(String(32), index=True)
    memory_gb: Mapped[float] = mapped_column(Float)
    memory_bandwidth_gbps: Mapped[float] = mapped_column(Float)
    power_watts: Mapped[float] = mapped_column(Float)
    benchmarks: Mapped[dict] = mapped_column(JSON, default=dict)


class InventoryItem(Base):
    """A datacenter's holding of a given hardware SKU and its capacity split."""

    __tablename__ = "inventory"
    __table_args__ = (Index("ix_inventory_dc_hw", "datacenter_id", "hardware_id"),)

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    datacenter_id: Mapped[str] = mapped_column(String(32), ForeignKey("datacenters.id"))
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"))
    installed_quantity: Mapped[int] = mapped_column(Integer, default=0)
    available_quantity: Mapped[int] = mapped_column(Integer, default=0)
    reserved_quantity: Mapped[int] = mapped_column(Integer, default=0)
    running_quantity: Mapped[int] = mapped_column(Integer, default=0)
    offline_quantity: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)

    datacenter: Mapped["DataCenter"] = relationship(back_populates="inventory")
    hardware: Mapped["Hardware"] = relationship()


# ---------------------------------------------------------------------------
# Orders / trades / order book
# ---------------------------------------------------------------------------


class Order(Base):
    __tablename__ = "orders"
    __table_args__ = (
        Index("ix_orders_book_key", "hardware_id", "region", "side", "status"),
    )

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    side: Mapped[str] = mapped_column(String(8))  # BUY / SELL
    order_type: Mapped[str] = mapped_column(String(32))
    market_segment: Mapped[str] = mapped_column(String(32), default="SPOT")
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"), index=True)
    region: Mapped[str] = mapped_column(String(16), index=True)
    quantity: Mapped[int] = mapped_column(Integer)
    filled_quantity: Mapped[int] = mapped_column(Integer, default=0)
    duration_hours: Mapped[float] = mapped_column(Float)
    limit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    min_performance_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    min_memory_gb: Mapped[float | None] = mapped_column(Float, nullable=True)
    max_latency_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    start_time: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="open", index=True)
    buyer_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("users.id"), nullable=True)
    provider_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("providers.id"), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)
    cancelled_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Trade(Base):
    __tablename__ = "trades"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    buy_order_id: Mapped[str] = mapped_column(String(32), ForeignKey("orders.id"))
    sell_order_id: Mapped[str] = mapped_column(String(32), ForeignKey("orders.id"))
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"), index=True)
    region: Mapped[str] = mapped_column(String(16), index=True)
    quantity: Mapped[int] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Float)
    duration_hours: Mapped[float] = mapped_column(Float)
    buyer_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    seller_provider_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    executed_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


# ---------------------------------------------------------------------------
# Reservations / contracts
# ---------------------------------------------------------------------------


class Reservation(Base):
    __tablename__ = "reservations"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    buyer_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    provider_id: Mapped[str] = mapped_column(String(32), ForeignKey("providers.id"))
    datacenter_id: Mapped[str] = mapped_column(String(32), ForeignKey("datacenters.id"))
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"))
    quantity: Mapped[int] = mapped_column(Integer)
    start_time: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    end_time: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    daily_window_start_hour: Mapped[int | None] = mapped_column(Integer, nullable=True)
    daily_window_end_hour: Mapped[int | None] = mapped_column(Integer, nullable=True)
    base_price_per_hour: Mapped[float] = mapped_column(Float)
    premium_fraction: Mapped[float] = mapped_column(Float)
    total_price_per_hour: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(24), default="active")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ComputeContract(Base):
    __tablename__ = "contracts"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    contract_type: Mapped[str] = mapped_column(String(32), default="FORWARD")  # FORWARD | LONG_TERM | RESERVATION
    buyer_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    provider_id: Mapped[str] = mapped_column(String(32), ForeignKey("providers.id"))
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"))
    quantity: Mapped[int] = mapped_column(Integer)
    region: Mapped[str] = mapped_column(String(16))
    delivery_start: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    delivery_end: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    strike_price_per_hour: Mapped[float] = mapped_column(Float)
    gpu_hours_total: Mapped[float] = mapped_column(Float)
    gpu_hours_delivered: Mapped[float] = mapped_column(Float, default=0.0)
    sla_tier: Mapped[str] = mapped_column(String(24), default="STANDARD")
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


# ---------------------------------------------------------------------------
# Usage / pricing / indices / forecast
# ---------------------------------------------------------------------------


class UsageRecord(Base):
    __tablename__ = "usage"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    buyer_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    contract_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("contracts.id"), nullable=True)
    reservation_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("reservations.id"), nullable=True)
    hardware_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    metric: Mapped[str] = mapped_column(String(32))  # gpu_hours, cpu_hours, ram_gb_hours, storage_gb_hours, network_gb, tokens
    quantity: Mapped[float] = mapped_column(Float)
    unit_price: Mapped[float] = mapped_column(Float, default=0.0)
    recorded_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


class PricePoint(Base):
    __tablename__ = "pricing"
    __table_args__ = (Index("ix_price_hw_region_time", "hardware_id", "region", "timestamp"),)

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"))
    region: Mapped[str] = mapped_column(String(16))
    market_segment: Mapped[str] = mapped_column(String(32), default="SPOT")
    price: Mapped[float] = mapped_column(Float)
    volume: Mapped[float] = mapped_column(Float, default=0.0)
    timestamp: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


class MarketIndexPoint(Base):
    __tablename__ = "market_indices"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    index_code: Mapped[str] = mapped_column(String(16), index=True)
    value: Mapped[float] = mapped_column(Float)
    components: Mapped[dict] = mapped_column(JSON, default=dict)
    timestamp: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)


class ForecastPoint(Base):
    __tablename__ = "forecast"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    metric: Mapped[str] = mapped_column(String(32))  # price, demand, supply, utilisation
    hardware_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    region: Mapped[str | None] = mapped_column(String(16), nullable=True)
    horizon: Mapped[str] = mapped_column(String(16))  # 1h, 6h, 24h, 7d, 30d
    generated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    target_time: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    predicted_value: Mapped[float] = mapped_column(Float)
    lower_bound: Mapped[float] = mapped_column(Float)
    upper_bound: Mapped[float] = mapped_column(Float)
    model_name: Mapped[str] = mapped_column(String(64), default="statistical")


# ---------------------------------------------------------------------------
# Auctions
# ---------------------------------------------------------------------------


class Auction(Base):
    __tablename__ = "auctions"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    auction_type: Mapped[str] = mapped_column(String(24))
    hardware_id: Mapped[str] = mapped_column(String(32), ForeignKey("hardware.id"))
    region: Mapped[str] = mapped_column(String(16))
    quantity_gpu_hours: Mapped[float] = mapped_column(Float)
    provider_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("providers.id"), nullable=True)
    reserve_price: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(16), default="open")
    clearing_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    winning_bidder_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    closes_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    cleared_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    bids: Mapped[list["AuctionBid"]] = relationship(back_populates="auction")


class AuctionBid(Base):
    __tablename__ = "auction_bids"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    auction_id: Mapped[str] = mapped_column(String(32), ForeignKey("auctions.id"), index=True)
    bidder_id: Mapped[str] = mapped_column(String(64))
    price: Mapped[float] = mapped_column(Float)
    quantity: Mapped[float] = mapped_column(Float)
    performance_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    submitted_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    auction: Mapped["Auction"] = relationship(back_populates="bids")


# ---------------------------------------------------------------------------
# Outages / SLA / surveillance / invoices
# ---------------------------------------------------------------------------


class Outage(Base):
    __tablename__ = "outages"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    datacenter_id: Mapped[str] = mapped_column(String(32), ForeignKey("datacenters.id"), index=True)
    outage_type: Mapped[str] = mapped_column(String(32))
    hardware_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    capacity_removed: Mapped[int] = mapped_column(Integer, default=0)
    description: Mapped[str] = mapped_column(Text, default="")
    started_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    resolved_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="active")


class SLARecord(Base):
    __tablename__ = "sla"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    contract_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("contracts.id"), nullable=True)
    reservation_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("reservations.id"), nullable=True)
    tier: Mapped[str] = mapped_column(String(24), default="STANDARD")
    period_start: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    period_end: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    uptime_target: Mapped[float] = mapped_column(Float)
    uptime_actual: Mapped[float] = mapped_column(Float)
    latency_target_ms: Mapped[float] = mapped_column(Float)
    latency_actual_ms: Mapped[float] = mapped_column(Float)
    compliant: Mapped[bool] = mapped_column(Boolean)
    credit_fraction: Mapped[float] = mapped_column(Float, default=0.0)
    credit_amount: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class Invoice(Base):
    __tablename__ = "invoices"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    invoice_number: Mapped[str] = mapped_column(String(64), unique=True)
    buyer_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    period_start: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    period_end: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    line_items: Mapped[list] = mapped_column(JSON, default=list)
    subtotal: Mapped[float] = mapped_column(Float)
    tax: Mapped[float] = mapped_column(Float, default=0.0)
    discount: Mapped[float] = mapped_column(Float, default=0.0)
    credit: Mapped[float] = mapped_column(Float, default=0.0)
    total: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(16), default="issued")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class SurveillanceFlag(Base):
    __tablename__ = "surveillance_flags"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uuid)
    level: Mapped[str] = mapped_column(String(16))  # normal|watch|anomaly|critical
    reason: Mapped[str] = mapped_column(String(255))
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    related_order_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    related_trade_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    related_actor_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
