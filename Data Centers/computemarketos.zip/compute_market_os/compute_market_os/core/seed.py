"""Seeds the `hardware` table from config/hardware.yaml.

Idempotent — safe to call on every app/CLI startup. This is the one piece
of "seed data" that is not synthetic: it's the configured hardware
catalog every other synthetic/demo table (providers, datacenters,
inventory) references by id.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from compute_market_os.core import models
from compute_market_os.domain.hardware import load_hardware_catalog


def seed_hardware_catalog(session: Session) -> int:
    catalog = load_hardware_catalog()
    existing_ids = {row.id for row in session.query(models.Hardware.id).all()}
    created = 0
    for hw in catalog.values():
        if hw.id in existing_ids:
            continue
        session.add(
            models.Hardware(
                id=hw.id,
                manufacturer=hw.manufacturer,
                model=hw.model,
                category=hw.category,
                memory_gb=hw.memory_gb,
                memory_bandwidth_gbps=hw.memory_bandwidth_gbps,
                power_watts=hw.power_watts,
                benchmarks=hw.benchmarks,
            )
        )
        created += 1
    session.commit()
    return created
