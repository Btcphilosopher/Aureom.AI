"""Compute Market OS CLI (section 74).

    compute-market start
    compute-market simulate
    compute-market prices
    compute-market capacity
    compute-market auction
    compute-market forecast
    compute-market index
    compute-market health
    compute-market seed-demo     (extra: loads the synthetic demo market)

SIMULATED MARKET — `simulate`/`seed-demo` output is synthetic, not live
market data.
"""

from __future__ import annotations

import datetime as dt

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(help="Compute Market OS — Compute Capacity Exchange & Pricing Engine CLI")
console = Console()


@app.command()
def start(host: str = "0.0.0.0", port: int = 8000, reload: bool = False):
    """Launch the FastAPI market server."""
    import uvicorn

    uvicorn.run("compute_market_os.api.main:app", host=host, port=port, reload=reload)


@app.command()
def health():
    """Check database connectivity and print catalog/config status."""
    from sqlalchemy import text

    from compute_market_os.core.database import init_db, session_scope
    from compute_market_os.domain.hardware import load_hardware_catalog

    init_db()
    catalog = load_hardware_catalog()
    try:
        with session_scope() as session:
            session.execute(text("SELECT 1"))
        db_ok = True
    except Exception as exc:  # noqa: BLE001
        db_ok = False
        console.print(f"[red]database error: {exc}[/red]")

    table = Table(title="Compute Market OS — health")
    table.add_column("component")
    table.add_column("status")
    table.add_row("database", "[green]ok[/green]" if db_ok else "[red]failed[/red]")
    table.add_row("hardware catalog", f"{len(catalog)} SKUs loaded")
    console.print(table)


@app.command("seed-demo")
def seed_demo(seed: int = 42, target_gpus: int = 12000):
    """Populate the database with the synthetic demonstration market
    (section 73): 10 providers, 20 datacenters, 5 regions, 6 accelerator
    types, 10,000+ GPU units. SIMULATED MARKET — NOT LIVE MARKET DATA."""
    from compute_market_os.core.database import init_db, session_scope
    from compute_market_os.data.synthetic.generator import generate_demo_market

    init_db()
    with session_scope() as session:
        summary = generate_demo_market(session, seed=seed, target_total_gpus=target_gpus)
    console.print("[bold yellow]SIMULATED MARKET — NOT LIVE MARKET DATA[/bold yellow]")
    for k, v in summary.items():
        console.print(f"  {k}: {v}")


@app.command()
def prices(
    hardware_id: str = typer.Option("hw-h100-sxm"),
    utilisation: float = typer.Option(0.75, min=0.0, max=1.0),
    electricity_price_per_kwh: float = typer.Option(0.15),
):
    """Print a full price breakdown (spot/on-demand/reservation/forward/
    auction-reserve) for one hardware SKU at a given utilisation."""
    from compute_market_os.pricing.pricing_engine import PricingEngine

    engine = PricingEngine()
    kwargs = dict(electricity_price_per_kwh=electricity_price_per_kwh)
    breakdown = engine.compute_price(hardware_id, utilisation, **kwargs)

    table = Table(title=f"Compute Price — {hardware_id} @ {utilisation:.0%} utilisation")
    table.add_column("component")
    table.add_column("£/hour", justify="right")
    for field, value in breakdown.as_dict().items():
        if field in ("hardware_id", "utilisation"):
            continue
        table.add_row(field, f"{value:.6f}" if isinstance(value, float) else str(value))
    console.print(table)

    console.print(f"SPOT:        {engine.spot_price(hardware_id, utilisation, **kwargs):.4f}")
    console.print(f"ON-DEMAND:   {engine.on_demand_price(hardware_id, utilisation, **kwargs):.4f}")
    console.print(f"RESERVATION: {engine.reservation_price(hardware_id, utilisation, duration_hours=720, **kwargs):.4f}")
    console.print(f"FORWARD+30d: {engine.forward_price(hardware_id, utilisation, days_ahead=30, **kwargs):.4f}")
    console.print(f"AUCTION RSV: {engine.auction_reserve_price(hardware_id, utilisation, **kwargs):.4f}")


@app.command()
def capacity(hardware_id: str = typer.Option(None), region: str = typer.Option(None)):
    """Print aggregate capacity utilisation from the database."""
    from compute_market_os.core import models
    from compute_market_os.core.database import init_db, session_scope
    from compute_market_os.domain.inventory import InventorySnapshot, UtilisationEngine

    init_db()
    with session_scope() as session:
        query = session.query(models.InventoryItem).join(models.DataCenter)
        if hardware_id:
            query = query.filter(models.InventoryItem.hardware_id == hardware_id)
        if region:
            query = query.filter(models.DataCenter.region == region)
        snapshots = [InventorySnapshot.from_orm_row(row) for row in query.all()]

    if not snapshots:
        console.print("[yellow]No inventory found — run `compute-market seed-demo` first.[/yellow]")
        raise typer.Exit(code=0)

    stats = UtilisationEngine.aggregate(snapshots)
    table = Table(title="Capacity summary")
    table.add_column("metric")
    table.add_column("value", justify="right")
    for k, v in stats.items():
        table.add_row(k, str(v))
    console.print(table)


@app.command()
def auction(
    auction_type: str = typer.Option("capacity_auction"),
    hardware_id: str = typer.Option("hw-h100-sxm"),
    region: str = typer.Option("TPE"),
    quantity_gpu_hours: float = typer.Option(1000.0),
    reserve_price: float = typer.Option(1.50),
):
    """Run a small demo auction with a few synthetic bids and print the
    clearing result (sections 19-21)."""
    from compute_market_os.market.auction_engine import AuctionEngine, Bid

    engine = AuctionEngine()
    live = engine.create_auction(auction_type, hardware_id, region, quantity_gpu_hours, reserve_price)
    demo_bids = [("buyer-A", 2.20, 400), ("buyer-B", 2.15, 350), ("buyer-C", 2.05, 600)]
    if auction_type == "reverse":
        demo_bids = [("provider-A", 1.95, 400), ("provider-B", 2.05, 350), ("provider-C", 1.75, 600)]
    for bidder, price, qty in demo_bids:
        engine.submit_bid(live, Bid(bidder_id=bidder, price=price, quantity=qty))

    result = engine.clear(live)
    console.print(f"[bold]{auction_type}[/bold] clearing result for {hardware_id}/{region}:")
    console.print(f"  status: {result.status.value}")
    console.print(f"  clearing_price: {result.clearing_price}")
    console.print(f"  total_quantity_cleared: {result.total_quantity_cleared}")
    console.print(f"  winners: {result.winners}")


@app.command()
def forecast(hardware_id: str = typer.Option("hw-h100-sxm"), region: str = typer.Option("TPE")):
    """Run a demo price forecast from a synthetic random-walk history."""
    import numpy as np

    from compute_market_os.forecasting.price_forecast import PriceForecastEngine

    rng = np.random.default_rng(7)
    now = dt.datetime.now(dt.timezone.utc)
    n = 48
    prices = list(2.0 * np.exp(np.cumsum(rng.normal(0.001, 0.01, n))))
    timestamps = [now - dt.timedelta(hours=n - i) for i in range(n)]

    engine = PriceForecastEngine()
    points = engine.forecast(prices, timestamps)

    table = Table(title=f"Price forecast (demo synthetic history) — {hardware_id}/{region}")
    table.add_column("horizon")
    table.add_column("predicted", justify="right")
    table.add_column("lower", justify="right")
    table.add_column("upper", justify="right")
    for p in points:
        table.add_row(p.horizon, f"{p.predicted_price:.4f}", f"{p.lower_bound:.4f}", f"{p.upper_bound:.4f}")
    console.print(table)


@app.command()
def index(index_code: str = typer.Option("CPI-TW"), utilisation: float = typer.Option(0.75)):
    """Compute a named Compute Price Index from live pricing-engine
    output for its configured hardware basket."""
    from compute_market_os.pricing.index import ComputePriceIndexEngine
    from compute_market_os.pricing.pricing_engine import PricingEngine

    index_engine = ComputePriceIndexEngine()
    pricing_engine = PricingEngine()
    basket = index_engine.basket(index_code)

    component_prices = {}
    for component in basket["weights"]:
        if component.startswith("hw-"):
            component_prices[component] = pricing_engine.spot_price(component, utilisation)

    result = index_engine.compute(index_code, component_prices)
    console.print(f"[bold]{index_code}[/bold] = {result.value:.4f}")
    for component, contribution in result.components.items():
        console.print(f"  {component}: {contribution:.4f}")
    if result.missing_components:
        console.print(f"[yellow]missing components (not priced): {result.missing_components}[/yellow]")


@app.command()
def simulate(
    num_buyers: int = typer.Option(30),
    num_providers: int = typer.Option(10),
    duration_hours: float = typer.Option(168.0),
    seed: int = typer.Option(42),
    shock: str = typer.Option(None, help="e.g. ai_demand_spike:0.4:24 (type:magnitude:at_tick)"),
):
    """Run the SimPy-based market simulator and print a summary.
    SIMULATED MARKET — NOT LIVE MARKET DATA."""
    from compute_market_os.simulation.market_simulator import ComputeMarketSimulation
    from compute_market_os.simulation.shocks import MarketShock, ShockType

    sim = ComputeMarketSimulation(seed=seed)
    sim.generate_participants(num_buyers, num_providers)

    if shock:
        shock_type, magnitude, at_tick = shock.split(":")
        sim.schedule_shock(MarketShock(shock_type=ShockType(shock_type), magnitude=float(magnitude), at_tick=int(at_tick)))

    console.print("[bold yellow]SIMULATED MARKET — NOT LIVE MARKET DATA[/bold yellow]")
    result = sim.run(duration_hours=duration_hours)

    console.print(f"orders_submitted: {result.orders_submitted}")
    console.print(f"trade_count: {result.trade_count}")
    console.print(f"shocks_applied: {result.shocks_applied}")
    if not result.price_history.empty:
        console.print(result.price_history.tail(10).to_string(index=False))


if __name__ == "__main__":
    app()
